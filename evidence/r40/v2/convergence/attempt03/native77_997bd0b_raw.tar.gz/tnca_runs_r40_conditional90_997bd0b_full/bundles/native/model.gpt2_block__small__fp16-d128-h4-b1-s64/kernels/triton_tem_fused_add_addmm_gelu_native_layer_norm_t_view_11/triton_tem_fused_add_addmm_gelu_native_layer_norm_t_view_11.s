    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s5, #512
    .li       s6, #2147483647
    s.mul        s7, s1, s5
    .li       s1, #2147483647
    s.movz       s5, #256
    s.movz       s8, #2
    .li       s9, #68719476752
    .li       s10, #8589934592
    s.rdspecial  s11, arg_base
    s.ld.d       s12, [s2, #8]                   // arg_A: device_ptr64 at arg_base+8
    s.add        s13, s3, s7                     // this context's own scratch
    s.rdspecial  s3, role_id
    s.addi       s7, s13, #0                     // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s13, #512
    .li       s14, #2147483647
    s.mul        s15, s3, s13
    .li       s3, #2147483647
    s.movz       s13, #256
    s.movz       s16, #2
    .li       s17, #68719476752
    s.ld.d       s18, [s2, #0]                   // in_ptr0: device_ptr64 at arg_base+0
    .li       s19, #8589934592
    s.movz       s20, #0
    s.movz       s20, #0
    s.ld.d       s20, [s2, #16]                  // arg_B: device_ptr64 at arg_base+16
    s.movz       s21, #32
    s.ld.d       s22, [s2, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    s.movz       s2, #0
    s.st.d       [s7, #0], s12
    s.movz       s12, #0
    s.st.d       [s7, #8], s6
    s.movz       s6, #0
    s.cmp.lt     s23, s21, s6
    s.st.d       [s7, #16], s1
    s.movz       s1, #0
    s.sub        s6, s1, s23
    s.movz       s1, #4
    s.st.d       [s7, #48], s5
    s.movz       s5, #1
    s.st.d       [s7, #56], s8
    s.cmp.lt     s8, s4, s2
    s.movz       s2, #0
    s.sub        s23, s12, s8
    s.movz       s8, #0
    s.st.d       [s7, #88], s9
    s.xor        s9, s4, s23
    s.sub        s12, s9, s23
    s.st.d       [s7, #104], s10
    s.lshri      s9, s12, #5
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s7, s23, s6
    s.movz       s10, #0
    s.ld.d       s23, [s11, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s11, s23, s15                   // this context's own scratch
    s.xor        s15, s9, s7
    s.cmp.lt     s23, s4, s8
    s.sub        s8, s15, s7
    s.movz       s7, #0
    s.sub        s15, s1, s8
    s.muli       s1, s9, #32
    s.min.s      s9, s15, s5
    s.addi       s15, s11, #256                  // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.cmp.lt     s11, s9, s2
    s.sub        s2, s7, s23
    s.movz       s7, #0
    s.st.d       [s15, #0], s20
    s.sub        s20, s10, s11
    s.movz       s10, #1
    s.xor        s11, s4, s2
    s.sub        s23, s12, s1
    s.xor        s1, s21, s6
    s.movz       s12, #0
    s.sub        s23, s1, s6
    s.st.d       [s15, #8], s14
    s.xor        s1, s9, s20
    s.sub        s6, s11, s2
    s.st.d       [s15, #16], s3
    s.sub        s3, s1, s20
    s.addi       s1, s7, #0
    s.st.d       [s15, #48], s13
    s.cmp.eq     s7, s3, s10
    s.addi       s10, s12, #0
    s.st.d       [s15, #56], s16
    s.st.d       [s15, #88], s17
    s.st.d       [s15, #104], s19
    fence.release.device
    td.load      d1, [s15]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s1, s6
    br.nz        s7, sdiv_done_1
    s.movz       s7, #0
    s.movz       s11, #31
    s.mov        s1, s7
    s.addi       s7, s11, #0
sdiv_2:
    s.lshr       s11, s6, s7
    s.shli       s12, s10, #1
    s.andi       s13, s11, #1
    s.movz       s11, #0
    s.or         s14, s12, s13
    s.movz       s12, #1
    s.cmp.geu    s13, s14, s3
    s.shl        s15, s12, s7
    s.sub        s12, s11, s13
    s.subi       s11, s7, #1
    s.and        s13, s3, s12
    s.and        s16, s15, s12
    s.sub        s12, s14, s13
    s.or         s13, s1, s16
    s.mov        s10, s12
    s.mov        s1, s13
    s.mov        s7, s11
    s.movz       s11, #0
    s.cmp.ge     s12, s7, s11
    br.nz        s12, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s3, #0
    s.cmp.lt     s6, s4, s1
    s.movz       s1, #0
    s.sub        s7, s3, s6
    s.movz       s3, #0
    s.xor        s6, s4, s7
    s.movz       s4, #0
    s.sub        s11, s6, s7
    s.cmp.lt     s6, s9, s1
    s.lshri      s1, s11, #5
    s.movz       s12, #0
    s.muli       s13, s1, #32
    s.sub        s1, s4, s6
    s.movz       s4, #0
    s.cmp.lt     s6, s21, s12
    s.xor        s12, s9, s1
    s.sub        s9, s11, s13
    s.movz       s11, #0
    s.xor        s13, s9, s7
    s.xor        s9, s10, s2
    s.sub        s10, s13, s7
    s.sub        s7, s11, s6
    s.cmp.lt     s6, s10, s3
    s.sub        s3, s12, s1
    s.sub        s11, s4, s6
    s.movz       s4, #0
    s.xor        s6, s10, s11
    s.movz       s10, #1
    s.sub        s12, s9, s2
    s.xor        s2, s21, s7
    s.sub        s9, s6, s11
    s.movz       s6, #0
    s.addi       s13, s4, #0
    s.cmp.eq     s4, s3, s10
    s.add        s10, s8, s12
    s.sub        s8, s2, s7
    s.addi       s2, s6, #0
    s.mov        s13, s9
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s6, #31
    s.mov        s13, s4
    s.addi       s4, s6, #0
sdiv_4:
    s.lshr       s6, s9, s4
    s.shli       s7, s2, #1
    s.andi       s8, s6, #1
    s.movz       s6, #0
    s.or         s12, s7, s8
    s.movz       s7, #1
    s.cmp.geu    s8, s12, s3
    s.shl        s14, s7, s4
    s.sub        s7, s6, s8
    s.subi       s6, s4, #1
    s.and        s8, s3, s7
    s.and        s15, s14, s7
    s.sub        s7, s12, s8
    s.or         s8, s13, s15
    s.mov        s2, s7
    s.mov        s13, s8
    s.mov        s4, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s4, s6
    br.nz        s7, sdiv_4
sdiv_done_3:
    s.xor        s2, s11, s1
    s.movz       s1, #16
    s.xor        s3, s13, s2
    s.mul        s4, s10, s1
    s.sub        s6, s3, s2
    s.movz       s2, #0
    s.mul        s3, s6, s1
    v.splat      v0, s10
    s.andi       s7, s4, #63
    v.splat      v1, s2
    v.splat      v2, s6
    s.andi       s6, s3, #511
    v.splat      v3, s2
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s4
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s3
    v.splat      v1, s7
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s6
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.movz       s8, #8
    s.addi       s9, s2, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s2, s9, s8
    br.nz        s2, endfor_6
    s.mul        s2, s9, s1
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s10, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s11, s9, s5
    s.movz       s12, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s2                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s13, s10
    mb.wait      s10
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s14, s6                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s2                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s14, s13
    mb.wait      s13
    mb.arm       s2, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s2
    mb.wait      s2
    s.mov        s9, s11
    br.nz        s12, for_5
endfor_6:
    s.movz       s1, #0
    s.movz       s5, #0
    s.add        s6, s1, s3                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s6
    s.add        s1, s5, s4                      // the tile origin
    s.movz       s5, #64
    s.movz       s6, #512
    s.muli       s7, s3, #2                      // a runtime tile origin, x2
    v.splat      v2, s1
    v.splat      v3, s5
    v.add        v4, v0, v1
    v.splat      v0, s6
    v.cmp.lt     p1, v2, v3
    s.add        s5, s18, s7                     // the tile origin
    v.cmp.lt     p2, v4, v0
    s.movz       s6, #0
    p.and        p3, p1, p2
    a.vread      v0, a0, s6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    s.addi       s6, s1, #1
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s7, #0
    v.splat      v2, s6
    s.movz       s6, #1
    s.addi       s8, s1, #2
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.splat      v2, s8
    s.movz       s8, #1
    s.movz       s9, #2
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s11, s1, #3
    vf.cvt.f16.f32 v2, v1
    v.splat      v1, s11
    s.movz       s11, #2
    s.movz       s12, #3
    vf.add       v4, v0, v2
    vf.cvt.f32.f16 v0, v4
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s7, v2
    a.vread      v0, a0, s6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s6, s1, #4
    s.movz       s7, #3
    v.splat      v1, s6
    s.movz       s6, #4
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.f16 v0, v2
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s8, v2
    a.vread      v0, a0, s9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s8, s1, #5
    s.movz       s9, #4
    v.splat      v1, s8
    s.movz       s8, #5
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.f16 v0, v2
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s11, v2
    a.vread      v0, a0, s12
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s11, s1, #6
    s.movz       s12, #5
    v.splat      v1, s11
    s.movz       s11, #6
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.f16 v0, v2
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s7, v2
    a.vread      v0, a0, s6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s6, s1, #7
    s.movz       s7, #6
    v.splat      v1, s6
    s.movz       s6, #7
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.f16 v0, v2
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s9, v2
    a.vread      v0, a0, s8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s8, s1, #8
    s.movz       s9, #7
    v.splat      v1, s8
    s.movz       s8, #8
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.f16 v0, v2
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s12, v2
    a.vread      v0, a0, s11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s11, s1, #9
    s.movz       s12, #8
    v.splat      v1, s11
    s.movz       s11, #9
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.f16 v0, v2
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s7, v2
    a.vread      v0, a0, s6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s6, s1, #10
    s.movz       s7, #9
    v.splat      v1, s6
    s.movz       s6, #10
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.f16 v0, v2
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s9, v2
    a.vread      v0, a0, s8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s8, s1, #11
    s.movz       s9, #10
    v.splat      v1, s8
    s.movz       s8, #11
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.f16 v0, v2
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s12, v2
    a.vread      v0, a0, s11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s11, s1, #12
    s.movz       s12, #11
    v.splat      v1, s11
    s.movz       s11, #12
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.f16 v0, v2
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s7, v2
    a.vread      v0, a0, s6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s6, s1, #13
    s.movz       s7, #12
    v.splat      v1, s6
    s.movz       s6, #13
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.f16 v0, v2
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s9, v2
    a.vread      v0, a0, s8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s8, s1, #14
    s.movz       s9, #13
    v.splat      v1, s8
    s.movz       s8, #14
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.f16 v0, v2
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s12, v2
    a.vread      v0, a0, s11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s11, s1, #15
    s.movz       s12, #14
    v.splat      v1, s11
    s.movz       s11, #15
    .li       s14, #1027024659
    v.splat      v4, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s14, #1061962282
    v.splat      v5, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s14, #1056964608
    v.splat      v6, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.f16.f32 v7, v2
    vf.add       v2, v0, v7
    vf.cvt.f32.f16 v0, v2
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s7, v2
    a.vread      v0, a0, s6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s5, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.movz       s6, #15
    s.movz       s7, #0
    vf.cvt.f16.f32 v1, v2
    vf.add       v2, v0, v1
    vf.cvt.f32.f16 v0, v2
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s9, v1
    a.vread      v0, a0, s8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s5, #0]
    s.movz       s8, #0
    s.movz       s9, #0
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s12, v1
    a.vread      v0, a0, s11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    s.movz       s5, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s11, #0
    s.movz       s12, #1
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    vf.cvt.f16.f32 v1, v0
    a.vwrite     a1, s6, v1
    a.vread      v0, a1, s7
    a.vread      v1, a1, s8
    a.vread      v2, a1, s9
    a.vread      v7, a1, s5
    s.movz       s5, #1
    vf.mul       v8, v1, v2
    s.movz       s6, #1
    s.movz       s7, #1
    s.movz       s8, #1
    s.movz       s9, #2
    vf.mul       v1, v8, v7
    vf.mul       v2, v1, v4
    vf.add       v1, v0, v2
    vf.mul       v0, v1, v5
    a.vwrite     a2, s11, v0
    a.vread      v0, a1, s12
    a.vread      v1, a1, s5
    a.vread      v2, a1, s6
    a.vread      v7, a1, s7
    s.movz       s5, #2
    vf.mul       v8, v1, v2
    s.movz       s6, #2
    s.movz       s7, #2
    s.movz       s11, #2
    s.movz       s12, #3
    vf.mul       v1, v8, v7
    vf.mul       v2, v1, v4
    vf.add       v1, v0, v2
    vf.mul       v0, v1, v5
    a.vwrite     a2, s8, v0
    a.vread      v0, a1, s9
    a.vread      v1, a1, s5
    a.vread      v2, a1, s6
    a.vread      v7, a1, s7
    s.movz       s5, #3
    vf.mul       v8, v1, v2
    s.movz       s6, #3
    s.movz       s7, #3
    s.movz       s8, #3
    s.movz       s9, #4
    vf.mul       v1, v8, v7
    vf.mul       v2, v1, v4
    vf.add       v1, v0, v2
    vf.mul       v0, v1, v5
    a.vwrite     a2, s11, v0
    a.vread      v0, a1, s12
    a.vread      v1, a1, s5
    a.vread      v2, a1, s6
    a.vread      v7, a1, s7
    s.movz       s5, #4
    vf.mul       v8, v1, v2
    s.movz       s6, #4
    s.movz       s7, #4
    s.movz       s11, #4
    s.movz       s12, #5
    vf.mul       v1, v8, v7
    vf.mul       v2, v1, v4
    vf.add       v1, v0, v2
    vf.mul       v0, v1, v5
    a.vwrite     a2, s8, v0
    a.vread      v0, a1, s9
    a.vread      v1, a1, s5
    a.vread      v2, a1, s6
    a.vread      v7, a1, s7
    s.movz       s5, #5
    vf.mul       v8, v1, v2
    s.movz       s6, #5
    s.movz       s7, #5
    s.movz       s8, #5
    s.movz       s9, #6
    vf.mul       v1, v8, v7
    vf.mul       v2, v1, v4
    vf.add       v1, v0, v2
    vf.mul       v0, v1, v5
    a.vwrite     a2, s11, v0
    a.vread      v0, a1, s12
    a.vread      v1, a1, s5
    a.vread      v2, a1, s6
    a.vread      v7, a1, s7
    s.movz       s5, #6
    vf.mul       v8, v1, v2
    s.movz       s6, #6
    s.movz       s7, #6
    s.movz       s11, #6
    s.movz       s12, #7
    vf.mul       v1, v8, v7
    vf.mul       v2, v1, v4
    vf.add       v1, v0, v2
    vf.mul       v0, v1, v5
    a.vwrite     a2, s8, v0
    a.vread      v0, a1, s9
    a.vread      v1, a1, s5
    a.vread      v2, a1, s6
    a.vread      v7, a1, s7
    s.movz       s5, #7
    vf.mul       v8, v1, v2
    s.movz       s6, #7
    s.movz       s7, #7
    s.movz       s8, #7
    s.movz       s9, #8
    vf.mul       v1, v8, v7
    vf.mul       v2, v1, v4
    vf.add       v1, v0, v2
    vf.mul       v0, v1, v5
    a.vwrite     a2, s11, v0
    a.vread      v0, a1, s12
    a.vread      v1, a1, s5
    a.vread      v2, a1, s6
    a.vread      v7, a1, s7
    s.movz       s5, #8
    vf.mul       v8, v1, v2
    s.movz       s6, #8
    s.movz       s7, #8
    s.movz       s11, #8
    s.movz       s12, #9
    vf.mul       v1, v8, v7
    vf.mul       v2, v1, v4
    vf.add       v1, v0, v2
    vf.mul       v0, v1, v5
    a.vwrite     a2, s8, v0
    a.vread      v0, a1, s9
    a.vread      v1, a1, s5
    a.vread      v2, a1, s6
    a.vread      v7, a1, s7
    s.movz       s5, #9
    vf.mul       v8, v1, v2
    s.movz       s6, #9
    s.movz       s7, #9
    s.movz       s8, #9
    s.movz       s9, #10
    vf.mul       v1, v8, v7
    vf.mul       v2, v1, v4
    vf.add       v1, v0, v2
    vf.mul       v0, v1, v5
    a.vwrite     a2, s11, v0
    a.vread      v0, a1, s12
    a.vread      v1, a1, s5
    a.vread      v2, a1, s6
    a.vread      v7, a1, s7
    s.movz       s5, #10
    vf.mul       v8, v1, v2
    s.movz       s6, #10
    s.movz       s7, #10
    s.movz       s11, #10
    s.movz       s12, #11
    vf.mul       v1, v8, v7
    vf.mul       v2, v1, v4
    vf.add       v1, v0, v2
    vf.mul       v0, v1, v5
    a.vwrite     a2, s8, v0
    a.vread      v0, a1, s9
    a.vread      v1, a1, s5
    a.vread      v2, a1, s6
    a.vread      v7, a1, s7
    s.movz       s5, #11
    vf.mul       v8, v1, v2
    s.movz       s6, #11
    s.movz       s7, #11
    s.movz       s8, #11
    s.movz       s9, #12
    vf.mul       v1, v8, v7
    vf.mul       v2, v1, v4
    vf.add       v1, v0, v2
    vf.mul       v0, v1, v5
    a.vwrite     a2, s11, v0
    a.vread      v0, a1, s12
    a.vread      v1, a1, s5
    a.vread      v2, a1, s6
    a.vread      v7, a1, s7
    s.movz       s5, #12
    vf.mul       v8, v1, v2
    s.movz       s6, #12
    s.movz       s7, #12
    s.movz       s11, #12
    s.movz       s12, #13
    vf.mul       v1, v8, v7
    vf.mul       v2, v1, v4
    vf.add       v1, v0, v2
    vf.mul       v0, v1, v5
    a.vwrite     a2, s8, v0
    a.vread      v0, a1, s9
    a.vread      v1, a1, s5
    a.vread      v2, a1, s6
    a.vread      v7, a1, s7
    s.movz       s5, #13
    vf.mul       v8, v1, v2
    s.movz       s6, #13
    s.movz       s7, #13
    s.movz       s8, #13
    s.movz       s9, #14
    vf.mul       v1, v8, v7
    vf.mul       v2, v1, v4
    vf.add       v1, v0, v2
    .li       s14, #3221225472
    v.splat      v0, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v2, v1, v5
    a.vwrite     a2, s11, v2
    a.vread      v1, a1, s12
    a.vread      v2, a1, s5
    a.vread      v7, a1, s6
    a.vread      v8, a1, s7
    s.movz       s5, #14
    vf.mul       v9, v2, v7
    s.movz       s6, #14
    s.movz       s7, #14
    s.movz       s11, #14
    s.movz       s12, #15
    vf.mul       v2, v9, v8
    .li       s14, #1069066811
    v.splat      v7, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s14, #1060205080
    v.splat      v8, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v9, v2, v4
    vf.add       v2, v1, v9
    vf.mul       v1, v2, v5
    a.vwrite     a2, s8, v1
    a.vread      v1, a1, s9
    a.vread      v2, a1, s5
    a.vread      v9, a1, s6
    a.vread      v10, a1, s7
    s.movz       s5, #15
    vf.mul       v11, v2, v9
    s.movz       s6, #15
    s.movz       s7, #15
    s.movz       s8, #15
    s.movz       s9, #0
    vf.mul       v2, v11, v10
    vf.mul       v9, v2, v4
    vf.add       v2, v1, v9
    vf.mul       v1, v2, v5
    a.vwrite     a2, s11, v1
    a.vread      v1, a1, s12
    a.vread      v2, a1, s5
    a.vread      v9, a1, s6
    a.vread      v10, a1, s7
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s5, #0
    vf.mul       v11, v2, v9
    s.movz       s6, #1
    s.movz       s7, #1
    s.movz       s11, #2
    s.movz       s12, #2
    vf.mul       v2, v11, v10
    vf.mul       v9, v2, v4
    vf.add       v2, v1, v9
    vf.mul       v1, v2, v5
    a.vwrite     a2, s8, v1
    a.vread      v1, a2, s9
    s.movz       s8, #3
    s.movz       s9, #3
    vf.abs       v2, v1
    vf.mul       v1, v2, v0
    vf.mul       v2, v1, v7
    v.exp2.approx v4, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v7, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v8
    vf.fma       v2, v4, v1, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v4
    a.vwrite     a3, s5, v1
    a.vread      v1, a2, s6
    s.movz       s5, #4
    s.movz       s6, #4
    vf.abs       v2, v1
    vf.mul       v1, v2, v0
    vf.mul       v2, v1, v7
    v.exp2.approx v4, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v7, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v8
    vf.fma       v2, v4, v1, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v4
    a.vwrite     a3, s7, v1
    a.vread      v1, a2, s11
    s.movz       s7, #5
    s.movz       s11, #5
    vf.abs       v2, v1
    vf.mul       v1, v2, v0
    vf.mul       v2, v1, v7
    v.exp2.approx v4, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v7, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v8
    vf.fma       v2, v4, v1, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v4
    a.vwrite     a3, s12, v1
    a.vread      v1, a2, s8
    s.movz       s8, #6
    s.movz       s12, #6
    vf.abs       v2, v1
    vf.mul       v1, v2, v0
    vf.mul       v2, v1, v7
    v.exp2.approx v4, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v7, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v8
    vf.fma       v2, v4, v1, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v4
    a.vwrite     a3, s9, v1
    a.vread      v1, a2, s5
    s.movz       s5, #7
    s.movz       s9, #7
    vf.abs       v2, v1
    vf.mul       v1, v2, v0
    vf.mul       v2, v1, v7
    v.exp2.approx v4, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v7, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v8
    vf.fma       v2, v4, v1, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v4
    a.vwrite     a3, s6, v1
    a.vread      v1, a2, s7
    s.movz       s6, #8
    s.movz       s7, #8
    vf.abs       v2, v1
    vf.mul       v1, v2, v0
    vf.mul       v2, v1, v7
    v.exp2.approx v4, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v7, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v8
    vf.fma       v2, v4, v1, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v4
    a.vwrite     a3, s11, v1
    a.vread      v1, a2, s8
    s.movz       s8, #9
    s.movz       s11, #9
    vf.abs       v2, v1
    vf.mul       v1, v2, v0
    vf.mul       v2, v1, v7
    v.exp2.approx v4, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v7, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v8
    vf.fma       v2, v4, v1, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v4
    a.vwrite     a3, s12, v1
    a.vread      v1, a2, s5
    s.movz       s5, #10
    s.movz       s12, #10
    vf.abs       v2, v1
    vf.mul       v1, v2, v0
    vf.mul       v2, v1, v7
    v.exp2.approx v4, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v7, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v8
    vf.fma       v2, v4, v1, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v4
    a.vwrite     a3, s9, v1
    a.vread      v1, a2, s6
    s.movz       s6, #11
    s.movz       s9, #11
    vf.abs       v2, v1
    vf.mul       v1, v2, v0
    vf.mul       v2, v1, v7
    v.exp2.approx v4, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v7, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v8
    vf.fma       v2, v4, v1, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v4
    a.vwrite     a3, s7, v1
    a.vread      v1, a2, s8
    s.movz       s7, #12
    s.movz       s8, #12
    vf.abs       v2, v1
    vf.mul       v1, v2, v0
    vf.mul       v2, v1, v7
    v.exp2.approx v4, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v7, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v8
    vf.fma       v2, v4, v1, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v4
    a.vwrite     a3, s11, v1
    a.vread      v1, a2, s5
    s.movz       s5, #13
    s.movz       s11, #13
    vf.abs       v2, v1
    vf.mul       v1, v2, v0
    vf.mul       v2, v1, v7
    v.exp2.approx v4, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v7, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v8
    vf.fma       v2, v4, v1, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v4
    a.vwrite     a3, s12, v1
    a.vread      v1, a2, s6
    s.movz       s6, #14
    s.movz       s12, #14
    vf.abs       v2, v1
    vf.mul       v1, v2, v0
    vf.mul       v2, v1, v7
    v.exp2.approx v4, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v7, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v8
    vf.fma       v2, v4, v1, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v4
    a.vwrite     a3, s9, v1
    a.vread      v1, a2, s7
    s.movz       s7, #15
    s.movz       s9, #15
    vf.abs       v2, v1
    vf.mul       v1, v2, v0
    .li       s14, #1065353216
    v.splat      v2, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v4, v1, v7
    .li       s14, #1065353216
    v.splat      v5, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.exp2.approx v9, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v1, v7, v4                 // the exact rounding error of x*log2(e)
    vf.mul       v1, v10, v8
    vf.fma       v4, v9, v1, v9                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v1, v4, v9
    a.vwrite     a3, s8, v1
    a.vread      v1, a2, s5
    s.movz       s5, #0
    s.movz       s8, #0
    vf.abs       v4, v1
    .li       s14, #1065353216
    v.splat      v1, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v9, v4, v0
    vf.mul       v4, v9, v7
    v.exp2.approx v10, v4                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v11, v9, v7, v4                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v11, v8
    vf.fma       v9, v10, v4, v10                // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v4, v9, v10
    a.vwrite     a3, s11, v4
    a.vread      v4, a2, s6
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    s.movz       s11, #1
    vf.abs       v9, v4
    vf.mul       v4, v9, v0
    vf.mul       v9, v4, v7
    v.exp2.approx v10, v9                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v11, v4, v7, v9                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v11, v8
    vf.fma       v9, v10, v4, v10                // 2**t * 2**d
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v4, v9, v10
    a.vwrite     a3, s12, v4
    a.vread      v4, a2, s7
    s.movz       s7, #1
    s.movz       s12, #1
    vf.abs       v9, v4
    vf.mul       v4, v9, v0
    vf.mul       v0, v4, v7
    v.exp2.approx v9, v0                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v7, v0                 // the exact rounding error of x*log2(e)
    vf.mul       v0, v10, v8
    vf.fma       v4, v9, v0, v9                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v0, v4, v9
    a.vwrite     a3, s9, v0
    a.vread      v0, a3, s5
    a.vread      v4, a3, s8
    s.movz       s5, #2
    vf.sub       v7, v2, v0
    vf.add       v0, v4, v5
    s.movz       s8, #2
    s.movz       s9, #2
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v0, v4, v1
    vf.fms       v0, v4, v8, v4
    vf.neg       v8, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v0, v8, v4
    vf.mul       v4, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s6, v4
    a.vread      v0, a3, s11
    a.vread      v4, a3, s7
    s.movz       s6, #3
    vf.sub       v7, v2, v0
    vf.add       v0, v4, v5
    s.movz       s7, #3
    s.movz       s11, #3
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v0, v4, v1
    vf.fms       v0, v4, v8, v4
    vf.neg       v8, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v0, v8, v4
    vf.mul       v4, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v4
    a.vread      v0, a3, s5
    a.vread      v4, a3, s8
    s.movz       s5, #4
    vf.sub       v7, v2, v0
    vf.add       v0, v4, v5
    s.movz       s8, #4
    s.movz       s12, #4
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v0, v4, v1
    vf.fms       v0, v4, v8, v4
    vf.neg       v8, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v0, v8, v4
    vf.mul       v4, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s9, v4
    a.vread      v0, a3, s6
    a.vread      v4, a3, s7
    s.movz       s6, #5
    vf.sub       v7, v2, v0
    vf.add       v0, v4, v5
    s.movz       s7, #5
    s.movz       s9, #5
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v0, v4, v1
    vf.fms       v0, v4, v8, v4
    vf.neg       v8, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v0, v8, v4
    vf.mul       v4, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s11, v4
    a.vread      v0, a3, s5
    a.vread      v4, a3, s8
    s.movz       s5, #6
    vf.sub       v7, v2, v0
    vf.add       v0, v4, v5
    s.movz       s8, #6
    s.movz       s11, #6
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v0, v4, v1
    vf.fms       v0, v4, v8, v4
    vf.neg       v8, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v0, v8, v4
    vf.mul       v4, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v4
    a.vread      v0, a3, s6
    a.vread      v4, a3, s7
    s.movz       s6, #7
    vf.sub       v7, v2, v0
    vf.add       v0, v4, v5
    s.movz       s7, #7
    s.movz       s12, #7
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v0, v4, v1
    vf.fms       v0, v4, v8, v4
    vf.neg       v8, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v0, v8, v4
    vf.mul       v4, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s9, v4
    a.vread      v0, a3, s5
    a.vread      v4, a3, s8
    s.movz       s5, #8
    vf.sub       v7, v2, v0
    vf.add       v0, v4, v5
    s.movz       s8, #8
    s.movz       s9, #8
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v0, v4, v1
    vf.fms       v0, v4, v8, v4
    vf.neg       v8, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v0, v8, v4
    vf.mul       v4, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s11, v4
    a.vread      v0, a3, s6
    a.vread      v4, a3, s7
    s.movz       s6, #9
    vf.sub       v7, v2, v0
    vf.add       v0, v4, v5
    s.movz       s7, #9
    s.movz       s11, #9
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v0, v4, v1
    vf.fms       v0, v4, v8, v4
    vf.neg       v8, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v0, v8, v4
    vf.mul       v4, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v4
    a.vread      v0, a3, s5
    a.vread      v4, a3, s8
    s.movz       s5, #10
    vf.sub       v7, v2, v0
    vf.add       v0, v4, v5
    s.movz       s8, #10
    s.movz       s12, #10
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v0, v4, v1
    vf.fms       v0, v4, v8, v4
    vf.neg       v8, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v0, v8, v4
    vf.mul       v4, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s9, v4
    a.vread      v0, a3, s6
    a.vread      v4, a3, s7
    s.movz       s6, #11
    vf.sub       v7, v2, v0
    vf.add       v0, v4, v5
    s.movz       s7, #11
    s.movz       s9, #11
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v0, v4, v1
    vf.fms       v0, v4, v8, v4
    vf.neg       v8, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v0, v8, v4
    vf.mul       v4, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s11, v4
    a.vread      v0, a3, s5
    a.vread      v4, a3, s8
    s.movz       s5, #12
    vf.sub       v7, v2, v0
    vf.add       v0, v4, v5
    s.movz       s8, #12
    s.movz       s11, #12
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v0, v4, v1
    vf.fms       v0, v4, v8, v4
    vf.neg       v8, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v0, v8, v4
    vf.mul       v4, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v4
    a.vread      v0, a3, s6
    a.vread      v4, a3, s7
    s.movz       s6, #13
    vf.sub       v7, v2, v0
    vf.add       v0, v4, v5
    s.movz       s7, #13
    s.movz       s12, #13
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v0, v4, v1
    vf.fms       v0, v4, v8, v4
    vf.neg       v8, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v0, v8, v4
    vf.mul       v4, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s9, v4
    a.vread      v0, a3, s5
    a.vread      v4, a3, s8
    s.movz       s5, #14
    vf.sub       v7, v2, v0
    vf.add       v0, v4, v5
    s.movz       s8, #14
    s.movz       s9, #14
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v0, v4, v1
    vf.fms       v0, v4, v8, v4
    vf.neg       v8, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v0, v8, v4
    v.movi       v4, #0
    vf.mul       v8, v7, v0                      // a/y as a refined reciprocal (ISA has no divide)
    .li       s14, #1065353216
    v.splat      v0, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    a.vwrite     a4, s11, v8
    a.vread      v7, a3, s6
    a.vread      v8, a3, s7
    s.movz       s6, #15
    vf.sub       v9, v2, v7
    vf.add       v7, v8, v5
    s.movz       s7, #15
    s.movz       s11, #15
    s.muli       s14, s3, #2                     // a runtime tile origin, x2
    s.muli       s3, s4, #1024                   // a runtime tile origin, x1024
    v.rcp.approx v8, v7                          // ISA 8.8: <= 2**-22 relative
    s.add        s4, s22, s14                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s14, #0
    s.add        s15, s4, s3                     // the tile origin
    s.movz       s3, #0
    vf.fms       v10, v7, v8, v1
    vf.fms       v7, v8, v10, v8
    vf.neg       v10, v7                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v10, v10
    @p1 v.sel        v7, v10, v8
    vf.mul       v8, v9, v7                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s12, v8
    a.vread      v7, a3, s5
    a.vread      v8, a3, s8
    s.movz       s4, #0
    vf.sub       v9, v2, v7
    vf.add       v7, v8, v5
    s.movz       s5, #0
    v.splat      v8, s1
    v.rcp.approx v10, v7                         // ISA 8.8: <= 2**-22 relative
    v.cmp.lt     p1, v8, v3
    p.and        p3, p1, p2
    s.movz       s8, #1
    vf.fms       v8, v7, v10, v1
    vf.fms       v7, v10, v8, v10
    vf.neg       v8, v7                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v7, v8, v10
    vf.mul       v8, v9, v7                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s9, v8
    a.vread      v7, a3, s6
    a.vread      v8, a3, s7
    s.movz       s6, #1
    vf.sub       v9, v2, v7
    vf.add       v2, v8, v5
    s.movz       s7, #1
    s.movz       s9, #1
    v.rcp.approx v5, v2                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v2, v5, v1
    vf.fms       v1, v5, v7, v5
    vf.neg       v2, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v5
    vf.mul       v2, v9, v1                      // a/y as a refined reciprocal (ISA has no divide)
    a.vwrite     a4, s11, v2
    a.vread      v1, a1, s14
    a.vread      v2, a2, s3
    a.vread      v5, a4, s4
    a.vread      v7, a4, s5
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v5
    vf.mul       v5, v1, v6
    s.addi       s3, s1, #1
    s.addi       s4, s15, #1024                  // row 1
    v.splat      v1, s3
    @p1 v.sel        v8, v2, v7
    s.movz       s3, #2
    v.cmp.lt     p1, v1, v3
    vf.add       v1, v8, v0
    p.and        p4, p1, p2
    s.movz       s5, #2
    s.movz       s11, #2
    s.movz       s12, #2
    vf.mul       v2, v5, v1
    vf.cvt.f32.f16 v1, v2
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a1, s8
    a.vread      v2, a2, s6
    a.vread      v5, a4, s7
    a.vread      v7, a4, s9
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v5
    vf.mul       v5, v1, v6
    s.addi       s6, s1, #2
    s.addi       s7, s15, #2048                  // row 2
    v.splat      v1, s6
    @p1 v.sel        v8, v2, v7
    s.movz       s6, #3
    v.cmp.lt     p1, v1, v3
    vf.add       v1, v8, v0
    p.and        p3, p1, p2
    s.movz       s8, #3
    s.movz       s9, #3
    vf.mul       v2, v5, v1
    vf.cvt.f32.f16 v1, v2
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a1, s3
    a.vread      v2, a2, s5
    a.vread      v5, a4, s11
    a.vread      v7, a4, s12
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v5
    vf.mul       v5, v1, v6
    s.movz       s3, #3
    s.addi       s4, s1, #3
    s.addi       s5, s15, #3072                  // row 3
    @p1 v.sel        v1, v2, v7
    v.splat      v2, s4
    s.movz       s4, #4
    vf.add       v7, v1, v0
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s11, #4
    s.movz       s12, #4
    vf.mul       v1, v5, v7
    vf.cvt.f32.f16 v2, v1
    @p3 v.st.h       [s7, #0], v2
    a.vread      v1, a1, s6
    a.vread      v2, a2, s8
    a.vread      v5, a4, s9
    a.vread      v7, a4, s3
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v5
    vf.mul       v5, v1, v6
    s.movz       s3, #4
    s.addi       s6, s1, #4
    s.addi       s7, s15, #4096                  // row 4
    @p1 v.sel        v1, v2, v7
    v.splat      v2, s6
    s.movz       s6, #5
    vf.add       v7, v1, v0
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.movz       s8, #5
    s.movz       s9, #5
    vf.mul       v1, v5, v7
    vf.cvt.f32.f16 v2, v1
    @p4 v.st.h       [s5, #0], v2
    a.vread      v1, a1, s4
    a.vread      v2, a2, s11
    a.vread      v5, a4, s12
    a.vread      v7, a4, s3
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v5
    vf.mul       v5, v1, v6
    s.movz       s3, #5
    s.addi       s4, s1, #5
    s.addi       s5, s15, #5120                  // row 5
    @p1 v.sel        v1, v2, v7
    v.splat      v2, s4
    s.movz       s4, #6
    vf.add       v7, v1, v0
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s11, #6
    s.movz       s12, #6
    vf.mul       v1, v5, v7
    vf.cvt.f32.f16 v2, v1
    @p3 v.st.h       [s7, #0], v2
    a.vread      v1, a1, s6
    a.vread      v2, a2, s8
    a.vread      v5, a4, s9
    a.vread      v7, a4, s3
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v5
    vf.mul       v5, v1, v6
    s.movz       s3, #6
    s.addi       s6, s1, #6
    s.addi       s7, s15, #6144                  // row 6
    @p1 v.sel        v1, v2, v7
    v.splat      v2, s6
    s.movz       s6, #7
    vf.add       v7, v1, v0
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.movz       s8, #7
    s.movz       s9, #7
    vf.mul       v1, v5, v7
    vf.cvt.f32.f16 v2, v1
    @p4 v.st.h       [s5, #0], v2
    a.vread      v1, a1, s4
    a.vread      v2, a2, s11
    a.vread      v5, a4, s12
    a.vread      v7, a4, s3
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v5
    vf.mul       v5, v1, v6
    s.movz       s3, #7
    s.addi       s4, s1, #7
    s.addi       s5, s15, #7168                  // row 7
    @p1 v.sel        v1, v2, v7
    v.splat      v2, s4
    s.movz       s4, #8
    vf.add       v7, v1, v0
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s11, #8
    s.movz       s12, #8
    vf.mul       v1, v5, v7
    vf.cvt.f32.f16 v2, v1
    @p3 v.st.h       [s7, #0], v2
    a.vread      v1, a1, s6
    a.vread      v2, a2, s8
    a.vread      v5, a4, s9
    a.vread      v7, a4, s3
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v5
    vf.mul       v5, v1, v6
    s.movz       s3, #8
    s.addi       s6, s1, #8
    s.addi       s7, s15, #8192                  // row 8
    @p1 v.sel        v1, v2, v7
    v.splat      v2, s6
    s.movz       s6, #9
    vf.add       v7, v1, v0
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.movz       s8, #9
    s.movz       s9, #9
    vf.mul       v1, v5, v7
    vf.cvt.f32.f16 v2, v1
    @p4 v.st.h       [s5, #0], v2
    a.vread      v1, a1, s4
    a.vread      v2, a2, s11
    a.vread      v5, a4, s12
    a.vread      v7, a4, s3
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v5
    vf.mul       v5, v1, v6
    s.movz       s3, #9
    s.addi       s4, s1, #9
    s.addi       s5, s15, #9216                  // row 9
    @p1 v.sel        v1, v2, v7
    v.splat      v2, s4
    s.movz       s4, #10
    vf.add       v7, v1, v0
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s11, #10
    s.movz       s12, #10
    vf.mul       v1, v5, v7
    vf.cvt.f32.f16 v2, v1
    @p3 v.st.h       [s7, #0], v2
    a.vread      v1, a1, s6
    a.vread      v2, a2, s8
    a.vread      v5, a4, s9
    a.vread      v7, a4, s3
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v5
    vf.mul       v5, v1, v6
    s.movz       s3, #10
    s.addi       s6, s1, #10
    s.addi       s7, s15, #10240                 // row 10
    @p1 v.sel        v1, v2, v7
    v.splat      v2, s6
    s.movz       s6, #11
    vf.add       v7, v1, v0
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.movz       s8, #11
    s.movz       s9, #11
    vf.mul       v1, v5, v7
    vf.cvt.f32.f16 v2, v1
    @p4 v.st.h       [s5, #0], v2
    a.vread      v1, a1, s4
    a.vread      v2, a2, s11
    a.vread      v5, a4, s12
    a.vread      v7, a4, s3
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v5
    vf.mul       v5, v1, v6
    s.movz       s3, #11
    s.addi       s4, s1, #11
    s.addi       s5, s15, #11264                 // row 11
    @p1 v.sel        v1, v2, v7
    v.splat      v2, s4
    s.movz       s4, #12
    vf.add       v7, v1, v0
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s11, #12
    s.movz       s12, #12
    vf.mul       v1, v5, v7
    vf.cvt.f32.f16 v2, v1
    @p3 v.st.h       [s7, #0], v2
    a.vread      v1, a1, s6
    a.vread      v2, a2, s8
    a.vread      v5, a4, s9
    a.vread      v7, a4, s3
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v5
    vf.mul       v5, v1, v6
    s.movz       s3, #12
    s.addi       s6, s1, #12
    s.addi       s7, s15, #12288                 // row 12
    @p1 v.sel        v1, v2, v7
    v.splat      v2, s6
    s.movz       s6, #13
    vf.add       v7, v1, v0
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.movz       s8, #13
    s.movz       s9, #13
    vf.mul       v1, v5, v7
    vf.cvt.f32.f16 v2, v1
    @p4 v.st.h       [s5, #0], v2
    a.vread      v1, a1, s4
    a.vread      v2, a2, s11
    a.vread      v5, a4, s12
    a.vread      v7, a4, s3
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v5
    vf.mul       v5, v1, v6
    s.movz       s3, #13
    s.addi       s4, s1, #13
    s.addi       s5, s15, #13312                 // row 13
    @p1 v.sel        v1, v2, v7
    v.splat      v2, s4
    s.movz       s4, #14
    vf.add       v7, v1, v0
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s11, #14
    s.movz       s12, #14
    vf.mul       v1, v5, v7
    vf.cvt.f32.f16 v2, v1
    @p3 v.st.h       [s7, #0], v2
    a.vread      v1, a1, s6
    a.vread      v2, a2, s8
    a.vread      v5, a4, s9
    a.vread      v7, a4, s3
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v5
    vf.mul       v5, v1, v6
    s.movz       s3, #14
    s.addi       s6, s1, #14
    s.addi       s7, s15, #14336                 // row 14
    @p1 v.sel        v1, v2, v7
    v.splat      v2, s6
    s.movz       s6, #15
    vf.add       v7, v1, v0
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.movz       s8, #15
    s.movz       s9, #15
    vf.mul       v1, v5, v7
    s.addi       s14, s1, #15
    s.addi       s1, s15, #15360                 // row 15
    v.splat      v2, s14
    s.movz       s14, #15
    vf.cvt.f32.f16 v5, v1
    @p4 v.st.h       [s5, #0], v5
    a.vread      v1, a1, s4
    a.vread      v5, a2, s11
    a.vread      v7, a4, s12
    a.vread      v8, a4, s3
    vf.cmp.lt    p1, v5, v4
    vf.neg       v5, v7
    vf.mul       v7, v1, v6
    @p1 v.sel        v1, v5, v8
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    vf.add       v2, v1, v0
    vf.mul       v1, v7, v2
    vf.cvt.f32.f16 v2, v1
    @p3 v.st.h       [s7, #0], v2
    a.vread      v1, a1, s6
    a.vread      v2, a2, s8
    a.vread      v3, a4, s9
    a.vread      v5, a4, s14
    vf.cmp.lt    p1, v2, v4
    vf.neg       v2, v3
    vf.mul       v3, v1, v6
    @p1 v.sel        v1, v2, v5
    vf.add       v2, v1, v0
    vf.mul       v0, v3, v2
    vf.cvt.f32.f16 v1, v0
    @p4 v.st.h       [s1, #0], v1
__rctx_next:
    exit
