    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    s.rdspecial  s3, pid.y
    s.rdspecial  s4, role_id
    s.mul        s5, s3, s1
    s.movz       s1, #6208
    v.splat      v1, s2
    s.rdspecial  s2, arg_base
    v.add        v2, v1, v0
    s.mul        s3, s4, s1
    v.movi       v1, #0
    s.ld.d       s1, [s2, #64]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.cmp.lt     p1, v2, v1
    s.movz       s2, #0
    s.add        s4, s1, s3                      // this context's own scratch
    v.movi       v3, #8
    s.addi       s1, s4, #0
    s.rdspecial  s3, arg_base
    s.addi       s6, s1, #64
    s.addi       s7, s1, #128
    s.addi       s8, s1, #192
    s.addi       s9, s1, #256
    s.addi       s10, s1, #320
    s.addi       s11, s1, #384
    s.addi       s12, s1, #448
    s.addi       s13, s1, #512
    s.addi       s14, s1, #576
    s.addi       s15, s1, #640
    s.addi       s16, s1, #704
    s.addi       s17, s1, #768
    s.addi       s18, s1, #832
    s.addi       s19, s1, #896
    s.addi       s20, s1, #960
    s.addi       s21, s4, #1024
    v.cmp.lt     p2, v3, v1
    s.ld.d       s22, [s3, #0]                   // arg_X: device_ptr64 at arg_base+0
    v.sub        v4, v1, v2
    s.movz       s23, #512
    s.ld.d       s24, [s3, #8]                   // arg_W: device_ptr64 at arg_base+8
    @p1 v.sel        v5, v4, v2
    s.movz       s25, #72
    s.ld.d       s25, [s3, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    v.sub        v4, v1, v3
    s.movz       s26, #9
    s.ld.d       s27, [s3, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.movz       s28, #1
    v.movi       v6, #1
    s.ld.d       s29, [s3, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    v.movi       v6, #7
    @p2 v.sel        v7, v4, v3
    s.ld.d       s30, [s3, #40]                  // in_ptr5: device_ptr64 at arg_base+40
    v.and        v4, v5, v6
    s.ld.d       s31, [s3, #48]                  // in_ptr6: device_ptr64 at arg_base+48
    v.sub        v5, v1, v4
    s.ld.d       s32, [s3, #56]                  // out_ptr1: device_ptr64 at arg_base+56
    v.movi       v1, #0
    v.movi       v6, #3
    v.sub        v7, v1, v2
    v.cmp.lt     p2, v2, v1
    @p2 v.sel        v8, v7, v2
    v.movi       v2, #0
    v.lshr       v7, v8, v6
    v.movi       v6, #3
    v.sub        v8, v1, v7
    v.movi       v9, #0
    @p2 v.sel        v10, v8, v7
    v.movi       v7, #512
    v.sub        v8, v2, v10
    v.cmp.lt     p2, v10, v2
    @p2 v.sel        v11, v8, v10
    v.sub        v8, v9, v10
    v.lshr       v12, v11, v6
    v.splat      v6, s5
    v.sub        v11, v2, v12
    v.cmp.lt     p3, v10, v9
    @p2 v.sel        v13, v11, v12
    @p3 v.sel        v11, v8, v10
    v.mul        v8, v13, v7
    v.movi       v7, #7
    v.add        v10, v6, v0
    v.extract    s3, v8, #0
    v.extract    s33, v8, #1
    v.and        v6, v11, v7
    v.splat      v7, s2
    v.splat      v11, s3
    v.cmp.lt     p2, v3, v1
    v.sub        v12, v1, v3
    v.add        v1, v7, v11
    @p1 v.sel        v11, v5, v4
    v.splat      v4, s33
    v.cmp.lt     p1, v3, v9
    v.add        v5, v7, v4
    v.movi       v4, #1
    v.extract    s3, v8, #2
    v.extract    s33, v8, #3
    @p2 v.sel        v4, v12, v3
    v.extract    s34, v8, #4
    v.splat      v4, s3
    v.cmp.lt     p2, v3, v2
    v.sub        v12, v2, v3
    v.add        v2, v7, v4
    v.movi       v4, #1
    v.extract    s3, v8, #5
    v.extract    s35, v8, #6
    v.movi       v4, #1
    @p2 v.sel        v4, v12, v3
    v.splat      v4, s33
    v.st.w       [s1, #0], v1
    v.splat      v1, s34
    v.add        v12, v7, v4
    v.add        v4, v7, v1
    v.st.w       [s6, #0], v5
    v.splat      v1, s3
    v.add        v5, v7, v1
    v.st.w       [s7, #0], v2
    v.sub        v1, v9, v3
    v.sub        v2, v9, v6
    @p1 v.sel        v9, v1, v3
    v.extract    s1, v8, #7
    v.splat      v1, s35
    @p3 v.sel        v9, v2, v6
    v.extract    s3, v8, #8
    v.extract    s6, v8, #9
    v.extract    s7, v8, #10
    v.extract    s33, v8, #11
    v.extract    s34, v8, #12
    v.extract    s35, v8, #13
    v.extract    s36, v8, #14
    v.extract    s37, v8, #15
    v.splat      v2, s1
    v.splat      v6, s3
    v.add        v8, v7, v1
    v.add        v1, v7, v2
    v.add        v2, v7, v6
    v.st.w       [s8, #0], v12
    v.movi       v6, #72
    v.mul        v12, v10, v6
    v.st.w       [s9, #0], v4
    v.splat      v4, s6
    v.add        v6, v7, v4
    v.st.w       [s10, #0], v5
    v.splat      v4, s7
    s.addi       s1, s2, #0
    v.add        v5, v7, v4
    v.st.w       [s11, #0], v8
    v.splat      v4, s33
    v.add        v8, v7, v4
    v.st.w       [s12, #0], v1
    v.splat      v1, s34
    v.add        v4, v7, v1
    v.st.w       [s13, #0], v2
    v.splat      v1, s35
    v.add        v2, v7, v1
    v.st.w       [s14, #0], v6
    v.splat      v1, s36
    v.add        v6, v7, v1
    v.st.w       [s15, #0], v5
    v.splat      v1, s37
    v.add        v5, v7, v1
    v.splat      v1, s2
    v.add        v7, v1, v12
    v.st.w       [s16, #0], v8
    v.st.w       [s17, #0], v4
    v.st.w       [s18, #0], v2
    v.st.w       [s19, #0], v6
    v.st.w       [s20, #0], v5
    fence.acq_rel.device
    v.st.w       [s21, #0], v7
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_1:
    s.cmp.ge     s3, s1, s26
    br.nz        s3, endfor_2
    s.movz       s3, #0
    s.movz       s6, #0
    s.cmp.lt     s7, s1, s3
    s.movz       s3, #0
    s.sub        s8, s6, s7
    .li       s6, #1431655766
    s.xor        s7, s1, s8
    s.movz       s9, #0
    s.sub        s10, s7, s8
    s.cmp.lt     s7, s1, s3
    s.mul        s3, s10, s6
    s.sub        s6, s9, s7
    .li       s7, #1431655766
    s.xor        s9, s1, s6
    s.movz       s11, #3
    s.sub        s12, s9, s6
    s.lshri      s9, s3, #32
    s.mul        s3, s12, s7
    s.sub        s7, s10, s9
    s.movz       s13, #0
    s.lshri      s14, s7, #1
    s.movz       s7, #0
    s.add        s15, s9, s14
    s.lshri      s9, s3, #32
    s.lshri      s3, s15, #1
    s.sub        s14, s12, s9
    s.muli       s15, s3, #3
    s.cmp.lt     s3, s11, s13
    s.lshri      s13, s14, #1
    s.sub        s14, s7, s3
    s.add        s3, s9, s13
    s.xor        s7, s6, s14
    s.lshri      s6, s3, #1
    s.sub        s3, s10, s15
    s.xor        s9, s6, s7
    s.xor        s10, s3, s8
    s.sub        s3, s9, s7
    s.sub        s7, s10, s8
    s.sub        s8, s3, s28
    s.sub        s9, s7, s28
    v.splat      v1, s8
    v.splat      v2, s9
    v.add        v4, v1, v9
    v.add        v1, v2, v11
    v.movi       v2, #64
    v.mul        v5, v1, v3
    v.mul        v6, v4, v2
    s.movz       s8, #8
    s.movz       s9, #0
    s.movz       s10, #0
    s.cmp.lt     s13, s11, s9
    s.muli       s9, s6, #3
    s.sub        s6, s10, s13
    s.xor        s10, s11, s14
    s.addi       s13, s4, #1088
    s.xor        s15, s11, s6
    s.sub        s16, s10, s14
    s.addi       s10, s4, #0
    v.extract    s14, v6, #0
    v.ld.w       v2, [s10, #0]
    v.extract    s10, v5, #0
    v.splat      v7, s14
    v.splat      v8, s10
    v.iota       v12                             // arange(0, VLEN)
    v.add        v14, v7, v8
    s.sub        s10, s12, s9
    v.add        v7, v14, v12
    s.addi       s9, s4, #64
    v.extract    s10, v6, #1
    v.add        v8, v2, v7
    v.extract    s12, v5, #1
    v.st.w       [s13, #0], v8
    v.splat      v2, s10
    v.splat      v7, s12
    s.addi       s10, s13, #64
    v.add        v8, v2, v7
    s.addi       s12, s4, #128
    v.add        v2, v8, v12
    s.addi       s14, s13, #128
    s.sub        s16, s15, s6
    v.extract    s6, v6, #2
    v.ld.w       v7, [s9, #0]
    v.extract    s9, v5, #2
    v.splat      v8, s6
    v.splat      v14, s9
    s.addi       s6, s4, #192
    v.add        v15, v8, v14
    v.extract    s9, v6, #3
    v.add        v8, v15, v12
    v.extract    s15, v5, #3
    v.splat      v14, s9
    v.add        v15, v7, v2
    v.splat      v2, s15
    v.st.w       [s10, #0], v15
    v.add        v7, v14, v2
    s.addi       s9, s13, #192
    v.add        v2, v7, v12
    s.movz       s10, #64
    s.addi       s10, s4, #256
    v.extract    s15, v6, #4
    v.splat      v7, s15
    v.extract    s15, v5, #4
    v.splat      v14, s15
    v.ld.w       v15, [s12, #0]
    v.add        v16, v7, v14
    s.addi       s12, s13, #256
    v.add        v7, v16, v12
    s.addi       s15, s4, #320
    v.add        v14, v15, v8
    v.st.w       [s14, #0], v14
    v.extract    s14, v6, #5
    v.splat      v8, s14
    v.extract    s14, v5, #5
    v.splat      v14, s14
    s.addi       s14, s13, #320
    v.add        v15, v8, v14
    v.add        v8, v15, v12
    v.ld.w       v14, [s6, #0]
    s.addi       s6, s4, #384
    v.add        v15, v14, v2
    v.st.w       [s9, #0], v15
    v.extract    s9, v6, #6
    v.splat      v2, s9
    v.extract    s9, v5, #6
    v.splat      v14, s9
    s.addi       s9, s13, #384
    v.add        v15, v2, v14
    v.add        v2, v15, v12
    v.ld.w       v14, [s10, #0]
    s.addi       s10, s4, #448
    v.add        v15, v14, v7
    v.st.w       [s12, #0], v15
    v.extract    s12, v6, #7
    v.splat      v7, s12
    v.extract    s12, v5, #7
    v.splat      v14, s12
    s.addi       s12, s13, #448
    v.add        v15, v7, v14
    v.add        v7, v15, v12
    v.ld.w       v14, [s15, #0]
    s.addi       s15, s4, #512
    v.add        v15, v14, v8
    v.st.w       [s14, #0], v15
    v.extract    s14, v6, #8
    v.splat      v8, s14
    v.extract    s14, v5, #8
    v.splat      v14, s14
    s.addi       s14, s13, #512
    v.add        v15, v8, v14
    v.add        v8, v15, v12
    v.ld.w       v14, [s6, #0]
    s.addi       s6, s4, #576
    v.add        v15, v14, v2
    v.st.w       [s9, #0], v15
    v.extract    s9, v6, #9
    v.splat      v2, s9
    v.extract    s9, v5, #9
    v.splat      v14, s9
    s.addi       s9, s13, #576
    v.add        v15, v2, v14
    v.add        v2, v15, v12
    v.ld.w       v14, [s10, #0]
    s.addi       s10, s4, #640
    v.add        v15, v14, v7
    v.st.w       [s12, #0], v15
    v.extract    s12, v6, #10
    v.splat      v7, s12
    v.extract    s12, v5, #10
    v.splat      v14, s12
    s.addi       s12, s13, #640
    v.add        v15, v7, v14
    v.add        v7, v15, v12
    v.ld.w       v14, [s15, #0]
    s.addi       s15, s4, #704
    v.add        v15, v14, v8
    v.st.w       [s14, #0], v15
    v.extract    s14, v6, #11
    v.splat      v8, s14
    v.extract    s14, v5, #11
    v.splat      v14, s14
    s.addi       s14, s13, #704
    v.add        v15, v8, v14
    v.add        v8, v15, v12
    v.ld.w       v14, [s6, #0]
    s.addi       s6, s4, #768
    v.add        v15, v14, v2
    v.st.w       [s9, #0], v15
    v.extract    s9, v6, #12
    v.splat      v2, s9
    v.extract    s9, v5, #12
    v.splat      v14, s9
    s.addi       s9, s13, #768
    v.add        v15, v2, v14
    v.add        v2, v15, v12
    v.ld.w       v14, [s10, #0]
    s.addi       s10, s4, #832
    v.add        v15, v14, v7
    v.st.w       [s12, #0], v15
    v.extract    s12, v6, #13
    v.splat      v7, s12
    v.extract    s12, v5, #13
    v.splat      v14, s12
    s.addi       s12, s13, #832
    v.add        v15, v7, v14
    v.add        v7, v15, v12
    v.ld.w       v14, [s15, #0]
    s.addi       s15, s4, #896
    v.movi       v15, #1
    v.add        v16, v14, v8
    v.cmp.lt     p1, v13, v15
    v.st.w       [s14, #0], v16
    v.extract    s14, v6, #14
    v.splat      v8, s14
    v.extract    s14, v5, #14
    v.splat      v14, s14
    s.addi       s14, s13, #896
    v.add        v15, v8, v14
    v.movi       v8, #1
    v.add        v14, v15, v12
    v.movi       v15, #0
    v.ld.w       v16, [s6, #0]
    s.addi       s6, s4, #960
    v.movi       v17, #0
    @p1 v.sel        v18, v8, v15
    v.movi       v8, #1
    v.cmp.ge     p1, v4, v17
    v.cmp.lt     p2, v4, v3
    v.movi       v4, #0
    s.addi       s16, s13, #960
    @p1 v.sel        v15, v8, v4
    v.add        v4, v16, v2
    v.movi       v2, #1
    v.st.w       [s9, #0], v4
    v.extract    s9, v6, #15
    v.splat      v4, s9
    v.extract    s9, v5, #15
    v.splat      v5, s9
    v.movi       v6, #0
    v.add        v8, v4, v5
    @p2 v.sel        v4, v2, v6
    v.add        v2, v8, v12
    v.movi       v5, #1
    v.ld.w       v6, [s10, #0]
    v.movi       v8, #0
    v.cmp.ge     p1, v1, v17
    @p1 v.sel        v16, v5, v8
    v.movi       v5, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v1, v3
    @p1 v.sel        v1, v5, v8
    v.cmp.lt     p1, v0, v3
    v.add        v5, v6, v7
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s9, #0
    v.st.w       [s12, #0], v5
    v.extract    s10, v18, #0
    s.addi       s12, s4, #1088
    v.ld.w       v5, [s15, #0]
    v.extract    s13, v15, #0
    v.splat      v6, s10
    v.movi       v7, #0
    v.splat      v8, s13
    v.movi       v17, #0
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p3, v8, v17
    v.add        v6, v5, v14
    p.and        p4, p2, p3
    v.st.w       [s14, #0], v6
    v.extract    s10, v4, #0
    v.splat      v5, s10
    v.movi       v6, #0
    v.ld.w       v7, [s6, #0]
    v.extract    s6, v16, #0
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s6
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v5, v6
    p.and        p4, p3, p2
    v.add        v5, v7, v2
    v.extract    s6, v1, #0
    v.st.w       [s16, #0], v5
    fence.acq_rel.device
    v.splat      v2, s6
    v.movi       v5, #0
    v.extract    s6, v18, #1
    v.cmp.ne     p2, v2, v5
    p.and        p3, p4, p2
    v.extract    s10, v15, #1
    p.and        p2, p3, p1
    v.splat      v2, s6
    v.ld.w       v5, [s12, #0]
    v.movi       v6, #0
    v.splat      v7, s10
    v.movi       v8, #0
    s.addi       s6, s4, #1152
    v.extract    s10, v4, #1
    v.cmp.ne     p3, v2, v6
    v.cmp.ne     p4, v7, v8
    v.splat      v2, s10
    v.movi       v6, #0
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s22, v5]              // index is in elements (ISA sec 9.1)
    p.and        p2, p3, p4
    v.extract    s10, v16, #1
    v.cmp.ne     p3, v2, v6
    v.splat      v2, s10
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.extract    s10, v1, #1
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s10
    a.vwrite     a1, s9, v7
    v.ld.w       v5, [s6, #0]
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v6
    p.and        p4, p3, p2
    v.extract    s6, v18, #2
    p.and        p2, p4, p1
    v.extract    s9, v15, #2
    v.splat      v2, s6
    v.movi       v6, #0
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s22, v5]              // index is in elements (ISA sec 9.1)
    v.splat      v5, s9
    v.movi       v8, #0
    s.movz       s6, #1
    s.addi       s9, s4, #1216
    v.extract    s10, v4, #2
    v.cmp.ne     p2, v2, v6
    v.cmp.ne     p3, v5, v8
    v.splat      v2, s10
    v.movi       v5, #0
    a.vwrite     a1, s6, v7
    v.ld.w       v6, [s9, #0]
    p.and        p4, p2, p3
    v.extract    s6, v16, #2
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s6
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.extract    s6, v1, #2
    v.cmp.ne     p2, v2, v5
    v.splat      v2, s6
    v.movi       v5, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v5
    p.and        p3, p4, p2
    v.extract    s6, v18, #3
    p.and        p2, p3, p1
    v.extract    s9, v15, #3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s22, v6]              // index is in elements (ISA sec 9.1)
    v.splat      v5, s6
    v.movi       v6, #0
    v.splat      v7, s9
    v.movi       v8, #0
    s.movz       s6, #2
    s.addi       s9, s4, #1280
    v.extract    s10, v4, #3
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v7, v8
    v.splat      v5, s10
    v.movi       v6, #0
    a.vwrite     a1, s6, v2
    v.ld.w       v2, [s9, #0]
    p.and        p4, p2, p3
    v.extract    s6, v16, #3
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s6
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s6, v1, #3
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s6
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #4
    p.and        p2, p3, p1
    v.extract    s9, v15, #4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s22, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s6
    v.movi       v6, #0
    v.splat      v7, s9
    v.movi       v8, #0
    s.movz       s6, #3
    s.addi       s9, s4, #1344
    v.extract    s10, v4, #4
    v.cmp.ne     p2, v2, v6
    v.cmp.ne     p3, v7, v8
    v.splat      v2, s10
    v.movi       v6, #0
    a.vwrite     a1, s6, v5
    v.ld.w       v5, [s9, #0]
    p.and        p4, p2, p3
    v.extract    s6, v16, #4
    v.cmp.ne     p2, v2, v6
    v.splat      v2, s6
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s6, v1, #4
    v.cmp.ne     p2, v2, v6
    v.splat      v2, s6
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #5
    p.and        p2, p3, p1
    v.extract    s9, v15, #5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s22, v5]              // index is in elements (ISA sec 9.1)
    v.splat      v5, s6
    v.movi       v6, #0
    v.splat      v7, s9
    v.movi       v8, #0
    s.movz       s6, #4
    s.addi       s9, s4, #1408
    v.extract    s10, v4, #5
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v7, v8
    v.splat      v5, s10
    v.movi       v6, #0
    a.vwrite     a1, s6, v2
    v.ld.w       v2, [s9, #0]
    p.and        p4, p2, p3
    v.extract    s6, v16, #5
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s6
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s6, v1, #5
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s6
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #6
    p.and        p2, p3, p1
    v.extract    s9, v15, #6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s22, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s6
    v.movi       v6, #0
    v.splat      v7, s9
    v.movi       v8, #0
    s.movz       s6, #5
    s.addi       s9, s4, #1472
    v.extract    s10, v4, #6
    v.cmp.ne     p2, v2, v6
    v.cmp.ne     p3, v7, v8
    v.splat      v2, s10
    v.movi       v6, #0
    a.vwrite     a1, s6, v5
    v.ld.w       v5, [s9, #0]
    p.and        p4, p2, p3
    v.extract    s6, v16, #6
    v.cmp.ne     p2, v2, v6
    v.splat      v2, s6
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s6, v1, #6
    v.cmp.ne     p2, v2, v6
    v.splat      v2, s6
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #7
    p.and        p2, p3, p1
    v.extract    s9, v15, #7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s22, v5]              // index is in elements (ISA sec 9.1)
    v.splat      v5, s6
    v.movi       v6, #0
    v.splat      v7, s9
    v.movi       v8, #0
    s.movz       s6, #6
    s.addi       s9, s4, #1536
    v.extract    s10, v4, #7
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v7, v8
    v.splat      v5, s10
    v.movi       v6, #0
    a.vwrite     a1, s6, v2
    v.ld.w       v2, [s9, #0]
    p.and        p4, p2, p3
    v.extract    s6, v16, #7
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s6
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s6, v1, #7
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s6
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #8
    p.and        p2, p3, p1
    v.extract    s9, v15, #8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s22, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s6
    v.movi       v6, #0
    v.splat      v7, s9
    v.movi       v8, #0
    s.movz       s6, #7
    s.addi       s9, s4, #1600
    v.extract    s10, v4, #8
    v.cmp.ne     p2, v2, v6
    v.cmp.ne     p3, v7, v8
    v.splat      v2, s10
    v.movi       v6, #0
    a.vwrite     a1, s6, v5
    v.ld.w       v5, [s9, #0]
    p.and        p4, p2, p3
    v.extract    s6, v16, #8
    v.cmp.ne     p2, v2, v6
    v.splat      v2, s6
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s6, v1, #8
    v.cmp.ne     p2, v2, v6
    v.splat      v2, s6
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #9
    p.and        p2, p3, p1
    v.extract    s9, v15, #9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s22, v5]              // index is in elements (ISA sec 9.1)
    v.splat      v5, s6
    v.movi       v6, #0
    v.splat      v7, s9
    v.movi       v8, #0
    s.movz       s6, #8
    s.addi       s9, s4, #1664
    v.extract    s10, v4, #9
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v7, v8
    v.splat      v5, s10
    v.movi       v6, #0
    a.vwrite     a1, s6, v2
    v.ld.w       v2, [s9, #0]
    p.and        p4, p2, p3
    v.extract    s6, v16, #9
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s6
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s6, v1, #9
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s6
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #10
    p.and        p2, p3, p1
    v.extract    s9, v15, #10
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s22, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s6
    v.movi       v6, #0
    v.splat      v7, s9
    v.movi       v8, #0
    s.movz       s6, #9
    s.addi       s9, s4, #1728
    v.extract    s10, v4, #10
    v.cmp.ne     p2, v2, v6
    v.cmp.ne     p3, v7, v8
    v.splat      v2, s10
    v.movi       v6, #0
    a.vwrite     a1, s6, v5
    v.ld.w       v5, [s9, #0]
    p.and        p4, p2, p3
    v.extract    s6, v16, #10
    v.cmp.ne     p2, v2, v6
    v.splat      v2, s6
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s6, v1, #10
    v.cmp.ne     p2, v2, v6
    v.splat      v2, s6
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #11
    p.and        p2, p3, p1
    v.extract    s9, v15, #11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s22, v5]              // index is in elements (ISA sec 9.1)
    v.splat      v5, s6
    v.movi       v6, #0
    v.splat      v7, s9
    v.movi       v8, #0
    s.movz       s6, #10
    s.addi       s9, s4, #1792
    v.extract    s10, v4, #11
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v7, v8
    v.splat      v5, s10
    v.movi       v6, #0
    a.vwrite     a1, s6, v2
    v.ld.w       v2, [s9, #0]
    p.and        p4, p2, p3
    v.extract    s6, v16, #11
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s6
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s6, v1, #11
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s6
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #12
    p.and        p2, p3, p1
    v.extract    s9, v15, #12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s22, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s6
    v.movi       v6, #0
    v.splat      v7, s9
    v.movi       v8, #0
    s.movz       s6, #11
    s.addi       s9, s4, #1856
    v.extract    s10, v4, #12
    v.cmp.ne     p2, v2, v6
    v.cmp.ne     p3, v7, v8
    v.splat      v2, s10
    v.movi       v6, #0
    a.vwrite     a1, s6, v5
    v.ld.w       v5, [s9, #0]
    p.and        p4, p2, p3
    v.extract    s6, v16, #12
    v.cmp.ne     p2, v2, v6
    v.splat      v2, s6
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s6, v1, #12
    v.cmp.ne     p2, v2, v6
    v.splat      v2, s6
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #13
    p.and        p2, p3, p1
    v.extract    s9, v15, #13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s22, v5]              // index is in elements (ISA sec 9.1)
    v.splat      v5, s6
    v.movi       v6, #0
    v.splat      v7, s9
    v.movi       v8, #0
    s.movz       s6, #12
    s.addi       s9, s4, #1920
    v.extract    s10, v4, #13
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v7, v8
    v.splat      v5, s10
    v.movi       v6, #0
    a.vwrite     a1, s6, v2
    v.ld.w       v2, [s9, #0]
    p.and        p4, p2, p3
    v.extract    s6, v16, #13
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s6
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s6, v1, #13
    v.cmp.ne     p2, v5, v6
    v.splat      v5, s6
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v5, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #14
    p.and        p2, p3, p1
    v.extract    s9, v15, #14
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v5, [s22, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s6
    v.movi       v6, #0
    v.splat      v7, s9
    v.movi       v8, #0
    s.movz       s6, #13
    s.addi       s9, s4, #1984
    v.extract    s10, v4, #14
    v.cmp.ne     p2, v2, v6
    v.cmp.ne     p3, v7, v8
    v.splat      v2, s10
    v.movi       v6, #0
    a.vwrite     a1, s6, v5
    v.ld.w       v5, [s9, #0]
    p.and        p4, p2, p3
    v.extract    s6, v16, #14
    v.cmp.ne     p2, v2, v6
    v.splat      v2, s6
    v.movi       v6, #0
    p.and        p3, p4, p2
    v.extract    s6, v1, #14
    v.cmp.ne     p2, v2, v6
    v.splat      v2, s6
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #15
    p.and        p2, p3, p1
    v.extract    s9, v15, #15
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s22, v5]              // index is in elements (ISA sec 9.1)
    v.splat      v5, s6
    v.movi       v6, #0
    v.splat      v7, s9
    v.movi       v8, #0
    s.movz       s6, #14
    s.addi       s9, s4, #2048
    v.extract    s10, v4, #15
    v.cmp.ne     p2, v5, v6
    v.cmp.ne     p3, v7, v8
    v.splat      v4, s10
    v.movi       v5, #0
    a.vwrite     a1, s6, v2
    v.ld.w       v2, [s9, #0]
    p.and        p4, p2, p3
    v.extract    s6, v16, #15
    v.cmp.ne     p2, v4, v5
    v.splat      v4, s6
    v.movi       v5, #0
    p.and        p3, p4, p2
    v.extract    s6, v1, #15
    v.cmp.ne     p2, v4, v5
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v4
    p.and        p3, p4, p2
    s.movz       s6, #24
    p.and        p2, p3, p1
    s.movz       s9, #15
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s22, v2]              // index is in elements (ISA sec 9.1)
    s.addi       s10, s4, #1024
    s.mul        s12, s3, s6
    s.mul        s3, s7, s8
    s.movz       s6, #0
    s.addi       s7, s4, #2112
    s.addi       s13, s4, #1024
    s.add        s14, s6, s12                    // the tile origin
    s.addi       s6, s7, #64
    s.add        s12, s14, s3                    // the tile origin
    a.vwrite     a1, s9, v1
    v.ld.w       v1, [s10, #0]
    v.splat      v2, s12
    s.addi       s3, s12, #1
    s.addi       s9, s4, #1024
    v.splat      v4, s3
    s.addi       s3, s12, #2
    s.addi       s10, s7, #128
    v.splat      v5, s3
    s.addi       s3, s4, #1024
    s.addi       s14, s12, #3
    v.add        v6, v1, v2
    v.splat      v1, s14
    v.st.w       [s7, #0], v6
    s.addi       s14, s7, #192
    s.addi       s15, s4, #1024
    s.addi       s16, s12, #4
    v.splat      v2, s16
    s.addi       s16, s7, #256
    v.ld.w       v6, [s13, #0]
    s.addi       s13, s4, #1024
    v.add        v7, v6, v4
    v.st.w       [s6, #0], v7
    s.addi       s6, s12, #5
    v.splat      v4, s6
    s.addi       s6, s7, #320
    v.ld.w       v6, [s9, #0]
    s.addi       s9, s4, #1024
    v.add        v7, v6, v5
    v.st.w       [s10, #0], v7
    s.addi       s10, s12, #6
    v.splat      v5, s10
    s.addi       s10, s7, #384
    v.ld.w       v6, [s3, #0]
    s.addi       s3, s4, #1024
    v.add        v7, v6, v1
    v.st.w       [s14, #0], v7
    s.addi       s14, s12, #7
    v.splat      v1, s14
    s.addi       s14, s7, #448
    v.ld.w       v6, [s15, #0]
    s.addi       s15, s4, #1024
    v.add        v7, v6, v2
    v.st.w       [s16, #0], v7
    s.addi       s16, s12, #8
    v.splat      v2, s16
    s.addi       s16, s7, #512
    v.ld.w       v6, [s13, #0]
    s.addi       s13, s4, #1024
    v.add        v7, v6, v4
    v.st.w       [s6, #0], v7
    s.addi       s6, s12, #9
    v.splat      v4, s6
    s.addi       s6, s7, #576
    v.ld.w       v6, [s9, #0]
    s.addi       s9, s4, #1024
    v.add        v7, v6, v5
    v.st.w       [s10, #0], v7
    s.addi       s10, s12, #10
    v.splat      v5, s10
    s.addi       s10, s7, #640
    v.ld.w       v6, [s3, #0]
    s.addi       s3, s4, #1024
    v.add        v7, v6, v1
    v.st.w       [s14, #0], v7
    s.addi       s14, s12, #11
    v.splat      v1, s14
    s.addi       s14, s7, #704
    v.ld.w       v6, [s15, #0]
    s.addi       s15, s4, #1024
    v.add        v7, v6, v2
    v.st.w       [s16, #0], v7
    s.addi       s16, s12, #12
    v.splat      v2, s16
    s.addi       s16, s7, #768
    v.ld.w       v6, [s13, #0]
    s.addi       s13, s4, #1024
    v.add        v7, v6, v4
    v.splat      v4, s2
    v.st.w       [s6, #0], v7
    s.addi       s6, s12, #13
    v.splat      v6, s8
    v.splat      v7, s6
    s.addi       s6, s7, #832
    v.cmp.lt     p1, v4, v6
    v.ld.w       v4, [s9, #0]
    s.addi       s9, s4, #1024
    v.add        v8, v4, v5
    v.splat      v4, s8
    v.st.w       [s10, #0], v8
    s.addi       s10, s12, #14
    s.addi       s17, s12, #15
    v.splat      v5, s10
    s.addi       s10, s7, #896
    v.splat      v8, s17
    s.addi       s12, s4, #1024
    s.addi       s17, s7, #960
    v.ld.w       v14, [s3, #0]
    s.addi       s3, s4, #2112
    v.add        v15, v14, v1
    v.st.w       [s14, #0], v15
    s.movz       s7, #0
    v.splat      v1, s28
    s.add        s14, s7, s5                     // the tile origin
    v.cmp.lt     p2, v1, v6
    v.splat      v1, s14
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s7, #0
    v.add        v14, v12, v1
    v.cmp.lt     p3, v14, v4
    v.ld.w       v1, [s15, #0]
    p.and        p4, p1, p3
    s.addi       s14, s4, #2176
    p.and        p1, p2, p3
    v.add        v4, v1, v2
    v.st.w       [s16, #0], v4
    s.movz       s15, #1
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s4, #2240
    v.add        v2, v1, v7
    v.st.w       [s6, #0], v2
    s.movz       s6, #2
    v.splat      v1, s6
    s.movz       s6, #2
    v.cmp.lt     p2, v1, v6
    p.and        p5, p2, p3
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s4, #2304
    v.splat      v2, s11
    s.movz       s11, #3
    v.add        v4, v1, v5
    v.st.w       [s10, #0], v4
    s.addi       s10, s4, #2368
    v.ld.w       v1, [s12, #0]
    s.movz       s12, #4
    v.splat      v4, s12
    s.movz       s12, #4
    v.add        v5, v1, v8
    v.st.w       [s17, #0], v5
    fence.acq_rel.device
    s.movz       s16, #5
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s4, #2432
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v5, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v6
    p.and        p4, p2, p3
    a.vwrite     a2, s7, v5
    v.ld.w       v1, [s14, #0]
    s.movz       s7, #5
    s.addi       s14, s4, #2496
    v.splat      v2, s7
    s.movz       s7, #6
    v.splat      v5, s7
    s.movz       s7, #6
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v6
    p.and        p2, p1, p3
    a.vwrite     a2, s15, v7
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s4, #2560
    s.movz       s15, #7
    v.splat      v4, s15
    s.movz       s15, #7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v7, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v6
    p.and        p5, p1, p3
    a.vwrite     a2, s6, v7
    v.ld.w       v1, [s9, #0]
    s.addi       s6, s4, #2624
    v.splat      v2, s8
    s.movz       s8, #8
    s.addi       s9, s4, #2688
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v7, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p3
    a.vwrite     a2, s11, v7
    v.ld.w       v1, [s10, #0]
    v.splat      v5, s26
    s.movz       s10, #9
    s.addi       s11, s4, #2752
    s.movz       s17, #10
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v6
    p.and        p2, p1, p3
    a.vwrite     a2, s12, v7
    v.ld.w       v1, [s3, #0]
    s.movz       s3, #10
    s.addi       s12, s4, #2816
    v.splat      v4, s3
    s.movz       s3, #11
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v7, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v6
    p.and        p5, p1, p3
    a.vwrite     a2, s16, v7
    v.ld.w       v1, [s14, #0]
    s.movz       s14, #11
    s.addi       s16, s4, #2880
    v.splat      v2, s14
    s.movz       s14, #12
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v7, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p3
    a.vwrite     a2, s7, v7
    v.ld.w       v1, [s13, #0]
    s.movz       s7, #12
    s.addi       s13, s4, #2944
    v.splat      v5, s7
    s.movz       s7, #13
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v6
    p.and        p2, p1, p3
    a.vwrite     a2, s15, v7
    v.ld.w       v1, [s6, #0]
    s.movz       s6, #13
    s.addi       s15, s4, #3008
    v.splat      v4, s6
    s.movz       s6, #14
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v7, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v6
    p.and        p5, p1, p3
    a.vwrite     a2, s8, v7
    v.ld.w       v1, [s9, #0]
    s.movz       s8, #14
    s.movz       s9, #15
    v.splat      v2, s8
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v7, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p3
    s.addi       s8, s4, #3072
    a.vwrite     a2, s10, v7
    v.ld.w       v1, [s11, #0]
    s.movz       s10, #15
    v.movi       v5, #0
    v.splat      v7, s10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v6
    p.and        p2, p1, p3
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s10, #0
    a.vwrite     a2, s17, v8
    v.ld.w       v1, [s12, #0]
    s.movz       s11, #0
    s.movz       s12, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v6
    p.and        p5, p1, p3
    a.vwrite     a2, s3, v4
    v.ld.w       v1, [s16, #0]
    s.movz       s3, #1
    s.movz       s16, #2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p3
    a.vwrite     a2, s14, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s13, #3
    s.movz       s14, #4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s24, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s7, v2
    v.ld.w       v1, [s15, #0]
    s.movz       s7, #5
    s.movz       s15, #6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v2, [s24, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s6, v2
    v.ld.w       v1, [s8, #0]
    s.movz       s6, #7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s24, v1]              // index is in elements (ISA sec 9.1)
    s.movz       s8, #8
    a.vwrite     a2, s9, v2
    a.vread      v1, a1, s11
    a.vread      v2, a2, s12
    v.extract    s9, v1, #0
    v.splat      v4, s9
    v.extract    s9, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s9
    a.vread      v4, a2, s3
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s16
    v.extract    s3, v1, #3
    vf.fma       v6, v2, v4, v7
    v.splat      v2, s3
    a.vread      v4, a2, s13
    v.extract    s3, v1, #4
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s14
    v.extract    s3, v1, #5
    vf.fma       v6, v2, v4, v7
    v.splat      v2, s3
    a.vread      v4, a2, s7
    v.extract    s3, v1, #6
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #7
    vf.fma       v6, v2, v4, v7
    v.splat      v2, s3
    a.vread      v4, a2, s6
    v.extract    s3, v1, #8
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s8
    s.movz       s3, #9
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #9
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #10
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #11
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #12
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #13
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #14
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v2, a2, s3
    s.movz       s3, #1
    vf.fma       v4, v1, v2, v6
    s.movz       s6, #0
    s.movz       s7, #1
    s.movz       s8, #2
    a.vwrite     a3, s10, v4
    a.vread      v1, a1, s3
    a.vread      v2, a2, s6
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s7
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s8
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #1
    vf.fma       v6, v2, v4, v7
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #2
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s6
    a.vread      v2, a2, s7
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s8
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s9
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #2
    vf.fma       v6, v2, v4, v7
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #3
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s6
    a.vread      v2, a2, s7
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s8
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s9
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #4
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s6
    a.vread      v2, a2, s7
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s8
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s9
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v2, v4, v7
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #5
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s6
    a.vread      v2, a2, s7
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s8
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s9
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #6
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s6
    a.vread      v2, a2, s7
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s8
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s9
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v2, v4, v7
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #7
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s6
    a.vread      v2, a2, s7
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s8
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s9
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #8
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s6
    a.vread      v2, a2, s7
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s8
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s9
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v2, v4, v7
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #9
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s6
    a.vread      v2, a2, s7
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s8
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s9
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #9
    vf.fma       v6, v2, v4, v7
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #10
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s6
    a.vread      v2, a2, s7
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s8
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s9
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #10
    vf.fma       v6, v2, v4, v7
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #11
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s6
    a.vread      v2, a2, s7
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s8
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s9
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #11
    vf.fma       v6, v2, v4, v7
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #12
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s6
    a.vread      v2, a2, s7
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s8
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s9
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #12
    vf.fma       v6, v2, v4, v7
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #13
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s6
    a.vread      v2, a2, s7
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s8
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s9
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #13
    vf.fma       v6, v2, v4, v7
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #14
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s6
    a.vread      v2, a2, s7
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s8
    v.extract    s3, v1, #2
    vf.fma       v7, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s9
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v7
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v7, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #14
    vf.fma       v6, v2, v4, v7
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v7, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v7
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #15
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s6
    a.vread      v2, a2, s7
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v6, v4, v2, v5
    v.splat      v2, s3
    a.vread      v4, a2, s8
    v.extract    s3, v1, #2
    vf.fma       v5, v2, v4, v6
    v.splat      v2, s3
    a.vread      v4, a2, s9
    s.movz       s3, #3
    vf.fma       v6, v2, v4, v5
    v.extract    s6, v1, #3
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v5, v2, v4, v6
    v.extract    s6, v1, #4
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v6, v2, v4, v5
    v.extract    s6, v1, #5
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v5, v2, v4, v6
    v.extract    s6, v1, #6
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v6, v2, v4, v5
    v.extract    s6, v1, #7
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v5, v2, v4, v6
    v.extract    s6, v1, #8
    v.splat      v2, s6
    a.vread      v4, a2, s3
    s.movz       s3, #15
    vf.fma       v6, v2, v4, v5
    s.movz       s6, #9
    v.extract    s7, v1, #9
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #10
    vf.fma       v5, v2, v4, v6
    v.extract    s7, v1, #10
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #11
    vf.fma       v6, v2, v4, v5
    v.extract    s7, v1, #11
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #12
    vf.fma       v5, v2, v4, v6
    v.extract    s7, v1, #12
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #13
    vf.fma       v6, v2, v4, v5
    v.extract    s7, v1, #13
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #14
    vf.fma       v5, v2, v4, v6
    v.extract    s7, v1, #14
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v6, v2, v4, v5
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v2, a2, s6
    s.movz       s6, #0
    vf.fma       v4, v1, v2, v6
    s.movz       s7, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s8, #0
    s.movz       s9, #1
    a.vwrite     a3, s3, v4
    a.vread      v1, a0, s6
    a.vread      v2, a3, s7
    s.movz       s3, #1
    vf.add       v4, v1, v2
    s.movz       s6, #1
    s.movz       s7, #2
    s.movz       s10, #2
    a.vwrite     a4, s8, v4
    a.vread      v1, a0, s9
    a.vread      v2, a3, s3
    s.movz       s3, #2
    vf.add       v4, v1, v2
    s.movz       s8, #3
    s.movz       s9, #3
    s.movz       s11, #3
    a.vwrite     a4, s6, v4
    a.vread      v1, a0, s7
    a.vread      v2, a3, s10
    s.movz       s6, #4
    vf.add       v4, v1, v2
    s.movz       s7, #4
    s.movz       s10, #4
    s.movz       s12, #5
    a.vwrite     a4, s3, v4
    a.vread      v1, a0, s8
    a.vread      v2, a3, s9
    s.movz       s3, #5
    vf.add       v4, v1, v2
    s.movz       s8, #5
    s.movz       s9, #6
    s.movz       s13, #6
    a.vwrite     a4, s11, v4
    a.vread      v1, a0, s6
    a.vread      v2, a3, s7
    s.movz       s6, #6
    vf.add       v4, v1, v2
    s.movz       s7, #7
    s.movz       s11, #7
    s.movz       s14, #7
    a.vwrite     a4, s10, v4
    a.vread      v1, a0, s12
    a.vread      v2, a3, s3
    s.movz       s3, #8
    vf.add       v4, v1, v2
    s.movz       s10, #8
    s.movz       s12, #8
    s.movz       s15, #9
    a.vwrite     a4, s8, v4
    a.vread      v1, a0, s9
    a.vread      v2, a3, s13
    s.movz       s8, #9
    vf.add       v4, v1, v2
    s.movz       s9, #9
    s.movz       s13, #10
    s.movz       s16, #10
    a.vwrite     a4, s6, v4
    a.vread      v1, a0, s7
    a.vread      v2, a3, s11
    s.movz       s6, #10
    vf.add       v4, v1, v2
    s.movz       s7, #11
    s.movz       s11, #11
    s.movz       s17, #11
    a.vwrite     a4, s14, v4
    a.vread      v1, a0, s3
    a.vread      v2, a3, s10
    s.movz       s3, #12
    vf.add       v4, v1, v2
    s.movz       s10, #12
    s.movz       s14, #12
    s.movz       s18, #13
    a.vwrite     a4, s12, v4
    a.vread      v1, a0, s15
    a.vread      v2, a3, s8
    s.movz       s8, #13
    vf.add       v4, v1, v2
    s.movz       s12, #13
    s.movz       s15, #14
    a.vwrite     a4, s9, v4
    a.vread      v1, a0, s13
    a.vread      v2, a3, s16
    s.movz       s9, #14
    vf.add       v4, v1, v2
    s.movz       s13, #14
    s.movz       s16, #15
    a.vwrite     a4, s6, v4
    a.vread      v1, a0, s7
    a.vread      v2, a3, s11
    s.movz       s6, #15
    vf.add       v4, v1, v2
    s.movz       s7, #15
    s.movz       s11, #0
    a.vwrite     a4, s17, v4
    a.vread      v1, a0, s3
    a.vread      v2, a3, s10
    s.movz       s3, #0
    vf.add       v4, v1, v2
    s.movz       s10, #1
    s.movz       s17, #1
    a.vwrite     a4, s14, v4
    a.vread      v1, a0, s18
    a.vread      v2, a3, s8
    s.movz       s8, #2
    vf.add       v4, v1, v2
    s.movz       s14, #2
    s.movz       s18, #3
    a.vwrite     a4, s12, v4
    a.vread      v1, a0, s15
    a.vread      v2, a3, s9
    s.movz       s9, #3
    vf.add       v4, v1, v2
    s.movz       s12, #4
    s.movz       s15, #4
    a.vwrite     a4, s13, v4
    a.vread      v1, a0, s16
    a.vread      v2, a3, s6
    s.movz       s6, #5
    vf.add       v4, v1, v2
    s.movz       s13, #5
    s.movz       s16, #6
    a.vwrite     a4, s7, v4
    a.vread      v1, a4, s11
    s.movz       s7, #6
    a.vwrite     a0, s3, v1
    a.vread      v1, a4, s10
    s.movz       s3, #7
    a.vwrite     a0, s17, v1
    a.vread      v1, a4, s8
    s.movz       s8, #7
    a.vwrite     a0, s14, v1
    a.vread      v1, a4, s18
    s.movz       s10, #8
    a.vwrite     a0, s9, v1
    a.vread      v1, a4, s12
    s.movz       s9, #8
    a.vwrite     a0, s15, v1
    a.vread      v1, a4, s6
    s.movz       s6, #9
    a.vwrite     a0, s13, v1
    a.vread      v1, a4, s16
    s.movz       s11, #9
    a.vwrite     a0, s7, v1
    a.vread      v1, a4, s3
    s.movz       s3, #10
    a.vwrite     a0, s8, v1
    a.vread      v1, a4, s10
    s.movz       s7, #10
    a.vwrite     a0, s9, v1
    a.vread      v1, a4, s6
    s.movz       s6, #11
    a.vwrite     a0, s11, v1
    a.vread      v1, a4, s3
    s.movz       s3, #11
    a.vwrite     a0, s7, v1
    a.vread      v1, a4, s6
    s.movz       s6, #12
    a.vwrite     a0, s3, v1
    s.movz       s3, #12
    a.vread      v1, a4, s6
    s.movz       s6, #13
    a.vwrite     a0, s3, v1
    s.movz       s3, #13
    a.vread      v1, a4, s6
    s.movz       s6, #14
    a.vwrite     a0, s3, v1
    s.movz       s3, #14
    a.vread      v1, a4, s6
    s.movz       s6, #15
    a.vwrite     a0, s3, v1
    s.movz       s3, #15
    a.vread      v1, a4, s6
    s.add        s6, s1, s28
    s.movz       s7, #1
    a.vwrite     a0, s3, v1
    s.mov        s1, s6
    br.nz        s7, for_1
endfor_2:
    s.muli       s1, s5, #64                     // a runtime tile origin, x64
    s.movz       s3, #8
    s.movz       s6, #0
    s.movz       s7, #64
    v.extract    s8, v9, #0
    v.extract    s9, v9, #1
    v.splat      v0, s8
    v.splat      v1, s3
    s.add        s3, s6, s1                      // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s7
    v.splat      v5, s9
    v.extract    s1, v11, #0
    v.extract    s6, v11, #1
    v.splat      v6, s1
    v.mul        v7, v0, v1
    v.mul        v0, v2, v4
    v.splat      v2, s3
    v.splat      v4, s6
    v.mul        v8, v5, v1
    v.extract    s1, v13, #0
    v.extract    s3, v13, #1
    v.add        v5, v6, v7
    v.add        v6, v0, v2
    v.splat      v0, s1
    v.splat      v2, s23
    v.add        v7, v4, v8
    s.addi       s1, s4, #3136
    v.add        v4, v5, v6
    v.mul        v5, v0, v2
    v.add        v0, v7, v6
    v.add        v7, v4, v5
    s.addi       s6, s1, #64
    v.st.w       [s1, #0], v7
    v.movi       v4, #1
    v.splat      v5, s3
    v.movi       v7, #1
    v.movi       v8, #0
    v.movi       v12, #1
    v.movi       v14, #0
    v.cmp.lt     p1, v13, v4
    v.mul        v4, v5, v2
    v.cmp.lt     p2, v9, v3
    v.add        v5, v0, v4
    @p1 v.sel        v0, v7, v8
    v.extract    s3, v9, #2
    v.extract    s7, v11, #2
    v.splat      v4, s7
    s.addi       s7, s1, #128
    v.st.w       [s6, #0], v5
    @p2 v.sel        v5, v12, v14
    v.splat      v7, s3
    v.movi       v8, #1
    v.movi       v12, #0
    v.cmp.lt     p1, v11, v3
    v.mul        v14, v7, v1
    @p1 v.sel        v7, v8, v12
    v.extract    s3, v13, #2
    v.add        v8, v4, v14
    v.cmp.lt     p1, v10, v3
    v.extract    s6, v9, #3
    v.extract    s8, v9, #4
    v.extract    s9, v9, #5
    v.splat      v3, s6
    v.splat      v4, s8
    v.splat      v10, s9
    v.extract    s6, v11, #3
    v.extract    s8, v11, #4
    v.extract    s9, v11, #5
    v.extract    s10, v11, #6
    v.splat      v12, s6
    v.mul        v14, v3, v1
    v.splat      v3, s8
    v.mul        v15, v4, v1
    v.mul        v4, v10, v1
    v.extract    s6, v13, #3
    v.extract    s8, v13, #4
    v.extract    s11, v13, #5
    v.add        v10, v12, v14
    v.splat      v12, s9
    v.add        v14, v3, v15
    v.splat      v3, s10
    v.add        v15, v12, v4
    v.splat      v4, s3
    v.add        v12, v8, v6
    v.extract    s3, v9, #6
    v.mul        v8, v4, v2
    v.add        v4, v10, v6
    v.add        v10, v14, v6
    v.add        v14, v15, v6
    v.add        v15, v12, v8
    v.splat      v8, s3
    s.addi       s3, s1, #192
    v.mul        v12, v8, v1
    s.addi       s9, s1, #256
    v.add        v8, v3, v12
    v.splat      v3, s6
    v.add        v12, v8, v6
    v.mul        v8, v3, v2
    s.addi       s6, s1, #320
    v.add        v3, v4, v8
    v.splat      v4, s8
    s.addi       s8, s1, #384
    v.mul        v8, v4, v2
    v.st.w       [s7, #0], v15
    v.extract    s7, v9, #7
    v.splat      v4, s7
    v.extract    s7, v11, #7
    v.mul        v15, v4, v1
    v.extract    s10, v13, #6
    v.add        v4, v10, v8
    v.splat      v8, s7
    s.addi       s7, s1, #448
    v.add        v10, v8, v15
    v.splat      v8, s11
    v.add        v15, v10, v6
    v.mul        v10, v8, v2
    v.st.w       [s3, #0], v3
    v.extract    s3, v9, #8
    v.splat      v3, s3
    v.extract    s3, v11, #8
    v.mul        v8, v3, v1
    v.extract    s11, v13, #7
    v.add        v3, v14, v10
    v.splat      v10, s3
    s.addi       s3, s1, #512
    v.add        v14, v10, v8
    v.splat      v8, s10
    v.add        v10, v14, v6
    v.mul        v14, v8, v2
    v.st.w       [s9, #0], v4
    v.extract    s9, v9, #9
    v.splat      v4, s9
    v.extract    s9, v11, #9
    v.mul        v8, v4, v1
    v.extract    s10, v13, #8
    v.add        v4, v12, v14
    v.splat      v12, s9
    s.addi       s9, s1, #576
    v.add        v14, v12, v8
    v.splat      v8, s11
    v.add        v12, v14, v6
    v.mul        v14, v8, v2
    v.st.w       [s6, #0], v3
    v.extract    s6, v9, #10
    v.splat      v3, s6
    v.extract    s6, v11, #10
    v.mul        v8, v3, v1
    v.extract    s11, v13, #9
    v.add        v3, v15, v14
    v.splat      v14, s6
    s.addi       s6, s1, #640
    v.add        v15, v14, v8
    v.splat      v8, s10
    v.add        v14, v15, v6
    v.mul        v15, v8, v2
    v.st.w       [s8, #0], v4
    v.extract    s8, v9, #11
    v.splat      v4, s8
    v.extract    s8, v11, #11
    v.mul        v8, v4, v1
    v.extract    s10, v13, #10
    v.add        v4, v10, v15
    v.splat      v10, s8
    s.addi       s8, s1, #704
    v.add        v15, v10, v8
    v.splat      v8, s11
    v.add        v10, v15, v6
    v.mul        v15, v8, v2
    v.st.w       [s7, #0], v3
    v.extract    s7, v9, #12
    v.splat      v3, s7
    v.extract    s7, v11, #12
    v.mul        v8, v3, v1
    v.extract    s11, v13, #11
    v.add        v3, v12, v15
    v.splat      v12, s7
    s.addi       s7, s1, #768
    v.add        v15, v12, v8
    v.splat      v8, s10
    v.add        v12, v15, v6
    v.mul        v15, v8, v2
    v.st.w       [s3, #0], v4
    v.extract    s3, v9, #13
    v.splat      v4, s3
    v.extract    s3, v11, #13
    v.mul        v8, v4, v1
    v.extract    s10, v13, #12
    v.add        v4, v14, v15
    v.splat      v14, s3
    s.addi       s3, s1, #832
    v.add        v15, v14, v8
    v.splat      v8, s11
    v.add        v14, v15, v6
    v.mul        v15, v8, v2
    v.st.w       [s9, #0], v3
    v.extract    s9, v9, #14
    v.splat      v3, s9
    v.extract    s9, v11, #14
    v.mul        v8, v3, v1
    v.extract    s11, v13, #13
    v.add        v3, v10, v15
    v.splat      v10, s9
    s.addi       s9, s1, #896
    v.add        v15, v10, v8
    v.splat      v8, s10
    v.add        v10, v15, v6
    v.mul        v15, v8, v2
    v.st.w       [s6, #0], v4
    v.extract    s6, v9, #15
    v.splat      v4, s6
    v.extract    s6, v11, #15
    v.splat      v8, s6
    v.mul        v9, v4, v1
    v.extract    s6, v13, #14
    v.splat      v1, s11
    v.splat      v4, s6
    v.add        v11, v8, v9
    v.mul        v8, v1, v2
    v.mul        v1, v4, v2
    v.add        v4, v11, v6
    v.add        v6, v12, v15
    v.add        v9, v14, v8
    v.add        v8, v10, v1
    s.addi       s6, s1, #960
    v.st.w       [s8, #0], v3
    v.extract    s1, v13, #15
    v.splat      v1, s1
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s1, s5, #4                      // a runtime tile origin, x4
    v.mul        v3, v1, v2
    s.muli       s8, s5, #4                      // a runtime tile origin, x4
    v.add        v1, v4, v3
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s10, s5, #4                     // a runtime tile origin, x4
    s.add        s11, s27, s1                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s1, s5, #4                      // a runtime tile origin, x4
    v.st.w       [s7, #0], v6
    s.addi       s5, s4, #3136
    v.splat      v2, s2
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.addi       s7, s4, #4160
    s.addi       s12, s4, #3200
    s.add        s13, s25, s8                    // the tile origin
    s.addi       s8, s7, #64
    s.add        s14, s29, s10                   // the tile origin
    s.addi       s10, s7, #128
    s.add        s15, s30, s1                    // the tile origin
    v.st.w       [s3, #0], v9
    s.addi       s1, s4, #3264
    s.addi       s3, s4, #3328
    v.st.w       [s9, #0], v8
    s.addi       s9, s7, #192
    v.st.w       [s6, #0], v1
    fence.acq_rel.device
    s.addi       s6, s4, #3392
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s7, #256
    v.add        v3, v2, v1
    v.st.w       [s7, #0], v3
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s4, #3456
    v.add        v3, v2, v1
    v.st.w       [s8, #0], v3
    s.addi       s8, s7, #320
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s4, #3520
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s7, #384
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s4, #3584
    v.add        v3, v2, v1
    v.st.w       [s9, #0], v3
    s.addi       s9, s7, #448
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #3648
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    s.addi       s5, s7, #512
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s4, #3712
    v.add        v3, v2, v1
    v.st.w       [s8, #0], v3
    s.addi       s8, s7, #576
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s4, #3776
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s7, #640
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s4, #3840
    v.add        v3, v2, v1
    v.movi       v1, #0
    v.st.w       [s9, #0], v3
    s.addi       s9, s7, #704
    v.ld.w       v3, [s6, #0]
    s.addi       s6, s4, #3904
    v.movi       v4, #0
    v.add        v6, v2, v3
    v.st.w       [s5, #0], v6
    s.addi       s5, s7, #768
    v.ld.w       v3, [s12, #0]
    s.addi       s12, s4, #3968
    v.movi       v6, #0
    v.add        v8, v2, v3
    v.st.w       [s8, #0], v8
    s.addi       s8, s7, #832
    v.ld.w       v3, [s1, #0]
    s.addi       s1, s4, #4032
    v.add        v8, v2, v3
    v.st.w       [s10, #0], v8
    s.addi       s10, s7, #896
    s.addi       s16, s7, #960
    v.ld.w       v3, [s3, #0]
    s.addi       s3, s4, #4096
    v.add        v8, v2, v3
    v.movi       v3, #0
    v.st.w       [s9, #0], v8
    s.addi       s7, s4, #4160
    v.ld.w       v8, [s6, #0]
    v.extract    s6, v0, #0
    v.splat      v9, s6
    v.extract    s6, v5, #0
    v.splat      v10, s6
    v.extract    s6, v7, #0
    v.cmp.ne     p2, v9, v1
    v.cmp.ne     p3, v10, v4
    v.splat      v1, s6
    p.and        p4, p2, p3
    v.add        v4, v2, v8
    v.cmp.ne     p2, v1, v6
    v.st.w       [s5, #0], v4
    p.and        p3, p4, p2
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s5, #0
    p.and        p2, p3, p1
    s.addi       s6, s4, #4224
    v.movi       v1, #0
    v.ld.w       v4, [s12, #0]
    v.extract    s9, v0, #1
    v.splat      v6, s9
    v.extract    s9, v5, #1
    v.splat      v8, s9
    v.extract    s9, v7, #1
    v.cmp.ne     p3, v6, v3
    v.cmp.ne     p4, v8, v1
    v.splat      v1, s9
    v.movi       v3, #0
    v.add        v6, v2, v4
    p.and        p5, p3, p4
    v.st.w       [s8, #0], v6
    v.cmp.ne     p3, v1, v3
    p.and        p4, p5, p3
    s.movz       s8, #1
    p.and        p3, p4, p1
    v.ld.w       v1, [s1, #0]
    v.add        v3, v2, v1
    s.movz       s1, #2
    v.st.w       [s10, #0], v3
    s.addi       s9, s4, #4288
    v.extract    s10, v0, #2
    v.ld.w       v1, [s3, #0]
    v.splat      v3, s10
    v.add        v4, v2, v1
    v.movi       v1, #0
    v.st.w       [s16, #0], v4
    fence.acq_rel.device
    v.extract    s3, v5, #2
    v.splat      v2, s3
    v.movi       v4, #0
    v.cmp.ne     p4, v3, v1
    v.ld.w       v1, [s7, #0]
    v.extract    s3, v7, #2
    v.splat      v3, s3
    v.movi       v6, #0
    s.addi       s3, s4, #4352
    v.extract    s7, v0, #3
    v.splat      v8, s7
    v.movi       v9, #0
    s.movz       s7, #3
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v10, [s31, v1]             // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v2, v4
    p.and        p5, p4, p2
    v.cmp.ne     p2, v3, v6
    p.and        p4, p5, p2
    v.cmp.ne     p2, v8, v9
    p.and        p5, p4, p1
    a.vwrite     a5, s5, v10
    v.ld.w       v1, [s6, #0]
    v.extract    s5, v5, #3
    v.splat      v2, s5
    v.movi       v3, #0
    v.extract    s5, v7, #3
    v.splat      v4, s5
    v.movi       v6, #0
    s.addi       s5, s4, #4416
    v.extract    s6, v0, #4
    v.splat      v8, s6
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v9, [s31, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v3
    p.and        p4, p2, p3
    v.cmp.ne     p2, v4, v6
    p.and        p3, p4, p2
    v.movi       v1, #0
    p.and        p2, p3, p1
    v.cmp.ne     p3, v8, v1
    s.movz       s6, #4
    a.vwrite     a5, s8, v9
    v.ld.w       v1, [s9, #0]
    v.extract    s8, v5, #4
    v.splat      v2, s8
    v.movi       v3, #0
    v.extract    s8, v7, #4
    v.splat      v4, s8
    v.movi       v6, #0
    s.addi       s8, s4, #4480
    v.extract    s9, v0, #5
    v.splat      v8, s9
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v9, [s31, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p4, v2, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v4, v6
    p.and        p4, p5, p3
    v.movi       v1, #0
    p.and        p3, p4, p1
    v.cmp.ne     p4, v8, v1
    s.movz       s9, #5
    a.vwrite     a5, s1, v9
    v.ld.w       v1, [s3, #0]
    v.extract    s1, v5, #5
    v.splat      v2, s1
    v.movi       v3, #0
    v.extract    s1, v7, #5
    v.splat      v4, s1
    v.movi       v6, #0
    s.addi       s1, s4, #4544
    v.extract    s3, v0, #6
    v.splat      v8, s3
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s31, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v4, v6
    p.and        p4, p5, p2
    v.movi       v1, #0
    p.and        p2, p4, p1
    v.cmp.ne     p4, v8, v1
    s.movz       s3, #6
    a.vwrite     a5, s7, v9
    v.ld.w       v1, [s5, #0]
    v.extract    s5, v5, #6
    v.splat      v2, s5
    v.movi       v3, #0
    v.extract    s5, v7, #6
    v.splat      v4, s5
    v.movi       v6, #0
    s.addi       s5, s4, #4608
    v.extract    s7, v0, #7
    v.splat      v8, s7
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v9, [s31, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v6
    p.and        p4, p5, p3
    v.movi       v1, #0
    p.and        p3, p4, p1
    v.cmp.ne     p4, v8, v1
    s.movz       s7, #7
    a.vwrite     a5, s6, v9
    v.ld.w       v1, [s8, #0]
    v.extract    s6, v5, #7
    v.splat      v2, s6
    v.movi       v3, #0
    v.extract    s6, v7, #7
    v.splat      v4, s6
    v.movi       v6, #0
    s.addi       s6, s4, #4672
    v.extract    s8, v0, #8
    v.splat      v8, s8
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s31, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v4, v6
    p.and        p4, p5, p2
    v.movi       v1, #0
    p.and        p2, p4, p1
    v.cmp.ne     p4, v8, v1
    s.movz       s8, #8
    a.vwrite     a5, s9, v9
    v.ld.w       v1, [s1, #0]
    v.extract    s1, v5, #8
    v.splat      v2, s1
    v.movi       v3, #0
    v.extract    s1, v7, #8
    v.splat      v4, s1
    v.movi       v6, #0
    s.addi       s1, s4, #4736
    v.extract    s9, v0, #9
    v.splat      v8, s9
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v9, [s31, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v6
    p.and        p4, p5, p3
    v.movi       v1, #0
    p.and        p3, p4, p1
    v.cmp.ne     p4, v8, v1
    s.movz       s9, #9
    a.vwrite     a5, s3, v9
    v.ld.w       v1, [s5, #0]
    v.extract    s3, v5, #9
    v.splat      v2, s3
    v.movi       v3, #0
    v.extract    s3, v7, #9
    v.splat      v4, s3
    v.movi       v6, #0
    s.addi       s3, s4, #4800
    v.extract    s5, v0, #10
    v.splat      v8, s5
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s31, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v4, v6
    p.and        p4, p5, p2
    v.movi       v1, #0
    p.and        p2, p4, p1
    v.cmp.ne     p4, v8, v1
    s.movz       s5, #10
    a.vwrite     a5, s7, v9
    v.ld.w       v1, [s6, #0]
    v.extract    s6, v5, #10
    v.splat      v2, s6
    v.movi       v3, #0
    v.extract    s6, v7, #10
    v.splat      v4, s6
    v.movi       v6, #0
    s.addi       s6, s4, #4864
    v.extract    s7, v0, #11
    v.splat      v8, s7
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v9, [s31, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v6
    p.and        p4, p5, p3
    v.movi       v1, #0
    p.and        p3, p4, p1
    v.cmp.ne     p4, v8, v1
    s.movz       s7, #11
    a.vwrite     a5, s8, v9
    v.ld.w       v1, [s1, #0]
    v.extract    s1, v5, #11
    v.splat      v2, s1
    v.movi       v3, #0
    v.extract    s1, v7, #11
    v.splat      v4, s1
    v.movi       v6, #0
    s.addi       s1, s4, #4928
    v.extract    s8, v0, #12
    v.splat      v8, s8
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s31, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v4, v6
    p.and        p4, p5, p2
    v.movi       v1, #0
    p.and        p2, p4, p1
    v.cmp.ne     p4, v8, v1
    s.movz       s8, #12
    a.vwrite     a5, s9, v9
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v5, #12
    v.splat      v2, s3
    v.movi       v3, #0
    v.extract    s3, v7, #12
    v.splat      v4, s3
    v.movi       v6, #0
    s.addi       s3, s4, #4992
    v.extract    s9, v0, #13
    v.splat      v8, s9
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v9, [s31, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v6
    p.and        p4, p5, p3
    v.movi       v1, #0
    p.and        p3, p4, p1
    v.cmp.ne     p4, v8, v1
    s.movz       s9, #13
    a.vwrite     a5, s5, v9
    v.ld.w       v1, [s6, #0]
    v.extract    s5, v5, #13
    v.splat      v2, s5
    v.movi       v3, #0
    v.extract    s5, v7, #13
    v.splat      v4, s5
    v.movi       v6, #0
    s.addi       s5, s4, #5056
    v.extract    s6, v0, #14
    v.splat      v8, s6
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s31, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v4, v6
    p.and        p4, p5, p2
    v.movi       v1, #0
    p.and        p2, p4, p1
    v.cmp.ne     p4, v8, v1
    s.movz       s6, #14
    a.vwrite     a5, s7, v9
    v.ld.w       v1, [s1, #0]
    v.extract    s1, v5, #14
    v.splat      v2, s1
    v.movi       v3, #0
    v.extract    s1, v7, #14
    v.splat      v4, s1
    v.movi       v6, #0
    s.addi       s1, s4, #5120
    v.extract    s7, v0, #15
    v.splat      v8, s7
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v9, [s31, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v6
    p.and        p4, p5, p3
    v.movi       v1, #0
    p.and        p3, p4, p1
    v.cmp.ne     p4, v8, v1
    s.movz       s7, #15
    a.vwrite     a5, s8, v9
    v.ld.w       v1, [s3, #0]
    v.extract    s3, v5, #15
    v.splat      v2, s3
    v.movi       v3, #0
    v.extract    s3, v7, #15
    v.splat      v4, s3
    v.movi       v6, #0
    s.addi       s3, s4, #3136
    v.splat      v8, s2
    s.addi       s2, s4, #5184
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s31, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v4, v6
    p.and        p4, p5, p2
    .li       s8, #925353388
    v.splat      v1, s8                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    p.and        p2, p4, p1
    v.movi       v2, #0
    a.vwrite     a5, s9, v9
    v.ld.w       v3, [s5, #0]
    s.addi       s5, s4, #3200
    s.addi       s8, s2, #64
    s.addi       s9, s4, #3264
    s.addi       s10, s2, #128
    s.addi       s12, s4, #3328
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s31, v3]              // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s6, v4
    v.ld.w       v3, [s1, #0]
    s.addi       s1, s2, #192
    s.addi       s6, s4, #3392
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s31, v3]              // index is in elements (ISA sec 9.1)
    s.addi       s16, s2, #256
    a.vwrite     a5, s7, v4
    v.ld.w       v3, [s3, #0]
    s.addi       s3, s4, #3456
    s.addi       s7, s2, #320
    v.add        v4, v8, v3
    v.st.w       [s2, #0], v4
    v.ld.w       v3, [s5, #0]
    s.addi       s5, s4, #3520
    v.add        v4, v8, v3
    v.st.w       [s8, #0], v4
    s.addi       s8, s2, #384
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s4, #3584
    v.add        v4, v8, v3
    v.st.w       [s10, #0], v4
    s.addi       s10, s2, #448
    v.ld.w       v3, [s12, #0]
    s.addi       s12, s4, #3648
    v.add        v4, v8, v3
    v.st.w       [s1, #0], v4
    s.addi       s1, s2, #512
    v.ld.w       v3, [s6, #0]
    s.addi       s6, s4, #3712
    v.add        v4, v8, v3
    v.st.w       [s16, #0], v4
    s.addi       s16, s2, #576
    v.ld.w       v3, [s3, #0]
    s.addi       s3, s4, #3776
    v.add        v4, v8, v3
    v.st.w       [s7, #0], v4
    s.addi       s7, s2, #640
    v.ld.w       v3, [s5, #0]
    s.addi       s5, s4, #3840
    v.add        v4, v8, v3
    v.st.w       [s8, #0], v4
    s.addi       s8, s2, #704
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s4, #3904
    v.movi       v4, #0
    v.add        v6, v8, v3
    v.st.w       [s10, #0], v6
    s.addi       s10, s2, #768
    v.movi       v3, #0
    v.ld.w       v6, [s12, #0]
    s.addi       s12, s4, #3968
    v.add        v9, v8, v6
    v.st.w       [s1, #0], v9
    s.addi       s1, s2, #832
    v.movi       v6, #0
    v.ld.w       v9, [s6, #0]
    s.addi       s6, s4, #4032
    v.add        v10, v8, v9
    v.st.w       [s16, #0], v10
    s.addi       s16, s2, #896
    s.addi       s17, s2, #960
    v.ld.w       v9, [s3, #0]
    s.addi       s2, s4, #4096
    v.add        v10, v8, v9
    v.st.w       [s7, #0], v10
    v.extract    s3, v0, #0
    v.splat      v9, s3
    v.extract    s3, v5, #0
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.ld.w       v9, [s5, #0]
    v.splat      v10, s3
    s.movz       s3, #0
    v.extract    s5, v0, #0
    v.splat      v11, s5
    v.extract    s5, v5, #0
    v.splat      v12, s5
    v.extract    s5, v7, #0
    v.cmp.ne     p3, v11, v4
    v.cmp.ne     p4, v12, v3
    v.add        v3, v8, v9
    v.movi       v4, #0
    v.st.w       [s8, #0], v3
    v.extract    s7, v7, #0
    v.splat      v3, s5
    p.and        p5, p3, p4
    v.cmp.ne     p3, v10, v4
    p.and        p4, p2, p3
    v.cmp.ne     p2, v3, v6
    p.and        p3, p5, p2
    p.and        p2, p3, p1
    v.ld.w       v3, [s9, #0]
    v.splat      v4, s7
    v.add        v6, v8, v3
    v.movi       v3, #0
    v.st.w       [s10, #0], v6
    v.cmp.ne     p3, v4, v3
    p.and        p5, p4, p3
    p.and        p3, p5, p1
    v.ld.w       v3, [s12, #0]
    v.add        v4, v8, v3
    v.st.w       [s1, #0], v4
    .li       s1, #1077936128
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v4, [s6, #0]
    v.add        v6, v8, v4
    .li       s1, #3204448256
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s16, #0], v6
    v.ld.w       v6, [s2, #0]
    v.add        v9, v8, v6
    v.st.w       [s17, #0], v9
    fence.acq_rel.device
    a.vread      v6, a0, s3
    v.extract    s1, v0, #0
    v.extract    s2, v5, #0
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v12, [s11, #0]
    v.cmp.ne     p3, v8, v9
    v.cmp.ne     p4, v10, v11
    v.splat      v8, s1
    v.movi       v9, #0
    p.and        p5, p3, p4
    v.extract    s1, v0, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s1
    p.and        p4, p5, p3
    vf.add       v9, v12, v1
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s13, #0]
    v.movi       v11, #0
    p.and        p2, p4, p1
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s14, #0]
    vf.sub       v14, v6, v10
    v.extract    s1, v5, #0
    v.splat      v6, s1
    v.movi       v10, #0
    v.extract    s1, v7, #0
    v.cmp.ne     p2, v8, v11
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v8, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v6, v8
    p.and        p3, p4, p2
    s.movz       s1, #0
    p.and        p2, p3, p1
    s.addi       s2, s4, #5184
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s15, #0]
    a.vread      v8, a5, s1
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    v.extract    s1, v0, #0
    vf.fms       v15, v9, v10, v3
    v.splat      v9, s1
    vf.mul       v10, v11, v15                   // Newton step: 0.5*r0*(3 - x*r0^2)
    v.ld.w       v11, [s2, #0]
    v.extract    s1, v5, #0
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v15, v10, v12
    v.movi       v10, #0
    vf.mul       v12, v14, v15
    v.splat      v14, s1
    v.extract    s1, v7, #0
    v.cmp.ne     p2, v9, v10
    vf.mul       v9, v12, v13
    v.extract    s2, v0, #1
    v.extract    s3, v5, #1
    v.movi       v10, #0
    vf.add       v12, v9, v6
    v.splat      v6, s2
    v.movi       v9, #0
    v.splat      v13, s3
    vf.add       v15, v12, v8
    v.movi       v8, #0
    v.extract    s2, v7, #1
    v.cmp.ne     p3, v14, v10
    v.splat      v10, s1
    v.movi       v12, #0
    v.cmp.ne     p4, v6, v9
    p.and        p5, p2, p3
    v.cmp.ne     p2, v13, v8
    p.and        p3, p4, p2
    v.cmp.ne     p2, v10, v12
    vf.max.prop  v6, v15, v2
    v.splat      v8, s2
    v.movi       v9, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v8, v9
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #1
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v11], v6
    a.vread      v6, a0, s1
    v.extract    s1, v0, #1
    v.extract    s2, v5, #1
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #1
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #1
    p.and        p2, p3, p1
    v.extract    s2, v5, #1
    vf.add       v9, v8, v1
    v.splat      v8, s1
    v.movi       v10, #0
    v.splat      v11, s2
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s13, #0]
    v.extract    s1, v7, #1
    v.cmp.ne     p2, v8, v10
    v.cmp.ne     p3, v11, v13
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #1
    v.extract    s2, v5, #1
    v.cmp.ne     p2, v8, v10
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v8, v10
    p.and        p4, p3, p1
    vf.sub       v8, v6, v14
    v.splat      v6, s2
    v.movi       v10, #0
    v.extract    s1, v7, #1
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v10, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    p.and        p3, p5, p2
    s.movz       s1, #1
    vf.fms       v13, v9, v10, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #5248
    v.extract    s3, v0, #1
    vf.mul       v9, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s15, #0]
    a.vread      v11, a5, s1
    v.extract    s1, v5, #1
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v12
    v.splat      v9, s3
    vf.mul       v12, v8, v13
    v.movi       v8, #0
    v.splat      v13, s1
    v.movi       v14, #0
    vf.mul       v15, v12, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v0, #2
    v.extract    s2, v5, #2
    vf.add       v12, v15, v10
    v.splat      v10, s1
    v.extract    s1, v7, #1
    v.cmp.ne     p2, v9, v8
    v.movi       v8, #0
    v.splat      v9, s2
    vf.add       v15, v12, v11
    v.movi       v11, #0
    v.extract    s2, v7, #2
    v.cmp.ne     p3, v13, v14
    v.splat      v12, s1
    v.movi       v13, #0
    v.cmp.ne     p4, v10, v8
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v11
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v13
    vf.max.prop  v8, v15, v2
    v.splat      v9, s2
    v.movi       v10, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #2
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v6], v8
    a.vread      v6, a0, s1
    v.extract    s1, v0, #2
    v.extract    s2, v5, #2
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #2
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #2
    p.and        p2, p3, p1
    v.extract    s2, v5, #2
    vf.add       v9, v8, v1
    v.splat      v8, s1
    v.movi       v10, #0
    v.splat      v11, s2
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s13, #0]
    v.extract    s1, v7, #2
    v.cmp.ne     p2, v8, v10
    v.cmp.ne     p3, v11, v13
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #2
    v.extract    s2, v5, #2
    v.cmp.ne     p2, v8, v10
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v8, v10
    p.and        p4, p3, p1
    vf.sub       v8, v6, v14
    v.splat      v6, s2
    v.movi       v10, #0
    v.extract    s1, v7, #2
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v10, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    p.and        p3, p5, p2
    s.movz       s1, #2
    vf.fms       v13, v9, v10, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #5312
    v.extract    s3, v0, #2
    vf.mul       v9, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s15, #0]
    a.vread      v11, a5, s1
    v.extract    s1, v5, #2
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v12
    v.splat      v9, s3
    vf.mul       v12, v8, v13
    v.movi       v8, #0
    v.splat      v13, s1
    v.movi       v14, #0
    vf.mul       v15, v12, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v0, #3
    v.extract    s2, v5, #3
    vf.add       v12, v15, v10
    v.splat      v10, s1
    v.extract    s1, v7, #2
    v.cmp.ne     p2, v9, v8
    v.movi       v8, #0
    v.splat      v9, s2
    vf.add       v15, v12, v11
    v.movi       v11, #0
    v.extract    s2, v7, #3
    v.cmp.ne     p3, v13, v14
    v.splat      v12, s1
    v.movi       v13, #0
    v.cmp.ne     p4, v10, v8
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v11
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v13
    vf.max.prop  v8, v15, v2
    v.splat      v9, s2
    v.movi       v10, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #3
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v6], v8
    a.vread      v6, a0, s1
    v.extract    s1, v0, #3
    v.extract    s2, v5, #3
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #3
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #3
    p.and        p2, p3, p1
    v.extract    s2, v5, #3
    vf.add       v9, v8, v1
    v.splat      v8, s1
    v.movi       v10, #0
    v.splat      v11, s2
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s13, #0]
    v.extract    s1, v7, #3
    v.cmp.ne     p2, v8, v10
    v.cmp.ne     p3, v11, v13
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #3
    v.extract    s2, v5, #3
    v.cmp.ne     p2, v8, v10
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v8, v10
    p.and        p4, p3, p1
    vf.sub       v8, v6, v14
    v.splat      v6, s2
    v.movi       v10, #0
    v.extract    s1, v7, #3
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v10, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    p.and        p3, p5, p2
    s.movz       s1, #3
    vf.fms       v13, v9, v10, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #5376
    v.extract    s3, v0, #3
    vf.mul       v9, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s15, #0]
    a.vread      v11, a5, s1
    v.extract    s1, v5, #3
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v12
    v.splat      v9, s3
    vf.mul       v12, v8, v13
    v.movi       v8, #0
    v.splat      v13, s1
    v.movi       v14, #0
    vf.mul       v15, v12, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v0, #4
    v.extract    s2, v5, #4
    vf.add       v12, v15, v10
    v.splat      v10, s1
    v.extract    s1, v7, #3
    v.cmp.ne     p2, v9, v8
    v.movi       v8, #0
    v.splat      v9, s2
    vf.add       v15, v12, v11
    v.movi       v11, #0
    v.extract    s2, v7, #4
    v.cmp.ne     p3, v13, v14
    v.splat      v12, s1
    v.movi       v13, #0
    v.cmp.ne     p4, v10, v8
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v11
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v13
    vf.max.prop  v8, v15, v2
    v.splat      v9, s2
    v.movi       v10, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #4
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v6], v8
    a.vread      v6, a0, s1
    v.extract    s1, v0, #4
    v.extract    s2, v5, #4
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #4
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #4
    p.and        p2, p3, p1
    v.extract    s2, v5, #4
    vf.add       v9, v8, v1
    v.splat      v8, s1
    v.movi       v10, #0
    v.splat      v11, s2
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s13, #0]
    v.extract    s1, v7, #4
    v.cmp.ne     p2, v8, v10
    v.cmp.ne     p3, v11, v13
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #4
    v.extract    s2, v5, #4
    v.cmp.ne     p2, v8, v10
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v8, v10
    p.and        p4, p3, p1
    vf.sub       v8, v6, v14
    v.splat      v6, s2
    v.movi       v10, #0
    v.extract    s1, v7, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v10, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    p.and        p3, p5, p2
    s.movz       s1, #4
    vf.fms       v13, v9, v10, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #5440
    v.extract    s3, v0, #4
    vf.mul       v9, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s15, #0]
    a.vread      v11, a5, s1
    v.extract    s1, v5, #4
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v12
    v.splat      v9, s3
    vf.mul       v12, v8, v13
    v.movi       v8, #0
    v.splat      v13, s1
    v.movi       v14, #0
    vf.mul       v15, v12, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v0, #5
    v.extract    s2, v5, #5
    vf.add       v12, v15, v10
    v.splat      v10, s1
    v.extract    s1, v7, #4
    v.cmp.ne     p2, v9, v8
    v.movi       v8, #0
    v.splat      v9, s2
    vf.add       v15, v12, v11
    v.movi       v11, #0
    v.extract    s2, v7, #5
    v.cmp.ne     p3, v13, v14
    v.splat      v12, s1
    v.movi       v13, #0
    v.cmp.ne     p4, v10, v8
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v11
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v13
    vf.max.prop  v8, v15, v2
    v.splat      v9, s2
    v.movi       v10, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #5
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v6], v8
    a.vread      v6, a0, s1
    v.extract    s1, v0, #5
    v.extract    s2, v5, #5
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #5
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #5
    p.and        p2, p3, p1
    v.extract    s2, v5, #5
    vf.add       v9, v8, v1
    v.splat      v8, s1
    v.movi       v10, #0
    v.splat      v11, s2
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s13, #0]
    v.extract    s1, v7, #5
    v.cmp.ne     p2, v8, v10
    v.cmp.ne     p3, v11, v13
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #5
    v.extract    s2, v5, #5
    v.cmp.ne     p2, v8, v10
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v8, v10
    p.and        p4, p3, p1
    vf.sub       v8, v6, v14
    v.splat      v6, s2
    v.movi       v10, #0
    v.extract    s1, v7, #5
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v10, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    p.and        p3, p5, p2
    s.movz       s1, #5
    vf.fms       v13, v9, v10, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #5504
    v.extract    s3, v0, #5
    vf.mul       v9, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s15, #0]
    a.vread      v11, a5, s1
    v.extract    s1, v5, #5
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v12
    v.splat      v9, s3
    vf.mul       v12, v8, v13
    v.movi       v8, #0
    v.splat      v13, s1
    v.movi       v14, #0
    vf.mul       v15, v12, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v0, #6
    v.extract    s2, v5, #6
    vf.add       v12, v15, v10
    v.splat      v10, s1
    v.extract    s1, v7, #5
    v.cmp.ne     p2, v9, v8
    v.movi       v8, #0
    v.splat      v9, s2
    vf.add       v15, v12, v11
    v.movi       v11, #0
    v.extract    s2, v7, #6
    v.cmp.ne     p3, v13, v14
    v.splat      v12, s1
    v.movi       v13, #0
    v.cmp.ne     p4, v10, v8
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v11
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v13
    vf.max.prop  v8, v15, v2
    v.splat      v9, s2
    v.movi       v10, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #6
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v6], v8
    a.vread      v6, a0, s1
    v.extract    s1, v0, #6
    v.extract    s2, v5, #6
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #6
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #6
    p.and        p2, p3, p1
    v.extract    s2, v5, #6
    vf.add       v9, v8, v1
    v.splat      v8, s1
    v.movi       v10, #0
    v.splat      v11, s2
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s13, #0]
    v.extract    s1, v7, #6
    v.cmp.ne     p2, v8, v10
    v.cmp.ne     p3, v11, v13
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #6
    v.extract    s2, v5, #6
    v.cmp.ne     p2, v8, v10
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v8, v10
    p.and        p4, p3, p1
    vf.sub       v8, v6, v14
    v.splat      v6, s2
    v.movi       v10, #0
    v.extract    s1, v7, #6
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v10, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    p.and        p3, p5, p2
    s.movz       s1, #6
    vf.fms       v13, v9, v10, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #5568
    v.extract    s3, v0, #6
    vf.mul       v9, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s15, #0]
    a.vread      v11, a5, s1
    v.extract    s1, v5, #6
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v12
    v.splat      v9, s3
    vf.mul       v12, v8, v13
    v.movi       v8, #0
    v.splat      v13, s1
    v.movi       v14, #0
    vf.mul       v15, v12, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v0, #7
    v.extract    s2, v5, #7
    vf.add       v12, v15, v10
    v.splat      v10, s1
    v.extract    s1, v7, #6
    v.cmp.ne     p2, v9, v8
    v.movi       v8, #0
    v.splat      v9, s2
    vf.add       v15, v12, v11
    v.movi       v11, #0
    v.extract    s2, v7, #7
    v.cmp.ne     p3, v13, v14
    v.splat      v12, s1
    v.movi       v13, #0
    v.cmp.ne     p4, v10, v8
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v11
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v13
    vf.max.prop  v8, v15, v2
    v.splat      v9, s2
    v.movi       v10, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #7
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v6], v8
    a.vread      v6, a0, s1
    v.extract    s1, v0, #7
    v.extract    s2, v5, #7
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #7
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #7
    p.and        p2, p3, p1
    v.extract    s2, v5, #7
    vf.add       v9, v8, v1
    v.splat      v8, s1
    v.movi       v10, #0
    v.splat      v11, s2
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s13, #0]
    v.extract    s1, v7, #7
    v.cmp.ne     p2, v8, v10
    v.cmp.ne     p3, v11, v13
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #7
    v.extract    s2, v5, #7
    v.cmp.ne     p2, v8, v10
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v8, v10
    p.and        p4, p3, p1
    vf.sub       v8, v6, v14
    v.splat      v6, s2
    v.movi       v10, #0
    v.extract    s1, v7, #7
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v10, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    p.and        p3, p5, p2
    s.movz       s1, #7
    vf.fms       v13, v9, v10, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #5632
    v.extract    s3, v0, #7
    vf.mul       v9, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s15, #0]
    a.vread      v11, a5, s1
    v.extract    s1, v5, #7
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v12
    v.splat      v9, s3
    vf.mul       v12, v8, v13
    v.movi       v8, #0
    v.splat      v13, s1
    v.movi       v14, #0
    vf.mul       v15, v12, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v0, #8
    v.extract    s2, v5, #8
    vf.add       v12, v15, v10
    v.splat      v10, s1
    v.extract    s1, v7, #7
    v.cmp.ne     p2, v9, v8
    v.movi       v8, #0
    v.splat      v9, s2
    vf.add       v15, v12, v11
    v.movi       v11, #0
    v.extract    s2, v7, #8
    v.cmp.ne     p3, v13, v14
    v.splat      v12, s1
    v.movi       v13, #0
    v.cmp.ne     p4, v10, v8
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v11
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v13
    vf.max.prop  v8, v15, v2
    v.splat      v9, s2
    v.movi       v10, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #8
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v6], v8
    a.vread      v6, a0, s1
    v.extract    s1, v0, #8
    v.extract    s2, v5, #8
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #8
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #8
    p.and        p2, p3, p1
    v.extract    s2, v5, #8
    vf.add       v9, v8, v1
    v.splat      v8, s1
    v.movi       v10, #0
    v.splat      v11, s2
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s13, #0]
    v.extract    s1, v7, #8
    v.cmp.ne     p2, v8, v10
    v.cmp.ne     p3, v11, v13
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #8
    v.extract    s2, v5, #8
    v.cmp.ne     p2, v8, v10
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v8, v10
    p.and        p4, p3, p1
    vf.sub       v8, v6, v14
    v.splat      v6, s2
    v.movi       v10, #0
    v.extract    s1, v7, #8
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v10, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    p.and        p3, p5, p2
    s.movz       s1, #8
    vf.fms       v13, v9, v10, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #5696
    v.extract    s3, v0, #8
    vf.mul       v9, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s15, #0]
    a.vread      v11, a5, s1
    v.extract    s1, v5, #8
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v12
    v.splat      v9, s3
    vf.mul       v12, v8, v13
    v.movi       v8, #0
    v.splat      v13, s1
    v.movi       v14, #0
    vf.mul       v15, v12, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v0, #9
    v.extract    s2, v5, #9
    vf.add       v12, v15, v10
    v.splat      v10, s1
    v.extract    s1, v7, #8
    v.cmp.ne     p2, v9, v8
    v.movi       v8, #0
    v.splat      v9, s2
    vf.add       v15, v12, v11
    v.movi       v11, #0
    v.extract    s2, v7, #9
    v.cmp.ne     p3, v13, v14
    v.splat      v12, s1
    v.movi       v13, #0
    v.cmp.ne     p4, v10, v8
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v11
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v13
    vf.max.prop  v8, v15, v2
    v.splat      v9, s2
    v.movi       v10, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #9
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v6], v8
    a.vread      v6, a0, s1
    v.extract    s1, v0, #9
    v.extract    s2, v5, #9
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #9
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #9
    p.and        p2, p3, p1
    v.extract    s2, v5, #9
    vf.add       v9, v8, v1
    v.splat      v8, s1
    v.movi       v10, #0
    v.splat      v11, s2
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s13, #0]
    v.extract    s1, v7, #9
    v.cmp.ne     p2, v8, v10
    v.cmp.ne     p3, v11, v13
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #9
    v.extract    s2, v5, #9
    v.cmp.ne     p2, v8, v10
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v8, v10
    p.and        p4, p3, p1
    vf.sub       v8, v6, v14
    v.splat      v6, s2
    v.movi       v10, #0
    v.extract    s1, v7, #9
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v10, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    p.and        p3, p5, p2
    s.movz       s1, #9
    vf.fms       v13, v9, v10, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #5760
    v.extract    s3, v0, #9
    vf.mul       v9, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s15, #0]
    a.vread      v11, a5, s1
    v.extract    s1, v5, #9
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v12
    v.splat      v9, s3
    vf.mul       v12, v8, v13
    v.movi       v8, #0
    v.splat      v13, s1
    v.movi       v14, #0
    vf.mul       v15, v12, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v0, #10
    v.extract    s2, v5, #10
    vf.add       v12, v15, v10
    v.splat      v10, s1
    v.extract    s1, v7, #9
    v.cmp.ne     p2, v9, v8
    v.movi       v8, #0
    v.splat      v9, s2
    vf.add       v15, v12, v11
    v.movi       v11, #0
    v.extract    s2, v7, #10
    v.cmp.ne     p3, v13, v14
    v.splat      v12, s1
    v.movi       v13, #0
    v.cmp.ne     p4, v10, v8
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v11
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v13
    vf.max.prop  v8, v15, v2
    v.splat      v9, s2
    v.movi       v10, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #10
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v6], v8
    a.vread      v6, a0, s1
    v.extract    s1, v0, #10
    v.extract    s2, v5, #10
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #10
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #10
    p.and        p2, p3, p1
    v.extract    s2, v5, #10
    vf.add       v9, v8, v1
    v.splat      v8, s1
    v.movi       v10, #0
    v.splat      v11, s2
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s13, #0]
    v.extract    s1, v7, #10
    v.cmp.ne     p2, v8, v10
    v.cmp.ne     p3, v11, v13
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #10
    v.extract    s2, v5, #10
    v.cmp.ne     p2, v8, v10
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v8, v10
    p.and        p4, p3, p1
    vf.sub       v8, v6, v14
    v.splat      v6, s2
    v.movi       v10, #0
    v.extract    s1, v7, #10
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v10, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    p.and        p3, p5, p2
    s.movz       s1, #10
    vf.fms       v13, v9, v10, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #5824
    v.extract    s3, v0, #10
    vf.mul       v9, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s15, #0]
    a.vread      v11, a5, s1
    v.extract    s1, v5, #10
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v12
    v.splat      v9, s3
    vf.mul       v12, v8, v13
    v.movi       v8, #0
    v.splat      v13, s1
    v.movi       v14, #0
    vf.mul       v15, v12, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v0, #11
    v.extract    s2, v5, #11
    vf.add       v12, v15, v10
    v.splat      v10, s1
    v.extract    s1, v7, #10
    v.cmp.ne     p2, v9, v8
    v.movi       v8, #0
    v.splat      v9, s2
    vf.add       v15, v12, v11
    v.movi       v11, #0
    v.extract    s2, v7, #11
    v.cmp.ne     p3, v13, v14
    v.splat      v12, s1
    v.movi       v13, #0
    v.cmp.ne     p4, v10, v8
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v11
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v13
    vf.max.prop  v8, v15, v2
    v.splat      v9, s2
    v.movi       v10, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #11
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v6], v8
    a.vread      v6, a0, s1
    v.extract    s1, v0, #11
    v.extract    s2, v5, #11
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #11
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #11
    p.and        p2, p3, p1
    v.extract    s2, v5, #11
    vf.add       v9, v8, v1
    v.splat      v8, s1
    v.movi       v10, #0
    v.splat      v11, s2
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s13, #0]
    v.extract    s1, v7, #11
    v.cmp.ne     p2, v8, v10
    v.cmp.ne     p3, v11, v13
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #11
    v.extract    s2, v5, #11
    v.cmp.ne     p2, v8, v10
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v8, v10
    p.and        p4, p3, p1
    vf.sub       v8, v6, v14
    v.splat      v6, s2
    v.movi       v10, #0
    v.extract    s1, v7, #11
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v10, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    p.and        p3, p5, p2
    s.movz       s1, #11
    vf.fms       v13, v9, v10, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #5888
    v.extract    s3, v0, #11
    vf.mul       v9, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s15, #0]
    a.vread      v11, a5, s1
    v.extract    s1, v5, #11
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v12
    v.splat      v9, s3
    vf.mul       v12, v8, v13
    v.movi       v8, #0
    v.splat      v13, s1
    v.movi       v14, #0
    vf.mul       v15, v12, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v0, #12
    v.extract    s2, v5, #12
    vf.add       v12, v15, v10
    v.splat      v10, s1
    v.extract    s1, v7, #11
    v.cmp.ne     p2, v9, v8
    v.movi       v8, #0
    v.splat      v9, s2
    vf.add       v15, v12, v11
    v.movi       v11, #0
    v.extract    s2, v7, #12
    v.cmp.ne     p3, v13, v14
    v.splat      v12, s1
    v.movi       v13, #0
    v.cmp.ne     p4, v10, v8
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v11
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v13
    vf.max.prop  v8, v15, v2
    v.splat      v9, s2
    v.movi       v10, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #12
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v6], v8
    a.vread      v6, a0, s1
    v.extract    s1, v0, #12
    v.extract    s2, v5, #12
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #12
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #12
    p.and        p2, p3, p1
    v.extract    s2, v5, #12
    vf.add       v9, v8, v1
    v.splat      v8, s1
    v.movi       v10, #0
    v.splat      v11, s2
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s13, #0]
    v.extract    s1, v7, #12
    v.cmp.ne     p2, v8, v10
    v.cmp.ne     p3, v11, v13
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #12
    v.extract    s2, v5, #12
    v.cmp.ne     p2, v8, v10
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v8, v10
    p.and        p4, p3, p1
    vf.sub       v8, v6, v14
    v.splat      v6, s2
    v.movi       v10, #0
    v.extract    s1, v7, #12
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v10, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    p.and        p3, p5, p2
    s.movz       s1, #12
    vf.fms       v13, v9, v10, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #5952
    v.extract    s3, v0, #12
    vf.mul       v9, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s15, #0]
    a.vread      v11, a5, s1
    v.extract    s1, v5, #12
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v12
    v.splat      v9, s3
    vf.mul       v12, v8, v13
    v.movi       v8, #0
    v.splat      v13, s1
    v.movi       v14, #0
    vf.mul       v15, v12, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v0, #13
    v.extract    s2, v5, #13
    vf.add       v12, v15, v10
    v.splat      v10, s1
    v.extract    s1, v7, #12
    v.cmp.ne     p2, v9, v8
    v.movi       v8, #0
    v.splat      v9, s2
    vf.add       v15, v12, v11
    v.movi       v11, #0
    v.extract    s2, v7, #13
    v.cmp.ne     p3, v13, v14
    v.splat      v12, s1
    v.movi       v13, #0
    v.cmp.ne     p4, v10, v8
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v11
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v13
    vf.max.prop  v8, v15, v2
    v.splat      v9, s2
    v.movi       v10, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #13
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v6], v8
    a.vread      v6, a0, s1
    v.extract    s1, v0, #13
    v.extract    s2, v5, #13
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #13
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #13
    p.and        p2, p3, p1
    v.extract    s2, v5, #13
    vf.add       v9, v8, v1
    v.splat      v8, s1
    v.movi       v10, #0
    v.splat      v11, s2
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s13, #0]
    v.extract    s1, v7, #13
    v.cmp.ne     p2, v8, v10
    v.cmp.ne     p3, v11, v13
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #13
    v.extract    s2, v5, #13
    v.cmp.ne     p2, v8, v10
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v8, v10
    p.and        p4, p3, p1
    vf.sub       v8, v6, v14
    v.splat      v6, s2
    v.movi       v10, #0
    v.extract    s1, v7, #13
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v10, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    p.and        p3, p5, p2
    s.movz       s1, #13
    vf.fms       v13, v9, v10, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #6016
    v.extract    s3, v0, #13
    vf.mul       v9, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s15, #0]
    a.vread      v11, a5, s1
    v.extract    s1, v5, #13
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v12
    v.splat      v9, s3
    vf.mul       v12, v8, v13
    v.movi       v8, #0
    v.splat      v13, s1
    v.movi       v14, #0
    vf.mul       v15, v12, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v0, #14
    v.extract    s2, v5, #14
    vf.add       v12, v15, v10
    v.splat      v10, s1
    v.extract    s1, v7, #13
    v.cmp.ne     p2, v9, v8
    v.movi       v8, #0
    v.splat      v9, s2
    vf.add       v15, v12, v11
    v.movi       v11, #0
    v.extract    s2, v7, #14
    v.cmp.ne     p3, v13, v14
    v.splat      v12, s1
    v.movi       v13, #0
    v.cmp.ne     p4, v10, v8
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v11
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v13
    vf.max.prop  v8, v15, v2
    v.splat      v9, s2
    v.movi       v10, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #14
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v6], v8
    a.vread      v6, a0, s1
    v.extract    s1, v0, #14
    v.extract    s2, v5, #14
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #14
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #14
    p.and        p2, p3, p1
    v.extract    s2, v5, #14
    vf.add       v9, v8, v1
    v.splat      v8, s1
    v.movi       v10, #0
    v.splat      v11, s2
    v.rsqrt.approx v12, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v13, #0
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v14, [s13, #0]
    v.extract    s1, v7, #14
    v.cmp.ne     p2, v8, v10
    v.cmp.ne     p3, v11, v13
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #14
    v.extract    s2, v5, #14
    v.cmp.ne     p2, v8, v10
    v.splat      v8, s1
    v.movi       v10, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v8, v10
    p.and        p4, p3, p1
    vf.sub       v8, v6, v14
    v.splat      v6, s2
    v.movi       v10, #0
    v.extract    s1, v7, #14
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s1
    v.movi       v10, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v10, v12, v12
    vf.mul       v11, v12, v4
    p.and        p3, p5, p2
    s.movz       s1, #14
    vf.fms       v13, v9, v10, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #6080
    v.extract    s3, v0, #14
    vf.mul       v9, v11, v13                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s15, #0]
    a.vread      v11, a5, s1
    v.extract    s1, v5, #14
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v13, v9, v12
    v.splat      v9, s3
    vf.mul       v12, v8, v13
    v.movi       v8, #0
    v.splat      v13, s1
    v.movi       v14, #0
    vf.mul       v15, v12, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v0, #15
    v.extract    s2, v5, #15
    vf.add       v12, v15, v10
    v.splat      v10, s1
    v.extract    s1, v7, #14
    v.cmp.ne     p2, v9, v8
    v.movi       v8, #0
    v.splat      v9, s2
    vf.add       v15, v12, v11
    v.movi       v11, #0
    v.extract    s2, v7, #15
    v.cmp.ne     p3, v13, v14
    v.splat      v12, s1
    v.movi       v13, #0
    v.cmp.ne     p4, v10, v8
    p.and        p5, p2, p3
    v.cmp.ne     p2, v9, v11
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v13
    vf.max.prop  v8, v15, v2
    v.splat      v9, s2
    v.movi       v10, #0
    p.and        p4, p5, p2
    v.cmp.ne     p2, v9, v10
    p.and        p5, p3, p2
    p.and        p2, p4, p1
    s.movz       s1, #15
    p.and        p3, p5, p1
    @p2 v.st.scatter.w [s32, v6], v8
    a.vread      v6, a0, s1
    v.extract    s1, v0, #15
    v.extract    s2, v5, #15
    v.splat      v8, s1
    v.movi       v9, #0
    v.splat      v10, s2
    v.movi       v11, #0
    v.extract    s1, v7, #15
    v.cmp.ne     p2, v8, v9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s11, #0]
    v.cmp.ne     p3, v10, v11
    v.splat      v9, s1
    v.movi       v10, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v9, v10
    p.and        p3, p4, p2
    v.extract    s1, v0, #15
    p.and        p2, p3, p1
    v.extract    s2, v5, #15
    vf.add       v9, v8, v1
    v.splat      v1, s1
    v.movi       v8, #0
    v.splat      v10, s2
    v.rsqrt.approx v11, v9                       // ISA 8.8: <= 2**-22 relative
    v.movi       v12, #0
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v13, [s13, #0]
    v.extract    s1, v7, #15
    v.cmp.ne     p2, v1, v8
    v.cmp.ne     p3, v10, v12
    v.splat      v1, s1
    v.movi       v8, #0
    p.and        p4, p2, p3
    v.extract    s1, v0, #15
    v.extract    s2, v5, #15
    v.cmp.ne     p2, v1, v8
    v.splat      v1, s1
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v1, v8
    p.and        p4, p3, p1
    vf.sub       v1, v6, v13
    v.splat      v6, s2
    v.movi       v8, #0
    v.extract    s1, v7, #15
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s1
    v.movi       v8, #0
    p.and        p5, p2, p3
    v.cmp.ne     p2, v6, v8
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.mul       v8, v11, v11
    vf.mul       v10, v11, v4
    p.and        p3, p5, p2
    s.movz       s1, #15
    vf.fms       v4, v9, v8, v3
    p.and        p2, p3, p1
    s.addi       s2, s4, #6144
    v.extract    s3, v0, #15
    vf.mul       v0, v10, v4                     // Newton step: 0.5*r0*(3 - x*r0^2)
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s15, #0]
    a.vread      v4, a5, s1
    v.extract    s1, v5, #15
    vf.cmp.o     p2, v0, v0
    @p2 v.sel        v5, v0, v11
    v.splat      v0, s3
    vf.mul       v8, v1, v5
    v.movi       v1, #0
    v.splat      v5, s1
    v.movi       v9, #0
    vf.mul       v10, v8, v6
    v.ld.w       v6, [s2, #0]
    v.extract    s1, v7, #15
    v.cmp.ne     p2, v0, v1
    vf.add       v0, v10, v3
    v.cmp.ne     p3, v5, v9
    v.splat      v1, s1
    v.movi       v3, #0
    vf.add       v5, v0, v4
    p.and        p4, p2, p3
    v.cmp.ne     p2, v1, v3
    p.and        p3, p4, p2
    vf.max.prop  v0, v5, v2
    p.and        p2, p3, p1
    @p2 v.st.scatter.w [s32, v6], v0
__rctx_next:
    exit
