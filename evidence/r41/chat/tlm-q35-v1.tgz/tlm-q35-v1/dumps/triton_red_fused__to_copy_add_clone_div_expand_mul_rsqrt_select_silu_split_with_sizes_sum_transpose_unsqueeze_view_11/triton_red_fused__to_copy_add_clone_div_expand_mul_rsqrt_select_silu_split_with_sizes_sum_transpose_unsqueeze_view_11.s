    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s8, #256
    s.mul        s9, s1, s8
    s.add        s1, s7, s9                      // this context's own scratch
    s.addi       s7, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s7, #0], s3
    s.movz       s1, #16
    s.st.d       [s7, #8], s1
    s.movz       s1, #128
    s.st.d       [s7, #16], s1
    s.movz       s1, #256
    s.st.d       [s7, #48], s1
    s.movz       s1, #2
    s.st.d       [s7, #56], s1
    .li       s1, #68719476737
    s.st.d       [s7, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s7, #104], s1
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #1
    s.movz       s7, #0
    s.movz       s8, #128
    s.movz       s9, #16
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #128
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v0
    @p1 v.sel        v5, v4, v0
    v.sub        v4, v3, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v4, #127
    v.and        v6, v5, v4
    v.sub        v4, v3, v6
    @p1 v.sel        v3, v4, v6
    v.movi       v4, #0
    v.movi       v5, #1
    v.cmp.lt     p1, v0, v4
    v.cmp.lt     p2, v2, v4
    v.sub        v5, v4, v0
    @p1 v.sel        v6, v5, v0
    v.sub        v0, v4, v2
    @p2 v.sel        v5, v0, v2
    v.movi       v0, #7
    v.lshr       v2, v6, v0
    v.sub        v0, v4, v2
    @p1 v.sel        v4, v0, v2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s1
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s5, v4]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s7, #0
    v.movi       v2, #0
    v.movi       v5, #0
    v.mov        v5, v2
for_1:
    s.cmp.ge     s5, s1, s8
    br.nz        s5, endfor_2
    s.movz       s5, #0
    s.movz       s7, #0
    s.cmp.lt     s10, s4, s5
    s.movz       s5, #256
    s.sub        s11, s7, s10
    s.movz       s7, #0
    s.movz       s10, #0
    s.cmp.lt     s12, s5, s7
    s.xor        s7, s4, s11
    s.sub        s13, s10, s12
    s.sub        s10, s7, s11
    s.xor        s7, s11, s13
    s.lshri      s11, s10, #8
    v.splat      v2, s1
    s.xor        s12, s11, s7
    v.iota       v6                              // arange(0, VLEN)
    s.sub        s14, s12, s7
    s.movz       s7, #128
    s.muli       s12, s14, #256
    v.add        v7, v2, v6
    v.movi       v2, #0
    v.splat      v6, s7
    v.splat      v8, s14
    s.muli       s7, s1, #2
    v.cmp.ge     p1, v7, v2
    v.cmp.lt     p2, v7, v6
    v.splat      v2, s1
    v.movi       v6, #0
    s.add        s14, s3, s12
    p.and        p3, p1, p2
    v.movi       v7, #16384
    s.add        s12, s14, s7
    v.add        v9, v2, v1
    v.cmp.ge     p1, v8, v6
    v.movi       v2, #128
    s.movz       s7, #16
    v.extract    s14, v3, #0
    v.mul        v6, v4, v7
    v.mul        v7, v9, v2
    v.splat      v10, s14
    v.extract    s14, v6, #0
    v.cmp.lt     p2, v9, v2
    v.splat      v2, s7
    v.add        v6, v10, v7
    v.splat      v7, s14
    v.cmp.lt     p4, v8, v2
    p.and        p5, p1, p4
    v.add        v2, v6, v7
    p.and        p1, p3, p5
    s.muli       s7, s11, #256
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s12, #0]
    s.xor        s11, s5, s13
    s.movz       s5, #16384
    .li       s5, #897988541
    v.splat      v7, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s5, #1077936128
    v.splat      v8, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.sub        s5, s11, s13
    vf.add       v9, v0, v7
    s.sub        s5, s10, s7
    v.rsqrt.approx v7, v9                        // ISA 8.8: <= 2**-22 relative
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v10, [s2, v2]              // index is in elements (ISA sec 9.1)
    .li       s5, #3204448256
    v.splat      v2, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.bf16.f32 v11, v6
    .li       s5, #1035273459
    v.splat      v6, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v12, #0
    s.add        s5, s1, s9
    s.movz       s7, #1
    vf.mul       v13, v7, v7
    vf.mul       v14, v7, v2
    vf.fms       v2, v9, v13, v8
    vf.mul       v8, v14, v2                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v2, v8, v7
    v.extract    s10, v2, #0
    v.splat      v2, s10
    vf.mul       v7, v11, v2
    vf.mul       v2, v7, v6
    vf.mul       v6, v10, v2
    vf.add       v2, v5, v6
    @p2 v.sel        v6, v2, v5
    v.mov        v12, v6
    v.mov        v5, v12
    s.mov        s1, s5
    br.nz        s7, for_1
endfor_2:
    vf.reduce.add.b v0, v5
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s6, s2                      // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
