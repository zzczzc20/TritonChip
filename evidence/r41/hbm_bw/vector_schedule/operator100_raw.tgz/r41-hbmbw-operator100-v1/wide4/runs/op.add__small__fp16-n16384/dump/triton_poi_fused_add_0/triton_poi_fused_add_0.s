    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #32
    s.movz       s6, #48
    s.shli       s7, s4, #6                      // x64 as a shift
    v.iota       v0                              // arange(0, VLEN)
    s.add        s4, s2, s7
    s.add        s2, s5, s7
    s.add        s5, s6, s7
    s.shli       s6, s7, #1                      // element offset -> bytes (x2)
    s.shli       s8, s4, #1                      // element offset -> bytes (x2)
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.shli       s9, s5, #1                      // element offset -> bytes (x2)
    s.add        s5, s3, s6                      // &in_ptr0[...]
    s.add        s10, s3, s8                     // &in_ptr0[...]
    s.add        s11, s3, s4                     // &in_ptr0[...]
    s.add        s12, s3, s9                     // &in_ptr0[...]
    v.movi       v1, #16
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #32
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #48
    s.add        s3, s2, s6                      // &in_ptr1[...]
    v.ld.h       v6, [s5, #0]
    s.add        s5, s2, s8                      // &in_ptr1[...]
    v.iota       v7                              // arange(0, VLEN)
    v.add        v8, v0, v1
    v.add        v0, v2, v3
    v.add        v1, v4, v5
    v.splat      v2, s7
    v.splat      v3, s7
    v.splat      v4, s7
    v.splat      v5, s7
    s.add        s7, s2, s4                      // &in_ptr1[...]
    v.add        v9, v2, v7
    v.add        v2, v3, v8
    v.add        v2, v4, v0
    v.ld.h       v0, [s10, #0]
    vf.cvt.f16.f32 v2, v6
    v.add        v3, v5, v1
    v.ld.h       v1, [s11, #0]
    vf.cvt.f16.f32 v3, v0
    v.ld.h       v0, [s12, #0]
    vf.cvt.f16.f32 v4, v1
    v.ld.h       v1, [s3, #0]
    vf.cvt.f16.f32 v5, v0
    v.ld.h       v0, [s5, #0]
    v.ld.h       v6, [s7, #0]
    s.ld.d       s3, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.add        s1, s2, s9                      // &in_ptr1[...]
    vf.cvt.f16.f32 v7, v1
    vf.cvt.f16.f32 v1, v0
    vf.cvt.f16.f32 v0, v6
    vf.add       v6, v2, v7
    vf.add       v2, v3, v1
    vf.add       v1, v4, v0
    v.ld.h       v0, [s1, #0]
    vf.cvt.f32.f16 v3, v6
    vf.cvt.f32.f16 v4, v2
    vf.cvt.f32.f16 v2, v1
    s.add        s1, s3, s6                      // &out_ptr0[...]
    s.add        s2, s3, s8                      // &out_ptr0[...]
    s.add        s5, s3, s4                      // &out_ptr0[...]
    s.add        s4, s3, s9                      // &out_ptr0[...]
    vf.cvt.f16.f32 v1, v0
    v.st.h       [s1, #0], v3
    vf.add       v0, v5, v1
    vf.cvt.f32.f16 v1, v0
    v.st.h       [s2, #0], v4
    v.st.h       [s5, #0], v2
    v.st.h       [s4, #0], v1
__rctx_next:
    exit
