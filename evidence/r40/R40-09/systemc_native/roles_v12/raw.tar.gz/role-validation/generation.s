
        .li s1, #70000
loop:
        mb.arm s2, b0, #0, #0
        mb.wait s2
        s.subi s1, s1, #1
        br.nz s1, loop
        .li s3, #0x50000
        s.st.d [s3, #0], s2
        exit
    