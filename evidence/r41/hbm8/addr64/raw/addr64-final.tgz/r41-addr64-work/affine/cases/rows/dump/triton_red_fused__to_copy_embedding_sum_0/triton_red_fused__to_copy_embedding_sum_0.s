    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #8
    s.rdspecial  s2, arg_base
    s.movz       s3, #0
    s.ld.d       s5, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s6, #0
    s.movz       s7, #32
    s.movz       s8, #1
    s.movz       s9, #1
    s.movz       s10, #1
    s.movz       s11, #1
    s.movz       s12, #1
    s.movz       s13, #1
    s.movz       s14, #1
    s.movz       s15, #1
    s.addi       s16, s5, #4
    s.addi       s17, s5, #4
    s.addi       s18, s5, #4
    s.addi       s19, s5, #4
    s.addi       s20, s5, #4
    s.addi       s21, s5, #4
    s.addi       s22, s5, #4
    s.addi       s23, s5, #4
    s.movz       s24, #0
    s.movz       s25, #0
    s.movz       s26, #0
    s.movz       s27, #0
    s.movz       s28, #0
    s.movz       s29, #0
    s.movz       s30, #0
    s.movz       s31, #0
    s.movz       s32, #64
    s.movz       s33, #64
    s.movz       s34, #64
    s.ld.d       s35, [s2, #8]                   // in_ptr1: device_ptr64 at arg_base+8
    s.mul        s36, s4, s1
    s.movz       s4, #64
    s.movz       s37, #64
    s.movz       s38, #64
    s.movz       s39, #64
    .li       s40, #-1
    s.movz       s41, #64
    s.movz       s42, #1
    s.movz       s43, #1
    s.movz       s44, #1
    s.ld.d       s45, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.add        s2, s3, s36                     // the tile origin
    s.add        s3, s6, s36                     // the tile origin
    s.addi       s6, s2, #1
    s.addi       s46, s3, #1
    s.addi       s47, s2, #2
    s.addi       s48, s3, #2
    v.splat      v0, s2
    v.splat      v1, s3
    v.splat      v2, s7
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s8
    v.movi       v5, #1
    v.splat      v6, s6
    v.splat      v7, s46
    v.iota       v8                              // arange(0, VLEN)
    v.splat      v9, s9
    v.movi       v10, #1
    v.splat      v11, s47
    v.splat      v12, s48
    v.iota       v13                             // arange(0, VLEN)
    v.splat      v14, s10
    v.movi       v15, #1
    v.cmp.lt     p1, v1, v2
    v.cmp.lt     p2, v3, v4
    v.shl        v1, v0, v5
    v.cmp.lt     p3, v7, v2
    v.cmp.lt     p4, v8, v9
    v.shl        v0, v6, v10
    v.cmp.lt     p5, v12, v2
    v.cmp.lt     p6, v13, v14
    v.shl        v3, v11, v15
    p.and        p7, p2, p1
    p.and        p1, p4, p3
    p.and        p2, p6, p5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.gather.w v4, [s16, v1]              // index is in elements (ISA sec 9.1)
    s.movz       s6, #1
    s.addi       s7, s2, #3
    s.movz       s8, #1
    v.splat      v5, s7
    s.movz       s7, #1
    s.addi       s9, s3, #3
    s.movz       s10, #1
    v.splat      v6, s9
    s.movz       s9, #1
    s.movz       s16, #0
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v8, s11
    v.cmp.lt     p3, v6, v2
    v.iota       v6                              // arange(0, VLEN)
    s.addi       s11, s2, #4
    s.addi       s46, s3, #4
    v.movi       v6, #1
    v.splat      v9, s11
    v.splat      v10, s46
    v.iota       v11                             // arange(0, VLEN)
    v.splat      v12, s12
    v.cmp.lt     p4, v7, v8
    v.shl        v7, v5, v6
    v.cmp.lt     p5, v10, v2
    p.and        p6, p4, p3
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v6, [s18, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p6 v.ld.gather.w v8, [s19, v7]              // index is in elements (ISA sec 9.1)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p7 v.ld.gather.w v10, [s5, v1]              // index is in elements (ISA sec 9.1)
    s.addi       s11, s2, #5
    s.addi       s12, s3, #5
    v.movi       v1, #1
    v.splat      v13, s11
    v.splat      v14, s12
    v.iota       v15                             // arange(0, VLEN)
    v.splat      v16, s13
    v.cmp.lt     p3, v11, v12
    v.shl        v11, v9, v1
    v.cmp.lt     p4, v14, v2
    p.and        p7, p3, p5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p7 v.ld.gather.w v1, [s20, v11]             // index is in elements (ISA sec 9.1)
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v9, [s5, v0]               // index is in elements (ISA sec 9.1)
    s.addi       s11, s2, #6
    s.addi       s12, s3, #6
    v.movi       v0, #1
    v.splat      v12, s11
    v.splat      v14, s12
    v.iota       v17                             // arange(0, VLEN)
    v.splat      v18, s14
    v.cmp.lt     p1, v15, v16
    v.shl        v15, v13, v0
    v.cmp.lt     p3, v14, v2
    p.and        p5, p1, p4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v0, [s21, v15]             // index is in elements (ISA sec 9.1)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v13, [s5, v3]              // index is in elements (ISA sec 9.1)
    s.addi       s11, s2, #7
    s.addi       s2, s3, #7
    v.movi       v3, #1
    v.splat      v14, s11
    v.splat      v16, s2
    v.iota       v19                             // arange(0, VLEN)
    v.splat      v20, s15
    v.cmp.lt     p1, v17, v18
    v.shl        v17, v12, v3
    v.cmp.lt     p2, v16, v2
    p.and        p4, p1, p3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s22, v17]             // index is in elements (ISA sec 9.1)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p6 v.ld.gather.w v12, [s5, v7]              // index is in elements (ISA sec 9.1)
    v.movi       v7, #1
    v.cmp.lt     p1, v19, v20
    p.and        p3, p1, p2
    v.shl        v16, v14, v7
    v.extract    s2, v4, #0
    v.extract    s11, v10, #0
    s.shli       s12, s2, #32
    v.movi       v7, #0
    s.or         s2, s11, s12
    s.cmp.ge     s11, s2, s24
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v14, [s23, v16]            // index is in elements (ISA sec 9.1)
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p7 v.ld.gather.w v18, [s5, v11]             // index is in elements (ISA sec 9.1)
    v.extract    s2, v5, #0
    v.extract    s12, v9, #0
    s.shli       s13, s2, #32
    v.movi       v11, #0
    v.movi       v19, #0
    v.movi       v20, #1
    v.movi       v21, #0
    v.movi       v22, #0
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v23, [s5, v15]             // index is in elements (ISA sec 9.1)
    s.or         s2, s12, s13
    v.movi       v15, #0
    s.cmp.ge     s12, s2, s25
    v.movi       v24, #0
    v.movi       v25, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v25, [s5, v17]             // index is in elements (ISA sec 9.1)
    v.extract    s2, v6, #0
    v.extract    s13, v13, #0
    s.shli       s14, s2, #32
    s.or         s2, s13, s14
    s.cmp.ge     s13, s2, s26
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v17, [s5, v16]             // index is in elements (ISA sec 9.1)
    v.extract    s2, v8, #0
    v.extract    s5, v12, #0
    s.shli       s14, s2, #32
    v.insert     v7, s11, #0
    s.or         s2, s5, s14
    v.insert     v11, s12, #0
    s.cmp.ge     s5, s2, s27
    v.insert     v15, s13, #0
    v.cmp.ne     p1, v7, v19
    v.movi       v7, #0
    v.movi       v16, #1
    v.cmp.ne     p2, v11, v24
    v.insert     v7, s5, #0
    v.movi       v11, #0
    v.movi       v19, #0
    @p1 v.sel        v24, v20, v21
    v.movi       v20, #1
    @p2 v.sel        v21, v16, v11
    v.movi       v11, #0
    v.cmp.ne     p1, v15, v19
    v.movi       v15, #0
    v.movi       v16, #1
    @p1 v.sel        v19, v20, v11
    v.movi       v11, #0
    v.extract    s2, v24, #0
    v.extract    s5, v21, #0
    v.cmp.ne     p1, v7, v15
    @p1 v.sel        v7, v16, v11
    v.splat      v11, s2
    v.splat      v15, s5
    v.movi       v16, #0
    v.extract    s2, v19, #0
    v.movi       v19, #0
    v.splat      v20, s2
    v.extract    s2, v7, #0
    v.cmp.ne     p1, v11, v22
    v.extract    s5, v1, #0
    v.extract    s11, v18, #0
    s.shli       s12, s5, #32
    v.movi       v7, #0
    s.or         s5, s11, s12
    v.movi       v11, #0
    s.cmp.ge     s11, s5, s28
    v.movi       v21, #1
    v.insert     v7, s11, #0
    v.movi       v22, #0
    v.cmp.ne     p2, v15, v16
    v.extract    s5, v0, #0
    v.extract    s11, v23, #0
    s.shli       s12, s5, #32
    v.movi       v15, #0
    s.or         s5, s11, s12
    v.movi       v16, #0
    s.cmp.ge     s11, s5, s29
    v.cmp.ne     p3, v7, v11
    v.insert     v15, s11, #0
    v.movi       v7, #1
    v.movi       v11, #0
    @p3 v.sel        v24, v21, v22
    v.cmp.ne     p3, v15, v16
    @p3 v.sel        v15, v7, v11
    v.splat      v7, s2
    v.movi       v11, #0
    v.extract    s2, v24, #0
    v.cmp.ne     p3, v20, v19
    v.extract    s5, v3, #0
    v.extract    s11, v25, #0
    s.shli       s12, s5, #32
    v.movi       v16, #0
    s.or         s5, s11, s12
    v.movi       v19, #0
    s.cmp.ge     s11, s5, s30
    v.movi       v20, #1
    v.insert     v16, s11, #0
    v.movi       v21, #0
    v.splat      v22, s2
    v.cmp.ne     p4, v16, v19
    @p4 v.sel        v16, v20, v21
    v.movi       v19, #0
    v.extract    s2, v15, #0
    v.cmp.ne     p4, v7, v11
    v.extract    s5, v14, #0
    v.extract    s11, v17, #0
    s.shli       s12, s5, #32
    v.movi       v7, #0
    s.or         s5, s11, s12
    v.movi       v11, #0
    s.cmp.ge     s11, s5, s31
    v.movi       v15, #1
    v.insert     v7, s11, #0
    v.movi       v20, #0
    v.splat      v21, s2
    v.cmp.ne     p5, v7, v11
    @p5 v.sel        v7, v15, v20
    v.movi       v11, #0
    v.extract    s2, v16, #0
    v.cmp.ne     p5, v22, v19
    v.extract    s5, v4, #0
    v.extract    s11, v10, #0
    s.shli       s12, s5, #32
    v.movi       v15, #0
    s.or         s5, s11, s12
    v.movi       v16, #0
    s.cmp.lt     s11, s5, s32
    v.movi       v19, #1
    v.insert     v15, s11, #0
    v.movi       v20, #0
    v.movi       v22, #0
    v.cmp.ne     p6, v15, v16
    @p6 v.sel        v15, v19, v20
    v.splat      v16, s2
    v.movi       v19, #0
    v.extract    s2, v15, #0
    v.extract    s5, v7, #0
    v.splat      v7, s2
    v.cmp.ne     p6, v21, v11
    v.extract    s2, v5, #0
    v.extract    s11, v9, #0
    s.shli       s12, s2, #32
    v.movi       v11, #0
    s.or         s2, s11, s12
    v.movi       v15, #0
    s.cmp.lt     s11, s2, s33
    v.movi       v20, #1
    v.insert     v11, s11, #0
    v.movi       v21, #0
    v.cmp.ne     p7, v7, v22
    v.cmp.ne     p8, v11, v15
    @p8 v.sel        v7, v20, v21
    v.movi       v11, #0
    v.splat      v15, s5
    v.extract    s2, v7, #0
    v.movi       v7, #0
    v.splat      v20, s2
    v.cmp.ne     p8, v16, v19
    v.extract    s2, v6, #0
    v.extract    s5, v13, #0
    s.shli       s11, s2, #32
    v.movi       v16, #0
    s.or         s2, s5, s11
    v.movi       v19, #0
    s.cmp.lt     s5, s2, s34
    v.movi       v21, #1
    v.insert     v16, s5, #0
    v.movi       v22, #0
    v.cmp.ne     p9, v20, v11
    v.cmp.ne     p10, v16, v19
    @p10 v.sel        v11, v21, v22
    v.movi       v16, #0
    v.cmp.ne     p10, v15, v7
    v.extract    s2, v8, #0
    v.extract    s5, v12, #0
    s.shli       s11, s2, #32
    v.extract    s2, v1, #0
    s.or         s12, s5, s11
    v.extract    s5, v18, #0
    s.shli       s11, s2, #32
    v.extract    s2, v0, #0
    v.movi       v7, #0
    s.cmp.lt     s13, s12, s4
    s.or         s4, s5, s11
    v.extract    s5, v23, #0
    s.shli       s11, s2, #32
    v.movi       v15, #0
    v.insert     v7, s13, #0
    v.movi       v19, #0
    s.cmp.lt     s2, s4, s37
    s.or         s4, s5, s11
    v.movi       v20, #1
    v.movi       v21, #0
    v.movi       v22, #0
    v.insert     v15, s2, #0
    s.cmp.lt     s2, s4, s38
    v.cmp.ne     p11, v7, v19
    v.movi       v7, #0
    v.movi       v19, #1
    @p11 v.sel        v24, v20, v21
    v.movi       v20, #0
    v.insert     v22, s2, #0
    v.extract    s2, v11, #0
    v.movi       v11, #0
    v.cmp.ne     p11, v15, v7
    v.movi       v7, #1
    v.movi       v15, #0
    @p11 v.sel        v21, v19, v20
    v.splat      v19, s2
    v.extract    s2, v24, #0
    v.cmp.ne     p11, v22, v11
    @p11 v.sel        v11, v7, v15
    v.splat      v7, s2
    v.movi       v15, #0
    v.extract    s2, v21, #0
    v.cmp.ne     p11, v19, v16
    v.extract    s4, v3, #0
    v.extract    s5, v25, #0
    s.shli       s11, s4, #32
    v.movi       v16, #0
    s.or         s4, s5, s11
    v.movi       v19, #0
    s.cmp.lt     s5, s4, s39
    v.movi       v20, #1
    v.insert     v16, s5, #0
    v.movi       v21, #0
    v.splat      v22, s2
    v.cmp.ne     p12, v16, v19
    @p12 v.sel        v16, v20, v21
    v.movi       v19, #0
    v.extract    s2, v11, #0
    v.cmp.ne     p12, v7, v15
    v.extract    s4, v14, #0
    v.extract    s5, v17, #0
    s.shli       s11, s4, #32
    v.movi       v7, #0
    s.or         s4, s5, s11
    v.movi       v11, #0
    s.cmp.lt     s5, s4, s41
    v.movi       v15, #1
    v.insert     v7, s5, #0
    v.movi       v20, #0
    v.splat      v21, s2
    v.cmp.ne     p13, v7, v11
    @p13 v.sel        v7, v15, v20
    v.movi       v11, #0
    v.extract    s2, v16, #0
    v.cmp.ne     p13, v22, v19
    v.splat      v15, s3
    v.splat      v16, s40
    v.movi       v19, #0
    v.cmp.lt     p14, v15, v2
    p.and        p15, p1, p7
    v.cmp.ne     p1, v16, v19
    p.xor        p7, p14, p1
    v.movi       v15, #0
    v.movi       v19, #1
    p.or         p1, p15, p7
    v.iota       v20                             // arange(0, VLEN)
    v.splat      v22, s42
    @p1 v.sel        v24, v15, v19
    v.splat      v15, s2
    v.extract    s2, v7, #0
    v.movi       v7, #0
    v.cmp.lt     p1, v20, v22
    v.cmp.ne     p7, v21, v11
    s.addi       s4, s3, #1
    v.movi       v11, #0
    v.splat      v19, s4
    p.and        p14, p2, p9
    v.cmp.ne     p2, v16, v11
    v.cmp.lt     p9, v19, v2
    p.xor        p15, p9, p2
    v.movi       v11, #0
    v.movi       v19, #1
    p.or         p2, p14, p15
    v.iota       v20                             // arange(0, VLEN)
    v.splat      v21, s43
    @p2 v.sel        v22, v11, v19
    @p1 v.reduce.or  s4, v24
    v.cmp.lt     p1, v20, v21
    @p1 v.reduce.or  s5, v22
    v.splat      v11, s2
    v.movi       v19, #0
    v.cmp.ne     p1, v15, v7
    s.addi       s2, s3, #2
    v.movi       v7, #0
    v.splat      v15, s2
    p.and        p2, p3, p11
    v.cmp.ne     p3, v16, v7
    v.cmp.lt     p9, v15, v2
    p.xor        p11, p9, p3
    v.movi       v7, #0
    v.movi       v15, #1
    p.or         p3, p2, p11
    v.iota       v20                             // arange(0, VLEN)
    v.splat      v21, s44
    @p3 v.sel        v22, v7, v15
    s.or         s2, s4, s5
    v.cmp.lt     p2, v20, v21
    @p2 v.reduce.or  s4, v22
    v.cmp.ne     p2, v11, v19
    s.addi       s5, s3, #3
    v.movi       v7, #0
    v.splat      v11, s5
    s.addi       s5, s3, #4
    v.movi       v15, #0
    v.splat      v19, s5
    s.addi       s5, s3, #5
    v.cmp.lt     p3, v11, v2
    v.cmp.ne     p9, v16, v7
    p.and        p11, p4, p12
    p.xor        p4, p3, p9
    v.splat      v7, s5
    v.movi       v11, #0
    v.movi       v20, #0
    v.movi       v21, #1
    v.cmp.lt     p3, v19, v2
    v.cmp.ne     p9, v16, v15
    p.or         p12, p11, p4
    p.and        p4, p5, p13
    p.xor        p5, p3, p9
    v.iota       v15                             // arange(0, VLEN)
    v.splat      v19, s6
    v.movi       v22, #0
    v.cmp.lt     p3, v7, v2
    v.movi       v7, #1
    v.cmp.ne     p9, v16, v11
    @p12 v.sel        v11, v20, v21
    p.or         p11, p4, p5
    p.and        p4, p6, p7
    p.xor        p5, p3, p9
    v.iota       v20                             // arange(0, VLEN)
    v.splat      v21, s8
    v.cmp.lt     p3, v15, v19
    v.movi       v15, #0
    v.movi       v19, #1
    @p11 v.sel        v24, v22, v7
    p.or         p6, p4, p5
    s.or         s5, s2, s4
    s.addi       s2, s3, #6
    v.movi       v7, #0
    p.and        p4, p8, p1
    @p3 v.reduce.or  s4, v11
    v.splat      v11, s2
    v.cmp.ne     p1, v16, v7
    v.iota       v7                              // arange(0, VLEN)
    v.cmp.lt     p3, v11, v2
    p.xor        p5, p3, p1
    v.splat      v11, s7
    v.cmp.lt     p1, v20, v21
    v.movi       v20, #0
    v.movi       v21, #1
    @p6 v.sel        v22, v15, v19
    p.or         p3, p4, p5
    s.or         s2, s5, s4
    s.addi       s4, s3, #7
    v.movi       v15, #0
    p.and        p4, p10, p2
    @p1 v.reduce.or  s5, v24
    v.splat      v19, s4
    v.cmp.ne     p1, v16, v15
    v.iota       v15                             // arange(0, VLEN)
    v.cmp.lt     p2, v19, v2
    p.xor        p5, p2, p1
    v.splat      v16, s10
    v.movi       v19, #0
    v.cmp.lt     p1, v7, v11
    v.movi       v7, #1
    @p3 v.sel        v11, v20, v21
    p.or         p2, p4, p5
    s.or         s4, s2, s5
    @p1 v.reduce.or  s2, v22
    v.iota       v20                             // arange(0, VLEN)
    v.splat      v21, s9
    v.cmp.lt     p1, v15, v16
    @p2 v.sel        v15, v19, v7
    s.or         s5, s4, s2
    @p1 v.reduce.or  s2, v11
    v.cmp.lt     p1, v20, v21
    s.or         s4, s5, s2
    @p1 v.reduce.or  s2, v15
    s.or         s5, s4, s2
    s.cmp.eq     s2, s5, s16
    br.nz        s2, assert_ok_1
    trap         #677351
assert_ok_1:
    v.extract    s2, v4, #0
    v.extract    s4, v5, #0
    v.extract    s5, v6, #0
    v.extract    s6, v8, #0
    v.extract    s7, v1, #0
    v.extract    s8, v10, #0
    s.shli       s9, s2, #32
    v.extract    s2, v9, #0
    s.shli       s10, s4, #32
    v.extract    s4, v13, #0
    s.shli       s11, s5, #32
    s.shli       s5, s6, #32
    s.or         s6, s8, s9
    v.extract    s8, v12, #0
    s.or         s9, s2, s10
    v.extract    s2, v18, #0
    s.or         s10, s4, s11
    s.movz       s4, #8
    s.or         s11, s8, s5
    s.movz       s5, #8
    s.mul        s8, s6, s4
    s.movz       s4, #8
    s.mul        s6, s9, s5
    s.movz       s5, #8
    s.mul        s9, s10, s4
    s.mul        s4, s11, s5
    v.movi       v1, #0
    s.shli       s5, s7, #32
    v.movi       v4, #0
    s.or         s7, s2, s5
    s.movz       s2, #8
    v.movi       v5, #0
    s.mul        s5, s7, s2
    v.movi       v6, #0
    v.movi       v7, #0
    v.movi       v8, #0
    v.movi       v9, #0
    v.movi       v10, #0
    v.movi       v11, #0
    v.movi       v12, #0
    v.movi       v13, #0
    s.lshri      s2, s8, #32
    s.lshri      s7, s6, #32
    s.lshri      s10, s9, #32
    v.insert     v1, s8, #0
    v.extract    s8, v23, #0
    v.movi       v15, #0
    v.insert     v4, s2, #0
    v.extract    s2, v0, #0
    v.movi       v0, #0
    s.shli       s11, s2, #32
    v.insert     v5, s6, #0
    v.extract    s2, v25, #0
    s.or         s6, s8, s11
    s.movz       s8, #8
    v.movi       v16, #0
    s.mul        s11, s6, s8
    s.lshri      s6, s4, #32
    v.insert     v6, s7, #0
    v.extract    s7, v3, #0
    v.movi       v3, #0
    s.shli       s8, s7, #32
    v.insert     v7, s9, #0
    v.extract    s7, v17, #0
    s.or         s9, s2, s8
    s.movz       s2, #8
    v.movi       v17, #0
    s.mul        s8, s9, s2
    s.lshri      s2, s5, #32
    v.insert     v8, s10, #0
    v.extract    s9, v14, #0
    v.movi       v14, #0
    s.shli       s10, s9, #32
    v.insert     v9, s4, #0
    s.or         s4, s7, s10
    s.movz       s7, #8
    v.movi       v18, #0
    s.mul        s9, s4, s7
    s.lshri      s4, s11, #32
    s.lshri      s7, s8, #32
    v.insert     v10, s6, #0
    v.iota       v19                             // arange(0, VLEN)
    s.lshri      s6, s9, #32
    v.insert     v11, s5, #0
    v.extract    s5, v19, #0
    v.insert     v12, s2, #0
    s.shli       s2, s5, #32
    v.extract    s5, v19, #1
    s.ashri      s10, s2, #32
    s.shli       s2, s5, #32
    v.insert     v13, s11, #0
    s.lshri      s5, s10, #32
    s.ashri      s11, s2, #32
    v.insert     v15, s4, #0
    v.extract    s2, v19, #2
    v.insert     v0, s8, #0
    v.insert     v16, s7, #0
    v.insert     v3, s9, #0
    v.insert     v17, s6, #0
    v.insert     v14, s10, #0
    v.insert     v18, s5, #0
    s.shli       s4, s2, #32
    s.lshri      s2, s11, #32
    v.extract    s5, v19, #3
    s.ashri      s6, s4, #32
    v.insert     v14, s11, #1
    v.insert     v18, s2, #1
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v19, #4
    s.ashri      s7, s2, #32
    v.insert     v14, s6, #2
    v.insert     v18, s4, #2
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v19, #5
    s.ashri      s6, s2, #32
    v.insert     v14, s7, #3
    v.insert     v18, s4, #3
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v19, #6
    s.ashri      s7, s2, #32
    v.insert     v14, s6, #4
    v.insert     v18, s4, #4
    s.shli       s2, s5, #32
    s.lshri      s4, s7, #32
    v.extract    s5, v19, #7
    s.ashri      s6, s2, #32
    v.insert     v14, s7, #5
    v.insert     v18, s4, #5
    s.shli       s2, s5, #32
    s.lshri      s4, s6, #32
    s.ashri      s5, s2, #32
    v.insert     v14, s6, #6
    v.insert     v18, s4, #6
    s.movz       s2, #0
    v.extract    s4, v4, #0
    v.extract    s6, v1, #0
    s.shli       s7, s4, #32
    v.extract    s4, v4, #0
    s.or         s8, s6, s7
    v.movi       v20, #0
    v.movi       v21, #0
    v.extract    s6, v1, #0
    s.shli       s7, s4, #32
    s.lshri      s4, s5, #32
    s.lshri      s9, s8, #32
    v.extract    s10, v4, #0
    s.or         s11, s6, s7
    v.insert     v14, s5, #7
    v.insert     v18, s4, #7
    v.insert     v20, s8, #0
    v.insert     v21, s9, #0
    v.extract    s4, v1, #0
    s.shli       s5, s10, #32
    s.lshri      s6, s11, #32
    v.extract    s7, v4, #0
    s.or         s8, s4, s5
    v.insert     v20, s11, #1
    v.insert     v21, s6, #1
    v.extract    s4, v1, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v4, #0
    s.or         s9, s4, s5
    v.insert     v20, s8, #2
    v.insert     v21, s6, #2
    v.extract    s4, v1, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v4, #0
    s.or         s8, s4, s5
    v.insert     v20, s9, #3
    v.insert     v21, s6, #3
    v.extract    s4, v1, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v4, #0
    s.or         s9, s4, s5
    v.insert     v20, s8, #4
    v.insert     v21, s6, #4
    v.extract    s4, v1, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v4, #0
    v.extract    s8, v6, #0
    s.or         s10, s4, s5
    v.insert     v20, s9, #5
    v.insert     v21, s6, #5
    v.extract    s4, v1, #0
    s.shli       s5, s7, #32
    v.extract    s6, v5, #0
    s.shli       s7, s8, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v6, #0
    s.or         s11, s4, s5
    s.or         s4, s6, s7
    v.insert     v20, s10, #6
    v.insert     v21, s8, #6
    v.movi       v1, #0
    v.movi       v4, #0
    v.extract    s5, v5, #0
    s.shli       s6, s9, #32
    s.lshri      s7, s11, #32
    s.lshri      s8, s4, #32
    v.extract    s9, v6, #0
    s.or         s10, s5, s6
    v.insert     v20, s11, #7
    v.insert     v21, s7, #7
    v.insert     v1, s4, #0
    v.insert     v4, s8, #0
    v.extract    s4, v5, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s10, #32
    v.extract    s7, v6, #0
    s.or         s8, s4, s5
    v.insert     v1, s10, #1
    v.insert     v4, s6, #1
    v.extract    s4, v5, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v6, #0
    s.or         s9, s4, s5
    v.insert     v1, s8, #2
    v.insert     v4, s6, #2
    v.extract    s4, v5, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v6, #0
    s.or         s8, s4, s5
    v.insert     v1, s9, #3
    v.insert     v4, s6, #3
    v.extract    s4, v5, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v6, #0
    s.or         s9, s4, s5
    v.insert     v1, s8, #4
    v.insert     v4, s6, #4
    v.extract    s4, v5, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v6, #0
    v.extract    s8, v8, #0
    s.or         s10, s4, s5
    v.insert     v1, s9, #5
    v.insert     v4, s6, #5
    v.extract    s4, v5, #0
    s.shli       s5, s7, #32
    v.extract    s6, v7, #0
    s.shli       s7, s8, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v8, #0
    s.or         s11, s4, s5
    s.or         s4, s6, s7
    v.insert     v1, s10, #6
    v.insert     v4, s8, #6
    v.movi       v5, #0
    v.movi       v6, #0
    v.extract    s5, v7, #0
    s.shli       s6, s9, #32
    s.lshri      s7, s11, #32
    s.lshri      s8, s4, #32
    v.extract    s9, v8, #0
    s.or         s10, s5, s6
    v.insert     v1, s11, #7
    v.insert     v4, s7, #7
    v.insert     v5, s4, #0
    v.insert     v6, s8, #0
    v.extract    s4, v7, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s10, #32
    v.extract    s7, v8, #0
    s.or         s8, s4, s5
    v.insert     v5, s10, #1
    v.insert     v6, s6, #1
    v.extract    s4, v7, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v8, #0
    s.or         s9, s4, s5
    v.insert     v5, s8, #2
    v.insert     v6, s6, #2
    v.extract    s4, v7, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v8, #0
    s.or         s8, s4, s5
    v.insert     v5, s9, #3
    v.insert     v6, s6, #3
    v.extract    s4, v7, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v8, #0
    s.or         s9, s4, s5
    v.insert     v5, s8, #4
    v.insert     v6, s6, #4
    v.extract    s4, v7, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v8, #0
    v.extract    s8, v10, #0
    s.or         s10, s4, s5
    v.insert     v5, s9, #5
    v.insert     v6, s6, #5
    v.extract    s4, v7, #0
    s.shli       s5, s7, #32
    v.extract    s6, v9, #0
    s.shli       s7, s8, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v10, #0
    s.or         s11, s4, s5
    s.or         s4, s6, s7
    v.insert     v5, s10, #6
    v.insert     v6, s8, #6
    v.movi       v7, #0
    v.movi       v8, #0
    v.extract    s5, v9, #0
    s.shli       s6, s9, #32
    s.lshri      s7, s11, #32
    s.lshri      s8, s4, #32
    v.extract    s9, v10, #0
    s.or         s10, s5, s6
    v.insert     v5, s11, #7
    v.insert     v6, s7, #7
    v.insert     v7, s4, #0
    v.insert     v8, s8, #0
    v.extract    s4, v9, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s10, #32
    v.extract    s7, v10, #0
    s.or         s8, s4, s5
    v.insert     v7, s10, #1
    v.insert     v8, s6, #1
    v.extract    s4, v9, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v10, #0
    s.or         s9, s4, s5
    v.insert     v7, s8, #2
    v.insert     v8, s6, #2
    v.extract    s4, v9, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v10, #0
    s.or         s8, s4, s5
    v.insert     v7, s9, #3
    v.insert     v8, s6, #3
    v.extract    s4, v9, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v10, #0
    s.or         s9, s4, s5
    v.insert     v7, s8, #4
    v.insert     v8, s6, #4
    v.extract    s4, v9, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v10, #0
    v.extract    s8, v12, #0
    s.or         s10, s4, s5
    v.insert     v7, s9, #5
    v.insert     v8, s6, #5
    v.extract    s4, v9, #0
    s.shli       s5, s7, #32
    v.extract    s6, v11, #0
    s.shli       s7, s8, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v12, #0
    s.or         s11, s4, s5
    s.or         s4, s6, s7
    v.insert     v7, s10, #6
    v.insert     v8, s8, #6
    v.movi       v9, #0
    v.movi       v10, #0
    v.extract    s5, v11, #0
    s.shli       s6, s9, #32
    s.lshri      s7, s11, #32
    s.lshri      s8, s4, #32
    v.extract    s9, v12, #0
    s.or         s10, s5, s6
    v.insert     v7, s11, #7
    v.insert     v8, s7, #7
    v.insert     v9, s4, #0
    v.insert     v10, s8, #0
    v.extract    s4, v11, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s10, #32
    v.extract    s7, v12, #0
    s.or         s8, s4, s5
    v.insert     v9, s10, #1
    v.insert     v10, s6, #1
    v.extract    s4, v11, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v12, #0
    s.or         s9, s4, s5
    v.insert     v9, s8, #2
    v.insert     v10, s6, #2
    v.extract    s4, v11, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v12, #0
    s.or         s8, s4, s5
    v.insert     v9, s9, #3
    v.insert     v10, s6, #3
    v.extract    s4, v11, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v12, #0
    s.or         s9, s4, s5
    v.insert     v9, s8, #4
    v.insert     v10, s6, #4
    v.extract    s4, v11, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v12, #0
    v.extract    s8, v15, #0
    s.or         s10, s4, s5
    v.insert     v9, s9, #5
    v.insert     v10, s6, #5
    v.extract    s4, v11, #0
    s.shli       s5, s7, #32
    v.extract    s6, v13, #0
    s.shli       s7, s8, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v15, #0
    s.or         s11, s4, s5
    s.or         s4, s6, s7
    v.insert     v9, s10, #6
    v.insert     v10, s8, #6
    v.movi       v11, #0
    v.movi       v12, #0
    v.extract    s5, v13, #0
    s.shli       s6, s9, #32
    s.lshri      s7, s11, #32
    s.lshri      s8, s4, #32
    v.extract    s9, v15, #0
    s.or         s10, s5, s6
    v.insert     v9, s11, #7
    v.insert     v10, s7, #7
    v.insert     v11, s4, #0
    v.insert     v12, s8, #0
    v.extract    s4, v13, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s10, #32
    v.extract    s7, v15, #0
    s.or         s8, s4, s5
    v.insert     v11, s10, #1
    v.insert     v12, s6, #1
    v.extract    s4, v13, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v15, #0
    s.or         s9, s4, s5
    v.insert     v11, s8, #2
    v.insert     v12, s6, #2
    v.extract    s4, v13, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v15, #0
    s.or         s8, s4, s5
    v.insert     v11, s9, #3
    v.insert     v12, s6, #3
    v.extract    s4, v13, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v15, #0
    s.or         s9, s4, s5
    v.insert     v11, s8, #4
    v.insert     v12, s6, #4
    v.extract    s4, v13, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v15, #0
    v.extract    s8, v16, #0
    s.or         s10, s4, s5
    v.insert     v11, s9, #5
    v.insert     v12, s6, #5
    v.extract    s4, v13, #0
    s.shli       s5, s7, #32
    v.extract    s6, v0, #0
    s.shli       s7, s8, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v16, #0
    s.or         s11, s4, s5
    s.or         s4, s6, s7
    v.insert     v11, s10, #6
    v.insert     v12, s8, #6
    v.movi       v13, #0
    v.movi       v15, #0
    v.extract    s5, v0, #0
    s.shli       s6, s9, #32
    s.lshri      s7, s11, #32
    s.lshri      s8, s4, #32
    v.extract    s9, v16, #0
    s.or         s10, s5, s6
    v.insert     v11, s11, #7
    v.insert     v12, s7, #7
    v.insert     v13, s4, #0
    v.insert     v15, s8, #0
    v.extract    s4, v0, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s10, #32
    v.extract    s7, v16, #0
    s.or         s8, s4, s5
    v.insert     v13, s10, #1
    v.insert     v15, s6, #1
    v.extract    s4, v0, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v16, #0
    s.or         s9, s4, s5
    v.insert     v13, s8, #2
    v.insert     v15, s6, #2
    v.extract    s4, v0, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v16, #0
    s.or         s8, s4, s5
    v.insert     v13, s9, #3
    v.insert     v15, s6, #3
    v.extract    s4, v0, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v16, #0
    s.or         s9, s4, s5
    v.insert     v13, s8, #4
    v.insert     v15, s6, #4
    v.extract    s4, v0, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v16, #0
    v.extract    s8, v17, #0
    s.or         s10, s4, s5
    v.insert     v13, s9, #5
    v.insert     v15, s6, #5
    v.extract    s4, v0, #0
    s.shli       s5, s7, #32
    v.extract    s6, v3, #0
    s.shli       s7, s8, #32
    s.lshri      s8, s10, #32
    v.extract    s9, v17, #0
    s.or         s11, s4, s5
    s.or         s4, s6, s7
    v.insert     v13, s10, #6
    v.insert     v15, s8, #6
    v.movi       v0, #0
    v.movi       v16, #0
    v.extract    s5, v3, #0
    s.shli       s6, s9, #32
    s.lshri      s7, s11, #32
    s.lshri      s8, s4, #32
    v.extract    s9, v17, #0
    s.or         s10, s5, s6
    v.insert     v13, s11, #7
    v.insert     v15, s7, #7
    v.insert     v0, s4, #0
    v.insert     v16, s8, #0
    v.extract    s4, v3, #0
    s.shli       s5, s9, #32
    s.lshri      s6, s10, #32
    v.extract    s7, v17, #0
    s.or         s8, s4, s5
    v.insert     v0, s10, #1
    v.insert     v16, s6, #1
    v.extract    s4, v3, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v17, #0
    s.or         s9, s4, s5
    v.insert     v0, s8, #2
    v.insert     v16, s6, #2
    v.extract    s4, v3, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s9, #32
    v.extract    s7, v17, #0
    s.or         s8, s4, s5
    v.insert     v0, s9, #3
    v.insert     v16, s6, #3
    v.extract    s4, v3, #0
    s.shli       s5, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v17, #0
    s.or         s9, s4, s5
    v.extract    s4, v18, #0
    v.extract    s5, v21, #0
    v.insert     v0, s8, #4
    v.insert     v16, s6, #4
    v.extract    s6, v3, #0
    s.shli       s8, s7, #32
    s.lshri      s7, s9, #32
    v.extract    s10, v17, #0
    s.shli       s11, s4, #32
    s.shli       s4, s5, #32
    s.or         s5, s6, s8
    v.extract    s6, v14, #0
    v.insert     v0, s9, #5
    v.extract    s8, v20, #0
    v.insert     v16, s7, #5
    v.extract    s7, v18, #1
    s.shli       s9, s10, #32
    s.or         s10, s6, s11
    v.extract    s6, v21, #1
    s.or         s11, s8, s4
    v.extract    s4, v3, #0
    s.shli       s8, s7, #32
    s.shli       s7, s6, #32
    s.or         s6, s4, s9
    s.lshri      s4, s5, #32
    s.add        s9, s10, s11
    v.extract    s10, v14, #1
    v.insert     v0, s5, #6
    v.extract    s5, v20, #1
    v.insert     v16, s4, #6
    v.extract    s4, v18, #2
    v.movi       v3, #0
    v.movi       v17, #0
    s.or         s11, s10, s8
    v.extract    s8, v21, #2
    s.or         s10, s5, s7
    s.lshri      s5, s6, #32
    s.shli       s7, s4, #32
    s.shli       s4, s8, #32
    s.add        s8, s11, s10
    s.lshri      s10, s9, #32
    v.insert     v0, s6, #7
    v.extract    s6, v14, #2
    v.insert     v16, s5, #7
    v.extract    s5, v20, #2
    v.insert     v3, s9, #0
    v.extract    s9, v18, #3
    v.insert     v17, s10, #0
    v.extract    s10, v21, #3
    s.or         s11, s6, s7
    s.or         s6, s5, s4
    s.lshri      s4, s8, #32
    v.extract    s5, v14, #3
    s.shli       s7, s9, #32
    s.shli       s9, s10, #32
    s.add        s10, s11, s6
    v.extract    s6, v20, #3
    v.insert     v3, s8, #1
    v.extract    s8, v18, #4
    v.insert     v17, s4, #1
    v.extract    s4, v21, #4
    s.or         s11, s5, s7
    s.or         s5, s6, s9
    s.lshri      s6, s10, #32
    v.extract    s7, v14, #4
    s.shli       s9, s8, #32
    s.shli       s8, s4, #32
    s.add        s4, s11, s5
    v.extract    s5, v20, #4
    v.insert     v3, s10, #2
    v.extract    s10, v18, #5
    v.insert     v17, s6, #2
    v.extract    s6, v21, #5
    s.or         s11, s7, s9
    s.or         s7, s5, s8
    s.lshri      s5, s4, #32
    v.extract    s8, v14, #5
    s.shli       s9, s10, #32
    s.shli       s10, s6, #32
    s.add        s6, s11, s7
    v.extract    s7, v20, #5
    v.insert     v3, s4, #3
    v.extract    s4, v18, #6
    v.insert     v17, s5, #3
    v.extract    s5, v21, #6
    s.or         s11, s8, s9
    s.or         s8, s7, s10
    s.lshri      s7, s6, #32
    v.extract    s9, v14, #6
    s.shli       s10, s4, #32
    s.shli       s4, s5, #32
    s.add        s5, s11, s8
    v.extract    s8, v20, #6
    v.insert     v3, s6, #4
    v.extract    s6, v18, #7
    v.insert     v17, s7, #4
    v.extract    s7, v21, #7
    s.or         s11, s9, s10
    v.extract    s9, v18, #0
    s.or         s10, s8, s4
    v.extract    s4, v4, #0
    s.shli       s8, s6, #32
    s.shli       s6, s7, #32
    s.shli       s7, s9, #32
    s.shli       s9, s4, #32
    s.add        s4, s11, s10
    s.lshri      s10, s5, #32
    v.insert     v3, s5, #5
    v.extract    s5, v14, #7
    v.insert     v17, s10, #5
    v.extract    s10, v20, #7
    s.or         s11, s5, s8
    v.extract    s5, v14, #0
    s.or         s8, s10, s6
    v.extract    s6, v1, #0
    s.or         s10, s5, s7
    v.extract    s5, v18, #1
    s.or         s7, s6, s9
    v.extract    s6, v4, #1
    s.shli       s9, s5, #32
    s.shli       s5, s6, #32
    s.add        s6, s11, s8
    s.lshri      s8, s4, #32
    s.add        s11, s10, s7
    v.extract    s7, v14, #1
    v.insert     v3, s4, #6
    v.extract    s4, v1, #1
    v.insert     v17, s8, #6
    v.extract    s8, v18, #2
    v.movi       v20, #0
    v.movi       v21, #0
    s.or         s10, s7, s9
    v.extract    s7, v4, #2
    s.or         s9, s4, s5
    s.lshri      s4, s6, #32
    s.shli       s5, s8, #32
    s.shli       s8, s7, #32
    s.add        s7, s10, s9
    s.lshri      s9, s11, #32
    v.insert     v3, s6, #7
    v.extract    s6, v14, #2
    v.insert     v17, s4, #7
    v.extract    s4, v1, #2
    v.insert     v20, s11, #0
    v.extract    s10, v18, #3
    v.insert     v21, s9, #0
    v.extract    s9, v4, #3
    s.or         s11, s6, s5
    s.or         s5, s4, s8
    s.lshri      s4, s7, #32
    v.extract    s6, v14, #3
    s.shli       s8, s10, #32
    s.shli       s10, s9, #32
    s.add        s9, s11, s5
    v.extract    s5, v1, #3
    v.insert     v20, s7, #1
    v.extract    s7, v18, #4
    v.insert     v21, s4, #1
    v.extract    s4, v4, #4
    s.or         s11, s6, s8
    s.or         s6, s5, s10
    s.lshri      s5, s9, #32
    v.extract    s8, v14, #4
    s.shli       s10, s7, #32
    s.shli       s7, s4, #32
    s.add        s4, s11, s6
    v.extract    s6, v1, #4
    v.insert     v20, s9, #2
    v.extract    s9, v18, #5
    v.insert     v21, s5, #2
    v.extract    s5, v4, #5
    s.or         s11, s8, s10
    s.or         s8, s6, s7
    s.lshri      s6, s4, #32
    v.extract    s7, v14, #5
    s.shli       s10, s9, #32
    s.shli       s9, s5, #32
    s.add        s5, s11, s8
    v.extract    s8, v1, #5
    v.insert     v20, s4, #3
    v.extract    s4, v18, #6
    v.insert     v21, s6, #3
    v.extract    s6, v4, #6
    s.or         s11, s7, s10
    s.or         s7, s8, s9
    s.lshri      s8, s5, #32
    v.extract    s9, v14, #6
    s.shli       s10, s4, #32
    s.shli       s4, s6, #32
    s.add        s6, s11, s7
    v.extract    s7, v1, #6
    v.insert     v20, s5, #4
    v.extract    s5, v18, #7
    v.insert     v21, s8, #4
    v.extract    s8, v4, #7
    s.or         s11, s9, s10
    v.extract    s9, v18, #0
    s.or         s10, s7, s4
    v.extract    s4, v6, #0
    s.shli       s7, s5, #32
    s.shli       s5, s8, #32
    s.shli       s8, s9, #32
    s.shli       s9, s4, #32
    s.add        s4, s11, s10
    s.lshri      s10, s6, #32
    v.insert     v20, s6, #5
    v.extract    s6, v14, #7
    v.insert     v21, s10, #5
    v.extract    s10, v1, #7
    s.or         s11, s6, s7
    v.extract    s6, v14, #0
    s.or         s7, s10, s5
    v.extract    s5, v5, #0
    s.or         s10, s6, s8
    v.extract    s6, v18, #1
    s.or         s8, s5, s9
    v.extract    s5, v6, #1
    s.shli       s9, s6, #32
    s.shli       s6, s5, #32
    s.add        s5, s11, s7
    s.lshri      s7, s4, #32
    s.add        s11, s10, s8
    v.extract    s8, v14, #1
    v.insert     v20, s4, #6
    v.extract    s4, v5, #1
    v.insert     v21, s7, #6
    v.extract    s7, v18, #2
    v.movi       v1, #0
    v.movi       v4, #0
    s.or         s10, s8, s9
    v.extract    s8, v6, #2
    s.or         s9, s4, s6
    s.lshri      s4, s5, #32
    s.shli       s6, s7, #32
    s.shli       s7, s8, #32
    s.add        s8, s10, s9
    s.lshri      s9, s11, #32
    v.insert     v20, s5, #7
    v.extract    s5, v14, #2
    v.insert     v21, s4, #7
    v.extract    s4, v5, #2
    v.insert     v1, s11, #0
    v.extract    s10, v18, #3
    v.insert     v4, s9, #0
    v.extract    s9, v6, #3
    s.or         s11, s5, s6
    s.or         s5, s4, s7
    s.lshri      s4, s8, #32
    v.extract    s6, v14, #3
    s.shli       s7, s10, #32
    s.shli       s10, s9, #32
    s.add        s9, s11, s5
    v.extract    s5, v5, #3
    v.insert     v1, s8, #1
    v.extract    s8, v18, #4
    v.insert     v4, s4, #1
    v.extract    s4, v6, #4
    s.or         s11, s6, s7
    s.or         s6, s5, s10
    s.lshri      s5, s9, #32
    v.extract    s7, v14, #4
    s.shli       s10, s8, #32
    s.shli       s8, s4, #32
    s.add        s4, s11, s6
    v.extract    s6, v5, #4
    v.insert     v1, s9, #2
    v.extract    s9, v18, #5
    v.insert     v4, s5, #2
    v.extract    s5, v6, #5
    s.or         s11, s7, s10
    s.or         s7, s6, s8
    s.lshri      s6, s4, #32
    v.extract    s8, v14, #5
    s.shli       s10, s9, #32
    s.shli       s9, s5, #32
    s.add        s5, s11, s7
    v.extract    s7, v5, #5
    v.insert     v1, s4, #3
    v.extract    s4, v18, #6
    v.insert     v4, s6, #3
    v.extract    s6, v6, #6
    s.or         s11, s8, s10
    s.or         s8, s7, s9
    s.lshri      s7, s5, #32
    v.extract    s9, v14, #6
    s.shli       s10, s4, #32
    s.shli       s4, s6, #32
    s.add        s6, s11, s8
    v.extract    s8, v5, #6
    v.insert     v1, s5, #4
    v.extract    s5, v18, #7
    v.insert     v4, s7, #4
    v.extract    s7, v6, #7
    s.or         s11, s9, s10
    v.extract    s9, v18, #0
    s.or         s10, s8, s4
    v.extract    s4, v8, #0
    s.shli       s8, s5, #32
    s.shli       s5, s7, #32
    s.shli       s7, s9, #32
    s.shli       s9, s4, #32
    s.add        s4, s11, s10
    s.lshri      s10, s6, #32
    v.insert     v1, s6, #5
    v.extract    s6, v14, #7
    v.insert     v4, s10, #5
    v.extract    s10, v5, #7
    s.or         s11, s6, s8
    v.extract    s6, v14, #0
    s.or         s8, s10, s5
    v.extract    s5, v7, #0
    s.or         s10, s6, s7
    v.extract    s6, v18, #1
    s.or         s7, s5, s9
    v.extract    s5, v8, #1
    s.shli       s9, s6, #32
    s.shli       s6, s5, #32
    s.add        s5, s11, s8
    s.lshri      s8, s4, #32
    s.add        s11, s10, s7
    v.extract    s7, v14, #1
    v.insert     v1, s4, #6
    v.extract    s4, v7, #1
    v.insert     v4, s8, #6
    v.extract    s8, v18, #2
    v.movi       v5, #0
    v.movi       v6, #0
    s.or         s10, s7, s9
    v.extract    s7, v8, #2
    s.or         s9, s4, s6
    s.lshri      s4, s5, #32
    s.shli       s6, s8, #32
    s.shli       s8, s7, #32
    s.add        s7, s10, s9
    s.lshri      s9, s11, #32
    v.insert     v1, s5, #7
    v.extract    s5, v14, #2
    v.insert     v4, s4, #7
    v.extract    s4, v7, #2
    v.insert     v5, s11, #0
    v.extract    s10, v18, #3
    v.insert     v6, s9, #0
    v.extract    s9, v8, #3
    s.or         s11, s5, s6
    s.or         s5, s4, s8
    s.lshri      s4, s7, #32
    v.extract    s6, v14, #3
    s.shli       s8, s10, #32
    s.shli       s10, s9, #32
    s.add        s9, s11, s5
    v.extract    s5, v7, #3
    v.insert     v5, s7, #1
    v.extract    s7, v18, #4
    v.insert     v6, s4, #1
    v.extract    s4, v8, #4
    s.or         s11, s6, s8
    s.or         s6, s5, s10
    s.lshri      s5, s9, #32
    v.extract    s8, v14, #4
    s.shli       s10, s7, #32
    s.shli       s7, s4, #32
    s.add        s4, s11, s6
    v.extract    s6, v7, #4
    v.insert     v5, s9, #2
    v.extract    s9, v18, #5
    v.insert     v6, s5, #2
    v.extract    s5, v8, #5
    s.or         s11, s8, s10
    s.or         s8, s6, s7
    s.lshri      s6, s4, #32
    v.extract    s7, v14, #5
    s.shli       s10, s9, #32
    s.shli       s9, s5, #32
    s.add        s5, s11, s8
    v.extract    s8, v7, #5
    v.insert     v5, s4, #3
    v.extract    s4, v18, #6
    v.insert     v6, s6, #3
    v.extract    s6, v8, #6
    s.or         s11, s7, s10
    s.or         s7, s8, s9
    s.lshri      s8, s5, #32
    v.extract    s9, v14, #6
    s.shli       s10, s4, #32
    s.shli       s4, s6, #32
    s.add        s6, s11, s7
    v.extract    s7, v7, #6
    v.insert     v5, s5, #4
    v.extract    s5, v18, #7
    v.insert     v6, s8, #4
    v.extract    s8, v8, #7
    s.or         s11, s9, s10
    v.extract    s9, v18, #0
    s.or         s10, s7, s4
    v.extract    s4, v10, #0
    s.shli       s7, s5, #32
    s.shli       s5, s8, #32
    s.shli       s8, s9, #32
    s.shli       s9, s4, #32
    s.add        s4, s11, s10
    s.lshri      s10, s6, #32
    v.insert     v5, s6, #5
    v.extract    s6, v14, #7
    v.insert     v6, s10, #5
    v.extract    s10, v7, #7
    s.or         s11, s6, s7
    v.extract    s6, v14, #0
    s.or         s7, s10, s5
    v.extract    s5, v9, #0
    s.or         s10, s6, s8
    v.extract    s6, v18, #1
    s.or         s8, s5, s9
    v.extract    s5, v10, #1
    s.shli       s9, s6, #32
    s.shli       s6, s5, #32
    s.add        s5, s11, s7
    s.lshri      s7, s4, #32
    s.add        s11, s10, s8
    v.extract    s8, v14, #1
    v.insert     v5, s4, #6
    v.extract    s4, v9, #1
    v.insert     v6, s7, #6
    v.extract    s7, v18, #2
    v.movi       v7, #0
    v.movi       v8, #0
    s.or         s10, s8, s9
    v.extract    s8, v10, #2
    s.or         s9, s4, s6
    s.lshri      s4, s5, #32
    s.shli       s6, s7, #32
    s.shli       s7, s8, #32
    s.add        s8, s10, s9
    s.lshri      s9, s11, #32
    v.insert     v5, s5, #7
    v.extract    s5, v14, #2
    v.insert     v6, s4, #7
    v.extract    s4, v9, #2
    v.insert     v7, s11, #0
    v.extract    s10, v18, #3
    v.insert     v8, s9, #0
    v.extract    s9, v10, #3
    s.or         s11, s5, s6
    s.or         s5, s4, s7
    s.lshri      s4, s8, #32
    v.extract    s6, v14, #3
    s.shli       s7, s10, #32
    s.shli       s10, s9, #32
    s.add        s9, s11, s5
    v.extract    s5, v9, #3
    v.insert     v7, s8, #1
    v.extract    s8, v18, #4
    v.insert     v8, s4, #1
    v.extract    s4, v10, #4
    s.or         s11, s6, s7
    s.or         s6, s5, s10
    s.lshri      s5, s9, #32
    v.extract    s7, v14, #4
    s.shli       s10, s8, #32
    s.shli       s8, s4, #32
    s.add        s4, s11, s6
    v.extract    s6, v9, #4
    v.insert     v7, s9, #2
    v.extract    s9, v18, #5
    v.insert     v8, s5, #2
    v.extract    s5, v10, #5
    s.or         s11, s7, s10
    s.or         s7, s6, s8
    s.lshri      s6, s4, #32
    v.extract    s8, v14, #5
    s.shli       s10, s9, #32
    s.shli       s9, s5, #32
    s.add        s5, s11, s7
    v.extract    s7, v9, #5
    v.insert     v7, s4, #3
    v.extract    s4, v18, #6
    v.insert     v8, s6, #3
    v.extract    s6, v10, #6
    s.or         s11, s8, s10
    s.or         s8, s7, s9
    s.lshri      s7, s5, #32
    v.extract    s9, v14, #6
    s.shli       s10, s4, #32
    s.shli       s4, s6, #32
    s.add        s6, s11, s8
    v.extract    s8, v9, #6
    v.insert     v7, s5, #4
    v.extract    s5, v18, #7
    v.insert     v8, s7, #4
    v.extract    s7, v10, #7
    s.or         s11, s9, s10
    v.extract    s9, v18, #0
    s.or         s10, s8, s4
    v.extract    s4, v12, #0
    s.shli       s8, s5, #32
    s.shli       s5, s7, #32
    s.shli       s7, s9, #32
    s.shli       s9, s4, #32
    s.add        s4, s11, s10
    s.lshri      s10, s6, #32
    v.insert     v7, s6, #5
    v.extract    s6, v14, #7
    v.insert     v8, s10, #5
    v.extract    s10, v9, #7
    s.or         s11, s6, s8
    v.extract    s6, v14, #0
    s.or         s8, s10, s5
    v.extract    s5, v11, #0
    s.or         s10, s6, s7
    v.extract    s6, v18, #1
    s.or         s7, s5, s9
    v.extract    s5, v12, #1
    s.shli       s9, s6, #32
    s.shli       s6, s5, #32
    s.add        s5, s11, s8
    s.lshri      s8, s4, #32
    s.add        s11, s10, s7
    v.extract    s7, v14, #1
    v.insert     v7, s4, #6
    v.extract    s4, v11, #1
    v.insert     v8, s8, #6
    v.extract    s8, v18, #2
    v.movi       v9, #0
    v.movi       v10, #0
    s.or         s10, s7, s9
    v.extract    s7, v12, #2
    s.or         s9, s4, s6
    s.lshri      s4, s5, #32
    s.shli       s6, s8, #32
    s.shli       s8, s7, #32
    s.add        s7, s10, s9
    s.lshri      s9, s11, #32
    v.insert     v7, s5, #7
    v.extract    s5, v14, #2
    v.insert     v8, s4, #7
    v.extract    s4, v11, #2
    v.insert     v9, s11, #0
    v.extract    s10, v18, #3
    v.insert     v10, s9, #0
    v.extract    s9, v12, #3
    s.or         s11, s5, s6
    s.or         s5, s4, s8
    s.lshri      s4, s7, #32
    v.extract    s6, v14, #3
    s.shli       s8, s10, #32
    s.shli       s10, s9, #32
    s.add        s9, s11, s5
    v.extract    s5, v11, #3
    v.insert     v9, s7, #1
    v.extract    s7, v18, #4
    v.insert     v10, s4, #1
    v.extract    s4, v12, #4
    s.or         s11, s6, s8
    s.or         s6, s5, s10
    s.lshri      s5, s9, #32
    v.extract    s8, v14, #4
    s.shli       s10, s7, #32
    s.shli       s7, s4, #32
    s.add        s4, s11, s6
    v.extract    s6, v11, #4
    v.insert     v9, s9, #2
    v.extract    s9, v18, #5
    v.insert     v10, s5, #2
    v.extract    s5, v12, #5
    s.or         s11, s8, s10
    s.or         s8, s6, s7
    s.lshri      s6, s4, #32
    v.extract    s7, v14, #5
    s.shli       s10, s9, #32
    s.shli       s9, s5, #32
    s.add        s5, s11, s8
    v.extract    s8, v11, #5
    v.insert     v9, s4, #3
    v.extract    s4, v18, #6
    v.insert     v10, s6, #3
    v.extract    s6, v12, #6
    s.or         s11, s7, s10
    s.or         s7, s8, s9
    s.lshri      s8, s5, #32
    v.extract    s9, v14, #6
    s.shli       s10, s4, #32
    s.shli       s4, s6, #32
    s.add        s6, s11, s7
    v.extract    s7, v11, #6
    v.insert     v9, s5, #4
    v.extract    s5, v18, #7
    v.insert     v10, s8, #4
    v.extract    s8, v12, #7
    s.or         s11, s9, s10
    v.extract    s9, v18, #0
    s.or         s10, s7, s4
    v.extract    s4, v15, #0
    s.shli       s7, s5, #32
    s.shli       s5, s8, #32
    s.shli       s8, s9, #32
    s.shli       s9, s4, #32
    s.add        s4, s11, s10
    s.lshri      s10, s6, #32
    v.insert     v9, s6, #5
    v.extract    s6, v14, #7
    v.insert     v10, s10, #5
    v.extract    s10, v11, #7
    s.or         s11, s6, s7
    v.extract    s6, v14, #0
    s.or         s7, s10, s5
    v.extract    s5, v13, #0
    s.or         s10, s6, s8
    v.extract    s6, v18, #1
    s.or         s8, s5, s9
    v.extract    s5, v15, #1
    s.shli       s9, s6, #32
    s.shli       s6, s5, #32
    s.add        s5, s11, s7
    s.lshri      s7, s4, #32
    s.add        s11, s10, s8
    v.extract    s8, v14, #1
    v.insert     v9, s4, #6
    v.extract    s4, v13, #1
    v.insert     v10, s7, #6
    v.extract    s7, v18, #2
    v.movi       v11, #0
    v.movi       v12, #0
    s.or         s10, s8, s9
    v.extract    s8, v15, #2
    s.or         s9, s4, s6
    s.lshri      s4, s5, #32
    s.shli       s6, s7, #32
    s.shli       s7, s8, #32
    s.add        s8, s10, s9
    s.lshri      s9, s11, #32
    v.insert     v9, s5, #7
    v.extract    s5, v14, #2
    v.insert     v10, s4, #7
    v.extract    s4, v13, #2
    v.insert     v11, s11, #0
    v.extract    s10, v18, #3
    v.insert     v12, s9, #0
    v.extract    s9, v15, #3
    s.or         s11, s5, s6
    s.or         s5, s4, s7
    s.lshri      s4, s8, #32
    v.extract    s6, v14, #3
    s.shli       s7, s10, #32
    s.shli       s10, s9, #32
    s.add        s9, s11, s5
    v.extract    s5, v13, #3
    v.insert     v11, s8, #1
    v.extract    s8, v18, #4
    v.insert     v12, s4, #1
    v.extract    s4, v15, #4
    s.or         s11, s6, s7
    s.or         s6, s5, s10
    s.lshri      s5, s9, #32
    v.extract    s7, v14, #4
    s.shli       s10, s8, #32
    s.shli       s8, s4, #32
    s.add        s4, s11, s6
    v.extract    s6, v13, #4
    v.insert     v11, s9, #2
    v.extract    s9, v18, #5
    v.insert     v12, s5, #2
    v.extract    s5, v15, #5
    s.or         s11, s7, s10
    s.or         s7, s6, s8
    s.lshri      s6, s4, #32
    v.extract    s8, v14, #5
    s.shli       s10, s9, #32
    s.shli       s9, s5, #32
    s.add        s5, s11, s7
    v.extract    s7, v13, #5
    v.insert     v11, s4, #3
    v.extract    s4, v18, #6
    v.insert     v12, s6, #3
    v.extract    s6, v15, #6
    s.or         s11, s8, s10
    s.or         s8, s7, s9
    s.lshri      s7, s5, #32
    v.extract    s9, v14, #6
    s.shli       s10, s4, #32
    s.shli       s4, s6, #32
    s.add        s6, s11, s8
    v.extract    s8, v13, #6
    v.insert     v11, s5, #4
    v.extract    s5, v18, #7
    v.insert     v12, s7, #4
    v.extract    s7, v15, #7
    s.or         s11, s9, s10
    v.extract    s9, v18, #0
    s.or         s10, s8, s4
    v.extract    s4, v16, #0
    s.shli       s8, s5, #32
    s.shli       s5, s7, #32
    s.shli       s7, s9, #32
    s.shli       s9, s4, #32
    s.add        s4, s11, s10
    s.lshri      s10, s6, #32
    v.insert     v11, s6, #5
    v.extract    s6, v14, #7
    v.insert     v12, s10, #5
    v.extract    s10, v13, #7
    s.or         s11, s6, s8
    v.extract    s6, v14, #0
    s.or         s8, s10, s5
    v.extract    s5, v0, #0
    s.or         s10, s6, s7
    v.extract    s6, v18, #1
    s.or         s7, s5, s9
    v.extract    s5, v16, #1
    s.shli       s9, s6, #32
    s.shli       s6, s5, #32
    s.add        s5, s11, s8
    s.lshri      s8, s4, #32
    s.add        s11, s10, s7
    v.extract    s7, v14, #1
    v.insert     v11, s4, #6
    v.extract    s4, v0, #1
    v.insert     v12, s8, #6
    v.extract    s8, v18, #2
    v.movi       v13, #0
    v.movi       v15, #0
    s.or         s10, s7, s9
    v.extract    s7, v16, #2
    s.or         s9, s4, s6
    s.lshri      s4, s5, #32
    s.shli       s6, s8, #32
    s.shli       s8, s7, #32
    s.add        s7, s10, s9
    s.lshri      s9, s11, #32
    v.insert     v11, s5, #7
    v.extract    s5, v14, #2
    v.insert     v12, s4, #7
    v.extract    s4, v0, #2
    v.insert     v13, s11, #0
    v.extract    s10, v18, #3
    v.insert     v15, s9, #0
    v.extract    s9, v16, #3
    s.or         s11, s5, s6
    s.or         s5, s4, s8
    s.lshri      s4, s7, #32
    v.extract    s6, v14, #3
    s.shli       s8, s10, #32
    s.shli       s10, s9, #32
    s.add        s9, s11, s5
    v.extract    s5, v0, #3
    v.insert     v13, s7, #1
    v.extract    s7, v18, #4
    v.insert     v15, s4, #1
    v.extract    s4, v16, #4
    s.or         s11, s6, s8
    s.or         s6, s5, s10
    s.lshri      s5, s9, #32
    v.extract    s8, v14, #4
    s.shli       s10, s7, #32
    s.shli       s7, s4, #32
    s.add        s4, s11, s6
    v.extract    s6, v0, #4
    v.insert     v13, s9, #2
    v.extract    s9, v18, #5
    v.insert     v15, s5, #2
    v.extract    s5, v16, #5
    s.or         s11, s8, s10
    s.or         s8, s6, s7
    s.lshri      s6, s4, #32
    v.extract    s7, v14, #5
    s.shli       s10, s9, #32
    s.shli       s9, s5, #32
    s.add        s5, s11, s8
    v.extract    s8, v0, #5
    v.insert     v13, s4, #3
    v.extract    s4, v18, #6
    v.insert     v15, s6, #3
    v.movi       v22, #31
    v.extract    s6, v16, #6
    s.or         s11, s7, s10
    s.or         s7, s8, s9
    s.lshri      s8, s5, #32
    v.extract    s9, v14, #6
    s.shli       s10, s4, #32
    s.shli       s4, s6, #32
    v.ashr       v23, v3, v22
    s.add        s6, s11, s7
    v.extract    s7, v0, #6
    v.movi       v22, #1
    v.movi       v24, #0
    v.insert     v13, s5, #4
    v.extract    s5, v18, #7
    v.insert     v15, s8, #4
    v.extract    s8, v16, #7
    s.or         s11, s9, s10
    s.movz       s9, #8
    s.or         s10, s7, s4
    s.lshri      s4, s6, #32
    s.shli       s7, s5, #32
    s.shli       s5, s8, #32
    v.cmp.ne     p1, v17, v23
    v.iota       v16                             // arange(0, VLEN)
    v.splat      v17, s9
    v.extract    s8, v14, #7
    s.add        s9, s11, s10
    v.extract    s10, v0, #7
    @p1 v.sel        v0, v22, v24
    v.insert     v13, s6, #5
    v.insert     v15, s4, #5
    s.or         s4, s8, s7
    s.or         s6, s10, s5
    s.lshri      s5, s9, #32
    v.cmp.lt     p1, v16, v17
    s.add        s7, s4, s6
    @p1 v.reduce.or  s4, v0
    s.movz       s6, #0
    v.insert     v13, s9, #6
    v.insert     v15, s5, #6
    s.lshri      s5, s7, #32
    s.cmp.eq     s8, s4, s6
    v.insert     v13, s7, #7
    v.insert     v15, s5, #7
    br.nz        s8, narrow_ok_2
    trap         #677220
narrow_ok_2:
    v.movi       v0, #31
    v.movi       v14, #1
    v.movi       v16, #0
    v.ashr       v17, v20, v0
    s.movz       s4, #8
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ne     p1, v21, v17
    v.splat      v17, s4
    @p1 v.sel        v18, v14, v16
    s.movz       s4, #0
    v.cmp.lt     p1, v0, v17
    @p1 v.reduce.or  s5, v18
    s.cmp.eq     s6, s5, s4
    br.nz        s6, narrow_ok_3
    trap         #677220
narrow_ok_3:
    v.movi       v0, #31
    v.movi       v14, #1
    v.movi       v16, #0
    v.ashr       v17, v1, v0
    s.movz       s4, #8
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ne     p1, v4, v17
    v.splat      v4, s4
    @p1 v.sel        v17, v14, v16
    s.movz       s4, #0
    v.cmp.lt     p1, v0, v4
    @p1 v.reduce.or  s5, v17
    s.cmp.eq     s6, s5, s4
    br.nz        s6, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v0, #31
    v.movi       v4, #1
    v.movi       v14, #0
    v.ashr       v16, v5, v0
    s.movz       s4, #8
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ne     p1, v6, v16
    v.splat      v6, s4
    @p1 v.sel        v16, v4, v14
    s.movz       s4, #0
    v.cmp.lt     p1, v0, v6
    @p1 v.reduce.or  s5, v16
    s.cmp.eq     s6, s5, s4
    br.nz        s6, narrow_ok_5
    trap         #677220
narrow_ok_5:
    v.movi       v0, #31
    v.movi       v4, #1
    v.movi       v6, #0
    v.ashr       v14, v7, v0
    s.movz       s4, #8
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ne     p1, v8, v14
    v.splat      v8, s4
    @p1 v.sel        v14, v4, v6
    s.movz       s4, #0
    v.cmp.lt     p1, v0, v8
    @p1 v.reduce.or  s5, v14
    s.cmp.eq     s6, s5, s4
    br.nz        s6, narrow_ok_6
    trap         #677220
narrow_ok_6:
    v.movi       v0, #31
    v.movi       v4, #1
    v.movi       v6, #0
    v.ashr       v8, v9, v0
    s.movz       s4, #8
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ne     p1, v10, v8
    v.splat      v8, s4
    @p1 v.sel        v10, v4, v6
    s.movz       s4, #0
    v.cmp.lt     p1, v0, v8
    @p1 v.reduce.or  s5, v10
    s.cmp.eq     s6, s5, s4
    br.nz        s6, narrow_ok_7
    trap         #677220
narrow_ok_7:
    v.movi       v0, #31
    v.movi       v4, #1
    v.movi       v6, #0
    v.ashr       v8, v11, v0
    s.movz       s4, #8
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ne     p1, v12, v8
    v.splat      v8, s4
    @p1 v.sel        v10, v4, v6
    s.movz       s4, #0
    v.cmp.lt     p1, v0, v8
    @p1 v.reduce.or  s5, v10
    s.cmp.eq     s6, s5, s4
    br.nz        s6, narrow_ok_8
    trap         #677220
narrow_ok_8:
    v.movi       v0, #31
    v.movi       v4, #1
    v.movi       v6, #0
    v.ashr       v8, v13, v0
    s.movz       s4, #8
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ne     p1, v15, v8
    v.splat      v8, s4
    @p1 v.sel        v10, v4, v6
    s.movz       s4, #0
    v.cmp.lt     p1, v0, v8
    @p1 v.reduce.or  s5, v10
    s.cmp.eq     s6, s5, s4
    br.nz        s6, narrow_ok_9
    trap         #677220
narrow_ok_9:
    s.rdspecial  s4, arg_base
    s.rdspecial  s5, role_id
    s.ld.d       s6, [s4, #40]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s4, #1024
    v.splat      v0, s2
    s.mul        s2, s5, s4
    v.splat      v4, s1
    v.add        v6, v0, v3
    v.add        v3, v0, v20
    v.add        v8, v0, v1
    v.add        v1, v0, v5
    v.add        v5, v0, v7
    v.add        v7, v0, v9
    s.add        s1, s6, s2                      // this context's own scratch
    v.add        v9, v0, v11
    s.addi       s2, s1, #0
    v.add        v10, v0, v13
    s.addi       s4, s2, #64
    s.addi       s5, s2, #128
    s.addi       s6, s2, #192
    s.addi       s7, s2, #256
    s.addi       s8, s2, #320
    s.addi       s9, s2, #384
    s.addi       s10, s2, #448
    v.st.w       [s2, #0], v6
    s.addi       s2, s1, #0
    v.splat      v0, s3
    v.iota       v6                              // arange(0, VLEN)
    v.cmp.lt     p1, v19, v4
    v.cmp.lt     p2, v0, v2
    p.and        p3, p1, p2
    v.iota       v0                              // arange(0, VLEN)
    v.st.w       [s4, #0], v3
    s.movz       s4, #8
    v.splat      v3, s4
    s.addi       s4, s1, #512
    v.cmp.lt     p2, v6, v3
    p.and        p4, p2, p3
    v.st.w       [s5, #0], v8
    s.addi       s5, s1, #64
    v.st.w       [s6, #0], v1
    s.addi       s6, s3, #1
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v3, s6
    s.movz       s6, #8
    v.splat      v4, s6
    v.cmp.lt     p2, v3, v2
    p.and        p3, p1, p2
    v.cmp.lt     p2, v0, v4
    p.and        p5, p2, p3
    s.addi       s6, s4, #64
    v.st.w       [s7, #0], v5
    s.addi       s7, s1, #128
    v.st.w       [s8, #0], v7
    s.addi       s8, s3, #2
    v.splat      v0, s8
    s.movz       s8, #8
    v.splat      v3, s8
    v.cmp.lt     p2, v0, v2
    p.and        p3, p1, p2
    s.addi       s8, s4, #128
    v.st.w       [s9, #0], v9
    s.addi       s9, s1, #192
    v.st.w       [s10, #0], v10
    fence.acq_rel.device
    s.addi       s10, s3, #3
    v.splat      v0, s10
    s.addi       s10, s4, #192
    v.ld.w       v4, [s2, #0]
    s.movz       s2, #8
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s2
    s.addi       s2, s1, #256
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v7, [s35, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v3
    p.and        p4, p2, p3
    v.cmp.lt     p2, v0, v2
    p.and        p3, p1, p2
    v.st.w       [s4, #0], v7
    v.iota       v0                              // arange(0, VLEN)
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s3, #4
    v.splat      v3, s5
    s.movz       s5, #8
    v.splat      v4, s5
    s.addi       s5, s4, #256
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v7, [s35, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v6
    p.and        p5, p2, p3
    v.cmp.lt     p2, v3, v2
    p.and        p3, p1, p2
    v.st.w       [s6, #0], v7
    s.addi       s6, s1, #320
    v.iota       v1                              // arange(0, VLEN)
    v.ld.w       v3, [s7, #0]
    s.addi       s7, s3, #5
    v.splat      v5, s7
    s.movz       s7, #8
    v.splat      v6, s7
    s.addi       s7, s4, #320
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v7, [s35, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v4
    p.and        p4, p2, p3
    v.cmp.lt     p2, v5, v2
    p.and        p3, p1, p2
    v.st.w       [s8, #0], v7
    s.addi       s8, s1, #384
    v.iota       v0                              // arange(0, VLEN)
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s3, #6
    v.splat      v4, s9
    s.movz       s9, #8
    v.splat      v5, s9
    s.addi       s9, s4, #384
    s.addi       s11, s4, #448
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v7, [s35, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v6
    p.and        p5, p2, p3
    v.cmp.lt     p2, v4, v2
    p.and        p3, p1, p2
    v.st.w       [s10, #0], v7
    s.addi       s4, s1, #448
    v.iota       v1                              // arange(0, VLEN)
    v.ld.w       v3, [s2, #0]
    s.addi       s2, s3, #7
    v.movi       v4, #0
    v.splat      v6, s2
    s.movz       s2, #8
    v.splat      v7, s3
    v.splat      v8, s2
    v.movi       v9, #0
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.h v10, [s35, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v5
    p.and        p4, p2, p3
    v.cmp.lt     p2, v6, v2
    p.and        p3, p1, p2
    v.st.w       [s5, #0], v10
    s.addi       s2, s1, #512
    v.ld.w       v0, [s6, #0]
    s.addi       s5, s3, #1
    s.movz       s6, #8
    v.splat      v3, s5
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s6
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.h v10, [s35, v0]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v8
    p.and        p5, p2, p3
    v.cmp.lt     p2, v7, v2
    p.and        p3, p1, p2
    v.st.w       [s7, #0], v10
    s.addi       s5, s1, #576
    v.ld.w       v0, [s8, #0]
    s.addi       s6, s3, #2
    s.movz       s7, #8
    v.splat      v1, s6
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v8, s7
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.h v10, [s35, v0]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v2
    p.and        p4, p1, p2
    v.st.w       [s9, #0], v10
    s.addi       s6, s1, #640
    v.ld.w       v0, [s4, #0]
    s.addi       s4, s3, #3
    s.movz       s7, #8
    v.splat      v3, s4
    v.iota       v10                             // arange(0, VLEN)
    v.splat      v11, s7
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.h v12, [s35, v0]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v2
    p.and        p5, p1, p2
    v.st.w       [s11, #0], v12
    fence.acq_rel.device
    s.addi       s4, s1, #704
    s.movz       s7, #8
    v.iota       v0                              // arange(0, VLEN)
    v.ld.w       v1, [s2, #0]
    v.splat      v12, s7
    v.ld.w       v13, [s5, #0]
    vf.cvt.bf16.f32 v14, v1
    vf.add       v1, v14, v4
    @p3 v.sel        v14, v1, v9
    s.addi       s2, s3, #4
    v.cmp.lt     p2, v3, v2
    v.splat      v1, s2
    p.and        p3, p1, p2
    v.ld.w       v3, [s6, #0]
    vf.cvt.bf16.f32 v15, v13
    vf.add       v13, v15, v4
    @p4 v.sel        v15, v13, v9
    v.cmp.lt     p2, v1, v2
    p.and        p4, p1, p2
    v.ld.w       v1, [s4, #0]
    vf.cvt.bf16.f32 v13, v3
    vf.add       v3, v13, v4
    @p5 v.sel        v13, v3, v9
    v.cmp.lt     p2, v5, v6
    s.addi       s2, s1, #768
    @p2 vf.reduce.add.b v3, v14
    s.addi       s4, s3, #5
    s.movz       s5, #8
    v.splat      v5, s4
    v.ld.w       v6, [s2, #0]
    vf.cvt.bf16.f32 v14, v1
    v.cmp.lt     p2, v5, v2
    p.and        p5, p1, p2
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v5, s5
    vf.add       v16, v14, v4
    @p3 v.sel        v14, v16, v9
    v.cmp.lt     p2, v7, v8
    s.addi       s2, s1, #832
    @p2 vf.reduce.add.b v7, v15
    s.addi       s4, s3, #6
    s.movz       s5, #8
    v.splat      v8, s4
    v.ld.w       v15, [s2, #0]
    vf.cvt.bf16.f32 v16, v6
    v.cmp.lt     p2, v8, v2
    p.and        p3, p1, p2
    v.iota       v6                              // arange(0, VLEN)
    vf.add       v8, v16, v4
    @p4 v.sel        v16, v8, v9
    v.cmp.lt     p2, v10, v11
    s.addi       s2, s1, #896
    v.splat      v8, s5
    @p2 vf.reduce.add.b v10, v13
    s.addi       s4, s3, #7
    s.movz       s5, #8
    v.ld.w       v11, [s2, #0]
    vf.cvt.bf16.f32 v13, v15
    v.cmp.lt     p2, v0, v12
    s.addi       s2, s1, #960
    v.splat      v0, s4
    v.iota       v12                             // arange(0, VLEN)
    vf.add       v15, v13, v4
    @p2 vf.reduce.add.b v13, v14
    v.cmp.lt     p2, v0, v2
    s.movz       s1, #8
    s.movz       s4, #0
    p.and        p4, p1, p2
    v.splat      v0, s5
    s.add        s5, s4, s36                     // the tile origin
    @p5 v.sel        v14, v15, v9
    v.cmp.lt     p1, v1, v5
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v5, s1
    vf.cvt.bf16.f32 v15, v11
    v.cmp.lt     p2, v6, v8
    v.ld.w       v6, [s2, #0]
    v.splat      v8, s3
    @p1 vf.reduce.add.b v11, v16
    vf.add       v16, v15, v4
    s.movz       s1, #1
    s.addi       s2, s3, #1
    s.movz       s4, #1
    s.addi       s6, s5, #1
    @p3 v.sel        v15, v16, v9
    v.cmp.lt     p1, v12, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v12, s1
    v.cmp.lt     p3, v1, v5
    v.splat      v1, s2
    v.iota       v5                              // arange(0, VLEN)
    @p2 vf.reduce.add.b v16, v14
    s.addi       s1, s3, #2
    s.movz       s2, #1
    vf.cvt.bf16.f32 v14, v6
    s.addi       s7, s5, #2
    @p1 vf.reduce.add.b v6, v15
    s.addi       s8, s3, #3
    s.movz       s9, #1
    vf.add       v15, v14, v4
    v.splat      v4, s4
    s.addi       s4, s5, #3
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s1
    @p4 v.sel        v14, v15, v9
    s.addi       s1, s3, #4
    v.iota       v9                              // arange(0, VLEN)
    s.addi       s10, s5, #4
    @p3 vf.reduce.add.b v15, v14
    v.cmp.lt     p2, v0, v12
    v.splat      v0, s2
    v.splat      v12, s8
    v.cmp.lt     p3, v1, v2
    v.iota       v1                              // arange(0, VLEN)
    v.cmp.lt     p4, v5, v4
    v.splat      v4, s9
    v.splat      v5, s1
    p.and        p5, p2, p1
    v.cmp.lt     p1, v8, v2
    v.iota       v8                              // arange(0, VLEN)
    p.and        p2, p4, p3
    v.cmp.lt     p3, v9, v0
    v.splat      v0, s5
    s.movz       s1, #1
    s.addi       s2, s3, #5
    v.splat      v9, s1
    s.addi       s1, s5, #5
    p.and        p4, p3, p1
    v.cmp.lt     p1, v12, v2
    v.splat      v12, s6
    @p5 v.st.scatter.w [s45, v0], v3
    s.movz       s6, #1
    s.addi       s8, s3, #6
    v.splat      v0, s2
    v.iota       v3                              // arange(0, VLEN)
    s.addi       s2, s5, #6
    v.cmp.lt     p3, v1, v4
    v.splat      v1, s6
    v.splat      v4, s7
    p.and        p5, p3, p1
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s4
    @p2 v.st.scatter.w [s45, v12], v7
    s.movz       s4, #1
    s.addi       s6, s3, #7
    v.splat      v7, s8
    v.iota       v12                             // arange(0, VLEN)
    s.addi       s3, s5, #7
    v.cmp.lt     p2, v8, v9
    v.splat      v8, s4
    v.splat      v9, s10
    p.and        p3, p2, p1
    v.cmp.lt     p1, v0, v2
    v.splat      v0, s1
    @p4 v.st.scatter.w [s45, v4], v10
    s.movz       s1, #1
    v.splat      v4, s6
    v.iota       v10                             // arange(0, VLEN)
    v.cmp.lt     p2, v3, v1
    v.splat      v1, s1
    v.splat      v3, s2
    p.and        p4, p2, p1
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s3
    @p5 v.st.scatter.w [s45, v5], v13
    v.cmp.lt     p2, v12, v8
    p.and        p5, p2, p1
    v.cmp.lt     p1, v4, v2
    @p3 v.st.scatter.w [s45, v9], v11
    v.cmp.lt     p2, v10, v1
    p.and        p3, p2, p1
    @p4 v.st.scatter.w [s45, v0], v16
    @p5 v.st.scatter.w [s45, v3], v6
    @p3 v.st.scatter.w [s45, v7], v15
__rctx_next:
    exit
