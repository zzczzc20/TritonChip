    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    s.movz       s1, #1
    s.rdspecial  s8, arg_base
    s.ld.d       s9, [s8, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s8, role_id
    s.movz       s10, #256
    s.mul        s11, s8, s10
    s.add        s8, s9, s11                     // this context's own scratch
    s.addi       s9, s8, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s8, #0
    s.st.d       [s9, #0], s3
    s.movz       s8, #4
    s.st.d       [s9, #8], s8
    s.movz       s8, #256
    s.st.d       [s9, #16], s8
    s.movz       s8, #1024
    s.st.d       [s9, #48], s8
    s.movz       s8, #4
    s.st.d       [s9, #56], s8
    .li       s8, #68719476737
    s.st.d       [s9, #88], s8
    .li       s8, #2207613190144
    s.st.d       [s9, #104], s8
    fence.release.device
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s8, #1
    s.movz       s9, #0
    s.movz       s10, #256
    s.movz       s11, #16
    v.splat      v0, s4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #32
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v0, v3
    v.cmp.lt     p2, v2, v3
    v.sub        v4, v3, v0
    @p1 v.sel        v5, v4, v0
    v.sub        v4, v3, v2
    @p2 v.sel        v6, v4, v2
    v.movi       v4, #5
    v.lshr       v6, v5, v4
    v.sub        v4, v3, v6
    @p1 v.sel        v3, v4, v6
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s1
    v.cmp.lt     p1, v4, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v4, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    v.cmp.ne     p1, v4, v5
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s8
    v.cmp.lt     p2, v4, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s5, v3]               // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    v.movi       v6, #1
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #31
    v.and        v2, v7, v0
    v.sub        v0, v5, v2
    @p2 v.sel        v5, v0, v2
    s.addi       s1, s9, #0
    v.movi       v0, #0
    v.movi       v2, #0
    v.mov        v2, v0
for_1:
    s.cmp.ge     s2, s1, s10
    br.nz        s2, endfor_2
    s.movz       s2, #0
    s.movz       s5, #0
    s.cmp.lt     s8, s4, s2
    s.movz       s2, #32
    s.sub        s9, s5, s8
    s.movz       s5, #0
    s.movz       s8, #0
    s.cmp.lt     s12, s2, s5
    s.xor        s5, s4, s9
    s.sub        s13, s8, s12
    s.sub        s8, s5, s9
    s.xor        s5, s9, s13
    s.lshri      s9, s8, #5
    v.splat      v6, s1
    s.xor        s12, s9, s5
    v.iota       v7                              // arange(0, VLEN)
    s.sub        s14, s12, s5
    s.movz       s5, #256
    s.movz       s12, #4
    s.muli       s15, s14, #1024
    v.splat      v8, s1
    v.add        v9, v6, v7
    v.movi       v6, #0
    v.splat      v7, s5
    v.splat      v10, s14
    v.movi       v11, #0
    s.muli       s5, s1, #4
    v.add        v12, v8, v1
    v.splat      v8, s12
    v.cmp.ge     p2, v9, v6
    v.cmp.lt     p3, v9, v7
    v.cmp.ge     p4, v10, v11
    v.cmp.lt     p5, v10, v8
    v.movi       v6, #32
    s.add        s12, s3, s15
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    v.extract    s14, v5, #0
    s.add        s15, s12, s5
    p.and        p3, p6, p2
    v.mul        v7, v12, v6
    v.splat      v6, s14
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s15, #0]
    v.movi       v9, #256
    v.add        v10, v6, v7
    s.muli       s5, s9, #32
    v.cmp.lt     p2, v12, v9
    v.movi       v6, #8192
    v.movi       v7, #1
    v.movi       v9, #0
    v.mul        v11, v3, v6
    v.movi       v6, #0
    @p1 v.sel        v12, v7, v9
    v.extract    s9, v11, #0
    s.xor        s12, s2, s13
    v.extract    s2, v4, #0
    v.splat      v7, s9
    v.cmp.eq     p3, v12, v6
    s.sub        s9, s12, s13
    v.splat      v6, s2
    .li       s2, #1065353216
    v.splat      v9, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v11, v10, v7
    v.rcp.approx v7, v6                          // ISA 8.8: <= 2**-22 relative
    s.sub        s2, s8, s5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.h v10, [s6, v11]             // index is in elements (ISA sec 9.1)
    v.movi       v11, #1
    v.movi       v12, #0
    v.movi       v13, #0
    v.movi       v14, #0
    @p3 v.sel        v15, v11, v12
    s.add        s2, s1, s11
    s.movz       s5, #1
    v.extract    s8, v15, #0
    s.movz       s9, #8192
    v.splat      v11, s8
    v.cmp.ne     p3, v11, v13
    vf.cvt.f16.f32 v11, v10
    vf.fms       v10, v6, v7, v9
    vf.fms       v6, v7, v10, v7
    vf.neg       v9, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v9, v9
    @p4 v.sel        v6, v9, v7
    vf.mul       v7, v8, v6                      // a/y as a refined reciprocal (ISA has no divide)
    @p3 v.sel        v6, v0, v7
    vf.mul       v7, v6, v11
    vf.add       v6, v2, v7
    @p2 v.sel        v7, v6, v2
    v.mov        v14, v7
    v.mov        v2, v14
    s.mov        s1, s2
    br.nz        s5, for_1
endfor_2:
    vf.reduce.add.b v0, v2
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #1                      // element offset -> bytes (x2)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s7, s2                      // &out_ptr1[...]
    vf.cvt.f32.f16 v3, v2
    v.cmp.lt     p1, v0, v1
    @p1 v.st.h       [s1, #0], v3
__rctx_next:
    exit
