    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #1536
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s3, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s3, role_id
    s.movz       s6, #1536
    s.ld.d       s7, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.add        s8, s2, s5                      // this context's own scratch
    .li       s2, #2147483647
    s.addi       s5, s7, #4096                   // the pointer's constant offset (4096 bytes)
    s.addi       s9, s8, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s8, #2147483647
    s.movz       s10, #256
    s.movz       s11, #4
    .li       s12, #68719476752
    .li       s13, #2207613190144
    s.rdspecial  s14, arg_base
    s.mul        s15, s3, s6
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    .li       s6, #2147483647
    .li       s16, #2147483647
    s.ld.d       s17, [s1, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.movz       s18, #512
    s.movz       s19, #4
    s.ld.d       s20, [s1, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    s.movz       s1, #0
    s.movz       s21, #0
    s.movz       s22, #8
    s.movz       s23, #0
    s.st.d       [s9, #0], s5
    s.movz       s5, #0
    s.cmp.lt     s24, s22, s23
    s.st.d       [s9, #8], s2
    s.sub        s2, s5, s24
    .li       s5, #68719476752
    s.st.d       [s9, #16], s8
    .li       s8, #2207613190144
    s.xor        s23, s22, s2
    s.st.d       [s9, #48], s10
    s.movz       s10, #0
    s.movz       s10, #3
    s.st.d       [s9, #56], s11
    s.cmp.lt     s11, s4, s1
    s.movz       s1, #1
    s.sub        s24, s21, s11
    s.movz       s11, #0
    s.st.d       [s9, #88], s12
    s.xor        s12, s4, s24
    s.movz       s21, #0
    s.sub        s21, s12, s24
    s.st.d       [s9, #104], s13
    s.lshri      s12, s21, #3
    fence.release.device
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s9, s24, s2
    s.movz       s13, #0
    s.ld.d       s24, [s14, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.sub        s14, s23, s2
    s.xor        s2, s12, s9
    s.movz       s14, #0
    s.sub        s23, s2, s9
    s.movz       s2, #0
    s.sub        s9, s10, s23
    s.muli       s10, s12, #8
    s.min.s      s12, s9, s1
    s.add        s1, s24, s15                    // this context's own scratch
    s.cmp.lt     s9, s4, s13
    s.movz       s13, #0
    s.movz       s15, #1
    s.addi       s24, s1, #256                   // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.cmp.lt     s1, s12, s11
    s.sub        s11, s2, s9
    s.movz       s2, #0
    s.st.d       [s24, #0], s3
    s.sub        s3, s14, s1
    s.xor        s1, s4, s11
    s.st.d       [s24, #8], s6
    s.xor        s6, s12, s3
    s.sub        s9, s1, s11
    s.st.d       [s24, #16], s16
    s.sub        s1, s6, s3
    s.addi       s3, s13, #0
    s.st.d       [s24, #48], s18
    s.cmp.eq     s6, s1, s15
    s.sub        s13, s21, s10
    s.st.d       [s24, #56], s19
    s.addi       s10, s2, #0
    s.st.d       [s24, #88], s5
    s.st.d       [s24, #104], s8
    fence.release.device
    td.load      d1, [s24]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s3, s9
    br.nz        s6, sdiv_done_1
    s.movz       s2, #0
    s.movz       s5, #31
    s.mov        s3, s2
    s.addi       s2, s5, #0
sdiv_2:
    s.lshr       s5, s9, s2
    s.shli       s6, s10, #1
    s.andi       s8, s5, #1
    s.movz       s5, #0
    s.or         s13, s6, s8
    s.movz       s6, #1
    s.cmp.geu    s8, s13, s1
    s.shl        s14, s6, s2
    s.sub        s6, s5, s8
    s.subi       s5, s2, #1
    s.and        s8, s1, s6
    s.and        s15, s14, s6
    s.sub        s6, s13, s8
    s.or         s8, s3, s15
    s.mov        s10, s6
    s.mov        s3, s8
    s.mov        s2, s5
    s.movz       s5, #0
    s.cmp.ge     s6, s2, s5
    br.nz        s6, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #0
    s.sub        s5, s2, s3
    s.movz       s2, #0
    s.xor        s3, s4, s5
    s.movz       s4, #0
    s.sub        s6, s3, s5
    s.cmp.lt     s3, s12, s1
    s.lshri      s1, s6, #3
    s.movz       s8, #0
    s.muli       s9, s1, #8
    s.sub        s1, s4, s3
    s.movz       s3, #0
    s.cmp.lt     s4, s22, s8
    s.xor        s8, s12, s1
    s.sub        s12, s6, s9
    s.movz       s6, #0
    s.xor        s9, s12, s5
    s.xor        s12, s10, s11
    s.sub        s10, s9, s5
    s.sub        s5, s6, s4
    s.cmp.lt     s4, s10, s2
    s.sub        s2, s8, s1
    s.sub        s6, s3, s4
    s.movz       s3, #0
    s.xor        s4, s10, s6
    s.movz       s8, #1
    s.sub        s9, s12, s11
    s.xor        s10, s22, s5
    s.sub        s11, s4, s6
    s.movz       s4, #0
    s.addi       s12, s3, #0
    s.cmp.eq     s3, s2, s8
    s.add        s8, s23, s9
    s.sub        s9, s10, s5
    s.addi       s5, s4, #0
    s.mov        s12, s11
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s12, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s11, s3
    s.shli       s9, s5, #1
    s.andi       s10, s4, #1
    s.movz       s4, #0
    s.or         s13, s9, s10
    s.movz       s9, #1
    s.cmp.geu    s10, s13, s2
    s.shl        s14, s9, s3
    s.sub        s9, s4, s10
    s.subi       s4, s3, #1
    s.and        s10, s2, s9
    s.and        s15, s14, s9
    s.sub        s9, s13, s10
    s.or         s10, s12, s15
    s.mov        s5, s9
    s.mov        s12, s10
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s9, s3, s4
    br.nz        s9, sdiv_4
sdiv_done_3:
    s.movz       s2, #16
    .li       s3, #1431655766
    s.mul        s4, s8, s2
    s.rdspecial  s5, pid.z
    s.rdspecial  s9, npid.y
    s.xor        s10, s6, s1
    s.mul        s1, s5, s9
    s.mul        s5, s4, s3
    s.xor        s3, s12, s10
    s.rdspecial  s6, pid.y
    s.sub        s9, s3, s10
    s.add        s3, s6, s1
    s.lshri      s1, s5, #32
    s.movz       s5, #63
    s.sub        s6, s4, s1
    s.mul        s10, s9, s2
    s.lshri      s2, s6, #1
    s.min.s      s6, s3, s5
    s.add        s5, s1, s2
    s.movz       s1, #4096
    s.lshri      s2, s5, #5
    s.movz       s5, #2048
    s.muli       s11, s2, #48
    s.mul        s2, s6, s1
    s.mul        s1, s6, s5
    s.andi       s6, s10, #127
    w.def        w0, #48, #16                    // v48..v63
    s.sub        s12, s4, s11
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s13, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s14, s12                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s2                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w0, d0, s14, s11
    mb.wait      s11
    s.movz       s2, #0
    v.splat      v0, s8
    s.add        s8, s6, s1
    w.def        w1, #32, #16                    // v32..v47
    v.splat      v1, s2
    mb.arm       s1, b1, #0, #1                  // 0 arrival(s), 1 operation(s)
    v.splat      v2, s9
    v.splat      v3, s2
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s4
    v.splat      v6, s10
    v.splat      v7, s12
    v.iota       v8                              // arange(0, VLEN)
    v.splat      v9, s6
    v.iota       v10                             // arange(0, VLEN)
    v.cmp.ge     p1, v0, v1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s14, s13                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s8                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w1, d1, s14, s1
    mb.wait      s1
    v.movi       v0, #0
    v.cmp.ge     p1, v2, v3
    v.extract    s6, v48, #0
    v.splat      v1, s6
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    v.add        v2, v5, v4
    vf.fma       v2, v1, v32, v0
    v.extract    s8, v48, #1
    v.splat      v1, s8
    v.add        v3, v6, v4
    vf.fma       v3, v1, v33, v2
    v.extract    s8, v48, #2
    v.splat      v1, s8
    v.extract    s8, v48, #3
    vf.fma       v2, v1, v34, v3
    v.splat      v1, s8
    v.extract    s8, v48, #4
    v.splat      v3, s8
    vf.fma       v4, v1, v35, v2
    v.add        v1, v7, v8
    v.extract    s8, v48, #5
    v.splat      v1, s8
    vf.fma       v2, v3, v36, v4
    v.add        v3, v9, v10
    v.extract    s8, v48, #6
    v.splat      v3, s8
    vf.fma       v4, v1, v37, v2
    v.extract    s8, v48, #7
    v.splat      v1, s8
    s.addi       s8, s7, #4096                   // &arg_A[1024] (a constant offset, x4)
    vf.fma       v2, v3, v38, v4
    v.extract    s7, v48, #8
    v.splat      v3, s7
    v.extract    s7, v48, #9
    vf.fma       v4, v1, v39, v2
    v.splat      v1, s7
    v.extract    s7, v48, #10
    v.splat      v2, s7
    vf.fma       v5, v3, v40, v4
    v.extract    s7, v48, #11
    v.splat      v3, s7
    v.extract    s7, v48, #12
    vf.fma       v4, v1, v41, v5
    v.splat      v1, s7
    v.extract    s7, v48, #13
    v.splat      v5, s7
    vf.fma       v6, v2, v42, v4
    v.extract    s7, v48, #14
    v.splat      v2, s7
    v.extract    s7, v48, #15
    vf.fma       v4, v3, v43, v6
    v.splat      v3, s7
    s.movz       s7, #1
    vf.fma       v6, v1, v44, v4
    vf.fma       v1, v5, v45, v6
    vf.fma       v4, v2, v46, v1
    vf.fma       v1, v3, v47, v4
    a.vwrite     a0, s6, v1
    v.extract    s6, v49, #0
    v.splat      v1, s6
    v.extract    s6, v49, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v49, #2
    v.splat      v3, s6
    vf.fma       v4, v1, v33, v2
    v.extract    s6, v49, #3
    v.splat      v1, s6
    v.extract    s6, v49, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s6
    v.extract    s6, v49, #5
    v.splat      v4, s6
    vf.fma       v5, v1, v35, v2
    v.extract    s6, v49, #6
    v.splat      v1, s6
    v.extract    s6, v49, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s6
    v.extract    s6, v49, #8
    v.splat      v5, s6
    vf.fma       v6, v4, v37, v2
    v.extract    s6, v49, #9
    v.splat      v2, s6
    v.extract    s6, v49, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s6
    v.extract    s6, v49, #11
    v.splat      v6, s6
    vf.fma       v7, v3, v39, v4
    v.extract    s6, v49, #12
    v.splat      v3, s6
    v.extract    s6, v49, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s6
    v.extract    s6, v49, #14
    v.splat      v7, s6
    vf.fma       v8, v2, v41, v4
    v.extract    s6, v49, #15
    v.splat      v2, s6
    s.movz       s6, #2
    vf.fma       v4, v1, v42, v8
    vf.fma       v1, v6, v43, v4
    vf.fma       v4, v3, v44, v1
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v7, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v50, #0
    v.splat      v1, s7
    v.extract    s7, v50, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v50, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v50, #3
    v.splat      v1, s7
    v.extract    s7, v50, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v50, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v50, #6
    v.splat      v1, s7
    v.extract    s7, v50, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v50, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v50, #9
    v.splat      v2, s7
    v.extract    s7, v50, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v50, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v50, #12
    v.splat      v3, s7
    v.extract    s7, v50, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v50, #14
    v.splat      v7, s7
    vf.fma       v8, v2, v41, v4
    v.extract    s7, v50, #15
    v.splat      v2, s7
    s.movz       s7, #3
    vf.fma       v4, v1, v42, v8
    vf.fma       v1, v6, v43, v4
    vf.fma       v4, v3, v44, v1
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v7, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s6, v1
    v.extract    s6, v51, #0
    v.splat      v1, s6
    v.extract    s6, v51, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v51, #2
    v.splat      v3, s6
    vf.fma       v4, v1, v33, v2
    v.extract    s6, v51, #3
    v.splat      v1, s6
    v.extract    s6, v51, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s6
    v.extract    s6, v51, #5
    v.splat      v4, s6
    vf.fma       v5, v1, v35, v2
    v.extract    s6, v51, #6
    v.splat      v1, s6
    v.extract    s6, v51, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s6
    v.extract    s6, v51, #8
    v.splat      v5, s6
    vf.fma       v6, v4, v37, v2
    v.extract    s6, v51, #9
    v.splat      v2, s6
    v.extract    s6, v51, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s6
    v.extract    s6, v51, #11
    v.splat      v6, s6
    vf.fma       v7, v3, v39, v4
    v.extract    s6, v51, #12
    v.splat      v3, s6
    v.extract    s6, v51, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s6
    v.extract    s6, v51, #14
    v.splat      v7, s6
    vf.fma       v8, v2, v41, v4
    v.extract    s6, v51, #15
    v.splat      v2, s6
    s.movz       s6, #4
    vf.fma       v4, v1, v42, v8
    vf.fma       v1, v6, v43, v4
    vf.fma       v4, v3, v44, v1
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v7, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v52, #0
    v.splat      v1, s7
    v.extract    s7, v52, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v52, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v52, #3
    v.splat      v1, s7
    v.extract    s7, v52, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v52, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v52, #6
    v.splat      v1, s7
    v.extract    s7, v52, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v52, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v52, #9
    v.splat      v2, s7
    v.extract    s7, v52, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v52, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v52, #12
    v.splat      v3, s7
    v.extract    s7, v52, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v52, #14
    v.splat      v7, s7
    vf.fma       v8, v2, v41, v4
    v.extract    s7, v52, #15
    v.splat      v2, s7
    s.movz       s7, #5
    vf.fma       v4, v1, v42, v8
    vf.fma       v1, v6, v43, v4
    vf.fma       v4, v3, v44, v1
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v7, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s6, v1
    v.extract    s6, v53, #0
    v.splat      v1, s6
    v.extract    s6, v53, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v53, #2
    v.splat      v3, s6
    vf.fma       v4, v1, v33, v2
    v.extract    s6, v53, #3
    v.splat      v1, s6
    v.extract    s6, v53, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s6
    v.extract    s6, v53, #5
    v.splat      v4, s6
    vf.fma       v5, v1, v35, v2
    v.extract    s6, v53, #6
    v.splat      v1, s6
    v.extract    s6, v53, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s6
    v.extract    s6, v53, #8
    v.splat      v5, s6
    vf.fma       v6, v4, v37, v2
    v.extract    s6, v53, #9
    v.splat      v2, s6
    v.extract    s6, v53, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s6
    v.extract    s6, v53, #11
    v.splat      v6, s6
    vf.fma       v7, v3, v39, v4
    v.extract    s6, v53, #12
    v.splat      v3, s6
    v.extract    s6, v53, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s6
    v.extract    s6, v53, #14
    v.splat      v7, s6
    vf.fma       v8, v2, v41, v4
    v.extract    s6, v53, #15
    v.splat      v2, s6
    s.movz       s6, #6
    vf.fma       v4, v1, v42, v8
    vf.fma       v1, v6, v43, v4
    vf.fma       v4, v3, v44, v1
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v7, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v54, #0
    v.splat      v1, s7
    v.extract    s7, v54, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v54, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v54, #3
    v.splat      v1, s7
    v.extract    s7, v54, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v54, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v54, #6
    v.splat      v1, s7
    v.extract    s7, v54, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v54, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v54, #9
    v.splat      v2, s7
    v.extract    s7, v54, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v54, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v54, #12
    v.splat      v3, s7
    v.extract    s7, v54, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v54, #14
    v.splat      v7, s7
    vf.fma       v8, v2, v41, v4
    v.extract    s7, v54, #15
    v.splat      v2, s7
    s.movz       s7, #7
    vf.fma       v4, v1, v42, v8
    vf.fma       v1, v6, v43, v4
    vf.fma       v4, v3, v44, v1
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v7, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s6, v1
    v.extract    s6, v55, #0
    v.splat      v1, s6
    v.extract    s6, v55, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v55, #2
    v.splat      v3, s6
    vf.fma       v4, v1, v33, v2
    v.extract    s6, v55, #3
    v.splat      v1, s6
    v.extract    s6, v55, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s6
    v.extract    s6, v55, #5
    v.splat      v4, s6
    vf.fma       v5, v1, v35, v2
    v.extract    s6, v55, #6
    v.splat      v1, s6
    v.extract    s6, v55, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s6
    v.extract    s6, v55, #8
    v.splat      v5, s6
    vf.fma       v6, v4, v37, v2
    v.extract    s6, v55, #9
    v.splat      v2, s6
    v.extract    s6, v55, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s6
    v.extract    s6, v55, #11
    v.splat      v6, s6
    vf.fma       v7, v3, v39, v4
    v.extract    s6, v55, #12
    v.splat      v3, s6
    v.extract    s6, v55, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s6
    v.extract    s6, v55, #14
    v.splat      v7, s6
    vf.fma       v8, v2, v41, v4
    v.extract    s6, v55, #15
    v.splat      v2, s6
    s.movz       s6, #8
    vf.fma       v4, v1, v42, v8
    vf.fma       v1, v6, v43, v4
    vf.fma       v4, v3, v44, v1
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v7, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v56, #0
    v.splat      v1, s7
    v.extract    s7, v56, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v56, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v56, #3
    v.splat      v1, s7
    v.extract    s7, v56, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v56, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v56, #6
    v.splat      v1, s7
    v.extract    s7, v56, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v56, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v56, #9
    v.splat      v2, s7
    v.extract    s7, v56, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v56, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v56, #12
    v.splat      v3, s7
    v.extract    s7, v56, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v56, #14
    v.splat      v7, s7
    vf.fma       v8, v2, v41, v4
    v.extract    s7, v56, #15
    v.splat      v2, s7
    s.movz       s7, #9
    vf.fma       v4, v1, v42, v8
    vf.fma       v1, v6, v43, v4
    vf.fma       v4, v3, v44, v1
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v7, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s6, v1
    v.extract    s6, v57, #0
    v.splat      v1, s6
    v.extract    s6, v57, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v57, #2
    v.splat      v3, s6
    vf.fma       v4, v1, v33, v2
    v.extract    s6, v57, #3
    v.splat      v1, s6
    v.extract    s6, v57, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s6
    v.extract    s6, v57, #5
    v.splat      v4, s6
    vf.fma       v5, v1, v35, v2
    v.extract    s6, v57, #6
    v.splat      v1, s6
    v.extract    s6, v57, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s6
    v.extract    s6, v57, #8
    v.splat      v5, s6
    vf.fma       v6, v4, v37, v2
    v.extract    s6, v57, #9
    v.splat      v2, s6
    v.extract    s6, v57, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s6
    v.extract    s6, v57, #11
    v.splat      v6, s6
    vf.fma       v7, v3, v39, v4
    v.extract    s6, v57, #12
    v.splat      v3, s6
    v.extract    s6, v57, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s6
    v.extract    s6, v57, #14
    v.splat      v7, s6
    vf.fma       v8, v2, v41, v4
    v.extract    s6, v57, #15
    v.splat      v2, s6
    s.movz       s6, #10
    vf.fma       v4, v1, v42, v8
    vf.fma       v1, v6, v43, v4
    vf.fma       v4, v3, v44, v1
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v7, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v58, #0
    v.splat      v1, s7
    v.extract    s7, v58, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v58, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v58, #3
    v.splat      v1, s7
    v.extract    s7, v58, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v58, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v58, #6
    v.splat      v1, s7
    v.extract    s7, v58, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v58, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v58, #9
    v.splat      v2, s7
    v.extract    s7, v58, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v58, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v58, #12
    v.splat      v3, s7
    v.extract    s7, v58, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v58, #14
    v.splat      v7, s7
    vf.fma       v8, v2, v41, v4
    v.extract    s7, v58, #15
    v.splat      v2, s7
    s.movz       s7, #11
    vf.fma       v4, v1, v42, v8
    vf.fma       v1, v6, v43, v4
    vf.fma       v4, v3, v44, v1
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v7, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s6, v1
    v.extract    s6, v59, #0
    v.splat      v1, s6
    v.extract    s6, v59, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v59, #2
    v.splat      v3, s6
    vf.fma       v4, v1, v33, v2
    v.extract    s6, v59, #3
    v.splat      v1, s6
    v.extract    s6, v59, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s6
    v.extract    s6, v59, #5
    v.splat      v4, s6
    vf.fma       v5, v1, v35, v2
    v.extract    s6, v59, #6
    v.splat      v1, s6
    v.extract    s6, v59, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s6
    v.extract    s6, v59, #8
    v.splat      v5, s6
    vf.fma       v6, v4, v37, v2
    v.extract    s6, v59, #9
    v.splat      v2, s6
    v.extract    s6, v59, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s6
    v.extract    s6, v59, #11
    v.splat      v6, s6
    vf.fma       v7, v3, v39, v4
    v.extract    s6, v59, #12
    v.splat      v3, s6
    v.extract    s6, v59, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s6
    v.extract    s6, v59, #14
    v.splat      v7, s6
    vf.fma       v8, v2, v41, v4
    v.extract    s6, v59, #15
    v.splat      v2, s6
    s.movz       s6, #12
    vf.fma       v4, v1, v42, v8
    vf.fma       v1, v6, v43, v4
    vf.fma       v4, v3, v44, v1
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v7, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v60, #0
    v.splat      v1, s7
    v.extract    s7, v60, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v60, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v60, #3
    v.splat      v1, s7
    v.extract    s7, v60, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v60, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v60, #6
    v.splat      v1, s7
    v.extract    s7, v60, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v60, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v60, #9
    v.splat      v2, s7
    v.extract    s7, v60, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v60, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v60, #12
    v.splat      v3, s7
    v.extract    s7, v60, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v60, #14
    v.splat      v7, s7
    vf.fma       v8, v2, v41, v4
    v.extract    s7, v60, #15
    v.splat      v2, s7
    s.movz       s7, #13
    vf.fma       v4, v1, v42, v8
    vf.fma       v1, v6, v43, v4
    vf.fma       v4, v3, v44, v1
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v7, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s6, v1
    v.extract    s6, v61, #0
    v.splat      v1, s6
    v.extract    s6, v61, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s6
    v.extract    s6, v61, #2
    v.splat      v3, s6
    vf.fma       v4, v1, v33, v2
    v.extract    s6, v61, #3
    v.splat      v1, s6
    v.extract    s6, v61, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s6
    v.extract    s6, v61, #5
    v.splat      v4, s6
    vf.fma       v5, v1, v35, v2
    v.extract    s6, v61, #6
    v.splat      v1, s6
    v.extract    s6, v61, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s6
    v.extract    s6, v61, #8
    v.splat      v5, s6
    vf.fma       v6, v4, v37, v2
    v.extract    s6, v61, #9
    v.splat      v2, s6
    v.extract    s6, v61, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s6
    v.extract    s6, v61, #11
    v.splat      v6, s6
    vf.fma       v7, v3, v39, v4
    v.extract    s6, v61, #12
    v.splat      v3, s6
    v.extract    s6, v61, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s6
    v.extract    s6, v61, #14
    v.splat      v7, s6
    vf.fma       v8, v2, v41, v4
    v.extract    s6, v61, #15
    v.splat      v2, s6
    s.movz       s6, #14
    vf.fma       v4, v1, v42, v8
    vf.fma       v1, v6, v43, v4
    vf.fma       v4, v3, v44, v1
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v7, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v62, #0
    v.splat      v1, s7
    v.extract    s7, v62, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v62, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v62, #3
    v.splat      v1, s7
    v.extract    s7, v62, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v62, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v62, #6
    v.splat      v1, s7
    v.extract    s7, v62, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v62, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v62, #9
    v.splat      v2, s7
    v.extract    s7, v62, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v62, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v62, #12
    v.splat      v3, s7
    v.extract    s7, v62, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v62, #14
    v.splat      v7, s7
    vf.fma       v8, v2, v41, v4
    v.extract    s7, v62, #15
    v.splat      v2, s7
    s.movz       s7, #15
    vf.fma       v4, v1, v42, v8
    vf.fma       v1, v6, v43, v4
    vf.fma       v4, v3, v44, v1
    vf.fma       v1, v5, v45, v4
    vf.fma       v3, v7, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s6, v1
    v.extract    s6, v63, #0
    v.splat      v1, s6
    v.extract    s6, v63, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v0, s6
    v.extract    s6, v63, #2
    v.splat      v1, s6
    vf.fma       v3, v0, v33, v2
    v.extract    s6, v63, #3
    v.splat      v0, s6
    v.extract    s6, v63, #4
    vf.fma       v2, v1, v34, v3
    v.splat      v1, s6
    v.extract    s6, v63, #5
    v.splat      v3, s6
    vf.fma       v4, v0, v35, v2
    v.extract    s6, v63, #6
    v.splat      v0, s6
    v.extract    s6, v63, #7
    vf.fma       v2, v1, v36, v4
    v.splat      v1, s6
    v.extract    s6, v63, #8
    v.splat      v4, s6
    vf.fma       v5, v3, v37, v2
    v.extract    s6, v63, #9
    v.splat      v2, s6
    v.extract    s6, v63, #10
    vf.fma       v3, v0, v38, v5
    v.splat      v0, s6
    v.extract    s6, v63, #11
    v.splat      v5, s6
    vf.fma       v6, v1, v39, v3
    v.extract    s6, v63, #12
    v.splat      v1, s6
    v.extract    s6, v63, #13
    vf.fma       v3, v4, v40, v6
    v.splat      v4, s6
    v.extract    s6, v63, #14
    v.splat      v6, s6
    vf.fma       v7, v2, v41, v3
    s.movz       s6, #6144
    s.muli       s8, s4, #128                    // a runtime tile origin, x128
    s.movz       s9, #0
    vf.fma       v2, v0, v42, v7
    s.mul        s12, s3, s6
    v.extract    s13, v63, #15
    s.add        s14, s9, s10                    // the tile origin
    vf.fma       v0, v5, v43, v2
    v.splat      v2, s13
    s.add        s9, s14, s8                     // the tile origin
    s.rdspecial  s8, role_id
    vf.fma       v3, v1, v44, v0
    s.movz       s13, #1536
    s.add        s14, s9, s12                    // the tile origin
    s.rdspecial  s9, arg_base
    vf.fma       v0, v4, v45, v3
    s.mul        s15, s8, s13
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v3, s14
    vf.fma       v4, v6, v46, v0
    s.movz       s8, #64
    v.add        v0, v1, v3
    v.splat      v3, s6
    vf.fma       v5, v2, v47, v4
    v.movi       v2, #0
    v.splat      v4, s3
    v.splat      v6, s8
    a.vwrite     a0, s7, v5
    s.ld.d       s6, [s9, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s7, #8192
    v.sub        v5, v2, v0
    s.add        s8, s6, s15                     // this context's own scratch
    v.sub        v7, v2, v3
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v3, v2
    v.movi       v8, #0
    v.cmp.lt     p3, v4, v6
    s.mul        s6, s3, s7
    s.addi       s3, s8, #512
    v.splat      v4, s2
    v.movi       v6, #1
    @p1 v.sel        v9, v5, v0
    @p2 v.sel        v0, v7, v3
    v.movi       v5, #0
    v.movi       v7, #0
    s.movz       s2, #31
idiv_6:
    v.splat      v10, s2
    v.shl        v11, v7, v6
    v.lshr       v12, v9, v10
    v.cmp.lt     p2, v7, v2
    v.and        v13, v12, v6
    v.shl        v12, v6, v10
    v.or         v10, v11, v13
    s.subi       s7, s2, #1
    v.cmp.geu    p4, v10, v0
    p.or         p5, p2, p4
    v.sub        v11, v10, v0
    @p5 v.sel        v13, v12, v2
    @p5 v.sel        v12, v11, v10
    v.or         v10, v5, v13
    v.mov        v7, v12
    v.mov        v5, v10
    s.mov        s2, s7
    s.movz       s7, #0
    s.cmp.ge     s9, s2, s7
    br.nz        s9, idiv_6
    v.sub        v0, v2, v7
    s.movz       s2, #0
    @p1 v.sel        v2, v0, v7
    v.splat      v0, s5
    s.add        s5, s2, s6                      // the tile origin
    s.addi       s2, s14, #128
    v.add        v5, v2, v0
    v.splat      v2, s5
    v.splat      v6, s2
    v.add        v7, v5, v2
    v.add        v5, v1, v6
    v.movi       v6, #0
    v.add        v9, v4, v7
    v.sub        v7, v6, v5
    v.sub        v10, v6, v3
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v3, v6
    v.st.w       [s3, #0], v9
    s.addi       s2, s3, #64
    v.movi       v9, #1
    @p1 v.sel        v11, v7, v5
    @p2 v.sel        v5, v10, v3
    v.movi       v7, #0
    v.movi       v10, #0
    s.movz       s5, #31
idiv_7:
    v.splat      v12, s5
    v.shl        v13, v10, v9
    v.lshr       v14, v11, v12
    v.cmp.lt     p2, v10, v6
    v.and        v15, v14, v9
    v.shl        v14, v9, v12
    v.or         v12, v13, v15
    s.subi       s6, s5, #1
    v.cmp.geu    p4, v12, v5
    p.or         p5, p2, p4
    v.sub        v13, v12, v5
    @p5 v.sel        v15, v14, v6
    @p5 v.sel        v14, v13, v12
    v.or         v12, v7, v15
    v.mov        v10, v14
    v.mov        v7, v12
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, idiv_7
    v.sub        v5, v6, v10
    s.addi       s5, s14, #256
    @p1 v.sel        v6, v5, v10
    v.splat      v5, s5
    v.add        v7, v6, v0
    v.add        v6, v1, v5
    v.add        v5, v7, v2
    v.movi       v7, #0
    v.add        v9, v4, v5
    v.sub        v5, v7, v6
    v.sub        v10, v7, v3
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v3, v7
    v.st.w       [s2, #0], v9
    s.addi       s2, s3, #128
    v.movi       v9, #1
    @p1 v.sel        v11, v5, v6
    @p2 v.sel        v5, v10, v3
    v.movi       v6, #0
    v.movi       v10, #0
    s.movz       s5, #31
idiv_8:
    v.splat      v12, s5
    v.shl        v13, v10, v9
    v.lshr       v14, v11, v12
    v.cmp.lt     p2, v10, v7
    v.and        v15, v14, v9
    v.shl        v14, v9, v12
    v.or         v12, v13, v15
    s.subi       s6, s5, #1
    v.cmp.geu    p4, v12, v5
    p.or         p5, p2, p4
    v.sub        v13, v12, v5
    @p5 v.sel        v15, v14, v7
    @p5 v.sel        v14, v13, v12
    v.or         v12, v6, v15
    v.mov        v10, v14
    v.mov        v6, v12
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, idiv_8
    v.sub        v5, v7, v10
    s.addi       s5, s14, #384
    @p1 v.sel        v6, v5, v10
    v.splat      v5, s5
    v.add        v7, v6, v0
    v.add        v6, v1, v5
    v.add        v5, v7, v2
    v.movi       v7, #0
    v.add        v9, v4, v5
    v.sub        v5, v7, v6
    v.sub        v10, v7, v3
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v3, v7
    v.st.w       [s2, #0], v9
    s.addi       s2, s3, #192
    v.movi       v9, #1
    @p1 v.sel        v11, v5, v6
    @p2 v.sel        v5, v10, v3
    v.movi       v6, #0
    v.movi       v10, #0
    s.movz       s5, #31
idiv_9:
    v.splat      v12, s5
    v.shl        v13, v10, v9
    v.lshr       v14, v11, v12
    v.cmp.lt     p2, v10, v7
    v.and        v15, v14, v9
    v.shl        v14, v9, v12
    v.or         v12, v13, v15
    s.subi       s6, s5, #1
    v.cmp.geu    p4, v12, v5
    p.or         p5, p2, p4
    v.sub        v13, v12, v5
    @p5 v.sel        v15, v14, v7
    @p5 v.sel        v14, v13, v12
    v.or         v12, v6, v15
    v.mov        v10, v14
    v.mov        v6, v12
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, idiv_9
    v.sub        v5, v7, v10
    s.addi       s5, s14, #512
    @p1 v.sel        v6, v5, v10
    v.splat      v5, s5
    v.add        v7, v6, v0
    v.add        v6, v1, v5
    v.add        v5, v7, v2
    v.movi       v7, #0
    v.add        v9, v4, v5
    v.sub        v5, v7, v6
    v.sub        v10, v7, v3
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v3, v7
    v.st.w       [s2, #0], v9
    s.addi       s2, s3, #256
    v.movi       v9, #1
    @p1 v.sel        v11, v5, v6
    @p2 v.sel        v5, v10, v3
    v.movi       v6, #0
    v.movi       v10, #0
    s.movz       s5, #31
idiv_10:
    v.splat      v12, s5
    v.shl        v13, v10, v9
    v.lshr       v14, v11, v12
    v.cmp.lt     p2, v10, v7
    v.and        v15, v14, v9
    v.shl        v14, v9, v12
    v.or         v12, v13, v15
    s.subi       s6, s5, #1
    v.cmp.geu    p4, v12, v5
    p.or         p5, p2, p4
    v.sub        v13, v12, v5
    @p5 v.sel        v15, v14, v7
    @p5 v.sel        v14, v13, v12
    v.or         v12, v6, v15
    v.mov        v10, v14
    v.mov        v6, v12
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, idiv_10
    v.sub        v5, v7, v10
    s.addi       s5, s14, #640
    @p1 v.sel        v6, v5, v10
    v.splat      v5, s5
    v.add        v7, v6, v0
    v.add        v6, v1, v5
    v.add        v5, v7, v2
    v.movi       v7, #0
    v.add        v9, v4, v5
    v.sub        v5, v7, v6
    v.sub        v10, v7, v3
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v3, v7
    v.st.w       [s2, #0], v9
    s.addi       s2, s3, #320
    v.movi       v9, #1
    @p1 v.sel        v11, v5, v6
    @p2 v.sel        v5, v10, v3
    v.movi       v6, #0
    v.movi       v10, #0
    s.movz       s5, #31
idiv_11:
    v.splat      v12, s5
    v.shl        v13, v10, v9
    v.lshr       v14, v11, v12
    v.cmp.lt     p2, v10, v7
    v.and        v15, v14, v9
    v.shl        v14, v9, v12
    v.or         v12, v13, v15
    s.subi       s6, s5, #1
    v.cmp.geu    p4, v12, v5
    p.or         p5, p2, p4
    v.sub        v13, v12, v5
    @p5 v.sel        v15, v14, v7
    @p5 v.sel        v14, v13, v12
    v.or         v12, v6, v15
    v.mov        v10, v14
    v.mov        v6, v12
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, idiv_11
    v.sub        v5, v7, v10
    s.addi       s5, s14, #768
    @p1 v.sel        v6, v5, v10
    v.splat      v5, s5
    v.add        v7, v6, v0
    v.add        v6, v1, v5
    v.add        v5, v7, v2
    v.movi       v7, #0
    v.add        v9, v4, v5
    v.sub        v5, v7, v6
    v.sub        v10, v7, v3
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v3, v7
    v.st.w       [s2, #0], v9
    s.addi       s2, s3, #384
    v.movi       v9, #1
    @p1 v.sel        v11, v5, v6
    @p2 v.sel        v5, v10, v3
    v.movi       v6, #0
    v.movi       v10, #0
    s.movz       s5, #31
idiv_12:
    v.splat      v12, s5
    v.shl        v13, v10, v9
    v.lshr       v14, v11, v12
    v.cmp.lt     p2, v10, v7
    v.and        v15, v14, v9
    v.shl        v14, v9, v12
    v.or         v12, v13, v15
    s.subi       s6, s5, #1
    v.cmp.geu    p4, v12, v5
    p.or         p5, p2, p4
    v.sub        v13, v12, v5
    @p5 v.sel        v15, v14, v7
    @p5 v.sel        v14, v13, v12
    v.or         v12, v6, v15
    v.mov        v10, v14
    v.mov        v6, v12
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, idiv_12
    v.sub        v5, v7, v10
    s.addi       s5, s14, #896
    @p1 v.sel        v6, v5, v10
    v.splat      v5, s5
    v.add        v7, v6, v0
    v.add        v6, v1, v5
    v.add        v5, v7, v2
    v.movi       v7, #0
    v.add        v9, v4, v5
    v.sub        v5, v7, v6
    v.sub        v10, v7, v3
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v3, v7
    v.st.w       [s2, #0], v9
    s.addi       s2, s3, #448
    v.movi       v9, #1
    @p1 v.sel        v11, v5, v6
    @p2 v.sel        v5, v10, v3
    v.movi       v6, #0
    v.movi       v10, #0
    s.movz       s5, #31
idiv_13:
    v.splat      v12, s5
    v.shl        v13, v10, v9
    v.lshr       v14, v11, v12
    v.cmp.lt     p2, v10, v7
    v.and        v15, v14, v9
    v.shl        v14, v9, v12
    v.or         v12, v13, v15
    s.subi       s6, s5, #1
    v.cmp.geu    p4, v12, v5
    p.or         p5, p2, p4
    v.sub        v13, v12, v5
    @p5 v.sel        v15, v14, v7
    @p5 v.sel        v14, v13, v12
    v.or         v12, v6, v15
    v.mov        v10, v14
    v.mov        v6, v12
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, idiv_13
    v.sub        v5, v7, v10
    s.addi       s5, s14, #1024
    @p1 v.sel        v6, v5, v10
    v.splat      v5, s5
    v.add        v7, v6, v0
    v.add        v6, v1, v5
    v.add        v5, v7, v2
    v.movi       v7, #0
    v.add        v9, v4, v5
    v.sub        v5, v7, v6
    v.sub        v10, v7, v3
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v3, v7
    v.st.w       [s2, #0], v9
    s.addi       s2, s3, #512
    v.movi       v9, #1
    @p1 v.sel        v11, v5, v6
    @p2 v.sel        v5, v10, v3
    v.movi       v6, #0
    v.movi       v10, #0
    s.movz       s5, #31
idiv_14:
    v.splat      v12, s5
    v.shl        v13, v10, v9
    v.lshr       v14, v11, v12
    v.cmp.lt     p2, v10, v7
    v.and        v15, v14, v9
    v.shl        v14, v9, v12
    v.or         v12, v13, v15
    s.subi       s6, s5, #1
    v.cmp.geu    p4, v12, v5
    p.or         p5, p2, p4
    v.sub        v13, v12, v5
    @p5 v.sel        v15, v14, v7
    @p5 v.sel        v14, v13, v12
    v.or         v12, v6, v15
    v.mov        v10, v14
    v.mov        v6, v12
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, idiv_14
    v.sub        v5, v7, v10
    s.addi       s5, s14, #1152
    @p1 v.sel        v6, v5, v10
    v.splat      v5, s5
    v.add        v7, v6, v0
    v.add        v6, v1, v5
    v.add        v5, v7, v2
    v.movi       v7, #0
    v.add        v9, v4, v5
    v.sub        v5, v7, v6
    v.sub        v10, v7, v3
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v3, v7
    v.st.w       [s2, #0], v9
    s.addi       s2, s3, #576
    v.movi       v9, #1
    @p1 v.sel        v11, v5, v6
    @p2 v.sel        v5, v10, v3
    v.movi       v6, #0
    v.movi       v10, #0
    s.movz       s5, #31
idiv_15:
    v.splat      v12, s5
    v.shl        v13, v10, v9
    v.lshr       v14, v11, v12
    v.cmp.lt     p2, v10, v7
    v.and        v15, v14, v9
    v.shl        v14, v9, v12
    v.or         v12, v13, v15
    s.subi       s6, s5, #1
    v.cmp.geu    p4, v12, v5
    p.or         p5, p2, p4
    v.sub        v13, v12, v5
    @p5 v.sel        v15, v14, v7
    @p5 v.sel        v14, v13, v12
    v.or         v12, v6, v15
    v.mov        v10, v14
    v.mov        v6, v12
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, idiv_15
    v.sub        v5, v7, v10
    s.addi       s5, s14, #1280
    @p1 v.sel        v6, v5, v10
    v.splat      v5, s5
    v.add        v7, v6, v0
    v.add        v6, v1, v5
    v.add        v5, v7, v2
    v.movi       v7, #0
    v.add        v9, v4, v5
    v.sub        v5, v7, v6
    v.sub        v10, v7, v3
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v3, v7
    v.st.w       [s2, #0], v9
    s.addi       s2, s3, #640
    v.movi       v9, #1
    @p1 v.sel        v11, v5, v6
    @p2 v.sel        v5, v10, v3
    v.movi       v6, #0
    v.movi       v10, #0
    s.movz       s5, #31
idiv_16:
    v.splat      v12, s5
    v.shl        v13, v10, v9
    v.lshr       v14, v11, v12
    v.cmp.lt     p2, v10, v7
    v.and        v15, v14, v9
    v.shl        v14, v9, v12
    v.or         v12, v13, v15
    s.subi       s6, s5, #1
    v.cmp.geu    p4, v12, v5
    p.or         p5, p2, p4
    v.sub        v13, v12, v5
    @p5 v.sel        v15, v14, v7
    @p5 v.sel        v14, v13, v12
    v.or         v12, v6, v15
    v.mov        v10, v14
    v.mov        v6, v12
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, idiv_16
    v.sub        v5, v7, v10
    s.addi       s5, s14, #1408
    @p1 v.sel        v6, v5, v10
    v.splat      v5, s5
    v.add        v7, v6, v0
    v.add        v6, v1, v5
    v.add        v5, v7, v2
    v.movi       v7, #0
    v.add        v9, v4, v5
    v.sub        v5, v7, v6
    v.sub        v10, v7, v3
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v3, v7
    v.st.w       [s2, #0], v9
    s.addi       s2, s3, #704
    v.movi       v9, #1
    @p1 v.sel        v11, v5, v6
    @p2 v.sel        v5, v10, v3
    v.movi       v6, #0
    v.movi       v10, #0
    s.movz       s5, #31
idiv_17:
    v.splat      v12, s5
    v.shl        v13, v10, v9
    v.lshr       v14, v11, v12
    v.cmp.lt     p2, v10, v7
    v.and        v15, v14, v9
    v.shl        v14, v9, v12
    v.or         v12, v13, v15
    s.subi       s6, s5, #1
    v.cmp.geu    p4, v12, v5
    p.or         p5, p2, p4
    v.sub        v13, v12, v5
    @p5 v.sel        v15, v14, v7
    @p5 v.sel        v14, v13, v12
    v.or         v12, v6, v15
    v.mov        v10, v14
    v.mov        v6, v12
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, idiv_17
    v.sub        v5, v7, v10
    s.addi       s5, s14, #1536
    @p1 v.sel        v6, v5, v10
    v.splat      v5, s5
    v.add        v7, v6, v0
    v.add        v6, v1, v5
    v.add        v5, v7, v2
    v.movi       v7, #0
    v.add        v9, v4, v5
    v.sub        v5, v7, v6
    v.sub        v10, v7, v3
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v3, v7
    v.st.w       [s2, #0], v9
    s.addi       s2, s3, #768
    v.movi       v9, #1
    @p1 v.sel        v11, v5, v6
    @p2 v.sel        v5, v10, v3
    v.movi       v6, #0
    v.movi       v10, #0
    s.movz       s5, #31
idiv_18:
    v.splat      v12, s5
    v.shl        v13, v10, v9
    v.lshr       v14, v11, v12
    v.cmp.lt     p2, v10, v7
    v.and        v15, v14, v9
    v.shl        v14, v9, v12
    v.or         v12, v13, v15
    s.subi       s6, s5, #1
    v.cmp.geu    p4, v12, v5
    p.or         p5, p2, p4
    v.sub        v13, v12, v5
    @p5 v.sel        v15, v14, v7
    @p5 v.sel        v14, v13, v12
    v.or         v12, v6, v15
    v.mov        v10, v14
    v.mov        v6, v12
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, idiv_18
    v.sub        v5, v7, v10
    s.addi       s5, s14, #1664
    @p1 v.sel        v6, v5, v10
    v.splat      v5, s5
    v.add        v7, v6, v0
    v.add        v6, v1, v5
    v.add        v5, v7, v2
    v.movi       v7, #0
    v.add        v9, v4, v5
    v.sub        v5, v7, v6
    v.sub        v10, v7, v3
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v3, v7
    v.st.w       [s2, #0], v9
    s.addi       s2, s3, #832
    v.movi       v9, #1
    @p1 v.sel        v11, v5, v6
    @p2 v.sel        v5, v10, v3
    v.movi       v6, #0
    v.movi       v10, #0
    s.movz       s5, #31
idiv_19:
    v.splat      v12, s5
    v.shl        v13, v10, v9
    v.lshr       v14, v11, v12
    v.cmp.lt     p2, v10, v7
    v.and        v15, v14, v9
    v.shl        v14, v9, v12
    v.or         v12, v13, v15
    s.subi       s6, s5, #1
    v.cmp.geu    p4, v12, v5
    p.or         p5, p2, p4
    v.sub        v13, v12, v5
    @p5 v.sel        v15, v14, v7
    @p5 v.sel        v14, v13, v12
    v.or         v12, v6, v15
    v.mov        v10, v14
    v.mov        v6, v12
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, idiv_19
    v.sub        v5, v7, v10
    s.addi       s5, s14, #1792
    @p1 v.sel        v6, v5, v10
    v.splat      v5, s5
    v.add        v7, v6, v0
    v.add        v6, v1, v5
    v.add        v5, v7, v2
    v.movi       v7, #0
    v.add        v9, v4, v5
    v.sub        v5, v7, v6
    v.sub        v10, v7, v3
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v3, v7
    v.st.w       [s2, #0], v9
    s.addi       s2, s3, #896
    v.movi       v9, #1
    @p1 v.sel        v11, v5, v6
    @p2 v.sel        v5, v10, v3
    v.movi       v6, #0
    v.movi       v10, #0
    s.movz       s5, #31
idiv_20:
    v.splat      v12, s5
    v.shl        v13, v10, v9
    v.lshr       v14, v11, v12
    v.cmp.lt     p2, v10, v7
    v.and        v15, v14, v9
    v.shl        v14, v9, v12
    v.or         v12, v13, v15
    s.subi       s6, s5, #1
    v.cmp.geu    p4, v12, v5
    p.or         p5, p2, p4
    v.sub        v13, v12, v5
    @p5 v.sel        v15, v14, v7
    @p5 v.sel        v14, v13, v12
    v.or         v12, v6, v15
    v.mov        v10, v14
    v.mov        v6, v12
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, idiv_20
    v.sub        v5, v7, v10
    s.addi       s5, s14, #1920
    @p1 v.sel        v6, v5, v10
    v.splat      v5, s5
    v.add        v7, v6, v0
    v.add        v6, v1, v5
    v.add        v5, v7, v2
    v.movi       v7, #0
    v.add        v9, v4, v5
    v.sub        v5, v7, v6
    v.sub        v10, v7, v3
    v.cmp.lt     p1, v6, v7
    v.cmp.lt     p2, v3, v7
    v.st.w       [s2, #0], v9
    s.addi       s2, s3, #960
    v.movi       v9, #1
    @p1 v.sel        v11, v5, v6
    @p2 v.sel        v5, v10, v3
    v.movi       v3, #0
    v.movi       v6, #0
    s.movz       s3, #31
idiv_21:
    v.splat      v10, s3
    v.shl        v12, v6, v9
    v.lshr       v13, v11, v10
    v.cmp.lt     p2, v6, v7
    v.and        v14, v13, v9
    v.shl        v13, v9, v10
    v.or         v10, v12, v14
    s.subi       s5, s3, #1
    v.cmp.geu    p4, v10, v5
    p.or         p5, p2, p4
    v.sub        v12, v10, v5
    @p5 v.sel        v14, v13, v7
    @p5 v.sel        v13, v12, v10
    v.or         v10, v3, v14
    v.mov        v6, v13
    v.mov        v3, v10
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s6, s3, s5
    br.nz        s6, idiv_21
    v.sub        v3, v7, v6
    s.movz       s3, #0
    @p1 v.sel        v5, v3, v6
    s.addi       s5, s8, #512
    v.add        v3, v5, v0
    s.movz       s6, #0
    v.add        v0, v3, v2
    s.add        s7, s3, s10                     // the tile origin
    v.add        v2, v4, v0
    s.add        s3, s6, s4                      // the tile origin
    v.st.w       [s2, #0], v2
    fence.acq_rel.device
    s.movz       s2, #48
    v.splat      v0, s7
    s.movz       s6, #128
    v.splat      v2, s3
    v.splat      v3, s2
    v.add        v4, v1, v0
    v.splat      v0, s6
    v.cmp.lt     p1, v2, v3
    v.ld.w       v1, [s5, #0]
    v.cmp.lt     p2, v4, v0
    p.and        p4, p1, p2
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s2, #0
    p.and        p1, p4, p3
    s.addi       s5, s8, #576
    s.addi       s6, s3, #1
    s.movz       s7, #1
    v.splat      v0, s6
    s.addi       s6, s8, #640
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s17, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s9, s3, #2
    p.and        p1, p4, p3
    v.splat      v0, s9
    s.movz       s9, #2
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    s.addi       s13, s8, #704
    a.vwrite     a1, s2, v2
    v.ld.w       v0, [s5, #0]
    p.and        p4, p5, p3
    s.addi       s2, s3, #3
    s.movz       s5, #3
    v.splat      v1, s2
    s.addi       s2, s8, #768
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p5, p1, p2
    p.and        p1, p5, p3
    a.vwrite     a1, s7, v2
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #4
    s.movz       s7, #4
    v.splat      v1, s6
    s.addi       s6, s8, #832
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v1, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p3
    a.vwrite     a1, s9, v2
    v.ld.w       v0, [s13, #0]
    s.addi       s9, s3, #5
    s.movz       s13, #5
    v.splat      v1, s9
    s.addi       s9, s8, #896
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p5, p1, p2
    p.and        p1, p5, p3
    a.vwrite     a1, s5, v2
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s3, #6
    s.movz       s5, #6
    v.splat      v1, s2
    s.addi       s2, s8, #960
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v1, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p3
    a.vwrite     a1, s7, v2
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #7
    s.movz       s7, #7
    v.splat      v1, s6
    s.addi       s6, s8, #1024
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p5, p1, p2
    p.and        p1, p5, p3
    a.vwrite     a1, s13, v2
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s3, #8
    s.movz       s13, #8
    v.splat      v1, s9
    s.addi       s9, s8, #1088
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v1, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p3
    a.vwrite     a1, s5, v2
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s3, #9
    s.movz       s5, #9
    v.splat      v1, s2
    s.addi       s2, s8, #1152
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p5, p1, p2
    p.and        p1, p5, p3
    a.vwrite     a1, s7, v2
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #10
    s.movz       s7, #10
    v.splat      v1, s6
    s.addi       s6, s8, #1216
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v1, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p3
    a.vwrite     a1, s13, v2
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s3, #11
    s.movz       s13, #11
    v.splat      v1, s9
    s.addi       s9, s8, #1280
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p5, p1, p2
    p.and        p1, p5, p3
    a.vwrite     a1, s5, v2
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s3, #12
    s.movz       s5, #12
    v.splat      v1, s2
    s.addi       s2, s8, #1344
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v1, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p3
    a.vwrite     a1, s7, v2
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #13
    s.movz       s7, #13
    v.splat      v1, s6
    s.addi       s6, s8, #1408
    s.addi       s14, s8, #1472
    s.muli       s8, s10, #4                     // a runtime tile origin, x4
    s.muli       s10, s4, #512                   // a runtime tile origin, x512
    s.muli       s4, s12, #4                     // a runtime tile origin, x4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p5, p1, p2
    s.add        s12, s20, s8                    // the tile origin
    p.and        p1, p5, p3
    s.addi       s8, s3, #14
    s.add        s15, s12, s10                   // the tile origin
    v.splat      v0, s8
    s.movz       s8, #14
    s.addi       s10, s3, #15
    a.vwrite     a1, s13, v2
    v.ld.w       v1, [s9, #0]
    v.splat      v2, s10
    s.movz       s9, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s10, #0
    s.movz       s12, #0
    v.splat      v4, s3
    s.add        s13, s15, s4                    // the tile origin
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v5, [s17, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p3
    a.vwrite     a1, s5, v5
    v.ld.w       v0, [s2, #0]
    s.movz       s2, #1
    s.movz       s4, #1
    s.addi       s5, s3, #1
    v.splat      v1, s5
    s.addi       s5, s13, #512                   // row 1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v3
    p.and        p5, p1, p2
    p.and        p1, p5, p3
    a.vwrite     a1, s7, v5
    v.ld.w       v0, [s6, #0]
    s.movz       s6, #2
    s.movz       s7, #2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v4, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p3
    a.vwrite     a1, s8, v2
    v.ld.w       v0, [s14, #0]
    s.addi       s8, s3, #2
    s.addi       s14, s13, #1024                 // row 2
    v.splat      v2, s8
    s.movz       s8, #3
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s17, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p5, p1, p2
    s.movz       s15, #3
    p.and        p1, p5, p3
    a.vwrite     a1, s9, v4
    a.vread      v0, a1, s10
    a.vread      v1, a0, s12
    s.addi       s9, s3, #3
    vf.add       v4, v1, v8
    v.splat      v1, s9
    s.addi       s9, s13, #1536                  // row 3
    s.movz       s10, #4
    vf.sub       v5, v0, v4
    s.movz       s12, #4
    @p4 v.st.w       [s13, #0], v5
    a.vread      v0, a1, s2
    a.vread      v4, a0, s4
    v.cmp.lt     p4, v2, v3
    vf.add       v2, v4, v8
    p.and        p5, p4, p2
    s.addi       s2, s3, #4
    p.and        p4, p5, p3
    vf.sub       v4, v0, v2
    v.splat      v0, s2
    s.addi       s2, s13, #2048                  // row 4
    s.movz       s4, #5
    @p1 v.st.w       [s5, #0], v4
    a.vread      v2, a1, s6
    a.vread      v4, a0, s7
    v.cmp.lt     p1, v1, v3
    vf.add       v1, v4, v8
    p.and        p5, p1, p2
    s.movz       s5, #5
    p.and        p1, p5, p3
    vf.sub       v4, v2, v1
    s.addi       s6, s3, #5
    s.addi       s7, s13, #2560                  // row 5
    v.splat      v1, s6
    @p4 v.st.w       [s14, #0], v4
    a.vread      v2, a1, s8
    a.vread      v4, a0, s15
    v.cmp.lt     p4, v0, v3
    vf.add       v0, v4, v8
    p.and        p5, p4, p2
    s.movz       s6, #6
    p.and        p4, p5, p3
    vf.sub       v4, v2, v0
    s.movz       s8, #6
    s.addi       s14, s3, #6
    s.addi       s15, s13, #3072                 // row 6
    @p1 v.st.w       [s9, #0], v4
    a.vread      v0, a1, s10
    a.vread      v2, a0, s12
    v.cmp.lt     p1, v1, v3
    vf.add       v1, v2, v8
    p.and        p5, p1, p2
    v.splat      v2, s14
    p.and        p1, p5, p3
    vf.sub       v4, v0, v1
    s.movz       s9, #7
    s.movz       s10, #7
    s.addi       s12, s3, #7
    @p4 v.st.w       [s2, #0], v4
    a.vread      v0, a1, s4
    a.vread      v1, a0, s5
    v.cmp.lt     p4, v2, v3
    vf.add       v2, v1, v8
    p.and        p5, p4, p2
    v.splat      v1, s12
    p.and        p4, p5, p3
    vf.sub       v4, v0, v2
    s.addi       s2, s13, #3584                  // row 7
    s.movz       s4, #8
    s.movz       s5, #8
    @p1 v.st.w       [s7, #0], v4
    a.vread      v0, a1, s6
    a.vread      v2, a0, s8
    v.cmp.lt     p1, v1, v3
    vf.add       v1, v2, v8
    p.and        p5, p1, p2
    s.addi       s6, s3, #8
    p.and        p1, p5, p3
    vf.sub       v2, v0, v1
    v.splat      v0, s6
    s.addi       s6, s13, #4096                  // row 8
    s.movz       s7, #9
    @p4 v.st.w       [s15, #0], v2
    a.vread      v1, a1, s9
    a.vread      v2, a0, s10
    v.cmp.lt     p4, v0, v3
    vf.add       v0, v2, v8
    p.and        p5, p4, p2
    s.movz       s8, #9
    p.and        p4, p5, p3
    vf.sub       v2, v1, v0
    s.addi       s9, s3, #9
    s.addi       s10, s13, #4608                 // row 9
    v.splat      v0, s9
    @p1 v.st.w       [s2, #0], v2
    a.vread      v1, a1, s4
    a.vread      v2, a0, s5
    v.cmp.lt     p1, v0, v3
    vf.add       v0, v2, v8
    p.and        p5, p1, p2
    s.movz       s2, #10
    p.and        p1, p5, p3
    vf.sub       v2, v1, v0
    s.movz       s4, #10
    s.addi       s5, s3, #10
    s.addi       s9, s13, #5120                  // row 10
    @p4 v.st.w       [s6, #0], v2
    a.vread      v0, a1, s7
    a.vread      v1, a0, s8
    v.splat      v2, s5
    vf.add       v4, v1, v8
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.movz       s5, #11
    vf.sub       v1, v0, v4
    p.and        p4, p5, p3
    s.movz       s6, #11
    s.addi       s7, s3, #11
    @p1 v.st.w       [s10, #0], v1
    a.vread      v0, a1, s2
    a.vread      v1, a0, s4
    v.splat      v2, s7
    vf.add       v4, v1, v8
    v.cmp.lt     p1, v2, v3
    p.and        p5, p1, p2
    s.addi       s2, s13, #5632                  // row 11
    vf.sub       v1, v0, v4
    p.and        p1, p5, p3
    s.movz       s4, #12
    s.movz       s7, #12
    @p4 v.st.w       [s9, #0], v1
    a.vread      v0, a1, s5
    a.vread      v1, a0, s6
    s.addi       s5, s3, #12
    vf.add       v2, v1, v8
    v.splat      v1, s5
    s.addi       s5, s13, #6144                  // row 12
    v.cmp.lt     p4, v1, v3
    vf.sub       v1, v0, v2
    p.and        p5, p4, p2
    s.movz       s6, #13
    p.and        p4, p5, p3
    @p1 v.st.w       [s2, #0], v1
    a.vread      v0, a1, s4
    a.vread      v1, a0, s7
    s.movz       s2, #13
    vf.add       v2, v1, v8
    s.addi       s4, s3, #13
    s.addi       s7, s13, #6656                  // row 13
    v.splat      v1, s4
    vf.sub       v4, v0, v2
    v.cmp.lt     p1, v1, v3
    p.and        p5, p1, p2
    s.movz       s4, #14
    @p4 v.st.w       [s5, #0], v4
    a.vread      v0, a1, s6
    a.vread      v1, a0, s2
    p.and        p1, p5, p3
    vf.add       v2, v1, v8
    s.movz       s2, #14
    s.addi       s5, s3, #14
    s.addi       s6, s13, #7168                  // row 14
    vf.sub       v1, v0, v2
    v.splat      v0, s5
    s.movz       s5, #15
    v.cmp.lt     p4, v0, v3
    @p1 v.st.w       [s7, #0], v1
    a.vread      v0, a1, s4
    a.vread      v1, a0, s2
    p.and        p1, p4, p2
    vf.add       v2, v1, v8
    p.and        p4, p1, p3
    s.movz       s2, #15
    s.addi       s4, s3, #15
    vf.sub       v1, v0, v2
    v.splat      v0, s4
    s.addi       s3, s13, #7680                  // row 15
    v.cmp.lt     p1, v0, v3
    @p4 v.st.w       [s6, #0], v1
    a.vread      v0, a1, s5
    a.vread      v1, a0, s2
    p.and        p4, p1, p2
    vf.add       v2, v1, v8
    p.and        p1, p4, p3
    vf.sub       v1, v0, v2
    @p1 v.st.w       [s3, #0], v1
__rctx_next:
    exit
