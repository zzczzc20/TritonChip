#!/usr/bin/env python3
"""Return first-layer submodule intermediates on CPU or DP TLM.

Diagnostic only: one layer, no vocabulary head, and extra graph outputs.
"""
import argparse,hashlib,json,sys,time
from pathlib import Path
import torch
from safetensors.torch import save_file
p=argparse.ArgumentParser();p.add_argument('--mode',choices=['cpu','tlm'],required=True);p.add_argument('--tree',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
sys.path[:0]=[str(a.tree/'tools/models'),str(a.tree),str(a.tree/'python'),str(a.tree/'compiler/python'),str(a.tree/'tools/asm')]
import chat
import transformers.models.qwen3_5.modeling_qwen3_5 as model
if a.mode=='tlm':chat.L.use_tnca(str(a.tree))
args=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1'])
start=time.monotonic();app=chat.ChatApplication(args);chat.L.install_fp8_route('official' if a.mode=='tlm' else 'reference',dot='exact',scale_div='ieee')
all_layers=app.model.model.language_model.layers;layer=all_layers[0]
if layer.block_type!='linear_attention':raise ValueError('unexpected first layer type')
app.model.model.language_model.layers=torch.nn.ModuleList([layer]);app.model.lm_head=torch.nn.Identity()
mods=dict(layer.named_modules()); names=('input_layernorm','linear_attn.in_proj_qkv','linear_attn.in_proj_z','linear_attn.in_proj_b','linear_attn.in_proj_a','linear_attn.norm','linear_attn.out_proj','linear_attn','post_attention_layernorm','mlp.gate_proj','mlp.up_proj','mlp.down_proj','mlp')
captures={};handles=[]
def hook_for(name):
 def hook(module,args,out):
  x=out[0] if isinstance(out,(tuple,list)) else out
  if isinstance(x,torch.Tensor):captures[name]=x
 return hook
for name in names:handles.append(mods[name].register_forward_hook(hook_for(name)))
handles.append(layer.register_forward_hook(hook_for('layer_output')))
def norm_pre(module,args):
 if len(args)!=2: raise ValueError('unexpected norm arguments')
 captures['norm_input_core'],captures['norm_input_z']=args
handles.append(layer.linear_attn.norm.register_forward_pre_hook(norm_pre))
conv0=model.causal_conv1d_fn;delta0=model.torch_chunk_gated_delta_rule
def conv(*args,**kwargs):
 result=conv0(*args,**kwargs);captures['conv_output']=result;return result
def delta(*args,**kwargs):
 for name,x in zip(('delta_input_q','delta_input_k','delta_input_v'),args[:3]):captures[name]=x
 captures['delta_input_g']=kwargs['g'];captures['delta_input_beta']=kwargs['beta']
 result=delta0(*args,**kwargs);captures['delta_output']=result[0];return result
model.causal_conv1d_fn=conv;model.torch_chunk_gated_delta_rule=delta
prompt='My name is Alice. Please remember it and reply with one short sentence.';inputs,text=chat.make_inputs(app.spec,app.processor,[chat.user_message(prompt)])
device='tnca' if a.mode=='tlm' else 'cpu';skip=None if device=='tnca' else chat.L.vision_tower(app.model)
stage,dev=chat.L.place(chat.L.PrefillStage(app.model,all_logits=False,hidden_states=True),device,'eager',skip=skip)
cache=chat.L.make_cache(app.model,256,dev);ids=inputs['input_ids'].clone(memory_format=torch.contiguous_format).to(dev);pos=chat.L.prefill_position_ids(app.model,inputs).clone(memory_format=torch.contiguous_format).to(dev)
try:
 with torch.no_grad():out=stage(ids,pos,cache,None)
 missing=(set(names)|{'layer_output','norm_input_core','norm_input_z','conv_output','delta_input_q','delta_input_k','delta_input_v','delta_input_g','delta_input_beta','delta_output'})-captures.keys()
 if missing:raise RuntimeError('hooks did not capture: '+repr(sorted(missing)))
 vals={k:v.detach().cpu().contiguous().clone() for k,v in captures.items()}
 vals['embedding']=out[1].detach().cpu().contiguous().clone()
finally:
 for h in handles:h.remove()
a.out.mkdir(parents=True,exist_ok=False);save_file(vals,str(a.out/'states.safetensors'))
result={'schema':'r41-q35-first-components/1','scope':'one-layer headless hook-instrumented convolution/delta diagnostic, not full-model or board acceptance','mode':a.mode,'model':app.spec.name,'revision':app.spec.revision,'prompt':prompt,'input_ids':inputs['input_ids'].tolist(),'chat_sha256':hashlib.sha256((a.tree/'tools/models/chat.py').read_bytes()).hexdigest(),'seconds':time.monotonic()-start,'shapes':{k:list(v.shape) for k,v in vals.items()}}
(a.out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
