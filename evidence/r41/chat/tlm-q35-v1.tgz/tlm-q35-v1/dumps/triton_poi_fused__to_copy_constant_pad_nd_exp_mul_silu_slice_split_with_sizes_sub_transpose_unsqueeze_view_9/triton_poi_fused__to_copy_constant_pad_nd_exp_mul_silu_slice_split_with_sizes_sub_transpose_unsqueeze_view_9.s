    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #7
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #63
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    s.rdspecial  s2, arg_base
    @p1 v.sel        v6, v5, v4
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #15
    v.lshr       v5, v6, v3
    s.movz       s5, #15
    s.movz       s6, #15
    v.sub        v3, v2, v5
    s.movz       s7, #15
    s.movz       s8, #15
    @p1 v.sel        v6, v3, v5
    s.movz       s9, #15
    s.movz       s10, #15
    v.sub        v3, v0, v6
    v.cmp.lt     p1, v6, v0
    s.ld.d       s11, [s2, #8]                   // in_ptr1: device_ptr64 at arg_base+8
    @p1 v.sel        v5, v3, v6
    v.movi       v3, #0
    s.movz       s12, #15
    v.and        v7, v5, v1
    s.movz       s13, #15
    s.movz       s14, #15
    v.sub        v1, v0, v7
    v.movi       v5, #128
    s.movz       s15, #15
    @p1 v.sel        v8, v1, v7
    s.ld.d       s16, [s2, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    v.cmp.lt     p1, v4, v3
    s.movz       s17, #15
    v.movi       v1, #64
    v.sub        v7, v2, v5
    v.cmp.lt     p2, v5, v2
    v.sub        v2, v0, v1
    v.cmp.lt     p3, v1, v0
    @p2 v.sel        v0, v7, v5
    @p3 v.sel        v0, v2, v1
    s.ld.d       s18, [s2, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    v.cmp.lt     p2, v5, v3
    s.ld.d       s19, [s2, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    v.sub        v0, v3, v4
    s.ld.d       s20, [s2, #40]                  // out_ptr0: device_ptr64 at arg_base+40
    @p1 v.sel        v1, v0, v4
    s.ld.d       s21, [s2, #48]                  // out_ptr1: device_ptr64 at arg_base+48
    v.sub        v0, v3, v5
    s.ld.d       s22, [s2, #56]                  // out_ptr2: device_ptr64 at arg_base+56
    @p2 v.sel        v2, v0, v5
    s.ld.d       s23, [s2, #64]                  // out_ptr3: device_ptr64 at arg_base+64
    v.extract    s2, v8, #0
    v.extract    s24, v8, #1
    s.shli       s25, s2, #32
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    s.ashri      s1, s25, #32
    v.movi       v0, #0
    v.movi       v2, #0
    s.shli       s25, s24, #32
    s.add        s24, s3, s2                     // &in_ptr0[...]
    s.lshri      s3, s1, #32
    v.extract    s26, v8, #2
    s.ashri      s27, s25, #32
    v.ld.w       v7, [s24, #0]
    s.shli       s24, s26, #32
    s.lshri      s25, s27, #32
    s.ashri      s26, s24, #32
    v.movi       v9, #0
    v.movi       v10, #127
    v.movi       v11, #13
    v.sub        v12, v9, v4
    v.cmp.lt     p2, v4, v9
    v.and        v13, v1, v10
    @p2 v.sel        v1, v12, v4
    v.movi       v4, #8192
    v.sub        v10, v3, v13
    v.lshr       v3, v1, v11
    v.sub        v1, v9, v4
    @p1 v.sel        v11, v10, v13
    v.sub        v10, v9, v3
    v.cmp.lt     p1, v4, v9
    v.ld.gather.w v9, [s11, v6]                  // index is in elements (ISA sec 9.1)
    v.extract    s11, v8, #3
    @p2 v.sel        v12, v10, v3
    s.shli       s24, s11, #32
    @p1 v.sel        v3, v1, v4
    s.ashri      s11, s24, #32
    v.ld.gather.w v1, [s16, v6]                  // index is in elements (ISA sec 9.1)
    s.lshri      s16, s26, #32
    vf.mul       v3, v7, v9
    v.ld.gather.w v10, [s18, v6]                 // index is in elements (ISA sec 9.1)
    v.insert     v0, s1, #0
    v.insert     v2, s3, #0
    v.extract    s1, v8, #4
    v.insert     v0, s27, #1
    v.insert     v2, s25, #1
    s.shli       s3, s1, #32
    v.insert     v0, s26, #2
    v.insert     v2, s16, #2
    s.lshri      s1, s11, #32
    v.extract    s16, v8, #5
    s.ashri      s18, s3, #32
    v.insert     v0, s11, #3
    v.insert     v2, s1, #3
    s.shli       s1, s16, #32
    s.lshri      s3, s18, #32
    v.extract    s11, v8, #6
    s.ashri      s16, s1, #32
    v.insert     v0, s18, #4
    v.insert     v2, s3, #4
    s.shli       s1, s11, #32
    s.lshri      s3, s16, #32
    v.extract    s11, v8, #7
    s.ashri      s18, s1, #32
    v.insert     v0, s16, #5
    v.insert     v2, s3, #5
    s.shli       s1, s11, #32
    s.lshri      s3, s18, #32
    v.insert     v0, s18, #6
    v.insert     v2, s3, #6
    vf.mul       v6, v3, v1
    s.ashri      s3, s1, #32
    vf.mul       v1, v7, v10
    v.extract    s1, v8, #8
    s.lshri      s11, s3, #32
    s.shli       s16, s1, #32
    v.extract    s1, v8, #9
    s.ashri      s18, s16, #32
    v.insert     v0, s3, #7
    v.insert     v2, s11, #7
    s.shli       s3, s1, #32
    s.lshri      s1, s18, #32
    v.extract    s11, v8, #10
    s.ashri      s16, s3, #32
    v.insert     v0, s18, #8
    v.insert     v2, s1, #8
    s.shli       s1, s11, #32
    s.lshri      s3, s16, #32
    v.extract    s11, v8, #11
    s.ashri      s18, s1, #32
    v.insert     v0, s16, #9
    v.insert     v2, s3, #9
    s.shli       s1, s11, #32
    s.lshri      s3, s18, #32
    v.extract    s11, v8, #12
    s.ashri      s16, s1, #32
    v.insert     v0, s18, #10
    v.insert     v2, s3, #10
    s.shli       s1, s11, #32
    s.lshri      s3, s16, #32
    v.extract    s11, v8, #13
    s.ashri      s18, s1, #32
    v.insert     v0, s16, #11
    v.insert     v2, s3, #11
    s.shli       s1, s11, #32
    s.lshri      s3, s18, #32
    v.extract    s11, v8, #14
    s.ashri      s16, s1, #32
    v.insert     v0, s18, #12
    v.insert     v2, s3, #12
    s.shli       s1, s11, #32
    s.lshri      s3, s16, #32
    v.extract    s11, v8, #15
    s.ashri      s18, s1, #32
    v.insert     v0, s16, #13
    v.insert     v2, s3, #13
    s.shli       s1, s11, #32
    s.lshri      s3, s18, #32
    s.ashri      s11, s1, #32
    v.insert     v0, s18, #14
    v.insert     v2, s3, #14
    s.lshri      s1, s11, #32
    v.insert     v0, s11, #15
    v.insert     v2, s1, #15
    v.movi       v7, #0
    v.extract    s1, v0, #0
    v.extract    s3, v2, #0
    v.extract    s11, v2, #1
    s.shli       s16, s3, #32
    v.extract    s3, v0, #1
    s.or         s18, s1, s16
    s.shli       s1, s11, #32
    s.cmp.lt     s11, s18, s4
    v.extract    s16, v2, #2
    s.or         s18, s3, s1
    v.insert     v7, s11, #0
    v.extract    s1, v0, #2
    s.shli       s3, s16, #32
    s.cmp.lt     s11, s18, s4
    v.extract    s16, v2, #3
    s.or         s18, s1, s3
    v.insert     v7, s11, #1
    v.extract    s1, v0, #3
    s.shli       s3, s16, #32
    s.cmp.lt     s11, s18, s4
    v.extract    s16, v2, #4
    s.or         s18, s1, s3
    v.insert     v7, s11, #2
    v.extract    s1, v0, #4
    s.shli       s3, s16, #32
    s.cmp.lt     s11, s18, s4
    v.extract    s16, v2, #5
    s.or         s18, s1, s3
    v.insert     v7, s11, #3
    v.extract    s1, v0, #5
    s.shli       s3, s16, #32
    s.cmp.lt     s11, s18, s4
    v.extract    s4, v2, #6
    s.or         s16, s1, s3
    v.insert     v7, s11, #4
    v.extract    s1, v0, #6
    s.shli       s3, s4, #32
    s.cmp.lt     s4, s16, s5
    v.extract    s5, v2, #7
    s.or         s11, s1, s3
    v.insert     v7, s4, #5
    v.extract    s1, v0, #7
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s11, s6
    v.extract    s5, v2, #8
    s.or         s6, s1, s3
    v.insert     v7, s4, #6
    v.extract    s1, v0, #8
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s7
    v.extract    s5, v2, #9
    s.or         s6, s1, s3
    v.insert     v7, s4, #7
    v.extract    s1, v0, #9
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s8
    v.extract    s5, v2, #10
    s.or         s6, s1, s3
    v.insert     v7, s4, #8
    v.extract    s1, v0, #10
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s9
    v.extract    s5, v2, #11
    s.or         s6, s1, s3
    v.insert     v7, s4, #9
    v.extract    s1, v0, #11
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s10
    v.extract    s5, v2, #12
    s.or         s6, s1, s3
    v.insert     v7, s4, #10
    v.extract    s1, v0, #12
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s12
    v.extract    s5, v2, #13
    s.or         s6, s1, s3
    v.insert     v7, s4, #11
    v.extract    s1, v0, #13
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s13
    v.extract    s5, v2, #14
    s.or         s6, s1, s3
    v.insert     v7, s4, #12
    v.extract    s1, v0, #14
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s14
    v.extract    s5, v2, #15
    v.movi       v2, #4096
    s.or         s6, s1, s3
    v.insert     v7, s4, #13
    v.extract    s1, v0, #15
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s15
    v.add        v0, v11, v2
    v.mul        v2, v12, v5
    s.or         s5, s1, s3
    v.insert     v7, s4, #14
    s.cmp.lt     s1, s5, s17
    v.add        v5, v0, v2
    v.mul        v0, v8, v4
    v.insert     v7, s1, #15
    v.movi       v2, #0
    v.add        v4, v5, v0
    v.movi       v0, #0
    v.cmp.ne     p1, v7, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s19, v4]              // index is in elements (ISA sec 9.1)
    s.add        s1, s20, s2                     // &out_ptr0[...]
    s.add        s3, s21, s2                     // &out_ptr1[...]
    s.add        s4, s22, s2                     // &out_ptr2[...]
    s.add        s5, s23, s2                     // &out_ptr3[...]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s1, #0], v3
    @p1 v.sel        v2, v4, v0
    vf.mul       v0, v2, v9
    v.st.w       [s3, #0], v6
    v.st.w       [s4, #0], v1
    v.st.w       [s5, #0], v0
__rctx_next:
    exit
