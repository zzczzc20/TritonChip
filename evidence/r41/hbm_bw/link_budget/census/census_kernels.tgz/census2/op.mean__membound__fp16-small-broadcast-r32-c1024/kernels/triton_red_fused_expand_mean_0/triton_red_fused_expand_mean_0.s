    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.movi       v0, #0
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #1024
    s.movz       s6, #16
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s7, s2, #0
    s.ld.d       s2, [s1, #8]                    // out_ptr1: device_ptr64 at arg_base+8
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    v.splat      v0, s7
    v.movi       v3, #1024
    s.shli       s1, s7, #1                      // element offset -> bytes (x2)
    v.add        v4, v0, v2
    s.add        s8, s3, s1                      // &in_ptr0[...]
    v.movi       v0, #0
    v.cmp.lt     p1, v4, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s8, #0]
    s.add        s1, s7, s6
    s.movz       s8, #1
    vf.cvt.f16.f32 v4, v3
    vf.add       v3, v1, v4
    @p1 v.sel        v4, v3, v1
    v.mov        v0, v4
    v.mov        v1, v0
    s.mov        s7, s1
    br.nz        s8, for_1
endfor_2:
    .li       s1, #1149239296
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.add.b v3, v1
    v.rcp.approx v1, v0                          // ISA 8.8: <= 2**-22 relative
    v.movi       v4, #0
    s.movz       s1, #1
    s.shli       s3, s4, #1                      // element offset -> bytes (x2)
    vf.add       v5, v3, v4
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s1
    s.add        s1, s2, s3                      // &out_ptr1[...]
    v.cmp.lt     p1, v3, v4
    vf.fms       v3, v0, v1, v2
    vf.fms       v0, v1, v3, v1
    vf.neg       v2, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v0, v2, v1
    vf.mul       v1, v5, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.f16 v0, v1
    @p1 v.st.h       [s1, #0], v0
__rctx_next:
    exit
