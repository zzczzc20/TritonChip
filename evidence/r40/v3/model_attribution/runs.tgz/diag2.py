import json,glob,hashlib,sys
rows=json.load(open('dataset.json'))['rows']
def key(r):
    k={x:y for x,y in sorted(r['knobs'].items())}
    return hashlib.sha256(json.dumps(k,sort_keys=True).encode()).hexdigest()[:10]
pairs={}
for r in rows: pairs.setdefault((r['exp'],r['point']),{})[r['side']]=key(r)
only=sys.argv[1:] 
for (exp,pt),s in pairs.items():
    if only and not any(o in pt for o in only): continue
    out={}
    for side,k in s.items():
        f=glob.glob(f"out/*{pt.split('/')[0].replace('op.','op.')}*{k}/**/summary.json",recursive=True)
        f=[g for g in f if pt.replace('/','__') in g]
        res=glob.glob(f"out/*{k}/results.json")
        if not f: break
        out[side]=json.load(open(f[0]))['counters']
    if len(out)<2: print('==',exp,pt,'incomplete'); continue
    a,b=out['control'],out['candidate']
    print('==',exp,pt)
    rows2=[]
    for kk in set(a)|set(b):
        if not any(kk.startswith(p) for p in ('core_0','home_0','outlet_','core_1','core_2')): continue
        x,y=a.get(kk,0),b.get(kk,0)
        if max(x,y)>2000: rows2.append((abs(y-x),kk,x,y))
    rows2.sort(reverse=True)
    for d,kk,x,y in rows2[:16]:
        print(f"  {kk:46s} {x:>13} {y:>13}  x{(y/x if x else float('inf')):.2f}")
