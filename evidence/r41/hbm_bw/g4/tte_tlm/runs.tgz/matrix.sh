#!/bin/bash
cd ~/r41-tte-runs
P="op.copy/membound/fp32-medium-contig-r1024-c1024 op.add/membound/fp32-medium-contig-r1024-c1024 op.relu/membound/fp32-medium-contig-r1024-c1024 op.clone/membound/fp32-medium-contig-r1024-c1024 op.add/membound/fp16-medium-contig-r2048-c1024 op.copy/membound/fp16-medium-contig-r2048-c1024 op.add/membound/fp32-medium-strided-r1024-c1024"
for a in "mx_pipe_nofill_m2 pipe_nofill.cfg 2" "mx_pipe_line_m3 pipe_line.cfg 3" "mx_pipe_linewc_m3 pipe_linewc.cfg 3" "mx_pipe1_nofill_m2 pipe1_nofill.cfg 2" "mx_pipe1_line_m3 pipe1_line.cfg 3" "mx_pipe_base_m0 pipe_base.cfg 0" "mx_pipe_line_m0 pipe_line.cfg 0"; do set -- $a; rm -rf $1; ./run.sh $1 $2 $3 $P; done
G="op.bmm/small/fp16-b8-m64-k32-n64 op.bmm/medium/fp16-b16-m64-k32-n64"
for a in "gx_pipe_base_m0 pipe_base.cfg 0" "gx_pipe_line_m0 pipe_line.cfg 0"; do set -- $a; rm -rf $1; ./run.sh $1 $2 $3 $G; done
touch MATRIX_DONE
