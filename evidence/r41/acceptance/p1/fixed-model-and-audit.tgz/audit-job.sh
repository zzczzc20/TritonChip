#!/bin/bash
set -euo pipefail
source "$HOME/tc_env/env.sh"
PY="$HOME/tc_env/torchenv/bin/python"
ROOT="$HOME/r41-accept-src"
OUT="$HOME/r41-accept-p1"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 CUDA_VISIBLE_DEVICES=
for profile in core-vrf-sync-v5 core-vrf-sync-v5-x8; do
  tree=$(cd "$ROOT" && "$PY" -c 'from archbench.provenance import software_tree;from pathlib import Path;print(software_tree(Path.cwd(),refresh=True))')
  "$PY" "$OUT/audit_profile.py" "$ROOT" "$profile" run --source-root "$ROOT" --software-tree "$tree" --label "$profile" --out "$OUT/audit-$profile" --jobs 2 --torch-extensions-dir "$OUT/extensions" > "$OUT/audit-$profile.log" 2>&1
done
"$PY" "$ROOT/tools/performance_harness/default_change_audit.py" compare --control "$OUT/audit-core-vrf-sync-v5/report.json" --candidate "$OUT/audit-core-vrf-sync-v5-x8/report.json" --out "$OUT/profile-compare.json" > "$OUT/profile-compare.log" 2>&1
