    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #6
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #127
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    s.rdspecial  s2, arg_base
    @p1 v.sel        v6, v5, v4
    v.movi       v5, #0
    s.ld.d       s3, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.lshr       v7, v6, v3
    v.movi       v3, #0
    v.movi       v6, #63
    v.sub        v8, v2, v7
    v.sub        v9, v3, v4
    v.cmp.lt     p2, v4, v3
    @p1 v.sel        v10, v8, v7
    @p2 v.sel        v7, v9, v4
    v.movi       v8, #64
    v.sub        v9, v0, v10
    v.cmp.lt     p1, v10, v0
    v.and        v11, v7, v6
    @p1 v.sel        v6, v9, v10
    s.ld.d       s4, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.cmp.lt     p3, v4, v5
    v.and        v7, v6, v1
    v.sub        v1, v3, v11
    v.movi       v6, #128
    v.sub        v9, v0, v7
    @p2 v.sel        v12, v1, v11
    v.movi       v1, #8192
    @p1 v.sel        v11, v9, v7
    v.sub        v7, v3, v8
    v.sub        v9, v2, v8
    s.ld.d       s5, [s2, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.sub        v13, v5, v4
    v.sub        v14, v0, v6
    v.cmp.lt     p1, v8, v3
    v.cmp.lt     p2, v8, v2
    @p1 v.sel        v2, v7, v8
    v.cmp.lt     p1, v6, v0
    @p2 v.sel        v0, v9, v8
    v.cmp.lt     p2, v1, v5
    @p1 v.sel        v0, v14, v6
    s.ld.d       s6, [s2, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s7, [s2, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    @p3 v.sel        v0, v13, v4
    v.sub        v2, v5, v1
    s.ld.d       s8, [s2, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    @p2 v.sel        v3, v2, v1
    s.ld.d       s9, [s2, #48]                   // out_ptr0: device_ptr64 at arg_base+48
    .li       s2, #1132462080
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v2, #13
    v.movi       v3, #8
    v.rcp.approx v4, v1                          // ISA 8.8: <= 2**-22 relative
    v.lshr       v6, v0, v2
    v.mul        v0, v11, v3
    .li       s2, #1065353216
    v.splat      v2, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v3, v5, v6
    .li       s2, #897988541
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v7, #512
    @p3 v.sel        v8, v3, v6
    v.movi       v3, #0
    v.movi       v6, #4096
    v.add        v9, v8, v0
    v.mul        v0, v8, v7
    v.sub        v7, v3, v12
    v.ld.gather.w v8, [s3, v9]                   // index is in elements (ISA sec 9.1)
    v.add        v9, v12, v0
    v.mul        v0, v11, v6
    v.cmp.lt     p1, v12, v3
    @p1 v.sel        v6, v7, v12
    v.movi       v7, #31
    v.add        v13, v9, v0
    v.movi       v0, #32
    v.and        v9, v6, v7
    .li       s2, #1077936128
    v.splat      v6, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3204448256
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v14, v3, v9
    v.mul        v15, v11, v0
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    @p1 v.sel        v11, v14, v9
    vf.fms       v9, v1, v4, v2
    s.add        s1, s6, s2                      // &in_ptr4[...]
    v.add        v1, v15, v11
    v.ld.gather.h v2, [s4, v13]                  // index is in elements (ISA sec 9.1)
    v.sub        v11, v3, v0
    vf.fms       v13, v4, v9, v4
    v.cmp.lt     p1, v0, v3
    @p1 v.sel        v3, v11, v0
    vf.neg       v0, v13                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v3, v0, v4
    v.ld.gather.h v0, [s5, v12]                  // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v4, v2
    vf.mul       v2, v8, v3                      // a/y as a refined reciprocal (ISA has no divide)
    .li       s2, #1065353216
    v.splat      v3, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v8, v2, v5
    v.rsqrt.approx v2, v8                        // ISA 8.8: <= 2**-22 relative
    v.ld.h       v5, [s1, #0]
    vf.cvt.bf16.f32 v9, v0
    v.movi       v0, #256
    v.mul        v11, v10, v0
    vf.add       v0, v9, v3
    v.add        v3, v12, v11
    v.ld.gather.w v9, [s7, v1]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v10, v5
    vf.mul       v5, v2, v2
    vf.mul       v11, v2, v7
    vf.fms       v7, v8, v5, v6
    v.ld.gather.w v5, [s8, v1]                   // index is in elements (ISA sec 9.1)
    vf.mul       v1, v11, v7                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v6, v1, v2
    vf.mul       v1, v4, v6
    vf.mul       v2, v1, v0
    vf.mul       v0, v10, v5
    vf.mul       v1, v2, v9
    vf.add       v2, v1, v0
    vf.cvt.f32.bf16 v0, v2
    v.st.scatter.h [s9, v3], v0
__rctx_next:
    exit
