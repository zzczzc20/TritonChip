    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    s.rdspecial  s3, pid.y
    s.rdspecial  s4, role_id
    s.mul        s5, s3, s1
    s.movz       s1, #4160
    v.splat      v1, s2
    s.rdspecial  s2, arg_base
    v.add        v2, v1, v0
    s.mul        s3, s4, s1
    v.movi       v1, #0
    s.ld.d       s1, [s2, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.sub        v3, v1, v2
    v.cmp.lt     p1, v2, v1
    s.add        s2, s1, s3                      // this context's own scratch
    s.movz       s1, #0
    @p1 v.sel        v4, v3, v2
    s.addi       s3, s2, #0
    v.movi       v3, #8
    s.rdspecial  s4, arg_base
    v.movi       v5, #7
    s.addi       s6, s3, #64
    s.addi       s7, s3, #128
    s.addi       s8, s3, #192
    s.addi       s9, s3, #256
    s.addi       s10, s3, #320
    s.addi       s11, s3, #384
    s.addi       s12, s3, #448
    s.addi       s13, s3, #512
    s.addi       s14, s3, #576
    s.addi       s15, s3, #640
    s.addi       s16, s3, #704
    s.addi       s17, s3, #768
    s.addi       s18, s3, #832
    s.addi       s19, s3, #896
    s.addi       s20, s3, #960
    s.addi       s21, s2, #1024
    v.sub        v6, v1, v3
    v.cmp.lt     p2, v3, v1
    s.ld.d       s22, [s4, #0]                   // arg_X: device_ptr64 at arg_base+0
    v.and        v7, v4, v5
    s.movz       s23, #256
    s.ld.d       s23, [s4, #8]                   // arg_W: device_ptr64 at arg_base+8
    v.sub        v4, v1, v7
    s.movz       s24, #36
    s.ld.d       s24, [s4, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    v.movi       v1, #0
    v.movi       v5, #3
    v.sub        v8, v1, v2
    v.cmp.lt     p3, v2, v1
    @p3 v.sel        v9, v8, v2
    v.movi       v2, #0
    v.lshr       v8, v9, v5
    v.movi       v5, #0
    v.sub        v9, v1, v8
    v.movi       v10, #7
    @p3 v.sel        v11, v9, v8
    v.sub        v8, v1, v3
    v.sub        v9, v2, v11
    v.cmp.lt     p3, v11, v2
    v.sub        v12, v5, v11
    s.movz       s4, #9
    @p3 v.sel        v13, v9, v11
    s.movz       s25, #1
    v.movi       v9, #1
    @p2 v.sel        v9, v6, v3
    v.movi       v6, #3
    v.cmp.lt     p2, v11, v5
    v.lshr       v9, v13, v6
    v.movi       v6, #256
    @p2 v.sel        v13, v12, v11
    v.sub        v11, v2, v9
    v.and        v12, v13, v10
    @p3 v.sel        v10, v11, v9
    v.splat      v9, s5
    v.mul        v11, v10, v6
    v.add        v6, v9, v0
    v.extract    s26, v11, #0
    v.extract    s27, v11, #1
    v.splat      v9, s1
    v.cmp.lt     p3, v3, v1
    v.splat      v1, s26
    @p1 v.sel        v13, v4, v7
    v.splat      v4, s27
    v.add        v7, v9, v1
    v.add        v1, v9, v4
    v.cmp.lt     p1, v3, v5
    v.movi       v4, #1
    v.extract    s26, v11, #2
    v.extract    s27, v11, #3
    @p3 v.sel        v4, v8, v3
    v.extract    s28, v11, #4
    v.splat      v4, s26
    v.cmp.lt     p3, v3, v2
    v.sub        v8, v2, v3
    v.add        v2, v9, v4
    v.movi       v4, #1
    v.extract    s26, v11, #5
    v.extract    s29, v11, #6
    v.movi       v4, #1
    @p3 v.sel        v4, v8, v3
    v.splat      v4, s27
    v.st.w       [s3, #0], v7
    v.splat      v7, s28
    v.add        v8, v9, v4
    v.add        v4, v9, v7
    v.st.w       [s6, #0], v1
    v.splat      v1, s26
    v.add        v7, v9, v1
    v.st.w       [s7, #0], v2
    v.sub        v1, v5, v3
    v.sub        v2, v5, v12
    @p1 v.sel        v5, v1, v3
    v.extract    s3, v11, #7
    v.splat      v1, s29
    @p2 v.sel        v5, v2, v12
    v.extract    s6, v11, #8
    v.extract    s7, v11, #9
    v.extract    s26, v11, #10
    v.extract    s27, v11, #11
    v.extract    s28, v11, #12
    v.extract    s29, v11, #13
    v.extract    s30, v11, #14
    v.extract    s31, v11, #15
    v.splat      v2, s3
    v.splat      v11, s6
    v.add        v12, v9, v1
    v.add        v1, v9, v2
    v.add        v2, v9, v11
    v.st.w       [s8, #0], v8
    v.movi       v8, #36
    v.mul        v11, v6, v8
    v.st.w       [s9, #0], v4
    v.splat      v4, s7
    v.add        v8, v9, v4
    v.st.w       [s10, #0], v7
    v.splat      v4, s26
    s.addi       s3, s1, #0
    v.add        v7, v9, v4
    v.st.w       [s11, #0], v12
    v.splat      v4, s27
    v.add        v12, v9, v4
    v.st.w       [s12, #0], v1
    v.splat      v1, s28
    v.add        v4, v9, v1
    v.st.w       [s13, #0], v2
    v.splat      v1, s29
    v.add        v2, v9, v1
    v.st.w       [s14, #0], v8
    v.splat      v1, s30
    v.add        v8, v9, v1
    v.st.w       [s15, #0], v7
    v.splat      v1, s31
    v.add        v7, v9, v1
    v.splat      v1, s1
    v.add        v9, v1, v11
    v.st.w       [s16, #0], v12
    v.st.w       [s17, #0], v4
    v.st.w       [s18, #0], v2
    v.st.w       [s19, #0], v8
    v.st.w       [s20, #0], v7
    fence.acq_rel.device
    v.st.w       [s21, #0], v9
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_1:
    s.cmp.ge     s6, s3, s4
    br.nz        s6, endfor_2
    s.movz       s6, #0
    s.movz       s7, #0
    s.cmp.lt     s8, s3, s6
    s.movz       s6, #0
    s.sub        s9, s7, s8
    .li       s7, #1431655766
    s.xor        s8, s3, s9
    s.movz       s10, #0
    s.sub        s11, s8, s9
    s.cmp.lt     s8, s3, s6
    s.mul        s6, s11, s7
    s.sub        s7, s10, s8
    .li       s8, #1431655766
    s.xor        s10, s3, s7
    s.movz       s12, #3
    s.sub        s13, s10, s7
    s.lshri      s10, s6, #32
    s.mul        s6, s13, s8
    s.sub        s8, s11, s10
    s.movz       s14, #0
    s.lshri      s15, s8, #1
    s.movz       s8, #0
    s.add        s16, s10, s15
    s.lshri      s10, s6, #32
    s.lshri      s6, s16, #1
    s.sub        s15, s13, s10
    s.muli       s16, s6, #3
    s.cmp.lt     s6, s12, s14
    s.lshri      s14, s15, #1
    s.sub        s15, s8, s6
    s.add        s6, s10, s14
    s.xor        s8, s7, s15
    s.lshri      s7, s6, #1
    s.sub        s6, s11, s16
    s.xor        s10, s7, s8
    s.xor        s11, s6, s9
    s.sub        s6, s10, s8
    s.sub        s8, s11, s9
    s.sub        s9, s6, s25
    s.sub        s10, s8, s25
    v.splat      v1, s9
    v.splat      v2, s10
    v.add        v4, v1, v5
    v.add        v1, v2, v13
    v.movi       v2, #32
    v.movi       v7, #4
    v.mul        v8, v4, v2
    s.movz       s9, #4
    s.movz       s10, #0
    s.movz       s11, #0
    s.cmp.lt     s14, s12, s10
    s.muli       s10, s7, #3
    s.sub        s7, s11, s14
    s.xor        s11, s12, s15
    v.mul        v2, v1, v7
    s.xor        s14, s12, s7
    s.sub        s16, s11, s15
    s.addi       s11, s2, #0
    v.extract    s15, v8, #0
    v.ld.w       v9, [s11, #0]
    v.extract    s11, v2, #0
    v.splat      v11, s15
    v.splat      v12, s11
    v.iota       v14                             // arange(0, VLEN)
    v.add        v15, v11, v12
    s.addi       s11, s2, #1088
    s.sub        s15, s13, s10
    v.add        v11, v15, v14
    s.addi       s10, s2, #64
    v.add        v12, v9, v11
    v.extract    s13, v8, #1
    v.st.w       [s11, #0], v12
    v.extract    s15, v2, #1
    v.splat      v9, s13
    v.splat      v11, s15
    s.addi       s13, s11, #64
    v.add        v12, v9, v11
    s.addi       s15, s11, #128
    v.add        v9, v12, v14
    s.sub        s16, s14, s7
    s.addi       s7, s2, #128
    v.ld.w       v11, [s10, #0]
    v.extract    s10, v8, #2
    v.extract    s14, v2, #2
    v.splat      v12, s10
    v.splat      v15, s14
    s.addi       s10, s2, #192
    v.add        v16, v12, v15
    v.extract    s14, v8, #3
    v.add        v12, v16, v14
    v.extract    s16, v2, #3
    v.add        v15, v11, v9
    v.splat      v9, s14
    v.st.w       [s13, #0], v15
    v.splat      v11, s16
    s.addi       s13, s11, #192
    v.add        v15, v9, v11
    s.movz       s14, #32
    v.add        v9, v15, v14
    s.addi       s14, s2, #256
    v.extract    s16, v8, #4
    v.splat      v11, s16
    v.extract    s16, v2, #4
    v.ld.w       v15, [s7, #0]
    v.splat      v16, s16
    s.addi       s7, s11, #256
    v.add        v17, v11, v16
    s.addi       s16, s2, #320
    v.add        v11, v17, v14
    v.add        v16, v15, v12
    v.st.w       [s15, #0], v16
    v.extract    s15, v8, #5
    v.splat      v12, s15
    v.extract    s15, v2, #5
    v.splat      v15, s15
    s.addi       s15, s11, #320
    v.add        v16, v12, v15
    v.add        v12, v16, v14
    v.ld.w       v15, [s10, #0]
    s.addi       s10, s2, #384
    v.add        v16, v15, v9
    v.st.w       [s13, #0], v16
    v.extract    s13, v8, #6
    v.splat      v9, s13
    v.extract    s13, v2, #6
    v.splat      v15, s13
    s.addi       s13, s11, #384
    v.add        v16, v9, v15
    v.add        v9, v16, v14
    v.ld.w       v15, [s14, #0]
    s.addi       s14, s2, #448
    v.add        v16, v15, v11
    v.st.w       [s7, #0], v16
    v.extract    s7, v8, #7
    v.splat      v11, s7
    v.extract    s7, v2, #7
    v.splat      v15, s7
    s.addi       s7, s11, #448
    v.add        v16, v11, v15
    v.add        v11, v16, v14
    v.ld.w       v15, [s16, #0]
    s.addi       s16, s2, #512
    v.add        v16, v15, v12
    v.st.w       [s15, #0], v16
    v.extract    s15, v8, #8
    v.splat      v12, s15
    v.extract    s15, v2, #8
    v.splat      v15, s15
    s.addi       s15, s11, #512
    v.add        v16, v12, v15
    v.add        v12, v16, v14
    v.ld.w       v15, [s10, #0]
    s.addi       s10, s2, #576
    v.add        v16, v15, v9
    v.st.w       [s13, #0], v16
    v.extract    s13, v8, #9
    v.splat      v9, s13
    v.extract    s13, v2, #9
    v.splat      v15, s13
    s.addi       s13, s11, #576
    v.add        v16, v9, v15
    v.add        v9, v16, v14
    v.ld.w       v15, [s14, #0]
    s.addi       s14, s2, #640
    v.add        v16, v15, v11
    v.st.w       [s7, #0], v16
    v.extract    s7, v8, #10
    v.splat      v11, s7
    v.extract    s7, v2, #10
    v.splat      v15, s7
    s.addi       s7, s11, #640
    v.add        v16, v11, v15
    v.add        v11, v16, v14
    v.ld.w       v15, [s16, #0]
    s.addi       s16, s2, #704
    v.add        v16, v15, v12
    v.st.w       [s15, #0], v16
    v.extract    s15, v8, #11
    v.splat      v12, s15
    v.extract    s15, v2, #11
    v.splat      v15, s15
    s.addi       s15, s11, #704
    v.add        v16, v12, v15
    v.add        v12, v16, v14
    v.ld.w       v15, [s10, #0]
    s.addi       s10, s2, #768
    v.add        v16, v15, v9
    v.st.w       [s13, #0], v16
    v.extract    s13, v8, #12
    v.splat      v9, s13
    v.extract    s13, v2, #12
    v.splat      v15, s13
    s.addi       s13, s11, #768
    v.add        v16, v9, v15
    v.add        v9, v16, v14
    v.ld.w       v15, [s14, #0]
    s.addi       s14, s2, #832
    v.add        v16, v15, v11
    v.st.w       [s7, #0], v16
    v.extract    s7, v8, #13
    v.splat      v11, s7
    v.extract    s7, v2, #13
    v.splat      v15, s7
    s.addi       s7, s11, #832
    v.add        v16, v11, v15
    v.add        v11, v16, v14
    v.ld.w       v15, [s16, #0]
    s.addi       s16, s2, #896
    v.movi       v16, #1
    v.add        v17, v15, v12
    v.cmp.lt     p1, v10, v16
    v.st.w       [s15, #0], v17
    v.extract    s15, v8, #14
    v.splat      v12, s15
    v.extract    s15, v2, #14
    v.splat      v15, s15
    s.addi       s15, s11, #896
    v.add        v16, v12, v15
    v.movi       v12, #1
    v.add        v15, v16, v14
    v.movi       v16, #0
    v.ld.w       v17, [s10, #0]
    s.addi       s10, s2, #960
    v.movi       v18, #0
    @p1 v.sel        v19, v12, v16
    v.movi       v12, #1
    v.cmp.ge     p1, v4, v18
    v.cmp.lt     p2, v4, v3
    v.movi       v4, #0
    s.addi       s17, s11, #960
    @p1 v.sel        v16, v12, v4
    v.add        v4, v17, v9
    v.movi       v9, #1
    v.st.w       [s13, #0], v4
    v.extract    s11, v8, #15
    v.splat      v4, s11
    v.extract    s11, v2, #15
    v.splat      v2, s11
    v.movi       v8, #0
    v.add        v12, v4, v2
    @p2 v.sel        v2, v9, v8
    v.add        v4, v12, v14
    v.movi       v8, #1
    v.ld.w       v9, [s14, #0]
    v.movi       v12, #0
    v.cmp.ge     p1, v1, v18
    @p1 v.sel        v17, v8, v12
    v.movi       v8, #1
    v.movi       v12, #0
    v.cmp.lt     p1, v1, v3
    @p1 v.sel        v1, v8, v12
    v.cmp.lt     p1, v0, v7
    v.add        v7, v9, v11
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s11, #0
    v.st.w       [s7, #0], v7
    v.extract    s7, v19, #0
    s.addi       s13, s2, #1088
    v.ld.w       v7, [s16, #0]
    v.extract    s14, v16, #0
    v.splat      v8, s7
    v.movi       v9, #0
    v.splat      v11, s14
    v.movi       v12, #0
    v.cmp.ne     p2, v8, v9
    v.cmp.ne     p3, v11, v12
    v.add        v8, v7, v15
    p.and        p4, p2, p3
    v.st.w       [s15, #0], v8
    v.extract    s7, v2, #0
    v.splat      v7, s7
    v.movi       v8, #0
    v.ld.w       v9, [s10, #0]
    v.extract    s7, v17, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s7
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v7, v8
    p.and        p4, p3, p2
    v.add        v7, v9, v4
    v.extract    s7, v1, #0
    v.st.w       [s17, #0], v7
    fence.acq_rel.device
    v.splat      v4, s7
    v.movi       v7, #0
    v.extract    s7, v19, #1
    v.cmp.ne     p2, v4, v7
    p.and        p3, p4, p2
    v.extract    s10, v16, #1
    p.and        p2, p3, p1
    v.splat      v4, s7
    v.ld.w       v7, [s13, #0]
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.addi       s7, s2, #1152
    v.extract    s10, v2, #1
    v.cmp.ne     p3, v4, v8
    v.cmp.ne     p4, v9, v11
    v.splat      v4, s10
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s22, v7]              // index is in elements (ISA sec 9.1)
    p.and        p2, p3, p4
    v.extract    s10, v17, #1
    v.cmp.ne     p3, v4, v8
    v.splat      v4, s10
    v.movi       v7, #0
    p.and        p4, p2, p3
    v.extract    s10, v1, #1
    v.cmp.ne     p2, v4, v7
    v.splat      v4, s10
    a.vwrite     a1, s11, v9
    v.ld.w       v7, [s7, #0]
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v4, v8
    p.and        p4, p3, p2
    v.extract    s7, v19, #2
    p.and        p2, p4, p1
    v.extract    s10, v16, #2
    v.splat      v4, s7
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s22, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s10
    v.movi       v11, #0
    s.movz       s7, #1
    s.addi       s10, s2, #1216
    v.extract    s11, v2, #2
    v.cmp.ne     p2, v4, v8
    v.cmp.ne     p3, v7, v11
    v.splat      v4, s11
    v.movi       v7, #0
    a.vwrite     a1, s7, v9
    v.ld.w       v8, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s7, v17, #2
    v.cmp.ne     p2, v4, v7
    v.splat      v4, s7
    v.movi       v7, #0
    p.and        p3, p4, p2
    v.extract    s7, v1, #2
    v.cmp.ne     p2, v4, v7
    v.splat      v4, s7
    v.movi       v7, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v7
    p.and        p3, p4, p2
    v.extract    s7, v19, #3
    p.and        p2, p3, p1
    v.extract    s10, v16, #3
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s22, v8]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s7
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s7, #2
    s.addi       s10, s2, #1280
    v.extract    s11, v2, #3
    v.cmp.ne     p2, v7, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v7, s11
    v.movi       v8, #0
    a.vwrite     a1, s7, v4
    v.ld.w       v4, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s7, v17, #3
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s7
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s7, v1, #3
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s7
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    v.extract    s7, v19, #4
    p.and        p2, p3, p1
    v.extract    s10, v16, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s22, v4]              // index is in elements (ISA sec 9.1)
    v.splat      v4, s7
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s7, #3
    s.addi       s10, s2, #1344
    v.extract    s11, v2, #4
    v.cmp.ne     p2, v4, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v4, s11
    v.movi       v8, #0
    a.vwrite     a1, s7, v7
    v.ld.w       v7, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s7, v17, #4
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s7
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s7, v1, #4
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s7
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v8
    p.and        p3, p4, p2
    v.extract    s7, v19, #5
    p.and        p2, p3, p1
    v.extract    s10, v16, #5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s22, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s7
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s7, #4
    s.addi       s10, s2, #1408
    v.extract    s11, v2, #5
    v.cmp.ne     p2, v7, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v7, s11
    v.movi       v8, #0
    a.vwrite     a1, s7, v4
    v.ld.w       v4, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s7, v17, #5
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s7
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s7, v1, #5
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s7
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    v.extract    s7, v19, #6
    p.and        p2, p3, p1
    v.extract    s10, v16, #6
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s22, v4]              // index is in elements (ISA sec 9.1)
    v.splat      v4, s7
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s7, #5
    s.addi       s10, s2, #1472
    v.extract    s11, v2, #6
    v.cmp.ne     p2, v4, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v4, s11
    v.movi       v8, #0
    a.vwrite     a1, s7, v7
    v.ld.w       v7, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s7, v17, #6
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s7
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s7, v1, #6
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s7
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v8
    p.and        p3, p4, p2
    v.extract    s7, v19, #7
    p.and        p2, p3, p1
    v.extract    s10, v16, #7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s22, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s7
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s7, #6
    s.addi       s10, s2, #1536
    v.extract    s11, v2, #7
    v.cmp.ne     p2, v7, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v7, s11
    v.movi       v8, #0
    a.vwrite     a1, s7, v4
    v.ld.w       v4, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s7, v17, #7
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s7
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s7, v1, #7
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s7
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    v.extract    s7, v19, #8
    p.and        p2, p3, p1
    v.extract    s10, v16, #8
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s22, v4]              // index is in elements (ISA sec 9.1)
    v.splat      v4, s7
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s7, #7
    s.addi       s10, s2, #1600
    v.extract    s11, v2, #8
    v.cmp.ne     p2, v4, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v4, s11
    v.movi       v8, #0
    a.vwrite     a1, s7, v7
    v.ld.w       v7, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s7, v17, #8
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s7
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s7, v1, #8
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s7
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v8
    p.and        p3, p4, p2
    v.extract    s7, v19, #9
    p.and        p2, p3, p1
    v.extract    s10, v16, #9
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s22, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s7
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s7, #8
    s.addi       s10, s2, #1664
    v.extract    s11, v2, #9
    v.cmp.ne     p2, v7, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v7, s11
    v.movi       v8, #0
    a.vwrite     a1, s7, v4
    v.ld.w       v4, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s7, v17, #9
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s7
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s7, v1, #9
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s7
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    v.extract    s7, v19, #10
    p.and        p2, p3, p1
    v.extract    s10, v16, #10
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s22, v4]              // index is in elements (ISA sec 9.1)
    v.splat      v4, s7
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s7, #9
    s.addi       s10, s2, #1728
    v.extract    s11, v2, #10
    v.cmp.ne     p2, v4, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v4, s11
    v.movi       v8, #0
    a.vwrite     a1, s7, v7
    v.ld.w       v7, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s7, v17, #10
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s7
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s7, v1, #10
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s7
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v8
    p.and        p3, p4, p2
    v.extract    s7, v19, #11
    p.and        p2, p3, p1
    v.extract    s10, v16, #11
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s22, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s7
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s7, #10
    s.addi       s10, s2, #1792
    v.extract    s11, v2, #11
    v.cmp.ne     p2, v7, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v7, s11
    v.movi       v8, #0
    a.vwrite     a1, s7, v4
    v.ld.w       v4, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s7, v17, #11
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s7
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s7, v1, #11
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s7
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    v.extract    s7, v19, #12
    p.and        p2, p3, p1
    v.extract    s10, v16, #12
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s22, v4]              // index is in elements (ISA sec 9.1)
    v.splat      v4, s7
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s7, #11
    s.addi       s10, s2, #1856
    v.extract    s11, v2, #12
    v.cmp.ne     p2, v4, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v4, s11
    v.movi       v8, #0
    a.vwrite     a1, s7, v7
    v.ld.w       v7, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s7, v17, #12
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s7
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s7, v1, #12
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s7
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v8
    p.and        p3, p4, p2
    v.extract    s7, v19, #13
    p.and        p2, p3, p1
    v.extract    s10, v16, #13
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s22, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s7
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s7, #12
    s.addi       s10, s2, #1920
    v.extract    s11, v2, #13
    v.cmp.ne     p2, v7, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v7, s11
    v.movi       v8, #0
    a.vwrite     a1, s7, v4
    v.ld.w       v4, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s7, v17, #13
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s7
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s7, v1, #13
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s7
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    v.extract    s7, v19, #14
    p.and        p2, p3, p1
    v.extract    s10, v16, #14
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s22, v4]              // index is in elements (ISA sec 9.1)
    v.splat      v4, s7
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s7, #13
    s.addi       s10, s2, #1984
    v.extract    s11, v2, #14
    v.cmp.ne     p2, v4, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v4, s11
    v.movi       v8, #0
    a.vwrite     a1, s7, v7
    v.ld.w       v7, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s7, v17, #14
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s7
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s7, v1, #14
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s7
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v4, v8
    p.and        p3, p4, p2
    v.extract    s7, v19, #15
    p.and        p2, p3, p1
    v.extract    s10, v16, #15
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s22, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s7
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s7, #14
    s.addi       s10, s2, #2048
    v.extract    s11, v2, #15
    v.cmp.ne     p2, v7, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v2, s11
    v.movi       v7, #0
    a.vwrite     a1, s7, v4
    v.ld.w       v4, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s7, v17, #15
    v.cmp.ne     p2, v2, v7
    v.splat      v2, s7
    v.movi       v7, #0
    p.and        p3, p4, p2
    v.extract    s7, v1, #15
    v.cmp.ne     p2, v2, v7
    v.splat      v1, s7
    v.movi       v2, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v2
    p.and        p3, p4, p2
    s.movz       s7, #12
    p.and        p2, p3, p1
    s.movz       s10, #15
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s22, v4]              // index is in elements (ISA sec 9.1)
    s.addi       s11, s2, #1024
    s.mul        s13, s6, s7
    s.mul        s6, s8, s9
    s.movz       s8, #0
    s.addi       s14, s2, #2112
    s.addi       s15, s2, #1024
    s.add        s16, s8, s13                    // the tile origin
    s.addi       s8, s14, #64
    s.add        s13, s16, s6                    // the tile origin
    a.vwrite     a1, s10, v1
    v.ld.w       v1, [s11, #0]
    v.splat      v2, s13
    s.addi       s6, s13, #1
    s.addi       s10, s2, #1024
    v.splat      v4, s6
    s.addi       s6, s13, #2
    s.addi       s11, s14, #128
    v.splat      v7, s6
    s.addi       s6, s2, #1024
    s.addi       s16, s13, #3
    v.add        v8, v1, v2
    v.splat      v1, s16
    v.st.w       [s14, #0], v8
    s.addi       s16, s14, #192
    s.addi       s17, s2, #1024
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s13, #4
    v.splat      v8, s15
    s.addi       s15, s14, #256
    v.add        v9, v2, v4
    v.st.w       [s8, #0], v9
    s.addi       s8, s2, #1024
    v.ld.w       v2, [s10, #0]
    s.addi       s10, s13, #5
    v.splat      v4, s10
    s.addi       s10, s14, #320
    v.add        v9, v2, v7
    v.st.w       [s11, #0], v9
    s.addi       s11, s2, #1024
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s13, #6
    v.splat      v7, s6
    s.addi       s6, s14, #384
    v.add        v9, v2, v1
    v.st.w       [s16, #0], v9
    s.addi       s16, s2, #1024
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s13, #7
    v.splat      v2, s17
    s.addi       s17, s14, #448
    v.add        v9, v1, v8
    v.st.w       [s15, #0], v9
    s.addi       s15, s2, #1024
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s13, #8
    v.splat      v8, s8
    s.addi       s8, s14, #512
    v.add        v9, v1, v4
    v.st.w       [s10, #0], v9
    s.addi       s10, s2, #1024
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s13, #9
    v.splat      v4, s11
    s.addi       s11, s14, #576
    v.add        v9, v1, v7
    v.st.w       [s6, #0], v9
    s.addi       s6, s2, #1024
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s13, #10
    v.splat      v7, s16
    s.addi       s16, s14, #640
    v.add        v9, v1, v2
    v.st.w       [s17, #0], v9
    s.addi       s17, s2, #1024
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s13, #11
    v.splat      v2, s15
    s.addi       s15, s14, #704
    v.add        v9, v1, v8
    v.st.w       [s8, #0], v9
    s.addi       s8, s2, #1024
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s13, #12
    v.splat      v8, s10
    s.addi       s10, s14, #768
    v.add        v9, v1, v4
    v.splat      v1, s1
    v.st.w       [s11, #0], v9
    s.addi       s11, s2, #1024
    v.splat      v4, s9
    v.cmp.lt     p1, v1, v4
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s13, #13
    v.splat      v9, s6
    s.addi       s6, s14, #832
    v.add        v11, v1, v7
    v.st.w       [s16, #0], v11
    s.addi       s16, s2, #1024
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s13, #14
    s.addi       s18, s13, #15
    v.splat      v7, s17
    s.addi       s13, s14, #896
    v.splat      v11, s18
    s.addi       s17, s2, #1024
    s.addi       s18, s14, #960
    v.add        v12, v1, v2
    v.st.w       [s15, #0], v12
    s.addi       s14, s2, #2112
    v.splat      v1, s25
    v.cmp.lt     p2, v1, v4
    v.ld.w       v1, [s8, #0]
    s.movz       s8, #0
    s.add        s15, s8, s5                     // the tile origin
    v.splat      v2, s15
    s.movz       s8, #8
    v.add        v12, v14, v2
    v.splat      v2, s8
    v.add        v14, v1, v8
    v.cmp.lt     p3, v12, v2
    v.st.w       [s10, #0], v14
    p.and        p4, p1, p3
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s10, #0
    p.and        p1, p2, p3
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s2, #2176
    v.add        v2, v1, v9
    v.st.w       [s6, #0], v2
    s.movz       s6, #1
    v.ld.w       v1, [s16, #0]
    s.addi       s15, s2, #2240
    v.splat      v2, s12
    s.movz       s12, #2
    v.cmp.lt     p2, v2, v4
    v.splat      v2, s12
    s.movz       s12, #2
    v.add        v8, v1, v7
    p.and        p5, p2, p3
    v.st.w       [s13, #0], v8
    s.addi       s13, s2, #2304
    v.ld.w       v1, [s17, #0]
    s.movz       s16, #3
    v.splat      v7, s9
    s.addi       s9, s2, #2368
    v.add        v8, v1, v11
    v.st.w       [s18, #0], v8
    fence.acq_rel.device
    s.movz       s17, #4
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s2, #2432
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s23, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v4
    p.and        p4, p2, p3
    a.vwrite     a2, s10, v8
    v.ld.w       v1, [s11, #0]
    s.movz       s10, #5
    s.movz       s11, #5
    v.splat      v2, s10
    s.addi       s10, s2, #2496
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s23, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v4
    p.and        p2, p1, p3
    a.vwrite     a2, s6, v8
    v.ld.w       v1, [s15, #0]
    s.movz       s6, #6
    s.movz       s15, #6
    v.splat      v7, s6
    s.addi       s6, s2, #2560
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v8, [s23, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p3
    v.splat      v1, s8
    s.movz       s8, #7
    v.splat      v2, s8
    s.movz       s8, #7
    a.vwrite     a2, s12, v8
    v.ld.w       v8, [s13, #0]
    s.addi       s12, s2, #2624
    s.movz       s13, #8
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v9, [s23, v8]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v4
    p.and        p5, p1, p3
    v.splat      v7, s4
    s.addi       s18, s2, #2688
    a.vwrite     a2, s16, v9
    v.ld.w       v8, [s9, #0]
    s.movz       s9, #9
    s.addi       s16, s2, #2752
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s23, v8]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v4
    p.and        p2, p1, p3
    a.vwrite     a2, s17, v9
    v.ld.w       v2, [s14, #0]
    s.movz       s14, #10
    s.movz       s17, #10
    v.splat      v8, s14
    s.addi       s14, s2, #2816
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v9, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p3
    a.vwrite     a2, s11, v9
    v.ld.w       v1, [s10, #0]
    s.movz       s10, #11
    s.movz       s11, #11
    v.splat      v2, s10
    s.addi       s10, s2, #2880
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v9, [s23, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v4
    p.and        p5, p1, p3
    v.splat      v1, s7
    s.movz       s7, #12
    a.vwrite     a2, s15, v9
    v.ld.w       v7, [s6, #0]
    s.addi       s6, s2, #2944
    s.movz       s15, #13
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s23, v7]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v8, v4
    p.and        p2, p1, p3
    v.splat      v7, s15
    s.movz       s15, #13
    a.vwrite     a2, s8, v9
    v.ld.w       v8, [s12, #0]
    s.addi       s8, s2, #3008
    s.movz       s12, #14
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v9, [s23, v8]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p3
    a.vwrite     a2, s13, v9
    v.ld.w       v2, [s18, #0]
    s.movz       s13, #14
    s.addi       s18, s2, #3072
    v.splat      v8, s13
    s.movz       s13, #15
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v9, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v4
    p.and        p5, p1, p3
    a.vwrite     a2, s9, v9
    v.ld.w       v1, [s16, #0]
    s.movz       s9, #15
    v.movi       v2, #0
    v.splat      v9, s9
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s9, #0
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s23, v1]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v4
    p.and        p2, p1, p3
    s.movz       s16, #0
    a.vwrite     a2, s17, v11
    v.ld.w       v1, [s14, #0]
    s.movz       s14, #0
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v7, [s23, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v8, v4
    p.and        p4, p1, p3
    s.movz       s17, #1
    a.vwrite     a2, s11, v7
    v.ld.w       v1, [s10, #0]
    s.movz       s10, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v7, [s23, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v9, v4
    p.and        p5, p1, p3
    a.vwrite     a2, s7, v7
    v.ld.w       v1, [s6, #0]
    s.movz       s6, #3
    s.movz       s7, #4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s23, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v4
    v.ld.w       v1, [s8, #0]
    s.movz       s8, #5
    s.movz       s11, #6
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s23, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s12, v4
    v.ld.w       v1, [s18, #0]
    s.movz       s12, #7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s23, v1]              // index is in elements (ISA sec 9.1)
    s.movz       s15, #8
    a.vwrite     a2, s13, v4
    a.vread      v1, a1, s16
    a.vread      v4, a2, s14
    v.extract    s13, v1, #0
    v.splat      v7, s13
    v.extract    s13, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s13
    a.vread      v7, a2, s17
    v.extract    s13, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s13
    a.vread      v7, a2, s10
    v.extract    s10, v1, #3
    vf.fma       v8, v4, v7, v9
    v.splat      v4, s10
    a.vread      v7, a2, s6
    v.extract    s6, v1, #4
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s7
    v.extract    s6, v1, #5
    vf.fma       v8, v4, v7, v9
    v.splat      v4, s6
    a.vread      v7, a2, s8
    v.extract    s6, v1, #6
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s11
    v.extract    s6, v1, #7
    vf.fma       v8, v4, v7, v9
    v.splat      v4, s6
    a.vread      v7, a2, s12
    v.extract    s6, v1, #8
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s15
    s.movz       s6, #9
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #9
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #10
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #11
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #12
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #13
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #14
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #15
    v.splat      v1, s7
    a.vread      v4, a2, s6
    s.movz       s6, #1
    vf.fma       v7, v1, v4, v8
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s10, #2
    a.vwrite     a3, s9, v7
    a.vread      v1, a1, s6
    a.vread      v4, a2, s7
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s6
    a.vread      v7, a2, s8
    v.extract    s6, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #3
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #4
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #5
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #6
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #7
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #8
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #1
    vf.fma       v8, v4, v7, v9
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #10
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #11
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #12
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #13
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #14
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v4, a2, s7
    s.movz       s7, #2
    vf.fma       v7, v1, v4, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s6, v7
    a.vread      v1, a1, s7
    a.vread      v4, a2, s8
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s6
    a.vread      v7, a2, s9
    v.extract    s6, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #3
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #4
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #5
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #6
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #7
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #8
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #2
    vf.fma       v8, v4, v7, v9
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #10
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #11
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #12
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #13
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #14
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v4, a2, s7
    s.movz       s7, #3
    vf.fma       v7, v1, v4, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s6, v7
    a.vread      v1, a1, s7
    a.vread      v4, a2, s8
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s6
    a.vread      v7, a2, s9
    v.extract    s6, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #3
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #4
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #5
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #6
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #7
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #8
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #10
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #11
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #12
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #13
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #14
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v4, a2, s7
    s.movz       s7, #4
    vf.fma       v7, v1, v4, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s6, v7
    a.vread      v1, a1, s7
    a.vread      v4, a2, s8
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s6
    a.vread      v7, a2, s9
    v.extract    s6, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #3
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #4
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #5
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #6
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #7
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #8
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v8, v4, v7, v9
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #10
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #11
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #12
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #13
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #14
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v4, a2, s7
    s.movz       s7, #5
    vf.fma       v7, v1, v4, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s6, v7
    a.vread      v1, a1, s7
    a.vread      v4, a2, s8
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s6
    a.vread      v7, a2, s9
    v.extract    s6, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #3
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #4
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #5
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #6
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #7
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #8
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #10
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #11
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #12
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #13
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #14
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v4, a2, s7
    s.movz       s7, #6
    vf.fma       v7, v1, v4, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s6, v7
    a.vread      v1, a1, s7
    a.vread      v4, a2, s8
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s6
    a.vread      v7, a2, s9
    v.extract    s6, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #3
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #4
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #5
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #6
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #7
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #8
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v8, v4, v7, v9
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #10
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #11
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #12
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #13
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #14
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v4, a2, s7
    s.movz       s7, #7
    vf.fma       v7, v1, v4, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s6, v7
    a.vread      v1, a1, s7
    a.vread      v4, a2, s8
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s6
    a.vread      v7, a2, s9
    v.extract    s6, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #3
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #4
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #5
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #6
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #7
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #8
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #10
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #11
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #12
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #13
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #14
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v4, a2, s7
    s.movz       s7, #8
    vf.fma       v7, v1, v4, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s6, v7
    a.vread      v1, a1, s7
    a.vread      v4, a2, s8
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s6
    a.vread      v7, a2, s9
    v.extract    s6, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #3
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #4
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #5
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #6
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #7
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #8
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v8, v4, v7, v9
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #10
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #11
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #12
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #13
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #14
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v4, a2, s7
    s.movz       s7, #9
    vf.fma       v7, v1, v4, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s6, v7
    a.vread      v1, a1, s7
    a.vread      v4, a2, s8
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s6
    a.vread      v7, a2, s9
    v.extract    s6, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #3
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #4
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #5
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #6
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #7
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #8
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #9
    vf.fma       v8, v4, v7, v9
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #10
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #11
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #12
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #13
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #14
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v1, v4, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s6, v7
    a.vread      v1, a1, s7
    a.vread      v4, a2, s8
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s6
    a.vread      v7, a2, s9
    v.extract    s6, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #3
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #4
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #5
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #6
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #7
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #8
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #10
    vf.fma       v8, v4, v7, v9
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #10
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #11
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #12
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #13
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #14
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v7, v1, v4, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s6, v7
    a.vread      v1, a1, s7
    a.vread      v4, a2, s8
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s6
    a.vread      v7, a2, s9
    v.extract    s6, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #3
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #4
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #5
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #6
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #7
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #8
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #11
    vf.fma       v8, v4, v7, v9
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #10
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #11
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #12
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #13
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #14
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v1, v4, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s6, v7
    a.vread      v1, a1, s7
    a.vread      v4, a2, s8
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s6
    a.vread      v7, a2, s9
    v.extract    s6, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #3
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #4
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #5
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #6
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #7
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #8
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #12
    vf.fma       v8, v4, v7, v9
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #10
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #11
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #12
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #13
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #14
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v7, v1, v4, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s6, v7
    a.vread      v1, a1, s7
    a.vread      v4, a2, s8
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s6
    a.vread      v7, a2, s9
    v.extract    s6, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #3
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #4
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #5
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #6
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #7
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #8
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #13
    vf.fma       v8, v4, v7, v9
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #10
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #11
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #12
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #13
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #14
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v1, v4, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s6, v7
    a.vread      v1, a1, s7
    a.vread      v4, a2, s8
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v4, s6
    a.vread      v7, a2, s9
    v.extract    s6, v1, #2
    vf.fma       v9, v4, v7, v8
    v.splat      v4, s6
    a.vread      v7, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #3
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #4
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #4
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #5
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #6
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #6
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v4, v7, v9
    v.extract    s7, v1, #7
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #8
    vf.fma       v9, v4, v7, v8
    v.extract    s7, v1, #8
    v.splat      v4, s7
    a.vread      v7, a2, s6
    s.movz       s6, #14
    vf.fma       v8, v4, v7, v9
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #10
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #10
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #11
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #12
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #12
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #13
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #14
    vf.fma       v9, v4, v7, v8
    v.extract    s8, v1, #14
    v.splat      v4, s8
    a.vread      v7, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v4, v7, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v7, v1, v4, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s6, v7
    a.vread      v1, a1, s7
    a.vread      v4, a2, s8
    v.extract    s6, v1, #0
    v.splat      v7, s6
    v.extract    s6, v1, #1
    vf.fma       v8, v7, v4, v2
    v.splat      v2, s6
    a.vread      v4, a2, s9
    v.extract    s6, v1, #2
    vf.fma       v7, v2, v4, v8
    v.splat      v2, s6
    a.vread      v4, a2, s10
    s.movz       s6, #3
    vf.fma       v8, v2, v4, v7
    v.extract    s7, v1, #3
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #4
    vf.fma       v7, v2, v4, v8
    v.extract    s7, v1, #4
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #5
    vf.fma       v8, v2, v4, v7
    v.extract    s7, v1, #5
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #6
    vf.fma       v7, v2, v4, v8
    v.extract    s7, v1, #6
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #7
    vf.fma       v8, v2, v4, v7
    v.extract    s7, v1, #7
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #8
    vf.fma       v7, v2, v4, v8
    v.extract    s7, v1, #8
    v.splat      v2, s7
    a.vread      v4, a2, s6
    s.movz       s6, #15
    vf.fma       v8, v2, v4, v7
    s.movz       s7, #9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #10
    vf.fma       v7, v2, v4, v8
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #11
    vf.fma       v8, v2, v4, v7
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #12
    vf.fma       v7, v2, v4, v8
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #13
    vf.fma       v8, v2, v4, v7
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #14
    vf.fma       v7, v2, v4, v8
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s7
    s.movz       s7, #15
    vf.fma       v8, v2, v4, v7
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s7
    s.movz       s7, #0
    vf.fma       v4, v1, v2, v8
    s.movz       s8, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s9, #0
    s.movz       s10, #1
    a.vwrite     a3, s6, v4
    a.vread      v1, a0, s7
    a.vread      v2, a3, s8
    s.movz       s6, #1
    vf.add       v4, v1, v2
    s.movz       s7, #1
    s.movz       s8, #2
    s.movz       s11, #2
    a.vwrite     a4, s9, v4
    a.vread      v1, a0, s10
    a.vread      v2, a3, s6
    s.movz       s6, #2
    vf.add       v4, v1, v2
    s.movz       s9, #3
    s.movz       s10, #3
    s.movz       s12, #3
    a.vwrite     a4, s7, v4
    a.vread      v1, a0, s8
    a.vread      v2, a3, s11
    s.movz       s7, #4
    vf.add       v4, v1, v2
    s.movz       s8, #4
    s.movz       s11, #4
    s.movz       s13, #5
    a.vwrite     a4, s6, v4
    a.vread      v1, a0, s9
    a.vread      v2, a3, s10
    s.movz       s6, #5
    vf.add       v4, v1, v2
    s.movz       s9, #5
    s.movz       s10, #6
    s.movz       s14, #6
    a.vwrite     a4, s12, v4
    a.vread      v1, a0, s7
    a.vread      v2, a3, s8
    s.movz       s7, #6
    vf.add       v4, v1, v2
    s.movz       s8, #7
    s.movz       s12, #7
    s.movz       s15, #7
    a.vwrite     a4, s11, v4
    a.vread      v1, a0, s13
    a.vread      v2, a3, s6
    s.movz       s6, #8
    vf.add       v4, v1, v2
    s.movz       s11, #8
    s.movz       s13, #8
    s.movz       s16, #9
    a.vwrite     a4, s9, v4
    a.vread      v1, a0, s10
    a.vread      v2, a3, s14
    s.movz       s9, #9
    vf.add       v4, v1, v2
    s.movz       s10, #9
    s.movz       s14, #10
    s.movz       s17, #10
    a.vwrite     a4, s7, v4
    a.vread      v1, a0, s8
    a.vread      v2, a3, s12
    s.movz       s7, #10
    vf.add       v4, v1, v2
    s.movz       s8, #11
    s.movz       s12, #11
    s.movz       s18, #11
    a.vwrite     a4, s15, v4
    a.vread      v1, a0, s6
    a.vread      v2, a3, s11
    s.movz       s6, #12
    vf.add       v4, v1, v2
    s.movz       s11, #12
    s.movz       s15, #12
    s.movz       s19, #13
    a.vwrite     a4, s13, v4
    a.vread      v1, a0, s16
    a.vread      v2, a3, s9
    s.movz       s9, #13
    vf.add       v4, v1, v2
    s.movz       s13, #13
    s.movz       s16, #14
    a.vwrite     a4, s10, v4
    a.vread      v1, a0, s14
    a.vread      v2, a3, s17
    s.movz       s10, #14
    vf.add       v4, v1, v2
    s.movz       s14, #14
    s.movz       s17, #15
    a.vwrite     a4, s7, v4
    a.vread      v1, a0, s8
    a.vread      v2, a3, s12
    s.movz       s7, #15
    vf.add       v4, v1, v2
    s.movz       s8, #15
    s.movz       s12, #0
    a.vwrite     a4, s18, v4
    a.vread      v1, a0, s6
    a.vread      v2, a3, s11
    s.movz       s6, #0
    vf.add       v4, v1, v2
    s.movz       s11, #1
    s.movz       s18, #1
    a.vwrite     a4, s15, v4
    a.vread      v1, a0, s19
    a.vread      v2, a3, s9
    s.movz       s9, #2
    vf.add       v4, v1, v2
    s.movz       s15, #2
    s.movz       s19, #3
    a.vwrite     a4, s13, v4
    a.vread      v1, a0, s16
    a.vread      v2, a3, s10
    s.movz       s10, #3
    vf.add       v4, v1, v2
    s.movz       s13, #4
    s.movz       s16, #4
    a.vwrite     a4, s14, v4
    a.vread      v1, a0, s17
    a.vread      v2, a3, s7
    s.movz       s7, #5
    vf.add       v4, v1, v2
    s.movz       s14, #5
    s.movz       s17, #6
    a.vwrite     a4, s8, v4
    a.vread      v1, a4, s12
    s.movz       s8, #6
    a.vwrite     a0, s6, v1
    a.vread      v1, a4, s11
    s.movz       s6, #7
    a.vwrite     a0, s18, v1
    a.vread      v1, a4, s9
    s.movz       s9, #7
    a.vwrite     a0, s15, v1
    a.vread      v1, a4, s19
    s.movz       s11, #8
    a.vwrite     a0, s10, v1
    a.vread      v1, a4, s13
    s.movz       s10, #8
    a.vwrite     a0, s16, v1
    a.vread      v1, a4, s7
    s.movz       s7, #9
    a.vwrite     a0, s14, v1
    a.vread      v1, a4, s17
    s.movz       s12, #9
    a.vwrite     a0, s8, v1
    a.vread      v1, a4, s6
    s.movz       s6, #10
    a.vwrite     a0, s9, v1
    a.vread      v1, a4, s11
    s.movz       s8, #10
    a.vwrite     a0, s10, v1
    a.vread      v1, a4, s7
    s.movz       s7, #11
    a.vwrite     a0, s12, v1
    a.vread      v1, a4, s6
    s.movz       s6, #11
    a.vwrite     a0, s8, v1
    a.vread      v1, a4, s7
    s.movz       s7, #12
    a.vwrite     a0, s6, v1
    s.movz       s6, #12
    a.vread      v1, a4, s7
    s.movz       s7, #13
    a.vwrite     a0, s6, v1
    s.movz       s6, #13
    a.vread      v1, a4, s7
    s.movz       s7, #14
    a.vwrite     a0, s6, v1
    s.movz       s6, #14
    a.vread      v1, a4, s7
    s.movz       s7, #15
    a.vwrite     a0, s6, v1
    s.movz       s6, #15
    a.vread      v1, a4, s7
    s.add        s7, s3, s25
    s.movz       s8, #1
    a.vwrite     a0, s6, v1
    s.mov        s3, s7
    br.nz        s8, for_1
endfor_2:
    s.muli       s3, s5, #64                     // a runtime tile origin, x64
    s.movz       s4, #8
    s.movz       s5, #0
    s.movz       s6, #64
    v.extract    s7, v5, #0
    v.extract    s8, v5, #1
    v.splat      v0, s7
    v.splat      v1, s4
    s.add        s4, s5, s3                      // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s6
    v.splat      v7, s8
    v.extract    s3, v13, #0
    v.extract    s5, v13, #1
    v.extract    s6, v13, #2
    v.splat      v8, s3
    v.mul        v9, v0, v1
    v.mul        v0, v2, v4
    v.splat      v2, s4
    v.splat      v4, s5
    v.mul        v11, v7, v1
    v.add        v7, v8, v9
    v.add        v8, v0, v2
    v.add        v0, v4, v11
    v.movi       v2, #1
    v.splat      v4, s6
    v.movi       v9, #1
    v.movi       v11, #0
    v.movi       v12, #1
    s.addi       s3, s2, #3136
    v.add        v14, v7, v8
    v.add        v7, v0, v8
    v.cmp.lt     p1, v10, v2
    v.extract    s4, v5, #2
    v.splat      v0, s4
    v.movi       v2, #0
    v.mul        v10, v0, v1
    v.cmp.lt     p2, v5, v3
    @p1 v.sel        v0, v9, v11
    v.add        v9, v4, v10
    v.splat      v4, s1
    v.add        v10, v9, v8
    @p2 v.sel        v9, v12, v2
    v.movi       v2, #1
    v.movi       v11, #0
    v.add        v12, v4, v14
    s.addi       s1, s3, #64
    v.add        v14, v4, v7
    s.addi       s4, s3, #128
    v.add        v7, v4, v10
    s.addi       s5, s3, #192
    v.cmp.lt     p1, v13, v3
    v.extract    s6, v5, #3
    v.extract    s7, v13, #3
    @p1 v.sel        v10, v2, v11
    v.splat      v2, s6
    v.st.w       [s3, #0], v12
    v.splat      v11, s7
    v.cmp.lt     p1, v6, v3
    v.extract    s6, v5, #4
    v.extract    s7, v5, #5
    v.extract    s8, v5, #6
    v.splat      v3, s6
    v.splat      v6, s7
    v.extract    s6, v13, #4
    v.extract    s7, v13, #5
    v.mul        v12, v2, v1
    v.mul        v2, v3, v1
    v.mul        v3, v6, v1
    v.add        v6, v11, v12
    v.splat      v11, s8
    v.extract    s8, v13, #6
    v.mul        v12, v11, v1
    v.add        v11, v6, v8
    v.st.w       [s1, #0], v14
    v.extract    s1, v5, #7
    v.splat      v6, s1
    v.extract    s1, v13, #7
    v.mul        v14, v6, v1
    v.add        v6, v4, v11
    v.st.w       [s4, #0], v7
    v.extract    s4, v5, #8
    v.splat      v7, s4
    v.extract    s4, v13, #8
    v.mul        v11, v7, v1
    v.st.w       [s5, #0], v6
    v.splat      v6, s6
    s.addi       s5, s3, #256
    v.extract    s6, v5, #9
    v.add        v7, v6, v2
    v.splat      v2, s6
    v.extract    s6, v13, #9
    v.add        v6, v7, v8
    v.mul        v7, v2, v1
    v.add        v2, v4, v6
    v.st.w       [s5, #0], v2
    v.splat      v2, s7
    s.addi       s5, s3, #320
    v.extract    s7, v5, #10
    v.add        v6, v2, v3
    v.splat      v2, s7
    v.extract    s7, v13, #10
    v.add        v3, v6, v8
    v.mul        v6, v2, v1
    v.add        v2, v4, v3
    v.st.w       [s5, #0], v2
    v.splat      v2, s8
    s.addi       s5, s3, #384
    v.extract    s8, v5, #11
    v.add        v3, v2, v12
    v.splat      v2, s8
    v.extract    s8, v13, #11
    v.add        v12, v3, v8
    v.mul        v3, v2, v1
    v.add        v2, v4, v12
    v.st.w       [s5, #0], v2
    v.splat      v2, s1
    s.addi       s1, s3, #448
    v.extract    s5, v5, #12
    v.add        v12, v2, v14
    v.splat      v2, s5
    v.extract    s5, v13, #12
    v.add        v14, v12, v8
    v.mul        v12, v2, v1
    v.add        v2, v4, v14
    v.st.w       [s1, #0], v2
    v.splat      v2, s4
    s.addi       s1, s3, #512
    v.extract    s4, v5, #13
    v.add        v14, v2, v11
    v.splat      v2, s4
    v.extract    s4, v13, #13
    v.add        v11, v14, v8
    v.mul        v14, v2, v1
    v.add        v2, v4, v11
    v.st.w       [s1, #0], v2
    v.splat      v2, s6
    s.addi       s1, s3, #576
    v.extract    s6, v5, #14
    v.add        v11, v2, v7
    v.splat      v2, s6
    v.extract    s6, v13, #14
    v.add        v7, v11, v8
    v.mul        v11, v2, v1
    v.add        v2, v4, v7
    v.st.w       [s1, #0], v2
    v.splat      v2, s7
    s.addi       s1, s3, #640
    v.extract    s7, v5, #15
    v.splat      v5, s8
    v.extract    s8, v13, #15
    v.splat      v7, s5
    v.add        v13, v2, v6
    v.splat      v2, s7
    v.add        v6, v5, v3
    v.splat      v3, s4
    v.add        v5, v7, v12
    v.splat      v7, s6
    v.add        v12, v3, v14
    v.splat      v3, s8
    v.add        v14, v7, v11
    v.add        v7, v13, v8
    v.mul        v11, v2, v1
    v.add        v1, v6, v8
    v.add        v2, v5, v8
    v.add        v5, v12, v8
    v.add        v6, v14, v8
    v.add        v12, v4, v7
    v.add        v7, v3, v11
    s.addi       s4, s3, #704
    v.add        v3, v4, v1
    s.addi       s5, s3, #768
    v.add        v1, v4, v2
    s.addi       s6, s3, #832
    v.add        v2, v4, v5
    s.addi       s7, s3, #896
    v.add        v5, v4, v6
    s.addi       s8, s3, #960
    v.st.w       [s1, #0], v12
    v.add        v6, v7, v8
    s.movz       s1, #0
    v.add        v7, v4, v6
    s.addi       s3, s2, #3136
    v.st.w       [s4, #0], v3
    v.extract    s4, v0, #0
    v.splat      v3, s4
    v.extract    s4, v9, #0
    v.movi       v4, #0
    v.splat      v6, s4
    v.movi       v8, #0
    v.extract    s4, v10, #0
    v.cmp.ne     p2, v3, v4
    v.cmp.ne     p3, v6, v8
    v.st.w       [s5, #0], v1
    v.splat      v1, s4
    v.movi       v3, #0
    p.and        p4, p2, p3
    v.cmp.ne     p2, v1, v3
    p.and        p3, p4, p2
    s.movz       s4, #1
    p.and        p2, p3, p1
    s.addi       s5, s2, #3200
    v.st.w       [s6, #0], v2
    v.extract    s6, v0, #1
    v.splat      v1, s6
    v.extract    s6, v9, #1
    v.movi       v2, #0
    v.splat      v3, s6
    v.movi       v4, #0
    v.extract    s6, v10, #1
    v.cmp.ne     p3, v1, v2
    v.cmp.ne     p4, v3, v4
    v.st.w       [s7, #0], v5
    v.splat      v1, s6
    v.movi       v2, #0
    p.and        p5, p3, p4
    v.cmp.ne     p3, v1, v2
    p.and        p4, p5, p3
    s.movz       s6, #2
    p.and        p3, p4, p1
    s.addi       s7, s2, #3264
    v.st.w       [s8, #0], v7
    fence.acq_rel.device
    a.vread      v1, a0, s1
    v.extract    s1, v0, #2
    v.extract    s8, v9, #2
    v.splat      v2, s1
    v.movi       v3, #0
    v.splat      v4, s8
    v.movi       v5, #0
    v.cmp.ne     p4, v2, v3
    v.ld.w       v2, [s3, #0]
    v.extract    s1, v10, #2
    v.splat      v3, s1
    v.movi       v6, #0
    s.movz       s1, #3
    s.addi       s3, s2, #3328
    v.extract    s8, v0, #3
    v.splat      v7, s8
    v.movi       v8, #0
    @p2 v.st.scatter.w [s24, v2], v1
    a.vread      v1, a0, s4
    v.cmp.ne     p2, v4, v5
    p.and        p5, p4, p2
    v.cmp.ne     p2, v3, v6
    p.and        p4, p5, p2
    v.extract    s4, v9, #3
    p.and        p2, p4, p1
    v.splat      v2, s4
    v.movi       v3, #0
    v.ld.w       v4, [s5, #0]
    v.extract    s4, v10, #3
    v.cmp.ne     p4, v7, v8
    v.splat      v5, s4
    v.movi       v6, #0
    s.movz       s4, #4
    s.addi       s5, s2, #3392
    v.extract    s8, v0, #4
    v.splat      v7, s8
    v.movi       v8, #0
    @p3 v.st.scatter.w [s24, v4], v1
    a.vread      v1, a0, s6
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v6
    p.and        p4, p5, p3
    v.extract    s6, v9, #4
    p.and        p3, p4, p1
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v4, [s7, #0]
    v.extract    s6, v10, #4
    v.cmp.ne     p4, v7, v8
    v.splat      v5, s6
    v.movi       v6, #0
    s.movz       s6, #5
    s.addi       s7, s2, #3456
    v.extract    s8, v0, #5
    v.splat      v7, s8
    v.movi       v8, #0
    @p2 v.st.scatter.w [s24, v4], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v6
    p.and        p4, p5, p2
    v.extract    s1, v9, #5
    p.and        p2, p4, p1
    v.splat      v2, s1
    v.movi       v3, #0
    v.ld.w       v4, [s3, #0]
    v.extract    s1, v10, #5
    v.cmp.ne     p4, v7, v8
    v.splat      v5, s1
    v.movi       v6, #0
    s.movz       s1, #6
    s.addi       s3, s2, #3520
    v.extract    s8, v0, #6
    v.splat      v7, s8
    v.movi       v8, #0
    @p3 v.st.scatter.w [s24, v4], v1
    a.vread      v1, a0, s4
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v6
    p.and        p4, p5, p3
    v.extract    s4, v9, #6
    p.and        p3, p4, p1
    v.splat      v2, s4
    v.movi       v3, #0
    v.ld.w       v4, [s5, #0]
    v.extract    s4, v10, #6
    v.cmp.ne     p4, v7, v8
    v.splat      v5, s4
    v.movi       v6, #0
    s.movz       s4, #7
    s.addi       s5, s2, #3584
    v.extract    s8, v0, #7
    v.splat      v7, s8
    v.movi       v8, #0
    @p2 v.st.scatter.w [s24, v4], v1
    a.vread      v1, a0, s6
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v6
    p.and        p4, p5, p2
    v.extract    s6, v9, #7
    p.and        p2, p4, p1
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v4, [s7, #0]
    v.extract    s6, v10, #7
    v.cmp.ne     p4, v7, v8
    v.splat      v5, s6
    v.movi       v6, #0
    s.movz       s6, #8
    s.addi       s7, s2, #3648
    v.extract    s8, v0, #8
    v.splat      v7, s8
    v.movi       v8, #0
    @p3 v.st.scatter.w [s24, v4], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v6
    p.and        p4, p5, p3
    v.extract    s1, v9, #8
    p.and        p3, p4, p1
    v.splat      v2, s1
    v.movi       v3, #0
    v.ld.w       v4, [s3, #0]
    v.extract    s1, v10, #8
    v.cmp.ne     p4, v7, v8
    v.splat      v5, s1
    v.movi       v6, #0
    s.movz       s1, #9
    s.addi       s3, s2, #3712
    v.extract    s8, v0, #9
    v.splat      v7, s8
    v.movi       v8, #0
    @p2 v.st.scatter.w [s24, v4], v1
    a.vread      v1, a0, s4
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v6
    p.and        p4, p5, p2
    v.extract    s4, v9, #9
    p.and        p2, p4, p1
    v.splat      v2, s4
    v.movi       v3, #0
    v.ld.w       v4, [s5, #0]
    v.extract    s4, v10, #9
    v.cmp.ne     p4, v7, v8
    v.splat      v5, s4
    v.movi       v6, #0
    s.movz       s4, #10
    s.addi       s5, s2, #3776
    v.extract    s8, v0, #10
    v.splat      v7, s8
    v.movi       v8, #0
    @p3 v.st.scatter.w [s24, v4], v1
    a.vread      v1, a0, s6
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v6
    p.and        p4, p5, p3
    v.extract    s6, v9, #10
    p.and        p3, p4, p1
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v4, [s7, #0]
    v.extract    s6, v10, #10
    v.cmp.ne     p4, v7, v8
    v.splat      v5, s6
    v.movi       v6, #0
    s.movz       s6, #11
    s.addi       s7, s2, #3840
    v.extract    s8, v0, #11
    v.splat      v7, s8
    v.movi       v8, #0
    @p2 v.st.scatter.w [s24, v4], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v6
    p.and        p4, p5, p2
    v.extract    s1, v9, #11
    p.and        p2, p4, p1
    v.splat      v2, s1
    v.movi       v3, #0
    v.ld.w       v4, [s3, #0]
    v.extract    s1, v10, #11
    v.cmp.ne     p4, v7, v8
    v.splat      v5, s1
    v.movi       v6, #0
    s.movz       s1, #12
    s.addi       s3, s2, #3904
    v.extract    s8, v0, #12
    v.splat      v7, s8
    v.movi       v8, #0
    @p3 v.st.scatter.w [s24, v4], v1
    a.vread      v1, a0, s4
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v6
    p.and        p4, p5, p3
    v.extract    s4, v9, #12
    p.and        p3, p4, p1
    v.splat      v2, s4
    v.movi       v3, #0
    v.ld.w       v4, [s5, #0]
    v.extract    s4, v10, #12
    v.cmp.ne     p4, v7, v8
    v.splat      v5, s4
    v.movi       v6, #0
    s.movz       s4, #13
    s.addi       s5, s2, #3968
    v.extract    s8, v0, #13
    v.splat      v7, s8
    v.movi       v8, #0
    @p2 v.st.scatter.w [s24, v4], v1
    a.vread      v1, a0, s6
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v6
    p.and        p4, p5, p2
    v.extract    s6, v9, #13
    p.and        p2, p4, p1
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v4, [s7, #0]
    v.extract    s6, v10, #13
    v.cmp.ne     p4, v7, v8
    v.splat      v5, s6
    v.movi       v6, #0
    s.movz       s6, #14
    s.addi       s7, s2, #4032
    v.extract    s8, v0, #14
    v.splat      v7, s8
    v.movi       v8, #0
    @p3 v.st.scatter.w [s24, v4], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v6
    p.and        p4, p5, p3
    v.extract    s1, v9, #14
    p.and        p3, p4, p1
    v.splat      v2, s1
    v.movi       v3, #0
    v.ld.w       v4, [s3, #0]
    v.extract    s1, v10, #14
    v.cmp.ne     p4, v7, v8
    v.splat      v5, s1
    v.movi       v6, #0
    s.movz       s1, #15
    s.addi       s3, s2, #4096
    v.extract    s2, v0, #15
    v.splat      v0, s2
    v.movi       v7, #0
    @p2 v.st.scatter.w [s24, v4], v1
    a.vread      v1, a0, s4
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v6
    p.and        p4, p5, p2
    v.extract    s2, v9, #15
    p.and        p2, p4, p1
    v.splat      v2, s2
    v.movi       v3, #0
    v.ld.w       v4, [s5, #0]
    v.extract    s2, v10, #15
    v.cmp.ne     p4, v0, v7
    v.splat      v0, s2
    v.movi       v5, #0
    @p3 v.st.scatter.w [s24, v4], v1
    a.vread      v1, a0, s6
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v0, v5
    p.and        p4, p5, p3
    p.and        p3, p4, p1
    v.ld.w       v0, [s7, #0]
    @p2 v.st.scatter.w [s24, v0], v1
    a.vread      v0, a0, s1
    v.ld.w       v1, [s3, #0]
    @p3 v.st.scatter.w [s24, v1], v0
__rctx_next:
    exit
