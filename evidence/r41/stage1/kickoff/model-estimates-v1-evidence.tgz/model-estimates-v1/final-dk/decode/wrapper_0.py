# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/74/c74dfahw7hctqrxx7fzzyczrifrbtcui5aulhgr5yypcu63tuwh7.py
# Topologically Sorted Source Nodes: [getitem_4, position_ids, position_ids_1, position_ids_2, getitem_7, float_1, to, freqs, sin_1, getitem_9, cos_1, getitem_12, setitem_3, setitem_1], Original ATen: [aten.unsqueeze, aten.expand, aten.slice, aten._to_copy, aten.mul, aten.select]
# Source node to ATen node mapping:
#   cos_1 => cos
#   float_1 => convert_element_type
#   freqs => mul
#   getitem_12 => select_14, slice_10
#   getitem_4 => unsqueeze_4
#   getitem_7 => unsqueeze_5
#   getitem_9 => select_2, slice_2
#   position_ids => expand
#   position_ids_1 => slice_1
#   position_ids_2 => expand_1
#   setitem_1 => select_9, slice_8
#   setitem_3 => select_21, slice_16
#   sin_1 => sin
#   to => convert_element_type_1
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg3_1 : Tensor "bf16[32][1]tnca:0" = PlaceHolder[target=arg3_1]
#   %unsqueeze_4 : Tensor "i64[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg0_1, 0), kwargs = {})
#   %expand : Tensor "i64[4, 1, 1][0, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_4, [4, 1, -1]), kwargs = {})
#   %slice_1 : Tensor "i64[3, 1, 1][0, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%expand, 0, 1, 9223372036854775807), kwargs = {})
#   %expand_1 : Tensor "i64[3, 1, 1][0, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%slice_1, [3, -1, -1]), kwargs = {})
#   %unsqueeze_5 : Tensor "i64[3, 1, 1, 1][0, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%expand_1, 3), kwargs = {})
#   %convert_element_type : Tensor "f32[3, 1, 1, 1][1, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_5, torch.float32), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[32][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg3_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %convert_element_type_1), kwargs = {})
#   %sin : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.sin.default](args = (%mul,), kwargs = {})
#   %select_2 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 1), kwargs = {})
#   %slice_2 : Tensor "f32[1, 1, 11][32, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_2, 2, 1, 33, 3), kwargs = {})
#   %select_int : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 0), kwargs = {})
#   %slice_scatter_default : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int, %slice_2, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%sin, %slice_scatter_default, 0, 0), kwargs = {})
#   %cos : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.cos.default](args = (%mul,), kwargs = {})
#   %select_14 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 1), kwargs = {})
#   %slice_10 : Tensor "f32[1, 1, 11][32, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_14, 2, 1, 33, 3), kwargs = {})
#   %select_int_1 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 0), kwargs = {})
#   %slice_scatter_default_1 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_1, %slice_10, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default_1 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%cos, %slice_scatter_default_1, 0, 0), kwargs = {})
#   %select_21 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_16 : Tensor "f32[1, 1, 10][32, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_21, 2, 2, 30, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_16, 2, 2, 30, 3), kwargs = {})
#   %select_scatter_default_5 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_9 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_8 : Tensor "f32[1, 1, 10][32, 32, 3]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_9, 2, 2, 30, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_8, 2, 2, 30, 3), kwargs = {})
#   %select_scatter_default_6 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_3, 0, 0), kwargs = {})
#   return %select_scatter_default_5,%select_scatter_default_6
triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0 = async_compile.triton('triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 128}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1728}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 96
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = xindex // 32
    x0 = (xindex % 32)
    x2 = xindex
    tmp65 = tl.load(in_ptr0 + (0))
    tmp66 = tl.broadcast_to(tmp65, [XBLOCK])
    tmp68 = tl.load(in_ptr1 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 2, tl.int64)
    tmp6 = tmp4 >= tmp5
    tmp7 = tl.full([1], 30, tl.int64)
    tmp8 = tmp4 < tmp7
    tmp9 = ((((-2) + x0) % 3)).to(tl.int64)
    tmp10 = (tmp9).to(tl.int64)
    tmp11 = tl.full([1], 0, tl.int64)
    tmp12 = tmp10 == tmp11
    tmp13 = tmp6 & tmp8
    tmp14 = tmp13 & tmp12
    tmp15 = tl.full([1], 2, tl.int32)
    tmp16 = tl.full([1], 0, tl.int32)
    tmp17 = tmp15 == tmp16
    tmp18 = (2 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))).to(tl.int64)
    tmp19 = (tmp18).to(tl.int64)
    tmp20 = tl.full([1], 1, tl.int64)
    tmp21 = tmp19 >= tmp20
    tmp22 = tl.full([1], 0, tl.int64)
    tmp23 = tmp20 == tmp22
    tmp24 = tmp21 & tmp23
    tmp25 = tmp24 & tmp14
    tmp26 = tl.load(in_ptr0 + (0))
    tmp27 = tl.broadcast_to(tmp26, [XBLOCK])
    tmp28 = tl.where(tmp25, tmp27, 0)
    tmp29 = tmp28.to(tl.float32)
    tmp30 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))), tmp25 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp31 = tmp30.to(tl.float32)
    tmp32 = tmp29 * tmp31
    tmp33 = tl_math.cos(tmp32)
    tmp34 = tl.full(tmp33.shape, 0.0, tmp33.dtype)
    tmp35 = tl.where(tmp25, tmp33, tmp34)
    tmp36 = tl.load(in_ptr0 + (0))
    tmp37 = tl.broadcast_to(tmp36, [XBLOCK])
    tmp38 = tl.where(tmp14, tmp37, 0)
    tmp39 = tmp38.to(tl.float32)
    tmp40 = tl.load(in_ptr1 + (2 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))), tmp14 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp41 = tmp40.to(tl.float32)
    tmp42 = tmp39 * tmp41
    tmp43 = tl_math.cos(tmp42)
    tmp44 = tl.where(tmp24, tmp35, tmp43)
    tmp45 = tl.where(tmp17, tmp44, tmp43)
    tmp46 = tl.full(tmp45.shape, 0.0, tmp45.dtype)
    tmp47 = tl.where(tmp14, tmp45, tmp46)
    tmp48 = tmp1 == tmp1
    tmp49 = tl.full([1], 1, tl.int64)
    tmp50 = tmp4 >= tmp49
    tmp51 = ((((-1) + x0) % 3)).to(tl.int64)
    tmp52 = (tmp51).to(tl.int64)
    tmp53 = tmp52 == tmp11
    tmp54 = tmp50 & tmp53
    tmp55 = tl.load(in_ptr0 + (0))
    tmp56 = tl.broadcast_to(tmp55, [XBLOCK])
    tmp57 = tl.where(tmp54, tmp56, 0)
    tmp58 = tmp57.to(tl.float32)
    tmp59 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp54 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp60 = tmp59.to(tl.float32)
    tmp61 = tmp58 * tmp60
    tmp62 = tl_math.cos(tmp61)
    tmp63 = tl.full(tmp62.shape, 0.0, tmp62.dtype)
    tmp64 = tl.where(tmp54, tmp62, tmp63)
    tmp67 = tmp66.to(tl.float32)
    tmp69 = tmp68.to(tl.float32)
    tmp70 = tmp67 * tmp69
    tmp71 = tl_math.cos(tmp70)
    tmp72 = tl.where(tmp54, tmp64, tmp71)
    tmp73 = tl.where(tmp48, tmp72, tmp71)
    tmp74 = tl.where(tmp14, tmp47, tmp73)
    tmp75 = tl.where(tmp2, tmp72, tmp71)
    tmp76 = tl.where(tmp2, tmp74, tmp75)
    tmp77 = tl_math.sin(tmp32)
    tmp78 = tl.full(tmp77.shape, 0.0, tmp77.dtype)
    tmp79 = tl.where(tmp25, tmp77, tmp78)
    tmp80 = tl_math.sin(tmp42)
    tmp81 = tl.where(tmp24, tmp79, tmp80)
    tmp82 = tl.where(tmp17, tmp81, tmp80)
    tmp83 = tl.full(tmp82.shape, 0.0, tmp82.dtype)
    tmp84 = tl.where(tmp14, tmp82, tmp83)
    tmp85 = tl_math.sin(tmp61)
    tmp86 = tl.full(tmp85.shape, 0.0, tmp85.dtype)
    tmp87 = tl.where(tmp54, tmp85, tmp86)
    tmp88 = tl_math.sin(tmp70)
    tmp89 = tl.where(tmp54, tmp87, tmp88)
    tmp90 = tl.where(tmp48, tmp89, tmp88)
    tmp91 = tl.where(tmp14, tmp84, tmp90)
    tmp92 = tl.where(tmp2, tmp89, tmp88)
    tmp93 = tl.where(tmp2, tmp91, tmp92)
    tl.store(out_ptr0 + (x2), tmp76, xmask)
    tl.store(out_ptr1 + (x2), tmp93, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/i2/ci2la7enlnsjex3tre6cghng6oddmlooygtpo7e7oydxuhhmkjh2.py
# Topologically Sorted Source Nodes: [inputs_embeds, float_2, pow_1, mean, add, rsqrt, output, float_3, add_1, output_1, hidden_states], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add => add
#   add_1 => add_1
#   float_2 => convert_element_type_4
#   float_3 => convert_element_type_5
#   hidden_states => convert_element_type_6
#   inputs_embeds => embedding
#   mean => mean
#   output => mul_3
#   output_1 => mul_4
#   pow_1 => pow_1
#   rsqrt => rsqrt
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "bf16[248320, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %buf0 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf0]
#   %arg4_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg4_1]
#   %embedding : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_4, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul_3 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_4, %rsqrt), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %add_1 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_5, 1.0), kwargs = {})
#   %mul_4 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_3, %add_1), kwargs = {})
#   %convert_element_type_6 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_4, torch.bfloat16), kwargs = {})
#   return %buf0,%convert_element_type_6
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 12288}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    _tmp7 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.device_assert((0 <= tmp1) & (tmp1 < 248320), "index out of bounds: 0 <= tmp1 < 248320")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2048*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp3.to(tl.float32)
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
    tmp7 = triton_helpers.promote_to_tensor(tl.sum(_tmp7, 0))
    tmp9 = tl.load(in_ptr0 + (0))
    tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp20 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp10) & (tmp10 < 248320), "index out of bounds: 0 <= tmp10 < 248320")
        tmp12 = tl.load(in_ptr1 + (r0_0 + 2048*tmp10), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp13 = tmp12.to(tl.float32)
        tmp14 = tl.full([1], 2048.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp16 = tl.full([1], 1e-06, tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = libdevice.rsqrt(tmp17)
        tmp19 = tmp13 * tmp18
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tl.full([1], 1.0, tl.float32)
        tmp23 = tmp21 + tmp22
        tmp24 = tmp19 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp25, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/mb/cmbc6bps3lu5ca3fp5phllgdrqg46lhpmt3cxw6vwx4uutylzyze.py
# Topologically Sorted Source Nodes: [exp, neg, a, float_5, add_2, softplus, g, transpose_6, getitem_22, exp_1], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
# Source node to ATen node mapping:
#   a => mm_3, permute_4, view_10, view_9
#   add_2 => add_6
#   exp => exp_1
#   exp_1 => exp_3
#   float_5 => convert_element_type_20
#   g => mul_9
#   getitem_22 => select_36
#   neg => neg_1
#   softplus => exp_2, gt, log1p, where_1
#   transpose_6 => permute_10
# Graph fragment:
#   %convert_element_type_6 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_6]
#   %arg8_1 : Tensor "bf16[16, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg8_1]
#   %arg11_1 : Tensor "f32[16][1]tnca:0" = PlaceHolder[target=arg11_1]
#   %mm_3 : Tensor "bf16[1, 16][16, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %arg12_1 : Tensor "bf16[16][1]tnca:0" = PlaceHolder[target=arg12_1]
#   %exp_1 : Tensor "f32[16][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%arg11_1,), kwargs = {})
#   %neg_1 : Tensor "f32[16][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%exp_1,), kwargs = {})
#   %view_9 : Tensor "bf16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_6, [1, 2048]), kwargs = {})
#   %permute_4 : Tensor "bf16[2048, 16][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg8_1, [1, 0]), kwargs = {})
#   %mm_3 : Tensor "bf16[1, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_9, %permute_4), kwargs = {})
#   %view_10 : Tensor "bf16[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 16]), kwargs = {})
#   %convert_element_type_20 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float32), kwargs = {})
#   %add_6 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_20, %arg12_1), kwargs = {})
#   %gt : Tensor "b8[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.gt.Scalar](args = (%add_6, 20), kwargs = {})
#   %exp_2 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%add_6,), kwargs = {})
#   %log1p : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.log1p.default](args = (%exp_2,), kwargs = {})
#   %where_1 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%gt, %add_6, %log1p), kwargs = {})
#   %mul_9 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%neg_1, %where_1), kwargs = {})
#   %permute_10 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_9, [0, 2, 1]), kwargs = {})
#   %select_36 : Tensor "f32[1, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%permute_10, 2, 0), kwargs = {})
#   %exp_3 : Tensor "f32[1, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%select_36,), kwargs = {})
#   return %mm_3,%exp_3
triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2 = async_compile.triton('triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'in_ptr2': '*fp32', 'in_ptr3': '*bf16', 'out_ptr1': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2(arg_A, arg_B, in_ptr2, in_ptr3, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 16
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 16*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 16*idx_m
    tmp0 = acc.to(tl.bfloat16)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.load(in_ptr2 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask)
    tmp6 = tl.load(in_ptr3 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp3 = libdevice.exp(tmp2)
    tmp4 = -tmp3
    tmp5 = tmp1.to(tl.float32)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp5 + tmp7
    tmp9 = tl.full([1], 20.0, tl.float32)
    tmp10 = tmp8 > tmp9
    tmp11 = libdevice.exp(tmp8)
    tmp12 = libdevice.log1p(tmp11)
    tmp13 = tl.where(tmp10, tmp8, tmp12)
    tmp14 = tmp4 * tmp13
    tmp15 = libdevice.exp(tmp14)
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp15, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/mp/cmpftjbdsgzjcgiynptn2ewblsbalboyqfqforl6iusr57o2bqtz.py
# Topologically Sorted Source Nodes: [b, beta, transpose_5, beta_1], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
# Source node to ATen node mapping:
#   b => mm_2, permute_3, view_7, view_8
#   beta => sigmoid
#   beta_1 => clone_7, convert_element_type_24
#   transpose_5 => permute_9
# Graph fragment:
#   %convert_element_type_6 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_6]
#   %arg7_1 : Tensor "bf16[16, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg7_1]
#   %mm_2 : Tensor "bf16[1, 16][16, 1]tnca:0" = PlaceHolder[target=mm_2]
#   %view_7 : Tensor "bf16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_6, [1, 2048]), kwargs = {})
#   %permute_3 : Tensor "bf16[2048, 16][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg7_1, [1, 0]), kwargs = {})
#   %mm_2 : Tensor "bf16[1, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_7, %permute_3), kwargs = {})
#   %view_8 : Tensor "bf16[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 1, 16]), kwargs = {})
#   %sigmoid : Tensor "bf16[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sigmoid.default](args = (%view_8,), kwargs = {})
#   %permute_9 : Tensor "bf16[1, 16, 1][16, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%sigmoid, [0, 2, 1]), kwargs = {})
#   %convert_element_type_24 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_9, torch.float32), kwargs = {})
#   %clone_7 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_24,), kwargs = {memory_format: torch.contiguous_format})
#   return %mm_2,%clone_7
triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3 = async_compile.triton('triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr1': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3(arg_A, arg_B, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 16
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 16*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 16*idx_m
    tmp0 = acc.to(tl.bfloat16)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.sigmoid(tmp1)
    tmp3 = tmp2.to(tl.float32)
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp3, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/f2/cf2xjado7uf6hm3ivmecrd6mvuwfxudoknm75e42ezyje262qtk3.py
# Topologically Sorted Source Nodes: [z], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   z => mm_1, permute_2, view_4
# Graph fragment:
#   %convert_element_type_6 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_6]
#   %arg6_1 : Tensor "bf16[2048, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg6_1]
#   %view_4 : Tensor "bf16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_6, [1, 2048]), kwargs = {})
#   %permute_2 : Tensor "bf16[2048, 2048][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg6_1, [1, 0]), kwargs = {})
#   %mm_1 : Tensor "bf16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_4, %permute_2), kwargs = {})
#   return %mm_1
triton_tem_fused_mm_t_view_4 = async_compile.triton('triton_tem_fused_mm_t_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_4', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_4(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 2048
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 2048*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 2048*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/vj/cvjj4guq4weoam3rqxe644547rqowg7lizodsvdrd4umy4xeng4b.py
# Topologically Sorted Source Nodes: [inputs_embeds, float_2, pow_1, mean, add, rsqrt, output, float_3, add_1, output_1, hidden_states, mixed_qkv], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   add => add
#   add_1 => add_1
#   float_2 => convert_element_type_4
#   float_3 => convert_element_type_5
#   hidden_states => convert_element_type_6
#   inputs_embeds => embedding
#   mean => mean
#   mixed_qkv => mm, permute, view_2
#   output => mul_3
#   output_1 => mul_4
#   pow_1 => pow_1
#   rsqrt => rsqrt
# Graph fragment:
#   %convert_element_type_6 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_6]
#   %arg5_1 : Tensor "bf16[6144, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg5_1]
#   %embedding : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_4, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul_3 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_4, %rsqrt), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %add_1 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_5, 1.0), kwargs = {})
#   %mul_4 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_3, %add_1), kwargs = {})
#   %convert_element_type_6 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_4, torch.bfloat16), kwargs = {})
#   %view_2 : Tensor "bf16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_6, [1, 2048]), kwargs = {})
#   %permute : Tensor "bf16[2048, 6144][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg5_1, [1, 0]), kwargs = {})
#   %mm : Tensor "bf16[1, 6144][6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_2, %permute), kwargs = {})
#   return %mm
triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5 = async_compile.triton('triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 6144
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 6144*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 6144*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/dv/cdvmnbfaitohucmrqrw74jjlc5zjfltlilcbvmkfbswafli6m4al.py
# Topologically Sorted Source Nodes: [mixed_qkv, mixed_qkv_1, cat_2], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
# Source node to ATen node mapping:
#   cat_2 => cat
#   mixed_qkv => view_3
#   mixed_qkv_1 => permute_1
# Graph fragment:
#   %mm : Tensor "bf16[1, 6144][6144, 1]tnca:0" = PlaceHolder[target=mm]
#   %view_3 : Tensor "bf16[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 6144]), kwargs = {})
#   %permute_1 : Tensor "bf16[1, 6144, 1][6144, 1, 6144]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_3, [0, 2, 1]), kwargs = {})
#   %cat : Tensor "bf16[1, 6144, 5][30720, 5, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.cat.default](args = ([%arg9_1, %permute_1], -1), kwargs = {})
#   return %buf4
triton_poi_fused__unsafe_view_cat_transpose_6 = async_compile.triton('triton_poi_fused__unsafe_view_cat_transpose_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_transpose_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 12288}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_transpose_6(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 6144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask).to(tl.float32)
    tl.store(out_ptr0 + (5*x0), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/vd/cvd5ggpdm74k2s3uzuwvgp2iighzaryuhvs635t3xcbbdd7ceal3.py
# Topologically Sorted Source Nodes: [mixed_qkv, mixed_qkv_1, cat_2], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
# Source node to ATen node mapping:
#   cat_2 => cat
#   mixed_qkv => view_3
#   mixed_qkv_1 => permute_1
# Graph fragment:
#   %copy_ : Tensor "bf16[1, 6144, 4][24576, 4, 1]tnca:0" = PlaceHolder[target=copy_]
#   %view_3 : Tensor "bf16[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 6144]), kwargs = {})
#   %permute_1 : Tensor "bf16[1, 6144, 1][6144, 1, 6144]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_3, [0, 2, 1]), kwargs = {})
#   %cat : Tensor "bf16[1, 6144, 5][30720, 5, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.cat.default](args = ([%arg9_1, %permute_1], -1), kwargs = {})
#   return %buf3
triton_poi_fused__unsafe_view_cat_transpose_7 = async_compile.triton('triton_poi_fused__unsafe_view_cat_transpose_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32768}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_transpose_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 147456}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_transpose_7(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 24576
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 4)
    x1 = xindex // 4
    tmp0 = tl.load(in_ptr0 + (x2), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 5*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/uc/cuchej7w66jzzanqdjuo74rdpmyxpy7qb3giug6ajmzazieniwku.py
# Topologically Sorted Source Nodes: [getitem_14, copy_], Original ATen: [aten.slice, aten.copy, aten.copy_]
# Source node to ATen node mapping:
#   copy_ => copy_4
#   getitem_14 => slice_18
# Graph fragment:
#   %cat : Tensor "bf16[1, 6144, 5][30720, 5, 1]tnca:0" = PlaceHolder[target=cat]
#   %copy_ : Tensor "bf16[1, 6144, 4][24576, 4, 1]tnca:0" = PlaceHolder[target=copy_]
#   %buf3 : Tensor "bf16[1, 6144, 4][30720, 5, 1]tnca:0" = PlaceHolder[target=buf3]
#   %slice_18 : Tensor "bf16[1, 6144, 4][30720, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%cat, 2, -4, 9223372036854775807), kwargs = {})
#   %copy_4 : Tensor "bf16[1, 6144, 4][24576, 4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.copy.default](args = (%arg9_1, %slice_18), kwargs = {})
#   %copy_ : Tensor "bf16[1, 6144, 4][24576, 4, 1]tnca:0"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg9_1, %copy_4), kwargs = {})
#   return %buf743
triton_poi_fused_copy_copy__slice_8 = async_compile.triton('triton_poi_fused_copy_copy__slice_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32768}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_copy_copy__slice_8', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 147456}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_copy_copy__slice_8(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 24576
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 4)
    x1 = xindex // 4
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (1 + x0 + 5*x1), None).to(tl.float32)
    tl.store(out_ptr0 + (x2), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/mf/cmftbmjtwkx6kyvsil5zmclc4ovp325v2kdbtwxv7meiha4ohisa.py
# Topologically Sorted Source Nodes: [out, squeeze, unsqueeze, out_1, out_2], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
# Source node to ATen node mapping:
#   out => add_2, add_3, add_4, convert_element_type_15, convert_element_type_16, convert_element_type_17, mul_5, mul_6, mul_7, mul_8, select_25, select_26, select_27, select_28, select_29, select_30, select_31, select_32, slice_19, slice_20, slice_21, slice_22, view_11, view_12, view_13, view_14
#   out_1 => slice_23
#   out_2 => convert_element_type_18
#   squeeze => squeeze
#   unsqueeze => unsqueeze_8
# Graph fragment:
#   %cat : Tensor "bf16[1, 6144, 5][30720, 5, 1]tnca:0" = PlaceHolder[target=cat]
#   %arg10_1 : Tensor "bf16[6144, 1, 4][4, 4, 1]tnca:0" = PlaceHolder[target=arg10_1]
#   %convert_element_type_15 : Tensor "f32[1, 6144, 5][30720, 5, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%cat, torch.float32), kwargs = {})
#   %slice_19 : Tensor "f32[1, 6144, 2][30720, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%convert_element_type_15, 2, 0, 2), kwargs = {})
#   %squeeze : Tensor "bf16[6144, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.squeeze.dim](args = (%arg10_1, 1), kwargs = {})
#   %unsqueeze_8 : Tensor "bf16[6144, 1, 4][4, 4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%squeeze, 1), kwargs = {})
#   %convert_element_type_16 : Tensor "f32[6144, 1, 4][4, 4, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_8, torch.float32), kwargs = {})
#   %select_25 : Tensor "f32[6144, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_16, 1, 0), kwargs = {})
#   %select_26 : Tensor "f32[6144][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_25, 1, 0), kwargs = {})
#   %view_11 : Tensor "f32[1, 6144, 1][24576, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_26, [1, -1, 1]), kwargs = {})
#   %mul_5 : Tensor "f32[1, 6144, 2][12288, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_19, %view_11), kwargs = {})
#   %slice_20 : Tensor "f32[1, 6144, 2][30720, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%convert_element_type_15, 2, 1, 3), kwargs = {})
#   %select_27 : Tensor "f32[6144, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_16, 1, 0), kwargs = {})
#   %select_28 : Tensor "f32[6144][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_27, 1, 1), kwargs = {})
#   %view_12 : Tensor "f32[1, 6144, 1][24576, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_28, [1, -1, 1]), kwargs = {})
#   %mul_6 : Tensor "f32[1, 6144, 2][12288, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_20, %view_12), kwargs = {})
#   %add_2 : Tensor "f32[1, 6144, 2][12288, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_5, %mul_6), kwargs = {})
#   %slice_21 : Tensor "f32[1, 6144, 2][30720, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%convert_element_type_15, 2, 2, 4), kwargs = {})
#   %select_29 : Tensor "f32[6144, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_16, 1, 0), kwargs = {})
#   %select_30 : Tensor "f32[6144][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_29, 1, 2), kwargs = {})
#   %view_13 : Tensor "f32[1, 6144, 1][24576, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_30, [1, -1, 1]), kwargs = {})
#   %mul_7 : Tensor "f32[1, 6144, 2][12288, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_21, %view_13), kwargs = {})
#   %add_3 : Tensor "f32[1, 6144, 2][12288, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_2, %mul_7), kwargs = {})
#   %slice_22 : Tensor "f32[1, 6144, 2][30720, 5, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%convert_element_type_15, 2, 3, 5), kwargs = {})
#   %select_31 : Tensor "f32[6144, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_16, 1, 0), kwargs = {})
#   %select_32 : Tensor "f32[6144][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_31, 1, 3), kwargs = {})
#   %view_14 : Tensor "f32[1, 6144, 1][24576, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_32, [1, -1, 1]), kwargs = {})
#   %mul_8 : Tensor "f32[1, 6144, 2][12288, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_22, %view_14), kwargs = {})
#   %add_4 : Tensor "f32[1, 6144, 2][12288, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_3, %mul_8), kwargs = {})
#   %convert_element_type_17 : Tensor "bf16[1, 6144, 2][12288, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_4, torch.bfloat16), kwargs = {})
#   %slice_23 : Tensor "bf16[1, 6144, 1][12288, 2, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%convert_element_type_17, 2, -1, 9223372036854775807), kwargs = {})
#   %convert_element_type_18 : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_23, torch.float32), kwargs = {})
#   return %convert_element_type_18
triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9 = async_compile.triton('triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 49152}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 6144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (1 + 5*x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (4*x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp5 = tl.load(in_ptr0 + (2 + 5*x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp7 = tl.load(in_ptr1 + (1 + 4*x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp11 = tl.load(in_ptr0 + (3 + 5*x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp13 = tl.load(in_ptr1 + (2 + 4*x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp17 = tl.load(in_ptr0 + (4 + 5*x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp19 = tl.load(in_ptr1 + (3 + 4*x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 * tmp3
    tmp6 = tmp5.to(tl.float32)
    tmp8 = tmp7.to(tl.float32)
    tmp9 = tmp6 * tmp8
    tmp10 = tmp4 + tmp9
    tmp12 = tmp11.to(tl.float32)
    tmp14 = tmp13.to(tl.float32)
    tmp15 = tmp12 * tmp14
    tmp16 = tmp10 + tmp15
    tmp18 = tmp17.to(tl.float32)
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp18 * tmp20
    tmp22 = tmp16 + tmp21
    tmp23 = tmp22.to(tl.float32)
    tmp24 = tmp23.to(tl.float32)
    tl.store(out_ptr0 + (x0), tmp24, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/pq/cpqoejwdpu3tp2ltf5ookg4jdb2ebhrhn2bf6fv54dbsw4vbxglq.py
# Topologically Sorted Source Nodes: [out_2, mixed_qkv_3, split, key_1, transpose_3, key_2, mul_8, sum_2], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
# Source node to ATen node mapping:
#   key_1 => view_16
#   key_2 => clone_5, convert_element_type_22
#   mixed_qkv_3 => permute_5
#   mul_8 => mul_12
#   out_2 => add_5, convert_element_type_19, div, exp, neg
#   split => split_with_sizes
#   sum_2 => sum_2
#   transpose_3 => permute_7
# Graph fragment:
#   %convert_element_type_18 : Tensor "f32[1, 6144, 1][6144, 1, 6144]tnca:0" = PlaceHolder[target=convert_element_type_18]
#   %clone_5 : Tensor "f32[1, 16, 1, 128][2048, 128, 2048, 1]tnca:0" = PlaceHolder[target=clone_5]
#   %neg : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_18,), kwargs = {})
#   %exp : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_5 : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_18, %add_5), kwargs = {})
#   %convert_element_type_19 : Tensor "bf16[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %permute_5 : Tensor "bf16[1, 1, 6144][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_19, [0, 2, 1]), kwargs = {})
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%permute_5, [2048, 2048, 2048], -1), kwargs = {})
#   %view_16 : Tensor "bf16[1, 1, 16, 128][6144, 1, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_1, [1, 1, -1, 128]), kwargs = {})
#   %permute_7 : Tensor "bf16[1, 16, 1, 128][6144, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_16, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_22 : Tensor "f32[1, 16, 1, 128][6144, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_7, torch.float32), kwargs = {})
#   %clone_5 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_22,), kwargs = {memory_format: torch.contiguous_format})
#   %mul_12 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_5, %clone_5), kwargs = {})
#   %sum_2 : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_12, [-1], True), kwargs = {})
#   return %clone_5,%sum_2
triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10 = async_compile.triton('triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 128, 'r0_': 24576}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10(in_ptr0, out_ptr0, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0 + (2048), shape=[16, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp1 = -tmp0
        tmp2 = libdevice.exp(tmp1)
        tmp3 = tl.full([1], 1.0, tl.float32)
        tmp4 = tmp2 + tmp3
        tmp5 = (tmp0 / tmp4)
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
        tl.store(out_ptr0 + (r0_1 + 128*x0), tmp7, r0_mask)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tl.store(out_ptr1 + (x0), tmp10, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/5m/c5mgu4rdbivjclka2lsfmhvygtzye7xaf4ongmqv6433maqys5hq.py
# Topologically Sorted Source Nodes: [out_2, mixed_qkv_3, split, add_4, inv_norm_1, key_3, k_t, value_1, transpose_4, value_2, v_t, exp, neg, a, float_5, add_2, softplus, g, transpose_6, getitem_22, exp_1, decay_t, last_recurrent_state_1, unsqueeze_2, mul_11, kv_mem, sub, b, beta, transpose_5, beta_1, getitem_24, beta_t, delta], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
# Source node to ATen node mapping:
#   a => view_10
#   add_2 => add_6
#   add_4 => add_8
#   b => view_8
#   beta => sigmoid
#   beta_1 => clone_7, convert_element_type_24
#   beta_t => unsqueeze_11
#   decay_t => unsqueeze_10, unsqueeze_9
#   delta => mul_16
#   exp => exp_1
#   exp_1 => exp_3
#   float_5 => convert_element_type_20
#   g => mul_9
#   getitem_22 => select_36
#   getitem_24 => select_37
#   inv_norm_1 => rsqrt_2
#   k_t => select_34
#   key_3 => mul_13
#   kv_mem => sum_3
#   last_recurrent_state_1 => mul_14
#   mixed_qkv_3 => permute_5
#   mul_11 => mul_15
#   neg => neg_1
#   out_2 => add_5, convert_element_type_19, div, exp, neg
#   softplus => exp_2, gt, log1p, where_1
#   split => split_with_sizes
#   sub => sub
#   transpose_4 => permute_8
#   transpose_5 => permute_9
#   transpose_6 => permute_10
#   unsqueeze_2 => unsqueeze_12
#   v_t => select_35
#   value_1 => view_17
#   value_2 => clone_6, convert_element_type_23
# Graph fragment:
#   %copy__1 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0" = PlaceHolder[target=copy__1]
#   %exp_3 : Tensor "f32[1, 16][16, 1]tnca:0" = PlaceHolder[target=exp_3]
#   %clone_5 : Tensor "f32[1, 16, 1, 128][2048, 128, 2048, 1]tnca:0" = PlaceHolder[target=clone_5]
#   %sum_2 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=sum_2]
#   %convert_element_type_18 : Tensor "f32[1, 6144, 1][6144, 1, 6144]tnca:0" = PlaceHolder[target=convert_element_type_18]
#   %sum_3 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0" = PlaceHolder[target=sum_3]
#   %clone_7 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0" = PlaceHolder[target=clone_7]
#   %neg : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_18,), kwargs = {})
#   %exp : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_5 : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_18, %add_5), kwargs = {})
#   %convert_element_type_19 : Tensor "bf16[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %permute_5 : Tensor "bf16[1, 1, 6144][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_19, [0, 2, 1]), kwargs = {})
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%permute_5, [2048, 2048, 2048], -1), kwargs = {})
#   %add_8 : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_8,), kwargs = {})
#   %mul_13 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_5, %rsqrt_2), kwargs = {})
#   %select_34 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.select.int](args = (%mul_13, 2, 0), kwargs = {})
#   %view_17 : Tensor "bf16[1, 1, 16, 128][6144, 1, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_2, [1, 1, -1, 128]), kwargs = {})
#   %permute_8 : Tensor "bf16[1, 16, 1, 128][6144, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_17, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_23 : Tensor "f32[1, 16, 1, 128][6144, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_8, torch.float32), kwargs = {})
#   %clone_6 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_23,), kwargs = {memory_format: torch.contiguous_format})
#   %select_35 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%clone_6, 2, 0), kwargs = {})
#   %exp_1 : Tensor "f32[16][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%arg11_1,), kwargs = {})
#   %neg_1 : Tensor "f32[16][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%exp_1,), kwargs = {})
#   %view_10 : Tensor "bf16[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 16]), kwargs = {})
#   %convert_element_type_20 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float32), kwargs = {})
#   %add_6 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_20, %arg12_1), kwargs = {})
#   %gt : Tensor "b8[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.gt.Scalar](args = (%add_6, 20), kwargs = {})
#   %exp_2 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%add_6,), kwargs = {})
#   %log1p : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.log1p.default](args = (%exp_2,), kwargs = {})
#   %where_1 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%gt, %add_6, %log1p), kwargs = {})
#   %mul_9 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%neg_1, %where_1), kwargs = {})
#   %permute_10 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_9, [0, 2, 1]), kwargs = {})
#   %select_36 : Tensor "f32[1, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%permute_10, 2, 0), kwargs = {})
#   %exp_3 : Tensor "f32[1, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%select_36,), kwargs = {})
#   %unsqueeze_9 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp_3, 2), kwargs = {})
#   %unsqueeze_10 : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_9, 3), kwargs = {})
#   %mul_14 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg13_1, %unsqueeze_10), kwargs = {})
#   %unsqueeze_12 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_34, -1), kwargs = {})
#   %mul_15 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_14, %unsqueeze_12), kwargs = {})
#   %sum_3 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_15, [-2]), kwargs = {})
#   %sub : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%select_35, %sum_3), kwargs = {})
#   %view_8 : Tensor "bf16[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 1, 16]), kwargs = {})
#   %sigmoid : Tensor "bf16[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sigmoid.default](args = (%view_8,), kwargs = {})
#   %permute_9 : Tensor "bf16[1, 16, 1][16, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%sigmoid, [0, 2, 1]), kwargs = {})
#   %convert_element_type_24 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_9, torch.float32), kwargs = {})
#   %clone_7 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_24,), kwargs = {memory_format: torch.contiguous_format})
#   %select_37 : Tensor "f32[1, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%clone_7, 2, 0), kwargs = {})
#   %unsqueeze_11 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_37, -1), kwargs = {})
#   %mul_16 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub, %unsqueeze_11), kwargs = {})
#   return %sum_3,%mul_16
triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 2048, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 1073152, 'r0_': 8192}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 2048
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = (xindex % 128)
    x1 = xindex // 128
    tmp1 = tl.load(in_ptr1 + (x1), None, eviction_policy='evict_last')
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[16, 128], strides=[128, 1], block_shape=[(127 + XBLOCK) // 128, R0_BLOCK])
    tmp4 = tl.load(in_ptr3 + (x1), None, eviction_policy='evict_last')
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (x0 + 128*r0_2 + 16384*x1), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([xoffset // 128, r0_offset])[:, :, None], [(127 + XBLOCK) // 128, R0_BLOCK, ((128) * ((128) <= (XBLOCK)) + (XBLOCK) * ((XBLOCK) < (128)))]), [0, 2, 1]), [R0_BLOCK])
        tmp2 = tmp0 * tmp1
        tmp5 = tl.full([1], 1e-06, tl.float32)
        tmp6 = tmp4 + tmp5
        tmp7 = libdevice.rsqrt(tmp6)
        tmp8 = tmp3 * tmp7
        tmp9 = tmp2 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp13 = tl.load(in_ptr4 + (4096 + x3), None)
    tmp22 = tl.load(in_ptr5 + (x1), None, eviction_policy='evict_last')
    tmp14 = -tmp13
    tmp15 = libdevice.exp(tmp14)
    tmp16 = tl.full([1], 1.0, tl.float32)
    tmp17 = tmp15 + tmp16
    tmp18 = (tmp13 / tmp17)
    tmp19 = tmp18.to(tl.float32)
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp20 - tmp11
    tmp23 = tmp21 * tmp22
    tl.store(out_ptr1 + (x3), tmp23, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/yh/cyhbfc5yc5mz4cgxzkn3fauevv5mg42bqn3ikpwpaf2ydq6ej4my.py
# Topologically Sorted Source Nodes: [out_2, mixed_qkv_3, split, query_1, transpose_2, query_2, mul_6, sum_1], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
# Source node to ATen node mapping:
#   mixed_qkv_3 => permute_5
#   mul_6 => mul_10
#   out_2 => add_5, convert_element_type_19, div, exp, neg
#   query_1 => view_15
#   query_2 => clone_4, convert_element_type_21
#   split => split_with_sizes
#   sum_1 => sum_1
#   transpose_2 => permute_6
# Graph fragment:
#   %convert_element_type_18 : Tensor "f32[1, 6144, 1][6144, 1, 6144]tnca:0" = PlaceHolder[target=convert_element_type_18]
#   %clone_4 : Tensor "f32[1, 16, 1, 128][2048, 128, 2048, 1]tnca:0" = PlaceHolder[target=clone_4]
#   %neg : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_18,), kwargs = {})
#   %exp : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_5 : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_18, %add_5), kwargs = {})
#   %convert_element_type_19 : Tensor "bf16[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %permute_5 : Tensor "bf16[1, 1, 6144][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_19, [0, 2, 1]), kwargs = {})
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%permute_5, [2048, 2048, 2048], -1), kwargs = {})
#   %view_15 : Tensor "bf16[1, 1, 16, 128][6144, 1, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem, [1, 1, -1, 128]), kwargs = {})
#   %permute_6 : Tensor "bf16[1, 16, 1, 128][6144, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_15, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_21 : Tensor "f32[1, 16, 1, 128][6144, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_6, torch.float32), kwargs = {})
#   %clone_4 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_21,), kwargs = {memory_format: torch.contiguous_format})
#   %mul_10 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_4, %clone_4), kwargs = {})
#   %sum_1 : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_10, [-1], True), kwargs = {})
#   return %clone_4,%sum_1
triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12 = async_compile.triton('triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 128, 'r0_': 24576}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12(in_ptr0, out_ptr0, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp1 = -tmp0
        tmp2 = libdevice.exp(tmp1)
        tmp3 = tl.full([1], 1.0, tl.float32)
        tmp4 = tmp2 + tmp3
        tmp5 = (tmp0 / tmp4)
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
        tl.store(out_ptr0 + (r0_1 + 128*x0), tmp7, r0_mask)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tl.store(out_ptr1 + (x0), tmp10, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/h2/ch2vdjwazuesnfpzh5vl5tohdoirsma637boy2kokz4o5njbj3ny.py
# Topologically Sorted Source Nodes: [out_2, mixed_qkv_3, split, add_4, inv_norm_1, key_3, k_t, unsqueeze_3, value_1, transpose_4, value_2, v_t, exp, neg, a, float_5, add_2, softplus, g, transpose_6, getitem_22, exp_1, decay_t, last_recurrent_state_1, sub, b, beta, transpose_5, beta_1, getitem_24, beta_t, delta, unsqueeze_4, mul_13, last_recurrent_state_2], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
# Source node to ATen node mapping:
#   a => view_10
#   add_2 => add_6
#   add_4 => add_8
#   b => view_8
#   beta => sigmoid
#   beta_1 => clone_7, convert_element_type_24
#   beta_t => unsqueeze_11
#   decay_t => unsqueeze_10, unsqueeze_9
#   delta => mul_16
#   exp => exp_1
#   exp_1 => exp_3
#   float_5 => convert_element_type_20
#   g => mul_9
#   getitem_22 => select_36
#   getitem_24 => select_37
#   inv_norm_1 => rsqrt_2
#   k_t => select_34
#   key_3 => mul_13
#   last_recurrent_state_1 => mul_14
#   last_recurrent_state_2 => add_9
#   mixed_qkv_3 => permute_5
#   mul_13 => mul_17
#   neg => neg_1
#   out_2 => add_5, convert_element_type_19, div, exp, neg
#   softplus => exp_2, gt, log1p, where_1
#   split => split_with_sizes
#   sub => sub
#   transpose_4 => permute_8
#   transpose_5 => permute_9
#   transpose_6 => permute_10
#   unsqueeze_3 => unsqueeze_13
#   unsqueeze_4 => unsqueeze_14
#   v_t => select_35
#   value_1 => view_17
#   value_2 => clone_6, convert_element_type_23
# Graph fragment:
#   %copy__1 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0" = PlaceHolder[target=copy__1]
#   %exp_3 : Tensor "f32[1, 16][16, 1]tnca:0" = PlaceHolder[target=exp_3]
#   %clone_5 : Tensor "f32[1, 16, 1, 128][2048, 128, 2048, 1]tnca:0" = PlaceHolder[target=clone_5]
#   %sum_2 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=sum_2]
#   %mul_16 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0" = PlaceHolder[target=mul_16]
#   %add_9 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0" = PlaceHolder[target=add_9]
#   %sum_3 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0" = PlaceHolder[target=sum_3]
#   %neg : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_18,), kwargs = {})
#   %exp : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_5 : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_18, %add_5), kwargs = {})
#   %convert_element_type_19 : Tensor "bf16[1, 6144, 1][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %permute_5 : Tensor "bf16[1, 1, 6144][6144, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_19, [0, 2, 1]), kwargs = {})
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%permute_5, [2048, 2048, 2048], -1), kwargs = {})
#   %add_8 : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_8,), kwargs = {})
#   %mul_13 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_5, %rsqrt_2), kwargs = {})
#   %select_34 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.select.int](args = (%mul_13, 2, 0), kwargs = {})
#   %unsqueeze_13 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_34, -1), kwargs = {})
#   %view_17 : Tensor "bf16[1, 1, 16, 128][6144, 1, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_2, [1, 1, -1, 128]), kwargs = {})
#   %permute_8 : Tensor "bf16[1, 16, 1, 128][6144, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_17, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_23 : Tensor "f32[1, 16, 1, 128][6144, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_8, torch.float32), kwargs = {})
#   %clone_6 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_23,), kwargs = {memory_format: torch.contiguous_format})
#   %select_35 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%clone_6, 2, 0), kwargs = {})
#   %exp_1 : Tensor "f32[16][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%arg11_1,), kwargs = {})
#   %neg_1 : Tensor "f32[16][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%exp_1,), kwargs = {})
#   %view_10 : Tensor "bf16[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 16]), kwargs = {})
#   %convert_element_type_20 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float32), kwargs = {})
#   %add_6 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_20, %arg12_1), kwargs = {})
#   %gt : Tensor "b8[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.gt.Scalar](args = (%add_6, 20), kwargs = {})
#   %exp_2 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%add_6,), kwargs = {})
#   %log1p : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.log1p.default](args = (%exp_2,), kwargs = {})
#   %where_1 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%gt, %add_6, %log1p), kwargs = {})
#   %mul_9 : Tensor "f32[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%neg_1, %where_1), kwargs = {})
#   %permute_10 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul_9, [0, 2, 1]), kwargs = {})
#   %select_36 : Tensor "f32[1, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%permute_10, 2, 0), kwargs = {})
#   %exp_3 : Tensor "f32[1, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%select_36,), kwargs = {})
#   %unsqueeze_9 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp_3, 2), kwargs = {})
#   %unsqueeze_10 : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_9, 3), kwargs = {})
#   %mul_14 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg13_1, %unsqueeze_10), kwargs = {})
#   %sub : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%select_35, %sum_3), kwargs = {})
#   %view_8 : Tensor "bf16[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 1, 16]), kwargs = {})
#   %sigmoid : Tensor "bf16[1, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sigmoid.default](args = (%view_8,), kwargs = {})
#   %permute_9 : Tensor "bf16[1, 16, 1][16, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%sigmoid, [0, 2, 1]), kwargs = {})
#   %convert_element_type_24 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_9, torch.float32), kwargs = {})
#   %clone_7 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%convert_element_type_24,), kwargs = {memory_format: torch.contiguous_format})
#   %select_37 : Tensor "f32[1, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%clone_7, 2, 0), kwargs = {})
#   %unsqueeze_11 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_37, -1), kwargs = {})
#   %mul_16 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub, %unsqueeze_11), kwargs = {})
#   %unsqueeze_14 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%mul_16, -2), kwargs = {})
#   %mul_17 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%unsqueeze_13, %unsqueeze_14), kwargs = {})
#   %add_9 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_14, %mul_17), kwargs = {})
#   %copy__1 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg13_1, %add_9), kwargs = {})
#   return %add_9,%buf746
triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13', 'mutated_arg_names': ['in_ptr0', 'out_ptr1'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 5259392}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x3 = xindex
    x2 = xindex // 16384
    x4 = xindex // 128
    x0 = (xindex % 128)
    tmp0 = tl.load(in_ptr0 + (x3), None)
    tmp1 = tl.load(in_ptr1 + (x2), None, eviction_policy='evict_last')
    tmp3 = tl.load(in_ptr2 + (x4), None, eviction_policy='evict_last')
    tmp4 = tl.load(in_ptr3 + (x2), None, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr4 + (x0 + 128*x2), None, eviction_policy='evict_last')
    tmp2 = tmp0 * tmp1
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp3 * tmp7
    tmp10 = tmp8 * tmp9
    tmp11 = tmp2 + tmp10
    tl.store(out_ptr0 + (x3), tmp11, None)
    tl.store(out_ptr1 + (x3), tmp11, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/ci/ccihogtzv2oozellhismdy7zkutnjyymj2c2eumivuywttnm7ilx.py
# Topologically Sorted Source Nodes: [add_3, inv_norm, query_3, query_4, q_t, unsqueeze_5, mul_14, sum_4], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
# Source node to ATen node mapping:
#   add_3 => add_7
#   inv_norm => rsqrt_1
#   mul_14 => mul_18
#   q_t => select_33
#   query_3 => mul_11
#   query_4 => div_1
#   sum_4 => sum_4
#   unsqueeze_5 => unsqueeze_15
# Graph fragment:
#   %add_9 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0" = PlaceHolder[target=add_9]
#   %clone_4 : Tensor "f32[1, 16, 1, 128][2048, 128, 2048, 1]tnca:0" = PlaceHolder[target=clone_4]
#   %sum_1 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]tnca:0" = PlaceHolder[target=sum_1]
#   %add_7 : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_1, 1e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7,), kwargs = {})
#   %mul_11 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%clone_4, %rsqrt_1), kwargs = {})
#   %div_1 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%mul_11, 11.313708498984761), kwargs = {})
#   %select_33 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%div_1, 2, 0), kwargs = {})
#   %unsqueeze_15 : Tensor "f32[1, 16, 128, 1][2048, 128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_33, -1), kwargs = {})
#   %mul_18 : Tensor "f32[1, 16, 128, 128][262144, 16384, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_9, %unsqueeze_15), kwargs = {})
#   %sum_4 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_18, [-2]), kwargs = {})
#   return %sum_4
triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14 = async_compile.triton('triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 2048, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 1064960, 'r0_': 8192}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 2048
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = (xindex % 128)
    x1 = xindex // 128
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr1, shape=[16, 128], strides=[128, 1], block_shape=[(127 + XBLOCK) // 128, R0_BLOCK])
    tmp2 = tl.load(in_ptr2 + (x1), None, eviction_policy='evict_last')
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (x0 + 128*r0_2 + 16384*x1), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([xoffset // 128, r0_offset])[:, :, None], [(127 + XBLOCK) // 128, R0_BLOCK, ((128) * ((128) <= (XBLOCK)) + (XBLOCK) * ((XBLOCK) < (128)))]), [0, 2, 1]), [R0_BLOCK])
        tmp3 = tl.full([1], 1e-06, tl.float32)
        tmp4 = tmp2 + tmp3
        tmp5 = libdevice.rsqrt(tmp4)
        tmp6 = tmp1 * tmp5
        tmp7 = tl.full([1], 0.08838834764831843, tl.float32)
        tmp8 = tmp6 * tmp7
        tmp9 = tmp0 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tl.store(out_ptr0 + (x3), tmp11, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/xc/cxcw5nnm5lqgitfcaurh4fmg23mghetszfvqawi5dcjlchnlctcv.py
# Topologically Sorted Source Nodes: [core_attn_out, core_attn_out_1, core_attn_out_2, hidden_states_1, pow_2, variance, add_6, rsqrt_3, hidden_states_2, to_13, hidden_states_3, z, z_1, z_2, to_14, silu_1, hidden_states_4, core_attn_out_3], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
# Source node to ATen node mapping:
#   add_6 => add_10
#   core_attn_out => full_default_2
#   core_attn_out_1 => convert_element_type_25, permute_12
#   core_attn_out_2 => view_18
#   core_attn_out_3 => convert_element_type_29
#   hidden_states_1 => convert_element_type_26
#   hidden_states_2 => mul_19
#   hidden_states_3 => mul_20
#   hidden_states_4 => mul_21
#   pow_2 => pow_2
#   rsqrt_3 => rsqrt_3
#   silu_1 => add_11, div_2, exp_4, neg_2
#   to_13 => convert_element_type_27
#   to_14 => convert_element_type_28
#   variance => mean_1
#   z => view_5
#   z_1 => view_6
#   z_2 => view_19
# Graph fragment:
#   %sum_4 : Tensor "f32[1, 16, 128][2048, 128, 1]tnca:0" = PlaceHolder[target=sum_4]
#   %arg14_1 : Tensor "f32[128][1]tnca:0" = PlaceHolder[target=arg14_1]
#   %buf19 : Tensor "f32[16, 1][1, 16]tnca:0" = PlaceHolder[target=buf19]
#   %mm_1 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %full_default_2 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 1, 128], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %select_scatter_default_2 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%full_default_2, %sum_4, 2, 0), kwargs = {})
#   %permute_12 : Tensor "f32[1, 1, 16, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%select_scatter_default_2, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_25 : Tensor "bf16[1, 1, 16, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_12, torch.bfloat16), kwargs = {})
#   %view_18 : Tensor "bf16[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_25, [-1, 128]), kwargs = {})
#   %convert_element_type_26 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_18, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_26, 2), kwargs = {})
#   %mean_1 : Tensor "f32[16, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %add_10 : Tensor "f32[16, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, 1e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[16, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_10,), kwargs = {})
#   %mul_19 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_26, %rsqrt_3), kwargs = {})
#   %convert_element_type_27 : Tensor "bf16[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_19, torch.bfloat16), kwargs = {})
#   %mul_20 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg14_1, %convert_element_type_27), kwargs = {})
#   %view_5 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 2048]), kwargs = {})
#   %view_6 : Tensor "bf16[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_5, [1, 1, -1, 128]), kwargs = {})
#   %view_19 : Tensor "bf16[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_6, [-1, 128]), kwargs = {})
#   %convert_element_type_28 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_19, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_28,), kwargs = {})
#   %exp_4 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_11 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_4, 1), kwargs = {})
#   %div_2 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_28, %add_11), kwargs = {})
#   %mul_21 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_20, %div_2), kwargs = {})
#   %convert_element_type_29 : Tensor "bf16[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_21, torch.bfloat16), kwargs = {})
#   return %buf19,%convert_element_type_29
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 128},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 20992}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp9 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp2 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp0 = tl.full([1], 0, tl.int32)
        tmp1 = tmp0 == tmp0
        tmp3 = tl.full([1], 0.0, tl.float32)
        tmp4 = tl.where(tmp1, tmp2, tmp3)
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask, tmp10, _tmp9)
    tmp9 = triton_helpers.promote_to_tensor(tl.sum(_tmp9, 0))
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[16, 128], strides=[128, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp11 = tl.load(in_ptr1 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp14 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp28 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp12 = tl.full([1], 0, tl.int32)
        tmp13 = tmp12 == tmp12
        tmp15 = tl.full([1], 0.0, tl.float32)
        tmp16 = tl.where(tmp13, tmp14, tmp15)
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tl.full([1], 128.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp21 = tl.full([1], 1e-06, tl.float32)
        tmp22 = tmp20 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp18 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tmp26 = tmp25.to(tl.float32)
        tmp27 = tmp11 * tmp26
        tmp29 = tmp28.to(tl.float32)
        tmp30 = -tmp29
        tmp31 = libdevice.exp(tmp30)
        tmp32 = tl.full([1], 1.0, tl.float32)
        tmp33 = tmp31 + tmp32
        tmp34 = (tmp29 / tmp33)
        tmp35 = tmp27 * tmp34
        tmp36 = tmp35.to(tl.float32)
        tl.store(in_out_ptr0 + (r0_1 + 128*x0), tmp36, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/hf/chf5hi5wvauiby7hkmwmvd2b2vq7f4mtpwlnxzrwaqnnzllsvelh.py
# Topologically Sorted Source Nodes: [core_attn_out, core_attn_out_1, core_attn_out_2, hidden_states_1, pow_2, variance, add_6, rsqrt_3, hidden_states_2, to_13, hidden_states_3, z, z_1, z_2, to_14, silu_1, hidden_states_4, core_attn_out_3, core_attn_out_4, output_2], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
# Source node to ATen node mapping:
#   add_6 => add_10
#   core_attn_out => full_default_2
#   core_attn_out_1 => convert_element_type_25, permute_12
#   core_attn_out_2 => view_18
#   core_attn_out_3 => convert_element_type_29
#   core_attn_out_4 => view_20
#   hidden_states_1 => convert_element_type_26
#   hidden_states_2 => mul_19
#   hidden_states_3 => mul_20
#   hidden_states_4 => mul_21
#   output_2 => mm_4, permute_13, view_21
#   pow_2 => pow_2
#   rsqrt_3 => rsqrt_3
#   silu_1 => add_11, div_2, exp_4, neg_2
#   to_13 => convert_element_type_27
#   to_14 => convert_element_type_28
#   variance => mean_1
#   z => view_5
#   z_1 => view_6
#   z_2 => view_19
# Graph fragment:
#   %convert_element_type_29 : Tensor "bf16[16, 128][128, 1]tnca:0" = PlaceHolder[target=convert_element_type_29]
#   %arg15_1 : Tensor "bf16[2048, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg15_1]
#   %full_default_2 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 1, 128], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %select_scatter_default_2 : Tensor "f32[1, 16, 1, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%full_default_2, %sum_4, 2, 0), kwargs = {})
#   %permute_12 : Tensor "f32[1, 1, 16, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%select_scatter_default_2, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_25 : Tensor "bf16[1, 1, 16, 128][2048, 128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_12, torch.bfloat16), kwargs = {})
#   %view_18 : Tensor "bf16[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_25, [-1, 128]), kwargs = {})
#   %convert_element_type_26 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_18, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_26, 2), kwargs = {})
#   %mean_1 : Tensor "f32[16, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %add_10 : Tensor "f32[16, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, 1e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[16, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_10,), kwargs = {})
#   %mul_19 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_26, %rsqrt_3), kwargs = {})
#   %convert_element_type_27 : Tensor "bf16[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_19, torch.bfloat16), kwargs = {})
#   %mul_20 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg14_1, %convert_element_type_27), kwargs = {})
#   %view_5 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 2048]), kwargs = {})
#   %view_6 : Tensor "bf16[1, 1, 16, 128][2048, 2048, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_5, [1, 1, -1, 128]), kwargs = {})
#   %view_19 : Tensor "bf16[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_6, [-1, 128]), kwargs = {})
#   %convert_element_type_28 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_19, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_28,), kwargs = {})
#   %exp_4 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_11 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_4, 1), kwargs = {})
#   %div_2 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_28, %add_11), kwargs = {})
#   %mul_21 : Tensor "f32[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_20, %div_2), kwargs = {})
#   %convert_element_type_29 : Tensor "bf16[16, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_21, torch.bfloat16), kwargs = {})
#   %view_20 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_29, [1, 1, -1]), kwargs = {})
#   %view_21 : Tensor "bf16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_20, [1, 2048]), kwargs = {})
#   %permute_13 : Tensor "bf16[2048, 2048][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg15_1, [1, 0]), kwargs = {})
#   %mm_4 : Tensor "bf16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_21, %permute_13), kwargs = {})
#   return %mm_4
triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16 = async_compile.triton('triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 2048
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 2048*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 2048*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/2p/c2pw3libg7sfg2hq4tnbc5rrdfx34ggedmrvlpsao64pvmcd7ywt.py
# Topologically Sorted Source Nodes: [inputs_embeds, output_2, hidden_states_5, float_6, pow_3, mean_2, add_8, rsqrt_4, output_3, float_7, add_9, output_4, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_8 => add_13
#   add_9 => add_14
#   float_6 => convert_element_type_32
#   float_7 => convert_element_type_33
#   hidden_states_5 => add_12
#   hidden_states_6 => convert_element_type_34
#   inputs_embeds => embedding
#   mean_2 => mean_2
#   output_2 => view_22
#   output_3 => mul_22
#   output_4 => mul_23
#   pow_3 => pow_3
#   rsqrt_4 => rsqrt_4
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "bf16[248320, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %mm_4 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_4]
#   %buf23 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf23]
#   %arg16_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg16_1]
#   %embedding : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_22 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 1, 2048]), kwargs = {})
#   %add_12 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_22), kwargs = {})
#   %convert_element_type_32 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_12, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_32, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %add_13 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, 1e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_13,), kwargs = {})
#   %mul_22 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_32, %rsqrt_4), kwargs = {})
#   %convert_element_type_33 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg16_1, torch.float32), kwargs = {})
#   %add_14 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_33, 1.0), kwargs = {})
#   %mul_23 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_22, %add_14), kwargs = {})
#   %convert_element_type_34 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_23, torch.bfloat16), kwargs = {})
#   return %buf23,%convert_element_type_34
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 16384}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp9 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 248320), "index out of bounds: 0 <= tmp1 < 248320")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2048*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask, tmp10, _tmp9)
    tmp9 = triton_helpers.promote_to_tensor(tl.sum(_tmp9, 0))
    tmp11 = tl.load(in_ptr0 + (0))
    tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp24 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp12) & (tmp12 < 248320), "index out of bounds: 0 <= tmp12 < 248320")
        tmp14 = tl.load(in_ptr1 + (r0_0 + 2048*tmp12), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tmp14 + tmp15
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tl.full([1], 2048.0, tl.float32)
        tmp19 = (tmp9 / tmp18)
        tmp20 = tl.full([1], 1e-06, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = libdevice.rsqrt(tmp21)
        tmp23 = tmp17 * tmp22
        tmp25 = tmp24.to(tl.float32)
        tmp26 = tl.full([1], 1.0, tl.float32)
        tmp27 = tmp25 + tmp26
        tmp28 = tmp23 * tmp27
        tmp29 = tmp28.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp29, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/7r/c7rglnilhtvlorrcnbo57kpgkatc4emtzowyjgja5y44tnfitcfa.py
# Topologically Sorted Source Nodes: [linear_5], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_5 => mm_5, permute_14, view_23
# Graph fragment:
#   %convert_element_type_34 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_34]
#   %arg17_1 : Tensor "bf16[6144, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg17_1]
#   %view_23 : Tensor "bf16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_34, [1, 2048]), kwargs = {})
#   %permute_14 : Tensor "bf16[2048, 6144][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg17_1, [1, 0]), kwargs = {})
#   %mm_5 : Tensor "bf16[1, 6144][6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_23, %permute_14), kwargs = {})
#   return %mm_5
triton_tem_fused_mm_t_view_18 = async_compile.triton('triton_tem_fused_mm_t_view_18', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_18', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_18(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 6144
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 6144*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 6144*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/qs/cqsnwa3ti5xcpyno5luxyp322kc5mkbnb5bz3gnor363px7p5esq.py
# Topologically Sorted Source Nodes: [linear_5, silu_2, linear_6, mul_20], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
# Source node to ATen node mapping:
#   linear_5 => view_24
#   linear_6 => mm_6, permute_15, view_25, view_26
#   mul_20 => mul_24
#   silu_2 => add_15, convert_element_type_37, convert_element_type_38, div_3, exp_5, neg_3
# Graph fragment:
#   %convert_element_type_34 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_34]
#   %arg18_1 : Tensor "bf16[6144, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg18_1]
#   %mm_5 : Tensor "bf16[1, 6144][6144, 1]tnca:0" = PlaceHolder[target=mm_5]
#   %mm_6 : Tensor "bf16[1, 6144][6144, 1]tnca:0" = PlaceHolder[target=mm_6]
#   %view_24 : Tensor "bf16[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 1, 6144]), kwargs = {})
#   %convert_element_type_37 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_24, torch.float32), kwargs = {})
#   %neg_3 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_37,), kwargs = {})
#   %exp_5 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_3,), kwargs = {})
#   %add_15 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_5, 1), kwargs = {})
#   %div_3 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_37, %add_15), kwargs = {})
#   %convert_element_type_38 : Tensor "bf16[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_3, torch.bfloat16), kwargs = {})
#   %view_25 : Tensor "bf16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_34, [1, 2048]), kwargs = {})
#   %permute_15 : Tensor "bf16[2048, 6144][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg18_1, [1, 0]), kwargs = {})
#   %mm_6 : Tensor "bf16[1, 6144][6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_25, %permute_15), kwargs = {})
#   %view_26 : Tensor "bf16[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 1, 6144]), kwargs = {})
#   %mul_24 : Tensor "bf16[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_38, %view_26), kwargs = {})
#   return %mm_6,%mul_24
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19(arg_A, arg_B, in_ptr2, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 6144
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 6144*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 6144*idx_m
    tmp0 = acc.to(tl.bfloat16)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.load(in_ptr2 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = -tmp3
    tmp5 = libdevice.exp(tmp4)
    tmp6 = tl.full([1], 1.0, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = (tmp3 / tmp7)
    tmp9 = tmp8.to(tl.float32)
    tmp10 = tmp9 * tmp1
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp10, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/qm/cqm63cltszdsxsrsd46rqz7sqo467qgnkygwsyqiigxjvdjupmyu.py
# Topologically Sorted Source Nodes: [linear_5, silu_2, linear_6, mul_20, down_proj], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   down_proj => mm_7, permute_16, view_27
#   linear_5 => view_24
#   linear_6 => view_26
#   mul_20 => mul_24
#   silu_2 => add_15, convert_element_type_37, convert_element_type_38, div_3, exp_5, neg_3
# Graph fragment:
#   %mul_24 : Tensor "bf16[1, 1, 6144][6144, 6144, 1]tnca:0" = PlaceHolder[target=mul_24]
#   %arg19_1 : Tensor "bf16[2048, 6144][6144, 1]tnca:0" = PlaceHolder[target=arg19_1]
#   %view_24 : Tensor "bf16[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 1, 6144]), kwargs = {})
#   %convert_element_type_37 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_24, torch.float32), kwargs = {})
#   %neg_3 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_37,), kwargs = {})
#   %exp_5 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_3,), kwargs = {})
#   %add_15 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_5, 1), kwargs = {})
#   %div_3 : Tensor "f32[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_37, %add_15), kwargs = {})
#   %convert_element_type_38 : Tensor "bf16[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_3, torch.bfloat16), kwargs = {})
#   %view_26 : Tensor "bf16[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 1, 6144]), kwargs = {})
#   %mul_24 : Tensor "bf16[1, 1, 6144][6144, 6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_38, %view_26), kwargs = {})
#   %view_27 : Tensor "bf16[1, 6144][6144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_24, [1, 6144]), kwargs = {})
#   %permute_16 : Tensor "bf16[6144, 2048][1, 6144]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg19_1, [1, 0]), kwargs = {})
#   %mm_7 : Tensor "bf16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_27, %permute_16), kwargs = {})
#   return %mm_7
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 2048
    K = 6144
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 6144

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 6144*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 2048*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 6144*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 2048*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/tz/ctzs7x74tmq32jbnhxwdjazfvvpabqseu4duamwccpuetadaylfw.py
# Topologically Sorted Source Nodes: [inputs_embeds, output_2, hidden_states_5, down_proj, hidden_states_7, float_8, pow_4, mean_3, add_11, rsqrt_5, output_5, float_9, add_12, output_6, hidden_states_8], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_11 => add_17
#   add_12 => add_18
#   down_proj => view_28
#   float_8 => convert_element_type_43
#   float_9 => convert_element_type_44
#   hidden_states_5 => add_12
#   hidden_states_7 => add_16
#   hidden_states_8 => convert_element_type_45
#   inputs_embeds => embedding
#   mean_3 => mean_3
#   output_2 => view_22
#   output_5 => mul_25
#   output_6 => mul_26
#   pow_4 => pow_4
#   rsqrt_5 => rsqrt_5
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "bf16[248320, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %mm_4 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_4]
#   %mm_7 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_7]
#   %buf29 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf29]
#   %arg20_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg20_1]
#   %embedding : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_22 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 1, 2048]), kwargs = {})
#   %add_12 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_22), kwargs = {})
#   %view_28 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [1, 1, 2048]), kwargs = {})
#   %add_16 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_12, %view_28), kwargs = {})
#   %convert_element_type_43 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_16, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_43, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %add_17 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, 1e-06), kwargs = {})
#   %rsqrt_5 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_17,), kwargs = {})
#   %mul_25 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_43, %rsqrt_5), kwargs = {})
#   %convert_element_type_44 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg20_1, torch.float32), kwargs = {})
#   %add_18 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_44, 1.0), kwargs = {})
#   %mul_26 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_25, %add_18), kwargs = {})
#   %convert_element_type_45 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_26, torch.bfloat16), kwargs = {})
#   return %buf29,%convert_element_type_45
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_21 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_21', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_21', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 20480}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_21(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp6 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 248320), "index out of bounds: 0 <= tmp1 < 248320")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2048*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp13 = tl.load(in_ptr0 + (0))
    tmp14 = tl.broadcast_to(tmp13, [R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp17 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp19 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp28 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp14) & (tmp14 < 248320), "index out of bounds: 0 <= tmp14 < 248320")
        tmp16 = tl.load(in_ptr1 + (r0_0 + 2048*tmp14), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp18 = tmp16 + tmp17
        tmp20 = tmp18 + tmp19
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tl.full([1], 2048.0, tl.float32)
        tmp23 = (tmp11 / tmp22)
        tmp24 = tl.full([1], 1e-06, tl.float32)
        tmp25 = tmp23 + tmp24
        tmp26 = libdevice.rsqrt(tmp25)
        tmp27 = tmp21 * tmp26
        tmp29 = tmp28.to(tl.float32)
        tmp30 = tl.full([1], 1.0, tl.float32)
        tmp31 = tmp29 + tmp30
        tmp32 = tmp27 * tmp31
        tmp33 = tmp32.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp33, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/hc/chcf54bzchwo4ergnuv2vtkkyc5vkov4fnyba2dpro5mjnz3yima.py
# Topologically Sorted Source Nodes: [inputs_embeds, output_2, hidden_states_5, down_proj, hidden_states_7, output_7, hidden_states_13, float_12, pow_6, mean_5, add_19, rsqrt_9, output_8, float_13, add_20, output_9, hidden_states_14], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_19 => add_30
#   add_20 => add_31
#   down_proj => view_28
#   float_12 => convert_element_type_71
#   float_13 => convert_element_type_72
#   hidden_states_13 => add_29
#   hidden_states_14 => convert_element_type_73
#   hidden_states_5 => add_12
#   hidden_states_7 => add_16
#   inputs_embeds => embedding
#   mean_5 => mean_5
#   output_2 => view_22
#   output_7 => view_49
#   output_8 => mul_44
#   output_9 => mul_45
#   pow_6 => pow_6
#   rsqrt_9 => rsqrt_9
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "bf16[248320, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %mm_4 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_4]
#   %mm_7 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_7]
#   %mm_12 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_12]
#   %add_29 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_29]
#   %buf53 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf53]
#   %arg32_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg32_1]
#   %embedding : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_22 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 1, 2048]), kwargs = {})
#   %add_12 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_22), kwargs = {})
#   %view_28 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [1, 1, 2048]), kwargs = {})
#   %add_16 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_12, %view_28), kwargs = {})
#   %view_49 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_12, [1, 1, 2048]), kwargs = {})
#   %add_29 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_16, %view_49), kwargs = {})
#   %convert_element_type_71 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_29, torch.float32), kwargs = {})
#   %pow_6 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_71, 2), kwargs = {})
#   %mean_5 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %add_30 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, 1e-06), kwargs = {})
#   %rsqrt_9 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_30,), kwargs = {})
#   %mul_44 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_71, %rsqrt_9), kwargs = {})
#   %convert_element_type_72 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg32_1, torch.float32), kwargs = {})
#   %add_31 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_72, 1.0), kwargs = {})
#   %mul_45 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_44, %add_31), kwargs = {})
#   %convert_element_type_73 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_45, torch.bfloat16), kwargs = {})
#   return %add_29,%buf53,%convert_element_type_73
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_22 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_22', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_22', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 32768}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_22(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp13 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp6 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 248320), "index out of bounds: 0 <= tmp1 < 248320")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 2048*tmp1), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp9 = tmp7 + tmp8
        tmp10 = tmp9.to(tl.float32)
        tmp11 = tmp10 * tmp10
        tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
        tmp14 = _tmp13 + tmp12
        _tmp13 = tl.where(r0_mask, tmp14, _tmp13)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp9, r0_mask)
    tmp13 = triton_helpers.promote_to_tensor(tl.sum(_tmp13, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.debug_barrier()
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp23 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tl.full([1], 2048.0, tl.float32)
        tmp18 = (tmp13 / tmp17)
        tmp19 = tl.full([1], 1e-06, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = libdevice.rsqrt(tmp20)
        tmp22 = tmp16 * tmp21
        tmp24 = tmp23.to(tl.float32)
        tmp25 = tl.full([1], 1.0, tl.float32)
        tmp26 = tmp24 + tmp25
        tmp27 = tmp22 * tmp26
        tmp28 = tmp27.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp28, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/w6/cw6jymr3gqw5hoek43q6k365p3ci3ef33pqjalec3a4wh3bp34sp.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, float_14, pow_7, mean_6, add_22, rsqrt_10, output_10, float_15, add_23, output_11, hidden_states_16], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_22 => add_34
#   add_23 => add_35
#   down_proj_1 => view_55
#   float_14 => convert_element_type_82
#   float_15 => convert_element_type_83
#   hidden_states_15 => add_33
#   hidden_states_16 => convert_element_type_84
#   mean_6 => mean_6
#   output_10 => mul_47
#   output_11 => mul_48
#   pow_7 => pow_7
#   rsqrt_10 => rsqrt_10
# Graph fragment:
#   %add_29 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_29]
#   %mm_15 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_15]
#   %buf59 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf59]
#   %arg36_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg36_1]
#   %view_55 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_15, [1, 1, 2048]), kwargs = {})
#   %add_33 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_29, %view_55), kwargs = {})
#   %convert_element_type_82 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_33, torch.float32), kwargs = {})
#   %pow_7 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_82, 2), kwargs = {})
#   %mean_6 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [-1], True), kwargs = {})
#   %add_34 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_6, 1e-06), kwargs = {})
#   %rsqrt_10 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_34,), kwargs = {})
#   %mul_47 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_82, %rsqrt_10), kwargs = {})
#   %convert_element_type_83 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg36_1, torch.float32), kwargs = {})
#   %add_35 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_83, 1.0), kwargs = {})
#   %mul_48 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_47, %add_35), kwargs = {})
#   %convert_element_type_84 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_48, torch.bfloat16), kwargs = {})
#   return %buf59,%convert_element_type_84
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 20480}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 2048.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 1e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tl.full([1], 1.0, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = tmp17 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp23, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/nj/cnjmadx65wkpti55hpcbpixabn2dbniv4pqasngzvg75vy5rglkd.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, output_12, hidden_states_21, float_18, pow_9, mean_8, add_30, rsqrt_14, output_13, float_19, add_31, output_14, hidden_states_22], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_30 => add_47
#   add_31 => add_48
#   down_proj_1 => view_55
#   float_18 => convert_element_type_110
#   float_19 => convert_element_type_111
#   hidden_states_15 => add_33
#   hidden_states_21 => add_46
#   hidden_states_22 => convert_element_type_112
#   mean_8 => mean_8
#   output_12 => view_76
#   output_13 => mul_66
#   output_14 => mul_67
#   pow_9 => pow_9
#   rsqrt_14 => rsqrt_14
# Graph fragment:
#   %add_29 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_29]
#   %mm_15 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_15]
#   %mm_20 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_20]
#   %buf82 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf82]
#   %arg48_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg48_1]
#   %view_55 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_15, [1, 1, 2048]), kwargs = {})
#   %add_33 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_29, %view_55), kwargs = {})
#   %view_76 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_20, [1, 1, 2048]), kwargs = {})
#   %add_46 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_33, %view_76), kwargs = {})
#   %convert_element_type_110 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_46, torch.float32), kwargs = {})
#   %pow_9 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_110, 2), kwargs = {})
#   %mean_8 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_9, [-1], True), kwargs = {})
#   %add_47 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_8, 1e-06), kwargs = {})
#   %rsqrt_14 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_47,), kwargs = {})
#   %mul_66 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_110, %rsqrt_14), kwargs = {})
#   %convert_element_type_111 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg48_1, torch.float32), kwargs = {})
#   %add_48 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_111, 1.0), kwargs = {})
#   %mul_67 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_66, %add_48), kwargs = {})
#   %convert_element_type_112 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_67, torch.bfloat16), kwargs = {})
#   return %buf82,%convert_element_type_112
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 24576}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp8 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp5
        tmp7 = tl.broadcast_to(tmp6, [R0_BLOCK])
        tmp9 = _tmp8 + tmp7
        _tmp8 = tl.where(r0_mask, tmp9, _tmp8)
    tmp8 = triton_helpers.promote_to_tensor(tl.sum(_tmp8, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp10 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp11 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 2048.0, tl.float32)
        tmp17 = (tmp8 / tmp16)
        tmp18 = tl.full([1], 1e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tl.full([1], 1.0, tl.float32)
        tmp25 = tmp23 + tmp24
        tmp26 = tmp21 * tmp25
        tmp27 = tmp26.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp27, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/t2/ct2ynk33dkbjpmcuaq6jlw5ojn56go7pgqxcb6shrjacao4vers5.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, output_12, hidden_states_21, down_proj_2, hidden_states_23, float_20, pow_10, mean_9, add_33, rsqrt_15, output_15, float_21, add_34, output_16, hidden_states_24], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_33 => add_51
#   add_34 => add_52
#   down_proj_1 => view_55
#   down_proj_2 => view_82
#   float_20 => convert_element_type_121
#   float_21 => convert_element_type_122
#   hidden_states_15 => add_33
#   hidden_states_21 => add_46
#   hidden_states_23 => add_50
#   hidden_states_24 => convert_element_type_123
#   mean_9 => mean_9
#   output_12 => view_76
#   output_15 => mul_69
#   output_16 => mul_70
#   pow_10 => pow_10
#   rsqrt_15 => rsqrt_15
# Graph fragment:
#   %add_29 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_29]
#   %mm_15 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_15]
#   %mm_20 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_20]
#   %mm_23 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_23]
#   %buf88 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf88]
#   %arg52_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg52_1]
#   %view_55 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_15, [1, 1, 2048]), kwargs = {})
#   %add_33 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_29, %view_55), kwargs = {})
#   %view_76 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_20, [1, 1, 2048]), kwargs = {})
#   %add_46 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_33, %view_76), kwargs = {})
#   %view_82 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_23, [1, 1, 2048]), kwargs = {})
#   %add_50 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_46, %view_82), kwargs = {})
#   %convert_element_type_121 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_50, torch.float32), kwargs = {})
#   %pow_10 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_121, 2), kwargs = {})
#   %mean_9 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_10, [-1], True), kwargs = {})
#   %add_51 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_9, 1e-06), kwargs = {})
#   %rsqrt_15 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_51,), kwargs = {})
#   %mul_69 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_121, %rsqrt_15), kwargs = {})
#   %convert_element_type_122 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg52_1, torch.float32), kwargs = {})
#   %add_52 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_122, 1.0), kwargs = {})
#   %mul_70 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_69, %add_52), kwargs = {})
#   %convert_element_type_123 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_70, torch.bfloat16), kwargs = {})
#   return %buf88,%convert_element_type_123
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 28672}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor6 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor7 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp12 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor6.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp17 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor7.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp26 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tl.full([1], 2048.0, tl.float32)
        tmp21 = (tmp10 / tmp20)
        tmp22 = tl.full([1], 1e-06, tl.float32)
        tmp23 = tmp21 + tmp22
        tmp24 = libdevice.rsqrt(tmp23)
        tmp25 = tmp19 * tmp24
        tmp27 = tmp26.to(tl.float32)
        tmp28 = tl.full([1], 1.0, tl.float32)
        tmp29 = tmp27 + tmp28
        tmp30 = tmp25 * tmp29
        tmp31 = tmp30.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp31, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/md/cmdax76n44riqg6ovnnln3iuahwcqvjv4weh55di7jsmgvkbl4n4.py
# Topologically Sorted Source Nodes: [linear_25], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_25 => mm_25, permute_53, view_88
# Graph fragment:
#   %convert_element_type_123 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_123]
#   %arg55_1 : Tensor "bf16[512, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg55_1]
#   %view_88 : Tensor "bf16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_123, [1, 2048]), kwargs = {})
#   %permute_53 : Tensor "bf16[2048, 512][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg55_1, [1, 0]), kwargs = {})
#   %mm_25 : Tensor "bf16[1, 512][512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_88, %permute_53), kwargs = {})
#   return %mm_25
triton_tem_fused_mm_t_view_26 = async_compile.triton('triton_tem_fused_mm_t_view_26', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_26', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_26(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 512
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 512*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 512*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/zl/czlzg6tnjym5e33vqdb3tskwb7rqvtsp457pfcy6cs6km72gnixq.py
# Topologically Sorted Source Nodes: [linear_25, view_2, float_24, pow_12, mean_11], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   float_24 => convert_element_type_131
#   linear_25 => view_89
#   mean_11 => mean_11
#   pow_12 => pow_12
#   view_2 => view_90
# Graph fragment:
#   %mm_25 : Tensor "bf16[1, 512][512, 1]tnca:0" = PlaceHolder[target=mm_25]
#   %view_89 : Tensor "bf16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_25, [1, 1, 512]), kwargs = {})
#   %view_90 : Tensor "bf16[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_89, [1, 1, -1, 256]), kwargs = {})
#   %convert_element_type_131 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_90, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_131, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   return %buf101
triton_red_fused__to_copy__unsafe_view_mean_pow_view_27 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_mean_pow_view_27', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 2, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_mean_pow_view_27', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 4, 'r0_': 1024}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_mean_pow_view_27(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 2
    XBLOCK: tl.constexpr = 1
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[2, 256], strides=[256, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/fz/cfzkxpscl6noafpouzhhjux2qujiuhi3ep2gumbrn5aqrpnjhnmp.py
# Topologically Sorted Source Nodes: [linear_25, view_2, float_24, pow_12, mean_11, add_37, rsqrt_17, output_19, float_25, add_38, output_20, type_as_8, key_states, k_rot, x2_1, neg_4], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg]
# Source node to ATen node mapping:
#   add_37 => add_55
#   add_38 => add_56
#   float_24 => convert_element_type_131
#   float_25 => convert_element_type_132
#   k_rot => slice_38
#   key_states => permute_54
#   linear_25 => view_89
#   mean_11 => mean_11
#   neg_4 => neg_13
#   output_19 => mul_73
#   output_20 => mul_74
#   pow_12 => pow_12
#   rsqrt_17 => rsqrt_17
#   type_as_8 => convert_element_type_133
#   view_2 => view_90
#   x2_1 => slice_43
# Graph fragment:
#   %mm_25 : Tensor "bf16[1, 512][512, 1]tnca:0" = PlaceHolder[target=mm_25]
#   %buf101 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 2]tnca:0" = PlaceHolder[target=buf101]
#   %arg56_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg56_1]
#   %view_89 : Tensor "bf16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_25, [1, 1, 512]), kwargs = {})
#   %view_90 : Tensor "bf16[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_89, [1, 1, -1, 256]), kwargs = {})
#   %convert_element_type_131 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_90, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_131, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   %add_55 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_11, 1e-06), kwargs = {})
#   %rsqrt_17 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_55,), kwargs = {})
#   %mul_73 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_131, %rsqrt_17), kwargs = {})
#   %convert_element_type_132 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg56_1, torch.float32), kwargs = {})
#   %add_56 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_132, 1.0), kwargs = {})
#   %mul_74 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_73, %add_56), kwargs = {})
#   %convert_element_type_133 : Tensor "bf16[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_74, torch.bfloat16), kwargs = {})
#   %permute_54 : Tensor "bf16[1, 2, 1, 256][512, 256, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_133, [0, 2, 1, 3]), kwargs = {})
#   %slice_38 : Tensor "bf16[1, 2, 1, 64][512, 256, 512, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_54, 3, 0, 64), kwargs = {})
#   %slice_43 : Tensor "bf16[1, 2, 1, 32][512, 256, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_38, 3, 32, 9223372036854775807), kwargs = {})
#   %neg_13 : Tensor "bf16[1, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_43,), kwargs = {})
#   return %neg_13
triton_poi_fused__to_copy__unsafe_view_add_mean_mul_neg_pow_rsqrt_slice_transpose_view_28 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_mean_mul_neg_pow_rsqrt_slice_transpose_view_28', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 64}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_mean_mul_neg_pow_rsqrt_slice_transpose_view_28', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 456}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_mean_mul_neg_pow_rsqrt_slice_transpose_view_28(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 64
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (32 + x0 + 256*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (32 + x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tmp15 = -tmp14
    tl.store(out_ptr0 + (x0 + 64*x1), tmp15, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/4f/c4fhvmz4mlgwupynbdjpqi7o3y7stprpvtfrypnckvcjpolzuji7.py
# Topologically Sorted Source Nodes: [linear_25, view_2, float_24, pow_12, mean_11, add_37, rsqrt_17, output_19, float_25, add_38, output_20, type_as_8, key_states, k_rot, x2_1, neg_4, x1_1, cat_6], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   add_37 => add_55
#   add_38 => add_56
#   cat_6 => cat_4
#   float_24 => convert_element_type_131
#   float_25 => convert_element_type_132
#   k_rot => slice_38
#   key_states => permute_54
#   linear_25 => view_89
#   mean_11 => mean_11
#   neg_4 => neg_13
#   output_19 => mul_73
#   output_20 => mul_74
#   pow_12 => pow_12
#   rsqrt_17 => rsqrt_17
#   type_as_8 => convert_element_type_133
#   view_2 => view_90
#   x1_1 => slice_42
#   x2_1 => slice_43
# Graph fragment:
#   %mm_25 : Tensor "bf16[1, 512][512, 1]tnca:0" = PlaceHolder[target=mm_25]
#   %buf101 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 2]tnca:0" = PlaceHolder[target=buf101]
#   %arg56_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg56_1]
#   %view_89 : Tensor "bf16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_25, [1, 1, 512]), kwargs = {})
#   %view_90 : Tensor "bf16[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_89, [1, 1, -1, 256]), kwargs = {})
#   %convert_element_type_131 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_90, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_131, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   %add_55 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_11, 1e-06), kwargs = {})
#   %rsqrt_17 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_55,), kwargs = {})
#   %mul_73 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_131, %rsqrt_17), kwargs = {})
#   %convert_element_type_132 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg56_1, torch.float32), kwargs = {})
#   %add_56 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_132, 1.0), kwargs = {})
#   %mul_74 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_73, %add_56), kwargs = {})
#   %convert_element_type_133 : Tensor "bf16[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_74, torch.bfloat16), kwargs = {})
#   %permute_54 : Tensor "bf16[1, 2, 1, 256][512, 256, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_133, [0, 2, 1, 3]), kwargs = {})
#   %slice_38 : Tensor "bf16[1, 2, 1, 64][512, 256, 512, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_54, 3, 0, 64), kwargs = {})
#   %slice_43 : Tensor "bf16[1, 2, 1, 32][512, 256, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_38, 3, 32, 9223372036854775807), kwargs = {})
#   %neg_13 : Tensor "bf16[1, 2, 1, 32][64, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_43,), kwargs = {})
#   %slice_42 : Tensor "bf16[1, 2, 1, 32][512, 256, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_38, 3, 0, 32), kwargs = {})
#   %cat_4 : Tensor "bf16[1, 2, 1, 64][128, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_13, %slice_42], -1), kwargs = {})
#   return %buf103
triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_29 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_29', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 64}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_29', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 456}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_29(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 64
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (x0 + 256*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 64*x1), tmp14, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/vn/cvni36guf6gwx2jrmacigwmp4sc4rvwaremo6ybtdmxf3qkdmpud.py
# Topologically Sorted Source Nodes: [cos_2, cos_3, cos_4, sin_2, sin_3, sin_4, linear_25, view_2, float_24, pow_12, mean_11, add_37, rsqrt_17, output_19, float_25, add_38, output_20, type_as_8, key_states, k_rot, mul_65, mul_66, k_embed], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
# Source node to ATen node mapping:
#   add_37 => add_55
#   add_38 => add_56
#   cos_2 => clone_2, expand_3, select_24, unsqueeze_7, view_1
#   cos_3 => convert_element_type_2
#   cos_4 => unsqueeze_32
#   float_24 => convert_element_type_131
#   float_25 => convert_element_type_132
#   k_embed => add_58
#   k_rot => slice_38
#   key_states => permute_54
#   linear_25 => view_89
#   mean_11 => mean_11
#   mul_65 => mul_77
#   mul_66 => mul_78
#   output_19 => mul_73
#   output_20 => mul_74
#   pow_12 => pow_12
#   rsqrt_17 => rsqrt_17
#   sin_2 => clone, expand_2, select_12, unsqueeze_6, view
#   sin_3 => convert_element_type_3
#   sin_4 => unsqueeze_33
#   type_as_8 => convert_element_type_133
#   view_2 => view_90
# Graph fragment:
#   %mm_25 : Tensor "bf16[1, 512][512, 1]tnca:0" = PlaceHolder[target=mm_25]
#   %buf101 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 2]tnca:0" = PlaceHolder[target=buf101]
#   %arg56_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg56_1]
#   %select_scatter_default_5 : Tensor "f32[3, 1, 1, 32][32, 96, 96, 1]tnca:0" = PlaceHolder[target=select_scatter_default_5]
#   %cat_4 : Tensor "bf16[1, 2, 1, 64][128, 64, 64, 1]tnca:0" = PlaceHolder[target=cat_4]
#   %select_scatter_default_6 : Tensor "f32[3, 1, 1, 32][32, 96, 96, 1]tnca:0" = PlaceHolder[target=select_scatter_default_6]
#   %select_24 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_5, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_24, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 1, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 1, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_32 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %select_12 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_6, 0, 0), kwargs = {})
#   %unsqueeze_6 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_12, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_6, [1, 1, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 64]), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_33 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_3, 1), kwargs = {})
#   %view_89 : Tensor "bf16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_25, [1, 1, 512]), kwargs = {})
#   %view_90 : Tensor "bf16[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_89, [1, 1, -1, 256]), kwargs = {})
#   %convert_element_type_131 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_90, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_131, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   %add_55 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_11, 1e-06), kwargs = {})
#   %rsqrt_17 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_55,), kwargs = {})
#   %mul_73 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_131, %rsqrt_17), kwargs = {})
#   %convert_element_type_132 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg56_1, torch.float32), kwargs = {})
#   %add_56 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_132, 1.0), kwargs = {})
#   %mul_74 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_73, %add_56), kwargs = {})
#   %convert_element_type_133 : Tensor "bf16[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_74, torch.bfloat16), kwargs = {})
#   %permute_54 : Tensor "bf16[1, 2, 1, 256][512, 256, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_133, [0, 2, 1, 3]), kwargs = {})
#   %slice_38 : Tensor "bf16[1, 2, 1, 64][512, 256, 512, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_54, 3, 0, 64), kwargs = {})
#   %mul_77 : Tensor "bf16[1, 2, 1, 64][128, 64, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_38, %unsqueeze_32), kwargs = {})
#   %mul_78 : Tensor "bf16[1, 2, 1, 64][128, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_4, %unsqueeze_33), kwargs = {})
#   %add_58 : Tensor "bf16[1, 2, 1, 64][128, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_77, %mul_78), kwargs = {})
#   return %add_58
triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_30 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_30', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 128}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'in_ptr5': '*fp32', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_30', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1672}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_30(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 128
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 256*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp15 = tl.load(in_ptr3 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp18 = tl.load(in_ptr4 + (x2), xmask).to(tl.float32)
    tmp19 = tl.load(in_ptr5 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tmp16 = tmp15.to(tl.float32)
    tmp17 = tmp14 * tmp16
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp18 * tmp20
    tmp22 = tmp17 + tmp21
    tl.store(out_ptr0 + (x0 + 256*x1), tmp22, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/px/cpxzgh2nlnmwcpj6bz2orynhwzpboxsnp3yfyh5grjix6mylzmfr.py
# Topologically Sorted Source Nodes: [cos_2, cos_3, cos_4, sin_2, sin_3, sin_4, linear_25, view_2, float_24, pow_12, mean_11, add_37, rsqrt_17, output_19, float_25, add_38, output_20, type_as_8, key_states, k_rot, mul_65, mul_66, k_embed, k_pass, k_embed_1], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
# Source node to ATen node mapping:
#   add_37 => add_55
#   add_38 => add_56
#   cos_2 => clone_2, expand_3, select_24, unsqueeze_7, view_1
#   cos_3 => convert_element_type_2
#   cos_4 => unsqueeze_32
#   float_24 => convert_element_type_131
#   float_25 => convert_element_type_132
#   k_embed => add_58
#   k_embed_1 => cat_6
#   k_pass => slice_39
#   k_rot => slice_38
#   key_states => permute_54
#   linear_25 => view_89
#   mean_11 => mean_11
#   mul_65 => mul_77
#   mul_66 => mul_78
#   output_19 => mul_73
#   output_20 => mul_74
#   pow_12 => pow_12
#   rsqrt_17 => rsqrt_17
#   sin_2 => clone, expand_2, select_12, unsqueeze_6, view
#   sin_3 => convert_element_type_3
#   sin_4 => unsqueeze_33
#   type_as_8 => convert_element_type_133
#   view_2 => view_90
# Graph fragment:
#   %mm_25 : Tensor "bf16[1, 512][512, 1]tnca:0" = PlaceHolder[target=mm_25]
#   %buf101 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 2]tnca:0" = PlaceHolder[target=buf101]
#   %arg56_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg56_1]
#   %select_24 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_5, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_24, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 1, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 1, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_32 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %select_12 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_6, 0, 0), kwargs = {})
#   %unsqueeze_6 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_12, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_6, [1, 1, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 64]), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_33 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_3, 1), kwargs = {})
#   %view_89 : Tensor "bf16[1, 1, 512][512, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_25, [1, 1, 512]), kwargs = {})
#   %view_90 : Tensor "bf16[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_89, [1, 1, -1, 256]), kwargs = {})
#   %convert_element_type_131 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_90, torch.float32), kwargs = {})
#   %pow_12 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_131, 2), kwargs = {})
#   %mean_11 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_12, [-1], True), kwargs = {})
#   %add_55 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_11, 1e-06), kwargs = {})
#   %rsqrt_17 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_55,), kwargs = {})
#   %mul_73 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_131, %rsqrt_17), kwargs = {})
#   %convert_element_type_132 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg56_1, torch.float32), kwargs = {})
#   %add_56 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_132, 1.0), kwargs = {})
#   %mul_74 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_73, %add_56), kwargs = {})
#   %convert_element_type_133 : Tensor "bf16[1, 1, 2, 256][512, 512, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_74, torch.bfloat16), kwargs = {})
#   %permute_54 : Tensor "bf16[1, 2, 1, 256][512, 256, 512, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_133, [0, 2, 1, 3]), kwargs = {})
#   %slice_38 : Tensor "bf16[1, 2, 1, 64][512, 256, 512, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_54, 3, 0, 64), kwargs = {})
#   %mul_77 : Tensor "bf16[1, 2, 1, 64][128, 64, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_38, %unsqueeze_32), kwargs = {})
#   %mul_78 : Tensor "bf16[1, 2, 1, 64][128, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_4, %unsqueeze_33), kwargs = {})
#   %add_58 : Tensor "bf16[1, 2, 1, 64][128, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_77, %mul_78), kwargs = {})
#   %slice_39 : Tensor "bf16[1, 2, 1, 192][512, 256, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_54, 3, 64, 9223372036854775807), kwargs = {})
#   %cat_6 : Tensor "bf16[1, 2, 1, 256][512, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%add_58, %slice_39], -1), kwargs = {})
#   return %buf106
triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_31 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_31', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_31', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 2696}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_31(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 384
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 192)
    x1 = xindex // 192
    tmp0 = tl.load(in_ptr0 + (64 + x0 + 256*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (64 + x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 256*x1), tmp14, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/4t/c4togtfnjqqzjq2z7x4v2frn2yxxwphyxc7kowupychnanfmnwdd.py
# Topologically Sorted Source Nodes: [arange_1, cache_position, index_copy_], Original ATen: [aten.arange, aten.add, aten.index_copy]
# Source node to ATen node mapping:
#   arange_1 => iota_1
#   cache_position => add_59
#   index_copy_ => index_put
# Graph fragment:
#   %copy__6 : Tensor "i64[][]tnca:0" = PlaceHolder[target=copy__6]
#   %cat_6 : Tensor "bf16[1, 2, 1, 256][512, 256, 256, 1]tnca:0" = PlaceHolder[target=cat_6]
#   %index_put : Tensor "bf16[1, 2, 144, 256][73728, 36864, 256, 1]tnca:0" = PlaceHolder[target=index_put]
#   %iota_1 : Tensor "i64[1][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (1,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %add_59 : Tensor "i64[1][1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota_1, %arg58_1), kwargs = {})
#   %index_put : Tensor "bf16[1, 2, 144, 256][73728, 36864, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%arg59_1, [None, None, %add_59], %cat_6), kwargs = {})
#   return %buf108
triton_poi_fused_add_arange_index_copy_32 = async_compile.triton('triton_poi_fused_add_arange_index_copy_32', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_arange_index_copy_32', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1024}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_arange_index_copy_32(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 256)
    x1 = xindex // 256
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp9 = tl.load(in_ptr1 + (x2), xmask).to(tl.float32)
    tmp2 = tl.full([1], 0, tl.int64)
    tmp3 = tmp2 + tmp1
    tmp4 = (tl.full([XBLOCK], 144, tl.int32)).to(tl.int32)
    tmp5 = tmp3 + tmp4
    tmp6 = tmp3 < 0
    tmp7 = tl.where(tmp6, tmp5, tmp3)
    tl.device_assert((0 <= tmp7) & (tmp7 < 144), "index out of bounds: 0 <= tmp7 < 144")
    tl.store(out_ptr0 + (x0 + 256*tmp7 + 36864*x1), tmp9, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/6u/c6uosgbius4vlgrnw3rblnm6qre5mosgbulaakrkvbrredkxtwwp.py
# Topologically Sorted Source Nodes: [add_], Original ATen: [aten.add, aten.copy_]
# Source node to ATen node mapping:
#   add_ => add_60
# Graph fragment:
#   %copy__6 : Tensor "i64[][]tnca:0" = PlaceHolder[target=copy__6]
#   %add_60 : Tensor "i64[][]tnca:0" = PlaceHolder[target=add_60]
#   %buf108 : Tensor "bf16[1, 2, 144, 256][73728, 36864, 256, 1]tnca:0" = PlaceHolder[target=buf108]
#   %buf114 : Tensor "bf16[1, 2, 144, 256][73728, 36864, 256, 1]tnca:0" = PlaceHolder[target=buf114]
#   %add_60 : Tensor "i64[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg58_1, 1), kwargs = {})
#   %copy__6 : Tensor "i64[][]tnca:0"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg58_1, %add_60), kwargs = {})
#   return %add_60,%buf757
triton_poi_fused_add_copy__33 = async_compile.triton('triton_poi_fused_add_copy__33', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'out_ptr1': '*i64', 'xnumel': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_copy__33', 'mutated_arg_names': ['in_ptr0', 'out_ptr1'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_copy__33(in_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp2 = tl.full([1], 1, tl.int64)
    tmp3 = tmp1 + tmp2
    tl.store(out_ptr1 + (tl.full([XBLOCK], 0, tl.int32).broadcast_to(XBLOCK)), tmp3, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/gu/cgufkeozbrti4ws7x3n3hhxsmxlhebu7my66zdua5zw5dmmzsr2a.py
# Topologically Sorted Source Nodes: [linear_24], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_24 => mm_24, permute_51, view_83
# Graph fragment:
#   %convert_element_type_123 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_123]
#   %arg53_1 : Tensor "bf16[4096, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg53_1]
#   %view_83 : Tensor "bf16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_123, [1, 2048]), kwargs = {})
#   %permute_51 : Tensor "bf16[2048, 4096][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg53_1, [1, 0]), kwargs = {})
#   %mm_24 : Tensor "bf16[1, 4096][4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_83, %permute_51), kwargs = {})
#   return %mm_24
triton_tem_fused_mm_t_view_34 = async_compile.triton('triton_tem_fused_mm_t_view_34', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_34', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_34(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 4096
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 4096*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 4096*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/3d/c3d356yhtjooqqr63llkt3xnfbmuvbzileps7ixcypubfonpzfz6.py
# Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   chunk => split
#   float_22 => convert_element_type_126
#   linear_24 => view_84
#   mean_10 => mean_10
#   pow_11 => pow_11
#   view => view_85
# Graph fragment:
#   %mm_24 : Tensor "bf16[1, 4096][4096, 1]tnca:0" = PlaceHolder[target=mm_24]
#   %view_84 : Tensor "bf16[1, 1, 4096][4096, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_24, [1, 1, 4096]), kwargs = {})
#   %view_85 : Tensor "bf16[1, 1, 8, 512][4096, 4096, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_84, [1, 1, -1, 512]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_85, 256, -1), kwargs = {})
#   %convert_element_type_126 : Tensor "f32[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_9, torch.float32), kwargs = {})
#   %pow_11 : Tensor "f32[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_126, 2), kwargs = {})
#   %mean_10 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_11, [-1], True), kwargs = {})
#   return %buf91
triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_35 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_35', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 8, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_35', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 64, 'r0_': 4096}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_35(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 8
    XBLOCK: tl.constexpr = 1
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[8, 256], strides=[512, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x0), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/xh/cxhncg25qcquhdevttvzrhzh3ik5ycevgergv7sio6rfzcmuu27v.py
# Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10, add_35, rsqrt_16, output_17, float_23, add_36, output_18, type_as_7, query_states_1, q_rot, x2, neg_3, x1, cat_5], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   add_35 => add_53
#   add_36 => add_54
#   cat_5 => cat_3
#   chunk => split
#   float_22 => convert_element_type_126
#   float_23 => convert_element_type_127
#   linear_24 => view_84
#   mean_10 => mean_10
#   neg_3 => neg_12
#   output_17 => mul_71
#   output_18 => mul_72
#   pow_11 => pow_11
#   q_rot => slice_36
#   query_states_1 => permute_52
#   rsqrt_16 => rsqrt_16
#   type_as_7 => convert_element_type_128
#   view => view_85
#   x1 => slice_40
#   x2 => slice_41
# Graph fragment:
#   %mm_24 : Tensor "bf16[1, 4096][4096, 1]tnca:0" = PlaceHolder[target=mm_24]
#   %buf91 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 8]tnca:0" = PlaceHolder[target=buf91]
#   %arg54_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg54_1]
#   %view_84 : Tensor "bf16[1, 1, 4096][4096, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_24, [1, 1, 4096]), kwargs = {})
#   %view_85 : Tensor "bf16[1, 1, 8, 512][4096, 4096, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_84, [1, 1, -1, 512]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_85, 256, -1), kwargs = {})
#   %convert_element_type_126 : Tensor "f32[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_9, torch.float32), kwargs = {})
#   %pow_11 : Tensor "f32[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_126, 2), kwargs = {})
#   %mean_10 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_11, [-1], True), kwargs = {})
#   %add_53 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_10, 1e-06), kwargs = {})
#   %rsqrt_16 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_53,), kwargs = {})
#   %mul_71 : Tensor "f32[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_126, %rsqrt_16), kwargs = {})
#   %convert_element_type_127 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg54_1, torch.float32), kwargs = {})
#   %add_54 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_127, 1.0), kwargs = {})
#   %mul_72 : Tensor "f32[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_71, %add_54), kwargs = {})
#   %convert_element_type_128 : Tensor "bf16[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_72, torch.bfloat16), kwargs = {})
#   %permute_52 : Tensor "bf16[1, 8, 1, 256][2048, 256, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_128, [0, 2, 1, 3]), kwargs = {})
#   %slice_36 : Tensor "bf16[1, 8, 1, 64][2048, 256, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_52, 3, 0, 64), kwargs = {})
#   %slice_41 : Tensor "bf16[1, 8, 1, 32][2048, 256, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_36, 3, 32, 9223372036854775807), kwargs = {})
#   %neg_12 : Tensor "bf16[1, 8, 1, 32][256, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_41,), kwargs = {})
#   %slice_40 : Tensor "bf16[1, 8, 1, 32][2048, 256, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_36, 3, 0, 32), kwargs = {})
#   %cat_3 : Tensor "bf16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_12, %slice_40], -1), kwargs = {})
#   return %neg_12,%buf94
triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3232}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 256
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (32 + x0 + 512*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (32 + x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp16 = tl.load(in_ptr0 + (x0 + 512*x1), xmask).to(tl.float32)
    tmp19 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tmp15 = -tmp14
    tmp17 = tmp16.to(tl.float32)
    tmp18 = tmp17 * tmp7
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp20 + tmp11
    tmp22 = tmp18 * tmp21
    tmp23 = tmp22.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 64*x1), tmp15, xmask)
    tl.store(out_ptr1 + (x0 + 64*x1), tmp23, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/n3/cn3v533axkvwalukvt2s677e44xw6vpxdmb7kd3zg3bfaq7edfvw.py
# Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10, add_35, rsqrt_16, output_17, float_23, add_36, output_18, type_as_7, query_states_1, q_rot, cos_2, cos_3, cos_4, mul_63, sin_2, sin_3, sin_4, mul_64, q_embed], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.select, aten.cat, aten.unsqueeze]
# Source node to ATen node mapping:
#   add_35 => add_53
#   add_36 => add_54
#   chunk => split
#   cos_2 => clone_2, expand_3, select_24, unsqueeze_7, view_1
#   cos_3 => convert_element_type_2
#   cos_4 => unsqueeze_32
#   float_22 => convert_element_type_126
#   float_23 => convert_element_type_127
#   linear_24 => view_84
#   mean_10 => mean_10
#   mul_63 => mul_75
#   mul_64 => mul_76
#   output_17 => mul_71
#   output_18 => mul_72
#   pow_11 => pow_11
#   q_embed => add_57
#   q_rot => slice_36
#   query_states_1 => permute_52
#   rsqrt_16 => rsqrt_16
#   sin_2 => clone, expand_2, select_12, unsqueeze_6, view
#   sin_3 => convert_element_type_3
#   sin_4 => unsqueeze_33
#   type_as_7 => convert_element_type_128
#   view => view_85
# Graph fragment:
#   %mm_24 : Tensor "bf16[1, 4096][4096, 1]tnca:0" = PlaceHolder[target=mm_24]
#   %buf91 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 8]tnca:0" = PlaceHolder[target=buf91]
#   %arg54_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg54_1]
#   %select_scatter_default_5 : Tensor "f32[3, 1, 1, 32][32, 96, 96, 1]tnca:0" = PlaceHolder[target=select_scatter_default_5]
#   %cat_3 : Tensor "bf16[1, 8, 1, 64][512, 64, 64, 1]tnca:0" = PlaceHolder[target=cat_3]
#   %select_scatter_default_6 : Tensor "f32[3, 1, 1, 32][32, 96, 96, 1]tnca:0" = PlaceHolder[target=select_scatter_default_6]
#   %view_84 : Tensor "bf16[1, 1, 4096][4096, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_24, [1, 1, 4096]), kwargs = {})
#   %view_85 : Tensor "bf16[1, 1, 8, 512][4096, 4096, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_84, [1, 1, -1, 512]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_85, 256, -1), kwargs = {})
#   %convert_element_type_126 : Tensor "f32[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_9, torch.float32), kwargs = {})
#   %pow_11 : Tensor "f32[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_126, 2), kwargs = {})
#   %mean_10 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_11, [-1], True), kwargs = {})
#   %add_53 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_10, 1e-06), kwargs = {})
#   %rsqrt_16 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_53,), kwargs = {})
#   %mul_71 : Tensor "f32[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_126, %rsqrt_16), kwargs = {})
#   %convert_element_type_127 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg54_1, torch.float32), kwargs = {})
#   %add_54 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_127, 1.0), kwargs = {})
#   %mul_72 : Tensor "f32[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_71, %add_54), kwargs = {})
#   %convert_element_type_128 : Tensor "bf16[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_72, torch.bfloat16), kwargs = {})
#   %permute_52 : Tensor "bf16[1, 8, 1, 256][2048, 256, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_128, [0, 2, 1, 3]), kwargs = {})
#   %slice_36 : Tensor "bf16[1, 8, 1, 64][2048, 256, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_52, 3, 0, 64), kwargs = {})
#   %select_24 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_5, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_24, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 1, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 1, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_32 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %mul_75 : Tensor "bf16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_36, %unsqueeze_32), kwargs = {})
#   %select_12 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_6, 0, 0), kwargs = {})
#   %unsqueeze_6 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_12, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_6, [1, 1, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 64]), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_33 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_3, 1), kwargs = {})
#   %mul_76 : Tensor "bf16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_3, %unsqueeze_33), kwargs = {})
#   %add_57 : Tensor "bf16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_75, %mul_76), kwargs = {})
#   return %add_57
triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'in_ptr5': '*fp32', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4768}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 512*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp15 = tl.load(in_ptr3 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp18 = tl.load(in_ptr4 + (x2), xmask).to(tl.float32)
    tmp19 = tl.load(in_ptr5 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tmp16 = tmp15.to(tl.float32)
    tmp17 = tmp14 * tmp16
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tmp18 * tmp20
    tmp22 = tmp17 + tmp21
    tl.store(out_ptr0 + (x0 + 256*x1), tmp22, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/jn/cjn3n47uwwwxp2hvblm5iytn26u5n6sxltjw3fpevly3gpx6pog7.py
# Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10, add_35, rsqrt_16, output_17, float_23, add_36, output_18, type_as_7, query_states_1, q_rot, cos_2, cos_3, cos_4, mul_63, sin_2, sin_3, sin_4, mul_64, q_embed, q_pass, q_embed_1], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.select, aten.cat, aten.unsqueeze]
# Source node to ATen node mapping:
#   add_35 => add_53
#   add_36 => add_54
#   chunk => split
#   cos_2 => clone_2, expand_3, select_24, unsqueeze_7, view_1
#   cos_3 => convert_element_type_2
#   cos_4 => unsqueeze_32
#   float_22 => convert_element_type_126
#   float_23 => convert_element_type_127
#   linear_24 => view_84
#   mean_10 => mean_10
#   mul_63 => mul_75
#   mul_64 => mul_76
#   output_17 => mul_71
#   output_18 => mul_72
#   pow_11 => pow_11
#   q_embed => add_57
#   q_embed_1 => cat_5
#   q_pass => slice_37
#   q_rot => slice_36
#   query_states_1 => permute_52
#   rsqrt_16 => rsqrt_16
#   sin_2 => clone, expand_2, select_12, unsqueeze_6, view
#   sin_3 => convert_element_type_3
#   sin_4 => unsqueeze_33
#   type_as_7 => convert_element_type_128
#   view => view_85
# Graph fragment:
#   %mm_24 : Tensor "bf16[1, 4096][4096, 1]tnca:0" = PlaceHolder[target=mm_24]
#   %buf91 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 8]tnca:0" = PlaceHolder[target=buf91]
#   %arg54_1 : Tensor "bf16[256][1]tnca:0" = PlaceHolder[target=arg54_1]
#   %view_84 : Tensor "bf16[1, 1, 4096][4096, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_24, [1, 1, 4096]), kwargs = {})
#   %view_85 : Tensor "bf16[1, 1, 8, 512][4096, 4096, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_84, [1, 1, -1, 512]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_85, 256, -1), kwargs = {})
#   %convert_element_type_126 : Tensor "f32[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_9, torch.float32), kwargs = {})
#   %pow_11 : Tensor "f32[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_126, 2), kwargs = {})
#   %mean_10 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_11, [-1], True), kwargs = {})
#   %add_53 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_10, 1e-06), kwargs = {})
#   %rsqrt_16 : Tensor "f32[1, 1, 8, 1][8, 8, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_53,), kwargs = {})
#   %mul_71 : Tensor "f32[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_126, %rsqrt_16), kwargs = {})
#   %convert_element_type_127 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg54_1, torch.float32), kwargs = {})
#   %add_54 : Tensor "f32[256][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_127, 1.0), kwargs = {})
#   %mul_72 : Tensor "f32[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_71, %add_54), kwargs = {})
#   %convert_element_type_128 : Tensor "bf16[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_72, torch.bfloat16), kwargs = {})
#   %permute_52 : Tensor "bf16[1, 8, 1, 256][2048, 256, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_128, [0, 2, 1, 3]), kwargs = {})
#   %slice_36 : Tensor "bf16[1, 8, 1, 64][2048, 256, 2048, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_52, 3, 0, 64), kwargs = {})
#   %select_24 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_5, 0, 0), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_24, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 1, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 1, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_32 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %mul_75 : Tensor "bf16[1, 8, 1, 64][512, 64, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_36, %unsqueeze_32), kwargs = {})
#   %select_12 : Tensor "f32[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_6, 0, 0), kwargs = {})
#   %unsqueeze_6 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_12, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_6, [1, 1, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 64]), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[1, 1, 64][64, 64, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.bfloat16), kwargs = {})
#   %unsqueeze_33 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_3, 1), kwargs = {})
#   %mul_76 : Tensor "bf16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_3, %unsqueeze_33), kwargs = {})
#   %add_57 : Tensor "bf16[1, 8, 1, 64][512, 64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_75, %mul_76), kwargs = {})
#   %slice_37 : Tensor "bf16[1, 8, 1, 192][2048, 256, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_52, 3, 64, 9223372036854775807), kwargs = {})
#   %cat_5 : Tensor "bf16[1, 8, 1, 256][2048, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%add_57, %slice_37], -1), kwargs = {})
#   return %buf98
triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 2048}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 9632}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1536
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 192)
    x1 = xindex // 192
    tmp0 = tl.load(in_ptr0 + (64 + x0 + 512*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (64 + x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 256*x1), tmp14, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/tq/ctq5akbd7dxlu7natsvnfb2si3zg4lvm4swnb2jn3hw33qbqiuge.py
# Topologically Sorted Source Nodes: [matmul, key_states_1, transpose_27], Original ATen: [aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.bmm]
# Source node to ATen node mapping:
#   key_states_1 => clone_17, expand_5, unsqueeze_36, view_94
#   matmul => bmm, view_96, view_97
#   transpose_27 => permute_57
# Graph fragment:
#   %expand_8 : Tensor "bf16[1, 8, 1, 256][2048, 256, 256, 1]tnca:0" = PlaceHolder[target=expand_8]
#   %buf108 : Tensor "bf16[1, 2, 144, 256][73728, 36864, 256, 1]tnca:0" = PlaceHolder[target=buf108]
#   %view_96 : Tensor "bf16[8, 1, 256][256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_8, [8, 1, 256]), kwargs = {})
#   %unsqueeze_36 : Tensor "bf16[1, 2, 1, 144, 256][73728, 36864, 36864, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%index_put, 2), kwargs = {})
#   %expand_5 : Tensor "bf16[1, 2, 4, 144, 256][73728, 36864, 0, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_36, [1, 2, 4, 144, 256]), kwargs = {})
#   %clone_17 : Tensor "bf16[1, 2, 4, 144, 256][294912, 147456, 36864, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_5,), kwargs = {memory_format: torch.contiguous_format})
#   %view_94 : Tensor "bf16[1, 8, 144, 256][294912, 36864, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_17, [1, 8, 144, 256]), kwargs = {})
#   %permute_57 : Tensor "bf16[1, 8, 256, 144][294912, 36864, 1, 256]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_94, [0, 1, 3, 2]), kwargs = {})
#   %view_97 : Tensor "bf16[8, 256, 144][36864, 1, 256]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_9, [8, 256, 144]), kwargs = {})
#   %bmm : Tensor "bf16[8, 1, 144][144, 144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_96, %view_97), kwargs = {})
#   return %bmm
triton_red_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_39 = async_compile.triton('triton_red_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_39', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 2048, 'r0_': 256},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_39', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 4608, 'r0_': 4096}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_39(in_ptr0, in_ptr1, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1152
    XBLOCK: tl.constexpr = 1
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 144
    x0 = (xindex % 144)
    _tmp4 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_2 + 256*x1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tl.load(in_ptr1 + (r0_2 + 256*x0 + 36864*(x1 // 4)), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp2 = tmp0 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask, tmp5, _tmp4)
    tmp4 = triton_helpers.promote_to_tensor(tl.sum(_tmp4, 0))
    tl.store(out_ptr0 + (x3), tmp4, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/hg/chgqyxvyhv2muau4e5k5rjg7kp6nkutdhm4xwf7flvs2afv7jwwv.py
# Topologically Sorted Source Nodes: [matmul, attn_weights, arange, getitem, getitem_1, getitem_2, allowed, mask_1, mask, getitem_3, attn_weights_1, softmax], Original ATen: [aten.view, aten.mul, aten.arange, aten.unsqueeze, aten.select, aten.le, aten.masked_fill, aten.full, aten.add, aten._to_copy, aten._softmax]
# Source node to ATen node mapping:
#   allowed => le
#   arange => iota
#   attn_weights => mul_79
#   attn_weights_1 => add_61
#   getitem => unsqueeze
#   getitem_1 => select
#   getitem_2 => unsqueeze_1
#   getitem_3 => unsqueeze_2, unsqueeze_3
#   mask => full_default
#   mask_1 => full_default_1, where
#   matmul => view_98
#   softmax => amax, convert_element_type_138, exp_18, sub_3, sum_13
# Graph fragment:
#   %bmm : Tensor "bf16[8, 1, 144][144, 144, 1]tnca:0" = PlaceHolder[target=bmm]
#   %arg0_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %amax : Tensor "f32[1, 8, 1, 1][8, 1, 8, 8]tnca:0" = PlaceHolder[target=amax]
#   %exp_18 : Tensor "f32[1, 8, 1, 144][1152, 144, 1152, 1]tnca:0" = PlaceHolder[target=exp_18]
#   %view_98 : Tensor "bf16[1, 8, 1, 144][1152, 144, 144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 8, 1, 144]), kwargs = {})
#   %mul_79 : Tensor "bf16[1, 8, 1, 144][1152, 144, 144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_98, 0.0625), kwargs = {})
#   %iota : Tensor "i64[144][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (144,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze : Tensor "i64[1, 144][144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota, 0), kwargs = {})
#   %select : Tensor "i64[1][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg0_1, 0, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "i64[1, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select, 1), kwargs = {})
#   %le : Tensor "b8[1, 144][144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.le.Tensor](args = (%unsqueeze, %unsqueeze_1), kwargs = {})
#   %full_default_1 : Tensor "bf16[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], 0.0), kwargs = {dtype: torch.bfloat16, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %full_default : Tensor "bf16[1, 144][144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 144], -inf), kwargs = {dtype: torch.bfloat16, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %where : Tensor "bf16[1, 144][144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%le, %full_default_1, %full_default), kwargs = {})
#   %unsqueeze_2 : Tensor "bf16[1, 1, 144][144, 144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%where, 0), kwargs = {})
#   %unsqueeze_3 : Tensor "bf16[1, 1, 1, 144][144, 144, 144, 1]tnca:0"[num_users=6] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_2, 1), kwargs = {})
#   %add_61 : Tensor "bf16[1, 8, 1, 144][1152, 144, 144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_79, %unsqueeze_3), kwargs = {})
#   %convert_element_type_138 : Tensor "f32[1, 8, 1, 144][1152, 144, 144, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_61, torch.float32), kwargs = {})
#   %amax : Tensor "f32[1, 8, 1, 1][8, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%convert_element_type_138, [-1], True), kwargs = {})
#   %sub_3 : Tensor "f32[1, 8, 1, 144][1152, 144, 144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%convert_element_type_138, %amax), kwargs = {})
#   %exp_18 : Tensor "f32[1, 8, 1, 144][1152, 144, 144, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub_3,), kwargs = {})
#   %sum_13 : Tensor "f32[1, 8, 1, 1][8, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp_18, [-1], True), kwargs = {})
#   return %amax,%exp_18,%sum_13
triton_red_fused__softmax__to_copy_add_arange_full_le_masked_fill_mul_select_unsqueeze_view_40 = async_compile.triton('triton_red_fused__softmax__to_copy_add_arange_full_le_masked_fill_mul_select_unsqueeze_view_40', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 8, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*i64', 'out_ptr1': '*fp32', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__softmax__to_copy_add_arange_full_le_masked_fill_mul_select_unsqueeze_view_40', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 2, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'x': 64, 'r0_': 11520}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__softmax__to_copy_add_arange_full_le_masked_fill_mul_select_unsqueeze_view_40(in_ptr0, in_ptr1, out_ptr1, out_ptr2, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 8
    XBLOCK: tl.constexpr = 1
    r0_numel = 144
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[8, 144], strides=[144, 1], block_shape=[XBLOCK, R0_BLOCK])
    tmp3 = tl.load(in_ptr1 + (0))
    tmp4 = tl.broadcast_to(tmp3, [R0_BLOCK])
    _tmp14 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.full([1], 0.0625, tl.float32)
        tmp2 = tmp0 * tmp1
        tmp5 = (r0_1).to(tl.int64)
        tmp6 = (tmp5).to(tl.int64)
        tmp7 = tmp6 <= tmp4
        tmp8 = tl.full([1], 0.0, tl.float32)
        tmp9 = tl.full([1], float("-inf"), tl.float32)
        tmp10 = tl.where(tmp7, tmp8, tmp9)
        tmp11 = tmp2 + tmp10
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tl.broadcast_to(tmp12, [R0_BLOCK])
        tmp15 = tl.maximum(_tmp14, tmp13, tl.PropagateNan.ALL)
        _tmp14 = tl.where(r0_mask, tmp15, _tmp14)
    tmp14 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp14, 0))
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[8, 144], strides=[144, 1], block_shape=[XBLOCK, R0_BLOCK])
    tmp19 = tl.load(in_ptr1 + (0))
    tmp20 = tl.broadcast_to(tmp19, [R0_BLOCK])
    _tmp32 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp16 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp17 = tl.full([1], 0.0625, tl.float32)
        tmp18 = tmp16 * tmp17
        tmp21 = (r0_1).to(tl.int64)
        tmp22 = (tmp21).to(tl.int64)
        tmp23 = tmp22 <= tmp20
        tmp24 = tl.full([1], 0.0, tl.float32)
        tmp25 = tl.full([1], float("-inf"), tl.float32)
        tmp26 = tl.where(tmp23, tmp24, tmp25)
        tmp27 = tmp18 + tmp26
        tmp28 = tmp27.to(tl.float32)
        tmp29 = tmp28 - tmp14
        tmp30 = libdevice.exp(tmp29)
        tmp31 = tl.broadcast_to(tmp30, [R0_BLOCK])
        tmp33 = _tmp32 + tmp31
        _tmp32 = tl.where(r0_mask, tmp33, _tmp32)
        tl.store(out_ptr1 + (r0_1 + 144*x0), tmp30, r0_mask)
    tmp32 = triton_helpers.promote_to_tensor(tl.sum(_tmp32, 0))
    tl.store(out_ptr2 + (x0), tmp32, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/dt/cdths6cfpdojaeiauusqptf6bqyhcsqp2mwpbjz2onarldmp6moi.py
# Topologically Sorted Source Nodes: [linear_24, view, chunk, softmax, attn_weights_2, attn_output, value_states_1, transpose_28, reshape_24, gate_1, sigmoid_3, attn_output_3], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._softmax, aten._to_copy, aten.unsqueeze, aten.expand, aten.clone, aten.bmm, aten.transpose, aten.sigmoid, aten.mul]
# Source node to ATen node mapping:
#   attn_output => bmm_1, view_100, view_101, view_99
#   attn_output_3 => mul_80
#   attn_weights_2 => convert_element_type_139
#   chunk => split
#   gate_1 => clone_16, view_86
#   linear_24 => view_84
#   reshape_24 => view_102
#   sigmoid_3 => sigmoid_3
#   softmax => div_12
#   transpose_28 => permute_58
#   value_states_1 => clone_18, expand_7, unsqueeze_39, view_95
#   view => view_85
# Graph fragment:
#   %exp_18 : Tensor "f32[1, 8, 1, 144][1152, 144, 1152, 1]tnca:0" = PlaceHolder[target=exp_18]
#   %sum_13 : Tensor "f32[1, 8, 1, 1][8, 1, 8, 8]tnca:0" = PlaceHolder[target=sum_13]
#   %buf114 : Tensor "bf16[1, 2, 144, 256][73728, 36864, 256, 1]tnca:0" = PlaceHolder[target=buf114]
#   %bmm_1 : Tensor "bf16[8, 1, 256][256, 256, 1]tnca:0" = PlaceHolder[target=bmm_1]
#   %mm_24 : Tensor "bf16[1, 4096][4096, 1]tnca:0" = PlaceHolder[target=mm_24]
#   %view_84 : Tensor "bf16[1, 1, 4096][4096, 4096, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_24, [1, 1, 4096]), kwargs = {})
#   %view_85 : Tensor "bf16[1, 1, 8, 512][4096, 4096, 512, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_84, [1, 1, -1, 512]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_85, 256, -1), kwargs = {})
#   %div_12 : Tensor "f32[1, 8, 1, 144][1152, 144, 144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp_18, %sum_13), kwargs = {})
#   %convert_element_type_139 : Tensor "bf16[1, 8, 1, 144][1152, 144, 144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_12, torch.bfloat16), kwargs = {})
#   %view_99 : Tensor "bf16[8, 1, 144][144, 144, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_10, [8, 1, 144]), kwargs = {})
#   %unsqueeze_39 : Tensor "bf16[1, 2, 1, 144, 256][73728, 36864, 36864, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%index_put_1, 2), kwargs = {})
#   %expand_7 : Tensor "bf16[1, 2, 4, 144, 256][73728, 36864, 0, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_39, [1, 2, 4, 144, 256]), kwargs = {})
#   %clone_18 : Tensor "bf16[1, 2, 4, 144, 256][294912, 147456, 36864, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_7,), kwargs = {memory_format: torch.contiguous_format})
#   %view_95 : Tensor "bf16[1, 8, 144, 256][294912, 36864, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_18, [1, 8, 144, 256]), kwargs = {})
#   %view_100 : Tensor "bf16[8, 144, 256][36864, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_11, [8, 144, 256]), kwargs = {})
#   %bmm_1 : Tensor "bf16[8, 1, 256][256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_99, %view_100), kwargs = {})
#   %view_101 : Tensor "bf16[1, 8, 1, 256][2048, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 8, 1, 256]), kwargs = {})
#   %permute_58 : Tensor "bf16[1, 1, 8, 256][2048, 256, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_101, [0, 2, 1, 3]), kwargs = {})
#   %view_102 : Tensor "bf16[1, 1, 2048][2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%permute_58, [1, 1, -1]), kwargs = {})
#   %clone_16 : Tensor "bf16[1, 1, 8, 256][2048, 2048, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%getitem_10,), kwargs = {memory_format: torch.contiguous_format})
#   %view_86 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_16, [1, 1, 2048]), kwargs = {})
#   %sigmoid_3 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sigmoid.default](args = (%view_86,), kwargs = {})
#   %mul_80 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_102, %sigmoid_3), kwargs = {})
#   return %bmm_1,%mul_80
triton_red_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_41 = async_compile.triton('triton_red_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_41', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 2048, 'r0_': 256},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_41', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 12288, 'r0_': 4608}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_41(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 2048
    XBLOCK: tl.constexpr = 1
    r0_numel = 144
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 256
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[8, 144], strides=[144, 1], block_shape=[(255 + XBLOCK) // 256, R0_BLOCK])
    tmp1 = tl.load(in_ptr1 + (x1), None, eviction_policy='evict_last')
    x0 = (xindex % 256)
    _tmp7 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([xoffset // 256, r0_offset])[:, :, None, None], [(255 + XBLOCK) // 256, R0_BLOCK, ((1) * ((1) <= ((255 + XBLOCK) // 256)) + ((255 + XBLOCK) // 256) * (((255 + XBLOCK) // 256) < (1))), ((256) * ((256) <= (XBLOCK)) + (XBLOCK) * ((XBLOCK) < (256)))]), [0, 2, 3, 1]), [R0_BLOCK])
        tmp4 = tl.load(in_ptr2 + (x0 + 256*r0_2 + 36864*(x1 // 4)), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp2 = (tmp0 / tmp1)
        tmp3 = tmp2.to(tl.float32)
        tmp5 = tmp3 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
    tmp7 = triton_helpers.promote_to_tensor(tl.sum(_tmp7, 0))
    tmp9 = tl.load(in_ptr3 + (256 + 512*(x3 // 256) + ((x3 % 256))), None).to(tl.float32)
    tmp10 = tl.sigmoid(tmp9)
    tmp11 = tmp7 * tmp10
    tl.store(in_out_ptr0 + (x3), tmp11, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/cz/cczciw4okjfarr3jn7da6twb67tioinuatuyjcqn6nq3nptwbvul.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, output_12, hidden_states_21, down_proj_2, hidden_states_23, attn_output_4, hidden_states_27, float_26, pow_13, mean_12, add_44, rsqrt_18, output_21, float_27, add_45, output_22, hidden_states_28], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_44 => add_63
#   add_45 => add_64
#   attn_output_4 => view_104
#   down_proj_1 => view_55
#   down_proj_2 => view_82
#   float_26 => convert_element_type_144
#   float_27 => convert_element_type_145
#   hidden_states_15 => add_33
#   hidden_states_21 => add_46
#   hidden_states_23 => add_50
#   hidden_states_27 => add_62
#   hidden_states_28 => convert_element_type_146
#   mean_12 => mean_12
#   output_12 => view_76
#   output_21 => mul_81
#   output_22 => mul_82
#   pow_13 => pow_13
#   rsqrt_18 => rsqrt_18
# Graph fragment:
#   %add_29 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_29]
#   %mm_15 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_15]
#   %mm_20 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_20]
#   %mm_23 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_23]
#   %mm_27 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_27]
#   %add_62 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_62]
#   %buf119 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf119]
#   %arg62_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg62_1]
#   %view_55 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_15, [1, 1, 2048]), kwargs = {})
#   %add_33 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_29, %view_55), kwargs = {})
#   %view_76 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_20, [1, 1, 2048]), kwargs = {})
#   %add_46 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_33, %view_76), kwargs = {})
#   %view_82 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_23, [1, 1, 2048]), kwargs = {})
#   %add_50 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_46, %view_82), kwargs = {})
#   %view_104 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_27, [1, 1, 2048]), kwargs = {})
#   %add_62 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_50, %view_104), kwargs = {})
#   %convert_element_type_144 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_62, torch.float32), kwargs = {})
#   %pow_13 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_144, 2), kwargs = {})
#   %mean_12 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_13, [-1], True), kwargs = {})
#   %add_63 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_12, 1e-06), kwargs = {})
#   %rsqrt_18 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_63,), kwargs = {})
#   %mul_81 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_144, %rsqrt_18), kwargs = {})
#   %convert_element_type_145 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg62_1, torch.float32), kwargs = {})
#   %add_64 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_145, 1.0), kwargs = {})
#   %mul_82 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_81, %add_64), kwargs = {})
#   %convert_element_type_146 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_82, torch.bfloat16), kwargs = {})
#   return %add_62,%buf119,%convert_element_type_146
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 40960}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr1, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr2, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr3, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp7 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8.to(tl.float32)
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp8, r0_mask)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tma_descriptor5 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.debug_barrier()
        tmp14 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 2048.0, tl.float32)
        tmp17 = (tmp12 / tmp16)
        tmp18 = tl.full([1], 1e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tl.full([1], 1.0, tl.float32)
        tmp25 = tmp23 + tmp24
        tmp26 = tmp21 * tmp25
        tmp27 = tmp26.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp27, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/k7/ck7mfsiwr7anuoe2u7j5gvtbexw25uobaptxyb7drmfzaf53hted.py
# Topologically Sorted Source Nodes: [down_proj_23, hidden_states_179, float_158, pow_79, mean_78, add_282, rsqrt_114, output_138, float_159, add_283, output_139, hidden_states_180], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_282 => add_402
#   add_283 => add_403
#   down_proj_23 => view_655
#   float_158 => convert_element_type_910
#   float_159 => convert_element_type_911
#   hidden_states_179 => add_401
#   hidden_states_180 => convert_element_type_912
#   mean_78 => mean_78
#   output_138 => mul_489
#   output_139 => mul_490
#   pow_79 => pow_79
#   rsqrt_114 => rsqrt_114
# Graph fragment:
#   %add_397 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=add_397]
#   %mm_185 : Tensor "bf16[1, 2048][2048, 1]tnca:0" = PlaceHolder[target=mm_185]
#   %buf740 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf740]
#   %arg376_1 : Tensor "bf16[2048][1]tnca:0" = PlaceHolder[target=arg376_1]
#   %view_655 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_185, [1, 1, 2048]), kwargs = {})
#   %add_401 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_397, %view_655), kwargs = {})
#   %convert_element_type_910 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_401, torch.float32), kwargs = {})
#   %pow_79 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_910, 2), kwargs = {})
#   %mean_78 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_79, [-1], True), kwargs = {})
#   %add_402 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_78, 1e-06), kwargs = {})
#   %rsqrt_114 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_402,), kwargs = {})
#   %mul_489 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_910, %rsqrt_114), kwargs = {})
#   %convert_element_type_911 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg376_1, torch.float32), kwargs = {})
#   %add_403 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_911, 1.0), kwargs = {})
#   %mul_490 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_489, %add_403), kwargs = {})
#   %convert_element_type_912 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_490, torch.bfloat16), kwargs = {})
#   return %buf740,%convert_element_type_912
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_43 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_43', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*bf16', 'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_43', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 20480}, 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_43(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[2048], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 2048.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 1e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tl.full([1], 1.0, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = tmp17 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp23, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41s1-qwen/runs/final-dk/decode/inductor_cache/xk/cxk4bxdo5wnuy6tbvh5upss5jcgx5pl6eaoyzpb7762g3v3unwpw.py
# Topologically Sorted Source Nodes: [down_proj_23, hidden_states_179, float_158, pow_79, mean_78, add_282, rsqrt_114, output_138, float_159, add_283, output_139, hidden_states_180, getitem_284, logits], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   add_282 => add_402
#   add_283 => add_403
#   down_proj_23 => view_655
#   float_158 => convert_element_type_910
#   float_159 => convert_element_type_911
#   getitem_284 => slice_174
#   hidden_states_179 => add_401
#   hidden_states_180 => convert_element_type_912
#   logits => mm_186, permute_378, view_656
#   mean_78 => mean_78
#   output_138 => mul_489
#   output_139 => mul_490
#   pow_79 => pow_79
#   rsqrt_114 => rsqrt_114
# Graph fragment:
#   %convert_element_type_912 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0" = PlaceHolder[target=convert_element_type_912]
#   %arg2_1 : Tensor "bf16[248320, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %view_655 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_185, [1, 1, 2048]), kwargs = {})
#   %add_401 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_397, %view_655), kwargs = {})
#   %convert_element_type_910 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_401, torch.float32), kwargs = {})
#   %pow_79 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_910, 2), kwargs = {})
#   %mean_78 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_79, [-1], True), kwargs = {})
#   %add_402 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_78, 1e-06), kwargs = {})
#   %rsqrt_114 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_402,), kwargs = {})
#   %mul_489 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_910, %rsqrt_114), kwargs = {})
#   %convert_element_type_911 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg376_1, torch.float32), kwargs = {})
#   %add_403 : Tensor "f32[2048][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_911, 1.0), kwargs = {})
#   %mul_490 : Tensor "f32[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_489, %add_403), kwargs = {})
#   %convert_element_type_912 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_490, torch.bfloat16), kwargs = {})
#   %slice_174 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%convert_element_type_912, 1, -1, 9223372036854775807), kwargs = {})
#   %view_656 : Tensor "bf16[1, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%slice_174, [1, 2048]), kwargs = {})
#   %permute_378 : Tensor "bf16[2048, 248320][1, 2048]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg2_1, [1, 0]), kwargs = {})
#   %mm_186 : Tensor "bf16[1, 248320][248320, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_656, %permute_378), kwargs = {})
#   return %mm_186
triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_44 = async_compile.triton('triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_44', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_44', 'backend_hash': '1E9FB3B537419DBA1C3B4D87B4648F25D53D122ED887FFF20471233707A87BB0', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_44(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 248320
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 248320*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 248320*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg3_1), ((1, 1), (32, )), ((1, 1), (1, )), 'input')
        buf92 = empty_strided((3, 1, 1, 32), (32, 96, 96, 1), device='tnca', dtype=torch.float32)
        buf96 = empty_strided((3, 1, 1, 32), (32, 96, 96, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [getitem_4, position_ids, position_ids_1, position_ids_2, getitem_7, float_1, to, freqs, sin_1, getitem_9, cos_1, getitem_12, setitem_3, setitem_1], Original ATen: [aten.unsqueeze, aten.expand, aten.slice, aten._to_copy, aten.mul, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_expand_mul_select_slice_unsqueeze_0.run(arg0_1, arg3_1, buf92, buf96, 96, stream=raw_stream0)
        del arg3_1
        assert_size_stride_grouped((arg1_1, arg2_1, arg4_1), ((1, 1), (248320, 2048), (2048, )), ((1, 1), (2048, 1), (1, )), 'input')
        buf1 = empty_strided((1, 1, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [inputs_embeds, float_2, pow_1, mean, add, rsqrt, output, float_3, add_1, output_1, hidden_states], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1.run(arg1_1, arg2_1, arg4_1, buf1, 1, 2048, stream=raw_stream0)
        del arg4_1
        assert_size_stride_grouped((arg8_1, arg11_1, arg12_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf10 = empty_strided((1, 16), (16, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [exp, neg, a, float_5, add_2, softplus, g, transpose_6, getitem_22, exp_1], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf1, arg8_1, arg11_1, arg12_1, buf10, 1, 1, 1, stream=raw_stream0)
        del arg11_1
        del arg12_1
        del arg8_1
        assert_size_stride(arg7_1, (16, 2048), (2048, 1), 'input')
        buf13 = empty_strided((1, 16, 1), (16, 1, 16), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [b, beta, transpose_5, beta_1], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf1, arg7_1, buf13, 1, 1, 1, stream=raw_stream0)
        del arg7_1
        assert_size_stride(arg6_1, (2048, 2048), (2048, 1), 'input')
        buf20 = empty_strided((1, 2048), (2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [z], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf1, arg6_1, buf20, 128, 1, 1, stream=raw_stream0)
        del arg6_1
        assert_size_stride(arg5_1, (6144, 2048), (2048, 1), 'input')
        buf2 = empty_strided((1, 6144), (6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [inputs_embeds, float_2, pow_1, mean, add, rsqrt, output, float_3, add_1, output_1, hidden_states, mixed_qkv], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf1, arg5_1, buf2, 384, 1, 1, stream=raw_stream0)
        del arg5_1
        del buf1
        buf5 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf4 = reinterpret_tensor(buf5, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv, mixed_qkv_1, cat_2], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf2, buf4, 6144, stream=raw_stream0)
        del buf2
        assert_size_stride(arg9_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf3 = reinterpret_tensor(buf5, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv, mixed_qkv_1, cat_2], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg9_1, buf3, 24576, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_14, copy_], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf5, arg9_1, 24576, stream=raw_stream0)
        del arg9_1
        del buf3
        del buf4
        assert_size_stride(arg10_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf6 = empty_strided((1, 6144, 1), (6144, 1, 6144), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out, squeeze, unsqueeze, out_1, out_2], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf5, arg10_1, buf6, 6144, stream=raw_stream0)
        del arg10_1
        buf7 = empty_strided((1, 16, 1, 128), (2048, 128, 2048, 1), device='tnca', dtype=torch.float32)
        buf8 = empty_strided((1, 16, 1, 1), (16, 1, 16, 16), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_2, mixed_qkv_3, split, key_1, transpose_3, key_2, mul_8, sum_2], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf6, buf7, buf8, 16, 128, stream=raw_stream0)
        assert_size_stride(arg13_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf14 = empty_strided((1, 16, 128), (2048, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_2, mixed_qkv_3, split, add_4, inv_norm_1, key_3, k_t, value_1, transpose_4, value_2, v_t, exp, neg, a, float_5, add_2, softplus, g, transpose_6, getitem_22, exp_1, decay_t, last_recurrent_state_1, unsqueeze_2, mul_11, kv_mem, sub, b, beta, transpose_5, beta_1, getitem_24, beta_t, delta], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg13_1, buf10, buf7, buf8, buf6, buf13, buf14, 2048, 128, stream=raw_stream0)
        buf16 = empty_strided((1, 16, 1, 128), (2048, 128, 2048, 1), device='tnca', dtype=torch.float32)
        buf17 = reinterpret_tensor(buf13, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf13  # reuse
        # Topologically Sorted Source Nodes: [out_2, mixed_qkv_3, split, query_1, transpose_2, query_2, mul_6, sum_1], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf6, buf16, buf17, 16, 128, stream=raw_stream0)
        del buf6
        assert_size_stride(arg25_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf34 = buf5; del buf5  # reuse
        buf32 = reinterpret_tensor(buf34, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_4, mixed_qkv_5, cat_3], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg25_1, buf32, 24576, stream=raw_stream0)
        assert_size_stride(arg41_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf64 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf62 = reinterpret_tensor(buf64, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_8, mixed_qkv_9, cat_4], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg41_1, buf62, 24576, stream=raw_stream0)
        assert_size_stride(arg71_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf130 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf128 = reinterpret_tensor(buf130, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_12, mixed_qkv_13, cat_9], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg71_1, buf128, 24576, stream=raw_stream0)
        assert_size_stride(arg87_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf159 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf157 = reinterpret_tensor(buf159, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_16, mixed_qkv_17, cat_10], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg87_1, buf157, 24576, stream=raw_stream0)
        assert_size_stride(arg103_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf189 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf187 = reinterpret_tensor(buf189, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_20, mixed_qkv_21, cat_11], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg103_1, buf187, 24576, stream=raw_stream0)
        assert_size_stride(arg133_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf253 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf251 = reinterpret_tensor(buf253, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_24, mixed_qkv_25, cat_16], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg133_1, buf251, 24576, stream=raw_stream0)
        assert_size_stride(arg149_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf282 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf280 = reinterpret_tensor(buf282, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_28, mixed_qkv_29, cat_17], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg149_1, buf280, 24576, stream=raw_stream0)
        assert_size_stride(arg165_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf312 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf310 = reinterpret_tensor(buf312, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_32, mixed_qkv_33, cat_18], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg165_1, buf310, 24576, stream=raw_stream0)
        assert_size_stride(arg195_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf376 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf374 = reinterpret_tensor(buf376, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_36, mixed_qkv_37, cat_23], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg195_1, buf374, 24576, stream=raw_stream0)
        assert_size_stride(arg211_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf405 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf403 = reinterpret_tensor(buf405, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_40, mixed_qkv_41, cat_24], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg211_1, buf403, 24576, stream=raw_stream0)
        assert_size_stride(arg227_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf435 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf433 = reinterpret_tensor(buf435, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_44, mixed_qkv_45, cat_25], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg227_1, buf433, 24576, stream=raw_stream0)
        assert_size_stride(arg257_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf499 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf497 = reinterpret_tensor(buf499, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_48, mixed_qkv_49, cat_30], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg257_1, buf497, 24576, stream=raw_stream0)
        assert_size_stride(arg273_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf528 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf526 = reinterpret_tensor(buf528, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_52, mixed_qkv_53, cat_31], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg273_1, buf526, 24576, stream=raw_stream0)
        assert_size_stride(arg289_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf558 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf556 = reinterpret_tensor(buf558, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_56, mixed_qkv_57, cat_32], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg289_1, buf556, 24576, stream=raw_stream0)
        assert_size_stride(arg319_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf622 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf620 = reinterpret_tensor(buf622, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_60, mixed_qkv_61, cat_37], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg319_1, buf620, 24576, stream=raw_stream0)
        assert_size_stride(arg335_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf651 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf649 = reinterpret_tensor(buf651, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_64, mixed_qkv_65, cat_38], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg335_1, buf649, 24576, stream=raw_stream0)
        assert_size_stride(arg351_1, (1, 6144, 4), (24576, 4, 1), 'input')
        buf681 = empty_strided((1, 6144, 5), (30720, 5, 1), device='tnca', dtype=torch.bfloat16)
        buf679 = reinterpret_tensor(buf681, (1, 6144, 4), (30720, 5, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_68, mixed_qkv_69, cat_39], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_7.run(arg351_1, buf679, 24576, stream=raw_stream0)
        buf15 = empty_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_2, mixed_qkv_3, split, add_4, inv_norm_1, key_3, k_t, unsqueeze_3, value_1, transpose_4, value_2, v_t, exp, neg, a, float_5, add_2, softplus, g, transpose_6, getitem_22, exp_1, decay_t, last_recurrent_state_1, sub, b, beta, transpose_5, beta_1, getitem_24, beta_t, delta, unsqueeze_4, mul_13, last_recurrent_state_2], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg13_1, buf10, buf7, buf8, buf14, buf15, arg13_1, 262144, stream=raw_stream0)
        del arg13_1
        buf18 = reinterpret_tensor(buf7, (1, 16, 128), (2048, 128, 1), 0); del buf7  # reuse
        # Topologically Sorted Source Nodes: [add_3, inv_norm, query_3, query_4, q_t, unsqueeze_5, mul_14, sum_4], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf15, buf16, buf17, buf18, 2048, 128, stream=raw_stream0)
        del buf15
        assert_size_stride(arg14_1, (128, ), (1, ), 'input')
        buf21 = reinterpret_tensor(buf20, (16, 128), (128, 1), 0); del buf20  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out, core_attn_out_1, core_attn_out_2, hidden_states_1, pow_2, variance, add_6, rsqrt_3, hidden_states_2, to_13, hidden_states_3, z, z_1, z_2, to_14, silu_1, hidden_states_4, core_attn_out_3], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf21, buf18, arg14_1, 16, 128, stream=raw_stream0)
        del arg14_1
        assert_size_stride(arg15_1, (2048, 2048), (2048, 1), 'input')
        buf22 = empty_strided((1, 2048), (2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [core_attn_out, core_attn_out_1, core_attn_out_2, hidden_states_1, pow_2, variance, add_6, rsqrt_3, hidden_states_2, to_13, hidden_states_3, z, z_1, z_2, to_14, silu_1, hidden_states_4, core_attn_out_3, core_attn_out_4, output_2], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf21, arg15_1, buf22, 128, 1, 1, stream=raw_stream0)
        del arg15_1
        assert_size_stride(arg16_1, (2048, ), (1, ), 'input')
        buf24 = reinterpret_tensor(buf21, (1, 1, 2048), (2048, 2048, 1), 0); del buf21  # reuse
        # Topologically Sorted Source Nodes: [inputs_embeds, output_2, hidden_states_5, float_6, pow_3, mean_2, add_8, rsqrt_4, output_3, float_7, add_9, output_4, hidden_states_6], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17.run(arg1_1, arg2_1, buf22, arg16_1, buf24, 1, 2048, stream=raw_stream0)
        del arg16_1
        assert_size_stride(arg17_1, (6144, 2048), (2048, 1), 'input')
        buf25 = empty_strided((1, 6144), (6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [linear_5], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf24, arg17_1, buf25, 384, 1, 1, stream=raw_stream0)
        del arg17_1
        assert_size_stride(arg18_1, (6144, 2048), (2048, 1), 'input')
        buf27 = empty_strided((1, 1, 6144), (6144, 6144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [linear_5, silu_2, linear_6, mul_20], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf24, arg18_1, buf25, buf27, 384, 1, 1, stream=raw_stream0)
        del arg18_1
        assert_size_stride(arg19_1, (2048, 6144), (6144, 1), 'input')
        buf28 = reinterpret_tensor(buf24, (1, 2048), (2048, 1), 0); del buf24  # reuse
        # Topologically Sorted Source Nodes: [linear_5, silu_2, linear_6, mul_20, down_proj], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf27, arg19_1, buf28, 128, 1, 1, stream=raw_stream0)
        del arg19_1
        assert_size_stride(arg20_1, (2048, ), (1, ), 'input')
        buf30 = empty_strided((1, 1, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [inputs_embeds, output_2, hidden_states_5, down_proj, hidden_states_7, float_8, pow_4, mean_3, add_11, rsqrt_5, output_5, float_9, add_12, output_6, hidden_states_8], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_21.run(arg1_1, arg2_1, buf22, buf28, arg20_1, buf30, 1, 2048, stream=raw_stream0)
        del arg20_1
        assert_size_stride_grouped((arg24_1, arg27_1, arg28_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf39 = reinterpret_tensor(buf17, (1, 16), (16, 1), 0); del buf17  # reuse
        # Topologically Sorted Source Nodes: [exp_2, neg_1, a_1, float_11, add_13, softplus_1, g_1, transpose_14, getitem_33, exp_3], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf30, arg24_1, arg27_1, arg28_1, buf39, 1, 1, 1, stream=raw_stream0)
        del arg24_1
        del arg27_1
        del arg28_1
        assert_size_stride(arg23_1, (16, 2048), (2048, 1), 'input')
        buf42 = reinterpret_tensor(buf8, (1, 16, 1), (16, 1, 16), 0); del buf8  # reuse
        # Topologically Sorted Source Nodes: [b_1, beta_2, transpose_13, beta_3], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf30, arg23_1, buf42, 1, 1, 1, stream=raw_stream0)
        del arg23_1
        assert_size_stride(arg22_1, (2048, 2048), (2048, 1), 'input')
        buf49 = empty_strided((1, 2048), (2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [z_3], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf30, arg22_1, buf49, 128, 1, 1, stream=raw_stream0)
        del arg22_1
        assert_size_stride(arg21_1, (6144, 2048), (2048, 1), 'input')
        buf31 = reinterpret_tensor(buf27, (1, 6144), (6144, 1), 0); del buf27  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_4], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf30, arg21_1, buf31, 384, 1, 1, stream=raw_stream0)
        del arg21_1
        buf33 = reinterpret_tensor(buf34, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_4, mixed_qkv_5, cat_3], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf31, buf33, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_25, copy__2], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf34, arg25_1, 24576, stream=raw_stream0)
        del arg25_1
        del buf32
        del buf33
        assert_size_stride(arg26_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf35 = empty_strided((1, 6144, 1), (6144, 1, 6144), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_3, squeeze_1, unsqueeze_6, out_4, out_5], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf34, arg26_1, buf35, 6144, stream=raw_stream0)
        del arg26_1
        del buf34
        buf36 = reinterpret_tensor(buf18, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf18  # reuse
        buf37 = reinterpret_tensor(buf10, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf10  # reuse
        # Topologically Sorted Source Nodes: [out_5, mixed_qkv_7, split_1, key_5, transpose_11, key_6, mul_26, sum_6], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf35, buf36, buf37, 16, 128, stream=raw_stream0)
        assert_size_stride(arg29_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf43 = reinterpret_tensor(buf16, (1, 16, 128), (2048, 128, 1), 0); del buf16  # reuse
        # Topologically Sorted Source Nodes: [out_5, mixed_qkv_7, split_1, add_15, inv_norm_3, key_7, k_t_1, value_4, transpose_12, value_5, v_t_1, exp_2, neg_1, a_1, float_11, add_13, softplus_1, g_1, transpose_14, getitem_33, exp_3, decay_t_1, last_recurrent_state_4, unsqueeze_8, mul_29, kv_mem_1, sub_1, b_1, beta_2, transpose_13, beta_3, getitem_35, beta_t_1, delta_1], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg29_1, buf39, buf36, buf37, buf35, buf42, buf43, 2048, 128, stream=raw_stream0)
        buf45 = reinterpret_tensor(buf14, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf14  # reuse
        buf46 = reinterpret_tensor(buf42, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf42  # reuse
        # Topologically Sorted Source Nodes: [out_5, mixed_qkv_7, split_1, query_6, transpose_10, query_7, mul_24, sum_5], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf35, buf45, buf46, 16, 128, stream=raw_stream0)
        del buf35
        buf44 = empty_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_5, mixed_qkv_7, split_1, add_15, inv_norm_3, key_7, k_t_1, unsqueeze_9, value_4, transpose_12, value_5, v_t_1, exp_2, neg_1, a_1, float_11, add_13, softplus_1, g_1, transpose_14, getitem_33, exp_3, decay_t_1, last_recurrent_state_4, sub_1, b_1, beta_2, transpose_13, beta_3, getitem_35, beta_t_1, delta_1, unsqueeze_10, mul_31, last_recurrent_state_5], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg29_1, buf39, buf36, buf37, buf43, buf44, arg29_1, 262144, stream=raw_stream0)
        del arg29_1
        buf47 = buf43; del buf43  # reuse
        # Topologically Sorted Source Nodes: [add_14, inv_norm_2, query_8, query_9, q_t_1, unsqueeze_11, mul_32, sum_8], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf44, buf45, buf46, buf47, 2048, 128, stream=raw_stream0)
        del buf44
        assert_size_stride(arg30_1, (128, ), (1, ), 'input')
        buf50 = reinterpret_tensor(buf49, (16, 128), (128, 1), 0); del buf49  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_5, core_attn_out_6, core_attn_out_7, hidden_states_9, pow_5, variance_1, add_17, rsqrt_8, hidden_states_10, to_26, hidden_states_11, z_3, z_4, z_5, to_27, silu_4, hidden_states_12, core_attn_out_8], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf50, buf47, arg30_1, 16, 128, stream=raw_stream0)
        del arg30_1
        assert_size_stride(arg31_1, (2048, 2048), (2048, 1), 'input')
        buf51 = reinterpret_tensor(buf30, (1, 2048), (2048, 1), 0); del buf30  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_5, core_attn_out_6, core_attn_out_7, hidden_states_9, pow_5, variance_1, add_17, rsqrt_8, hidden_states_10, to_26, hidden_states_11, z_3, z_4, z_5, to_27, silu_4, hidden_states_12, core_attn_out_8, core_attn_out_9, output_7], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf50, arg31_1, buf51, 128, 1, 1, stream=raw_stream0)
        del arg31_1
        assert_size_stride(arg32_1, (2048, ), (1, ), 'input')
        buf52 = reinterpret_tensor(buf22, (1, 1, 2048), (2048, 2048, 1), 0); del buf22  # reuse
        buf54 = reinterpret_tensor(buf50, (1, 1, 2048), (2048, 2048, 1), 0); del buf50  # reuse
        # Topologically Sorted Source Nodes: [inputs_embeds, output_2, hidden_states_5, down_proj, hidden_states_7, output_7, hidden_states_13, float_12, pow_6, mean_5, add_19, rsqrt_9, output_8, float_13, add_20, output_9, hidden_states_14], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_22.run(buf52, arg1_1, arg2_1, buf28, buf51, arg32_1, buf54, 1, 2048, stream=raw_stream0)
        del arg1_1
        del arg32_1
        assert_size_stride(arg33_1, (6144, 2048), (2048, 1), 'input')
        buf55 = buf31; del buf31  # reuse
        # Topologically Sorted Source Nodes: [float_12, pow_6, mean_5, add_19, rsqrt_9, output_8, float_13, add_20, output_9, hidden_states_14, linear_13], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf54, arg33_1, buf55, 384, 1, 1, stream=raw_stream0)
        del arg33_1
        assert_size_stride(arg34_1, (6144, 2048), (2048, 1), 'input')
        buf57 = reinterpret_tensor(buf25, (1, 1, 6144), (6144, 6144, 1), 0); del buf25  # reuse
        # Topologically Sorted Source Nodes: [linear_13, silu_5, linear_14, mul_38], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf54, arg34_1, buf55, buf57, 384, 1, 1, stream=raw_stream0)
        del arg34_1
        assert_size_stride(arg35_1, (2048, 6144), (6144, 1), 'input')
        buf58 = reinterpret_tensor(buf54, (1, 2048), (2048, 1), 0); del buf54  # reuse
        # Topologically Sorted Source Nodes: [linear_13, silu_5, linear_14, mul_38, down_proj_1], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf57, arg35_1, buf58, 128, 1, 1, stream=raw_stream0)
        del arg35_1
        assert_size_stride(arg36_1, (2048, ), (1, ), 'input')
        buf60 = reinterpret_tensor(buf51, (1, 1, 2048), (2048, 2048, 1), 0); del buf51  # reuse
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, float_14, pow_7, mean_6, add_22, rsqrt_10, output_10, float_15, add_23, output_11, hidden_states_16], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23.run(buf52, buf58, arg36_1, buf60, 1, 2048, stream=raw_stream0)
        del arg36_1
        assert_size_stride_grouped((arg40_1, arg43_1, arg44_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf69 = reinterpret_tensor(buf46, (1, 16), (16, 1), 0); del buf46  # reuse
        # Topologically Sorted Source Nodes: [exp_4, neg_2, a_2, float_17, add_24, softplus_2, g_2, transpose_22, getitem_44, exp_5], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf60, arg40_1, arg43_1, arg44_1, buf69, 1, 1, 1, stream=raw_stream0)
        del arg40_1
        del arg43_1
        del arg44_1
        assert_size_stride(arg39_1, (16, 2048), (2048, 1), 'input')
        buf72 = reinterpret_tensor(buf39, (1, 16, 1), (16, 1, 16), 0); del buf39  # reuse
        # Topologically Sorted Source Nodes: [b_2, beta_4, transpose_21, beta_5], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf60, arg39_1, buf72, 1, 1, 1, stream=raw_stream0)
        del arg39_1
        assert_size_stride(arg38_1, (2048, 2048), (2048, 1), 'input')
        buf79 = buf28; del buf28  # reuse
        # Topologically Sorted Source Nodes: [z_6], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf60, arg38_1, buf79, 128, 1, 1, stream=raw_stream0)
        del arg38_1
        assert_size_stride(arg37_1, (6144, 2048), (2048, 1), 'input')
        buf61 = reinterpret_tensor(buf57, (1, 6144), (6144, 1), 0); del buf57  # reuse
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, float_14, pow_7, mean_6, add_22, rsqrt_10, output_10, float_15, add_23, output_11, hidden_states_16, mixed_qkv_8], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf60, arg37_1, buf61, 384, 1, 1, stream=raw_stream0)
        del arg37_1
        buf63 = reinterpret_tensor(buf64, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_8, mixed_qkv_9, cat_4], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf61, buf63, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_36, copy__4], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf64, arg41_1, 24576, stream=raw_stream0)
        del arg41_1
        del buf62
        del buf63
        assert_size_stride(arg42_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf65 = empty_strided((1, 6144, 1), (6144, 1, 6144), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_6, squeeze_2, unsqueeze_12, out_7, out_8], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf64, arg42_1, buf65, 6144, stream=raw_stream0)
        del arg42_1
        del buf64
        buf66 = reinterpret_tensor(buf47, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf47  # reuse
        buf67 = buf37; del buf37  # reuse
        # Topologically Sorted Source Nodes: [out_8, mixed_qkv_11, split_2, key_9, transpose_19, key_10, mul_44, sum_10], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf65, buf66, buf67, 16, 128, stream=raw_stream0)
        assert_size_stride(arg45_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf73 = reinterpret_tensor(buf45, (1, 16, 128), (2048, 128, 1), 0); del buf45  # reuse
        # Topologically Sorted Source Nodes: [out_8, mixed_qkv_11, split_2, add_26, inv_norm_5, key_11, k_t_2, value_7, transpose_20, value_8, v_t_2, exp_4, neg_2, a_2, float_17, add_24, softplus_2, g_2, transpose_22, getitem_44, exp_5, decay_t_2, last_recurrent_state_7, unsqueeze_14, mul_47, kv_mem_2, sub_2, b_2, beta_4, transpose_21, beta_5, getitem_46, beta_t_2, delta_2], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg45_1, buf69, buf66, buf67, buf65, buf72, buf73, 2048, 128, stream=raw_stream0)
        buf75 = buf36; del buf36  # reuse
        buf76 = reinterpret_tensor(buf72, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf72  # reuse
        # Topologically Sorted Source Nodes: [out_8, mixed_qkv_11, split_2, query_11, transpose_18, query_12, mul_42, sum_9], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf65, buf75, buf76, 16, 128, stream=raw_stream0)
        buf74 = empty_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_8, mixed_qkv_11, split_2, add_26, inv_norm_5, key_11, k_t_2, unsqueeze_15, value_7, transpose_20, value_8, v_t_2, exp_4, neg_2, a_2, float_17, add_24, softplus_2, g_2, transpose_22, getitem_44, exp_5, decay_t_2, last_recurrent_state_7, sub_2, b_2, beta_4, transpose_21, beta_5, getitem_46, beta_t_2, delta_2, unsqueeze_16, mul_49, last_recurrent_state_8], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg45_1, buf69, buf66, buf67, buf73, buf74, arg45_1, 262144, stream=raw_stream0)
        del arg45_1
        buf77 = buf73; del buf73  # reuse
        # Topologically Sorted Source Nodes: [add_25, inv_norm_4, query_13, query_14, q_t_2, unsqueeze_17, mul_50, sum_12], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf74, buf75, buf76, buf77, 2048, 128, stream=raw_stream0)
        del buf74
        assert_size_stride(arg46_1, (128, ), (1, ), 'input')
        buf80 = reinterpret_tensor(buf79, (16, 128), (128, 1), 0); del buf79  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_10, core_attn_out_11, core_attn_out_12, hidden_states_17, pow_8, variance_2, add_28, rsqrt_13, hidden_states_18, to_39, hidden_states_19, z_6, z_7, z_8, to_40, silu_7, hidden_states_20, core_attn_out_13], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf80, buf77, arg46_1, 16, 128, stream=raw_stream0)
        del arg46_1
        assert_size_stride(arg47_1, (2048, 2048), (2048, 1), 'input')
        buf81 = reinterpret_tensor(buf60, (1, 2048), (2048, 1), 0); del buf60  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_10, core_attn_out_11, core_attn_out_12, hidden_states_17, pow_8, variance_2, add_28, rsqrt_13, hidden_states_18, to_39, hidden_states_19, z_6, z_7, z_8, to_40, silu_7, hidden_states_20, core_attn_out_13, core_attn_out_14, output_12], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf80, arg47_1, buf81, 128, 1, 1, stream=raw_stream0)
        del arg47_1
        assert_size_stride(arg48_1, (2048, ), (1, ), 'input')
        buf83 = reinterpret_tensor(buf80, (1, 1, 2048), (2048, 2048, 1), 0); del buf80  # reuse
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, output_12, hidden_states_21, float_18, pow_9, mean_8, add_30, rsqrt_14, output_13, float_19, add_31, output_14, hidden_states_22], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf52, buf58, buf81, arg48_1, buf83, 1, 2048, stream=raw_stream0)
        del arg48_1
        assert_size_stride(arg49_1, (6144, 2048), (2048, 1), 'input')
        buf84 = buf61; del buf61  # reuse
        # Topologically Sorted Source Nodes: [linear_21], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf83, arg49_1, buf84, 384, 1, 1, stream=raw_stream0)
        del arg49_1
        assert_size_stride(arg50_1, (6144, 2048), (2048, 1), 'input')
        buf86 = reinterpret_tensor(buf55, (1, 1, 6144), (6144, 6144, 1), 0); del buf55  # reuse
        # Topologically Sorted Source Nodes: [linear_21, silu_8, linear_22, mul_56], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf83, arg50_1, buf84, buf86, 384, 1, 1, stream=raw_stream0)
        del arg50_1
        assert_size_stride(arg51_1, (2048, 6144), (6144, 1), 'input')
        buf87 = reinterpret_tensor(buf83, (1, 2048), (2048, 1), 0); del buf83  # reuse
        # Topologically Sorted Source Nodes: [linear_21, silu_8, linear_22, mul_56, down_proj_2], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf86, arg51_1, buf87, 128, 1, 1, stream=raw_stream0)
        del arg51_1
        assert_size_stride(arg52_1, (2048, ), (1, ), 'input')
        buf89 = empty_strided((1, 1, 2048), (2048, 2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, output_12, hidden_states_21, down_proj_2, hidden_states_23, float_20, pow_10, mean_9, add_33, rsqrt_15, output_15, float_21, add_34, output_16, hidden_states_24], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf52, buf58, buf81, buf87, arg52_1, buf89, 1, 2048, stream=raw_stream0)
        del arg52_1
        assert_size_stride(arg55_1, (512, 2048), (2048, 1), 'input')
        buf100 = empty_strided((1, 512), (512, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [linear_25], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_26.run(buf89, arg55_1, buf100, 32, 1, 1, stream=raw_stream0)
        del arg55_1
        buf101 = empty_strided((1, 1, 2, 1), (2, 2, 1, 2), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear_25, view_2, float_24, pow_12, mean_11], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_view_27.run(buf100, buf101, 2, 256, stream=raw_stream0)
        assert_size_stride(arg56_1, (256, ), (1, ), 'input')
        buf104 = empty_strided((1, 2, 1, 64), (128, 64, 64, 1), device='tnca', dtype=torch.bfloat16)
        buf102 = reinterpret_tensor(buf104, (1, 2, 1, 32), (128, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_25, view_2, float_24, pow_12, mean_11, add_37, rsqrt_17, output_19, float_25, add_38, output_20, type_as_8, key_states, k_rot, x2_1, neg_4], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_mean_mul_neg_pow_rsqrt_slice_transpose_view_28.run(buf100, buf101, arg56_1, buf102, 64, stream=raw_stream0)
        buf103 = reinterpret_tensor(buf104, (1, 2, 1, 32), (128, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_25, view_2, float_24, pow_12, mean_11, add_37, rsqrt_17, output_19, float_25, add_38, output_20, type_as_8, key_states, k_rot, x2_1, neg_4, x1_1, cat_6], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_29.run(buf100, buf101, arg56_1, buf103, 64, stream=raw_stream0)
        buf107 = empty_strided((1, 2, 1, 256), (512, 256, 256, 1), device='tnca', dtype=torch.bfloat16)
        buf105 = reinterpret_tensor(buf107, (1, 2, 1, 64), (512, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, cos_4, sin_2, sin_3, sin_4, linear_25, view_2, float_24, pow_12, mean_11, add_37, rsqrt_17, output_19, float_25, add_38, output_20, type_as_8, key_states, k_rot, mul_65, mul_66, k_embed], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_30.run(buf100, buf101, arg56_1, buf92, buf104, buf96, buf105, 128, stream=raw_stream0)
        del buf102
        del buf103
        buf106 = reinterpret_tensor(buf107, (1, 2, 1, 192), (512, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, cos_4, sin_2, sin_3, sin_4, linear_25, view_2, float_24, pow_12, mean_11, add_37, rsqrt_17, output_19, float_25, add_38, output_20, type_as_8, key_states, k_rot, mul_65, mul_66, k_embed, k_pass, k_embed_1], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_31.run(buf100, buf101, arg56_1, buf106, 384, stream=raw_stream0)
        del arg56_1
        assert_size_stride_grouped((arg58_1, arg59_1), ((), (1, 2, 144, 256)), ((), (73728, 36864, 256, 1)), 'input')
        # Topologically Sorted Source Nodes: [arange_1, cache_position, index_copy_], Original ATen: [aten.arange, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_32.run(arg58_1, buf107, arg59_1, 512, stream=raw_stream0)
        del buf105
        del buf106
        assert_size_stride(arg57_1, (512, 2048), (2048, 1), 'input')
        buf113 = reinterpret_tensor(buf107, (1, 512), (512, 1), 0); del buf107  # reuse
        # Topologically Sorted Source Nodes: [linear_26], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_26.run(buf89, arg57_1, buf113, 32, 1, 1, stream=raw_stream0)
        del arg57_1
        assert_size_stride(arg60_1, (1, 2, 144, 256), (73728, 36864, 256, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_1, cache_position, linear_26, view_3, value_states, index_copy__1], Original ATen: [aten.arange, aten.add, aten._unsafe_view, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_32.run(arg58_1, buf113, arg60_1, 512, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [add_], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__33.run(arg58_1, arg58_1, 1, stream=raw_stream0)
        del arg58_1
        assert_size_stride(arg53_1, (4096, 2048), (2048, 1), 'input')
        buf90 = empty_strided((1, 4096), (4096, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [linear_24], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_34.run(buf89, arg53_1, buf90, 256, 1, 1, stream=raw_stream0)
        del arg53_1
        buf91 = empty_strided((1, 1, 8, 1), (8, 8, 1, 8), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_35.run(buf90, buf91, 8, 256, stream=raw_stream0)
        assert_size_stride(arg54_1, (256, ), (1, ), 'input')
        buf95 = reinterpret_tensor(buf113, (1, 8, 1, 64), (512, 64, 64, 1), 0); del buf113  # reuse
        buf93 = reinterpret_tensor(buf95, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        buf94 = reinterpret_tensor(buf95, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10, add_35, rsqrt_16, output_17, float_23, add_36, output_18, type_as_7, query_states_1, q_rot, x2, neg_3, x1, cat_5], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36.run(buf90, buf91, arg54_1, buf93, buf94, 256, stream=raw_stream0)
        buf99 = reinterpret_tensor(buf89, (1, 8, 1, 256), (2048, 256, 256, 1), 0); del buf89  # reuse
        buf97 = reinterpret_tensor(buf99, (1, 8, 1, 64), (2048, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10, add_35, rsqrt_16, output_17, float_23, add_36, output_18, type_as_7, query_states_1, q_rot, cos_2, cos_3, cos_4, mul_63, sin_2, sin_3, sin_4, mul_64, q_embed], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.select, aten.cat, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37.run(buf90, buf91, arg54_1, buf92, buf95, buf96, buf97, 512, stream=raw_stream0)
        del buf93
        del buf94
        buf98 = reinterpret_tensor(buf99, (1, 8, 1, 192), (2048, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [linear_24, view, chunk, float_22, pow_11, mean_10, add_35, rsqrt_16, output_17, float_23, add_36, output_18, type_as_7, query_states_1, q_rot, cos_2, cos_3, cos_4, mul_63, sin_2, sin_3, sin_4, mul_64, q_embed, q_pass, q_embed_1], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.select, aten.cat, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38.run(buf90, buf91, arg54_1, buf98, 1536, stream=raw_stream0)
        del arg54_1
        buf109 = empty_strided((8, 1, 144), (144, 144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [matmul, key_states_1, transpose_27], Original ATen: [aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_39.run(buf99, arg59_1, buf109, 1152, 256, stream=raw_stream0)
        del arg59_1
        del buf97
        del buf98
        buf111 = empty_strided((1, 8, 1, 144), (1152, 144, 1152, 1), device='tnca', dtype=torch.float32)
        buf112 = reinterpret_tensor(buf91, (1, 8, 1, 1), (8, 1, 8, 8), 0); del buf91  # reuse
        # Topologically Sorted Source Nodes: [matmul, attn_weights, arange, getitem, getitem_1, getitem_2, allowed, mask_1, mask, getitem_3, attn_weights_1, softmax], Original ATen: [aten.view, aten.mul, aten.arange, aten.unsqueeze, aten.select, aten.le, aten.masked_fill, aten.full, aten.add, aten._to_copy, aten._softmax]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy_add_arange_full_le_masked_fill_mul_select_unsqueeze_view_40.run(buf109, arg0_1, buf111, buf112, 8, 144, stream=raw_stream0)
        del buf109
        buf115 = reinterpret_tensor(buf99, (8, 1, 256), (256, 256, 1), 0); del buf99  # reuse
        buf116 = reinterpret_tensor(buf115, (1, 1, 2048), (2048, 2048, 1), 0); del buf115  # reuse
        # Topologically Sorted Source Nodes: [linear_24, view, chunk, softmax, attn_weights_2, attn_output, value_states_1, transpose_28, reshape_24, gate_1, sigmoid_3, attn_output_3], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._softmax, aten._to_copy, aten.unsqueeze, aten.expand, aten.clone, aten.bmm, aten.transpose, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_41.run(buf116, buf111, buf112, arg60_1, buf90, 2048, 144, stream=raw_stream0)
        del arg60_1
        del buf111
        del buf90
        assert_size_stride(arg61_1, (2048, 2048), (2048, 1), 'input')
        buf117 = empty_strided((1, 2048), (2048, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [linear_24, view, chunk, attn_output, transpose_28, reshape_24, gate_1, sigmoid_3, attn_output_3, attn_output_4], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf116, arg61_1, buf117, 128, 1, 1, stream=raw_stream0)
        del arg61_1
        assert_size_stride(arg62_1, (2048, ), (1, ), 'input')
        buf118 = buf52; del buf52  # reuse
        buf120 = buf116; del buf116  # reuse
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_15, output_12, hidden_states_21, down_proj_2, hidden_states_23, attn_output_4, hidden_states_27, float_26, pow_13, mean_12, add_44, rsqrt_18, output_21, float_27, add_45, output_22, hidden_states_28], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42.run(buf118, buf58, buf81, buf87, buf117, arg62_1, buf120, 1, 2048, stream=raw_stream0)
        del arg62_1
        assert_size_stride(arg63_1, (6144, 2048), (2048, 1), 'input')
        buf121 = reinterpret_tensor(buf86, (1, 6144), (6144, 1), 0); del buf86  # reuse
        # Topologically Sorted Source Nodes: [float_26, pow_13, mean_12, add_44, rsqrt_18, output_21, float_27, add_45, output_22, hidden_states_28, linear_28], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf120, arg63_1, buf121, 384, 1, 1, stream=raw_stream0)
        del arg63_1
        assert_size_stride(arg64_1, (6144, 2048), (2048, 1), 'input')
        buf123 = reinterpret_tensor(buf84, (1, 1, 6144), (6144, 6144, 1), 0); del buf84  # reuse
        # Topologically Sorted Source Nodes: [linear_28, silu_9, linear_29, mul_71], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf120, arg64_1, buf121, buf123, 384, 1, 1, stream=raw_stream0)
        del arg64_1
        assert_size_stride(arg65_1, (2048, 6144), (6144, 1), 'input')
        buf124 = reinterpret_tensor(buf120, (1, 2048), (2048, 1), 0); del buf120  # reuse
        # Topologically Sorted Source Nodes: [linear_28, silu_9, linear_29, mul_71, down_proj_3], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf123, arg65_1, buf124, 128, 1, 1, stream=raw_stream0)
        del arg65_1
        assert_size_stride(arg66_1, (2048, ), (1, ), 'input')
        buf126 = reinterpret_tensor(buf87, (1, 1, 2048), (2048, 2048, 1), 0); del buf87  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_29, float_28, pow_14, mean_13, add_47, rsqrt_19, output_23, float_29, add_48, output_24, hidden_states_30], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23.run(buf118, buf124, arg66_1, buf126, 1, 2048, stream=raw_stream0)
        del arg66_1
        assert_size_stride_grouped((arg70_1, arg73_1, arg74_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf135 = reinterpret_tensor(buf76, (1, 16), (16, 1), 0); del buf76  # reuse
        # Topologically Sorted Source Nodes: [exp_6, neg_5, a_3, float_31, add_49, softplus_3, g_3, transpose_35, getitem_67, exp_7], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf126, arg70_1, arg73_1, arg74_1, buf135, 1, 1, 1, stream=raw_stream0)
        del arg70_1
        del arg73_1
        del arg74_1
        assert_size_stride(arg69_1, (16, 2048), (2048, 1), 'input')
        buf138 = reinterpret_tensor(buf69, (1, 16, 1), (16, 1, 16), 0); del buf69  # reuse
        # Topologically Sorted Source Nodes: [b_3, beta_6, transpose_34, beta_7], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf126, arg69_1, buf138, 1, 1, 1, stream=raw_stream0)
        del arg69_1
        assert_size_stride(arg68_1, (2048, 2048), (2048, 1), 'input')
        buf145 = buf81; del buf81  # reuse
        # Topologically Sorted Source Nodes: [z_9], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf126, arg68_1, buf145, 128, 1, 1, stream=raw_stream0)
        del arg68_1
        assert_size_stride(arg67_1, (6144, 2048), (2048, 1), 'input')
        buf127 = reinterpret_tensor(buf123, (1, 6144), (6144, 1), 0); del buf123  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_29, float_28, pow_14, mean_13, add_47, rsqrt_19, output_23, float_29, add_48, output_24, hidden_states_30, mixed_qkv_12], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf126, arg67_1, buf127, 384, 1, 1, stream=raw_stream0)
        del arg67_1
        buf129 = reinterpret_tensor(buf130, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_12, mixed_qkv_13, cat_9], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf127, buf129, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_59, copy__6], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf130, arg71_1, 24576, stream=raw_stream0)
        del arg71_1
        del buf128
        del buf129
        assert_size_stride(arg72_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf131 = buf65; del buf65  # reuse
        # Topologically Sorted Source Nodes: [out_9, squeeze_3, unsqueeze_20, out_10, out_11], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf130, arg72_1, buf131, 6144, stream=raw_stream0)
        del arg72_1
        del buf130
        buf132 = reinterpret_tensor(buf77, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf77  # reuse
        buf133 = buf67; del buf67  # reuse
        # Topologically Sorted Source Nodes: [out_11, mixed_qkv_15, split_3, key_13, transpose_32, key_14, mul_77, sum_14], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf131, buf132, buf133, 16, 128, stream=raw_stream0)
        assert_size_stride(arg75_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf139 = reinterpret_tensor(buf75, (1, 16, 128), (2048, 128, 1), 0); del buf75  # reuse
        # Topologically Sorted Source Nodes: [out_11, mixed_qkv_15, split_3, add_51, inv_norm_7, key_15, k_t_3, value_10, transpose_33, value_11, v_t_3, exp_6, neg_5, a_3, float_31, add_49, softplus_3, g_3, transpose_35, getitem_67, exp_7, decay_t_3, last_recurrent_state_10, unsqueeze_22, mul_80, kv_mem_3, sub_3, b_3, beta_6, transpose_34, beta_7, getitem_69, beta_t_3, delta_3], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg75_1, buf135, buf132, buf133, buf131, buf138, buf139, 2048, 128, stream=raw_stream0)
        buf141 = buf66; del buf66  # reuse
        buf142 = reinterpret_tensor(buf138, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf138  # reuse
        # Topologically Sorted Source Nodes: [out_11, mixed_qkv_15, split_3, query_16, transpose_31, query_17, mul_75, sum_13], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf131, buf141, buf142, 16, 128, stream=raw_stream0)
        buf140 = empty_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [out_11, mixed_qkv_15, split_3, add_51, inv_norm_7, key_15, k_t_3, unsqueeze_23, value_10, transpose_33, value_11, v_t_3, exp_6, neg_5, a_3, float_31, add_49, softplus_3, g_3, transpose_35, getitem_67, exp_7, decay_t_3, last_recurrent_state_10, sub_3, b_3, beta_6, transpose_34, beta_7, getitem_69, beta_t_3, delta_3, unsqueeze_24, mul_82, last_recurrent_state_11], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg75_1, buf135, buf132, buf133, buf139, buf140, arg75_1, 262144, stream=raw_stream0)
        del arg75_1
        buf143 = buf139; del buf139  # reuse
        # Topologically Sorted Source Nodes: [add_50, inv_norm_6, query_18, query_19, q_t_3, unsqueeze_25, mul_83, sum_16], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf140, buf141, buf142, buf143, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg76_1, (128, ), (1, ), 'input')
        buf146 = reinterpret_tensor(buf145, (16, 128), (128, 1), 0); del buf145  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_15, core_attn_out_16, core_attn_out_17, hidden_states_31, pow_15, variance_3, add_53, rsqrt_22, hidden_states_32, to_53, hidden_states_33, z_9, z_10, z_11, to_54, silu_11, hidden_states_34, core_attn_out_18], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf146, buf143, arg76_1, 16, 128, stream=raw_stream0)
        del arg76_1
        assert_size_stride(arg77_1, (2048, 2048), (2048, 1), 'input')
        buf147 = reinterpret_tensor(buf126, (1, 2048), (2048, 1), 0); del buf126  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_15, core_attn_out_16, core_attn_out_17, hidden_states_31, pow_15, variance_3, add_53, rsqrt_22, hidden_states_32, to_53, hidden_states_33, z_9, z_10, z_11, to_54, silu_11, hidden_states_34, core_attn_out_18, core_attn_out_19, output_25], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf146, arg77_1, buf147, 128, 1, 1, stream=raw_stream0)
        del arg77_1
        assert_size_stride(arg78_1, (2048, ), (1, ), 'input')
        buf149 = reinterpret_tensor(buf146, (1, 1, 2048), (2048, 2048, 1), 0); del buf146  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_29, output_25, hidden_states_35, float_32, pow_16, mean_15, add_55, rsqrt_23, output_26, float_33, add_56, output_27, hidden_states_36], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf118, buf124, buf147, arg78_1, buf149, 1, 2048, stream=raw_stream0)
        del arg78_1
        assert_size_stride(arg79_1, (6144, 2048), (2048, 1), 'input')
        buf150 = buf127; del buf127  # reuse
        # Topologically Sorted Source Nodes: [linear_36], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf149, arg79_1, buf150, 384, 1, 1, stream=raw_stream0)
        del arg79_1
        assert_size_stride(arg80_1, (6144, 2048), (2048, 1), 'input')
        buf152 = reinterpret_tensor(buf121, (1, 1, 6144), (6144, 6144, 1), 0); del buf121  # reuse
        # Topologically Sorted Source Nodes: [linear_36, silu_12, linear_37, mul_89], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf149, arg80_1, buf150, buf152, 384, 1, 1, stream=raw_stream0)
        del arg80_1
        assert_size_stride(arg81_1, (2048, 6144), (6144, 1), 'input')
        buf153 = reinterpret_tensor(buf149, (1, 2048), (2048, 1), 0); del buf149  # reuse
        # Topologically Sorted Source Nodes: [linear_36, silu_12, linear_37, mul_89, down_proj_4], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf152, arg81_1, buf153, 128, 1, 1, stream=raw_stream0)
        del arg81_1
        assert_size_stride(arg82_1, (2048, ), (1, ), 'input')
        buf155 = reinterpret_tensor(buf58, (1, 1, 2048), (2048, 2048, 1), 0); del buf58  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_29, output_25, hidden_states_35, down_proj_4, hidden_states_37, float_34, pow_17, mean_16, add_58, rsqrt_24, output_28, float_35, add_59, output_29, hidden_states_38], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf118, buf124, buf147, buf153, arg82_1, buf155, 1, 2048, stream=raw_stream0)
        del arg82_1
        assert_size_stride_grouped((arg86_1, arg89_1, arg90_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf164 = reinterpret_tensor(buf142, (1, 16), (16, 1), 0); del buf142  # reuse
        # Topologically Sorted Source Nodes: [exp_8, neg_6, a_4, float_37, add_60, softplus_4, g_4, transpose_43, getitem_78, exp_9], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf155, arg86_1, arg89_1, arg90_1, buf164, 1, 1, 1, stream=raw_stream0)
        del arg86_1
        del arg89_1
        del arg90_1
        assert_size_stride(arg85_1, (16, 2048), (2048, 1), 'input')
        buf167 = reinterpret_tensor(buf135, (1, 16, 1), (16, 1, 16), 0); del buf135  # reuse
        # Topologically Sorted Source Nodes: [b_4, beta_8, transpose_42, beta_9], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf155, arg85_1, buf167, 1, 1, 1, stream=raw_stream0)
        del arg85_1
        assert_size_stride(arg84_1, (2048, 2048), (2048, 1), 'input')
        buf174 = buf117; del buf117  # reuse
        # Topologically Sorted Source Nodes: [z_12], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf155, arg84_1, buf174, 128, 1, 1, stream=raw_stream0)
        del arg84_1
        assert_size_stride(arg83_1, (6144, 2048), (2048, 1), 'input')
        buf156 = reinterpret_tensor(buf152, (1, 6144), (6144, 1), 0); del buf152  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_16], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf155, arg83_1, buf156, 384, 1, 1, stream=raw_stream0)
        del arg83_1
        buf158 = reinterpret_tensor(buf159, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_16, mixed_qkv_17, cat_10], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf156, buf158, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_70, copy__8], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf159, arg87_1, 24576, stream=raw_stream0)
        del arg87_1
        del buf157
        del buf158
        assert_size_stride(arg88_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf160 = buf131; del buf131  # reuse
        # Topologically Sorted Source Nodes: [out_12, squeeze_4, unsqueeze_26, out_13, out_14], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf159, arg88_1, buf160, 6144, stream=raw_stream0)
        del arg88_1
        del buf159
        buf161 = reinterpret_tensor(buf143, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf143  # reuse
        buf162 = buf133; del buf133  # reuse
        # Topologically Sorted Source Nodes: [out_14, mixed_qkv_19, split_4, key_17, transpose_40, key_18, mul_95, sum_18], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf160, buf161, buf162, 16, 128, stream=raw_stream0)
        assert_size_stride(arg91_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf168 = reinterpret_tensor(buf141, (1, 16, 128), (2048, 128, 1), 0); del buf141  # reuse
        # Topologically Sorted Source Nodes: [out_14, mixed_qkv_19, split_4, add_62, inv_norm_9, key_19, k_t_4, value_13, transpose_41, value_14, v_t_4, exp_8, neg_6, a_4, float_37, add_60, softplus_4, g_4, transpose_43, getitem_78, exp_9, decay_t_4, last_recurrent_state_13, unsqueeze_28, mul_98, kv_mem_4, sub_4, b_4, beta_8, transpose_42, beta_9, getitem_80, beta_t_4, delta_4], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg91_1, buf164, buf161, buf162, buf160, buf167, buf168, 2048, 128, stream=raw_stream0)
        buf170 = buf132; del buf132  # reuse
        buf171 = reinterpret_tensor(buf167, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf167  # reuse
        # Topologically Sorted Source Nodes: [out_14, mixed_qkv_19, split_4, query_21, transpose_39, query_22, mul_93, sum_17], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf160, buf170, buf171, 16, 128, stream=raw_stream0)
        buf169 = buf140; del buf140  # reuse
        # Topologically Sorted Source Nodes: [out_14, mixed_qkv_19, split_4, add_62, inv_norm_9, key_19, k_t_4, unsqueeze_29, value_13, transpose_41, value_14, v_t_4, exp_8, neg_6, a_4, float_37, add_60, softplus_4, g_4, transpose_43, getitem_78, exp_9, decay_t_4, last_recurrent_state_13, sub_4, b_4, beta_8, transpose_42, beta_9, getitem_80, beta_t_4, delta_4, unsqueeze_30, mul_100, last_recurrent_state_14], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg91_1, buf164, buf161, buf162, buf168, buf169, arg91_1, 262144, stream=raw_stream0)
        del arg91_1
        buf172 = buf168; del buf168  # reuse
        # Topologically Sorted Source Nodes: [add_61, inv_norm_8, query_23, query_24, q_t_4, unsqueeze_31, mul_101, sum_20], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf169, buf170, buf171, buf172, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg92_1, (128, ), (1, ), 'input')
        buf175 = reinterpret_tensor(buf174, (16, 128), (128, 1), 0); del buf174  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_20, core_attn_out_21, core_attn_out_22, hidden_states_39, pow_18, variance_4, add_64, rsqrt_27, hidden_states_40, to_66, hidden_states_41, z_12, z_13, z_14, to_67, silu_14, hidden_states_42, core_attn_out_23], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf175, buf172, arg92_1, 16, 128, stream=raw_stream0)
        del arg92_1
        assert_size_stride(arg93_1, (2048, 2048), (2048, 1), 'input')
        buf176 = reinterpret_tensor(buf155, (1, 2048), (2048, 1), 0); del buf155  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_20, core_attn_out_21, core_attn_out_22, hidden_states_39, pow_18, variance_4, add_64, rsqrt_27, hidden_states_40, to_66, hidden_states_41, z_12, z_13, z_14, to_67, silu_14, hidden_states_42, core_attn_out_23, core_attn_out_24, output_30], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf175, arg93_1, buf176, 128, 1, 1, stream=raw_stream0)
        del arg93_1
        assert_size_stride(arg94_1, (2048, ), (1, ), 'input')
        buf177 = buf118; del buf118  # reuse
        buf179 = reinterpret_tensor(buf175, (1, 1, 2048), (2048, 2048, 1), 0); del buf175  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_29, output_25, hidden_states_35, down_proj_4, hidden_states_37, output_30, hidden_states_43, float_38, pow_19, mean_18, add_66, rsqrt_28, output_31, float_39, add_67, output_32, hidden_states_44], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42.run(buf177, buf124, buf147, buf153, buf176, arg94_1, buf179, 1, 2048, stream=raw_stream0)
        del arg94_1
        assert_size_stride(arg95_1, (6144, 2048), (2048, 1), 'input')
        buf180 = buf156; del buf156  # reuse
        # Topologically Sorted Source Nodes: [float_38, pow_19, mean_18, add_66, rsqrt_28, output_31, float_39, add_67, output_32, hidden_states_44, linear_44], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf179, arg95_1, buf180, 384, 1, 1, stream=raw_stream0)
        del arg95_1
        assert_size_stride(arg96_1, (6144, 2048), (2048, 1), 'input')
        buf182 = reinterpret_tensor(buf150, (1, 1, 6144), (6144, 6144, 1), 0); del buf150  # reuse
        # Topologically Sorted Source Nodes: [linear_44, silu_15, linear_45, mul_107], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf179, arg96_1, buf180, buf182, 384, 1, 1, stream=raw_stream0)
        del arg96_1
        assert_size_stride(arg97_1, (2048, 6144), (6144, 1), 'input')
        buf183 = reinterpret_tensor(buf179, (1, 2048), (2048, 1), 0); del buf179  # reuse
        # Topologically Sorted Source Nodes: [linear_44, silu_15, linear_45, mul_107, down_proj_5], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf182, arg97_1, buf183, 128, 1, 1, stream=raw_stream0)
        del arg97_1
        assert_size_stride(arg98_1, (2048, ), (1, ), 'input')
        buf185 = reinterpret_tensor(buf176, (1, 1, 2048), (2048, 2048, 1), 0); del buf176  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_45, float_40, pow_20, mean_19, add_69, rsqrt_29, output_33, float_41, add_70, output_34, hidden_states_46], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23.run(buf177, buf183, arg98_1, buf185, 1, 2048, stream=raw_stream0)
        del arg98_1
        assert_size_stride_grouped((arg102_1, arg105_1, arg106_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf194 = reinterpret_tensor(buf171, (1, 16), (16, 1), 0); del buf171  # reuse
        # Topologically Sorted Source Nodes: [exp_10, neg_7, a_5, float_43, add_71, softplus_5, g_5, transpose_51, getitem_89, exp_11], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf185, arg102_1, arg105_1, arg106_1, buf194, 1, 1, 1, stream=raw_stream0)
        del arg102_1
        del arg105_1
        del arg106_1
        assert_size_stride(arg101_1, (16, 2048), (2048, 1), 'input')
        buf197 = reinterpret_tensor(buf164, (1, 16, 1), (16, 1, 16), 0); del buf164  # reuse
        # Topologically Sorted Source Nodes: [b_5, beta_10, transpose_50, beta_11], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf185, arg101_1, buf197, 1, 1, 1, stream=raw_stream0)
        del arg101_1
        assert_size_stride(arg100_1, (2048, 2048), (2048, 1), 'input')
        buf204 = buf153; del buf153  # reuse
        # Topologically Sorted Source Nodes: [z_15], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf185, arg100_1, buf204, 128, 1, 1, stream=raw_stream0)
        del arg100_1
        assert_size_stride(arg99_1, (6144, 2048), (2048, 1), 'input')
        buf186 = reinterpret_tensor(buf182, (1, 6144), (6144, 1), 0); del buf182  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_45, float_40, pow_20, mean_19, add_69, rsqrt_29, output_33, float_41, add_70, output_34, hidden_states_46, mixed_qkv_20], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf185, arg99_1, buf186, 384, 1, 1, stream=raw_stream0)
        del arg99_1
        buf188 = reinterpret_tensor(buf189, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_20, mixed_qkv_21, cat_11], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf186, buf188, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_81, copy__10], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf189, arg103_1, 24576, stream=raw_stream0)
        del arg103_1
        del buf187
        del buf188
        assert_size_stride(arg104_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf190 = buf160; del buf160  # reuse
        # Topologically Sorted Source Nodes: [out_15, squeeze_5, unsqueeze_32, out_16, out_17], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf189, arg104_1, buf190, 6144, stream=raw_stream0)
        del arg104_1
        del buf189
        buf191 = reinterpret_tensor(buf172, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf172  # reuse
        buf192 = buf162; del buf162  # reuse
        # Topologically Sorted Source Nodes: [out_17, mixed_qkv_23, split_5, key_21, transpose_48, key_22, mul_113, sum_22], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf190, buf191, buf192, 16, 128, stream=raw_stream0)
        assert_size_stride(arg107_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf198 = reinterpret_tensor(buf170, (1, 16, 128), (2048, 128, 1), 0); del buf170  # reuse
        # Topologically Sorted Source Nodes: [out_17, mixed_qkv_23, split_5, add_73, inv_norm_11, key_23, k_t_5, value_16, transpose_49, value_17, v_t_5, exp_10, neg_7, a_5, float_43, add_71, softplus_5, g_5, transpose_51, getitem_89, exp_11, decay_t_5, last_recurrent_state_16, unsqueeze_34, mul_116, kv_mem_5, sub_5, b_5, beta_10, transpose_50, beta_11, getitem_91, beta_t_5, delta_5], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg107_1, buf194, buf191, buf192, buf190, buf197, buf198, 2048, 128, stream=raw_stream0)
        buf200 = buf161; del buf161  # reuse
        buf201 = reinterpret_tensor(buf197, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf197  # reuse
        # Topologically Sorted Source Nodes: [out_17, mixed_qkv_23, split_5, query_26, transpose_47, query_27, mul_111, sum_21], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf190, buf200, buf201, 16, 128, stream=raw_stream0)
        buf199 = buf169; del buf169  # reuse
        # Topologically Sorted Source Nodes: [out_17, mixed_qkv_23, split_5, add_73, inv_norm_11, key_23, k_t_5, unsqueeze_35, value_16, transpose_49, value_17, v_t_5, exp_10, neg_7, a_5, float_43, add_71, softplus_5, g_5, transpose_51, getitem_89, exp_11, decay_t_5, last_recurrent_state_16, sub_5, b_5, beta_10, transpose_50, beta_11, getitem_91, beta_t_5, delta_5, unsqueeze_36, mul_118, last_recurrent_state_17], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg107_1, buf194, buf191, buf192, buf198, buf199, arg107_1, 262144, stream=raw_stream0)
        del arg107_1
        buf202 = buf198; del buf198  # reuse
        # Topologically Sorted Source Nodes: [add_72, inv_norm_10, query_28, query_29, q_t_5, unsqueeze_37, mul_119, sum_24], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf199, buf200, buf201, buf202, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg108_1, (128, ), (1, ), 'input')
        buf205 = reinterpret_tensor(buf204, (16, 128), (128, 1), 0); del buf204  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_25, core_attn_out_26, core_attn_out_27, hidden_states_47, pow_21, variance_5, add_75, rsqrt_32, hidden_states_48, to_79, hidden_states_49, z_15, z_16, z_17, to_80, silu_17, hidden_states_50, core_attn_out_28], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf205, buf202, arg108_1, 16, 128, stream=raw_stream0)
        del arg108_1
        assert_size_stride(arg109_1, (2048, 2048), (2048, 1), 'input')
        buf206 = reinterpret_tensor(buf185, (1, 2048), (2048, 1), 0); del buf185  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_25, core_attn_out_26, core_attn_out_27, hidden_states_47, pow_21, variance_5, add_75, rsqrt_32, hidden_states_48, to_79, hidden_states_49, z_15, z_16, z_17, to_80, silu_17, hidden_states_50, core_attn_out_28, core_attn_out_29, output_35], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf205, arg109_1, buf206, 128, 1, 1, stream=raw_stream0)
        del arg109_1
        assert_size_stride(arg110_1, (2048, ), (1, ), 'input')
        buf208 = reinterpret_tensor(buf205, (1, 1, 2048), (2048, 2048, 1), 0); del buf205  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_45, output_35, hidden_states_51, float_44, pow_22, mean_21, add_77, rsqrt_33, output_36, float_45, add_78, output_37, hidden_states_52], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf177, buf183, buf206, arg110_1, buf208, 1, 2048, stream=raw_stream0)
        del arg110_1
        assert_size_stride(arg111_1, (6144, 2048), (2048, 1), 'input')
        buf209 = buf186; del buf186  # reuse
        # Topologically Sorted Source Nodes: [linear_52], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf208, arg111_1, buf209, 384, 1, 1, stream=raw_stream0)
        del arg111_1
        assert_size_stride(arg112_1, (6144, 2048), (2048, 1), 'input')
        buf211 = reinterpret_tensor(buf180, (1, 1, 6144), (6144, 6144, 1), 0); del buf180  # reuse
        # Topologically Sorted Source Nodes: [linear_52, silu_18, linear_53, mul_125], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf208, arg112_1, buf209, buf211, 384, 1, 1, stream=raw_stream0)
        del arg112_1
        assert_size_stride(arg113_1, (2048, 6144), (6144, 1), 'input')
        buf212 = reinterpret_tensor(buf208, (1, 2048), (2048, 1), 0); del buf208  # reuse
        # Topologically Sorted Source Nodes: [linear_52, silu_18, linear_53, mul_125, down_proj_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf211, arg113_1, buf212, 128, 1, 1, stream=raw_stream0)
        del arg113_1
        assert_size_stride(arg114_1, (2048, ), (1, ), 'input')
        buf214 = reinterpret_tensor(buf147, (1, 1, 2048), (2048, 2048, 1), 0); del buf147  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_45, output_35, hidden_states_51, down_proj_6, hidden_states_53, float_46, pow_23, mean_22, add_80, rsqrt_34, output_38, float_47, add_81, output_39, hidden_states_54], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf177, buf183, buf206, buf212, arg114_1, buf214, 1, 2048, stream=raw_stream0)
        del arg114_1
        assert_size_stride(arg117_1, (512, 2048), (2048, 1), 'input')
        buf223 = reinterpret_tensor(buf95, (1, 512), (512, 1), 0); del buf95  # reuse
        # Topologically Sorted Source Nodes: [linear_56], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_26.run(buf214, arg117_1, buf223, 32, 1, 1, stream=raw_stream0)
        del arg117_1
        buf224 = buf101; del buf101  # reuse
        # Topologically Sorted Source Nodes: [linear_56, view_6, float_50, pow_25, mean_24], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_view_27.run(buf223, buf224, 2, 256, stream=raw_stream0)
        assert_size_stride(arg118_1, (256, ), (1, ), 'input')
        buf227 = buf104; del buf104  # reuse
        buf225 = reinterpret_tensor(buf227, (1, 2, 1, 32), (128, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_56, view_6, float_50, pow_25, mean_24, add_84, rsqrt_36, output_42, float_51, add_85, output_43, type_as_18, key_states_2, k_rot_1, x2_3, neg_9], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_mean_mul_neg_pow_rsqrt_slice_transpose_view_28.run(buf223, buf224, arg118_1, buf225, 64, stream=raw_stream0)
        buf226 = reinterpret_tensor(buf227, (1, 2, 1, 32), (128, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_56, view_6, float_50, pow_25, mean_24, add_84, rsqrt_36, output_42, float_51, add_85, output_43, type_as_18, key_states_2, k_rot_1, x2_3, neg_9, x1_3, cat_13], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_29.run(buf223, buf224, arg118_1, buf226, 64, stream=raw_stream0)
        buf230 = reinterpret_tensor(buf100, (1, 2, 1, 256), (512, 256, 256, 1), 0); del buf100  # reuse
        buf228 = reinterpret_tensor(buf230, (1, 2, 1, 64), (512, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_5, sin_5, linear_56, view_6, float_50, pow_25, mean_24, add_84, rsqrt_36, output_42, float_51, add_85, output_43, type_as_18, key_states_2, k_rot_1, mul_134, mul_135, k_embed_2], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_30.run(buf223, buf224, arg118_1, buf92, buf227, buf96, buf228, 128, stream=raw_stream0)
        del buf225
        del buf226
        buf229 = reinterpret_tensor(buf230, (1, 2, 1, 192), (512, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_5, sin_5, linear_56, view_6, float_50, pow_25, mean_24, add_84, rsqrt_36, output_42, float_51, add_85, output_43, type_as_18, key_states_2, k_rot_1, mul_134, mul_135, k_embed_2, k_pass_1, k_embed_3], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_31.run(buf223, buf224, arg118_1, buf229, 384, stream=raw_stream0)
        del arg118_1
        assert_size_stride_grouped((arg120_1, arg121_1), ((), (1, 2, 144, 256)), ((), (73728, 36864, 256, 1)), 'input')
        # Topologically Sorted Source Nodes: [arange_2, cache_position_1, index_copy__2], Original ATen: [aten.arange, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_32.run(arg120_1, buf230, arg121_1, 512, stream=raw_stream0)
        del buf228
        del buf229
        assert_size_stride(arg119_1, (512, 2048), (2048, 1), 'input')
        buf236 = reinterpret_tensor(buf230, (1, 512), (512, 1), 0); del buf230  # reuse
        # Topologically Sorted Source Nodes: [linear_57], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_26.run(buf214, arg119_1, buf236, 32, 1, 1, stream=raw_stream0)
        del arg119_1
        assert_size_stride(arg122_1, (1, 2, 144, 256), (73728, 36864, 256, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_2, cache_position_1, linear_57, view_7, value_states_2, index_copy__3], Original ATen: [aten.arange, aten.add, aten._unsafe_view, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_32.run(arg120_1, buf236, arg122_1, 512, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [add__1], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__33.run(arg120_1, arg120_1, 1, stream=raw_stream0)
        del arg120_1
        assert_size_stride(arg115_1, (4096, 2048), (2048, 1), 'input')
        buf215 = empty_strided((1, 4096), (4096, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [linear_55], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_34.run(buf214, arg115_1, buf215, 256, 1, 1, stream=raw_stream0)
        del arg115_1
        buf216 = reinterpret_tensor(buf112, (1, 1, 8, 1), (8, 8, 1, 8), 0); del buf112  # reuse
        # Topologically Sorted Source Nodes: [linear_55, view_4, chunk_1, float_48, pow_24, mean_23], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_35.run(buf215, buf216, 8, 256, stream=raw_stream0)
        assert_size_stride(arg116_1, (256, ), (1, ), 'input')
        buf219 = reinterpret_tensor(buf236, (1, 8, 1, 64), (512, 64, 64, 1), 0); del buf236  # reuse
        buf217 = reinterpret_tensor(buf219, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        buf218 = reinterpret_tensor(buf219, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_55, view_4, chunk_1, float_48, pow_24, mean_23, add_82, rsqrt_35, output_40, float_49, add_83, output_41, type_as_17, query_states_3, q_rot_1, x2_2, neg_8, x1_2, cat_12], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36.run(buf215, buf216, arg116_1, buf217, buf218, 256, stream=raw_stream0)
        buf222 = reinterpret_tensor(buf214, (1, 8, 1, 256), (2048, 256, 256, 1), 0); del buf214  # reuse
        buf220 = reinterpret_tensor(buf222, (1, 8, 1, 64), (2048, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_55, view_4, chunk_1, float_48, pow_24, mean_23, add_82, rsqrt_35, output_40, float_49, add_83, output_41, type_as_17, query_states_3, q_rot_1, cos_5, mul_132, sin_5, mul_133, q_embed_2], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37.run(buf215, buf216, arg116_1, buf92, buf219, buf96, buf220, 512, stream=raw_stream0)
        del buf217
        del buf218
        buf221 = reinterpret_tensor(buf222, (1, 8, 1, 192), (2048, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_55, view_4, chunk_1, float_48, pow_24, mean_23, add_82, rsqrt_35, output_40, float_49, add_83, output_41, type_as_17, query_states_3, q_rot_1, cos_5, mul_132, sin_5, mul_133, q_embed_2, q_pass_1, q_embed_3], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38.run(buf215, buf216, arg116_1, buf221, 1536, stream=raw_stream0)
        del arg116_1
        buf232 = empty_strided((8, 1, 144), (144, 144, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [matmul_2, key_states_3, transpose_56], Original ATen: [aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_39.run(buf222, arg121_1, buf232, 1152, 256, stream=raw_stream0)
        del arg121_1
        del buf220
        del buf221
        buf234 = empty_strided((1, 8, 1, 144), (1152, 144, 1152, 1), device='tnca', dtype=torch.float32)
        buf235 = reinterpret_tensor(buf216, (1, 8, 1, 1), (8, 1, 8, 8), 0); del buf216  # reuse
        # Topologically Sorted Source Nodes: [arange, getitem, getitem_1, getitem_2, allowed, mask_1, mask, getitem_3, matmul_2, attn_weights_4, attn_weights_5, softmax_1], Original ATen: [aten.arange, aten.unsqueeze, aten.select, aten.le, aten.masked_fill, aten.full, aten.view, aten.mul, aten.add, aten._to_copy, aten._softmax]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy_add_arange_full_le_masked_fill_mul_select_unsqueeze_view_40.run(buf232, arg0_1, buf234, buf235, 8, 144, stream=raw_stream0)
        buf238 = reinterpret_tensor(buf222, (8, 1, 256), (256, 256, 1), 0); del buf222  # reuse
        buf239 = reinterpret_tensor(buf238, (1, 1, 2048), (2048, 2048, 1), 0); del buf238  # reuse
        # Topologically Sorted Source Nodes: [linear_55, view_4, chunk_1, softmax_1, attn_weights_6, attn_output_5, value_states_3, transpose_57, reshape_49, gate_3, sigmoid_7, attn_output_8], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._softmax, aten._to_copy, aten.unsqueeze, aten.expand, aten.clone, aten.bmm, aten.transpose, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_41.run(buf239, buf234, buf235, arg122_1, buf215, 2048, 144, stream=raw_stream0)
        del arg122_1
        assert_size_stride(arg123_1, (2048, 2048), (2048, 1), 'input')
        buf240 = buf124; del buf124  # reuse
        # Topologically Sorted Source Nodes: [linear_55, view_4, chunk_1, attn_output_5, transpose_57, reshape_49, gate_3, sigmoid_7, attn_output_8, attn_output_9], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf239, arg123_1, buf240, 128, 1, 1, stream=raw_stream0)
        del arg123_1
        assert_size_stride(arg124_1, (2048, ), (1, ), 'input')
        buf241 = buf177; del buf177  # reuse
        buf243 = buf239; del buf239  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_45, output_35, hidden_states_51, down_proj_6, hidden_states_53, attn_output_9, hidden_states_57, float_52, pow_26, mean_25, add_91, rsqrt_37, output_44, float_53, add_92, output_45, hidden_states_58], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42.run(buf241, buf183, buf206, buf212, buf240, arg124_1, buf243, 1, 2048, stream=raw_stream0)
        del arg124_1
        assert_size_stride(arg125_1, (6144, 2048), (2048, 1), 'input')
        buf244 = reinterpret_tensor(buf211, (1, 6144), (6144, 1), 0); del buf211  # reuse
        # Topologically Sorted Source Nodes: [float_52, pow_26, mean_25, add_91, rsqrt_37, output_44, float_53, add_92, output_45, hidden_states_58, linear_59], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf243, arg125_1, buf244, 384, 1, 1, stream=raw_stream0)
        del arg125_1
        assert_size_stride(arg126_1, (6144, 2048), (2048, 1), 'input')
        buf246 = reinterpret_tensor(buf209, (1, 1, 6144), (6144, 6144, 1), 0); del buf209  # reuse
        # Topologically Sorted Source Nodes: [linear_59, silu_19, linear_60, mul_140], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf243, arg126_1, buf244, buf246, 384, 1, 1, stream=raw_stream0)
        del arg126_1
        assert_size_stride(arg127_1, (2048, 6144), (6144, 1), 'input')
        buf247 = reinterpret_tensor(buf243, (1, 2048), (2048, 1), 0); del buf243  # reuse
        # Topologically Sorted Source Nodes: [linear_59, silu_19, linear_60, mul_140, down_proj_7], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf246, arg127_1, buf247, 128, 1, 1, stream=raw_stream0)
        del arg127_1
        assert_size_stride(arg128_1, (2048, ), (1, ), 'input')
        buf249 = reinterpret_tensor(buf240, (1, 1, 2048), (2048, 2048, 1), 0); del buf240  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_59, float_54, pow_27, mean_26, add_94, rsqrt_38, output_46, float_55, add_95, output_47, hidden_states_60], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23.run(buf241, buf247, arg128_1, buf249, 1, 2048, stream=raw_stream0)
        del arg128_1
        assert_size_stride_grouped((arg132_1, arg135_1, arg136_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf258 = reinterpret_tensor(buf201, (1, 16), (16, 1), 0); del buf201  # reuse
        # Topologically Sorted Source Nodes: [exp_12, neg_10, a_6, float_57, add_96, softplus_6, g_6, transpose_64, getitem_112, exp_13], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf249, arg132_1, arg135_1, arg136_1, buf258, 1, 1, 1, stream=raw_stream0)
        del arg132_1
        del arg135_1
        del arg136_1
        assert_size_stride(arg131_1, (16, 2048), (2048, 1), 'input')
        buf261 = reinterpret_tensor(buf194, (1, 16, 1), (16, 1, 16), 0); del buf194  # reuse
        # Topologically Sorted Source Nodes: [b_6, beta_12, transpose_63, beta_13], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf249, arg131_1, buf261, 1, 1, 1, stream=raw_stream0)
        del arg131_1
        assert_size_stride(arg130_1, (2048, 2048), (2048, 1), 'input')
        buf268 = buf212; del buf212  # reuse
        # Topologically Sorted Source Nodes: [z_18], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf249, arg130_1, buf268, 128, 1, 1, stream=raw_stream0)
        del arg130_1
        assert_size_stride(arg129_1, (6144, 2048), (2048, 1), 'input')
        buf250 = reinterpret_tensor(buf246, (1, 6144), (6144, 1), 0); del buf246  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_59, float_54, pow_27, mean_26, add_94, rsqrt_38, output_46, float_55, add_95, output_47, hidden_states_60, mixed_qkv_24], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf249, arg129_1, buf250, 384, 1, 1, stream=raw_stream0)
        del arg129_1
        buf252 = reinterpret_tensor(buf253, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_24, mixed_qkv_25, cat_16], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf250, buf252, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_104, copy__12], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf253, arg133_1, 24576, stream=raw_stream0)
        del arg133_1
        del buf251
        del buf252
        assert_size_stride(arg134_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf254 = buf190; del buf190  # reuse
        # Topologically Sorted Source Nodes: [out_18, squeeze_6, unsqueeze_40, out_19, out_20], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf253, arg134_1, buf254, 6144, stream=raw_stream0)
        del arg134_1
        del buf253
        buf255 = reinterpret_tensor(buf202, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf202  # reuse
        buf256 = buf192; del buf192  # reuse
        # Topologically Sorted Source Nodes: [out_20, mixed_qkv_27, split_6, key_25, transpose_61, key_26, mul_146, sum_26], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf254, buf255, buf256, 16, 128, stream=raw_stream0)
        assert_size_stride(arg137_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf262 = reinterpret_tensor(buf200, (1, 16, 128), (2048, 128, 1), 0); del buf200  # reuse
        # Topologically Sorted Source Nodes: [out_20, mixed_qkv_27, split_6, add_98, inv_norm_13, key_27, k_t_6, value_19, transpose_62, value_20, v_t_6, exp_12, neg_10, a_6, float_57, add_96, softplus_6, g_6, transpose_64, getitem_112, exp_13, decay_t_6, last_recurrent_state_19, unsqueeze_42, mul_149, kv_mem_6, sub_6, b_6, beta_12, transpose_63, beta_13, getitem_114, beta_t_6, delta_6], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg137_1, buf258, buf255, buf256, buf254, buf261, buf262, 2048, 128, stream=raw_stream0)
        buf264 = buf191; del buf191  # reuse
        buf265 = reinterpret_tensor(buf261, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf261  # reuse
        # Topologically Sorted Source Nodes: [out_20, mixed_qkv_27, split_6, query_31, transpose_60, query_32, mul_144, sum_25], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf254, buf264, buf265, 16, 128, stream=raw_stream0)
        buf263 = buf199; del buf199  # reuse
        # Topologically Sorted Source Nodes: [out_20, mixed_qkv_27, split_6, add_98, inv_norm_13, key_27, k_t_6, unsqueeze_43, value_19, transpose_62, value_20, v_t_6, exp_12, neg_10, a_6, float_57, add_96, softplus_6, g_6, transpose_64, getitem_112, exp_13, decay_t_6, last_recurrent_state_19, sub_6, b_6, beta_12, transpose_63, beta_13, getitem_114, beta_t_6, delta_6, unsqueeze_44, mul_151, last_recurrent_state_20], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg137_1, buf258, buf255, buf256, buf262, buf263, arg137_1, 262144, stream=raw_stream0)
        del arg137_1
        buf266 = buf262; del buf262  # reuse
        # Topologically Sorted Source Nodes: [add_97, inv_norm_12, query_33, query_34, q_t_6, unsqueeze_45, mul_152, sum_28], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf263, buf264, buf265, buf266, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg138_1, (128, ), (1, ), 'input')
        buf269 = reinterpret_tensor(buf268, (16, 128), (128, 1), 0); del buf268  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_30, core_attn_out_31, core_attn_out_32, hidden_states_61, pow_28, variance_6, add_100, rsqrt_41, hidden_states_62, to_93, hidden_states_63, z_18, z_19, z_20, to_94, silu_21, hidden_states_64, core_attn_out_33], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf269, buf266, arg138_1, 16, 128, stream=raw_stream0)
        del arg138_1
        assert_size_stride(arg139_1, (2048, 2048), (2048, 1), 'input')
        buf270 = reinterpret_tensor(buf249, (1, 2048), (2048, 1), 0); del buf249  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_30, core_attn_out_31, core_attn_out_32, hidden_states_61, pow_28, variance_6, add_100, rsqrt_41, hidden_states_62, to_93, hidden_states_63, z_18, z_19, z_20, to_94, silu_21, hidden_states_64, core_attn_out_33, core_attn_out_34, output_48], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf269, arg139_1, buf270, 128, 1, 1, stream=raw_stream0)
        del arg139_1
        assert_size_stride(arg140_1, (2048, ), (1, ), 'input')
        buf272 = reinterpret_tensor(buf269, (1, 1, 2048), (2048, 2048, 1), 0); del buf269  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_59, output_48, hidden_states_65, float_58, pow_29, mean_28, add_102, rsqrt_42, output_49, float_59, add_103, output_50, hidden_states_66], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf241, buf247, buf270, arg140_1, buf272, 1, 2048, stream=raw_stream0)
        del arg140_1
        assert_size_stride(arg141_1, (6144, 2048), (2048, 1), 'input')
        buf273 = buf250; del buf250  # reuse
        # Topologically Sorted Source Nodes: [linear_67], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf272, arg141_1, buf273, 384, 1, 1, stream=raw_stream0)
        del arg141_1
        assert_size_stride(arg142_1, (6144, 2048), (2048, 1), 'input')
        buf275 = reinterpret_tensor(buf244, (1, 1, 6144), (6144, 6144, 1), 0); del buf244  # reuse
        # Topologically Sorted Source Nodes: [linear_67, silu_22, linear_68, mul_158], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf272, arg142_1, buf273, buf275, 384, 1, 1, stream=raw_stream0)
        del arg142_1
        assert_size_stride(arg143_1, (2048, 6144), (6144, 1), 'input')
        buf276 = reinterpret_tensor(buf272, (1, 2048), (2048, 1), 0); del buf272  # reuse
        # Topologically Sorted Source Nodes: [linear_67, silu_22, linear_68, mul_158, down_proj_8], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf275, arg143_1, buf276, 128, 1, 1, stream=raw_stream0)
        del arg143_1
        assert_size_stride(arg144_1, (2048, ), (1, ), 'input')
        buf278 = reinterpret_tensor(buf206, (1, 1, 2048), (2048, 2048, 1), 0); del buf206  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_59, output_48, hidden_states_65, down_proj_8, hidden_states_67, float_60, pow_30, mean_29, add_105, rsqrt_43, output_51, float_61, add_106, output_52, hidden_states_68], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf241, buf247, buf270, buf276, arg144_1, buf278, 1, 2048, stream=raw_stream0)
        del arg144_1
        assert_size_stride_grouped((arg148_1, arg151_1, arg152_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf287 = reinterpret_tensor(buf265, (1, 16), (16, 1), 0); del buf265  # reuse
        # Topologically Sorted Source Nodes: [exp_14, neg_11, a_7, float_63, add_107, softplus_7, g_7, transpose_72, getitem_123, exp_15], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf278, arg148_1, arg151_1, arg152_1, buf287, 1, 1, 1, stream=raw_stream0)
        del arg148_1
        del arg151_1
        del arg152_1
        assert_size_stride(arg147_1, (16, 2048), (2048, 1), 'input')
        buf290 = reinterpret_tensor(buf258, (1, 16, 1), (16, 1, 16), 0); del buf258  # reuse
        # Topologically Sorted Source Nodes: [b_7, beta_14, transpose_71, beta_15], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf278, arg147_1, buf290, 1, 1, 1, stream=raw_stream0)
        del arg147_1
        assert_size_stride(arg146_1, (2048, 2048), (2048, 1), 'input')
        buf297 = buf183; del buf183  # reuse
        # Topologically Sorted Source Nodes: [z_21], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf278, arg146_1, buf297, 128, 1, 1, stream=raw_stream0)
        del arg146_1
        assert_size_stride(arg145_1, (6144, 2048), (2048, 1), 'input')
        buf279 = reinterpret_tensor(buf275, (1, 6144), (6144, 1), 0); del buf275  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_28], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf278, arg145_1, buf279, 384, 1, 1, stream=raw_stream0)
        del arg145_1
        buf281 = reinterpret_tensor(buf282, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_28, mixed_qkv_29, cat_17], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf279, buf281, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_115, copy__14], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf282, arg149_1, 24576, stream=raw_stream0)
        del arg149_1
        del buf280
        del buf281
        assert_size_stride(arg150_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf283 = buf254; del buf254  # reuse
        # Topologically Sorted Source Nodes: [out_21, squeeze_7, unsqueeze_46, out_22, out_23], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf282, arg150_1, buf283, 6144, stream=raw_stream0)
        del arg150_1
        del buf282
        buf284 = reinterpret_tensor(buf266, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf266  # reuse
        buf285 = buf256; del buf256  # reuse
        # Topologically Sorted Source Nodes: [out_23, mixed_qkv_31, split_7, key_29, transpose_69, key_30, mul_164, sum_30], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf283, buf284, buf285, 16, 128, stream=raw_stream0)
        assert_size_stride(arg153_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf291 = reinterpret_tensor(buf264, (1, 16, 128), (2048, 128, 1), 0); del buf264  # reuse
        # Topologically Sorted Source Nodes: [out_23, mixed_qkv_31, split_7, add_109, inv_norm_15, key_31, k_t_7, value_22, transpose_70, value_23, v_t_7, exp_14, neg_11, a_7, float_63, add_107, softplus_7, g_7, transpose_72, getitem_123, exp_15, decay_t_7, last_recurrent_state_22, unsqueeze_48, mul_167, kv_mem_7, sub_7, b_7, beta_14, transpose_71, beta_15, getitem_125, beta_t_7, delta_7], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg153_1, buf287, buf284, buf285, buf283, buf290, buf291, 2048, 128, stream=raw_stream0)
        buf293 = buf255; del buf255  # reuse
        buf294 = reinterpret_tensor(buf290, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf290  # reuse
        # Topologically Sorted Source Nodes: [out_23, mixed_qkv_31, split_7, query_36, transpose_68, query_37, mul_162, sum_29], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf283, buf293, buf294, 16, 128, stream=raw_stream0)
        buf292 = buf263; del buf263  # reuse
        # Topologically Sorted Source Nodes: [out_23, mixed_qkv_31, split_7, add_109, inv_norm_15, key_31, k_t_7, unsqueeze_49, value_22, transpose_70, value_23, v_t_7, exp_14, neg_11, a_7, float_63, add_107, softplus_7, g_7, transpose_72, getitem_123, exp_15, decay_t_7, last_recurrent_state_22, sub_7, b_7, beta_14, transpose_71, beta_15, getitem_125, beta_t_7, delta_7, unsqueeze_50, mul_169, last_recurrent_state_23], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg153_1, buf287, buf284, buf285, buf291, buf292, arg153_1, 262144, stream=raw_stream0)
        del arg153_1
        buf295 = buf291; del buf291  # reuse
        # Topologically Sorted Source Nodes: [add_108, inv_norm_14, query_38, query_39, q_t_7, unsqueeze_51, mul_170, sum_32], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf292, buf293, buf294, buf295, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg154_1, (128, ), (1, ), 'input')
        buf298 = reinterpret_tensor(buf297, (16, 128), (128, 1), 0); del buf297  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_35, core_attn_out_36, core_attn_out_37, hidden_states_69, pow_31, variance_7, add_111, rsqrt_46, hidden_states_70, to_106, hidden_states_71, z_21, z_22, z_23, to_107, silu_24, hidden_states_72, core_attn_out_38], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf298, buf295, arg154_1, 16, 128, stream=raw_stream0)
        del arg154_1
        assert_size_stride(arg155_1, (2048, 2048), (2048, 1), 'input')
        buf299 = reinterpret_tensor(buf278, (1, 2048), (2048, 1), 0); del buf278  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_35, core_attn_out_36, core_attn_out_37, hidden_states_69, pow_31, variance_7, add_111, rsqrt_46, hidden_states_70, to_106, hidden_states_71, z_21, z_22, z_23, to_107, silu_24, hidden_states_72, core_attn_out_38, core_attn_out_39, output_53], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf298, arg155_1, buf299, 128, 1, 1, stream=raw_stream0)
        del arg155_1
        assert_size_stride(arg156_1, (2048, ), (1, ), 'input')
        buf300 = buf241; del buf241  # reuse
        buf302 = reinterpret_tensor(buf298, (1, 1, 2048), (2048, 2048, 1), 0); del buf298  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_59, output_48, hidden_states_65, down_proj_8, hidden_states_67, output_53, hidden_states_73, float_64, pow_32, mean_31, add_113, rsqrt_47, output_54, float_65, add_114, output_55, hidden_states_74], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42.run(buf300, buf247, buf270, buf276, buf299, arg156_1, buf302, 1, 2048, stream=raw_stream0)
        del arg156_1
        assert_size_stride(arg157_1, (6144, 2048), (2048, 1), 'input')
        buf303 = buf279; del buf279  # reuse
        # Topologically Sorted Source Nodes: [float_64, pow_32, mean_31, add_113, rsqrt_47, output_54, float_65, add_114, output_55, hidden_states_74, linear_75], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf302, arg157_1, buf303, 384, 1, 1, stream=raw_stream0)
        del arg157_1
        assert_size_stride(arg158_1, (6144, 2048), (2048, 1), 'input')
        buf305 = reinterpret_tensor(buf273, (1, 1, 6144), (6144, 6144, 1), 0); del buf273  # reuse
        # Topologically Sorted Source Nodes: [linear_75, silu_25, linear_76, mul_176], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf302, arg158_1, buf303, buf305, 384, 1, 1, stream=raw_stream0)
        del arg158_1
        assert_size_stride(arg159_1, (2048, 6144), (6144, 1), 'input')
        buf306 = reinterpret_tensor(buf302, (1, 2048), (2048, 1), 0); del buf302  # reuse
        # Topologically Sorted Source Nodes: [linear_75, silu_25, linear_76, mul_176, down_proj_9], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf305, arg159_1, buf306, 128, 1, 1, stream=raw_stream0)
        del arg159_1
        assert_size_stride(arg160_1, (2048, ), (1, ), 'input')
        buf308 = reinterpret_tensor(buf299, (1, 1, 2048), (2048, 2048, 1), 0); del buf299  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_75, float_66, pow_33, mean_32, add_116, rsqrt_48, output_56, float_67, add_117, output_57, hidden_states_76], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23.run(buf300, buf306, arg160_1, buf308, 1, 2048, stream=raw_stream0)
        del arg160_1
        assert_size_stride_grouped((arg164_1, arg167_1, arg168_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf317 = reinterpret_tensor(buf294, (1, 16), (16, 1), 0); del buf294  # reuse
        # Topologically Sorted Source Nodes: [exp_16, neg_12, a_8, float_69, add_118, softplus_8, g_8, transpose_80, getitem_134, exp_17], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf308, arg164_1, arg167_1, arg168_1, buf317, 1, 1, 1, stream=raw_stream0)
        del arg164_1
        del arg167_1
        del arg168_1
        assert_size_stride(arg163_1, (16, 2048), (2048, 1), 'input')
        buf320 = reinterpret_tensor(buf287, (1, 16, 1), (16, 1, 16), 0); del buf287  # reuse
        # Topologically Sorted Source Nodes: [b_8, beta_16, transpose_79, beta_17], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf308, arg163_1, buf320, 1, 1, 1, stream=raw_stream0)
        del arg163_1
        assert_size_stride(arg162_1, (2048, 2048), (2048, 1), 'input')
        buf327 = buf276; del buf276  # reuse
        # Topologically Sorted Source Nodes: [z_24], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf308, arg162_1, buf327, 128, 1, 1, stream=raw_stream0)
        del arg162_1
        assert_size_stride(arg161_1, (6144, 2048), (2048, 1), 'input')
        buf309 = reinterpret_tensor(buf305, (1, 6144), (6144, 1), 0); del buf305  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_75, float_66, pow_33, mean_32, add_116, rsqrt_48, output_56, float_67, add_117, output_57, hidden_states_76, mixed_qkv_32], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf308, arg161_1, buf309, 384, 1, 1, stream=raw_stream0)
        del arg161_1
        buf311 = reinterpret_tensor(buf312, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_32, mixed_qkv_33, cat_18], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf309, buf311, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_126, copy__16], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf312, arg165_1, 24576, stream=raw_stream0)
        del arg165_1
        del buf310
        del buf311
        assert_size_stride(arg166_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf313 = buf283; del buf283  # reuse
        # Topologically Sorted Source Nodes: [out_24, squeeze_8, unsqueeze_52, out_25, out_26], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf312, arg166_1, buf313, 6144, stream=raw_stream0)
        del arg166_1
        del buf312
        buf314 = reinterpret_tensor(buf295, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf295  # reuse
        buf315 = buf285; del buf285  # reuse
        # Topologically Sorted Source Nodes: [out_26, mixed_qkv_35, split_8, key_33, transpose_77, key_34, mul_182, sum_34], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf313, buf314, buf315, 16, 128, stream=raw_stream0)
        assert_size_stride(arg169_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf321 = reinterpret_tensor(buf293, (1, 16, 128), (2048, 128, 1), 0); del buf293  # reuse
        # Topologically Sorted Source Nodes: [out_26, mixed_qkv_35, split_8, add_120, inv_norm_17, key_35, k_t_8, value_25, transpose_78, value_26, v_t_8, exp_16, neg_12, a_8, float_69, add_118, softplus_8, g_8, transpose_80, getitem_134, exp_17, decay_t_8, last_recurrent_state_25, unsqueeze_54, mul_185, kv_mem_8, sub_8, b_8, beta_16, transpose_79, beta_17, getitem_136, beta_t_8, delta_8], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg169_1, buf317, buf314, buf315, buf313, buf320, buf321, 2048, 128, stream=raw_stream0)
        buf323 = buf284; del buf284  # reuse
        buf324 = reinterpret_tensor(buf320, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf320  # reuse
        # Topologically Sorted Source Nodes: [out_26, mixed_qkv_35, split_8, query_41, transpose_76, query_42, mul_180, sum_33], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf313, buf323, buf324, 16, 128, stream=raw_stream0)
        buf322 = buf292; del buf292  # reuse
        # Topologically Sorted Source Nodes: [out_26, mixed_qkv_35, split_8, add_120, inv_norm_17, key_35, k_t_8, unsqueeze_55, value_25, transpose_78, value_26, v_t_8, exp_16, neg_12, a_8, float_69, add_118, softplus_8, g_8, transpose_80, getitem_134, exp_17, decay_t_8, last_recurrent_state_25, sub_8, b_8, beta_16, transpose_79, beta_17, getitem_136, beta_t_8, delta_8, unsqueeze_56, mul_187, last_recurrent_state_26], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg169_1, buf317, buf314, buf315, buf321, buf322, arg169_1, 262144, stream=raw_stream0)
        del arg169_1
        buf325 = buf321; del buf321  # reuse
        # Topologically Sorted Source Nodes: [add_119, inv_norm_16, query_43, query_44, q_t_8, unsqueeze_57, mul_188, sum_36], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf322, buf323, buf324, buf325, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg170_1, (128, ), (1, ), 'input')
        buf328 = reinterpret_tensor(buf327, (16, 128), (128, 1), 0); del buf327  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_40, core_attn_out_41, core_attn_out_42, hidden_states_77, pow_34, variance_8, add_122, rsqrt_51, hidden_states_78, to_119, hidden_states_79, z_24, z_25, z_26, to_120, silu_27, hidden_states_80, core_attn_out_43], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf328, buf325, arg170_1, 16, 128, stream=raw_stream0)
        del arg170_1
        assert_size_stride(arg171_1, (2048, 2048), (2048, 1), 'input')
        buf329 = reinterpret_tensor(buf308, (1, 2048), (2048, 1), 0); del buf308  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_40, core_attn_out_41, core_attn_out_42, hidden_states_77, pow_34, variance_8, add_122, rsqrt_51, hidden_states_78, to_119, hidden_states_79, z_24, z_25, z_26, to_120, silu_27, hidden_states_80, core_attn_out_43, core_attn_out_44, output_58], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf328, arg171_1, buf329, 128, 1, 1, stream=raw_stream0)
        del arg171_1
        assert_size_stride(arg172_1, (2048, ), (1, ), 'input')
        buf331 = reinterpret_tensor(buf328, (1, 1, 2048), (2048, 2048, 1), 0); del buf328  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_75, output_58, hidden_states_81, float_70, pow_35, mean_34, add_124, rsqrt_52, output_59, float_71, add_125, output_60, hidden_states_82], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf300, buf306, buf329, arg172_1, buf331, 1, 2048, stream=raw_stream0)
        del arg172_1
        assert_size_stride(arg173_1, (6144, 2048), (2048, 1), 'input')
        buf332 = buf309; del buf309  # reuse
        # Topologically Sorted Source Nodes: [linear_83], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf331, arg173_1, buf332, 384, 1, 1, stream=raw_stream0)
        del arg173_1
        assert_size_stride(arg174_1, (6144, 2048), (2048, 1), 'input')
        buf334 = reinterpret_tensor(buf303, (1, 1, 6144), (6144, 6144, 1), 0); del buf303  # reuse
        # Topologically Sorted Source Nodes: [linear_83, silu_28, linear_84, mul_194], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf331, arg174_1, buf332, buf334, 384, 1, 1, stream=raw_stream0)
        del arg174_1
        assert_size_stride(arg175_1, (2048, 6144), (6144, 1), 'input')
        buf335 = reinterpret_tensor(buf331, (1, 2048), (2048, 1), 0); del buf331  # reuse
        # Topologically Sorted Source Nodes: [linear_83, silu_28, linear_84, mul_194, down_proj_10], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf334, arg175_1, buf335, 128, 1, 1, stream=raw_stream0)
        del arg175_1
        assert_size_stride(arg176_1, (2048, ), (1, ), 'input')
        buf337 = reinterpret_tensor(buf270, (1, 1, 2048), (2048, 2048, 1), 0); del buf270  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_75, output_58, hidden_states_81, down_proj_10, hidden_states_83, float_72, pow_36, mean_35, add_127, rsqrt_53, output_61, float_73, add_128, output_62, hidden_states_84], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf300, buf306, buf329, buf335, arg176_1, buf337, 1, 2048, stream=raw_stream0)
        del arg176_1
        assert_size_stride(arg179_1, (512, 2048), (2048, 1), 'input')
        buf346 = reinterpret_tensor(buf219, (1, 512), (512, 1), 0); del buf219  # reuse
        # Topologically Sorted Source Nodes: [linear_87], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_26.run(buf337, arg179_1, buf346, 32, 1, 1, stream=raw_stream0)
        del arg179_1
        buf347 = buf224; del buf224  # reuse
        # Topologically Sorted Source Nodes: [linear_87, view_10, float_76, pow_38, mean_37], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_view_27.run(buf346, buf347, 2, 256, stream=raw_stream0)
        assert_size_stride(arg180_1, (256, ), (1, ), 'input')
        buf350 = buf227; del buf227  # reuse
        buf348 = reinterpret_tensor(buf350, (1, 2, 1, 32), (128, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_87, view_10, float_76, pow_38, mean_37, add_131, rsqrt_55, output_65, float_77, add_132, output_66, type_as_28, key_states_4, k_rot_2, x2_5, neg_14], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_mean_mul_neg_pow_rsqrt_slice_transpose_view_28.run(buf346, buf347, arg180_1, buf348, 64, stream=raw_stream0)
        buf349 = reinterpret_tensor(buf350, (1, 2, 1, 32), (128, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_87, view_10, float_76, pow_38, mean_37, add_131, rsqrt_55, output_65, float_77, add_132, output_66, type_as_28, key_states_4, k_rot_2, x2_5, neg_14, x1_5, cat_20], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_29.run(buf346, buf347, arg180_1, buf349, 64, stream=raw_stream0)
        buf353 = reinterpret_tensor(buf223, (1, 2, 1, 256), (512, 256, 256, 1), 0); del buf223  # reuse
        buf351 = reinterpret_tensor(buf353, (1, 2, 1, 64), (512, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_6, sin_6, linear_87, view_10, float_76, pow_38, mean_37, add_131, rsqrt_55, output_65, float_77, add_132, output_66, type_as_28, key_states_4, k_rot_2, mul_203, mul_204, k_embed_4], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_30.run(buf346, buf347, arg180_1, buf92, buf350, buf96, buf351, 128, stream=raw_stream0)
        del buf348
        del buf349
        buf352 = reinterpret_tensor(buf353, (1, 2, 1, 192), (512, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_6, sin_6, linear_87, view_10, float_76, pow_38, mean_37, add_131, rsqrt_55, output_65, float_77, add_132, output_66, type_as_28, key_states_4, k_rot_2, mul_203, mul_204, k_embed_4, k_pass_2, k_embed_5], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_31.run(buf346, buf347, arg180_1, buf352, 384, stream=raw_stream0)
        del arg180_1
        assert_size_stride_grouped((arg182_1, arg183_1), ((), (1, 2, 144, 256)), ((), (73728, 36864, 256, 1)), 'input')
        # Topologically Sorted Source Nodes: [arange_3, cache_position_2, index_copy__4], Original ATen: [aten.arange, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_32.run(arg182_1, buf353, arg183_1, 512, stream=raw_stream0)
        del buf351
        del buf352
        assert_size_stride(arg181_1, (512, 2048), (2048, 1), 'input')
        buf359 = reinterpret_tensor(buf353, (1, 512), (512, 1), 0); del buf353  # reuse
        # Topologically Sorted Source Nodes: [linear_88], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_26.run(buf337, arg181_1, buf359, 32, 1, 1, stream=raw_stream0)
        del arg181_1
        assert_size_stride(arg184_1, (1, 2, 144, 256), (73728, 36864, 256, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_3, cache_position_2, linear_88, view_11, value_states_4, index_copy__5], Original ATen: [aten.arange, aten.add, aten._unsafe_view, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_32.run(arg182_1, buf359, arg184_1, 512, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [add__2], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__33.run(arg182_1, arg182_1, 1, stream=raw_stream0)
        del arg182_1
        assert_size_stride(arg177_1, (4096, 2048), (2048, 1), 'input')
        buf338 = buf215; del buf215  # reuse
        # Topologically Sorted Source Nodes: [linear_86], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_34.run(buf337, arg177_1, buf338, 256, 1, 1, stream=raw_stream0)
        del arg177_1
        buf339 = reinterpret_tensor(buf235, (1, 1, 8, 1), (8, 8, 1, 8), 0); del buf235  # reuse
        # Topologically Sorted Source Nodes: [linear_86, view_8, chunk_2, float_74, pow_37, mean_36], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_35.run(buf338, buf339, 8, 256, stream=raw_stream0)
        assert_size_stride(arg178_1, (256, ), (1, ), 'input')
        buf342 = reinterpret_tensor(buf359, (1, 8, 1, 64), (512, 64, 64, 1), 0); del buf359  # reuse
        buf340 = reinterpret_tensor(buf342, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        buf341 = reinterpret_tensor(buf342, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_86, view_8, chunk_2, float_74, pow_37, mean_36, add_129, rsqrt_54, output_63, float_75, add_130, output_64, type_as_27, query_states_5, q_rot_2, x2_4, neg_13, x1_4, cat_19], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36.run(buf338, buf339, arg178_1, buf340, buf341, 256, stream=raw_stream0)
        buf345 = reinterpret_tensor(buf337, (1, 8, 1, 256), (2048, 256, 256, 1), 0); del buf337  # reuse
        buf343 = reinterpret_tensor(buf345, (1, 8, 1, 64), (2048, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_86, view_8, chunk_2, float_74, pow_37, mean_36, add_129, rsqrt_54, output_63, float_75, add_130, output_64, type_as_27, query_states_5, q_rot_2, cos_6, mul_201, sin_6, mul_202, q_embed_4], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37.run(buf338, buf339, arg178_1, buf92, buf342, buf96, buf343, 512, stream=raw_stream0)
        del buf340
        del buf341
        buf344 = reinterpret_tensor(buf345, (1, 8, 1, 192), (2048, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_86, view_8, chunk_2, float_74, pow_37, mean_36, add_129, rsqrt_54, output_63, float_75, add_130, output_64, type_as_27, query_states_5, q_rot_2, cos_6, mul_201, sin_6, mul_202, q_embed_4, q_pass_2, q_embed_5], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38.run(buf338, buf339, arg178_1, buf344, 1536, stream=raw_stream0)
        del arg178_1
        buf355 = buf232; del buf232  # reuse
        # Topologically Sorted Source Nodes: [matmul_4, key_states_5, transpose_85], Original ATen: [aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_39.run(buf345, arg183_1, buf355, 1152, 256, stream=raw_stream0)
        del arg183_1
        del buf343
        del buf344
        buf357 = buf234; del buf234  # reuse
        buf358 = reinterpret_tensor(buf339, (1, 8, 1, 1), (8, 1, 8, 8), 0); del buf339  # reuse
        # Topologically Sorted Source Nodes: [arange, getitem, getitem_1, getitem_2, allowed, mask_1, mask, getitem_3, matmul_4, attn_weights_8, attn_weights_9, softmax_2], Original ATen: [aten.arange, aten.unsqueeze, aten.select, aten.le, aten.masked_fill, aten.full, aten.view, aten.mul, aten.add, aten._to_copy, aten._softmax]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy_add_arange_full_le_masked_fill_mul_select_unsqueeze_view_40.run(buf355, arg0_1, buf357, buf358, 8, 144, stream=raw_stream0)
        buf361 = reinterpret_tensor(buf345, (8, 1, 256), (256, 256, 1), 0); del buf345  # reuse
        buf362 = reinterpret_tensor(buf361, (1, 1, 2048), (2048, 2048, 1), 0); del buf361  # reuse
        # Topologically Sorted Source Nodes: [linear_86, view_8, chunk_2, softmax_2, attn_weights_10, attn_output_10, value_states_5, transpose_86, reshape_74, gate_5, sigmoid_11, attn_output_13], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._softmax, aten._to_copy, aten.unsqueeze, aten.expand, aten.clone, aten.bmm, aten.transpose, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_41.run(buf362, buf357, buf358, arg184_1, buf338, 2048, 144, stream=raw_stream0)
        del arg184_1
        assert_size_stride(arg185_1, (2048, 2048), (2048, 1), 'input')
        buf363 = buf247; del buf247  # reuse
        # Topologically Sorted Source Nodes: [linear_86, view_8, chunk_2, attn_output_10, transpose_86, reshape_74, gate_5, sigmoid_11, attn_output_13, attn_output_14], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf362, arg185_1, buf363, 128, 1, 1, stream=raw_stream0)
        del arg185_1
        assert_size_stride(arg186_1, (2048, ), (1, ), 'input')
        buf364 = buf300; del buf300  # reuse
        buf366 = buf362; del buf362  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_75, output_58, hidden_states_81, down_proj_10, hidden_states_83, attn_output_14, hidden_states_87, float_78, pow_39, mean_38, add_138, rsqrt_56, output_67, float_79, add_139, output_68, hidden_states_88], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42.run(buf364, buf306, buf329, buf335, buf363, arg186_1, buf366, 1, 2048, stream=raw_stream0)
        del arg186_1
        assert_size_stride(arg187_1, (6144, 2048), (2048, 1), 'input')
        buf367 = reinterpret_tensor(buf334, (1, 6144), (6144, 1), 0); del buf334  # reuse
        # Topologically Sorted Source Nodes: [float_78, pow_39, mean_38, add_138, rsqrt_56, output_67, float_79, add_139, output_68, hidden_states_88, linear_90], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf366, arg187_1, buf367, 384, 1, 1, stream=raw_stream0)
        del arg187_1
        assert_size_stride(arg188_1, (6144, 2048), (2048, 1), 'input')
        buf369 = reinterpret_tensor(buf332, (1, 1, 6144), (6144, 6144, 1), 0); del buf332  # reuse
        # Topologically Sorted Source Nodes: [linear_90, silu_29, linear_91, mul_209], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf366, arg188_1, buf367, buf369, 384, 1, 1, stream=raw_stream0)
        del arg188_1
        assert_size_stride(arg189_1, (2048, 6144), (6144, 1), 'input')
        buf370 = reinterpret_tensor(buf366, (1, 2048), (2048, 1), 0); del buf366  # reuse
        # Topologically Sorted Source Nodes: [linear_90, silu_29, linear_91, mul_209, down_proj_11], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf369, arg189_1, buf370, 128, 1, 1, stream=raw_stream0)
        del arg189_1
        assert_size_stride(arg190_1, (2048, ), (1, ), 'input')
        buf372 = reinterpret_tensor(buf363, (1, 1, 2048), (2048, 2048, 1), 0); del buf363  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_89, float_80, pow_40, mean_39, add_141, rsqrt_57, output_69, float_81, add_142, output_70, hidden_states_90], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23.run(buf364, buf370, arg190_1, buf372, 1, 2048, stream=raw_stream0)
        del arg190_1
        assert_size_stride_grouped((arg194_1, arg197_1, arg198_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf381 = reinterpret_tensor(buf324, (1, 16), (16, 1), 0); del buf324  # reuse
        # Topologically Sorted Source Nodes: [exp_18, neg_15, a_9, float_83, add_143, softplus_9, g_9, transpose_93, getitem_157, exp_19], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf372, arg194_1, arg197_1, arg198_1, buf381, 1, 1, 1, stream=raw_stream0)
        del arg194_1
        del arg197_1
        del arg198_1
        assert_size_stride(arg193_1, (16, 2048), (2048, 1), 'input')
        buf384 = reinterpret_tensor(buf317, (1, 16, 1), (16, 1, 16), 0); del buf317  # reuse
        # Topologically Sorted Source Nodes: [b_9, beta_18, transpose_92, beta_19], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf372, arg193_1, buf384, 1, 1, 1, stream=raw_stream0)
        del arg193_1
        assert_size_stride(arg192_1, (2048, 2048), (2048, 1), 'input')
        buf391 = buf335; del buf335  # reuse
        # Topologically Sorted Source Nodes: [z_27], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf372, arg192_1, buf391, 128, 1, 1, stream=raw_stream0)
        del arg192_1
        assert_size_stride(arg191_1, (6144, 2048), (2048, 1), 'input')
        buf373 = reinterpret_tensor(buf369, (1, 6144), (6144, 1), 0); del buf369  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_89, float_80, pow_40, mean_39, add_141, rsqrt_57, output_69, float_81, add_142, output_70, hidden_states_90, mixed_qkv_36], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf372, arg191_1, buf373, 384, 1, 1, stream=raw_stream0)
        del arg191_1
        buf375 = reinterpret_tensor(buf376, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_36, mixed_qkv_37, cat_23], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf373, buf375, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_149, copy__18], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf376, arg195_1, 24576, stream=raw_stream0)
        del arg195_1
        del buf374
        del buf375
        assert_size_stride(arg196_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf377 = buf313; del buf313  # reuse
        # Topologically Sorted Source Nodes: [out_27, squeeze_9, unsqueeze_60, out_28, out_29], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf376, arg196_1, buf377, 6144, stream=raw_stream0)
        del arg196_1
        del buf376
        buf378 = reinterpret_tensor(buf325, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf325  # reuse
        buf379 = buf315; del buf315  # reuse
        # Topologically Sorted Source Nodes: [out_29, mixed_qkv_39, split_9, key_37, transpose_90, key_38, mul_215, sum_38], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf377, buf378, buf379, 16, 128, stream=raw_stream0)
        assert_size_stride(arg199_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf385 = reinterpret_tensor(buf323, (1, 16, 128), (2048, 128, 1), 0); del buf323  # reuse
        # Topologically Sorted Source Nodes: [out_29, mixed_qkv_39, split_9, add_145, inv_norm_19, key_39, k_t_9, value_28, transpose_91, value_29, v_t_9, exp_18, neg_15, a_9, float_83, add_143, softplus_9, g_9, transpose_93, getitem_157, exp_19, decay_t_9, last_recurrent_state_28, unsqueeze_62, mul_218, kv_mem_9, sub_9, b_9, beta_18, transpose_92, beta_19, getitem_159, beta_t_9, delta_9], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg199_1, buf381, buf378, buf379, buf377, buf384, buf385, 2048, 128, stream=raw_stream0)
        buf387 = buf314; del buf314  # reuse
        buf388 = reinterpret_tensor(buf384, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf384  # reuse
        # Topologically Sorted Source Nodes: [out_29, mixed_qkv_39, split_9, query_46, transpose_89, query_47, mul_213, sum_37], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf377, buf387, buf388, 16, 128, stream=raw_stream0)
        buf386 = buf322; del buf322  # reuse
        # Topologically Sorted Source Nodes: [out_29, mixed_qkv_39, split_9, add_145, inv_norm_19, key_39, k_t_9, unsqueeze_63, value_28, transpose_91, value_29, v_t_9, exp_18, neg_15, a_9, float_83, add_143, softplus_9, g_9, transpose_93, getitem_157, exp_19, decay_t_9, last_recurrent_state_28, sub_9, b_9, beta_18, transpose_92, beta_19, getitem_159, beta_t_9, delta_9, unsqueeze_64, mul_220, last_recurrent_state_29], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg199_1, buf381, buf378, buf379, buf385, buf386, arg199_1, 262144, stream=raw_stream0)
        del arg199_1
        buf389 = buf385; del buf385  # reuse
        # Topologically Sorted Source Nodes: [add_144, inv_norm_18, query_48, query_49, q_t_9, unsqueeze_65, mul_221, sum_40], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf386, buf387, buf388, buf389, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg200_1, (128, ), (1, ), 'input')
        buf392 = reinterpret_tensor(buf391, (16, 128), (128, 1), 0); del buf391  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_45, core_attn_out_46, core_attn_out_47, hidden_states_91, pow_41, variance_9, add_147, rsqrt_60, hidden_states_92, to_133, hidden_states_93, z_27, z_28, z_29, to_134, silu_31, hidden_states_94, core_attn_out_48], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf392, buf389, arg200_1, 16, 128, stream=raw_stream0)
        del arg200_1
        assert_size_stride(arg201_1, (2048, 2048), (2048, 1), 'input')
        buf393 = reinterpret_tensor(buf372, (1, 2048), (2048, 1), 0); del buf372  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_45, core_attn_out_46, core_attn_out_47, hidden_states_91, pow_41, variance_9, add_147, rsqrt_60, hidden_states_92, to_133, hidden_states_93, z_27, z_28, z_29, to_134, silu_31, hidden_states_94, core_attn_out_48, core_attn_out_49, output_71], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf392, arg201_1, buf393, 128, 1, 1, stream=raw_stream0)
        del arg201_1
        assert_size_stride(arg202_1, (2048, ), (1, ), 'input')
        buf395 = reinterpret_tensor(buf392, (1, 1, 2048), (2048, 2048, 1), 0); del buf392  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_89, output_71, hidden_states_95, float_84, pow_42, mean_41, add_149, rsqrt_61, output_72, float_85, add_150, output_73, hidden_states_96], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf364, buf370, buf393, arg202_1, buf395, 1, 2048, stream=raw_stream0)
        del arg202_1
        assert_size_stride(arg203_1, (6144, 2048), (2048, 1), 'input')
        buf396 = buf373; del buf373  # reuse
        # Topologically Sorted Source Nodes: [linear_98], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf395, arg203_1, buf396, 384, 1, 1, stream=raw_stream0)
        del arg203_1
        assert_size_stride(arg204_1, (6144, 2048), (2048, 1), 'input')
        buf398 = reinterpret_tensor(buf367, (1, 1, 6144), (6144, 6144, 1), 0); del buf367  # reuse
        # Topologically Sorted Source Nodes: [linear_98, silu_32, linear_99, mul_227], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf395, arg204_1, buf396, buf398, 384, 1, 1, stream=raw_stream0)
        del arg204_1
        assert_size_stride(arg205_1, (2048, 6144), (6144, 1), 'input')
        buf399 = reinterpret_tensor(buf395, (1, 2048), (2048, 1), 0); del buf395  # reuse
        # Topologically Sorted Source Nodes: [linear_98, silu_32, linear_99, mul_227, down_proj_12], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf398, arg205_1, buf399, 128, 1, 1, stream=raw_stream0)
        del arg205_1
        assert_size_stride(arg206_1, (2048, ), (1, ), 'input')
        buf401 = reinterpret_tensor(buf329, (1, 1, 2048), (2048, 2048, 1), 0); del buf329  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_89, output_71, hidden_states_95, down_proj_12, hidden_states_97, float_86, pow_43, mean_42, add_152, rsqrt_62, output_74, float_87, add_153, output_75, hidden_states_98], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf364, buf370, buf393, buf399, arg206_1, buf401, 1, 2048, stream=raw_stream0)
        del arg206_1
        assert_size_stride_grouped((arg210_1, arg213_1, arg214_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf410 = reinterpret_tensor(buf388, (1, 16), (16, 1), 0); del buf388  # reuse
        # Topologically Sorted Source Nodes: [exp_20, neg_16, a_10, float_89, add_154, softplus_10, g_10, transpose_101, getitem_168, exp_21], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf401, arg210_1, arg213_1, arg214_1, buf410, 1, 1, 1, stream=raw_stream0)
        del arg210_1
        del arg213_1
        del arg214_1
        assert_size_stride(arg209_1, (16, 2048), (2048, 1), 'input')
        buf413 = reinterpret_tensor(buf381, (1, 16, 1), (16, 1, 16), 0); del buf381  # reuse
        # Topologically Sorted Source Nodes: [b_10, beta_20, transpose_100, beta_21], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf401, arg209_1, buf413, 1, 1, 1, stream=raw_stream0)
        del arg209_1
        assert_size_stride(arg208_1, (2048, 2048), (2048, 1), 'input')
        buf420 = buf306; del buf306  # reuse
        # Topologically Sorted Source Nodes: [z_30], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf401, arg208_1, buf420, 128, 1, 1, stream=raw_stream0)
        del arg208_1
        assert_size_stride(arg207_1, (6144, 2048), (2048, 1), 'input')
        buf402 = reinterpret_tensor(buf398, (1, 6144), (6144, 1), 0); del buf398  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_40], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf401, arg207_1, buf402, 384, 1, 1, stream=raw_stream0)
        del arg207_1
        buf404 = reinterpret_tensor(buf405, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_40, mixed_qkv_41, cat_24], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf402, buf404, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_160, copy__20], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf405, arg211_1, 24576, stream=raw_stream0)
        del arg211_1
        del buf403
        del buf404
        assert_size_stride(arg212_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf406 = buf377; del buf377  # reuse
        # Topologically Sorted Source Nodes: [out_30, squeeze_10, unsqueeze_66, out_31, out_32], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf405, arg212_1, buf406, 6144, stream=raw_stream0)
        del arg212_1
        del buf405
        buf407 = reinterpret_tensor(buf389, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf389  # reuse
        buf408 = buf379; del buf379  # reuse
        # Topologically Sorted Source Nodes: [out_32, mixed_qkv_43, split_10, key_41, transpose_98, key_42, mul_233, sum_42], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf406, buf407, buf408, 16, 128, stream=raw_stream0)
        assert_size_stride(arg215_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf414 = reinterpret_tensor(buf387, (1, 16, 128), (2048, 128, 1), 0); del buf387  # reuse
        # Topologically Sorted Source Nodes: [out_32, mixed_qkv_43, split_10, add_156, inv_norm_21, key_43, k_t_10, value_31, transpose_99, value_32, v_t_10, exp_20, neg_16, a_10, float_89, add_154, softplus_10, g_10, transpose_101, getitem_168, exp_21, decay_t_10, last_recurrent_state_31, unsqueeze_68, mul_236, kv_mem_10, sub_10, b_10, beta_20, transpose_100, beta_21, getitem_170, beta_t_10, delta_10], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg215_1, buf410, buf407, buf408, buf406, buf413, buf414, 2048, 128, stream=raw_stream0)
        buf416 = buf378; del buf378  # reuse
        buf417 = reinterpret_tensor(buf413, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf413  # reuse
        # Topologically Sorted Source Nodes: [out_32, mixed_qkv_43, split_10, query_51, transpose_97, query_52, mul_231, sum_41], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf406, buf416, buf417, 16, 128, stream=raw_stream0)
        buf415 = buf386; del buf386  # reuse
        # Topologically Sorted Source Nodes: [out_32, mixed_qkv_43, split_10, add_156, inv_norm_21, key_43, k_t_10, unsqueeze_69, value_31, transpose_99, value_32, v_t_10, exp_20, neg_16, a_10, float_89, add_154, softplus_10, g_10, transpose_101, getitem_168, exp_21, decay_t_10, last_recurrent_state_31, sub_10, b_10, beta_20, transpose_100, beta_21, getitem_170, beta_t_10, delta_10, unsqueeze_70, mul_238, last_recurrent_state_32], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg215_1, buf410, buf407, buf408, buf414, buf415, arg215_1, 262144, stream=raw_stream0)
        del arg215_1
        buf418 = buf414; del buf414  # reuse
        # Topologically Sorted Source Nodes: [add_155, inv_norm_20, query_53, query_54, q_t_10, unsqueeze_71, mul_239, sum_44], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf415, buf416, buf417, buf418, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg216_1, (128, ), (1, ), 'input')
        buf421 = reinterpret_tensor(buf420, (16, 128), (128, 1), 0); del buf420  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_50, core_attn_out_51, core_attn_out_52, hidden_states_99, pow_44, variance_10, add_158, rsqrt_65, hidden_states_100, to_146, hidden_states_101, z_30, z_31, z_32, to_147, silu_34, hidden_states_102, core_attn_out_53], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf421, buf418, arg216_1, 16, 128, stream=raw_stream0)
        del arg216_1
        assert_size_stride(arg217_1, (2048, 2048), (2048, 1), 'input')
        buf422 = reinterpret_tensor(buf401, (1, 2048), (2048, 1), 0); del buf401  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_50, core_attn_out_51, core_attn_out_52, hidden_states_99, pow_44, variance_10, add_158, rsqrt_65, hidden_states_100, to_146, hidden_states_101, z_30, z_31, z_32, to_147, silu_34, hidden_states_102, core_attn_out_53, core_attn_out_54, output_76], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf421, arg217_1, buf422, 128, 1, 1, stream=raw_stream0)
        del arg217_1
        assert_size_stride(arg218_1, (2048, ), (1, ), 'input')
        buf423 = buf364; del buf364  # reuse
        buf425 = reinterpret_tensor(buf421, (1, 1, 2048), (2048, 2048, 1), 0); del buf421  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_89, output_71, hidden_states_95, down_proj_12, hidden_states_97, output_76, hidden_states_103, float_90, pow_45, mean_44, add_160, rsqrt_66, output_77, float_91, add_161, output_78, hidden_states_104], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42.run(buf423, buf370, buf393, buf399, buf422, arg218_1, buf425, 1, 2048, stream=raw_stream0)
        del arg218_1
        assert_size_stride(arg219_1, (6144, 2048), (2048, 1), 'input')
        buf426 = buf402; del buf402  # reuse
        # Topologically Sorted Source Nodes: [float_90, pow_45, mean_44, add_160, rsqrt_66, output_77, float_91, add_161, output_78, hidden_states_104, linear_106], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf425, arg219_1, buf426, 384, 1, 1, stream=raw_stream0)
        del arg219_1
        assert_size_stride(arg220_1, (6144, 2048), (2048, 1), 'input')
        buf428 = reinterpret_tensor(buf396, (1, 1, 6144), (6144, 6144, 1), 0); del buf396  # reuse
        # Topologically Sorted Source Nodes: [linear_106, silu_35, linear_107, mul_245], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf425, arg220_1, buf426, buf428, 384, 1, 1, stream=raw_stream0)
        del arg220_1
        assert_size_stride(arg221_1, (2048, 6144), (6144, 1), 'input')
        buf429 = reinterpret_tensor(buf425, (1, 2048), (2048, 1), 0); del buf425  # reuse
        # Topologically Sorted Source Nodes: [linear_106, silu_35, linear_107, mul_245, down_proj_13], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf428, arg221_1, buf429, 128, 1, 1, stream=raw_stream0)
        del arg221_1
        assert_size_stride(arg222_1, (2048, ), (1, ), 'input')
        buf431 = reinterpret_tensor(buf422, (1, 1, 2048), (2048, 2048, 1), 0); del buf422  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_105, float_92, pow_46, mean_45, add_163, rsqrt_67, output_79, float_93, add_164, output_80, hidden_states_106], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23.run(buf423, buf429, arg222_1, buf431, 1, 2048, stream=raw_stream0)
        del arg222_1
        assert_size_stride_grouped((arg226_1, arg229_1, arg230_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf440 = reinterpret_tensor(buf417, (1, 16), (16, 1), 0); del buf417  # reuse
        # Topologically Sorted Source Nodes: [exp_22, neg_17, a_11, float_95, add_165, softplus_11, g_11, transpose_109, getitem_179, exp_23], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf431, arg226_1, arg229_1, arg230_1, buf440, 1, 1, 1, stream=raw_stream0)
        del arg226_1
        del arg229_1
        del arg230_1
        assert_size_stride(arg225_1, (16, 2048), (2048, 1), 'input')
        buf443 = reinterpret_tensor(buf410, (1, 16, 1), (16, 1, 16), 0); del buf410  # reuse
        # Topologically Sorted Source Nodes: [b_11, beta_22, transpose_108, beta_23], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf431, arg225_1, buf443, 1, 1, 1, stream=raw_stream0)
        del arg225_1
        assert_size_stride(arg224_1, (2048, 2048), (2048, 1), 'input')
        buf450 = buf399; del buf399  # reuse
        # Topologically Sorted Source Nodes: [z_33], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf431, arg224_1, buf450, 128, 1, 1, stream=raw_stream0)
        del arg224_1
        assert_size_stride(arg223_1, (6144, 2048), (2048, 1), 'input')
        buf432 = reinterpret_tensor(buf428, (1, 6144), (6144, 1), 0); del buf428  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_105, float_92, pow_46, mean_45, add_163, rsqrt_67, output_79, float_93, add_164, output_80, hidden_states_106, mixed_qkv_44], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf431, arg223_1, buf432, 384, 1, 1, stream=raw_stream0)
        del arg223_1
        buf434 = reinterpret_tensor(buf435, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_44, mixed_qkv_45, cat_25], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf432, buf434, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_171, copy__22], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf435, arg227_1, 24576, stream=raw_stream0)
        del arg227_1
        del buf433
        del buf434
        assert_size_stride(arg228_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf436 = buf406; del buf406  # reuse
        # Topologically Sorted Source Nodes: [out_33, squeeze_11, unsqueeze_72, out_34, out_35], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf435, arg228_1, buf436, 6144, stream=raw_stream0)
        del arg228_1
        del buf435
        buf437 = reinterpret_tensor(buf418, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf418  # reuse
        buf438 = buf408; del buf408  # reuse
        # Topologically Sorted Source Nodes: [out_35, mixed_qkv_47, split_11, key_45, transpose_106, key_46, mul_251, sum_46], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf436, buf437, buf438, 16, 128, stream=raw_stream0)
        assert_size_stride(arg231_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf444 = reinterpret_tensor(buf416, (1, 16, 128), (2048, 128, 1), 0); del buf416  # reuse
        # Topologically Sorted Source Nodes: [out_35, mixed_qkv_47, split_11, add_167, inv_norm_23, key_47, k_t_11, value_34, transpose_107, value_35, v_t_11, exp_22, neg_17, a_11, float_95, add_165, softplus_11, g_11, transpose_109, getitem_179, exp_23, decay_t_11, last_recurrent_state_34, unsqueeze_74, mul_254, kv_mem_11, sub_11, b_11, beta_22, transpose_108, beta_23, getitem_181, beta_t_11, delta_11], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg231_1, buf440, buf437, buf438, buf436, buf443, buf444, 2048, 128, stream=raw_stream0)
        buf446 = buf407; del buf407  # reuse
        buf447 = reinterpret_tensor(buf443, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf443  # reuse
        # Topologically Sorted Source Nodes: [out_35, mixed_qkv_47, split_11, query_56, transpose_105, query_57, mul_249, sum_45], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf436, buf446, buf447, 16, 128, stream=raw_stream0)
        buf445 = buf415; del buf415  # reuse
        # Topologically Sorted Source Nodes: [out_35, mixed_qkv_47, split_11, add_167, inv_norm_23, key_47, k_t_11, unsqueeze_75, value_34, transpose_107, value_35, v_t_11, exp_22, neg_17, a_11, float_95, add_165, softplus_11, g_11, transpose_109, getitem_179, exp_23, decay_t_11, last_recurrent_state_34, sub_11, b_11, beta_22, transpose_108, beta_23, getitem_181, beta_t_11, delta_11, unsqueeze_76, mul_256, last_recurrent_state_35], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg231_1, buf440, buf437, buf438, buf444, buf445, arg231_1, 262144, stream=raw_stream0)
        del arg231_1
        buf448 = buf444; del buf444  # reuse
        # Topologically Sorted Source Nodes: [add_166, inv_norm_22, query_58, query_59, q_t_11, unsqueeze_77, mul_257, sum_48], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf445, buf446, buf447, buf448, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg232_1, (128, ), (1, ), 'input')
        buf451 = reinterpret_tensor(buf450, (16, 128), (128, 1), 0); del buf450  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_55, core_attn_out_56, core_attn_out_57, hidden_states_107, pow_47, variance_11, add_169, rsqrt_70, hidden_states_108, to_159, hidden_states_109, z_33, z_34, z_35, to_160, silu_37, hidden_states_110, core_attn_out_58], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf451, buf448, arg232_1, 16, 128, stream=raw_stream0)
        del arg232_1
        assert_size_stride(arg233_1, (2048, 2048), (2048, 1), 'input')
        buf452 = reinterpret_tensor(buf431, (1, 2048), (2048, 1), 0); del buf431  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_55, core_attn_out_56, core_attn_out_57, hidden_states_107, pow_47, variance_11, add_169, rsqrt_70, hidden_states_108, to_159, hidden_states_109, z_33, z_34, z_35, to_160, silu_37, hidden_states_110, core_attn_out_58, core_attn_out_59, output_81], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf451, arg233_1, buf452, 128, 1, 1, stream=raw_stream0)
        del arg233_1
        assert_size_stride(arg234_1, (2048, ), (1, ), 'input')
        buf454 = reinterpret_tensor(buf451, (1, 1, 2048), (2048, 2048, 1), 0); del buf451  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_105, output_81, hidden_states_111, float_96, pow_48, mean_47, add_171, rsqrt_71, output_82, float_97, add_172, output_83, hidden_states_112], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf423, buf429, buf452, arg234_1, buf454, 1, 2048, stream=raw_stream0)
        del arg234_1
        assert_size_stride(arg235_1, (6144, 2048), (2048, 1), 'input')
        buf455 = buf432; del buf432  # reuse
        # Topologically Sorted Source Nodes: [linear_114], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf454, arg235_1, buf455, 384, 1, 1, stream=raw_stream0)
        del arg235_1
        assert_size_stride(arg236_1, (6144, 2048), (2048, 1), 'input')
        buf457 = reinterpret_tensor(buf426, (1, 1, 6144), (6144, 6144, 1), 0); del buf426  # reuse
        # Topologically Sorted Source Nodes: [linear_114, silu_38, linear_115, mul_263], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf454, arg236_1, buf455, buf457, 384, 1, 1, stream=raw_stream0)
        del arg236_1
        assert_size_stride(arg237_1, (2048, 6144), (6144, 1), 'input')
        buf458 = reinterpret_tensor(buf454, (1, 2048), (2048, 1), 0); del buf454  # reuse
        # Topologically Sorted Source Nodes: [linear_114, silu_38, linear_115, mul_263, down_proj_14], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf457, arg237_1, buf458, 128, 1, 1, stream=raw_stream0)
        del arg237_1
        assert_size_stride(arg238_1, (2048, ), (1, ), 'input')
        buf460 = reinterpret_tensor(buf393, (1, 1, 2048), (2048, 2048, 1), 0); del buf393  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_105, output_81, hidden_states_111, down_proj_14, hidden_states_113, float_98, pow_49, mean_48, add_174, rsqrt_72, output_84, float_99, add_175, output_85, hidden_states_114], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf423, buf429, buf452, buf458, arg238_1, buf460, 1, 2048, stream=raw_stream0)
        del arg238_1
        assert_size_stride(arg241_1, (512, 2048), (2048, 1), 'input')
        buf469 = reinterpret_tensor(buf342, (1, 512), (512, 1), 0); del buf342  # reuse
        # Topologically Sorted Source Nodes: [linear_118], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_26.run(buf460, arg241_1, buf469, 32, 1, 1, stream=raw_stream0)
        del arg241_1
        buf470 = buf347; del buf347  # reuse
        # Topologically Sorted Source Nodes: [linear_118, view_14, float_102, pow_51, mean_50], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_view_27.run(buf469, buf470, 2, 256, stream=raw_stream0)
        assert_size_stride(arg242_1, (256, ), (1, ), 'input')
        buf473 = buf350; del buf350  # reuse
        buf471 = reinterpret_tensor(buf473, (1, 2, 1, 32), (128, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_118, view_14, float_102, pow_51, mean_50, add_178, rsqrt_74, output_88, float_103, add_179, output_89, type_as_38, key_states_6, k_rot_3, x2_7, neg_19], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_mean_mul_neg_pow_rsqrt_slice_transpose_view_28.run(buf469, buf470, arg242_1, buf471, 64, stream=raw_stream0)
        buf472 = reinterpret_tensor(buf473, (1, 2, 1, 32), (128, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_118, view_14, float_102, pow_51, mean_50, add_178, rsqrt_74, output_88, float_103, add_179, output_89, type_as_38, key_states_6, k_rot_3, x2_7, neg_19, x1_7, cat_27], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_29.run(buf469, buf470, arg242_1, buf472, 64, stream=raw_stream0)
        buf476 = reinterpret_tensor(buf346, (1, 2, 1, 256), (512, 256, 256, 1), 0); del buf346  # reuse
        buf474 = reinterpret_tensor(buf476, (1, 2, 1, 64), (512, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_7, sin_7, linear_118, view_14, float_102, pow_51, mean_50, add_178, rsqrt_74, output_88, float_103, add_179, output_89, type_as_38, key_states_6, k_rot_3, mul_272, mul_273, k_embed_6], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_30.run(buf469, buf470, arg242_1, buf92, buf473, buf96, buf474, 128, stream=raw_stream0)
        del buf471
        del buf472
        buf475 = reinterpret_tensor(buf476, (1, 2, 1, 192), (512, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_7, sin_7, linear_118, view_14, float_102, pow_51, mean_50, add_178, rsqrt_74, output_88, float_103, add_179, output_89, type_as_38, key_states_6, k_rot_3, mul_272, mul_273, k_embed_6, k_pass_3, k_embed_7], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_31.run(buf469, buf470, arg242_1, buf475, 384, stream=raw_stream0)
        del arg242_1
        assert_size_stride_grouped((arg244_1, arg245_1), ((), (1, 2, 144, 256)), ((), (73728, 36864, 256, 1)), 'input')
        # Topologically Sorted Source Nodes: [arange_4, cache_position_3, index_copy__6], Original ATen: [aten.arange, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_32.run(arg244_1, buf476, arg245_1, 512, stream=raw_stream0)
        del buf474
        del buf475
        assert_size_stride(arg243_1, (512, 2048), (2048, 1), 'input')
        buf482 = reinterpret_tensor(buf476, (1, 512), (512, 1), 0); del buf476  # reuse
        # Topologically Sorted Source Nodes: [linear_119], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_26.run(buf460, arg243_1, buf482, 32, 1, 1, stream=raw_stream0)
        del arg243_1
        assert_size_stride(arg246_1, (1, 2, 144, 256), (73728, 36864, 256, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_4, cache_position_3, linear_119, view_15, value_states_6, index_copy__7], Original ATen: [aten.arange, aten.add, aten._unsafe_view, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_32.run(arg244_1, buf482, arg246_1, 512, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [add__3], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__33.run(arg244_1, arg244_1, 1, stream=raw_stream0)
        del arg244_1
        assert_size_stride(arg239_1, (4096, 2048), (2048, 1), 'input')
        buf461 = buf338; del buf338  # reuse
        # Topologically Sorted Source Nodes: [linear_117], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_34.run(buf460, arg239_1, buf461, 256, 1, 1, stream=raw_stream0)
        del arg239_1
        buf462 = reinterpret_tensor(buf358, (1, 1, 8, 1), (8, 8, 1, 8), 0); del buf358  # reuse
        # Topologically Sorted Source Nodes: [linear_117, view_12, chunk_3, float_100, pow_50, mean_49], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_35.run(buf461, buf462, 8, 256, stream=raw_stream0)
        assert_size_stride(arg240_1, (256, ), (1, ), 'input')
        buf465 = reinterpret_tensor(buf482, (1, 8, 1, 64), (512, 64, 64, 1), 0); del buf482  # reuse
        buf463 = reinterpret_tensor(buf465, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        buf464 = reinterpret_tensor(buf465, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_117, view_12, chunk_3, float_100, pow_50, mean_49, add_176, rsqrt_73, output_86, float_101, add_177, output_87, type_as_37, query_states_7, q_rot_3, x2_6, neg_18, x1_6, cat_26], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36.run(buf461, buf462, arg240_1, buf463, buf464, 256, stream=raw_stream0)
        buf468 = reinterpret_tensor(buf460, (1, 8, 1, 256), (2048, 256, 256, 1), 0); del buf460  # reuse
        buf466 = reinterpret_tensor(buf468, (1, 8, 1, 64), (2048, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_117, view_12, chunk_3, float_100, pow_50, mean_49, add_176, rsqrt_73, output_86, float_101, add_177, output_87, type_as_37, query_states_7, q_rot_3, cos_7, mul_270, sin_7, mul_271, q_embed_6], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37.run(buf461, buf462, arg240_1, buf92, buf465, buf96, buf466, 512, stream=raw_stream0)
        del buf463
        del buf464
        buf467 = reinterpret_tensor(buf468, (1, 8, 1, 192), (2048, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_117, view_12, chunk_3, float_100, pow_50, mean_49, add_176, rsqrt_73, output_86, float_101, add_177, output_87, type_as_37, query_states_7, q_rot_3, cos_7, mul_270, sin_7, mul_271, q_embed_6, q_pass_3, q_embed_7], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38.run(buf461, buf462, arg240_1, buf467, 1536, stream=raw_stream0)
        del arg240_1
        buf478 = buf355; del buf355  # reuse
        # Topologically Sorted Source Nodes: [matmul_6, key_states_7, transpose_114], Original ATen: [aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_39.run(buf468, arg245_1, buf478, 1152, 256, stream=raw_stream0)
        del arg245_1
        del buf466
        del buf467
        buf480 = buf357; del buf357  # reuse
        buf481 = reinterpret_tensor(buf462, (1, 8, 1, 1), (8, 1, 8, 8), 0); del buf462  # reuse
        # Topologically Sorted Source Nodes: [arange, getitem, getitem_1, getitem_2, allowed, mask_1, mask, getitem_3, matmul_6, attn_weights_12, attn_weights_13, softmax_3], Original ATen: [aten.arange, aten.unsqueeze, aten.select, aten.le, aten.masked_fill, aten.full, aten.view, aten.mul, aten.add, aten._to_copy, aten._softmax]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy_add_arange_full_le_masked_fill_mul_select_unsqueeze_view_40.run(buf478, arg0_1, buf480, buf481, 8, 144, stream=raw_stream0)
        buf484 = reinterpret_tensor(buf468, (8, 1, 256), (256, 256, 1), 0); del buf468  # reuse
        buf485 = reinterpret_tensor(buf484, (1, 1, 2048), (2048, 2048, 1), 0); del buf484  # reuse
        # Topologically Sorted Source Nodes: [linear_117, view_12, chunk_3, softmax_3, attn_weights_14, attn_output_15, value_states_7, transpose_115, reshape_99, gate_7, sigmoid_15, attn_output_18], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._softmax, aten._to_copy, aten.unsqueeze, aten.expand, aten.clone, aten.bmm, aten.transpose, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_41.run(buf485, buf480, buf481, arg246_1, buf461, 2048, 144, stream=raw_stream0)
        del arg246_1
        assert_size_stride(arg247_1, (2048, 2048), (2048, 1), 'input')
        buf486 = buf370; del buf370  # reuse
        # Topologically Sorted Source Nodes: [linear_117, view_12, chunk_3, attn_output_15, transpose_115, reshape_99, gate_7, sigmoid_15, attn_output_18, attn_output_19], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf485, arg247_1, buf486, 128, 1, 1, stream=raw_stream0)
        del arg247_1
        assert_size_stride(arg248_1, (2048, ), (1, ), 'input')
        buf487 = buf423; del buf423  # reuse
        buf489 = buf485; del buf485  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_105, output_81, hidden_states_111, down_proj_14, hidden_states_113, attn_output_19, hidden_states_117, float_104, pow_52, mean_51, add_185, rsqrt_75, output_90, float_105, add_186, output_91, hidden_states_118], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42.run(buf487, buf429, buf452, buf458, buf486, arg248_1, buf489, 1, 2048, stream=raw_stream0)
        del arg248_1
        assert_size_stride(arg249_1, (6144, 2048), (2048, 1), 'input')
        buf490 = reinterpret_tensor(buf457, (1, 6144), (6144, 1), 0); del buf457  # reuse
        # Topologically Sorted Source Nodes: [float_104, pow_52, mean_51, add_185, rsqrt_75, output_90, float_105, add_186, output_91, hidden_states_118, linear_121], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf489, arg249_1, buf490, 384, 1, 1, stream=raw_stream0)
        del arg249_1
        assert_size_stride(arg250_1, (6144, 2048), (2048, 1), 'input')
        buf492 = reinterpret_tensor(buf455, (1, 1, 6144), (6144, 6144, 1), 0); del buf455  # reuse
        # Topologically Sorted Source Nodes: [linear_121, silu_39, linear_122, mul_278], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf489, arg250_1, buf490, buf492, 384, 1, 1, stream=raw_stream0)
        del arg250_1
        assert_size_stride(arg251_1, (2048, 6144), (6144, 1), 'input')
        buf493 = reinterpret_tensor(buf489, (1, 2048), (2048, 1), 0); del buf489  # reuse
        # Topologically Sorted Source Nodes: [linear_121, silu_39, linear_122, mul_278, down_proj_15], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf492, arg251_1, buf493, 128, 1, 1, stream=raw_stream0)
        del arg251_1
        assert_size_stride(arg252_1, (2048, ), (1, ), 'input')
        buf495 = reinterpret_tensor(buf486, (1, 1, 2048), (2048, 2048, 1), 0); del buf486  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_119, float_106, pow_53, mean_52, add_188, rsqrt_76, output_92, float_107, add_189, output_93, hidden_states_120], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23.run(buf487, buf493, arg252_1, buf495, 1, 2048, stream=raw_stream0)
        del arg252_1
        assert_size_stride_grouped((arg256_1, arg259_1, arg260_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf504 = reinterpret_tensor(buf447, (1, 16), (16, 1), 0); del buf447  # reuse
        # Topologically Sorted Source Nodes: [exp_24, neg_20, a_12, float_109, add_190, softplus_12, g_12, transpose_122, getitem_202, exp_25], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf495, arg256_1, arg259_1, arg260_1, buf504, 1, 1, 1, stream=raw_stream0)
        del arg256_1
        del arg259_1
        del arg260_1
        assert_size_stride(arg255_1, (16, 2048), (2048, 1), 'input')
        buf507 = reinterpret_tensor(buf440, (1, 16, 1), (16, 1, 16), 0); del buf440  # reuse
        # Topologically Sorted Source Nodes: [b_12, beta_24, transpose_121, beta_25], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf495, arg255_1, buf507, 1, 1, 1, stream=raw_stream0)
        del arg255_1
        assert_size_stride(arg254_1, (2048, 2048), (2048, 1), 'input')
        buf514 = buf458; del buf458  # reuse
        # Topologically Sorted Source Nodes: [z_36], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf495, arg254_1, buf514, 128, 1, 1, stream=raw_stream0)
        del arg254_1
        assert_size_stride(arg253_1, (6144, 2048), (2048, 1), 'input')
        buf496 = reinterpret_tensor(buf492, (1, 6144), (6144, 1), 0); del buf492  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_119, float_106, pow_53, mean_52, add_188, rsqrt_76, output_92, float_107, add_189, output_93, hidden_states_120, mixed_qkv_48], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf495, arg253_1, buf496, 384, 1, 1, stream=raw_stream0)
        del arg253_1
        buf498 = reinterpret_tensor(buf499, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_48, mixed_qkv_49, cat_30], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf496, buf498, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_194, copy__24], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf499, arg257_1, 24576, stream=raw_stream0)
        del arg257_1
        del buf497
        del buf498
        assert_size_stride(arg258_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf500 = buf436; del buf436  # reuse
        # Topologically Sorted Source Nodes: [out_36, squeeze_12, unsqueeze_80, out_37, out_38], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf499, arg258_1, buf500, 6144, stream=raw_stream0)
        del arg258_1
        del buf499
        buf501 = reinterpret_tensor(buf448, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf448  # reuse
        buf502 = buf438; del buf438  # reuse
        # Topologically Sorted Source Nodes: [out_38, mixed_qkv_51, split_12, key_49, transpose_119, key_50, mul_284, sum_50], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf500, buf501, buf502, 16, 128, stream=raw_stream0)
        assert_size_stride(arg261_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf508 = reinterpret_tensor(buf446, (1, 16, 128), (2048, 128, 1), 0); del buf446  # reuse
        # Topologically Sorted Source Nodes: [out_38, mixed_qkv_51, split_12, add_192, inv_norm_25, key_51, k_t_12, value_37, transpose_120, value_38, v_t_12, exp_24, neg_20, a_12, float_109, add_190, softplus_12, g_12, transpose_122, getitem_202, exp_25, decay_t_12, last_recurrent_state_37, unsqueeze_82, mul_287, kv_mem_12, sub_12, b_12, beta_24, transpose_121, beta_25, getitem_204, beta_t_12, delta_12], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg261_1, buf504, buf501, buf502, buf500, buf507, buf508, 2048, 128, stream=raw_stream0)
        buf510 = buf437; del buf437  # reuse
        buf511 = reinterpret_tensor(buf507, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf507  # reuse
        # Topologically Sorted Source Nodes: [out_38, mixed_qkv_51, split_12, query_61, transpose_118, query_62, mul_282, sum_49], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf500, buf510, buf511, 16, 128, stream=raw_stream0)
        buf509 = buf445; del buf445  # reuse
        # Topologically Sorted Source Nodes: [out_38, mixed_qkv_51, split_12, add_192, inv_norm_25, key_51, k_t_12, unsqueeze_83, value_37, transpose_120, value_38, v_t_12, exp_24, neg_20, a_12, float_109, add_190, softplus_12, g_12, transpose_122, getitem_202, exp_25, decay_t_12, last_recurrent_state_37, sub_12, b_12, beta_24, transpose_121, beta_25, getitem_204, beta_t_12, delta_12, unsqueeze_84, mul_289, last_recurrent_state_38], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg261_1, buf504, buf501, buf502, buf508, buf509, arg261_1, 262144, stream=raw_stream0)
        del arg261_1
        buf512 = buf508; del buf508  # reuse
        # Topologically Sorted Source Nodes: [add_191, inv_norm_24, query_63, query_64, q_t_12, unsqueeze_85, mul_290, sum_52], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf509, buf510, buf511, buf512, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg262_1, (128, ), (1, ), 'input')
        buf515 = reinterpret_tensor(buf514, (16, 128), (128, 1), 0); del buf514  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_60, core_attn_out_61, core_attn_out_62, hidden_states_121, pow_54, variance_12, add_194, rsqrt_79, hidden_states_122, to_173, hidden_states_123, z_36, z_37, z_38, to_174, silu_41, hidden_states_124, core_attn_out_63], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf515, buf512, arg262_1, 16, 128, stream=raw_stream0)
        del arg262_1
        assert_size_stride(arg263_1, (2048, 2048), (2048, 1), 'input')
        buf516 = reinterpret_tensor(buf495, (1, 2048), (2048, 1), 0); del buf495  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_60, core_attn_out_61, core_attn_out_62, hidden_states_121, pow_54, variance_12, add_194, rsqrt_79, hidden_states_122, to_173, hidden_states_123, z_36, z_37, z_38, to_174, silu_41, hidden_states_124, core_attn_out_63, core_attn_out_64, output_94], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf515, arg263_1, buf516, 128, 1, 1, stream=raw_stream0)
        del arg263_1
        assert_size_stride(arg264_1, (2048, ), (1, ), 'input')
        buf518 = reinterpret_tensor(buf515, (1, 1, 2048), (2048, 2048, 1), 0); del buf515  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_119, output_94, hidden_states_125, float_110, pow_55, mean_54, add_196, rsqrt_80, output_95, float_111, add_197, output_96, hidden_states_126], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf487, buf493, buf516, arg264_1, buf518, 1, 2048, stream=raw_stream0)
        del arg264_1
        assert_size_stride(arg265_1, (6144, 2048), (2048, 1), 'input')
        buf519 = buf496; del buf496  # reuse
        # Topologically Sorted Source Nodes: [linear_129], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf518, arg265_1, buf519, 384, 1, 1, stream=raw_stream0)
        del arg265_1
        assert_size_stride(arg266_1, (6144, 2048), (2048, 1), 'input')
        buf521 = reinterpret_tensor(buf490, (1, 1, 6144), (6144, 6144, 1), 0); del buf490  # reuse
        # Topologically Sorted Source Nodes: [linear_129, silu_42, linear_130, mul_296], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf518, arg266_1, buf519, buf521, 384, 1, 1, stream=raw_stream0)
        del arg266_1
        assert_size_stride(arg267_1, (2048, 6144), (6144, 1), 'input')
        buf522 = reinterpret_tensor(buf518, (1, 2048), (2048, 1), 0); del buf518  # reuse
        # Topologically Sorted Source Nodes: [linear_129, silu_42, linear_130, mul_296, down_proj_16], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf521, arg267_1, buf522, 128, 1, 1, stream=raw_stream0)
        del arg267_1
        assert_size_stride(arg268_1, (2048, ), (1, ), 'input')
        buf524 = reinterpret_tensor(buf452, (1, 1, 2048), (2048, 2048, 1), 0); del buf452  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_119, output_94, hidden_states_125, down_proj_16, hidden_states_127, float_112, pow_56, mean_55, add_199, rsqrt_81, output_97, float_113, add_200, output_98, hidden_states_128], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf487, buf493, buf516, buf522, arg268_1, buf524, 1, 2048, stream=raw_stream0)
        del arg268_1
        assert_size_stride_grouped((arg272_1, arg275_1, arg276_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf533 = reinterpret_tensor(buf511, (1, 16), (16, 1), 0); del buf511  # reuse
        # Topologically Sorted Source Nodes: [exp_26, neg_21, a_13, float_115, add_201, softplus_13, g_13, transpose_130, getitem_213, exp_27], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf524, arg272_1, arg275_1, arg276_1, buf533, 1, 1, 1, stream=raw_stream0)
        del arg272_1
        del arg275_1
        del arg276_1
        assert_size_stride(arg271_1, (16, 2048), (2048, 1), 'input')
        buf536 = reinterpret_tensor(buf504, (1, 16, 1), (16, 1, 16), 0); del buf504  # reuse
        # Topologically Sorted Source Nodes: [b_13, beta_26, transpose_129, beta_27], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf524, arg271_1, buf536, 1, 1, 1, stream=raw_stream0)
        del arg271_1
        assert_size_stride(arg270_1, (2048, 2048), (2048, 1), 'input')
        buf543 = buf429; del buf429  # reuse
        # Topologically Sorted Source Nodes: [z_39], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf524, arg270_1, buf543, 128, 1, 1, stream=raw_stream0)
        del arg270_1
        assert_size_stride(arg269_1, (6144, 2048), (2048, 1), 'input')
        buf525 = reinterpret_tensor(buf521, (1, 6144), (6144, 1), 0); del buf521  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_52], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf524, arg269_1, buf525, 384, 1, 1, stream=raw_stream0)
        del arg269_1
        buf527 = reinterpret_tensor(buf528, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_52, mixed_qkv_53, cat_31], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf525, buf527, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_205, copy__26], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf528, arg273_1, 24576, stream=raw_stream0)
        del arg273_1
        del buf526
        del buf527
        assert_size_stride(arg274_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf529 = buf500; del buf500  # reuse
        # Topologically Sorted Source Nodes: [out_39, squeeze_13, unsqueeze_86, out_40, out_41], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf528, arg274_1, buf529, 6144, stream=raw_stream0)
        del arg274_1
        del buf528
        buf530 = reinterpret_tensor(buf512, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf512  # reuse
        buf531 = buf502; del buf502  # reuse
        # Topologically Sorted Source Nodes: [out_41, mixed_qkv_55, split_13, key_53, transpose_127, key_54, mul_302, sum_54], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf529, buf530, buf531, 16, 128, stream=raw_stream0)
        assert_size_stride(arg277_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf537 = reinterpret_tensor(buf510, (1, 16, 128), (2048, 128, 1), 0); del buf510  # reuse
        # Topologically Sorted Source Nodes: [out_41, mixed_qkv_55, split_13, add_203, inv_norm_27, key_55, k_t_13, value_40, transpose_128, value_41, v_t_13, exp_26, neg_21, a_13, float_115, add_201, softplus_13, g_13, transpose_130, getitem_213, exp_27, decay_t_13, last_recurrent_state_40, unsqueeze_88, mul_305, kv_mem_13, sub_13, b_13, beta_26, transpose_129, beta_27, getitem_215, beta_t_13, delta_13], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg277_1, buf533, buf530, buf531, buf529, buf536, buf537, 2048, 128, stream=raw_stream0)
        buf539 = buf501; del buf501  # reuse
        buf540 = reinterpret_tensor(buf536, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf536  # reuse
        # Topologically Sorted Source Nodes: [out_41, mixed_qkv_55, split_13, query_66, transpose_126, query_67, mul_300, sum_53], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf529, buf539, buf540, 16, 128, stream=raw_stream0)
        buf538 = buf509; del buf509  # reuse
        # Topologically Sorted Source Nodes: [out_41, mixed_qkv_55, split_13, add_203, inv_norm_27, key_55, k_t_13, unsqueeze_89, value_40, transpose_128, value_41, v_t_13, exp_26, neg_21, a_13, float_115, add_201, softplus_13, g_13, transpose_130, getitem_213, exp_27, decay_t_13, last_recurrent_state_40, sub_13, b_13, beta_26, transpose_129, beta_27, getitem_215, beta_t_13, delta_13, unsqueeze_90, mul_307, last_recurrent_state_41], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg277_1, buf533, buf530, buf531, buf537, buf538, arg277_1, 262144, stream=raw_stream0)
        del arg277_1
        buf541 = buf537; del buf537  # reuse
        # Topologically Sorted Source Nodes: [add_202, inv_norm_26, query_68, query_69, q_t_13, unsqueeze_91, mul_308, sum_56], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf538, buf539, buf540, buf541, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg278_1, (128, ), (1, ), 'input')
        buf544 = reinterpret_tensor(buf543, (16, 128), (128, 1), 0); del buf543  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_65, core_attn_out_66, core_attn_out_67, hidden_states_129, pow_57, variance_13, add_205, rsqrt_84, hidden_states_130, to_186, hidden_states_131, z_39, z_40, z_41, to_187, silu_44, hidden_states_132, core_attn_out_68], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf544, buf541, arg278_1, 16, 128, stream=raw_stream0)
        del arg278_1
        assert_size_stride(arg279_1, (2048, 2048), (2048, 1), 'input')
        buf545 = reinterpret_tensor(buf524, (1, 2048), (2048, 1), 0); del buf524  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_65, core_attn_out_66, core_attn_out_67, hidden_states_129, pow_57, variance_13, add_205, rsqrt_84, hidden_states_130, to_186, hidden_states_131, z_39, z_40, z_41, to_187, silu_44, hidden_states_132, core_attn_out_68, core_attn_out_69, output_99], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf544, arg279_1, buf545, 128, 1, 1, stream=raw_stream0)
        del arg279_1
        assert_size_stride(arg280_1, (2048, ), (1, ), 'input')
        buf546 = buf487; del buf487  # reuse
        buf548 = reinterpret_tensor(buf544, (1, 1, 2048), (2048, 2048, 1), 0); del buf544  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_119, output_94, hidden_states_125, down_proj_16, hidden_states_127, output_99, hidden_states_133, float_116, pow_58, mean_57, add_207, rsqrt_85, output_100, float_117, add_208, output_101, hidden_states_134], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42.run(buf546, buf493, buf516, buf522, buf545, arg280_1, buf548, 1, 2048, stream=raw_stream0)
        del arg280_1
        assert_size_stride(arg281_1, (6144, 2048), (2048, 1), 'input')
        buf549 = buf525; del buf525  # reuse
        # Topologically Sorted Source Nodes: [float_116, pow_58, mean_57, add_207, rsqrt_85, output_100, float_117, add_208, output_101, hidden_states_134, linear_137], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf548, arg281_1, buf549, 384, 1, 1, stream=raw_stream0)
        del arg281_1
        assert_size_stride(arg282_1, (6144, 2048), (2048, 1), 'input')
        buf551 = reinterpret_tensor(buf519, (1, 1, 6144), (6144, 6144, 1), 0); del buf519  # reuse
        # Topologically Sorted Source Nodes: [linear_137, silu_45, linear_138, mul_314], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf548, arg282_1, buf549, buf551, 384, 1, 1, stream=raw_stream0)
        del arg282_1
        assert_size_stride(arg283_1, (2048, 6144), (6144, 1), 'input')
        buf552 = reinterpret_tensor(buf548, (1, 2048), (2048, 1), 0); del buf548  # reuse
        # Topologically Sorted Source Nodes: [linear_137, silu_45, linear_138, mul_314, down_proj_17], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf551, arg283_1, buf552, 128, 1, 1, stream=raw_stream0)
        del arg283_1
        assert_size_stride(arg284_1, (2048, ), (1, ), 'input')
        buf554 = reinterpret_tensor(buf545, (1, 1, 2048), (2048, 2048, 1), 0); del buf545  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_135, float_118, pow_59, mean_58, add_210, rsqrt_86, output_102, float_119, add_211, output_103, hidden_states_136], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23.run(buf546, buf552, arg284_1, buf554, 1, 2048, stream=raw_stream0)
        del arg284_1
        assert_size_stride_grouped((arg288_1, arg291_1, arg292_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf563 = reinterpret_tensor(buf540, (1, 16), (16, 1), 0); del buf540  # reuse
        # Topologically Sorted Source Nodes: [exp_28, neg_22, a_14, float_121, add_212, softplus_14, g_14, transpose_138, getitem_224, exp_29], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf554, arg288_1, arg291_1, arg292_1, buf563, 1, 1, 1, stream=raw_stream0)
        del arg288_1
        del arg291_1
        del arg292_1
        assert_size_stride(arg287_1, (16, 2048), (2048, 1), 'input')
        buf566 = reinterpret_tensor(buf533, (1, 16, 1), (16, 1, 16), 0); del buf533  # reuse
        # Topologically Sorted Source Nodes: [b_14, beta_28, transpose_137, beta_29], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf554, arg287_1, buf566, 1, 1, 1, stream=raw_stream0)
        del arg287_1
        assert_size_stride(arg286_1, (2048, 2048), (2048, 1), 'input')
        buf573 = buf522; del buf522  # reuse
        # Topologically Sorted Source Nodes: [z_42], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf554, arg286_1, buf573, 128, 1, 1, stream=raw_stream0)
        del arg286_1
        assert_size_stride(arg285_1, (6144, 2048), (2048, 1), 'input')
        buf555 = reinterpret_tensor(buf551, (1, 6144), (6144, 1), 0); del buf551  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_135, float_118, pow_59, mean_58, add_210, rsqrt_86, output_102, float_119, add_211, output_103, hidden_states_136, mixed_qkv_56], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf554, arg285_1, buf555, 384, 1, 1, stream=raw_stream0)
        del arg285_1
        buf557 = reinterpret_tensor(buf558, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_56, mixed_qkv_57, cat_32], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf555, buf557, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_216, copy__28], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf558, arg289_1, 24576, stream=raw_stream0)
        del arg289_1
        del buf556
        del buf557
        assert_size_stride(arg290_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf559 = buf529; del buf529  # reuse
        # Topologically Sorted Source Nodes: [out_42, squeeze_14, unsqueeze_92, out_43, out_44], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf558, arg290_1, buf559, 6144, stream=raw_stream0)
        del arg290_1
        del buf558
        buf560 = reinterpret_tensor(buf541, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf541  # reuse
        buf561 = buf531; del buf531  # reuse
        # Topologically Sorted Source Nodes: [out_44, mixed_qkv_59, split_14, key_57, transpose_135, key_58, mul_320, sum_58], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf559, buf560, buf561, 16, 128, stream=raw_stream0)
        assert_size_stride(arg293_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf567 = reinterpret_tensor(buf539, (1, 16, 128), (2048, 128, 1), 0); del buf539  # reuse
        # Topologically Sorted Source Nodes: [out_44, mixed_qkv_59, split_14, add_214, inv_norm_29, key_59, k_t_14, value_43, transpose_136, value_44, v_t_14, exp_28, neg_22, a_14, float_121, add_212, softplus_14, g_14, transpose_138, getitem_224, exp_29, decay_t_14, last_recurrent_state_43, unsqueeze_94, mul_323, kv_mem_14, sub_14, b_14, beta_28, transpose_137, beta_29, getitem_226, beta_t_14, delta_14], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg293_1, buf563, buf560, buf561, buf559, buf566, buf567, 2048, 128, stream=raw_stream0)
        buf569 = buf530; del buf530  # reuse
        buf570 = reinterpret_tensor(buf566, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf566  # reuse
        # Topologically Sorted Source Nodes: [out_44, mixed_qkv_59, split_14, query_71, transpose_134, query_72, mul_318, sum_57], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf559, buf569, buf570, 16, 128, stream=raw_stream0)
        buf568 = buf538; del buf538  # reuse
        # Topologically Sorted Source Nodes: [out_44, mixed_qkv_59, split_14, add_214, inv_norm_29, key_59, k_t_14, unsqueeze_95, value_43, transpose_136, value_44, v_t_14, exp_28, neg_22, a_14, float_121, add_212, softplus_14, g_14, transpose_138, getitem_224, exp_29, decay_t_14, last_recurrent_state_43, sub_14, b_14, beta_28, transpose_137, beta_29, getitem_226, beta_t_14, delta_14, unsqueeze_96, mul_325, last_recurrent_state_44], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg293_1, buf563, buf560, buf561, buf567, buf568, arg293_1, 262144, stream=raw_stream0)
        del arg293_1
        buf571 = buf567; del buf567  # reuse
        # Topologically Sorted Source Nodes: [add_213, inv_norm_28, query_73, query_74, q_t_14, unsqueeze_97, mul_326, sum_60], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf568, buf569, buf570, buf571, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg294_1, (128, ), (1, ), 'input')
        buf574 = reinterpret_tensor(buf573, (16, 128), (128, 1), 0); del buf573  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_70, core_attn_out_71, core_attn_out_72, hidden_states_137, pow_60, variance_14, add_216, rsqrt_89, hidden_states_138, to_199, hidden_states_139, z_42, z_43, z_44, to_200, silu_47, hidden_states_140, core_attn_out_73], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf574, buf571, arg294_1, 16, 128, stream=raw_stream0)
        del arg294_1
        assert_size_stride(arg295_1, (2048, 2048), (2048, 1), 'input')
        buf575 = reinterpret_tensor(buf554, (1, 2048), (2048, 1), 0); del buf554  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_70, core_attn_out_71, core_attn_out_72, hidden_states_137, pow_60, variance_14, add_216, rsqrt_89, hidden_states_138, to_199, hidden_states_139, z_42, z_43, z_44, to_200, silu_47, hidden_states_140, core_attn_out_73, core_attn_out_74, output_104], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf574, arg295_1, buf575, 128, 1, 1, stream=raw_stream0)
        del arg295_1
        assert_size_stride(arg296_1, (2048, ), (1, ), 'input')
        buf577 = reinterpret_tensor(buf574, (1, 1, 2048), (2048, 2048, 1), 0); del buf574  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_135, output_104, hidden_states_141, float_122, pow_61, mean_60, add_218, rsqrt_90, output_105, float_123, add_219, output_106, hidden_states_142], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf546, buf552, buf575, arg296_1, buf577, 1, 2048, stream=raw_stream0)
        del arg296_1
        assert_size_stride(arg297_1, (6144, 2048), (2048, 1), 'input')
        buf578 = buf555; del buf555  # reuse
        # Topologically Sorted Source Nodes: [linear_145], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf577, arg297_1, buf578, 384, 1, 1, stream=raw_stream0)
        del arg297_1
        assert_size_stride(arg298_1, (6144, 2048), (2048, 1), 'input')
        buf580 = reinterpret_tensor(buf549, (1, 1, 6144), (6144, 6144, 1), 0); del buf549  # reuse
        # Topologically Sorted Source Nodes: [linear_145, silu_48, linear_146, mul_332], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf577, arg298_1, buf578, buf580, 384, 1, 1, stream=raw_stream0)
        del arg298_1
        assert_size_stride(arg299_1, (2048, 6144), (6144, 1), 'input')
        buf581 = reinterpret_tensor(buf577, (1, 2048), (2048, 1), 0); del buf577  # reuse
        # Topologically Sorted Source Nodes: [linear_145, silu_48, linear_146, mul_332, down_proj_18], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf580, arg299_1, buf581, 128, 1, 1, stream=raw_stream0)
        del arg299_1
        assert_size_stride(arg300_1, (2048, ), (1, ), 'input')
        buf583 = reinterpret_tensor(buf516, (1, 1, 2048), (2048, 2048, 1), 0); del buf516  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_135, output_104, hidden_states_141, down_proj_18, hidden_states_143, float_124, pow_62, mean_61, add_221, rsqrt_91, output_107, float_125, add_222, output_108, hidden_states_144], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf546, buf552, buf575, buf581, arg300_1, buf583, 1, 2048, stream=raw_stream0)
        del arg300_1
        assert_size_stride(arg303_1, (512, 2048), (2048, 1), 'input')
        buf592 = reinterpret_tensor(buf465, (1, 512), (512, 1), 0); del buf465  # reuse
        # Topologically Sorted Source Nodes: [linear_149], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_26.run(buf583, arg303_1, buf592, 32, 1, 1, stream=raw_stream0)
        del arg303_1
        buf593 = buf470; del buf470  # reuse
        # Topologically Sorted Source Nodes: [linear_149, view_18, float_128, pow_64, mean_63], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_view_27.run(buf592, buf593, 2, 256, stream=raw_stream0)
        assert_size_stride(arg304_1, (256, ), (1, ), 'input')
        buf596 = buf473; del buf473  # reuse
        buf594 = reinterpret_tensor(buf596, (1, 2, 1, 32), (128, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_149, view_18, float_128, pow_64, mean_63, add_225, rsqrt_93, output_111, float_129, add_226, output_112, type_as_48, key_states_8, k_rot_4, x2_9, neg_24], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_mean_mul_neg_pow_rsqrt_slice_transpose_view_28.run(buf592, buf593, arg304_1, buf594, 64, stream=raw_stream0)
        buf595 = reinterpret_tensor(buf596, (1, 2, 1, 32), (128, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_149, view_18, float_128, pow_64, mean_63, add_225, rsqrt_93, output_111, float_129, add_226, output_112, type_as_48, key_states_8, k_rot_4, x2_9, neg_24, x1_9, cat_34], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_29.run(buf592, buf593, arg304_1, buf595, 64, stream=raw_stream0)
        buf599 = reinterpret_tensor(buf469, (1, 2, 1, 256), (512, 256, 256, 1), 0); del buf469  # reuse
        buf597 = reinterpret_tensor(buf599, (1, 2, 1, 64), (512, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_8, sin_8, linear_149, view_18, float_128, pow_64, mean_63, add_225, rsqrt_93, output_111, float_129, add_226, output_112, type_as_48, key_states_8, k_rot_4, mul_341, mul_342, k_embed_8], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_30.run(buf592, buf593, arg304_1, buf92, buf596, buf96, buf597, 128, stream=raw_stream0)
        del buf594
        del buf595
        buf598 = reinterpret_tensor(buf599, (1, 2, 1, 192), (512, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_8, sin_8, linear_149, view_18, float_128, pow_64, mean_63, add_225, rsqrt_93, output_111, float_129, add_226, output_112, type_as_48, key_states_8, k_rot_4, mul_341, mul_342, k_embed_8, k_pass_4, k_embed_9], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_31.run(buf592, buf593, arg304_1, buf598, 384, stream=raw_stream0)
        del arg304_1
        assert_size_stride_grouped((arg306_1, arg307_1), ((), (1, 2, 144, 256)), ((), (73728, 36864, 256, 1)), 'input')
        # Topologically Sorted Source Nodes: [arange_5, cache_position_4, index_copy__8], Original ATen: [aten.arange, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_32.run(arg306_1, buf599, arg307_1, 512, stream=raw_stream0)
        del buf597
        del buf598
        assert_size_stride(arg305_1, (512, 2048), (2048, 1), 'input')
        buf605 = reinterpret_tensor(buf599, (1, 512), (512, 1), 0); del buf599  # reuse
        # Topologically Sorted Source Nodes: [linear_150], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_26.run(buf583, arg305_1, buf605, 32, 1, 1, stream=raw_stream0)
        del arg305_1
        assert_size_stride(arg308_1, (1, 2, 144, 256), (73728, 36864, 256, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_5, cache_position_4, linear_150, view_19, value_states_8, index_copy__9], Original ATen: [aten.arange, aten.add, aten._unsafe_view, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_32.run(arg306_1, buf605, arg308_1, 512, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [add__4], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__33.run(arg306_1, arg306_1, 1, stream=raw_stream0)
        del arg306_1
        assert_size_stride(arg301_1, (4096, 2048), (2048, 1), 'input')
        buf584 = buf461; del buf461  # reuse
        # Topologically Sorted Source Nodes: [linear_148], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_34.run(buf583, arg301_1, buf584, 256, 1, 1, stream=raw_stream0)
        del arg301_1
        buf585 = reinterpret_tensor(buf481, (1, 1, 8, 1), (8, 8, 1, 8), 0); del buf481  # reuse
        # Topologically Sorted Source Nodes: [linear_148, view_16, chunk_4, float_126, pow_63, mean_62], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_35.run(buf584, buf585, 8, 256, stream=raw_stream0)
        assert_size_stride(arg302_1, (256, ), (1, ), 'input')
        buf588 = reinterpret_tensor(buf605, (1, 8, 1, 64), (512, 64, 64, 1), 0); del buf605  # reuse
        buf586 = reinterpret_tensor(buf588, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        buf587 = reinterpret_tensor(buf588, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_148, view_16, chunk_4, float_126, pow_63, mean_62, add_223, rsqrt_92, output_109, float_127, add_224, output_110, type_as_47, query_states_9, q_rot_4, x2_8, neg_23, x1_8, cat_33], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36.run(buf584, buf585, arg302_1, buf586, buf587, 256, stream=raw_stream0)
        buf591 = reinterpret_tensor(buf583, (1, 8, 1, 256), (2048, 256, 256, 1), 0); del buf583  # reuse
        buf589 = reinterpret_tensor(buf591, (1, 8, 1, 64), (2048, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_148, view_16, chunk_4, float_126, pow_63, mean_62, add_223, rsqrt_92, output_109, float_127, add_224, output_110, type_as_47, query_states_9, q_rot_4, cos_8, mul_339, sin_8, mul_340, q_embed_8], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37.run(buf584, buf585, arg302_1, buf92, buf588, buf96, buf589, 512, stream=raw_stream0)
        del buf586
        del buf587
        buf590 = reinterpret_tensor(buf591, (1, 8, 1, 192), (2048, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_148, view_16, chunk_4, float_126, pow_63, mean_62, add_223, rsqrt_92, output_109, float_127, add_224, output_110, type_as_47, query_states_9, q_rot_4, cos_8, mul_339, sin_8, mul_340, q_embed_8, q_pass_4, q_embed_9], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38.run(buf584, buf585, arg302_1, buf590, 1536, stream=raw_stream0)
        del arg302_1
        buf601 = buf478; del buf478  # reuse
        # Topologically Sorted Source Nodes: [matmul_8, key_states_9, transpose_143], Original ATen: [aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_39.run(buf591, arg307_1, buf601, 1152, 256, stream=raw_stream0)
        del arg307_1
        del buf589
        del buf590
        buf603 = buf480; del buf480  # reuse
        buf604 = reinterpret_tensor(buf585, (1, 8, 1, 1), (8, 1, 8, 8), 0); del buf585  # reuse
        # Topologically Sorted Source Nodes: [arange, getitem, getitem_1, getitem_2, allowed, mask_1, mask, getitem_3, matmul_8, attn_weights_16, attn_weights_17, softmax_4], Original ATen: [aten.arange, aten.unsqueeze, aten.select, aten.le, aten.masked_fill, aten.full, aten.view, aten.mul, aten.add, aten._to_copy, aten._softmax]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy_add_arange_full_le_masked_fill_mul_select_unsqueeze_view_40.run(buf601, arg0_1, buf603, buf604, 8, 144, stream=raw_stream0)
        buf607 = reinterpret_tensor(buf591, (8, 1, 256), (256, 256, 1), 0); del buf591  # reuse
        buf608 = reinterpret_tensor(buf607, (1, 1, 2048), (2048, 2048, 1), 0); del buf607  # reuse
        # Topologically Sorted Source Nodes: [linear_148, view_16, chunk_4, softmax_4, attn_weights_18, attn_output_20, value_states_9, transpose_144, reshape_124, gate_9, sigmoid_19, attn_output_23], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._softmax, aten._to_copy, aten.unsqueeze, aten.expand, aten.clone, aten.bmm, aten.transpose, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_41.run(buf608, buf603, buf604, arg308_1, buf584, 2048, 144, stream=raw_stream0)
        del arg308_1
        assert_size_stride(arg309_1, (2048, 2048), (2048, 1), 'input')
        buf609 = buf493; del buf493  # reuse
        # Topologically Sorted Source Nodes: [linear_148, view_16, chunk_4, attn_output_20, transpose_144, reshape_124, gate_9, sigmoid_19, attn_output_23, attn_output_24], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf608, arg309_1, buf609, 128, 1, 1, stream=raw_stream0)
        del arg309_1
        assert_size_stride(arg310_1, (2048, ), (1, ), 'input')
        buf610 = buf546; del buf546  # reuse
        buf612 = buf608; del buf608  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_135, output_104, hidden_states_141, down_proj_18, hidden_states_143, attn_output_24, hidden_states_147, float_130, pow_65, mean_64, add_232, rsqrt_94, output_113, float_131, add_233, output_114, hidden_states_148], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42.run(buf610, buf552, buf575, buf581, buf609, arg310_1, buf612, 1, 2048, stream=raw_stream0)
        del arg310_1
        assert_size_stride(arg311_1, (6144, 2048), (2048, 1), 'input')
        buf613 = reinterpret_tensor(buf580, (1, 6144), (6144, 1), 0); del buf580  # reuse
        # Topologically Sorted Source Nodes: [float_130, pow_65, mean_64, add_232, rsqrt_94, output_113, float_131, add_233, output_114, hidden_states_148, linear_152], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf612, arg311_1, buf613, 384, 1, 1, stream=raw_stream0)
        del arg311_1
        assert_size_stride(arg312_1, (6144, 2048), (2048, 1), 'input')
        buf615 = reinterpret_tensor(buf578, (1, 1, 6144), (6144, 6144, 1), 0); del buf578  # reuse
        # Topologically Sorted Source Nodes: [linear_152, silu_49, linear_153, mul_347], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf612, arg312_1, buf613, buf615, 384, 1, 1, stream=raw_stream0)
        del arg312_1
        assert_size_stride(arg313_1, (2048, 6144), (6144, 1), 'input')
        buf616 = reinterpret_tensor(buf612, (1, 2048), (2048, 1), 0); del buf612  # reuse
        # Topologically Sorted Source Nodes: [linear_152, silu_49, linear_153, mul_347, down_proj_19], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf615, arg313_1, buf616, 128, 1, 1, stream=raw_stream0)
        del arg313_1
        assert_size_stride(arg314_1, (2048, ), (1, ), 'input')
        buf618 = reinterpret_tensor(buf609, (1, 1, 2048), (2048, 2048, 1), 0); del buf609  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_149, float_132, pow_66, mean_65, add_235, rsqrt_95, output_115, float_133, add_236, output_116, hidden_states_150], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23.run(buf610, buf616, arg314_1, buf618, 1, 2048, stream=raw_stream0)
        del arg314_1
        assert_size_stride_grouped((arg318_1, arg321_1, arg322_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf627 = reinterpret_tensor(buf570, (1, 16), (16, 1), 0); del buf570  # reuse
        # Topologically Sorted Source Nodes: [exp_30, neg_25, a_15, float_135, add_237, softplus_15, g_15, transpose_151, getitem_247, exp_31], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf618, arg318_1, arg321_1, arg322_1, buf627, 1, 1, 1, stream=raw_stream0)
        del arg318_1
        del arg321_1
        del arg322_1
        assert_size_stride(arg317_1, (16, 2048), (2048, 1), 'input')
        buf630 = reinterpret_tensor(buf563, (1, 16, 1), (16, 1, 16), 0); del buf563  # reuse
        # Topologically Sorted Source Nodes: [b_15, beta_30, transpose_150, beta_31], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf618, arg317_1, buf630, 1, 1, 1, stream=raw_stream0)
        del arg317_1
        assert_size_stride(arg316_1, (2048, 2048), (2048, 1), 'input')
        buf637 = buf581; del buf581  # reuse
        # Topologically Sorted Source Nodes: [z_45], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf618, arg316_1, buf637, 128, 1, 1, stream=raw_stream0)
        del arg316_1
        assert_size_stride(arg315_1, (6144, 2048), (2048, 1), 'input')
        buf619 = reinterpret_tensor(buf615, (1, 6144), (6144, 1), 0); del buf615  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_149, float_132, pow_66, mean_65, add_235, rsqrt_95, output_115, float_133, add_236, output_116, hidden_states_150, mixed_qkv_60], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf618, arg315_1, buf619, 384, 1, 1, stream=raw_stream0)
        del arg315_1
        buf621 = reinterpret_tensor(buf622, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_60, mixed_qkv_61, cat_37], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf619, buf621, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_239, copy__30], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf622, arg319_1, 24576, stream=raw_stream0)
        del arg319_1
        del buf620
        del buf621
        assert_size_stride(arg320_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf623 = buf559; del buf559  # reuse
        # Topologically Sorted Source Nodes: [out_45, squeeze_15, unsqueeze_100, out_46, out_47], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf622, arg320_1, buf623, 6144, stream=raw_stream0)
        del arg320_1
        del buf622
        buf624 = reinterpret_tensor(buf571, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf571  # reuse
        buf625 = buf561; del buf561  # reuse
        # Topologically Sorted Source Nodes: [out_47, mixed_qkv_63, split_15, key_61, transpose_148, key_62, mul_353, sum_62], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf623, buf624, buf625, 16, 128, stream=raw_stream0)
        assert_size_stride(arg323_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf631 = reinterpret_tensor(buf569, (1, 16, 128), (2048, 128, 1), 0); del buf569  # reuse
        # Topologically Sorted Source Nodes: [out_47, mixed_qkv_63, split_15, add_239, inv_norm_31, key_63, k_t_15, value_46, transpose_149, value_47, v_t_15, exp_30, neg_25, a_15, float_135, add_237, softplus_15, g_15, transpose_151, getitem_247, exp_31, decay_t_15, last_recurrent_state_46, unsqueeze_102, mul_356, kv_mem_15, sub_15, b_15, beta_30, transpose_150, beta_31, getitem_249, beta_t_15, delta_15], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg323_1, buf627, buf624, buf625, buf623, buf630, buf631, 2048, 128, stream=raw_stream0)
        buf633 = buf560; del buf560  # reuse
        buf634 = reinterpret_tensor(buf630, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf630  # reuse
        # Topologically Sorted Source Nodes: [out_47, mixed_qkv_63, split_15, query_76, transpose_147, query_77, mul_351, sum_61], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf623, buf633, buf634, 16, 128, stream=raw_stream0)
        buf632 = buf568; del buf568  # reuse
        # Topologically Sorted Source Nodes: [out_47, mixed_qkv_63, split_15, add_239, inv_norm_31, key_63, k_t_15, unsqueeze_103, value_46, transpose_149, value_47, v_t_15, exp_30, neg_25, a_15, float_135, add_237, softplus_15, g_15, transpose_151, getitem_247, exp_31, decay_t_15, last_recurrent_state_46, sub_15, b_15, beta_30, transpose_150, beta_31, getitem_249, beta_t_15, delta_15, unsqueeze_104, mul_358, last_recurrent_state_47], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg323_1, buf627, buf624, buf625, buf631, buf632, arg323_1, 262144, stream=raw_stream0)
        del arg323_1
        buf635 = buf631; del buf631  # reuse
        # Topologically Sorted Source Nodes: [add_238, inv_norm_30, query_78, query_79, q_t_15, unsqueeze_105, mul_359, sum_64], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf632, buf633, buf634, buf635, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg324_1, (128, ), (1, ), 'input')
        buf638 = reinterpret_tensor(buf637, (16, 128), (128, 1), 0); del buf637  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_75, core_attn_out_76, core_attn_out_77, hidden_states_151, pow_67, variance_15, add_241, rsqrt_98, hidden_states_152, to_213, hidden_states_153, z_45, z_46, z_47, to_214, silu_51, hidden_states_154, core_attn_out_78], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf638, buf635, arg324_1, 16, 128, stream=raw_stream0)
        del arg324_1
        assert_size_stride(arg325_1, (2048, 2048), (2048, 1), 'input')
        buf639 = reinterpret_tensor(buf618, (1, 2048), (2048, 1), 0); del buf618  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_75, core_attn_out_76, core_attn_out_77, hidden_states_151, pow_67, variance_15, add_241, rsqrt_98, hidden_states_152, to_213, hidden_states_153, z_45, z_46, z_47, to_214, silu_51, hidden_states_154, core_attn_out_78, core_attn_out_79, output_117], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf638, arg325_1, buf639, 128, 1, 1, stream=raw_stream0)
        del arg325_1
        assert_size_stride(arg326_1, (2048, ), (1, ), 'input')
        buf641 = reinterpret_tensor(buf638, (1, 1, 2048), (2048, 2048, 1), 0); del buf638  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_149, output_117, hidden_states_155, float_136, pow_68, mean_67, add_243, rsqrt_99, output_118, float_137, add_244, output_119, hidden_states_156], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf610, buf616, buf639, arg326_1, buf641, 1, 2048, stream=raw_stream0)
        del arg326_1
        assert_size_stride(arg327_1, (6144, 2048), (2048, 1), 'input')
        buf642 = buf619; del buf619  # reuse
        # Topologically Sorted Source Nodes: [linear_160], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf641, arg327_1, buf642, 384, 1, 1, stream=raw_stream0)
        del arg327_1
        assert_size_stride(arg328_1, (6144, 2048), (2048, 1), 'input')
        buf644 = reinterpret_tensor(buf613, (1, 1, 6144), (6144, 6144, 1), 0); del buf613  # reuse
        # Topologically Sorted Source Nodes: [linear_160, silu_52, linear_161, mul_365], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf641, arg328_1, buf642, buf644, 384, 1, 1, stream=raw_stream0)
        del arg328_1
        assert_size_stride(arg329_1, (2048, 6144), (6144, 1), 'input')
        buf645 = reinterpret_tensor(buf641, (1, 2048), (2048, 1), 0); del buf641  # reuse
        # Topologically Sorted Source Nodes: [linear_160, silu_52, linear_161, mul_365, down_proj_20], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf644, arg329_1, buf645, 128, 1, 1, stream=raw_stream0)
        del arg329_1
        assert_size_stride(arg330_1, (2048, ), (1, ), 'input')
        buf647 = reinterpret_tensor(buf575, (1, 1, 2048), (2048, 2048, 1), 0); del buf575  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_149, output_117, hidden_states_155, down_proj_20, hidden_states_157, float_138, pow_69, mean_68, add_246, rsqrt_100, output_120, float_139, add_247, output_121, hidden_states_158], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf610, buf616, buf639, buf645, arg330_1, buf647, 1, 2048, stream=raw_stream0)
        del arg330_1
        assert_size_stride_grouped((arg334_1, arg337_1, arg338_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf656 = reinterpret_tensor(buf634, (1, 16), (16, 1), 0); del buf634  # reuse
        # Topologically Sorted Source Nodes: [exp_32, neg_26, a_16, float_141, add_248, softplus_16, g_16, transpose_159, getitem_258, exp_33], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf647, arg334_1, arg337_1, arg338_1, buf656, 1, 1, 1, stream=raw_stream0)
        del arg334_1
        del arg337_1
        del arg338_1
        assert_size_stride(arg333_1, (16, 2048), (2048, 1), 'input')
        buf659 = reinterpret_tensor(buf627, (1, 16, 1), (16, 1, 16), 0); del buf627  # reuse
        # Topologically Sorted Source Nodes: [b_16, beta_32, transpose_158, beta_33], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf647, arg333_1, buf659, 1, 1, 1, stream=raw_stream0)
        del arg333_1
        assert_size_stride(arg332_1, (2048, 2048), (2048, 1), 'input')
        buf666 = buf552; del buf552  # reuse
        # Topologically Sorted Source Nodes: [z_48], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf647, arg332_1, buf666, 128, 1, 1, stream=raw_stream0)
        del arg332_1
        assert_size_stride(arg331_1, (6144, 2048), (2048, 1), 'input')
        buf648 = reinterpret_tensor(buf644, (1, 6144), (6144, 1), 0); del buf644  # reuse
        # Topologically Sorted Source Nodes: [mixed_qkv_64], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf647, arg331_1, buf648, 384, 1, 1, stream=raw_stream0)
        del arg331_1
        buf650 = reinterpret_tensor(buf651, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_64, mixed_qkv_65, cat_38], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf648, buf650, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_250, copy__32], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf651, arg335_1, 24576, stream=raw_stream0)
        del arg335_1
        del buf649
        del buf650
        assert_size_stride(arg336_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf652 = buf623; del buf623  # reuse
        # Topologically Sorted Source Nodes: [out_48, squeeze_16, unsqueeze_106, out_49, out_50], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf651, arg336_1, buf652, 6144, stream=raw_stream0)
        del arg336_1
        del buf651
        buf653 = reinterpret_tensor(buf635, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf635  # reuse
        buf654 = buf625; del buf625  # reuse
        # Topologically Sorted Source Nodes: [out_50, mixed_qkv_67, split_16, key_65, transpose_156, key_66, mul_371, sum_66], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf652, buf653, buf654, 16, 128, stream=raw_stream0)
        assert_size_stride(arg339_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf660 = reinterpret_tensor(buf633, (1, 16, 128), (2048, 128, 1), 0); del buf633  # reuse
        # Topologically Sorted Source Nodes: [out_50, mixed_qkv_67, split_16, add_250, inv_norm_33, key_67, k_t_16, value_49, transpose_157, value_50, v_t_16, exp_32, neg_26, a_16, float_141, add_248, softplus_16, g_16, transpose_159, getitem_258, exp_33, decay_t_16, last_recurrent_state_49, unsqueeze_108, mul_374, kv_mem_16, sub_16, b_16, beta_32, transpose_158, beta_33, getitem_260, beta_t_16, delta_16], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg339_1, buf656, buf653, buf654, buf652, buf659, buf660, 2048, 128, stream=raw_stream0)
        buf662 = buf624; del buf624  # reuse
        buf663 = reinterpret_tensor(buf659, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf659  # reuse
        # Topologically Sorted Source Nodes: [out_50, mixed_qkv_67, split_16, query_81, transpose_155, query_82, mul_369, sum_65], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf652, buf662, buf663, 16, 128, stream=raw_stream0)
        buf661 = buf632; del buf632  # reuse
        # Topologically Sorted Source Nodes: [out_50, mixed_qkv_67, split_16, add_250, inv_norm_33, key_67, k_t_16, unsqueeze_109, value_49, transpose_157, value_50, v_t_16, exp_32, neg_26, a_16, float_141, add_248, softplus_16, g_16, transpose_159, getitem_258, exp_33, decay_t_16, last_recurrent_state_49, sub_16, b_16, beta_32, transpose_158, beta_33, getitem_260, beta_t_16, delta_16, unsqueeze_110, mul_376, last_recurrent_state_50], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg339_1, buf656, buf653, buf654, buf660, buf661, arg339_1, 262144, stream=raw_stream0)
        del arg339_1
        buf664 = buf660; del buf660  # reuse
        # Topologically Sorted Source Nodes: [add_249, inv_norm_32, query_83, query_84, q_t_16, unsqueeze_111, mul_377, sum_68], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf661, buf662, buf663, buf664, 2048, 128, stream=raw_stream0)
        assert_size_stride(arg340_1, (128, ), (1, ), 'input')
        buf667 = reinterpret_tensor(buf666, (16, 128), (128, 1), 0); del buf666  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_80, core_attn_out_81, core_attn_out_82, hidden_states_159, pow_70, variance_16, add_252, rsqrt_103, hidden_states_160, to_226, hidden_states_161, z_48, z_49, z_50, to_227, silu_54, hidden_states_162, core_attn_out_83], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf667, buf664, arg340_1, 16, 128, stream=raw_stream0)
        del arg340_1
        assert_size_stride(arg341_1, (2048, 2048), (2048, 1), 'input')
        buf668 = reinterpret_tensor(buf647, (1, 2048), (2048, 1), 0); del buf647  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_80, core_attn_out_81, core_attn_out_82, hidden_states_159, pow_70, variance_16, add_252, rsqrt_103, hidden_states_160, to_226, hidden_states_161, z_48, z_49, z_50, to_227, silu_54, hidden_states_162, core_attn_out_83, core_attn_out_84, output_122], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf667, arg341_1, buf668, 128, 1, 1, stream=raw_stream0)
        del arg341_1
        assert_size_stride(arg342_1, (2048, ), (1, ), 'input')
        buf669 = buf610; del buf610  # reuse
        buf671 = reinterpret_tensor(buf667, (1, 1, 2048), (2048, 2048, 1), 0); del buf667  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_149, output_117, hidden_states_155, down_proj_20, hidden_states_157, output_122, hidden_states_163, float_142, pow_71, mean_70, add_254, rsqrt_104, output_123, float_143, add_255, output_124, hidden_states_164], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42.run(buf669, buf616, buf639, buf645, buf668, arg342_1, buf671, 1, 2048, stream=raw_stream0)
        del arg342_1
        assert_size_stride(arg343_1, (6144, 2048), (2048, 1), 'input')
        buf672 = buf648; del buf648  # reuse
        # Topologically Sorted Source Nodes: [float_142, pow_71, mean_70, add_254, rsqrt_104, output_123, float_143, add_255, output_124, hidden_states_164, linear_168], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf671, arg343_1, buf672, 384, 1, 1, stream=raw_stream0)
        del arg343_1
        assert_size_stride(arg344_1, (6144, 2048), (2048, 1), 'input')
        buf674 = reinterpret_tensor(buf642, (1, 1, 6144), (6144, 6144, 1), 0); del buf642  # reuse
        # Topologically Sorted Source Nodes: [linear_168, silu_55, linear_169, mul_383], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf671, arg344_1, buf672, buf674, 384, 1, 1, stream=raw_stream0)
        del arg344_1
        assert_size_stride(arg345_1, (2048, 6144), (6144, 1), 'input')
        buf675 = reinterpret_tensor(buf671, (1, 2048), (2048, 1), 0); del buf671  # reuse
        # Topologically Sorted Source Nodes: [linear_168, silu_55, linear_169, mul_383, down_proj_21], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf674, arg345_1, buf675, 128, 1, 1, stream=raw_stream0)
        del arg345_1
        assert_size_stride(arg346_1, (2048, ), (1, ), 'input')
        buf677 = reinterpret_tensor(buf668, (1, 1, 2048), (2048, 2048, 1), 0); del buf668  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_165, float_144, pow_72, mean_71, add_257, rsqrt_105, output_125, float_145, add_258, output_126, hidden_states_166], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_23.run(buf669, buf675, arg346_1, buf677, 1, 2048, stream=raw_stream0)
        del arg346_1
        assert_size_stride_grouped((arg350_1, arg353_1, arg354_1), ((16, 2048), (16, ), (16, )), ((2048, 1), (1, ), (1, )), 'input')
        buf686 = reinterpret_tensor(buf663, (1, 16), (16, 1), 0); del buf663  # reuse
        # Topologically Sorted Source Nodes: [exp_34, neg_27, a_17, float_147, add_259, softplus_17, g_17, transpose_167, getitem_269, exp_35], Original ATen: [aten.exp, aten.neg, aten.view, aten.t, aten.mm, aten._unsafe_view, aten._to_copy, aten.add, aten.softplus, aten.mul, aten.transpose, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_exp_mm_mul_neg_select_softplus_t_transpose_view_2.run(buf677, arg350_1, arg353_1, arg354_1, buf686, 1, 1, 1, stream=raw_stream0)
        del arg350_1
        del arg353_1
        del arg354_1
        assert_size_stride(arg349_1, (16, 2048), (2048, 1), 'input')
        buf689 = reinterpret_tensor(buf656, (1, 16, 1), (16, 1, 16), 0); del buf656  # reuse
        # Topologically Sorted Source Nodes: [b_17, beta_34, transpose_166, beta_35], Original ATen: [aten.view, aten.t, aten.mm, aten._unsafe_view, aten.sigmoid, aten.transpose, aten._to_copy]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_mm_sigmoid_t_transpose_view_3.run(buf677, arg349_1, buf689, 1, 1, 1, stream=raw_stream0)
        del arg349_1
        assert_size_stride(arg348_1, (2048, 2048), (2048, 1), 'input')
        buf696 = buf645; del buf645  # reuse
        # Topologically Sorted Source Nodes: [z_51], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_4.run(buf677, arg348_1, buf696, 128, 1, 1, stream=raw_stream0)
        del arg348_1
        assert_size_stride(arg347_1, (6144, 2048), (2048, 1), 'input')
        buf678 = reinterpret_tensor(buf674, (1, 6144), (6144, 1), 0); del buf674  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_165, float_144, pow_72, mean_71, add_257, rsqrt_105, output_125, float_145, add_258, output_126, hidden_states_166, mixed_qkv_68], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf677, arg347_1, buf678, 384, 1, 1, stream=raw_stream0)
        del arg347_1
        buf680 = reinterpret_tensor(buf681, (1, 6144, 1), (30720, 5, 1), 4)  # alias
        # Topologically Sorted Source Nodes: [mixed_qkv_68, mixed_qkv_69, cat_39], Original ATen: [aten._unsafe_view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_transpose_6.run(buf678, buf680, 6144, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [getitem_261, copy__34], Original ATen: [aten.slice, aten.copy, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_copy_copy__slice_8.run(buf681, arg351_1, 24576, stream=raw_stream0)
        del arg351_1
        del buf679
        del buf680
        assert_size_stride(arg352_1, (6144, 1, 4), (4, 4, 1), 'input')
        buf682 = buf652; del buf652  # reuse
        # Topologically Sorted Source Nodes: [out_51, squeeze_17, unsqueeze_112, out_52, out_53], Original ATen: [aten.convolution, aten.squeeze, aten.unsqueeze, aten.slice, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_silu_slice_squeeze_unsqueeze_9.run(buf681, arg352_1, buf682, 6144, stream=raw_stream0)
        del arg352_1
        del buf681
        buf683 = reinterpret_tensor(buf664, (1, 16, 1, 128), (2048, 128, 2048, 1), 0); del buf664  # reuse
        buf684 = buf654; del buf654  # reuse
        # Topologically Sorted Source Nodes: [out_53, mixed_qkv_71, split_17, key_69, transpose_164, key_70, mul_389, sum_70], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_10.run(buf682, buf683, buf684, 16, 128, stream=raw_stream0)
        assert_size_stride(arg355_1, (1, 16, 128, 128), (262144, 16384, 128, 1), 'input')
        buf690 = reinterpret_tensor(buf662, (1, 16, 128), (2048, 128, 1), 0); del buf662  # reuse
        # Topologically Sorted Source Nodes: [out_53, mixed_qkv_71, split_17, add_261, inv_norm_35, key_71, k_t_17, value_52, transpose_165, value_53, v_t_17, exp_34, neg_27, a_17, float_147, add_259, softplus_17, g_17, transpose_167, getitem_269, exp_35, decay_t_17, last_recurrent_state_52, unsqueeze_114, mul_392, kv_mem_17, sub_17, b_17, beta_34, transpose_166, beta_35, getitem_271, beta_t_17, delta_17], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.unsqueeze, aten.sum, aten.sub, aten.sigmoid]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_sum_transpose_unsqueeze_view_11.run(arg355_1, buf686, buf683, buf684, buf682, buf689, buf690, 2048, 128, stream=raw_stream0)
        buf692 = buf653; del buf653  # reuse
        buf693 = reinterpret_tensor(buf689, (1, 16, 1, 1), (16, 1, 16, 16), 0); del buf689  # reuse
        # Topologically Sorted Source Nodes: [out_53, mixed_qkv_71, split_17, query_86, transpose_163, query_87, mul_387, sum_69], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.view, aten._to_copy, aten.mul, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_mul_silu_split_with_sizes_sum_transpose_view_12.run(buf682, buf692, buf693, 16, 128, stream=raw_stream0)
        del buf682
        buf691 = buf661; del buf661  # reuse
        # Topologically Sorted Source Nodes: [out_53, mixed_qkv_71, split_17, add_261, inv_norm_35, key_71, k_t_17, unsqueeze_115, value_52, transpose_165, value_53, v_t_17, exp_34, neg_27, a_17, float_147, add_259, softplus_17, g_17, transpose_167, getitem_269, exp_35, decay_t_17, last_recurrent_state_52, sub_17, b_17, beta_34, transpose_166, beta_35, getitem_271, beta_t_17, delta_17, unsqueeze_116, mul_394, last_recurrent_state_53], Original ATen: [aten.silu, aten.transpose, aten.split_with_sizes, aten.add, aten.rsqrt, aten.mul, aten.select, aten.unsqueeze, aten.view, aten._to_copy, aten.exp, aten.neg, aten._unsafe_view, aten.softplus, aten.sub, aten.sigmoid, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_copy__exp_mul_neg_rsqrt_select_sigmoid_silu_softplus_split_with_sizes_sub_transpose_unsqueeze_view_13.run(arg355_1, buf686, buf683, buf684, buf690, buf691, arg355_1, 262144, stream=raw_stream0)
        del arg355_1
        del buf683
        del buf684
        del buf686
        buf694 = buf690; del buf690  # reuse
        # Topologically Sorted Source Nodes: [add_260, inv_norm_34, query_88, query_89, q_t_17, unsqueeze_117, mul_395, sum_72], Original ATen: [aten.add, aten.rsqrt, aten.mul, aten.div, aten.select, aten.unsqueeze, aten.sum]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_div_mul_rsqrt_select_sum_unsqueeze_14.run(buf691, buf692, buf693, buf694, 2048, 128, stream=raw_stream0)
        del buf691
        del buf692
        del buf693
        assert_size_stride(arg356_1, (128, ), (1, ), 'input')
        buf697 = reinterpret_tensor(buf696, (16, 128), (128, 1), 0); del buf696  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_85, core_attn_out_86, core_attn_out_87, hidden_states_167, pow_73, variance_17, add_263, rsqrt_108, hidden_states_168, to_239, hidden_states_169, z_51, z_52, z_53, to_240, silu_57, hidden_states_170, core_attn_out_88], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_silu_transpose_view_zeros_like_15.run(buf697, buf694, arg356_1, 16, 128, stream=raw_stream0)
        del arg356_1
        del buf694
        assert_size_stride(arg357_1, (2048, 2048), (2048, 1), 'input')
        buf698 = reinterpret_tensor(buf677, (1, 2048), (2048, 1), 0); del buf677  # reuse
        # Topologically Sorted Source Nodes: [core_attn_out_85, core_attn_out_86, core_attn_out_87, hidden_states_167, pow_73, variance_17, add_263, rsqrt_108, hidden_states_168, to_239, hidden_states_169, z_51, z_52, z_53, to_240, silu_57, hidden_states_170, core_attn_out_88, core_attn_out_89, output_127], Original ATen: [aten.zeros_like, aten.transpose, aten._to_copy, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._unsafe_view, aten.silu, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf697, arg357_1, buf698, 128, 1, 1, stream=raw_stream0)
        del arg357_1
        assert_size_stride(arg358_1, (2048, ), (1, ), 'input')
        buf700 = reinterpret_tensor(buf697, (1, 1, 2048), (2048, 2048, 1), 0); del buf697  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_165, output_127, hidden_states_171, float_148, pow_74, mean_73, add_265, rsqrt_109, output_128, float_149, add_266, output_129, hidden_states_172], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf669, buf675, buf698, arg358_1, buf700, 1, 2048, stream=raw_stream0)
        del arg358_1
        assert_size_stride(arg359_1, (6144, 2048), (2048, 1), 'input')
        buf701 = buf678; del buf678  # reuse
        # Topologically Sorted Source Nodes: [linear_176], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf700, arg359_1, buf701, 384, 1, 1, stream=raw_stream0)
        del arg359_1
        assert_size_stride(arg360_1, (6144, 2048), (2048, 1), 'input')
        buf703 = reinterpret_tensor(buf672, (1, 1, 6144), (6144, 6144, 1), 0); del buf672  # reuse
        # Topologically Sorted Source Nodes: [linear_176, silu_58, linear_177, mul_401], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf700, arg360_1, buf701, buf703, 384, 1, 1, stream=raw_stream0)
        del arg360_1
        assert_size_stride(arg361_1, (2048, 6144), (6144, 1), 'input')
        buf704 = reinterpret_tensor(buf700, (1, 2048), (2048, 1), 0); del buf700  # reuse
        # Topologically Sorted Source Nodes: [linear_176, silu_58, linear_177, mul_401, down_proj_22], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf703, arg361_1, buf704, 128, 1, 1, stream=raw_stream0)
        del arg361_1
        assert_size_stride(arg362_1, (2048, ), (1, ), 'input')
        buf706 = reinterpret_tensor(buf639, (1, 1, 2048), (2048, 2048, 1), 0); del buf639  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_165, output_127, hidden_states_171, down_proj_22, hidden_states_173, float_150, pow_75, mean_74, add_268, rsqrt_110, output_130, float_151, add_269, output_131, hidden_states_174], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_25.run(buf669, buf675, buf698, buf704, arg362_1, buf706, 1, 2048, stream=raw_stream0)
        del arg362_1
        assert_size_stride(arg365_1, (512, 2048), (2048, 1), 'input')
        buf715 = reinterpret_tensor(buf588, (1, 512), (512, 1), 0); del buf588  # reuse
        # Topologically Sorted Source Nodes: [linear_180], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_26.run(buf706, arg365_1, buf715, 32, 1, 1, stream=raw_stream0)
        del arg365_1
        buf716 = buf593; del buf593  # reuse
        # Topologically Sorted Source Nodes: [linear_180, view_22, float_154, pow_77, mean_76], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_view_27.run(buf715, buf716, 2, 256, stream=raw_stream0)
        assert_size_stride(arg366_1, (256, ), (1, ), 'input')
        buf719 = buf596; del buf596  # reuse
        buf717 = reinterpret_tensor(buf719, (1, 2, 1, 32), (128, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_180, view_22, float_154, pow_77, mean_76, add_272, rsqrt_112, output_134, float_155, add_273, output_135, type_as_58, key_states_10, k_rot_5, x2_11, neg_29], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_mean_mul_neg_pow_rsqrt_slice_transpose_view_28.run(buf715, buf716, arg366_1, buf717, 64, stream=raw_stream0)
        buf718 = reinterpret_tensor(buf719, (1, 2, 1, 32), (128, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_180, view_22, float_154, pow_77, mean_76, add_272, rsqrt_112, output_134, float_155, add_273, output_135, type_as_58, key_states_10, k_rot_5, x2_11, neg_29, x1_11, cat_41], Original ATen: [aten._unsafe_view, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_transpose_view_29.run(buf715, buf716, arg366_1, buf718, 64, stream=raw_stream0)
        buf722 = reinterpret_tensor(buf592, (1, 2, 1, 256), (512, 256, 256, 1), 0); del buf592  # reuse
        buf720 = reinterpret_tensor(buf722, (1, 2, 1, 64), (512, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_9, sin_9, linear_180, view_22, float_154, pow_77, mean_76, add_272, rsqrt_112, output_134, float_155, add_273, output_135, type_as_58, key_states_10, k_rot_5, mul_410, mul_411, k_embed_10], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_30.run(buf715, buf716, arg366_1, buf92, buf719, buf96, buf720, 128, stream=raw_stream0)
        del buf717
        del buf718
        del buf719
        buf721 = reinterpret_tensor(buf722, (1, 2, 1, 192), (512, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, cos_9, sin_9, linear_180, view_22, float_154, pow_77, mean_76, add_272, rsqrt_112, output_134, float_155, add_273, output_135, type_as_58, key_states_10, k_rot_5, mul_410, mul_411, k_embed_10, k_pass_5, k_embed_11], Original ATen: [aten.select, aten.cat, aten._to_copy, aten.unsqueeze, aten._unsafe_view, aten.view, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_31.run(buf715, buf716, arg366_1, buf721, 384, stream=raw_stream0)
        del arg366_1
        del buf715
        del buf716
        assert_size_stride_grouped((arg368_1, arg369_1), ((), (1, 2, 144, 256)), ((), (73728, 36864, 256, 1)), 'input')
        # Topologically Sorted Source Nodes: [arange_6, cache_position_5, index_copy__10], Original ATen: [aten.arange, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_32.run(arg368_1, buf722, arg369_1, 512, stream=raw_stream0)
        del buf720
        del buf721
        assert_size_stride(arg367_1, (512, 2048), (2048, 1), 'input')
        buf728 = reinterpret_tensor(buf722, (1, 512), (512, 1), 0); del buf722  # reuse
        # Topologically Sorted Source Nodes: [linear_181], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_26.run(buf706, arg367_1, buf728, 32, 1, 1, stream=raw_stream0)
        del arg367_1
        assert_size_stride(arg370_1, (1, 2, 144, 256), (73728, 36864, 256, 1), 'input')
        # Topologically Sorted Source Nodes: [arange_6, cache_position_5, linear_181, view_23, value_states_10, index_copy__11], Original ATen: [aten.arange, aten.add, aten._unsafe_view, aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_arange_index_copy_32.run(arg368_1, buf728, arg370_1, 512, stream=raw_stream0)
        # Topologically Sorted Source Nodes: [add__5], Original ATen: [aten.add, aten.copy_]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_copy__33.run(arg368_1, arg368_1, 1, stream=raw_stream0)
        del arg368_1
        assert_size_stride(arg363_1, (4096, 2048), (2048, 1), 'input')
        buf707 = buf584; del buf584  # reuse
        # Topologically Sorted Source Nodes: [linear_179], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_34.run(buf706, arg363_1, buf707, 256, 1, 1, stream=raw_stream0)
        del arg363_1
        buf708 = reinterpret_tensor(buf604, (1, 1, 8, 1), (8, 8, 1, 8), 0); del buf604  # reuse
        # Topologically Sorted Source Nodes: [linear_179, view_20, chunk_5, float_152, pow_76, mean_75], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_mean_pow_split_view_35.run(buf707, buf708, 8, 256, stream=raw_stream0)
        assert_size_stride(arg364_1, (256, ), (1, ), 'input')
        buf711 = reinterpret_tensor(buf728, (1, 8, 1, 64), (512, 64, 64, 1), 0); del buf728  # reuse
        buf709 = reinterpret_tensor(buf711, (1, 8, 1, 32), (512, 64, 64, 1), 0)  # alias
        buf710 = reinterpret_tensor(buf711, (1, 8, 1, 32), (512, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_179, view_20, chunk_5, float_152, pow_76, mean_75, add_270, rsqrt_111, output_132, float_153, add_271, output_133, type_as_57, query_states_11, q_rot_5, x2_10, neg_28, x1_10, cat_40], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_neg_pow_rsqrt_slice_split_transpose_view_36.run(buf707, buf708, arg364_1, buf709, buf710, 256, stream=raw_stream0)
        buf714 = reinterpret_tensor(buf706, (1, 8, 1, 256), (2048, 256, 256, 1), 0); del buf706  # reuse
        buf712 = reinterpret_tensor(buf714, (1, 8, 1, 64), (2048, 256, 256, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_179, view_20, chunk_5, float_152, pow_76, mean_75, add_270, rsqrt_111, output_132, float_153, add_271, output_133, type_as_57, query_states_11, q_rot_5, cos_9, mul_408, sin_9, mul_409, q_embed_10], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_37.run(buf707, buf708, arg364_1, buf92, buf711, buf96, buf712, 512, stream=raw_stream0)
        del buf709
        del buf710
        del buf711
        del buf92
        del buf96
        buf713 = reinterpret_tensor(buf714, (1, 8, 1, 192), (2048, 256, 256, 1), 64)  # alias
        # Topologically Sorted Source Nodes: [cos_2, cos_3, sin_2, sin_3, linear_179, view_20, chunk_5, float_152, pow_76, mean_75, add_270, rsqrt_111, output_132, float_153, add_271, output_133, type_as_57, query_states_11, q_rot_5, cos_9, mul_408, sin_9, mul_409, q_embed_10, q_pass_5, q_embed_11], Original ATen: [aten.select, aten.cat, aten._to_copy, aten._unsafe_view, aten.view, aten.split, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.unsqueeze]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy__unsafe_view_add_cat_mean_mul_pow_rsqrt_select_slice_split_transpose_unsqueeze_view_38.run(buf707, buf708, arg364_1, buf713, 1536, stream=raw_stream0)
        del arg364_1
        buf724 = buf601; del buf601  # reuse
        # Topologically Sorted Source Nodes: [matmul_10, key_states_11, transpose_172], Original ATen: [aten.view, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten.transpose, aten.bmm]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__unsafe_view_bmm_clone_expand_transpose_unsqueeze_view_39.run(buf714, arg369_1, buf724, 1152, 256, stream=raw_stream0)
        del arg369_1
        del buf712
        del buf713
        buf726 = buf603; del buf603  # reuse
        buf727 = reinterpret_tensor(buf708, (1, 8, 1, 1), (8, 1, 8, 8), 0); del buf708  # reuse
        # Topologically Sorted Source Nodes: [arange, getitem, getitem_1, getitem_2, allowed, mask_1, mask, getitem_3, matmul_10, attn_weights_20, attn_weights_21, softmax_5], Original ATen: [aten.arange, aten.unsqueeze, aten.select, aten.le, aten.masked_fill, aten.full, aten.view, aten.mul, aten.add, aten._to_copy, aten._softmax]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy_add_arange_full_le_masked_fill_mul_select_unsqueeze_view_40.run(buf724, arg0_1, buf726, buf727, 8, 144, stream=raw_stream0)
        del arg0_1
        del buf724
        buf730 = reinterpret_tensor(buf714, (8, 1, 256), (256, 256, 1), 0); del buf714  # reuse
        buf731 = reinterpret_tensor(buf730, (1, 1, 2048), (2048, 2048, 1), 0); del buf730  # reuse
        # Topologically Sorted Source Nodes: [linear_179, view_20, chunk_5, softmax_5, attn_weights_22, attn_output_25, value_states_11, transpose_173, reshape_149, gate_11, sigmoid_23, attn_output_28], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten._softmax, aten._to_copy, aten.unsqueeze, aten.expand, aten.clone, aten.bmm, aten.transpose, aten.sigmoid, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__softmax__to_copy__unsafe_view_bmm_clone_expand_mul_sigmoid_split_transpose_unsqueeze_view_41.run(buf731, buf726, buf727, arg370_1, buf707, 2048, 144, stream=raw_stream0)
        del arg370_1
        del buf707
        del buf726
        del buf727
        assert_size_stride(arg371_1, (2048, 2048), (2048, 1), 'input')
        buf732 = buf616; del buf616  # reuse
        # Topologically Sorted Source Nodes: [linear_179, view_20, chunk_5, attn_output_25, transpose_173, reshape_149, gate_11, sigmoid_23, attn_output_28, attn_output_29], Original ATen: [aten._unsafe_view, aten.view, aten.split, aten.transpose, aten.clone, aten.sigmoid, aten.mul, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_silu_t_transpose_view_zeros_like_16.run(buf731, arg371_1, buf732, 128, 1, 1, stream=raw_stream0)
        del arg371_1
        assert_size_stride(arg372_1, (2048, ), (1, ), 'input')
        buf733 = buf669; del buf669  # reuse
        buf735 = buf731; del buf731  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_165, output_127, hidden_states_171, down_proj_22, hidden_states_173, attn_output_29, hidden_states_177, float_156, pow_78, mean_77, add_279, rsqrt_113, output_136, float_157, add_280, output_137, hidden_states_178], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_42.run(buf733, buf675, buf698, buf704, buf732, arg372_1, buf735, 1, 2048, stream=raw_stream0)
        del arg372_1
        del buf675
        del buf698
        del buf704
        del buf732
        assert_size_stride(arg373_1, (6144, 2048), (2048, 1), 'input')
        buf736 = reinterpret_tensor(buf703, (1, 6144), (6144, 1), 0); del buf703  # reuse
        # Topologically Sorted Source Nodes: [float_156, pow_78, mean_77, add_279, rsqrt_113, output_136, float_157, add_280, output_137, hidden_states_178, linear_183], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf735, arg373_1, buf736, 384, 1, 1, stream=raw_stream0)
        del arg373_1
        assert_size_stride(arg374_1, (6144, 2048), (2048, 1), 'input')
        buf738 = reinterpret_tensor(buf701, (1, 1, 6144), (6144, 6144, 1), 0); del buf701  # reuse
        # Topologically Sorted Source Nodes: [linear_183, silu_59, linear_184, mul_416], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_19.run(buf735, arg374_1, buf736, buf738, 384, 1, 1, stream=raw_stream0)
        del arg374_1
        del buf736
        assert_size_stride(arg375_1, (2048, 6144), (6144, 1), 'input')
        buf739 = reinterpret_tensor(buf735, (1, 2048), (2048, 1), 0); del buf735  # reuse
        # Topologically Sorted Source Nodes: [linear_183, silu_59, linear_184, mul_416, down_proj_23], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_20.run(buf738, arg375_1, buf739, 128, 1, 1, stream=raw_stream0)
        del arg375_1
        del buf738
        assert_size_stride(arg376_1, (2048, ), (1, ), 'input')
        buf741 = buf733; del buf733  # reuse
        # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_179, float_158, pow_79, mean_78, add_282, rsqrt_114, output_138, float_159, add_283, output_139, hidden_states_180], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_43.run(buf741, buf739, arg376_1, 1, 2048, stream=raw_stream0)
        del arg376_1
        del buf739
        buf742 = empty_strided((1, 248320), (248320, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_179, float_158, pow_79, mean_78, add_282, rsqrt_114, output_138, float_159, add_283, output_139, hidden_states_180, getitem_284, logits], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_44.run(buf741, arg2_1, buf742, 15520, 1, 1, stream=raw_stream0)
        del arg2_1
        return (reinterpret_tensor(buf742, (1, 1, 248320), (248320, 248320, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 1), (1, 1), device='tnca:0', dtype=torch.int64)
    arg1_1 = rand_strided((1, 1), (1, 1), device='tnca:0', dtype=torch.int64)
    arg2_1 = rand_strided((248320, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg3_1 = rand_strided((32, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg4_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg5_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg6_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg7_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg8_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg9_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg10_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg11_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg12_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg13_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg14_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg15_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg16_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg17_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg18_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg19_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg20_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg21_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg22_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg23_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg24_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg25_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg26_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg27_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg28_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg29_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg30_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg31_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg32_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg33_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg34_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg35_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg36_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg37_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg38_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg39_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg40_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg41_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg42_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg43_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg44_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg45_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg46_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg47_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg48_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg49_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg50_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg51_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg52_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg53_1 = rand_strided((4096, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg54_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg55_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg56_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg57_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg58_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg59_1 = rand_strided((1, 2, 144, 256), (73728, 36864, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg60_1 = rand_strided((1, 2, 144, 256), (73728, 36864, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg61_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg62_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg63_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg64_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg65_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg66_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg67_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg68_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg69_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg70_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg71_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg72_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg73_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg74_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg75_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg76_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg77_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg78_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg79_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg80_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg81_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg82_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg83_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg84_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg85_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg86_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg87_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg88_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg89_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg90_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg91_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg92_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg93_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg94_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg95_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg96_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg97_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg98_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg99_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg100_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg101_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg102_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg103_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg104_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg105_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg106_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg107_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg108_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg109_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg110_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg111_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg112_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg113_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg114_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg115_1 = rand_strided((4096, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg116_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg117_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg118_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg119_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg120_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg121_1 = rand_strided((1, 2, 144, 256), (73728, 36864, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg122_1 = rand_strided((1, 2, 144, 256), (73728, 36864, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg123_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg124_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg125_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg126_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg127_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg128_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg129_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg130_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg131_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg132_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg133_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg134_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg135_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg136_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg137_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg138_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg139_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg140_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg141_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg142_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg143_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg144_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg145_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg146_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg147_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg148_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg149_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg150_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg151_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg152_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg153_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg154_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg155_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg156_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg157_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg158_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg159_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg160_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg161_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg162_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg163_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg164_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg165_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg166_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg167_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg168_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg169_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg170_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg171_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg172_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg173_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg174_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg175_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg176_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg177_1 = rand_strided((4096, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg178_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg179_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg180_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg181_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg182_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg183_1 = rand_strided((1, 2, 144, 256), (73728, 36864, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg184_1 = rand_strided((1, 2, 144, 256), (73728, 36864, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg185_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg186_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg187_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg188_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg189_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg190_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg191_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg192_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg193_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg194_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg195_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg196_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg197_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg198_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg199_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg200_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg201_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg202_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg203_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg204_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg205_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg206_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg207_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg208_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg209_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg210_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg211_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg212_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg213_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg214_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg215_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg216_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg217_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg218_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg219_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg220_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg221_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg222_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg223_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg224_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg225_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg226_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg227_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg228_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg229_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg230_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg231_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg232_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg233_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg234_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg235_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg236_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg237_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg238_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg239_1 = rand_strided((4096, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg240_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg241_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg242_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg243_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg244_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg245_1 = rand_strided((1, 2, 144, 256), (73728, 36864, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg246_1 = rand_strided((1, 2, 144, 256), (73728, 36864, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg247_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg248_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg249_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg250_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg251_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg252_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg253_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg254_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg255_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg256_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg257_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg258_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg259_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg260_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg261_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg262_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg263_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg264_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg265_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg266_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg267_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg268_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg269_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg270_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg271_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg272_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg273_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg274_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg275_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg276_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg277_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg278_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg279_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg280_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg281_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg282_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg283_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg284_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg285_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg286_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg287_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg288_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg289_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg290_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg291_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg292_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg293_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg294_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg295_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg296_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg297_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg298_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg299_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg300_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg301_1 = rand_strided((4096, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg302_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg303_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg304_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg305_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg306_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg307_1 = rand_strided((1, 2, 144, 256), (73728, 36864, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg308_1 = rand_strided((1, 2, 144, 256), (73728, 36864, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg309_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg310_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg311_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg312_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg313_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg314_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg315_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg316_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg317_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg318_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg319_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg320_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg321_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg322_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg323_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg324_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg325_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg326_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg327_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg328_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg329_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg330_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg331_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg332_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg333_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg334_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg335_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg336_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg337_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg338_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg339_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg340_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg341_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg342_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg343_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg344_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg345_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg346_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg347_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg348_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg349_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg350_1 = rand_strided((16, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg351_1 = rand_strided((1, 6144, 4), (24576, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg352_1 = rand_strided((6144, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    arg353_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg354_1 = rand_strided((16, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg355_1 = rand_strided((1, 16, 128, 128), (262144, 16384, 128, 1), device='tnca:0', dtype=torch.float32)
    arg356_1 = rand_strided((128, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg357_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg358_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg359_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg360_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg361_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg362_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg363_1 = rand_strided((4096, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg364_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg365_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg366_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg367_1 = rand_strided((512, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg368_1 = rand_strided((), (), device='tnca:0', dtype=torch.int64)
    arg369_1 = rand_strided((1, 2, 144, 256), (73728, 36864, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg370_1 = rand_strided((1, 2, 144, 256), (73728, 36864, 256, 1), device='tnca:0', dtype=torch.bfloat16)
    arg371_1 = rand_strided((2048, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg372_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    arg373_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg374_1 = rand_strided((6144, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    arg375_1 = rand_strided((2048, 6144), (6144, 1), device='tnca:0', dtype=torch.bfloat16)
    arg376_1 = rand_strided((2048, ), (1, ), device='tnca:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
