# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/op.attention_decode__tiny__fp16-b1-h2-l16-d16/inductor_cache/4s/c4san62zx4mkdsd633tsd2bkwquc5sg4nbilrslslpxvkju2nwxf.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => bmm, convert_element_type, convert_element_type_1, mul, mul_1, permute, view, view_1
# Graph fragment:
#   %arg0_1 : Tensor "f16[1, 2, 1, 16][32, 16, 16, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "f16[1, 2, 16, 16][512, 256, 16, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %convert_element_type : Tensor "f32[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type, 0.5), kwargs = {})
#   %view : Tensor "f32[2, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand, [2, 1, 16]), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[1, 2, 16, 16][512, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg1_1, torch.float32), kwargs = {})
#   %permute : Tensor "f32[1, 2, 16, 16][512, 256, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_1, [0, 1, 3, 2]), kwargs = {})
#   %mul_1 : Tensor "f32[1, 2, 16, 16][512, 256, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute, 0.5), kwargs = {})
#   %view_1 : Tensor "f32[2, 16, 16][256, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_1, [2, 16, 16]), kwargs = {})
#   %bmm : Tensor "f32[2, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view, %view_1), kwargs = {})
#   return %bmm
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_0 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 32, 'r0_': 16},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 256, 'r0_': 1088}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_0(in_ptr0, in_ptr1, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 32
    XBLOCK: tl.constexpr = 1
    r0_numel = 16
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 16
    x3 = xindex
    _tmp9 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_2 + 16*x1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tl.load(in_ptr1 + (r0_2 + 16*x3), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tl.full([1], 0.5, tl.float32)
        tmp3 = tmp1 * tmp2
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp2
        tmp7 = tmp3 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask, tmp10, _tmp9)
    tmp9 = triton_helpers.promote_to_tensor(tl.sum(_tmp9, 0))
    tl.store(out_ptr0 + (x3), tmp9, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/op.attention_decode__tiny__fp16-b1-h2-l16-d16/inductor_cache/rq/crqmy37ovyhuoqv6ydfq3s22lkvsp7qtm4jouna66o5lyelwghar.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => amax, any_1, eq, exp, logical_not, sub, sum_1, view_2
# Graph fragment:
#   %bmm : Tensor "f32[2, 1, 16][16, 16, 1]tnca:0" = PlaceHolder[target=bmm]
#   %amax : Tensor "f32[1, 2, 1, 1][2, 1, 2, 2]tnca:0" = PlaceHolder[target=amax]
#   %exp : Tensor "f32[1, 2, 1, 16][32, 16, 32, 1]tnca:0" = PlaceHolder[target=exp]
#   %view_2 : Tensor "f32[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 2, 1, 16]), kwargs = {})
#   %eq : Tensor "b8[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%view_2, -inf), kwargs = {})
#   %logical_not : Tensor "b8[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq,), kwargs = {})
#   %any_1 : Tensor "b8[1, 2, 1, 1][2, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.any.dim](args = (%logical_not, -1, True), kwargs = {})
#   %amax : Tensor "f32[1, 2, 1, 1][2, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%view_2, [-1], True), kwargs = {})
#   %sub : Tensor "f32[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%view_2, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub,), kwargs = {})
#   %sum_1 : Tensor "f32[1, 2, 1, 1][2, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp, [-1], True), kwargs = {})
#   return %any_1,%amax,%exp,%sum_1
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_1 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 2, 'r0_': 16},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*i1', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 3, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 5, 'r0_': 384}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_1(in_ptr0, out_ptr0, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 2
    XBLOCK: tl.constexpr = 1
    r0_numel = 16
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[2, 16], strides=[16, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp7 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp11 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp1 = tl.full([1], float("-inf"), tl.float32)
        tmp2 = tmp0 == tmp1
        tmp3 = tmp2 == 0
        tmp4 = tmp3.to(tl.int64)
        tmp5 = (tmp4 != 0)
        tmp6 = tl.broadcast_to(tmp5, [R0_BLOCK])
        tmp8 = _tmp7 | tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
        tmp10 = tl.broadcast_to(tmp0, [R0_BLOCK])
        tmp12 = tl.maximum(_tmp11, tmp10, tl.PropagateNan.ALL)
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp9 = _tmp7.to(tl.int8)
    tmp7 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp9, 0))
    tmp11 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp11, 0))
    tl.store(out_ptr0 + (x0), tmp7, None)
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[2, 16], strides=[16, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp17 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp14 = tmp13 - tmp11
        tmp15 = libdevice.exp(tmp14)
        tmp16 = tl.broadcast_to(tmp15, [R0_BLOCK])
        tmp18 = _tmp17 + tmp16
        _tmp17 = tl.where(r0_mask, tmp18, _tmp17)
        tl.store(out_ptr2 + (r0_1 + 16*x0), tmp15, r0_mask)
    tmp17 = triton_helpers.promote_to_tensor(tl.sum(_tmp17, 0))
    tl.store(out_ptr3 + (x0), tmp17, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/op.attention_decode__tiny__fp16-b1-h2-l16-d16/inductor_cache/u2/cu2gxrrcakyzdhaovvpbalc3yteesjvvtp3ldhjmtnvryyk4ce3n.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => bmm_1, convert_element_type_2, convert_element_type_3, div, full_default, logical_not_1, view_3, view_4, view_5, where
# Graph fragment:
#   %any_1 : Tensor "b8[1, 2, 1, 1][2, 1, 2, 2]tnca:0" = PlaceHolder[target=any_1]
#   %exp : Tensor "f32[1, 2, 1, 16][32, 16, 32, 1]tnca:0" = PlaceHolder[target=exp]
#   %sum_1 : Tensor "f32[1, 2, 1, 1][2, 1, 2, 2]tnca:0" = PlaceHolder[target=sum_1]
#   %arg2_1 : Tensor "f16[1, 2, 16, 16][512, 256, 16, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %bmm_1 : Tensor "f32[2, 1, 16][16, 16, 1]tnca:0" = PlaceHolder[target=bmm_1]
#   %logical_not_1 : Tensor "b8[1, 2, 1, 1][2, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default : Tensor "f32[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 2, 1, 16], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %div : Tensor "f32[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where : Tensor "f32[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default, %div), kwargs = {})
#   %view_3 : Tensor "f32[2, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_2, [2, 1, 16]), kwargs = {})
#   %convert_element_type_2 : Tensor "f32[1, 2, 16, 16][512, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg2_1, torch.float32), kwargs = {})
#   %view_4 : Tensor "f32[2, 16, 16][256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_3, [2, 16, 16]), kwargs = {})
#   %bmm_1 : Tensor "f32[2, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_3, %view_4), kwargs = {})
#   %view_5 : Tensor "f32[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 2, 1, 16]), kwargs = {})
#   %convert_element_type_3 : Tensor "f16[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_5, torch.float16), kwargs = {})
#   return %bmm_1,%convert_element_type_3
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_2 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 32, 'r0_': 16},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i1', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 1152, 'r0_': 128}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_2(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 32
    XBLOCK: tl.constexpr = 1
    r0_numel = 16
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 16
    tmp0 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last').to(tl.int1)
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr1, shape=[2, 16], strides=[16, 1], block_shape=[(15 + XBLOCK) // 16, R0_BLOCK])
    tmp3 = tl.load(in_ptr2 + (x1), None, eviction_policy='evict_last')
    x0 = (xindex % 16)
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp2 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([xoffset // 16, r0_offset])[:, :, None, None], [(15 + XBLOCK) // 16, R0_BLOCK, ((1) * ((1) <= ((15 + XBLOCK) // 16)) + ((15 + XBLOCK) // 16) * (((15 + XBLOCK) // 16) < (1))), ((16) * ((16) <= (XBLOCK)) + (XBLOCK) * ((XBLOCK) < (16)))]), [0, 2, 3, 1]), [R0_BLOCK])
        tmp7 = tl.load(in_ptr3 + (x0 + 16*r0_2 + 256*x1), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp1 = tmp0 == 0
        tmp4 = (tmp2 / tmp3)
        tmp5 = tl.full([1], 0.0, tl.float32)
        tmp6 = tl.where(tmp1, tmp5, tmp4)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp6 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp13 = tmp11.to(tl.float32)
    tl.store(out_ptr1 + (x3), tmp13, None)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1), ((1, 2, 1, 16), (1, 2, 16, 16)), ((32, 16, 16, 1), (512, 256, 16, 1)), 'input')
        buf0 = empty_strided((2, 1, 16), (16, 16, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_0.run(arg0_1, arg1_1, buf0, 32, 16, stream=raw_stream0)
        del arg0_1
        del arg1_1
        buf1 = empty_strided((1, 2, 1, 1), (2, 1, 2, 2), device='tnca', dtype=torch.bool)
        buf3 = empty_strided((1, 2, 1, 16), (32, 16, 32, 1), device='tnca', dtype=torch.float32)
        buf4 = empty_strided((1, 2, 1, 1), (2, 1, 2, 2), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_1.run(buf0, buf1, buf3, buf4, 2, 16, stream=raw_stream0)
        del buf0
        assert_size_stride(arg2_1, (1, 2, 16, 16), (512, 256, 16, 1), 'input')
        buf6 = empty_strided((1, 2, 1, 16), (32, 16, 16, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_2.run(buf1, buf3, buf4, arg2_1, buf6, 32, 16, stream=raw_stream0)
        del arg2_1
        return (buf6, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 2, 1, 16), (32, 16, 16, 1), device='tnca:0', dtype=torch.float16)
    arg1_1 = rand_strided((1, 2, 16, 16), (512, 256, 16, 1), device='tnca:0', dtype=torch.float16)
    arg2_1 = rand_strided((1, 2, 16, 16), (512, 256, 16, 1), device='tnca:0', dtype=torch.float16)
    return [arg0_1, arg1_1, arg2_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
