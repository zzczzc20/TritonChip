    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (2 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
    .li       s9, #1056964608
    v.splat      v0, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s9, #1027024659
    v.splat      v1, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s9, #1061962282
    v.splat      v2, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s9, #3221225472
    v.splat      v3, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s9, #1069066811
    v.splat      v4, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s9, #1060205080
    v.splat      v5, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s9, #1065353216
    v.splat      v6, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v7, #0
tiles_1:
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s9, s1, s8
    // tile 1 of the iteration: lanes t0 + 128
    s.addi       s10, s8, #128
    s.add        s11, s1, s10
    s.shli       s10, s9, #1
    s.add        s9, s3, s10
    v.ld.h       v8, [s9, #0]
    v.ld.h       v9, [s9, #32]
    v.ld.h       v10, [s9, #64]
    v.ld.h       v11, [s9, #96]
    v.ld.h       v12, [s9, #128]
    v.ld.h       v13, [s9, #160]
    v.ld.h       v14, [s9, #192]
    v.ld.h       v15, [s9, #224]
    s.shli       s9, s11, #1
    s.add        s11, s3, s9
    v.ld.h       v16, [s11, #0]
    v.ld.h       v17, [s11, #32]
    v.ld.h       v18, [s11, #64]
    v.ld.h       v19, [s11, #96]
    v.ld.h       v20, [s11, #128]
    v.ld.h       v21, [s11, #160]
    v.ld.h       v22, [s11, #192]
    v.ld.h       v23, [s11, #224]
    vf.cvt.f16.f32 v24, v8
    vf.cvt.f16.f32 v8, v9
    vf.cvt.f16.f32 v9, v10
    vf.cvt.f16.f32 v10, v11
    vf.cvt.f16.f32 v11, v12
    vf.cvt.f16.f32 v12, v13
    vf.cvt.f16.f32 v13, v14
    vf.cvt.f16.f32 v14, v15
    vf.mul       v15, v24, v0
    vf.mul       v25, v8, v0
    vf.mul       v26, v9, v0
    vf.mul       v27, v10, v0
    vf.mul       v28, v11, v0
    vf.mul       v29, v12, v0
    vf.mul       v30, v13, v0
    vf.mul       v31, v14, v0
    vf.mul       v32, v24, v24
    vf.mul       v33, v8, v8
    vf.mul       v34, v9, v9
    vf.mul       v35, v10, v10
    vf.mul       v36, v11, v11
    vf.mul       v37, v12, v12
    vf.mul       v38, v13, v13
    vf.mul       v39, v14, v14
    vf.mul       v40, v32, v24
    vf.mul       v32, v33, v8
    vf.mul       v33, v34, v9
    vf.mul       v34, v35, v10
    vf.mul       v35, v36, v11
    vf.mul       v36, v37, v12
    vf.mul       v37, v38, v13
    vf.mul       v38, v39, v14
    vf.mul       v39, v40, v1
    vf.mul       v40, v32, v1
    vf.mul       v32, v33, v1
    vf.mul       v33, v34, v1
    vf.mul       v34, v35, v1
    vf.mul       v35, v36, v1
    vf.mul       v36, v37, v1
    vf.mul       v37, v38, v1
    vf.add       v38, v24, v39
    vf.add       v24, v8, v40
    vf.add       v8, v9, v32
    vf.add       v9, v10, v33
    vf.add       v10, v11, v34
    vf.add       v11, v12, v35
    vf.add       v12, v13, v36
    vf.add       v13, v14, v37
    vf.mul       v14, v38, v2
    vf.mul       v32, v24, v2
    vf.mul       v24, v8, v2
    vf.mul       v8, v9, v2
    vf.mul       v9, v10, v2
    vf.mul       v10, v11, v2
    vf.mul       v11, v12, v2
    vf.mul       v12, v13, v2
    vf.abs       v13, v14
    vf.abs       v33, v32
    vf.abs       v34, v24
    vf.abs       v35, v8
    vf.abs       v36, v9
    vf.abs       v37, v10
    vf.abs       v38, v11
    vf.abs       v39, v12
    vf.mul       v40, v13, v3
    vf.mul       v13, v33, v3
    vf.mul       v33, v34, v3
    vf.mul       v34, v35, v3
    vf.mul       v35, v36, v3
    vf.mul       v36, v37, v3
    vf.mul       v37, v38, v3
    vf.mul       v38, v39, v3
    vf.mul       v39, v40, v4
    vf.fms       v41, v40, v4, v39               // the exact rounding error of x*log2(e)
    v.exp2.approx v40, v39                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v39, v41, v5
    vf.fma       v41, v40, v39, v40              // 2**t * 2**d
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v40
    vf.mul       v40, v13, v4
    vf.fms       v41, v13, v4, v40               // the exact rounding error of x*log2(e)
    v.exp2.approx v13, v40                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v40, v41, v5
    vf.fma       v41, v13, v40, v13              // 2**t * 2**d
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v40, v41, v13
    vf.mul       v13, v33, v4
    vf.fms       v41, v33, v4, v13               // the exact rounding error of x*log2(e)
    v.exp2.approx v33, v13                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v13, v41, v5
    vf.fma       v41, v33, v13, v33              // 2**t * 2**d
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v13, v41, v33
    vf.mul       v33, v34, v4
    vf.fms       v41, v34, v4, v33               // the exact rounding error of x*log2(e)
    v.exp2.approx v34, v33                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v33, v41, v5
    vf.fma       v41, v34, v33, v34              // 2**t * 2**d
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v33, v41, v34
    vf.mul       v34, v35, v4
    vf.fms       v41, v35, v4, v34               // the exact rounding error of x*log2(e)
    v.exp2.approx v35, v34                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v34, v41, v5
    vf.fma       v41, v35, v34, v35              // 2**t * 2**d
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v34, v41, v35
    vf.mul       v35, v36, v4
    vf.fms       v41, v36, v4, v35               // the exact rounding error of x*log2(e)
    v.exp2.approx v36, v35                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v35, v41, v5
    vf.fma       v41, v36, v35, v36              // 2**t * 2**d
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v35, v41, v36
    vf.mul       v36, v37, v4
    vf.fms       v41, v37, v4, v36               // the exact rounding error of x*log2(e)
    v.exp2.approx v37, v36                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v36, v41, v5
    vf.fma       v41, v37, v36, v37              // 2**t * 2**d
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v36, v41, v37
    vf.mul       v37, v38, v4
    vf.fms       v41, v38, v4, v37               // the exact rounding error of x*log2(e)
    v.exp2.approx v38, v37                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v37, v41, v5
    vf.fma       v41, v38, v37, v38              // 2**t * 2**d
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v37, v41, v38
    vf.sub       v38, v6, v39
    vf.sub       v41, v6, v40
    vf.sub       v42, v6, v13
    vf.sub       v43, v6, v33
    vf.sub       v44, v6, v34
    vf.sub       v45, v6, v35
    vf.sub       v46, v6, v36
    vf.sub       v47, v6, v37
    vf.add       v48, v39, v6
    vf.add       v39, v40, v6
    vf.add       v40, v13, v6
    vf.add       v13, v33, v6
    vf.add       v33, v34, v6
    vf.add       v34, v35, v6
    vf.add       v35, v36, v6
    vf.add       v36, v37, v6
    v.rcp.approx v37, v48                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v49, v48, v37, v6
    vf.fms       v48, v37, v49, v37
    vf.neg       v49, v48                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v49, v49
    @p1 v.sel        v48, v49, v37
    vf.mul       v37, v38, v48                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v38, v39                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v48, v39, v38, v6
    vf.fms       v39, v38, v48, v38
    vf.neg       v48, v39                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v48, v48
    @p1 v.sel        v39, v48, v38
    vf.mul       v38, v41, v39                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v39, v40                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v41, v40, v39, v6
    vf.fms       v40, v39, v41, v39
    vf.neg       v41, v40                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v40, v41, v39
    vf.mul       v39, v42, v40                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v40, v13                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v41, v13, v40, v6
    vf.fms       v13, v40, v41, v40
    vf.neg       v41, v13                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v13, v41, v40
    vf.mul       v40, v43, v13                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v13, v33                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v41, v33, v13, v6
    vf.fms       v33, v13, v41, v13
    vf.neg       v41, v33                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v33, v41, v13
    vf.mul       v13, v44, v33                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v33, v34                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v41, v34, v33, v6
    vf.fms       v34, v33, v41, v33
    vf.neg       v41, v34                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v34, v41, v33
    vf.mul       v33, v45, v34                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v34, v35                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v41, v35, v34, v6
    vf.fms       v35, v34, v41, v34
    vf.neg       v41, v35                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v35, v41, v34
    vf.mul       v34, v46, v35                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v35, v36                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v41, v36, v35, v6
    vf.fms       v36, v35, v41, v35
    vf.neg       v41, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v36, v41, v35
    vf.mul       v35, v47, v36                   // a/y as a refined reciprocal (ISA has no divide)
    vf.neg       v36, v37
    vf.neg       v41, v38
    vf.neg       v42, v39
    vf.neg       v43, v40
    vf.neg       v44, v13
    vf.neg       v45, v33
    vf.neg       v46, v34
    vf.neg       v47, v35
    vf.cmp.lt    p1, v14, v7
    @p1 v.sel        v14, v36, v37
    vf.cmp.lt    p1, v32, v7
    @p1 v.sel        v32, v41, v38
    vf.cmp.lt    p1, v24, v7
    @p1 v.sel        v24, v42, v39
    vf.cmp.lt    p1, v8, v7
    @p1 v.sel        v8, v43, v40
    vf.cmp.lt    p1, v9, v7
    @p1 v.sel        v9, v44, v13
    vf.cmp.lt    p1, v10, v7
    @p1 v.sel        v10, v45, v33
    vf.cmp.lt    p1, v11, v7
    @p1 v.sel        v11, v46, v34
    vf.cmp.lt    p1, v12, v7
    @p1 v.sel        v12, v47, v35
    vf.add       v13, v14, v6
    vf.add       v14, v32, v6
    vf.add       v32, v24, v6
    vf.add       v24, v8, v6
    vf.add       v8, v9, v6
    vf.add       v9, v10, v6
    vf.add       v10, v11, v6
    vf.add       v11, v12, v6
    vf.mul       v12, v15, v13
    vf.mul       v13, v25, v14
    vf.mul       v14, v26, v32
    vf.mul       v15, v27, v24
    vf.mul       v24, v28, v8
    vf.mul       v8, v29, v9
    vf.mul       v9, v30, v10
    vf.mul       v10, v31, v11
    vf.cvt.f32.f16 v11, v12
    vf.cvt.f32.f16 v12, v13
    vf.cvt.f32.f16 v13, v14
    vf.cvt.f32.f16 v14, v15
    vf.cvt.f32.f16 v15, v24
    vf.cvt.f32.f16 v24, v8
    vf.cvt.f32.f16 v8, v9
    vf.cvt.f32.f16 v9, v10
    s.add        s11, s7, s10
    v.st.h       [s11, #0], v11
    v.st.h       [s11, #32], v12
    v.st.h       [s11, #64], v13
    v.st.h       [s11, #96], v14
    v.st.h       [s11, #128], v15
    v.st.h       [s11, #160], v24
    v.st.h       [s11, #192], v8
    v.st.h       [s11, #224], v9
    vf.cvt.f16.f32 v8, v16
    vf.cvt.f16.f32 v9, v17
    vf.cvt.f16.f32 v10, v18
    vf.cvt.f16.f32 v11, v19
    vf.cvt.f16.f32 v12, v20
    vf.cvt.f16.f32 v13, v21
    vf.cvt.f16.f32 v14, v22
    vf.cvt.f16.f32 v15, v23
    vf.mul       v16, v8, v0
    vf.mul       v17, v9, v0
    vf.mul       v18, v10, v0
    vf.mul       v19, v11, v0
    vf.mul       v20, v12, v0
    vf.mul       v21, v13, v0
    vf.mul       v22, v14, v0
    vf.mul       v23, v15, v0
    vf.mul       v24, v8, v8
    vf.mul       v25, v9, v9
    vf.mul       v26, v10, v10
    vf.mul       v27, v11, v11
    vf.mul       v28, v12, v12
    vf.mul       v29, v13, v13
    vf.mul       v30, v14, v14
    vf.mul       v31, v15, v15
    vf.mul       v32, v24, v8
    vf.mul       v24, v25, v9
    vf.mul       v25, v26, v10
    vf.mul       v26, v27, v11
    vf.mul       v27, v28, v12
    vf.mul       v28, v29, v13
    vf.mul       v29, v30, v14
    vf.mul       v30, v31, v15
    vf.mul       v31, v32, v1
    vf.mul       v32, v24, v1
    vf.mul       v24, v25, v1
    vf.mul       v25, v26, v1
    vf.mul       v26, v27, v1
    vf.mul       v27, v28, v1
    vf.mul       v28, v29, v1
    vf.mul       v29, v30, v1
    vf.add       v30, v8, v31
    vf.add       v8, v9, v32
    vf.add       v9, v10, v24
    vf.add       v10, v11, v25
    vf.add       v11, v12, v26
    vf.add       v12, v13, v27
    vf.add       v13, v14, v28
    vf.add       v14, v15, v29
    vf.mul       v15, v30, v2
    vf.mul       v24, v8, v2
    vf.mul       v8, v9, v2
    vf.mul       v9, v10, v2
    vf.mul       v10, v11, v2
    vf.mul       v11, v12, v2
    vf.mul       v12, v13, v2
    vf.mul       v13, v14, v2
    vf.abs       v14, v15
    vf.abs       v25, v24
    vf.abs       v26, v8
    vf.abs       v27, v9
    vf.abs       v28, v10
    vf.abs       v29, v11
    vf.abs       v30, v12
    vf.abs       v31, v13
    vf.mul       v32, v14, v3
    vf.mul       v14, v25, v3
    vf.mul       v25, v26, v3
    vf.mul       v26, v27, v3
    vf.mul       v27, v28, v3
    vf.mul       v28, v29, v3
    vf.mul       v29, v30, v3
    vf.mul       v30, v31, v3
    vf.mul       v31, v32, v4
    vf.fms       v33, v32, v4, v31               // the exact rounding error of x*log2(e)
    v.exp2.approx v32, v31                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v31, v33, v5
    vf.fma       v33, v32, v31, v32              // 2**t * 2**d
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v31, v33, v32
    vf.mul       v32, v14, v4
    vf.fms       v33, v14, v4, v32               // the exact rounding error of x*log2(e)
    v.exp2.approx v14, v32                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v32, v33, v5
    vf.fma       v33, v14, v32, v14              // 2**t * 2**d
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v32, v33, v14
    vf.mul       v14, v25, v4
    vf.fms       v33, v25, v4, v14               // the exact rounding error of x*log2(e)
    v.exp2.approx v25, v14                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v14, v33, v5
    vf.fma       v33, v25, v14, v25              // 2**t * 2**d
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v14, v33, v25
    vf.mul       v25, v26, v4
    vf.fms       v33, v26, v4, v25               // the exact rounding error of x*log2(e)
    v.exp2.approx v26, v25                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v25, v33, v5
    vf.fma       v33, v26, v25, v26              // 2**t * 2**d
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v25, v33, v26
    vf.mul       v26, v27, v4
    vf.fms       v33, v27, v4, v26               // the exact rounding error of x*log2(e)
    v.exp2.approx v27, v26                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v26, v33, v5
    vf.fma       v33, v27, v26, v27              // 2**t * 2**d
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v26, v33, v27
    vf.mul       v27, v28, v4
    vf.fms       v33, v28, v4, v27               // the exact rounding error of x*log2(e)
    v.exp2.approx v28, v27                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v27, v33, v5
    vf.fma       v33, v28, v27, v28              // 2**t * 2**d
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v27, v33, v28
    vf.mul       v28, v29, v4
    vf.fms       v33, v29, v4, v28               // the exact rounding error of x*log2(e)
    v.exp2.approx v29, v28                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v28, v33, v5
    vf.fma       v33, v29, v28, v29              // 2**t * 2**d
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v28, v33, v29
    vf.mul       v29, v30, v4
    vf.fms       v33, v30, v4, v29               // the exact rounding error of x*log2(e)
    v.exp2.approx v30, v29                       // ISA 8.8: <= 2**-22 relative
    vf.mul       v29, v33, v5
    vf.fma       v33, v30, v29, v30              // 2**t * 2**d
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v29, v33, v30
    vf.sub       v30, v6, v31
    vf.sub       v33, v6, v32
    vf.sub       v34, v6, v14
    vf.sub       v35, v6, v25
    vf.sub       v36, v6, v26
    vf.sub       v37, v6, v27
    vf.sub       v38, v6, v28
    vf.sub       v39, v6, v29
    vf.add       v40, v31, v6
    vf.add       v31, v32, v6
    vf.add       v32, v14, v6
    vf.add       v14, v25, v6
    vf.add       v25, v26, v6
    vf.add       v26, v27, v6
    vf.add       v27, v28, v6
    vf.add       v28, v29, v6
    v.rcp.approx v29, v40                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v41, v40, v29, v6
    vf.fms       v40, v29, v41, v29
    vf.neg       v41, v40                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v40, v41, v29
    vf.mul       v29, v30, v40                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v30, v31                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v40, v31, v30, v6
    vf.fms       v31, v30, v40, v30
    vf.neg       v40, v31                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v31, v40, v30
    vf.mul       v30, v33, v31                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v31, v32                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v33, v32, v31, v6
    vf.fms       v32, v31, v33, v31
    vf.neg       v33, v32                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v32, v33, v31
    vf.mul       v31, v34, v32                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v32, v14                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v33, v14, v32, v6
    vf.fms       v14, v32, v33, v32
    vf.neg       v33, v14                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v14, v33, v32
    vf.mul       v32, v35, v14                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v14, v25                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v33, v25, v14, v6
    vf.fms       v25, v14, v33, v14
    vf.neg       v33, v25                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v25, v33, v14
    vf.mul       v14, v36, v25                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v25, v26                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v33, v26, v25, v6
    vf.fms       v26, v25, v33, v25
    vf.neg       v33, v26                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v26, v33, v25
    vf.mul       v25, v37, v26                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v26, v27                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v33, v27, v26, v6
    vf.fms       v27, v26, v33, v26
    vf.neg       v33, v27                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v27, v33, v26
    vf.mul       v26, v38, v27                   // a/y as a refined reciprocal (ISA has no divide)
    v.rcp.approx v27, v28                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v33, v28, v27, v6
    vf.fms       v28, v27, v33, v27
    vf.neg       v33, v28                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v33, v33
    @p1 v.sel        v28, v33, v27
    vf.mul       v27, v39, v28                   // a/y as a refined reciprocal (ISA has no divide)
    vf.neg       v28, v29
    vf.neg       v33, v30
    vf.neg       v34, v31
    vf.neg       v35, v32
    vf.neg       v36, v14
    vf.neg       v37, v25
    vf.neg       v38, v26
    vf.neg       v39, v27
    vf.cmp.lt    p1, v15, v7
    @p1 v.sel        v15, v28, v29
    vf.cmp.lt    p1, v24, v7
    @p1 v.sel        v24, v33, v30
    vf.cmp.lt    p1, v8, v7
    @p1 v.sel        v8, v34, v31
    vf.cmp.lt    p1, v9, v7
    @p1 v.sel        v9, v35, v32
    vf.cmp.lt    p1, v10, v7
    @p1 v.sel        v10, v36, v14
    vf.cmp.lt    p1, v11, v7
    @p1 v.sel        v11, v37, v25
    vf.cmp.lt    p1, v12, v7
    @p1 v.sel        v12, v38, v26
    vf.cmp.lt    p1, v13, v7
    @p1 v.sel        v13, v39, v27
    vf.add       v14, v15, v6
    vf.add       v15, v24, v6
    vf.add       v24, v8, v6
    vf.add       v8, v9, v6
    vf.add       v9, v10, v6
    vf.add       v10, v11, v6
    vf.add       v11, v12, v6
    vf.add       v12, v13, v6
    vf.mul       v13, v16, v14
    vf.mul       v14, v17, v15
    vf.mul       v15, v18, v24
    vf.mul       v16, v19, v8
    vf.mul       v8, v20, v9
    vf.mul       v9, v21, v10
    vf.mul       v10, v22, v11
    vf.mul       v11, v23, v12
    vf.cvt.f32.f16 v12, v13
    vf.cvt.f32.f16 v13, v14
    vf.cvt.f32.f16 v14, v15
    vf.cvt.f32.f16 v15, v16
    vf.cvt.f32.f16 v16, v8
    vf.cvt.f32.f16 v8, v9
    vf.cvt.f32.f16 v9, v10
    vf.cvt.f32.f16 v10, v11
    s.add        s10, s7, s9
    v.st.h       [s10, #0], v12
    v.st.h       [s10, #32], v13
    v.st.h       [s10, #64], v14
    v.st.h       [s10, #96], v15
    v.st.h       [s10, #128], v16
    v.st.h       [s10, #160], v8
    v.st.h       [s10, #192], v9
    v.st.h       [s10, #224], v10
    s.addi       s8, s8, #256
    s.cmp.lt     s9, s8, s2
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
