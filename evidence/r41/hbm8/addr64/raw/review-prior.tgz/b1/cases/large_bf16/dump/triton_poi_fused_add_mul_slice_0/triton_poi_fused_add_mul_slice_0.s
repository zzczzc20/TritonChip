    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    .li       s4, #1207926784
    v.splat      v2, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #1073741824
    v.splat      v3, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v4, v1, v0
    .li       s4, #1065353216
    v.splat      v0, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    v.add        v1, v4, v2
    v.ld.gather.h v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v1, v2
    s.ld.d       s2, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    vf.mul       v2, v1, v3
    vf.add       v1, v2, v0
    s.add        s1, s2, s4                      // &out_ptr0[...]
    vf.cvt.f32.bf16 v0, v1
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
