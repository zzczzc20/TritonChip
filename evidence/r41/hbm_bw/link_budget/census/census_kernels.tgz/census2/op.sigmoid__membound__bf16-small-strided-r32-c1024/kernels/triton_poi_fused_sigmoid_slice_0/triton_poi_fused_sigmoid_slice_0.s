    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    v.movi       v2, #2
    .li       s4, #1069066811
    v.splat      v3, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v4, v1, v0
    .li       s4, #1060205080
    v.splat      v0, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #1065353216
    v.splat      v1, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mul        v5, v4, v2
    .li       s4, #1065353216
    v.splat      v2, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    v.ld.gather.h v4, [s3, v5]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v5, v4
    s.ld.d       s2, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    vf.neg       v4, v5
    vf.mul       v5, v4, v3
    s.add        s1, s2, s4                      // &out_ptr0[...]
    v.exp2.approx v6, v5                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v7, v4, v3, v5                  // the exact rounding error of x*log2(e)
    vf.mul       v3, v7, v0
    vf.fma       v0, v6, v3, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v3, v0, v6
    vf.add       v0, v3, v1
    v.rcp.approx v3, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v4, v0, v3, v2
    vf.fms       v0, v3, v4, v3
    vf.neg       v2, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v3
    vf.mul       v2, v1, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.bf16 v0, v2
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
