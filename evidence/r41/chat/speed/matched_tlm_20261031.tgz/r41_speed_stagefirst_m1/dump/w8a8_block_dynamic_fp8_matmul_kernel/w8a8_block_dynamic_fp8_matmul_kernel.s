    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #32]                   // N: i32 at arg_base+32
    s.movz       s4, #0
    s.movz       s5, #128
    s.rdspecial  s6, pid.x
    s.cmp.lt     s7, s5, s4
    s.movz       s8, #8
    s.sub        s9, s4, s7
    s.rdspecial  s7, pid.y
    s.movz       s10, #1
    s.xor        s11, s5, s9
    s.addi       s12, s4, #0
    s.add        s13, s3, s2
    s.ld.d       s14, [s1, #0]                   // A: device_ptr64 at arg_base+0
    s.cmp.lt     s15, s13, s4
    s.sub        s16, s11, s9
    s.sub        s11, s4, s15
    s.addi       s15, s4, #0
    s.xor        s16, s13, s11
    s.xor        s13, s11, s9
    s.sub        s9, s16, s11
    s.lshri      s11, s9, #7
    s.xor        s16, s11, s13
    s.muli       s17, s11, #128
    s.sub        s11, s16, s13
    s.ld.d       s13, [s1, #8]                   // B: device_ptr64 at arg_base+8
    s.mul        s16, s6, s11
    s.mul        s6, s11, s8
    s.sub        s11, s9, s17
    s.add        s9, s16, s7
    s.cmp.lt     s7, s6, s4
    s.cmp.lt     s11, s9, s4
    s.sub        s16, s4, s7
    s.sub        s7, s4, s11
    s.xor        s11, s6, s16
    s.xor        s17, s9, s7
    s.sub        s18, s11, s16
    s.sub        s11, s17, s7
    s.cmp.eq     s17, s18, s10
    s.ld.d       s19, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.ld.d       s20, [s1, #24]                  // Bs: device_ptr64 at arg_base+24
    s.ld.sw      s21, [s1, #40]                  // K: i32 at arg_base+40
    s.ld.sw      s22, [s1, #56]                  // stride_bn: i32 at arg_base+56
    s.ld.sw      s23, [s1, #64]                  // stride_cm: i32 at arg_base+64
    s.ld.sw      s24, [s1, #72]                  // stride_bs_n: i32 at arg_base+72
    s.mov        s12, s11
    br.nz        s17, sdiv_done_1
    s.movz       s1, #0
    s.movz       s17, #31
    s.mov        s12, s1
    s.addi       s1, s17, #0
sdiv_2:
    s.lshr       s17, s11, s1
    s.shli       s25, s15, #1
    s.andi       s26, s17, #1
    s.shl        s17, s10, s1
    s.or         s27, s25, s26
    s.subi       s25, s1, #1
    s.cmp.geu    s26, s27, s18
    s.sub        s28, s4, s26
    s.and        s26, s18, s28
    s.and        s29, s17, s28
    s.sub        s17, s27, s26
    s.or         s26, s12, s29
    s.mov        s15, s17
    s.mov        s12, s26
    s.mov        s1, s25
    s.cmp.ge     s17, s1, s4
    br.nz        s17, sdiv_2
sdiv_done_1:
    s.xor        s1, s7, s16
    s.movz       s4, #0
    s.xor        s7, s12, s1
    s.cmp.lt     s11, s6, s4
    s.sub        s12, s7, s1
    s.cmp.lt     s1, s9, s4
    s.sub        s7, s4, s11
    s.mul        s11, s12, s8
    s.sub        s12, s4, s1
    s.xor        s1, s6, s7
    s.xor        s6, s9, s12
    s.sub        s9, s1, s7
    s.sub        s1, s10, s11
    s.sub        s7, s6, s12
    s.addi       s6, s4, #0
    s.cmp.eq     s15, s9, s10
    s.min.s      s16, s1, s8
    s.addi       s1, s4, #0
    s.mov        s6, s7
    br.nz        s15, sdiv_done_3
    s.movz       s8, #0
    s.movz       s15, #31
    s.mov        s6, s8
    s.addi       s8, s15, #0
sdiv_4:
    s.lshr       s15, s7, s8
    s.shli       s17, s1, #1
    s.andi       s18, s15, #1
    s.movz       s15, #1
    s.or         s25, s17, s18
    s.shl        s17, s15, s8
    s.cmp.geu    s15, s25, s9
    s.subi       s18, s8, #1
    s.sub        s26, s4, s15
    s.and        s15, s9, s26
    s.and        s27, s17, s26
    s.sub        s17, s25, s15
    s.or         s15, s6, s27
    s.mov        s1, s17
    s.mov        s6, s15
    s.mov        s8, s18
    s.cmp.ge     s15, s8, s4
    br.nz        s15, sdiv_4
sdiv_done_3:
    s.xor        s6, s1, s12
    s.cmp.lt     s1, s16, s4
    s.sub        s7, s6, s12
    s.sub        s6, s4, s1
    s.cmp.lt     s1, s7, s4
    s.xor        s8, s16, s6
    s.sub        s9, s4, s1
    s.sub        s1, s8, s6
    s.xor        s6, s7, s9
    s.movz       s8, #1
    s.sub        s12, s6, s9
    s.addi       s6, s4, #0
    s.cmp.eq     s15, s1, s8
    s.addi       s17, s4, #0
    s.mov        s6, s12
    br.nz        s15, sdiv_done_5
    s.movz       s4, #0
    s.movz       s15, #31
    s.mov        s6, s4
    s.addi       s4, s15, #0
sdiv_6:
    s.lshr       s15, s12, s4
    s.shli       s18, s17, #1
    s.andi       s25, s15, #1
    s.movz       s15, #0
    s.or         s26, s18, s25
    s.shl        s18, s8, s4
    s.cmp.geu    s25, s26, s1
    s.subi       s27, s4, #1
    s.sub        s28, s15, s25
    s.and        s25, s1, s28
    s.and        s29, s18, s28
    s.sub        s18, s26, s25
    s.or         s25, s6, s29
    s.mov        s17, s18
    s.mov        s6, s25
    s.mov        s4, s27
    s.cmp.ge     s18, s4, s15
    br.nz        s18, sdiv_6
sdiv_done_5:
    s.movz       s1, #0
    s.xor        s4, s17, s9
    s.cmp.lt     s6, s16, s1
    s.cmp.lt     s12, s7, s1
    s.sub        s15, s1, s6
    s.sub        s6, s1, s12
    s.xor        s12, s16, s15
    s.xor        s16, s7, s6
    s.sub        s7, s12, s15
    s.sub        s12, s4, s9
    s.sub        s4, s16, s6
    s.addi       s9, s1, #0
    s.cmp.eq     s16, s7, s8
    s.add        s8, s11, s12
    s.addi       s11, s1, #0
    s.mov        s9, s4
    br.nz        s16, sdiv_done_7
    s.movz       s12, #0
    s.movz       s16, #31
    s.mov        s9, s12
    s.addi       s12, s16, #0
sdiv_8:
    s.lshr       s16, s4, s12
    s.shli       s17, s11, #1
    s.andi       s18, s16, #1
    s.movz       s16, #1
    s.or         s25, s17, s18
    s.shl        s17, s16, s12
    s.cmp.geu    s16, s25, s7
    s.subi       s18, s12, #1
    s.sub        s26, s1, s16
    s.and        s16, s7, s26
    s.and        s27, s17, s26
    s.sub        s17, s25, s16
    s.or         s16, s9, s27
    s.mov        s11, s17
    s.mov        s9, s16
    s.mov        s12, s18
    s.cmp.ge     s16, s12, s1
    br.nz        s16, sdiv_8
sdiv_done_7:
    s.xor        s1, s6, s15
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s4, s9, s1
    v.movi       v1, #16
    s.sub        s6, s4, s1
    v.movi       v2, #32
    s.mul        s1, s6, s5
    v.movi       v3, #48
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #64
    v.movi       v6, #80
    v.splat      v7, s1
    v.movi       v8, #96
    v.iota       v9                              // arange(0, VLEN)
    v.movi       v10, #112
    v.add        v11, v7, v0
    v.splat      v12, s3
    v.movi       v13, #0
    v.add        v14, v0, v1
    v.add        v1, v0, v2
    v.add        v2, v0, v3
    v.add        v0, v4, v5
    v.add        v3, v4, v6
    v.add        v5, v4, v8
    v.add        v4, v9, v10
    v.sub        v6, v13, v11
    v.sub        v8, v13, v12
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v12, v13
    v.add        v9, v7, v14
    v.add        v10, v7, v1
    v.add        v1, v7, v2
    v.add        v2, v7, v0
    v.add        v0, v7, v3
    v.add        v3, v7, v5
    v.add        v5, v7, v4
    v.movi       v4, #1
    @p1 v.sel        v7, v6, v11
    @p2 v.sel        v6, v8, v12
    v.movi       v8, #0
    v.movi       v11, #0
    s.movz       s4, #31
idiv_9:
    v.splat      v14, s4
    v.shl        v15, v11, v4
    v.cmp.lt     p2, v11, v13
    v.lshr       v16, v7, v14
    v.shl        v17, v4, v14
    s.subi       s6, s4, #1
    v.and        v14, v16, v4
    s.movz       s7, #0
    v.or         v16, v15, v14
    v.cmp.geu    p3, v16, v6
    p.or         p4, p2, p3
    v.sub        v14, v16, v6
    @p4 v.sel        v15, v17, v13
    @p4 v.sel        v17, v14, v16
    v.or         v14, v8, v15
    v.mov        v11, v17
    v.mov        v8, v14
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_9
    v.movi       v4, #0
    v.sub        v6, v13, v11
    v.movi       v7, #1
    v.sub        v8, v4, v9
    v.sub        v13, v4, v12
    v.cmp.lt     p2, v9, v4
    v.cmp.lt     p3, v12, v4
    @p1 v.sel        v14, v6, v11
    @p2 v.sel        v6, v8, v9
    @p3 v.sel        v8, v13, v12
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s4, #31
idiv_10:
    v.splat      v13, s4
    v.shl        v15, v11, v7
    v.cmp.lt     p1, v11, v4
    v.lshr       v16, v6, v13
    v.shl        v17, v7, v13
    s.subi       s6, s4, #1
    v.and        v13, v16, v7
    v.or         v16, v15, v13
    v.cmp.geu    p3, v16, v8
    p.or         p4, p1, p3
    v.sub        v13, v16, v8
    @p4 v.sel        v15, v17, v4
    @p4 v.sel        v17, v13, v16
    v.or         v13, v9, v15
    v.mov        v11, v17
    v.mov        v9, v13
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_10
    v.movi       v6, #0
    v.sub        v7, v4, v11
    v.movi       v4, #1
    v.sub        v8, v6, v10
    v.sub        v9, v6, v12
    v.cmp.lt     p1, v10, v6
    v.cmp.lt     p3, v12, v6
    @p2 v.sel        v13, v7, v11
    @p1 v.sel        v7, v8, v10
    @p3 v.sel        v8, v9, v12
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s4, #31
idiv_11:
    v.splat      v11, s4
    v.shl        v15, v10, v4
    v.cmp.lt     p2, v10, v6
    v.lshr       v16, v7, v11
    v.shl        v17, v4, v11
    s.subi       s6, s4, #1
    v.and        v11, v16, v4
    s.movz       s7, #0
    v.or         v16, v15, v11
    v.cmp.geu    p3, v16, v8
    p.or         p4, p2, p3
    v.sub        v11, v16, v8
    @p4 v.sel        v15, v17, v6
    @p4 v.sel        v17, v11, v16
    v.or         v11, v9, v15
    v.mov        v10, v17
    v.mov        v9, v11
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_11
    v.movi       v4, #0
    v.sub        v7, v6, v10
    v.movi       v6, #1
    v.sub        v8, v4, v1
    v.sub        v9, v4, v12
    v.cmp.lt     p2, v1, v4
    v.cmp.lt     p3, v12, v4
    @p1 v.sel        v11, v7, v10
    @p2 v.sel        v7, v8, v1
    @p3 v.sel        v1, v9, v12
    v.movi       v8, #0
    v.movi       v9, #0
    s.movz       s4, #31
idiv_12:
    v.splat      v10, s4
    v.shl        v15, v9, v6
    v.cmp.lt     p1, v9, v4
    v.lshr       v16, v7, v10
    v.shl        v17, v6, v10
    s.subi       s6, s4, #1
    v.and        v10, v16, v6
    v.or         v16, v15, v10
    v.cmp.geu    p3, v16, v1
    p.or         p4, p1, p3
    v.sub        v10, v16, v1
    @p4 v.sel        v15, v17, v4
    @p4 v.sel        v17, v10, v16
    v.or         v10, v8, v15
    v.mov        v9, v17
    v.mov        v8, v10
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_12
    v.movi       v1, #0
    v.sub        v6, v4, v9
    v.movi       v4, #1
    v.sub        v7, v1, v2
    v.sub        v8, v1, v12
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p3, v12, v1
    @p2 v.sel        v10, v6, v9
    @p1 v.sel        v6, v7, v2
    @p3 v.sel        v2, v8, v12
    v.movi       v7, #0
    v.movi       v8, #0
    s.movz       s4, #31
idiv_13:
    v.splat      v9, s4
    v.shl        v15, v8, v4
    v.cmp.lt     p2, v8, v1
    v.lshr       v16, v6, v9
    v.shl        v17, v4, v9
    s.subi       s6, s4, #1
    v.and        v9, v16, v4
    s.movz       s7, #0
    v.or         v16, v15, v9
    v.cmp.geu    p3, v16, v2
    p.or         p4, p2, p3
    v.sub        v9, v16, v2
    @p4 v.sel        v15, v17, v1
    @p4 v.sel        v17, v9, v16
    v.or         v9, v7, v15
    v.mov        v8, v17
    v.mov        v7, v9
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_13
    v.movi       v2, #0
    v.sub        v4, v1, v8
    v.movi       v1, #1
    v.sub        v6, v2, v0
    v.sub        v7, v2, v12
    v.cmp.lt     p2, v0, v2
    v.cmp.lt     p3, v12, v2
    @p1 v.sel        v9, v4, v8
    @p2 v.sel        v4, v6, v0
    @p3 v.sel        v0, v7, v12
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s4, #31
idiv_14:
    v.splat      v8, s4
    v.shl        v15, v7, v1
    v.cmp.lt     p1, v7, v2
    v.lshr       v16, v4, v8
    v.shl        v17, v1, v8
    s.subi       s6, s4, #1
    v.and        v8, v16, v1
    v.or         v16, v15, v8
    v.cmp.geu    p3, v16, v0
    p.or         p4, p1, p3
    v.sub        v8, v16, v0
    @p4 v.sel        v15, v17, v2
    @p4 v.sel        v17, v8, v16
    v.or         v8, v6, v15
    v.mov        v7, v17
    v.mov        v6, v8
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_14
    v.movi       v0, #0
    v.sub        v1, v2, v7
    v.movi       v2, #1
    v.sub        v4, v0, v3
    v.sub        v6, v0, v12
    v.cmp.lt     p1, v3, v0
    v.cmp.lt     p3, v12, v0
    @p2 v.sel        v8, v1, v7
    @p1 v.sel        v1, v4, v3
    @p3 v.sel        v3, v6, v12
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s4, #31
idiv_15:
    v.splat      v7, s4
    v.shl        v15, v6, v2
    v.cmp.lt     p2, v6, v0
    v.lshr       v16, v1, v7
    v.shl        v17, v2, v7
    s.subi       s6, s4, #1
    v.and        v7, v16, v2
    s.movz       s7, #0
    v.or         v16, v15, v7
    v.cmp.geu    p3, v16, v3
    p.or         p4, p2, p3
    v.sub        v7, v16, v3
    @p4 v.sel        v15, v17, v0
    @p4 v.sel        v17, v7, v16
    v.or         v7, v4, v15
    v.mov        v6, v17
    v.mov        v4, v7
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_15
    v.movi       v1, #0
    v.sub        v2, v0, v6
    v.movi       v0, #1
    v.sub        v3, v1, v5
    v.sub        v4, v1, v12
    v.cmp.lt     p2, v5, v1
    v.cmp.lt     p3, v12, v1
    @p1 v.sel        v7, v2, v6
    @p2 v.sel        v2, v3, v5
    @p3 v.sel        v3, v4, v12
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s4, #31
idiv_16:
    v.splat      v6, s4
    v.shl        v12, v5, v0
    v.cmp.lt     p1, v5, v1
    v.lshr       v15, v2, v6
    v.shl        v16, v0, v6
    s.subi       s6, s4, #1
    v.and        v6, v15, v0
    v.or         v15, v12, v6
    v.cmp.geu    p3, v15, v3
    p.or         p4, p1, p3
    v.sub        v6, v15, v3
    @p4 v.sel        v12, v16, v1
    @p4 v.sel        v16, v6, v15
    v.or         v6, v4, v12
    v.mov        v5, v16
    v.mov        v4, v6
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_16
    v.sub        v0, v1, v5
    v.movi       v1, #0
    v.movi       v2, #0
    @p2 v.sel        v3, v0, v5
    v.movi       v0, #0
    v.movi       v4, #0
    v.sub        v5, v1, v14
    v.sub        v6, v2, v13
    v.sub        v12, v0, v11
    v.cmp.lt     p1, v14, v1
    v.cmp.lt     p2, v13, v2
    v.cmp.lt     p3, v11, v0
    @p1 v.sel        v15, v5, v14
    v.movi       v5, #7
    @p2 v.sel        v16, v6, v13
    v.movi       v6, #7
    @p3 v.sel        v17, v12, v11
    v.movi       v12, #7
    v.lshr       v18, v15, v5
    v.lshr       v5, v16, v6
    v.lshr       v6, v17, v12
    v.movi       v12, #128
    v.sub        v15, v1, v18
    v.movi       v16, #128
    v.sub        v17, v2, v5
    v.movi       v19, #128
    v.sub        v20, v0, v6
    v.movi       v21, #128
    v.sub        v22, v1, v12
    @p1 v.sel        v23, v15, v18
    v.sub        v15, v2, v16
    @p2 v.sel        v18, v17, v5
    v.sub        v5, v0, v19
    @p3 v.sel        v17, v20, v6
    v.cmp.lt     p1, v12, v1
    v.cmp.lt     p2, v16, v2
    v.cmp.lt     p3, v19, v0
    s.movz       s4, #16
    s.movz       s6, #32
    s.movz       s7, #48
    s.movz       s9, #64
    v.sub        v0, v4, v10
    s.movz       s11, #80
    s.movz       s12, #96
    v.sub        v1, v4, v21
    s.movz       s15, #112
    v.movi       v2, #7
    v.movi       v6, #1
    v.movi       v6, #0
    @p1 v.sel        v20, v22, v12
    v.cmp.lt     p1, v10, v4
    v.sub        v12, v6, v9
    @p1 v.sel        v20, v0, v10
    v.movi       v0, #7
    v.movi       v22, #1
    v.lshr       v22, v20, v2
    v.movi       v2, #0
    @p2 v.sel        v20, v15, v16
    v.cmp.lt     p2, v9, v6
    v.sub        v15, v2, v8
    @p2 v.sel        v16, v12, v9
    v.movi       v12, #7
    v.movi       v20, #1
    v.lshr       v20, v16, v0
    v.movi       v0, #0
    @p3 v.sel        v16, v5, v19
    v.cmp.lt     p3, v8, v2
    v.sub        v5, v0, v7
    @p3 v.sel        v16, v15, v8
    v.movi       v15, #7
    v.movi       v19, #1
    v.lshr       v19, v16, v12
    v.sub        v12, v4, v22
    v.movi       v16, #1
    v.movi       v16, #1
    @p1 v.sel        v16, v12, v22
    v.cmp.lt     p1, v7, v0
    @p1 v.sel        v12, v5, v7
    v.movi       v5, #128
    v.movi       v22, #1
    v.lshr       v22, v12, v15
    v.sub        v12, v6, v20
    @p2 v.sel        v15, v12, v20
    v.movi       v12, #128
    v.cmp.lt     p2, v21, v4
    v.movi       v4, #0
    @p2 v.sel        v20, v1, v21
    v.movi       v1, #7
    v.sub        v20, v4, v3
    v.cmp.lt     p2, v3, v4
    v.movi       v21, #1
    @p2 v.sel        v21, v20, v3
    v.lshr       v20, v21, v1
    v.sub        v1, v2, v19
    @p3 v.sel        v21, v1, v19
    v.movi       v1, #128
    v.cmp.lt     p3, v5, v6
    v.sub        v19, v6, v5
    @p3 v.sel        v6, v19, v5
    s.add        s16, s21, s2
    s.movz       s2, #0
    v.sub        v5, v0, v22
    s.cmp.lt     s17, s16, s2
    v.movi       v6, #128
    s.sub        s18, s2, s17
    @p1 v.sel        v19, v5, v22
    v.sub        v5, v4, v20
    v.cmp.lt     p1, v12, v2
    s.xor        s17, s16, s18
    s.cmp.lt     s16, s5, s2
    v.sub        v22, v2, v12
    s.sub        s25, s17, s18
    s.sub        s17, s2, s16
    @p2 v.sel        v2, v5, v20
    v.sub        v5, v0, v1
    v.cmp.lt     p2, v1, v0
    v.sub        v0, v4, v6
    v.cmp.lt     p3, v6, v4
    v.splat      v4, s24
    @p1 v.sel        v20, v22, v12
    s.lshri      s16, s25, #7
    s.xor        s24, s18, s17
    s.muli       s18, s16, #128
    s.xor        s26, s5, s17
    s.xor        s27, s16, s24
    @p2 v.sel        v12, v5, v1
    @p3 v.sel        v1, v0, v6
    v.mul        v0, v23, v4
    v.mul        v1, v18, v4
    v.mul        v5, v17, v4
    v.mul        v6, v16, v4
    v.mul        v12, v15, v4
    v.mul        v15, v21, v4
    v.mul        v16, v19, v4
    v.mul        v17, v2, v4
    s.sub        s16, s26, s17
    s.sub        s16, s25, s18
    s.sub        s16, s27, s24
    s.addi       s17, s2, #0
    s.addi       s18, s2, #0
    s.addi       s24, s2, #0
    s.addi       s25, s20, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_25:
    s.cmp.ge     s20, s17, s16
    br.nz        s20, endfor_26
    s.mul        s20, s17, s5
    s.muli       s26, s18, #2
    v.iota       v2                              // arange(0, VLEN)
    s.rdspecial  s27, arg_base
    s.sub        s28, s21, s20
    s.add        s20, s14, s26
    s.add        s29, s2, s28                    // the tile origin
    s.ld.d       s30, [s27, #80]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v4, s29
    v.cmp.lt     p1, v2, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s20, #0]
    s.addi       s27, s30, #0
    s.add        s29, s14, s26
    s.addi       s31, s27, #64
    s.addi       s32, s27, #128
    s.addi       s33, s27, #192
    s.addi       s34, s27, #256
    s.addi       s35, s27, #320
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s27, #0], v18
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s20, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s27, #384
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s20, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s27, #448
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s20, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s27, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s20, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s34, #0], v18
    s.addi       s34, s27, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s20, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s35, #0], v18
    s.addi       s35, s27, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s20, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s27, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s20, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s27, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s20, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s27, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s20, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s34, #0], v18
    s.addi       s34, s27, #896
    s.addi       s36, s27, #960
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s20, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s35, #0], v18
    s.movz       s27, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s20, #0]
    s.add        s20, s27, s4                    // the tile origin
    s.add        s35, s27, s28                   // the tile origin
    v.splat      v18, s20
    s.addi       s20, s26, #32
    v.splat      v19, s35
    v.add        v20, v2, v18
    s.add        s27, s14, s20
    s.addi       s20, s30, #1024
    v.cmp.lt     p2, v20, v19
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s20, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s20, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s20, #192
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s34, #0], v18
    s.addi       s34, s20, #256
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    s.addi       s29, s20, #320
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s36, #0], v18
    fence.acq_rel.device
    s.addi       s35, s20, #384
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s20, #0], v18
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s20, #448
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s20, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s26, #32
    s.add        s36, s14, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s34, #0], v18
    s.addi       s33, s20, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s29, #0], v18
    s.addi       s29, s20, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s35, #0], v18
    s.addi       s34, s20, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s20, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s20, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    s.addi       s27, s20, #896
    s.addi       s35, s20, #960
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.movz       s20, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s29, #0], v18
    s.add        s29, s20, s6                    // the tile origin
    s.add        s33, s20, s28                   // the tile origin
    v.splat      v4, s29
    s.addi       s20, s26, #64
    v.splat      v18, s33
    v.add        v19, v2, v4
    s.add        s29, s14, s20
    s.addi       s20, s30, #2048
    v.cmp.lt     p1, v19, v18
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s34, #0], v18
    s.addi       s33, s20, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s20, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s20, #192
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s27, #0], v18
    s.addi       s27, s20, #256
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    s.addi       s34, s20, #320
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s35, #0], v18
    fence.acq_rel.device
    s.addi       s35, s20, #384
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s20, #0], v18
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s20, #448
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s20, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s26, #64
    s.add        s36, s14, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s27, #0], v18
    s.addi       s27, s20, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s34, #0], v18
    s.addi       s32, s20, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s35, #0], v18
    s.addi       s34, s20, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s20, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s20, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    s.addi       s29, s20, #896
    s.addi       s35, s20, #960
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s27, #0], v18
    s.movz       s20, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.add        s27, s20, s7                    // the tile origin
    s.add        s32, s20, s28                   // the tile origin
    v.splat      v4, s27
    s.addi       s20, s26, #96
    v.splat      v18, s32
    v.add        v19, v2, v4
    s.add        s27, s14, s20
    s.addi       s20, s30, #3072
    v.cmp.lt     p2, v19, v18
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s34, #0], v18
    s.addi       s32, s20, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s20, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s20, #192
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s29, #0], v18
    s.addi       s29, s20, #256
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s36, #0]
    s.addi       s34, s20, #320
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s35, #0], v18
    fence.acq_rel.device
    s.addi       s35, s20, #384
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s20, #0], v18
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s20, #448
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s20, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s26, #96
    s.add        s36, s14, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s29, #0], v18
    s.addi       s29, s20, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s34, #0], v18
    s.addi       s31, s20, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s35, #0], v18
    s.addi       s34, s20, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s20, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s20, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    s.addi       s27, s20, #896
    s.addi       s35, s20, #960
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s29, #0], v18
    s.movz       s20, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.add        s29, s20, s9                    // the tile origin
    s.add        s31, s20, s28                   // the tile origin
    v.splat      v4, s29
    s.addi       s20, s26, #128
    v.splat      v18, s31
    v.add        v19, v2, v4
    s.add        s29, s14, s20
    s.addi       s20, s30, #4096
    v.cmp.lt     p1, v19, v18
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s34, #0], v18
    s.addi       s31, s20, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s20, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s20, #192
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s27, #0], v18
    s.addi       s27, s20, #256
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    s.addi       s34, s20, #320
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s35, #0], v18
    fence.acq_rel.device
    s.addi       s35, s20, #384
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s20, #0], v18
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s20, #448
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s20, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s26, #128
    s.add        s36, s14, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s27, #0], v18
    s.addi       s27, s20, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s34, #0], v18
    s.addi       s33, s20, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s35, #0], v18
    s.addi       s34, s20, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s20, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s20, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    s.addi       s29, s20, #896
    s.addi       s35, s20, #960
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s27, #0], v18
    s.movz       s20, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.add        s27, s20, s11                   // the tile origin
    s.add        s33, s20, s28                   // the tile origin
    v.splat      v4, s27
    s.addi       s20, s26, #160
    v.splat      v18, s33
    v.add        v19, v2, v4
    s.add        s27, s14, s20
    s.addi       s20, s30, #5120
    v.cmp.lt     p2, v19, v18
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s34, #0], v18
    s.addi       s33, s20, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s20, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s20, #192
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s29, #0], v18
    s.addi       s29, s20, #256
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s36, #0]
    s.addi       s34, s20, #320
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s35, #0], v18
    fence.acq_rel.device
    s.addi       s35, s20, #384
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s20, #0], v18
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s20, #448
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s20, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s26, #160
    s.add        s36, s14, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s29, #0], v18
    s.addi       s29, s20, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s34, #0], v18
    s.addi       s32, s20, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s35, #0], v18
    s.addi       s34, s20, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s20, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s20, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s27, #0]
    s.addi       s27, s20, #896
    s.addi       s35, s20, #960
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s29, #0], v18
    s.movz       s20, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.add        s29, s20, s12                   // the tile origin
    s.add        s32, s20, s28                   // the tile origin
    v.splat      v4, s29
    s.addi       s20, s26, #192
    v.splat      v18, s32
    v.add        v19, v2, v4
    s.add        s29, s14, s20
    s.addi       s20, s30, #6144
    v.cmp.lt     p1, v19, v18
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s34, #0], v18
    s.addi       s32, s20, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s20, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s20, #192
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s27, #0], v18
    s.addi       s27, s20, #256
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s36, #0]
    s.addi       s34, s20, #320
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s35, #0], v18
    fence.acq_rel.device
    s.addi       s35, s20, #384
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s20, #0], v18
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s20, #448
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s20, #512
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.addi       s31, s26, #192
    s.add        s36, s14, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s27, #0], v18
    s.addi       s27, s20, #576
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s34, #0], v18
    s.addi       s31, s20, #640
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s35, #0], v18
    s.addi       s34, s20, #704
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s32, #0], v18
    s.addi       s32, s20, #768
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s33, #0], v18
    s.addi       s33, s20, #832
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s29, #0]
    s.addi       s29, s20, #896
    s.addi       s35, s20, #960
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s27, #0], v18
    s.movz       s20, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s36, #0]
    vf.cvt.bf16.f32 v18, v4
    v.st.w       [s31, #0], v18
    s.add        s27, s20, s15                   // the tile origin
    s.add        s31, s20, s28                   // the tile origin
    v.splat      v4, s27
    s.addi       s20, s26, #224
    v.splat      v18, s31
    v.add        v19, v2, v4
    s.add        s27, s14, s20
    s.addi       s20, s30, #7168
    v.cmp.lt     p2, v19, v18
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s36, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s34, #0], v4
    s.addi       s31, s20, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s36, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s32, #0], v4
    s.addi       s32, s20, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s36, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s33, #0], v4
    s.addi       s33, s20, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s36, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s29, #0], v4
    s.addi       s29, s20, #256
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s36, #0]
    s.addi       s34, s20, #320
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s35, #0], v4
    fence.acq_rel.device
    s.addi       s35, s20, #384
    s.addi       s36, s26, #224
    s.add        s26, s14, s36
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s27, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s20, #0], v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s27, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s31, #0], v4
    s.addi       s31, s20, #448
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s27, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s32, #0], v4
    s.addi       s32, s20, #512
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s27, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s33, #0], v4
    s.addi       s33, s20, #576
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s27, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s29, #0], v4
    s.addi       s29, s20, #640
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s27, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s34, #0], v4
    s.addi       s34, s20, #704
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s27, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s35, #0], v4
    s.addi       s35, s20, #768
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s27, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s31, #0], v4
    s.addi       s31, s20, #832
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s27, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s32, #0], v4
    s.addi       s32, s20, #896
    s.addi       s36, s20, #960
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s27, #0]
    s.addi       s20, s30, #0
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s33, #0], v4
    s.addi       s27, s30, #1024
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s26, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s29, #0], v4
    s.addi       s29, s30, #2048
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s26, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s34, #0], v4
    s.addi       s33, s30, #3072
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s26, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s35, #0], v4
    s.addi       s34, s30, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s26, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s31, #0], v4
    s.addi       s31, s30, #1088
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s26, #0]
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s32, #0], v4
    s.addi       s32, s30, #2112
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s26, #0]
    s.addi       s26, s30, #3136
    vf.cvt.bf16.f32 v4, v2
    v.st.w       [s36, #0], v4
    fence.acq_rel.device
    s.addi       s35, s30, #4096
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s30, #4160
    v.ld.w       v4, [s27, #0]
    vf.abs       v18, v2
    s.addi       s27, s30, #5120
    v.ld.w       v2, [s34, #0]
    vf.abs       v19, v4
    s.addi       s34, s30, #5184
    vf.max.ieee  v4, v18, v19
    v.ld.w       v18, [s31, #0]
    vf.abs       v19, v2
    s.addi       s31, s30, #6144
    v.ld.w       v2, [s29, #0]
    vf.abs       v20, v18
    s.addi       s29, s30, #6208
    vf.max.ieee  v18, v19, v20
    v.ld.w       v19, [s32, #0]
    vf.abs       v20, v2
    s.addi       s32, s30, #7168
    vf.max.ieee  v2, v4, v20
    v.ld.w       v4, [s33, #0]
    vf.abs       v20, v19
    s.addi       s33, s30, #7232
    vf.max.ieee  v19, v18, v20
    v.ld.w       v18, [s26, #0]
    vf.abs       v20, v4
    vf.max.ieee  v4, v2, v20
    v.ld.w       v2, [s35, #0]
    s.addi       s26, s30, #128
    vf.abs       v20, v18
    vf.max.ieee  v18, v19, v20
    v.ld.w       v19, [s20, #0]
    vf.abs       v20, v2
    vf.max.ieee  v2, v4, v20
    s.addi       s20, s30, #1152
    v.ld.w       v4, [s26, #0]
    vf.abs       v20, v19
    vf.max.ieee  v19, v18, v20
    v.ld.w       v18, [s27, #0]
    vf.abs       v20, v4
    v.ld.w       v4, [s20, #0]
    vf.abs       v21, v18
    vf.max.ieee  v18, v2, v21
    s.addi       s20, s30, #2176
    v.ld.w       v2, [s34, #0]
    vf.abs       v21, v4
    vf.max.ieee  v4, v20, v21
    v.ld.w       v20, [s31, #0]
    vf.abs       v21, v2
    vf.max.ieee  v2, v19, v21
    v.ld.w       v19, [s20, #0]
    vf.abs       v21, v20
    vf.max.ieee  v20, v18, v21
    s.addi       s20, s30, #3200
    v.ld.w       v18, [s29, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v4, v21
    v.ld.w       v4, [s32, #0]
    vf.abs       v21, v18
    vf.max.ieee  v18, v2, v21
    v.ld.w       v2, [s20, #0]
    vf.abs       v21, v4
    vf.max.ieee  v4, v20, v21
    vf.reduce.max.b v20, v4
    s.addi       s20, s30, #192
    s.addi       s26, s30, #1216
    s.addi       s27, s30, #2240
    s.addi       s29, s30, #3264
    s.addi       s31, s30, #4224
    s.addi       s32, s30, #5248
    v.ld.w       v4, [s20, #0]
    s.addi       s20, s30, #6272
    vf.abs       v21, v2
    s.addi       s34, s30, #7296
    vf.max.ieee  v2, v19, v21
    v.ld.w       v19, [s26, #0]
    vf.abs       v21, v4
    v.ld.w       v4, [s27, #0]
    vf.abs       v22, v19
    vf.max.ieee  v19, v21, v22
    v.ld.w       v21, [s31, #0]
    vf.abs       v22, v4
    vf.max.ieee  v4, v19, v22
    v.ld.w       v19, [s32, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v2, v22
    v.ld.w       v2, [s20, #0]
    vf.abs       v22, v19
    vf.max.ieee  v19, v21, v22
    v.ld.w       v21, [s33, #0]
    vf.abs       v22, v2
    vf.max.ieee  v2, v19, v22
    v.ld.w       v19, [s29, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v18, v22
    vf.reduce.max.b v18, v21
    s.addi       s20, s30, #256
    s.addi       s26, s30, #1280
    s.addi       s27, s30, #2304
    s.addi       s29, s30, #3328
    s.addi       s31, s30, #4288
    s.addi       s32, s30, #5312
    v.ld.w       v21, [s20, #0]
    s.addi       s20, s30, #6336
    vf.abs       v22, v19
    s.addi       s33, s30, #7360
    vf.max.ieee  v19, v4, v22
    v.ld.w       v4, [s26, #0]
    vf.abs       v22, v21
    v.ld.w       v21, [s27, #0]
    vf.abs       v23, v4
    vf.max.ieee  v4, v22, v23
    v.ld.w       v22, [s31, #0]
    vf.abs       v23, v21
    vf.max.ieee  v21, v4, v23
    v.ld.w       v4, [s32, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v19, v23
    v.ld.w       v19, [s20, #0]
    vf.abs       v23, v4
    vf.max.ieee  v4, v22, v23
    v.ld.w       v22, [s34, #0]
    vf.abs       v23, v19
    vf.max.ieee  v19, v4, v23
    v.ld.w       v4, [s29, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v2, v23
    vf.reduce.max.b v2, v22
    s.addi       s20, s30, #320
    s.addi       s26, s30, #1344
    s.addi       s27, s30, #2368
    s.addi       s29, s30, #3392
    s.addi       s31, s30, #4352
    s.addi       s32, s30, #5376
    v.ld.w       v22, [s20, #0]
    s.addi       s20, s30, #6400
    vf.abs       v23, v4
    s.addi       s34, s30, #7424
    vf.max.ieee  v4, v21, v23
    v.ld.w       v21, [s26, #0]
    vf.abs       v23, v22
    v.ld.w       v22, [s27, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v23, v24
    v.ld.w       v23, [s31, #0]
    vf.abs       v24, v22
    vf.max.ieee  v22, v21, v24
    v.ld.w       v21, [s32, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v4, v24
    v.ld.w       v4, [s20, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v23, v24
    v.ld.w       v23, [s33, #0]
    vf.abs       v24, v4
    vf.max.ieee  v4, v21, v24
    v.ld.w       v21, [s29, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v19, v24
    vf.reduce.max.b v19, v23
    s.addi       s20, s30, #384
    s.addi       s26, s30, #1408
    s.addi       s27, s30, #2432
    s.addi       s29, s30, #3456
    s.addi       s31, s30, #4416
    s.addi       s32, s30, #5440
    v.ld.w       v23, [s20, #0]
    s.addi       s20, s30, #6464
    vf.abs       v24, v21
    s.addi       s33, s30, #7488
    vf.max.ieee  v21, v22, v24
    v.ld.w       v22, [s26, #0]
    vf.abs       v24, v23
    v.ld.w       v23, [s27, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v24, v25
    v.ld.w       v24, [s31, #0]
    vf.abs       v25, v23
    vf.max.ieee  v23, v22, v25
    v.ld.w       v22, [s32, #0]
    vf.abs       v25, v24
    vf.max.ieee  v24, v21, v25
    v.ld.w       v21, [s20, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v24, v25
    v.ld.w       v24, [s34, #0]
    vf.abs       v25, v21
    vf.max.ieee  v21, v22, v25
    v.ld.w       v22, [s29, #0]
    vf.abs       v25, v24
    vf.max.ieee  v24, v4, v25
    vf.reduce.max.b v4, v24
    s.addi       s20, s30, #448
    s.addi       s26, s30, #1472
    s.addi       s27, s30, #2496
    s.addi       s29, s30, #3520
    s.addi       s31, s30, #4480
    s.addi       s32, s30, #5504
    v.ld.w       v24, [s20, #0]
    s.addi       s20, s30, #6528
    vf.abs       v25, v22
    s.addi       s34, s30, #7552
    vf.max.ieee  v22, v23, v25
    v.ld.w       v23, [s26, #0]
    vf.abs       v25, v24
    v.ld.w       v24, [s27, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v25, v26
    v.ld.w       v25, [s31, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v23, v26
    v.ld.w       v23, [s32, #0]
    vf.abs       v26, v25
    vf.max.ieee  v25, v22, v26
    v.ld.w       v22, [s20, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v25, v26
    v.ld.w       v25, [s33, #0]
    vf.abs       v26, v22
    vf.max.ieee  v22, v23, v26
    v.ld.w       v23, [s29, #0]
    vf.abs       v26, v25
    vf.max.ieee  v25, v21, v26
    vf.reduce.max.b v21, v25
    s.addi       s20, s30, #512
    s.addi       s26, s30, #1536
    s.addi       s27, s30, #2560
    s.addi       s29, s30, #3584
    s.addi       s31, s30, #4544
    s.addi       s32, s30, #5568
    v.ld.w       v25, [s20, #0]
    s.addi       s20, s30, #6592
    vf.abs       v26, v23
    s.addi       s33, s30, #7616
    vf.max.ieee  v23, v24, v26
    v.ld.w       v24, [s26, #0]
    vf.abs       v26, v25
    v.ld.w       v25, [s27, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v26, v27
    v.ld.w       v26, [s31, #0]
    vf.abs       v27, v25
    vf.max.ieee  v25, v24, v27
    v.ld.w       v24, [s32, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v23, v27
    v.ld.w       v23, [s20, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v26, v27
    v.ld.w       v26, [s34, #0]
    vf.abs       v27, v23
    vf.max.ieee  v23, v24, v27
    v.ld.w       v24, [s29, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v22, v27
    vf.reduce.max.b v22, v26
    s.addi       s20, s30, #576
    s.addi       s26, s30, #1600
    s.addi       s27, s30, #2624
    s.addi       s29, s30, #3648
    s.addi       s31, s30, #4608
    s.addi       s32, s30, #5632
    v.ld.w       v26, [s20, #0]
    s.addi       s20, s30, #6656
    vf.abs       v27, v24
    s.addi       s34, s30, #7680
    vf.max.ieee  v24, v25, v27
    v.ld.w       v25, [s26, #0]
    vf.abs       v27, v26
    v.ld.w       v26, [s27, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v27, v28
    v.ld.w       v27, [s31, #0]
    vf.abs       v28, v26
    vf.max.ieee  v26, v25, v28
    v.ld.w       v25, [s32, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v24, v28
    v.ld.w       v24, [s20, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v27, v28
    v.ld.w       v27, [s33, #0]
    vf.abs       v28, v24
    vf.max.ieee  v24, v25, v28
    v.ld.w       v25, [s29, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v23, v28
    vf.reduce.max.b v23, v27
    s.addi       s20, s30, #640
    s.addi       s26, s30, #1664
    s.addi       s27, s30, #2688
    s.addi       s29, s30, #3712
    s.addi       s31, s30, #4672
    s.addi       s32, s30, #5696
    v.ld.w       v27, [s20, #0]
    s.addi       s20, s30, #6720
    vf.abs       v28, v25
    s.addi       s33, s30, #7744
    vf.max.ieee  v25, v26, v28
    v.ld.w       v26, [s26, #0]
    vf.abs       v28, v27
    v.ld.w       v27, [s27, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v28, v29
    v.ld.w       v28, [s31, #0]
    vf.abs       v29, v27
    vf.max.ieee  v27, v26, v29
    v.ld.w       v26, [s32, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v25, v29
    v.ld.w       v25, [s20, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v28, v29
    v.ld.w       v28, [s34, #0]
    vf.abs       v29, v25
    vf.max.ieee  v25, v26, v29
    v.ld.w       v26, [s29, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v24, v29
    vf.reduce.max.b v24, v28
    s.addi       s20, s30, #704
    s.addi       s26, s30, #1728
    s.addi       s27, s30, #2752
    s.addi       s29, s30, #3776
    s.addi       s31, s30, #4736
    s.addi       s32, s30, #5760
    v.ld.w       v28, [s20, #0]
    s.addi       s20, s30, #6784
    vf.abs       v29, v26
    s.addi       s34, s30, #7808
    vf.max.ieee  v26, v27, v29
    v.ld.w       v27, [s26, #0]
    vf.abs       v29, v28
    v.ld.w       v28, [s27, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v29, v30
    v.ld.w       v29, [s31, #0]
    vf.abs       v30, v28
    vf.max.ieee  v28, v27, v30
    v.ld.w       v27, [s32, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v26, v30
    v.ld.w       v26, [s20, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v29, v30
    v.ld.w       v29, [s33, #0]
    vf.abs       v30, v26
    vf.max.ieee  v26, v27, v30
    v.ld.w       v27, [s29, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v25, v30
    vf.reduce.max.b v25, v29
    s.addi       s20, s30, #768
    s.addi       s26, s30, #1792
    s.addi       s27, s30, #2816
    s.addi       s29, s30, #3840
    s.addi       s31, s30, #4800
    s.addi       s32, s30, #5824
    v.ld.w       v29, [s20, #0]
    s.addi       s20, s30, #6848
    vf.abs       v30, v27
    s.addi       s33, s30, #7872
    vf.max.ieee  v27, v28, v30
    v.ld.w       v28, [s26, #0]
    vf.abs       v30, v29
    v.ld.w       v29, [s27, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v30, v31
    v.ld.w       v30, [s31, #0]
    vf.abs       v31, v29
    vf.max.ieee  v29, v28, v31
    v.ld.w       v28, [s32, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v27, v31
    v.ld.w       v27, [s20, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v30, v31
    v.ld.w       v30, [s34, #0]
    vf.abs       v31, v27
    vf.max.ieee  v27, v28, v31
    v.ld.w       v28, [s29, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v26, v31
    vf.reduce.max.b v26, v30
    s.addi       s20, s30, #832
    s.addi       s26, s30, #1856
    s.addi       s27, s30, #2880
    s.addi       s29, s30, #3904
    s.addi       s31, s30, #4864
    s.addi       s32, s30, #5888
    v.ld.w       v30, [s20, #0]
    s.addi       s20, s30, #6912
    s.addi       s34, s30, #7936
    vf.abs       v31, v28
    vf.max.ieee  v28, v29, v31
    v.ld.w       v29, [s26, #0]
    vf.abs       v31, v30
    v.ld.w       v30, [s27, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v31, v32
    v.ld.w       v31, [s31, #0]
    vf.abs       v32, v30
    vf.max.ieee  v30, v29, v32
    v.ld.w       v29, [s32, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v28, v32
    v.ld.w       v28, [s20, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v31, v32
    v.ld.w       v31, [s33, #0]
    vf.abs       v32, v28
    vf.max.ieee  v28, v29, v32
    v.ld.w       v29, [s29, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v27, v32
    vf.reduce.max.b v27, v31
    s.addi       s20, s30, #896
    s.addi       s26, s30, #1920
    s.addi       s27, s30, #2944
    s.addi       s29, s30, #3968
    s.addi       s31, s30, #4928
    s.addi       s32, s30, #5952
    v.ld.w       v31, [s20, #0]
    s.addi       s20, s30, #6976
    s.addi       s33, s30, #8000
    vf.abs       v32, v29
    vf.max.ieee  v29, v30, v32
    v.ld.w       v30, [s26, #0]
    vf.abs       v32, v31
    v.ld.w       v31, [s27, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v32, v33
    v.ld.w       v32, [s31, #0]
    vf.abs       v33, v31
    vf.max.ieee  v31, v30, v33
    v.ld.w       v30, [s32, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v29, v33
    v.ld.w       v29, [s34, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v32, v33
    v.ld.w       v32, [s29, #0]
    vf.abs       v33, v29
    vf.max.ieee  v29, v28, v33
    vf.reduce.max.b v28, v29
    s.addi       s26, s30, #960
    s.addi       s27, s30, #1984
    s.addi       s29, s30, #3008
    s.addi       s31, s30, #4992
    s.addi       s32, s30, #6016
    s.addi       s34, s30, #7040
    v.ld.w       v29, [s26, #0]
    s.addi       s26, s30, #8064
    vf.abs       v33, v32
    vf.max.ieee  v32, v31, v33
    v.ld.w       v31, [s27, #0]
    vf.abs       v33, v29
    v.ld.w       v29, [s31, #0]
    vf.abs       v34, v31
    vf.max.ieee  v31, v33, v34
    v.ld.w       v33, [s32, #0]
    vf.abs       v34, v29
    vf.max.ieee  v29, v32, v34
    v.ld.w       v32, [s20, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v29, v34
    v.ld.w       v29, [s29, #0]
    vf.abs       v34, v32
    vf.max.ieee  v32, v30, v34
    s.addi       s20, s30, #4032
    v.ld.w       v30, [s33, #0]
    vf.abs       v34, v29
    vf.max.ieee  v29, v31, v34
    v.ld.w       v31, [s20, #0]
    vf.abs       v34, v30
    vf.max.ieee  v30, v32, v34
    vf.reduce.max.b v32, v30
    s.addi       s20, s30, #5056
    v.movi       v30, #0
    s.addi       s27, s30, #6080
    s.addi       s29, s30, #7104
    s.addi       s31, s30, #8128
    // one value per row into one vector (ISA 0x09)
    v.extract    s32, v20, #0
    v.ld.w       v20, [s20, #0]
    v.extract    s20, v18, #0
    v.extract    s33, v2, #0
    v.extract    s35, v19, #0
    vf.abs       v2, v31
    vf.max.ieee  v18, v29, v2
    v.ld.w       v2, [s34, #0]
    vf.abs       v19, v20
    vf.max.ieee  v20, v18, v19
    v.ld.w       v18, [s26, #0]
    vf.abs       v19, v2
    v.extract    s26, v4, #0
    vf.max.ieee  v2, v33, v19
    v.extract    s34, v21, #0
    v.ld.w       v4, [s27, #0]
    vf.abs       v19, v18
    v.extract    s27, v22, #0
    vf.max.ieee  v18, v2, v19
    vf.reduce.max.b v2, v18
    .li       s36, #1138753536
    v.splat      v18, s36                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s36, #1065353216
    v.splat      v19, s36                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v21, v18                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v22, [s29, #0]
    v.extract    s29, v23, #0
    vf.abs       v23, v4
    vf.max.ieee  v4, v20, v23
    v.ld.w       v20, [s31, #0]
    v.insert     v30, s32, #0
    v.extract    s31, v24, #0
    vf.abs       v23, v22
    v.insert     v30, s20, #1
    v.extract    s20, v25, #0
    v.extract    s32, v26, #0
    v.insert     v30, s33, #2
    vf.fms       v22, v18, v21, v19
    vf.max.ieee  v24, v4, v23
    v.insert     v30, s35, #3
    v.extract    s33, v27, #0
    v.extract    s35, v28, #0
    v.insert     v30, s26, #4
    vf.fms       v4, v21, v22, v21
    v.extract    s26, v32, #0
    v.insert     v30, s34, #5
    v.extract    s34, v2, #0
    vf.abs       v2, v20
    v.insert     v30, s27, #6
    vf.neg       v20, v4                         // Newton step: r0*(2 - x*r0)
    v.insert     v30, s29, #7
    vf.max.ieee  v4, v24, v2
    v.insert     v30, s31, #8
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v2, v20, v21
    v.insert     v30, s20, #9
    vf.reduce.max.b v20, v4
    v.iota       v4                              // arange(0, VLEN)
    v.insert     v30, s32, #10
    v.extract    s20, v20, #0
    .li       s27, #730643660
    v.splat      v20, s27                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.insert     v30, s33, #11
    v.extract    s27, v14, #0
    s.movz       s29, #0
    v.insert     v30, s35, #12
    v.splat      v21, s27
    s.add        s31, s2, s28
    v.insert     v30, s26, #13
    v.add        v22, v21, v4
    s.cmp.ge     s26, s31, s29
    v.insert     v30, s34, #14
    v.sub        v21, v14, v22
    s.cmp.ge     s28, s27, s29
    v.insert     v30, s20, #15
    v.extract    s20, v13, #0
    v.reduce.or  s32, v21
    vf.mul       v21, v30, v2                    // a/y: faithful quotient
    v.splat      v22, s20
    s.cmp.eq     s33, s32, s29
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    v.movi       v23, #0
    v.add        v24, v22, v4
    vf.fms       v22, v21, v18, v30
    s.and        s32, s33, s28
    v.sub        v18, v13, v24
    v.movi       v24, #0
    s.cmp.ge     s28, s20, s29
    vf.fms       v25, v22, v2, v21
    v.reduce.or  s33, v18
    s.and        s34, s32, s26
    s.cmp.eq     s32, s33, s29
    v.ld.gather.w v2, [s25, v0]                  // index is in elements (ISA sec 9.1)
    vf.neg       v18, v25                        // a/y: one correction to the IEEE quotient
    s.and        s33, s32, s28
    v.splat      v22, s22
    s.and        s28, s33, s26
    v.splat      v25, s22
    vf.cmp.o     p1, v18, v18
    @p1 v.sel        v26, v18, v21
    v.extract    s32, v11, #0
    v.mul        v18, v14, v22
    v.splat      v21, s32
    v.mul        v27, v13, v22
    v.mul        v28, v11, v22
    v.add        v29, v21, v4
    v.mul        v21, v10, v22
    s.cmp.ge     s33, s32, s29
    v.sub        v30, v11, v29
    v.mul        v29, v9, v22
    v.ld.gather.w v22, [s25, v1]                 // index is in elements (ISA sec 9.1)
    v.reduce.or  s35, v30
    v.mul        v30, v8, v25
    s.cmp.eq     s36, s35, s29
    v.mul        v31, v7, v25
    s.and        s35, s36, s33
    v.mul        v32, v3, v25
    v.extract    s33, v10, #0
    s.and        s36, s35, s26
    v.splat      v25, s33
    v.add        v33, v25, v4
    v.ld.gather.w v25, [s25, v5]                 // index is in elements (ISA sec 9.1)
    v.sub        v34, v10, v33
    v.ld.gather.w v33, [s25, v6]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v35, [s25, v12]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v36, [s25, v15]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v37, [s25, v16]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v38, [s25, v17]                // index is in elements (ISA sec 9.1)
    v.insert     v23, s34, #0
    v.extract    s34, v9, #0
    v.insert     v24, s27, #0
    v.splat      v39, s34
    v.extract    s27, v8, #0
    v.insert     v23, s28, #1
    v.add        v40, v39, v4
    v.splat      v39, s27
    v.extract    s28, v7, #0
    v.sub        v41, v9, v40
    v.add        v40, v39, v4
    v.splat      v39, s28
    v.insert     v24, s20, #1
    v.reduce.or  s20, v34
    v.sub        v34, v8, v40
    s.cmp.eq     s35, s20, s29
    v.add        v40, v39, v4
    v.insert     v23, s36, #2
    v.extract    s20, v3, #0
    v.insert     v24, s32, #2
    s.cmp.ge     s32, s33, s29
    v.splat      v39, s20
    s.and        s36, s35, s32
    v.reduce.or  s32, v41
    s.and        s35, s36, s26
    s.cmp.eq     s36, s32, s29
    s.cmp.ge     s32, s34, s29
    v.sub        v41, v7, v40
    v.add        v40, v39, v4
    s.and        s29, s36, s32
    v.reduce.or  s32, v34
    v.insert     v23, s35, #3
    s.movz       s35, #0
    v.insert     v24, s33, #3
    s.cmp.eq     s33, s32, s35
    s.cmp.ge     s32, s27, s35
    s.and        s36, s29, s26
    v.sub        v4, v3, v40
    s.and        s29, s33, s32
    v.reduce.or  s32, v41
    v.insert     v23, s36, #4
    v.insert     v24, s34, #4
    s.cmp.eq     s33, s32, s35
    s.cmp.ge     s32, s28, s35
    s.and        s34, s29, s26
    v.reduce.or  s29, v4
    s.and        s36, s33, s32
    v.insert     v23, s34, #5
    v.insert     v24, s27, #5
    s.cmp.eq     s27, s29, s35
    s.cmp.ge     s29, s20, s35
    s.and        s32, s36, s26
    s.and        s33, s27, s29
    v.insert     v23, s32, #6
    v.insert     v24, s28, #6
    v.extract    s27, v26, #0
    s.and        s28, s33, s26
    v.splat      v4, s27
    s.add        s26, s13, s24
    s.addi       s27, s30, #8192                 // TensorMap 0: W's rows for a transposed FP8 B
    vf.max.ieee  v34, v4, v20
    .li       s29, #2147483647
    s.movz       s32, #1
    .li       s33, #137438953488
    .li       s34, #7705171329024
    v.rcp.approx v4, v34                         // ISA 8.8: <= 2**-22 relative
    s.addi       s35, s30, #8448
    v.insert     v23, s28, #7
    s.addi       s28, s30, #8960                 // TensorMap 1: the gathered fallback B tile
    v.insert     v24, s20, #7
    s.movz       s20, #32
    s.st.d       [s27, #0], s26
    s.movz       s26, #16
    s.st.d       [s27, #8], s29
    .li       s29, #68719476768
    vf.fms       v39, v34, v4, v19
    s.st.d       [s27, #16], s31
    vf.fms       v40, v4, v39, v4
    vf.neg       v39, v40                        // Newton step: r0*(2 - x*r0)
    s.st.d       [s27, #48], s22
    vf.cmp.o     p1, v39, v39
    @p1 v.sel        v40, v39, v4
    s.st.d       [s27, #56], s32
    v.movi       v4, #24
    s.st.d       [s27, #88], s33
    s.addi       s33, s30, #0
    v.movi       v39, #128
    s.st.d       [s27, #104], s34
    fence.release.device
    td.load      d0, [s27]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s27, s30, #9216                 // 512 bytes of repack scratch
    s.st.d       [s28, #0], s35
    v.extract    s35, v26, #1
    v.splat      v41, s35
    s.addi       s35, s27, #0
    s.st.d       [s28, #8], s20
    vf.max.ieee  v42, v41, v20
    s.addi       s20, s30, #64
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    s.st.d       [s28, #16], s26
    s.st.d       [s28, #48], s26
    s.st.d       [s28, #56], s32
    vf.fms       v43, v42, v41, v19
    vf.fms       v44, v41, v43, v41
    s.st.d       [s28, #88], s29
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    s.st.d       [s28, #104], s34
    fence.release.device
    td.load      d1, [s28]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    v.ld.w       v41, [s33, #0]
    v.extract    s26, v26, #2
    s.addi       s28, s27, #32
    v.splat      v43, s26
    s.addi       s26, s30, #128
    vf.max.ieee  v45, v43, v20
    v.rcp.approx v43, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v41, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v34, v41
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v46
    vf.fms       v40, v45, v43, v19
    v.lshr       v41, v34, v4
    vf.cvt.f32.e4m3 v46, v34
    v.and        v34, v41, v39
    vf.fms       v41, v43, v40, v43
    s.addi       s29, s27, #64
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s32, s30, #192
    v.st.b       [s35, #0], v40
    vf.neg       v34, v41                        // Newton step: r0*(2 - x*r0)
    v.extract    s33, v26, #3
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v43
    v.ld.w       v34, [s20, #0]
    v.splat      v41, s33
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v44                   // a/y: faithful quotient
    vf.fms       v47, v46, v42, v34
    vf.fms       v34, v47, v44, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s20, s27, #96
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s30, #256
    v.st.b       [s28, #0], v42
    v.extract    s28, v26, #4
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s26, #0]
    v.splat      v41, s28
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s26, s27, #128
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s30, #320
    v.st.b       [s29, #0], v40
    v.extract    s29, v26, #5
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s29
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s29, s27, #160
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s30, #384
    v.st.b       [s20, #0], v42
    v.extract    s20, v26, #6
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s20
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s20, s27, #192
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s30, #448
    v.st.b       [s26, #0], v40
    v.extract    s26, v26, #7
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s26
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s26, s27, #224
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s30, #512
    v.st.b       [s29, #0], v42
    v.extract    s29, v26, #8
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s29
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s29, s27, #256
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s30, #576
    v.st.b       [s20, #0], v40
    v.extract    s20, v26, #9
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s20
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s20, s27, #288
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s30, #640
    v.st.b       [s26, #0], v42
    v.extract    s26, v26, #10
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s26
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s26, s27, #320
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s30, #704
    v.st.b       [s29, #0], v40
    v.extract    s29, v26, #11
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s29
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s29, s27, #352
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s30, #768
    v.st.b       [s20, #0], v42
    v.extract    s20, v26, #12
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s20
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s20, s27, #384
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s30, #832
    v.st.b       [s26, #0], v40
    v.extract    s26, v26, #13
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s26
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s26, s27, #416
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s30, #896
    v.st.b       [s29, #0], v42
    v.extract    s29, v26, #14
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s29
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s29, s27, #448
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s30, #960
    v.st.b       [s20, #0], v40
    v.extract    s20, v26, #15
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s20
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s20, s27, #480
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s30, #1024
    v.st.b       [s26, #0], v42
    v.extract    s26, v26, #0
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s26
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s26, s27, #16
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s30, #1088
    v.st.b       [s29, #0], v40
    v.extract    s29, v26, #1
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s29
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s29, s27, #48
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s30, #1152
    v.st.b       [s20, #0], v42
    v.extract    s20, v26, #2
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s20
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s20, s27, #80
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s30, #1216
    v.st.b       [s26, #0], v40
    v.extract    s26, v26, #3
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s26
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s26, s27, #112
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s30, #1280
    v.st.b       [s29, #0], v42
    v.extract    s29, v26, #4
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s29
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s29, s27, #144
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s30, #1344
    v.st.b       [s20, #0], v40
    v.extract    s20, v26, #5
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s20
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s20, s27, #176
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s30, #1408
    v.st.b       [s26, #0], v42
    v.extract    s26, v26, #6
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s26
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s26, s27, #208
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s30, #1472
    v.st.b       [s29, #0], v40
    v.extract    s29, v26, #7
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s29
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s29, s27, #240
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s30, #1536
    v.st.b       [s20, #0], v42
    v.extract    s20, v26, #8
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s20
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s20, s27, #272
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s30, #1600
    v.st.b       [s26, #0], v40
    v.extract    s26, v26, #9
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s26
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s26, s27, #304
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s30, #1664
    v.st.b       [s29, #0], v42
    v.extract    s29, v26, #10
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s29
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v46
    v.lshr       v40, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s29, s27, #336
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s30, #1728
    v.st.b       [s20, #0], v40
    v.extract    s20, v26, #11
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s20
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s20, s27, #368
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s30, #1792
    v.st.b       [s26, #0], v42
    v.extract    s26, v26, #12
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s26
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v45, v40, v46
    v.lshr       v40, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s26, s27, #400
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s28, s30, #1856
    v.st.b       [s29, #0], v40
    v.extract    s29, v26, #13
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s32, #0]
    v.splat      v41, s29
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s29, s27, #432
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s32, s30, #1920
    v.st.b       [s20, #0], v42
    v.extract    s20, v26, #14
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s33, #0]
    v.splat      v41, s20
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v40                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v34
    vf.fms       v34, v47, v40, v46
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v43, v41, v19
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v46
    v.lshr       v40, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v34, v41
    v.and        v34, v40, v39
    s.addi       s20, s27, #464
    v.or         v40, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s30, #1984
    v.st.b       [s26, #0], v40
    v.extract    s26, v26, #15
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.ld.w       v34, [s28, #0]
    v.splat      v41, s26
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v34, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v34
    vf.fms       v34, v47, v42, v46
    vf.neg       v42, v34                        // a/y: one correction to the IEEE quotient
    vf.fms       v34, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v34, v41
    v.and        v34, v42, v39
    s.addi       s26, s27, #496
    v.or         v42, v46, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v34, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s29, #0], v42
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v42, v34, v41
    v.ld.w       v34, [s32, #0]
    s.addi       s28, s27, #64
    s.addi       s29, s27, #128
    s.addi       s32, s27, #192
    vf.mul       v41, v34, v40                   // a/y: faithful quotient
    s.addi       s34, s27, #256
    vf.fms       v45, v41, v43, v34
    vf.fms       v34, v45, v40, v41
    vf.neg       v40, v34                        // a/y: one correction to the IEEE quotient
    s.addi       s35, s27, #320
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.lshr       v40, v34, v4
    vf.cvt.f32.e4m3 v41, v34
    v.and        v34, v40, v39
    v.or         v40, v41, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s20, #0], v40
    s.addi       s20, s27, #384
    v.ld.w       v34, [s33, #0]
    s.addi       s33, s27, #448
    vf.mul       v40, v34, v42                   // a/y: faithful quotient
    vf.fms       v41, v40, v44, v34
    vf.fms       v34, v41, v42, v40
    vf.neg       v41, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v34, v41, v40
    v.lshr       v40, v34, v4
    vf.cvt.f32.e4m3 v41, v34
    v.and        v34, v40, v39
    v.or         v40, v41, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s26, #0], v40
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.extract    s26, v23, #0
    v.ld.w       v34, [s27, #0]
    v.mov        v48, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s28, #0]
    v.mov        v49, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s29, #0]
    v.mov        v50, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s32, #0]
    v.mov        v51, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s34, #0]
    v.mov        v52, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s35, #0]
    v.mov        v53, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s20, #0]
    v.mov        v54, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s33, #0]
    v.mov        v55, v34                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s26, x8dot_done_27
    s.movz       s20, #0
    s.add        s27, s13, s24
    s.addi       s28, s20, #0
    s.addi       s20, s30, #8448
x8dot_row_28:
    s.addi       s29, s31, #0
    v.movi       v34, #0
    s.sub        s32, s29, s28
    s.add        s29, s27, s28
    v.splat      v40, s32
    s.shli       s32, s28, #4
    s.addi       s33, s28, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s29, v18]            // index is in elements (ISA sec 9.1)
    s.add        s29, s20, s32
    s.movz       s32, #32
    v.st.b       [s29, #0], v34
    fence.acq_rel.device
    s.mov        s28, s33
    s.cmp.lt     s29, s28, s32
    br.nz        s29, x8dot_row_28
x8dot_done_27:
    v.splat      v34, s26
    v.movi       v40, #0
    mb.arm       s20, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s26, #0
    v.extract    s27, v24, #0
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s28, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s28, s20            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s28, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s28, s20          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s20
    mb.arm       s27, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s28, v23, #1
    m.mma.dp.async.k32.e4m3 a8, v48, v56, s27
    mb.wait      s27
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s28, x8dot_done_29
    s.addi       s29, s26, #0
    s.add        s32, s13, s24
    s.addi       s33, s30, #8448
x8dot_row_30:
    s.addi       s34, s31, #0
    v.movi       v34, #0
    s.sub        s35, s34, s29
    s.add        s34, s32, s29
    v.splat      v40, s35
    s.shli       s35, s29, #4
    s.addi       s36, s29, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s34, v27]            // index is in elements (ISA sec 9.1)
    s.add        s34, s33, s35
    s.movz       s35, #32
    v.st.b       [s34, #0], v34
    fence.acq_rel.device
    s.mov        s29, s36
    s.cmp.lt     s34, s29, s35
    br.nz        s34, x8dot_row_30
x8dot_done_29:
    v.splat      v34, s28
    v.movi       v40, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s29, v24, #1
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s32, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s32, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s32, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s32, v23, #2
    m.mma.dp.async.k32.e4m3 a9, v48, v56, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s32, x8dot_done_31
    s.addi       s33, s26, #0
    s.add        s26, s13, s24
    s.addi       s34, s30, #8448
x8dot_row_32:
    s.addi       s35, s31, #0
    v.movi       v34, #0
    s.sub        s36, s35, s33
    s.add        s35, s26, s33
    v.splat      v40, s36
    s.shli       s36, s33, #4
    s.addi       s37, s33, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s35, v28]            // index is in elements (ISA sec 9.1)
    s.add        s35, s34, s36
    s.movz       s36, #32
    v.st.b       [s35, #0], v34
    fence.acq_rel.device
    s.mov        s33, s37
    s.cmp.lt     s35, s33, s36
    br.nz        s35, x8dot_row_32
x8dot_done_31:
    v.splat      v34, s32
    v.movi       v40, #0
    mb.arm       s26, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    v.extract    s33, v24, #2
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s34, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s26            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s26          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s26
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v23, #3
    m.mma.dp.async.k32.e4m3 a10, v48, v56, s33
    mb.wait      s33
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_33
    s.addi       s35, s32, #0
    s.add        s36, s13, s24
    s.addi       s37, s30, #8448
x8dot_row_34:
    s.addi       s38, s31, #0
    v.movi       v34, #0
    s.sub        s39, s38, s35
    s.add        s38, s36, s35
    v.splat      v40, s39
    s.shli       s39, s35, #4
    s.addi       s40, s35, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s38, v21]            // index is in elements (ISA sec 9.1)
    s.add        s38, s37, s39
    s.movz       s39, #32
    v.st.b       [s38, #0], v34
    fence.acq_rel.device
    s.mov        s35, s40
    s.cmp.lt     s38, s35, s39
    br.nz        s38, x8dot_row_34
x8dot_done_33:
    v.splat      v34, s34
    v.movi       v40, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s35, v24, #3
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v23, #4
    m.mma.dp.async.k32.e4m3 a11, v48, v56, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s36, x8dot_done_35
    s.addi       s37, s32, #0
    s.add        s32, s13, s24
    s.addi       s38, s30, #8448
x8dot_row_36:
    s.addi       s39, s31, #0
    v.movi       v34, #0
    s.sub        s40, s39, s37
    s.add        s39, s32, s37
    v.splat      v40, s40
    s.shli       s40, s37, #4
    s.addi       s41, s37, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s39, v29]            // index is in elements (ISA sec 9.1)
    s.add        s39, s38, s40
    s.movz       s40, #32
    v.st.b       [s39, #0], v34
    fence.acq_rel.device
    s.mov        s37, s41
    s.cmp.lt     s39, s37, s40
    br.nz        s39, x8dot_row_36
x8dot_done_35:
    v.splat      v34, s36
    v.movi       v40, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    v.extract    s37, v24, #4
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s38, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v23, #5
    m.mma.dp.async.k32.e4m3 a12, v48, v56, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s38, x8dot_done_37
    s.addi       s39, s36, #0
    s.add        s40, s13, s24
    s.addi       s41, s30, #8448
x8dot_row_38:
    s.addi       s42, s31, #0
    v.movi       v34, #0
    s.sub        s43, s42, s39
    s.add        s42, s40, s39
    v.splat      v40, s43
    s.shli       s43, s39, #4
    s.addi       s44, s39, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s42, v30]            // index is in elements (ISA sec 9.1)
    s.add        s42, s41, s43
    s.movz       s43, #32
    v.st.b       [s42, #0], v34
    fence.acq_rel.device
    s.mov        s39, s44
    s.cmp.lt     s42, s39, s43
    br.nz        s42, x8dot_row_38
x8dot_done_37:
    v.splat      v34, s38
    v.movi       v40, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s39, v24, #5
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s40, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v23, #6
    m.mma.dp.async.k32.e4m3 a13, v48, v56, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_39
    s.addi       s41, s36, #0
    s.add        s36, s13, s24
    s.addi       s42, s30, #8448
x8dot_row_40:
    s.addi       s43, s31, #0
    v.movi       v34, #0
    s.sub        s44, s43, s41
    s.add        s43, s36, s41
    v.splat      v40, s44
    s.shli       s44, s41, #4
    s.addi       s45, s41, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s43, v31]            // index is in elements (ISA sec 9.1)
    s.add        s43, s42, s44
    s.movz       s44, #32
    v.st.b       [s43, #0], v34
    fence.acq_rel.device
    s.mov        s41, s45
    s.cmp.lt     s43, s41, s44
    br.nz        s43, x8dot_row_40
x8dot_done_39:
    v.splat      v34, s40
    v.movi       v40, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.extract    s41, v24, #6
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v23, #7
    m.mma.dp.async.k32.e4m3 a14, v48, v56, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_41
    s.addi       s43, s40, #0
    s.add        s44, s13, s24
    s.addi       s45, s30, #8448
x8dot_row_42:
    s.addi       s46, s31, #0
    v.movi       v34, #0
    s.sub        s47, s46, s43
    s.add        s46, s44, s43
    v.splat      v40, s47
    s.shli       s47, s43, #4
    s.addi       s48, s43, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s46, v32]            // index is in elements (ISA sec 9.1)
    s.add        s46, s45, s47
    s.movz       s47, #32
    v.st.b       [s46, #0], v34
    fence.acq_rel.device
    s.mov        s43, s48
    s.cmp.lt     s46, s43, s47
    br.nz        s46, x8dot_row_42
x8dot_done_41:
    v.extract    s43, v26, #0
    v.splat      v34, s42
    v.splat      v40, s43
    v.movi       v41, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    vf.max.ieee  v42, v40, v20
    v.extract    s43, v24, #7
    v.cmp.ne     p1, v34, v41
    v.cmp.eq     p2, v34, v41
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s44, s42            // predicated off still completes once (ISA sec 9A.3)
    v.rcp.approx v34, v42                        // ISA 8.8: <= 2**-22 relative
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s43, s30, #2048
    v.extract    s44, v26, #1
    m.mma.dp.async.k32.e4m3 a15, v48, v56, s40
    mb.wait      s40
    v.ld.w       v40, [s43, #0]
    v.splat      v41, s44
    s.addi       s43, s30, #9728                 // 512 bytes of repack scratch
    s.addi       s44, s30, #2112
    vf.max.ieee  v43, v41, v20
    s.addi       s45, s43, #0
    v.extract    s46, v26, #2
    s.addi       s47, s43, #32
    v.splat      v41, s46
    v.rcp.approx v44, v43                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s30, #2176
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v46, v42, v34, v19
    vf.fms       v47, v34, v46, v34
    vf.neg       v46, v47                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v46, v46
    @p1 v.sel        v47, v46, v34
    vf.fms       v34, v43, v44, v19
    vf.fms       v46, v44, v34, v44
    vf.neg       v34, v46                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v46, v34, v44
    vf.mul       v34, v40, v47                   // a/y: faithful quotient
    vf.fms       v44, v34, v42, v40
    vf.fms       v40, v45, v41, v19
    vf.fms       v42, v44, v47, v34
    vf.fms       v44, v41, v40, v41
    vf.neg       v40, v42                        // a/y: one correction to the IEEE quotient
    vf.neg       v42, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v34
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v34, v42, v41
    v.lshr       v40, v44, v4
    vf.cvt.f32.e4m3 v41, v44
    v.and        v42, v40, v39
    s.addi       s48, s43, #64
    v.or         v40, v41, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s45, #0], v40
    v.extract    s45, v26, #3
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s45
    s.addi       s44, s30, #2240
    vf.max.ieee  v42, v41, v20
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v40, v46                   // a/y: faithful quotient
    vf.fms       v47, v44, v43, v40
    vf.fms       v40, v47, v46, v44
    vf.neg       v43, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v42, v41, v19
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v46, v43, v44
    v.lshr       v43, v46, v4
    vf.cvt.f32.e4m3 v44, v46
    vf.fms       v46, v41, v40, v41
    v.and        v40, v43, v39
    s.addi       s45, s43, #96
    v.or         v43, v44, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v46                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v43
    v.extract    s47, v26, #4
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v41
    v.ld.w       v40, [s46, #0]
    v.splat      v41, s47
    s.addi       s46, s30, #2304
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s47, s43, #128
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v34
    v.extract    s48, v26, #5
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s48
    s.addi       s44, s30, #2368
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v42, v40
    vf.fms       v40, v47, v43, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s48, s43, #160
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s45, #0], v42
    v.extract    s45, v26, #6
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s46, #0]
    v.splat      v41, s45
    s.addi       s45, s30, #2432
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s46, s43, #192
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v34
    v.extract    s47, v26, #7
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s47
    s.addi       s44, s30, #2496
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s47, s43, #224
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v42
    v.extract    s48, v26, #8
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s45, #0]
    v.splat      v41, s48
    s.addi       s45, s30, #2560
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.lshr       v34, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s48, s43, #256
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v34
    v.extract    s46, v26, #9
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s46
    s.addi       s44, s30, #2624
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s46, s43, #288
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v42
    v.extract    s47, v26, #10
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s45, #0]
    v.splat      v41, s47
    s.addi       s45, s30, #2688
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s47, s43, #320
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v34
    v.extract    s48, v26, #11
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s48
    s.addi       s44, s30, #2752
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s48, s43, #352
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v42
    v.extract    s46, v26, #12
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s45, #0]
    v.splat      v41, s46
    s.addi       s45, s30, #2816
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s46, s43, #384
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v34
    v.extract    s47, v26, #13
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s47
    s.addi       s44, s30, #2880
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s47, s43, #416
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v42
    v.extract    s48, v26, #14
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s45, #0]
    v.splat      v41, s48
    s.addi       s45, s30, #2944
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.lshr       v34, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s48, s43, #448
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v34
    v.extract    s46, v26, #15
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s46
    s.addi       s44, s30, #3008
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s46, s43, #480
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v42
    v.extract    s47, v26, #0
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s45, #0]
    v.splat      v41, s47
    s.addi       s45, s30, #3072
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s47, s43, #16
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v34
    v.extract    s48, v26, #1
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s48
    s.addi       s44, s30, #3136
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s48, s43, #48
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v42
    v.extract    s46, v26, #2
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s45, #0]
    v.splat      v41, s46
    s.addi       s45, s30, #3200
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s46, s43, #80
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v34
    v.extract    s47, v26, #3
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s47
    s.addi       s44, s30, #3264
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s47, s43, #112
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v42
    v.extract    s48, v26, #4
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s45, #0]
    v.splat      v41, s48
    s.addi       s45, s30, #3328
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.lshr       v34, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s48, s43, #144
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v34
    v.extract    s46, v26, #5
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s46
    s.addi       s44, s30, #3392
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s46, s43, #176
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v42
    v.extract    s47, v26, #6
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s45, #0]
    v.splat      v41, s47
    s.addi       s45, s30, #3456
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s47, s43, #208
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v34
    v.extract    s48, v26, #7
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s48
    s.addi       s44, s30, #3520
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s48, s43, #240
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v42
    v.extract    s46, v26, #8
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s45, #0]
    v.splat      v41, s46
    s.addi       s45, s30, #3584
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s46, s43, #272
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v34
    v.extract    s47, v26, #9
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s47
    s.addi       s44, s30, #3648
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s47, s43, #304
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v42
    v.extract    s48, v26, #10
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s45, #0]
    v.splat      v41, s48
    s.addi       s45, s30, #3712
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.lshr       v34, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s48, s43, #336
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v34
    v.extract    s46, v26, #11
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s46
    s.addi       s44, s30, #3776
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s46, s43, #368
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v42
    v.extract    s47, v26, #12
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s45, #0]
    v.splat      v41, s47
    s.addi       s45, s30, #3840
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s47, s43, #400
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v34
    v.extract    s48, v26, #13
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s48
    s.addi       s44, s30, #3904
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s48, s43, #432
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s46, #0], v42
    v.extract    s46, v26, #14
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s45, #0]
    v.splat      v41, s46
    s.addi       s45, s30, #3968
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s46, s43, #464
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s47, #0], v34
    v.extract    s47, v26, #15
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s44, #0]
    v.splat      v41, s47
    s.addi       s44, s30, #4032
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s47, s43, #496
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s48, #0], v42
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s45, #0]
    s.addi       s45, s43, #64
    s.addi       s48, s43, #128
    vf.mul       v41, v40, v34                   // a/y: faithful quotient
    vf.fms       v45, v41, v43, v40
    vf.fms       v40, v45, v34, v41
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.lshr       v34, v40, v4
    vf.cvt.f32.e4m3 v41, v40
    v.and        v40, v34, v39
    v.or         v34, v41, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v34
    s.addi       s46, s43, #192
    v.ld.w       v34, [s44, #0]
    s.addi       s44, s43, #256
    vf.mul       v40, v34, v42                   // a/y: faithful quotient
    vf.fms       v41, v40, v44, v34
    vf.fms       v34, v41, v42, v40
    vf.neg       v41, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v34, v41, v40
    v.lshr       v40, v34, v4
    vf.cvt.f32.e4m3 v41, v34
    v.and        v34, v40, v39
    v.or         v40, v41, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v40
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s47, s43, #320
    v.ld.w       v34, [s43, #0]
    v.mov        v48, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s45, #0]
    s.addi       s45, s43, #384
    s.addi       s49, s43, #448
    v.mov        v49, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s48, #0]
    v.extract    s43, v23, #0
    v.mov        v50, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s46, #0]
    v.mov        v51, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s44, #0]
    v.mov        v52, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s47, #0]
    v.mov        v53, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s45, #0]
    v.mov        v54, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s49, #0]
    v.mov        v55, v34                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s43, x8dot_done_43
    s.movz       s44, #0
    s.add        s45, s13, s24
    s.addi       s46, s44, #0
    s.addi       s44, s45, #32
    s.addi       s45, s30, #8448
x8dot_row_44:
    s.addi       s47, s31, #-32
    v.movi       v34, #0
    s.sub        s48, s47, s46
    s.add        s47, s44, s46
    v.splat      v40, s48
    s.shli       s48, s46, #4
    s.addi       s49, s46, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s47, v18]            // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s48
    s.movz       s48, #32
    v.st.b       [s47, #0], v34
    fence.acq_rel.device
    s.mov        s46, s49
    s.cmp.lt     s47, s46, s48
    br.nz        s47, x8dot_row_44
x8dot_done_43:
    v.splat      v34, s43
    v.movi       v40, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    v.extract    s45, v24, #0
    s.movz       s46, #32
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s47, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v23, #1
    m.mma.dp.async.k32.e4m3 a8, v48, v56, s45
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s47, x8dot_done_45
    s.add        s48, s13, s24
    s.addi       s49, s44, #0
    s.addi       s50, s48, #32
    s.addi       s48, s30, #8448
x8dot_row_46:
    s.addi       s51, s31, #-32
    v.movi       v34, #0
    s.sub        s52, s51, s49
    s.add        s51, s50, s49
    v.splat      v40, s52
    s.shli       s52, s49, #4
    s.addi       s53, s49, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s51, v27]            // index is in elements (ISA sec 9.1)
    s.add        s51, s48, s52
    v.st.b       [s51, #0], v34
    fence.acq_rel.device
    s.mov        s49, s53
    s.cmp.lt     s51, s49, s46
    br.nz        s51, x8dot_row_46
x8dot_done_45:
    v.splat      v34, s47
    v.movi       v40, #0
    mb.arm       s47, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s48, v24, #1
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s49, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v23, #2
    m.mma.dp.async.k32.e4m3 a9, v48, v56, s46
    mb.wait      s46
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s48, x8dot_done_47
    s.add        s49, s13, s24
    s.addi       s50, s44, #0
    s.addi       s44, s49, #32
    s.addi       s49, s30, #8448
x8dot_row_48:
    s.addi       s51, s31, #-32
    v.movi       v34, #0
    s.sub        s52, s51, s50
    s.add        s51, s44, s50
    v.splat      v40, s52
    s.shli       s52, s50, #4
    s.addi       s53, s50, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s51, v28]            // index is in elements (ISA sec 9.1)
    s.add        s51, s49, s52
    s.movz       s52, #32
    v.st.b       [s51, #0], v34
    fence.acq_rel.device
    s.mov        s50, s53
    s.cmp.lt     s51, s50, s52
    br.nz        s51, x8dot_row_48
x8dot_done_47:
    v.splat      v34, s48
    v.movi       v40, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s48, #0
    v.extract    s49, v24, #2
    s.movz       s50, #32
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s51, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s51, v23, #3
    m.mma.dp.async.k32.e4m3 a10, v48, v56, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s51, x8dot_done_49
    s.add        s52, s13, s24
    s.addi       s53, s48, #0
    s.addi       s54, s52, #32
    s.addi       s52, s30, #8448
x8dot_row_50:
    s.addi       s55, s31, #-32
    v.movi       v34, #0
    s.sub        s56, s55, s53
    s.add        s55, s54, s53
    v.splat      v40, s56
    s.shli       s56, s53, #4
    s.addi       s57, s53, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s55, v21]            // index is in elements (ISA sec 9.1)
    s.add        s55, s52, s56
    v.st.b       [s55, #0], v34
    fence.acq_rel.device
    s.mov        s53, s57
    s.cmp.lt     s55, s53, s50
    br.nz        s55, x8dot_row_50
x8dot_done_49:
    v.splat      v34, s51
    v.movi       v40, #0
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s52, v24, #3
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s53, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s51            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v23, #4
    m.mma.dp.async.k32.e4m3 a11, v48, v56, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s52, x8dot_done_51
    s.add        s53, s13, s24
    s.addi       s54, s48, #0
    s.addi       s48, s53, #32
    s.addi       s53, s30, #8448
x8dot_row_52:
    s.addi       s55, s31, #-32
    v.movi       v34, #0
    s.sub        s56, s55, s54
    s.add        s55, s48, s54
    v.splat      v40, s56
    s.shli       s56, s54, #4
    s.addi       s57, s54, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s55, v29]            // index is in elements (ISA sec 9.1)
    s.add        s55, s53, s56
    s.movz       s56, #32
    v.st.b       [s55, #0], v34
    fence.acq_rel.device
    s.mov        s54, s57
    s.cmp.lt     s55, s54, s56
    br.nz        s55, x8dot_row_52
x8dot_done_51:
    v.splat      v34, s52
    v.movi       v40, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    v.extract    s53, v24, #4
    s.movz       s54, #32
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s55, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s55, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v23, #5
    m.mma.dp.async.k32.e4m3 a12, v48, v56, s53
    mb.wait      s53
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s55, x8dot_done_53
    s.add        s56, s13, s24
    s.addi       s57, s52, #0
    s.addi       s58, s56, #32
    s.addi       s56, s30, #8448
x8dot_row_54:
    s.addi       s59, s31, #-32
    v.movi       v34, #0
    s.sub        s60, s59, s57
    s.add        s59, s58, s57
    v.splat      v40, s60
    s.shli       s60, s57, #4
    s.addi       s20, s57, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s59, v30]            // index is in elements (ISA sec 9.1)
    s.add        s26, s56, s60
    v.st.b       [s26, #0], v34
    fence.acq_rel.device
    s.mov        s57, s20
    s.cmp.lt     s20, s57, s54
    br.nz        s20, x8dot_row_54
x8dot_done_53:
    v.splat      v34, s55
    v.movi       v40, #0
    mb.arm       s20, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s26, v24, #5
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s27, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s27, s20            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s27, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s27, s20          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s20
    mb.arm       s26, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s27, v23, #6
    m.mma.dp.async.k32.e4m3 a13, v48, v56, s26
    mb.wait      s26
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s27, x8dot_done_55
    s.add        s28, s13, s24
    s.addi       s29, s52, #0
    s.addi       s32, s28, #32
    s.addi       s28, s30, #8448
x8dot_row_56:
    s.addi       s33, s31, #-32
    v.movi       v34, #0
    s.sub        s34, s33, s29
    s.add        s33, s32, s29
    v.splat      v40, s34
    s.shli       s34, s29, #4
    s.addi       s35, s29, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s33, v31]            // index is in elements (ISA sec 9.1)
    s.add        s33, s28, s34
    s.movz       s34, #32
    v.st.b       [s33, #0], v34
    fence.acq_rel.device
    s.mov        s29, s35
    s.cmp.lt     s33, s29, s34
    br.nz        s33, x8dot_row_56
x8dot_done_55:
    v.splat      v34, s27
    v.movi       v40, #0
    mb.arm       s27, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s28, #0
    v.extract    s29, v24, #6
    s.movz       s32, #32
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s33, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s33, s27            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s27          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s27
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v23, #7
    m.mma.dp.async.k32.e4m3 a14, v48, v56, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_57
    s.add        s34, s13, s24
    s.addi       s35, s28, #0
    s.addi       s36, s34, #32
    s.addi       s34, s30, #8448
x8dot_row_58:
    s.addi       s37, s31, #-32
    v.movi       v34, #0
    s.sub        s38, s37, s35
    s.add        s37, s36, s35
    v.splat      v40, s38
    s.shli       s38, s35, #4
    s.addi       s39, s35, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s37, v32]            // index is in elements (ISA sec 9.1)
    s.add        s37, s34, s38
    v.st.b       [s37, #0], v34
    fence.acq_rel.device
    s.mov        s35, s39
    s.cmp.lt     s37, s35, s32
    br.nz        s37, x8dot_row_58
x8dot_done_57:
    v.extract    s34, v26, #0
    v.splat      v34, s33
    v.splat      v40, s34
    v.movi       v41, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    vf.max.ieee  v42, v40, v20
    v.extract    s34, v24, #7
    v.cmp.ne     p1, v34, v41
    v.cmp.eq     p2, v34, v41
    s.mov        s35, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s33            // predicated off still completes once (ISA sec 9A.3)
    v.rcp.approx v34, v42                        // ISA 8.8: <= 2**-22 relative
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s28, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s32, s30, #4096
    v.extract    s34, v26, #1
    m.mma.dp.async.k32.e4m3 a15, v48, v56, s28
    mb.wait      s28
    v.ld.w       v40, [s32, #0]
    v.splat      v41, s34
    s.addi       s32, s30, #10240                // 512 bytes of repack scratch
    s.addi       s34, s30, #4160
    vf.max.ieee  v43, v41, v20
    s.addi       s35, s32, #0
    v.extract    s36, v26, #2
    s.addi       s37, s32, #32
    v.splat      v41, s36
    v.rcp.approx v44, v43                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s30, #4224
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v46, v42, v34, v19
    vf.fms       v47, v34, v46, v34
    vf.neg       v46, v47                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v46, v46
    @p1 v.sel        v47, v46, v34
    vf.fms       v34, v43, v44, v19
    vf.fms       v46, v44, v34, v44
    vf.neg       v34, v46                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v46, v34, v44
    vf.mul       v34, v40, v47                   // a/y: faithful quotient
    vf.fms       v44, v34, v42, v40
    vf.fms       v40, v45, v41, v19
    vf.fms       v42, v44, v47, v34
    vf.fms       v44, v41, v40, v41
    vf.neg       v40, v42                        // a/y: one correction to the IEEE quotient
    vf.neg       v42, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v34
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v34, v42, v41
    v.lshr       v40, v44, v4
    vf.cvt.f32.e4m3 v41, v44
    v.and        v42, v40, v39
    s.addi       s38, s32, #64
    v.or         v40, v41, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s39, s30, #4288
    v.st.b       [s35, #0], v40
    v.extract    s35, v26, #3
    v.ld.w       v40, [s34, #0]
    v.splat      v41, s35
    vf.max.ieee  v42, v41, v20
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v40, v46                   // a/y: faithful quotient
    vf.fms       v47, v44, v43, v40
    vf.fms       v40, v47, v46, v44
    vf.neg       v43, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v42, v41, v19
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v46, v43, v44
    v.lshr       v43, v46, v4
    vf.cvt.f32.e4m3 v44, v46
    vf.fms       v46, v41, v40, v41
    v.and        v40, v43, v39
    s.addi       s34, s32, #96
    v.or         v43, v44, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v46                        // Newton step: r0*(2 - x*r0)
    s.addi       s35, s30, #4352
    v.st.b       [s37, #0], v43
    v.extract    s37, v26, #4
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v41
    v.ld.w       v40, [s36, #0]
    v.splat      v41, s37
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s36, s32, #128
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s37, s30, #4416
    v.st.b       [s38, #0], v34
    v.extract    s38, v26, #5
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s39, #0]
    v.splat      v41, s38
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v42, v40
    vf.fms       v40, v47, v43, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s38, s32, #160
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s39, s30, #4480
    v.st.b       [s34, #0], v42
    v.extract    s34, v26, #6
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s35, #0]
    v.splat      v41, s34
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s34, s32, #192
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s35, s30, #4544
    v.st.b       [s36, #0], v34
    v.extract    s36, v26, #7
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s37, #0]
    v.splat      v41, s36
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s36, s32, #224
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s37, s30, #4608
    v.st.b       [s38, #0], v42
    v.extract    s38, v26, #8
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s39, #0]
    v.splat      v41, s38
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.lshr       v34, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s38, s32, #256
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s39, s30, #4672
    v.st.b       [s34, #0], v34
    v.extract    s34, v26, #9
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s35, #0]
    v.splat      v41, s34
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s34, s32, #288
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s35, s30, #4736
    v.st.b       [s36, #0], v42
    v.extract    s36, v26, #10
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s37, #0]
    v.splat      v41, s36
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s36, s32, #320
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s37, s30, #4800
    v.st.b       [s38, #0], v34
    v.extract    s38, v26, #11
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s39, #0]
    v.splat      v41, s38
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s38, s32, #352
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s39, s30, #4864
    v.st.b       [s34, #0], v42
    v.extract    s34, v26, #12
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s35, #0]
    v.splat      v41, s34
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s34, s32, #384
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s35, s30, #4928
    v.st.b       [s36, #0], v34
    v.extract    s36, v26, #13
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s37, #0]
    v.splat      v41, s36
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s36, s32, #416
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s37, s30, #4992
    v.st.b       [s38, #0], v42
    v.extract    s38, v26, #14
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s39, #0]
    v.splat      v41, s38
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.lshr       v34, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s38, s32, #448
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s39, s30, #5056
    v.st.b       [s34, #0], v34
    v.extract    s34, v26, #15
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s35, #0]
    v.splat      v41, s34
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s34, s32, #480
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s35, s30, #5120
    v.st.b       [s36, #0], v42
    v.extract    s36, v26, #0
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s37, #0]
    v.splat      v41, s36
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s36, s32, #16
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s37, s30, #5184
    v.st.b       [s38, #0], v34
    v.extract    s38, v26, #1
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s39, #0]
    v.splat      v41, s38
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s38, s32, #48
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s39, s30, #5248
    v.st.b       [s34, #0], v42
    v.extract    s34, v26, #2
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s35, #0]
    v.splat      v41, s34
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s34, s32, #80
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s35, s30, #5312
    v.st.b       [s36, #0], v34
    v.extract    s36, v26, #3
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s37, #0]
    v.splat      v41, s36
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s36, s32, #112
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s37, s30, #5376
    v.st.b       [s38, #0], v42
    v.extract    s38, v26, #4
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s39, #0]
    v.splat      v41, s38
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.lshr       v34, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s38, s32, #144
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s39, s30, #5440
    v.st.b       [s34, #0], v34
    v.extract    s34, v26, #5
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s35, #0]
    v.splat      v41, s34
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s34, s32, #176
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s35, s30, #5504
    v.st.b       [s36, #0], v42
    v.extract    s36, v26, #6
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s37, #0]
    v.splat      v41, s36
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s36, s32, #208
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s37, s30, #5568
    v.st.b       [s38, #0], v34
    v.extract    s38, v26, #7
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s39, #0]
    v.splat      v41, s38
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s38, s32, #240
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s39, s30, #5632
    v.st.b       [s34, #0], v42
    v.extract    s34, v26, #8
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s35, #0]
    v.splat      v41, s34
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s34, s32, #272
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s35, s30, #5696
    v.st.b       [s36, #0], v34
    v.extract    s36, v26, #9
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s37, #0]
    v.splat      v41, s36
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s36, s32, #304
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s37, s30, #5760
    v.st.b       [s38, #0], v42
    v.extract    s38, v26, #10
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s39, #0]
    v.splat      v41, s38
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.lshr       v34, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s38, s32, #336
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s39, s30, #5824
    v.st.b       [s34, #0], v34
    v.extract    s34, v26, #11
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s35, #0]
    v.splat      v41, s34
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s34, s32, #368
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s35, s30, #5888
    v.st.b       [s36, #0], v42
    v.extract    s36, v26, #12
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s37, #0]
    v.splat      v41, s36
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s36, s32, #400
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s37, s30, #5952
    v.st.b       [s38, #0], v34
    v.extract    s38, v26, #13
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s39, #0]
    v.splat      v41, s38
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s38, s32, #432
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s39, s30, #6016
    v.st.b       [s34, #0], v42
    v.extract    s34, v26, #14
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s35, #0]
    v.splat      v41, s34
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s34, s32, #464
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s35, s30, #6080
    v.st.b       [s36, #0], v34
    v.extract    s36, v26, #15
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s37, #0]
    v.splat      v41, s36
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s36, s32, #496
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s38, #0], v42
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s39, #0]
    s.addi       s37, s32, #64
    s.addi       s38, s32, #128
    s.addi       s39, s32, #192
    vf.mul       v41, v40, v34                   // a/y: faithful quotient
    vf.fms       v45, v41, v43, v40
    vf.fms       v40, v45, v34, v41
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v40, v34, v41
    v.lshr       v34, v40, v4
    vf.cvt.f32.e4m3 v41, v40
    v.and        v40, v34, v39
    v.or         v34, v41, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s34, #0], v34
    s.addi       s34, s32, #256
    v.ld.w       v34, [s35, #0]
    s.addi       s35, s32, #320
    vf.mul       v40, v34, v42                   // a/y: faithful quotient
    vf.fms       v41, v40, v44, v34
    vf.fms       v34, v41, v42, v40
    vf.neg       v41, v34                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v34, v41, v40
    v.lshr       v40, v34, v4
    vf.cvt.f32.e4m3 v41, v34
    v.and        v34, v40, v39
    v.or         v40, v41, v34                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v40
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s36, s32, #384
    v.ld.w       v34, [s32, #0]
    s.addi       s40, s32, #448
    v.mov        v48, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s37, #0]
    v.extract    s32, v23, #0
    v.mov        v49, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s38, #0]
    v.mov        v50, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s39, #0]
    v.mov        v51, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s34, #0]
    v.mov        v52, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s35, #0]
    v.mov        v53, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s36, #0]
    v.mov        v54, v34                        // hand off through the shared window (sec 7.3)
    v.ld.w       v34, [s40, #0]
    v.mov        v55, v34                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s32, x8dot_done_59
    s.movz       s34, #0
    s.add        s35, s13, s24
    s.addi       s36, s34, #0
    s.addi       s34, s35, #64
    s.addi       s35, s30, #8448
x8dot_row_60:
    s.addi       s37, s31, #-64
    v.movi       v34, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v40, s38
    s.shli       s38, s36, #4
    s.addi       s39, s36, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s37, v18]            // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v34
    fence.acq_rel.device
    s.mov        s36, s39
    s.cmp.lt     s37, s36, s38
    br.nz        s37, x8dot_row_60
x8dot_done_59:
    v.splat      v34, s32
    v.movi       v40, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    v.extract    s35, v24, #0
    s.movz       s36, #64
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v23, #1
    m.mma.dp.async.k32.e4m3 a8, v48, v56, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_61
    s.add        s38, s13, s24
    s.addi       s39, s34, #0
    s.addi       s40, s38, #64
    s.addi       s38, s30, #8448
x8dot_row_62:
    s.addi       s41, s31, #-64
    v.movi       v34, #0
    s.sub        s42, s41, s39
    s.add        s41, s40, s39
    v.splat      v40, s42
    s.shli       s42, s39, #4
    s.addi       s43, s39, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s41, v27]            // index is in elements (ISA sec 9.1)
    s.add        s41, s38, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v34
    fence.acq_rel.device
    s.mov        s39, s43
    s.cmp.lt     s41, s39, s42
    br.nz        s41, x8dot_row_62
x8dot_done_61:
    v.splat      v34, s37
    v.movi       v40, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s38, v24, #1
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s39, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s39, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v23, #2
    m.mma.dp.async.k32.e4m3 a9, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s38, x8dot_done_63
    s.add        s39, s13, s24
    s.addi       s40, s34, #0
    s.addi       s34, s39, #64
    s.addi       s39, s30, #8448
x8dot_row_64:
    s.addi       s41, s31, #-64
    v.movi       v34, #0
    s.sub        s42, s41, s40
    s.add        s41, s34, s40
    v.splat      v40, s42
    s.shli       s42, s40, #4
    s.addi       s43, s40, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s41, v28]            // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v34
    fence.acq_rel.device
    s.mov        s40, s43
    s.cmp.lt     s41, s40, s42
    br.nz        s41, x8dot_row_64
x8dot_done_63:
    v.splat      v34, s38
    v.movi       v40, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.extract    s39, v24, #2
    s.movz       s40, #64
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s41, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v23, #3
    m.mma.dp.async.k32.e4m3 a10, v48, v56, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s41, x8dot_done_65
    s.add        s42, s13, s24
    s.addi       s43, s38, #0
    s.addi       s44, s42, #64
    s.addi       s42, s30, #8448
x8dot_row_66:
    s.addi       s45, s31, #-64
    v.movi       v34, #0
    s.sub        s46, s45, s43
    s.add        s45, s44, s43
    v.splat      v40, s46
    s.shli       s46, s43, #4
    s.addi       s47, s43, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s45, v21]            // index is in elements (ISA sec 9.1)
    s.add        s45, s42, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v34
    fence.acq_rel.device
    s.mov        s43, s47
    s.cmp.lt     s45, s43, s46
    br.nz        s45, x8dot_row_66
x8dot_done_65:
    v.splat      v34, s41
    v.movi       v40, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s42, v24, #3
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s43, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v23, #4
    m.mma.dp.async.k32.e4m3 a11, v48, v56, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_67
    s.add        s43, s13, s24
    s.addi       s44, s38, #0
    s.addi       s38, s43, #64
    s.addi       s43, s30, #8448
x8dot_row_68:
    s.addi       s45, s31, #-64
    v.movi       v34, #0
    s.sub        s46, s45, s44
    s.add        s45, s38, s44
    v.splat      v40, s46
    s.shli       s46, s44, #4
    s.addi       s47, s44, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s45, v29]            // index is in elements (ISA sec 9.1)
    s.add        s45, s43, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v34
    fence.acq_rel.device
    s.mov        s44, s47
    s.cmp.lt     s45, s44, s46
    br.nz        s45, x8dot_row_68
x8dot_done_67:
    v.splat      v34, s42
    v.movi       v40, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.extract    s43, v24, #4
    s.movz       s44, #64
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v23, #5
    m.mma.dp.async.k32.e4m3 a12, v48, v56, s43
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s45, x8dot_done_69
    s.add        s46, s13, s24
    s.addi       s47, s42, #0
    s.addi       s48, s46, #64
    s.addi       s46, s30, #8448
x8dot_row_70:
    s.addi       s49, s31, #-64
    v.movi       v34, #0
    s.sub        s50, s49, s47
    s.add        s49, s48, s47
    v.splat      v40, s50
    s.shli       s50, s47, #4
    s.addi       s51, s47, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s49, v30]            // index is in elements (ISA sec 9.1)
    s.add        s49, s46, s50
    s.movz       s50, #32
    v.st.b       [s49, #0], v34
    fence.acq_rel.device
    s.mov        s47, s51
    s.cmp.lt     s49, s47, s50
    br.nz        s49, x8dot_row_70
x8dot_done_69:
    v.splat      v34, s45
    v.movi       v40, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s46, v24, #5
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s47, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v23, #6
    m.mma.dp.async.k32.e4m3 a13, v48, v56, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s46, x8dot_done_71
    s.add        s47, s13, s24
    s.addi       s48, s42, #0
    s.addi       s42, s47, #64
    s.addi       s47, s30, #8448
x8dot_row_72:
    s.addi       s49, s31, #-64
    v.movi       v34, #0
    s.sub        s50, s49, s48
    s.add        s49, s42, s48
    v.splat      v40, s50
    s.shli       s50, s48, #4
    s.addi       s51, s48, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s49, v31]            // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.movz       s50, #32
    v.st.b       [s49, #0], v34
    fence.acq_rel.device
    s.mov        s48, s51
    s.cmp.lt     s49, s48, s50
    br.nz        s49, x8dot_row_72
x8dot_done_71:
    v.splat      v34, s46
    v.movi       v40, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.extract    s47, v24, #6
    s.movz       s48, #64
    v.cmp.ne     p1, v34, v40
    v.cmp.eq     p2, v34, v40
    s.mov        s49, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v23, #7
    m.mma.dp.async.k32.e4m3 a14, v48, v56, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s49, x8dot_done_73
    s.add        s50, s13, s24
    s.addi       s51, s46, #0
    s.addi       s52, s50, #64
    s.addi       s50, s30, #8448
x8dot_row_74:
    s.addi       s53, s31, #-64
    v.movi       v34, #0
    s.sub        s54, s53, s51
    s.add        s53, s52, s51
    v.splat      v40, s54
    s.shli       s54, s51, #4
    s.addi       s55, s51, #1
    v.cmp.gt     p1, v40, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v34, [s53, v32]            // index is in elements (ISA sec 9.1)
    s.add        s53, s50, s54
    s.movz       s54, #32
    v.st.b       [s53, #0], v34
    fence.acq_rel.device
    s.mov        s51, s55
    s.cmp.lt     s53, s51, s54
    br.nz        s53, x8dot_row_74
x8dot_done_73:
    v.extract    s50, v26, #0
    v.splat      v34, s49
    v.splat      v40, s50
    v.movi       v41, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    vf.max.ieee  v42, v40, v20
    v.extract    s50, v24, #7
    v.cmp.ne     p1, v34, v41
    v.cmp.eq     p2, v34, v41
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s49            // predicated off still completes once (ISA sec 9A.3)
    v.rcp.approx v34, v42                        // ISA 8.8: <= 2**-22 relative
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s48, s30, #6144
    v.extract    s50, v26, #1
    m.mma.dp.async.k32.e4m3 a15, v48, v56, s46
    mb.wait      s46
    v.ld.w       v40, [s48, #0]
    v.splat      v41, s50
    s.addi       s48, s30, #10752                // 512 bytes of repack scratch
    s.addi       s50, s30, #6208
    vf.max.ieee  v43, v41, v20
    s.addi       s51, s48, #0
    v.extract    s52, v26, #2
    s.addi       s53, s48, #32
    v.splat      v41, s52
    v.rcp.approx v44, v43                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s30, #6272
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v46, v42, v34, v19
    vf.fms       v47, v34, v46, v34
    vf.neg       v46, v47                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v46, v46
    @p1 v.sel        v47, v46, v34
    vf.fms       v34, v43, v44, v19
    vf.fms       v46, v44, v34, v44
    vf.neg       v34, v46                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v46, v34, v44
    vf.mul       v34, v40, v47                   // a/y: faithful quotient
    vf.fms       v44, v34, v42, v40
    vf.fms       v40, v45, v41, v19
    vf.fms       v42, v44, v47, v34
    vf.fms       v44, v41, v40, v41
    vf.neg       v40, v42                        // a/y: one correction to the IEEE quotient
    vf.neg       v42, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v44, v40, v34
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v34, v42, v41
    v.lshr       v40, v44, v4
    vf.cvt.f32.e4m3 v41, v44
    v.and        v42, v40, v39
    s.addi       s54, s48, #64
    v.or         v40, v41, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s55, s30, #6336
    v.st.b       [s51, #0], v40
    v.extract    s51, v26, #3
    v.ld.w       v40, [s50, #0]
    v.splat      v41, s51
    vf.max.ieee  v42, v41, v20
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v40, v46                   // a/y: faithful quotient
    vf.fms       v47, v44, v43, v40
    vf.fms       v40, v47, v46, v44
    vf.neg       v43, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v42, v41, v19
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v46, v43, v44
    v.lshr       v43, v46, v4
    vf.cvt.f32.e4m3 v44, v46
    vf.fms       v46, v41, v40, v41
    v.and        v40, v43, v39
    s.addi       s50, s48, #96
    v.or         v43, v44, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v46                        // Newton step: r0*(2 - x*r0)
    s.addi       s51, s30, #6400
    v.st.b       [s53, #0], v43
    v.extract    s53, v26, #4
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v43, v40, v41
    v.ld.w       v40, [s52, #0]
    v.splat      v41, s53
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s52, s48, #128
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s53, s30, #6464
    v.st.b       [s54, #0], v34
    v.extract    s54, v26, #5
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s55, #0]
    v.splat      v41, s54
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v43                   // a/y: faithful quotient
    vf.fms       v47, v46, v42, v40
    vf.fms       v40, v47, v43, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s54, s48, #160
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s55, s30, #6528
    v.st.b       [s50, #0], v42
    v.extract    s50, v26, #6
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s51, #0]
    v.splat      v41, s50
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s50, s48, #192
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s51, s30, #6592
    v.st.b       [s52, #0], v34
    v.extract    s52, v26, #7
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s53, #0]
    v.splat      v41, s52
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s52, s48, #224
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s53, s30, #6656
    v.st.b       [s54, #0], v42
    v.extract    s54, v26, #8
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s55, #0]
    v.splat      v41, s54
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.lshr       v34, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s54, s48, #256
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s55, s30, #6720
    v.st.b       [s50, #0], v34
    v.extract    s50, v26, #9
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s51, #0]
    v.splat      v41, s50
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s50, s48, #288
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s51, s30, #6784
    v.st.b       [s52, #0], v42
    v.extract    s52, v26, #10
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s53, #0]
    v.splat      v41, s52
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s52, s48, #320
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s53, s30, #6848
    v.st.b       [s54, #0], v34
    v.extract    s54, v26, #11
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s55, #0]
    v.splat      v41, s54
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s54, s48, #352
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s55, s30, #6912
    v.st.b       [s50, #0], v42
    v.extract    s50, v26, #12
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s51, #0]
    v.splat      v41, s50
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s50, s48, #384
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s51, s30, #6976
    v.st.b       [s52, #0], v34
    v.extract    s52, v26, #13
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s53, #0]
    v.splat      v41, s52
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s52, s48, #416
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s53, s30, #7040
    v.st.b       [s54, #0], v42
    v.extract    s54, v26, #14
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s55, #0]
    v.splat      v41, s54
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.lshr       v34, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s54, s48, #448
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s55, s30, #7104
    v.st.b       [s50, #0], v34
    v.extract    s50, v26, #15
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s51, #0]
    v.splat      v41, s50
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s50, s48, #480
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s51, s30, #7168
    v.st.b       [s52, #0], v42
    v.extract    s52, v26, #0
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s53, #0]
    v.splat      v41, s52
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s52, s48, #16
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s53, s30, #7232
    v.st.b       [s54, #0], v34
    v.extract    s54, v26, #1
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s55, #0]
    v.splat      v41, s54
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s54, s48, #48
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s55, s30, #7296
    v.st.b       [s50, #0], v42
    v.extract    s50, v26, #2
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s51, #0]
    v.splat      v41, s50
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s50, s48, #80
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s51, s30, #7360
    v.st.b       [s52, #0], v34
    v.extract    s52, v26, #3
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s53, #0]
    v.splat      v41, s52
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s52, s48, #112
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s53, s30, #7424
    v.st.b       [s54, #0], v42
    v.extract    s54, v26, #4
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s55, #0]
    v.splat      v41, s54
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.lshr       v34, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s54, s48, #144
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s55, s30, #7488
    v.st.b       [s50, #0], v34
    v.extract    s50, v26, #5
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s51, #0]
    v.splat      v41, s50
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s50, s48, #176
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s51, s30, #7552
    v.st.b       [s52, #0], v42
    v.extract    s52, v26, #6
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s53, #0]
    v.splat      v41, s52
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s52, s48, #208
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s53, s30, #7616
    v.st.b       [s54, #0], v34
    v.extract    s54, v26, #7
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s55, #0]
    v.splat      v41, s54
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s54, s48, #240
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s55, s30, #7680
    v.st.b       [s50, #0], v42
    v.extract    s50, v26, #8
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s51, #0]
    v.splat      v41, s50
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s50, s48, #272
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s51, s30, #7744
    v.st.b       [s52, #0], v34
    v.extract    s52, v26, #9
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s53, #0]
    v.splat      v41, s52
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v46
    v.lshr       v42, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s52, s48, #304
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s53, s30, #7808
    v.st.b       [s54, #0], v42
    v.extract    s54, v26, #10
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s55, #0]
    v.splat      v41, s54
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v43, v34, v46
    v.lshr       v34, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s54, s48, #336
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s55, s30, #7872
    v.st.b       [s50, #0], v34
    v.extract    s50, v26, #11
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s51, #0]
    v.splat      v41, s50
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v46
    v.lshr       v42, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s50, s48, #368
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s51, s30, #7936
    v.st.b       [s52, #0], v42
    v.extract    s52, v26, #12
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s53, #0]
    v.splat      v41, s52
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v41, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v45, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v45, v34, v46
    v.lshr       v34, v45, v4
    vf.cvt.f32.e4m3 v46, v45
    vf.fms       v45, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s52, s48, #400
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v45                        // Newton step: r0*(2 - x*r0)
    s.addi       s53, s30, #8000
    v.st.b       [s54, #0], v34
    v.extract    s54, v26, #13
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s55, #0]
    v.splat      v41, s54
    vf.max.ieee  v45, v41, v20
    v.rcp.approx v41, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v42                   // a/y: faithful quotient
    vf.fms       v47, v46, v43, v40
    vf.fms       v40, v47, v42, v46
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v45, v41, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v46
    v.lshr       v42, v43, v4
    vf.cvt.f32.e4m3 v46, v43
    vf.fms       v43, v41, v40, v41
    v.and        v40, v42, v39
    s.addi       s54, s48, #432
    v.or         v42, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v43                        // Newton step: r0*(2 - x*r0)
    s.addi       s55, s30, #8064
    v.st.b       [s50, #0], v42
    v.extract    s50, v26, #14
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v42, v40, v41
    v.ld.w       v40, [s51, #0]
    v.splat      v41, s50
    vf.max.ieee  v43, v41, v20
    v.rcp.approx v41, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v40, v34                   // a/y: faithful quotient
    vf.fms       v47, v46, v44, v40
    vf.fms       v40, v47, v34, v46
    vf.neg       v34, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v43, v41, v19
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v44, v34, v46
    v.lshr       v34, v44, v4
    vf.cvt.f32.e4m3 v46, v44
    vf.fms       v44, v41, v40, v41
    v.and        v40, v34, v39
    s.addi       s50, s48, #464
    v.or         v34, v46, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    s.addi       s51, s30, #8128
    v.st.b       [s52, #0], v34
    v.extract    s52, v26, #15
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v34, v40, v41
    v.ld.w       v40, [s53, #0]
    v.splat      v41, s52
    vf.max.ieee  v44, v41, v20
    v.rcp.approx v20, v44                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v41, v40, v42                   // a/y: faithful quotient
    vf.fms       v46, v41, v45, v40
    vf.fms       v40, v46, v42, v41
    vf.neg       v42, v40                        // a/y: one correction to the IEEE quotient
    vf.fms       v40, v44, v20, v19
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v41
    v.lshr       v41, v19, v4
    vf.cvt.f32.e4m3 v42, v19
    vf.fms       v19, v20, v40, v20
    v.and        v40, v41, v39
    s.addi       s52, s48, #496
    v.or         v41, v42, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.neg       v40, v19                        // Newton step: r0*(2 - x*r0)
    v.st.b       [s54, #0], v41
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v19, v40, v20
    v.ld.w       v20, [s55, #0]
    s.addi       s53, s48, #64
    s.addi       s54, s48, #128
    s.addi       s55, s48, #192
    vf.mul       v40, v20, v34                   // a/y: faithful quotient
    vf.fms       v41, v40, v43, v20
    vf.fms       v20, v41, v34, v40
    vf.neg       v34, v20                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v34, v34
    @p1 v.sel        v20, v34, v40
    v.lshr       v34, v20, v4
    vf.cvt.f32.e4m3 v40, v20
    v.and        v20, v34, v39
    v.or         v34, v40, v20                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s50, #0], v34
    s.addi       s50, s48, #256
    v.ld.w       v20, [s51, #0]
    s.addi       s51, s48, #320
    vf.mul       v34, v20, v19                   // a/y: faithful quotient
    vf.fms       v40, v34, v44, v20
    vf.fms       v20, v40, v19, v34
    vf.neg       v19, v20                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v20, v19, v34
    v.lshr       v19, v20, v4
    vf.cvt.f32.e4m3 v4, v20
    v.and        v20, v19, v39
    v.or         v19, v4, v20                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v19
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s52, s48, #384
    v.ld.w       v4, [s48, #0]
    s.addi       s56, s48, #448
    v.mov        v48, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s53, #0]
    v.extract    s48, v23, #0
    v.mov        v49, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s54, #0]
    v.mov        v50, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s55, #0]
    v.mov        v51, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s50, #0]
    v.mov        v52, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s51, #0]
    v.mov        v53, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s52, #0]
    v.mov        v54, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s56, #0]
    v.mov        v55, v4                         // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s48, x8dot_done_75
    s.movz       s50, #0
    s.add        s51, s13, s24
    s.addi       s52, s50, #0
    s.addi       s50, s51, #96
    s.addi       s51, s30, #8448
x8dot_row_76:
    s.addi       s53, s31, #-96
    v.movi       v4, #0
    s.sub        s54, s53, s52
    s.add        s53, s50, s52
    v.splat      v19, s54
    s.shli       s54, s52, #4
    s.addi       s55, s52, #1
    v.cmp.gt     p1, v19, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v4, [s53, v18]             // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.movz       s54, #32
    v.st.b       [s53, #0], v4
    fence.acq_rel.device
    s.mov        s52, s55
    s.cmp.lt     s53, s52, s54
    br.nz        s53, x8dot_row_76
x8dot_done_75:
    v.splat      v4, s48
    v.movi       v18, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.extract    s51, v24, #0
    s.movz       s52, #96
    v.cmp.ne     p1, v4, v18
    v.cmp.eq     p2, v4, v18
    s.mov        s53, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v23, #1
    m.mma.dp.async.k32.e4m3 a8, v48, v56, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s53, x8dot_done_77
    s.add        s54, s13, s24
    s.addi       s55, s50, #0
    s.addi       s56, s54, #96
    s.addi       s54, s30, #8448
x8dot_row_78:
    s.addi       s57, s31, #-96
    v.movi       v4, #0
    s.sub        s58, s57, s55
    s.add        s57, s56, s55
    v.splat      v18, s58
    s.shli       s58, s55, #4
    s.addi       s59, s55, #1
    v.cmp.gt     p1, v18, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v4, [s57, v27]             // index is in elements (ISA sec 9.1)
    s.add        s57, s54, s58
    s.movz       s58, #32
    v.st.b       [s57, #0], v4
    fence.acq_rel.device
    s.mov        s55, s59
    s.cmp.lt     s57, s55, s58
    br.nz        s57, x8dot_row_78
x8dot_done_77:
    v.splat      v4, s53
    v.movi       v18, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s54, v24, #1
    v.cmp.ne     p1, v4, v18
    v.cmp.eq     p2, v4, v18
    s.mov        s55, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s55, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v23, #2
    m.mma.dp.async.k32.e4m3 a9, v48, v56, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s54, x8dot_done_79
    s.add        s55, s13, s24
    s.addi       s56, s50, #0
    s.addi       s50, s55, #96
    s.addi       s55, s30, #8448
x8dot_row_80:
    s.addi       s57, s31, #-96
    v.movi       v4, #0
    s.sub        s58, s57, s56
    s.add        s57, s50, s56
    v.splat      v18, s58
    s.shli       s58, s56, #4
    s.addi       s59, s56, #1
    v.cmp.gt     p1, v18, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v4, [s57, v28]             // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.movz       s58, #32
    v.st.b       [s57, #0], v4
    fence.acq_rel.device
    s.mov        s56, s59
    s.cmp.lt     s57, s56, s58
    br.nz        s57, x8dot_row_80
x8dot_done_79:
    v.splat      v4, s54
    v.movi       v18, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    v.extract    s55, v24, #2
    s.movz       s56, #96
    v.cmp.ne     p1, v4, v18
    v.cmp.eq     p2, v4, v18
    s.mov        s57, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s57, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s57, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s55, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s57, v23, #3
    m.mma.dp.async.k32.e4m3 a10, v48, v56, s55
    mb.wait      s55
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s57, x8dot_done_81
    s.add        s58, s13, s24
    s.addi       s59, s54, #0
    s.addi       s60, s58, #96
    s.addi       s58, s30, #8448
x8dot_row_82:
    s.addi       s20, s31, #-96
    v.movi       v4, #0
    s.sub        s26, s20, s59
    s.add        s20, s60, s59
    v.splat      v18, s26
    s.shli       s26, s59, #4
    s.addi       s27, s59, #1
    v.cmp.gt     p1, v18, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v4, [s20, v21]             // index is in elements (ISA sec 9.1)
    s.add        s20, s58, s26
    s.movz       s26, #32
    v.st.b       [s20, #0], v4
    fence.acq_rel.device
    s.mov        s59, s27
    s.cmp.lt     s20, s59, s26
    br.nz        s20, x8dot_row_82
x8dot_done_81:
    v.splat      v4, s57
    v.movi       v18, #0
    mb.arm       s20, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s26, v24, #3
    v.cmp.ne     p1, v4, v18
    v.cmp.eq     p2, v4, v18
    s.mov        s27, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s27, s20            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s27, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s27, s20          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s20
    mb.arm       s26, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s27, v23, #4
    m.mma.dp.async.k32.e4m3 a11, v48, v56, s26
    mb.wait      s26
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s27, x8dot_done_83
    s.add        s28, s13, s24
    s.addi       s29, s54, #0
    s.addi       s32, s28, #96
    s.addi       s28, s30, #8448
x8dot_row_84:
    s.addi       s33, s31, #-96
    v.movi       v4, #0
    s.sub        s34, s33, s29
    s.add        s33, s32, s29
    v.splat      v18, s34
    s.shli       s34, s29, #4
    s.addi       s35, s29, #1
    v.cmp.gt     p1, v18, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v4, [s33, v29]             // index is in elements (ISA sec 9.1)
    s.add        s33, s28, s34
    s.movz       s34, #32
    v.st.b       [s33, #0], v4
    fence.acq_rel.device
    s.mov        s29, s35
    s.cmp.lt     s33, s29, s34
    br.nz        s33, x8dot_row_84
x8dot_done_83:
    v.splat      v4, s27
    v.movi       v18, #0
    mb.arm       s27, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s28, #0
    v.extract    s29, v24, #4
    s.movz       s32, #96
    v.cmp.ne     p1, v4, v18
    v.cmp.eq     p2, v4, v18
    s.mov        s33, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s33, s27            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s27          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s27
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v23, #5
    m.mma.dp.async.k32.e4m3 a12, v48, v56, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_85
    s.add        s34, s13, s24
    s.addi       s35, s28, #0
    s.addi       s36, s34, #96
    s.addi       s34, s30, #8448
x8dot_row_86:
    s.addi       s37, s31, #-96
    v.movi       v4, #0
    s.sub        s38, s37, s35
    s.add        s37, s36, s35
    v.splat      v18, s38
    s.shli       s38, s35, #4
    s.addi       s39, s35, #1
    v.cmp.gt     p1, v18, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v4, [s37, v30]             // index is in elements (ISA sec 9.1)
    s.add        s37, s34, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v4
    fence.acq_rel.device
    s.mov        s35, s39
    s.cmp.lt     s37, s35, s38
    br.nz        s37, x8dot_row_86
x8dot_done_85:
    v.splat      v4, s33
    v.movi       v18, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s34, v24, #5
    v.cmp.ne     p1, v4, v18
    v.cmp.eq     p2, v4, v18
    s.mov        s35, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v23, #6
    m.mma.dp.async.k32.e4m3 a13, v48, v56, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_87
    s.add        s35, s13, s24
    s.addi       s36, s28, #0
    s.addi       s28, s35, #96
    s.addi       s35, s30, #8448
x8dot_row_88:
    s.addi       s37, s31, #-96
    v.movi       v4, #0
    s.sub        s38, s37, s36
    s.add        s37, s28, s36
    v.splat      v18, s38
    s.shli       s38, s36, #4
    s.addi       s39, s36, #1
    v.cmp.gt     p1, v18, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v4, [s37, v31]             // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v4
    fence.acq_rel.device
    s.mov        s36, s39
    s.cmp.lt     s37, s36, s38
    br.nz        s37, x8dot_row_88
x8dot_done_87:
    v.splat      v4, s34
    v.movi       v18, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    v.extract    s35, v24, #6
    s.movz       s36, #96
    v.cmp.ne     p1, v4, v18
    v.cmp.eq     p2, v4, v18
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v23, #7
    m.mma.dp.async.k32.e4m3 a14, v48, v56, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_89
    s.add        s38, s13, s24
    s.addi       s39, s34, #0
    s.addi       s40, s38, #96
    s.addi       s38, s30, #8448
x8dot_row_90:
    s.addi       s41, s31, #-96
    v.movi       v4, #0
    s.sub        s42, s41, s39
    s.add        s41, s40, s39
    v.splat      v18, s42
    s.shli       s42, s39, #4
    s.addi       s43, s39, #1
    v.cmp.gt     p1, v18, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v4, [s41, v32]             // index is in elements (ISA sec 9.1)
    s.add        s41, s38, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v4
    fence.acq_rel.device
    s.mov        s39, s43
    s.cmp.lt     s41, s39, s42
    br.nz        s41, x8dot_row_90
x8dot_done_89:
    v.splat      v4, s37
    v.movi       v18, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s37, v24, #7
    v.cmp.ne     p1, v4, v18
    v.cmp.eq     p2, v4, v18
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s37, s30, #11264
    s.movz       s38, #1
    m.mma.dp.async.k32.e4m3 a15, v48, v56, s36
    mb.wait      s36
    a.vread      v4, a8, s34
    s.addi       s34, s37, #64
    s.movz       s39, #2
    v.st.w       [s37, #0], v4
    a.vread      v4, a8, s38
    s.addi       s38, s37, #128
    s.movz       s40, #3
    s.addi       s41, s37, #192
    s.movz       s42, #4
    s.addi       s43, s37, #256
    s.movz       s44, #5
    s.addi       s45, s37, #320
    s.movz       s46, #6
    s.addi       s47, s37, #384
    s.movz       s48, #7
    s.addi       s49, s37, #448
    s.movz       s50, #8
    s.addi       s51, s37, #512
    s.movz       s52, #9
    s.addi       s53, s37, #576
    v.st.w       [s34, #0], v4
    a.vread      v4, a8, s39
    s.movz       s34, #10
    s.addi       s39, s37, #640
    v.st.w       [s38, #0], v4
    a.vread      v4, a8, s40
    s.movz       s38, #11
    s.addi       s40, s37, #704
    v.st.w       [s41, #0], v4
    a.vread      v4, a8, s42
    s.movz       s41, #12
    s.addi       s42, s37, #768
    v.st.w       [s43, #0], v4
    a.vread      v4, a8, s44
    s.movz       s43, #13
    s.addi       s44, s37, #832
    v.st.w       [s45, #0], v4
    a.vread      v4, a8, s46
    s.movz       s45, #14
    s.addi       s46, s37, #896
    s.addi       s54, s37, #960
    v.st.w       [s47, #0], v4
    a.vread      v4, a8, s48
    s.movz       s37, #15
    s.movz       s47, #0
    v.st.w       [s49, #0], v4
    a.vread      v4, a8, s50
    s.addi       s48, s30, #12288
    s.movz       s49, #1
    v.st.w       [s51, #0], v4
    a.vread      v4, a8, s52
    s.addi       s50, s48, #64
    s.movz       s51, #2
    v.st.w       [s53, #0], v4
    a.vread      v4, a8, s34
    s.addi       s34, s48, #128
    s.movz       s52, #3
    v.st.w       [s39, #0], v4
    a.vread      v4, a8, s38
    s.addi       s38, s48, #192
    s.movz       s39, #4
    v.st.w       [s40, #0], v4
    a.vread      v4, a8, s41
    s.addi       s40, s48, #256
    s.movz       s41, #5
    v.st.w       [s42, #0], v4
    a.vread      v4, a8, s43
    s.addi       s42, s48, #320
    s.movz       s43, #6
    v.st.w       [s44, #0], v4
    a.vread      v4, a8, s45
    s.addi       s44, s48, #384
    s.movz       s45, #7
    v.st.w       [s46, #0], v4
    a.vread      v4, a8, s37
    s.addi       s37, s48, #448
    s.movz       s46, #8
    v.st.w       [s54, #0], v4
    fence.acq_rel.device
    a.vread      v4, a9, s47
    s.addi       s47, s48, #512
    s.movz       s53, #9
    v.st.w       [s48, #0], v4
    a.vread      v4, a9, s49
    s.addi       s49, s48, #576
    v.st.w       [s50, #0], v4
    a.vread      v4, a9, s51
    s.movz       s50, #10
    s.addi       s51, s48, #640
    v.st.w       [s34, #0], v4
    a.vread      v4, a9, s52
    s.movz       s34, #11
    s.addi       s52, s48, #704
    v.st.w       [s38, #0], v4
    a.vread      v4, a9, s39
    s.movz       s38, #12
    s.addi       s39, s48, #768
    v.st.w       [s40, #0], v4
    a.vread      v4, a9, s41
    s.movz       s40, #13
    s.addi       s41, s48, #832
    v.st.w       [s42, #0], v4
    a.vread      v4, a9, s43
    s.movz       s42, #14
    s.addi       s43, s48, #896
    s.addi       s54, s48, #960
    v.st.w       [s44, #0], v4
    a.vread      v4, a9, s45
    s.movz       s44, #15
    s.movz       s45, #0
    v.st.w       [s37, #0], v4
    a.vread      v4, a9, s46
    s.addi       s37, s30, #13312
    s.movz       s46, #1
    v.st.w       [s47, #0], v4
    a.vread      v4, a9, s53
    s.addi       s47, s37, #64
    s.movz       s48, #2
    v.st.w       [s49, #0], v4
    a.vread      v4, a9, s50
    s.addi       s49, s37, #128
    s.movz       s50, #3
    v.st.w       [s51, #0], v4
    a.vread      v4, a9, s34
    s.addi       s34, s37, #192
    s.movz       s51, #4
    v.st.w       [s52, #0], v4
    a.vread      v4, a9, s38
    s.addi       s38, s37, #256
    s.movz       s52, #5
    v.st.w       [s39, #0], v4
    a.vread      v4, a9, s40
    s.addi       s39, s37, #320
    s.movz       s40, #6
    v.st.w       [s41, #0], v4
    a.vread      v4, a9, s42
    s.addi       s41, s37, #384
    s.movz       s42, #7
    v.st.w       [s43, #0], v4
    a.vread      v4, a9, s44
    s.addi       s43, s37, #448
    s.movz       s44, #8
    v.st.w       [s54, #0], v4
    fence.acq_rel.device
    a.vread      v4, a10, s45
    s.addi       s45, s37, #512
    s.movz       s53, #9
    v.st.w       [s37, #0], v4
    a.vread      v4, a10, s46
    s.addi       s46, s37, #576
    v.st.w       [s47, #0], v4
    a.vread      v4, a10, s48
    s.movz       s47, #10
    s.addi       s48, s37, #640
    v.st.w       [s49, #0], v4
    a.vread      v4, a10, s50
    s.movz       s49, #11
    s.addi       s50, s37, #704
    v.st.w       [s34, #0], v4
    a.vread      v4, a10, s51
    s.movz       s34, #12
    s.addi       s51, s37, #768
    v.st.w       [s38, #0], v4
    a.vread      v4, a10, s52
    s.movz       s38, #13
    s.addi       s52, s37, #832
    v.st.w       [s39, #0], v4
    a.vread      v4, a10, s40
    s.movz       s39, #14
    s.addi       s40, s37, #896
    s.addi       s54, s37, #960
    v.st.w       [s41, #0], v4
    a.vread      v4, a10, s42
    s.movz       s37, #15
    s.movz       s41, #0
    v.st.w       [s43, #0], v4
    a.vread      v4, a10, s44
    s.addi       s42, s30, #14336
    s.movz       s43, #1
    v.st.w       [s45, #0], v4
    a.vread      v4, a10, s53
    s.addi       s44, s42, #64
    s.movz       s45, #2
    v.st.w       [s46, #0], v4
    a.vread      v4, a10, s47
    s.addi       s46, s42, #128
    s.movz       s47, #3
    v.st.w       [s48, #0], v4
    a.vread      v4, a10, s49
    s.addi       s48, s42, #192
    s.movz       s49, #4
    v.st.w       [s50, #0], v4
    a.vread      v4, a10, s34
    s.addi       s34, s42, #256
    s.movz       s50, #5
    v.st.w       [s51, #0], v4
    a.vread      v4, a10, s38
    s.addi       s38, s42, #320
    s.movz       s51, #6
    v.st.w       [s52, #0], v4
    a.vread      v4, a10, s39
    s.addi       s39, s42, #384
    s.movz       s52, #7
    v.st.w       [s40, #0], v4
    a.vread      v4, a10, s37
    s.addi       s37, s42, #448
    s.movz       s40, #8
    v.st.w       [s54, #0], v4
    fence.acq_rel.device
    a.vread      v4, a11, s41
    s.addi       s41, s42, #512
    s.movz       s53, #9
    v.st.w       [s42, #0], v4
    a.vread      v4, a11, s43
    s.addi       s43, s42, #576
    v.st.w       [s44, #0], v4
    a.vread      v4, a11, s45
    s.movz       s44, #10
    s.addi       s45, s42, #640
    v.st.w       [s46, #0], v4
    a.vread      v4, a11, s47
    s.movz       s46, #11
    s.addi       s47, s42, #704
    v.st.w       [s48, #0], v4
    a.vread      v4, a11, s49
    s.movz       s48, #12
    s.addi       s49, s42, #768
    v.st.w       [s34, #0], v4
    a.vread      v4, a11, s50
    s.movz       s34, #13
    s.addi       s50, s42, #832
    v.st.w       [s38, #0], v4
    a.vread      v4, a11, s51
    s.movz       s38, #14
    s.addi       s51, s42, #896
    s.addi       s54, s42, #960
    v.st.w       [s39, #0], v4
    a.vread      v4, a11, s52
    s.movz       s39, #15
    s.movz       s42, #0
    v.st.w       [s37, #0], v4
    a.vread      v4, a11, s40
    s.addi       s37, s30, #15360
    s.movz       s40, #1
    v.st.w       [s41, #0], v4
    a.vread      v4, a11, s53
    s.addi       s41, s37, #64
    s.movz       s52, #2
    v.st.w       [s43, #0], v4
    a.vread      v4, a11, s44
    s.addi       s43, s37, #128
    s.movz       s44, #3
    v.st.w       [s45, #0], v4
    a.vread      v4, a11, s46
    s.addi       s45, s37, #192
    s.movz       s46, #4
    v.st.w       [s47, #0], v4
    a.vread      v4, a11, s48
    s.addi       s47, s37, #256
    s.movz       s48, #5
    v.st.w       [s49, #0], v4
    a.vread      v4, a11, s34
    s.addi       s34, s37, #320
    s.movz       s49, #6
    v.st.w       [s50, #0], v4
    a.vread      v4, a11, s38
    s.addi       s38, s37, #384
    s.movz       s50, #7
    v.st.w       [s51, #0], v4
    a.vread      v4, a11, s39
    s.addi       s39, s37, #448
    s.movz       s51, #8
    v.st.w       [s54, #0], v4
    fence.acq_rel.device
    a.vread      v4, a12, s42
    s.addi       s42, s37, #512
    s.movz       s53, #9
    v.st.w       [s37, #0], v4
    a.vread      v4, a12, s40
    s.addi       s40, s37, #576
    v.st.w       [s41, #0], v4
    a.vread      v4, a12, s52
    s.movz       s41, #10
    s.addi       s52, s37, #640
    v.st.w       [s43, #0], v4
    a.vread      v4, a12, s44
    s.movz       s43, #11
    s.addi       s44, s37, #704
    v.st.w       [s45, #0], v4
    a.vread      v4, a12, s46
    s.movz       s45, #12
    s.addi       s46, s37, #768
    v.st.w       [s47, #0], v4
    a.vread      v4, a12, s48
    s.movz       s47, #13
    s.addi       s48, s37, #832
    v.st.w       [s34, #0], v4
    a.vread      v4, a12, s49
    s.movz       s34, #14
    s.addi       s49, s37, #896
    s.addi       s54, s37, #960
    v.st.w       [s38, #0], v4
    a.vread      v4, a12, s50
    s.movz       s37, #15
    s.movz       s38, #0
    v.st.w       [s39, #0], v4
    a.vread      v4, a12, s51
    s.addi       s39, s30, #16384
    s.movz       s50, #1
    v.st.w       [s42, #0], v4
    a.vread      v4, a12, s53
    s.addi       s42, s39, #64
    s.movz       s51, #2
    v.st.w       [s40, #0], v4
    a.vread      v4, a12, s41
    s.addi       s40, s39, #128
    s.movz       s41, #3
    v.st.w       [s52, #0], v4
    a.vread      v4, a12, s43
    s.addi       s43, s39, #192
    s.movz       s52, #4
    v.st.w       [s44, #0], v4
    a.vread      v4, a12, s45
    s.addi       s44, s39, #256
    s.movz       s45, #5
    v.st.w       [s46, #0], v4
    a.vread      v4, a12, s47
    s.addi       s46, s39, #320
    s.movz       s47, #6
    v.st.w       [s48, #0], v4
    a.vread      v4, a12, s34
    s.addi       s34, s39, #384
    s.movz       s48, #7
    v.st.w       [s49, #0], v4
    a.vread      v4, a12, s37
    s.addi       s37, s39, #448
    s.movz       s49, #8
    v.st.w       [s54, #0], v4
    fence.acq_rel.device
    a.vread      v4, a13, s38
    s.addi       s38, s39, #512
    s.movz       s53, #9
    v.st.w       [s39, #0], v4
    a.vread      v4, a13, s50
    s.addi       s50, s39, #576
    v.st.w       [s42, #0], v4
    a.vread      v4, a13, s51
    s.movz       s42, #10
    s.addi       s51, s39, #640
    v.st.w       [s40, #0], v4
    a.vread      v4, a13, s41
    s.movz       s40, #11
    s.addi       s41, s39, #704
    v.st.w       [s43, #0], v4
    a.vread      v4, a13, s52
    s.movz       s43, #12
    s.addi       s52, s39, #768
    v.st.w       [s44, #0], v4
    a.vread      v4, a13, s45
    s.movz       s44, #13
    s.addi       s45, s39, #832
    v.st.w       [s46, #0], v4
    a.vread      v4, a13, s47
    s.movz       s46, #14
    s.addi       s47, s39, #896
    s.addi       s54, s39, #960
    v.st.w       [s34, #0], v4
    a.vread      v4, a13, s48
    s.movz       s34, #15
    s.movz       s39, #0
    v.st.w       [s37, #0], v4
    a.vread      v4, a13, s49
    s.addi       s37, s30, #17408
    s.movz       s48, #1
    v.st.w       [s38, #0], v4
    a.vread      v4, a13, s53
    s.addi       s38, s37, #64
    s.movz       s49, #2
    v.st.w       [s50, #0], v4
    a.vread      v4, a13, s42
    s.addi       s42, s37, #128
    s.movz       s50, #3
    v.st.w       [s51, #0], v4
    a.vread      v4, a13, s40
    s.addi       s40, s37, #192
    s.movz       s51, #4
    v.st.w       [s41, #0], v4
    a.vread      v4, a13, s43
    s.addi       s41, s37, #256
    s.movz       s43, #5
    v.st.w       [s52, #0], v4
    a.vread      v4, a13, s44
    s.addi       s44, s37, #320
    s.movz       s52, #6
    v.st.w       [s45, #0], v4
    a.vread      v4, a13, s46
    s.addi       s45, s37, #384
    s.movz       s46, #7
    v.st.w       [s47, #0], v4
    a.vread      v4, a13, s34
    s.addi       s34, s37, #448
    s.movz       s47, #8
    v.st.w       [s54, #0], v4
    fence.acq_rel.device
    a.vread      v4, a14, s39
    s.addi       s39, s37, #512
    s.movz       s53, #9
    v.st.w       [s37, #0], v4
    a.vread      v4, a14, s48
    s.addi       s48, s37, #576
    v.st.w       [s38, #0], v4
    a.vread      v4, a14, s49
    s.movz       s38, #10
    s.addi       s49, s37, #640
    v.st.w       [s42, #0], v4
    a.vread      v4, a14, s50
    s.movz       s42, #11
    s.addi       s50, s37, #704
    v.st.w       [s40, #0], v4
    a.vread      v4, a14, s51
    s.movz       s40, #12
    s.addi       s51, s37, #768
    v.st.w       [s41, #0], v4
    a.vread      v4, a14, s43
    s.movz       s41, #13
    s.addi       s43, s37, #832
    v.st.w       [s44, #0], v4
    a.vread      v4, a14, s52
    s.movz       s44, #14
    s.addi       s52, s37, #896
    s.addi       s54, s37, #960
    v.st.w       [s45, #0], v4
    a.vread      v4, a14, s46
    s.movz       s37, #15
    s.movz       s45, #0
    v.st.w       [s34, #0], v4
    a.vread      v4, a14, s47
    s.addi       s34, s30, #18432
    s.movz       s46, #1
    v.st.w       [s39, #0], v4
    a.vread      v4, a14, s53
    s.addi       s39, s34, #64
    s.movz       s47, #2
    v.st.w       [s48, #0], v4
    a.vread      v4, a14, s38
    s.addi       s38, s34, #128
    s.movz       s48, #3
    v.st.w       [s49, #0], v4
    a.vread      v4, a14, s42
    s.addi       s42, s34, #192
    s.movz       s49, #4
    v.st.w       [s50, #0], v4
    a.vread      v4, a14, s40
    s.addi       s40, s34, #256
    s.movz       s50, #5
    v.st.w       [s51, #0], v4
    a.vread      v4, a14, s41
    s.addi       s41, s34, #320
    s.movz       s51, #6
    v.st.w       [s43, #0], v4
    a.vread      v4, a14, s44
    s.addi       s43, s34, #384
    s.movz       s44, #7
    v.st.w       [s52, #0], v4
    a.vread      v4, a14, s37
    s.addi       s37, s34, #448
    s.movz       s52, #8
    v.st.w       [s54, #0], v4
    fence.acq_rel.device
    a.vread      v4, a15, s45
    s.addi       s45, s34, #512
    s.movz       s53, #9
    v.st.w       [s34, #0], v4
    a.vread      v4, a15, s46
    s.addi       s46, s34, #576
    v.st.w       [s39, #0], v4
    a.vread      v4, a15, s47
    s.movz       s39, #10
    s.addi       s47, s34, #640
    v.st.w       [s38, #0], v4
    a.vread      v4, a15, s48
    s.movz       s38, #11
    s.addi       s48, s34, #704
    v.st.w       [s42, #0], v4
    a.vread      v4, a15, s49
    s.movz       s42, #12
    s.addi       s49, s34, #768
    v.st.w       [s40, #0], v4
    a.vread      v4, a15, s50
    s.movz       s40, #13
    s.addi       s50, s34, #832
    v.st.w       [s41, #0], v4
    a.vread      v4, a15, s51
    s.movz       s41, #14
    s.addi       s51, s34, #896
    s.addi       s54, s34, #960
    v.st.w       [s43, #0], v4
    a.vread      v4, a15, s44
    s.movz       s34, #15
    s.movz       s43, #0
    v.st.w       [s37, #0], v4
    a.vread      v4, a15, s52
    s.addi       s37, s30, #11264
    v.extract    s44, v26, #0
    v.splat      v18, s44
    s.addi       s44, s30, #19456
    v.st.w       [s45, #0], v4
    a.vread      v4, a15, s53
    s.movz       s45, #1
    s.addi       s52, s30, #11328
    v.st.w       [s46, #0], v4
    a.vread      v4, a15, s39
    v.extract    s39, v26, #1
    s.addi       s46, s44, #64
    v.splat      v19, s39
    s.movz       s39, #2
    v.st.w       [s47, #0], v4
    a.vread      v4, a15, s38
    s.addi       s38, s30, #11392
    v.extract    s47, v26, #2
    v.splat      v20, s47
    s.addi       s47, s44, #128
    v.st.w       [s48, #0], v4
    a.vread      v4, a15, s42
    s.addi       s42, s44, #192
    v.st.w       [s49, #0], v4
    a.vread      v4, a15, s40
    s.movz       s40, #3
    s.addi       s48, s30, #11456
    v.st.w       [s50, #0], v4
    a.vread      v4, a15, s41
    v.extract    s41, v26, #3
    v.splat      v21, s41
    v.st.w       [s51, #0], v4
    a.vread      v4, a15, s34
    s.movz       s34, #4
    s.addi       s41, s44, #256
    v.st.w       [s54, #0], v4
    fence.acq_rel.device
    a.vread      v4, a0, s43
    s.addi       s43, s30, #11520
    v.extract    s49, v26, #4
    v.splat      v23, s49
    v.ld.w       v24, [s37, #0]
    vf.mul       v27, v24, v18
    s.addi       s37, s44, #320
    vf.mul       v18, v27, v2
    s.movz       s49, #5
    vf.add       v24, v4, v18
    v.st.w       [s44, #0], v24
    a.vread      v4, a0, s45
    s.addi       s45, s30, #11584
    v.extract    s50, v26, #5
    v.splat      v18, s50
    v.ld.w       v24, [s52, #0]
    vf.mul       v27, v24, v19
    s.addi       s50, s44, #384
    vf.mul       v19, v27, v2
    s.movz       s51, #6
    vf.add       v24, v4, v19
    v.st.w       [s46, #0], v24
    a.vread      v4, a0, s39
    s.addi       s39, s30, #11648
    v.extract    s46, v26, #6
    v.splat      v19, s46
    v.ld.w       v24, [s38, #0]
    vf.mul       v27, v24, v20
    s.addi       s38, s44, #448
    vf.mul       v20, v27, v2
    s.movz       s46, #7
    vf.add       v24, v4, v20
    v.st.w       [s47, #0], v24
    a.vread      v4, a0, s40
    s.addi       s40, s30, #11712
    v.extract    s47, v26, #7
    v.splat      v20, s47
    v.ld.w       v24, [s48, #0]
    vf.mul       v27, v24, v21
    s.addi       s47, s44, #512
    vf.mul       v21, v27, v2
    s.movz       s48, #8
    vf.add       v24, v4, v21
    v.st.w       [s42, #0], v24
    a.vread      v4, a0, s34
    s.addi       s34, s30, #11776
    v.extract    s42, v26, #8
    v.splat      v21, s42
    v.ld.w       v24, [s43, #0]
    vf.mul       v27, v24, v23
    s.addi       s42, s44, #576
    vf.mul       v23, v27, v2
    s.movz       s43, #9
    vf.add       v24, v4, v23
    v.st.w       [s41, #0], v24
    a.vread      v4, a0, s49
    s.addi       s41, s30, #11840
    v.extract    s49, v26, #9
    v.splat      v23, s49
    v.ld.w       v24, [s45, #0]
    vf.mul       v27, v24, v18
    s.addi       s45, s44, #640
    vf.mul       v18, v27, v2
    s.movz       s49, #10
    vf.add       v24, v4, v18
    v.st.w       [s37, #0], v24
    a.vread      v4, a0, s51
    s.addi       s37, s30, #11904
    v.extract    s51, v26, #10
    v.splat      v18, s51
    v.ld.w       v24, [s39, #0]
    vf.mul       v27, v24, v19
    s.addi       s39, s44, #704
    vf.mul       v19, v27, v2
    s.movz       s51, #11
    vf.add       v24, v4, v19
    v.st.w       [s50, #0], v24
    a.vread      v4, a0, s46
    s.addi       s46, s30, #11968
    v.extract    s50, v26, #11
    v.splat      v19, s50
    v.ld.w       v24, [s40, #0]
    vf.mul       v27, v24, v20
    s.addi       s40, s44, #768
    vf.mul       v20, v27, v2
    s.movz       s50, #12
    vf.add       v24, v4, v20
    v.st.w       [s38, #0], v24
    a.vread      v4, a0, s48
    s.addi       s38, s30, #12032
    v.extract    s48, v26, #12
    v.splat      v20, s48
    v.ld.w       v24, [s34, #0]
    vf.mul       v27, v24, v21
    s.addi       s34, s44, #832
    vf.mul       v21, v27, v2
    s.movz       s48, #13
    vf.add       v24, v4, v21
    v.st.w       [s47, #0], v24
    a.vread      v4, a0, s43
    s.addi       s43, s30, #12096
    v.extract    s47, v26, #13
    v.splat      v21, s47
    v.ld.w       v24, [s41, #0]
    vf.mul       v27, v24, v23
    s.addi       s41, s44, #896
    vf.mul       v23, v27, v2
    s.movz       s47, #14
    vf.add       v24, v4, v23
    v.st.w       [s42, #0], v24
    a.vread      v4, a0, s49
    s.addi       s42, s30, #12160
    v.extract    s49, v26, #14
    v.splat      v23, s49
    v.ld.w       v24, [s37, #0]
    vf.mul       v27, v24, v18
    s.addi       s37, s44, #960
    vf.mul       v18, v27, v2
    s.movz       s44, #15
    vf.add       v24, v4, v18
    v.st.w       [s45, #0], v24
    a.vread      v4, a0, s51
    s.addi       s45, s30, #12224
    v.extract    s49, v26, #15
    v.splat      v18, s49
    v.ld.w       v24, [s46, #0]
    vf.mul       v27, v24, v19
    vf.mul       v19, v27, v2
    s.addi       s46, s30, #20480
    vf.add       v24, v4, v19
    s.movz       s49, #0
    v.st.w       [s39, #0], v24
    a.vread      v4, a0, s50
    s.addi       s39, s30, #12288
    v.extract    s50, v26, #0
    v.splat      v19, s50
    v.ld.w       v24, [s38, #0]
    vf.mul       v27, v24, v20
    vf.mul       v20, v27, v2
    s.addi       s38, s46, #64
    vf.add       v24, v4, v20
    s.movz       s50, #1
    v.st.w       [s40, #0], v24
    a.vread      v4, a0, s48
    s.addi       s40, s30, #12352
    v.extract    s48, v26, #1
    v.splat      v20, s48
    v.ld.w       v24, [s43, #0]
    vf.mul       v27, v24, v21
    vf.mul       v21, v27, v2
    s.addi       s43, s46, #128
    vf.add       v24, v4, v21
    s.movz       s48, #2
    v.st.w       [s34, #0], v24
    a.vread      v4, a0, s47
    s.addi       s34, s30, #12416
    v.extract    s47, v26, #2
    v.splat      v21, s47
    v.ld.w       v24, [s42, #0]
    vf.mul       v27, v24, v23
    vf.mul       v23, v27, v2
    s.addi       s42, s46, #192
    vf.add       v24, v4, v23
    s.movz       s47, #3
    v.st.w       [s41, #0], v24
    a.vread      v4, a0, s44
    s.addi       s41, s30, #12480
    v.extract    s44, v26, #3
    v.splat      v23, s44
    v.ld.w       v24, [s45, #0]
    vf.mul       v27, v24, v18
    vf.mul       v18, v27, v2
    s.addi       s44, s46, #256
    vf.add       v2, v4, v18
    s.movz       s45, #4
    v.st.w       [s37, #0], v2
    fence.acq_rel.device
    a.vread      v2, a1, s49
    s.addi       s37, s30, #12544
    v.extract    s49, v26, #4
    v.splat      v4, s49
    v.ld.w       v18, [s39, #0]
    vf.mul       v24, v18, v19
    s.addi       s39, s46, #320
    vf.mul       v18, v24, v22
    s.movz       s49, #5
    vf.add       v19, v2, v18
    v.st.w       [s46, #0], v19
    a.vread      v2, a1, s50
    s.addi       s50, s30, #12608
    v.extract    s51, v26, #5
    v.splat      v18, s51
    v.ld.w       v19, [s40, #0]
    vf.mul       v24, v19, v20
    s.addi       s40, s46, #384
    vf.mul       v19, v24, v22
    s.movz       s51, #6
    vf.add       v20, v2, v19
    v.st.w       [s38, #0], v20
    a.vread      v2, a1, s48
    s.addi       s38, s30, #12672
    v.extract    s48, v26, #6
    v.splat      v19, s48
    v.ld.w       v20, [s34, #0]
    vf.mul       v24, v20, v21
    s.addi       s34, s46, #448
    vf.mul       v20, v24, v22
    s.movz       s48, #7
    vf.add       v21, v2, v20
    v.st.w       [s43, #0], v21
    a.vread      v2, a1, s47
    s.addi       s43, s30, #12736
    v.extract    s47, v26, #7
    v.splat      v20, s47
    v.ld.w       v21, [s41, #0]
    vf.mul       v24, v21, v23
    s.addi       s41, s46, #512
    vf.mul       v21, v24, v22
    s.movz       s47, #8
    vf.add       v23, v2, v21
    v.st.w       [s42, #0], v23
    a.vread      v2, a1, s45
    s.addi       s42, s30, #12800
    v.extract    s45, v26, #8
    v.splat      v21, s45
    v.ld.w       v23, [s37, #0]
    vf.mul       v24, v23, v4
    s.addi       s37, s46, #576
    vf.mul       v4, v24, v22
    s.movz       s45, #9
    vf.add       v23, v2, v4
    v.st.w       [s44, #0], v23
    a.vread      v2, a1, s49
    s.addi       s44, s30, #12864
    v.extract    s49, v26, #9
    v.splat      v4, s49
    v.ld.w       v23, [s50, #0]
    vf.mul       v24, v23, v18
    s.addi       s49, s46, #640
    vf.mul       v18, v24, v22
    s.movz       s50, #10
    vf.add       v23, v2, v18
    v.st.w       [s39, #0], v23
    a.vread      v2, a1, s51
    s.addi       s39, s30, #12928
    v.extract    s51, v26, #10
    v.splat      v18, s51
    v.ld.w       v23, [s38, #0]
    vf.mul       v24, v23, v19
    s.addi       s38, s46, #704
    vf.mul       v19, v24, v22
    s.movz       s51, #11
    vf.add       v23, v2, v19
    v.st.w       [s40, #0], v23
    a.vread      v2, a1, s48
    s.addi       s40, s30, #12992
    v.extract    s48, v26, #11
    v.splat      v19, s48
    v.ld.w       v23, [s43, #0]
    vf.mul       v24, v23, v20
    s.addi       s43, s46, #768
    vf.mul       v20, v24, v22
    s.movz       s48, #12
    vf.add       v23, v2, v20
    v.st.w       [s34, #0], v23
    a.vread      v2, a1, s47
    s.addi       s34, s30, #13056
    v.extract    s47, v26, #12
    v.splat      v20, s47
    v.ld.w       v23, [s42, #0]
    vf.mul       v24, v23, v21
    s.addi       s42, s46, #832
    vf.mul       v21, v24, v22
    s.movz       s47, #13
    vf.add       v23, v2, v21
    v.st.w       [s41, #0], v23
    a.vread      v2, a1, s45
    s.addi       s41, s30, #13120
    v.extract    s45, v26, #13
    v.splat      v21, s45
    v.ld.w       v23, [s44, #0]
    vf.mul       v24, v23, v4
    s.addi       s44, s46, #896
    vf.mul       v4, v24, v22
    s.movz       s45, #14
    vf.add       v23, v2, v4
    v.st.w       [s37, #0], v23
    a.vread      v2, a1, s50
    s.addi       s37, s30, #13184
    v.extract    s50, v26, #14
    v.splat      v4, s50
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v18
    s.addi       s39, s46, #960
    vf.mul       v18, v24, v22
    s.movz       s46, #15
    vf.add       v23, v2, v18
    v.st.w       [s49, #0], v23
    a.vread      v2, a1, s51
    s.addi       s49, s30, #13248
    v.extract    s50, v26, #15
    v.splat      v18, s50
    v.ld.w       v23, [s40, #0]
    vf.mul       v24, v23, v19
    vf.mul       v19, v24, v22
    s.addi       s40, s30, #21504
    vf.add       v23, v2, v19
    s.movz       s50, #0
    v.st.w       [s38, #0], v23
    a.vread      v2, a1, s48
    s.addi       s38, s30, #13312
    v.extract    s48, v26, #0
    v.splat      v19, s48
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v20
    vf.mul       v20, v24, v22
    s.addi       s34, s40, #64
    vf.add       v23, v2, v20
    s.movz       s48, #1
    v.st.w       [s43, #0], v23
    a.vread      v2, a1, s47
    s.addi       s43, s30, #13376
    v.extract    s47, v26, #1
    v.splat      v20, s47
    v.ld.w       v23, [s41, #0]
    vf.mul       v24, v23, v21
    vf.mul       v21, v24, v22
    s.addi       s41, s40, #128
    vf.add       v23, v2, v21
    s.movz       s47, #2
    v.st.w       [s42, #0], v23
    a.vread      v2, a1, s45
    s.addi       s42, s30, #13440
    v.extract    s45, v26, #2
    v.splat      v21, s45
    v.ld.w       v23, [s37, #0]
    vf.mul       v24, v23, v4
    vf.mul       v4, v24, v22
    s.addi       s37, s40, #192
    vf.add       v23, v2, v4
    s.movz       s45, #3
    v.st.w       [s44, #0], v23
    a.vread      v2, a1, s46
    s.addi       s44, s30, #13504
    v.extract    s46, v26, #3
    v.splat      v4, s46
    v.ld.w       v23, [s49, #0]
    vf.mul       v24, v23, v18
    vf.mul       v18, v24, v22
    s.addi       s46, s40, #256
    vf.add       v22, v2, v18
    s.movz       s49, #4
    v.st.w       [s39, #0], v22
    fence.acq_rel.device
    a.vread      v2, a2, s50
    s.addi       s39, s30, #13568
    v.extract    s50, v26, #4
    v.splat      v18, s50
    v.ld.w       v22, [s38, #0]
    vf.mul       v23, v22, v19
    s.addi       s38, s40, #320
    vf.mul       v19, v23, v25
    s.movz       s50, #5
    vf.add       v22, v2, v19
    v.st.w       [s40, #0], v22
    a.vread      v2, a2, s48
    s.addi       s48, s30, #13632
    v.extract    s51, v26, #5
    v.splat      v19, s51
    v.ld.w       v22, [s43, #0]
    vf.mul       v23, v22, v20
    s.addi       s43, s40, #384
    vf.mul       v20, v23, v25
    s.movz       s51, #6
    vf.add       v22, v2, v20
    v.st.w       [s34, #0], v22
    a.vread      v2, a2, s47
    s.addi       s34, s30, #13696
    v.extract    s47, v26, #6
    v.splat      v20, s47
    v.ld.w       v22, [s42, #0]
    vf.mul       v23, v22, v21
    s.addi       s42, s40, #448
    vf.mul       v21, v23, v25
    s.movz       s47, #7
    vf.add       v22, v2, v21
    v.st.w       [s41, #0], v22
    a.vread      v2, a2, s45
    s.addi       s41, s30, #13760
    v.extract    s45, v26, #7
    v.splat      v21, s45
    v.ld.w       v22, [s44, #0]
    vf.mul       v23, v22, v4
    s.addi       s44, s40, #512
    vf.mul       v4, v23, v25
    s.movz       s45, #8
    vf.add       v22, v2, v4
    v.st.w       [s37, #0], v22
    a.vread      v2, a2, s49
    s.addi       s37, s30, #13824
    v.extract    s49, v26, #8
    v.splat      v4, s49
    v.ld.w       v22, [s39, #0]
    vf.mul       v23, v22, v18
    s.addi       s39, s40, #576
    vf.mul       v18, v23, v25
    s.movz       s49, #9
    vf.add       v22, v2, v18
    v.st.w       [s46, #0], v22
    a.vread      v2, a2, s50
    s.addi       s46, s30, #13888
    v.extract    s50, v26, #9
    v.splat      v18, s50
    v.ld.w       v22, [s48, #0]
    vf.mul       v23, v22, v19
    s.addi       s48, s40, #640
    vf.mul       v19, v23, v25
    s.movz       s50, #10
    vf.add       v22, v2, v19
    v.st.w       [s38, #0], v22
    a.vread      v2, a2, s51
    s.addi       s38, s30, #13952
    v.extract    s51, v26, #10
    v.splat      v19, s51
    v.ld.w       v22, [s34, #0]
    vf.mul       v23, v22, v20
    s.addi       s34, s40, #704
    vf.mul       v20, v23, v25
    s.movz       s51, #11
    vf.add       v22, v2, v20
    v.st.w       [s43, #0], v22
    a.vread      v2, a2, s47
    s.addi       s43, s30, #14016
    v.extract    s47, v26, #11
    v.splat      v20, s47
    v.ld.w       v22, [s41, #0]
    vf.mul       v23, v22, v21
    s.addi       s41, s40, #768
    vf.mul       v21, v23, v25
    s.movz       s47, #12
    vf.add       v22, v2, v21
    v.st.w       [s42, #0], v22
    a.vread      v2, a2, s45
    s.addi       s42, s30, #14080
    v.extract    s45, v26, #12
    v.splat      v21, s45
    v.ld.w       v22, [s37, #0]
    vf.mul       v23, v22, v4
    s.addi       s37, s40, #832
    vf.mul       v4, v23, v25
    s.movz       s45, #13
    vf.add       v22, v2, v4
    v.st.w       [s44, #0], v22
    a.vread      v2, a2, s49
    s.addi       s44, s30, #14144
    v.extract    s49, v26, #13
    v.splat      v4, s49
    v.ld.w       v22, [s46, #0]
    vf.mul       v23, v22, v18
    s.addi       s46, s40, #896
    vf.mul       v18, v23, v25
    s.movz       s49, #14
    vf.add       v22, v2, v18
    v.st.w       [s39, #0], v22
    a.vread      v2, a2, s50
    s.addi       s39, s30, #14208
    v.extract    s50, v26, #14
    v.splat      v18, s50
    v.ld.w       v22, [s38, #0]
    vf.mul       v23, v22, v19
    s.addi       s38, s40, #960
    vf.mul       v19, v23, v25
    s.movz       s40, #15
    vf.add       v22, v2, v19
    v.st.w       [s48, #0], v22
    a.vread      v2, a2, s51
    s.addi       s48, s30, #14272
    v.extract    s50, v26, #15
    v.splat      v19, s50
    v.ld.w       v22, [s43, #0]
    vf.mul       v23, v22, v20
    vf.mul       v20, v23, v25
    s.addi       s43, s30, #22528
    vf.add       v22, v2, v20
    s.movz       s50, #0
    v.st.w       [s34, #0], v22
    a.vread      v2, a2, s47
    s.addi       s34, s30, #14336
    v.extract    s47, v26, #0
    v.splat      v20, s47
    v.ld.w       v22, [s42, #0]
    vf.mul       v23, v22, v21
    vf.mul       v21, v23, v25
    s.addi       s42, s43, #64
    vf.add       v22, v2, v21
    s.movz       s47, #1
    v.st.w       [s41, #0], v22
    a.vread      v2, a2, s45
    s.addi       s41, s30, #14400
    v.extract    s45, v26, #1
    v.splat      v21, s45
    v.ld.w       v22, [s44, #0]
    vf.mul       v23, v22, v4
    vf.mul       v4, v23, v25
    s.addi       s44, s43, #128
    vf.add       v22, v2, v4
    s.movz       s45, #2
    v.st.w       [s37, #0], v22
    a.vread      v2, a2, s49
    s.addi       s37, s30, #14464
    v.extract    s49, v26, #2
    v.splat      v4, s49
    v.ld.w       v22, [s39, #0]
    vf.mul       v23, v22, v18
    vf.mul       v18, v23, v25
    s.addi       s39, s43, #192
    vf.add       v22, v2, v18
    s.movz       s49, #3
    v.st.w       [s46, #0], v22
    a.vread      v2, a2, s40
    s.addi       s40, s30, #14528
    v.extract    s46, v26, #3
    v.splat      v18, s46
    v.ld.w       v22, [s48, #0]
    vf.mul       v23, v22, v19
    vf.mul       v19, v23, v25
    s.addi       s46, s43, #256
    vf.add       v22, v2, v19
    s.movz       s48, #4
    v.st.w       [s38, #0], v22
    fence.acq_rel.device
    a.vread      v2, a3, s50
    s.addi       s38, s30, #14592
    v.extract    s50, v26, #4
    v.splat      v19, s50
    v.ld.w       v22, [s34, #0]
    vf.mul       v23, v22, v20
    s.addi       s34, s43, #320
    vf.mul       v20, v23, v33
    s.movz       s50, #5
    vf.add       v22, v2, v20
    v.st.w       [s43, #0], v22
    a.vread      v2, a3, s47
    s.addi       s47, s30, #14656
    v.extract    s51, v26, #5
    v.splat      v20, s51
    v.ld.w       v22, [s41, #0]
    vf.mul       v23, v22, v21
    s.addi       s41, s43, #384
    vf.mul       v21, v23, v33
    s.movz       s51, #6
    vf.add       v22, v2, v21
    v.st.w       [s42, #0], v22
    a.vread      v2, a3, s45
    s.addi       s42, s30, #14720
    v.extract    s45, v26, #6
    v.splat      v21, s45
    v.ld.w       v22, [s37, #0]
    vf.mul       v23, v22, v4
    s.addi       s37, s43, #448
    vf.mul       v4, v23, v33
    s.movz       s45, #7
    vf.add       v22, v2, v4
    v.st.w       [s44, #0], v22
    a.vread      v2, a3, s49
    s.addi       s44, s30, #14784
    v.extract    s49, v26, #7
    v.splat      v4, s49
    v.ld.w       v22, [s40, #0]
    vf.mul       v23, v22, v18
    s.addi       s40, s43, #512
    vf.mul       v18, v23, v33
    s.movz       s49, #8
    vf.add       v22, v2, v18
    v.st.w       [s39, #0], v22
    a.vread      v2, a3, s48
    s.addi       s39, s30, #14848
    v.extract    s48, v26, #8
    v.splat      v18, s48
    v.ld.w       v22, [s38, #0]
    vf.mul       v23, v22, v19
    s.addi       s38, s43, #576
    vf.mul       v19, v23, v33
    s.movz       s48, #9
    vf.add       v22, v2, v19
    v.st.w       [s46, #0], v22
    a.vread      v2, a3, s50
    s.addi       s46, s30, #14912
    v.extract    s50, v26, #9
    v.splat      v19, s50
    v.ld.w       v22, [s47, #0]
    vf.mul       v23, v22, v20
    s.addi       s47, s43, #640
    vf.mul       v20, v23, v33
    s.movz       s50, #10
    vf.add       v22, v2, v20
    v.st.w       [s34, #0], v22
    a.vread      v2, a3, s51
    s.addi       s34, s30, #14976
    v.extract    s51, v26, #10
    v.splat      v20, s51
    v.ld.w       v22, [s42, #0]
    vf.mul       v23, v22, v21
    s.addi       s42, s43, #704
    vf.mul       v21, v23, v33
    s.movz       s51, #11
    vf.add       v22, v2, v21
    v.st.w       [s41, #0], v22
    a.vread      v2, a3, s45
    s.addi       s41, s30, #15040
    v.extract    s45, v26, #11
    v.splat      v21, s45
    v.ld.w       v22, [s44, #0]
    vf.mul       v23, v22, v4
    s.addi       s44, s43, #768
    vf.mul       v4, v23, v33
    s.movz       s45, #12
    vf.add       v22, v2, v4
    v.st.w       [s37, #0], v22
    a.vread      v2, a3, s49
    s.addi       s37, s30, #15104
    v.extract    s49, v26, #12
    v.splat      v4, s49
    v.ld.w       v22, [s39, #0]
    vf.mul       v23, v22, v18
    s.addi       s39, s43, #832
    vf.mul       v18, v23, v33
    s.movz       s49, #13
    vf.add       v22, v2, v18
    v.st.w       [s40, #0], v22
    a.vread      v2, a3, s48
    s.addi       s40, s30, #15168
    v.extract    s48, v26, #13
    v.splat      v18, s48
    v.ld.w       v22, [s46, #0]
    vf.mul       v23, v22, v19
    s.addi       s46, s43, #896
    vf.mul       v19, v23, v33
    s.movz       s48, #14
    vf.add       v22, v2, v19
    v.st.w       [s38, #0], v22
    a.vread      v2, a3, s50
    s.addi       s38, s30, #15232
    v.extract    s50, v26, #14
    v.splat      v19, s50
    v.ld.w       v22, [s34, #0]
    vf.mul       v23, v22, v20
    s.addi       s34, s43, #960
    vf.mul       v20, v23, v33
    s.movz       s43, #15
    vf.add       v22, v2, v20
    v.st.w       [s47, #0], v22
    a.vread      v2, a3, s51
    s.addi       s47, s30, #15296
    v.extract    s50, v26, #15
    v.splat      v20, s50
    v.ld.w       v22, [s41, #0]
    vf.mul       v23, v22, v21
    vf.mul       v21, v23, v33
    s.addi       s41, s30, #23552
    vf.add       v22, v2, v21
    s.movz       s50, #0
    v.st.w       [s42, #0], v22
    a.vread      v2, a3, s45
    s.addi       s42, s30, #15360
    v.extract    s45, v26, #0
    v.splat      v21, s45
    v.ld.w       v22, [s37, #0]
    vf.mul       v23, v22, v4
    vf.mul       v4, v23, v33
    s.addi       s37, s41, #64
    vf.add       v22, v2, v4
    s.movz       s45, #1
    v.st.w       [s44, #0], v22
    a.vread      v2, a3, s49
    s.addi       s44, s30, #15424
    v.extract    s49, v26, #1
    v.splat      v4, s49
    v.ld.w       v22, [s40, #0]
    vf.mul       v23, v22, v18
    vf.mul       v18, v23, v33
    s.addi       s40, s41, #128
    vf.add       v22, v2, v18
    s.movz       s49, #2
    v.st.w       [s39, #0], v22
    a.vread      v2, a3, s48
    s.addi       s39, s30, #15488
    v.extract    s48, v26, #2
    v.splat      v18, s48
    v.ld.w       v22, [s38, #0]
    vf.mul       v23, v22, v19
    vf.mul       v19, v23, v33
    s.addi       s38, s41, #192
    vf.add       v22, v2, v19
    s.movz       s48, #3
    v.st.w       [s46, #0], v22
    a.vread      v2, a3, s43
    s.addi       s43, s30, #15552
    v.extract    s46, v26, #3
    v.splat      v19, s46
    v.ld.w       v22, [s47, #0]
    vf.mul       v23, v22, v20
    vf.mul       v20, v23, v33
    s.addi       s46, s41, #256
    vf.add       v22, v2, v20
    s.movz       s47, #4
    v.st.w       [s34, #0], v22
    fence.acq_rel.device
    a.vread      v2, a4, s50
    s.addi       s34, s30, #15616
    v.extract    s50, v26, #4
    v.splat      v20, s50
    v.ld.w       v22, [s42, #0]
    vf.mul       v23, v22, v21
    s.addi       s42, s41, #320
    vf.mul       v21, v23, v35
    s.movz       s50, #5
    vf.add       v22, v2, v21
    v.st.w       [s41, #0], v22
    a.vread      v2, a4, s45
    s.addi       s45, s30, #15680
    v.extract    s51, v26, #5
    v.splat      v21, s51
    v.ld.w       v22, [s44, #0]
    vf.mul       v23, v22, v4
    s.addi       s44, s41, #384
    vf.mul       v4, v23, v35
    s.movz       s51, #6
    vf.add       v22, v2, v4
    v.st.w       [s37, #0], v22
    a.vread      v2, a4, s49
    s.addi       s37, s30, #15744
    v.extract    s49, v26, #6
    v.splat      v4, s49
    v.ld.w       v22, [s39, #0]
    vf.mul       v23, v22, v18
    s.addi       s39, s41, #448
    vf.mul       v18, v23, v35
    s.movz       s49, #7
    vf.add       v22, v2, v18
    v.st.w       [s40, #0], v22
    a.vread      v2, a4, s48
    s.addi       s40, s30, #15808
    v.extract    s48, v26, #7
    v.splat      v18, s48
    v.ld.w       v22, [s43, #0]
    vf.mul       v23, v22, v19
    s.addi       s43, s41, #512
    vf.mul       v19, v23, v35
    s.movz       s48, #8
    vf.add       v22, v2, v19
    v.st.w       [s38, #0], v22
    a.vread      v2, a4, s47
    s.addi       s38, s30, #15872
    v.extract    s47, v26, #8
    v.splat      v19, s47
    v.ld.w       v22, [s34, #0]
    vf.mul       v23, v22, v20
    s.addi       s34, s41, #576
    vf.mul       v20, v23, v35
    s.movz       s47, #9
    vf.add       v22, v2, v20
    v.st.w       [s46, #0], v22
    a.vread      v2, a4, s50
    s.addi       s46, s30, #15936
    v.extract    s50, v26, #9
    v.splat      v20, s50
    v.ld.w       v22, [s45, #0]
    vf.mul       v23, v22, v21
    s.addi       s45, s41, #640
    vf.mul       v21, v23, v35
    s.movz       s50, #10
    vf.add       v22, v2, v21
    v.st.w       [s42, #0], v22
    a.vread      v2, a4, s51
    s.addi       s42, s30, #16000
    v.extract    s51, v26, #10
    v.splat      v21, s51
    v.ld.w       v22, [s37, #0]
    vf.mul       v23, v22, v4
    s.addi       s37, s41, #704
    vf.mul       v4, v23, v35
    s.movz       s51, #11
    vf.add       v22, v2, v4
    v.st.w       [s44, #0], v22
    a.vread      v2, a4, s49
    s.addi       s44, s30, #16064
    v.extract    s49, v26, #11
    v.splat      v4, s49
    v.ld.w       v22, [s40, #0]
    vf.mul       v23, v22, v18
    s.addi       s40, s41, #768
    vf.mul       v18, v23, v35
    s.movz       s49, #12
    vf.add       v22, v2, v18
    v.st.w       [s39, #0], v22
    a.vread      v2, a4, s48
    s.addi       s39, s30, #16128
    v.extract    s48, v26, #12
    v.splat      v18, s48
    v.ld.w       v22, [s38, #0]
    vf.mul       v23, v22, v19
    s.addi       s38, s41, #832
    vf.mul       v19, v23, v35
    s.movz       s48, #13
    vf.add       v22, v2, v19
    v.st.w       [s43, #0], v22
    a.vread      v2, a4, s47
    s.addi       s43, s30, #16192
    v.extract    s47, v26, #13
    v.splat      v19, s47
    v.ld.w       v22, [s46, #0]
    vf.mul       v23, v22, v20
    s.addi       s46, s41, #896
    vf.mul       v20, v23, v35
    s.movz       s47, #14
    vf.add       v22, v2, v20
    v.st.w       [s34, #0], v22
    a.vread      v2, a4, s50
    s.addi       s34, s30, #16256
    v.extract    s50, v26, #14
    v.splat      v20, s50
    v.ld.w       v22, [s42, #0]
    vf.mul       v23, v22, v21
    s.addi       s42, s41, #960
    vf.mul       v21, v23, v35
    s.movz       s41, #15
    vf.add       v22, v2, v21
    v.st.w       [s45, #0], v22
    a.vread      v2, a4, s51
    s.addi       s45, s30, #16320
    v.extract    s50, v26, #15
    v.splat      v21, s50
    v.ld.w       v22, [s44, #0]
    vf.mul       v23, v22, v4
    vf.mul       v4, v23, v35
    s.addi       s44, s30, #24576
    vf.add       v22, v2, v4
    s.movz       s50, #0
    v.st.w       [s37, #0], v22
    a.vread      v2, a4, s49
    s.addi       s37, s30, #16384
    v.extract    s49, v26, #0
    v.splat      v4, s49
    v.ld.w       v22, [s39, #0]
    vf.mul       v23, v22, v18
    vf.mul       v18, v23, v35
    s.addi       s39, s44, #64
    vf.add       v22, v2, v18
    s.movz       s49, #1
    v.st.w       [s40, #0], v22
    a.vread      v2, a4, s48
    s.addi       s40, s30, #16448
    v.extract    s48, v26, #1
    v.splat      v18, s48
    v.ld.w       v22, [s43, #0]
    vf.mul       v23, v22, v19
    vf.mul       v19, v23, v35
    s.addi       s43, s44, #128
    vf.add       v22, v2, v19
    s.movz       s48, #2
    v.st.w       [s38, #0], v22
    a.vread      v2, a4, s47
    s.addi       s38, s30, #16512
    v.extract    s47, v26, #2
    v.splat      v19, s47
    v.ld.w       v22, [s34, #0]
    vf.mul       v23, v22, v20
    vf.mul       v20, v23, v35
    s.addi       s34, s44, #192
    vf.add       v22, v2, v20
    s.movz       s47, #3
    v.st.w       [s46, #0], v22
    a.vread      v2, a4, s41
    s.addi       s41, s30, #16576
    v.extract    s46, v26, #3
    v.splat      v20, s46
    v.ld.w       v22, [s45, #0]
    vf.mul       v23, v22, v21
    vf.mul       v21, v23, v35
    s.addi       s45, s44, #256
    vf.add       v22, v2, v21
    s.movz       s46, #4
    v.st.w       [s42, #0], v22
    fence.acq_rel.device
    a.vread      v2, a5, s50
    s.addi       s42, s30, #16640
    v.extract    s50, v26, #4
    v.splat      v21, s50
    v.ld.w       v22, [s37, #0]
    vf.mul       v23, v22, v4
    s.addi       s37, s44, #320
    vf.mul       v4, v23, v36
    s.movz       s50, #5
    vf.add       v22, v2, v4
    v.st.w       [s44, #0], v22
    a.vread      v2, a5, s49
    s.addi       s49, s30, #16704
    v.extract    s51, v26, #5
    v.splat      v4, s51
    v.ld.w       v22, [s40, #0]
    vf.mul       v23, v22, v18
    s.addi       s40, s44, #384
    vf.mul       v18, v23, v36
    s.movz       s51, #6
    vf.add       v22, v2, v18
    v.st.w       [s39, #0], v22
    a.vread      v2, a5, s48
    s.addi       s39, s30, #16768
    v.extract    s48, v26, #6
    v.splat      v18, s48
    v.ld.w       v22, [s38, #0]
    vf.mul       v23, v22, v19
    s.addi       s38, s44, #448
    vf.mul       v19, v23, v36
    s.movz       s48, #7
    vf.add       v22, v2, v19
    v.st.w       [s43, #0], v22
    a.vread      v2, a5, s47
    s.addi       s43, s30, #16832
    v.extract    s47, v26, #7
    v.splat      v19, s47
    v.ld.w       v22, [s41, #0]
    vf.mul       v23, v22, v20
    s.addi       s41, s44, #512
    vf.mul       v20, v23, v36
    s.movz       s47, #8
    vf.add       v22, v2, v20
    v.st.w       [s34, #0], v22
    a.vread      v2, a5, s46
    s.addi       s34, s30, #16896
    v.extract    s46, v26, #8
    v.splat      v20, s46
    v.ld.w       v22, [s42, #0]
    vf.mul       v23, v22, v21
    s.addi       s42, s44, #576
    vf.mul       v21, v23, v36
    s.movz       s46, #9
    vf.add       v22, v2, v21
    v.st.w       [s45, #0], v22
    a.vread      v2, a5, s50
    s.addi       s45, s30, #16960
    v.extract    s50, v26, #9
    v.splat      v21, s50
    v.ld.w       v22, [s49, #0]
    vf.mul       v23, v22, v4
    s.addi       s49, s44, #640
    vf.mul       v4, v23, v36
    s.movz       s50, #10
    vf.add       v22, v2, v4
    v.st.w       [s37, #0], v22
    a.vread      v2, a5, s51
    s.addi       s37, s30, #17024
    v.extract    s51, v26, #10
    v.splat      v4, s51
    v.ld.w       v22, [s39, #0]
    vf.mul       v23, v22, v18
    s.addi       s39, s44, #704
    vf.mul       v18, v23, v36
    s.movz       s51, #11
    vf.add       v22, v2, v18
    v.st.w       [s40, #0], v22
    a.vread      v2, a5, s48
    s.addi       s40, s30, #17088
    v.extract    s48, v26, #11
    v.splat      v18, s48
    v.ld.w       v22, [s43, #0]
    vf.mul       v23, v22, v19
    s.addi       s43, s44, #768
    vf.mul       v19, v23, v36
    s.movz       s48, #12
    vf.add       v22, v2, v19
    v.st.w       [s38, #0], v22
    a.vread      v2, a5, s47
    s.addi       s38, s30, #17152
    v.extract    s47, v26, #12
    v.splat      v19, s47
    v.ld.w       v22, [s34, #0]
    vf.mul       v23, v22, v20
    s.addi       s34, s44, #832
    vf.mul       v20, v23, v36
    s.movz       s47, #13
    vf.add       v22, v2, v20
    v.st.w       [s41, #0], v22
    a.vread      v2, a5, s46
    s.addi       s41, s30, #17216
    v.extract    s46, v26, #13
    v.splat      v20, s46
    v.ld.w       v22, [s45, #0]
    vf.mul       v23, v22, v21
    s.addi       s45, s44, #896
    vf.mul       v21, v23, v36
    s.movz       s46, #14
    vf.add       v22, v2, v21
    v.st.w       [s42, #0], v22
    a.vread      v2, a5, s50
    s.addi       s42, s30, #17280
    v.extract    s50, v26, #14
    v.splat      v21, s50
    v.ld.w       v22, [s37, #0]
    vf.mul       v23, v22, v4
    s.addi       s37, s44, #960
    vf.mul       v4, v23, v36
    s.movz       s44, #15
    vf.add       v22, v2, v4
    v.st.w       [s49, #0], v22
    a.vread      v2, a5, s51
    s.addi       s49, s30, #17344
    v.extract    s50, v26, #15
    v.splat      v4, s50
    v.ld.w       v22, [s40, #0]
    vf.mul       v23, v22, v18
    vf.mul       v18, v23, v36
    s.addi       s40, s30, #25600
    vf.add       v22, v2, v18
    s.movz       s50, #0
    v.st.w       [s39, #0], v22
    a.vread      v2, a5, s48
    s.addi       s39, s30, #17408
    v.extract    s48, v26, #0
    v.splat      v18, s48
    v.ld.w       v22, [s38, #0]
    vf.mul       v23, v22, v19
    vf.mul       v19, v23, v36
    s.addi       s38, s40, #64
    vf.add       v22, v2, v19
    s.movz       s48, #1
    v.st.w       [s43, #0], v22
    a.vread      v2, a5, s47
    s.addi       s43, s30, #17472
    v.extract    s47, v26, #1
    v.splat      v19, s47
    v.ld.w       v22, [s41, #0]
    vf.mul       v23, v22, v20
    vf.mul       v20, v23, v36
    s.addi       s41, s40, #128
    vf.add       v22, v2, v20
    s.movz       s47, #2
    v.st.w       [s34, #0], v22
    a.vread      v2, a5, s46
    s.addi       s34, s30, #17536
    v.extract    s46, v26, #2
    v.splat      v20, s46
    v.ld.w       v22, [s42, #0]
    vf.mul       v23, v22, v21
    vf.mul       v21, v23, v36
    s.addi       s42, s40, #192
    vf.add       v22, v2, v21
    s.movz       s46, #3
    v.st.w       [s45, #0], v22
    a.vread      v2, a5, s44
    s.addi       s44, s30, #17600
    v.extract    s45, v26, #3
    v.splat      v21, s45
    v.ld.w       v22, [s49, #0]
    vf.mul       v23, v22, v4
    vf.mul       v4, v23, v36
    s.addi       s45, s40, #256
    vf.add       v22, v2, v4
    s.movz       s49, #4
    v.st.w       [s37, #0], v22
    fence.acq_rel.device
    a.vread      v2, a6, s50
    s.addi       s37, s30, #17664
    v.extract    s50, v26, #4
    v.splat      v4, s50
    v.ld.w       v22, [s39, #0]
    vf.mul       v23, v22, v18
    s.addi       s39, s40, #320
    vf.mul       v18, v23, v37
    s.movz       s50, #5
    vf.add       v22, v2, v18
    v.st.w       [s40, #0], v22
    a.vread      v2, a6, s48
    s.addi       s48, s30, #17728
    v.extract    s51, v26, #5
    v.splat      v18, s51
    v.ld.w       v22, [s43, #0]
    vf.mul       v23, v22, v19
    s.addi       s43, s40, #384
    vf.mul       v19, v23, v37
    s.movz       s51, #6
    vf.add       v22, v2, v19
    v.st.w       [s38, #0], v22
    a.vread      v2, a6, s47
    s.addi       s38, s30, #17792
    v.extract    s47, v26, #6
    v.splat      v19, s47
    v.ld.w       v22, [s34, #0]
    vf.mul       v23, v22, v20
    s.addi       s34, s40, #448
    vf.mul       v20, v23, v37
    s.movz       s47, #7
    vf.add       v22, v2, v20
    v.st.w       [s41, #0], v22
    a.vread      v2, a6, s46
    s.addi       s41, s30, #17856
    v.extract    s46, v26, #7
    v.splat      v20, s46
    v.ld.w       v22, [s44, #0]
    vf.mul       v23, v22, v21
    s.addi       s44, s40, #512
    vf.mul       v21, v23, v37
    s.movz       s46, #8
    vf.add       v22, v2, v21
    v.st.w       [s42, #0], v22
    a.vread      v2, a6, s49
    s.addi       s42, s30, #17920
    v.extract    s49, v26, #8
    v.splat      v21, s49
    v.ld.w       v22, [s37, #0]
    vf.mul       v23, v22, v4
    s.addi       s37, s40, #576
    vf.mul       v4, v23, v37
    s.movz       s49, #9
    vf.add       v22, v2, v4
    v.st.w       [s45, #0], v22
    a.vread      v2, a6, s50
    s.addi       s45, s30, #17984
    v.extract    s50, v26, #9
    v.splat      v4, s50
    v.ld.w       v22, [s48, #0]
    vf.mul       v23, v22, v18
    s.addi       s48, s40, #640
    vf.mul       v18, v23, v37
    s.movz       s50, #10
    vf.add       v22, v2, v18
    v.st.w       [s39, #0], v22
    a.vread      v2, a6, s51
    s.addi       s39, s30, #18048
    v.extract    s51, v26, #10
    v.splat      v18, s51
    v.ld.w       v22, [s38, #0]
    vf.mul       v23, v22, v19
    s.addi       s38, s40, #704
    vf.mul       v19, v23, v37
    s.movz       s51, #11
    vf.add       v22, v2, v19
    v.st.w       [s43, #0], v22
    a.vread      v2, a6, s47
    s.addi       s43, s30, #18112
    v.extract    s47, v26, #11
    v.splat      v19, s47
    v.ld.w       v22, [s41, #0]
    vf.mul       v23, v22, v20
    s.addi       s41, s40, #768
    vf.mul       v20, v23, v37
    s.movz       s47, #12
    vf.add       v22, v2, v20
    v.st.w       [s34, #0], v22
    a.vread      v2, a6, s46
    s.addi       s34, s30, #18176
    v.extract    s46, v26, #12
    v.splat      v20, s46
    v.ld.w       v22, [s42, #0]
    vf.mul       v23, v22, v21
    s.addi       s42, s40, #832
    vf.mul       v21, v23, v37
    s.movz       s46, #13
    vf.add       v22, v2, v21
    v.st.w       [s44, #0], v22
    a.vread      v2, a6, s49
    s.addi       s44, s30, #18240
    v.extract    s49, v26, #13
    v.splat      v21, s49
    v.ld.w       v22, [s45, #0]
    vf.mul       v23, v22, v4
    s.addi       s45, s40, #896
    vf.mul       v4, v23, v37
    s.movz       s49, #14
    vf.add       v22, v2, v4
    v.st.w       [s37, #0], v22
    a.vread      v2, a6, s50
    s.addi       s37, s30, #18304
    v.extract    s50, v26, #14
    v.splat      v4, s50
    v.ld.w       v22, [s39, #0]
    vf.mul       v23, v22, v18
    s.addi       s39, s40, #960
    vf.mul       v18, v23, v37
    s.movz       s40, #15
    vf.add       v22, v2, v18
    v.st.w       [s48, #0], v22
    a.vread      v2, a6, s51
    s.addi       s48, s30, #18368
    v.extract    s50, v26, #15
    v.splat      v18, s50
    v.ld.w       v22, [s43, #0]
    vf.mul       v23, v22, v19
    vf.mul       v19, v23, v37
    s.addi       s43, s30, #26624
    vf.add       v22, v2, v19
    s.movz       s50, #0
    v.st.w       [s38, #0], v22
    a.vread      v2, a6, s47
    s.addi       s38, s30, #18432
    v.extract    s47, v26, #0
    v.splat      v19, s47
    v.ld.w       v22, [s34, #0]
    vf.mul       v23, v22, v20
    vf.mul       v20, v23, v37
    s.addi       s34, s43, #64
    vf.add       v22, v2, v20
    s.movz       s47, #1
    v.st.w       [s41, #0], v22
    a.vread      v2, a6, s46
    s.addi       s41, s30, #18496
    v.extract    s46, v26, #1
    v.splat      v20, s46
    v.ld.w       v22, [s44, #0]
    vf.mul       v23, v22, v21
    vf.mul       v21, v23, v37
    s.addi       s44, s43, #128
    vf.add       v22, v2, v21
    s.movz       s46, #2
    v.st.w       [s42, #0], v22
    a.vread      v2, a6, s49
    s.addi       s42, s30, #18560
    v.extract    s49, v26, #2
    v.splat      v21, s49
    v.ld.w       v22, [s37, #0]
    vf.mul       v23, v22, v4
    vf.mul       v4, v23, v37
    s.addi       s37, s43, #192
    vf.add       v22, v2, v4
    s.movz       s49, #3
    v.st.w       [s45, #0], v22
    a.vread      v2, a6, s40
    s.addi       s40, s30, #18624
    v.extract    s45, v26, #3
    v.splat      v4, s45
    v.ld.w       v22, [s48, #0]
    vf.mul       v23, v22, v18
    vf.mul       v18, v23, v37
    s.addi       s45, s43, #256
    vf.add       v22, v2, v18
    s.movz       s48, #4
    v.st.w       [s39, #0], v22
    fence.acq_rel.device
    a.vread      v2, a7, s50
    s.addi       s39, s30, #18688
    v.extract    s50, v26, #4
    v.splat      v18, s50
    v.ld.w       v22, [s38, #0]
    vf.mul       v23, v22, v19
    s.addi       s38, s43, #320
    vf.mul       v19, v23, v38
    s.movz       s50, #5
    vf.add       v22, v2, v19
    v.st.w       [s43, #0], v22
    a.vread      v2, a7, s47
    s.addi       s47, s30, #18752
    v.extract    s51, v26, #5
    v.splat      v19, s51
    v.ld.w       v22, [s41, #0]
    vf.mul       v23, v22, v20
    s.addi       s41, s43, #384
    vf.mul       v20, v23, v38
    s.movz       s51, #6
    vf.add       v22, v2, v20
    v.st.w       [s34, #0], v22
    a.vread      v2, a7, s46
    s.addi       s34, s30, #18816
    v.extract    s46, v26, #6
    v.splat      v20, s46
    v.ld.w       v22, [s42, #0]
    vf.mul       v23, v22, v21
    s.addi       s42, s43, #448
    vf.mul       v21, v23, v38
    s.movz       s46, #7
    vf.add       v22, v2, v21
    v.st.w       [s44, #0], v22
    a.vread      v2, a7, s49
    s.addi       s44, s30, #18880
    v.extract    s49, v26, #7
    v.splat      v21, s49
    v.ld.w       v22, [s40, #0]
    vf.mul       v23, v22, v4
    s.addi       s40, s43, #512
    vf.mul       v4, v23, v38
    s.movz       s49, #8
    vf.add       v22, v2, v4
    v.st.w       [s37, #0], v22
    a.vread      v2, a7, s48
    s.addi       s37, s30, #18944
    v.extract    s48, v26, #8
    v.splat      v4, s48
    v.ld.w       v22, [s39, #0]
    vf.mul       v23, v22, v18
    s.addi       s39, s43, #576
    vf.mul       v18, v23, v38
    s.movz       s48, #9
    vf.add       v22, v2, v18
    v.st.w       [s45, #0], v22
    a.vread      v2, a7, s50
    s.addi       s45, s30, #19008
    v.extract    s50, v26, #9
    v.splat      v18, s50
    v.ld.w       v22, [s47, #0]
    vf.mul       v23, v22, v19
    s.addi       s47, s43, #640
    vf.mul       v19, v23, v38
    s.movz       s50, #10
    vf.add       v22, v2, v19
    v.st.w       [s38, #0], v22
    a.vread      v2, a7, s51
    s.addi       s38, s30, #19072
    v.extract    s51, v26, #10
    v.splat      v19, s51
    v.ld.w       v22, [s34, #0]
    vf.mul       v23, v22, v20
    s.addi       s34, s43, #704
    vf.mul       v20, v23, v38
    s.movz       s51, #11
    vf.add       v22, v2, v20
    v.st.w       [s41, #0], v22
    a.vread      v2, a7, s46
    s.addi       s41, s30, #19136
    v.extract    s46, v26, #11
    v.splat      v20, s46
    v.ld.w       v22, [s44, #0]
    vf.mul       v23, v22, v21
    s.addi       s44, s43, #768
    vf.mul       v21, v23, v38
    s.movz       s46, #12
    vf.add       v22, v2, v21
    v.st.w       [s42, #0], v22
    a.vread      v2, a7, s49
    s.addi       s42, s30, #19200
    v.extract    s49, v26, #12
    v.splat      v21, s49
    v.ld.w       v22, [s37, #0]
    vf.mul       v23, v22, v4
    s.addi       s37, s43, #832
    vf.mul       v4, v23, v38
    s.movz       s49, #13
    vf.add       v22, v2, v4
    v.st.w       [s40, #0], v22
    a.vread      v2, a7, s48
    s.addi       s40, s30, #19264
    v.extract    s48, v26, #13
    v.splat      v4, s48
    v.ld.w       v22, [s45, #0]
    vf.mul       v23, v22, v18
    s.addi       s45, s43, #896
    vf.mul       v18, v23, v38
    s.movz       s48, #14
    vf.add       v22, v2, v18
    v.st.w       [s39, #0], v22
    a.vread      v2, a7, s50
    s.addi       s39, s30, #19328
    v.extract    s50, v26, #14
    v.splat      v18, s50
    v.ld.w       v22, [s38, #0]
    vf.mul       v23, v22, v19
    s.addi       s38, s43, #960
    vf.mul       v19, v23, v38
    s.movz       s43, #15
    vf.add       v22, v2, v19
    v.st.w       [s47, #0], v22
    a.vread      v2, a7, s51
    s.addi       s47, s30, #19392
    v.extract    s50, v26, #15
    v.splat      v19, s50
    v.ld.w       v22, [s41, #0]
    vf.mul       v23, v22, v20
    vf.mul       v20, v23, v38
    s.addi       s41, s18, #128
    vf.add       v22, v2, v20
    s.addi       s50, s41, #0
    v.st.w       [s34, #0], v22
    a.vread      v2, a7, s46
    s.addi       s34, s24, #128
    s.addi       s41, s25, #4                    // &ptr_carry_17[1] (a constant offset, x4)
    s.addi       s46, s34, #0
    s.addi       s34, s41, #0
    s.addi       s41, s25, #4                    // &ptr_carry_18[1] (a constant offset, x4)
    v.ld.w       v20, [s42, #0]
    s.addi       s41, s25, #4                    // &ptr_carry_19[1] (a constant offset, x4)
    s.addi       s41, s25, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    s.addi       s41, s25, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    vf.mul       v22, v20, v21
    s.addi       s41, s25, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    vf.mul       v20, v22, v38
    s.addi       s41, s25, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    vf.add       v21, v2, v20
    s.addi       s41, s25, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    v.st.w       [s44, #0], v21
    a.vread      v2, a7, s49
    s.addi       s41, s30, #19456
    s.movz       s42, #0
    v.ld.w       v20, [s40, #0]
    s.movz       s40, #1
    vf.mul       v21, v20, v4
    s.addi       s44, s30, #19520
    vf.mul       v4, v21, v38
    vf.add       v20, v2, v4
    v.st.w       [s37, #0], v20
    a.vread      v2, a7, s48
    s.addi       s37, s30, #19584
    s.movz       s48, #2
    s.movz       s49, #3
    v.ld.w       v4, [s39, #0]
    s.addi       s39, s30, #19648
    vf.mul       v20, v4, v18
    s.movz       s51, #4
    vf.mul       v4, v20, v38
    s.addi       s52, s30, #19712
    vf.add       v18, v2, v4
    v.st.w       [s45, #0], v18
    a.vread      v2, a7, s43
    s.addi       s43, s30, #19776
    s.movz       s45, #5
    v.ld.w       v4, [s47, #0]
    s.addi       s47, s30, #19840
    s.movz       s53, #6
    vf.mul       v18, v4, v19
    vf.mul       v4, v18, v38
    vf.add       v18, v2, v4
    v.st.w       [s38, #0], v18
    fence.acq_rel.device
    s.mov        s18, s50
    s.mov        s24, s46
    s.mov        s25, s34
    s.addi       s34, s30, #19904
    s.movz       s38, #7
    s.addi       s46, s30, #19968
    s.movz       s50, #8
    s.addi       s54, s30, #20032
    s.movz       s55, #9
    s.addi       s56, s30, #20096
    v.ld.w       v2, [s41, #0]
    s.movz       s41, #10
    a.vwrite     a0, s42, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s30, #20160
    a.vwrite     a0, s40, v2
    v.ld.w       v2, [s37, #0]
    s.movz       s37, #11
    a.vwrite     a0, s48, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s30, #20224
    a.vwrite     a0, s49, v2
    v.ld.w       v2, [s52, #0]
    s.movz       s52, #12
    a.vwrite     a0, s51, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s30, #20288
    a.vwrite     a0, s45, v2
    v.ld.w       v2, [s47, #0]
    s.movz       s47, #13
    a.vwrite     a0, s53, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s30, #20352
    a.vwrite     a0, s38, v2
    v.ld.w       v2, [s46, #0]
    s.movz       s46, #14
    a.vwrite     a0, s50, v2
    v.ld.w       v2, [s54, #0]
    s.addi       s54, s30, #20416
    a.vwrite     a0, s55, v2
    v.ld.w       v2, [s56, #0]
    s.movz       s56, #15
    a.vwrite     a0, s41, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s30, #20480
    a.vwrite     a0, s37, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s30, #20544
    a.vwrite     a0, s52, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s30, #20608
    a.vwrite     a0, s47, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s30, #20672
    a.vwrite     a0, s46, v2
    v.ld.w       v2, [s54, #0]
    s.addi       s54, s30, #20736
    a.vwrite     a0, s56, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s30, #20800
    a.vwrite     a1, s42, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s30, #20864
    s.addi       s42, s30, #20928
    a.vwrite     a1, s40, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s40, s30, #20992
    s.addi       s43, s30, #21056
    a.vwrite     a1, s48, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s30, #21120
    s.addi       s48, s30, #21184
    a.vwrite     a1, s49, v2
    v.ld.w       v2, [s54, #0]
    s.addi       s49, s30, #21248
    s.addi       s54, s30, #21312
    a.vwrite     a1, s51, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s30, #21376
    s.addi       s51, s30, #21440
    a.vwrite     a1, s45, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s30, #21504
    s.movz       s45, #0
    a.vwrite     a1, s53, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s30, #21568
    s.movz       s53, #1
    a.vwrite     a1, s38, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s38, s30, #21632
    s.movz       s40, #2
    a.vwrite     a1, s50, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s30, #21696
    s.movz       s50, #3
    a.vwrite     a1, s55, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s30, #21760
    s.movz       s55, #4
    a.vwrite     a1, s41, v2
    v.ld.w       v2, [s48, #0]
    s.addi       s41, s30, #21824
    s.movz       s48, #5
    a.vwrite     a1, s37, v2
    v.ld.w       v2, [s49, #0]
    s.addi       s37, s30, #21888
    s.movz       s49, #6
    a.vwrite     a1, s52, v2
    v.ld.w       v2, [s54, #0]
    s.addi       s52, s30, #21952
    s.movz       s54, #7
    a.vwrite     a1, s47, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s30, #22016
    s.movz       s47, #8
    a.vwrite     a1, s46, v2
    v.ld.w       v2, [s51, #0]
    s.addi       s46, s30, #22080
    s.movz       s51, #9
    a.vwrite     a1, s56, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s30, #22144
    s.movz       s56, #10
    a.vwrite     a2, s45, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s30, #22208
    a.vwrite     a2, s53, v2
    v.ld.w       v2, [s38, #0]
    s.movz       s38, #11
    a.vwrite     a2, s40, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s30, #22272
    a.vwrite     a2, s50, v2
    v.ld.w       v2, [s34, #0]
    s.movz       s34, #12
    a.vwrite     a2, s55, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s30, #22336
    a.vwrite     a2, s48, v2
    v.ld.w       v2, [s37, #0]
    s.movz       s37, #13
    a.vwrite     a2, s49, v2
    v.ld.w       v2, [s52, #0]
    s.addi       s52, s30, #22400
    a.vwrite     a2, s54, v2
    v.ld.w       v2, [s44, #0]
    s.movz       s44, #14
    a.vwrite     a2, s47, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s46, s30, #22464
    a.vwrite     a2, s51, v2
    v.ld.w       v2, [s39, #0]
    s.movz       s39, #15
    a.vwrite     a2, s56, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s30, #22528
    a.vwrite     a2, s38, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s30, #22592
    a.vwrite     a2, s34, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s30, #22656
    a.vwrite     a2, s37, v2
    v.ld.w       v2, [s52, #0]
    s.addi       s52, s30, #22720
    a.vwrite     a2, s44, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s46, s30, #22784
    a.vwrite     a2, s39, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s30, #22848
    a.vwrite     a3, s45, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s30, #22912
    s.addi       s45, s30, #22976
    a.vwrite     a3, s53, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s30, #23040
    s.addi       s53, s30, #23104
    a.vwrite     a3, s40, v2
    v.ld.w       v2, [s52, #0]
    s.addi       s40, s30, #23168
    s.addi       s52, s30, #23232
    a.vwrite     a3, s50, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s46, s30, #23296
    s.addi       s50, s30, #23360
    a.vwrite     a3, s55, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s30, #23424
    s.addi       s55, s30, #23488
    a.vwrite     a3, s48, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s30, #23552
    s.movz       s48, #0
    a.vwrite     a3, s49, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s45, s30, #23616
    s.movz       s49, #1
    a.vwrite     a3, s54, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s30, #23680
    s.movz       s54, #2
    a.vwrite     a3, s47, v2
    v.ld.w       v2, [s53, #0]
    s.addi       s47, s30, #23744
    s.movz       s53, #3
    a.vwrite     a3, s51, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s30, #23808
    s.movz       s51, #4
    a.vwrite     a3, s56, v2
    v.ld.w       v2, [s52, #0]
    s.addi       s52, s30, #23872
    s.movz       s56, #5
    a.vwrite     a3, s38, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s38, s30, #23936
    s.movz       s46, #6
    a.vwrite     a3, s34, v2
    v.ld.w       v2, [s50, #0]
    s.addi       s34, s30, #24000
    s.movz       s50, #7
    a.vwrite     a3, s37, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s37, s30, #24064
    s.movz       s42, #8
    a.vwrite     a3, s44, v2
    v.ld.w       v2, [s55, #0]
    s.addi       s44, s30, #24128
    s.movz       s55, #9
    a.vwrite     a3, s39, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s39, s30, #24192
    s.movz       s43, #10
    a.vwrite     a4, s48, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s45, s30, #24256
    a.vwrite     a4, s49, v2
    v.ld.w       v2, [s41, #0]
    s.movz       s41, #11
    a.vwrite     a4, s54, v2
    v.ld.w       v2, [s47, #0]
    s.addi       s47, s30, #24320
    a.vwrite     a4, s53, v2
    v.ld.w       v2, [s40, #0]
    s.movz       s40, #12
    a.vwrite     a4, s51, v2
    v.ld.w       v2, [s52, #0]
    s.addi       s52, s30, #24384
    a.vwrite     a4, s56, v2
    v.ld.w       v2, [s38, #0]
    s.movz       s38, #13
    a.vwrite     a4, s46, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s30, #24448
    a.vwrite     a4, s50, v2
    v.ld.w       v2, [s37, #0]
    s.movz       s37, #14
    a.vwrite     a4, s42, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s30, #24512
    a.vwrite     a4, s55, v2
    v.ld.w       v2, [s39, #0]
    s.movz       s39, #15
    a.vwrite     a4, s43, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s45, s30, #24576
    a.vwrite     a4, s41, v2
    v.ld.w       v2, [s47, #0]
    s.addi       s47, s30, #24640
    a.vwrite     a4, s40, v2
    v.ld.w       v2, [s52, #0]
    s.addi       s52, s30, #24704
    a.vwrite     a4, s38, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s30, #24768
    a.vwrite     a4, s37, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s30, #24832
    a.vwrite     a4, s39, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s45, s30, #24896
    a.vwrite     a5, s48, v2
    v.ld.w       v2, [s47, #0]
    s.addi       s47, s30, #24960
    s.addi       s48, s30, #25024
    a.vwrite     a5, s49, v2
    v.ld.w       v2, [s52, #0]
    s.addi       s49, s30, #25088
    s.addi       s52, s30, #25152
    a.vwrite     a5, s54, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s30, #25216
    s.addi       s54, s30, #25280
    a.vwrite     a5, s53, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s44, s30, #25344
    s.addi       s53, s30, #25408
    a.vwrite     a5, s51, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s45, s30, #25472
    s.addi       s51, s30, #25536
    a.vwrite     a5, s56, v2
    v.ld.w       v2, [s47, #0]
    s.addi       s47, s30, #25600
    s.movz       s56, #0
    a.vwrite     a5, s46, v2
    v.ld.w       v2, [s48, #0]
    s.addi       s46, s30, #25664
    s.movz       s48, #1
    a.vwrite     a5, s50, v2
    v.ld.w       v2, [s49, #0]
    s.addi       s49, s30, #25728
    s.movz       s50, #2
    a.vwrite     a5, s42, v2
    v.ld.w       v2, [s52, #0]
    s.addi       s42, s30, #25792
    s.movz       s52, #3
    a.vwrite     a5, s55, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s30, #25856
    s.movz       s55, #4
    a.vwrite     a5, s43, v2
    v.ld.w       v2, [s54, #0]
    s.addi       s43, s30, #25920
    s.movz       s54, #5
    a.vwrite     a5, s41, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s41, s30, #25984
    s.movz       s44, #6
    a.vwrite     a5, s40, v2
    v.ld.w       v2, [s53, #0]
    s.addi       s40, s30, #26048
    s.movz       s53, #7
    a.vwrite     a5, s38, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s38, s30, #26112
    s.movz       s45, #8
    a.vwrite     a5, s37, v2
    v.ld.w       v2, [s51, #0]
    s.addi       s37, s30, #26176
    s.movz       s51, #9
    a.vwrite     a5, s39, v2
    v.ld.w       v2, [s47, #0]
    s.addi       s39, s30, #26240
    s.movz       s47, #10
    a.vwrite     a6, s56, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s46, s30, #26304
    a.vwrite     a6, s48, v2
    v.ld.w       v2, [s49, #0]
    s.movz       s49, #11
    a.vwrite     a6, s50, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s30, #26368
    a.vwrite     a6, s52, v2
    v.ld.w       v2, [s34, #0]
    s.movz       s34, #12
    a.vwrite     a6, s55, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s30, #26432
    a.vwrite     a6, s54, v2
    v.ld.w       v2, [s41, #0]
    s.movz       s41, #13
    a.vwrite     a6, s44, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s30, #26496
    a.vwrite     a6, s53, v2
    v.ld.w       v2, [s38, #0]
    s.movz       s38, #14
    a.vwrite     a6, s45, v2
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s30, #26560
    a.vwrite     a6, s51, v2
    v.ld.w       v2, [s39, #0]
    s.movz       s39, #15
    a.vwrite     a6, s47, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s46, s30, #26624
    a.vwrite     a6, s49, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s30, #26688
    a.vwrite     a6, s34, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s30, #26752
    a.vwrite     a6, s41, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s30, #26816
    a.vwrite     a6, s38, v2
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s30, #26880
    a.vwrite     a6, s39, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s46, s30, #26944
    a.vwrite     a7, s56, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s30, #27008
    s.addi       s56, s30, #27072
    a.vwrite     a7, s48, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s30, #27136
    s.addi       s48, s30, #27200
    a.vwrite     a7, s50, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s30, #27264
    s.addi       s50, s30, #27328
    a.vwrite     a7, s52, v2
    v.ld.w       v2, [s37, #0]
    s.addi       s37, s30, #27392
    s.addi       s52, s30, #27456
    a.vwrite     a7, s55, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s46, s30, #27520
    s.addi       s55, s30, #27584
    s.add        s30, s17, s10
    a.vwrite     a7, s54, v2
    v.ld.w       v2, [s42, #0]
    s.movz       s42, #1
    a.vwrite     a7, s44, v2
    v.ld.w       v2, [s56, #0]
    a.vwrite     a7, s53, v2
    v.ld.w       v2, [s43, #0]
    a.vwrite     a7, s45, v2
    v.ld.w       v2, [s48, #0]
    a.vwrite     a7, s51, v2
    v.ld.w       v2, [s40, #0]
    a.vwrite     a7, s47, v2
    v.ld.w       v2, [s50, #0]
    a.vwrite     a7, s49, v2
    v.ld.w       v2, [s37, #0]
    a.vwrite     a7, s34, v2
    v.ld.w       v2, [s52, #0]
    a.vwrite     a7, s41, v2
    v.ld.w       v2, [s46, #0]
    a.vwrite     a7, s38, v2
    v.ld.w       v2, [s55, #0]
    a.vwrite     a7, s39, v2
    s.mov        s17, s30
    br.nz        s42, for_25
endfor_26:
    s.mul        s2, s8, s4
    s.movz       s4, #0
    s.muli       s5, s1, #2
    s.add        s6, s4, s1                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s7, s2, s23
    v.splat      v1, s6
    a.vread      v2, a0, s4
    s.muli       s6, s23, #2
    s.add        s8, s4, s2                      // the tile origin
    s.muli       s9, s7, #2
    s.add        s7, s4, s3                      // the tile origin
    v.splat      v3, s8
    v.splat      v4, s10
    v.add        v5, v0, v1
    v.splat      v1, s7
    vf.cvt.f32.bf16 v6, v2
    s.add        s4, s9, s5
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.muli       s7, s6, #1
    s.add        s10, s19, s4
    p.and        p3, p1, p2
    s.movz       s4, #1
    @p3 v.st.h       [s10, #0], v6
    a.vread      v1, a0, s4
    s.addi       s4, s8, #1
    s.add        s10, s7, s9
    v.splat      v2, s4
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s10, s5
    v.cmp.lt     p1, v2, v4
    s.muli       s7, s6, #2
    s.add        s10, s19, s4
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.addi       s11, s1, #16
    s.addi       s12, s1, #32
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s4
    s.addi       s4, s1, #48
    s.addi       s10, s1, #64
    vf.cvt.f32.bf16 v2, v1
    s.addi       s13, s1, #80
    s.addi       s14, s1, #96
    s.addi       s15, s1, #112
    v.iota       v1                              // arange(0, VLEN)
    s.add        s1, s7, s9
    v.splat      v3, s2
    s.add        s2, s1, s5
    v.add        v5, v3, v1
    s.addi       s1, s8, #2
    s.muli       s7, s6, #3
    v.splat      v1, s1
    s.add        s1, s19, s2
    s.movz       s2, #3
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s16, s8, #3
    @p3 v.st.h       [s1, #0], v2
    a.vread      v1, a0, s2
    s.add        s1, s7, s9
    v.splat      v2, s16
    vf.cvt.f32.bf16 v3, v1
    s.add        s2, s1, s5
    v.cmp.lt     p1, v2, v4
    s.muli       s1, s6, #4
    s.add        s7, s19, s2
    p.and        p3, p1, p2
    s.movz       s2, #4
    s.addi       s16, s8, #4
    s.add        s17, s1, s9
    v.splat      v1, s16
    @p3 v.st.h       [s7, #0], v3
    a.vread      v2, a0, s2
    s.add        s1, s17, s5
    v.cmp.lt     p1, v1, v4
    vf.cvt.f32.bf16 v1, v2
    s.muli       s2, s6, #5
    s.add        s7, s19, s1
    p.and        p3, p1, p2
    s.movz       s1, #5
    s.addi       s16, s8, #5
    s.add        s17, s2, s9
    v.splat      v2, s16
    s.add        s2, s17, s5
    s.muli       s16, s6, #6
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v2, v4
    s.add        s1, s19, s2
    vf.cvt.f32.bf16 v2, v1
    p.and        p3, p1, p2
    s.movz       s2, #6
    s.addi       s7, s8, #6
    s.add        s17, s16, s9
    v.splat      v1, s7
    s.add        s7, s17, s5
    s.muli       s16, s6, #7
    v.cmp.lt     p1, v1, v4
    s.add        s17, s19, s7
    @p3 v.st.h       [s1, #0], v2
    a.vread      v1, a0, s2
    p.and        p3, p1, p2
    s.movz       s1, #7
    vf.cvt.f32.bf16 v2, v1
    s.addi       s2, s8, #7
    s.add        s7, s16, s9
    v.splat      v1, s2
    s.add        s2, s7, s5
    s.muli       s7, s6, #8
    v.cmp.lt     p1, v1, v4
    s.add        s16, s19, s2
    p.and        p4, p1, p2
    s.movz       s2, #8
    @p3 v.st.h       [s17, #0], v2
    a.vread      v1, a0, s1
    s.addi       s1, s8, #8
    s.add        s17, s7, s9
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s1
    s.add        s1, s17, s5
    s.muli       s7, s6, #9
    v.cmp.lt     p1, v1, v4
    s.add        s17, s19, s1
    p.and        p3, p1, p2
    s.movz       s1, #9
    s.addi       s18, s8, #9
    s.add        s21, s7, s9
    @p4 v.st.h       [s16, #0], v2
    a.vread      v1, a0, s2
    v.splat      v2, s18
    s.add        s2, s21, s5
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s7, s6, #10
    s.add        s16, s19, s2
    p.and        p4, p1, p2
    s.movz       s2, #10
    s.addi       s18, s8, #10
    s.add        s21, s7, s9
    v.splat      v1, s18
    s.add        s7, s21, s5
    @p3 v.st.h       [s17, #0], v3
    a.vread      v2, a0, s1
    v.cmp.lt     p1, v1, v4
    s.muli       s1, s6, #11
    vf.cvt.f32.bf16 v1, v2
    s.add        s17, s19, s7
    p.and        p3, p1, p2
    s.movz       s7, #11
    s.addi       s18, s8, #11
    s.add        s21, s1, s9
    v.splat      v2, s18
    s.add        s1, s21, s5
    s.muli       s18, s6, #12
    s.add        s21, s19, s1
    @p4 v.st.h       [s16, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.movz       s1, #12
    s.addi       s2, s8, #12
    s.add        s16, s18, s9
    v.splat      v1, s2
    s.add        s2, s16, s5
    s.muli       s16, s6, #13
    s.add        s18, s19, s2
    s.movz       s2, #13
    s.addi       s22, s8, #13
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a0, s7
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s7, s16, s9
    v.splat      v2, s22
    s.add        s16, s7, s5
    s.muli       s7, s6, #14
    s.add        s17, s19, s16
    s.movz       s16, #14
    s.addi       s22, s8, #14
    s.add        s23, s7, s9
    @p4 v.st.h       [s21, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s22
    s.add        s1, s23, s5
    s.muli       s7, s6, #15
    s.add        s21, s19, s1
    s.movz       s1, #15
    s.addi       s22, s8, #15
    v.splat      v3, s8
    s.add        s23, s7, s9
    v.splat      v5, s22
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a0, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.movz       s2, #0
    s.add        s7, s23, s5
    s.add        s5, s2, s11                     // the tile origin
    s.add        s18, s19, s7
    s.muli       s7, s11, #2
    v.splat      v2, s5
    s.add        s5, s2, s3                      // the tile origin
    s.muli       s11, s6, #1
    v.add        v6, v0, v2
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a0, s16
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s5
    s.add        s5, s9, s7
    v.cmp.lt     p1, v3, v4
    s.add        s16, s19, s5
    s.movz       s5, #1
    s.addi       s17, s8, #1
    s.add        s22, s11, s9
    v.splat      v3, s17
    s.add        s11, s22, s7
    @p3 v.st.h       [s21, #0], v2
    a.vread      v2, a0, s1
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s1, s6, #2
    s.add        s17, s19, s11
    s.movz       s11, #2
    s.addi       s21, s8, #2
    s.muli       s22, s6, #3
    s.add        s23, s1, s9
    v.splat      v2, s21
    s.add        s1, s23, s7
    s.movz       s21, #3
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s2
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s2, s19, s1
    s.addi       s1, s8, #3
    s.add        s18, s22, s9
    v.splat      v1, s1
    s.add        s1, s18, s7
    s.muli       s18, s6, #4
    s.add        s22, s19, s1
    s.movz       s1, #4
    @p3 v.st.h       [s16, #0], v3
    a.vread      v3, a1, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s5, s8, #4
    s.add        s16, s18, s9
    v.splat      v3, s5
    s.add        s5, s16, s7
    s.muli       s16, s6, #5
    s.add        s18, s19, s5
    s.movz       s5, #5
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a1, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s11, s8, #5
    s.add        s17, s16, s9
    v.splat      v2, s11
    s.add        s11, s17, s7
    s.muli       s16, s6, #6
    s.add        s17, s19, s11
    s.movz       s11, #6
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a1, s21
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s2, s8, #6
    s.add        s21, s16, s9
    v.splat      v1, s2
    s.add        s2, s21, s7
    s.muli       s16, s6, #7
    s.add        s21, s19, s2
    s.movz       s2, #7
    @p4 v.st.h       [s22, #0], v3
    a.vread      v3, a1, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s1, s8, #7
    s.add        s22, s16, s9
    v.splat      v3, s1
    s.add        s1, s22, s7
    s.muli       s16, s6, #8
    s.add        s22, s19, s1
    s.movz       s1, #8
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a1, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s5, s8, #8
    s.add        s18, s16, s9
    v.splat      v2, s5
    s.add        s5, s18, s7
    s.muli       s16, s6, #9
    s.add        s18, s19, s5
    s.movz       s5, #9
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a1, s11
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s8, #9
    s.add        s17, s16, s9
    v.splat      v1, s11
    s.add        s11, s17, s7
    s.muli       s16, s6, #10
    s.add        s17, s19, s11
    s.movz       s11, #10
    @p3 v.st.h       [s21, #0], v3
    a.vread      v3, a1, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s2, s8, #10
    s.add        s21, s16, s9
    v.splat      v3, s2
    s.add        s2, s21, s7
    s.muli       s16, s6, #11
    s.add        s21, s19, s2
    s.movz       s2, #11
    @p4 v.st.h       [s22, #0], v2
    a.vread      v2, a1, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s1, s8, #11
    s.add        s22, s16, s9
    v.splat      v2, s1
    s.add        s1, s22, s7
    s.muli       s16, s6, #12
    s.add        s22, s19, s1
    s.movz       s1, #12
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s5, s8, #12
    s.add        s18, s16, s9
    v.splat      v1, s5
    s.add        s5, s18, s7
    s.muli       s16, s6, #13
    s.add        s18, s19, s5
    s.movz       s5, #13
    @p4 v.st.h       [s17, #0], v3
    a.vread      v3, a1, s11
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s11, s8, #13
    s.add        s17, s16, s9
    v.splat      v3, s11
    s.add        s11, s17, s7
    s.muli       s16, s6, #14
    s.add        s17, s19, s11
    s.movz       s11, #14
    @p3 v.st.h       [s21, #0], v2
    a.vread      v2, a1, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s2, s8, #14
    s.add        s21, s16, s9
    v.splat      v2, s2
    s.add        s2, s21, s7
    s.muli       s16, s6, #15
    s.add        s21, s19, s2
    s.movz       s2, #15
    @p4 v.st.h       [s22, #0], v1
    a.vread      v1, a1, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s8, #15
    s.add        s22, s16, s9
    v.splat      v1, s1
    s.movz       s1, #0
    s.add        s16, s22, s7
    s.add        s7, s1, s12                     // the tile origin
    s.add        s22, s19, s16
    s.muli       s16, s12, #2
    v.splat      v5, s7
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a1, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.add        s5, s1, s3                      // the tile origin
    v.splat      v3, s8
    v.add        v6, v0, v5
    v.splat      v5, s5
    s.add        s5, s9, s16
    s.muli       s7, s6, #1
    s.add        s12, s19, s5
    s.movz       s5, #1
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a1, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.cmp.lt     p1, v3, v4
    s.addi       s11, s8, #1
    s.add        s17, s7, s9
    v.splat      v2, s11
    s.add        s7, s17, s16
    s.muli       s11, s6, #2
    s.add        s17, s19, s7
    s.movz       s7, #2
    @p3 v.st.h       [s21, #0], v1
    a.vread      v1, a1, s2
    v.cmp.lt     p2, v6, v5
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s2, s8, #2
    s.add        s18, s11, s9
    v.splat      v1, s2
    s.add        s2, s18, s16
    s.muli       s11, s6, #3
    s.add        s18, s19, s2
    s.movz       s2, #3
    @p4 v.st.h       [s22, #0], v3
    a.vread      v3, a2, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s1, s8, #3
    s.add        s21, s11, s9
    v.splat      v3, s1
    s.add        s1, s21, s16
    s.muli       s11, s6, #4
    s.add        s21, s19, s1
    s.movz       s1, #4
    s.addi       s22, s8, #4
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a2, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s5, s11, s9
    v.splat      v2, s22
    s.add        s11, s5, s16
    s.muli       s5, s6, #5
    s.add        s12, s19, s11
    s.movz       s11, #5
    s.addi       s22, s8, #5
    s.add        s23, s5, s9
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a2, s7
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s22
    s.add        s5, s23, s16
    s.muli       s7, s6, #6
    s.add        s17, s19, s5
    s.movz       s5, #6
    s.addi       s22, s8, #6
    s.add        s23, s7, s9
    v.splat      v5, s22
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.add        s2, s23, s16
    s.muli       s7, s6, #7
    s.add        s18, s19, s2
    s.movz       s2, #7
    s.addi       s22, s8, #7
    s.add        s23, s7, s9
    v.splat      v3, s22
    s.add        s7, s23, s16
    @p4 v.st.h       [s21, #0], v2
    a.vread      v2, a2, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s1, s6, #8
    s.add        s21, s19, s7
    s.movz       s7, #8
    s.addi       s22, s8, #8
    s.add        s23, s1, s9
    v.splat      v2, s22
    s.add        s1, s23, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a2, s11
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s11, s6, #9
    s.add        s12, s19, s1
    s.movz       s1, #9
    s.addi       s22, s8, #9
    s.add        s23, s11, s9
    v.splat      v1, s22
    s.add        s11, s23, s16
    @p4 v.st.h       [s17, #0], v5
    a.vread      v5, a2, s5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s5, s6, #10
    s.add        s17, s19, s11
    s.movz       s11, #10
    s.addi       s22, s8, #10
    s.add        s23, s5, s9
    v.splat      v5, s22
    s.add        s5, s23, s16
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s2, s6, #11
    s.add        s18, s19, s5
    s.movz       s5, #11
    s.addi       s22, s8, #11
    s.add        s23, s2, s9
    v.splat      v3, s22
    s.add        s2, s23, s16
    @p4 v.st.h       [s21, #0], v2
    a.vread      v2, a2, s7
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s7, s6, #12
    s.add        s21, s19, s2
    s.movz       s2, #12
    s.addi       s22, s8, #12
    s.add        s23, s7, s9
    v.splat      v2, s22
    s.add        s7, s23, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a2, s1
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s1, s6, #13
    s.add        s12, s19, s7
    s.movz       s7, #13
    s.addi       s22, s8, #13
    s.add        s23, s1, s9
    v.splat      v1, s22
    s.add        s1, s23, s16
    @p4 v.st.h       [s17, #0], v5
    a.vread      v5, a2, s11
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s11, s6, #14
    s.add        s17, s19, s1
    s.movz       s1, #14
    s.addi       s22, s8, #14
    s.add        s23, s11, s9
    v.splat      v5, s22
    s.add        s11, s23, s16
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s5, s6, #15
    s.add        s18, s19, s11
    s.movz       s11, #15
    s.addi       s22, s8, #15
    s.add        s23, s5, s9
    v.splat      v3, s22
    s.add        s5, s23, s16
    @p4 v.st.h       [s21, #0], v2
    a.vread      v2, a2, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.movz       s2, #0
    s.add        s16, s19, s5
    s.add        s5, s2, s4                      // the tile origin
    s.muli       s21, s4, #2
    v.splat      v2, s5
    v.splat      v6, s8
    v.add        v7, v0, v2
    s.add        s4, s9, s21
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a2, s7
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s5, s2, s3                      // the tile origin
    s.muli       s7, s6, #1
    v.splat      v1, s5
    s.add        s5, s19, s4
    s.movz       s4, #1
    s.add        s12, s7, s9
    s.add        s7, s12, s21
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s1, s8, #1
    s.muli       s12, s6, #2
    v.splat      v2, s1
    s.add        s1, s19, s7
    s.movz       s7, #2
    s.add        s17, s12, s9
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s11
    v.cmp.lt     p2, v7, v1
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s11, s8, #2
    s.add        s12, s17, s21
    v.splat      v3, s11
    s.muli       s11, s6, #3
    s.add        s17, s19, s12
    s.movz       s12, #3
    s.add        s18, s11, s9
    @p4 v.st.h       [s16, #0], v1
    a.vread      v1, a3, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s2, s8, #3
    s.add        s11, s18, s21
    v.splat      v1, s2
    s.muli       s2, s6, #4
    s.add        s16, s19, s11
    s.movz       s11, #4
    s.addi       s18, s8, #4
    s.add        s22, s2, s9
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a3, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s18
    s.add        s2, s22, s21
    s.muli       s4, s6, #5
    s.add        s5, s19, s2
    s.movz       s2, #5
    s.addi       s18, s8, #5
    s.add        s22, s4, s9
    v.splat      v5, s18
    @p4 v.st.h       [s1, #0], v3
    a.vread      v3, a3, s7
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s1, s22, s21
    s.muli       s4, s6, #6
    s.add        s7, s19, s1
    s.movz       s1, #6
    s.addi       s18, s8, #6
    s.add        s22, s4, s9
    v.splat      v3, s18
    s.add        s4, s22, s21
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s12
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s12, s6, #7
    s.add        s17, s19, s4
    s.movz       s4, #7
    s.addi       s18, s8, #7
    s.add        s22, s12, s9
    v.splat      v1, s18
    s.add        s12, s22, s21
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a3, s11
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s11, s6, #8
    s.add        s16, s19, s12
    s.movz       s12, #8
    s.addi       s18, s8, #8
    s.add        s22, s11, s9
    v.splat      v2, s18
    s.add        s11, s22, s21
    @p3 v.st.h       [s5, #0], v5
    a.vread      v5, a3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s2, s6, #9
    s.add        s5, s19, s11
    s.movz       s11, #9
    s.addi       s18, s8, #9
    s.add        s22, s2, s9
    v.splat      v5, s18
    s.add        s2, s22, s21
    @p4 v.st.h       [s7, #0], v3
    a.vread      v3, a3, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s1, s6, #10
    s.add        s7, s19, s2
    s.movz       s2, #10
    s.addi       s18, s8, #10
    s.add        s22, s1, s9
    v.splat      v3, s18
    s.add        s1, s22, s21
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s4
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s4, s6, #11
    s.add        s17, s19, s1
    s.movz       s1, #11
    s.addi       s18, s8, #11
    s.add        s22, s4, s9
    v.splat      v1, s18
    s.add        s4, s22, s21
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a3, s12
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s12, s6, #12
    s.add        s16, s19, s4
    s.movz       s4, #12
    s.addi       s18, s8, #12
    s.add        s22, s12, s9
    v.splat      v2, s18
    s.add        s12, s22, s21
    @p3 v.st.h       [s5, #0], v5
    a.vread      v5, a3, s11
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s5, s6, #13
    s.add        s11, s19, s12
    s.movz       s12, #13
    s.addi       s18, s8, #13
    s.add        s22, s5, s9
    v.splat      v5, s18
    s.add        s5, s22, s21
    @p4 v.st.h       [s7, #0], v3
    a.vread      v3, a3, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s6, #14
    s.add        s7, s19, s5
    s.movz       s5, #14
    s.addi       s18, s8, #14
    s.add        s22, s2, s9
    v.splat      v3, s18
    s.add        s2, s22, s21
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s1, s6, #15
    s.add        s17, s19, s2
    s.movz       s2, #15
    s.addi       s18, s8, #15
    s.add        s22, s1, s9
    v.splat      v1, s18
    s.add        s1, s22, s21
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a3, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.movz       s4, #0
    s.add        s16, s19, s1
    s.add        s1, s4, s10                     // the tile origin
    s.muli       s18, s10, #2
    v.splat      v2, s1
    v.splat      v6, s8
    v.add        v7, v0, v2
    s.add        s1, s9, s18
    @p3 v.st.h       [s11, #0], v5
    a.vread      v2, a3, s12
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s10, s4, s3                     // the tile origin
    s.muli       s11, s6, #1
    v.splat      v2, s10
    s.add        s10, s19, s1
    s.movz       s1, #1
    s.add        s12, s11, s9
    s.add        s11, s12, s18
    @p4 v.st.h       [s7, #0], v3
    a.vread      v3, a3, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    v.cmp.lt     p1, v6, v4
    s.addi       s5, s8, #1
    s.muli       s7, s6, #2
    v.splat      v3, s5
    s.add        s5, s19, s11
    s.movz       s11, #2
    s.add        s12, s7, s9
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s2
    v.cmp.lt     p2, v7, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s2, s8, #2
    s.add        s7, s12, s18
    v.splat      v1, s2
    s.muli       s2, s6, #3
    s.add        s12, s19, s7
    s.movz       s7, #3
    s.add        s17, s2, s9
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a4, s4
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s2, s8, #3
    s.add        s4, s17, s18
    v.splat      v2, s2
    s.muli       s2, s6, #4
    s.add        s16, s19, s4
    s.movz       s4, #4
    s.addi       s17, s8, #4
    s.add        s21, s2, s9
    @p3 v.st.h       [s10, #0], v3
    a.vread      v3, a4, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    v.splat      v3, s17
    s.add        s1, s21, s18
    s.muli       s2, s6, #5
    s.add        s10, s19, s1
    s.movz       s1, #5
    s.addi       s17, s8, #5
    s.add        s21, s2, s9
    v.splat      v5, s17
    @p4 v.st.h       [s5, #0], v1
    a.vread      v1, a4, s11
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s2, s21, s18
    s.muli       s5, s6, #6
    s.add        s11, s19, s2
    s.movz       s2, #6
    s.addi       s17, s8, #6
    s.add        s21, s5, s9
    v.splat      v1, s17
    s.add        s5, s21, s18
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a4, s7
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s7, s6, #7
    s.add        s12, s19, s5
    s.movz       s5, #7
    s.addi       s17, s8, #7
    s.add        s21, s7, s9
    v.splat      v2, s17
    s.add        s7, s21, s18
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a4, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v3
    s.muli       s4, s6, #8
    s.add        s16, s19, s7
    s.movz       s7, #8
    s.addi       s17, s8, #8
    s.add        s21, s4, s9
    v.splat      v3, s17
    s.add        s4, s21, s18
    @p3 v.st.h       [s10, #0], v5
    a.vread      v5, a4, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s1, s6, #9
    s.add        s10, s19, s4
    s.movz       s4, #9
    s.addi       s17, s8, #9
    s.add        s21, s1, s9
    v.splat      v5, s17
    s.add        s1, s21, s18
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a4, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s2, s6, #10
    s.add        s11, s19, s1
    s.movz       s1, #10
    s.addi       s17, s8, #10
    s.add        s21, s2, s9
    v.splat      v1, s17
    s.add        s2, s21, s18
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a4, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s5, s6, #11
    s.add        s12, s19, s2
    s.movz       s2, #11
    s.addi       s17, s8, #11
    s.add        s21, s5, s9
    v.splat      v2, s17
    s.add        s5, s21, s18
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a4, s7
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v3
    s.muli       s7, s6, #12
    s.add        s16, s19, s5
    s.movz       s5, #12
    s.addi       s17, s8, #12
    s.add        s21, s7, s9
    v.splat      v3, s17
    s.add        s7, s21, s18
    @p3 v.st.h       [s10, #0], v5
    a.vread      v5, a4, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s4, s6, #13
    s.add        s10, s19, s7
    s.movz       s7, #13
    s.addi       s17, s8, #13
    s.add        s21, s4, s9
    v.splat      v5, s17
    s.add        s4, s21, s18
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a4, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s1, s6, #14
    s.add        s11, s19, s4
    s.movz       s4, #14
    s.addi       s17, s8, #14
    s.add        s21, s1, s9
    v.splat      v1, s17
    s.add        s1, s21, s18
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a4, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s2, s6, #15
    s.add        s12, s19, s1
    s.movz       s1, #15
    s.addi       s17, s8, #15
    s.add        s21, s2, s9
    v.splat      v2, s17
    s.add        s2, s21, s18
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a4, s5
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v3
    s.movz       s5, #0
    s.add        s16, s19, s2
    s.add        s2, s5, s13                     // the tile origin
    s.muli       s17, s13, #2
    v.splat      v3, s2
    v.splat      v6, s8
    v.add        v7, v0, v3
    s.add        s2, s9, s17
    @p3 v.st.h       [s10, #0], v5
    a.vread      v3, a4, s7
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s7, s5, s3                      // the tile origin
    s.muli       s10, s6, #1
    v.splat      v3, s7
    s.add        s7, s19, s2
    s.movz       s2, #1
    s.add        s13, s10, s9
    s.add        s10, s13, s17
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a4, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.cmp.lt     p1, v6, v4
    s.addi       s4, s8, #1
    s.muli       s11, s6, #2
    v.splat      v1, s4
    s.add        s4, s19, s10
    s.movz       s10, #2
    s.add        s13, s11, s9
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a4, s1
    v.cmp.lt     p2, v7, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s1, s8, #2
    s.add        s11, s13, s17
    v.splat      v2, s1
    s.muli       s1, s6, #3
    s.add        s12, s19, s11
    s.movz       s11, #3
    s.add        s13, s1, s9
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a5, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s1, s8, #3
    s.add        s5, s13, s17
    v.splat      v3, s1
    s.muli       s1, s6, #4
    s.add        s13, s19, s5
    s.movz       s5, #4
    s.addi       s16, s8, #4
    s.add        s18, s1, s9
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a5, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s16
    s.add        s1, s18, s17
    s.muli       s2, s6, #5
    s.add        s7, s19, s1
    s.movz       s1, #5
    s.addi       s16, s8, #5
    s.add        s18, s2, s9
    v.splat      v5, s16
    @p4 v.st.h       [s4, #0], v2
    a.vread      v2, a5, s10
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s2, s18, s17
    s.muli       s4, s6, #6
    s.add        s10, s19, s2
    s.movz       s2, #6
    s.addi       s16, s8, #6
    s.add        s18, s4, s9
    v.splat      v2, s16
    s.add        s4, s18, s17
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a5, s11
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s11, s6, #7
    s.add        s12, s19, s4
    s.movz       s4, #7
    s.addi       s16, s8, #7
    s.add        s18, s11, s9
    v.splat      v3, s16
    s.add        s11, s18, s17
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s5
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s5, s6, #8
    s.add        s13, s19, s11
    s.movz       s11, #8
    s.addi       s16, s8, #8
    s.add        s18, s5, s9
    v.splat      v1, s16
    s.add        s5, s18, s17
    @p3 v.st.h       [s7, #0], v5
    a.vread      v5, a5, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s1, s6, #9
    s.add        s7, s19, s5
    s.movz       s5, #9
    s.addi       s16, s8, #9
    s.add        s18, s1, s9
    v.splat      v5, s16
    s.add        s1, s18, s17
    @p4 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s2
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s2, s6, #10
    s.add        s10, s19, s1
    s.movz       s1, #10
    s.addi       s16, s8, #10
    s.add        s18, s2, s9
    v.splat      v2, s16
    s.add        s2, s18, s17
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a5, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s6, #11
    s.add        s12, s19, s2
    s.movz       s2, #11
    s.addi       s16, s8, #11
    s.add        s18, s4, s9
    v.splat      v3, s16
    s.add        s4, s18, s17
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s11
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s11, s6, #12
    s.add        s13, s19, s4
    s.movz       s4, #12
    s.addi       s16, s8, #12
    s.add        s18, s11, s9
    v.splat      v1, s16
    s.add        s11, s18, s17
    @p3 v.st.h       [s7, #0], v5
    a.vread      v5, a5, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s5, s6, #13
    s.add        s7, s19, s11
    s.movz       s11, #13
    s.addi       s16, s8, #13
    s.add        s18, s5, s9
    v.splat      v5, s16
    s.add        s5, s18, s17
    @p4 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s1, s6, #14
    s.add        s10, s19, s5
    s.movz       s5, #14
    s.addi       s16, s8, #14
    s.add        s18, s1, s9
    v.splat      v2, s16
    s.add        s1, s18, s17
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a5, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s6, #15
    s.add        s12, s19, s1
    s.movz       s1, #15
    s.addi       s16, s8, #15
    s.add        s18, s2, s9
    v.splat      v3, s16
    s.add        s2, s18, s17
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.movz       s4, #0
    s.add        s13, s19, s2
    s.add        s2, s4, s14                     // the tile origin
    s.muli       s16, s14, #2
    v.splat      v1, s2
    v.splat      v6, s8
    v.add        v7, v0, v1
    s.add        s2, s9, s16
    @p3 v.st.h       [s7, #0], v5
    a.vread      v1, a5, s11
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s7, s4, s3                      // the tile origin
    s.muli       s11, s6, #1
    v.splat      v1, s7
    s.add        s7, s19, s2
    s.movz       s2, #1
    s.add        s14, s11, s9
    s.add        s11, s14, s16
    @p4 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s5, s8, #1
    s.muli       s10, s6, #2
    v.splat      v2, s5
    s.add        s5, s19, s11
    s.movz       s11, #2
    s.add        s14, s10, s9
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a5, s1
    v.cmp.lt     p2, v7, v1
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s1, s8, #2
    s.add        s10, s14, s16
    v.splat      v3, s1
    s.muli       s1, s6, #3
    s.add        s12, s19, s10
    s.movz       s10, #3
    s.add        s14, s1, s9
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a6, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s1, s8, #3
    s.add        s4, s14, s16
    v.splat      v1, s1
    s.muli       s1, s6, #4
    s.add        s13, s19, s4
    s.movz       s4, #4
    s.addi       s14, s8, #4
    s.add        s17, s1, s9
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a6, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s14
    s.add        s1, s17, s16
    s.muli       s2, s6, #5
    s.add        s7, s19, s1
    s.movz       s1, #5
    s.addi       s14, s8, #5
    s.add        s17, s2, s9
    v.splat      v5, s14
    @p4 v.st.h       [s5, #0], v3
    a.vread      v3, a6, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s2, s17, s16
    s.muli       s5, s6, #6
    s.add        s11, s19, s2
    s.movz       s2, #6
    s.addi       s14, s8, #6
    s.add        s17, s5, s9
    v.splat      v3, s14
    s.add        s5, s17, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s10
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s10, s6, #7
    s.add        s12, s19, s5
    s.movz       s5, #7
    s.addi       s14, s8, #7
    s.add        s17, s10, s9
    v.splat      v1, s14
    s.add        s10, s17, s16
    @p4 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s4, s6, #8
    s.add        s13, s19, s10
    s.movz       s10, #8
    s.addi       s14, s8, #8
    s.add        s17, s4, s9
    v.splat      v2, s14
    s.add        s4, s17, s16
    @p3 v.st.h       [s7, #0], v5
    a.vread      v5, a6, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s1, s6, #9
    s.add        s7, s19, s4
    s.movz       s4, #9
    s.addi       s14, s8, #9
    s.add        s17, s1, s9
    v.splat      v5, s14
    s.add        s1, s17, s16
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a6, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s6, #10
    s.add        s11, s19, s1
    s.movz       s1, #10
    s.addi       s14, s8, #10
    s.add        s17, s2, s9
    v.splat      v3, s14
    s.add        s2, s17, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s5, s6, #11
    s.add        s12, s19, s2
    s.movz       s2, #11
    s.addi       s14, s8, #11
    s.add        s17, s5, s9
    v.splat      v1, s14
    s.add        s5, s17, s16
    @p4 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s10
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s10, s6, #12
    s.add        s13, s19, s5
    s.movz       s5, #12
    s.addi       s14, s8, #12
    s.add        s17, s10, s9
    v.splat      v2, s14
    s.add        s10, s17, s16
    @p3 v.st.h       [s7, #0], v5
    a.vread      v5, a6, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s4, s6, #13
    s.add        s7, s19, s10
    s.movz       s10, #13
    s.addi       s14, s8, #13
    s.add        s17, s4, s9
    v.splat      v5, s14
    s.add        s4, s17, s16
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a6, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s1, s6, #14
    s.add        s11, s19, s4
    s.movz       s4, #14
    s.addi       s14, s8, #14
    s.add        s17, s1, s9
    v.splat      v3, s14
    s.add        s1, s17, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s2, s6, #15
    s.add        s12, s19, s1
    s.movz       s1, #15
    s.addi       s14, s8, #15
    s.add        s17, s2, s9
    v.splat      v1, s14
    s.add        s2, s17, s16
    @p4 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s5
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.movz       s5, #0
    s.add        s13, s19, s2
    s.add        s2, s5, s15                     // the tile origin
    s.muli       s14, s15, #2
    v.splat      v2, s2
    v.splat      v6, s8
    v.add        v7, v0, v2
    s.add        s2, s9, s14
    @p3 v.st.h       [s7, #0], v5
    a.vread      v0, a6, s10
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.add        s7, s5, s3                      // the tile origin
    s.muli       s3, s6, #1
    v.splat      v0, s7
    s.add        s7, s19, s2
    s.movz       s2, #1
    s.add        s10, s3, s9
    s.add        s3, s10, s14
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a6, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s4, s8, #1
    s.muli       s10, s6, #2
    v.splat      v2, s4
    s.add        s4, s19, s3
    s.movz       s3, #2
    s.add        s11, s10, s9
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s1
    v.cmp.lt     p2, v7, v0
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s8, #2
    s.add        s10, s11, s14
    v.splat      v1, s1
    s.muli       s1, s6, #3
    s.add        s11, s19, s10
    s.movz       s10, #3
    s.add        s12, s1, s9
    @p4 v.st.h       [s13, #0], v0
    a.vread      v0, a7, s5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.addi       s1, s8, #3
    s.add        s5, s12, s14
    v.splat      v0, s1
    s.muli       s1, s6, #4
    s.add        s12, s19, s5
    s.movz       s5, #4
    s.addi       s13, s8, #4
    s.add        s15, s1, s9
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a7, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.splat      v2, s13
    s.add        s1, s15, s14
    s.muli       s2, s6, #5
    s.add        s7, s19, s1
    s.movz       s1, #5
    s.addi       s13, s8, #5
    s.add        s15, s2, s9
    v.splat      v3, s13
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a7, s3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.add        s2, s15, s14
    s.muli       s3, s6, #6
    s.add        s4, s19, s2
    s.movz       s2, #6
    s.addi       s13, s8, #6
    s.add        s15, s3, s9
    v.splat      v1, s13
    s.add        s3, s15, s14
    @p3 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s10
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s10, s6, #7
    s.add        s11, s19, s3
    s.movz       s3, #7
    s.addi       s13, s8, #7
    s.add        s15, s10, s9
    v.splat      v0, s13
    s.add        s10, s15, s14
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a7, s5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s5, s6, #8
    s.add        s12, s19, s10
    s.movz       s10, #8
    s.addi       s13, s8, #8
    s.add        s15, s5, s9
    v.splat      v2, s13
    s.add        s5, s15, s14
    @p3 v.st.h       [s7, #0], v3
    a.vread      v3, a7, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s1, s6, #9
    s.add        s7, s19, s5
    s.movz       s5, #9
    s.addi       s13, s8, #9
    s.add        s15, s1, s9
    v.splat      v3, s13
    s.add        s1, s15, s14
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a7, s2
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s2, s6, #10
    s.add        s4, s19, s1
    s.movz       s1, #10
    s.addi       s13, s8, #10
    s.add        s15, s2, s9
    v.splat      v1, s13
    s.add        s2, s15, s14
    @p3 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s3
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s3, s6, #11
    s.add        s11, s19, s2
    s.movz       s2, #11
    s.addi       s13, s8, #11
    s.add        s15, s3, s9
    v.splat      v0, s13
    s.add        s3, s15, s14
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a7, s10
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s10, s6, #12
    s.add        s12, s19, s3
    s.movz       s3, #12
    s.addi       s13, s8, #12
    s.add        s15, s10, s9
    v.splat      v2, s13
    s.add        s10, s15, s14
    @p3 v.st.h       [s7, #0], v3
    a.vread      v3, a7, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s5, s6, #13
    s.add        s7, s19, s10
    s.movz       s10, #13
    s.addi       s13, s8, #13
    s.add        s15, s5, s9
    v.splat      v3, s13
    s.add        s5, s15, s14
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a7, s1
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s1, s6, #14
    s.add        s4, s19, s5
    s.movz       s5, #14
    s.addi       s13, s8, #14
    s.add        s15, s1, s9
    v.splat      v1, s13
    s.add        s1, s15, s14
    @p3 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s2, s6, #15
    s.add        s6, s19, s1
    s.movz       s1, #15
    s.addi       s11, s8, #15
    s.add        s8, s2, s9
    v.splat      v0, s11
    s.add        s2, s8, s14
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a7, s3
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s3, s19, s2
    @p3 v.st.h       [s7, #0], v3
    a.vread      v2, a7, s10
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a7, s5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s3, #0], v1
    exit
    exit
