#!/bin/bash
set -eu
mode="$1"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TNCA_X8_EQUAL_OUTPUT="$mode" TNCA_BACKEND=systemc-tlm-grid TNCA_PROFILE=core-vrf-sync-v5-x8-g2c4-dp TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip" TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg" TNCA_HOST_TIMEOUT=600 TNCA_TLM_OUT="$HOME/r41_x8_equal_output_proof_v7_${mode}_tlm_20261101"
cd "$HOME/r41_current_x8_equal_output_20261101"
exec "$HOME/flux-venv/bin/python" -u tools/r41/chat_speed/test_x8_equal_output_modulo_tlm.py --out "$HOME/r41_x8_equal_output_proof_v7_${mode}_20261101"
