    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #2048
    s.movz       s5, #16
    s.movz       s6, #1
    s.rdspecial  s6, role_id
    s.rdspecial  s7, npid.x
    s.ld.d       s8, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    s.mul        s1, s6, s4
    s.addi       s9, s2, #0
    .li       s10, #4286578688
    v.splat      v0, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    .li       s10, #2147483647
    v.splat      v2, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s10, s9, s1
    v.movi       v3, #0
    v.movi       v4, #-1
    v.movi       v5, #0
    s.shli       s1, s10, #1                     // element offset -> bytes (x2)
    v.iota       v6                              // arange(0, VLEN)
    v.mov        v1, v0
    v.mov        v3, v2
    v.cmp.ne     p1, v4, v5
    s.add        s10, s3, s1                     // &in_ptr0[...]
for_1:
    v.ld.h       v0, [s10, #0]
    v.splat      v2, s9
    vf.cmp.ne    p2, v1, v1
    v.add        v4, v2, v6
    v.cmp.lt     p3, v3, v4
    vf.cvt.f16.f32 v2, v0
    vf.cmp.ne    p4, v2, v2
    p.xor        p5, p4, p1
    p.and        p6, p2, p4
    vf.cmp.eq    p4, v1, v2
    p.and        p7, p2, p5
    p.or         p2, p4, p6
    vf.cmp.gt    p4, v1, v2
    p.or         p5, p4, p7
    p.and        p4, p2, p3
    p.or         p2, p5, p4
    @p2 v.sel        v1, v1, v2
    @p2 v.sel        v3, v3, v4
    s.addi       s10, s10, #32                   // the next iteration's address
    s.add        s9, s9, s5
    s.cmp.lt     s1, s9, s4
    br.nz        s1, for_1
endfor_2:
    v.extract    s1, v1, #0
    v.splat      v0, s1
    v.extract    s1, v1, #1
    v.splat      v2, s1
    v.extract    s1, v1, #2
    v.splat      v4, s1
    v.extract    s1, v1, #3
    v.splat      v5, s1
    v.extract    s1, v1, #4
    v.splat      v6, s1
    v.extract    s1, v1, #5
    v.splat      v7, s1
    v.extract    s1, v1, #6
    v.splat      v8, s1
    v.extract    s1, v1, #7
    v.splat      v9, s1
    v.extract    s1, v1, #8
    v.splat      v10, s1
    v.extract    s1, v1, #9
    v.splat      v11, s1
    v.extract    s1, v1, #10
    v.splat      v12, s1
    v.extract    s1, v1, #11
    v.splat      v13, s1
    v.extract    s1, v1, #12
    v.splat      v14, s1
    v.extract    s1, v1, #13
    v.splat      v15, s1
    v.extract    s1, v1, #14
    v.splat      v16, s1
    v.extract    s1, v1, #15
    v.splat      v1, s1
    v.extract    s1, v3, #0
    v.splat      v17, s1
    v.extract    s1, v3, #1
    v.splat      v18, s1
    v.extract    s1, v3, #2
    v.splat      v19, s1
    v.extract    s1, v3, #3
    v.splat      v20, s1
    v.extract    s1, v3, #4
    v.splat      v21, s1
    v.extract    s1, v3, #5
    v.splat      v22, s1
    v.extract    s1, v3, #6
    v.splat      v23, s1
    v.extract    s1, v3, #7
    v.splat      v24, s1
    v.extract    s1, v3, #8
    v.splat      v25, s1
    v.extract    s1, v3, #9
    v.splat      v26, s1
    v.extract    s1, v3, #10
    v.splat      v27, s1
    v.extract    s1, v3, #11
    v.splat      v28, s1
    v.extract    s1, v3, #12
    v.splat      v29, s1
    v.extract    s1, v3, #13
    v.splat      v30, s1
    v.extract    s1, v3, #14
    v.splat      v31, s1
    v.extract    s1, v3, #15
    v.splat      v3, s1
    vf.cmp.gt    p1, v0, v2
    vf.cmp.eq    p2, v0, v2
    vf.cmp.ne    p3, v0, v0
    vf.cmp.ne    p4, v2, v2
    .li       s1, #-1
    v.splat      v32, s1
    v.movi       v33, #0
    v.cmp.ne     p5, v32, v33
    p.xor        p6, p4, p5
    p.and        p7, p3, p6
    p.or         p6, p1, p7
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v17, v18
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v32, v0, v2
    @p1 v.sel        v0, v17, v18
    vf.cmp.gt    p1, v32, v4
    vf.cmp.eq    p2, v32, v4
    vf.cmp.ne    p3, v32, v32
    vf.cmp.ne    p4, v4, v4
    p.xor        p6, p4, p5
    p.and        p7, p3, p6
    p.or         p6, p1, p7
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v0, v19
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v2, v32, v4
    @p1 v.sel        v4, v0, v19
    vf.cmp.gt    p1, v2, v5
    vf.cmp.eq    p2, v2, v5
    vf.cmp.ne    p3, v2, v2
    vf.cmp.ne    p4, v5, v5
    p.xor        p6, p4, p5
    p.and        p7, p3, p6
    p.or         p6, p1, p7
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v4, v20
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v0, v2, v5
    @p1 v.sel        v2, v4, v20
    vf.cmp.gt    p1, v0, v6
    vf.cmp.eq    p2, v0, v6
    vf.cmp.ne    p3, v0, v0
    vf.cmp.ne    p4, v6, v6
    p.xor        p6, p4, p5
    p.and        p7, p3, p6
    p.or         p6, p1, p7
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v2, v21
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v4, v0, v6
    @p1 v.sel        v0, v2, v21
    vf.cmp.gt    p1, v4, v7
    vf.cmp.eq    p2, v4, v7
    vf.cmp.ne    p3, v4, v4
    vf.cmp.ne    p4, v7, v7
    p.xor        p6, p4, p5
    p.and        p7, p3, p6
    p.or         p6, p1, p7
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v0, v22
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v2, v4, v7
    @p1 v.sel        v4, v0, v22
    vf.cmp.gt    p1, v2, v8
    vf.cmp.eq    p2, v2, v8
    vf.cmp.ne    p3, v2, v2
    vf.cmp.ne    p4, v8, v8
    p.xor        p6, p4, p5
    p.and        p7, p3, p6
    p.or         p6, p1, p7
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v4, v23
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v0, v2, v8
    @p1 v.sel        v2, v4, v23
    vf.cmp.gt    p1, v0, v9
    vf.cmp.eq    p2, v0, v9
    vf.cmp.ne    p3, v0, v0
    vf.cmp.ne    p4, v9, v9
    p.xor        p6, p4, p5
    p.and        p7, p3, p6
    p.or         p6, p1, p7
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v2, v24
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v4, v0, v9
    @p1 v.sel        v0, v2, v24
    vf.cmp.gt    p1, v4, v10
    vf.cmp.eq    p2, v4, v10
    vf.cmp.ne    p3, v4, v4
    vf.cmp.ne    p4, v10, v10
    p.xor        p6, p4, p5
    p.and        p7, p3, p6
    p.or         p6, p1, p7
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v0, v25
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v2, v4, v10
    @p1 v.sel        v4, v0, v25
    vf.cmp.gt    p1, v2, v11
    vf.cmp.eq    p2, v2, v11
    vf.cmp.ne    p3, v2, v2
    vf.cmp.ne    p4, v11, v11
    p.xor        p6, p4, p5
    p.and        p7, p3, p6
    p.or         p6, p1, p7
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v4, v26
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v0, v2, v11
    @p1 v.sel        v2, v4, v26
    vf.cmp.gt    p1, v0, v12
    vf.cmp.eq    p2, v0, v12
    vf.cmp.ne    p3, v0, v0
    vf.cmp.ne    p4, v12, v12
    p.xor        p6, p4, p5
    p.and        p7, p3, p6
    p.or         p6, p1, p7
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v2, v27
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v4, v0, v12
    @p1 v.sel        v0, v2, v27
    vf.cmp.gt    p1, v4, v13
    vf.cmp.eq    p2, v4, v13
    vf.cmp.ne    p3, v4, v4
    vf.cmp.ne    p4, v13, v13
    p.xor        p6, p4, p5
    p.and        p7, p3, p6
    p.or         p6, p1, p7
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v0, v28
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v2, v4, v13
    @p1 v.sel        v4, v0, v28
    vf.cmp.gt    p1, v2, v14
    vf.cmp.eq    p2, v2, v14
    vf.cmp.ne    p3, v2, v2
    vf.cmp.ne    p4, v14, v14
    p.xor        p6, p4, p5
    p.and        p7, p3, p6
    p.or         p6, p1, p7
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v4, v29
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v0, v2, v14
    @p1 v.sel        v2, v4, v29
    vf.cmp.gt    p1, v0, v15
    vf.cmp.eq    p2, v0, v15
    vf.cmp.ne    p3, v0, v0
    vf.cmp.ne    p4, v15, v15
    p.xor        p6, p4, p5
    p.and        p7, p3, p6
    p.or         p6, p1, p7
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v2, v30
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v4, v0, v15
    @p1 v.sel        v0, v2, v30
    vf.cmp.gt    p1, v4, v16
    vf.cmp.eq    p2, v4, v16
    vf.cmp.ne    p3, v4, v4
    vf.cmp.ne    p4, v16, v16
    p.xor        p6, p4, p5
    p.and        p7, p3, p6
    p.or         p6, p1, p7
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v0, v31
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v2, v4, v16
    @p1 v.sel        v4, v0, v31
    vf.cmp.gt    p1, v2, v1
    vf.cmp.eq    p2, v2, v1
    vf.cmp.ne    p3, v2, v2
    vf.cmp.ne    p4, v1, v1
    p.xor        p6, p4, p5
    p.and        p5, p3, p6
    p.or         p6, p1, p5
    p.and        p1, p3, p4
    p.or         p3, p2, p1
    v.cmp.lt     p1, v4, v3
    p.and        p2, p3, p1
    p.or         p1, p6, p2
    @p1 v.sel        v0, v2, v1
    @p1 v.sel        v0, v4, v3
    v.movi       v1, #0
    v.movi       v2, #0
    v.extract    s1, v0, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v2, s9, #0
    s.shli       s1, s6, #3                      // element offset -> bytes (x8)
    s.add        s9, s8, s1                      // &out_ptr0[...]
    v.iota       v0                              // arange(0, VLEN)
    s.movz       s1, #1
    v.splat      v3, s1
    v.cmp.lt     p1, v0, v3
    v.movi       v0, #1
    v.shl        v3, v33, v0
    @p1 v.st.scatter.w [s9, v3], v1
    s.addi       s1, s9, #4
    @p1 v.st.scatter.w [s1, v3], v2
__rctx_next:
    s.addi       s1, s6, #4                      // the next program of this context: + 4
    s.cmp.lt     s9, s1, s7
    s.mov        s6, s1
    br.nz        s9, __rctx_program
    exit
