    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    s.rdspecial  s3, pid.y
    s.rdspecial  s4, arg_base
    s.mul        s5, s3, s1
    s.ld.d       s1, [s4, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v1, s2
    v.movi       v2, #0
    s.rdspecial  s2, role_id
    v.add        v3, v1, v0
    s.movz       s3, #4160
    s.movz       s4, #0
    v.sub        v1, v2, v3
    s.mul        s6, s2, s3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #8
    s.rdspecial  s2, arg_base
    v.movi       v5, #7
    s.add        s3, s1, s6                      // this context's own scratch
    v.sub        v6, v2, v1
    s.addi       s1, s3, #0
    s.addi       s6, s3, #1024
    s.addi       s7, s1, #64
    s.addi       s8, s1, #128
    s.addi       s9, s1, #192
    s.addi       s10, s1, #256
    s.addi       s11, s1, #320
    s.addi       s12, s1, #384
    s.addi       s13, s1, #448
    s.addi       s14, s1, #512
    s.addi       s15, s1, #576
    s.addi       s16, s1, #640
    s.addi       s17, s1, #704
    s.addi       s18, s1, #768
    s.addi       s19, s1, #832
    s.addi       s20, s1, #896
    s.addi       s21, s1, #960
    v.cmp.lt     p2, v1, v2
    s.ld.d       s22, [s2, #0]                   // arg_X: device_ptr64 at arg_base+0
    v.and        v7, v4, v5
    s.movz       s23, #256
    s.movz       s23, #36
    s.movz       s23, #9
    s.movz       s24, #1
    v.movi       v4, #1
    @p2 v.sel        v4, v6, v1
    s.ld.d       s25, [s2, #8]                   // arg_W: device_ptr64 at arg_base+8
    v.sub        v4, v2, v7
    s.ld.d       s26, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    v.movi       v2, #0
    v.movi       v5, #3
    v.movi       v6, #0
    v.sub        v8, v2, v3
    v.cmp.lt     p2, v3, v2
    v.movi       v9, #3
    @p2 v.sel        v10, v8, v3
    v.movi       v3, #0
    v.movi       v8, #256
    v.lshr       v11, v10, v5
    v.splat      v5, s5
    v.movi       v10, #7
    v.sub        v12, v2, v11
    v.add        v13, v5, v0
    v.cmp.lt     p3, v1, v2
    @p2 v.sel        v5, v12, v11
    v.splat      v11, s4
    v.sub        v12, v2, v1
    v.cmp.lt     p2, v5, v6
    @p1 v.sel        v2, v4, v7
    v.sub        v4, v6, v5
    v.cmp.lt     p1, v5, v3
    v.movi       v7, #1
    @p2 v.sel        v7, v4, v5
    @p3 v.sel        v4, v12, v1
    v.sub        v4, v3, v5
    v.lshr       v12, v7, v9
    v.sub        v7, v3, v1
    @p1 v.sel        v9, v4, v5
    v.sub        v4, v6, v12
    v.cmp.lt     p3, v1, v3
    v.and        v5, v9, v10
    @p2 v.sel        v9, v4, v12
    v.sub        v4, v6, v1
    v.sub        v10, v3, v5
    v.mul        v3, v9, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v6, #1
    v.extract    s2, v3, #0
    v.extract    s27, v3, #1
    v.extract    s28, v3, #2
    v.extract    s29, v3, #3
    v.extract    s30, v3, #4
    v.extract    s31, v3, #5
    v.splat      v6, s2
    v.extract    s2, v3, #6
    v.splat      v8, s27
    v.add        v12, v11, v6
    @p3 v.sel        v6, v7, v1
    v.extract    s27, v3, #7
    v.splat      v6, s28
    v.add        v7, v11, v8
    @p1 v.sel        v8, v10, v5
    v.splat      v5, s29
    v.add        v10, v11, v6
    v.movi       v6, #1
    v.extract    s28, v3, #8
    v.extract    s29, v3, #9
    v.add        v6, v11, v5
    @p2 v.sel        v5, v4, v1
    v.splat      v4, s30
    v.extract    s30, v3, #10
    v.st.w       [s1, #0], v12
    v.extract    s1, v3, #11
    v.splat      v5, s31
    v.extract    s31, v3, #12
    v.add        v12, v11, v4
    v.add        v4, v11, v5
    v.st.w       [s7, #0], v7
    v.extract    s7, v3, #13
    v.splat      v5, s2
    v.extract    s2, v3, #14
    v.add        v7, v11, v5
    v.st.w       [s8, #0], v10
    v.extract    s8, v3, #15
    v.splat      v3, s27
    v.splat      v5, s28
    v.add        v10, v11, v3
    v.add        v3, v11, v5
    v.st.w       [s9, #0], v6
    v.movi       v5, #36
    v.mul        v6, v13, v5
    v.st.w       [s10, #0], v12
    v.splat      v5, s29
    v.add        v12, v11, v5
    v.st.w       [s11, #0], v4
    v.splat      v4, s30
    s.addi       s9, s4, #0
    v.add        v5, v11, v4
    v.st.w       [s12, #0], v7
    v.splat      v4, s1
    v.add        v7, v11, v4
    v.st.w       [s13, #0], v10
    v.splat      v4, s31
    v.add        v10, v11, v4
    v.st.w       [s14, #0], v3
    v.splat      v3, s7
    v.add        v4, v11, v3
    v.st.w       [s15, #0], v12
    v.splat      v3, s2
    v.add        v12, v11, v3
    v.st.w       [s16, #0], v5
    v.splat      v3, s8
    v.add        v5, v11, v3
    v.splat      v3, s4
    v.add        v11, v3, v6
    v.st.w       [s17, #0], v7
    v.st.w       [s18, #0], v10
    v.st.w       [s19, #0], v4
    v.st.w       [s20, #0], v12
    v.st.w       [s21, #0], v5
    fence.acq_rel.device
    v.st.w       [s6, #0], v11
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_1:
    s.cmp.ge     s1, s9, s23
    br.nz        s1, endfor_2
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s6, s9, s1
    s.movz       s1, #0
    s.sub        s7, s2, s6
    .li       s2, #1431655766
    s.xor        s6, s9, s7
    s.movz       s8, #0
    s.sub        s10, s6, s7
    s.cmp.lt     s6, s9, s1
    s.mul        s1, s10, s2
    s.sub        s2, s8, s6
    .li       s6, #1431655766
    s.xor        s8, s9, s2
    s.movz       s11, #3
    s.sub        s12, s8, s2
    s.lshri      s8, s1, #32
    s.mul        s1, s12, s6
    s.sub        s6, s10, s8
    s.movz       s13, #0
    s.lshri      s14, s6, #1
    s.movz       s6, #0
    s.add        s15, s8, s14
    s.lshri      s8, s1, #32
    s.lshri      s1, s15, #1
    s.sub        s14, s12, s8
    s.muli       s15, s1, #3
    s.cmp.lt     s1, s11, s13
    s.lshri      s13, s14, #1
    s.sub        s14, s6, s1
    s.add        s1, s8, s13
    s.xor        s6, s2, s14
    s.lshri      s2, s1, #1
    s.sub        s1, s10, s15
    s.xor        s8, s2, s6
    s.xor        s10, s1, s7
    s.sub        s1, s8, s6
    s.sub        s6, s10, s7
    s.sub        s7, s1, s24
    s.sub        s8, s6, s24
    v.splat      v3, s7
    v.splat      v4, s8
    v.movi       v5, #32
    v.add        v6, v3, v8
    v.add        v3, v4, v2
    v.movi       v4, #4
    v.mul        v7, v6, v5
    s.movz       s7, #4
    s.movz       s8, #0
    s.movz       s10, #0
    s.cmp.lt     s13, s11, s8
    s.muli       s8, s2, #3
    s.sub        s2, s10, s13
    s.xor        s10, s11, s14
    v.mul        v5, v3, v4
    s.xor        s13, s11, s2
    s.sub        s15, s10, s14
    s.addi       s10, s3, #0
    v.extract    s14, v7, #0
    v.ld.w       v10, [s10, #0]
    v.extract    s10, v5, #0
    v.splat      v11, s14
    v.splat      v12, s10
    v.iota       v14                             // arange(0, VLEN)
    s.addi       s10, s3, #1088
    v.add        v15, v11, v12
    s.sub        s14, s12, s8
    s.addi       s8, s3, #64
    v.add        v11, v15, v14
    v.extract    s12, v7, #1
    v.extract    s14, v5, #1
    v.splat      v12, s12
    v.splat      v15, s14
    s.addi       s12, s10, #64
    s.addi       s14, s10, #128
    v.add        v16, v12, v15
    s.sub        s15, s13, s2
    v.add        v12, v10, v11
    v.add        v10, v16, v14
    s.addi       s2, s3, #128
    v.st.w       [s10, #0], v12
    v.extract    s13, v7, #2
    v.extract    s15, v5, #2
    v.splat      v11, s13
    v.splat      v12, s15
    s.addi       s13, s3, #192
    v.extract    s15, v7, #3
    v.add        v15, v11, v12
    v.splat      v11, s15
    v.extract    s15, v5, #3
    v.add        v12, v15, v14
    v.splat      v15, s15
    s.addi       s15, s10, #192
    s.movz       s16, #32
    v.add        v16, v11, v15
    v.add        v11, v16, v14
    v.ld.w       v15, [s8, #0]
    s.addi       s8, s3, #256
    v.add        v16, v15, v10
    v.st.w       [s12, #0], v16
    v.extract    s12, v7, #4
    v.splat      v10, s12
    v.extract    s12, v5, #4
    v.splat      v15, s12
    s.addi       s12, s10, #256
    v.add        v16, v10, v15
    v.add        v10, v16, v14
    v.ld.w       v15, [s2, #0]
    s.addi       s2, s3, #320
    v.add        v16, v15, v12
    v.st.w       [s14, #0], v16
    v.extract    s14, v7, #5
    v.splat      v12, s14
    v.extract    s14, v5, #5
    v.splat      v15, s14
    s.addi       s14, s10, #320
    v.add        v16, v12, v15
    v.add        v12, v16, v14
    v.ld.w       v15, [s13, #0]
    s.addi       s13, s3, #384
    v.add        v16, v15, v11
    v.st.w       [s15, #0], v16
    v.extract    s15, v7, #6
    v.splat      v11, s15
    v.extract    s15, v5, #6
    v.splat      v15, s15
    s.addi       s15, s10, #384
    v.add        v16, v11, v15
    v.add        v11, v16, v14
    v.ld.w       v15, [s8, #0]
    s.addi       s8, s3, #448
    v.add        v16, v15, v10
    v.st.w       [s12, #0], v16
    v.extract    s12, v7, #7
    v.splat      v10, s12
    v.extract    s12, v5, #7
    v.splat      v15, s12
    s.addi       s12, s10, #448
    v.add        v16, v10, v15
    v.add        v10, v16, v14
    v.ld.w       v15, [s2, #0]
    s.addi       s2, s3, #512
    v.add        v16, v15, v12
    v.st.w       [s14, #0], v16
    v.extract    s14, v7, #8
    v.splat      v12, s14
    v.extract    s14, v5, #8
    v.splat      v15, s14
    s.addi       s14, s10, #512
    v.add        v16, v12, v15
    v.add        v12, v16, v14
    v.ld.w       v15, [s13, #0]
    s.addi       s13, s3, #576
    v.add        v16, v15, v11
    v.st.w       [s15, #0], v16
    v.extract    s15, v7, #9
    v.splat      v11, s15
    v.extract    s15, v5, #9
    v.splat      v15, s15
    s.addi       s15, s10, #576
    v.add        v16, v11, v15
    v.add        v11, v16, v14
    v.ld.w       v15, [s8, #0]
    s.addi       s8, s3, #640
    v.add        v16, v15, v10
    v.st.w       [s12, #0], v16
    v.extract    s12, v7, #10
    v.splat      v10, s12
    v.extract    s12, v5, #10
    v.splat      v15, s12
    s.addi       s12, s10, #640
    v.add        v16, v10, v15
    v.add        v10, v16, v14
    v.ld.w       v15, [s2, #0]
    s.addi       s2, s3, #704
    v.add        v16, v15, v12
    v.st.w       [s14, #0], v16
    v.extract    s14, v7, #11
    v.splat      v12, s14
    v.extract    s14, v5, #11
    v.splat      v15, s14
    s.addi       s14, s10, #704
    v.add        v16, v12, v15
    v.add        v12, v16, v14
    v.ld.w       v15, [s13, #0]
    s.addi       s13, s3, #768
    v.add        v16, v15, v11
    v.st.w       [s15, #0], v16
    v.extract    s15, v7, #12
    v.splat      v11, s15
    v.extract    s15, v5, #12
    v.splat      v15, s15
    s.addi       s15, s10, #768
    v.add        v16, v11, v15
    v.add        v11, v16, v14
    v.ld.w       v15, [s8, #0]
    s.addi       s8, s3, #832
    v.add        v16, v15, v10
    v.st.w       [s12, #0], v16
    v.extract    s12, v7, #13
    v.splat      v10, s12
    v.extract    s12, v5, #13
    v.splat      v15, s12
    s.addi       s12, s10, #832
    v.add        v16, v10, v15
    v.add        v10, v16, v14
    v.ld.w       v15, [s2, #0]
    s.addi       s2, s3, #896
    v.movi       v16, #1
    v.add        v17, v15, v12
    v.cmp.lt     p1, v9, v16
    v.st.w       [s14, #0], v17
    v.extract    s14, v7, #14
    v.movi       v12, #1
    v.splat      v15, s14
    v.extract    s14, v5, #14
    v.movi       v16, #0
    v.splat      v17, s14
    s.addi       s14, s10, #896
    s.addi       s16, s10, #960
    v.add        v18, v15, v17
    @p1 v.sel        v15, v12, v16
    v.add        v12, v18, v14
    v.ld.w       v16, [s13, #0]
    s.addi       s10, s3, #960
    v.movi       v17, #0
    v.movi       v18, #1
    v.cmp.lt     p1, v6, v1
    v.cmp.ge     p2, v6, v17
    v.movi       v6, #0
    @p2 v.sel        v19, v18, v6
    v.movi       v6, #1
    v.add        v18, v16, v11
    v.movi       v11, #0
    v.st.w       [s15, #0], v18
    v.extract    s13, v7, #15
    v.movi       v7, #1
    v.splat      v16, s13
    v.extract    s13, v5, #15
    @p1 v.sel        v5, v6, v11
    v.splat      v6, s13
    v.cmp.ge     p1, v3, v17
    v.add        v11, v16, v6
    v.add        v6, v11, v14
    v.ld.w       v11, [s8, #0]
    v.movi       v16, #0
    v.movi       v17, #1
    v.cmp.lt     p2, v3, v1
    v.movi       v3, #0
    @p1 v.sel        v18, v7, v16
    v.cmp.lt     p1, v0, v4
    @p2 v.sel        v4, v17, v3
    v.add        v3, v11, v10
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s8, #0
    v.st.w       [s12, #0], v3
    s.addi       s12, s3, #1088
    v.extract    s13, v15, #0
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v19, #0
    v.splat      v7, s13
    v.movi       v10, #0
    v.splat      v11, s2
    v.movi       v16, #0
    v.cmp.ne     p2, v7, v10
    v.cmp.ne     p3, v11, v16
    v.add        v7, v3, v12
    p.and        p4, p2, p3
    v.st.w       [s14, #0], v7
    v.extract    s2, v5, #0
    v.movi       v3, #0
    v.splat      v7, s2
    v.ld.w       v10, [s10, #0]
    v.extract    s2, v18, #0
    v.movi       v11, #0
    v.splat      v12, s2
    v.cmp.ne     p2, v7, v3
    p.and        p3, p4, p2
    v.cmp.ne     p2, v12, v11
    p.and        p4, p3, p2
    v.add        v3, v10, v6
    v.extract    s2, v4, #0
    v.st.w       [s16, #0], v3
    fence.acq_rel.device
    v.splat      v3, s2
    v.movi       v6, #0
    s.addi       s2, s3, #1152
    v.extract    s10, v15, #1
    v.cmp.ne     p2, v3, v6
    p.and        p3, p4, p2
    v.extract    s13, v19, #1
    p.and        p2, p3, p1
    v.splat      v3, s10
    v.movi       v6, #0
    v.splat      v7, s13
    v.movi       v10, #0
    v.extract    s10, v5, #1
    v.movi       v11, #0
    v.splat      v12, s10
    v.extract    s10, v18, #1
    v.ld.w       v16, [s12, #0]
    v.cmp.ne     p3, v3, v6
    v.cmp.ne     p4, v7, v10
    p.and        p5, p3, p4
    v.splat      v3, s10
    v.movi       v6, #0
    v.extract    s10, v4, #1
    v.cmp.ne     p3, v12, v11
    p.and        p4, p5, p3
    v.splat      v7, s10
    v.movi       v10, #0
    v.cmp.ne     p3, v3, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v7, v10
    p.and        p4, p5, p3
    s.movz       s10, #1
    p.and        p3, p4, p1
    s.addi       s12, s3, #1216
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v3, [s22, v16]             // index is in elements (ISA sec 9.1)
    v.extract    s13, v15, #2
    v.extract    s14, v19, #2
    v.splat      v6, s13
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0
    v.extract    s13, v5, #2
    v.movi       v12, #0
    v.splat      v16, s13
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v11
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v12
    p.and        p4, p5, p2
    s.movz       s13, #2
    a.vwrite     a1, s8, v3
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v18, #2
    v.movi       v6, #0
    v.splat      v7, s2
    v.extract    s2, v4, #2
    v.movi       v10, #0
    v.splat      v11, s2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s2, s3, #1280
    p.and        p2, p4, p1
    v.extract    s8, v15, #3
    v.extract    s14, v19, #3
    v.splat      v6, s8
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s22, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s8, v5, #3
    v.movi       v12, #0
    v.splat      v16, s8
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v12
    p.and        p4, p5, p3
    s.movz       s8, #3
    a.vwrite     a1, s10, v11
    v.ld.w       v3, [s12, #0]
    v.extract    s10, v18, #3
    v.movi       v6, #0
    v.splat      v7, s10
    v.extract    s10, v4, #3
    v.movi       v10, #0
    v.splat      v11, s10
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s10, s3, #1344
    p.and        p3, p4, p1
    v.extract    s12, v15, #4
    v.extract    s14, v19, #4
    v.splat      v6, s12
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s22, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s12, v5, #4
    v.movi       v12, #0
    v.splat      v16, s12
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v12
    p.and        p4, p5, p2
    s.movz       s12, #4
    a.vwrite     a1, s13, v11
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v18, #4
    v.movi       v6, #0
    v.splat      v7, s2
    v.extract    s2, v4, #4
    v.movi       v10, #0
    v.splat      v11, s2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s2, s3, #1408
    p.and        p2, p4, p1
    v.extract    s13, v15, #5
    v.extract    s14, v19, #5
    v.splat      v6, s13
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s22, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s13, v5, #5
    v.movi       v12, #0
    v.splat      v16, s13
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v12
    p.and        p4, p5, p3
    s.movz       s13, #5
    a.vwrite     a1, s8, v11
    v.ld.w       v3, [s10, #0]
    v.extract    s8, v18, #5
    v.movi       v6, #0
    v.splat      v7, s8
    v.extract    s8, v4, #5
    v.movi       v10, #0
    v.splat      v11, s8
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s8, s3, #1472
    p.and        p3, p4, p1
    v.extract    s10, v15, #6
    v.extract    s14, v19, #6
    v.splat      v6, s10
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s22, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s10, v5, #6
    v.movi       v12, #0
    v.splat      v16, s10
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v12
    p.and        p4, p5, p2
    s.movz       s10, #6
    a.vwrite     a1, s12, v11
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v18, #6
    v.movi       v6, #0
    v.splat      v7, s2
    v.extract    s2, v4, #6
    v.movi       v10, #0
    v.splat      v11, s2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s2, s3, #1536
    p.and        p2, p4, p1
    v.extract    s12, v15, #7
    v.extract    s14, v19, #7
    v.splat      v6, s12
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s22, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s12, v5, #7
    v.movi       v12, #0
    v.splat      v16, s12
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v12
    p.and        p4, p5, p3
    s.movz       s12, #7
    a.vwrite     a1, s13, v11
    v.ld.w       v3, [s8, #0]
    v.extract    s8, v18, #7
    v.movi       v6, #0
    v.splat      v7, s8
    v.extract    s8, v4, #7
    v.movi       v10, #0
    v.splat      v11, s8
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s8, s3, #1600
    p.and        p3, p4, p1
    v.extract    s13, v15, #8
    v.extract    s14, v19, #8
    v.splat      v6, s13
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s22, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s13, v5, #8
    v.movi       v12, #0
    v.splat      v16, s13
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v12
    p.and        p4, p5, p2
    s.movz       s13, #8
    a.vwrite     a1, s10, v11
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v18, #8
    v.movi       v6, #0
    v.splat      v7, s2
    v.extract    s2, v4, #8
    v.movi       v10, #0
    v.splat      v11, s2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s2, s3, #1664
    p.and        p2, p4, p1
    v.extract    s10, v15, #9
    v.extract    s14, v19, #9
    v.splat      v6, s10
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s22, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s10, v5, #9
    v.movi       v12, #0
    v.splat      v16, s10
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v12
    p.and        p4, p5, p3
    s.movz       s10, #9
    a.vwrite     a1, s12, v11
    v.ld.w       v3, [s8, #0]
    v.extract    s8, v18, #9
    v.movi       v6, #0
    v.splat      v7, s8
    v.extract    s8, v4, #9
    v.movi       v10, #0
    v.splat      v11, s8
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s8, s3, #1728
    p.and        p3, p4, p1
    v.extract    s12, v15, #10
    v.extract    s14, v19, #10
    v.splat      v6, s12
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s22, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s12, v5, #10
    v.movi       v12, #0
    v.splat      v16, s12
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v12
    p.and        p4, p5, p2
    s.movz       s12, #10
    a.vwrite     a1, s13, v11
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v18, #10
    v.movi       v6, #0
    v.splat      v7, s2
    v.extract    s2, v4, #10
    v.movi       v10, #0
    v.splat      v11, s2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s2, s3, #1792
    p.and        p2, p4, p1
    v.extract    s13, v15, #11
    v.extract    s14, v19, #11
    v.splat      v6, s13
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s22, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s13, v5, #11
    v.movi       v12, #0
    v.splat      v16, s13
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v12
    p.and        p4, p5, p3
    s.movz       s13, #11
    a.vwrite     a1, s10, v11
    v.ld.w       v3, [s8, #0]
    v.extract    s8, v18, #11
    v.movi       v6, #0
    v.splat      v7, s8
    v.extract    s8, v4, #11
    v.movi       v10, #0
    v.splat      v11, s8
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s8, s3, #1856
    p.and        p3, p4, p1
    v.extract    s10, v15, #12
    v.extract    s14, v19, #12
    v.splat      v6, s10
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s22, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s10, v5, #12
    v.movi       v12, #0
    v.splat      v16, s10
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v12
    p.and        p4, p5, p2
    s.movz       s10, #12
    a.vwrite     a1, s12, v11
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v18, #12
    v.movi       v6, #0
    v.splat      v7, s2
    v.extract    s2, v4, #12
    v.movi       v10, #0
    v.splat      v11, s2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s2, s3, #1920
    p.and        p2, p4, p1
    v.extract    s12, v15, #13
    v.extract    s14, v19, #13
    v.splat      v6, s12
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s22, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s12, v5, #13
    v.movi       v12, #0
    v.splat      v16, s12
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v12
    p.and        p4, p5, p3
    s.movz       s12, #13
    a.vwrite     a1, s13, v11
    v.ld.w       v3, [s8, #0]
    v.extract    s8, v18, #13
    v.movi       v6, #0
    v.splat      v7, s8
    v.extract    s8, v4, #13
    v.movi       v10, #0
    v.splat      v11, s8
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s8, s3, #1984
    p.and        p3, p4, p1
    v.extract    s13, v15, #14
    v.extract    s14, v19, #14
    v.splat      v6, s13
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s22, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s13, v5, #14
    v.movi       v12, #0
    v.splat      v16, s13
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v12
    p.and        p4, p5, p2
    s.movz       s13, #14
    a.vwrite     a1, s10, v11
    v.ld.w       v3, [s2, #0]
    v.extract    s2, v18, #14
    v.movi       v6, #0
    v.splat      v7, s2
    v.extract    s2, v4, #14
    v.movi       v10, #0
    v.splat      v11, s2
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s2, s3, #2048
    p.and        p2, p4, p1
    v.extract    s10, v15, #15
    v.extract    s14, v19, #15
    v.splat      v6, s10
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s22, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s10, v5, #15
    v.movi       v5, #0
    v.splat      v12, s10
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v12, v5
    p.and        p4, p5, p3
    s.movz       s10, #15
    a.vwrite     a1, s12, v11
    v.ld.w       v3, [s8, #0]
    v.extract    s8, v18, #15
    v.movi       v5, #0
    v.splat      v6, s8
    v.extract    s8, v4, #15
    v.movi       v4, #0
    v.splat      v7, s8
    v.cmp.ne     p3, v6, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v7, v4
    p.and        p4, p5, p3
    s.addi       s8, s3, #1024
    p.and        p3, p4, p1
    s.movz       s12, #12
    s.mul        s14, s6, s7
    s.mul        s6, s1, s12
    s.movz       s1, #0
    s.addi       s15, s3, #2112
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s22, v3]              // index is in elements (ISA sec 9.1)
    s.add        s16, s1, s6                     // the tile origin
    s.addi       s1, s3, #1024
    s.add        s6, s16, s14                    // the tile origin
    s.addi       s14, s15, #64
    v.splat      v3, s6
    a.vwrite     a1, s13, v4
    v.ld.w       v4, [s2, #0]
    s.addi       s2, s6, #1
    s.addi       s13, s3, #1024
    v.splat      v5, s2
    s.addi       s2, s6, #2
    v.splat      v6, s2
    s.addi       s2, s15, #128
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s22, v4]              // index is in elements (ISA sec 9.1)
    s.addi       s16, s3, #1024
    a.vwrite     a1, s10, v7
    v.ld.w       v4, [s8, #0]
    s.addi       s8, s6, #3
    s.addi       s10, s15, #192
    v.splat      v7, s8
    s.addi       s8, s3, #1024
    v.add        v10, v4, v3
    v.st.w       [s15, #0], v10
    v.ld.w       v3, [s1, #0]
    s.addi       s1, s6, #4
    v.splat      v4, s1
    s.addi       s1, s15, #256
    v.add        v10, v3, v5
    v.st.w       [s14, #0], v10
    s.addi       s14, s3, #1024
    v.ld.w       v3, [s13, #0]
    s.addi       s13, s6, #5
    v.splat      v5, s13
    s.addi       s13, s15, #320
    v.add        v10, v3, v6
    v.st.w       [s2, #0], v10
    s.addi       s2, s3, #1024
    v.ld.w       v3, [s16, #0]
    s.addi       s16, s6, #6
    v.splat      v6, s16
    s.addi       s16, s15, #384
    v.add        v10, v3, v7
    v.st.w       [s10, #0], v10
    s.addi       s10, s3, #1024
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s6, #7
    v.splat      v7, s8
    s.addi       s8, s15, #448
    v.add        v10, v3, v4
    v.st.w       [s1, #0], v10
    s.addi       s1, s3, #1024
    v.ld.w       v3, [s14, #0]
    s.addi       s14, s6, #8
    v.splat      v4, s14
    s.addi       s14, s15, #512
    v.add        v10, v3, v5
    v.st.w       [s13, #0], v10
    s.addi       s13, s3, #1024
    v.ld.w       v3, [s2, #0]
    s.addi       s2, s6, #9
    v.splat      v5, s2
    s.addi       s2, s15, #576
    v.add        v10, v3, v6
    v.st.w       [s16, #0], v10
    s.addi       s16, s3, #1024
    v.ld.w       v3, [s10, #0]
    s.addi       s10, s6, #10
    v.splat      v6, s10
    s.addi       s10, s15, #640
    v.add        v10, v3, v7
    v.st.w       [s8, #0], v10
    s.addi       s8, s3, #1024
    v.ld.w       v3, [s1, #0]
    s.addi       s1, s6, #11
    v.splat      v7, s1
    s.addi       s1, s15, #704
    v.add        v10, v3, v4
    v.st.w       [s14, #0], v10
    s.addi       s14, s3, #1024
    v.ld.w       v3, [s13, #0]
    s.addi       s13, s6, #12
    v.splat      v4, s13
    s.addi       s13, s15, #768
    v.add        v10, v3, v5
    v.splat      v3, s4
    v.st.w       [s2, #0], v10
    s.addi       s2, s3, #1024
    v.splat      v5, s7
    v.cmp.lt     p1, v3, v5
    v.ld.w       v3, [s16, #0]
    s.addi       s16, s6, #13
    v.splat      v10, s16
    s.addi       s16, s15, #832
    v.add        v11, v3, v6
    v.st.w       [s10, #0], v11
    s.addi       s10, s3, #1024
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s6, #14
    s.addi       s17, s6, #15
    v.splat      v6, s8
    s.addi       s6, s15, #896
    v.splat      v11, s17
    s.addi       s8, s3, #1024
    s.addi       s17, s15, #960
    v.add        v12, v3, v7
    v.st.w       [s1, #0], v12
    s.addi       s1, s3, #2112
    v.splat      v3, s24
    v.cmp.lt     p2, v3, v5
    v.ld.w       v3, [s14, #0]
    s.movz       s14, #0
    s.add        s15, s14, s5                    // the tile origin
    v.splat      v7, s15
    s.movz       s14, #8
    v.add        v12, v14, v7
    v.splat      v7, s14
    v.cmp.lt     p3, v12, v7
    p.and        p4, p1, p3
    p.and        p1, p2, p3
    v.add        v7, v3, v4
    v.st.w       [s13, #0], v7
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s13, #0
    v.ld.w       v3, [s2, #0]
    s.addi       s2, s3, #2176
    v.add        v4, v3, v10
    v.st.w       [s16, #0], v4
    s.movz       s15, #1
    v.ld.w       v3, [s10, #0]
    s.addi       s10, s3, #2240
    v.splat      v4, s11
    s.movz       s11, #2
    v.splat      v7, s11
    s.movz       s11, #2
    v.cmp.lt     p2, v4, v5
    v.add        v4, v3, v6
    p.and        p5, p2, p3
    v.st.w       [s6, #0], v4
    s.addi       s6, s3, #2304
    v.ld.w       v3, [s8, #0]
    s.movz       s8, #3
    v.splat      v4, s7
    s.addi       s7, s3, #2368
    v.add        v6, v3, v11
    v.st.w       [s17, #0], v6
    fence.acq_rel.device
    s.movz       s16, #4
    v.ld.w       v3, [s1, #0]
    s.addi       s1, s3, #2432
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v6, [s25, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v5
    p.and        p4, p2, p3
    a.vwrite     a2, s13, v6
    v.ld.w       v3, [s2, #0]
    s.movz       s2, #5
    s.movz       s13, #5
    v.splat      v6, s2
    s.addi       s2, s3, #2496
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s25, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v5
    p.and        p2, p1, p3
    a.vwrite     a2, s15, v7
    v.ld.w       v3, [s10, #0]
    s.movz       s10, #6
    s.movz       s15, #6
    v.splat      v4, s10
    s.addi       s10, s3, #2560
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v7, [s25, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v5
    p.and        p4, p1, p3
    v.splat      v3, s14
    s.movz       s14, #7
    v.splat      v6, s14
    s.movz       s14, #7
    a.vwrite     a2, s11, v7
    v.ld.w       v7, [s6, #0]
    s.addi       s6, s3, #2624
    s.movz       s11, #8
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v10, [s25, v7]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v5
    p.and        p5, p1, p3
    v.splat      v4, s23
    s.addi       s17, s3, #2688
    a.vwrite     a2, s8, v10
    v.ld.w       v7, [s7, #0]
    s.movz       s7, #9
    s.addi       s8, s3, #2752
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v10, [s25, v7]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v5
    p.and        p2, p1, p3
    a.vwrite     a2, s16, v10
    v.ld.w       v6, [s1, #0]
    s.movz       s1, #10
    s.movz       s16, #10
    v.splat      v7, s1
    s.addi       s1, s3, #2816
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v10, [s25, v6]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v5
    p.and        p4, p1, p3
    a.vwrite     a2, s13, v10
    v.ld.w       v3, [s2, #0]
    s.movz       s2, #11
    s.movz       s13, #11
    v.splat      v6, s2
    s.addi       s2, s3, #2880
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v10, [s25, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v5
    p.and        p5, p1, p3
    v.splat      v3, s12
    s.movz       s12, #12
    a.vwrite     a2, s15, v10
    v.ld.w       v4, [s10, #0]
    s.addi       s10, s3, #2944
    s.movz       s15, #13
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v10, [s25, v4]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v5
    p.and        p2, p1, p3
    v.splat      v4, s15
    s.movz       s15, #13
    a.vwrite     a2, s14, v10
    v.ld.w       v7, [s6, #0]
    s.addi       s6, s3, #3008
    s.movz       s14, #14
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v10, [s25, v7]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v5
    p.and        p4, p1, p3
    a.vwrite     a2, s11, v10
    v.ld.w       v6, [s17, #0]
    s.movz       s11, #14
    s.addi       s17, s3, #3072
    v.splat      v7, s11
    s.movz       s11, #15
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v10, [s25, v6]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v5
    p.and        p5, p1, p3
    a.vwrite     a2, s7, v10
    v.ld.w       v3, [s8, #0]
    s.movz       s7, #15
    v.movi       v6, #0
    v.splat      v10, s7
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s7, #0
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s25, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v5
    p.and        p2, p1, p3
    s.movz       s8, #0
    a.vwrite     a2, s16, v11
    v.ld.w       v3, [s1, #0]
    s.movz       s1, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s25, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v5
    p.and        p4, p1, p3
    s.movz       s16, #1
    a.vwrite     a2, s13, v4
    v.ld.w       v3, [s2, #0]
    s.movz       s2, #2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s25, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v10, v5
    p.and        p5, p1, p3
    a.vwrite     a2, s12, v4
    v.ld.w       v3, [s10, #0]
    s.movz       s10, #3
    s.movz       s12, #4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s25, v3]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v4
    v.ld.w       v3, [s6, #0]
    s.movz       s6, #5
    s.movz       s13, #6
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s25, v3]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v4
    v.ld.w       v3, [s17, #0]
    s.movz       s14, #7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s25, v3]              // index is in elements (ISA sec 9.1)
    s.movz       s15, #8
    a.vwrite     a2, s11, v4
    a.vread      v3, a1, s8
    a.vread      v4, a2, s1
    a.vread      v5, a2, s16
    v.extract    s1, v3, #0
    v.extract    s8, v3, #1
    v.splat      v7, s1
    v.splat      v10, s8
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s2
    v.extract    s1, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s12
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s6
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #1
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s8, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #1
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s7, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s8
    v.extract    s1, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s13
    v.extract    s1, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #2
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s7, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s8, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s15, #2
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s7
    v.extract    s1, v3, #3
    a.vread      v12, a2, s8
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s11
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s12
    v.extract    s1, v3, #7
    a.vread      v15, a2, s13
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s14
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #3
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s7, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s8, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s16, #3
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s15, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s7
    v.extract    s1, v3, #3
    a.vread      v12, a2, s8
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s11
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s12
    v.extract    s1, v3, #7
    a.vread      v15, a2, s13
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s14
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #4
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s7, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s8, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s15, #4
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s7
    v.extract    s1, v3, #3
    a.vread      v12, a2, s8
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s11
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s12
    v.extract    s1, v3, #7
    a.vread      v15, a2, s13
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s14
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #5
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s7, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s8, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s16, #5
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s15, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s7
    v.extract    s1, v3, #3
    a.vread      v12, a2, s8
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s11
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s12
    v.extract    s1, v3, #7
    a.vread      v15, a2, s13
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s14
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #6
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s7, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s8, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s15, #6
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s7
    v.extract    s1, v3, #3
    a.vread      v12, a2, s8
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s11
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s12
    v.extract    s1, v3, #7
    a.vread      v15, a2, s13
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s14
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #7
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s7, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s8, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s16, #7
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s15, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s7
    v.extract    s1, v3, #3
    a.vread      v12, a2, s8
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s11
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s12
    v.extract    s1, v3, #7
    a.vread      v15, a2, s13
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s14
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #8
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s7, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s8, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s15, #8
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s7
    v.extract    s1, v3, #3
    a.vread      v12, a2, s8
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s11
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s12
    v.extract    s1, v3, #7
    a.vread      v15, a2, s13
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s14
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #9
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s7, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s8, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s16, #9
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s15, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s7
    v.extract    s1, v3, #3
    a.vread      v12, a2, s8
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s11
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s12
    v.extract    s1, v3, #7
    a.vread      v15, a2, s13
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s14
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #10
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s7, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s8, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s15, #10
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s7
    v.extract    s1, v3, #3
    a.vread      v12, a2, s8
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s11
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s12
    v.extract    s1, v3, #7
    a.vread      v15, a2, s13
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s14
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #11
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s7, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s8, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s16, #11
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s15, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s7
    v.extract    s1, v3, #3
    a.vread      v12, a2, s8
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s11
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s12
    v.extract    s1, v3, #7
    a.vread      v15, a2, s13
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s14
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #12
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s7, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s8, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s15, #12
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s7
    v.extract    s1, v3, #3
    a.vread      v12, a2, s8
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s11
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s12
    v.extract    s1, v3, #7
    a.vread      v15, a2, s13
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s14
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #13
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s7, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s8, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s16, #13
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s15, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s7
    v.extract    s1, v3, #3
    a.vread      v12, a2, s8
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s11
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s12
    v.extract    s1, v3, #7
    a.vread      v15, a2, s13
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s14
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #14
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s7, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s8, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s15, #14
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v7, a2, s7
    v.extract    s1, v3, #3
    a.vread      v12, a2, s8
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s1
    vf.fma       v15, v4, v7, v14
    v.extract    s1, v3, #5
    a.vread      v4, a2, s11
    v.splat      v7, s1
    v.extract    s1, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s1
    a.vread      v12, a2, s12
    v.extract    s1, v3, #7
    a.vread      v15, a2, s13
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s14
    v.splat      v14, s1
    vf.fma       v17, v7, v4, v16
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v15, a2, s2
    vf.fma       v16, v14, v11, v17
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v14, a2, s2
    vf.fma       v17, v4, v7, v16
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v5, v12, v17
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v12, a2, s2
    vf.fma       v17, v10, v15, v16
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v15, v11, v14, v17
    s.movz       s1, #15
    s.movz       s2, #0
    s.movz       s6, #1
    s.movz       s7, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s8, #3
    s.movz       s10, #4
    s.movz       s11, #5
    s.movz       s12, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s13, #7
    s.movz       s14, #8
    s.movz       s16, #15
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s15, v5
    a.vread      v3, a1, s1
    a.vread      v4, a2, s2
    a.vread      v5, a2, s6
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v7, s1
    v.splat      v10, s2
    v.extract    s1, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s1
    a.vread      v6, a2, s7
    v.extract    s1, v3, #3
    a.vread      v7, a2, s8
    vf.fma       v12, v10, v5, v11
    v.splat      v5, s1
    v.extract    s1, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s1
    vf.fma       v14, v4, v6, v12
    v.extract    s1, v3, #5
    a.vread      v4, a2, s11
    v.splat      v6, s1
    v.extract    s1, v3, #6
    vf.fma       v12, v5, v7, v14
    v.splat      v5, s1
    a.vread      v7, a2, s12
    v.extract    s1, v3, #7
    a.vread      v14, a2, s13
    vf.fma       v15, v11, v10, v12
    v.splat      v10, s1
    v.extract    s1, v3, #8
    a.vread      v11, a2, s14
    v.splat      v12, s1
    vf.fma       v16, v6, v4, v15
    v.extract    s1, v3, #9
    s.movz       s2, #9
    v.splat      v4, s1
    a.vread      v6, a2, s2
    vf.fma       v15, v5, v7, v16
    v.extract    s1, v3, #10
    s.movz       s2, #10
    v.splat      v5, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v10, v14, v15
    v.extract    s1, v3, #11
    s.movz       s2, #11
    v.splat      v10, s1
    a.vread      v14, a2, s2
    vf.fma       v15, v12, v11, v16
    v.extract    s1, v3, #12
    s.movz       s2, #12
    v.splat      v11, s1
    a.vread      v12, a2, s2
    vf.fma       v16, v4, v6, v15
    v.extract    s1, v3, #13
    s.movz       s2, #13
    v.splat      v4, s1
    a.vread      v6, a2, s2
    vf.fma       v15, v5, v7, v16
    v.extract    s1, v3, #14
    s.movz       s2, #14
    v.splat      v5, s1
    a.vread      v7, a2, s2
    vf.fma       v16, v10, v14, v15
    v.extract    s1, v3, #15
    s.movz       s2, #15
    v.splat      v3, s1
    a.vread      v10, a2, s2
    vf.fma       v14, v11, v12, v16
    s.movz       s1, #0
    s.movz       s2, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    s.movz       s7, #1
    vf.fma       v11, v4, v6, v14
    s.movz       s8, #1
    s.movz       s10, #1
    s.movz       s11, #2
    s.movz       s12, #2
    vf.fma       v4, v5, v7, v11
    s.movz       s13, #2
    s.movz       s14, #3
    s.movz       s15, #3
    s.movz       s17, #3
    vf.fma       v5, v3, v10, v4
    s.movz       s18, #4
    a.vwrite     a3, s16, v5
    a.vread      v3, a0, s1
    a.vread      v4, a3, s2
    s.movz       s1, #4
    s.movz       s2, #4
    vf.add       v5, v3, v4
    s.movz       s16, #5
    a.vwrite     a4, s6, v5
    a.vread      v3, a0, s7
    a.vread      v4, a3, s8
    s.movz       s6, #5
    s.movz       s7, #5
    vf.add       v5, v3, v4
    s.movz       s8, #6
    a.vwrite     a4, s10, v5
    a.vread      v3, a0, s11
    a.vread      v4, a3, s12
    s.movz       s10, #6
    s.movz       s11, #6
    vf.add       v5, v3, v4
    s.movz       s12, #7
    a.vwrite     a4, s13, v5
    a.vread      v3, a0, s14
    a.vread      v4, a3, s15
    s.movz       s13, #7
    s.movz       s14, #7
    vf.add       v5, v3, v4
    s.movz       s15, #8
    a.vwrite     a4, s17, v5
    a.vread      v3, a0, s18
    a.vread      v4, a3, s1
    s.movz       s1, #8
    s.movz       s17, #8
    vf.add       v5, v3, v4
    s.movz       s18, #9
    a.vwrite     a4, s2, v5
    a.vread      v3, a0, s16
    a.vread      v4, a3, s6
    s.movz       s2, #9
    s.movz       s6, #9
    vf.add       v5, v3, v4
    s.movz       s16, #10
    a.vwrite     a4, s7, v5
    a.vread      v3, a0, s8
    a.vread      v4, a3, s10
    s.movz       s7, #10
    s.movz       s8, #10
    vf.add       v5, v3, v4
    s.movz       s10, #11
    a.vwrite     a4, s11, v5
    a.vread      v3, a0, s12
    a.vread      v4, a3, s13
    s.movz       s11, #11
    s.movz       s12, #11
    vf.add       v5, v3, v4
    s.movz       s13, #12
    a.vwrite     a4, s14, v5
    a.vread      v3, a0, s15
    a.vread      v4, a3, s1
    s.movz       s1, #12
    s.movz       s14, #12
    vf.add       v5, v3, v4
    s.movz       s15, #13
    a.vwrite     a4, s17, v5
    a.vread      v3, a0, s18
    a.vread      v4, a3, s2
    s.movz       s2, #13
    s.movz       s17, #13
    vf.add       v5, v3, v4
    s.movz       s18, #14
    a.vwrite     a4, s6, v5
    a.vread      v3, a0, s16
    a.vread      v4, a3, s7
    s.movz       s6, #14
    s.movz       s7, #14
    vf.add       v5, v3, v4
    s.movz       s16, #15
    a.vwrite     a4, s8, v5
    a.vread      v3, a0, s10
    a.vread      v4, a3, s11
    s.movz       s8, #15
    s.movz       s10, #15
    vf.add       v5, v3, v4
    s.movz       s11, #0
    a.vwrite     a4, s12, v5
    a.vread      v3, a0, s13
    a.vread      v4, a3, s1
    s.movz       s1, #0
    s.movz       s12, #1
    vf.add       v5, v3, v4
    s.movz       s13, #1
    a.vwrite     a4, s14, v5
    a.vread      v3, a0, s15
    a.vread      v4, a3, s2
    s.movz       s2, #2
    s.movz       s14, #2
    vf.add       v5, v3, v4
    s.movz       s15, #3
    a.vwrite     a4, s17, v5
    a.vread      v3, a0, s18
    a.vread      v4, a3, s6
    s.movz       s6, #3
    s.movz       s17, #4
    vf.add       v5, v3, v4
    s.movz       s18, #4
    a.vwrite     a4, s7, v5
    a.vread      v3, a0, s16
    a.vread      v4, a3, s8
    s.movz       s7, #5
    s.movz       s8, #5
    vf.add       v5, v3, v4
    s.movz       s16, #6
    a.vwrite     a4, s10, v5
    a.vread      v3, a4, s11
    s.movz       s10, #6
    s.movz       s11, #7
    a.vwrite     a0, s1, v3
    a.vread      v3, a4, s12
    s.movz       s1, #7
    s.movz       s12, #8
    a.vwrite     a0, s13, v3
    a.vread      v3, a4, s2
    s.movz       s2, #8
    s.movz       s13, #9
    a.vwrite     a0, s14, v3
    a.vread      v3, a4, s15
    s.movz       s14, #9
    s.movz       s15, #10
    a.vwrite     a0, s6, v3
    a.vread      v3, a4, s17
    s.movz       s6, #10
    s.movz       s17, #11
    a.vwrite     a0, s18, v3
    a.vread      v3, a4, s7
    s.movz       s7, #11
    s.movz       s18, #12
    a.vwrite     a0, s8, v3
    a.vread      v3, a4, s16
    s.movz       s8, #12
    s.movz       s16, #13
    a.vwrite     a0, s10, v3
    a.vread      v3, a4, s11
    s.movz       s10, #13
    s.movz       s11, #14
    a.vwrite     a0, s1, v3
    a.vread      v3, a4, s12
    s.movz       s1, #14
    s.movz       s12, #15
    a.vwrite     a0, s2, v3
    a.vread      v3, a4, s13
    s.movz       s2, #15
    s.add        s13, s9, s24
    a.vwrite     a0, s14, v3
    a.vread      v3, a4, s15
    s.movz       s14, #1
    a.vwrite     a0, s6, v3
    a.vread      v3, a4, s17
    a.vwrite     a0, s7, v3
    a.vread      v3, a4, s18
    a.vwrite     a0, s8, v3
    a.vread      v3, a4, s16
    a.vwrite     a0, s10, v3
    a.vread      v3, a4, s11
    a.vwrite     a0, s1, v3
    a.vread      v3, a4, s12
    a.vwrite     a0, s2, v3
    s.mov        s9, s13
    br.nz        s14, for_1
endfor_2:
    s.muli       s1, s5, #64                     // a runtime tile origin, x64
    v.extract    s2, v8, #0
    s.movz       s5, #8
    s.movz       s6, #64
    v.extract    s7, v8, #1
    s.movz       s8, #0
    v.splat      v0, s2
    v.splat      v3, s5
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s6
    v.splat      v6, s7
    v.extract    s2, v2, #0
    s.add        s5, s8, s1                      // the tile origin
    v.extract    s1, v2, #1
    v.extract    s6, v2, #2
    v.splat      v7, s2
    v.mul        v10, v0, v3
    v.mul        v0, v4, v5
    v.splat      v4, s5
    v.splat      v5, s1
    v.mul        v11, v6, v3
    v.add        v6, v7, v10
    v.add        v7, v0, v4
    v.add        v0, v5, v11
    v.splat      v4, s4
    v.add        v5, v6, v7
    v.add        v6, v0, v7
    s.addi       s1, s3, #3136
    v.add        v0, v4, v5
    v.add        v5, v4, v6
    s.addi       s2, s1, #64
    s.addi       s4, s1, #128
    v.movi       v6, #1
    v.splat      v10, s6
    v.movi       v11, #1
    v.movi       v12, #0
    v.st.w       [s1, #0], v0
    v.movi       v0, #1
    v.cmp.lt     p1, v9, v6
    v.extract    s5, v8, #2
    v.movi       v6, #0
    v.splat      v9, s5
    v.cmp.lt     p2, v8, v1
    @p1 v.sel        v14, v11, v12
    v.mul        v11, v9, v3
    v.movi       v9, #1
    @p2 v.sel        v12, v0, v6
    v.add        v0, v10, v11
    s.addi       s5, s1, #192
    v.movi       v6, #0
    v.add        v10, v0, v7
    v.cmp.lt     p1, v2, v1
    v.extract    s6, v8, #3
    v.extract    s7, v2, #3
    v.add        v0, v4, v10
    v.splat      v10, s7
    v.st.w       [s2, #0], v5
    @p1 v.sel        v5, v9, v6
    v.splat      v6, s6
    v.cmp.lt     p1, v13, v1
    v.extract    s2, v8, #4
    v.extract    s6, v8, #5
    v.extract    s7, v8, #6
    v.extract    s8, v8, #7
    v.splat      v1, s2
    v.splat      v9, s6
    v.splat      v11, s7
    v.extract    s2, v2, #4
    v.extract    s6, v2, #5
    v.extract    s7, v2, #6
    v.mul        v13, v6, v3
    v.mul        v6, v1, v3
    v.mul        v1, v9, v3
    v.mul        v9, v11, v3
    v.add        v11, v10, v13
    v.splat      v10, s8
    v.extract    s8, v2, #7
    v.add        v13, v11, v7
    v.mul        v11, v10, v3
    v.st.w       [s4, #0], v0
    v.extract    s4, v8, #8
    v.splat      v0, s2
    v.extract    s2, v2, #8
    v.add        v10, v4, v13
    v.add        v13, v0, v6
    v.splat      v0, s4
    s.addi       s4, s1, #256
    v.add        v6, v13, v7
    v.mul        v13, v0, v3
    v.add        v0, v4, v6
    v.st.w       [s5, #0], v10
    v.extract    s5, v8, #9
    v.splat      v6, s6
    v.extract    s6, v2, #9
    v.add        v10, v6, v1
    v.splat      v1, s5
    s.addi       s5, s1, #320
    v.add        v6, v10, v7
    v.mul        v10, v1, v3
    v.add        v1, v4, v6
    v.st.w       [s4, #0], v0
    v.extract    s4, v8, #10
    v.splat      v0, s7
    v.extract    s7, v2, #10
    v.add        v6, v0, v9
    v.splat      v0, s4
    s.addi       s4, s1, #384
    v.add        v9, v6, v7
    v.mul        v6, v0, v3
    v.add        v0, v4, v9
    v.st.w       [s5, #0], v1
    v.extract    s5, v8, #11
    v.splat      v1, s8
    v.extract    s8, v2, #11
    v.add        v9, v1, v11
    v.splat      v1, s5
    s.addi       s5, s1, #448
    v.add        v11, v9, v7
    v.mul        v9, v1, v3
    v.add        v1, v4, v11
    v.st.w       [s4, #0], v0
    v.extract    s4, v8, #12
    v.splat      v0, s2
    v.extract    s2, v2, #12
    v.add        v11, v0, v13
    v.splat      v0, s4
    s.addi       s4, s1, #512
    v.add        v13, v11, v7
    v.mul        v11, v0, v3
    v.add        v0, v4, v13
    v.st.w       [s5, #0], v1
    v.extract    s5, v8, #13
    v.splat      v1, s6
    v.extract    s6, v2, #13
    v.add        v13, v1, v10
    v.splat      v1, s5
    s.addi       s5, s1, #576
    v.add        v10, v13, v7
    v.mul        v13, v1, v3
    v.add        v1, v4, v10
    v.st.w       [s4, #0], v0
    v.extract    s4, v8, #14
    v.splat      v0, s7
    v.extract    s7, v2, #14
    v.add        v10, v0, v6
    v.splat      v0, s4
    s.addi       s4, s1, #640
    v.add        v6, v10, v7
    v.mul        v10, v0, v3
    v.add        v0, v4, v6
    v.st.w       [s5, #0], v1
    v.extract    s5, v8, #15
    v.splat      v1, s8
    v.splat      v6, s5
    v.extract    s5, v2, #15
    v.splat      v2, s2
    v.mul        v8, v6, v3
    v.splat      v3, s6
    v.add        v6, v1, v9
    v.splat      v1, s7
    v.add        v9, v2, v11
    v.splat      v2, s5
    v.add        v11, v3, v13
    v.add        v3, v1, v10
    v.add        v1, v2, v8
    v.add        v2, v6, v7
    v.add        v6, v9, v7
    v.add        v8, v11, v7
    v.add        v9, v3, v7
    v.add        v3, v4, v2
    v.add        v2, v4, v6
    v.add        v6, v4, v8
    v.add        v8, v4, v9
    s.addi       s2, s1, #704
    s.addi       s5, s1, #768
    s.addi       s6, s1, #832
    s.addi       s7, s1, #896
    s.addi       s8, s1, #960
    v.st.w       [s4, #0], v0
    v.add        v0, v1, v7
    s.movz       s1, #0
    s.addi       s4, s3, #3136
    v.add        v1, v4, v0
    v.st.w       [s2, #0], v3
    v.extract    s2, v14, #0
    v.movi       v0, #0
    v.splat      v3, s2
    v.extract    s2, v12, #0
    v.movi       v4, #0
    v.splat      v7, s2
    v.extract    s2, v5, #0
    v.movi       v9, #0
    v.splat      v10, s2
    v.cmp.ne     p2, v3, v0
    v.cmp.ne     p3, v7, v4
    p.and        p4, p2, p3
    v.st.w       [s5, #0], v2
    v.cmp.ne     p2, v10, v9
    p.and        p3, p4, p2
    s.movz       s2, #1
    p.and        p2, p3, p1
    s.addi       s5, s3, #3200
    v.st.w       [s6, #0], v6
    v.extract    s6, v14, #1
    v.movi       v0, #0
    v.splat      v2, s6
    v.extract    s6, v12, #1
    v.movi       v3, #0
    v.splat      v4, s6
    v.extract    s6, v5, #1
    v.movi       v6, #0
    v.splat      v7, s6
    v.cmp.ne     p3, v2, v0
    v.cmp.ne     p4, v4, v3
    p.and        p5, p3, p4
    v.st.w       [s7, #0], v8
    v.cmp.ne     p3, v7, v6
    p.and        p4, p5, p3
    s.movz       s6, #2
    p.and        p3, p4, p1
    s.addi       s7, s3, #3264
    v.st.w       [s8, #0], v1
    fence.acq_rel.device
    a.vread      v0, a0, s1
    v.extract    s1, v14, #2
    v.extract    s8, v12, #2
    v.splat      v1, s1
    v.movi       v2, #0
    v.splat      v3, s8
    v.movi       v4, #0
    v.cmp.ne     p4, v1, v2
    v.ld.w       v1, [s4, #0]
    v.extract    s1, v5, #2
    v.movi       v2, #0
    v.splat      v6, s1
    s.movz       s1, #3
    s.addi       s4, s3, #3328
    v.extract    s8, v14, #3
    v.movi       v7, #0
    v.splat      v8, s8
    @p2 v.st.scatter.w [s26, v1], v0
    a.vread      v0, a0, s2
    v.cmp.ne     p2, v3, v4
    p.and        p5, p4, p2
    v.cmp.ne     p2, v6, v2
    p.and        p4, p5, p2
    v.extract    s2, v12, #3
    p.and        p2, p4, p1
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s5, #0]
    v.extract    s2, v5, #3
    v.movi       v4, #0
    v.splat      v6, s2
    s.movz       s2, #4
    s.addi       s5, s3, #3392
    v.extract    s8, v14, #4
    v.movi       v7, #0
    v.splat      v8, s8
    @p3 v.st.scatter.w [s26, v3], v0
    a.vread      v0, a0, s6
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v6, v4
    p.and        p4, p5, p3
    v.extract    s6, v12, #4
    p.and        p3, p4, p1
    v.splat      v1, s6
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s7, #0]
    v.extract    s6, v5, #4
    v.movi       v4, #0
    v.splat      v6, s6
    s.movz       s6, #5
    s.addi       s7, s3, #3456
    v.extract    s8, v14, #5
    v.movi       v7, #0
    v.splat      v8, s8
    @p2 v.st.scatter.w [s26, v3], v0
    a.vread      v0, a0, s1
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v6, v4
    p.and        p4, p5, p2
    v.extract    s1, v12, #5
    p.and        p2, p4, p1
    v.splat      v1, s1
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s4, #0]
    v.extract    s1, v5, #5
    v.movi       v4, #0
    v.splat      v6, s1
    s.movz       s1, #6
    s.addi       s4, s3, #3520
    v.extract    s8, v14, #6
    v.movi       v7, #0
    v.splat      v8, s8
    @p3 v.st.scatter.w [s26, v3], v0
    a.vread      v0, a0, s2
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v6, v4
    p.and        p4, p5, p3
    v.extract    s2, v12, #6
    p.and        p3, p4, p1
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s5, #0]
    v.extract    s2, v5, #6
    v.movi       v4, #0
    v.splat      v6, s2
    s.movz       s2, #7
    s.addi       s5, s3, #3584
    v.extract    s8, v14, #7
    v.movi       v7, #0
    v.splat      v8, s8
    @p2 v.st.scatter.w [s26, v3], v0
    a.vread      v0, a0, s6
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v6, v4
    p.and        p4, p5, p2
    v.extract    s6, v12, #7
    p.and        p2, p4, p1
    v.splat      v1, s6
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s7, #0]
    v.extract    s6, v5, #7
    v.movi       v4, #0
    v.splat      v6, s6
    s.movz       s6, #8
    s.addi       s7, s3, #3648
    v.extract    s8, v14, #8
    v.movi       v7, #0
    v.splat      v8, s8
    @p3 v.st.scatter.w [s26, v3], v0
    a.vread      v0, a0, s1
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v6, v4
    p.and        p4, p5, p3
    v.extract    s1, v12, #8
    p.and        p3, p4, p1
    v.splat      v1, s1
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s4, #0]
    v.extract    s1, v5, #8
    v.movi       v4, #0
    v.splat      v6, s1
    s.movz       s1, #9
    s.addi       s4, s3, #3712
    v.extract    s8, v14, #9
    v.movi       v7, #0
    v.splat      v8, s8
    @p2 v.st.scatter.w [s26, v3], v0
    a.vread      v0, a0, s2
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v6, v4
    p.and        p4, p5, p2
    v.extract    s2, v12, #9
    p.and        p2, p4, p1
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s5, #0]
    v.extract    s2, v5, #9
    v.movi       v4, #0
    v.splat      v6, s2
    s.movz       s2, #10
    s.addi       s5, s3, #3776
    v.extract    s8, v14, #10
    v.movi       v7, #0
    v.splat      v8, s8
    @p3 v.st.scatter.w [s26, v3], v0
    a.vread      v0, a0, s6
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v6, v4
    p.and        p4, p5, p3
    v.extract    s6, v12, #10
    p.and        p3, p4, p1
    v.splat      v1, s6
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s7, #0]
    v.extract    s6, v5, #10
    v.movi       v4, #0
    v.splat      v6, s6
    s.movz       s6, #11
    s.addi       s7, s3, #3840
    v.extract    s8, v14, #11
    v.movi       v7, #0
    v.splat      v8, s8
    @p2 v.st.scatter.w [s26, v3], v0
    a.vread      v0, a0, s1
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v6, v4
    p.and        p4, p5, p2
    v.extract    s1, v12, #11
    p.and        p2, p4, p1
    v.splat      v1, s1
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s4, #0]
    v.extract    s1, v5, #11
    v.movi       v4, #0
    v.splat      v6, s1
    s.movz       s1, #12
    s.addi       s4, s3, #3904
    v.extract    s8, v14, #12
    v.movi       v7, #0
    v.splat      v8, s8
    @p3 v.st.scatter.w [s26, v3], v0
    a.vread      v0, a0, s2
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v6, v4
    p.and        p4, p5, p3
    v.extract    s2, v12, #12
    p.and        p3, p4, p1
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s5, #0]
    v.extract    s2, v5, #12
    v.movi       v4, #0
    v.splat      v6, s2
    s.movz       s2, #13
    s.addi       s5, s3, #3968
    v.extract    s8, v14, #13
    v.movi       v7, #0
    v.splat      v8, s8
    @p2 v.st.scatter.w [s26, v3], v0
    a.vread      v0, a0, s6
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v6, v4
    p.and        p4, p5, p2
    v.extract    s6, v12, #13
    p.and        p2, p4, p1
    v.splat      v1, s6
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s7, #0]
    v.extract    s6, v5, #13
    v.movi       v4, #0
    v.splat      v6, s6
    s.movz       s6, #14
    s.addi       s7, s3, #4032
    v.extract    s8, v14, #14
    v.movi       v7, #0
    v.splat      v8, s8
    @p3 v.st.scatter.w [s26, v3], v0
    a.vread      v0, a0, s1
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v6, v4
    p.and        p4, p5, p3
    v.extract    s1, v12, #14
    p.and        p3, p4, p1
    v.splat      v1, s1
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s4, #0]
    v.extract    s1, v5, #14
    v.movi       v4, #0
    v.splat      v6, s1
    s.movz       s1, #15
    s.addi       s4, s3, #4096
    v.extract    s3, v14, #15
    v.movi       v7, #0
    v.splat      v8, s3
    @p2 v.st.scatter.w [s26, v3], v0
    a.vread      v0, a0, s2
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v6, v4
    p.and        p4, p5, p2
    v.extract    s2, v12, #15
    p.and        p2, p4, p1
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v7
    v.ld.w       v3, [s5, #0]
    v.extract    s2, v5, #15
    v.movi       v4, #0
    v.splat      v5, s2
    @p3 v.st.scatter.w [s26, v3], v0
    a.vread      v0, a0, s6
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    p.and        p3, p4, p1
    v.ld.w       v1, [s7, #0]
    @p2 v.st.scatter.w [s26, v1], v0
    a.vread      v0, a0, s1
    v.ld.w       v1, [s4, #0]
    @p3 v.st.scatter.w [s26, v1], v0
__rctx_next:
    exit
