    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #5
    v.movi       v2, #0
    v.movi       v3, #200
    s.rdspecial  s1, arg_base
    v.splat      v4, s2
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v1, v2
    v.add        v6, v4, v0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v0, #1
    v.sub        v4, v2, v6
    v.cmp.lt     p2, v6, v2
    v.cmp.lt     p3, v6, v3
    @p2 v.sel        v3, v4, v6
    @p1 v.sel        v4, v5, v1
    v.movi       v5, #0
    v.movi       v6, #0
    s.movz       s4, #31
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s6, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
idiv_1:
    v.splat      v7, s4
    v.shl        v8, v6, v0
    v.cmp.lt     p4, v6, v2
    v.lshr       v9, v3, v7
    v.shl        v10, v0, v7
    s.subi       s1, s4, #1
    v.and        v7, v9, v0
    s.movz       s7, #0
    v.or         v9, v8, v7
    v.cmp.geu    p5, v9, v4
    p.or         p6, p4, p5
    v.sub        v7, v9, v4
    @p6 v.sel        v8, v10, v2
    @p6 v.sel        v10, v7, v9
    v.or         v7, v5, v8
    v.mov        v6, v10
    v.mov        v5, v7
    s.mov        s4, s1
    s.cmp.ge     s1, s4, s7
    br.nz        s1, idiv_1
    v.sub        v0, v2, v5
    p.xor        p4, p2, p1
    v.movi       v2, #1
    @p4 v.sel        v3, v0, v5
    v.movi       v0, #2
    v.movi       v4, #3
    v.mul        v5, v3, v1
    v.movi       v1, #4
    s.shli       s1, s2, #2                      // element offset -> bytes (x4)
    v.add        v6, v5, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s5, v5]               // index is in elements (ISA sec 9.1)
    v.add        v7, v5, v0
    v.add        v0, v5, v4
    v.add        v4, v5, v1
    .li       s2, #1065353216
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s2, s5, s1                      // &in_ptr1[...]
    v.movi       v5, #0
    v.movi       v8, #1
    v.movi       v9, #0
    v.movi       v10, #0
    v.movi       v11, #0
    s.add        s4, s6, s1                      // &out_ptr0[...]
    s.movz       s1, #5
    s.movz       s1, #1
    s.movz       s1, #2
    s.movz       s1, #3
    s.movz       s1, #4
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v12, [s5, v6]              // index is in elements (ISA sec 9.1)
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s5, v7]               // index is in elements (ISA sec 9.1)
    vf.add       v7, v2, v12
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s5, v0]               // index is in elements (ISA sec 9.1)
    vf.add       v0, v7, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v6, [s5, v4]               // index is in elements (ISA sec 9.1)
    vf.add       v4, v0, v2
    vf.add       v0, v4, v6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v2, [s3, v3]              // index is in elements (ISA sec 9.1)
    v.rcp.approx v3, v0                          // ISA 8.8: <= 2**-22 relative
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    v.cmp.ne     p1, v2, v5
    @p1 v.sel        v2, v8, v9
    v.cmp.eq     p1, v2, v10
    vf.fms       v2, v0, v3, v1
    vf.fms       v0, v3, v2, v3
    vf.neg       v1, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v0, v1, v3
    vf.mul       v1, v4, v0                      // a/y as a refined reciprocal (ISA has no divide)
    @p1 v.sel        v0, v11, v1
    @p3 v.st.w       [s4, #0], v0
__rctx_next:
    exit
