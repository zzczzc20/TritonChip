    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #32
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #48
    v.iota       v6                              // arange(0, VLEN)
    v.movi       v7, #64
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #80
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #96
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #112
    s.shli       s1, s4, #7                      // x128 as a shift
    v.iota       v14                             // arange(0, VLEN)
    v.add        v15, v0, v1
    v.add        v0, v2, v3
    v.add        v1, v4, v5
    v.add        v2, v6, v7
    v.add        v3, v8, v9
    v.add        v4, v10, v11
    v.add        v5, v12, v13
    v.splat      v6, s1
    v.splat      v7, s1
    v.splat      v8, s1
    v.splat      v9, s1
    v.splat      v10, s1
    v.splat      v11, s1
    v.splat      v12, s1
    v.splat      v13, s1
    v.add        v16, v6, v14
    v.add        v6, v7, v15
    v.add        v7, v8, v0
    v.add        v0, v9, v1
    v.add        v1, v10, v2
    v.add        v2, v11, v3
    v.add        v3, v12, v4
    v.add        v4, v13, v5
    v.movi       v5, #0
    s.rdspecial  s1, arg_base
    v.movi       v8, #2
    v.sub        v9, v5, v16
    v.cmp.lt     p1, v16, v5
    s.ld.d       s2, [s1, #0]                    // SRC: device_ptr64 at arg_base+0
    @p1 v.sel        v10, v9, v16
    v.sub        v9, v5, v8
    v.cmp.lt     p2, v8, v5
    @p2 v.sel        v11, v9, v8
    s.ld.d       s3, [s1, #8]                    // DST: device_ptr64 at arg_base+8
    v.movi       v9, #0
    v.movi       v11, #0
    v.movi       v12, #0
    v.movi       v13, #0
    v.sub        v14, v9, v6
    v.sub        v15, v11, v7
    v.sub        v17, v12, v0
    v.sub        v18, v13, v1
    v.cmp.lt     p2, v6, v9
    v.cmp.lt     p3, v7, v11
    v.movi       v19, #1
    @p2 v.sel        v20, v14, v6
    v.movi       v14, #1
    @p3 v.sel        v21, v15, v7
    v.movi       v15, #1
    v.movi       v22, #1
    v.movi       v23, #1
    v.lshr       v24, v10, v19
    v.lshr       v10, v20, v14
    v.lshr       v14, v21, v15
    v.sub        v15, v5, v24
    v.sub        v5, v9, v10
    v.sub        v19, v11, v14
    @p1 v.sel        v20, v15, v24
    v.cmp.lt     p1, v0, v12
    @p1 v.sel        v15, v17, v0
    v.movi       v17, #2
    v.movi       v21, #0
    v.lshr       v24, v15, v22
    @p2 v.sel        v15, v5, v10
    v.cmp.lt     p2, v1, v13
    @p2 v.sel        v5, v18, v1
    v.sub        v10, v12, v24
    v.movi       v18, #2
    v.lshr       v22, v5, v23
    @p3 v.sel        v5, v19, v14
    v.cmp.lt     p3, v2, v21
    v.sub        v14, v13, v22
    v.movi       v19, #2
    @p1 v.sel        v23, v10, v24
    v.movi       v10, #2
    @p2 v.sel        v24, v14, v22
    v.movi       v14, #2
    v.sub        v22, v9, v17
    v.sub        v25, v11, v18
    v.sub        v26, v12, v19
    v.sub        v27, v13, v10
    v.cmp.lt     p1, v17, v9
    v.sub        v9, v21, v2
    v.sub        v28, v21, v14
    v.cmp.lt     p2, v18, v11
    @p3 v.sel        v11, v9, v2
    @p1 v.sel        v9, v22, v17
    v.movi       v9, #0
    v.movi       v22, #1
    v.movi       v29, #2
    v.sub        v30, v9, v3
    v.cmp.lt     p1, v3, v9
    v.lshr       v31, v11, v22
    @p1 v.sel        v11, v30, v3
    v.sub        v22, v9, v29
    v.sub        v30, v21, v31
    @p2 v.sel        v32, v25, v18
    v.movi       v25, #0
    v.movi       v32, #1
    @p3 v.sel        v33, v30, v31
    v.cmp.lt     p2, v4, v25
    v.lshr       v30, v11, v32
    v.movi       v11, #2
    v.cmp.lt     p3, v19, v12
    v.sub        v12, v25, v4
    v.sub        v31, v9, v30
    v.sub        v32, v25, v11
    @p2 v.sel        v34, v12, v4
    @p1 v.sel        v12, v31, v30
    v.cmp.lt     p1, v10, v13
    @p3 v.sel        v13, v26, v19
    v.movi       v13, #0
    v.movi       v26, #1
    v.cmp.lt     p3, v14, v21
    v.sub        v21, v13, v16
    v.lshr       v30, v34, v26
    v.sub        v26, v13, v8
    @p1 v.sel        v31, v27, v10
    v.movi       v27, #0
    v.cmp.lt     p1, v16, v13
    @p1 v.sel        v31, v21, v16
    v.sub        v21, v27, v6
    v.movi       v34, #1
    v.movi       v35, #1
    v.sub        v36, v25, v30
    v.and        v37, v31, v34
    v.sub        v31, v27, v17
    @p2 v.sel        v34, v36, v30
    v.cmp.lt     p2, v6, v27
    @p2 v.sel        v30, v21, v6
    v.sub        v21, v13, v37
    @p3 v.sel        v36, v28, v14
    v.movi       v28, #0
    v.and        v36, v30, v35
    @p1 v.sel        v30, v21, v37
    v.sub        v21, v28, v7
    v.cmp.lt     p1, v7, v28
    v.sub        v35, v27, v36
    @p1 v.sel        v37, v21, v7
    v.cmp.lt     p3, v29, v9
    v.movi       v9, #1
    @p2 v.sel        v21, v35, v36
    v.sub        v35, v28, v18
    v.and        v36, v37, v9
    v.cmp.lt     p2, v11, v25
    @p3 v.sel        v9, v22, v29
    v.movi       v9, #0
    v.movi       v22, #1
    v.sub        v25, v28, v36
    v.sub        v37, v9, v0
    v.cmp.lt     p3, v0, v9
    @p1 v.sel        v38, v25, v36
    @p3 v.sel        v25, v37, v0
    v.sub        v36, v9, v19
    v.cmp.lt     p1, v8, v13
    v.and        v13, v25, v22
    @p2 v.sel        v22, v32, v11
    v.movi       v22, #0
    v.movi       v25, #1
    v.sub        v32, v9, v13
    v.sub        v37, v22, v1
    v.cmp.lt     p2, v1, v22
    @p3 v.sel        v39, v32, v13
    @p2 v.sel        v13, v37, v1
    v.sub        v32, v22, v10
    v.cmp.lt     p3, v17, v27
    v.and        v27, v13, v25
    @p1 v.sel        v13, v26, v8
    v.movi       v13, #0
    v.movi       v25, #1
    v.sub        v26, v22, v27
    v.sub        v37, v13, v2
    v.cmp.lt     p1, v2, v13
    @p2 v.sel        v40, v26, v27
    @p1 v.sel        v26, v37, v2
    v.sub        v27, v13, v14
    v.cmp.lt     p2, v18, v28
    v.and        v28, v26, v25
    @p3 v.sel        v25, v31, v17
    v.movi       v25, #0
    v.movi       v26, #1
    v.sub        v31, v13, v28
    v.sub        v37, v25, v3
    v.cmp.lt     p3, v3, v25
    @p1 v.sel        v41, v31, v28
    @p3 v.sel        v28, v37, v3
    v.sub        v31, v25, v29
    v.cmp.lt     p1, v19, v9
    v.and        v9, v28, v26
    @p2 v.sel        v26, v35, v18
    v.movi       v26, #0
    v.movi       v28, #1
    v.sub        v35, v25, v9
    v.sub        v37, v26, v4
    v.cmp.lt     p2, v4, v26
    @p3 v.sel        v42, v35, v9
    @p2 v.sel        v9, v37, v4
    v.sub        v35, v26, v11
    v.cmp.lt     p3, v10, v22
    v.and        v22, v9, v28
    @p1 v.sel        v9, v36, v19
    v.mul        v9, v20, v8
    v.sub        v8, v26, v22
    v.mul        v20, v15, v17
    v.mul        v15, v5, v18
    @p2 v.sel        v5, v8, v22
    v.mul        v8, v23, v19
    v.mul        v17, v24, v10
    v.mul        v18, v33, v14
    v.mul        v19, v12, v29
    v.mul        v12, v34, v11
    .li       s1, #65536
    v.splat      v22, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p1, v14, v13
    v.cmp.lt     p2, v29, v25
    @p3 v.sel        v13, v32, v10
    .li       s1, #65536
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #65536
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #65536
    v.splat      v23, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v24, v9, v30                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v25, v20, v21                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v28, v15, v38                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p3, v16, v22
    v.movi       v32, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v32, [s2, v24]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v6, v10
    @p1 v.sel        v24, v27, v14
    .li       s1, #65536
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #65536
    v.splat      v24, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v27, v8, v39                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v33, v17, v40                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v34, v18, v41                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v13
    @p2 v.sel        v36, v31, v29
    .li       s1, #65536
    v.splat      v29, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #65536
    v.splat      v31, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v36, v19, v42                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v37, v12, v5                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v23
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v43, [s2, v25]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v1, v14
    v.movi       v25, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v25, [s2, v28]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v24
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v28, [s2, v27]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v29
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v27, [s2, v33]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v4, v31
    v.movi       v33, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v33, [s2, v34]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v11, v26
    v.add        v26, v9, v30                    // per-lane offsets add up, in elements (ISA sec 9.1)
    @p1 v.sel        v9, v35, v11
    v.add        v9, v20, v21                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v11, v15, v38                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v15, v8, v39                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v8, v17, v40                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v17, v18, v41                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v18, v19, v42                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v19, v12, v5                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p1, v16, v22
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v5, [s2, v36]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v6, [s2, v37]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v7, v13
    @p1 v.st.scatter.b [s3, v26], v32
    v.cmp.lt     p1, v0, v23
    @p2 v.st.scatter.b [s3, v9], v43
    v.cmp.lt     p2, v1, v14
    @p3 v.st.scatter.b [s3, v11], v25
    v.cmp.lt     p3, v2, v24
    @p1 v.st.scatter.b [s3, v15], v28
    v.cmp.lt     p1, v3, v29
    @p2 v.st.scatter.b [s3, v8], v27
    v.cmp.lt     p2, v4, v31
    @p3 v.st.scatter.b [s3, v17], v33
    @p1 v.st.scatter.b [s3, v18], v5
    @p2 v.st.scatter.b [s3, v19], v6
__rctx_next:
    exit
