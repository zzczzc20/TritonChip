#!/bin/bash
# After the main campaign: graph-level default identity, then the sensitivity runs.
W=~/r41-pmac-model-work
R=$W/tools/run_cfg.sh
while [ ! -f $W/runs/campaign.done ]; do sleep 30; done
ID="op.matmul/medium/fp16-m128-k192-n128 op.w8a8_linear/hbm/bf16-m1-k2048-n6144 op.bf16_linear/hbm/bf16-m1-k2048-n6144 op.attention_prefill/medium/fp16-b1-h4-s96-d32"
BINARY=$HOME/r41-pmac-model-build/base/tnca-chip $R i-base-g1-pf0 g1-pf0 14-17 4 $ID &
$R i-mod-keys-default g1-keys-default 18-19 2 $ID
wait
P="op.matmul/large/fp16-m2048-k2048-n2048 op.w8a8_linear/hbm/bf16-m128-k2560-n9216 op.bf16_linear/hbm/bf16-m128-k2560-n9216 op.bf16_linear/hbm/bf16-m1-k2560-n9216"
for g in g1 g2g4-pf1; do
  base=g1-pf0; [ $g = g2g4-pf1 ] && base=g2g4-pf1
  $R s-dma4-$g s-dma4-$g 14-19 4 $P
  $R s-home2-$g s-home2-$g 14-19 4 $P
  EXTRA_ENV="--env TNCA_GEMM_TILE=16,64,16" $R s-t64-$g $base 14-19 4 $P
  EXTRA_ENV="--env TNCA_RCTX_ROLES=2 --env TNCA_PIPELINE=3" $R s-ring-$g $base 14-19 4 $P
  EXTRA_ENV="--env TNCA_GEMM_TILE=16,64,16 --env TNCA_RCTX_ROLES=2 --env TNCA_PIPELINE=3" $R s-best-$g s-all-$g 14-19 4 $P
done
echo SENS-DONE > $W/runs/sens.done
