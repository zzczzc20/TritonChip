create_clock -name clk -period 11.1 [get_ports clk]
