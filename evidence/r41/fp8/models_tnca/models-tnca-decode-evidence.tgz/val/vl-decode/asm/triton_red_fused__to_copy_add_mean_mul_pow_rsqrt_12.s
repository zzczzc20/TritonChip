    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // out_ptr0: device_ptr64 at arg_base+32
    s.ld.d       s7, [s1, #40]                   // out_ptr2: device_ptr64 at arg_base+40
    s.ld.d       s8, [s1, #48]                   // out_ptr3: device_ptr64 at arg_base+48
    s.ld.d       s9, [s1, #56]                   // out_ptr4: device_ptr64 at arg_base+56
    v.iota       v0                              // arange(0, VLEN)
    s.rdspecial  s1, arg_base
    s.ld.d       s10, [s1, #72]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s1, s10, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 1)
    s.movz       s11, #0
    s.st.d       [s1, #0], s3
    s.movz       s11, #2048
    s.st.d       [s1, #8], s11
    s.movz       s11, #2
    s.st.d       [s1, #48], s11
    s.movz       s11, #16
    s.st.d       [s1, #88], s11
    .li       s11, #1103806595072
    s.st.d       [s1, #104], s11
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s10, #256                   // TensorMap 1: tl.make_tensor_descriptor (rank 1)
    s.movz       s11, #0
    s.st.d       [s1, #0], s4
    s.movz       s11, #2048
    s.st.d       [s1, #8], s11
    s.movz       s11, #2
    s.st.d       [s1, #48], s11
    s.movz       s11, #16
    s.st.d       [s1, #88], s11
    .li       s11, #1103806595072
    s.st.d       [s1, #104], s11
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s11, #2048
    s.movz       s12, #16
    s.addi       s13, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s14, s13, s11
    br.nz        s14, endfor_2
    s.muli       s14, s13, #2
    v.splat      v1, s13
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s15, #2048
    v.splat      v4, s13
    v.add        v5, v1, v3
    v.movi       v1, #0
    v.splat      v3, s15
    s.shli       s15, s13, #1                    // element offset -> bytes (x2)
    v.add        v6, v4, v0
    v.movi       v4, #2048
    v.cmp.ge     p1, v5, v1
    v.cmp.lt     p2, v5, v3
    s.muli       s16, s13, #2
    v.splat      v1, s13
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s17, #2048
    s.add        s18, s2, s15                    // &in_ptr0[...]
    s.add        s19, s3, s14
    p.and        p3, p1, p2
    v.cmp.lt     p1, v6, v4
    v.add        v4, v1, v3
    v.movi       v1, #0
    v.splat      v3, s17
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v5, [s18, #0]
    v.cmp.ge     p2, v4, v1
    v.cmp.lt     p4, v4, v3
    s.add        s14, s4, s16
    p.and        p5, p2, p4
    s.add        s16, s6, s15                    // &out_ptr0[...]
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s19, #0]
    vf.cvt.bf16.f32 v3, v5
    v.movi       v4, #0
    s.add        s15, s13, s12
    s.movz       s17, #1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v5, [s14, #0]
    vf.cvt.bf16.f32 v6, v1
    vf.add       v1, v3, v6
    vf.cvt.bf16.f32 v3, v5
    vf.add       v5, v1, v3
    vf.mul       v1, v5, v5
    vf.cvt.f32.bf16 v3, v5
    vf.add       v5, v2, v1
    @p1 v.st.h       [s16, #0], v3
    @p1 v.sel        v1, v5, v2
    v.mov        v4, v1
    v.mov        v2, v4
    s.mov        s13, s15
    br.nz        s17, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    vf.add       v3, v1, v2
    s.addi       s2, s10, #512                   // TensorMap 2: tl.make_tensor_descriptor (rank 1)
    s.movz       s3, #0
    s.st.d       [s2, #0], s6
    s.movz       s3, #2048
    s.st.d       [s2, #8], s3
    s.movz       s3, #2
    s.st.d       [s2, #48], s3
    s.movz       s3, #16
    s.st.d       [s2, #88], s3
    .li       s3, #1103806595072
    s.st.d       [s2, #104], s3
    td.load      d2, [s2]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s2, s1, #0
for_3:
    s.cmp.ge     s1, s2, s11
    br.nz        s1, endfor_4
    .li       s1, #1157627904
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v4, v1                          // ISA 8.8: <= 2**-22 relative
    .li       s1, #897988541
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s1, s2, #2
    v.splat      v6, s2
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s3, #2048
    .li       s4, #1077936128
    v.splat      v8, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #3204448256
    v.splat      v9, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v10, v6, v7
    v.splat      v6, s2
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    v.add        v7, v6, v0
    v.movi       v6, #0
    s.add        s10, s5, s4                     // &in_ptr3[...]
    v.cmp.ge     p1, v10, v6
    v.splat      v6, s3
    s.add        s3, s6, s1
    v.cmp.lt     p2, v10, v6
    v.movi       v6, #2048
    p.and        p3, p1, p2
    v.cmp.lt     p1, v7, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v6, [s10, #0]
    fence.acq_rel.device
    s.add        s1, s7, s4                      // &out_ptr2[...]
    vf.fms       v7, v1, v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v10, v6
    s.add        s3, s8, s4                      // &out_ptr3[...]
    vf.fms       v6, v4, v7, v4
    s.add        s10, s9, s4                     // &out_ptr4[...]
    s.add        s4, s2, s12
    vf.cvt.bf16.f32 v7, v2
    vf.neg       v2, v6                          // Newton step: r0*(2 - x*r0)
    s.movz       s13, #1
    fence.acq_rel.device
    fence.acq_rel.device
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v6, v2, v4
    vf.mul       v2, v3, v6                      // a/y: faithful quotient
    vf.fms       v4, v2, v1, v3
    vf.fms       v1, v4, v6, v2
    vf.neg       v4, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v1, v4, v2
    vf.add       v2, v1, v5
    v.rsqrt.approx v1, v2                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v1, v1
    vf.mul       v5, v1, v9
    vf.fms       v6, v2, v4, v8
    vf.mul       v2, v5, v6                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v4, v2, v1
    v.extract    s14, v4, #0
    v.splat      v1, s14
    vf.mul       v2, v7, v1
    vf.mul       v1, v10, v2
    vf.cvt.f32.bf16 v2, v1
    @p1 v.st.h       [s1, #0], v2
    @p1 v.st.h       [s3, #0], v2
    @p1 v.st.h       [s10, #0], v2
    s.mov        s2, s4
    br.nz        s13, for_3
endfor_4:
    exit
    exit
