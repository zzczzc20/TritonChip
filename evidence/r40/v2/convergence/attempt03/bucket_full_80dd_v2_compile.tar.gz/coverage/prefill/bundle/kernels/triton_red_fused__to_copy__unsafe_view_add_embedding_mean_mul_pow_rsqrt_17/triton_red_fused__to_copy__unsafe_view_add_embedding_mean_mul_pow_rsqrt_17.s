    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s7, [s1, #40]                   // out_ptr1: device_ptr64 at arg_base+40
    s.movz       s1, #1
    s.rdspecial  s8, arg_base
    s.ld.d       s9, [s8, #64]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s8, role_id
    s.movz       s10, #512
    s.mul        s11, s8, s10
    s.add        s8, s9, s11                     // this context's own scratch
    s.addi       s9, s8, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s10, #0
    s.st.d       [s9, #0], s4
    s.movz       s10, #512
    s.st.d       [s9, #8], s10
    s.movz       s10, #1024
    s.st.d       [s9, #16], s10
    s.movz       s10, #2048
    s.st.d       [s9, #48], s10
    s.movz       s10, #2
    s.st.d       [s9, #56], s10
    .li       s10, #68719476737
    s.st.d       [s9, #88], s10
    .li       s10, #8589934592
    s.st.d       [s9, #104], s10
    fence.release.device
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s9, s8, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s8, #0
    s.st.d       [s9, #0], s5
    s.movz       s8, #512
    s.st.d       [s9, #8], s8
    s.movz       s8, #1024
    s.st.d       [s9, #16], s8
    s.movz       s8, #2048
    s.st.d       [s9, #48], s8
    s.movz       s8, #2
    s.st.d       [s9, #56], s8
    .li       s8, #68719476737
    s.st.d       [s9, #88], s8
    .li       s8, #8589934592
    s.st.d       [s9, #104], s8
    fence.release.device
    td.load      d1, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s8, #0
    s.movz       s9, #1024
    s.movz       s10, #16
    s.rdspecial  s11, role_id
    s.rdspecial  s12, npid.x
__rctx_program:
    s.shli       s13, s11, #3                    // element offset -> bytes (x8)
    v.movi       v0, #0
    v.movi       v1, #1
    s.add        s14, s2, s13                    // &in_ptr0[...]
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s1
    v.shl        v4, v0, v1
    v.movi       v0, #0
    v.movi       v1, #0
    s.addi       s13, s14, #4
    v.cmp.lt     p1, v2, v3
    v.splat      v2, s11
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s14, v4]              // index is in elements (ISA sec 9.1)
    s.addi       s14, s8, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s13, v4]              // index is in elements (ISA sec 9.1)
    v.mov        v1, v0
for_1:
    s.cmp.ge     s13, s14, s9
    br.nz        s13, endfor_2
    v.splat      v0, s14
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v6, s14
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s13, #1024
    s.movz       s15, #512
    s.movz       s16, #1024
    s.movz       s17, #512
    s.muli       s18, s11, #2048
    s.muli       s19, s11, #2048
    v.add        v8, v0, v4
    v.movi       v0, #0
    v.splat      v4, s13
    v.splat      v9, s11
    v.movi       v10, #0
    v.splat      v11, s15
    v.add        v12, v6, v7
    v.movi       v6, #0
    v.splat      v7, s16
    v.splat      v13, s11
    s.muli       s13, s14, #2
    s.muli       s15, s14, #2
    v.cmp.ge     p1, v8, v0
    v.movi       v0, #0
    v.cmp.lt     p2, v8, v4
    v.splat      v4, s17
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    v.cmp.ge     p5, v12, v6
    s.add        s16, s4, s18
    p.and        p6, p1, p2
    v.cmp.lt     p1, v12, v7
    p.and        p2, p3, p4
    v.cmp.ge     p3, v13, v0
    s.add        s17, s5, s19
    p.and        p4, p5, p1
    v.cmp.lt     p1, v13, v4
    p.and        p5, p3, p1
    s.add        s18, s16, s13
    p.and        p1, p6, p2
    s.add        s13, s17, s15
    p.and        p2, p4, p5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s18, #0]
    v.splat      v4, s14
    v.movi       v6, #1024
    v.add        v7, v4, v2
    v.movi       v4, #0
    v.cmp.lt     p1, v7, v6
    v.extract    s15, v5, #0
    v.extract    s16, v5, #0
    v.extract    s17, v3, #0
    s.shli       s18, s15, #32
    v.extract    s15, v3, #0
    s.shli       s19, s16, #32
    s.or         s16, s17, s18
    s.movz       s17, #0
    s.or         s18, s15, s19
    s.movz       s15, #32000
    v.movi       v6, #0
    s.cmp.ge     s19, s16, s17
    s.cmp.lt     s16, s18, s15
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v8, [s13, #0]
    v.insert     v4, s19, #0
    v.movi       v9, #0
    v.insert     v6, s16, #0
    v.movi       v10, #0
    v.cmp.ne     p2, v4, v9
    v.movi       v4, #0
    v.cmp.ne     p3, v6, v10
    v.movi       v6, #1
    p.and        p4, p2, p3
    vf.cvt.f16.f32 v9, v0
    s.movz       s13, #1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v10, s13
    @p4 v.sel        v11, v4, v6
    s.movz       s13, #0
    v.cmp.lt     p2, v0, v10
    @p2 v.reduce.or  s15, v11
    vf.cvt.f16.f32 v0, v8
    s.cmp.eq     s16, s15, s13
    br.nz        s16, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s13, v5, #0
    v.extract    s15, v3, #0
    s.shli       s16, s13, #32
    s.movz       s13, #1024
    s.or         s17, s15, s16
    v.extract    s15, v7, #0
    s.mul        s16, s17, s13
    s.shli       s13, s15, #32
    v.extract    s15, v7, #1
    s.ashri      s17, s13, #32
    v.movi       v4, #0
    v.movi       v6, #0
    v.movi       v8, #0
    v.movi       v10, #0
    s.shli       s13, s15, #32
    s.lshri      s15, s16, #32
    s.lshri      s18, s17, #32
    v.extract    s19, v7, #2
    s.ashri      s20, s13, #32
    v.insert     v4, s16, #0
    v.insert     v6, s15, #0
    v.insert     v8, s17, #0
    v.insert     v10, s18, #0
    s.shli       s13, s19, #32
    s.lshri      s15, s20, #32
    v.extract    s16, v7, #3
    s.ashri      s17, s13, #32
    v.insert     v8, s20, #1
    v.insert     v10, s15, #1
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v7, #4
    s.ashri      s18, s13, #32
    v.insert     v8, s17, #2
    v.insert     v10, s15, #2
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v7, #5
    s.ashri      s17, s13, #32
    v.insert     v8, s18, #3
    v.insert     v10, s15, #3
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v7, #6
    s.ashri      s18, s13, #32
    v.insert     v8, s17, #4
    v.insert     v10, s15, #4
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v7, #7
    s.ashri      s17, s13, #32
    v.insert     v8, s18, #5
    v.insert     v10, s15, #5
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v7, #8
    s.ashri      s18, s13, #32
    v.insert     v8, s17, #6
    v.insert     v10, s15, #6
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v7, #9
    s.ashri      s17, s13, #32
    v.insert     v8, s18, #7
    v.insert     v10, s15, #7
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v7, #10
    s.ashri      s18, s13, #32
    v.insert     v8, s17, #8
    v.insert     v10, s15, #8
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v7, #11
    s.ashri      s17, s13, #32
    v.insert     v8, s18, #9
    v.insert     v10, s15, #9
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v7, #12
    s.ashri      s18, s13, #32
    v.insert     v8, s17, #10
    v.insert     v10, s15, #10
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v7, #13
    s.ashri      s17, s13, #32
    v.insert     v8, s18, #11
    v.insert     v10, s15, #11
    s.shli       s13, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v7, #14
    s.ashri      s18, s13, #32
    v.insert     v8, s17, #12
    v.insert     v10, s15, #12
    s.shli       s13, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v7, #15
    v.extract    s17, v6, #0
    s.ashri      s19, s13, #32
    v.insert     v8, s18, #13
    v.insert     v10, s15, #13
    s.shli       s13, s16, #32
    v.extract    s15, v4, #0
    s.shli       s16, s17, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v6, #0
    s.ashri      s20, s13, #32
    s.or         s13, s15, s16
    v.insert     v8, s19, #14
    v.insert     v10, s17, #14
    v.movi       v7, #0
    v.movi       v11, #0
    v.extract    s15, v4, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    s.lshri      s18, s13, #32
    v.extract    s19, v6, #0
    s.or         s21, s15, s16
    v.insert     v8, s20, #15
    v.insert     v10, s17, #15
    v.insert     v7, s13, #0
    v.insert     v11, s18, #0
    v.extract    s13, v4, #0
    s.shli       s15, s19, #32
    s.lshri      s16, s21, #32
    v.extract    s17, v6, #0
    s.or         s18, s13, s15
    v.insert     v7, s21, #1
    v.insert     v11, s16, #1
    v.extract    s13, v4, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v6, #0
    s.or         s19, s13, s15
    v.insert     v7, s18, #2
    v.insert     v11, s16, #2
    v.extract    s13, v4, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v6, #0
    s.or         s18, s13, s15
    v.insert     v7, s19, #3
    v.insert     v11, s16, #3
    v.extract    s13, v4, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v6, #0
    s.or         s19, s13, s15
    v.insert     v7, s18, #4
    v.insert     v11, s16, #4
    v.extract    s13, v4, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v6, #0
    s.or         s18, s13, s15
    v.insert     v7, s19, #5
    v.insert     v11, s16, #5
    v.extract    s13, v4, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v6, #0
    s.or         s19, s13, s15
    v.insert     v7, s18, #6
    v.insert     v11, s16, #6
    v.extract    s13, v4, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v6, #0
    s.or         s18, s13, s15
    v.insert     v7, s19, #7
    v.insert     v11, s16, #7
    v.extract    s13, v4, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v6, #0
    s.or         s19, s13, s15
    v.insert     v7, s18, #8
    v.insert     v11, s16, #8
    v.extract    s13, v4, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v6, #0
    s.or         s18, s13, s15
    v.insert     v7, s19, #9
    v.insert     v11, s16, #9
    v.extract    s13, v4, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v6, #0
    s.or         s19, s13, s15
    v.insert     v7, s18, #10
    v.insert     v11, s16, #10
    v.extract    s13, v4, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v6, #0
    s.or         s18, s13, s15
    v.insert     v7, s19, #11
    v.insert     v11, s16, #11
    v.extract    s13, v4, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v6, #0
    s.or         s19, s13, s15
    v.insert     v7, s18, #12
    v.insert     v11, s16, #12
    v.extract    s13, v4, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v6, #0
    s.or         s18, s13, s15
    v.insert     v7, s19, #13
    v.insert     v11, s16, #13
    v.extract    s13, v4, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    s.or         s17, s13, s15
    v.insert     v7, s18, #14
    v.insert     v11, s16, #14
    s.lshri      s13, s17, #32
    v.insert     v7, s17, #15
    v.insert     v11, s13, #15
    v.extract    s13, v10, #0
    v.extract    s15, v8, #0
    v.extract    s16, v11, #0
    s.shli       s17, s13, #32
    v.extract    s13, v7, #0
    s.shli       s18, s16, #32
    v.extract    s16, v10, #1
    v.extract    s19, v11, #1
    s.or         s20, s15, s17
    s.or         s15, s13, s18
    v.movi       v4, #0
    v.extract    s13, v8, #1
    s.shli       s17, s16, #32
    v.extract    s16, v7, #1
    s.shli       s18, s19, #32
    s.add        s19, s20, s15
    v.extract    s15, v10, #2
    v.extract    s20, v11, #2
    s.or         s21, s13, s17
    s.or         s13, s16, s18
    v.movi       v6, #0
    v.insert     v4, s19, #0
    v.extract    s16, v8, #2
    s.shli       s17, s15, #32
    v.extract    s15, v7, #2
    s.shli       s18, s20, #32
    s.lshri      s20, s19, #32
    s.add        s19, s21, s13
    v.extract    s13, v10, #3
    s.or         s21, s16, s17
    v.extract    s16, v11, #3
    s.or         s17, s15, s18
    v.insert     v6, s20, #0
    v.insert     v4, s19, #1
    v.extract    s15, v8, #3
    s.shli       s18, s13, #32
    v.extract    s13, v7, #3
    s.shli       s20, s16, #32
    s.lshri      s16, s19, #32
    s.add        s19, s21, s17
    v.extract    s17, v10, #4
    s.or         s21, s15, s18
    v.extract    s15, v11, #4
    s.or         s18, s13, s20
    v.insert     v6, s16, #1
    v.insert     v4, s19, #2
    v.extract    s13, v8, #4
    s.shli       s16, s17, #32
    v.extract    s17, v7, #4
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s18
    v.extract    s18, v10, #5
    s.or         s21, s13, s16
    v.extract    s13, v11, #5
    s.or         s16, s17, s20
    v.insert     v6, s15, #2
    v.insert     v4, s19, #3
    v.extract    s15, v8, #5
    s.shli       s17, s18, #32
    v.extract    s18, v7, #5
    s.shli       s20, s13, #32
    s.lshri      s13, s19, #32
    s.add        s19, s21, s16
    v.extract    s16, v10, #6
    s.or         s21, s15, s17
    v.extract    s15, v11, #6
    s.or         s17, s18, s20
    v.insert     v6, s13, #3
    v.insert     v4, s19, #4
    v.extract    s13, v8, #6
    s.shli       s18, s16, #32
    v.extract    s16, v7, #6
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s17
    v.extract    s17, v10, #7
    s.or         s21, s13, s18
    v.extract    s13, v11, #7
    s.or         s18, s16, s20
    v.insert     v6, s15, #4
    v.insert     v4, s19, #5
    v.extract    s15, v8, #7
    s.shli       s16, s17, #32
    v.extract    s17, v7, #7
    s.shli       s20, s13, #32
    s.lshri      s13, s19, #32
    s.add        s19, s21, s18
    v.extract    s18, v10, #8
    s.or         s21, s15, s16
    v.extract    s15, v11, #8
    s.or         s16, s17, s20
    v.insert     v6, s13, #5
    v.insert     v4, s19, #6
    v.extract    s13, v8, #8
    s.shli       s17, s18, #32
    v.extract    s18, v7, #8
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s16
    v.extract    s16, v10, #9
    s.or         s21, s13, s17
    v.extract    s13, v11, #9
    s.or         s17, s18, s20
    v.insert     v6, s15, #6
    v.insert     v4, s19, #7
    v.extract    s15, v8, #9
    s.shli       s18, s16, #32
    v.extract    s16, v7, #9
    s.shli       s20, s13, #32
    s.lshri      s13, s19, #32
    s.add        s19, s21, s17
    v.extract    s17, v10, #10
    s.or         s21, s15, s18
    v.extract    s15, v11, #10
    s.or         s18, s16, s20
    v.insert     v6, s13, #7
    v.insert     v4, s19, #8
    v.extract    s13, v8, #10
    s.shli       s16, s17, #32
    v.extract    s17, v7, #10
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s18
    v.extract    s18, v10, #11
    s.or         s21, s13, s16
    v.extract    s13, v11, #11
    s.or         s16, s17, s20
    v.insert     v6, s15, #8
    v.insert     v4, s19, #9
    v.extract    s15, v8, #11
    s.shli       s17, s18, #32
    v.extract    s18, v7, #11
    s.shli       s20, s13, #32
    s.lshri      s13, s19, #32
    s.add        s19, s21, s16
    v.extract    s16, v10, #12
    s.or         s21, s15, s17
    v.extract    s15, v11, #12
    s.or         s17, s18, s20
    v.insert     v6, s13, #9
    v.insert     v4, s19, #10
    v.extract    s13, v8, #12
    s.shli       s18, s16, #32
    v.extract    s16, v7, #12
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s17
    v.extract    s17, v10, #13
    s.or         s21, s13, s18
    v.extract    s13, v11, #13
    s.or         s18, s16, s20
    v.insert     v6, s15, #10
    v.insert     v4, s19, #11
    v.extract    s15, v8, #13
    s.shli       s16, s17, #32
    v.extract    s17, v7, #13
    s.shli       s20, s13, #32
    s.lshri      s13, s19, #32
    s.add        s19, s21, s18
    v.extract    s18, v10, #14
    s.or         s21, s15, s16
    v.extract    s15, v11, #14
    s.or         s16, s17, s20
    v.insert     v6, s13, #11
    v.insert     v4, s19, #12
    v.extract    s13, v8, #14
    s.shli       s17, s18, #32
    v.extract    s18, v7, #14
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s16
    v.extract    s16, v10, #15
    s.or         s21, s13, s17
    v.extract    s13, v11, #15
    s.or         s17, s18, s20
    v.insert     v6, s15, #12
    v.insert     v4, s19, #13
    v.extract    s15, v8, #15
    s.shli       s18, s16, #32
    v.extract    s16, v7, #15
    s.shli       s20, s13, #32
    s.lshri      s13, s19, #32
    s.add        s19, s21, s17
    s.or         s17, s15, s18
    s.or         s15, s16, s20
    v.insert     v6, s13, #13
    v.insert     v4, s19, #14
    s.lshri      s13, s19, #32
    s.add        s16, s17, s15
    v.insert     v6, s13, #14
    v.insert     v4, s16, #15
    v.movi       v7, #31
    s.lshri      s13, s16, #32
    v.movi       v8, #1
    v.insert     v6, s13, #15
    v.ashr       v10, v4, v7
    v.movi       v7, #0
    s.movz       s13, #0
    v.cmp.ne     p2, v6, v10
    @p2 v.sel        v6, v8, v7
    v.reduce.or  s15, v6
    s.cmp.eq     s16, s15, s13
    br.nz        s16, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v6, [s3, v4]               // index is in elements (ISA sec 9.1)
    v.movi       v4, #0
    s.add        s13, s14, s10
    s.movz       s15, #1
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v7, v9
    vf.add       v7, v6, v0
    vf.mul       v0, v7, v7
    vf.add       v6, v1, v0
    @p1 v.sel        v0, v6, v1
    v.mov        v4, v0
    v.mov        v1, v4
    s.mov        s14, s13
    br.nz        s15, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.addi       s13, s8, #0
    vf.add       v4, v0, v1
for_5:
    s.cmp.ge     s14, s13, s9
    br.nz        s14, endfor_6
    v.splat      v0, s13
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v6, s13
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s14, #1024
    s.movz       s15, #512
    s.movz       s16, #1024
    s.movz       s17, #512
    s.muli       s18, s11, #2048
    s.muli       s19, s11, #2048
    v.add        v8, v0, v1
    v.movi       v0, #0
    v.splat      v1, s14
    v.splat      v9, s11
    v.movi       v10, #0
    v.splat      v11, s15
    v.add        v12, v6, v7
    v.movi       v6, #0
    v.splat      v7, s16
    v.splat      v13, s11
    v.movi       v14, #0
    s.muli       s14, s13, #2
    s.muli       s15, s13, #2
    v.cmp.ge     p1, v8, v0
    v.splat      v0, s17
    v.cmp.lt     p2, v8, v1
    v.splat      v1, s13
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    v.cmp.ge     p5, v12, v6
    v.add        v6, v1, v2
    v.movi       v1, #1024
    s.add        s16, s4, s18
    p.and        p6, p1, p2
    v.cmp.lt     p1, v12, v7
    p.and        p2, p3, p4
    v.cmp.ge     p3, v13, v14
    s.add        s17, s5, s19
    p.and        p4, p5, p1
    v.cmp.lt     p1, v13, v0
    p.and        p5, p3, p1
    s.shli       s18, s13, #1                    // element offset -> bytes (x2)
    s.add        s19, s16, s14
    p.and        p1, p6, p2
    s.add        s14, s17, s15
    p.and        p2, p4, p5
    v.cmp.lt     p3, v6, v1
    v.extract    s15, v5, #0
    v.extract    s16, v5, #0
    v.extract    s17, v3, #0
    s.shli       s20, s15, #32
    s.shli       s15, s16, #32
    s.or         s16, s17, s20
    v.extract    s17, v3, #0
    s.add        s20, s6, s18                    // &in_ptr4[...]
    s.or         s18, s17, s15
    s.movz       s15, #0
    v.movi       v0, #0
    v.movi       v1, #0
    s.cmp.ge     s17, s16, s15
    s.movz       s15, #32000
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v7, [s19, #0]
    s.cmp.lt     s16, s18, s15
    v.movi       v8, #0
    v.movi       v9, #0
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v10, [s14, #0]
    vf.cvt.f16.f32 v11, v7
    v.movi       v7, #0
    v.movi       v12, #1
    s.movz       s14, #1
    v.iota       v13                             // arange(0, VLEN)
    v.splat      v14, s14
    s.movz       s14, #0
    v.cmp.lt     p1, v13, v14
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v13, [s20, #0]
    v.insert     v0, s17, #0
    v.insert     v1, s16, #0
    vf.cvt.f16.f32 v14, v10
    v.cmp.ne     p2, v0, v8
    v.cmp.ne     p4, v1, v9
    p.and        p5, p2, p4
    @p5 v.sel        v0, v7, v12
    @p1 v.reduce.or  s15, v0
    s.cmp.eq     s16, s15, s14
    vf.cvt.f16.f32 v0, v13
    br.nz        s16, assert_ok_7
    trap         #677351
assert_ok_7:
    v.extract    s14, v5, #0
    v.extract    s15, v3, #0
    s.shli       s16, s14, #32
    s.movz       s14, #1024
    s.or         s17, s15, s16
    v.extract    s15, v6, #0
    s.mul        s16, s17, s14
    s.shli       s14, s15, #32
    v.extract    s15, v6, #1
    s.ashri      s17, s14, #32
    v.movi       v1, #0
    v.movi       v7, #0
    v.movi       v8, #0
    v.movi       v9, #0
    s.shli       s14, s15, #32
    s.lshri      s15, s16, #32
    s.lshri      s18, s17, #32
    v.extract    s19, v6, #2
    s.ashri      s20, s14, #32
    v.insert     v1, s16, #0
    v.insert     v7, s15, #0
    v.insert     v8, s17, #0
    v.insert     v9, s18, #0
    s.shli       s14, s19, #32
    s.lshri      s15, s20, #32
    v.extract    s16, v6, #3
    s.ashri      s17, s14, #32
    v.insert     v8, s20, #1
    v.insert     v9, s15, #1
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #4
    s.ashri      s18, s14, #32
    v.insert     v8, s17, #2
    v.insert     v9, s15, #2
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #5
    s.ashri      s17, s14, #32
    v.insert     v8, s18, #3
    v.insert     v9, s15, #3
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #6
    s.ashri      s18, s14, #32
    v.insert     v8, s17, #4
    v.insert     v9, s15, #4
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #7
    s.ashri      s17, s14, #32
    v.insert     v8, s18, #5
    v.insert     v9, s15, #5
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #8
    s.ashri      s18, s14, #32
    v.insert     v8, s17, #6
    v.insert     v9, s15, #6
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #9
    s.ashri      s17, s14, #32
    v.insert     v8, s18, #7
    v.insert     v9, s15, #7
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #10
    s.ashri      s18, s14, #32
    v.insert     v8, s17, #8
    v.insert     v9, s15, #8
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #11
    s.ashri      s17, s14, #32
    v.insert     v8, s18, #9
    v.insert     v9, s15, #9
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #12
    s.ashri      s18, s14, #32
    v.insert     v8, s17, #10
    v.insert     v9, s15, #10
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #13
    s.ashri      s17, s14, #32
    v.insert     v8, s18, #11
    v.insert     v9, s15, #11
    s.shli       s14, s16, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v6, #14
    s.ashri      s18, s14, #32
    v.insert     v8, s17, #12
    v.insert     v9, s15, #12
    s.shli       s14, s16, #32
    s.lshri      s15, s18, #32
    v.extract    s16, v6, #15
    v.extract    s17, v7, #0
    s.ashri      s19, s14, #32
    v.insert     v8, s18, #13
    v.insert     v9, s15, #13
    s.shli       s14, s16, #32
    v.extract    s15, v1, #0
    s.shli       s16, s17, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v7, #0
    s.ashri      s20, s14, #32
    s.or         s14, s15, s16
    v.insert     v8, s19, #14
    v.insert     v9, s17, #14
    v.movi       v10, #0
    v.movi       v12, #0
    v.extract    s15, v1, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    s.lshri      s18, s14, #32
    v.extract    s19, v7, #0
    s.or         s21, s15, s16
    v.insert     v8, s20, #15
    v.insert     v9, s17, #15
    v.insert     v10, s14, #0
    v.insert     v12, s18, #0
    v.extract    s14, v1, #0
    s.shli       s15, s19, #32
    s.lshri      s16, s21, #32
    v.extract    s17, v7, #0
    s.or         s18, s14, s15
    v.insert     v10, s21, #1
    v.insert     v12, s16, #1
    v.extract    s14, v1, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v7, #0
    s.or         s19, s14, s15
    v.insert     v10, s18, #2
    v.insert     v12, s16, #2
    v.extract    s14, v1, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v7, #0
    s.or         s18, s14, s15
    v.insert     v10, s19, #3
    v.insert     v12, s16, #3
    v.extract    s14, v1, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v7, #0
    s.or         s19, s14, s15
    v.insert     v10, s18, #4
    v.insert     v12, s16, #4
    v.extract    s14, v1, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v7, #0
    s.or         s18, s14, s15
    v.insert     v10, s19, #5
    v.insert     v12, s16, #5
    v.extract    s14, v1, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v7, #0
    s.or         s19, s14, s15
    v.insert     v10, s18, #6
    v.insert     v12, s16, #6
    v.extract    s14, v1, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v7, #0
    s.or         s18, s14, s15
    v.insert     v10, s19, #7
    v.insert     v12, s16, #7
    v.extract    s14, v1, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v7, #0
    s.or         s19, s14, s15
    v.insert     v10, s18, #8
    v.insert     v12, s16, #8
    v.extract    s14, v1, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v7, #0
    s.or         s18, s14, s15
    v.insert     v10, s19, #9
    v.insert     v12, s16, #9
    v.extract    s14, v1, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v7, #0
    s.or         s19, s14, s15
    v.insert     v10, s18, #10
    v.insert     v12, s16, #10
    v.extract    s14, v1, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v7, #0
    s.or         s18, s14, s15
    v.insert     v10, s19, #11
    v.insert     v12, s16, #11
    v.extract    s14, v1, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v7, #0
    s.or         s19, s14, s15
    v.insert     v10, s18, #12
    v.insert     v12, s16, #12
    v.extract    s14, v1, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v7, #0
    s.or         s18, s14, s15
    v.insert     v10, s19, #13
    v.insert     v12, s16, #13
    v.extract    s14, v1, #0
    s.shli       s15, s17, #32
    s.lshri      s16, s18, #32
    s.or         s17, s14, s15
    v.insert     v10, s18, #14
    v.insert     v12, s16, #14
    s.lshri      s14, s17, #32
    v.insert     v10, s17, #15
    v.insert     v12, s14, #15
    v.extract    s14, v9, #0
    v.extract    s15, v8, #0
    v.extract    s16, v12, #0
    s.shli       s17, s14, #32
    v.extract    s14, v10, #0
    s.shli       s18, s16, #32
    v.extract    s16, v9, #1
    v.extract    s19, v12, #1
    s.or         s20, s15, s17
    s.or         s15, s14, s18
    v.movi       v1, #0
    v.extract    s14, v8, #1
    s.shli       s17, s16, #32
    v.extract    s16, v10, #1
    s.shli       s18, s19, #32
    s.add        s19, s20, s15
    v.extract    s15, v9, #2
    v.extract    s20, v12, #2
    s.or         s21, s14, s17
    s.or         s14, s16, s18
    v.movi       v7, #0
    v.insert     v1, s19, #0
    v.extract    s16, v8, #2
    s.shli       s17, s15, #32
    v.extract    s15, v10, #2
    s.shli       s18, s20, #32
    s.lshri      s20, s19, #32
    s.add        s19, s21, s14
    v.extract    s14, v9, #3
    s.or         s21, s16, s17
    v.extract    s16, v12, #3
    s.or         s17, s15, s18
    v.insert     v7, s20, #0
    v.insert     v1, s19, #1
    v.extract    s15, v8, #3
    s.shli       s18, s14, #32
    v.extract    s14, v10, #3
    s.shli       s20, s16, #32
    s.lshri      s16, s19, #32
    s.add        s19, s21, s17
    v.extract    s17, v9, #4
    s.or         s21, s15, s18
    v.extract    s15, v12, #4
    s.or         s18, s14, s20
    v.insert     v7, s16, #1
    v.insert     v1, s19, #2
    v.extract    s14, v8, #4
    s.shli       s16, s17, #32
    v.extract    s17, v10, #4
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s18
    v.extract    s18, v9, #5
    s.or         s21, s14, s16
    v.extract    s14, v12, #5
    s.or         s16, s17, s20
    v.insert     v7, s15, #2
    v.insert     v1, s19, #3
    v.extract    s15, v8, #5
    s.shli       s17, s18, #32
    v.extract    s18, v10, #5
    s.shli       s20, s14, #32
    s.lshri      s14, s19, #32
    s.add        s19, s21, s16
    v.extract    s16, v9, #6
    s.or         s21, s15, s17
    v.extract    s15, v12, #6
    s.or         s17, s18, s20
    v.insert     v7, s14, #3
    v.insert     v1, s19, #4
    v.extract    s14, v8, #6
    s.shli       s18, s16, #32
    v.extract    s16, v10, #6
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s17
    v.extract    s17, v9, #7
    s.or         s21, s14, s18
    v.extract    s14, v12, #7
    s.or         s18, s16, s20
    v.insert     v7, s15, #4
    v.insert     v1, s19, #5
    v.extract    s15, v8, #7
    s.shli       s16, s17, #32
    v.extract    s17, v10, #7
    s.shli       s20, s14, #32
    s.lshri      s14, s19, #32
    s.add        s19, s21, s18
    v.extract    s18, v9, #8
    s.or         s21, s15, s16
    v.extract    s15, v12, #8
    s.or         s16, s17, s20
    v.insert     v7, s14, #5
    v.insert     v1, s19, #6
    v.extract    s14, v8, #8
    s.shli       s17, s18, #32
    v.extract    s18, v10, #8
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s16
    v.extract    s16, v9, #9
    s.or         s21, s14, s17
    v.extract    s14, v12, #9
    s.or         s17, s18, s20
    v.insert     v7, s15, #6
    v.insert     v1, s19, #7
    v.extract    s15, v8, #9
    s.shli       s18, s16, #32
    v.extract    s16, v10, #9
    s.shli       s20, s14, #32
    s.lshri      s14, s19, #32
    s.add        s19, s21, s17
    v.extract    s17, v9, #10
    s.or         s21, s15, s18
    v.extract    s15, v12, #10
    s.or         s18, s16, s20
    v.insert     v7, s14, #7
    v.insert     v1, s19, #8
    v.extract    s14, v8, #10
    s.shli       s16, s17, #32
    v.extract    s17, v10, #10
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s18
    v.extract    s18, v9, #11
    s.or         s21, s14, s16
    v.extract    s14, v12, #11
    s.or         s16, s17, s20
    v.insert     v7, s15, #8
    v.insert     v1, s19, #9
    v.extract    s15, v8, #11
    s.shli       s17, s18, #32
    v.extract    s18, v10, #11
    s.shli       s20, s14, #32
    s.lshri      s14, s19, #32
    s.add        s19, s21, s16
    v.extract    s16, v9, #12
    s.or         s21, s15, s17
    v.extract    s15, v12, #12
    s.or         s17, s18, s20
    v.insert     v7, s14, #9
    v.insert     v1, s19, #10
    v.extract    s14, v8, #12
    s.shli       s18, s16, #32
    v.extract    s16, v10, #12
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s17
    v.extract    s17, v9, #13
    s.or         s21, s14, s18
    v.extract    s14, v12, #13
    s.or         s18, s16, s20
    v.insert     v7, s15, #10
    v.insert     v1, s19, #11
    v.extract    s15, v8, #13
    s.shli       s16, s17, #32
    v.extract    s17, v10, #13
    s.shli       s20, s14, #32
    s.lshri      s14, s19, #32
    s.add        s19, s21, s18
    v.extract    s18, v9, #14
    s.or         s21, s15, s16
    v.extract    s15, v12, #14
    s.or         s16, s17, s20
    v.insert     v7, s14, #11
    v.insert     v1, s19, #12
    v.extract    s14, v8, #14
    s.shli       s17, s18, #32
    v.extract    s18, v10, #14
    s.shli       s20, s15, #32
    s.lshri      s15, s19, #32
    s.add        s19, s21, s16
    v.extract    s16, v9, #15
    s.or         s21, s14, s17
    v.extract    s14, v12, #15
    s.or         s17, s18, s20
    v.insert     v7, s15, #12
    v.insert     v1, s19, #13
    v.extract    s15, v8, #15
    s.shli       s18, s16, #32
    v.extract    s16, v10, #15
    s.shli       s20, s14, #32
    s.lshri      s14, s19, #32
    s.add        s19, s21, s17
    s.or         s17, s15, s18
    s.or         s15, s16, s20
    v.insert     v7, s14, #13
    v.insert     v1, s19, #14
    s.lshri      s14, s19, #32
    s.add        s16, s17, s15
    v.insert     v7, s14, #14
    v.insert     v1, s16, #15
    v.movi       v8, #31
    s.lshri      s14, s16, #32
    v.movi       v9, #1
    v.insert     v7, s14, #15
    v.ashr       v10, v1, v8
    v.movi       v8, #0
    s.movz       s14, #0
    v.cmp.ne     p1, v7, v10
    @p1 v.sel        v7, v9, v8
    v.reduce.or  s15, v7
    s.cmp.eq     s16, s15, s14
    br.nz        s16, narrow_ok_8
    trap         #677220
narrow_ok_8:
    .li       s14, #1149239296
    v.splat      v7, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s14, #1065353216
    v.splat      v8, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s14, #925353388
    v.splat      v9, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v10, v7                         // ISA 8.8: <= 2**-22 relative
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v12, [s3, v1]              // index is in elements (ISA sec 9.1)
    .li       s14, #1077936128
    v.splat      v1, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s14, s11, s9
    s.add        s15, s13, s10
    s.movz       s16, #1
    s.add        s17, s13, s14
    s.shli       s18, s17, #1                    // element offset -> bytes (x2)
    s.add        s17, s7, s18                    // &out_ptr1[...]
    vf.cvt.f16.f32 v13, v12
    vf.add       v12, v13, v11
    .li       s18, #3204448256
    v.splat      v11, s18                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v13, v12, v14
    v.splat      v12, s14
    vf.fms       v14, v7, v10, v8
    v.add        v7, v6, v12
    vf.fms       v6, v10, v14, v10
    vf.neg       v7, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v6, v7, v10
    vf.mul       v7, v4, v6                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v6, v7, v9
    v.rsqrt.approx v7, v6                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v7, v7
    vf.mul       v9, v7, v11
    vf.fms       v10, v6, v8, v1
    vf.mul       v1, v9, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v6, v1, v7
    v.extract    s14, v6, #0
    v.splat      v1, s14
    vf.mul       v6, v13, v1
    vf.mul       v1, v6, v0
    vf.cvt.f32.f16 v0, v1
    @p3 v.st.h       [s17, #0], v0
    s.mov        s13, s15
    br.nz        s16, for_5
endfor_6:
__rctx_next:
    s.addi       s13, s11, #2                    // the next program of this context: + 2
    s.cmp.lt     s14, s13, s12
    s.mov        s11, s13
    br.nz        s14, __rctx_program
    exit
