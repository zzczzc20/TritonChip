    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #16
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #4
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s8, #0
    s.cmp.lt     s13, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s13
    s.sub        s11, s8, s9
    s.xor        s8, s12, s3
    s.muli       s9, s5, #16
    s.movz       s5, #0
    s.movz       s13, #1
    s.xor        s14, s4, s11
    s.sub        s15, s8, s3
    s.rdspecial  s3, arg_base
    s.xor        s8, s1, s7
    s.movz       s16, #0
    s.sub        s17, s14, s11
    s.addi       s14, s5, #0
    s.cmp.eq     s5, s15, s13
    s.ld.d       s13, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s18, s8, s7
    s.sub        s7, s2, s9
    s.addi       s2, s16, #0
    s.ld.d       s7, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s8, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s14, s17
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s14, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s17, s3
    s.shli       s9, s2, #1
    s.andi       s16, s5, #1
    s.movz       s5, #0
    s.or         s18, s9, s16
    s.movz       s9, #1
    s.cmp.geu    s16, s18, s15
    s.shl        s19, s9, s3
    s.sub        s9, s5, s16
    s.subi       s5, s3, #1
    s.and        s16, s15, s9
    s.and        s20, s19, s9
    s.sub        s9, s18, s16
    s.or         s16, s14, s20
    s.mov        s2, s9
    s.mov        s14, s16
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s3, s5
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s3
    s.movz       s3, #0
    s.sub        s14, s5, s9
    s.movz       s5, #0
    s.xor        s9, s4, s14
    s.movz       s4, #0
    s.sub        s15, s9, s14
    s.cmp.lt     s9, s12, s3
    s.lshri      s3, s15, #4
    s.movz       s16, #0
    s.muli       s17, s3, #16
    s.movz       s3, #0
    s.sub        s18, s4, s9
    s.movz       s4, #0
    s.cmp.lt     s9, s1, s16
    s.sub        s16, s15, s17
    s.xor        s15, s12, s18
    s.xor        s12, s16, s14
    s.xor        s16, s2, s11
    s.sub        s2, s12, s14
    s.sub        s12, s4, s9
    s.cmp.lt     s4, s2, s5
    s.sub        s5, s15, s18
    s.sub        s9, s3, s4
    s.movz       s3, #0
    s.xor        s4, s2, s9
    s.movz       s2, #1
    s.sub        s14, s16, s11
    s.xor        s11, s1, s12
    s.sub        s15, s4, s9
    s.movz       s4, #0
    s.addi       s16, s3, #0
    s.cmp.eq     s3, s5, s2
    s.add        s2, s10, s14
    s.sub        s10, s11, s12
    s.addi       s10, s4, #0
    s.mov        s16, s15
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s16, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s15, s3
    s.shli       s11, s10, #1
    s.andi       s12, s4, #1
    s.movz       s4, #0
    s.or         s14, s11, s12
    s.movz       s11, #1
    s.cmp.geu    s12, s14, s5
    s.shl        s17, s11, s3
    s.sub        s11, s4, s12
    s.subi       s4, s3, #1
    s.and        s12, s5, s11
    s.and        s19, s17, s11
    s.sub        s11, s14, s12
    s.or         s12, s16, s19
    s.mov        s10, s11
    s.mov        s16, s12
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s11, s3, s4
    br.nz        s11, sdiv_4
sdiv_done_3:
    s.xor        s3, s9, s18
    s.mul        s4, s2, s1
    s.xor        s5, s16, s3
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s9, s5, s3
    v.movi       v1, #5
    v.splat      v2, s4
    s.mul        s3, s9, s1
    v.movi       v3, #0
    v.add        v4, v2, v0
    s.movz       s1, #0
    v.splat      v2, s2
    v.splat      v5, s1
    v.splat      v6, s9
    v.splat      v7, s1
    v.splat      v8, s3
    v.sub        v9, v3, v4
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.cmp.ge     p3, v2, v5
    v.sub        v2, v3, v1
    v.cmp.ge     p3, v6, v7
    v.add        v5, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v4
    @p2 v.sel        v4, v2, v1
    v.movi       v1, #0
    v.movi       v2, #0
    s.movz       s2, #31
idiv_5:
    v.splat      v6, s2
    v.shl        v7, v2, v0
    v.cmp.lt     p2, v2, v3
    v.lshr       v8, v5, v6
    v.shl        v9, v0, v6
    s.subi       s5, s2, #1
    v.and        v6, v8, v0
    s.movz       s9, #0
    v.or         v8, v7, v6
    v.cmp.geu    p3, v8, v4
    p.or         p4, p2, p3
    v.sub        v6, v8, v4
    @p4 v.sel        v7, v9, v3
    @p4 v.sel        v9, v6, v8
    v.or         v6, v1, v7
    v.mov        v2, v9
    v.mov        v1, v6
    s.mov        s2, s5
    s.cmp.ge     s5, s2, s9
    br.nz        s5, idiv_5
    s.rdspecial  s2, pid.z
    s.rdspecial  s5, npid.y
    v.sub        v0, v3, v2
    s.mul        s9, s2, s5
    s.rdspecial  s2, pid.y
    @p1 v.sel        v1, v0, v2
    s.movz       s5, #7
    s.rdspecial  s10, arg_base
    s.add        s11, s2, s9
    s.movz       s2, #25
    s.min.s      s9, s11, s5
    s.ld.d       s12, [s10, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.extract    s10, v1, #0
    s.movz       s14, #5
    v.extract    s15, v1, #1
    v.extract    s16, v1, #2
    s.mul        s17, s9, s2
    v.splat      v0, s10
    v.splat      v2, s14
    v.splat      v3, s15
    v.splat      v4, s16
    s.rdspecial  s2, role_id
    s.movz       s10, #1024
    s.movz       s15, #0
    v.mul        v5, v0, v2
    v.iota       v0                              // arange(0, VLEN)
    v.mul        v6, v3, v2
    v.mul        v3, v4, v2
    s.mul        s16, s2, s10
    s.add        s2, s15, s17                    // the tile origin
    v.add        v4, v5, v0
    v.splat      v5, s2
    v.add        v7, v6, v0
    v.add        v6, v3, v0
    s.add        s2, s12, s16                    // this context's own scratch
    v.splat      v3, s1
    v.add        v8, v4, v5
    v.add        v4, v7, v5
    v.add        v7, v6, v5
    s.addi       s10, s2, #0
    v.add        v6, v3, v8
    v.add        v8, v3, v4
    s.addi       s12, s10, #64
    s.addi       s15, s10, #128
    v.st.w       [s10, #0], v6
    s.andi       s16, s3, #255
    v.add        v4, v3, v7
    v.splat      v6, s16
    v.iota       v7                              // arange(0, VLEN)
    s.addi       s17, s10, #192
    v.add        v9, v6, v7
    v.extract    s18, v1, #3
    v.extract    s19, v1, #4
    v.extract    s20, v1, #5
    v.extract    s21, v1, #6
    v.extract    s22, v1, #7
    v.splat      v6, s18
    v.splat      v7, s19
    v.splat      v9, s20
    v.splat      v10, s21
    v.mul        v11, v6, v2
    v.mul        v6, v7, v2
    v.mul        v7, v9, v2
    v.mul        v9, v10, v2
    v.add        v10, v11, v0
    v.add        v11, v6, v0
    v.add        v6, v7, v0
    v.add        v7, v9, v0
    v.add        v9, v10, v5
    v.add        v10, v11, v5
    v.add        v11, v6, v5
    v.add        v6, v7, v5
    v.add        v7, v3, v9
    v.add        v9, v3, v10
    v.add        v10, v3, v11
    v.add        v11, v3, v6
    s.addi       s18, s10, #256
    s.addi       s19, s10, #320
    s.addi       s20, s10, #384
    s.addi       s21, s10, #448
    v.st.w       [s12, #0], v8
    v.extract    s12, v1, #8
    v.splat      v6, s22
    s.addi       s22, s10, #512
    v.mul        v8, v6, v2
    v.add        v6, v8, v0
    v.add        v8, v6, v5
    v.add        v6, v3, v8
    v.st.w       [s15, #0], v4
    v.extract    s15, v1, #9
    v.splat      v4, s12
    s.addi       s12, s10, #576
    v.mul        v8, v4, v2
    v.add        v4, v8, v0
    v.add        v8, v4, v5
    v.add        v4, v3, v8
    v.st.w       [s17, #0], v7
    v.extract    s17, v1, #10
    v.splat      v7, s15
    s.addi       s15, s10, #640
    v.mul        v8, v7, v2
    v.add        v7, v8, v0
    v.add        v8, v7, v5
    v.add        v7, v3, v8
    v.st.w       [s18, #0], v9
    v.extract    s18, v1, #11
    v.splat      v8, s17
    s.addi       s17, s10, #704
    v.mul        v9, v8, v2
    v.add        v8, v9, v0
    v.add        v9, v8, v5
    v.add        v8, v3, v9
    v.st.w       [s19, #0], v10
    v.extract    s19, v1, #12
    v.splat      v9, s18
    s.addi       s18, s10, #768
    v.mul        v10, v9, v2
    v.add        v9, v10, v0
    v.add        v10, v9, v5
    v.add        v9, v3, v10
    v.st.w       [s20, #0], v11
    v.extract    s20, v1, #13
    v.splat      v10, s19
    s.addi       s19, s10, #832
    v.mul        v11, v10, v2
    v.add        v10, v11, v0
    v.add        v11, v10, v5
    v.add        v10, v3, v11
    v.st.w       [s21, #0], v6
    v.extract    s21, v1, #14
    v.splat      v6, s20
    s.addi       s20, s10, #896
    v.mul        v11, v6, v2
    v.add        v6, v11, v0
    v.add        v11, v6, v5
    v.add        v6, v3, v11
    v.st.w       [s22, #0], v4
    v.extract    s22, v1, #15
    v.splat      v1, s21
    v.splat      v4, s22
    s.addi       s21, s10, #960
    v.mul        v11, v1, v2
    v.mul        v1, v4, v2
    v.add        v4, v11, v0
    v.add        v11, v1, v0
    v.add        v1, v4, v5
    v.add        v4, v11, v5
    v.add        v5, v3, v1
    v.add        v1, v3, v4
    v.st.w       [s12, #0], v7
    s.addi       s10, s2, #0
    v.splat      v3, s14
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s12, #0
    s.movz       s22, #1280
    s.mul        s23, s9, s22
    v.st.w       [s15, #0], v8
    v.cmp.lt     p1, v0, v3
    s.addi       s9, s2, #64
    s.movz       s15, #1
    v.st.w       [s17, #0], v9
    s.addi       s17, s2, #128
    s.movz       s24, #2
    s.addi       s25, s2, #192
    s.movz       s26, #3
    v.st.w       [s18, #0], v10
    s.addi       s18, s2, #256
    s.movz       s27, #4
    s.movz       s28, #5
    v.st.w       [s19, #0], v6
    s.addi       s19, s2, #320
    v.st.w       [s20, #0], v5
    s.addi       s20, s2, #384
    v.st.w       [s21, #0], v1
    fence.acq_rel.device
    s.movz       s21, #6
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s2, #448
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s12, v3
    v.ld.w       v1, [s9, #0]
    s.movz       s9, #7
    s.addi       s12, s2, #512
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s15, v3
    v.ld.w       v1, [s17, #0]
    s.movz       s15, #8
    s.addi       s17, s2, #576
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s24, v3
    v.ld.w       v1, [s25, #0]
    s.movz       s24, #9
    s.addi       s25, s2, #640
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s26, v3
    v.ld.w       v1, [s18, #0]
    s.movz       s18, #10
    s.addi       s26, s2, #704
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s27, v3
    v.ld.w       v1, [s19, #0]
    s.movz       s19, #11
    s.addi       s27, s2, #768
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s28, v3
    v.ld.w       v1, [s20, #0]
    s.movz       s20, #12
    s.addi       s28, s2, #832
    s.muli       s29, s16, #4                    // a runtime tile origin, x4
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v1]              // index is in elements (ISA sec 9.1)
    s.add        s16, s7, s29                    // the tile origin
    s.movz       s7, #13
    a.vwrite     a0, s21, v3
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s2, #896
    s.movz       s21, #14
    s.addi       s29, s2, #960
    s.muli       s2, s23, #4                     // a runtime tile origin, x4
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    v.movi       v3, #0
    s.add        s23, s16, s2                    // the tile origin
    s.movz       s2, #15
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s9, v4
    v.ld.w       v1, [s12, #0]
    v.splat      v4, s1
    s.movz       s9, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s12, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s13, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v2
    a.vwrite     a0, s15, v5
    v.ld.w       v1, [s17, #0]
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s13, v1]              // index is in elements (ISA sec 9.1)
    s.addi       s15, s23, #1024                 // row 1
    a.vwrite     a0, s24, v4
    v.ld.w       v1, [s25, #0]
    v.splat      v4, s6
    v.cmp.lt     p3, v4, v2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s18, v4
    v.ld.w       v1, [s26, #0]
    s.movz       s16, #2
    s.addi       s17, s23, #2048                 // row 2
    v.splat      v4, s16
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s13, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p4, v4, v2
    a.vwrite     a0, s19, v5
    v.ld.w       v1, [s27, #0]
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s13, v1]              // index is in elements (ISA sec 9.1)
    s.addi       s18, s23, #3072                 // row 3
    a.vwrite     a0, s20, v4
    v.ld.w       v1, [s28, #0]
    s.movz       s19, #3
    v.splat      v4, s19
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s13, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s7, v5
    v.ld.w       v1, [s10, #0]
    s.movz       s7, #4
    s.addi       s10, s23, #4096                 // row 4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s13, v1]              // index is in elements (ISA sec 9.1)
    v.splat      v1, s7
    a.vwrite     a0, s21, v5
    v.ld.w       v5, [s29, #0]
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s13, v5]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v2
    a.vwrite     a0, s2, v6
    a.vread      v4, a0, s9
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s2, v4, #0
    v.extract    s9, v4, #1
    v.splat      v1, s2
    v.splat      v6, s9
    v.splat      v7, s14
    v.extract    s2, v4, #2
    s.addi       s9, s23, #5120                  // row 5
    s.movz       s13, #6
    v.splat      v8, s2
    v.splat      v9, s13
    v.extract    s2, v4, #3
    s.addi       s20, s23, #6144                 // row 6
    v.splat      v10, s2
    v.extract    s2, v4, #4
    v.extract    s21, v4, #5
    v.extract    s24, v4, #6
    vf.fma       v11, v1, v5, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s15, #0]
    v.cmp.lt     p3, v7, v2
    v.splat      v5, s5
    s.addi       s15, s23, #7168                 // row 7
    v.extract    s25, v4, #7
    v.extract    s26, v4, #8
    vf.fma       v7, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s17, #0]
    v.cmp.lt     p4, v9, v2
    s.movz       s17, #8
    v.splat      v6, s2
    v.splat      v9, s17
    s.addi       s2, s23, #8192                  // row 8
    v.extract    s27, v4, #9
    vf.fma       v11, v8, v1, v7
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s18, #0]
    v.cmp.lt     p1, v5, v2
    s.movz       s18, #9
    v.splat      v5, s21
    v.splat      v7, s18
    s.addi       s21, s23, #9216                 // row 9
    v.extract    s28, v4, #10
    vf.fma       v8, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s10, #0]
    v.cmp.lt     p2, v9, v2
    s.movz       s10, #10
    v.splat      v9, s24
    v.splat      v10, s10
    s.addi       s24, s23, #10240                // row 10
    vf.fma       v11, v6, v1, v8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s9, #0]
    v.cmp.lt     p3, v7, v2
    s.movz       s9, #11
    v.splat      v6, s25
    v.splat      v7, s9
    s.addi       s25, s23, #11264                // row 11
    vf.fma       v8, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s20, #0]
    v.cmp.lt     p4, v10, v2
    s.movz       s20, #12
    v.splat      v5, s26
    v.splat      v10, s20
    s.addi       s26, s23, #12288                // row 12
    vf.fma       v11, v9, v1, v8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s15, #0]
    v.cmp.lt     p1, v7, v2
    s.movz       s15, #13
    v.splat      v7, s27
    v.splat      v8, s15
    s.addi       s27, s23, #13312                // row 13
    vf.fma       v9, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s2, #0]
    v.cmp.lt     p2, v10, v2
    s.movz       s2, #14
    v.splat      v6, s28
    v.splat      v10, s2
    v.extract    s28, v4, #11
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p3, v8, v2
    s.addi       s21, s23, #14336                // row 14
    v.splat      v5, s28
    s.movz       s28, #15
    v.splat      v8, s28
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s24, v4, #12
    v.splat      v7, s1
    v.splat      v10, s24
    s.addi       s24, s23, #15360                // row 15
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p1, v8, v2
    v.extract    s25, v4, #13
    v.splat      v6, s6
    v.splat      v8, s25
    v.extract    s25, v4, #14
    vf.fma       v9, v5, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s26, #0]
    v.splat      v5, s25
    v.extract    s25, v4, #15
    s.movz       s26, #1
    v.splat      v4, s25
    v.cmp.lt     p2, v7, v2
    s.addi       s25, s23, #1024                 // row 1
    v.splat      v7, s16
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p3, v6, v2
    s.addi       s27, s23, #2048                 // row 2
    v.splat      v6, s19
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v9, [s21, #0]
    vf.fma       v10, v8, v1, v11
    v.cmp.lt     p4, v7, v2
    s.addi       s21, s23, #3072                 // row 3
    v.splat      v1, s7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v7, [s24, #0]
    vf.fma       v8, v5, v9, v10
    v.cmp.lt     p1, v6, v2
    s.addi       s24, s23, #4096                 // row 4
    v.splat      v5, s14
    vf.fma       v6, v4, v7, v8
    a.vwrite     a1, s12, v6
    a.vread      v4, a0, s26
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s12, v4, #0
    v.extract    s26, v4, #1
    v.splat      v1, s12
    v.splat      v7, s26
    v.extract    s12, v4, #2
    s.addi       s26, s23, #5120                 // row 5
    v.splat      v8, s12
    v.splat      v9, s13
    v.extract    s12, v4, #3
    v.splat      v10, s12
    s.addi       s12, s23, #6144                 // row 6
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s25, v4, #4
    v.splat      v5, s25
    v.extract    s25, v4, #5
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.splat      v7, s25
    v.extract    s25, v4, #6
    s.movz       s27, #1
    v.cmp.lt     p4, v9, v2
    v.splat      v9, s5
    vf.fma       v11, v8, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    s.addi       s21, s23, #7168                 // row 7
    v.cmp.lt     p1, v9, v2
    v.splat      v6, s17
    v.splat      v8, s18
    vf.fma       v9, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s24, #0]
    s.addi       s24, s23, #8192                 // row 8
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s25
    s.addi       s25, s23, #9216                 // row 9
    v.splat      v10, s10
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p3, v8, v2
    v.extract    s26, v4, #7
    v.splat      v5, s9
    v.splat      v8, s26
    s.addi       s26, s23, #10240                // row 10
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s12, v4, #8
    v.splat      v7, s20
    v.splat      v10, s12
    s.addi       s12, s23, #11264                // row 11
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s21, v4, #9
    v.splat      v5, s15
    v.splat      v6, s21
    s.addi       s21, s23, #12288                // row 12
    vf.fma       v9, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p2, v7, v2
    v.extract    s24, v4, #10
    v.splat      v7, s2
    v.splat      v8, s24
    s.addi       s24, s23, #13312                // row 13
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s25, v4, #11
    v.splat      v5, s28
    v.splat      v9, s25
    s.addi       s25, s23, #14336                // row 14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p4, v7, v2
    v.extract    s26, v4, #12
    v.splat      v6, s1
    v.splat      v7, s26
    s.addi       s26, s23, #15360                // row 15
    vf.fma       v11, v8, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s12, v4, #13
    v.splat      v5, s6
    v.splat      v8, s12
    v.extract    s12, v4, #14
    vf.fma       v10, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s21, #0]
    v.splat      v9, s12
    v.extract    s12, v4, #15
    s.movz       s21, #2
    v.splat      v4, s12
    v.cmp.lt     p2, v6, v2
    s.addi       s12, s23, #1024                 // row 1
    v.splat      v6, s16
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p3, v5, v2
    s.addi       s24, s23, #2048                 // row 2
    v.splat      v5, s19
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s25, #0]
    vf.fma       v10, v8, v1, v11
    v.cmp.lt     p4, v6, v2
    s.addi       s25, s23, #3072                 // row 3
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s26, #0]
    vf.fma       v8, v9, v7, v10
    v.cmp.lt     p1, v5, v2
    s.addi       s26, s23, #4096                 // row 4
    v.splat      v5, s14
    vf.fma       v7, v4, v6, v8
    a.vwrite     a1, s27, v7
    a.vread      v4, a0, s21
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s21, v4, #0
    v.extract    s27, v4, #1
    v.splat      v1, s21
    v.splat      v7, s27
    v.extract    s21, v4, #2
    s.addi       s27, s23, #5120                 // row 5
    v.splat      v8, s21
    v.splat      v9, s13
    v.extract    s21, v4, #3
    v.splat      v10, s21
    s.addi       s21, s23, #6144                 // row 6
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v4, #4
    v.splat      v5, s12
    v.extract    s12, v4, #5
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s24, #0]
    v.splat      v7, s12
    v.extract    s12, v4, #6
    s.movz       s24, #2
    v.cmp.lt     p4, v9, v2
    v.splat      v9, s5
    vf.fma       v11, v8, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s25, #0]
    s.addi       s25, s23, #7168                 // row 7
    v.cmp.lt     p1, v9, v2
    v.splat      v6, s17
    v.splat      v8, s18
    vf.fma       v9, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s26, #0]
    s.addi       s26, s23, #8192                 // row 8
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s12
    s.addi       s12, s23, #9216                 // row 9
    v.splat      v10, s10
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p3, v8, v2
    v.extract    s27, v4, #7
    v.splat      v5, s9
    v.splat      v8, s27
    s.addi       s27, s23, #10240                // row 10
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s21, v4, #8
    v.splat      v7, s20
    v.splat      v10, s21
    s.addi       s21, s23, #11264                // row 11
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s25, v4, #9
    v.splat      v5, s15
    v.splat      v6, s25
    s.addi       s25, s23, #12288                // row 12
    vf.fma       v9, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p2, v7, v2
    v.extract    s26, v4, #10
    v.splat      v7, s2
    v.splat      v8, s26
    s.addi       s26, s23, #13312                // row 13
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v4, #11
    v.splat      v5, s28
    v.splat      v9, s12
    s.addi       s12, s23, #14336                // row 14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p4, v7, v2
    v.extract    s27, v4, #12
    v.splat      v6, s1
    v.splat      v7, s27
    s.addi       s27, s23, #15360                // row 15
    vf.fma       v11, v8, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s21, v4, #13
    v.splat      v5, s6
    v.splat      v8, s21
    v.extract    s21, v4, #14
    vf.fma       v10, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s25, #0]
    v.splat      v9, s21
    v.extract    s21, v4, #15
    s.movz       s25, #3
    v.splat      v4, s21
    v.cmp.lt     p2, v6, v2
    s.addi       s21, s23, #1024                 // row 1
    v.splat      v6, s16
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p3, v5, v2
    s.addi       s26, s23, #2048                 // row 2
    v.splat      v5, s19
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s12, #0]
    vf.fma       v10, v8, v1, v11
    v.cmp.lt     p4, v6, v2
    s.addi       s12, s23, #3072                 // row 3
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s27, #0]
    vf.fma       v8, v9, v7, v10
    v.cmp.lt     p1, v5, v2
    s.addi       s27, s23, #4096                 // row 4
    v.splat      v5, s14
    vf.fma       v7, v4, v6, v8
    a.vwrite     a1, s24, v7
    a.vread      v4, a0, s25
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s24, v4, #0
    v.extract    s25, v4, #1
    v.splat      v1, s24
    v.splat      v7, s25
    v.extract    s24, v4, #2
    s.addi       s25, s23, #5120                 // row 5
    v.splat      v8, s24
    v.splat      v9, s13
    v.extract    s24, v4, #3
    v.splat      v10, s24
    s.addi       s24, s23, #6144                 // row 6
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s21, v4, #4
    v.splat      v5, s21
    v.extract    s21, v4, #5
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s26, #0]
    v.splat      v7, s21
    v.extract    s21, v4, #6
    s.movz       s26, #3
    v.cmp.lt     p4, v9, v2
    v.splat      v9, s5
    vf.fma       v11, v8, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s12, #0]
    s.addi       s12, s23, #7168                 // row 7
    v.cmp.lt     p1, v9, v2
    v.splat      v6, s17
    v.splat      v8, s18
    vf.fma       v9, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    s.addi       s27, s23, #8192                 // row 8
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s21
    s.addi       s21, s23, #9216                 // row 9
    v.splat      v10, s10
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p3, v8, v2
    v.extract    s25, v4, #7
    v.splat      v5, s9
    v.splat      v8, s25
    s.addi       s25, s23, #10240                // row 10
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s24, v4, #8
    v.splat      v7, s20
    v.splat      v10, s24
    s.addi       s24, s23, #11264                // row 11
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s12, v4, #9
    v.splat      v5, s15
    v.splat      v6, s12
    s.addi       s12, s23, #12288                // row 12
    vf.fma       v9, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p2, v7, v2
    v.extract    s27, v4, #10
    v.splat      v7, s2
    v.splat      v8, s27
    s.addi       s27, s23, #13312                // row 13
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s21, v4, #11
    v.splat      v5, s28
    v.splat      v9, s21
    s.addi       s21, s23, #14336                // row 14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p4, v7, v2
    v.extract    s25, v4, #12
    v.splat      v6, s1
    v.splat      v7, s25
    s.addi       s25, s23, #15360                // row 15
    vf.fma       v11, v8, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s24, v4, #13
    v.splat      v5, s6
    v.splat      v8, s24
    v.extract    s24, v4, #14
    vf.fma       v10, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s12, #0]
    v.splat      v9, s24
    v.extract    s12, v4, #15
    s.movz       s24, #4
    v.splat      v4, s12
    v.cmp.lt     p2, v6, v2
    s.addi       s12, s23, #1024                 // row 1
    v.splat      v6, s16
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p3, v5, v2
    s.addi       s27, s23, #2048                 // row 2
    v.splat      v5, s19
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s21, #0]
    vf.fma       v10, v8, v1, v11
    v.cmp.lt     p4, v6, v2
    s.addi       s21, s23, #3072                 // row 3
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s25, #0]
    vf.fma       v8, v9, v7, v10
    v.cmp.lt     p1, v5, v2
    s.addi       s25, s23, #4096                 // row 4
    v.splat      v5, s14
    vf.fma       v7, v4, v6, v8
    a.vwrite     a1, s26, v7
    a.vread      v4, a0, s24
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s24, v4, #0
    v.extract    s26, v4, #1
    v.splat      v1, s24
    v.splat      v7, s26
    v.extract    s24, v4, #2
    s.addi       s26, s23, #5120                 // row 5
    v.splat      v8, s24
    v.splat      v9, s13
    v.extract    s24, v4, #3
    v.splat      v10, s24
    s.addi       s24, s23, #6144                 // row 6
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v4, #4
    v.splat      v5, s12
    v.extract    s12, v4, #5
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.splat      v7, s12
    v.extract    s12, v4, #6
    s.movz       s27, #4
    v.cmp.lt     p4, v9, v2
    v.splat      v9, s5
    vf.fma       v11, v8, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    s.addi       s21, s23, #7168                 // row 7
    v.cmp.lt     p1, v9, v2
    v.splat      v6, s17
    v.splat      v8, s18
    vf.fma       v9, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s25, #0]
    s.addi       s25, s23, #8192                 // row 8
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s12
    s.addi       s12, s23, #9216                 // row 9
    v.splat      v10, s10
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p3, v8, v2
    v.extract    s26, v4, #7
    v.splat      v5, s9
    v.splat      v8, s26
    s.addi       s26, s23, #10240                // row 10
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s24, v4, #8
    v.splat      v7, s20
    v.splat      v10, s24
    s.addi       s24, s23, #11264                // row 11
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s21, v4, #9
    v.splat      v5, s15
    v.splat      v6, s21
    s.addi       s21, s23, #12288                // row 12
    vf.fma       v9, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p2, v7, v2
    v.extract    s25, v4, #10
    v.splat      v7, s2
    v.splat      v8, s25
    s.addi       s25, s23, #13312                // row 13
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v4, #11
    v.splat      v5, s28
    v.splat      v9, s12
    s.addi       s12, s23, #14336                // row 14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p4, v7, v2
    v.extract    s26, v4, #12
    v.splat      v6, s1
    v.splat      v7, s26
    s.addi       s26, s23, #15360                // row 15
    vf.fma       v11, v8, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s24, v4, #13
    v.splat      v5, s6
    v.splat      v8, s24
    v.extract    s24, v4, #14
    vf.fma       v10, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s21, #0]
    v.splat      v9, s24
    v.extract    s21, v4, #15
    s.movz       s24, #5
    v.splat      v4, s21
    v.cmp.lt     p2, v6, v2
    s.addi       s21, s23, #1024                 // row 1
    v.splat      v6, s16
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p3, v5, v2
    s.addi       s25, s23, #2048                 // row 2
    v.splat      v5, s19
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s12, #0]
    vf.fma       v10, v8, v1, v11
    v.cmp.lt     p4, v6, v2
    s.addi       s12, s23, #3072                 // row 3
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s26, #0]
    vf.fma       v8, v9, v7, v10
    v.cmp.lt     p1, v5, v2
    s.addi       s26, s23, #4096                 // row 4
    v.splat      v5, s14
    vf.fma       v7, v4, v6, v8
    a.vwrite     a1, s27, v7
    a.vread      v4, a0, s24
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s24, v4, #0
    v.extract    s27, v4, #1
    v.splat      v1, s24
    v.splat      v7, s27
    v.extract    s24, v4, #2
    s.addi       s27, s23, #5120                 // row 5
    v.splat      v8, s24
    v.splat      v9, s13
    v.extract    s24, v4, #3
    v.splat      v10, s24
    s.addi       s24, s23, #6144                 // row 6
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s21, v4, #4
    v.splat      v5, s21
    v.extract    s21, v4, #5
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s25, #0]
    v.splat      v7, s21
    v.extract    s21, v4, #6
    s.movz       s25, #5
    v.cmp.lt     p4, v9, v2
    v.splat      v9, s5
    vf.fma       v11, v8, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s12, #0]
    s.addi       s12, s23, #7168                 // row 7
    v.cmp.lt     p1, v9, v2
    v.splat      v6, s17
    v.splat      v8, s18
    vf.fma       v9, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s26, #0]
    s.addi       s26, s23, #8192                 // row 8
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s21
    s.addi       s21, s23, #9216                 // row 9
    v.splat      v10, s10
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p3, v8, v2
    v.extract    s27, v4, #7
    v.splat      v5, s9
    v.splat      v8, s27
    s.addi       s27, s23, #10240                // row 10
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s24, v4, #8
    v.splat      v7, s20
    v.splat      v10, s24
    s.addi       s24, s23, #11264                // row 11
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s12, v4, #9
    v.splat      v5, s15
    v.splat      v6, s12
    s.addi       s12, s23, #12288                // row 12
    vf.fma       v9, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p2, v7, v2
    v.extract    s26, v4, #10
    v.splat      v7, s2
    v.splat      v8, s26
    s.addi       s26, s23, #13312                // row 13
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s21, v4, #11
    v.splat      v5, s28
    v.splat      v9, s21
    s.addi       s21, s23, #14336                // row 14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p4, v7, v2
    v.extract    s27, v4, #12
    v.splat      v6, s1
    v.splat      v7, s27
    s.addi       s27, s23, #15360                // row 15
    vf.fma       v11, v8, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s24, v4, #13
    v.splat      v5, s6
    v.splat      v8, s24
    v.extract    s24, v4, #14
    vf.fma       v10, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s12, #0]
    v.splat      v9, s24
    v.extract    s12, v4, #15
    s.movz       s24, #6
    v.splat      v4, s12
    v.cmp.lt     p2, v6, v2
    s.addi       s12, s23, #1024                 // row 1
    v.splat      v6, s16
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p3, v5, v2
    s.addi       s26, s23, #2048                 // row 2
    v.splat      v5, s19
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s21, #0]
    vf.fma       v10, v8, v1, v11
    v.cmp.lt     p4, v6, v2
    s.addi       s21, s23, #3072                 // row 3
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s27, #0]
    vf.fma       v8, v9, v7, v10
    v.cmp.lt     p1, v5, v2
    s.addi       s27, s23, #4096                 // row 4
    v.splat      v5, s14
    vf.fma       v7, v4, v6, v8
    a.vwrite     a1, s25, v7
    a.vread      v4, a0, s24
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s24, v4, #0
    v.extract    s25, v4, #1
    v.splat      v1, s24
    v.splat      v7, s25
    v.extract    s24, v4, #2
    s.addi       s25, s23, #5120                 // row 5
    v.splat      v8, s24
    v.splat      v9, s13
    v.extract    s24, v4, #3
    v.splat      v10, s24
    s.addi       s24, s23, #6144                 // row 6
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v4, #4
    v.splat      v5, s12
    v.extract    s12, v4, #5
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s26, #0]
    v.splat      v7, s12
    v.extract    s12, v4, #6
    s.movz       s26, #6
    v.cmp.lt     p4, v9, v2
    v.splat      v9, s5
    vf.fma       v11, v8, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    s.addi       s21, s23, #7168                 // row 7
    v.cmp.lt     p1, v9, v2
    v.splat      v6, s17
    v.splat      v8, s18
    vf.fma       v9, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    s.addi       s27, s23, #8192                 // row 8
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s12
    s.addi       s12, s23, #9216                 // row 9
    v.splat      v10, s10
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p3, v8, v2
    v.extract    s25, v4, #7
    v.splat      v5, s9
    v.splat      v8, s25
    s.addi       s25, s23, #10240                // row 10
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s24, v4, #8
    v.splat      v7, s20
    v.splat      v10, s24
    s.addi       s24, s23, #11264                // row 11
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s21, v4, #9
    v.splat      v5, s15
    v.splat      v6, s21
    s.addi       s21, s23, #12288                // row 12
    vf.fma       v9, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p2, v7, v2
    v.extract    s27, v4, #10
    v.splat      v7, s2
    v.splat      v8, s27
    s.addi       s27, s23, #13312                // row 13
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v4, #11
    v.splat      v5, s28
    v.splat      v9, s12
    s.addi       s12, s23, #14336                // row 14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p4, v7, v2
    v.extract    s25, v4, #12
    v.splat      v6, s1
    v.splat      v7, s25
    s.addi       s25, s23, #15360                // row 15
    vf.fma       v11, v8, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s24, v4, #13
    v.splat      v5, s6
    v.splat      v8, s24
    v.extract    s24, v4, #14
    vf.fma       v10, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s21, #0]
    v.splat      v9, s24
    v.extract    s21, v4, #15
    s.movz       s24, #7
    v.splat      v4, s21
    v.cmp.lt     p2, v6, v2
    s.addi       s21, s23, #1024                 // row 1
    v.splat      v6, s16
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p3, v5, v2
    s.addi       s27, s23, #2048                 // row 2
    v.splat      v5, s19
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s12, #0]
    vf.fma       v10, v8, v1, v11
    v.cmp.lt     p4, v6, v2
    s.addi       s12, s23, #3072                 // row 3
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s25, #0]
    vf.fma       v8, v9, v7, v10
    v.cmp.lt     p1, v5, v2
    s.addi       s25, s23, #4096                 // row 4
    v.splat      v5, s14
    vf.fma       v7, v4, v6, v8
    a.vwrite     a1, s26, v7
    a.vread      v4, a0, s24
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s24, v4, #0
    v.extract    s26, v4, #1
    v.splat      v1, s24
    v.splat      v7, s26
    v.extract    s24, v4, #2
    s.addi       s26, s23, #5120                 // row 5
    v.splat      v8, s24
    v.splat      v9, s13
    v.extract    s24, v4, #3
    v.splat      v10, s24
    s.addi       s24, s23, #6144                 // row 6
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s21, v4, #4
    v.splat      v5, s21
    v.extract    s21, v4, #5
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.splat      v7, s21
    v.extract    s21, v4, #6
    s.movz       s27, #7
    v.cmp.lt     p4, v9, v2
    v.splat      v9, s5
    vf.fma       v11, v8, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s12, #0]
    s.addi       s12, s23, #7168                 // row 7
    v.cmp.lt     p1, v9, v2
    v.splat      v6, s17
    v.splat      v8, s18
    vf.fma       v9, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s25, #0]
    s.addi       s25, s23, #8192                 // row 8
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s21
    s.addi       s21, s23, #9216                 // row 9
    v.splat      v10, s10
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p3, v8, v2
    v.extract    s26, v4, #7
    v.splat      v5, s9
    v.splat      v8, s26
    s.addi       s26, s23, #10240                // row 10
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s24, v4, #8
    v.splat      v7, s20
    v.splat      v10, s24
    s.addi       s24, s23, #11264                // row 11
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s12, v4, #9
    v.splat      v5, s15
    v.splat      v6, s12
    s.addi       s12, s23, #12288                // row 12
    vf.fma       v9, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p2, v7, v2
    v.extract    s25, v4, #10
    v.splat      v7, s2
    v.splat      v8, s25
    s.addi       s25, s23, #13312                // row 13
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s21, v4, #11
    v.splat      v5, s28
    v.splat      v9, s21
    s.addi       s21, s23, #14336                // row 14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p4, v7, v2
    v.extract    s26, v4, #12
    v.splat      v6, s1
    v.splat      v7, s26
    s.addi       s26, s23, #15360                // row 15
    vf.fma       v11, v8, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s24, v4, #13
    v.splat      v5, s6
    v.splat      v8, s24
    v.extract    s24, v4, #14
    vf.fma       v10, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s12, #0]
    v.splat      v9, s24
    v.extract    s12, v4, #15
    s.movz       s24, #8
    v.splat      v4, s12
    v.cmp.lt     p2, v6, v2
    s.addi       s12, s23, #1024                 // row 1
    v.splat      v6, s16
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p3, v5, v2
    s.addi       s25, s23, #2048                 // row 2
    v.splat      v5, s19
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s21, #0]
    vf.fma       v10, v8, v1, v11
    v.cmp.lt     p4, v6, v2
    s.addi       s21, s23, #3072                 // row 3
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s26, #0]
    vf.fma       v8, v9, v7, v10
    v.cmp.lt     p1, v5, v2
    s.addi       s26, s23, #4096                 // row 4
    v.splat      v5, s14
    vf.fma       v7, v4, v6, v8
    a.vwrite     a1, s27, v7
    a.vread      v4, a0, s24
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s24, v4, #0
    v.extract    s27, v4, #1
    v.splat      v1, s24
    v.splat      v7, s27
    v.extract    s24, v4, #2
    s.addi       s27, s23, #5120                 // row 5
    v.splat      v8, s24
    v.splat      v9, s13
    v.extract    s24, v4, #3
    v.splat      v10, s24
    s.addi       s24, s23, #6144                 // row 6
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v4, #4
    v.splat      v5, s12
    v.extract    s12, v4, #5
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s25, #0]
    v.splat      v7, s12
    v.extract    s12, v4, #6
    s.movz       s25, #8
    v.cmp.lt     p4, v9, v2
    v.splat      v9, s5
    vf.fma       v11, v8, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    s.addi       s21, s23, #7168                 // row 7
    v.cmp.lt     p1, v9, v2
    v.splat      v6, s17
    v.splat      v8, s18
    vf.fma       v9, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s26, #0]
    s.addi       s26, s23, #8192                 // row 8
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s12
    s.addi       s12, s23, #9216                 // row 9
    v.splat      v10, s10
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p3, v8, v2
    v.extract    s27, v4, #7
    v.splat      v5, s9
    v.splat      v8, s27
    s.addi       s27, s23, #10240                // row 10
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s24, v4, #8
    v.splat      v7, s20
    v.splat      v10, s24
    s.addi       s24, s23, #11264                // row 11
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s21, v4, #9
    v.splat      v5, s15
    v.splat      v6, s21
    s.addi       s21, s23, #12288                // row 12
    vf.fma       v9, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p2, v7, v2
    v.extract    s26, v4, #10
    v.splat      v7, s2
    v.splat      v8, s26
    s.addi       s26, s23, #13312                // row 13
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v4, #11
    v.splat      v5, s28
    v.splat      v9, s12
    s.addi       s12, s23, #14336                // row 14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p4, v7, v2
    v.extract    s27, v4, #12
    v.splat      v6, s1
    v.splat      v7, s27
    s.addi       s27, s23, #15360                // row 15
    vf.fma       v11, v8, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s24, v4, #13
    v.splat      v5, s6
    v.splat      v8, s24
    v.extract    s24, v4, #14
    vf.fma       v10, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s21, #0]
    v.splat      v9, s24
    v.extract    s21, v4, #15
    s.movz       s24, #9
    v.splat      v4, s21
    v.cmp.lt     p2, v6, v2
    s.addi       s21, s23, #1024                 // row 1
    v.splat      v6, s16
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p3, v5, v2
    s.addi       s26, s23, #2048                 // row 2
    v.splat      v5, s19
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s12, #0]
    vf.fma       v10, v8, v1, v11
    v.cmp.lt     p4, v6, v2
    s.addi       s12, s23, #3072                 // row 3
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s27, #0]
    vf.fma       v8, v9, v7, v10
    v.cmp.lt     p1, v5, v2
    s.addi       s27, s23, #4096                 // row 4
    v.splat      v5, s14
    vf.fma       v7, v4, v6, v8
    a.vwrite     a1, s25, v7
    a.vread      v4, a0, s24
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s24, v4, #0
    v.extract    s25, v4, #1
    v.splat      v1, s24
    v.splat      v7, s25
    v.extract    s24, v4, #2
    s.addi       s25, s23, #5120                 // row 5
    v.splat      v8, s24
    v.splat      v9, s13
    v.extract    s24, v4, #3
    v.splat      v10, s24
    s.addi       s24, s23, #6144                 // row 6
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s21, v4, #4
    v.splat      v5, s21
    v.extract    s21, v4, #5
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s26, #0]
    v.splat      v7, s21
    v.extract    s21, v4, #6
    s.movz       s26, #9
    v.cmp.lt     p4, v9, v2
    v.splat      v9, s5
    vf.fma       v11, v8, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s12, #0]
    s.addi       s12, s23, #7168                 // row 7
    v.cmp.lt     p1, v9, v2
    v.splat      v6, s17
    v.splat      v8, s18
    vf.fma       v9, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    s.addi       s27, s23, #8192                 // row 8
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s21
    s.addi       s21, s23, #9216                 // row 9
    v.splat      v10, s10
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p3, v8, v2
    v.extract    s25, v4, #7
    v.splat      v5, s9
    v.splat      v8, s25
    s.addi       s25, s23, #10240                // row 10
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s24, v4, #8
    v.splat      v7, s20
    v.splat      v10, s24
    s.addi       s24, s23, #11264                // row 11
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s12, v4, #9
    v.splat      v5, s15
    v.splat      v6, s12
    s.addi       s12, s23, #12288                // row 12
    vf.fma       v9, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p2, v7, v2
    v.extract    s27, v4, #10
    v.splat      v7, s2
    v.splat      v8, s27
    s.addi       s27, s23, #13312                // row 13
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s21, v4, #11
    v.splat      v5, s28
    v.splat      v9, s21
    s.addi       s21, s23, #14336                // row 14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p4, v7, v2
    v.extract    s25, v4, #12
    v.splat      v6, s1
    v.splat      v7, s25
    s.addi       s25, s23, #15360                // row 15
    vf.fma       v11, v8, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s24, v4, #13
    v.splat      v5, s6
    v.splat      v8, s24
    v.extract    s24, v4, #14
    vf.fma       v10, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s12, #0]
    v.splat      v9, s24
    v.extract    s12, v4, #15
    s.movz       s24, #10
    v.splat      v4, s12
    v.cmp.lt     p2, v6, v2
    s.addi       s12, s23, #1024                 // row 1
    v.splat      v6, s16
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p3, v5, v2
    s.addi       s27, s23, #2048                 // row 2
    v.splat      v5, s19
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s21, #0]
    vf.fma       v10, v8, v1, v11
    v.cmp.lt     p4, v6, v2
    s.addi       s21, s23, #3072                 // row 3
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s25, #0]
    vf.fma       v8, v9, v7, v10
    v.cmp.lt     p1, v5, v2
    s.addi       s25, s23, #4096                 // row 4
    v.splat      v5, s14
    vf.fma       v7, v4, v6, v8
    a.vwrite     a1, s26, v7
    a.vread      v4, a0, s24
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s24, v4, #0
    v.extract    s26, v4, #1
    v.splat      v1, s24
    v.splat      v7, s26
    v.extract    s24, v4, #2
    s.addi       s26, s23, #5120                 // row 5
    v.splat      v8, s24
    v.splat      v9, s13
    v.extract    s24, v4, #3
    v.splat      v10, s24
    s.addi       s24, s23, #6144                 // row 6
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v4, #4
    v.splat      v5, s12
    v.extract    s12, v4, #5
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.splat      v7, s12
    v.extract    s12, v4, #6
    s.movz       s27, #10
    v.cmp.lt     p4, v9, v2
    v.splat      v9, s5
    vf.fma       v11, v8, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    s.addi       s21, s23, #7168                 // row 7
    v.cmp.lt     p1, v9, v2
    v.splat      v6, s17
    v.splat      v8, s18
    vf.fma       v9, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s25, #0]
    s.addi       s25, s23, #8192                 // row 8
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s12
    s.addi       s12, s23, #9216                 // row 9
    v.splat      v10, s10
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p3, v8, v2
    v.extract    s26, v4, #7
    v.splat      v5, s9
    v.splat      v8, s26
    s.addi       s26, s23, #10240                // row 10
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s24, v4, #8
    v.splat      v7, s20
    v.splat      v10, s24
    s.addi       s24, s23, #11264                // row 11
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s21, v4, #9
    v.splat      v5, s15
    v.splat      v6, s21
    s.addi       s21, s23, #12288                // row 12
    vf.fma       v9, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p2, v7, v2
    v.extract    s25, v4, #10
    v.splat      v7, s2
    v.splat      v8, s25
    s.addi       s25, s23, #13312                // row 13
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v4, #11
    v.splat      v5, s28
    v.splat      v9, s12
    s.addi       s12, s23, #14336                // row 14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p4, v7, v2
    v.extract    s26, v4, #12
    v.splat      v6, s1
    v.splat      v7, s26
    s.addi       s26, s23, #15360                // row 15
    vf.fma       v11, v8, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s24, v4, #13
    v.splat      v5, s6
    v.splat      v8, s24
    v.extract    s24, v4, #14
    vf.fma       v10, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s21, #0]
    v.splat      v9, s24
    v.extract    s21, v4, #15
    s.movz       s24, #11
    v.splat      v4, s21
    v.cmp.lt     p2, v6, v2
    s.addi       s21, s23, #1024                 // row 1
    v.splat      v6, s16
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p3, v5, v2
    s.addi       s25, s23, #2048                 // row 2
    v.splat      v5, s19
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s12, #0]
    vf.fma       v10, v8, v1, v11
    v.cmp.lt     p4, v6, v2
    s.addi       s12, s23, #3072                 // row 3
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s26, #0]
    vf.fma       v8, v9, v7, v10
    v.cmp.lt     p1, v5, v2
    s.addi       s26, s23, #4096                 // row 4
    v.splat      v5, s14
    vf.fma       v7, v4, v6, v8
    a.vwrite     a1, s27, v7
    a.vread      v4, a0, s24
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s24, v4, #0
    v.extract    s27, v4, #1
    v.splat      v1, s24
    v.splat      v7, s27
    v.extract    s24, v4, #2
    s.addi       s27, s23, #5120                 // row 5
    v.splat      v8, s24
    v.splat      v9, s13
    v.extract    s24, v4, #3
    v.splat      v10, s24
    s.addi       s24, s23, #6144                 // row 6
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s21, v4, #4
    v.splat      v5, s21
    v.extract    s21, v4, #5
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s25, #0]
    v.splat      v7, s21
    v.extract    s21, v4, #6
    s.movz       s25, #11
    v.cmp.lt     p4, v9, v2
    v.splat      v9, s5
    vf.fma       v11, v8, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s12, #0]
    s.addi       s12, s23, #7168                 // row 7
    v.cmp.lt     p1, v9, v2
    v.splat      v6, s17
    v.splat      v8, s18
    vf.fma       v9, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s26, #0]
    s.addi       s26, s23, #8192                 // row 8
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s21
    s.addi       s21, s23, #9216                 // row 9
    v.splat      v10, s10
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p3, v8, v2
    v.extract    s27, v4, #7
    v.splat      v5, s9
    v.splat      v8, s27
    s.addi       s27, s23, #10240                // row 10
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s24, v4, #8
    v.splat      v7, s20
    v.splat      v10, s24
    s.addi       s24, s23, #11264                // row 11
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s12, v4, #9
    v.splat      v5, s15
    v.splat      v6, s12
    s.addi       s12, s23, #12288                // row 12
    vf.fma       v9, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p2, v7, v2
    v.extract    s26, v4, #10
    v.splat      v7, s2
    v.splat      v8, s26
    s.addi       s26, s23, #13312                // row 13
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s21, v4, #11
    v.splat      v5, s28
    v.splat      v9, s21
    s.addi       s21, s23, #14336                // row 14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p4, v7, v2
    v.extract    s27, v4, #12
    v.splat      v6, s1
    v.splat      v7, s27
    s.addi       s27, s23, #15360                // row 15
    vf.fma       v11, v8, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s24, v4, #13
    v.splat      v5, s6
    v.splat      v8, s24
    v.extract    s24, v4, #14
    vf.fma       v10, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s12, #0]
    v.splat      v9, s24
    v.extract    s12, v4, #15
    s.movz       s24, #12
    v.splat      v4, s12
    v.cmp.lt     p2, v6, v2
    s.addi       s12, s23, #1024                 // row 1
    v.splat      v6, s16
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p3, v5, v2
    s.addi       s26, s23, #2048                 // row 2
    v.splat      v5, s19
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s21, #0]
    vf.fma       v10, v8, v1, v11
    v.cmp.lt     p4, v6, v2
    s.addi       s21, s23, #3072                 // row 3
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s27, #0]
    vf.fma       v8, v9, v7, v10
    v.cmp.lt     p1, v5, v2
    s.addi       s27, s23, #4096                 // row 4
    v.splat      v5, s14
    vf.fma       v7, v4, v6, v8
    a.vwrite     a1, s25, v7
    a.vread      v4, a0, s24
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s24, v4, #0
    v.extract    s25, v4, #1
    v.splat      v1, s24
    v.splat      v7, s25
    v.extract    s24, v4, #2
    s.addi       s25, s23, #5120                 // row 5
    v.splat      v8, s24
    v.splat      v9, s13
    v.extract    s24, v4, #3
    v.splat      v10, s24
    s.addi       s24, s23, #6144                 // row 6
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v4, #4
    v.splat      v5, s12
    v.extract    s12, v4, #5
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s26, #0]
    v.splat      v7, s12
    v.extract    s12, v4, #6
    s.movz       s26, #12
    v.cmp.lt     p4, v9, v2
    v.splat      v9, s5
    vf.fma       v11, v8, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    s.addi       s21, s23, #7168                 // row 7
    v.cmp.lt     p1, v9, v2
    v.splat      v6, s17
    v.splat      v8, s18
    vf.fma       v9, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    s.addi       s27, s23, #8192                 // row 8
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s12
    s.addi       s12, s23, #9216                 // row 9
    v.splat      v10, s10
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p3, v8, v2
    v.extract    s25, v4, #7
    v.splat      v5, s9
    v.splat      v8, s25
    s.addi       s25, s23, #10240                // row 10
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s24, v4, #8
    v.splat      v7, s20
    v.splat      v10, s24
    s.addi       s24, s23, #11264                // row 11
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s21, v4, #9
    v.splat      v5, s15
    v.splat      v6, s21
    s.addi       s21, s23, #12288                // row 12
    vf.fma       v9, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p2, v7, v2
    v.extract    s27, v4, #10
    v.splat      v7, s2
    v.splat      v8, s27
    s.addi       s27, s23, #13312                // row 13
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v4, #11
    v.splat      v5, s28
    v.splat      v9, s12
    s.addi       s12, s23, #14336                // row 14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p4, v7, v2
    v.extract    s25, v4, #12
    v.splat      v6, s1
    v.splat      v7, s25
    s.addi       s25, s23, #15360                // row 15
    vf.fma       v11, v8, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s24, v4, #13
    v.splat      v5, s6
    v.splat      v8, s24
    v.extract    s24, v4, #14
    vf.fma       v10, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s21, #0]
    v.splat      v9, s24
    v.extract    s21, v4, #15
    s.movz       s24, #13
    v.splat      v4, s21
    v.cmp.lt     p2, v6, v2
    s.addi       s21, s23, #1024                 // row 1
    v.splat      v6, s16
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p3, v5, v2
    s.addi       s27, s23, #2048                 // row 2
    v.splat      v5, s19
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s12, #0]
    vf.fma       v10, v8, v1, v11
    v.cmp.lt     p4, v6, v2
    s.addi       s12, s23, #3072                 // row 3
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s25, #0]
    vf.fma       v8, v9, v7, v10
    v.cmp.lt     p1, v5, v2
    s.addi       s25, s23, #4096                 // row 4
    v.splat      v5, s14
    vf.fma       v7, v4, v6, v8
    a.vwrite     a1, s26, v7
    a.vread      v4, a0, s24
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s24, v4, #0
    v.extract    s26, v4, #1
    v.splat      v1, s24
    v.splat      v7, s26
    v.extract    s24, v4, #2
    s.addi       s26, s23, #5120                 // row 5
    v.splat      v8, s24
    v.splat      v9, s13
    v.extract    s24, v4, #3
    v.splat      v10, s24
    s.addi       s24, s23, #6144                 // row 6
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s21, v4, #4
    v.splat      v5, s21
    v.extract    s21, v4, #5
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.splat      v7, s21
    v.extract    s21, v4, #6
    s.movz       s27, #13
    v.cmp.lt     p4, v9, v2
    v.splat      v9, s5
    vf.fma       v11, v8, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s12, #0]
    s.addi       s12, s23, #7168                 // row 7
    v.cmp.lt     p1, v9, v2
    v.splat      v6, s17
    v.splat      v8, s18
    vf.fma       v9, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s25, #0]
    s.addi       s25, s23, #8192                 // row 8
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s21
    s.addi       s21, s23, #9216                 // row 9
    v.splat      v10, s10
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p3, v8, v2
    v.extract    s26, v4, #7
    v.splat      v5, s9
    v.splat      v8, s26
    s.addi       s26, s23, #10240                // row 10
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s24, v4, #8
    v.splat      v7, s20
    v.splat      v10, s24
    s.addi       s24, s23, #11264                // row 11
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s12, v4, #9
    v.splat      v5, s15
    v.splat      v6, s12
    s.addi       s12, s23, #12288                // row 12
    vf.fma       v9, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p2, v7, v2
    v.extract    s25, v4, #10
    v.splat      v7, s2
    v.splat      v8, s25
    s.addi       s25, s23, #13312                // row 13
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s21, v4, #11
    v.splat      v5, s28
    v.splat      v9, s21
    s.addi       s21, s23, #14336                // row 14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p4, v7, v2
    v.extract    s26, v4, #12
    v.splat      v6, s1
    v.splat      v7, s26
    s.addi       s26, s23, #15360                // row 15
    vf.fma       v11, v8, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s24, v4, #13
    v.splat      v5, s6
    v.splat      v8, s24
    v.extract    s24, v4, #14
    vf.fma       v10, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s12, #0]
    v.splat      v9, s24
    v.extract    s12, v4, #15
    s.movz       s24, #14
    v.splat      v4, s12
    v.cmp.lt     p2, v6, v2
    s.addi       s12, s23, #1024                 // row 1
    v.splat      v6, s16
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s25, #0]
    v.cmp.lt     p3, v5, v2
    s.addi       s25, s23, #2048                 // row 2
    v.splat      v5, s19
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s21, #0]
    vf.fma       v10, v8, v1, v11
    v.cmp.lt     p4, v6, v2
    s.addi       s21, s23, #3072                 // row 3
    v.splat      v1, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s26, #0]
    vf.fma       v8, v9, v7, v10
    v.cmp.lt     p1, v5, v2
    s.addi       s26, s23, #4096                 // row 4
    v.splat      v5, s14
    vf.fma       v7, v4, v6, v8
    a.vwrite     a1, s27, v7
    a.vread      v4, a0, s24
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s24, v4, #0
    v.extract    s27, v4, #1
    v.splat      v1, s24
    v.splat      v7, s27
    v.extract    s24, v4, #2
    s.addi       s27, s23, #5120                 // row 5
    v.splat      v8, s24
    v.splat      v9, s13
    v.extract    s24, v4, #3
    v.splat      v10, s24
    s.addi       s24, s23, #6144                 // row 6
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v4, #4
    v.splat      v5, s12
    v.extract    s12, v4, #5
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s25, #0]
    v.splat      v7, s12
    v.extract    s12, v4, #6
    s.movz       s25, #14
    v.cmp.lt     p4, v9, v2
    v.splat      v9, s5
    vf.fma       v11, v8, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    s.addi       s21, s23, #7168                 // row 7
    v.cmp.lt     p1, v9, v2
    v.splat      v6, s17
    v.splat      v8, s18
    vf.fma       v9, v10, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s26, #0]
    s.addi       s26, s23, #8192                 // row 8
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s12
    s.addi       s12, s23, #9216                 // row 9
    v.splat      v10, s10
    vf.fma       v11, v5, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p3, v8, v2
    v.extract    s27, v4, #7
    v.splat      v5, s9
    v.splat      v8, s27
    s.addi       s27, s23, #10240                // row 10
    vf.fma       v9, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p4, v10, v2
    v.extract    s24, v4, #8
    v.splat      v7, s20
    v.splat      v10, s24
    s.addi       s24, s23, #11264                // row 11
    vf.fma       v11, v6, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p1, v5, v2
    v.extract    s21, v4, #9
    v.splat      v5, s15
    v.splat      v6, s21
    s.addi       s21, s23, #12288                // row 12
    vf.fma       v9, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p2, v7, v2
    v.extract    s26, v4, #10
    v.splat      v7, s2
    v.splat      v8, s26
    s.addi       s26, s23, #13312                // row 13
    vf.fma       v11, v10, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v4, #11
    v.splat      v5, s28
    v.splat      v9, s12
    s.addi       s12, s23, #14336                // row 14
    vf.fma       v10, v6, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p4, v7, v2
    v.extract    s27, v4, #12
    v.splat      v6, s1
    s.addi       s1, s23, #15360                 // row 15
    v.splat      v7, s27
    v.extract    s27, v4, #13
    vf.fma       v11, v8, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s24, #0]
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s27
    v.extract    s24, v4, #14
    v.extract    s27, v4, #15
    v.splat      v4, s24
    v.splat      v8, s27
    s.movz       s24, #15
    s.addi       s27, s23, #1024                 // row 1
    vf.fma       v10, v9, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s21, #0]
    v.cmp.lt     p2, v6, v2
    v.splat      v6, s6
    v.splat      v9, s16
    s.addi       s6, s23, #2048                  // row 2
    s.movz       s16, #15
    vf.fma       v11, v7, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s26, #0]
    v.cmp.lt     p3, v6, v2
    v.splat      v6, s19
    s.addi       s19, s23, #3072                 // row 3
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s12, #0]
    vf.fma       v10, v5, v1, v11
    v.cmp.lt     p4, v9, v2
    v.splat      v1, s7
    s.addi       s7, s23, #4096                  // row 4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s1, #0]
    vf.fma       v9, v4, v7, v10
    v.cmp.lt     p1, v6, v2
    v.splat      v4, s14
    s.addi       s1, s23, #5120                  // row 5
    vf.fma       v6, v8, v5, v9
    s.addi       s12, s23, #6144                 // row 6
    a.vwrite     a1, s25, v6
    a.vread      v5, a0, s24
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s23, #0]
    v.cmp.lt     p2, v1, v2
    v.extract    s14, v5, #0
    v.extract    s21, v5, #1
    v.splat      v1, s14
    v.splat      v7, s21
    v.extract    s14, v5, #2
    v.splat      v8, s13
    v.splat      v9, s14
    v.extract    s13, v5, #3
    v.splat      v10, s5
    v.extract    s5, v5, #4
    s.addi       s14, s23, #7168                 // row 7
    v.extract    s21, v5, #5
    v.extract    s24, v5, #6
    v.extract    s25, v5, #7
    vf.fma       v11, v1, v6, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s27, #0]
    v.cmp.lt     p3, v4, v2
    v.splat      v3, s13
    v.splat      v4, s5
    s.addi       s5, s23, #8192                  // row 8
    v.extract    s13, v5, #8
    vf.fma       v6, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s6, #0]
    v.cmp.lt     p4, v8, v2
    v.splat      v7, s17
    v.splat      v8, s21
    s.addi       s6, s23, #9216                  // row 9
    v.extract    s21, v5, #9
    vf.fma       v11, v9, v1, v6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s19, #0]
    v.cmp.lt     p1, v10, v2
    v.splat      v6, s18
    v.splat      v9, s24
    s.addi       s18, s23, #10240                // row 10
    v.extract    s19, v5, #10
    vf.fma       v10, v3, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s7, #0]
    v.cmp.lt     p2, v7, v2
    v.splat      v3, s10
    v.splat      v7, s25
    s.addi       s7, s23, #11264                 // row 11
    v.extract    s10, v5, #11
    vf.fma       v11, v4, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s1, #0]
    v.cmp.lt     p3, v6, v2
    v.splat      v4, s9
    v.splat      v6, s13
    s.addi       s1, s23, #12288                 // row 12
    v.extract    s9, v5, #12
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s12, #0]
    v.cmp.lt     p4, v3, v2
    v.splat      v3, s20
    v.splat      v8, s21
    s.addi       s12, s23, #13312                // row 13
    v.extract    s13, v5, #13
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s14, #0]
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s15
    v.splat      v9, s19
    s.addi       s14, s23, #14336                // row 14
    v.extract    s15, v5, #14
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s5, #0]
    v.cmp.lt     p2, v3, v2
    v.splat      v3, s2
    v.splat      v7, s10
    s.addi       s2, s23, #15360                 // row 15
    v.extract    s5, v5, #15
    v.splat      v5, s28
    vf.fma       v11, v6, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s6, #0]
    v.cmp.lt     p3, v4, v2
    v.splat      v4, s9
    v.splat      v6, s13
    vf.fma       v10, v8, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s18, #0]
    v.cmp.lt     p4, v3, v2
    v.splat      v3, s15
    v.splat      v8, s5
    s.mul        s5, s11, s22
    s.muli       s6, s3, #4                      // a runtime tile origin, x4
    s.muli       s9, s4, #1024                   // a runtime tile origin, x1024
    s.muli       s10, s5, #4                     // a runtime tile origin, x4
    s.add        s5, s8, s6                      // the tile origin
    s.add        s6, s5, s9                      // the tile origin
    s.add        s5, s6, s10                     // the tile origin
    vf.fma       v11, v9, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s7, #0]
    v.cmp.lt     p1, v5, v2
    s.movz       s6, #0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s7, #0
    s.add        s8, s6, s4                      // the tile origin
    v.movi       v5, #0
    v.splat      v9, s8
    vf.fma       v10, v7, v1, v11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s1, #0]
    s.movz       s1, #0
    s.movz       s4, #256
    s.add        s6, s1, s3                      // the tile origin
    v.splat      v7, s4
    v.cmp.lt     p2, v9, v2
    v.splat      v9, s6
    v.add        v11, v0, v9
    v.splat      v0, s11
    vf.fma       v9, v4, v1, v10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s12, #0]
    v.splat      v4, s17
    v.cmp.lt     p3, v11, v7
    p.and        p5, p2, p3
    s.movz       s1, #1
    s.addi       s3, s5, #1024                   // row 1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s14, #0]
    vf.fma       v10, v6, v1, v9
    v.cmp.lt     p2, v0, v4
    p.and        p4, p5, p2
    s.addi       s4, s8, #1
    s.movz       s6, #2
    v.splat      v0, s4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v1, [s2, #0]
    vf.fma       v4, v3, v7, v10
    v.cmp.lt     p1, v0, v2
    p.and        p5, p1, p3
    s.addi       s2, s8, #2
    p.and        p1, p5, p2
    v.splat      v0, s2
    s.addi       s2, s5, #2048                   // row 2
    vf.fma       v3, v8, v1, v4
    a.vwrite     a1, s16, v3
    a.vread      v1, a1, s7
    s.movz       s4, #3
    s.addi       s7, s8, #3
    vf.add       v3, v1, v5
    v.splat      v1, s7
    s.addi       s7, s5, #3072                   // row 3
    s.movz       s9, #4
    s.addi       s10, s8, #4
    @p4 v.st.w       [s5, #0], v3
    a.vread      v3, a1, s1
    v.cmp.lt     p4, v0, v2
    p.and        p5, p4, p3
    vf.add       v0, v3, v5
    p.and        p4, p5, p2
    v.splat      v3, s10
    s.addi       s1, s5, #4096                   // row 4
    s.movz       s10, #5
    s.addi       s11, s8, #5
    s.addi       s12, s5, #5120                  // row 5
    v.splat      v4, s11
    s.movz       s11, #6
    s.addi       s13, s8, #6
    s.addi       s14, s5, #6144                  // row 6
    v.splat      v6, s13
    @p1 v.st.w       [s3, #0], v0
    a.vread      v0, a1, s6
    v.cmp.lt     p1, v1, v2
    p.and        p5, p1, p3
    vf.add       v1, v0, v5
    p.and        p1, p5, p2
    s.movz       s3, #7
    s.addi       s6, s8, #7
    s.addi       s13, s5, #7168                  // row 7
    v.splat      v0, s6
    @p4 v.st.w       [s2, #0], v1
    a.vread      v1, a1, s4
    v.cmp.lt     p4, v3, v2
    p.and        p5, p4, p3
    vf.add       v3, v1, v5
    p.and        p4, p5, p2
    s.movz       s2, #8
    s.addi       s4, s8, #8
    s.addi       s6, s5, #8192                   // row 8
    v.splat      v1, s4
    @p1 v.st.w       [s7, #0], v3
    a.vread      v3, a1, s9
    v.cmp.lt     p1, v4, v2
    p.and        p5, p1, p3
    vf.add       v4, v3, v5
    p.and        p1, p5, p2
    s.movz       s4, #9
    s.addi       s7, s8, #9
    s.addi       s9, s5, #9216                   // row 9
    v.splat      v3, s7
    @p4 v.st.w       [s1, #0], v4
    a.vread      v4, a1, s10
    v.cmp.lt     p4, v6, v2
    p.and        p5, p4, p3
    vf.add       v6, v4, v5
    p.and        p4, p5, p2
    s.movz       s1, #10
    s.addi       s7, s8, #10
    s.addi       s10, s5, #10240                 // row 10
    v.splat      v4, s7
    @p1 v.st.w       [s12, #0], v6
    a.vread      v6, a1, s11
    v.cmp.lt     p1, v0, v2
    p.and        p5, p1, p3
    vf.add       v0, v6, v5
    p.and        p1, p5, p2
    s.movz       s7, #11
    s.addi       s11, s8, #11
    s.addi       s12, s5, #11264                 // row 11
    v.splat      v6, s11
    @p4 v.st.w       [s14, #0], v0
    a.vread      v0, a1, s3
    v.cmp.lt     p4, v1, v2
    p.and        p5, p4, p3
    vf.add       v1, v0, v5
    p.and        p4, p5, p2
    s.movz       s3, #12
    s.addi       s11, s8, #12
    s.addi       s14, s5, #12288                 // row 12
    v.splat      v0, s11
    @p1 v.st.w       [s13, #0], v1
    a.vread      v1, a1, s2
    v.cmp.lt     p1, v3, v2
    p.and        p5, p1, p3
    vf.add       v3, v1, v5
    p.and        p1, p5, p2
    s.movz       s2, #13
    s.addi       s11, s8, #13
    s.addi       s13, s5, #13312                 // row 13
    v.splat      v1, s11
    @p4 v.st.w       [s6, #0], v3
    a.vread      v3, a1, s4
    v.cmp.lt     p4, v4, v2
    p.and        p5, p4, p3
    vf.add       v4, v3, v5
    p.and        p4, p5, p2
    s.movz       s4, #14
    s.addi       s6, s8, #14
    s.addi       s11, s5, #14336                 // row 14
    v.splat      v3, s6
    @p1 v.st.w       [s9, #0], v4
    a.vread      v4, a1, s1
    v.cmp.lt     p1, v6, v2
    p.and        p5, p1, p3
    vf.add       v6, v4, v5
    p.and        p1, p5, p2
    s.movz       s1, #15
    s.addi       s6, s8, #15
    s.addi       s8, s5, #15360                  // row 15
    v.splat      v4, s6
    @p4 v.st.w       [s10, #0], v6
    a.vread      v6, a1, s7
    v.cmp.lt     p4, v0, v2
    p.and        p5, p4, p3
    vf.add       v0, v6, v5
    p.and        p4, p5, p2
    @p1 v.st.w       [s12, #0], v0
    a.vread      v0, a1, s3
    v.cmp.lt     p1, v1, v2
    p.and        p5, p1, p3
    vf.add       v1, v0, v5
    p.and        p1, p5, p2
    @p4 v.st.w       [s14, #0], v1
    a.vread      v0, a1, s2
    v.cmp.lt     p4, v3, v2
    p.and        p5, p4, p3
    vf.add       v1, v0, v5
    p.and        p4, p5, p2
    @p1 v.st.w       [s13, #0], v1
    a.vread      v0, a1, s4
    v.cmp.lt     p1, v4, v2
    p.and        p5, p1, p3
    vf.add       v1, v0, v5
    p.and        p1, p5, p2
    @p4 v.st.w       [s11, #0], v1
    a.vread      v0, a1, s1
    vf.add       v1, v0, v5
    @p1 v.st.w       [s8, #0], v1
__rctx_next:
    exit
