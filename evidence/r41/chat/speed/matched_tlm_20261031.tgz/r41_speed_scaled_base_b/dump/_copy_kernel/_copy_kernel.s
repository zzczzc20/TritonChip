    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.movi       v2, #32
    v.movi       v3, #48
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #64
    v.movi       v6, #80
    v.movi       v7, #96
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #112
    s.shli       s1, s4, #7                      // x128 as a shift
    v.add        v10, v0, v1
    v.add        v1, v0, v2
    v.add        v2, v0, v3
    v.add        v3, v4, v5
    v.add        v5, v4, v6
    v.add        v6, v4, v7
    v.add        v4, v8, v9
    v.splat      v7, s1
    v.movi       v8, #0
    v.movi       v9, #0
    v.add        v11, v7, v0
    v.add        v0, v7, v10
    v.add        v10, v7, v1
    v.add        v1, v7, v2
    v.add        v2, v7, v3
    v.add        v3, v7, v5
    v.add        v5, v7, v6
    v.add        v6, v7, v4
    v.sub        v4, v8, v11
    v.sub        v7, v9, v0
    v.cmp.lt     p1, v11, v8
    v.cmp.lt     p2, v0, v9
    @p1 v.sel        v12, v4, v11
    v.movi       v4, #1
    @p2 v.sel        v13, v7, v0
    s.rdspecial  s1, arg_base
    v.lshr       v7, v12, v4
    s.ld.d       s2, [s1, #0]                    // SRC: device_ptr64 at arg_base+0
    v.movi       v4, #2
    v.sub        v12, v8, v7
    v.movi       v14, #2
    v.sub        v15, v8, v4
    @p1 v.sel        v16, v12, v7
    v.sub        v7, v9, v14
    v.cmp.lt     p1, v4, v8
    v.cmp.lt     p3, v14, v9
    @p1 v.sel        v8, v15, v4
    @p3 v.sel        v8, v7, v14
    s.ld.d       s3, [s1, #8]                    // DST: device_ptr64 at arg_base+8
    v.movi       v7, #0
    v.movi       v8, #0
    v.movi       v12, #0
    v.movi       v15, #0
    v.sub        v17, v7, v10
    v.sub        v18, v8, v1
    v.sub        v19, v12, v2
    v.sub        v20, v15, v3
    v.cmp.lt     p1, v10, v7
    v.cmp.lt     p3, v1, v8
    v.movi       v21, #1
    @p1 v.sel        v22, v17, v10
    v.movi       v17, #1
    @p3 v.sel        v23, v18, v1
    v.movi       v18, #1
    v.movi       v24, #1
    v.movi       v25, #1
    v.lshr       v26, v13, v21
    v.lshr       v13, v22, v17
    v.lshr       v17, v23, v18
    v.sub        v18, v9, v26
    v.sub        v9, v7, v13
    v.sub        v21, v8, v17
    @p2 v.sel        v22, v18, v26
    v.cmp.lt     p2, v2, v12
    @p2 v.sel        v18, v19, v2
    v.movi       v19, #2
    v.movi       v23, #0
    v.lshr       v26, v18, v24
    @p1 v.sel        v18, v9, v13
    v.cmp.lt     p1, v3, v15
    @p1 v.sel        v9, v20, v3
    v.sub        v13, v12, v26
    v.movi       v20, #2
    v.lshr       v24, v9, v25
    @p3 v.sel        v9, v21, v17
    v.cmp.lt     p3, v5, v23
    v.sub        v17, v15, v24
    v.movi       v21, #2
    @p2 v.sel        v25, v13, v26
    v.movi       v13, #2
    @p1 v.sel        v26, v17, v24
    v.movi       v17, #2
    v.sub        v24, v7, v19
    v.sub        v27, v8, v20
    v.sub        v28, v12, v21
    v.sub        v29, v15, v13
    v.cmp.lt     p1, v19, v7
    v.sub        v7, v23, v5
    v.sub        v30, v23, v17
    v.cmp.lt     p2, v20, v8
    @p3 v.sel        v8, v7, v5
    @p1 v.sel        v7, v24, v19
    v.movi       v7, #0
    v.movi       v24, #1
    v.movi       v31, #2
    v.sub        v32, v7, v6
    v.cmp.lt     p1, v6, v7
    v.lshr       v33, v8, v24
    @p1 v.sel        v8, v32, v6
    v.sub        v24, v7, v31
    v.sub        v32, v23, v33
    @p2 v.sel        v34, v27, v20
    v.movi       v27, #0
    v.movi       v34, #1
    @p3 v.sel        v35, v32, v33
    v.cmp.lt     p2, v11, v27
    v.lshr       v32, v8, v34
    v.cmp.lt     p3, v21, v12
    v.sub        v8, v27, v11
    v.sub        v12, v7, v32
    v.sub        v33, v27, v4
    @p2 v.sel        v34, v8, v11
    @p1 v.sel        v8, v12, v32
    v.cmp.lt     p1, v13, v15
    @p3 v.sel        v12, v28, v21
    v.movi       v12, #0
    v.movi       v15, #1
    v.movi       v28, #1
    v.sub        v32, v12, v0
    v.cmp.lt     p3, v0, v12
    v.and        v36, v34, v15
    @p3 v.sel        v15, v32, v0
    v.sub        v32, v12, v14
    v.sub        v34, v27, v36
    @p1 v.sel        v37, v29, v13
    v.movi       v29, #0
    v.and        v37, v15, v28
    @p2 v.sel        v15, v34, v36
    v.sub        v28, v29, v10
    v.cmp.lt     p1, v10, v29
    v.sub        v34, v12, v37
    @p1 v.sel        v36, v28, v10
    v.cmp.lt     p2, v17, v23
    v.movi       v23, #1
    @p3 v.sel        v28, v34, v37
    v.sub        v34, v29, v19
    v.and        v37, v36, v23
    v.cmp.lt     p3, v31, v7
    @p2 v.sel        v7, v30, v17
    v.movi       v7, #0
    v.movi       v23, #1
    v.sub        v30, v29, v37
    v.sub        v36, v7, v1
    v.cmp.lt     p2, v1, v7
    @p1 v.sel        v38, v30, v37
    @p2 v.sel        v30, v36, v1
    v.sub        v36, v7, v20
    v.cmp.lt     p1, v4, v27
    v.and        v27, v30, v23
    @p3 v.sel        v23, v24, v31
    v.movi       v23, #0
    v.movi       v24, #1
    v.sub        v30, v7, v27
    v.sub        v37, v23, v2
    v.cmp.lt     p3, v2, v23
    @p2 v.sel        v39, v30, v27
    @p3 v.sel        v27, v37, v2
    v.sub        v30, v23, v21
    v.cmp.lt     p2, v14, v12
    v.and        v12, v27, v24
    @p1 v.sel        v24, v33, v4
    v.movi       v24, #0
    v.movi       v27, #1
    v.sub        v33, v23, v12
    v.sub        v37, v24, v3
    v.cmp.lt     p1, v3, v24
    @p3 v.sel        v40, v33, v12
    @p1 v.sel        v12, v37, v3
    v.sub        v33, v24, v13
    v.cmp.lt     p3, v19, v29
    v.and        v29, v12, v27
    @p2 v.sel        v12, v32, v14
    v.movi       v12, #0
    v.movi       v27, #1
    v.sub        v32, v24, v29
    v.sub        v37, v12, v5
    v.cmp.lt     p2, v5, v12
    @p1 v.sel        v41, v32, v29
    @p2 v.sel        v29, v37, v5
    v.sub        v32, v12, v17
    v.cmp.lt     p1, v20, v7
    v.and        v7, v29, v27
    @p3 v.sel        v27, v34, v19
    v.movi       v27, #0
    v.movi       v29, #1
    v.sub        v34, v12, v7
    v.sub        v37, v27, v6
    v.cmp.lt     p3, v6, v27
    @p2 v.sel        v42, v34, v7
    @p3 v.sel        v7, v37, v6
    v.sub        v34, v27, v31
    v.cmp.lt     p2, v21, v23
    v.and        v23, v7, v29
    @p1 v.sel        v7, v36, v20
    v.mul        v7, v16, v4
    v.sub        v16, v27, v23
    v.mul        v29, v22, v14
    v.mul        v22, v18, v19
    @p3 v.sel        v18, v16, v23
    v.mul        v16, v9, v20
    v.mul        v9, v25, v21
    v.mul        v23, v26, v13
    v.mul        v25, v35, v17
    v.mul        v26, v8, v31
    v.add        v8, v7, v15                     // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p1, v11, v4
    v.cmp.lt     p3, v13, v24
    @p2 v.sel        v24, v30, v21
    v.add        v24, v29, v28                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v30, v22, v38                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v35, v16, v39                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v14
    v.movi       v36, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v36, [s2, v8]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v10, v19
    @p3 v.sel        v8, v33, v13
    v.add        v8, v9, v40                     // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v33, v23, v41                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v37, v25, v42                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p3, v1, v20
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v43, [s2, v24]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v21
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v24, [s2, v30]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v13
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v30, [s2, v35]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v5, v17
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v35, [s2, v8]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v17, v12
    v.add        v8, v26, v18                    // per-lane offsets add up, in elements (ISA sec 9.1)
    @p2 v.sel        v12, v32, v17
    v.cmp.lt     p2, v6, v31
    v.add        v12, v7, v15                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v7, v29, v28                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v15, [s2, v33]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v31, v27
    v.add        v27, v22, v38                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v22, v16, v39                   // per-lane offsets add up, in elements (ISA sec 9.1)
    @p1 v.sel        v16, v34, v31
    v.add        v16, v9, v40                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v9, v23, v41                    // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v23, v25, v42                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.add        v25, v26, v18                   // per-lane offsets add up, in elements (ISA sec 9.1)
    v.cmp.lt     p1, v11, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.sb v4, [s2, v37]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v0, v14
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v0, [s2, v8]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v10, v19
    @p1 v.st.scatter.b [s3, v12], v36
    v.cmp.lt     p1, v1, v20
    @p3 v.st.scatter.b [s3, v7], v43
    v.cmp.lt     p3, v2, v21
    @p2 v.st.scatter.b [s3, v27], v24
    v.cmp.lt     p2, v3, v13
    @p1 v.st.scatter.b [s3, v22], v30
    v.cmp.lt     p1, v5, v17
    @p3 v.st.scatter.b [s3, v16], v35
    v.cmp.lt     p3, v6, v31
    @p2 v.st.scatter.b [s3, v9], v15
    @p1 v.st.scatter.b [s3, v23], v4
    @p3 v.st.scatter.b [s3, v25], v0
__rctx_next:
    exit
