    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // out_ptr1: device_ptr64 at arg_base+40
    s.movz       s1, #1
    s.rdspecial  s9, arg_base
    s.ld.d       s10, [s9, #64]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s9, role_id
    s.movz       s11, #512
    s.mul        s12, s9, s11
    s.add        s9, s10, s12                    // this context's own scratch
    s.addi       s10, s9, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s11, #0
    s.st.d       [s10, #0], s5
    s.movz       s11, #64
    s.st.d       [s10, #8], s11
    s.movz       s11, #192
    s.st.d       [s10, #16], s11
    s.movz       s11, #384
    s.st.d       [s10, #48], s11
    s.movz       s11, #2
    s.st.d       [s10, #56], s11
    .li       s11, #68719476737
    s.st.d       [s10, #88], s11
    .li       s11, #8589934592
    s.st.d       [s10, #104], s11
    fence.release.device
    td.load      d0, [s10]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s10, s9, #256                   // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s9, #0
    s.st.d       [s10, #0], s6
    s.movz       s9, #64
    s.st.d       [s10, #8], s9
    s.movz       s9, #192
    s.st.d       [s10, #16], s9
    s.movz       s9, #384
    s.st.d       [s10, #48], s9
    s.movz       s9, #2
    s.st.d       [s10, #56], s9
    .li       s9, #68719476737
    s.st.d       [s10, #88], s9
    .li       s9, #8589934592
    s.st.d       [s10, #104], s9
    fence.release.device
    td.load      d1, [s10]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s9, #0
    s.movz       s10, #192
    s.movz       s11, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.shli       s12, s4, #3                     // element offset -> bytes (x8)
    s.add        s13, s2, s12                    // &in_ptr0[...]
    v.movi       v1, #0
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s1
    v.cmp.lt     p1, v2, v3
    v.movi       v2, #1
    v.shl        v3, v1, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s13, v3]              // index is in elements (ISA sec 9.1)
    s.addi       s1, s13, #4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s1, v3]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s9, #0
    v.movi       v3, #0
    v.movi       v4, #0
    v.mov        v4, v3
for_1:
    s.cmp.ge     s2, s1, s10
    br.nz        s2, endfor_2
    s.muli       s2, s4, #384
    v.splat      v3, s1
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s12, #192
    s.movz       s13, #64
    s.muli       s14, s4, #384
    v.splat      v6, s1
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s15, #192
    s.movz       s16, #64
    v.add        v8, v3, v5
    v.movi       v3, #0
    v.splat      v5, s12
    s.muli       s12, s1, #2
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s13
    s.muli       s13, s1, #2
    v.add        v12, v6, v7
    v.movi       v6, #0
    v.splat      v7, s15
    v.splat      v13, s4
    v.cmp.ge     p1, v8, v3
    v.movi       v3, #0
    v.cmp.lt     p2, v8, v5
    v.splat      v5, s16
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    v.cmp.ge     p5, v12, v6
    s.add        s15, s5, s2
    p.and        p6, p1, p2
    v.cmp.lt     p1, v12, v7
    p.and        p2, p3, p4
    v.cmp.ge     p3, v13, v3
    s.add        s2, s6, s14
    p.and        p4, p5, p1
    v.cmp.lt     p1, v13, v5
    p.and        p5, p3, p1
    s.add        s14, s15, s12
    p.and        p1, p6, p2
    s.add        s12, s2, s13
    p.and        p2, p4, p5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s14, #0]
    v.splat      v5, s1
    v.movi       v6, #192
    v.add        v7, v5, v0
    v.movi       v5, #0
    v.cmp.lt     p1, v7, v6
    v.extract    s2, v2, #0
    v.extract    s13, v2, #0
    s.shli       s14, s2, #32
    s.shli       s2, s13, #32
    v.extract    s13, v1, #0
    v.extract    s15, v1, #0
    s.or         s16, s13, s14
    s.movz       s13, #0
    s.or         s14, s15, s2
    s.movz       s2, #640
    s.cmp.ge     s15, s16, s13
    v.movi       v6, #0
    s.cmp.lt     s13, s14, s2
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v8, [s12, #0]
    v.insert     v5, s15, #0
    v.movi       v9, #0
    v.insert     v6, s13, #0
    v.movi       v10, #0
    v.cmp.ne     p2, v5, v9
    v.cmp.ne     p3, v6, v10
    p.and        p4, p2, p3
    v.movi       v5, #0
    v.movi       v6, #1
    vf.cvt.f16.f32 v9, v3
    s.movz       s2, #1
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v10, s2
    @p4 v.sel        v11, v5, v6
    v.cmp.lt     p2, v3, v10
    s.movz       s2, #0
    @p2 v.reduce.or  s12, v11
    s.cmp.eq     s13, s12, s2
    vf.cvt.f16.f32 v3, v8
    br.nz        s13, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s2, v2, #0
    s.shli       s12, s2, #32
    v.extract    s2, v1, #0
    s.or         s13, s2, s12
    s.movz       s2, #192
    v.extract    s12, v7, #0
    s.mul        s14, s13, s2
    s.shli       s2, s12, #32
    v.extract    s12, v7, #1
    s.ashri      s13, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v7, #2
    v.movi       v5, #0
    v.movi       v6, #0
    s.lshri      s15, s14, #32
    v.movi       v8, #0
    v.movi       v10, #0
    s.lshri      s16, s13, #32
    s.ashri      s17, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v7, #3
    v.insert     v5, s14, #0
    v.insert     v6, s15, #0
    v.insert     v8, s13, #0
    v.insert     v10, s16, #0
    s.lshri      s13, s17, #32
    s.ashri      s14, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v7, #4
    v.insert     v8, s17, #1
    v.insert     v10, s13, #1
    s.lshri      s13, s14, #32
    s.ashri      s15, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v7, #5
    v.insert     v8, s14, #2
    v.insert     v10, s13, #2
    s.lshri      s13, s15, #32
    s.ashri      s14, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v7, #6
    v.insert     v8, s15, #3
    v.insert     v10, s13, #3
    s.lshri      s13, s14, #32
    s.ashri      s15, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v7, #7
    v.insert     v8, s14, #4
    v.insert     v10, s13, #4
    s.lshri      s13, s15, #32
    s.ashri      s14, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v7, #8
    v.insert     v8, s15, #5
    v.insert     v10, s13, #5
    s.lshri      s13, s14, #32
    s.ashri      s15, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v7, #9
    v.insert     v8, s14, #6
    v.insert     v10, s13, #6
    s.lshri      s13, s15, #32
    s.ashri      s14, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v7, #10
    v.insert     v8, s15, #7
    v.insert     v10, s13, #7
    s.lshri      s13, s14, #32
    s.ashri      s15, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v7, #11
    v.insert     v8, s14, #8
    v.insert     v10, s13, #8
    s.lshri      s13, s15, #32
    s.ashri      s14, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v7, #12
    v.insert     v8, s15, #9
    v.insert     v10, s13, #9
    s.lshri      s13, s14, #32
    s.ashri      s15, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v7, #13
    v.insert     v8, s14, #10
    v.insert     v10, s13, #10
    s.lshri      s13, s15, #32
    s.ashri      s14, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v7, #14
    v.insert     v8, s15, #11
    v.insert     v10, s13, #11
    s.lshri      s13, s14, #32
    s.ashri      s15, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v7, #15
    v.extract    s16, v6, #0
    v.insert     v8, s14, #12
    v.insert     v10, s13, #12
    s.lshri      s13, s15, #32
    s.ashri      s14, s2, #32
    s.shli       s2, s12, #32
    s.shli       s12, s16, #32
    v.extract    s16, v5, #0
    v.extract    s17, v6, #0
    v.insert     v8, s15, #13
    v.insert     v10, s13, #13
    s.lshri      s13, s14, #32
    s.ashri      s15, s2, #32
    s.or         s2, s16, s12
    s.shli       s12, s17, #32
    v.extract    s16, v5, #0
    v.extract    s17, v6, #0
    v.insert     v8, s14, #14
    v.insert     v10, s13, #14
    s.lshri      s13, s15, #32
    v.movi       v7, #0
    v.movi       v11, #0
    s.lshri      s14, s2, #32
    s.or         s18, s16, s12
    s.shli       s12, s17, #32
    v.extract    s16, v5, #0
    v.insert     v8, s15, #15
    v.extract    s15, v6, #0
    v.insert     v10, s13, #15
    v.insert     v7, s2, #0
    v.insert     v11, s14, #0
    s.lshri      s2, s18, #32
    s.or         s13, s16, s12
    s.shli       s12, s15, #32
    v.extract    s14, v5, #0
    v.extract    s15, v6, #0
    v.insert     v7, s18, #1
    v.insert     v11, s2, #1
    s.lshri      s2, s13, #32
    s.or         s16, s14, s12
    s.shli       s12, s15, #32
    v.extract    s14, v5, #0
    v.extract    s15, v6, #0
    v.insert     v7, s13, #2
    v.insert     v11, s2, #2
    s.lshri      s2, s16, #32
    s.or         s13, s14, s12
    s.shli       s12, s15, #32
    v.extract    s14, v5, #0
    v.extract    s15, v6, #0
    v.insert     v7, s16, #3
    v.insert     v11, s2, #3
    s.lshri      s2, s13, #32
    s.or         s16, s14, s12
    s.shli       s12, s15, #32
    v.extract    s14, v5, #0
    v.extract    s15, v6, #0
    v.insert     v7, s13, #4
    v.insert     v11, s2, #4
    s.lshri      s2, s16, #32
    s.or         s13, s14, s12
    s.shli       s12, s15, #32
    v.extract    s14, v5, #0
    v.extract    s15, v6, #0
    v.insert     v7, s16, #5
    v.insert     v11, s2, #5
    s.lshri      s2, s13, #32
    s.or         s16, s14, s12
    s.shli       s12, s15, #32
    v.extract    s14, v5, #0
    v.extract    s15, v6, #0
    v.insert     v7, s13, #6
    v.insert     v11, s2, #6
    s.lshri      s2, s16, #32
    s.or         s13, s14, s12
    s.shli       s12, s15, #32
    v.extract    s14, v5, #0
    v.extract    s15, v6, #0
    v.insert     v7, s16, #7
    v.insert     v11, s2, #7
    s.lshri      s2, s13, #32
    s.or         s16, s14, s12
    s.shli       s12, s15, #32
    v.extract    s14, v5, #0
    v.extract    s15, v6, #0
    v.insert     v7, s13, #8
    v.insert     v11, s2, #8
    s.lshri      s2, s16, #32
    s.or         s13, s14, s12
    s.shli       s12, s15, #32
    v.extract    s14, v5, #0
    v.extract    s15, v6, #0
    v.insert     v7, s16, #9
    v.insert     v11, s2, #9
    s.lshri      s2, s13, #32
    s.or         s16, s14, s12
    s.shli       s12, s15, #32
    v.extract    s14, v5, #0
    v.extract    s15, v6, #0
    v.insert     v7, s13, #10
    v.insert     v11, s2, #10
    s.lshri      s2, s16, #32
    s.or         s13, s14, s12
    s.shli       s12, s15, #32
    v.extract    s14, v5, #0
    v.extract    s15, v6, #0
    v.insert     v7, s16, #11
    v.insert     v11, s2, #11
    s.lshri      s2, s13, #32
    s.or         s16, s14, s12
    s.shli       s12, s15, #32
    v.extract    s14, v5, #0
    v.extract    s15, v6, #0
    v.insert     v7, s13, #12
    v.insert     v11, s2, #12
    s.lshri      s2, s16, #32
    s.or         s13, s14, s12
    s.shli       s12, s15, #32
    v.extract    s14, v5, #0
    v.insert     v7, s16, #13
    v.insert     v11, s2, #13
    s.lshri      s2, s13, #32
    s.or         s15, s14, s12
    v.insert     v7, s13, #14
    v.insert     v11, s2, #14
    s.lshri      s2, s15, #32
    v.insert     v7, s15, #15
    v.insert     v11, s2, #15
    v.extract    s2, v10, #0
    v.extract    s12, v11, #0
    s.shli       s13, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v8, #0
    v.extract    s14, v7, #0
    v.extract    s15, v10, #1
    v.extract    s16, v11, #1
    s.or         s17, s12, s13
    s.or         s12, s14, s2
    s.shli       s2, s15, #32
    s.shli       s13, s16, #32
    v.extract    s14, v8, #1
    v.extract    s15, v7, #1
    v.extract    s16, v10, #2
    v.movi       v5, #0
    s.add        s18, s17, s12
    v.extract    s12, v11, #2
    s.or         s17, s14, s2
    s.or         s2, s15, s13
    s.shli       s13, s16, #32
    s.shli       s14, s12, #32
    v.extract    s12, v8, #2
    v.extract    s15, v7, #2
    v.movi       v6, #0
    v.insert     v5, s18, #0
    s.lshri      s16, s18, #32
    s.add        s18, s17, s2
    v.extract    s2, v10, #3
    s.or         s17, s12, s13
    v.extract    s12, v11, #3
    s.or         s13, s15, s14
    s.shli       s14, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v8, #3
    v.insert     v6, s16, #0
    v.extract    s15, v7, #3
    v.insert     v5, s18, #1
    s.lshri      s16, s18, #32
    s.add        s18, s17, s13
    v.extract    s13, v10, #4
    s.or         s17, s12, s14
    v.extract    s12, v11, #4
    s.or         s14, s15, s2
    s.shli       s2, s13, #32
    s.shli       s13, s12, #32
    v.extract    s12, v8, #4
    v.insert     v6, s16, #1
    v.extract    s15, v7, #4
    v.insert     v5, s18, #2
    s.lshri      s16, s18, #32
    s.add        s18, s17, s14
    v.extract    s14, v10, #5
    s.or         s17, s12, s2
    v.extract    s2, v11, #5
    s.or         s12, s15, s13
    s.shli       s13, s14, #32
    s.shli       s14, s2, #32
    v.extract    s2, v8, #5
    v.insert     v6, s16, #2
    v.extract    s15, v7, #5
    v.insert     v5, s18, #3
    s.lshri      s16, s18, #32
    s.add        s18, s17, s12
    v.extract    s12, v10, #6
    s.or         s17, s2, s13
    v.extract    s2, v11, #6
    s.or         s13, s15, s14
    s.shli       s14, s12, #32
    s.shli       s12, s2, #32
    v.extract    s2, v8, #6
    v.insert     v6, s16, #3
    v.extract    s15, v7, #6
    v.insert     v5, s18, #4
    s.lshri      s16, s18, #32
    s.add        s18, s17, s13
    v.extract    s13, v10, #7
    s.or         s17, s2, s14
    v.extract    s2, v11, #7
    s.or         s14, s15, s12
    s.shli       s12, s13, #32
    s.shli       s13, s2, #32
    v.extract    s2, v8, #7
    v.insert     v6, s16, #4
    v.extract    s15, v7, #7
    v.insert     v5, s18, #5
    s.lshri      s16, s18, #32
    s.add        s18, s17, s14
    v.extract    s14, v10, #8
    s.or         s17, s2, s12
    v.extract    s2, v11, #8
    s.or         s12, s15, s13
    s.shli       s13, s14, #32
    s.shli       s14, s2, #32
    v.extract    s2, v8, #8
    v.insert     v6, s16, #5
    v.extract    s15, v7, #8
    v.insert     v5, s18, #6
    s.lshri      s16, s18, #32
    s.add        s18, s17, s12
    v.extract    s12, v10, #9
    s.or         s17, s2, s13
    v.extract    s2, v11, #9
    s.or         s13, s15, s14
    s.shli       s14, s12, #32
    s.shli       s12, s2, #32
    v.extract    s2, v8, #9
    v.insert     v6, s16, #6
    v.extract    s15, v7, #9
    v.insert     v5, s18, #7
    s.lshri      s16, s18, #32
    s.add        s18, s17, s13
    v.extract    s13, v10, #10
    s.or         s17, s2, s14
    v.extract    s2, v11, #10
    s.or         s14, s15, s12
    s.shli       s12, s13, #32
    s.shli       s13, s2, #32
    v.extract    s2, v8, #10
    v.insert     v6, s16, #7
    v.extract    s15, v7, #10
    v.insert     v5, s18, #8
    s.lshri      s16, s18, #32
    s.add        s18, s17, s14
    v.extract    s14, v10, #11
    s.or         s17, s2, s12
    v.extract    s2, v11, #11
    s.or         s12, s15, s13
    s.shli       s13, s14, #32
    s.shli       s14, s2, #32
    v.extract    s2, v8, #11
    v.insert     v6, s16, #8
    v.extract    s15, v7, #11
    v.insert     v5, s18, #9
    s.lshri      s16, s18, #32
    s.add        s18, s17, s12
    v.extract    s12, v10, #12
    s.or         s17, s2, s13
    v.extract    s2, v11, #12
    s.or         s13, s15, s14
    s.shli       s14, s12, #32
    s.shli       s12, s2, #32
    v.extract    s2, v8, #12
    v.insert     v6, s16, #9
    v.extract    s15, v7, #12
    v.insert     v5, s18, #10
    s.lshri      s16, s18, #32
    s.add        s18, s17, s13
    v.extract    s13, v10, #13
    s.or         s17, s2, s14
    v.extract    s2, v11, #13
    s.or         s14, s15, s12
    s.shli       s12, s13, #32
    s.shli       s13, s2, #32
    v.extract    s2, v8, #13
    v.insert     v6, s16, #10
    v.extract    s15, v7, #13
    v.insert     v5, s18, #11
    s.lshri      s16, s18, #32
    s.add        s18, s17, s14
    v.extract    s14, v10, #14
    s.or         s17, s2, s12
    v.extract    s2, v11, #14
    s.or         s12, s15, s13
    s.shli       s13, s14, #32
    s.shli       s14, s2, #32
    v.extract    s2, v8, #14
    v.insert     v6, s16, #11
    v.extract    s15, v7, #14
    v.insert     v5, s18, #12
    s.lshri      s16, s18, #32
    s.add        s18, s17, s12
    v.extract    s12, v10, #15
    s.or         s17, s2, s13
    v.extract    s2, v11, #15
    s.or         s13, s15, s14
    s.shli       s14, s12, #32
    s.shli       s12, s2, #32
    v.extract    s2, v8, #15
    v.insert     v6, s16, #12
    v.extract    s15, v7, #15
    v.insert     v5, s18, #13
    s.lshri      s16, s18, #32
    s.add        s18, s17, s13
    s.or         s13, s2, s14
    s.or         s2, s15, s12
    v.insert     v6, s16, #13
    v.insert     v5, s18, #14
    s.lshri      s12, s18, #32
    s.add        s14, s13, s2
    v.insert     v6, s12, #14
    v.insert     v5, s14, #15
    s.lshri      s2, s14, #32
    v.movi       v7, #31
    v.insert     v6, s2, #15
    v.ashr       v8, v5, v7
    v.movi       v7, #1
    v.movi       v10, #0
    v.cmp.ne     p2, v6, v8
    @p2 v.sel        v6, v7, v10
    s.movz       s2, #0
    v.reduce.or  s12, v6
    s.cmp.eq     s13, s12, s2
    br.nz        s13, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v6, [s3, v5]               // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    s.add        s2, s1, s11
    s.movz       s12, #1
    vf.cvt.f16.f32 v7, v6
    vf.add       v6, v7, v9
    vf.add       v7, v6, v3
    vf.mul       v3, v7, v7
    vf.add       v6, v4, v3
    @p1 v.sel        v3, v6, v4
    v.mov        v5, v3
    v.mov        v4, v5
    s.mov        s1, s2
    br.nz        s12, for_1
endfor_2:
    vf.reduce.add.b v3, v4
    v.movi       v4, #0
    s.addi       s1, s9, #0
    vf.add       v5, v3, v4
for_5:
    s.cmp.ge     s2, s1, s10
    br.nz        s2, endfor_6
    s.muli       s2, s4, #384
    v.splat      v3, s1
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s9, #192
    s.movz       s12, #64
    s.muli       s13, s4, #384
    v.splat      v6, s1
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s14, #192
    s.movz       s15, #64
    v.add        v8, v3, v4
    v.movi       v3, #0
    v.splat      v4, s9
    s.muli       s9, s1, #2
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s12
    s.muli       s12, s1, #2
    v.add        v12, v6, v7
    v.movi       v6, #0
    v.splat      v7, s14
    v.splat      v13, s4
    v.movi       v14, #0
    v.cmp.ge     p1, v8, v3
    v.splat      v3, s15
    v.cmp.lt     p2, v8, v4
    v.splat      v4, s1
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    v.cmp.ge     p5, v12, v6
    s.add        s14, s5, s2
    p.and        p6, p1, p2
    v.cmp.lt     p1, v12, v7
    p.and        p2, p3, p4
    v.cmp.ge     p3, v13, v14
    s.add        s2, s6, s13
    p.and        p4, p5, p1
    v.cmp.lt     p1, v13, v3
    p.and        p5, p3, p1
    v.add        v3, v4, v0
    v.movi       v4, #192
    s.shli       s13, s1, #1                     // element offset -> bytes (x2)
    s.add        s15, s14, s9
    p.and        p1, p6, p2
    s.add        s9, s2, s12
    p.and        p2, p4, p5
    v.cmp.lt     p3, v3, v4
    v.extract    s2, v2, #0
    v.extract    s12, v2, #0
    s.shli       s14, s2, #32
    s.shli       s2, s12, #32
    v.extract    s12, v1, #0
    s.or         s16, s12, s14
    v.extract    s12, v1, #0
    s.or         s14, s12, s2
    s.movz       s2, #0
    s.add        s12, s7, s13                    // &in_ptr4[...]
    v.movi       v4, #0
    s.cmp.ge     s13, s16, s2
    s.movz       s2, #640
    v.movi       v6, #0
    s.cmp.lt     s16, s14, s2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v7, [s15, #0]
    v.movi       v8, #0
    v.movi       v9, #0
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v10, [s9, #0]
    vf.cvt.f16.f32 v11, v7
    s.movz       s2, #1
    v.movi       v7, #0
    v.movi       v12, #1
    v.iota       v13                             // arange(0, VLEN)
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v14, [s12, #0]
    v.insert     v4, s13, #0
    v.insert     v6, s16, #0
    v.cmp.ne     p1, v4, v8
    v.cmp.ne     p2, v6, v9
    p.and        p4, p1, p2
    v.splat      v4, s2
    @p4 v.sel        v6, v7, v12
    v.cmp.lt     p1, v13, v4
    s.movz       s2, #0
    @p1 v.reduce.or  s9, v6
    s.cmp.eq     s12, s9, s2
    vf.cvt.f16.f32 v4, v10
    vf.cvt.f16.f32 v6, v14
    br.nz        s12, assert_ok_7
    trap         #677351
assert_ok_7:
    v.extract    s2, v2, #0
    s.shli       s9, s2, #32
    v.extract    s2, v1, #0
    s.or         s12, s2, s9
    s.movz       s2, #192
    v.extract    s9, v3, #0
    s.mul        s13, s12, s2
    s.shli       s2, s9, #32
    v.extract    s9, v3, #1
    s.ashri      s12, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v3, #2
    v.movi       v7, #0
    v.movi       v8, #0
    s.lshri      s14, s13, #32
    v.movi       v9, #0
    v.movi       v10, #0
    s.lshri      s15, s12, #32
    s.ashri      s16, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v3, #3
    v.insert     v7, s13, #0
    v.insert     v8, s14, #0
    v.insert     v9, s12, #0
    v.insert     v10, s15, #0
    s.lshri      s12, s16, #32
    s.ashri      s13, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v3, #4
    v.insert     v9, s16, #1
    v.insert     v10, s12, #1
    s.lshri      s12, s13, #32
    s.ashri      s14, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v3, #5
    v.insert     v9, s13, #2
    v.insert     v10, s12, #2
    s.lshri      s12, s14, #32
    s.ashri      s13, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v3, #6
    v.insert     v9, s14, #3
    v.insert     v10, s12, #3
    s.lshri      s12, s13, #32
    s.ashri      s14, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v3, #7
    v.insert     v9, s13, #4
    v.insert     v10, s12, #4
    s.lshri      s12, s14, #32
    s.ashri      s13, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v3, #8
    v.insert     v9, s14, #5
    v.insert     v10, s12, #5
    s.lshri      s12, s13, #32
    s.ashri      s14, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v3, #9
    v.insert     v9, s13, #6
    v.insert     v10, s12, #6
    s.lshri      s12, s14, #32
    s.ashri      s13, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v3, #10
    v.insert     v9, s14, #7
    v.insert     v10, s12, #7
    s.lshri      s12, s13, #32
    s.ashri      s14, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v3, #11
    v.insert     v9, s13, #8
    v.insert     v10, s12, #8
    s.lshri      s12, s14, #32
    s.ashri      s13, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v3, #12
    v.insert     v9, s14, #9
    v.insert     v10, s12, #9
    s.lshri      s12, s13, #32
    s.ashri      s14, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v3, #13
    v.insert     v9, s13, #10
    v.insert     v10, s12, #10
    s.lshri      s12, s14, #32
    s.ashri      s13, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v3, #14
    v.insert     v9, s14, #11
    v.insert     v10, s12, #11
    s.lshri      s12, s13, #32
    s.ashri      s14, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v3, #15
    v.extract    s15, v8, #0
    v.insert     v9, s13, #12
    v.insert     v10, s12, #12
    s.lshri      s12, s14, #32
    s.ashri      s13, s2, #32
    s.shli       s2, s9, #32
    s.shli       s9, s15, #32
    v.extract    s15, v7, #0
    v.extract    s16, v8, #0
    v.insert     v9, s14, #13
    v.insert     v10, s12, #13
    s.lshri      s12, s13, #32
    s.ashri      s14, s2, #32
    s.or         s2, s15, s9
    s.shli       s9, s16, #32
    v.extract    s15, v7, #0
    v.extract    s16, v8, #0
    v.insert     v9, s13, #14
    v.insert     v10, s12, #14
    s.lshri      s12, s14, #32
    v.movi       v12, #0
    v.movi       v13, #0
    s.lshri      s13, s2, #32
    s.or         s17, s15, s9
    s.shli       s9, s16, #32
    v.extract    s15, v7, #0
    v.insert     v9, s14, #15
    v.extract    s14, v8, #0
    v.insert     v10, s12, #15
    v.insert     v12, s2, #0
    v.insert     v13, s13, #0
    s.lshri      s2, s17, #32
    s.or         s12, s15, s9
    s.shli       s9, s14, #32
    v.extract    s13, v7, #0
    v.extract    s14, v8, #0
    v.insert     v12, s17, #1
    v.insert     v13, s2, #1
    s.lshri      s2, s12, #32
    s.or         s15, s13, s9
    s.shli       s9, s14, #32
    v.extract    s13, v7, #0
    v.extract    s14, v8, #0
    v.insert     v12, s12, #2
    v.insert     v13, s2, #2
    s.lshri      s2, s15, #32
    s.or         s12, s13, s9
    s.shli       s9, s14, #32
    v.extract    s13, v7, #0
    v.extract    s14, v8, #0
    v.insert     v12, s15, #3
    v.insert     v13, s2, #3
    s.lshri      s2, s12, #32
    s.or         s15, s13, s9
    s.shli       s9, s14, #32
    v.extract    s13, v7, #0
    v.extract    s14, v8, #0
    v.insert     v12, s12, #4
    v.insert     v13, s2, #4
    s.lshri      s2, s15, #32
    s.or         s12, s13, s9
    s.shli       s9, s14, #32
    v.extract    s13, v7, #0
    v.extract    s14, v8, #0
    v.insert     v12, s15, #5
    v.insert     v13, s2, #5
    s.lshri      s2, s12, #32
    s.or         s15, s13, s9
    s.shli       s9, s14, #32
    v.extract    s13, v7, #0
    v.extract    s14, v8, #0
    v.insert     v12, s12, #6
    v.insert     v13, s2, #6
    s.lshri      s2, s15, #32
    s.or         s12, s13, s9
    s.shli       s9, s14, #32
    v.extract    s13, v7, #0
    v.extract    s14, v8, #0
    v.insert     v12, s15, #7
    v.insert     v13, s2, #7
    s.lshri      s2, s12, #32
    s.or         s15, s13, s9
    s.shli       s9, s14, #32
    v.extract    s13, v7, #0
    v.extract    s14, v8, #0
    v.insert     v12, s12, #8
    v.insert     v13, s2, #8
    s.lshri      s2, s15, #32
    s.or         s12, s13, s9
    s.shli       s9, s14, #32
    v.extract    s13, v7, #0
    v.extract    s14, v8, #0
    v.insert     v12, s15, #9
    v.insert     v13, s2, #9
    s.lshri      s2, s12, #32
    s.or         s15, s13, s9
    s.shli       s9, s14, #32
    v.extract    s13, v7, #0
    v.extract    s14, v8, #0
    v.insert     v12, s12, #10
    v.insert     v13, s2, #10
    s.lshri      s2, s15, #32
    s.or         s12, s13, s9
    s.shli       s9, s14, #32
    v.extract    s13, v7, #0
    v.extract    s14, v8, #0
    v.insert     v12, s15, #11
    v.insert     v13, s2, #11
    s.lshri      s2, s12, #32
    s.or         s15, s13, s9
    s.shli       s9, s14, #32
    v.extract    s13, v7, #0
    v.extract    s14, v8, #0
    v.insert     v12, s12, #12
    v.insert     v13, s2, #12
    s.lshri      s2, s15, #32
    s.or         s12, s13, s9
    s.shli       s9, s14, #32
    v.extract    s13, v7, #0
    v.insert     v12, s15, #13
    v.insert     v13, s2, #13
    s.lshri      s2, s12, #32
    s.or         s14, s13, s9
    v.insert     v12, s12, #14
    v.insert     v13, s2, #14
    s.lshri      s2, s14, #32
    v.insert     v12, s14, #15
    v.insert     v13, s2, #15
    v.extract    s2, v10, #0
    v.extract    s9, v13, #0
    s.shli       s12, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v9, #0
    v.extract    s13, v12, #0
    v.extract    s14, v10, #1
    v.extract    s15, v13, #1
    s.or         s16, s9, s12
    s.or         s9, s13, s2
    s.shli       s2, s14, #32
    s.shli       s12, s15, #32
    v.extract    s13, v9, #1
    v.extract    s14, v12, #1
    v.extract    s15, v10, #2
    v.movi       v7, #0
    s.add        s17, s16, s9
    v.extract    s9, v13, #2
    s.or         s16, s13, s2
    s.or         s2, s14, s12
    s.shli       s12, s15, #32
    s.shli       s13, s9, #32
    v.extract    s9, v9, #2
    v.extract    s14, v12, #2
    v.movi       v8, #0
    v.insert     v7, s17, #0
    s.lshri      s15, s17, #32
    s.add        s17, s16, s2
    v.extract    s2, v10, #3
    s.or         s16, s9, s12
    v.extract    s9, v13, #3
    s.or         s12, s14, s13
    s.shli       s13, s2, #32
    s.shli       s2, s9, #32
    v.extract    s9, v9, #3
    v.insert     v8, s15, #0
    v.extract    s14, v12, #3
    v.insert     v7, s17, #1
    s.lshri      s15, s17, #32
    s.add        s17, s16, s12
    v.extract    s12, v10, #4
    s.or         s16, s9, s13
    v.extract    s9, v13, #4
    s.or         s13, s14, s2
    s.shli       s2, s12, #32
    s.shli       s12, s9, #32
    v.extract    s9, v9, #4
    v.insert     v8, s15, #1
    v.extract    s14, v12, #4
    v.insert     v7, s17, #2
    s.lshri      s15, s17, #32
    s.add        s17, s16, s13
    v.extract    s13, v10, #5
    s.or         s16, s9, s2
    v.extract    s2, v13, #5
    s.or         s9, s14, s12
    s.shli       s12, s13, #32
    s.shli       s13, s2, #32
    v.extract    s2, v9, #5
    v.insert     v8, s15, #2
    v.extract    s14, v12, #5
    v.insert     v7, s17, #3
    s.lshri      s15, s17, #32
    s.add        s17, s16, s9
    v.extract    s9, v10, #6
    s.or         s16, s2, s12
    v.extract    s2, v13, #6
    s.or         s12, s14, s13
    s.shli       s13, s9, #32
    s.shli       s9, s2, #32
    v.extract    s2, v9, #6
    v.insert     v8, s15, #3
    v.extract    s14, v12, #6
    v.insert     v7, s17, #4
    s.lshri      s15, s17, #32
    s.add        s17, s16, s12
    v.extract    s12, v10, #7
    s.or         s16, s2, s13
    v.extract    s2, v13, #7
    s.or         s13, s14, s9
    s.shli       s9, s12, #32
    s.shli       s12, s2, #32
    v.extract    s2, v9, #7
    v.insert     v8, s15, #4
    v.extract    s14, v12, #7
    v.insert     v7, s17, #5
    s.lshri      s15, s17, #32
    s.add        s17, s16, s13
    v.extract    s13, v10, #8
    s.or         s16, s2, s9
    v.extract    s2, v13, #8
    s.or         s9, s14, s12
    s.shli       s12, s13, #32
    s.shli       s13, s2, #32
    v.extract    s2, v9, #8
    v.insert     v8, s15, #5
    v.extract    s14, v12, #8
    v.insert     v7, s17, #6
    s.lshri      s15, s17, #32
    s.add        s17, s16, s9
    v.extract    s9, v10, #9
    s.or         s16, s2, s12
    v.extract    s2, v13, #9
    s.or         s12, s14, s13
    s.shli       s13, s9, #32
    s.shli       s9, s2, #32
    v.extract    s2, v9, #9
    v.insert     v8, s15, #6
    v.extract    s14, v12, #9
    v.insert     v7, s17, #7
    s.lshri      s15, s17, #32
    s.add        s17, s16, s12
    v.extract    s12, v10, #10
    s.or         s16, s2, s13
    v.extract    s2, v13, #10
    s.or         s13, s14, s9
    s.shli       s9, s12, #32
    s.shli       s12, s2, #32
    v.extract    s2, v9, #10
    v.insert     v8, s15, #7
    v.extract    s14, v12, #10
    v.insert     v7, s17, #8
    s.lshri      s15, s17, #32
    s.add        s17, s16, s13
    v.extract    s13, v10, #11
    s.or         s16, s2, s9
    v.extract    s2, v13, #11
    s.or         s9, s14, s12
    s.shli       s12, s13, #32
    s.shli       s13, s2, #32
    v.extract    s2, v9, #11
    v.insert     v8, s15, #8
    v.extract    s14, v12, #11
    v.insert     v7, s17, #9
    s.lshri      s15, s17, #32
    s.add        s17, s16, s9
    v.extract    s9, v10, #12
    s.or         s16, s2, s12
    v.extract    s2, v13, #12
    s.or         s12, s14, s13
    s.shli       s13, s9, #32
    s.shli       s9, s2, #32
    v.extract    s2, v9, #12
    v.insert     v8, s15, #9
    v.extract    s14, v12, #12
    v.insert     v7, s17, #10
    s.lshri      s15, s17, #32
    s.add        s17, s16, s12
    v.extract    s12, v10, #13
    s.or         s16, s2, s13
    v.extract    s2, v13, #13
    s.or         s13, s14, s9
    s.shli       s9, s12, #32
    s.shli       s12, s2, #32
    v.extract    s2, v9, #13
    v.insert     v8, s15, #10
    v.extract    s14, v12, #13
    v.insert     v7, s17, #11
    s.lshri      s15, s17, #32
    s.add        s17, s16, s13
    v.extract    s13, v10, #14
    s.or         s16, s2, s9
    v.extract    s2, v13, #14
    s.or         s9, s14, s12
    s.shli       s12, s13, #32
    s.shli       s13, s2, #32
    v.extract    s2, v9, #14
    v.insert     v8, s15, #11
    v.extract    s14, v12, #14
    v.insert     v7, s17, #12
    s.lshri      s15, s17, #32
    s.add        s17, s16, s9
    v.extract    s9, v10, #15
    s.or         s16, s2, s12
    v.extract    s2, v13, #15
    s.or         s12, s14, s13
    s.shli       s13, s9, #32
    s.shli       s9, s2, #32
    v.extract    s2, v9, #15
    v.insert     v8, s15, #12
    v.extract    s14, v12, #15
    v.insert     v7, s17, #13
    s.lshri      s15, s17, #32
    s.add        s17, s16, s12
    s.or         s12, s2, s13
    s.or         s2, s14, s9
    v.insert     v8, s15, #13
    v.insert     v7, s17, #14
    s.lshri      s9, s17, #32
    s.add        s13, s12, s2
    v.insert     v8, s9, #14
    v.insert     v7, s13, #15
    s.lshri      s2, s13, #32
    v.movi       v9, #31
    v.insert     v8, s2, #15
    v.ashr       v10, v7, v9
    v.movi       v9, #1
    v.movi       v12, #0
    v.cmp.ne     p1, v8, v10
    @p1 v.sel        v8, v9, v12
    s.movz       s2, #0
    v.reduce.or  s9, v8
    s.cmp.eq     s12, s9, s2
    br.nz        s12, narrow_ok_8
    trap         #677220
narrow_ok_8:
    .li       s2, #1128267776
    v.splat      v8, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v9, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v10, v8                         // ISA 8.8: <= 2**-22 relative
    .li       s2, #925353388
    v.splat      v12, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v13, [s3, v7]              // index is in elements (ISA sec 9.1)
    .li       s2, #1077936128
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s2, s4, s10
    s.add        s9, s1, s11
    s.movz       s12, #1
    vf.cvt.f16.f32 v14, v13
    s.add        s13, s1, s2
    s.shli       s14, s13, #1                    // element offset -> bytes (x2)
    vf.add       v13, v14, v11
    .li       s13, #3204448256
    v.splat      v11, s13                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s13, s8, s14                    // &out_ptr1[...]
    vf.add       v14, v13, v4
    v.splat      v4, s2
    v.add        v13, v3, v4
    vf.fms       v3, v8, v10, v9
    vf.fms       v4, v10, v3, v10
    vf.neg       v3, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v4, v3, v10
    vf.mul       v3, v5, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v4, v3, v12
    v.rsqrt.approx v3, v4                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v3, v3
    vf.mul       v9, v3, v11
    vf.fms       v10, v4, v8, v7
    vf.mul       v4, v9, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v7, v4, v3
    v.extract    s2, v7, #0
    v.splat      v3, s2
    vf.mul       v4, v14, v3
    vf.mul       v3, v4, v6
    vf.cvt.f32.f16 v4, v3
    @p3 v.st.h       [s13, #0], v4
    s.mov        s1, s9
    br.nz        s12, for_5
endfor_6:
__rctx_next:
    exit
