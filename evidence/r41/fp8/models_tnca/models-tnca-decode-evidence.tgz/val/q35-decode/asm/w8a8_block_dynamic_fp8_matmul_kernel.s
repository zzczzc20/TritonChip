    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #32]                   // N: i32 at arg_base+32
    s.movz       s4, #0
    s.movz       s5, #0
    s.add        s6, s3, s2
    s.movz       s7, #128
    s.cmp.lt     s8, s6, s4
    s.movz       s4, #0
    s.sub        s9, s5, s8
    s.movz       s5, #0
    s.cmp.lt     s8, s7, s4
    s.xor        s4, s6, s9
    s.sub        s6, s5, s8
    s.sub        s5, s4, s9
    s.xor        s4, s9, s6
    s.lshri      s8, s5, #7
    s.rdspecial  s9, pid.x
    s.xor        s10, s8, s4
    s.movz       s11, #8
    s.sub        s12, s10, s4
    s.rdspecial  s4, pid.y
    s.mul        s10, s9, s12
    s.mul        s9, s12, s11
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.add        s15, s10, s4
    s.cmp.lt     s4, s9, s12
    s.movz       s10, #0
    s.cmp.lt     s12, s15, s13
    s.sub        s13, s14, s4
    s.sub        s4, s10, s12
    s.xor        s10, s9, s13
    s.muli       s12, s8, #128
    s.xor        s8, s15, s4
    s.sub        s14, s10, s13
    s.xor        s10, s7, s6
    s.sub        s16, s8, s4
    s.ld.d       s8, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.movz       s17, #0
    s.sub        s18, s10, s6
    s.ld.d       s6, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.movz       s10, #0
    s.sub        s18, s5, s12
    s.ld.d       s5, [s1, #16]                   // C: device_ptr64 at arg_base+16
    s.addi       s12, s17, #0
    s.ld.d       s17, [s1, #24]                  // Bs: device_ptr64 at arg_base+24
    s.movz       s18, #1
    s.addi       s19, s10, #0
    s.ld.sw      s10, [s1, #40]                  // K: i32 at arg_base+40
    s.cmp.eq     s20, s14, s18
    s.ld.sw      s18, [s1, #56]                  // stride_bn: i32 at arg_base+56
    s.ld.sw      s21, [s1, #64]                  // stride_cm: i32 at arg_base+64
    s.ld.sw      s22, [s1, #72]                  // stride_bs_n: i32 at arg_base+72
    s.mov        s12, s16
    br.nz        s20, sdiv_done_1
    s.movz       s1, #0
    s.movz       s20, #31
    s.mov        s12, s1
    s.addi       s1, s20, #0
sdiv_2:
    s.lshr       s20, s16, s1
    s.shli       s23, s19, #1
    s.andi       s24, s20, #1
    s.movz       s20, #0
    s.or         s25, s23, s24
    s.movz       s23, #1
    s.cmp.geu    s24, s25, s14
    s.shl        s26, s23, s1
    s.sub        s23, s20, s24
    s.subi       s20, s1, #1
    s.and        s24, s14, s23
    s.and        s27, s26, s23
    s.sub        s23, s25, s24
    s.or         s24, s12, s27
    s.mov        s19, s23
    s.mov        s12, s24
    s.mov        s1, s20
    s.movz       s20, #0
    s.cmp.ge     s23, s1, s20
    br.nz        s23, sdiv_2
sdiv_done_1:
    s.xor        s1, s4, s13
    s.movz       s4, #0
    s.xor        s13, s12, s1
    s.movz       s12, #0
    s.movz       s14, #0
    s.cmp.lt     s16, s9, s4
    s.sub        s4, s13, s1
    s.movz       s1, #0
    s.cmp.lt     s13, s15, s12
    s.sub        s12, s14, s16
    s.mul        s14, s4, s11
    s.sub        s4, s1, s13
    s.xor        s1, s9, s12
    s.movz       s9, #1
    s.xor        s13, s15, s4
    s.sub        s15, s1, s12
    s.movz       s1, #0
    s.movz       s12, #1
    s.sub        s16, s9, s14
    s.sub        s19, s13, s4
    s.movz       s13, #0
    s.addi       s20, s1, #0
    s.cmp.eq     s1, s15, s12
    s.min.s      s12, s16, s11
    s.addi       s11, s13, #0
    s.mov        s20, s19
    br.nz        s1, sdiv_done_3
    s.movz       s1, #0
    s.movz       s13, #31
    s.mov        s20, s1
    s.addi       s1, s13, #0
sdiv_4:
    s.lshr       s13, s19, s1
    s.shli       s16, s11, #1
    s.andi       s23, s13, #1
    s.movz       s13, #0
    s.or         s24, s16, s23
    s.movz       s16, #1
    s.cmp.geu    s23, s24, s15
    s.shl        s25, s16, s1
    s.sub        s16, s13, s23
    s.subi       s13, s1, #1
    s.and        s23, s15, s16
    s.and        s26, s25, s16
    s.sub        s16, s24, s23
    s.or         s23, s20, s26
    s.mov        s11, s16
    s.mov        s20, s23
    s.mov        s1, s13
    s.movz       s13, #0
    s.cmp.ge     s16, s1, s13
    br.nz        s16, sdiv_4
sdiv_done_3:
    s.xor        s1, s11, s4
    s.movz       s11, #0
    s.sub        s13, s1, s4
    s.movz       s1, #0
    s.movz       s4, #0
    s.cmp.lt     s15, s12, s11
    s.movz       s11, #0
    s.cmp.lt     s16, s13, s1
    s.sub        s1, s4, s15
    s.sub        s4, s11, s16
    s.xor        s11, s12, s1
    s.xor        s15, s13, s4
    s.sub        s16, s11, s1
    s.movz       s1, #0
    s.movz       s11, #1
    s.sub        s19, s15, s4
    s.movz       s15, #0
    s.addi       s20, s1, #0
    s.cmp.eq     s1, s16, s11
    s.addi       s11, s15, #0
    s.mov        s20, s19
    br.nz        s1, sdiv_done_5
    s.movz       s1, #0
    s.movz       s15, #31
    s.mov        s20, s1
    s.addi       s1, s15, #0
sdiv_6:
    s.lshr       s15, s19, s1
    s.shli       s23, s11, #1
    s.andi       s24, s15, #1
    s.movz       s15, #0
    s.or         s25, s23, s24
    s.movz       s23, #1
    s.cmp.geu    s24, s25, s16
    s.shl        s26, s23, s1
    s.sub        s23, s15, s24
    s.subi       s15, s1, #1
    s.and        s24, s16, s23
    s.and        s27, s26, s23
    s.sub        s23, s25, s24
    s.or         s24, s20, s27
    s.mov        s11, s23
    s.mov        s20, s24
    s.mov        s1, s15
    s.movz       s15, #0
    s.cmp.ge     s23, s1, s15
    br.nz        s23, sdiv_6
sdiv_done_5:
    s.movz       s1, #0
    s.movz       s15, #0
    s.movz       s16, #0
    s.cmp.lt     s19, s12, s1
    s.movz       s1, #0
    s.cmp.lt     s20, s13, s15
    s.sub        s15, s16, s19
    s.sub        s16, s1, s20
    s.xor        s1, s12, s15
    s.xor        s12, s11, s4
    s.xor        s11, s13, s16
    s.sub        s13, s1, s15
    s.movz       s1, #0
    s.movz       s19, #1
    s.sub        s20, s12, s4
    s.sub        s4, s11, s16
    s.movz       s11, #0
    s.addi       s12, s1, #0
    s.cmp.eq     s1, s13, s19
    s.add        s19, s14, s20
    s.addi       s14, s11, #0
    s.mov        s12, s4
    br.nz        s1, sdiv_done_7
    s.movz       s1, #0
    s.movz       s11, #31
    s.mov        s12, s1
    s.addi       s1, s11, #0
sdiv_8:
    s.lshr       s11, s4, s1
    s.shli       s20, s14, #1
    s.andi       s23, s11, #1
    s.movz       s11, #0
    s.or         s24, s20, s23
    s.movz       s20, #1
    s.cmp.geu    s23, s24, s13
    s.shl        s25, s20, s1
    s.sub        s20, s11, s23
    s.subi       s11, s1, #1
    s.and        s23, s13, s20
    s.and        s26, s25, s20
    s.sub        s20, s24, s23
    s.or         s23, s12, s26
    s.mov        s14, s20
    s.mov        s12, s23
    s.mov        s1, s11
    s.movz       s11, #0
    s.cmp.ge     s20, s1, s11
    br.nz        s20, sdiv_8
sdiv_done_7:
    s.xor        s1, s16, s15
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s4, s12, s1
    v.iota       v1                              // arange(0, VLEN)
    s.sub        s11, s4, s1
    v.movi       v2, #16
    s.mul        s1, s11, s7
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v4, #32
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #48
    v.splat      v7, s1
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #64
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #80
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #96
    v.iota       v14                             // arange(0, VLEN)
    v.movi       v15, #112
    v.add        v16, v7, v0
    v.splat      v0, s3
    v.movi       v7, #0
    v.add        v17, v1, v2
    v.add        v1, v3, v4
    v.add        v2, v5, v6
    v.add        v3, v8, v9
    v.add        v4, v10, v11
    v.add        v5, v12, v13
    v.add        v6, v14, v15
    v.splat      v8, s1
    v.splat      v9, s1
    v.splat      v10, s1
    v.splat      v11, s1
    v.splat      v12, s1
    v.splat      v13, s1
    v.splat      v14, s1
    v.sub        v15, v7, v16
    v.sub        v18, v7, v0
    v.cmp.lt     p1, v16, v7
    v.cmp.lt     p2, v0, v7
    v.add        v19, v8, v17
    v.add        v8, v9, v1
    v.add        v1, v10, v2
    v.add        v2, v11, v3
    v.add        v3, v12, v4
    v.add        v4, v13, v5
    v.add        v5, v14, v6
    v.splat      v6, s3
    v.splat      v9, s3
    v.splat      v10, s3
    v.splat      v11, s3
    v.splat      v12, s3
    v.splat      v13, s3
    v.splat      v14, s3
    v.movi       v17, #1
    @p1 v.sel        v20, v15, v16
    @p2 v.sel        v15, v18, v0
    v.movi       v0, #0
    v.movi       v16, #0
    s.movz       s4, #31
idiv_9:
    v.splat      v18, s4
    v.shl        v21, v16, v17
    v.lshr       v22, v20, v18
    v.cmp.lt     p2, v16, v7
    v.and        v23, v22, v17
    v.shl        v22, v17, v18
    v.or         v18, v21, v23
    s.subi       s11, s4, #1
    v.cmp.geu    p3, v18, v15
    p.or         p4, p2, p3
    v.sub        v21, v18, v15
    @p4 v.sel        v23, v22, v7
    @p4 v.sel        v22, v21, v18
    v.or         v18, v0, v23
    v.mov        v16, v22
    v.mov        v0, v18
    s.mov        s4, s11
    s.movz       s11, #0
    s.cmp.ge     s12, s4, s11
    br.nz        s12, idiv_9
    v.movi       v0, #0
    v.sub        v15, v7, v16
    v.sub        v7, v0, v19
    v.sub        v17, v0, v6
    v.cmp.lt     p2, v19, v0
    v.cmp.lt     p3, v6, v0
    @p1 v.sel        v18, v15, v16
    v.movi       v15, #1
    @p2 v.sel        v16, v7, v19
    @p3 v.sel        v7, v17, v6
    v.movi       v6, #0
    v.movi       v17, #0
    s.movz       s4, #31
idiv_10:
    v.splat      v19, s4
    v.shl        v20, v17, v15
    v.lshr       v21, v16, v19
    v.cmp.lt     p1, v17, v0
    v.and        v22, v21, v15
    v.shl        v21, v15, v19
    v.or         v19, v20, v22
    s.subi       s11, s4, #1
    v.cmp.geu    p3, v19, v7
    p.or         p4, p1, p3
    v.sub        v20, v19, v7
    @p4 v.sel        v22, v21, v0
    @p4 v.sel        v21, v20, v19
    v.or         v19, v6, v22
    v.mov        v17, v21
    v.mov        v6, v19
    s.mov        s4, s11
    s.movz       s11, #0
    s.cmp.ge     s12, s4, s11
    br.nz        s12, idiv_10
    v.movi       v6, #0
    v.sub        v7, v0, v17
    v.sub        v0, v6, v8
    v.sub        v15, v6, v9
    v.cmp.lt     p1, v8, v6
    v.cmp.lt     p3, v9, v6
    @p2 v.sel        v16, v7, v17
    v.movi       v7, #1
    @p1 v.sel        v17, v0, v8
    @p3 v.sel        v0, v15, v9
    v.movi       v8, #0
    v.movi       v9, #0
    s.movz       s4, #31
idiv_11:
    v.splat      v15, s4
    v.shl        v19, v9, v7
    v.lshr       v20, v17, v15
    v.cmp.lt     p2, v9, v6
    v.and        v21, v20, v7
    v.shl        v20, v7, v15
    v.or         v15, v19, v21
    s.subi       s11, s4, #1
    v.cmp.geu    p3, v15, v0
    p.or         p4, p2, p3
    v.sub        v19, v15, v0
    @p4 v.sel        v21, v20, v6
    @p4 v.sel        v20, v19, v15
    v.or         v15, v8, v21
    v.mov        v9, v20
    v.mov        v8, v15
    s.mov        s4, s11
    s.movz       s11, #0
    s.cmp.ge     s12, s4, s11
    br.nz        s12, idiv_11
    v.movi       v0, #0
    v.sub        v7, v6, v9
    v.sub        v6, v0, v1
    v.sub        v8, v0, v10
    v.cmp.lt     p2, v1, v0
    v.cmp.lt     p3, v10, v0
    @p1 v.sel        v15, v7, v9
    v.movi       v7, #1
    @p2 v.sel        v9, v6, v1
    @p3 v.sel        v1, v8, v10
    v.movi       v6, #0
    v.movi       v8, #0
    s.movz       s4, #31
idiv_12:
    v.splat      v10, s4
    v.shl        v17, v8, v7
    v.lshr       v19, v9, v10
    v.cmp.lt     p1, v8, v0
    v.and        v20, v19, v7
    v.shl        v19, v7, v10
    v.or         v10, v17, v20
    s.subi       s11, s4, #1
    v.cmp.geu    p3, v10, v1
    p.or         p4, p1, p3
    v.sub        v17, v10, v1
    @p4 v.sel        v20, v19, v0
    @p4 v.sel        v19, v17, v10
    v.or         v10, v6, v20
    v.mov        v8, v19
    v.mov        v6, v10
    s.mov        s4, s11
    s.movz       s11, #0
    s.cmp.ge     s12, s4, s11
    br.nz        s12, idiv_12
    v.movi       v1, #0
    v.sub        v6, v0, v8
    v.sub        v0, v1, v2
    v.sub        v7, v1, v11
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p3, v11, v1
    @p2 v.sel        v9, v6, v8
    v.movi       v6, #1
    @p1 v.sel        v8, v0, v2
    @p3 v.sel        v0, v7, v11
    v.movi       v2, #0
    v.movi       v7, #0
    s.movz       s4, #31
idiv_13:
    v.splat      v10, s4
    v.shl        v11, v7, v6
    v.lshr       v17, v8, v10
    v.cmp.lt     p2, v7, v1
    v.and        v19, v17, v6
    v.shl        v17, v6, v10
    v.or         v10, v11, v19
    s.subi       s11, s4, #1
    v.cmp.geu    p3, v10, v0
    p.or         p4, p2, p3
    v.sub        v11, v10, v0
    @p4 v.sel        v19, v17, v1
    @p4 v.sel        v17, v11, v10
    v.or         v10, v2, v19
    v.mov        v7, v17
    v.mov        v2, v10
    s.mov        s4, s11
    s.movz       s11, #0
    s.cmp.ge     s12, s4, s11
    br.nz        s12, idiv_13
    v.movi       v0, #0
    v.sub        v2, v1, v7
    v.sub        v1, v0, v3
    v.sub        v6, v0, v12
    v.cmp.lt     p2, v3, v0
    v.cmp.lt     p3, v12, v0
    @p1 v.sel        v8, v2, v7
    v.movi       v2, #1
    @p2 v.sel        v7, v1, v3
    @p3 v.sel        v1, v6, v12
    v.movi       v3, #0
    v.movi       v6, #0
    s.movz       s4, #31
idiv_14:
    v.splat      v10, s4
    v.shl        v11, v6, v2
    v.lshr       v12, v7, v10
    v.cmp.lt     p1, v6, v0
    v.and        v17, v12, v2
    v.shl        v12, v2, v10
    v.or         v10, v11, v17
    s.subi       s11, s4, #1
    v.cmp.geu    p3, v10, v1
    p.or         p4, p1, p3
    v.sub        v11, v10, v1
    @p4 v.sel        v17, v12, v0
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v17
    v.mov        v6, v12
    v.mov        v3, v10
    s.mov        s4, s11
    s.movz       s11, #0
    s.cmp.ge     s12, s4, s11
    br.nz        s12, idiv_14
    v.movi       v1, #0
    v.sub        v2, v0, v6
    v.sub        v0, v1, v4
    v.sub        v3, v1, v13
    v.cmp.lt     p1, v4, v1
    v.cmp.lt     p3, v13, v1
    @p2 v.sel        v7, v2, v6
    v.movi       v2, #1
    @p1 v.sel        v6, v0, v4
    @p3 v.sel        v0, v3, v13
    v.movi       v3, #0
    v.movi       v4, #0
    s.movz       s4, #31
idiv_15:
    v.splat      v10, s4
    v.shl        v11, v4, v2
    v.lshr       v12, v6, v10
    v.cmp.lt     p2, v4, v1
    v.and        v13, v12, v2
    v.shl        v12, v2, v10
    v.or         v10, v11, v13
    s.subi       s11, s4, #1
    v.cmp.geu    p3, v10, v0
    p.or         p4, p2, p3
    v.sub        v11, v10, v0
    @p4 v.sel        v13, v12, v1
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v4, v12
    v.mov        v3, v10
    s.mov        s4, s11
    s.movz       s11, #0
    s.cmp.ge     s12, s4, s11
    br.nz        s12, idiv_15
    v.movi       v0, #0
    v.sub        v2, v1, v4
    v.sub        v1, v0, v5
    v.sub        v3, v0, v14
    v.cmp.lt     p2, v5, v0
    v.cmp.lt     p3, v14, v0
    @p1 v.sel        v6, v2, v4
    v.movi       v2, #1
    @p2 v.sel        v4, v1, v5
    @p3 v.sel        v1, v3, v14
    v.movi       v3, #0
    v.movi       v5, #0
    s.movz       s4, #31
idiv_16:
    v.splat      v10, s4
    v.shl        v11, v5, v2
    v.lshr       v12, v4, v10
    v.cmp.lt     p1, v5, v0
    v.and        v13, v12, v2
    v.shl        v12, v2, v10
    v.or         v10, v11, v13
    s.subi       s11, s4, #1
    v.cmp.geu    p3, v10, v1
    p.or         p4, p1, p3
    v.sub        v11, v10, v1
    @p4 v.sel        v13, v12, v0
    @p4 v.sel        v12, v11, v10
    v.or         v10, v3, v13
    v.mov        v5, v12
    v.mov        v3, v10
    s.mov        s4, s11
    s.movz       s11, #0
    s.cmp.ge     s12, s4, s11
    br.nz        s12, idiv_16
    v.sub        v1, v0, v5
    v.movi       v0, #0
    @p2 v.sel        v2, v1, v5
    v.movi       v1, #0
    v.movi       v3, #0
    v.movi       v4, #0
    v.sub        v5, v0, v18
    v.sub        v10, v1, v16
    v.sub        v11, v3, v15
    v.cmp.lt     p1, v18, v0
    v.cmp.lt     p2, v16, v1
    v.cmp.lt     p3, v15, v3
    @p1 v.sel        v12, v5, v18
    v.movi       v5, #7
    @p2 v.sel        v13, v10, v16
    v.movi       v10, #7
    @p3 v.sel        v14, v11, v15
    v.movi       v11, #7
    v.lshr       v17, v12, v5
    v.lshr       v5, v13, v10
    v.lshr       v10, v14, v11
    v.movi       v11, #128
    v.sub        v12, v0, v17
    v.movi       v13, #128
    v.sub        v14, v1, v5
    v.movi       v19, #128
    v.sub        v20, v3, v10
    v.movi       v21, #128
    v.sub        v22, v0, v11
    @p1 v.sel        v23, v12, v17
    v.sub        v12, v1, v13
    @p2 v.sel        v17, v14, v5
    v.sub        v5, v3, v19
    @p3 v.sel        v14, v20, v10
    v.cmp.lt     p1, v11, v0
    v.cmp.lt     p2, v13, v1
    v.cmp.lt     p3, v19, v3
    s.movz       s4, #16
    s.movz       s11, #32
    s.movz       s12, #48
    s.movz       s13, #64
    v.sub        v0, v4, v9
    s.movz       s14, #80
    s.movz       s15, #96
    v.sub        v1, v4, v21
    s.movz       s16, #112
    v.movi       v3, #7
    v.movi       v10, #1
    v.movi       v10, #0
    v.movi       v20, #128
    @p1 v.sel        v24, v22, v11
    v.sub        v11, v10, v8
    v.cmp.lt     p1, v9, v4
    @p1 v.sel        v22, v0, v9
    v.movi       v0, #7
    v.lshr       v24, v22, v3
    v.sub        v3, v10, v20
    v.sub        v22, v4, v24
    v.movi       v25, #1
    v.movi       v25, #0
    v.movi       v26, #128
    @p1 v.sel        v27, v22, v24
    v.cmp.lt     p1, v8, v10
    @p1 v.sel        v22, v11, v8
    @p2 v.sel        v11, v12, v13
    v.sub        v11, v25, v7
    v.cmp.lt     p2, v7, v25
    @p2 v.sel        v12, v11, v7
    v.movi       v11, #7
    v.lshr       v13, v22, v0
    v.lshr       v0, v12, v11
    v.sub        v11, v10, v13
    v.sub        v12, v25, v26
    @p1 v.sel        v22, v11, v13
    v.cmp.lt     p1, v21, v4
    v.movi       v4, #1
    v.movi       v4, #0
    v.sub        v11, v25, v0
    v.movi       v13, #128
    @p2 v.sel        v24, v11, v0
    v.cmp.lt     p2, v6, v4
    @p3 v.sel        v0, v5, v19
    v.sub        v0, v4, v6
    v.movi       v5, #7
    @p2 v.sel        v11, v0, v6
    v.sub        v0, v4, v13
    v.lshr       v19, v11, v5
    v.cmp.lt     p3, v20, v10
    v.movi       v5, #1
    v.movi       v5, #0
    v.sub        v10, v4, v19
    v.movi       v11, #128
    @p2 v.sel        v28, v10, v19
    v.cmp.lt     p2, v2, v5
    @p1 v.sel        v10, v1, v21
    v.sub        v1, v5, v2
    v.movi       v10, #7
    @p2 v.sel        v19, v1, v2
    v.sub        v1, v5, v11
    v.lshr       v21, v19, v10
    v.cmp.lt     p1, v26, v25
    v.movi       v10, #1
    v.sub        v10, v5, v21
    v.splat      v19, s22
    @p2 v.sel        v25, v10, v21
    v.splat      v10, s22
    v.cmp.lt     p2, v13, v4
    v.splat      v4, s22
    @p3 v.sel        v21, v3, v20
    v.splat      v3, s22
    v.splat      v20, s22
    v.cmp.lt     p3, v11, v5
    v.splat      v5, s22
    v.movi       v21, #1
    s.add        s20, s10, s2
    @p1 v.sel        v21, v12, v26
    s.movz       s2, #0
    s.movz       s23, #0
    s.cmp.lt     s24, s20, s2
    s.movz       s2, #0
    s.sub        s25, s23, s24
    s.movz       s23, #0
    s.cmp.lt     s24, s7, s2
    v.splat      v12, s22
    v.splat      v21, s22
    v.movi       v26, #1
    s.xor        s2, s20, s25
    s.sub        s20, s23, s24
    s.sub        s22, s2, s25
    s.xor        s2, s7, s20
    s.lshri      s23, s22, #7
    @p2 v.sel        v26, v0, v13
    s.muli       s24, s23, #128
    s.xor        s26, s25, s20
    s.movz       s25, #0
    s.xor        s27, s23, s26
    v.movi       v0, #1
    s.movz       s23, #0
    s.movz       s28, #0
    @p3 v.sel        v0, v1, v11
    v.mul        v0, v23, v19
    v.mul        v1, v17, v10
    v.mul        v10, v14, v4
    v.mul        v4, v27, v3
    v.mul        v3, v22, v20
    v.mul        v11, v24, v5
    v.mul        v5, v28, v12
    v.mul        v12, v25, v21
    s.sub        s29, s2, s20
    s.sub        s2, s22, s24
    s.sub        s2, s27, s26
    s.addi       s20, s25, #0
    s.addi       s22, s23, #0
    s.addi       s23, s28, #0
    s.addi       s24, s17, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_25:
    s.cmp.ge     s17, s20, s2
    br.nz        s17, endfor_26
    s.mul        s17, s20, s7
    s.muli       s26, s22, #2
    s.movz       s27, #0
    v.iota       v13                             // arange(0, VLEN)
    s.rdspecial  s28, arg_base
    s.sub        s29, s10, s17
    s.add        s17, s8, s26
    s.add        s30, s27, s29                   // the tile origin
    s.ld.d       s27, [s28, #80]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v14, s30
    s.add        s28, s8, s26
    v.cmp.lt     p1, v13, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s17, #0]
    s.addi       s17, s27, #0
    s.add        s30, s8, s26
    s.addi       s31, s17, #64
    s.addi       s32, s17, #128
    s.add        s33, s8, s26
    vf.cvt.bf16.f32 v17, v14
    s.addi       s34, s17, #192
    v.st.w       [s17, #0], v17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s28, #0]
    s.add        s28, s8, s26
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s17, #256
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s30, #0]
    s.add        s30, s8, s26
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s32, #0], v17
    s.addi       s32, s17, #320
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.add        s33, s8, s26
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s34, #0], v17
    s.addi       s34, s17, #384
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s28, #0]
    s.add        s28, s8, s26
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s17, #448
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s30, #0]
    s.add        s30, s8, s26
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s32, #0], v17
    s.addi       s32, s17, #512
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.add        s33, s8, s26
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s34, #0], v17
    s.addi       s34, s17, #576
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s28, #0]
    s.add        s28, s8, s26
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s17, #640
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s30, #0]
    s.add        s30, s8, s26
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s32, #0], v17
    s.addi       s32, s17, #704
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.add        s33, s8, s26
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s34, #0], v17
    s.addi       s34, s17, #768
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s28, #0]
    s.add        s28, s8, s26
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s17, #832
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s30, #0]
    s.add        s30, s8, s26
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s32, #0], v17
    s.addi       s32, s17, #896
    s.addi       s35, s17, #960
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.add        s17, s8, s26
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s34, #0], v17
    s.movz       s33, #0
    s.add        s34, s33, s4                    // the tile origin
    v.splat      v14, s34
    s.movz       s33, #0
    v.add        v17, v13, v14
    s.add        s34, s33, s29                   // the tile origin
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s28, #0]
    s.addi       s28, s26, #32
    v.splat      v19, s34
    s.add        s33, s8, s28
    v.cmp.lt     p2, v17, v19
    s.addi       s28, s26, #32
    vf.cvt.bf16.f32 v17, v14
    s.add        s34, s8, s28
    v.st.w       [s31, #0], v17
    s.addi       s28, s27, #1024
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s30, #0]
    s.addi       s30, s26, #32
    s.add        s31, s8, s30
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s32, #0], v17
    s.addi       s30, s28, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s17, #0]
    s.addi       s17, s26, #32
    s.add        s32, s8, s17
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    s.addi       s17, s28, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s33, s26, #32
    s.add        s35, s8, s33
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s33, s28, #192
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #32
    s.add        s34, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s31, #0]
    s.addi       s30, s28, #256
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s17, #0], v17
    s.addi       s17, s26, #32
    s.add        s31, s8, s17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s17, s28, #320
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s33, #0], v17
    s.addi       s32, s26, #32
    s.add        s33, s8, s32
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s32, s28, #384
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #32
    s.add        s35, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s30, s28, #448
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s17, #0], v17
    s.addi       s17, s26, #32
    s.add        s34, s8, s17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s31, #0]
    s.addi       s17, s28, #512
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s32, #0], v17
    s.addi       s31, s26, #32
    s.add        s32, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s31, s28, #576
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #32
    s.add        s33, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s30, s28, #640
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s17, #0], v17
    s.addi       s17, s26, #32
    s.add        s35, s8, s17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s17, s28, #704
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #32
    s.add        s34, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s31, s28, #768
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #32
    s.add        s32, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s30, s28, #832
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s17, #0], v17
    s.addi       s17, s26, #32
    s.add        s33, s8, s17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s17, s28, #896
    s.addi       s35, s28, #960
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.movz       s28, #0
    s.add        s31, s28, s11                   // the tile origin
    v.splat      v14, s31
    s.movz       s28, #0
    v.add        v17, v13, v14
    s.add        s31, s28, s29                   // the tile origin
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s28, s26, #64
    v.splat      v19, s31
    s.add        s31, s8, s28
    v.cmp.lt     p1, v17, v19
    s.addi       s28, s26, #64
    vf.cvt.bf16.f32 v17, v14
    s.add        s34, s8, s28
    v.st.w       [s30, #0], v17
    s.addi       s28, s27, #2048
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s30, s26, #64
    s.add        s32, s8, s30
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s17, #0], v17
    s.addi       s17, s28, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s30, s26, #64
    s.add        s33, s8, s30
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    s.addi       s30, s28, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s31, #0]
    s.addi       s31, s26, #64
    s.add        s35, s8, s31
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s31, s28, #192
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s17, #0], v17
    s.addi       s17, s26, #64
    s.add        s34, s8, s17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s17, s28, #256
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #64
    s.add        s32, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s30, s28, #320
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #64
    s.add        s33, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s31, s28, #384
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s17, #0], v17
    s.addi       s17, s26, #64
    s.add        s35, s8, s17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s17, s28, #448
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #64
    s.add        s34, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s30, s28, #512
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #64
    s.add        s32, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s31, s28, #576
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s17, #0], v17
    s.addi       s17, s26, #64
    s.add        s33, s8, s17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s17, s28, #640
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #64
    s.add        s35, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s30, s28, #704
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #64
    s.add        s34, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s31, s28, #768
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s17, #0], v17
    s.addi       s17, s26, #64
    s.add        s32, s8, s17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s17, s28, #832
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #64
    s.add        s33, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s30, s28, #896
    s.addi       s35, s28, #960
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.movz       s28, #0
    s.add        s31, s28, s12                   // the tile origin
    v.splat      v14, s31
    s.movz       s28, #0
    v.add        v17, v13, v14
    s.add        s31, s28, s29                   // the tile origin
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s28, s26, #96
    v.splat      v19, s31
    s.add        s31, s8, s28
    v.cmp.lt     p2, v17, v19
    s.addi       s28, s26, #96
    vf.cvt.bf16.f32 v17, v14
    s.add        s34, s8, s28
    v.st.w       [s17, #0], v17
    s.addi       s17, s27, #3072
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s28, s26, #96
    s.add        s32, s8, s28
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s28, s17, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s30, s26, #96
    s.add        s33, s8, s30
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    s.addi       s30, s17, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s31, #0]
    s.addi       s31, s26, #96
    s.add        s35, s8, s31
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s17, #0], v17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s31, s17, #192
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #96
    s.add        s34, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s28, s17, #256
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #96
    s.add        s32, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s30, s17, #320
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #96
    s.add        s33, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s31, s17, #384
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #96
    s.add        s35, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s28, s17, #448
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #96
    s.add        s34, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s30, s17, #512
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #96
    s.add        s32, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s31, s17, #576
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #96
    s.add        s33, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s28, s17, #640
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #96
    s.add        s35, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s30, s17, #704
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #96
    s.add        s34, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s31, s17, #768
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #96
    s.add        s32, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s28, s17, #832
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #96
    s.add        s33, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s30, s17, #896
    s.addi       s35, s17, #960
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.movz       s17, #0
    s.add        s31, s17, s13                   // the tile origin
    v.splat      v14, s31
    s.movz       s17, #0
    v.add        v17, v13, v14
    s.add        s31, s17, s29                   // the tile origin
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s17, s26, #128
    v.splat      v19, s31
    s.add        s31, s8, s17
    v.cmp.lt     p1, v17, v19
    s.addi       s17, s26, #128
    vf.cvt.bf16.f32 v17, v14
    s.add        s34, s8, s17
    v.st.w       [s28, #0], v17
    s.addi       s17, s27, #4096
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s28, s26, #128
    s.add        s32, s8, s28
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s28, s17, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s30, s26, #128
    s.add        s33, s8, s30
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    s.addi       s30, s17, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s31, #0]
    s.addi       s31, s26, #128
    s.add        s35, s8, s31
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s17, #0], v17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s31, s17, #192
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #128
    s.add        s34, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s28, s17, #256
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #128
    s.add        s32, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s30, s17, #320
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #128
    s.add        s33, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s31, s17, #384
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #128
    s.add        s35, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s28, s17, #448
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #128
    s.add        s34, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s30, s17, #512
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #128
    s.add        s32, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s31, s17, #576
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #128
    s.add        s33, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s28, s17, #640
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #128
    s.add        s35, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s30, s17, #704
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #128
    s.add        s34, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s31, s17, #768
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #128
    s.add        s32, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s28, s17, #832
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #128
    s.add        s33, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s30, s17, #896
    s.addi       s35, s17, #960
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.movz       s17, #0
    s.add        s31, s17, s14                   // the tile origin
    v.splat      v14, s31
    s.movz       s17, #0
    v.add        v17, v13, v14
    s.add        s31, s17, s29                   // the tile origin
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s17, s26, #160
    v.splat      v19, s31
    s.add        s31, s8, s17
    v.cmp.lt     p2, v17, v19
    s.addi       s17, s26, #160
    vf.cvt.bf16.f32 v17, v14
    s.add        s34, s8, s17
    v.st.w       [s28, #0], v17
    s.addi       s17, s27, #5120
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s28, s26, #160
    s.add        s32, s8, s28
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s28, s17, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s30, s26, #160
    s.add        s33, s8, s30
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    s.addi       s30, s17, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s31, #0]
    s.addi       s31, s26, #160
    s.add        s35, s8, s31
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s17, #0], v17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s31, s17, #192
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #160
    s.add        s34, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s28, s17, #256
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #160
    s.add        s32, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s30, s17, #320
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #160
    s.add        s33, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s31, s17, #384
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #160
    s.add        s35, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s28, s17, #448
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #160
    s.add        s34, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s30, s17, #512
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #160
    s.add        s32, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s31, s17, #576
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #160
    s.add        s33, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s28, s17, #640
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #160
    s.add        s35, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s30, s17, #704
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #160
    s.add        s34, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s31, s17, #768
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #160
    s.add        s32, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s28, s17, #832
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #160
    s.add        s33, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s35, #0]
    s.addi       s30, s17, #896
    s.addi       s35, s17, #960
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.movz       s17, #0
    s.add        s31, s17, s15                   // the tile origin
    v.splat      v14, s31
    s.movz       s17, #0
    v.add        v17, v13, v14
    s.add        s31, s17, s29                   // the tile origin
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s34, #0]
    s.addi       s17, s26, #192
    v.splat      v19, s31
    s.add        s31, s8, s17
    v.cmp.lt     p1, v17, v19
    s.addi       s17, s26, #192
    vf.cvt.bf16.f32 v17, v14
    s.add        s34, s8, s17
    v.st.w       [s28, #0], v17
    s.addi       s17, s27, #6144
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s32, #0]
    s.addi       s28, s26, #192
    s.add        s32, s8, s28
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s28, s17, #64
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v14, [s33, #0]
    s.addi       s30, s26, #192
    s.add        s33, s8, s30
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    s.addi       s30, s17, #128
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s31, #0]
    s.addi       s31, s26, #192
    s.add        s35, s8, s31
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s17, #0], v17
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s31, s17, #192
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #192
    s.add        s34, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s28, s17, #256
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #192
    s.add        s32, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s30, s17, #320
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #192
    s.add        s33, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s31, s17, #384
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #192
    s.add        s35, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s28, s17, #448
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #192
    s.add        s34, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s30, s17, #512
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #192
    s.add        s32, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s31, s17, #576
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #192
    s.add        s33, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s28, s17, #640
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #192
    s.add        s35, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s34, #0]
    s.addi       s30, s17, #704
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.addi       s31, s26, #192
    s.add        s34, s8, s31
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s32, #0]
    s.addi       s31, s17, #768
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s28, #0], v17
    s.addi       s28, s26, #192
    s.add        s32, s8, s28
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s33, #0]
    s.addi       s28, s17, #832
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s30, #0], v17
    s.addi       s30, s26, #192
    s.add        s33, s8, s30
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v14, [s35, #0]
    s.addi       s30, s17, #896
    s.addi       s35, s17, #960
    vf.cvt.bf16.f32 v17, v14
    v.st.w       [s31, #0], v17
    s.movz       s17, #0
    s.add        s31, s17, s16                   // the tile origin
    v.splat      v14, s31
    s.movz       s17, #0
    v.add        v17, v13, v14
    s.add        s31, s17, s29                   // the tile origin
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s34, #0]
    s.addi       s17, s26, #224
    v.splat      v14, s31
    s.add        s31, s8, s17
    v.cmp.lt     p2, v17, v14
    s.addi       s17, s26, #224
    vf.cvt.bf16.f32 v14, v13
    s.add        s34, s8, s17
    v.st.w       [s28, #0], v14
    s.addi       s17, s27, #7168
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s32, #0]
    s.addi       s28, s26, #224
    s.add        s32, s8, s28
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s30, #0], v14
    s.addi       s28, s17, #64
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s33, #0]
    s.addi       s30, s26, #224
    s.add        s33, s8, s30
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s35, #0], v14
    fence.acq_rel.device
    s.addi       s30, s17, #128
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s31, #0]
    s.addi       s31, s26, #224
    s.add        s35, s8, s31
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s17, #0], v14
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s34, #0]
    s.addi       s31, s17, #192
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s28, #0], v14
    s.addi       s28, s26, #224
    s.add        s34, s8, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s32, #0]
    s.addi       s28, s17, #256
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s30, #0], v14
    s.addi       s30, s26, #224
    s.add        s32, s8, s30
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s33, #0]
    s.addi       s30, s17, #320
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s31, #0], v14
    s.addi       s31, s26, #224
    s.add        s33, s8, s31
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s35, #0]
    s.addi       s31, s17, #384
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s28, #0], v14
    s.addi       s28, s26, #224
    s.add        s35, s8, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s34, #0]
    s.addi       s28, s17, #448
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s30, #0], v14
    s.addi       s30, s26, #224
    s.add        s34, s8, s30
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s32, #0]
    s.addi       s30, s17, #512
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s31, #0], v14
    s.addi       s31, s26, #224
    s.add        s32, s8, s31
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s33, #0]
    s.addi       s31, s17, #576
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s28, #0], v14
    s.addi       s28, s26, #224
    s.add        s33, s8, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s35, #0]
    s.addi       s28, s17, #640
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s30, #0], v14
    s.addi       s30, s26, #224
    s.add        s35, s8, s30
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s34, #0]
    s.addi       s30, s17, #704
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s31, #0], v14
    s.addi       s31, s26, #224
    s.add        s34, s8, s31
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s32, #0]
    s.addi       s31, s17, #768
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s28, #0], v14
    s.addi       s28, s26, #224
    s.addi       s32, s26, #224
    s.add        s26, s8, s28
    s.add        s28, s8, s32
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s33, #0]
    s.addi       s32, s17, #832
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s30, #0], v14
    s.addi       s30, s17, #896
    s.addi       s33, s17, #960
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s35, #0]
    s.addi       s17, s27, #0
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s31, #0], v14
    s.addi       s31, s27, #1024
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s34, #0]
    s.addi       s34, s27, #64
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s32, #0], v14
    s.addi       s32, s27, #1088
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s26, #0]
    s.addi       s26, s27, #2048
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s30, #0], v14
    s.addi       s30, s27, #2112
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s28, #0]
    s.addi       s28, s27, #3072
    vf.cvt.bf16.f32 v14, v13
    v.st.w       [s33, #0], v14
    fence.acq_rel.device
    s.addi       s33, s27, #3136
    v.ld.w       v13, [s17, #0]
    s.addi       s17, s27, #4096
    v.ld.w       v14, [s31, #0]
    vf.abs       v17, v13
    s.addi       s31, s27, #4160
    v.ld.w       v13, [s34, #0]
    vf.abs       v19, v14
    s.addi       s34, s27, #5120
    vf.max.ieee  v14, v17, v19
    v.ld.w       v17, [s32, #0]
    vf.abs       v19, v13
    s.addi       s32, s27, #5184
    v.ld.w       v13, [s26, #0]
    vf.abs       v20, v17
    s.addi       s26, s27, #6144
    vf.max.ieee  v17, v19, v20
    v.ld.w       v19, [s30, #0]
    vf.abs       v20, v13
    s.addi       s30, s27, #6208
    vf.max.ieee  v13, v14, v20
    v.ld.w       v14, [s28, #0]
    vf.abs       v20, v19
    s.addi       s28, s27, #7168
    vf.max.ieee  v19, v17, v20
    v.ld.w       v17, [s33, #0]
    vf.abs       v20, v14
    s.addi       s33, s27, #7232
    vf.max.ieee  v14, v13, v20
    v.ld.w       v13, [s17, #0]
    s.addi       s17, s27, #128
    vf.abs       v20, v17
    vf.max.ieee  v17, v19, v20
    v.ld.w       v19, [s31, #0]
    vf.abs       v20, v13
    vf.max.ieee  v13, v14, v20
    s.addi       s31, s27, #1152
    v.ld.w       v14, [s17, #0]
    vf.abs       v20, v19
    vf.max.ieee  v19, v17, v20
    vf.abs       v17, v14
    v.ld.w       v14, [s34, #0]
    v.ld.w       v20, [s31, #0]
    vf.abs       v21, v14
    vf.max.ieee  v14, v13, v21
    s.addi       s17, s27, #2176
    vf.abs       v13, v20
    v.ld.w       v20, [s32, #0]
    vf.max.ieee  v21, v17, v13
    v.ld.w       v13, [s26, #0]
    vf.abs       v17, v20
    vf.max.ieee  v20, v19, v17
    v.ld.w       v17, [s17, #0]
    vf.abs       v19, v13
    vf.max.ieee  v13, v14, v19
    s.addi       s17, s27, #3200
    vf.abs       v14, v17
    v.ld.w       v17, [s30, #0]
    vf.max.ieee  v19, v21, v14
    v.ld.w       v14, [s28, #0]
    vf.abs       v21, v17
    vf.max.ieee  v17, v20, v21
    v.ld.w       v20, [s17, #0]
    vf.abs       v21, v14
    vf.max.ieee  v14, v13, v21
    vf.reduce.max.b v13, v14
    s.addi       s17, s27, #192
    s.addi       s26, s27, #1216
    v.ld.w       v14, [s17, #0]
    s.addi       s17, s27, #2240
    s.addi       s28, s27, #3264
    s.addi       s30, s27, #4224
    s.addi       s31, s27, #5248
    vf.abs       v21, v20
    s.addi       s32, s27, #6272
    s.addi       s34, s27, #7296
    vf.max.ieee  v20, v19, v21
    v.ld.w       v19, [s26, #0]
    vf.abs       v21, v14
    v.ld.w       v14, [s17, #0]
    vf.abs       v22, v19
    vf.max.ieee  v19, v21, v22
    v.ld.w       v21, [s30, #0]
    vf.abs       v22, v14
    vf.max.ieee  v14, v19, v22
    v.ld.w       v19, [s31, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v20, v22
    v.ld.w       v20, [s32, #0]
    vf.abs       v22, v19
    vf.max.ieee  v19, v21, v22
    v.ld.w       v21, [s33, #0]
    vf.abs       v22, v20
    vf.max.ieee  v20, v19, v22
    v.ld.w       v19, [s28, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v17, v22
    vf.reduce.max.b v17, v21
    s.addi       s17, s27, #256
    s.addi       s26, s27, #1280
    v.ld.w       v21, [s17, #0]
    s.addi       s17, s27, #2304
    s.addi       s28, s27, #3328
    s.addi       s30, s27, #4288
    s.addi       s31, s27, #5312
    vf.abs       v22, v19
    s.addi       s32, s27, #6336
    s.addi       s33, s27, #7360
    vf.max.ieee  v19, v14, v22
    v.ld.w       v14, [s26, #0]
    vf.abs       v22, v21
    v.ld.w       v21, [s17, #0]
    vf.abs       v23, v14
    vf.max.ieee  v14, v22, v23
    v.ld.w       v22, [s30, #0]
    vf.abs       v23, v21
    vf.max.ieee  v21, v14, v23
    v.ld.w       v14, [s31, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v19, v23
    v.ld.w       v19, [s32, #0]
    vf.abs       v23, v14
    vf.max.ieee  v14, v22, v23
    v.ld.w       v22, [s34, #0]
    vf.abs       v23, v19
    vf.max.ieee  v19, v14, v23
    v.ld.w       v14, [s28, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v20, v23
    vf.reduce.max.b v20, v22
    s.addi       s17, s27, #320
    s.addi       s26, s27, #1344
    v.ld.w       v22, [s17, #0]
    s.addi       s17, s27, #2368
    s.addi       s28, s27, #3392
    s.addi       s30, s27, #4352
    s.addi       s31, s27, #5376
    vf.abs       v23, v14
    s.addi       s32, s27, #6400
    s.addi       s34, s27, #7424
    vf.max.ieee  v14, v21, v23
    v.ld.w       v21, [s26, #0]
    vf.abs       v23, v22
    v.ld.w       v22, [s17, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v23, v24
    v.ld.w       v23, [s30, #0]
    vf.abs       v24, v22
    vf.max.ieee  v22, v21, v24
    v.ld.w       v21, [s31, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v14, v24
    v.ld.w       v14, [s32, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v23, v24
    v.ld.w       v23, [s33, #0]
    vf.abs       v24, v14
    vf.max.ieee  v14, v21, v24
    v.ld.w       v21, [s28, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v19, v24
    vf.reduce.max.b v19, v23
    s.addi       s17, s27, #384
    s.addi       s26, s27, #1408
    v.ld.w       v23, [s17, #0]
    s.addi       s17, s27, #2432
    s.addi       s28, s27, #3456
    s.addi       s30, s27, #4416
    s.addi       s31, s27, #5440
    vf.abs       v24, v21
    s.addi       s32, s27, #6464
    s.addi       s33, s27, #7488
    vf.max.ieee  v21, v22, v24
    v.ld.w       v22, [s26, #0]
    vf.abs       v24, v23
    v.ld.w       v23, [s17, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v24, v25
    v.ld.w       v24, [s30, #0]
    vf.abs       v25, v23
    vf.max.ieee  v23, v22, v25
    v.ld.w       v22, [s31, #0]
    vf.abs       v25, v24
    vf.max.ieee  v24, v21, v25
    v.ld.w       v21, [s32, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v24, v25
    v.ld.w       v24, [s34, #0]
    vf.abs       v25, v21
    vf.max.ieee  v21, v22, v25
    v.ld.w       v22, [s28, #0]
    vf.abs       v25, v24
    vf.max.ieee  v24, v14, v25
    vf.reduce.max.b v14, v24
    s.addi       s17, s27, #448
    s.addi       s26, s27, #1472
    v.ld.w       v24, [s17, #0]
    s.addi       s17, s27, #2496
    s.addi       s28, s27, #3520
    s.addi       s30, s27, #4480
    s.addi       s31, s27, #5504
    vf.abs       v25, v22
    s.addi       s32, s27, #6528
    s.addi       s34, s27, #7552
    vf.max.ieee  v22, v23, v25
    v.ld.w       v23, [s26, #0]
    vf.abs       v25, v24
    v.ld.w       v24, [s17, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v25, v26
    v.ld.w       v25, [s30, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v23, v26
    v.ld.w       v23, [s31, #0]
    vf.abs       v26, v25
    vf.max.ieee  v25, v22, v26
    v.ld.w       v22, [s32, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v25, v26
    v.ld.w       v25, [s33, #0]
    vf.abs       v26, v22
    vf.max.ieee  v22, v23, v26
    v.ld.w       v23, [s28, #0]
    vf.abs       v26, v25
    vf.max.ieee  v25, v21, v26
    vf.reduce.max.b v21, v25
    s.addi       s17, s27, #512
    s.addi       s26, s27, #1536
    v.ld.w       v25, [s17, #0]
    s.addi       s17, s27, #2560
    s.addi       s28, s27, #3584
    s.addi       s30, s27, #4544
    s.addi       s31, s27, #5568
    vf.abs       v26, v23
    s.addi       s32, s27, #6592
    s.addi       s33, s27, #7616
    vf.max.ieee  v23, v24, v26
    v.ld.w       v24, [s26, #0]
    vf.abs       v26, v25
    v.ld.w       v25, [s17, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v26, v27
    v.ld.w       v26, [s30, #0]
    vf.abs       v27, v25
    vf.max.ieee  v25, v24, v27
    v.ld.w       v24, [s31, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v23, v27
    v.ld.w       v23, [s32, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v26, v27
    v.ld.w       v26, [s34, #0]
    vf.abs       v27, v23
    vf.max.ieee  v23, v24, v27
    v.ld.w       v24, [s28, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v22, v27
    vf.reduce.max.b v22, v26
    s.addi       s17, s27, #576
    s.addi       s26, s27, #1600
    v.ld.w       v26, [s17, #0]
    s.addi       s17, s27, #2624
    s.addi       s28, s27, #3648
    s.addi       s30, s27, #4608
    s.addi       s31, s27, #5632
    vf.abs       v27, v24
    s.addi       s32, s27, #6656
    s.addi       s34, s27, #7680
    vf.max.ieee  v24, v25, v27
    v.ld.w       v25, [s26, #0]
    vf.abs       v27, v26
    v.ld.w       v26, [s17, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v27, v28
    v.ld.w       v27, [s30, #0]
    vf.abs       v28, v26
    vf.max.ieee  v26, v25, v28
    v.ld.w       v25, [s31, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v24, v28
    v.ld.w       v24, [s32, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v27, v28
    v.ld.w       v27, [s33, #0]
    vf.abs       v28, v24
    vf.max.ieee  v24, v25, v28
    v.ld.w       v25, [s28, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v23, v28
    vf.reduce.max.b v23, v27
    s.addi       s17, s27, #640
    s.addi       s26, s27, #1664
    v.ld.w       v27, [s17, #0]
    s.addi       s17, s27, #2688
    s.addi       s28, s27, #3712
    s.addi       s30, s27, #4672
    s.addi       s31, s27, #5696
    vf.abs       v28, v25
    s.addi       s32, s27, #6720
    s.addi       s33, s27, #7744
    vf.max.ieee  v25, v26, v28
    v.ld.w       v26, [s26, #0]
    vf.abs       v28, v27
    v.ld.w       v27, [s17, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v28, v29
    v.ld.w       v28, [s30, #0]
    vf.abs       v29, v27
    vf.max.ieee  v27, v26, v29
    v.ld.w       v26, [s31, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v25, v29
    v.ld.w       v25, [s32, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v28, v29
    v.ld.w       v28, [s34, #0]
    vf.abs       v29, v25
    vf.max.ieee  v25, v26, v29
    v.ld.w       v26, [s28, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v24, v29
    vf.reduce.max.b v24, v28
    s.addi       s17, s27, #704
    s.addi       s26, s27, #1728
    v.ld.w       v28, [s17, #0]
    s.addi       s17, s27, #2752
    s.addi       s28, s27, #3776
    s.addi       s30, s27, #4736
    s.addi       s31, s27, #5760
    vf.abs       v29, v26
    s.addi       s32, s27, #6784
    s.addi       s34, s27, #7808
    vf.max.ieee  v26, v27, v29
    v.ld.w       v27, [s26, #0]
    vf.abs       v29, v28
    v.ld.w       v28, [s17, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v29, v30
    v.ld.w       v29, [s30, #0]
    vf.abs       v30, v28
    vf.max.ieee  v28, v27, v30
    v.ld.w       v27, [s31, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v26, v30
    v.ld.w       v26, [s32, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v29, v30
    v.ld.w       v29, [s33, #0]
    vf.abs       v30, v26
    vf.max.ieee  v26, v27, v30
    v.ld.w       v27, [s28, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v25, v30
    vf.reduce.max.b v25, v29
    s.addi       s17, s27, #768
    s.addi       s26, s27, #1792
    v.ld.w       v29, [s17, #0]
    s.addi       s17, s27, #2816
    s.addi       s28, s27, #3840
    s.addi       s30, s27, #4800
    s.addi       s31, s27, #5824
    vf.abs       v30, v27
    s.addi       s32, s27, #6848
    s.addi       s33, s27, #7872
    vf.max.ieee  v27, v28, v30
    v.ld.w       v28, [s26, #0]
    vf.abs       v30, v29
    v.ld.w       v29, [s17, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v30, v31
    v.ld.w       v30, [s30, #0]
    vf.abs       v31, v29
    vf.max.ieee  v29, v28, v31
    v.ld.w       v28, [s31, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v27, v31
    v.ld.w       v27, [s32, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v30, v31
    v.ld.w       v30, [s34, #0]
    vf.abs       v31, v27
    vf.max.ieee  v27, v28, v31
    v.ld.w       v28, [s28, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v26, v31
    vf.reduce.max.b v26, v30
    s.addi       s17, s27, #832
    s.addi       s26, s27, #1856
    v.ld.w       v30, [s17, #0]
    s.addi       s17, s27, #2880
    s.addi       s28, s27, #3904
    s.addi       s30, s27, #4864
    s.addi       s31, s27, #5888
    vf.abs       v31, v28
    s.addi       s32, s27, #6912
    s.addi       s34, s27, #7936
    vf.max.ieee  v28, v29, v31
    v.ld.w       v29, [s26, #0]
    vf.abs       v31, v30
    v.ld.w       v30, [s17, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v31, v32
    v.ld.w       v31, [s30, #0]
    vf.abs       v32, v30
    vf.max.ieee  v30, v29, v32
    v.ld.w       v29, [s31, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v28, v32
    v.ld.w       v28, [s32, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v31, v32
    v.ld.w       v31, [s33, #0]
    vf.abs       v32, v28
    vf.max.ieee  v28, v29, v32
    v.ld.w       v29, [s28, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v27, v32
    vf.reduce.max.b v27, v31
    s.addi       s17, s27, #896
    s.addi       s26, s27, #1920
    v.ld.w       v31, [s17, #0]
    s.addi       s17, s27, #2944
    s.addi       s28, s27, #3968
    s.addi       s30, s27, #4928
    s.addi       s31, s27, #5952
    s.addi       s32, s27, #6976
    s.addi       s33, s27, #8000
    vf.abs       v32, v29
    v.ld.w       v29, [s26, #0]
    vf.abs       v33, v31
    vf.max.ieee  v31, v30, v32
    v.ld.w       v30, [s17, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v33, v32
    v.ld.w       v32, [s30, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v29, v33
    v.ld.w       v29, [s31, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v31, v33
    v.ld.w       v31, [s34, #0]
    vf.abs       v33, v29
    vf.max.ieee  v29, v32, v33
    v.ld.w       v32, [s28, #0]
    vf.abs       v33, v31
    vf.max.ieee  v31, v28, v33
    vf.reduce.max.b v28, v31
    s.addi       s17, s27, #960
    s.addi       s26, s27, #1984
    v.ld.w       v31, [s17, #0]
    s.addi       s17, s27, #3008
    s.addi       s28, s27, #4992
    s.addi       s30, s27, #6016
    s.addi       s31, s27, #7040
    s.addi       s34, s27, #8064
    vf.abs       v33, v32
    v.ld.w       v32, [s26, #0]
    vf.abs       v34, v31
    vf.max.ieee  v31, v30, v33
    v.ld.w       v30, [s28, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v34, v33
    v.ld.w       v33, [s30, #0]
    vf.abs       v34, v30
    vf.max.ieee  v30, v31, v34
    v.ld.w       v31, [s32, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v30, v34
    v.ld.w       v30, [s17, #0]
    vf.abs       v34, v31
    vf.max.ieee  v31, v29, v34
    s.addi       s17, s27, #4032
    vf.abs       v29, v30
    v.ld.w       v30, [s33, #0]
    vf.max.ieee  v34, v32, v29
    v.ld.w       v29, [s17, #0]
    vf.abs       v32, v30
    vf.max.ieee  v30, v31, v32
    vf.reduce.max.b v31, v30
    s.addi       s17, s27, #5056
    s.addi       s26, s27, #6080
    v.ld.w       v30, [s17, #0]
    s.addi       s17, s27, #7104
    s.addi       s28, s27, #8128
    v.movi       v32, #0
    // one value per row into one vector (ISA 0x09)
    v.extract    s30, v13, #0
    v.extract    s32, v17, #0
    vf.abs       v13, v29
    v.extract    s33, v20, #0
    v.ld.w       v17, [s31, #0]
    v.extract    s31, v19, #0
    vf.max.ieee  v19, v34, v13
    vf.abs       v13, v30
    vf.max.ieee  v20, v19, v13
    v.ld.w       v13, [s34, #0]
    vf.abs       v19, v17
    v.extract    s34, v14, #0
    vf.max.ieee  v14, v33, v19
    v.ld.w       v17, [s26, #0]
    v.extract    s26, v21, #0
    vf.abs       v19, v13
    vf.max.ieee  v13, v14, v19
    v.ld.w       v14, [s17, #0]
    vf.abs       v19, v17
    v.extract    s17, v22, #0
    vf.reduce.max.b v17, v13
    .li       s35, #1138753536
    v.splat      v13, s35                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.max.ieee  v21, v20, v19
    v.rcp.approx v19, v13                        // ISA 8.8: <= 2**-22 relative
    .li       s35, #1065353216
    v.splat      v20, s35                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.w       v22, [s28, #0]
    v.insert     v32, s30, #0
    v.extract    s28, v23, #0
    v.insert     v32, s32, #1
    vf.abs       v23, v14
    v.insert     v32, s33, #2
    v.extract    s30, v24, #0
    v.insert     v32, s31, #3
    v.extract    s31, v25, #0
    v.insert     v32, s34, #4
    vf.max.ieee  v14, v21, v23
    v.insert     v32, s26, #5
    vf.abs       v21, v22
    v.insert     v32, s17, #6
    v.extract    s17, v26, #0
    v.insert     v32, s28, #7
    v.extract    s26, v27, #0
    v.insert     v32, s30, #8
    vf.max.ieee  v22, v14, v21
    v.insert     v32, s31, #9
    v.extract    s28, v28, #0
    v.insert     v32, s17, #10
    v.extract    s17, v31, #0
    vf.fms       v14, v13, v19, v20
    v.insert     v32, s26, #11
    vf.reduce.max.b v21, v22
    v.insert     v32, s28, #12
    vf.fms       v22, v19, v14, v19
    v.insert     v32, s17, #13
    v.extract    s17, v17, #0
    v.insert     v32, s17, #14
    vf.neg       v14, v22                        // Newton step: r0*(2 - x*r0)
    v.extract    s17, v21, #0
    v.insert     v32, s17, #15
    .li       s17, #730643660
    v.splat      v17, s17                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v21, v14, v19
    v.extract    s17, v18, #0
    vf.mul       v14, v32, v21                   // a/y: faithful quotient
    v.iota       v19                             // arange(0, VLEN)
    v.splat      v22, s17
    s.movz       s26, #0
    vf.fms       v23, v14, v13, v32
    v.add        v13, v22, v19
    s.movz       s28, #0
    v.sub        v22, v18, v13
    vf.fms       v13, v23, v21, v14
    v.extract    s30, v16, #0
    v.reduce.or  s31, v22
    s.add        s32, s25, s29
    vf.neg       v21, v13                        // a/y: one correction to the IEEE quotient
    v.splat      v13, s30
    s.movz       s29, #0
    s.cmp.eq     s33, s31, s26
    vf.cmp.o     p1, v21, v21
    @p1 v.sel        v22, v21, v14
    v.add        v14, v13, v19
    s.cmp.ge     s26, s17, s28
    v.sub        v13, v16, v14
    s.cmp.ge     s28, s32, s29
    v.reduce.or  s29, v13
    s.and        s31, s33, s26
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    v.movi       v13, #0
    v.movi       v14, #0
    s.and        s26, s31, s28
    v.ld.gather.w v21, [s24, v0]                 // index is in elements (ISA sec 9.1)
    v.splat      v23, s18
    s.movz       s31, #0
    v.splat      v24, s18
    v.splat      v25, s18
    v.splat      v26, s18
    v.splat      v27, s18
    v.splat      v28, s18
    v.splat      v29, s18
    v.splat      v30, s18
    v.ld.gather.w v31, [s24, v1]                 // index is in elements (ISA sec 9.1)
    v.mul        v32, v18, v23
    s.movz       s33, #0
    s.cmp.eq     s34, s29, s31
    v.mul        v23, v16, v24
    s.cmp.ge     s29, s30, s33
    v.mul        v24, v15, v25
    s.and        s31, s34, s29
    v.mul        v25, v9, v26
    v.extract    s29, v15, #0
    v.ld.gather.w v26, [s24, v10]                // index is in elements (ISA sec 9.1)
    s.and        s33, s31, s28
    v.mul        v33, v8, v27
    v.splat      v27, s29
    v.mul        v34, v7, v28
    v.add        v28, v27, v19
    v.mul        v27, v6, v29
    v.sub        v29, v15, v28
    s.movz       s31, #0
    v.reduce.or  s34, v29
    s.cmp.eq     s35, s34, s31
    v.ld.gather.w v28, [s24, v4]                 // index is in elements (ISA sec 9.1)
    v.mul        v29, v2, v30
    s.movz       s31, #0
    s.cmp.ge     s34, s29, s31
    s.and        s31, s35, s34
    s.and        s34, s31, s28
    v.ld.gather.w v30, [s24, v3]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v35, [s24, v11]                // index is in elements (ISA sec 9.1)
    v.extract    s31, v9, #0
    v.ld.gather.w v36, [s24, v5]                 // index is in elements (ISA sec 9.1)
    v.splat      v37, s31
    v.ld.gather.w v38, [s24, v12]                // index is in elements (ISA sec 9.1)
    v.add        v39, v37, v19
    v.insert     v13, s26, #0
    v.extract    s26, v8, #0
    v.splat      v37, s26
    v.sub        v40, v9, v39
    v.add        v39, v37, v19
    v.insert     v14, s17, #0
    v.extract    s17, v7, #0
    v.splat      v37, s17
    v.sub        v41, v8, v39
    v.add        v39, v37, v19
    v.insert     v13, s33, #1
    s.movz       s33, #0
    v.sub        v37, v7, v39
    v.insert     v14, s30, #1
    s.movz       s30, #0
    v.insert     v13, s34, #2
    v.extract    s34, v6, #0
    v.splat      v39, s34
    s.cmp.ge     s35, s31, s30
    v.add        v42, v39, v19
    v.insert     v14, s29, #2
    v.reduce.or  s29, v40
    s.cmp.eq     s30, s29, s33
    s.movz       s29, #0
    s.and        s33, s30, s35
    s.movz       s30, #0
    v.sub        v39, v6, v42
    s.cmp.ge     s35, s26, s30
    s.and        s30, s33, s28
    v.insert     v13, s30, #3
    v.extract    s30, v2, #0
    v.splat      v40, s30
    v.insert     v14, s31, #3
    v.reduce.or  s31, v41
    s.cmp.eq     s33, s31, s29
    s.movz       s29, #0
    v.add        v41, v40, v19
    s.and        s31, s33, s35
    s.movz       s33, #0
    v.sub        v19, v2, v41
    s.cmp.ge     s35, s17, s33
    s.and        s33, s31, s28
    s.movz       s31, #0
    v.insert     v13, s33, #4
    v.reduce.or  s31, v37
    s.cmp.eq     s33, s31, s29
    s.movz       s29, #0
    s.and        s31, s33, s35
    s.movz       s33, #0
    v.insert     v14, s26, #4
    v.reduce.or  s26, v39
    s.cmp.eq     s35, s26, s29
    s.cmp.ge     s26, s34, s33
    s.movz       s29, #0
    s.and        s33, s31, s28
    s.and        s31, s35, s26
    s.movz       s26, #0
    v.insert     v13, s33, #5
    v.reduce.or  s33, v19
    s.cmp.eq     s35, s33, s29
    s.cmp.ge     s29, s30, s26
    v.insert     v14, s17, #5
    s.and        s17, s31, s28
    s.and        s26, s35, s29
    v.insert     v13, s17, #6
    v.insert     v14, s34, #6
    v.extract    s17, v22, #0
    v.splat      v19, s17
    s.and        s17, s26, s28
    vf.max.ieee  v37, v19, v17
    s.add        s26, s6, s23
    s.addi       s28, s27, #8192                 // TensorMap 0: W's rows for a transposed FP8 B
    .li       s29, #2147483647
    s.movz       s31, #1
    .li       s33, #137438953488
    .li       s34, #7705171329024
    v.insert     v13, s17, #7
    v.rcp.approx v19, v37                        // ISA 8.8: <= 2**-22 relative
    s.addi       s17, s27, #8448
    v.insert     v14, s30, #7
    s.addi       s30, s27, #8960                 // TensorMap 1: the gathered fallback B tile
    s.st.d       [s28, #0], s26
    s.movz       s26, #32
    s.movz       s35, #0
    s.st.d       [s28, #8], s29
    s.movz       s29, #16
    s.st.d       [s28, #16], s32
    s.st.d       [s28, #48], s18
    s.st.d       [s28, #56], s31
    s.movz       s31, #16
    s.st.d       [s28, #88], s33
    s.movz       s33, #1
    v.movi       v39, #24
    s.st.d       [s28, #104], s34
    .li       s34, #68719476768
    td.load      d0, [s28]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    .li       s28, #7705171329024
    s.st.d       [s30, #0], s17
    vf.fms       v40, v37, v19, v20
    s.addi       s17, s27, #0
    s.st.d       [s30, #8], s26
    v.extract    s26, v22, #1
    v.splat      v41, s26
    vf.fms       v42, v19, v40, v19
    s.st.d       [s30, #16], s29
    vf.max.ieee  v40, v41, v17
    v.movi       v41, #128
    s.st.d       [s30, #48], s31
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v42, v40                        // ISA 8.8: <= 2**-22 relative
    s.st.d       [s30, #56], s33
    s.addi       s26, s27, #9216                 // 512 bytes of repack scratch
    vf.cmp.o     p1, v43, v43
    s.st.d       [s30, #88], s34
    @p1 v.sel        v44, v43, v19
    s.addi       s29, s26, #0
    s.st.d       [s30, #104], s28
    td.load      d1, [s30]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    v.ld.w       v19, [s17, #0]
    v.extract    s17, v22, #2
    v.splat      v43, s17
    s.addi       s17, s27, #64
    vf.max.ieee  v45, v43, v17
    s.addi       s28, s26, #32
    s.addi       s30, s27, #128
    v.rcp.approx v43, v45                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v46, v19, v44                   // a/y: faithful quotient
    vf.fms       v47, v46, v37, v19
    vf.fms       v19, v40, v42, v20
    vf.fms       v37, v47, v44, v46
    vf.fms       v44, v42, v19, v42
    vf.neg       v19, v37                        // a/y: one correction to the IEEE quotient
    vf.neg       v37, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v44, v19, v46
    vf.cmp.o     p1, v37, v37
    vf.cvt.f32.e4m3 v19, v44
    v.lshr       v46, v44, v39
    @p1 v.sel        v44, v37, v42
    v.and        v37, v46, v41
    s.addi       s31, s26, #64
    v.or         v42, v19, v37                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v43, v20
    v.st.b       [s29, #0], v42
    v.extract    s29, v22, #3
    s.addi       s33, s27, #192
    vf.fms       v37, v43, v19, v43
    v.ld.w       v19, [s17, #0]
    v.splat      v42, s29
    vf.max.ieee  v46, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v46                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v43
    vf.mul       v42, v19, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v40, v19
    vf.fms       v19, v43, v44, v42
    vf.neg       v40, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v19, v40, v42
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s17, s26, #96
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v46, v37, v20
    v.st.b       [s28, #0], v42
    v.extract    s28, v22, #4
    s.addi       s29, s27, #256
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s30, #0]
    v.splat      v42, s28
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s28, s26, #128
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s31, #0], v42
    v.extract    s30, v22, #5
    s.addi       s31, s27, #320
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s30
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v40
    vf.mul       v40, v19, v44                   // a/y: faithful quotient
    vf.fms       v42, v40, v46, v19
    vf.fms       v19, v42, v44, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s30, s26, #160
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s17, #0], v42
    v.extract    s17, v22, #6
    s.addi       s33, s27, #384
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s29, #0]
    v.splat      v42, s17
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s17, s26, #192
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s28, #0], v42
    v.extract    s28, v22, #7
    s.addi       s29, s27, #448
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s28
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v40
    vf.mul       v40, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v46, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s28, s26, #224
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s30, #0], v42
    v.extract    s30, v22, #8
    s.addi       s31, s27, #512
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s30
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s30, s26, #256
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s17, #0], v42
    v.extract    s17, v22, #9
    s.addi       s33, s27, #576
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s29, #0]
    v.splat      v42, s17
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v40
    vf.mul       v40, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v46, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s17, s26, #288
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s28, #0], v42
    v.extract    s28, v22, #10
    s.addi       s29, s27, #640
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s28
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s28, s26, #320
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s30, #0], v42
    v.extract    s30, v22, #11
    s.addi       s31, s27, #704
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s30
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v40
    vf.mul       v40, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v46, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s30, s26, #352
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s17, #0], v42
    v.extract    s17, v22, #12
    s.addi       s33, s27, #768
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s29, #0]
    v.splat      v42, s17
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s17, s26, #384
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s28, #0], v42
    v.extract    s28, v22, #13
    s.addi       s29, s27, #832
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s28
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v40
    vf.mul       v40, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v46, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s28, s26, #416
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s30, #0], v42
    v.extract    s30, v22, #14
    s.addi       s31, s27, #896
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s30
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s30, s26, #448
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s17, #0], v42
    v.extract    s17, v22, #15
    s.addi       s33, s27, #960
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s29, #0]
    v.splat      v42, s17
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v40
    vf.mul       v40, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v46, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s17, s26, #480
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s28, #0], v42
    v.extract    s28, v22, #0
    s.addi       s29, s27, #1024
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s28
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s28, s26, #16
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s30, #0], v42
    v.extract    s30, v22, #1
    s.addi       s31, s27, #1088
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s30
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v40
    vf.mul       v40, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v46, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s30, s26, #48
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s17, #0], v42
    v.extract    s17, v22, #2
    s.addi       s33, s27, #1152
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s29, #0]
    v.splat      v42, s17
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s17, s26, #80
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s28, #0], v42
    v.extract    s28, v22, #3
    s.addi       s29, s27, #1216
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s28
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v40
    vf.mul       v40, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v46, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s28, s26, #112
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s30, #0], v42
    v.extract    s30, v22, #4
    s.addi       s31, s27, #1280
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s30
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s30, s26, #144
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s17, #0], v42
    v.extract    s17, v22, #5
    s.addi       s33, s27, #1344
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s29, #0]
    v.splat      v42, s17
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v40
    vf.mul       v40, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v46, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s17, s26, #176
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s28, #0], v42
    v.extract    s28, v22, #6
    s.addi       s29, s27, #1408
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s28
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s28, s26, #208
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s30, #0], v42
    v.extract    s30, v22, #7
    s.addi       s31, s27, #1472
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s30
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v40
    vf.mul       v40, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v46, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s30, s26, #240
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s17, #0], v42
    v.extract    s17, v22, #8
    s.addi       s33, s27, #1536
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s29, #0]
    v.splat      v42, s17
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s17, s26, #272
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s28, #0], v42
    v.extract    s28, v22, #9
    s.addi       s29, s27, #1600
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s28
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v40
    vf.mul       v40, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v46, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s28, s26, #304
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s30, #0], v42
    v.extract    s30, v22, #10
    s.addi       s31, s27, #1664
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s30
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s30, s26, #336
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s17, #0], v42
    v.extract    s17, v22, #11
    s.addi       s33, s27, #1728
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s29, #0]
    v.splat      v42, s17
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v40
    vf.mul       v40, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v46, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s17, s26, #368
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s28, #0], v42
    v.extract    s28, v22, #12
    s.addi       s29, s27, #1792
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s28
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s28, s26, #400
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s30, #0], v42
    v.extract    s30, v22, #13
    s.addi       s31, s27, #1856
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s30
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v40
    vf.mul       v40, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v46, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s30, s26, #432
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s17, #0], v42
    v.extract    s17, v22, #14
    s.addi       s33, s27, #1920
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s29, #0]
    v.splat      v42, s17
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s17, s26, #464
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s28, #0], v42
    v.extract    s28, v22, #15
    s.addi       s29, s27, #1984
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s28
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v40
    vf.mul       v40, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v46, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s28, s26, #496
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s30, #0], v42
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    s.addi       s30, s26, #64
    s.addi       s31, s26, #128
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    s.addi       s33, s26, #192
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v40, v42, v37
    vf.mul       v37, v19, v47                   // a/y: faithful quotient
    s.addi       s34, s26, #256
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v47, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s17, #0], v42
    s.addi       s17, s26, #320
    v.ld.w       v19, [s29, #0]
    s.addi       s29, s26, #384
    vf.mul       v37, v19, v40                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v40, v37
    vf.neg       v40, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v19, v40, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v40, v19, v39
    v.and        v19, v40, v41
    v.or         v40, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s28, #0], v40
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s28, s26, #448
    v.ld.w       v19, [s26, #0]
    v.extract    s26, v13, #0
    v.mov        v48, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s30, #0]
    v.mov        v49, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s31, #0]
    v.mov        v50, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s33, #0]
    v.mov        v51, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s34, #0]
    v.mov        v52, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s17, #0]
    v.mov        v53, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s29, #0]
    v.mov        v54, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s28, #0]
    v.mov        v55, v19                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s26, x8dot_done_27
    s.movz       s17, #0
    s.add        s28, s6, s23
    s.addi       s29, s17, #0
    s.addi       s17, s27, #8448
x8dot_row_28:
    s.addi       s30, s32, #0
    v.movi       v19, #0
    s.sub        s31, s30, s29
    s.add        s30, s28, s29
    v.splat      v37, s31
    s.shli       s31, s29, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s30, v32]            // index is in elements (ISA sec 9.1)
    s.add        s30, s17, s31
    s.addi       s31, s29, #1
    s.movz       s33, #32
    v.st.b       [s30, #0], v19
    fence.acq_rel.device
    s.mov        s29, s31
    s.cmp.lt     s30, s29, s33
    br.nz        s30, x8dot_row_28
x8dot_done_27:
    v.splat      v19, s26
    v.movi       v37, #0
    v.splat      v40, s26
    v.movi       v42, #0
    mb.arm       s17, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s26, #0
    s.movz       s28, #0
    s.movz       s29, #0
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s30, v14, #0
    s.mov        s33, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s33, s17            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s17          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s17
    mb.arm       s26, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s28, v13, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s26
    mb.wait      s26
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s28, x8dot_done_29
    s.movz       s29, #0
    s.add        s30, s6, s23
    s.addi       s31, s29, #0
    s.addi       s29, s27, #8448
x8dot_row_30:
    s.addi       s33, s32, #0
    v.movi       v19, #0
    s.sub        s34, s33, s31
    s.add        s33, s30, s31
    v.splat      v37, s34
    s.shli       s34, s31, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s33, v23]            // index is in elements (ISA sec 9.1)
    s.add        s33, s29, s34
    s.addi       s34, s31, #1
    s.movz       s35, #32
    v.st.b       [s33, #0], v19
    fence.acq_rel.device
    s.mov        s31, s34
    s.cmp.lt     s33, s31, s35
    br.nz        s33, x8dot_row_30
x8dot_done_29:
    v.splat      v19, s28
    v.movi       v37, #0
    v.splat      v40, s28
    v.movi       v42, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    s.movz       s30, #0
    s.movz       s31, #0
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s33, v14, #1
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s29, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s30, v13, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s30, x8dot_done_31
    s.movz       s31, #0
    s.add        s33, s6, s23
    s.addi       s34, s31, #0
    s.addi       s31, s27, #8448
x8dot_row_32:
    s.addi       s35, s32, #0
    v.movi       v19, #0
    s.sub        s36, s35, s34
    s.add        s35, s33, s34
    v.splat      v37, s36
    s.shli       s36, s34, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s35, v24]            // index is in elements (ISA sec 9.1)
    s.add        s35, s31, s36
    s.addi       s36, s34, #1
    s.movz       s37, #32
    v.st.b       [s35, #0], v19
    fence.acq_rel.device
    s.mov        s34, s36
    s.cmp.lt     s35, s34, s37
    br.nz        s35, x8dot_row_32
x8dot_done_31:
    v.splat      v19, s30
    v.movi       v37, #0
    v.splat      v40, s30
    v.movi       v42, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s31, #0
    s.movz       s33, #0
    s.movz       s34, #0
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s35, v14, #2
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v13, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_33
    s.movz       s34, #0
    s.add        s35, s6, s23
    s.addi       s36, s34, #0
    s.addi       s34, s27, #8448
x8dot_row_34:
    s.addi       s37, s32, #0
    v.movi       v19, #0
    s.sub        s38, s37, s36
    s.add        s37, s35, s36
    v.splat      v37, s38
    s.shli       s38, s36, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s37, v25]            // index is in elements (ISA sec 9.1)
    s.add        s37, s34, s38
    s.addi       s38, s36, #1
    s.movz       s39, #32
    v.st.b       [s37, #0], v19
    fence.acq_rel.device
    s.mov        s36, s38
    s.cmp.lt     s37, s36, s39
    br.nz        s37, x8dot_row_34
x8dot_done_33:
    v.splat      v19, s33
    v.movi       v37, #0
    v.splat      v40, s33
    v.movi       v42, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    s.movz       s35, #0
    s.movz       s36, #0
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s37, v14, #3
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v13, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_35
    s.movz       s36, #0
    s.add        s37, s6, s23
    s.addi       s38, s36, #0
    s.addi       s36, s27, #8448
x8dot_row_36:
    s.addi       s39, s32, #0
    v.movi       v19, #0
    s.sub        s40, s39, s38
    s.add        s39, s37, s38
    v.splat      v37, s40
    s.shli       s40, s38, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s39, v33]            // index is in elements (ISA sec 9.1)
    s.add        s39, s36, s40
    s.addi       s40, s38, #1
    s.movz       s41, #32
    v.st.b       [s39, #0], v19
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s39, s38, s41
    br.nz        s39, x8dot_row_36
x8dot_done_35:
    v.splat      v19, s35
    v.movi       v37, #0
    v.splat      v40, s35
    v.movi       v42, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    s.movz       s37, #0
    s.movz       s38, #0
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s39, v14, #4
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v13, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_37
    s.movz       s38, #0
    s.add        s39, s6, s23
    s.addi       s40, s38, #0
    s.addi       s38, s27, #8448
x8dot_row_38:
    s.addi       s41, s32, #0
    v.movi       v19, #0
    s.sub        s42, s41, s40
    s.add        s41, s39, s40
    v.splat      v37, s42
    s.shli       s42, s40, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s41, v34]            // index is in elements (ISA sec 9.1)
    s.add        s41, s38, s42
    s.addi       s42, s40, #1
    s.movz       s43, #32
    v.st.b       [s41, #0], v19
    fence.acq_rel.device
    s.mov        s40, s42
    s.cmp.lt     s41, s40, s43
    br.nz        s41, x8dot_row_38
x8dot_done_37:
    v.splat      v19, s37
    v.movi       v37, #0
    v.splat      v40, s37
    v.movi       v42, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    s.movz       s39, #0
    s.movz       s40, #0
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s41, v14, #5
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v13, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s39, x8dot_done_39
    s.movz       s40, #0
    s.add        s41, s6, s23
    s.addi       s42, s40, #0
    s.addi       s40, s27, #8448
x8dot_row_40:
    s.addi       s43, s32, #0
    v.movi       v19, #0
    s.sub        s44, s43, s42
    s.add        s43, s41, s42
    v.splat      v37, s44
    s.shli       s44, s42, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s43, v27]            // index is in elements (ISA sec 9.1)
    s.add        s43, s40, s44
    s.addi       s44, s42, #1
    s.movz       s45, #32
    v.st.b       [s43, #0], v19
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s43, s42, s45
    br.nz        s43, x8dot_row_40
x8dot_done_39:
    v.splat      v19, s39
    v.movi       v37, #0
    v.splat      v40, s39
    v.movi       v42, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    s.movz       s41, #0
    s.movz       s42, #0
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s43, v14, #6
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s44, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s40, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v13, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s41, x8dot_done_41
    s.movz       s42, #0
    s.add        s43, s6, s23
    s.addi       s44, s42, #0
    s.addi       s42, s27, #8448
x8dot_row_42:
    s.addi       s45, s32, #0
    v.movi       v19, #0
    s.sub        s46, s45, s44
    s.add        s45, s43, s44
    v.splat      v37, s46
    s.shli       s46, s44, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s45, v29]            // index is in elements (ISA sec 9.1)
    s.add        s45, s42, s46
    s.addi       s46, s44, #1
    s.movz       s47, #32
    v.st.b       [s45, #0], v19
    fence.acq_rel.device
    s.mov        s44, s46
    s.cmp.lt     s45, s44, s47
    br.nz        s45, x8dot_row_42
x8dot_done_41:
    v.extract    s42, v22, #0
    v.splat      v19, s42
    v.splat      v37, s41
    vf.max.ieee  v40, v19, v17
    v.movi       v19, #0
    v.splat      v42, s41
    v.movi       v43, #0
    v.rcp.approx v44, v40                        // ISA 8.8: <= 2**-22 relative
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    s.movz       s43, #0
    s.movz       s44, #0
    v.extract    s45, v22, #1
    v.cmp.ne     p1, v37, v19
    v.cmp.eq     p2, v42, v43
    v.extract    s46, v14, #7
    v.splat      v19, s45
    s.mov        s47, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s43, s27, #2048
    vf.max.ieee  v37, v19, v17
    m.mma.async.k32.e4m3 a15, v48, v56, s42
    mb.wait      s42
    v.ld.w       v19, [s43, #0]
    v.rcp.approx v42, v37                        // ISA 8.8: <= 2**-22 relative
    s.addi       s43, s27, #9728                 // 512 bytes of repack scratch
    v.extract    s44, v22, #2
    v.splat      v43, s44
    s.addi       s44, s43, #0
    s.addi       s45, s27, #2112
    vf.max.ieee  v45, v43, v17
    s.addi       s46, s43, #32
    vf.fms       v43, v40, v44, v20
    s.addi       s47, s27, #2176
    v.rcp.approx v46, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v47, v44, v43, v44
    vf.neg       v43, v47                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v47, v43, v44
    vf.mul       v43, v19, v47                   // a/y: faithful quotient
    vf.fms       v44, v43, v40, v19
    vf.fms       v19, v37, v42, v20
    vf.fms       v40, v44, v47, v43
    vf.fms       v44, v42, v19, v42
    vf.neg       v19, v40                        // a/y: one correction to the IEEE quotient
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    vf.fms       v44, v45, v46, v20
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v47, v19, v43
    vf.cmp.o     p1, v40, v40
    vf.cvt.f32.e4m3 v19, v47
    v.lshr       v43, v47, v39
    @p1 v.sel        v47, v40, v42
    v.and        v40, v43, v41
    vf.fms       v42, v46, v44, v46
    v.or         v43, v19, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s48, s43, #64
    v.st.b       [s44, #0], v43
    v.extract    s44, v22, #3
    vf.neg       v19, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v40, [s45, #0]
    v.splat      v42, s44
    vf.cmp.o     p1, v19, v19
    vf.max.ieee  v43, v42, v17
    @p1 v.sel        v42, v19, v46
    s.addi       s44, s27, #2240
    v.rcp.approx v19, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v40, v47                   // a/y: faithful quotient
    vf.fms       v46, v44, v37, v40
    vf.fms       v37, v46, v47, v44
    vf.neg       v40, v37                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v37, v40, v44
    vf.cvt.f32.e4m3 v40, v37
    v.lshr       v44, v37, v39
    v.and        v37, v44, v41
    s.addi       s45, s43, #96
    v.or         v44, v40, v37                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v37, v43, v19, v20
    v.st.b       [s46, #0], v44
    v.extract    s46, v22, #4
    vf.fms       v40, v19, v37, v19
    v.ld.w       v37, [s47, #0]
    v.splat      v44, s46
    s.addi       s46, s27, #2304
    vf.max.ieee  v46, v44, v17
    vf.neg       v44, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v46                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v47, v44, v19
    vf.mul       v19, v37, v42                   // a/y: faithful quotient
    vf.fms       v44, v19, v45, v37
    vf.fms       v37, v44, v42, v19
    vf.neg       v42, v37                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v37, v42, v19
    vf.cvt.f32.e4m3 v19, v37
    v.lshr       v42, v37, v39
    v.and        v37, v42, v41
    s.addi       s47, s43, #128
    v.or         v42, v19, v37                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v46, v40, v20
    v.st.b       [s48, #0], v42
    v.extract    s48, v22, #5
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s44, #0]
    v.splat      v42, s48
    s.addi       s44, s27, #2368
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s48, s43, #160
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s45, #0], v42
    v.extract    s45, v22, #6
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s46, #0]
    v.splat      v42, s45
    s.addi       s45, s27, #2432
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v45                   // a/y: faithful quotient
    vf.fms       v42, v37, v46, v19
    vf.fms       v19, v42, v45, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s46, s43, #192
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s47, #0], v42
    v.extract    s47, v22, #7
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s44, #0]
    v.splat      v42, s47
    s.addi       s44, s27, #2496
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s47, s43, #224
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s48, #0], v42
    v.extract    s48, v22, #8
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s45, #0]
    v.splat      v42, s48
    s.addi       s45, s27, #2560
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s48, s43, #256
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s46, #0], v42
    v.extract    s46, v22, #9
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s44, #0]
    v.splat      v42, s46
    s.addi       s44, s27, #2624
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s46, s43, #288
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s47, #0], v42
    v.extract    s47, v22, #10
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s45, #0]
    v.splat      v42, s47
    s.addi       s45, s27, #2688
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s47, s43, #320
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s48, #0], v42
    v.extract    s48, v22, #11
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s44, #0]
    v.splat      v42, s48
    s.addi       s44, s27, #2752
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s48, s43, #352
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s46, #0], v42
    v.extract    s46, v22, #12
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s45, #0]
    v.splat      v42, s46
    s.addi       s45, s27, #2816
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s46, s43, #384
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s47, #0], v42
    v.extract    s47, v22, #13
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s44, #0]
    v.splat      v42, s47
    s.addi       s44, s27, #2880
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s47, s43, #416
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s48, #0], v42
    v.extract    s48, v22, #14
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s45, #0]
    v.splat      v42, s48
    s.addi       s45, s27, #2944
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s48, s43, #448
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s46, #0], v42
    v.extract    s46, v22, #15
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s44, #0]
    v.splat      v42, s46
    s.addi       s44, s27, #3008
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s46, s43, #480
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s47, #0], v42
    v.extract    s47, v22, #0
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s45, #0]
    v.splat      v42, s47
    s.addi       s45, s27, #3072
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s47, s43, #16
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s48, #0], v42
    v.extract    s48, v22, #1
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s44, #0]
    v.splat      v42, s48
    s.addi       s44, s27, #3136
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s48, s43, #48
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s46, #0], v42
    v.extract    s46, v22, #2
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s45, #0]
    v.splat      v42, s46
    s.addi       s45, s27, #3200
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s46, s43, #80
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s47, #0], v42
    v.extract    s47, v22, #3
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s44, #0]
    v.splat      v42, s47
    s.addi       s44, s27, #3264
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s47, s43, #112
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s48, #0], v42
    v.extract    s48, v22, #4
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s45, #0]
    v.splat      v42, s48
    s.addi       s45, s27, #3328
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s48, s43, #144
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s46, #0], v42
    v.extract    s46, v22, #5
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s44, #0]
    v.splat      v42, s46
    s.addi       s44, s27, #3392
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s46, s43, #176
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s47, #0], v42
    v.extract    s47, v22, #6
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s45, #0]
    v.splat      v42, s47
    s.addi       s45, s27, #3456
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s47, s43, #208
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s48, #0], v42
    v.extract    s48, v22, #7
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s44, #0]
    v.splat      v42, s48
    s.addi       s44, s27, #3520
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s48, s43, #240
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s46, #0], v42
    v.extract    s46, v22, #8
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s45, #0]
    v.splat      v42, s46
    s.addi       s45, s27, #3584
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s46, s43, #272
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s47, #0], v42
    v.extract    s47, v22, #9
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s44, #0]
    v.splat      v42, s47
    s.addi       s44, s27, #3648
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s47, s43, #304
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s48, #0], v42
    v.extract    s48, v22, #10
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s45, #0]
    v.splat      v42, s48
    s.addi       s45, s27, #3712
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s48, s43, #336
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s46, #0], v42
    v.extract    s46, v22, #11
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s44, #0]
    v.splat      v42, s46
    s.addi       s44, s27, #3776
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s46, s43, #368
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s47, #0], v42
    v.extract    s47, v22, #12
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s45, #0]
    v.splat      v42, s47
    s.addi       s45, s27, #3840
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s47, s43, #400
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s48, #0], v42
    v.extract    s48, v22, #13
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s44, #0]
    v.splat      v42, s48
    s.addi       s44, s27, #3904
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s48, s43, #432
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s46, #0], v42
    v.extract    s46, v22, #14
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s45, #0]
    v.splat      v42, s46
    s.addi       s45, s27, #3968
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s46, s43, #464
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s47, #0], v42
    v.extract    s47, v22, #15
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s44, #0]
    v.splat      v42, s47
    s.addi       s44, s27, #4032
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s47, s43, #496
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s48, #0], v42
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s45, #0]
    s.addi       s45, s43, #64
    s.addi       s48, s43, #128
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v40, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    s.addi       s46, s43, #192
    v.ld.w       v19, [s44, #0]
    s.addi       s44, s43, #256
    vf.mul       v37, v19, v40                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v40, v37
    vf.neg       v40, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v19, v40, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v40, v19, v39
    v.and        v19, v40, v41
    v.or         v40, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v40
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s47, s43, #320
    v.ld.w       v19, [s43, #0]
    v.mov        v48, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s45, #0]
    s.addi       s45, s43, #384
    s.addi       s49, s43, #448
    v.mov        v49, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s48, #0]
    v.extract    s43, v13, #0
    v.mov        v50, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s46, #0]
    v.mov        v51, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s44, #0]
    v.mov        v52, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s47, #0]
    v.mov        v53, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s45, #0]
    v.mov        v54, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s49, #0]
    v.mov        v55, v19                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s43, x8dot_done_43
    s.movz       s44, #0
    s.add        s45, s6, s23
    s.addi       s46, s44, #0
    s.addi       s44, s45, #32
    s.addi       s45, s27, #8448
x8dot_row_44:
    s.addi       s47, s32, #-32
    v.movi       v19, #0
    s.sub        s48, s47, s46
    s.add        s47, s44, s46
    v.splat      v37, s48
    s.shli       s48, s46, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s47, v32]            // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s48
    s.addi       s48, s46, #1
    s.movz       s49, #32
    v.st.b       [s47, #0], v19
    fence.acq_rel.device
    s.mov        s46, s48
    s.cmp.lt     s47, s46, s49
    br.nz        s47, x8dot_row_44
x8dot_done_43:
    v.splat      v19, s43
    v.movi       v37, #0
    v.splat      v40, s43
    v.movi       v42, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    s.movz       s45, #0
    s.movz       s46, #32
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s47, v14, #0
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s48, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v13, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s45, x8dot_done_45
    s.movz       s46, #0
    s.add        s47, s6, s23
    s.addi       s48, s46, #0
    s.addi       s46, s47, #32
    s.addi       s47, s27, #8448
x8dot_row_46:
    s.addi       s49, s32, #-32
    v.movi       v19, #0
    s.sub        s50, s49, s48
    s.add        s49, s46, s48
    v.splat      v37, s50
    s.shli       s50, s48, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s49, v23]            // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.addi       s50, s48, #1
    s.movz       s51, #32
    v.st.b       [s49, #0], v19
    fence.acq_rel.device
    s.mov        s48, s50
    s.cmp.lt     s49, s48, s51
    br.nz        s49, x8dot_row_46
x8dot_done_45:
    v.splat      v19, s45
    v.movi       v37, #0
    v.splat      v40, s45
    v.movi       v42, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    s.movz       s47, #0
    s.movz       s48, #32
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s49, v14, #1
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s50, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s46, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v13, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s46
    mb.wait      s46
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s47, x8dot_done_47
    s.movz       s48, #0
    s.add        s49, s6, s23
    s.addi       s50, s48, #0
    s.addi       s48, s49, #32
    s.addi       s49, s27, #8448
x8dot_row_48:
    s.addi       s51, s32, #-32
    v.movi       v19, #0
    s.sub        s52, s51, s50
    s.add        s51, s48, s50
    v.splat      v37, s52
    s.shli       s52, s50, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s51, v24]            // index is in elements (ISA sec 9.1)
    s.add        s51, s49, s52
    s.addi       s52, s50, #1
    s.movz       s53, #32
    v.st.b       [s51, #0], v19
    fence.acq_rel.device
    s.mov        s50, s52
    s.cmp.lt     s51, s50, s53
    br.nz        s51, x8dot_row_48
x8dot_done_47:
    v.splat      v19, s47
    v.movi       v37, #0
    v.splat      v40, s47
    v.movi       v42, #0
    mb.arm       s47, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s48, #0
    s.movz       s49, #0
    s.movz       s50, #32
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s51, v14, #2
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s52, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s48, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s48, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v13, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s48
    mb.wait      s48
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s49, x8dot_done_49
    s.movz       s50, #0
    s.add        s51, s6, s23
    s.addi       s52, s50, #0
    s.addi       s50, s51, #32
    s.addi       s51, s27, #8448
x8dot_row_50:
    s.addi       s53, s32, #-32
    v.movi       v19, #0
    s.sub        s54, s53, s52
    s.add        s53, s50, s52
    v.splat      v37, s54
    s.shli       s54, s52, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s53, v25]            // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.addi       s54, s52, #1
    s.movz       s55, #32
    v.st.b       [s53, #0], v19
    fence.acq_rel.device
    s.mov        s52, s54
    s.cmp.lt     s53, s52, s55
    br.nz        s53, x8dot_row_50
x8dot_done_49:
    v.splat      v19, s49
    v.movi       v37, #0
    v.splat      v40, s49
    v.movi       v42, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    s.movz       s51, #0
    s.movz       s52, #32
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s53, v14, #3
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s54, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s51, v13, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s51, x8dot_done_51
    s.movz       s52, #0
    s.add        s53, s6, s23
    s.addi       s54, s52, #0
    s.addi       s52, s53, #32
    s.addi       s53, s27, #8448
x8dot_row_52:
    s.addi       s55, s32, #-32
    v.movi       v19, #0
    s.sub        s56, s55, s54
    s.add        s55, s52, s54
    v.splat      v37, s56
    s.shli       s56, s54, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s55, v33]            // index is in elements (ISA sec 9.1)
    s.add        s55, s53, s56
    s.addi       s56, s54, #1
    s.movz       s57, #32
    v.st.b       [s55, #0], v19
    fence.acq_rel.device
    s.mov        s54, s56
    s.cmp.lt     s55, s54, s57
    br.nz        s55, x8dot_row_52
x8dot_done_51:
    v.splat      v19, s51
    v.movi       v37, #0
    v.splat      v40, s51
    v.movi       v42, #0
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    s.movz       s53, #0
    s.movz       s54, #32
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s55, v14, #4
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s56, s51            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s52, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v13, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s53, x8dot_done_53
    s.movz       s54, #0
    s.add        s55, s6, s23
    s.addi       s56, s54, #0
    s.addi       s54, s55, #32
    s.addi       s55, s27, #8448
x8dot_row_54:
    s.addi       s57, s32, #-32
    v.movi       v19, #0
    s.sub        s58, s57, s56
    s.add        s57, s54, s56
    v.splat      v37, s58
    s.shli       s58, s56, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s57, v34]            // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.addi       s58, s56, #1
    s.movz       s59, #32
    v.st.b       [s57, #0], v19
    fence.acq_rel.device
    s.mov        s56, s58
    s.cmp.lt     s57, s56, s59
    br.nz        s57, x8dot_row_54
x8dot_done_53:
    v.splat      v19, s53
    v.movi       v37, #0
    v.splat      v40, s53
    v.movi       v42, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    s.movz       s55, #0
    s.movz       s56, #32
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s57, v14, #5
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s58, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s57                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s54, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v13, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s55, x8dot_done_55
    s.movz       s56, #0
    s.add        s57, s6, s23
    s.addi       s58, s56, #0
    s.addi       s56, s57, #32
    s.addi       s57, s27, #8448
x8dot_row_56:
    s.addi       s59, s32, #-32
    v.movi       v19, #0
    s.sub        s60, s59, s58
    s.add        s59, s56, s58
    v.splat      v37, s60
    s.shli       s60, s58, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s59, v27]            // index is in elements (ISA sec 9.1)
    s.add        s59, s57, s60
    s.addi       s60, s58, #1
    s.movz       s17, #32
    v.st.b       [s59, #0], v19
    fence.acq_rel.device
    s.mov        s58, s60
    s.cmp.lt     s26, s58, s17
    br.nz        s26, x8dot_row_56
x8dot_done_55:
    v.splat      v19, s55
    v.movi       v37, #0
    v.splat      v40, s55
    v.movi       v42, #0
    mb.arm       s17, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s26, #0
    s.movz       s28, #0
    s.movz       s29, #32
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s30, v14, #6
    s.mov        s33, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s33, s17            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s17          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s17
    mb.arm       s26, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s28, v13, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s26
    mb.wait      s26
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s28, x8dot_done_57
    s.movz       s29, #0
    s.add        s30, s6, s23
    s.addi       s31, s29, #0
    s.addi       s29, s30, #32
    s.addi       s30, s27, #8448
x8dot_row_58:
    s.addi       s33, s32, #-32
    v.movi       v19, #0
    s.sub        s34, s33, s31
    s.add        s33, s29, s31
    v.splat      v37, s34
    s.shli       s34, s31, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s33, v29]            // index is in elements (ISA sec 9.1)
    s.add        s33, s30, s34
    s.addi       s34, s31, #1
    s.movz       s35, #32
    v.st.b       [s33, #0], v19
    fence.acq_rel.device
    s.mov        s31, s34
    s.cmp.lt     s33, s31, s35
    br.nz        s33, x8dot_row_58
x8dot_done_57:
    v.extract    s29, v22, #0
    v.splat      v19, s29
    v.splat      v37, s28
    vf.max.ieee  v40, v19, v17
    v.movi       v19, #0
    v.splat      v42, s28
    v.movi       v43, #0
    v.rcp.approx v44, v40                        // ISA 8.8: <= 2**-22 relative
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    s.movz       s30, #0
    s.movz       s31, #32
    v.extract    s33, v22, #1
    v.cmp.ne     p1, v37, v19
    v.cmp.eq     p2, v42, v43
    v.extract    s34, v14, #7
    v.splat      v19, s33
    s.mov        s35, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s29, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s30, s27, #4096
    vf.max.ieee  v37, v19, v17
    m.mma.async.k32.e4m3 a15, v48, v56, s29
    mb.wait      s29
    v.ld.w       v19, [s30, #0]
    v.rcp.approx v42, v37                        // ISA 8.8: <= 2**-22 relative
    s.addi       s30, s27, #10240                // 512 bytes of repack scratch
    v.extract    s31, v22, #2
    v.splat      v43, s31
    s.addi       s31, s30, #0
    s.addi       s33, s27, #4160
    vf.max.ieee  v45, v43, v17
    s.addi       s34, s30, #32
    vf.fms       v43, v40, v44, v20
    s.addi       s35, s27, #4224
    v.rcp.approx v46, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v47, v44, v43, v44
    vf.neg       v43, v47                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v47, v43, v44
    vf.mul       v43, v19, v47                   // a/y: faithful quotient
    vf.fms       v44, v43, v40, v19
    vf.fms       v19, v37, v42, v20
    vf.fms       v40, v44, v47, v43
    vf.fms       v44, v42, v19, v42
    vf.neg       v19, v40                        // a/y: one correction to the IEEE quotient
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    vf.fms       v44, v45, v46, v20
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v47, v19, v43
    vf.cmp.o     p1, v40, v40
    vf.cvt.f32.e4m3 v19, v47
    v.lshr       v43, v47, v39
    @p1 v.sel        v47, v40, v42
    v.and        v40, v43, v41
    vf.fms       v42, v46, v44, v46
    v.or         v43, v19, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s36, s30, #64
    v.st.b       [s31, #0], v43
    v.extract    s31, v22, #3
    vf.neg       v19, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v40, [s33, #0]
    v.splat      v42, s31
    vf.cmp.o     p1, v19, v19
    vf.max.ieee  v43, v42, v17
    @p1 v.sel        v42, v19, v46
    s.addi       s31, s27, #4288
    v.rcp.approx v19, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v40, v47                   // a/y: faithful quotient
    vf.fms       v46, v44, v37, v40
    vf.fms       v37, v46, v47, v44
    vf.neg       v40, v37                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v37, v40, v44
    vf.cvt.f32.e4m3 v40, v37
    v.lshr       v44, v37, v39
    v.and        v37, v44, v41
    s.addi       s33, s30, #96
    v.or         v44, v40, v37                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v37, v43, v19, v20
    v.st.b       [s34, #0], v44
    v.extract    s34, v22, #4
    vf.fms       v40, v19, v37, v19
    v.ld.w       v37, [s35, #0]
    v.splat      v44, s34
    s.addi       s34, s27, #4352
    vf.max.ieee  v46, v44, v17
    vf.neg       v44, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v46                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v47, v44, v19
    vf.mul       v19, v37, v42                   // a/y: faithful quotient
    vf.fms       v44, v19, v45, v37
    vf.fms       v37, v44, v42, v19
    vf.neg       v42, v37                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v37, v42, v19
    vf.cvt.f32.e4m3 v19, v37
    v.lshr       v42, v37, v39
    v.and        v37, v42, v41
    s.addi       s35, s30, #128
    v.or         v42, v19, v37                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v46, v40, v20
    v.st.b       [s36, #0], v42
    v.extract    s36, v22, #5
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s36
    s.addi       s31, s27, #4416
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s36, s30, #160
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s33, #0], v42
    v.extract    s33, v22, #6
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s34, #0]
    v.splat      v42, s33
    s.addi       s33, s27, #4480
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v45                   // a/y: faithful quotient
    vf.fms       v42, v37, v46, v19
    vf.fms       v19, v42, v45, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s34, s30, #192
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s35, #0], v42
    v.extract    s35, v22, #7
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s35
    s.addi       s31, s27, #4544
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s35, s30, #224
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s36, #0], v42
    v.extract    s36, v22, #8
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s36
    s.addi       s33, s27, #4608
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s36, s30, #256
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s34, #0], v42
    v.extract    s34, v22, #9
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s34
    s.addi       s31, s27, #4672
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s34, s30, #288
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s35, #0], v42
    v.extract    s35, v22, #10
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s35
    s.addi       s33, s27, #4736
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s35, s30, #320
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s36, #0], v42
    v.extract    s36, v22, #11
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s36
    s.addi       s31, s27, #4800
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s36, s30, #352
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s34, #0], v42
    v.extract    s34, v22, #12
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s34
    s.addi       s33, s27, #4864
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s34, s30, #384
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s35, #0], v42
    v.extract    s35, v22, #13
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s35
    s.addi       s31, s27, #4928
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s35, s30, #416
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s36, #0], v42
    v.extract    s36, v22, #14
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s36
    s.addi       s33, s27, #4992
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s36, s30, #448
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s34, #0], v42
    v.extract    s34, v22, #15
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s34
    s.addi       s31, s27, #5056
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s34, s30, #480
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s35, #0], v42
    v.extract    s35, v22, #0
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s35
    s.addi       s33, s27, #5120
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s35, s30, #16
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s36, #0], v42
    v.extract    s36, v22, #1
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s36
    s.addi       s31, s27, #5184
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s36, s30, #48
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s34, #0], v42
    v.extract    s34, v22, #2
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s34
    s.addi       s33, s27, #5248
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s34, s30, #80
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s35, #0], v42
    v.extract    s35, v22, #3
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s35
    s.addi       s31, s27, #5312
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s35, s30, #112
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s36, #0], v42
    v.extract    s36, v22, #4
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s36
    s.addi       s33, s27, #5376
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s36, s30, #144
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s34, #0], v42
    v.extract    s34, v22, #5
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s34
    s.addi       s31, s27, #5440
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s34, s30, #176
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s35, #0], v42
    v.extract    s35, v22, #6
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s35
    s.addi       s33, s27, #5504
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s35, s30, #208
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s36, #0], v42
    v.extract    s36, v22, #7
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s36
    s.addi       s31, s27, #5568
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s36, s30, #240
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s34, #0], v42
    v.extract    s34, v22, #8
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s34
    s.addi       s33, s27, #5632
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s34, s30, #272
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s35, #0], v42
    v.extract    s35, v22, #9
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s35
    s.addi       s31, s27, #5696
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s35, s30, #304
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s36, #0], v42
    v.extract    s36, v22, #10
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s36
    s.addi       s33, s27, #5760
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s36, s30, #336
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s34, #0], v42
    v.extract    s34, v22, #11
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s34
    s.addi       s31, s27, #5824
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s34, s30, #368
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s35, #0], v42
    v.extract    s35, v22, #12
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s35
    s.addi       s33, s27, #5888
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s35, s30, #400
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s36, #0], v42
    v.extract    s36, v22, #13
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s36
    s.addi       s31, s27, #5952
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s36, s30, #432
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s34, #0], v42
    v.extract    s34, v22, #14
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    v.splat      v42, s34
    s.addi       s33, s27, #6016
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s34, s30, #464
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s35, #0], v42
    v.extract    s35, v22, #15
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s31, #0]
    v.splat      v42, s35
    s.addi       s31, s27, #6080
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s35, s30, #496
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s36, #0], v42
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s33, #0]
    s.addi       s33, s30, #64
    s.addi       s36, s30, #128
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v40, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s34, #0], v42
    s.addi       s34, s30, #192
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s30, #256
    vf.mul       v37, v19, v40                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v40, v37
    vf.neg       v40, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v19, v40, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v40, v19, v39
    v.and        v19, v40, v41
    v.or         v40, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v40
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s35, s30, #320
    v.ld.w       v19, [s30, #0]
    v.mov        v48, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s33, #0]
    s.addi       s33, s30, #384
    s.addi       s37, s30, #448
    v.mov        v49, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s36, #0]
    v.extract    s30, v13, #0
    v.mov        v50, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s34, #0]
    v.mov        v51, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s31, #0]
    v.mov        v52, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s35, #0]
    v.mov        v53, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s33, #0]
    v.mov        v54, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s37, #0]
    v.mov        v55, v19                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s30, x8dot_done_59
    s.movz       s31, #0
    s.add        s33, s6, s23
    s.addi       s34, s31, #0
    s.addi       s31, s33, #64
    s.addi       s33, s27, #8448
x8dot_row_60:
    s.addi       s35, s32, #-64
    v.movi       v19, #0
    s.sub        s36, s35, s34
    s.add        s35, s31, s34
    v.splat      v37, s36
    s.shli       s36, s34, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s35, v32]            // index is in elements (ISA sec 9.1)
    s.add        s35, s33, s36
    s.addi       s36, s34, #1
    s.movz       s37, #32
    v.st.b       [s35, #0], v19
    fence.acq_rel.device
    s.mov        s34, s36
    s.cmp.lt     s35, s34, s37
    br.nz        s35, x8dot_row_60
x8dot_done_59:
    v.splat      v19, s30
    v.movi       v37, #0
    v.splat      v40, s30
    v.movi       v42, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s31, #0
    s.movz       s33, #0
    s.movz       s34, #64
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s35, v14, #0
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v13, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_61
    s.movz       s34, #0
    s.add        s35, s6, s23
    s.addi       s36, s34, #0
    s.addi       s34, s35, #64
    s.addi       s35, s27, #8448
x8dot_row_62:
    s.addi       s37, s32, #-64
    v.movi       v19, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v37, s38
    s.shli       s38, s36, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s37, v23]            // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.addi       s38, s36, #1
    s.movz       s39, #32
    v.st.b       [s37, #0], v19
    fence.acq_rel.device
    s.mov        s36, s38
    s.cmp.lt     s37, s36, s39
    br.nz        s37, x8dot_row_62
x8dot_done_61:
    v.splat      v19, s33
    v.movi       v37, #0
    v.splat      v40, s33
    v.movi       v42, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    s.movz       s35, #0
    s.movz       s36, #64
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s37, v14, #1
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v13, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_63
    s.movz       s36, #0
    s.add        s37, s6, s23
    s.addi       s38, s36, #0
    s.addi       s36, s37, #64
    s.addi       s37, s27, #8448
x8dot_row_64:
    s.addi       s39, s32, #-64
    v.movi       v19, #0
    s.sub        s40, s39, s38
    s.add        s39, s36, s38
    v.splat      v37, s40
    s.shli       s40, s38, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s39, v24]            // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.addi       s40, s38, #1
    s.movz       s41, #32
    v.st.b       [s39, #0], v19
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s39, s38, s41
    br.nz        s39, x8dot_row_64
x8dot_done_63:
    v.splat      v19, s35
    v.movi       v37, #0
    v.splat      v40, s35
    v.movi       v42, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    s.movz       s37, #0
    s.movz       s38, #64
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s39, v14, #2
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v13, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_65
    s.movz       s38, #0
    s.add        s39, s6, s23
    s.addi       s40, s38, #0
    s.addi       s38, s39, #64
    s.addi       s39, s27, #8448
x8dot_row_66:
    s.addi       s41, s32, #-64
    v.movi       v19, #0
    s.sub        s42, s41, s40
    s.add        s41, s38, s40
    v.splat      v37, s42
    s.shli       s42, s40, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s41, v25]            // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.addi       s42, s40, #1
    s.movz       s43, #32
    v.st.b       [s41, #0], v19
    fence.acq_rel.device
    s.mov        s40, s42
    s.cmp.lt     s41, s40, s43
    br.nz        s41, x8dot_row_66
x8dot_done_65:
    v.splat      v19, s37
    v.movi       v37, #0
    v.splat      v40, s37
    v.movi       v42, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    s.movz       s39, #0
    s.movz       s40, #64
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s41, v14, #3
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v13, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s39, x8dot_done_67
    s.movz       s40, #0
    s.add        s41, s6, s23
    s.addi       s42, s40, #0
    s.addi       s40, s41, #64
    s.addi       s41, s27, #8448
x8dot_row_68:
    s.addi       s43, s32, #-64
    v.movi       v19, #0
    s.sub        s44, s43, s42
    s.add        s43, s40, s42
    v.splat      v37, s44
    s.shli       s44, s42, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s43, v33]            // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.addi       s44, s42, #1
    s.movz       s45, #32
    v.st.b       [s43, #0], v19
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s43, s42, s45
    br.nz        s43, x8dot_row_68
x8dot_done_67:
    v.splat      v19, s39
    v.movi       v37, #0
    v.splat      v40, s39
    v.movi       v42, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    s.movz       s41, #0
    s.movz       s42, #64
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s43, v14, #4
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s44, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s40, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v13, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s41, x8dot_done_69
    s.movz       s42, #0
    s.add        s43, s6, s23
    s.addi       s44, s42, #0
    s.addi       s42, s43, #64
    s.addi       s43, s27, #8448
x8dot_row_70:
    s.addi       s45, s32, #-64
    v.movi       v19, #0
    s.sub        s46, s45, s44
    s.add        s45, s42, s44
    v.splat      v37, s46
    s.shli       s46, s44, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s45, v34]            // index is in elements (ISA sec 9.1)
    s.add        s45, s43, s46
    s.addi       s46, s44, #1
    s.movz       s47, #32
    v.st.b       [s45, #0], v19
    fence.acq_rel.device
    s.mov        s44, s46
    s.cmp.lt     s45, s44, s47
    br.nz        s45, x8dot_row_70
x8dot_done_69:
    v.splat      v19, s41
    v.movi       v37, #0
    v.splat      v40, s41
    v.movi       v42, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    s.movz       s43, #0
    s.movz       s44, #64
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s45, v14, #5
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s46, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v13, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s43, x8dot_done_71
    s.movz       s44, #0
    s.add        s45, s6, s23
    s.addi       s46, s44, #0
    s.addi       s44, s45, #64
    s.addi       s45, s27, #8448
x8dot_row_72:
    s.addi       s47, s32, #-64
    v.movi       v19, #0
    s.sub        s48, s47, s46
    s.add        s47, s44, s46
    v.splat      v37, s48
    s.shli       s48, s46, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s47, v27]            // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s48
    s.addi       s48, s46, #1
    s.movz       s49, #32
    v.st.b       [s47, #0], v19
    fence.acq_rel.device
    s.mov        s46, s48
    s.cmp.lt     s47, s46, s49
    br.nz        s47, x8dot_row_72
x8dot_done_71:
    v.splat      v19, s43
    v.movi       v37, #0
    v.splat      v40, s43
    v.movi       v42, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    s.movz       s45, #0
    s.movz       s46, #64
    v.cmp.ne     p1, v19, v37
    v.cmp.eq     p2, v40, v42
    v.extract    s47, v14, #6
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s48, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v13, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s45, x8dot_done_73
    s.movz       s46, #0
    s.add        s47, s6, s23
    s.addi       s48, s46, #0
    s.addi       s46, s47, #64
    s.addi       s47, s27, #8448
x8dot_row_74:
    s.addi       s49, s32, #-64
    v.movi       v19, #0
    s.sub        s50, s49, s48
    s.add        s49, s46, s48
    v.splat      v37, s50
    s.shli       s50, s48, #4
    v.cmp.gt     p1, v37, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s49, v29]            // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.addi       s50, s48, #1
    s.movz       s51, #32
    v.st.b       [s49, #0], v19
    fence.acq_rel.device
    s.mov        s48, s50
    s.cmp.lt     s49, s48, s51
    br.nz        s49, x8dot_row_74
x8dot_done_73:
    v.extract    s46, v22, #0
    v.splat      v19, s46
    v.splat      v37, s45
    vf.max.ieee  v40, v19, v17
    v.movi       v19, #0
    v.splat      v42, s45
    v.movi       v43, #0
    v.rcp.approx v44, v40                        // ISA 8.8: <= 2**-22 relative
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    s.movz       s47, #0
    s.movz       s48, #64
    v.extract    s49, v22, #1
    v.cmp.ne     p1, v37, v19
    v.cmp.eq     p2, v42, v43
    v.extract    s50, v14, #7
    v.splat      v19, s49
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s46, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s47, s27, #6144
    vf.max.ieee  v37, v19, v17
    m.mma.async.k32.e4m3 a15, v48, v56, s46
    mb.wait      s46
    v.ld.w       v19, [s47, #0]
    v.rcp.approx v42, v37                        // ISA 8.8: <= 2**-22 relative
    s.addi       s47, s27, #10752                // 512 bytes of repack scratch
    v.extract    s48, v22, #2
    v.splat      v43, s48
    s.addi       s48, s47, #0
    s.addi       s49, s27, #6208
    vf.max.ieee  v45, v43, v17
    s.addi       s50, s47, #32
    vf.fms       v43, v40, v44, v20
    s.addi       s51, s27, #6272
    v.rcp.approx v46, v45                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v47, v44, v43, v44
    vf.neg       v43, v47                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v47, v43, v44
    vf.mul       v43, v19, v47                   // a/y: faithful quotient
    vf.fms       v44, v43, v40, v19
    vf.fms       v19, v37, v42, v20
    vf.fms       v40, v44, v47, v43
    vf.fms       v44, v42, v19, v42
    vf.neg       v19, v40                        // a/y: one correction to the IEEE quotient
    vf.neg       v40, v44                        // Newton step: r0*(2 - x*r0)
    vf.fms       v44, v45, v46, v20
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v47, v19, v43
    vf.cmp.o     p1, v40, v40
    vf.cvt.f32.e4m3 v19, v47
    v.lshr       v43, v47, v39
    @p1 v.sel        v47, v40, v42
    v.and        v40, v43, v41
    vf.fms       v42, v46, v44, v46
    v.or         v43, v19, v40                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s52, s47, #64
    v.st.b       [s48, #0], v43
    v.extract    s48, v22, #3
    vf.neg       v19, v42                        // Newton step: r0*(2 - x*r0)
    v.ld.w       v40, [s49, #0]
    v.splat      v42, s48
    vf.cmp.o     p1, v19, v19
    vf.max.ieee  v43, v42, v17
    @p1 v.sel        v42, v19, v46
    s.addi       s48, s27, #6336
    v.rcp.approx v19, v43                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v40, v47                   // a/y: faithful quotient
    vf.fms       v46, v44, v37, v40
    vf.fms       v37, v46, v47, v44
    vf.neg       v40, v37                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v37, v40, v44
    vf.cvt.f32.e4m3 v40, v37
    v.lshr       v44, v37, v39
    v.and        v37, v44, v41
    s.addi       s49, s47, #96
    v.or         v44, v40, v37                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v37, v43, v19, v20
    v.st.b       [s50, #0], v44
    v.extract    s50, v22, #4
    vf.fms       v40, v19, v37, v19
    v.ld.w       v37, [s51, #0]
    v.splat      v44, s50
    s.addi       s50, s27, #6400
    vf.max.ieee  v46, v44, v17
    vf.neg       v44, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v46                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v47, v44, v19
    vf.mul       v19, v37, v42                   // a/y: faithful quotient
    vf.fms       v44, v19, v45, v37
    vf.fms       v37, v44, v42, v19
    vf.neg       v42, v37                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v37, v42, v19
    vf.cvt.f32.e4m3 v19, v37
    v.lshr       v42, v37, v39
    v.and        v37, v42, v41
    s.addi       s51, s47, #128
    v.or         v42, v19, v37                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v46, v40, v20
    v.st.b       [s52, #0], v42
    v.extract    s52, v22, #5
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s48, #0]
    v.splat      v42, s52
    s.addi       s48, s27, #6464
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v45, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s52, s47, #160
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s49, #0], v42
    v.extract    s49, v22, #6
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s50, #0]
    v.splat      v42, s49
    s.addi       s49, s27, #6528
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v45                   // a/y: faithful quotient
    vf.fms       v42, v37, v46, v19
    vf.fms       v19, v42, v45, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s50, s47, #192
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s51, #0], v42
    v.extract    s51, v22, #7
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s48, #0]
    v.splat      v42, s51
    s.addi       s48, s27, #6592
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s51, s47, #224
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s52, #0], v42
    v.extract    s52, v22, #8
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s49, #0]
    v.splat      v42, s52
    s.addi       s49, s27, #6656
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s52, s47, #256
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s50, #0], v42
    v.extract    s50, v22, #9
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s48, #0]
    v.splat      v42, s50
    s.addi       s48, s27, #6720
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s50, s47, #288
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s51, #0], v42
    v.extract    s51, v22, #10
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s49, #0]
    v.splat      v42, s51
    s.addi       s49, s27, #6784
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s51, s47, #320
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s52, #0], v42
    v.extract    s52, v22, #11
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s48, #0]
    v.splat      v42, s52
    s.addi       s48, s27, #6848
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s52, s47, #352
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s50, #0], v42
    v.extract    s50, v22, #12
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s49, #0]
    v.splat      v42, s50
    s.addi       s49, s27, #6912
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s50, s47, #384
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s51, #0], v42
    v.extract    s51, v22, #13
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s48, #0]
    v.splat      v42, s51
    s.addi       s48, s27, #6976
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s51, s47, #416
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s52, #0], v42
    v.extract    s52, v22, #14
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s49, #0]
    v.splat      v42, s52
    s.addi       s49, s27, #7040
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s52, s47, #448
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s50, #0], v42
    v.extract    s50, v22, #15
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s48, #0]
    v.splat      v42, s50
    s.addi       s48, s27, #7104
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s50, s47, #480
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s51, #0], v42
    v.extract    s51, v22, #0
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s49, #0]
    v.splat      v42, s51
    s.addi       s49, s27, #7168
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s51, s47, #16
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s52, #0], v42
    v.extract    s52, v22, #1
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s48, #0]
    v.splat      v42, s52
    s.addi       s48, s27, #7232
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s52, s47, #48
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s50, #0], v42
    v.extract    s50, v22, #2
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s49, #0]
    v.splat      v42, s50
    s.addi       s49, s27, #7296
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s50, s47, #80
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s51, #0], v42
    v.extract    s51, v22, #3
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s48, #0]
    v.splat      v42, s51
    s.addi       s48, s27, #7360
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s51, s47, #112
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s52, #0], v42
    v.extract    s52, v22, #4
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s49, #0]
    v.splat      v42, s52
    s.addi       s49, s27, #7424
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s52, s47, #144
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s50, #0], v42
    v.extract    s50, v22, #5
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s48, #0]
    v.splat      v42, s50
    s.addi       s48, s27, #7488
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s50, s47, #176
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s51, #0], v42
    v.extract    s51, v22, #6
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s49, #0]
    v.splat      v42, s51
    s.addi       s49, s27, #7552
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s51, s47, #208
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s52, #0], v42
    v.extract    s52, v22, #7
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s48, #0]
    v.splat      v42, s52
    s.addi       s48, s27, #7616
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s52, s47, #240
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s50, #0], v42
    v.extract    s50, v22, #8
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s49, #0]
    v.splat      v42, s50
    s.addi       s49, s27, #7680
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s50, s47, #272
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s51, #0], v42
    v.extract    s51, v22, #9
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s48, #0]
    v.splat      v42, s51
    s.addi       s48, s27, #7744
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v44, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s51, s47, #304
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v37, v20
    v.st.b       [s52, #0], v42
    v.extract    s52, v22, #10
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s49, #0]
    v.splat      v42, s52
    s.addi       s49, s27, #7808
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v43, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s52, s47, #336
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v40, v20
    v.st.b       [s50, #0], v42
    v.extract    s50, v22, #11
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s48, #0]
    v.splat      v42, s50
    s.addi       s48, s27, #7872
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v45, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s50, s47, #368
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v37, v20
    v.st.b       [s51, #0], v42
    v.extract    s51, v22, #12
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s49, #0]
    v.splat      v42, s51
    s.addi       s49, s27, #7936
    vf.max.ieee  v45, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v44, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s51, s47, #400
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v45, v40, v20
    v.st.b       [s52, #0], v42
    v.extract    s52, v22, #13
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s48, #0]
    v.splat      v42, s52
    s.addi       s48, s27, #8000
    vf.max.ieee  v44, v42, v17
    vf.neg       v42, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v44                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v46, v42, v40
    vf.mul       v40, v19, v47                   // a/y: faithful quotient
    vf.fms       v42, v40, v43, v19
    vf.fms       v19, v42, v47, v40
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v40
    vf.cvt.f32.e4m3 v40, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s52, s47, #432
    v.or         v42, v40, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v44, v37, v20
    v.st.b       [s50, #0], v42
    v.extract    s50, v22, #14
    vf.fms       v40, v37, v19, v37
    v.ld.w       v19, [s49, #0]
    v.splat      v42, s50
    s.addi       s49, s27, #8064
    vf.max.ieee  v43, v42, v17
    vf.neg       v42, v40                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v40, v43                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v47, v42, v37
    vf.mul       v37, v19, v46                   // a/y: faithful quotient
    vf.fms       v42, v37, v45, v19
    vf.fms       v19, v42, v46, v37
    vf.neg       v42, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v19, v42, v37
    vf.cvt.f32.e4m3 v37, v19
    v.lshr       v42, v19, v39
    v.and        v19, v42, v41
    s.addi       s50, s47, #464
    v.or         v42, v37, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v19, v43, v40, v20
    v.st.b       [s51, #0], v42
    v.extract    s51, v22, #15
    vf.fms       v37, v40, v19, v40
    v.ld.w       v19, [s48, #0]
    v.splat      v42, s51
    s.addi       s48, s27, #8128
    vf.max.ieee  v45, v42, v17
    vf.neg       v17, v37                        // Newton step: r0*(2 - x*r0)
    v.rcp.approx v37, v45                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p1, v17, v17
    @p1 v.sel        v42, v17, v40
    vf.mul       v17, v19, v47                   // a/y: faithful quotient
    vf.fms       v40, v17, v44, v19
    vf.fms       v19, v40, v47, v17
    vf.neg       v40, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v19, v40, v17
    vf.cvt.f32.e4m3 v17, v19
    v.lshr       v40, v19, v39
    v.and        v19, v40, v41
    s.addi       s51, s47, #496
    v.or         v40, v17, v19                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v17, v45, v37, v20
    v.st.b       [s52, #0], v40
    vf.fms       v19, v37, v17, v37
    v.ld.w       v17, [s49, #0]
    s.addi       s49, s47, #64
    s.addi       s52, s47, #128
    vf.neg       v20, v19                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v19, v20, v37
    vf.mul       v20, v17, v42                   // a/y: faithful quotient
    vf.fms       v37, v20, v43, v17
    vf.fms       v17, v37, v42, v20
    vf.neg       v37, v17                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v37, v37
    @p1 v.sel        v17, v37, v20
    vf.cvt.f32.e4m3 v20, v17
    v.lshr       v37, v17, v39
    v.and        v17, v37, v41
    v.or         v37, v20, v17                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s50, #0], v37
    s.addi       s50, s47, #192
    v.ld.w       v17, [s48, #0]
    s.addi       s48, s47, #256
    vf.mul       v20, v17, v19                   // a/y: faithful quotient
    vf.fms       v37, v20, v45, v17
    vf.fms       v17, v37, v19, v20
    vf.neg       v19, v17                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v17, v19, v20
    vf.cvt.f32.e4m3 v19, v17
    v.lshr       v20, v17, v39
    v.and        v17, v20, v41
    v.or         v20, v19, v17                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v20
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s51, s47, #320
    v.ld.w       v17, [s47, #0]
    v.mov        v48, v17                        // hand off through the shared window (sec 7.3)
    v.ld.w       v17, [s49, #0]
    s.addi       s49, s47, #384
    s.addi       s53, s47, #448
    v.mov        v49, v17                        // hand off through the shared window (sec 7.3)
    v.ld.w       v17, [s52, #0]
    v.extract    s47, v13, #0
    v.mov        v50, v17                        // hand off through the shared window (sec 7.3)
    v.ld.w       v17, [s50, #0]
    v.mov        v51, v17                        // hand off through the shared window (sec 7.3)
    v.ld.w       v17, [s48, #0]
    v.mov        v52, v17                        // hand off through the shared window (sec 7.3)
    v.ld.w       v17, [s51, #0]
    v.mov        v53, v17                        // hand off through the shared window (sec 7.3)
    v.ld.w       v17, [s49, #0]
    v.mov        v54, v17                        // hand off through the shared window (sec 7.3)
    v.ld.w       v17, [s53, #0]
    v.mov        v55, v17                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s47, x8dot_done_75
    s.movz       s48, #0
    s.add        s49, s6, s23
    s.addi       s50, s48, #0
    s.addi       s48, s49, #96
    s.addi       s49, s27, #8448
x8dot_row_76:
    s.addi       s51, s32, #-96
    v.movi       v17, #0
    s.sub        s52, s51, s50
    s.add        s51, s48, s50
    v.splat      v19, s52
    s.shli       s52, s50, #4
    v.cmp.gt     p1, v19, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s51, v32]            // index is in elements (ISA sec 9.1)
    s.add        s51, s49, s52
    s.addi       s52, s50, #1
    s.movz       s53, #32
    v.st.b       [s51, #0], v17
    fence.acq_rel.device
    s.mov        s50, s52
    s.cmp.lt     s51, s50, s53
    br.nz        s51, x8dot_row_76
x8dot_done_75:
    v.splat      v17, s47
    v.movi       v19, #0
    v.splat      v20, s47
    v.movi       v32, #0
    mb.arm       s47, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s48, #0
    s.movz       s49, #0
    s.movz       s50, #96
    v.cmp.ne     p1, v17, v19
    v.cmp.eq     p2, v20, v32
    v.extract    s51, v14, #0
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s52, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s48, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s48, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v13, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s48
    mb.wait      s48
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s49, x8dot_done_77
    s.movz       s50, #0
    s.add        s51, s6, s23
    s.addi       s52, s50, #0
    s.addi       s50, s51, #96
    s.addi       s51, s27, #8448
x8dot_row_78:
    s.addi       s53, s32, #-96
    v.movi       v17, #0
    s.sub        s54, s53, s52
    s.add        s53, s50, s52
    v.splat      v19, s54
    s.shli       s54, s52, #4
    v.cmp.gt     p1, v19, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s53, v23]            // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.addi       s54, s52, #1
    s.movz       s55, #32
    v.st.b       [s53, #0], v17
    fence.acq_rel.device
    s.mov        s52, s54
    s.cmp.lt     s53, s52, s55
    br.nz        s53, x8dot_row_78
x8dot_done_77:
    v.splat      v17, s49
    v.movi       v19, #0
    v.splat      v20, s49
    v.movi       v23, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    s.movz       s51, #0
    s.movz       s52, #96
    v.cmp.ne     p1, v17, v19
    v.cmp.eq     p2, v20, v23
    v.extract    s53, v14, #1
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s54, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s51, v13, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s50
    mb.wait      s50
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s51, x8dot_done_79
    s.movz       s52, #0
    s.add        s53, s6, s23
    s.addi       s54, s52, #0
    s.addi       s52, s53, #96
    s.addi       s53, s27, #8448
x8dot_row_80:
    s.addi       s55, s32, #-96
    v.movi       v17, #0
    s.sub        s56, s55, s54
    s.add        s55, s52, s54
    v.splat      v19, s56
    s.shli       s56, s54, #4
    v.cmp.gt     p1, v19, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s55, v24]            // index is in elements (ISA sec 9.1)
    s.add        s55, s53, s56
    s.addi       s56, s54, #1
    s.movz       s57, #32
    v.st.b       [s55, #0], v17
    fence.acq_rel.device
    s.mov        s54, s56
    s.cmp.lt     s55, s54, s57
    br.nz        s55, x8dot_row_80
x8dot_done_79:
    v.splat      v17, s51
    v.movi       v19, #0
    v.splat      v20, s51
    v.movi       v23, #0
    mb.arm       s51, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    s.movz       s53, #0
    s.movz       s54, #96
    v.cmp.ne     p1, v17, v19
    v.cmp.eq     p2, v20, v23
    v.extract    s55, v14, #2
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s56, s51            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s52, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v13, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s53, x8dot_done_81
    s.movz       s54, #0
    s.add        s55, s6, s23
    s.addi       s56, s54, #0
    s.addi       s54, s55, #96
    s.addi       s55, s27, #8448
x8dot_row_82:
    s.addi       s57, s32, #-96
    v.movi       v17, #0
    s.sub        s58, s57, s56
    s.add        s57, s54, s56
    v.splat      v19, s58
    s.shli       s58, s56, #4
    v.cmp.gt     p1, v19, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s57, v25]            // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.addi       s58, s56, #1
    s.movz       s59, #32
    v.st.b       [s57, #0], v17
    fence.acq_rel.device
    s.mov        s56, s58
    s.cmp.lt     s57, s56, s59
    br.nz        s57, x8dot_row_82
x8dot_done_81:
    v.splat      v17, s53
    v.movi       v19, #0
    v.splat      v20, s53
    v.movi       v23, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    s.movz       s55, #0
    s.movz       s56, #96
    v.cmp.ne     p1, v17, v19
    v.cmp.eq     p2, v20, v23
    v.extract    s57, v14, #3
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s58, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s57                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s54, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v13, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s55, x8dot_done_83
    s.movz       s56, #0
    s.add        s57, s6, s23
    s.addi       s58, s56, #0
    s.addi       s56, s57, #96
    s.addi       s57, s27, #8448
x8dot_row_84:
    s.addi       s59, s32, #-96
    v.movi       v17, #0
    s.sub        s60, s59, s58
    s.add        s59, s56, s58
    v.splat      v19, s60
    s.shli       s60, s58, #4
    v.cmp.gt     p1, v19, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s59, v33]            // index is in elements (ISA sec 9.1)
    s.add        s59, s57, s60
    s.addi       s60, s58, #1
    s.movz       s17, #32
    v.st.b       [s59, #0], v17
    fence.acq_rel.device
    s.mov        s58, s60
    s.cmp.lt     s26, s58, s17
    br.nz        s26, x8dot_row_84
x8dot_done_83:
    v.splat      v17, s55
    v.movi       v19, #0
    v.splat      v20, s55
    v.movi       v23, #0
    mb.arm       s17, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s26, #0
    s.movz       s28, #0
    s.movz       s29, #96
    v.cmp.ne     p1, v17, v19
    v.cmp.eq     p2, v20, v23
    v.extract    s30, v14, #4
    s.mov        s33, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s33, s17            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s17          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s17
    mb.arm       s26, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s28, v13, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s26
    mb.wait      s26
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s28, x8dot_done_85
    s.movz       s29, #0
    s.add        s30, s6, s23
    s.addi       s31, s29, #0
    s.addi       s29, s30, #96
    s.addi       s30, s27, #8448
x8dot_row_86:
    s.addi       s33, s32, #-96
    v.movi       v17, #0
    s.sub        s34, s33, s31
    s.add        s33, s29, s31
    v.splat      v19, s34
    s.shli       s34, s31, #4
    v.cmp.gt     p1, v19, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s33, v34]            // index is in elements (ISA sec 9.1)
    s.add        s33, s30, s34
    s.addi       s34, s31, #1
    s.movz       s35, #32
    v.st.b       [s33, #0], v17
    fence.acq_rel.device
    s.mov        s31, s34
    s.cmp.lt     s33, s31, s35
    br.nz        s33, x8dot_row_86
x8dot_done_85:
    v.splat      v17, s28
    v.movi       v19, #0
    v.splat      v20, s28
    v.movi       v23, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    s.movz       s30, #0
    s.movz       s31, #96
    v.cmp.ne     p1, v17, v19
    v.cmp.eq     p2, v20, v23
    v.extract    s33, v14, #5
    s.mov        s34, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s29, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s30, v13, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s30, x8dot_done_87
    s.movz       s31, #0
    s.add        s33, s6, s23
    s.addi       s34, s31, #0
    s.addi       s31, s33, #96
    s.addi       s33, s27, #8448
x8dot_row_88:
    s.addi       s35, s32, #-96
    v.movi       v17, #0
    s.sub        s36, s35, s34
    s.add        s35, s31, s34
    v.splat      v19, s36
    s.shli       s36, s34, #4
    v.cmp.gt     p1, v19, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v17, [s35, v27]            // index is in elements (ISA sec 9.1)
    s.add        s35, s33, s36
    s.addi       s36, s34, #1
    s.movz       s37, #32
    v.st.b       [s35, #0], v17
    fence.acq_rel.device
    s.mov        s34, s36
    s.cmp.lt     s35, s34, s37
    br.nz        s35, x8dot_row_88
x8dot_done_87:
    v.splat      v17, s30
    v.movi       v19, #0
    v.splat      v20, s30
    v.movi       v23, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s31, #0
    s.movz       s33, #0
    s.movz       s34, #96
    v.cmp.ne     p1, v17, v19
    v.cmp.eq     p2, v20, v23
    v.extract    s35, v14, #6
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v13, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_89
    s.movz       s34, #0
    s.add        s35, s6, s23
    s.addi       s36, s34, #0
    s.addi       s34, s35, #96
    s.addi       s35, s27, #8448
x8dot_row_90:
    s.addi       s37, s32, #-96
    v.movi       v13, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v17, s38
    s.shli       s38, s36, #4
    v.cmp.gt     p1, v17, v13
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v13, [s37, v29]            // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.addi       s38, s36, #1
    s.movz       s39, #32
    v.st.b       [s37, #0], v13
    fence.acq_rel.device
    s.mov        s36, s38
    s.cmp.lt     s37, s36, s39
    br.nz        s37, x8dot_row_90
x8dot_done_89:
    v.splat      v13, s33
    v.movi       v17, #0
    v.splat      v19, s33
    v.movi       v20, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    s.movz       s34, #0
    s.movz       s35, #96
    v.cmp.ne     p1, v13, v17
    v.cmp.eq     p2, v19, v20
    v.extract    s36, v14, #7
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s34, #0
    m.mma.async.k32.e4m3 a15, v48, v56, s33
    mb.wait      s33
    s.addi       s35, s27, #11264
    a.vread      v13, a8, s34
    s.movz       s34, #1
    v.st.w       [s35, #0], v13
    s.addi       s36, s35, #64
    a.vread      v13, a8, s34
    s.movz       s34, #2
    s.addi       s37, s35, #128
    s.movz       s38, #3
    s.addi       s39, s35, #192
    s.movz       s40, #4
    v.st.w       [s36, #0], v13
    a.vread      v13, a8, s34
    s.addi       s34, s35, #256
    s.movz       s36, #5
    v.st.w       [s37, #0], v13
    a.vread      v13, a8, s38
    s.addi       s37, s35, #320
    s.movz       s38, #6
    v.st.w       [s39, #0], v13
    a.vread      v13, a8, s40
    s.addi       s39, s35, #384
    s.movz       s40, #7
    v.st.w       [s34, #0], v13
    a.vread      v13, a8, s36
    s.addi       s34, s35, #448
    s.movz       s36, #8
    v.st.w       [s37, #0], v13
    a.vread      v13, a8, s38
    s.addi       s37, s35, #512
    s.movz       s38, #9
    v.st.w       [s39, #0], v13
    a.vread      v13, a8, s40
    s.addi       s39, s35, #576
    s.movz       s40, #10
    v.st.w       [s34, #0], v13
    a.vread      v13, a8, s36
    s.addi       s34, s35, #640
    s.movz       s36, #11
    v.st.w       [s37, #0], v13
    a.vread      v13, a8, s38
    s.addi       s37, s35, #704
    s.movz       s38, #12
    v.st.w       [s39, #0], v13
    a.vread      v13, a8, s40
    s.addi       s39, s35, #768
    s.movz       s40, #13
    v.st.w       [s34, #0], v13
    a.vread      v13, a8, s36
    s.addi       s34, s35, #832
    s.movz       s36, #14
    v.st.w       [s37, #0], v13
    a.vread      v13, a8, s38
    s.addi       s37, s35, #896
    s.movz       s38, #15
    s.addi       s41, s35, #960
    v.st.w       [s39, #0], v13
    a.vread      v13, a8, s40
    s.movz       s35, #0
    s.addi       s39, s27, #12288
    v.st.w       [s34, #0], v13
    a.vread      v13, a8, s36
    s.movz       s34, #1
    s.addi       s36, s39, #64
    v.st.w       [s37, #0], v13
    a.vread      v13, a8, s38
    s.movz       s37, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v13
    fence.acq_rel.device
    a.vread      v13, a9, s35
    s.movz       s35, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v13
    a.vread      v13, a9, s34
    s.movz       s34, #4
    v.st.w       [s36, #0], v13
    a.vread      v13, a9, s37
    s.addi       s36, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v13
    a.vread      v13, a9, s35
    s.addi       s35, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v13
    a.vread      v13, a9, s34
    s.addi       s34, s39, #384
    s.movz       s40, #7
    v.st.w       [s36, #0], v13
    a.vread      v13, a9, s37
    s.addi       s36, s39, #448
    s.movz       s37, #8
    v.st.w       [s35, #0], v13
    a.vread      v13, a9, s38
    s.addi       s35, s39, #512
    s.movz       s38, #9
    v.st.w       [s34, #0], v13
    a.vread      v13, a9, s40
    s.addi       s34, s39, #576
    s.movz       s40, #10
    v.st.w       [s36, #0], v13
    a.vread      v13, a9, s37
    s.addi       s36, s39, #640
    s.movz       s37, #11
    v.st.w       [s35, #0], v13
    a.vread      v13, a9, s38
    s.addi       s35, s39, #704
    s.movz       s38, #12
    v.st.w       [s34, #0], v13
    a.vread      v13, a9, s40
    s.addi       s34, s39, #768
    s.movz       s40, #13
    v.st.w       [s36, #0], v13
    a.vread      v13, a9, s37
    s.addi       s36, s39, #832
    s.movz       s37, #14
    v.st.w       [s35, #0], v13
    a.vread      v13, a9, s38
    s.addi       s35, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s34, #0], v13
    a.vread      v13, a9, s40
    s.movz       s34, #0
    s.addi       s39, s27, #13312
    v.st.w       [s36, #0], v13
    a.vread      v13, a9, s37
    s.movz       s36, #1
    s.addi       s37, s39, #64
    v.st.w       [s35, #0], v13
    a.vread      v13, a9, s38
    s.movz       s35, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v13
    fence.acq_rel.device
    a.vread      v13, a10, s34
    s.movz       s34, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v13
    a.vread      v13, a10, s36
    s.movz       s36, #4
    v.st.w       [s37, #0], v13
    a.vread      v13, a10, s35
    s.addi       s35, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v13
    a.vread      v13, a10, s34
    s.addi       s34, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v13
    a.vread      v13, a10, s36
    s.addi       s36, s39, #384
    s.movz       s40, #7
    v.st.w       [s35, #0], v13
    a.vread      v13, a10, s37
    s.addi       s35, s39, #448
    s.movz       s37, #8
    v.st.w       [s34, #0], v13
    a.vread      v13, a10, s38
    s.addi       s34, s39, #512
    s.movz       s38, #9
    v.st.w       [s36, #0], v13
    a.vread      v13, a10, s40
    s.addi       s36, s39, #576
    s.movz       s40, #10
    v.st.w       [s35, #0], v13
    a.vread      v13, a10, s37
    s.addi       s35, s39, #640
    s.movz       s37, #11
    v.st.w       [s34, #0], v13
    a.vread      v13, a10, s38
    s.addi       s34, s39, #704
    s.movz       s38, #12
    v.st.w       [s36, #0], v13
    a.vread      v13, a10, s40
    s.addi       s36, s39, #768
    s.movz       s40, #13
    v.st.w       [s35, #0], v13
    a.vread      v13, a10, s37
    s.addi       s35, s39, #832
    s.movz       s37, #14
    v.st.w       [s34, #0], v13
    a.vread      v13, a10, s38
    s.addi       s34, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s36, #0], v13
    a.vread      v13, a10, s40
    s.movz       s36, #0
    s.addi       s39, s27, #14336
    v.st.w       [s35, #0], v13
    a.vread      v13, a10, s37
    s.movz       s35, #1
    s.addi       s37, s39, #64
    v.st.w       [s34, #0], v13
    a.vread      v13, a10, s38
    s.movz       s34, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v13
    fence.acq_rel.device
    a.vread      v13, a11, s36
    s.movz       s36, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v13
    a.vread      v13, a11, s35
    s.movz       s35, #4
    v.st.w       [s37, #0], v13
    a.vread      v13, a11, s34
    s.addi       s34, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v13
    a.vread      v13, a11, s36
    s.addi       s36, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v13
    a.vread      v13, a11, s35
    s.addi       s35, s39, #384
    s.movz       s40, #7
    v.st.w       [s34, #0], v13
    a.vread      v13, a11, s37
    s.addi       s34, s39, #448
    s.movz       s37, #8
    v.st.w       [s36, #0], v13
    a.vread      v13, a11, s38
    s.addi       s36, s39, #512
    s.movz       s38, #9
    v.st.w       [s35, #0], v13
    a.vread      v13, a11, s40
    s.addi       s35, s39, #576
    s.movz       s40, #10
    v.st.w       [s34, #0], v13
    a.vread      v13, a11, s37
    s.addi       s34, s39, #640
    s.movz       s37, #11
    v.st.w       [s36, #0], v13
    a.vread      v13, a11, s38
    s.addi       s36, s39, #704
    s.movz       s38, #12
    v.st.w       [s35, #0], v13
    a.vread      v13, a11, s40
    s.addi       s35, s39, #768
    s.movz       s40, #13
    v.st.w       [s34, #0], v13
    a.vread      v13, a11, s37
    s.addi       s34, s39, #832
    s.movz       s37, #14
    v.st.w       [s36, #0], v13
    a.vread      v13, a11, s38
    s.addi       s36, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s35, #0], v13
    a.vread      v13, a11, s40
    s.movz       s35, #0
    s.addi       s39, s27, #15360
    v.st.w       [s34, #0], v13
    a.vread      v13, a11, s37
    s.movz       s34, #1
    s.addi       s37, s39, #64
    v.st.w       [s36, #0], v13
    a.vread      v13, a11, s38
    s.movz       s36, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v13
    fence.acq_rel.device
    a.vread      v13, a12, s35
    s.movz       s35, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v13
    a.vread      v13, a12, s34
    s.movz       s34, #4
    v.st.w       [s37, #0], v13
    a.vread      v13, a12, s36
    s.addi       s36, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v13
    a.vread      v13, a12, s35
    s.addi       s35, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v13
    a.vread      v13, a12, s34
    s.addi       s34, s39, #384
    s.movz       s40, #7
    v.st.w       [s36, #0], v13
    a.vread      v13, a12, s37
    s.addi       s36, s39, #448
    s.movz       s37, #8
    v.st.w       [s35, #0], v13
    a.vread      v13, a12, s38
    s.addi       s35, s39, #512
    s.movz       s38, #9
    v.st.w       [s34, #0], v13
    a.vread      v13, a12, s40
    s.addi       s34, s39, #576
    s.movz       s40, #10
    v.st.w       [s36, #0], v13
    a.vread      v13, a12, s37
    s.addi       s36, s39, #640
    s.movz       s37, #11
    v.st.w       [s35, #0], v13
    a.vread      v13, a12, s38
    s.addi       s35, s39, #704
    s.movz       s38, #12
    v.st.w       [s34, #0], v13
    a.vread      v13, a12, s40
    s.addi       s34, s39, #768
    s.movz       s40, #13
    v.st.w       [s36, #0], v13
    a.vread      v13, a12, s37
    s.addi       s36, s39, #832
    s.movz       s37, #14
    v.st.w       [s35, #0], v13
    a.vread      v13, a12, s38
    s.addi       s35, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s34, #0], v13
    a.vread      v13, a12, s40
    s.movz       s34, #0
    s.addi       s39, s27, #16384
    v.st.w       [s36, #0], v13
    a.vread      v13, a12, s37
    s.movz       s36, #1
    s.addi       s37, s39, #64
    v.st.w       [s35, #0], v13
    a.vread      v13, a12, s38
    s.movz       s35, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v13
    fence.acq_rel.device
    a.vread      v13, a13, s34
    s.movz       s34, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v13
    a.vread      v13, a13, s36
    s.movz       s36, #4
    v.st.w       [s37, #0], v13
    a.vread      v13, a13, s35
    s.addi       s35, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v13
    a.vread      v13, a13, s34
    s.addi       s34, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v13
    a.vread      v13, a13, s36
    s.addi       s36, s39, #384
    s.movz       s40, #7
    v.st.w       [s35, #0], v13
    a.vread      v13, a13, s37
    s.addi       s35, s39, #448
    s.movz       s37, #8
    v.st.w       [s34, #0], v13
    a.vread      v13, a13, s38
    s.addi       s34, s39, #512
    s.movz       s38, #9
    v.st.w       [s36, #0], v13
    a.vread      v13, a13, s40
    s.addi       s36, s39, #576
    s.movz       s40, #10
    v.st.w       [s35, #0], v13
    a.vread      v13, a13, s37
    s.addi       s35, s39, #640
    s.movz       s37, #11
    v.st.w       [s34, #0], v13
    a.vread      v13, a13, s38
    s.addi       s34, s39, #704
    s.movz       s38, #12
    v.st.w       [s36, #0], v13
    a.vread      v13, a13, s40
    s.addi       s36, s39, #768
    s.movz       s40, #13
    v.st.w       [s35, #0], v13
    a.vread      v13, a13, s37
    s.addi       s35, s39, #832
    s.movz       s37, #14
    v.st.w       [s34, #0], v13
    a.vread      v13, a13, s38
    s.addi       s34, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s36, #0], v13
    a.vread      v13, a13, s40
    s.movz       s36, #0
    s.addi       s39, s27, #17408
    v.st.w       [s35, #0], v13
    a.vread      v13, a13, s37
    s.movz       s35, #1
    s.addi       s37, s39, #64
    v.st.w       [s34, #0], v13
    a.vread      v13, a13, s38
    s.movz       s34, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v13
    fence.acq_rel.device
    a.vread      v13, a14, s36
    s.movz       s36, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v13
    a.vread      v13, a14, s35
    s.movz       s35, #4
    v.st.w       [s37, #0], v13
    a.vread      v13, a14, s34
    s.addi       s34, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v13
    a.vread      v13, a14, s36
    s.addi       s36, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v13
    a.vread      v13, a14, s35
    s.addi       s35, s39, #384
    s.movz       s40, #7
    v.st.w       [s34, #0], v13
    a.vread      v13, a14, s37
    s.addi       s34, s39, #448
    s.movz       s37, #8
    v.st.w       [s36, #0], v13
    a.vread      v13, a14, s38
    s.addi       s36, s39, #512
    s.movz       s38, #9
    v.st.w       [s35, #0], v13
    a.vread      v13, a14, s40
    s.addi       s35, s39, #576
    s.movz       s40, #10
    v.st.w       [s34, #0], v13
    a.vread      v13, a14, s37
    s.addi       s34, s39, #640
    s.movz       s37, #11
    v.st.w       [s36, #0], v13
    a.vread      v13, a14, s38
    s.addi       s36, s39, #704
    s.movz       s38, #12
    v.st.w       [s35, #0], v13
    a.vread      v13, a14, s40
    s.addi       s35, s39, #768
    s.movz       s40, #13
    v.st.w       [s34, #0], v13
    a.vread      v13, a14, s37
    s.addi       s34, s39, #832
    s.movz       s37, #14
    v.st.w       [s36, #0], v13
    a.vread      v13, a14, s38
    s.addi       s36, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s35, #0], v13
    a.vread      v13, a14, s40
    s.movz       s35, #0
    s.addi       s39, s27, #18432
    v.st.w       [s34, #0], v13
    a.vread      v13, a14, s37
    s.movz       s34, #1
    s.addi       s37, s39, #64
    v.st.w       [s36, #0], v13
    a.vread      v13, a14, s38
    s.movz       s36, #2
    s.addi       s38, s39, #128
    v.st.w       [s41, #0], v13
    fence.acq_rel.device
    a.vread      v13, a15, s35
    s.movz       s35, #3
    s.addi       s40, s39, #192
    v.st.w       [s39, #0], v13
    a.vread      v13, a15, s34
    s.movz       s34, #4
    v.st.w       [s37, #0], v13
    a.vread      v13, a15, s36
    s.addi       s36, s39, #256
    s.movz       s37, #5
    v.st.w       [s38, #0], v13
    a.vread      v13, a15, s35
    s.addi       s35, s39, #320
    s.movz       s38, #6
    v.st.w       [s40, #0], v13
    a.vread      v13, a15, s34
    s.addi       s34, s39, #384
    s.movz       s40, #7
    v.st.w       [s36, #0], v13
    a.vread      v13, a15, s37
    s.addi       s36, s39, #448
    s.movz       s37, #8
    v.st.w       [s35, #0], v13
    a.vread      v13, a15, s38
    s.addi       s35, s39, #512
    s.movz       s38, #9
    v.st.w       [s34, #0], v13
    a.vread      v13, a15, s40
    s.addi       s34, s39, #576
    s.movz       s40, #10
    v.st.w       [s36, #0], v13
    a.vread      v13, a15, s37
    s.addi       s36, s39, #640
    s.movz       s37, #11
    v.st.w       [s35, #0], v13
    a.vread      v13, a15, s38
    s.addi       s35, s39, #704
    s.movz       s38, #12
    v.st.w       [s34, #0], v13
    a.vread      v13, a15, s40
    s.addi       s34, s39, #768
    s.movz       s40, #13
    v.st.w       [s36, #0], v13
    a.vread      v13, a15, s37
    s.addi       s36, s39, #832
    s.movz       s37, #14
    v.st.w       [s35, #0], v13
    a.vread      v13, a15, s38
    s.addi       s35, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.st.w       [s34, #0], v13
    a.vread      v13, a15, s40
    s.movz       s34, #0
    s.addi       s39, s27, #11264
    v.st.w       [s36, #0], v13
    a.vread      v13, a15, s37
    v.extract    s36, v22, #0
    v.splat      v14, s36
    s.addi       s36, s27, #19456
    s.movz       s37, #1
    v.st.w       [s35, #0], v13
    a.vread      v13, a15, s38
    s.addi       s35, s27, #11328
    v.extract    s38, v22, #1
    v.splat      v17, s38
    s.addi       s38, s36, #64
    v.st.w       [s41, #0], v13
    fence.acq_rel.device
    a.vread      v13, a0, s34
    s.movz       s34, #2
    s.addi       s40, s27, #11392
    v.ld.w       v19, [s39, #0]
    v.extract    s39, v22, #2
    v.splat      v20, s39
    s.addi       s39, s36, #128
    vf.mul       v23, v19, v14
    vf.mul       v14, v23, v21
    vf.add       v19, v13, v14
    v.st.w       [s36, #0], v19
    a.vread      v13, a0, s37
    s.movz       s37, #3
    v.ld.w       v14, [s35, #0]
    s.addi       s35, s27, #11456
    vf.mul       v19, v14, v17
    vf.mul       v14, v19, v21
    vf.add       v17, v13, v14
    v.st.w       [s38, #0], v17
    a.vread      v13, a0, s34
    v.extract    s34, v22, #3
    v.splat      v14, s34
    s.addi       s34, s36, #192
    s.movz       s38, #4
    v.ld.w       v17, [s40, #0]
    s.addi       s40, s27, #11520
    vf.mul       v19, v17, v20
    vf.mul       v17, v19, v21
    vf.add       v19, v13, v17
    v.st.w       [s39, #0], v19
    a.vread      v13, a0, s37
    v.extract    s37, v22, #4
    v.splat      v17, s37
    s.addi       s37, s36, #256
    s.movz       s39, #5
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s27, #11584
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v21
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a0, s38
    v.extract    s34, v22, #5
    v.splat      v14, s34
    s.addi       s34, s36, #320
    s.movz       s38, #6
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #11648
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v21
    vf.add       v19, v13, v17
    v.st.w       [s37, #0], v19
    a.vread      v13, a0, s39
    v.extract    s37, v22, #6
    v.splat      v17, s37
    s.addi       s37, s36, #384
    s.movz       s39, #7
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s27, #11712
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v21
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a0, s38
    v.extract    s34, v22, #7
    v.splat      v14, s34
    s.addi       s34, s36, #448
    s.movz       s38, #8
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #11776
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v21
    vf.add       v19, v13, v17
    v.st.w       [s37, #0], v19
    a.vread      v13, a0, s39
    v.extract    s37, v22, #8
    v.splat      v17, s37
    s.addi       s37, s36, #512
    s.movz       s39, #9
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s27, #11840
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v21
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a0, s38
    v.extract    s34, v22, #9
    v.splat      v14, s34
    s.addi       s34, s36, #576
    s.movz       s38, #10
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #11904
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v21
    vf.add       v19, v13, v17
    v.st.w       [s37, #0], v19
    a.vread      v13, a0, s39
    v.extract    s37, v22, #10
    v.splat      v17, s37
    s.addi       s37, s36, #640
    s.movz       s39, #11
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s27, #11968
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v21
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a0, s38
    v.extract    s34, v22, #11
    v.splat      v14, s34
    s.addi       s34, s36, #704
    s.movz       s38, #12
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #12032
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v21
    vf.add       v19, v13, v17
    v.st.w       [s37, #0], v19
    a.vread      v13, a0, s39
    v.extract    s37, v22, #12
    v.splat      v17, s37
    s.addi       s37, s36, #768
    s.movz       s39, #13
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s27, #12096
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v21
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a0, s38
    v.extract    s34, v22, #13
    v.splat      v14, s34
    s.addi       s34, s36, #832
    s.movz       s38, #14
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #12160
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v21
    vf.add       v19, v13, v17
    v.st.w       [s37, #0], v19
    a.vread      v13, a0, s39
    v.extract    s37, v22, #14
    v.splat      v17, s37
    s.addi       s37, s36, #896
    s.movz       s39, #15
    s.addi       s41, s36, #960
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s27, #12224
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v21
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a0, s38
    v.extract    s34, v22, #15
    v.splat      v14, s34
    s.movz       s34, #0
    s.addi       s36, s27, #12288
    v.ld.w       v19, [s40, #0]
    v.extract    s38, v22, #0
    v.splat      v20, s38
    s.addi       s38, s27, #20480
    vf.mul       v23, v19, v17
    vf.mul       v17, v23, v21
    vf.add       v19, v13, v17
    v.st.w       [s37, #0], v19
    a.vread      v13, a0, s39
    s.movz       s37, #1
    s.addi       s39, s27, #12352
    v.ld.w       v17, [s35, #0]
    v.extract    s35, v22, #1
    v.splat      v19, s35
    s.addi       s35, s38, #64
    vf.mul       v23, v17, v14
    vf.mul       v14, v23, v21
    vf.add       v17, v13, v14
    v.st.w       [s41, #0], v17
    fence.acq_rel.device
    a.vread      v13, a1, s34
    s.movz       s34, #2
    s.addi       s40, s27, #12416
    v.ld.w       v14, [s36, #0]
    v.extract    s36, v22, #2
    v.splat      v17, s36
    s.addi       s36, s38, #128
    vf.mul       v21, v14, v20
    vf.mul       v14, v21, v31
    vf.add       v20, v13, v14
    v.st.w       [s38, #0], v20
    a.vread      v13, a1, s37
    s.movz       s37, #3
    v.ld.w       v14, [s39, #0]
    s.addi       s39, s27, #12480
    vf.mul       v20, v14, v19
    vf.mul       v14, v20, v31
    vf.add       v19, v13, v14
    v.st.w       [s35, #0], v19
    a.vread      v13, a1, s34
    v.extract    s34, v22, #3
    v.splat      v14, s34
    s.addi       s34, s38, #192
    s.movz       s35, #4
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #12544
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v31
    vf.add       v19, v13, v17
    v.st.w       [s36, #0], v19
    a.vread      v13, a1, s37
    v.extract    s36, v22, #4
    v.splat      v17, s36
    s.addi       s36, s38, #256
    s.movz       s37, #5
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s27, #12608
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v31
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a1, s35
    v.extract    s34, v22, #5
    v.splat      v14, s34
    s.addi       s34, s38, #320
    s.movz       s35, #6
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #12672
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v31
    vf.add       v19, v13, v17
    v.st.w       [s36, #0], v19
    a.vread      v13, a1, s37
    v.extract    s36, v22, #6
    v.splat      v17, s36
    s.addi       s36, s38, #384
    s.movz       s37, #7
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s27, #12736
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v31
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a1, s35
    v.extract    s34, v22, #7
    v.splat      v14, s34
    s.addi       s34, s38, #448
    s.movz       s35, #8
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #12800
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v31
    vf.add       v19, v13, v17
    v.st.w       [s36, #0], v19
    a.vread      v13, a1, s37
    v.extract    s36, v22, #8
    v.splat      v17, s36
    s.addi       s36, s38, #512
    s.movz       s37, #9
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s27, #12864
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v31
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a1, s35
    v.extract    s34, v22, #9
    v.splat      v14, s34
    s.addi       s34, s38, #576
    s.movz       s35, #10
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #12928
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v31
    vf.add       v19, v13, v17
    v.st.w       [s36, #0], v19
    a.vread      v13, a1, s37
    v.extract    s36, v22, #10
    v.splat      v17, s36
    s.addi       s36, s38, #640
    s.movz       s37, #11
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s27, #12992
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v31
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a1, s35
    v.extract    s34, v22, #11
    v.splat      v14, s34
    s.addi       s34, s38, #704
    s.movz       s35, #12
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #13056
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v31
    vf.add       v19, v13, v17
    v.st.w       [s36, #0], v19
    a.vread      v13, a1, s37
    v.extract    s36, v22, #12
    v.splat      v17, s36
    s.addi       s36, s38, #768
    s.movz       s37, #13
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s27, #13120
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v31
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a1, s35
    v.extract    s34, v22, #13
    v.splat      v14, s34
    s.addi       s34, s38, #832
    s.movz       s35, #14
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #13184
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v31
    vf.add       v19, v13, v17
    v.st.w       [s36, #0], v19
    a.vread      v13, a1, s37
    v.extract    s36, v22, #14
    v.splat      v17, s36
    s.addi       s36, s38, #896
    s.movz       s37, #15
    s.addi       s41, s38, #960
    v.ld.w       v19, [s39, #0]
    s.addi       s38, s27, #13248
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v31
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a1, s35
    v.extract    s34, v22, #15
    v.splat      v14, s34
    s.movz       s34, #0
    s.addi       s35, s27, #13312
    v.ld.w       v19, [s40, #0]
    v.extract    s39, v22, #0
    v.splat      v20, s39
    s.addi       s39, s27, #21504
    vf.mul       v21, v19, v17
    vf.mul       v17, v21, v31
    vf.add       v19, v13, v17
    v.st.w       [s36, #0], v19
    a.vread      v13, a1, s37
    s.movz       s36, #1
    s.addi       s37, s27, #13376
    v.ld.w       v17, [s38, #0]
    v.extract    s38, v22, #1
    v.splat      v19, s38
    s.addi       s38, s39, #64
    vf.mul       v21, v17, v14
    vf.mul       v14, v21, v31
    vf.add       v17, v13, v14
    v.st.w       [s41, #0], v17
    fence.acq_rel.device
    a.vread      v13, a2, s34
    s.movz       s34, #2
    s.addi       s40, s27, #13440
    v.ld.w       v14, [s35, #0]
    v.extract    s35, v22, #2
    v.splat      v17, s35
    s.addi       s35, s39, #128
    vf.mul       v21, v14, v20
    vf.mul       v14, v21, v26
    vf.add       v20, v13, v14
    v.st.w       [s39, #0], v20
    a.vread      v13, a2, s36
    s.movz       s36, #3
    v.ld.w       v14, [s37, #0]
    s.addi       s37, s27, #13504
    vf.mul       v20, v14, v19
    vf.mul       v14, v20, v26
    vf.add       v19, v13, v14
    v.st.w       [s38, #0], v19
    a.vread      v13, a2, s34
    v.extract    s34, v22, #3
    v.splat      v14, s34
    s.addi       s34, s39, #192
    s.movz       s38, #4
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #13568
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v26
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a2, s36
    v.extract    s35, v22, #4
    v.splat      v17, s35
    s.addi       s35, s39, #256
    s.movz       s36, #5
    v.ld.w       v19, [s37, #0]
    s.addi       s37, s27, #13632
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v26
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a2, s38
    v.extract    s34, v22, #5
    v.splat      v14, s34
    s.addi       s34, s39, #320
    s.movz       s38, #6
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #13696
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v26
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a2, s36
    v.extract    s35, v22, #6
    v.splat      v17, s35
    s.addi       s35, s39, #384
    s.movz       s36, #7
    v.ld.w       v19, [s37, #0]
    s.addi       s37, s27, #13760
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v26
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a2, s38
    v.extract    s34, v22, #7
    v.splat      v14, s34
    s.addi       s34, s39, #448
    s.movz       s38, #8
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #13824
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v26
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a2, s36
    v.extract    s35, v22, #8
    v.splat      v17, s35
    s.addi       s35, s39, #512
    s.movz       s36, #9
    v.ld.w       v19, [s37, #0]
    s.addi       s37, s27, #13888
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v26
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a2, s38
    v.extract    s34, v22, #9
    v.splat      v14, s34
    s.addi       s34, s39, #576
    s.movz       s38, #10
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #13952
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v26
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a2, s36
    v.extract    s35, v22, #10
    v.splat      v17, s35
    s.addi       s35, s39, #640
    s.movz       s36, #11
    v.ld.w       v19, [s37, #0]
    s.addi       s37, s27, #14016
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v26
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a2, s38
    v.extract    s34, v22, #11
    v.splat      v14, s34
    s.addi       s34, s39, #704
    s.movz       s38, #12
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #14080
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v26
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a2, s36
    v.extract    s35, v22, #12
    v.splat      v17, s35
    s.addi       s35, s39, #768
    s.movz       s36, #13
    v.ld.w       v19, [s37, #0]
    s.addi       s37, s27, #14144
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v26
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a2, s38
    v.extract    s34, v22, #13
    v.splat      v14, s34
    s.addi       s34, s39, #832
    s.movz       s38, #14
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #14208
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v26
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a2, s36
    v.extract    s35, v22, #14
    v.splat      v17, s35
    s.addi       s35, s39, #896
    s.movz       s36, #15
    s.addi       s41, s39, #960
    v.ld.w       v19, [s37, #0]
    s.addi       s37, s27, #14272
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v26
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a2, s38
    v.extract    s34, v22, #15
    v.splat      v14, s34
    s.movz       s34, #0
    s.addi       s38, s27, #14336
    v.ld.w       v19, [s40, #0]
    v.extract    s39, v22, #0
    v.splat      v20, s39
    s.addi       s39, s27, #22528
    vf.mul       v21, v19, v17
    vf.mul       v17, v21, v26
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a2, s36
    s.movz       s35, #1
    s.addi       s36, s27, #14400
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v22, #1
    v.splat      v19, s37
    s.addi       s37, s39, #64
    vf.mul       v21, v17, v14
    vf.mul       v14, v21, v26
    vf.add       v17, v13, v14
    v.st.w       [s41, #0], v17
    fence.acq_rel.device
    a.vread      v13, a3, s34
    s.movz       s34, #2
    s.addi       s40, s27, #14464
    v.ld.w       v14, [s38, #0]
    v.extract    s38, v22, #2
    v.splat      v17, s38
    s.addi       s38, s39, #128
    vf.mul       v21, v14, v20
    vf.mul       v14, v21, v28
    vf.add       v20, v13, v14
    v.st.w       [s39, #0], v20
    a.vread      v13, a3, s35
    s.movz       s35, #3
    v.ld.w       v14, [s36, #0]
    s.addi       s36, s27, #14528
    vf.mul       v20, v14, v19
    vf.mul       v14, v20, v28
    vf.add       v19, v13, v14
    v.st.w       [s37, #0], v19
    a.vread      v13, a3, s34
    v.extract    s34, v22, #3
    v.splat      v14, s34
    s.addi       s34, s39, #192
    s.movz       s37, #4
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #14592
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v28
    vf.add       v19, v13, v17
    v.st.w       [s38, #0], v19
    a.vread      v13, a3, s35
    v.extract    s35, v22, #4
    v.splat      v17, s35
    s.addi       s35, s39, #256
    s.movz       s38, #5
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s27, #14656
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v28
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a3, s37
    v.extract    s34, v22, #5
    v.splat      v14, s34
    s.addi       s34, s39, #320
    s.movz       s37, #6
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #14720
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v28
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a3, s38
    v.extract    s35, v22, #6
    v.splat      v17, s35
    s.addi       s35, s39, #384
    s.movz       s38, #7
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s27, #14784
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v28
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a3, s37
    v.extract    s34, v22, #7
    v.splat      v14, s34
    s.addi       s34, s39, #448
    s.movz       s37, #8
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #14848
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v28
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a3, s38
    v.extract    s35, v22, #8
    v.splat      v17, s35
    s.addi       s35, s39, #512
    s.movz       s38, #9
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s27, #14912
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v28
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a3, s37
    v.extract    s34, v22, #9
    v.splat      v14, s34
    s.addi       s34, s39, #576
    s.movz       s37, #10
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #14976
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v28
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a3, s38
    v.extract    s35, v22, #10
    v.splat      v17, s35
    s.addi       s35, s39, #640
    s.movz       s38, #11
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s27, #15040
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v28
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a3, s37
    v.extract    s34, v22, #11
    v.splat      v14, s34
    s.addi       s34, s39, #704
    s.movz       s37, #12
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #15104
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v28
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a3, s38
    v.extract    s35, v22, #12
    v.splat      v17, s35
    s.addi       s35, s39, #768
    s.movz       s38, #13
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s27, #15168
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v28
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a3, s37
    v.extract    s34, v22, #13
    v.splat      v14, s34
    s.addi       s34, s39, #832
    s.movz       s37, #14
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #15232
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v28
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a3, s38
    v.extract    s35, v22, #14
    v.splat      v17, s35
    s.addi       s35, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s27, #15296
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v28
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a3, s37
    v.extract    s34, v22, #15
    v.splat      v14, s34
    s.movz       s34, #0
    s.addi       s37, s27, #15360
    v.ld.w       v19, [s40, #0]
    v.extract    s39, v22, #0
    v.splat      v20, s39
    s.addi       s39, s27, #23552
    vf.mul       v21, v19, v17
    vf.mul       v17, v21, v28
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a3, s38
    s.movz       s35, #1
    s.addi       s38, s27, #15424
    v.ld.w       v17, [s36, #0]
    v.extract    s36, v22, #1
    v.splat      v19, s36
    s.addi       s36, s39, #64
    vf.mul       v21, v17, v14
    vf.mul       v14, v21, v28
    vf.add       v17, v13, v14
    v.st.w       [s41, #0], v17
    fence.acq_rel.device
    a.vread      v13, a4, s34
    s.movz       s34, #2
    s.addi       s40, s27, #15488
    v.ld.w       v14, [s37, #0]
    v.extract    s37, v22, #2
    v.splat      v17, s37
    s.addi       s37, s39, #128
    vf.mul       v21, v14, v20
    vf.mul       v14, v21, v30
    vf.add       v20, v13, v14
    v.st.w       [s39, #0], v20
    a.vread      v13, a4, s35
    s.movz       s35, #3
    v.ld.w       v14, [s38, #0]
    s.addi       s38, s27, #15552
    vf.mul       v20, v14, v19
    vf.mul       v14, v20, v30
    vf.add       v19, v13, v14
    v.st.w       [s36, #0], v19
    a.vread      v13, a4, s34
    v.extract    s34, v22, #3
    v.splat      v14, s34
    s.addi       s34, s39, #192
    s.movz       s36, #4
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #15616
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v30
    vf.add       v19, v13, v17
    v.st.w       [s37, #0], v19
    a.vread      v13, a4, s35
    v.extract    s35, v22, #4
    v.splat      v17, s35
    s.addi       s35, s39, #256
    s.movz       s37, #5
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s27, #15680
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v30
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a4, s36
    v.extract    s34, v22, #5
    v.splat      v14, s34
    s.addi       s34, s39, #320
    s.movz       s36, #6
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #15744
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v30
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a4, s37
    v.extract    s35, v22, #6
    v.splat      v17, s35
    s.addi       s35, s39, #384
    s.movz       s37, #7
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s27, #15808
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v30
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a4, s36
    v.extract    s34, v22, #7
    v.splat      v14, s34
    s.addi       s34, s39, #448
    s.movz       s36, #8
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #15872
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v30
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a4, s37
    v.extract    s35, v22, #8
    v.splat      v17, s35
    s.addi       s35, s39, #512
    s.movz       s37, #9
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s27, #15936
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v30
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a4, s36
    v.extract    s34, v22, #9
    v.splat      v14, s34
    s.addi       s34, s39, #576
    s.movz       s36, #10
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #16000
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v30
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a4, s37
    v.extract    s35, v22, #10
    v.splat      v17, s35
    s.addi       s35, s39, #640
    s.movz       s37, #11
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s27, #16064
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v30
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a4, s36
    v.extract    s34, v22, #11
    v.splat      v14, s34
    s.addi       s34, s39, #704
    s.movz       s36, #12
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #16128
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v30
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a4, s37
    v.extract    s35, v22, #12
    v.splat      v17, s35
    s.addi       s35, s39, #768
    s.movz       s37, #13
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s27, #16192
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v30
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a4, s36
    v.extract    s34, v22, #13
    v.splat      v14, s34
    s.addi       s34, s39, #832
    s.movz       s36, #14
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #16256
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v30
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a4, s37
    v.extract    s35, v22, #14
    v.splat      v17, s35
    s.addi       s35, s39, #896
    s.movz       s37, #15
    s.addi       s41, s39, #960
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s27, #16320
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v30
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a4, s36
    v.extract    s34, v22, #15
    v.splat      v14, s34
    s.movz       s34, #0
    s.addi       s36, s27, #16384
    v.ld.w       v19, [s40, #0]
    v.extract    s39, v22, #0
    v.splat      v20, s39
    s.addi       s39, s27, #24576
    vf.mul       v21, v19, v17
    vf.mul       v17, v21, v30
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a4, s37
    s.movz       s35, #1
    s.addi       s37, s27, #16448
    v.ld.w       v17, [s38, #0]
    v.extract    s38, v22, #1
    v.splat      v19, s38
    s.addi       s38, s39, #64
    vf.mul       v21, v17, v14
    vf.mul       v14, v21, v30
    vf.add       v17, v13, v14
    v.st.w       [s41, #0], v17
    fence.acq_rel.device
    a.vread      v13, a5, s34
    s.movz       s34, #2
    s.addi       s40, s27, #16512
    v.ld.w       v14, [s36, #0]
    v.extract    s36, v22, #2
    v.splat      v17, s36
    s.addi       s36, s39, #128
    vf.mul       v21, v14, v20
    vf.mul       v14, v21, v35
    vf.add       v20, v13, v14
    v.st.w       [s39, #0], v20
    a.vread      v13, a5, s35
    s.movz       s35, #3
    v.ld.w       v14, [s37, #0]
    s.addi       s37, s27, #16576
    vf.mul       v20, v14, v19
    vf.mul       v14, v20, v35
    vf.add       v19, v13, v14
    v.st.w       [s38, #0], v19
    a.vread      v13, a5, s34
    v.extract    s34, v22, #3
    v.splat      v14, s34
    s.addi       s34, s39, #192
    s.movz       s38, #4
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #16640
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v35
    vf.add       v19, v13, v17
    v.st.w       [s36, #0], v19
    a.vread      v13, a5, s35
    v.extract    s35, v22, #4
    v.splat      v17, s35
    s.addi       s35, s39, #256
    s.movz       s36, #5
    v.ld.w       v19, [s37, #0]
    s.addi       s37, s27, #16704
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v35
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a5, s38
    v.extract    s34, v22, #5
    v.splat      v14, s34
    s.addi       s34, s39, #320
    s.movz       s38, #6
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #16768
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v35
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a5, s36
    v.extract    s35, v22, #6
    v.splat      v17, s35
    s.addi       s35, s39, #384
    s.movz       s36, #7
    v.ld.w       v19, [s37, #0]
    s.addi       s37, s27, #16832
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v35
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a5, s38
    v.extract    s34, v22, #7
    v.splat      v14, s34
    s.addi       s34, s39, #448
    s.movz       s38, #8
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #16896
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v35
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a5, s36
    v.extract    s35, v22, #8
    v.splat      v17, s35
    s.addi       s35, s39, #512
    s.movz       s36, #9
    v.ld.w       v19, [s37, #0]
    s.addi       s37, s27, #16960
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v35
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a5, s38
    v.extract    s34, v22, #9
    v.splat      v14, s34
    s.addi       s34, s39, #576
    s.movz       s38, #10
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #17024
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v35
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a5, s36
    v.extract    s35, v22, #10
    v.splat      v17, s35
    s.addi       s35, s39, #640
    s.movz       s36, #11
    v.ld.w       v19, [s37, #0]
    s.addi       s37, s27, #17088
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v35
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a5, s38
    v.extract    s34, v22, #11
    v.splat      v14, s34
    s.addi       s34, s39, #704
    s.movz       s38, #12
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #17152
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v35
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a5, s36
    v.extract    s35, v22, #12
    v.splat      v17, s35
    s.addi       s35, s39, #768
    s.movz       s36, #13
    v.ld.w       v19, [s37, #0]
    s.addi       s37, s27, #17216
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v35
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a5, s38
    v.extract    s34, v22, #13
    v.splat      v14, s34
    s.addi       s34, s39, #832
    s.movz       s38, #14
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #17280
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v35
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a5, s36
    v.extract    s35, v22, #14
    v.splat      v17, s35
    s.addi       s35, s39, #896
    s.movz       s36, #15
    s.addi       s41, s39, #960
    v.ld.w       v19, [s37, #0]
    s.addi       s37, s27, #17344
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v35
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a5, s38
    v.extract    s34, v22, #15
    v.splat      v14, s34
    s.movz       s34, #0
    s.addi       s38, s27, #17408
    v.ld.w       v19, [s40, #0]
    v.extract    s39, v22, #0
    v.splat      v20, s39
    s.addi       s39, s27, #25600
    vf.mul       v21, v19, v17
    vf.mul       v17, v21, v35
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a5, s36
    s.movz       s35, #1
    s.addi       s36, s27, #17472
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v22, #1
    v.splat      v19, s37
    s.addi       s37, s39, #64
    vf.mul       v21, v17, v14
    vf.mul       v14, v21, v35
    vf.add       v17, v13, v14
    v.st.w       [s41, #0], v17
    fence.acq_rel.device
    a.vread      v13, a6, s34
    s.movz       s34, #2
    s.addi       s40, s27, #17536
    v.ld.w       v14, [s38, #0]
    v.extract    s38, v22, #2
    v.splat      v17, s38
    s.addi       s38, s39, #128
    vf.mul       v21, v14, v20
    vf.mul       v14, v21, v36
    vf.add       v20, v13, v14
    v.st.w       [s39, #0], v20
    a.vread      v13, a6, s35
    s.movz       s35, #3
    v.ld.w       v14, [s36, #0]
    s.addi       s36, s27, #17600
    vf.mul       v20, v14, v19
    vf.mul       v14, v20, v36
    vf.add       v19, v13, v14
    v.st.w       [s37, #0], v19
    a.vread      v13, a6, s34
    v.extract    s34, v22, #3
    v.splat      v14, s34
    s.addi       s34, s39, #192
    s.movz       s37, #4
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #17664
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v36
    vf.add       v19, v13, v17
    v.st.w       [s38, #0], v19
    a.vread      v13, a6, s35
    v.extract    s35, v22, #4
    v.splat      v17, s35
    s.addi       s35, s39, #256
    s.movz       s38, #5
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s27, #17728
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v36
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a6, s37
    v.extract    s34, v22, #5
    v.splat      v14, s34
    s.addi       s34, s39, #320
    s.movz       s37, #6
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #17792
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v36
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a6, s38
    v.extract    s35, v22, #6
    v.splat      v17, s35
    s.addi       s35, s39, #384
    s.movz       s38, #7
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s27, #17856
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v36
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a6, s37
    v.extract    s34, v22, #7
    v.splat      v14, s34
    s.addi       s34, s39, #448
    s.movz       s37, #8
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #17920
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v36
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a6, s38
    v.extract    s35, v22, #8
    v.splat      v17, s35
    s.addi       s35, s39, #512
    s.movz       s38, #9
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s27, #17984
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v36
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a6, s37
    v.extract    s34, v22, #9
    v.splat      v14, s34
    s.addi       s34, s39, #576
    s.movz       s37, #10
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #18048
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v36
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a6, s38
    v.extract    s35, v22, #10
    v.splat      v17, s35
    s.addi       s35, s39, #640
    s.movz       s38, #11
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s27, #18112
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v36
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a6, s37
    v.extract    s34, v22, #11
    v.splat      v14, s34
    s.addi       s34, s39, #704
    s.movz       s37, #12
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #18176
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v36
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a6, s38
    v.extract    s35, v22, #12
    v.splat      v17, s35
    s.addi       s35, s39, #768
    s.movz       s38, #13
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s27, #18240
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v36
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a6, s37
    v.extract    s34, v22, #13
    v.splat      v14, s34
    s.addi       s34, s39, #832
    s.movz       s37, #14
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #18304
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v36
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a6, s38
    v.extract    s35, v22, #14
    v.splat      v17, s35
    s.addi       s35, s39, #896
    s.movz       s38, #15
    s.addi       s41, s39, #960
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s27, #18368
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v36
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a6, s37
    v.extract    s34, v22, #15
    v.splat      v14, s34
    s.movz       s34, #0
    s.addi       s37, s27, #18432
    v.ld.w       v19, [s40, #0]
    v.extract    s39, v22, #0
    v.splat      v20, s39
    s.addi       s39, s27, #26624
    vf.mul       v21, v19, v17
    vf.mul       v17, v21, v36
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a6, s38
    s.movz       s35, #1
    s.addi       s38, s27, #18496
    v.ld.w       v17, [s36, #0]
    v.extract    s36, v22, #1
    v.splat      v19, s36
    s.addi       s36, s39, #64
    vf.mul       v21, v17, v14
    vf.mul       v14, v21, v36
    vf.add       v17, v13, v14
    v.st.w       [s41, #0], v17
    fence.acq_rel.device
    a.vread      v13, a7, s34
    s.movz       s34, #2
    s.addi       s40, s27, #18560
    v.ld.w       v14, [s37, #0]
    v.extract    s37, v22, #2
    v.splat      v17, s37
    s.addi       s37, s39, #128
    vf.mul       v21, v14, v20
    vf.mul       v14, v21, v38
    vf.add       v20, v13, v14
    v.st.w       [s39, #0], v20
    a.vread      v13, a7, s35
    s.movz       s35, #3
    v.ld.w       v14, [s38, #0]
    s.addi       s38, s27, #18624
    vf.mul       v20, v14, v19
    vf.mul       v14, v20, v38
    vf.add       v19, v13, v14
    v.st.w       [s36, #0], v19
    a.vread      v13, a7, s34
    v.extract    s34, v22, #3
    v.splat      v14, s34
    s.addi       s34, s39, #192
    s.movz       s36, #4
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #18688
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v38
    vf.add       v19, v13, v17
    v.st.w       [s37, #0], v19
    a.vread      v13, a7, s35
    v.extract    s35, v22, #4
    v.splat      v17, s35
    s.addi       s35, s39, #256
    s.movz       s37, #5
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s27, #18752
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v38
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a7, s36
    v.extract    s34, v22, #5
    v.splat      v14, s34
    s.addi       s34, s39, #320
    s.movz       s36, #6
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #18816
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v38
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a7, s37
    v.extract    s35, v22, #6
    v.splat      v17, s35
    s.addi       s35, s39, #384
    s.movz       s37, #7
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s27, #18880
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v38
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a7, s36
    v.extract    s34, v22, #7
    v.splat      v14, s34
    s.addi       s34, s39, #448
    s.movz       s36, #8
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #18944
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v38
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a7, s37
    v.extract    s35, v22, #8
    v.splat      v17, s35
    s.addi       s35, s39, #512
    s.movz       s37, #9
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s27, #19008
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v38
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a7, s36
    v.extract    s34, v22, #9
    v.splat      v14, s34
    s.addi       s34, s39, #576
    s.movz       s36, #10
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #19072
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v38
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a7, s37
    v.extract    s35, v22, #10
    v.splat      v17, s35
    s.addi       s35, s39, #640
    s.movz       s37, #11
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s27, #19136
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v38
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a7, s36
    v.extract    s34, v22, #11
    v.splat      v14, s34
    s.addi       s34, s39, #704
    s.movz       s36, #12
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #19200
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v38
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a7, s37
    v.extract    s35, v22, #12
    v.splat      v17, s35
    s.addi       s35, s39, #768
    s.movz       s37, #13
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s27, #19264
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v38
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a7, s36
    v.extract    s34, v22, #13
    v.splat      v14, s34
    s.addi       s34, s39, #832
    s.movz       s36, #14
    s.addi       s41, s24, #4                    // &ptr_carry_18[1] (a constant offset, x4)
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s27, #19328
    s.addi       s41, s24, #4                    // &ptr_carry_19[1] (a constant offset, x4)
    s.addi       s41, s24, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    s.addi       s41, s24, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    vf.mul       v20, v19, v17
    s.addi       s41, s24, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    vf.mul       v17, v20, v38
    s.addi       s41, s24, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    vf.add       v19, v13, v17
    s.addi       s41, s24, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    v.st.w       [s35, #0], v19
    a.vread      v13, a7, s37
    v.extract    s35, v22, #14
    v.splat      v17, s35
    s.addi       s35, s39, #896
    s.movz       s37, #15
    s.addi       s41, s39, #960
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s27, #19392
    vf.mul       v20, v19, v14
    vf.mul       v14, v20, v38
    vf.add       v19, v13, v14
    v.st.w       [s34, #0], v19
    a.vread      v13, a7, s36
    v.extract    s34, v22, #15
    v.splat      v14, s34
    s.addi       s34, s22, #128
    s.addi       s36, s23, #128
    s.addi       s39, s34, #0
    s.addi       s34, s36, #0
    v.ld.w       v19, [s40, #0]
    s.addi       s36, s24, #4                    // &ptr_carry_17[1] (a constant offset, x4)
    s.addi       s40, s36, #0
    vf.mul       v20, v19, v17
    vf.mul       v17, v20, v38
    vf.add       v19, v13, v17
    v.st.w       [s35, #0], v19
    a.vread      v13, a7, s37
    s.addi       s35, s27, #19456
    s.movz       s36, #0
    v.ld.w       v17, [s38, #0]
    s.addi       s37, s27, #19520
    vf.mul       v19, v17, v14
    vf.mul       v14, v19, v38
    vf.add       v17, v13, v14
    v.st.w       [s41, #0], v17
    fence.acq_rel.device
    s.mov        s22, s39
    s.mov        s23, s34
    s.mov        s24, s40
    s.movz       s34, #1
    s.addi       s38, s27, #19584
    s.movz       s39, #2
    s.addi       s40, s27, #19648
    s.movz       s41, #3
    v.ld.w       v13, [s35, #0]
    s.addi       s35, s27, #19712
    s.movz       s42, #4
    s.addi       s43, s27, #19776
    a.vwrite     a0, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #5
    s.addi       s37, s27, #19840
    a.vwrite     a0, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #6
    s.addi       s38, s27, #19904
    a.vwrite     a0, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #7
    s.addi       s40, s27, #19968
    a.vwrite     a0, s41, v13
    v.ld.w       v13, [s35, #0]
    s.movz       s35, #8
    s.addi       s41, s27, #20032
    a.vwrite     a0, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #9
    s.addi       s43, s27, #20096
    a.vwrite     a0, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #10
    s.addi       s37, s27, #20160
    a.vwrite     a0, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #11
    s.addi       s38, s27, #20224
    a.vwrite     a0, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #12
    s.addi       s40, s27, #20288
    a.vwrite     a0, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #13
    s.addi       s41, s27, #20352
    a.vwrite     a0, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #14
    s.addi       s43, s27, #20416
    a.vwrite     a0, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #15
    s.addi       s37, s27, #20480
    a.vwrite     a0, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #0
    s.addi       s38, s27, #20544
    a.vwrite     a0, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #1
    s.addi       s40, s27, #20608
    a.vwrite     a0, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #2
    s.addi       s41, s27, #20672
    a.vwrite     a0, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #3
    s.addi       s43, s27, #20736
    a.vwrite     a0, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #4
    s.addi       s37, s27, #20800
    a.vwrite     a1, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #5
    s.addi       s38, s27, #20864
    a.vwrite     a1, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #6
    s.addi       s40, s27, #20928
    a.vwrite     a1, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #7
    s.addi       s41, s27, #20992
    a.vwrite     a1, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #8
    s.addi       s43, s27, #21056
    a.vwrite     a1, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #9
    s.addi       s37, s27, #21120
    a.vwrite     a1, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #10
    s.addi       s38, s27, #21184
    a.vwrite     a1, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #11
    s.addi       s40, s27, #21248
    a.vwrite     a1, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #12
    s.addi       s41, s27, #21312
    a.vwrite     a1, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #13
    s.addi       s43, s27, #21376
    a.vwrite     a1, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #14
    s.addi       s37, s27, #21440
    a.vwrite     a1, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #15
    s.addi       s38, s27, #21504
    a.vwrite     a1, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #0
    s.addi       s40, s27, #21568
    a.vwrite     a1, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #1
    s.addi       s41, s27, #21632
    a.vwrite     a1, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #2
    s.addi       s43, s27, #21696
    a.vwrite     a1, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #3
    s.addi       s37, s27, #21760
    a.vwrite     a1, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #4
    s.addi       s38, s27, #21824
    a.vwrite     a2, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #5
    s.addi       s40, s27, #21888
    a.vwrite     a2, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #6
    s.addi       s41, s27, #21952
    a.vwrite     a2, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #7
    s.addi       s43, s27, #22016
    a.vwrite     a2, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #8
    s.addi       s37, s27, #22080
    a.vwrite     a2, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #9
    s.addi       s38, s27, #22144
    a.vwrite     a2, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #10
    s.addi       s40, s27, #22208
    a.vwrite     a2, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #11
    s.addi       s41, s27, #22272
    a.vwrite     a2, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #12
    s.addi       s43, s27, #22336
    a.vwrite     a2, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #13
    s.addi       s37, s27, #22400
    a.vwrite     a2, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #14
    s.addi       s38, s27, #22464
    a.vwrite     a2, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #15
    s.addi       s40, s27, #22528
    a.vwrite     a2, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #0
    s.addi       s41, s27, #22592
    a.vwrite     a2, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #1
    s.addi       s43, s27, #22656
    a.vwrite     a2, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #2
    s.addi       s37, s27, #22720
    a.vwrite     a2, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #3
    s.addi       s38, s27, #22784
    a.vwrite     a2, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #4
    s.addi       s40, s27, #22848
    a.vwrite     a3, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #5
    s.addi       s41, s27, #22912
    a.vwrite     a3, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #6
    s.addi       s43, s27, #22976
    a.vwrite     a3, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #7
    s.addi       s37, s27, #23040
    a.vwrite     a3, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #8
    s.addi       s38, s27, #23104
    a.vwrite     a3, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #9
    s.addi       s40, s27, #23168
    a.vwrite     a3, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #10
    s.addi       s41, s27, #23232
    a.vwrite     a3, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #11
    s.addi       s43, s27, #23296
    a.vwrite     a3, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #12
    s.addi       s37, s27, #23360
    a.vwrite     a3, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #13
    s.addi       s38, s27, #23424
    a.vwrite     a3, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #14
    s.addi       s40, s27, #23488
    a.vwrite     a3, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #15
    s.addi       s41, s27, #23552
    a.vwrite     a3, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #0
    s.addi       s43, s27, #23616
    a.vwrite     a3, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #1
    s.addi       s37, s27, #23680
    a.vwrite     a3, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #2
    s.addi       s38, s27, #23744
    a.vwrite     a3, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #3
    s.addi       s40, s27, #23808
    a.vwrite     a3, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #4
    s.addi       s41, s27, #23872
    a.vwrite     a4, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #5
    s.addi       s43, s27, #23936
    a.vwrite     a4, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #6
    s.addi       s37, s27, #24000
    a.vwrite     a4, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #7
    s.addi       s38, s27, #24064
    a.vwrite     a4, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #8
    s.addi       s40, s27, #24128
    a.vwrite     a4, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #9
    s.addi       s41, s27, #24192
    a.vwrite     a4, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #10
    s.addi       s43, s27, #24256
    a.vwrite     a4, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #11
    s.addi       s37, s27, #24320
    a.vwrite     a4, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #12
    s.addi       s38, s27, #24384
    a.vwrite     a4, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #13
    s.addi       s40, s27, #24448
    a.vwrite     a4, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #14
    s.addi       s41, s27, #24512
    a.vwrite     a4, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #15
    s.addi       s43, s27, #24576
    a.vwrite     a4, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #0
    s.addi       s37, s27, #24640
    a.vwrite     a4, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #1
    s.addi       s38, s27, #24704
    a.vwrite     a4, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #2
    s.addi       s40, s27, #24768
    a.vwrite     a4, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #3
    s.addi       s41, s27, #24832
    a.vwrite     a4, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #4
    s.addi       s43, s27, #24896
    a.vwrite     a5, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #5
    s.addi       s37, s27, #24960
    a.vwrite     a5, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #6
    s.addi       s38, s27, #25024
    a.vwrite     a5, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #7
    s.addi       s40, s27, #25088
    a.vwrite     a5, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #8
    s.addi       s41, s27, #25152
    a.vwrite     a5, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #9
    s.addi       s43, s27, #25216
    a.vwrite     a5, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #10
    s.addi       s37, s27, #25280
    a.vwrite     a5, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #11
    s.addi       s38, s27, #25344
    a.vwrite     a5, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #12
    s.addi       s40, s27, #25408
    a.vwrite     a5, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #13
    s.addi       s41, s27, #25472
    a.vwrite     a5, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #14
    s.addi       s43, s27, #25536
    a.vwrite     a5, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #15
    s.addi       s37, s27, #25600
    a.vwrite     a5, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #0
    s.addi       s38, s27, #25664
    a.vwrite     a5, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #1
    s.addi       s40, s27, #25728
    a.vwrite     a5, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #2
    s.addi       s41, s27, #25792
    a.vwrite     a5, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #3
    s.addi       s43, s27, #25856
    a.vwrite     a5, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #4
    s.addi       s37, s27, #25920
    a.vwrite     a6, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #5
    s.addi       s38, s27, #25984
    a.vwrite     a6, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #6
    s.addi       s40, s27, #26048
    a.vwrite     a6, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #7
    s.addi       s41, s27, #26112
    a.vwrite     a6, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #8
    s.addi       s43, s27, #26176
    a.vwrite     a6, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #9
    s.addi       s37, s27, #26240
    a.vwrite     a6, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #10
    s.addi       s38, s27, #26304
    a.vwrite     a6, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #11
    s.addi       s40, s27, #26368
    a.vwrite     a6, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #12
    s.addi       s41, s27, #26432
    a.vwrite     a6, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #13
    s.addi       s43, s27, #26496
    a.vwrite     a6, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #14
    s.addi       s37, s27, #26560
    a.vwrite     a6, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #15
    s.addi       s38, s27, #26624
    a.vwrite     a6, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #0
    s.addi       s40, s27, #26688
    a.vwrite     a6, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #1
    s.addi       s41, s27, #26752
    a.vwrite     a6, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #2
    s.addi       s43, s27, #26816
    a.vwrite     a6, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #3
    s.addi       s37, s27, #26880
    a.vwrite     a6, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #4
    s.addi       s38, s27, #26944
    a.vwrite     a7, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #5
    s.addi       s40, s27, #27008
    a.vwrite     a7, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #6
    s.addi       s41, s27, #27072
    a.vwrite     a7, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #7
    s.addi       s43, s27, #27136
    a.vwrite     a7, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #8
    s.addi       s37, s27, #27200
    a.vwrite     a7, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s34, #9
    s.addi       s38, s27, #27264
    a.vwrite     a7, s39, v13
    v.ld.w       v13, [s40, #0]
    s.movz       s39, #10
    s.addi       s40, s27, #27328
    a.vwrite     a7, s35, v13
    v.ld.w       v13, [s41, #0]
    s.movz       s35, #11
    s.addi       s41, s27, #27392
    a.vwrite     a7, s42, v13
    v.ld.w       v13, [s43, #0]
    s.movz       s42, #12
    s.addi       s43, s27, #27456
    a.vwrite     a7, s36, v13
    v.ld.w       v13, [s37, #0]
    s.movz       s36, #13
    s.addi       s37, s27, #27520
    s.addi       s44, s27, #27584
    a.vwrite     a7, s34, v13
    v.ld.w       v13, [s38, #0]
    s.movz       s27, #14
    s.movz       s34, #15
    a.vwrite     a7, s39, v13
    v.ld.w       v13, [s40, #0]
    s.add        s38, s20, s9
    s.movz       s39, #1
    a.vwrite     a7, s35, v13
    v.ld.w       v13, [s41, #0]
    a.vwrite     a7, s42, v13
    v.ld.w       v13, [s43, #0]
    a.vwrite     a7, s36, v13
    v.ld.w       v13, [s37, #0]
    a.vwrite     a7, s27, v13
    v.ld.w       v13, [s44, #0]
    a.vwrite     a7, s34, v13
    s.mov        s20, s38
    br.nz        s39, for_25
endfor_26:
    s.mul        s2, s19, s4
    s.movz       s4, #0
    s.muli       s6, s21, #2
    s.muli       s7, s1, #2
    s.movz       s8, #0
    s.mul        s10, s2, s21
    s.add        s11, s4, s1                     // the tile origin
    s.movz       s4, #0
    s.movz       s12, #0
    s.add        s13, s8, s2                     // the tile origin
    s.muli       s8, s10, #2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s11
    s.add        s10, s4, s3                     // the tile origin
    a.vread      v2, a0, s12
    v.splat      v3, s13
    v.splat      v4, s9
    v.add        v5, v0, v1
    v.splat      v1, s10
    s.muli       s4, s6, #1
    vf.cvt.f32.bf16 v6, v2
    s.add        s9, s8, s7
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s10, s5, s9
    p.and        p3, p1, p2
    s.movz       s9, #1
    s.addi       s11, s13, #1
    @p3 v.st.h       [s10, #0], v6
    a.vread      v1, a0, s9
    s.add        s9, s4, s8
    v.splat      v2, s11
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s9, s7
    v.cmp.lt     p1, v2, v4
    s.add        s9, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #2
    @p3 v.st.h       [s9, #0], v3
    s.addi       s9, s1, #16
    s.addi       s10, s1, #32
    s.addi       s11, s1, #48
    s.addi       s12, s1, #64
    s.addi       s14, s1, #80
    s.addi       s15, s1, #96
    s.addi       s16, s1, #112
    v.iota       v1                              // arange(0, VLEN)
    a.vread      v2, a0, s4
    v.splat      v3, s2
    vf.cvt.f32.bf16 v5, v2
    v.add        v2, v3, v1
    s.muli       s1, s6, #2
    s.addi       s2, s13, #2
    s.muli       s4, s6, #3
    v.splat      v1, s2
    s.movz       s2, #3
    s.add        s18, s1, s8
    v.cmp.lt     p1, v1, v4
    s.add        s1, s18, s7
    p.and        p3, p1, p2
    s.add        s18, s5, s1
    s.addi       s1, s13, #3
    @p3 v.st.h       [s18, #0], v5
    a.vread      v1, a0, s2
    s.add        s2, s4, s8
    v.splat      v2, s1
    s.muli       s1, s6, #4
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s2, s7
    v.cmp.lt     p1, v2, v4
    s.add        s2, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #4
    s.addi       s18, s13, #4
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a0, s4
    s.add        s2, s1, s8
    v.splat      v2, s18
    s.muli       s1, s6, #5
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s2, s7
    v.cmp.lt     p1, v2, v4
    s.add        s2, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #5
    s.addi       s18, s13, #5
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a0, s4
    s.add        s2, s1, s8
    v.splat      v2, s18
    s.muli       s1, s6, #6
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s2, s7
    v.cmp.lt     p1, v2, v4
    s.add        s2, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #6
    s.addi       s18, s13, #6
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a0, s4
    s.add        s2, s1, s8
    v.splat      v2, s18
    s.muli       s1, s6, #7
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s2, s7
    v.cmp.lt     p1, v2, v4
    s.add        s2, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #7
    s.addi       s18, s13, #7
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a0, s4
    s.add        s2, s1, s8
    v.splat      v2, s18
    s.muli       s1, s6, #8
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s2, s7
    v.cmp.lt     p1, v2, v4
    s.add        s2, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #8
    s.addi       s18, s13, #8
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a0, s4
    s.add        s2, s1, s8
    v.splat      v2, s18
    s.muli       s1, s6, #9
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s2, s7
    v.cmp.lt     p1, v2, v4
    s.add        s2, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #9
    s.addi       s18, s13, #9
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a0, s4
    s.add        s2, s1, s8
    v.splat      v2, s18
    s.muli       s1, s6, #10
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s2, s7
    v.cmp.lt     p1, v2, v4
    s.add        s2, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #10
    s.addi       s18, s13, #10
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a0, s4
    s.add        s2, s1, s8
    v.splat      v2, s18
    s.muli       s1, s6, #11
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s2, s7
    v.cmp.lt     p1, v2, v4
    s.add        s2, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #11
    s.addi       s18, s13, #11
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a0, s4
    s.add        s2, s1, s8
    v.splat      v2, s18
    s.muli       s1, s6, #12
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s2, s7
    v.cmp.lt     p1, v2, v4
    s.add        s2, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #12
    s.addi       s18, s13, #12
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a0, s4
    s.add        s2, s1, s8
    v.splat      v2, s18
    s.muli       s1, s6, #13
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s2, s7
    v.cmp.lt     p1, v2, v4
    s.add        s2, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #13
    s.addi       s18, s13, #13
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a0, s4
    s.add        s2, s1, s8
    v.splat      v2, s18
    s.muli       s1, s6, #14
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s2, s7
    v.cmp.lt     p1, v2, v4
    s.add        s2, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #14
    s.addi       s18, s13, #14
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a0, s4
    s.add        s2, s1, s8
    v.splat      v2, s18
    s.muli       s1, s6, #15
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s2, s7
    v.cmp.lt     p1, v2, v4
    s.add        s2, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #15
    s.addi       s18, s13, #15
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a0, s4
    s.add        s2, s1, s8
    v.splat      v2, s18
    s.movz       s1, #0
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s2, s7
    v.cmp.lt     p1, v2, v4
    s.muli       s2, s9, #2
    s.add        s7, s1, s9                      // the tile origin
    s.movz       s1, #0
    s.add        s9, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #0
    v.splat      v1, s7
    s.add        s7, s1, s3                      // the tile origin
    @p3 v.st.h       [s9, #0], v3
    a.vread      v2, a1, s4
    v.splat      v3, s13
    v.add        v5, v0, v1
    v.splat      v1, s7
    s.muli       s1, s6, #1
    vf.cvt.f32.bf16 v6, v2
    s.add        s4, s8, s2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s7, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #1
    s.addi       s9, s13, #1
    @p3 v.st.h       [s7, #0], v6
    a.vread      v1, a1, s4
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #2
    s.addi       s9, s13, #2
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a1, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #3
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #3
    s.addi       s9, s13, #3
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a1, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #4
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #4
    s.addi       s9, s13, #4
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a1, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #5
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #5
    s.addi       s9, s13, #5
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a1, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #6
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #6
    s.addi       s9, s13, #6
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a1, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #7
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #7
    s.addi       s9, s13, #7
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a1, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #8
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #8
    s.addi       s9, s13, #8
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a1, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #9
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #9
    s.addi       s9, s13, #9
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a1, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #10
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #10
    s.addi       s9, s13, #10
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a1, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #11
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #11
    s.addi       s9, s13, #11
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a1, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #12
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #12
    s.addi       s9, s13, #12
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a1, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #13
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #13
    s.addi       s9, s13, #13
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a1, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #14
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #14
    s.addi       s9, s13, #14
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a1, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #15
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #15
    s.addi       s9, s13, #15
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a1, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.movz       s1, #0
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.muli       s2, s10, #2
    s.add        s4, s1, s10                     // the tile origin
    s.movz       s1, #0
    s.add        s9, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #0
    v.splat      v1, s4
    s.add        s4, s1, s3                      // the tile origin
    @p3 v.st.h       [s9, #0], v3
    a.vread      v2, a2, s7
    v.splat      v3, s13
    v.add        v5, v0, v1
    v.splat      v1, s4
    s.muli       s1, s6, #1
    vf.cvt.f32.bf16 v6, v2
    s.add        s4, s8, s2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s7, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #1
    s.addi       s9, s13, #1
    @p3 v.st.h       [s7, #0], v6
    a.vread      v1, a2, s4
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #2
    s.addi       s9, s13, #2
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a2, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #3
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #3
    s.addi       s9, s13, #3
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a2, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #4
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #4
    s.addi       s9, s13, #4
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a2, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #5
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #5
    s.addi       s9, s13, #5
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a2, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #6
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #6
    s.addi       s9, s13, #6
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a2, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #7
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #7
    s.addi       s9, s13, #7
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a2, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #8
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #8
    s.addi       s9, s13, #8
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a2, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #9
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #9
    s.addi       s9, s13, #9
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a2, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #10
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #10
    s.addi       s9, s13, #10
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a2, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #11
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #11
    s.addi       s9, s13, #11
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a2, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #12
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #12
    s.addi       s9, s13, #12
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a2, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #13
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #13
    s.addi       s9, s13, #13
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a2, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #14
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #14
    s.addi       s9, s13, #14
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a2, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #15
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #15
    s.addi       s9, s13, #15
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a2, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.movz       s1, #0
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.muli       s2, s11, #2
    s.add        s4, s1, s11                     // the tile origin
    s.movz       s1, #0
    s.add        s9, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #0
    v.splat      v1, s4
    s.add        s4, s1, s3                      // the tile origin
    @p3 v.st.h       [s9, #0], v3
    a.vread      v2, a3, s7
    v.splat      v3, s13
    v.add        v5, v0, v1
    v.splat      v1, s4
    s.muli       s1, s6, #1
    vf.cvt.f32.bf16 v6, v2
    s.add        s4, s8, s2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s7, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #1
    s.addi       s9, s13, #1
    @p3 v.st.h       [s7, #0], v6
    a.vread      v1, a3, s4
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #2
    s.addi       s9, s13, #2
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a3, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #3
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #3
    s.addi       s9, s13, #3
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a3, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #4
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #4
    s.addi       s9, s13, #4
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a3, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #5
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #5
    s.addi       s9, s13, #5
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a3, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #6
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #6
    s.addi       s9, s13, #6
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a3, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #7
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #7
    s.addi       s9, s13, #7
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a3, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #8
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #8
    s.addi       s9, s13, #8
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a3, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #9
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #9
    s.addi       s9, s13, #9
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a3, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #10
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #10
    s.addi       s9, s13, #10
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a3, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #11
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #11
    s.addi       s9, s13, #11
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a3, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #12
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #12
    s.addi       s9, s13, #12
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a3, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #13
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #13
    s.addi       s9, s13, #13
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a3, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #14
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #14
    s.addi       s9, s13, #14
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a3, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #15
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #15
    s.addi       s9, s13, #15
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a3, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.movz       s1, #0
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.muli       s2, s12, #2
    s.add        s4, s1, s12                     // the tile origin
    s.movz       s1, #0
    s.add        s9, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #0
    v.splat      v1, s4
    s.add        s4, s1, s3                      // the tile origin
    @p3 v.st.h       [s9, #0], v3
    a.vread      v2, a4, s7
    v.splat      v3, s13
    v.add        v5, v0, v1
    v.splat      v1, s4
    s.muli       s1, s6, #1
    vf.cvt.f32.bf16 v6, v2
    s.add        s4, s8, s2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s7, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #1
    s.addi       s9, s13, #1
    @p3 v.st.h       [s7, #0], v6
    a.vread      v1, a4, s4
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #2
    s.addi       s9, s13, #2
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a4, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #3
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #3
    s.addi       s9, s13, #3
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a4, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #4
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #4
    s.addi       s9, s13, #4
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a4, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #5
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #5
    s.addi       s9, s13, #5
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a4, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #6
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #6
    s.addi       s9, s13, #6
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a4, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #7
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #7
    s.addi       s9, s13, #7
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a4, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #8
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #8
    s.addi       s9, s13, #8
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a4, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #9
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #9
    s.addi       s9, s13, #9
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a4, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #10
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #10
    s.addi       s9, s13, #10
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a4, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #11
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #11
    s.addi       s9, s13, #11
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a4, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #12
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #12
    s.addi       s9, s13, #12
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a4, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #13
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #13
    s.addi       s9, s13, #13
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a4, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #14
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #14
    s.addi       s9, s13, #14
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a4, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #15
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #15
    s.addi       s9, s13, #15
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a4, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.movz       s1, #0
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.muli       s2, s14, #2
    s.add        s4, s1, s14                     // the tile origin
    s.movz       s1, #0
    s.add        s9, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #0
    v.splat      v1, s4
    s.add        s4, s1, s3                      // the tile origin
    @p3 v.st.h       [s9, #0], v3
    a.vread      v2, a5, s7
    v.splat      v3, s13
    v.add        v5, v0, v1
    v.splat      v1, s4
    s.muli       s1, s6, #1
    vf.cvt.f32.bf16 v6, v2
    s.add        s4, s8, s2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s7, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #1
    s.addi       s9, s13, #1
    @p3 v.st.h       [s7, #0], v6
    a.vread      v1, a5, s4
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #2
    s.addi       s9, s13, #2
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a5, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #3
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #3
    s.addi       s9, s13, #3
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a5, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #4
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #4
    s.addi       s9, s13, #4
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a5, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #5
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #5
    s.addi       s9, s13, #5
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a5, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #6
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #6
    s.addi       s9, s13, #6
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a5, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #7
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #7
    s.addi       s9, s13, #7
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a5, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #8
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #8
    s.addi       s9, s13, #8
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a5, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #9
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #9
    s.addi       s9, s13, #9
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a5, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #10
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #10
    s.addi       s9, s13, #10
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a5, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #11
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #11
    s.addi       s9, s13, #11
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a5, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #12
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #12
    s.addi       s9, s13, #12
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a5, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #13
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #13
    s.addi       s9, s13, #13
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a5, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #14
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #14
    s.addi       s9, s13, #14
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a5, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #15
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #15
    s.addi       s9, s13, #15
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a5, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.movz       s1, #0
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.muli       s2, s15, #2
    s.add        s4, s1, s15                     // the tile origin
    s.movz       s1, #0
    s.add        s9, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #0
    v.splat      v1, s4
    s.add        s4, s1, s3                      // the tile origin
    @p3 v.st.h       [s9, #0], v3
    a.vread      v2, a6, s7
    v.splat      v3, s13
    v.add        v5, v0, v1
    v.splat      v1, s4
    s.muli       s1, s6, #1
    vf.cvt.f32.bf16 v6, v2
    s.add        s4, s8, s2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.add        s7, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #1
    s.addi       s9, s13, #1
    @p3 v.st.h       [s7, #0], v6
    a.vread      v1, a6, s4
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #2
    s.addi       s9, s13, #2
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a6, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #3
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #3
    s.addi       s9, s13, #3
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a6, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #4
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #4
    s.addi       s9, s13, #4
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a6, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #5
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #5
    s.addi       s9, s13, #5
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a6, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #6
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #6
    s.addi       s9, s13, #6
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a6, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #7
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #7
    s.addi       s9, s13, #7
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a6, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #8
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #8
    s.addi       s9, s13, #8
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a6, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #9
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #9
    s.addi       s9, s13, #9
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a6, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #10
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #10
    s.addi       s9, s13, #10
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a6, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #11
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #11
    s.addi       s9, s13, #11
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a6, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #12
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #12
    s.addi       s9, s13, #12
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a6, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #13
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #13
    s.addi       s9, s13, #13
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a6, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #14
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #14
    s.addi       s9, s13, #14
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a6, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.muli       s1, s6, #15
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #15
    s.addi       s9, s13, #15
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a6, s7
    s.add        s4, s1, s8
    v.splat      v2, s9
    s.movz       s1, #0
    vf.cvt.f32.bf16 v3, v1
    s.add        s7, s4, s2
    v.cmp.lt     p1, v2, v4
    s.muli       s2, s16, #2
    s.add        s4, s1, s16                     // the tile origin
    s.movz       s1, #0
    s.add        s9, s5, s7
    p.and        p3, p1, p2
    s.movz       s7, #0
    v.splat      v1, s4
    s.add        s4, s1, s3                      // the tile origin
    @p3 v.st.h       [s9, #0], v3
    a.vread      v2, a7, s7
    v.splat      v3, s13
    v.add        v5, v0, v1
    v.splat      v0, s4
    s.muli       s1, s6, #1
    vf.cvt.f32.bf16 v1, v2
    s.add        s3, s8, s2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s4, s5, s3
    p.and        p3, p1, p2
    s.movz       s3, #1
    s.addi       s7, s13, #1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v0, a7, s3
    s.add        s3, s1, s8
    v.splat      v1, s7
    s.muli       s1, s6, #2
    vf.cvt.f32.bf16 v2, v0
    s.add        s4, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s3, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.addi       s7, s13, #2
    @p3 v.st.h       [s3, #0], v2
    a.vread      v0, a7, s4
    s.add        s3, s1, s8
    v.splat      v1, s7
    s.muli       s1, s6, #3
    vf.cvt.f32.bf16 v2, v0
    s.add        s4, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s3, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #3
    s.addi       s7, s13, #3
    @p3 v.st.h       [s3, #0], v2
    a.vread      v0, a7, s4
    s.add        s3, s1, s8
    v.splat      v1, s7
    s.muli       s1, s6, #4
    vf.cvt.f32.bf16 v2, v0
    s.add        s4, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s3, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #4
    s.addi       s7, s13, #4
    @p3 v.st.h       [s3, #0], v2
    a.vread      v0, a7, s4
    s.add        s3, s1, s8
    v.splat      v1, s7
    s.muli       s1, s6, #5
    vf.cvt.f32.bf16 v2, v0
    s.add        s4, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s3, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #5
    s.addi       s7, s13, #5
    @p3 v.st.h       [s3, #0], v2
    a.vread      v0, a7, s4
    s.add        s3, s1, s8
    v.splat      v1, s7
    s.muli       s1, s6, #6
    vf.cvt.f32.bf16 v2, v0
    s.add        s4, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s3, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #6
    s.addi       s7, s13, #6
    @p3 v.st.h       [s3, #0], v2
    a.vread      v0, a7, s4
    s.add        s3, s1, s8
    v.splat      v1, s7
    s.muli       s1, s6, #7
    vf.cvt.f32.bf16 v2, v0
    s.add        s4, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s3, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #7
    s.addi       s7, s13, #7
    @p3 v.st.h       [s3, #0], v2
    a.vread      v0, a7, s4
    s.add        s3, s1, s8
    v.splat      v1, s7
    s.muli       s1, s6, #8
    vf.cvt.f32.bf16 v2, v0
    s.add        s4, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s3, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #8
    s.addi       s7, s13, #8
    @p3 v.st.h       [s3, #0], v2
    a.vread      v0, a7, s4
    s.add        s3, s1, s8
    v.splat      v1, s7
    s.muli       s1, s6, #9
    vf.cvt.f32.bf16 v2, v0
    s.add        s4, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s3, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #9
    s.addi       s7, s13, #9
    @p3 v.st.h       [s3, #0], v2
    a.vread      v0, a7, s4
    s.add        s3, s1, s8
    v.splat      v1, s7
    s.muli       s1, s6, #10
    vf.cvt.f32.bf16 v2, v0
    s.add        s4, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s3, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #10
    s.addi       s7, s13, #10
    @p3 v.st.h       [s3, #0], v2
    a.vread      v0, a7, s4
    s.add        s3, s1, s8
    v.splat      v1, s7
    s.muli       s1, s6, #11
    vf.cvt.f32.bf16 v2, v0
    s.add        s4, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s3, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #11
    s.addi       s7, s13, #11
    @p3 v.st.h       [s3, #0], v2
    a.vread      v0, a7, s4
    s.add        s3, s1, s8
    v.splat      v1, s7
    s.muli       s1, s6, #12
    vf.cvt.f32.bf16 v2, v0
    s.add        s4, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s3, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #12
    s.addi       s7, s13, #12
    @p3 v.st.h       [s3, #0], v2
    a.vread      v0, a7, s4
    s.add        s3, s1, s8
    v.splat      v1, s7
    s.muli       s1, s6, #13
    vf.cvt.f32.bf16 v2, v0
    s.add        s4, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s3, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #13
    s.addi       s7, s13, #13
    @p3 v.st.h       [s3, #0], v2
    a.vread      v0, a7, s4
    s.add        s3, s1, s8
    v.splat      v1, s7
    s.muli       s1, s6, #14
    vf.cvt.f32.bf16 v2, v0
    s.add        s4, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s3, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #14
    s.addi       s7, s13, #14
    @p3 v.st.h       [s3, #0], v2
    a.vread      v0, a7, s4
    s.add        s3, s1, s8
    v.splat      v1, s7
    s.muli       s1, s6, #15
    vf.cvt.f32.bf16 v2, v0
    s.add        s4, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s3, s5, s4
    p.and        p3, p1, p2
    s.movz       s4, #15
    s.addi       s6, s13, #15
    @p3 v.st.h       [s3, #0], v2
    a.vread      v0, a7, s4
    s.add        s3, s1, s8
    v.splat      v1, s6
    vf.cvt.f32.bf16 v2, v0
    s.add        s1, s3, s2
    v.cmp.lt     p1, v1, v4
    s.add        s2, s5, s1
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v2
    exit
    exit
