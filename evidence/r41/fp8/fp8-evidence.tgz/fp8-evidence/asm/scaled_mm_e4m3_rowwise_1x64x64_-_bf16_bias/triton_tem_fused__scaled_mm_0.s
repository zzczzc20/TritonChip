    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #4
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #2
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s8, #0
    s.cmp.lt     s13, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s13
    s.sub        s11, s8, s9
    s.xor        s8, s12, s3
    s.muli       s9, s5, #4
    s.movz       s5, #0
    s.movz       s13, #1
    s.xor        s14, s4, s11
    s.sub        s15, s8, s3
    s.rdspecial  s3, arg_base
    s.xor        s8, s1, s7
    s.movz       s16, #0
    s.sub        s17, s14, s11
    s.addi       s14, s5, #0
    s.cmp.eq     s5, s15, s13
    s.ld.d       s13, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s18, s8, s7
    s.sub        s7, s2, s9
    s.addi       s2, s16, #0
    s.ld.d       s7, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s8, [s3, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s9, [s3, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s16, [s3, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s18, [s3, #40]                  // out_ptr0: device_ptr64 at arg_base+40
    s.mov        s14, s17
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s14, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s17, s3
    s.shli       s19, s2, #1
    s.andi       s20, s5, #1
    s.movz       s5, #0
    s.or         s21, s19, s20
    s.movz       s19, #1
    s.cmp.geu    s20, s21, s15
    s.shl        s22, s19, s3
    s.sub        s19, s5, s20
    s.subi       s5, s3, #1
    s.and        s20, s15, s19
    s.and        s23, s22, s19
    s.sub        s19, s21, s20
    s.or         s20, s14, s23
    s.mov        s2, s19
    s.mov        s14, s20
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s19, s3, s5
    br.nz        s19, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s14, s4, s3
    s.movz       s3, #0
    s.sub        s15, s5, s14
    s.movz       s5, #0
    s.xor        s14, s4, s15
    s.movz       s4, #0
    s.sub        s17, s14, s15
    s.cmp.lt     s14, s12, s3
    s.lshri      s3, s17, #2
    s.movz       s19, #0
    s.muli       s20, s3, #4
    s.movz       s3, #0
    s.sub        s21, s4, s14
    s.movz       s4, #0
    s.cmp.lt     s14, s1, s19
    s.sub        s19, s17, s20
    s.xor        s17, s12, s21
    s.xor        s12, s19, s15
    s.xor        s19, s2, s11
    s.sub        s2, s12, s15
    s.sub        s12, s4, s14
    s.cmp.lt     s4, s2, s5
    s.sub        s5, s17, s21
    s.sub        s14, s3, s4
    s.movz       s3, #0
    s.xor        s4, s2, s14
    s.movz       s2, #1
    s.sub        s15, s19, s11
    s.xor        s11, s1, s12
    s.sub        s17, s4, s14
    s.movz       s4, #0
    s.addi       s19, s3, #0
    s.cmp.eq     s3, s5, s2
    s.add        s2, s10, s15
    s.sub        s10, s11, s12
    s.addi       s10, s4, #0
    s.mov        s19, s17
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s19, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s17, s3
    s.shli       s11, s10, #1
    s.andi       s12, s4, #1
    s.movz       s4, #0
    s.or         s15, s11, s12
    s.movz       s11, #1
    s.cmp.geu    s12, s15, s5
    s.shl        s20, s11, s3
    s.sub        s11, s4, s12
    s.subi       s4, s3, #1
    s.and        s12, s5, s11
    s.and        s22, s20, s11
    s.sub        s11, s15, s12
    s.or         s12, s19, s22
    s.mov        s10, s11
    s.mov        s19, s12
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s11, s3, s4
    br.nz        s11, sdiv_4
sdiv_done_3:
    s.xor        s3, s14, s21
    s.movz       s4, #16
    s.xor        s5, s19, s3
    s.movz       s10, #0
    s.sub        s11, s5, s3
    v.splat      v0, s2
    s.mul        s3, s11, s4
    v.splat      v1, s10
    v.splat      v2, s11
    v.splat      v3, s10
    v.iota       v4                              // arange(0, VLEN)
    s.andi       s5, s3, #63
    v.splat      v5, s3
    v.splat      v6, s5
    v.cmp.ge     p1, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ge     p1, v2, v3
    v.add        v1, v5, v4
    v.add        v1, v6, v0
    s.addi       s11, s10, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s10, s11, s1
    br.nz        s10, endfor_6
    s.mul        s10, s11, s4
    s.add        s12, s13, s10                   // the tile origin
    v.ld.b       v0, [s12, #0]
    s.rdspecial  s12, arg_base
    s.ld.d       s14, [s12, #48]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s12, role_id
    s.movz       s15, #512
    s.mul        s17, s12, s15
    s.add        s12, s14, s17                   // this context's own scratch
    s.addi       s14, s12, #0                    // 256 bytes of repack scratch
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    v.st.b       [s14, #0], v0
    s.addi       s15, s14, #16                   // row 1
    v.st.b       [s15, #0], v0
    s.addi       s15, s14, #32                   // row 2
    v.st.b       [s15, #0], v0
    s.addi       s15, s14, #48                   // row 3
    v.st.b       [s15, #0], v0
    s.addi       s15, s14, #64                   // row 4
    v.st.b       [s15, #0], v0
    s.addi       s15, s14, #80                   // row 5
    v.st.b       [s15, #0], v0
    s.addi       s15, s14, #96                   // row 6
    v.st.b       [s15, #0], v0
    s.addi       s15, s14, #112                  // row 7
    v.st.b       [s15, #0], v0
    s.addi       s15, s14, #128                  // row 8
    v.st.b       [s15, #0], v0
    s.addi       s15, s14, #144                  // row 9
    v.st.b       [s15, #0], v0
    s.addi       s15, s14, #160                  // row 10
    v.st.b       [s15, #0], v0
    s.addi       s15, s14, #176                  // row 11
    v.st.b       [s15, #0], v0
    s.addi       s15, s14, #192                  // row 12
    v.st.b       [s15, #0], v0
    s.addi       s15, s14, #208                  // row 13
    v.st.b       [s15, #0], v0
    s.addi       s15, s14, #224                  // row 14
    v.st.b       [s15, #0], v0
    s.addi       s15, s14, #240                  // row 15
    v.st.b       [s15, #0], v0
    w.def        w0, #60, #4                     // v60..v63
    fence.acq_rel.device
    v.ld.w       v0, [s14, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s15, s14, #64
    v.ld.w       v0, [s15, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s15, s14, #128
    v.ld.w       v0, [s15, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s15, s14, #192
    v.ld.w       v0, [s15, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #256                  // 256 bytes of repack scratch
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.movz       s12, #0
    s.add        s15, s12, s10                   // the tile origin
    s.muli       s10, s5, #64                    // a runtime tile origin, x64
    s.add        s12, s15, s10                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    s.movz       s10, #64
    v.splat      v1, s10
    v.mul        v2, v0, v1
    v.splat      v0, s12
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s14, #0], v0
    s.addi       s10, s12, #1
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #16                   // row 1
    v.st.b       [s10, #0], v0
    s.addi       s10, s12, #2
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #32                   // row 2
    v.st.b       [s10, #0], v0
    s.addi       s10, s12, #3
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #48                   // row 3
    v.st.b       [s10, #0], v0
    s.addi       s10, s12, #4
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #64                   // row 4
    v.st.b       [s10, #0], v0
    s.addi       s10, s12, #5
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #80                   // row 5
    v.st.b       [s10, #0], v0
    s.addi       s10, s12, #6
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #96                   // row 6
    v.st.b       [s10, #0], v0
    s.addi       s10, s12, #7
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #112                  // row 7
    v.st.b       [s10, #0], v0
    s.addi       s10, s12, #8
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #128                  // row 8
    v.st.b       [s10, #0], v0
    s.addi       s10, s12, #9
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #144                  // row 9
    v.st.b       [s10, #0], v0
    s.addi       s10, s12, #10
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #160                  // row 10
    v.st.b       [s10, #0], v0
    s.addi       s10, s12, #11
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #176                  // row 11
    v.st.b       [s10, #0], v0
    s.addi       s10, s12, #12
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #192                  // row 12
    v.st.b       [s10, #0], v0
    s.addi       s10, s12, #13
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #208                  // row 13
    v.st.b       [s10, #0], v0
    s.addi       s10, s12, #14
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #224                  // row 14
    v.st.b       [s10, #0], v0
    s.addi       s10, s12, #15
    v.splat      v0, s10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s10, s14, #240                  // row 15
    v.st.b       [s10, #0], v0
    w.def        w1, #56, #4                     // v56..v59
    fence.acq_rel.device
    v.ld.w       v0, [s14, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s10, s14, #64
    v.ld.w       v0, [s10, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s10, s14, #128
    v.ld.w       v0, [s10, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s10, s14, #192
    v.ld.w       v0, [s10, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s10, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.e4m3 a0, v60, v56, s10
    mb.wait      s10
    s.add        s12, s11, s6
    s.mov        s11, s12
    s.movz       s12, #1
    br.nz        s12, for_5
endfor_6:
    s.mul        s1, s2, s4
    s.movz       s2, #0
    s.movz       s4, #0
    s.add        s5, s2, s3                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s5
    s.add        s2, s4, s1                      // the tile origin
    s.movz       s4, #64
    s.muli       s5, s3, #4                      // a runtime tile origin, x4
    v.splat      v2, s2
    v.splat      v3, s6
    v.add        v5, v0, v1
    v.splat      v0, s4
    v.cmp.lt     p1, v2, v3
    s.add        s4, s9, s5                      // the tile origin
    v.cmp.lt     p2, v5, v0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s5, #0
    p.and        p3, p1, p2
    s.ld.w       s6, [s8, #0]                    // one element, not a vector
    a.vread      v0, a0, s5
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s5, s3, #2                      // a runtime tile origin, x2
    v.splat      v1, s2
    s.addi       s7, s2, #1
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s8, s3, #2                      // a runtime tile origin, x2
    v.cmp.lt     p1, v1, v3
    s.add        s3, s16, s5                     // the tile origin
    p.and        p4, p1, p2
    v.splat      v1, s2
    v.splat      v2, s7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s4, #0]
    v.splat      v6, s6
    v.cmp.lt     p1, v1, v3
    s.add        s5, s18, s8                     // the tile origin
    p.and        p3, p1, p2
    s.movz       s6, #1
    v.splat      v1, s1
    v.add        v7, v1, v4
    s.addi       s1, s2, #1
    s.addi       s7, s2, #1
    v.splat      v1, s1
    s.addi       s1, s2, #2
    v.splat      v4, s7
    v.splat      v7, s1
    s.movz       s1, #2
    s.addi       s7, s2, #2
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v8, [s3, #0]
    vf.mul       v9, v6, v5
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    v.splat      v2, s7
    vf.mul       v5, v0, v9
    s.addi       s7, s2, #2
    v.splat      v0, s7
    vf.cvt.bf16.f32 v9, v8
    vf.add       v8, v5, v9
    vf.cvt.f32.bf16 v5, v8
    s.addi       s7, s2, #3
    s.movz       s8, #3
    @p3 v.st.h       [s5, #0], v5
    a.vread      v5, a0, s6
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.splat      v1, s7
    s.addi       s6, s2, #3
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s4, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    v.splat      v4, s6
    vf.mul       v9, v6, v8
    vf.mul       v8, v5, v9
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s3, #0]
    v.cmp.lt     p1, v7, v3
    p.and        p3, p1, p2
    s.addi       s6, s2, #3
    vf.cvt.bf16.f32 v7, v5
    v.splat      v5, s6
    vf.add       v9, v8, v7
    vf.cvt.f32.bf16 v7, v9
    s.addi       s6, s2, #4
    s.movz       s7, #4
    @p4 v.st.h       [s5, #0], v7
    a.vread      v7, a0, s1
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    v.splat      v2, s6
    s.addi       s1, s2, #4
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    v.splat      v0, s1
    vf.mul       v9, v6, v8
    vf.mul       v8, v7, v9
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s1, s2, #4
    vf.cvt.bf16.f32 v1, v7
    v.splat      v7, s1
    vf.add       v9, v8, v1
    vf.cvt.f32.bf16 v1, v9
    s.addi       s1, s2, #5
    s.movz       s6, #5
    @p3 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s8
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.splat      v4, s1
    s.addi       s1, s2, #5
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s4, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    v.splat      v5, s1
    vf.mul       v9, v6, v8
    vf.mul       v8, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s3, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.addi       s1, s2, #5
    vf.cvt.bf16.f32 v2, v1
    v.splat      v1, s1
    vf.add       v9, v8, v2
    vf.cvt.f32.bf16 v2, v9
    s.addi       s1, s2, #6
    s.movz       s8, #6
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s7
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    v.splat      v0, s1
    s.addi       s1, s2, #6
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s4, #0]
    v.cmp.lt     p1, v7, v3
    p.and        p3, p1, p2
    v.splat      v7, s1
    vf.mul       v9, v6, v8
    vf.mul       v8, v2, v9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s3, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.addi       s1, s2, #6
    vf.cvt.bf16.f32 v4, v2
    v.splat      v2, s1
    vf.add       v9, v8, v4
    vf.cvt.f32.bf16 v4, v9
    s.addi       s1, s2, #7
    s.movz       s7, #7
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a0, s6
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.splat      v5, s1
    s.addi       s1, s2, #7
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s4, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.splat      v1, s1
    vf.mul       v9, v6, v8
    vf.mul       v8, v4, v9
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s3, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s1, s2, #7
    vf.cvt.bf16.f32 v0, v4
    v.splat      v4, s1
    vf.add       v9, v8, v0
    vf.cvt.f32.bf16 v0, v9
    s.addi       s1, s2, #8
    s.movz       s6, #8
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s8
    v.cmp.lt     p1, v7, v3
    p.and        p4, p1, p2
    v.splat      v7, s1
    s.addi       s1, s2, #8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s4, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.splat      v2, s1
    vf.mul       v9, v6, v8
    vf.mul       v8, v0, v9
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s3, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    s.addi       s1, s2, #8
    vf.cvt.bf16.f32 v5, v0
    v.splat      v0, s1
    vf.add       v9, v8, v5
    vf.cvt.f32.bf16 v5, v9
    s.addi       s1, s2, #9
    s.movz       s8, #9
    @p3 v.st.h       [s5, #0], v5
    a.vread      v5, a0, s7
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.splat      v1, s1
    s.addi       s1, s2, #9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s4, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    v.splat      v4, s1
    vf.mul       v9, v6, v8
    vf.mul       v8, v5, v9
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s3, #0]
    v.cmp.lt     p1, v7, v3
    p.and        p3, p1, p2
    s.addi       s1, s2, #9
    vf.cvt.bf16.f32 v7, v5
    v.splat      v5, s1
    vf.add       v9, v8, v7
    vf.cvt.f32.bf16 v7, v9
    s.addi       s1, s2, #10
    s.movz       s7, #10
    @p4 v.st.h       [s5, #0], v7
    a.vread      v7, a0, s6
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    v.splat      v2, s1
    s.addi       s1, s2, #10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    v.splat      v0, s1
    vf.mul       v9, v6, v8
    vf.mul       v8, v7, v9
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s1, s2, #10
    vf.cvt.bf16.f32 v1, v7
    v.splat      v7, s1
    vf.add       v9, v8, v1
    vf.cvt.f32.bf16 v1, v9
    s.addi       s1, s2, #11
    s.movz       s6, #11
    @p3 v.st.h       [s5, #0], v1
    a.vread      v1, a0, s8
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.splat      v4, s1
    s.addi       s1, s2, #11
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s4, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    v.splat      v5, s1
    vf.mul       v9, v6, v8
    vf.mul       v8, v1, v9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s3, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.addi       s1, s2, #11
    vf.cvt.bf16.f32 v2, v1
    v.splat      v1, s1
    vf.add       v9, v8, v2
    vf.cvt.f32.bf16 v2, v9
    s.addi       s1, s2, #12
    s.movz       s8, #12
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s7
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    v.splat      v0, s1
    s.addi       s1, s2, #12
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s4, #0]
    v.cmp.lt     p1, v7, v3
    p.and        p3, p1, p2
    v.splat      v7, s1
    vf.mul       v9, v6, v8
    vf.mul       v8, v2, v9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s3, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.addi       s1, s2, #12
    vf.cvt.bf16.f32 v4, v2
    v.splat      v2, s1
    vf.add       v9, v8, v4
    vf.cvt.f32.bf16 v4, v9
    s.addi       s1, s2, #13
    s.movz       s7, #13
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a0, s6
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.splat      v5, s1
    s.addi       s1, s2, #13
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s4, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.splat      v1, s1
    vf.mul       v9, v6, v8
    vf.mul       v8, v4, v9
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s3, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s1, s2, #13
    vf.cvt.bf16.f32 v0, v4
    v.splat      v4, s1
    vf.add       v9, v8, v0
    vf.cvt.f32.bf16 v0, v9
    s.addi       s1, s2, #14
    s.movz       s6, #14
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s8
    v.cmp.lt     p1, v7, v3
    p.and        p4, p1, p2
    v.splat      v7, s1
    s.addi       s1, s2, #14
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s4, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.splat      v2, s1
    vf.mul       v9, v6, v8
    vf.mul       v8, v0, v9
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s3, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    s.addi       s1, s2, #14
    vf.cvt.bf16.f32 v5, v0
    v.splat      v0, s1
    vf.add       v9, v8, v5
    vf.cvt.f32.bf16 v5, v9
    s.addi       s1, s2, #15
    s.movz       s8, #15
    @p3 v.st.h       [s5, #0], v5
    a.vread      v5, a0, s7
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.splat      v1, s1
    s.addi       s1, s2, #15
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s4, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    v.splat      v4, s1
    vf.mul       v9, v6, v8
    vf.mul       v8, v5, v9
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s3, #0]
    v.cmp.lt     p1, v7, v3
    p.and        p3, p1, p2
    s.addi       s1, s2, #15
    vf.cvt.bf16.f32 v7, v5
    v.splat      v5, s1
    vf.add       v9, v8, v7
    vf.cvt.f32.bf16 v7, v9
    @p4 v.st.h       [s5, #0], v7
    a.vread      v7, a0, s6
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v0, [s3, #0]
    vf.mul       v8, v6, v2
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    vf.mul       v1, v7, v8
    vf.cvt.bf16.f32 v2, v0
    vf.add       v0, v1, v2
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s5, #0], v1
    a.vread      v0, a0, s8
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s4, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s3, #0]
    vf.mul       v3, v6, v1
    vf.mul       v1, v0, v3
    vf.cvt.bf16.f32 v0, v2
    vf.add       v2, v1, v0
    vf.cvt.f32.bf16 v0, v2
    @p4 v.st.h       [s5, #0], v0
__rctx_next:
    exit
