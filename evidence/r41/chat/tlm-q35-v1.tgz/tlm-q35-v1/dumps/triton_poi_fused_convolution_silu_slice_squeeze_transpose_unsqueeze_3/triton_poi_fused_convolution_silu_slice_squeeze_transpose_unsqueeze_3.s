    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #0
    v.add        v4, v1, v0
    v.movi       v0, #13
    v.movi       v1, #8191
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v3, v4
    @p1 v.sel        v7, v5, v4
    v.cmp.lt     p2, v4, v3
    @p2 v.sel        v5, v6, v4
    v.lshr       v6, v7, v0
    v.movi       v0, #-3
    v.and        v7, v5, v1
    v.sub        v1, v2, v6
    s.rdspecial  s2, arg_base
    v.sub        v5, v3, v7
    @p1 v.sel        v8, v1, v6
    s.ld.d       s3, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    @p2 v.sel        v1, v5, v7
    v.add        v5, v8, v0
    v.movi       v0, #4
    v.movi       v6, #1
    v.movi       v7, #2
    v.mul        v9, v1, v0
    v.movi       v0, #3
    v.movi       v1, #8192
    v.add        v10, v9, v6
    v.add        v6, v9, v7
    v.add        v7, v9, v0
    s.ld.d       s4, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v0, #0
    v.movi       v11, #0
    v.sub        v12, v2, v1
    v.sub        v13, v3, v1
    v.cmp.lt     p1, v1, v2
    v.cmp.lt     p2, v1, v3
    @p1 v.sel        v2, v12, v1
    @p2 v.sel        v2, v13, v1
    s.ld.d       s5, [s2, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    v.extract    s2, v5, #0
    v.extract    s6, v5, #1
    s.shli       s7, s2, #32
    s.shli       s2, s6, #32
    s.ashri      s6, s7, #32
    v.extract    s7, v5, #2
    s.lshri      s8, s6, #32
    s.ashri      s9, s2, #32
    s.shli       s2, s7, #32
    s.lshri      s7, s9, #32
    v.ld.gather.h v1, [s3, v9]                   // index is in elements (ISA sec 9.1)
    v.extract    s10, v5, #3
    s.ashri      s11, s2, #32
    s.shli       s2, s10, #32
    s.ashri      s10, s2, #32
    v.ld.gather.h v2, [s3, v10]                  // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v3, v1
    v.ld.gather.h v1, [s3, v6]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v6, v2
    v.ld.gather.h v2, [s3, v7]                   // index is in elements (ISA sec 9.1)
    v.insert     v0, s6, #0
    v.insert     v11, s8, #0
    s.lshri      s2, s11, #32
    v.insert     v0, s9, #1
    v.insert     v11, s7, #1
    v.extract    s3, v5, #4
    v.insert     v0, s11, #2
    v.insert     v11, s2, #2
    s.shli       s2, s3, #32
    s.lshri      s3, s10, #32
    v.extract    s6, v5, #5
    s.ashri      s7, s2, #32
    v.insert     v0, s10, #3
    v.insert     v11, s3, #3
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v5, #6
    s.ashri      s8, s2, #32
    v.insert     v0, s7, #4
    v.insert     v11, s3, #4
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    s.ashri      s6, s2, #32
    v.insert     v0, s8, #5
    v.insert     v11, s3, #5
    vf.cvt.bf16.f32 v7, v1
    v.extract    s2, v5, #7
    s.lshri      s3, s6, #32
    v.insert     v0, s6, #6
    v.insert     v11, s3, #6
    vf.cvt.bf16.f32 v1, v2
    s.shli       s3, s2, #32
    v.extract    s2, v5, #8
    s.ashri      s6, s3, #32
    s.shli       s3, s2, #32
    s.lshri      s2, s6, #32
    v.extract    s7, v5, #9
    s.ashri      s8, s3, #32
    v.insert     v0, s6, #7
    v.insert     v11, s2, #7
    s.shli       s2, s7, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v5, #10
    s.ashri      s7, s2, #32
    v.insert     v0, s8, #8
    v.insert     v11, s3, #8
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v5, #11
    s.ashri      s8, s2, #32
    v.insert     v0, s7, #9
    v.insert     v11, s3, #9
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v5, #12
    s.ashri      s7, s2, #32
    v.insert     v0, s8, #10
    v.insert     v11, s3, #10
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v5, #13
    s.ashri      s8, s2, #32
    v.insert     v0, s7, #11
    v.insert     v11, s3, #11
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v5, #14
    s.ashri      s7, s2, #32
    v.insert     v0, s8, #12
    v.insert     v11, s3, #12
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v5, #15
    s.ashri      s8, s2, #32
    v.insert     v0, s7, #13
    v.insert     v11, s3, #13
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    s.ashri      s6, s2, #32
    v.insert     v0, s8, #14
    v.insert     v11, s3, #14
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #15
    v.insert     v11, s2, #15
    s.movz       s2, #0
    v.extract    s3, v0, #0
    v.extract    s6, v11, #0
    v.extract    s7, v11, #1
    s.shli       s8, s6, #32
    v.movi       v2, #0
    s.or         s6, s3, s8
    v.extract    s3, v0, #1
    s.shli       s8, s7, #32
    s.cmp.ge     s7, s6, s2
    v.extract    s6, v11, #2
    s.or         s9, s3, s8
    v.insert     v2, s7, #0
    v.extract    s3, v0, #2
    s.shli       s7, s6, #32
    s.cmp.ge     s6, s9, s2
    v.extract    s8, v11, #3
    s.or         s9, s3, s7
    v.insert     v2, s6, #1
    v.extract    s3, v0, #3
    s.shli       s6, s8, #32
    s.cmp.ge     s7, s9, s2
    v.extract    s8, v11, #4
    s.or         s9, s3, s6
    v.insert     v2, s7, #2
    v.extract    s3, v0, #4
    s.shli       s6, s8, #32
    s.cmp.ge     s7, s9, s2
    v.extract    s8, v11, #5
    s.or         s9, s3, s6
    v.insert     v2, s7, #3
    v.extract    s3, v0, #5
    s.shli       s6, s8, #32
    s.cmp.ge     s7, s9, s2
    v.extract    s2, v11, #6
    s.or         s8, s3, s6
    s.movz       s3, #0
    v.insert     v2, s7, #4
    v.extract    s6, v0, #6
    s.shli       s7, s2, #32
    s.cmp.ge     s2, s8, s3
    v.extract    s3, v11, #7
    s.or         s8, s6, s7
    s.movz       s6, #0
    v.insert     v2, s2, #5
    v.extract    s2, v0, #7
    s.shli       s7, s3, #32
    s.cmp.ge     s3, s8, s6
    v.extract    s6, v11, #8
    s.or         s8, s2, s7
    s.movz       s2, #0
    v.insert     v2, s3, #6
    v.extract    s3, v0, #8
    s.shli       s7, s6, #32
    s.cmp.ge     s6, s8, s2
    v.extract    s2, v11, #9
    s.or         s8, s3, s7
    s.movz       s3, #0
    v.insert     v2, s6, #7
    v.extract    s6, v0, #9
    s.shli       s7, s2, #32
    s.cmp.ge     s2, s8, s3
    v.extract    s3, v11, #10
    s.or         s8, s6, s7
    s.movz       s6, #0
    v.insert     v2, s2, #8
    v.extract    s2, v0, #10
    s.shli       s7, s3, #32
    s.cmp.ge     s3, s8, s6
    v.extract    s6, v11, #11
    s.or         s8, s2, s7
    s.movz       s2, #0
    v.insert     v2, s3, #9
    v.extract    s3, v0, #11
    s.shli       s7, s6, #32
    s.cmp.ge     s6, s8, s2
    v.extract    s2, v11, #12
    s.or         s8, s3, s7
    s.movz       s3, #0
    v.insert     v2, s6, #10
    v.extract    s6, v0, #12
    s.shli       s7, s2, #32
    s.cmp.ge     s2, s8, s3
    v.extract    s3, v11, #13
    s.or         s8, s6, s7
    s.movz       s6, #0
    v.insert     v2, s2, #11
    v.extract    s2, v0, #13
    s.shli       s7, s3, #32
    s.cmp.ge     s3, s8, s6
    v.extract    s6, v11, #14
    s.or         s8, s2, s7
    s.movz       s2, #0
    v.insert     v2, s3, #12
    v.extract    s3, v0, #14
    s.shli       s7, s6, #32
    s.cmp.ge     s6, s8, s2
    v.extract    s2, v11, #15
    v.extract    s8, v11, #0
    s.or         s9, s3, s7
    s.movz       s3, #0
    v.insert     v2, s6, #13
    v.extract    s6, v0, #15
    s.shli       s7, s2, #32
    v.extract    s2, v0, #0
    s.shli       s10, s8, #32
    s.cmp.ge     s8, s9, s3
    v.extract    s3, v11, #1
    s.or         s9, s6, s7
    s.movz       s6, #0
    s.or         s7, s2, s10
    s.movz       s2, #15
    v.insert     v2, s8, #14
    v.movi       v5, #0
    v.extract    s8, v0, #1
    s.shli       s10, s3, #32
    s.cmp.ge     s3, s9, s6
    s.cmp.lt     s6, s7, s2
    v.extract    s7, v11, #2
    s.or         s9, s8, s10
    v.insert     v2, s3, #15
    v.insert     v5, s6, #0
    v.extract    s3, v0, #2
    s.shli       s6, s7, #32
    s.cmp.lt     s7, s9, s2
    v.extract    s8, v11, #3
    s.or         s9, s3, s6
    v.insert     v5, s7, #1
    v.extract    s3, v0, #3
    s.shli       s6, s8, #32
    s.cmp.lt     s7, s9, s2
    v.extract    s8, v11, #4
    s.or         s9, s3, s6
    v.insert     v5, s7, #2
    v.extract    s3, v0, #4
    s.shli       s6, s8, #32
    s.cmp.lt     s7, s9, s2
    v.extract    s8, v11, #5
    s.or         s9, s3, s6
    v.insert     v5, s7, #3
    v.extract    s3, v0, #5
    s.shli       s6, s8, #32
    s.cmp.lt     s7, s9, s2
    v.extract    s2, v11, #6
    s.or         s8, s3, s6
    s.movz       s3, #15
    v.insert     v5, s7, #4
    v.extract    s6, v0, #6
    s.shli       s7, s2, #32
    s.cmp.lt     s2, s8, s3
    s.or         s3, s6, s7
    s.movz       s6, #15
    v.insert     v5, s2, #5
    s.cmp.lt     s2, s3, s6
    v.movi       v9, #0
    v.extract    s3, v0, #7
    v.insert     v5, s2, #6
    v.cmp.ne     p1, v2, v9
    v.extract    s2, v11, #7
    v.extract    s6, v11, #8
    s.shli       s7, s2, #32
    s.movz       s2, #15
    s.or         s8, s3, s7
    v.extract    s3, v0, #8
    s.shli       s7, s6, #32
    s.cmp.lt     s6, s8, s2
    v.extract    s2, v11, #9
    s.or         s8, s3, s7
    s.movz       s3, #15
    v.insert     v5, s6, #7
    v.extract    s6, v0, #9
    s.shli       s7, s2, #32
    s.cmp.lt     s2, s8, s3
    v.extract    s3, v11, #10
    s.or         s8, s6, s7
    s.movz       s6, #15
    v.insert     v5, s2, #8
    v.extract    s2, v0, #10
    s.shli       s7, s3, #32
    s.cmp.lt     s3, s8, s6
    v.extract    s6, v11, #11
    s.or         s8, s2, s7
    s.movz       s2, #15
    v.insert     v5, s3, #9
    v.extract    s3, v0, #11
    s.shli       s7, s6, #32
    s.cmp.lt     s6, s8, s2
    v.extract    s2, v11, #12
    s.or         s8, s3, s7
    s.movz       s3, #15
    v.insert     v5, s6, #10
    v.extract    s6, v0, #12
    s.shli       s7, s2, #32
    s.cmp.lt     s2, s8, s3
    v.extract    s3, v11, #13
    s.or         s8, s6, s7
    s.movz       s6, #15
    v.insert     v5, s2, #11
    v.extract    s2, v0, #13
    s.shli       s7, s3, #32
    s.cmp.lt     s3, s8, s6
    v.extract    s6, v11, #14
    s.or         s8, s2, s7
    s.movz       s2, #15
    v.insert     v5, s3, #12
    v.extract    s3, v0, #14
    s.shli       s7, s6, #32
    s.cmp.lt     s6, s8, s2
    v.extract    s2, v11, #15
    v.movi       v2, #-2
    s.or         s8, s3, s7
    s.movz       s3, #15
    v.insert     v5, s6, #13
    v.extract    s6, v0, #15
    s.shli       s7, s2, #32
    s.cmp.lt     s2, s8, s3
    v.add        v0, v8, v2
    s.or         s3, s6, s7
    s.movz       s6, #15
    v.insert     v5, s2, #14
    s.cmp.lt     s2, s3, s6
    v.extract    s3, v0, #0
    v.insert     v5, s2, #15
    v.movi       v2, #0
    v.movi       v9, #-24576
    s.shli       s2, s3, #32
    v.extract    s3, v0, #1
    s.ashri      s6, s2, #32
    v.cmp.ne     p2, v5, v2
    v.add        v2, v4, v9
    v.movi       v5, #0
    v.movi       v9, #0
    s.shli       s2, s3, #32
    p.and        p3, p1, p2
    s.lshri      s3, s6, #32
    v.extract    s7, v0, #2
    s.ashri      s8, s2, #32
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v10, [s4, v2]              // index is in elements (ISA sec 9.1)
    v.insert     v5, s6, #0
    v.insert     v9, s3, #0
    s.shli       s2, s7, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v0, #3
    s.ashri      s7, s2, #32
    v.insert     v5, s8, #1
    v.insert     v9, s3, #1
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v0, #4
    s.ashri      s8, s2, #32
    v.insert     v5, s7, #2
    v.insert     v9, s3, #2
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v0, #5
    s.ashri      s7, s2, #32
    v.insert     v5, s8, #3
    v.insert     v9, s3, #3
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v0, #6
    s.ashri      s8, s2, #32
    v.insert     v5, s7, #4
    v.insert     v9, s3, #4
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    s.ashri      s6, s2, #32
    v.insert     v5, s8, #5
    v.insert     v9, s3, #5
    vf.cvt.bf16.f32 v2, v10
    s.lshri      s2, s6, #32
    v.insert     v5, s6, #6
    v.movi       v10, #0
    v.insert     v9, s2, #6
    @p3 v.sel        v11, v2, v10
    v.extract    s2, v0, #7
    vf.mul       v2, v11, v3
    s.shli       s3, s2, #32
    v.extract    s2, v0, #8
    s.ashri      s6, s3, #32
    s.shli       s3, s2, #32
    s.lshri      s2, s6, #32
    v.extract    s7, v0, #9
    s.ashri      s8, s3, #32
    v.insert     v5, s6, #7
    v.insert     v9, s2, #7
    s.shli       s2, s7, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v0, #10
    s.ashri      s7, s2, #32
    v.insert     v5, s8, #8
    v.insert     v9, s3, #8
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v0, #11
    s.ashri      s8, s2, #32
    v.insert     v5, s7, #9
    v.insert     v9, s3, #9
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v0, #12
    s.ashri      s7, s2, #32
    v.insert     v5, s8, #10
    v.insert     v9, s3, #10
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v0, #13
    s.ashri      s8, s2, #32
    v.insert     v5, s7, #11
    v.insert     v9, s3, #11
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v0, #14
    s.ashri      s7, s2, #32
    v.insert     v5, s8, #12
    v.insert     v9, s3, #12
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v0, #15
    s.ashri      s8, s2, #32
    v.insert     v5, s7, #13
    v.insert     v9, s3, #13
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    s.ashri      s6, s2, #32
    v.insert     v5, s8, #14
    v.insert     v9, s3, #14
    s.lshri      s2, s6, #32
    v.insert     v5, s6, #15
    v.insert     v9, s2, #15
    s.movz       s2, #0
    v.extract    s3, v5, #0
    v.extract    s6, v9, #0
    v.extract    s7, v9, #1
    s.shli       s8, s6, #32
    v.movi       v0, #0
    s.or         s6, s3, s8
    v.extract    s3, v5, #1
    s.shli       s8, s7, #32
    s.cmp.ge     s7, s6, s2
    v.extract    s2, v9, #2
    s.or         s6, s3, s8
    s.movz       s3, #0
    v.insert     v0, s7, #0
    v.extract    s7, v5, #2
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s6, s3
    v.extract    s3, v9, #3
    s.or         s6, s7, s8
    s.movz       s7, #0
    v.insert     v0, s2, #1
    v.extract    s2, v5, #3
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s6, s7
    v.extract    s6, v9, #4
    s.or         s7, s2, s8
    s.movz       s2, #0
    v.insert     v0, s3, #2
    v.extract    s3, v5, #4
    s.shli       s8, s6, #32
    s.cmp.ge     s6, s7, s2
    v.extract    s2, v9, #5
    s.or         s7, s3, s8
    s.movz       s3, #0
    v.insert     v0, s6, #3
    v.extract    s6, v5, #5
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s7, s3
    v.extract    s3, v9, #6
    s.or         s7, s6, s8
    s.movz       s6, #0
    v.insert     v0, s2, #4
    v.extract    s2, v5, #6
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s7, s6
    v.extract    s6, v9, #7
    s.or         s7, s2, s8
    s.movz       s2, #0
    v.insert     v0, s3, #5
    v.extract    s3, v5, #7
    s.shli       s8, s6, #32
    s.cmp.ge     s6, s7, s2
    v.extract    s2, v9, #8
    s.or         s7, s3, s8
    s.movz       s3, #0
    v.insert     v0, s6, #6
    v.extract    s6, v5, #8
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s7, s3
    v.extract    s3, v9, #9
    s.or         s7, s6, s8
    s.movz       s6, #0
    v.insert     v0, s2, #7
    v.extract    s2, v5, #9
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s7, s6
    v.extract    s6, v9, #10
    s.or         s7, s2, s8
    s.movz       s2, #0
    v.insert     v0, s3, #8
    v.extract    s3, v5, #10
    s.shli       s8, s6, #32
    s.cmp.ge     s6, s7, s2
    v.extract    s2, v9, #11
    s.or         s7, s3, s8
    s.movz       s3, #0
    v.insert     v0, s6, #9
    v.extract    s6, v5, #11
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s7, s3
    v.extract    s3, v9, #12
    s.or         s7, s6, s8
    s.movz       s6, #0
    v.insert     v0, s2, #10
    v.extract    s2, v5, #12
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s7, s6
    v.extract    s6, v9, #13
    s.or         s7, s2, s8
    s.movz       s2, #0
    v.insert     v0, s3, #11
    v.extract    s3, v5, #13
    s.shli       s8, s6, #32
    s.cmp.ge     s6, s7, s2
    v.extract    s2, v9, #14
    s.or         s7, s3, s8
    s.movz       s3, #0
    v.insert     v0, s6, #12
    v.extract    s6, v5, #14
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s7, s3
    v.extract    s3, v9, #15
    v.extract    s7, v9, #0
    s.or         s9, s6, s8
    s.movz       s6, #0
    v.insert     v0, s2, #13
    v.extract    s2, v5, #15
    s.shli       s8, s3, #32
    v.extract    s3, v5, #0
    s.shli       s10, s7, #32
    s.cmp.ge     s7, s9, s6
    v.extract    s6, v9, #1
    s.or         s9, s2, s8
    s.movz       s2, #0
    s.or         s8, s3, s10
    s.movz       s3, #15
    v.insert     v0, s7, #14
    v.movi       v3, #0
    v.extract    s7, v5, #1
    s.shli       s10, s6, #32
    s.cmp.ge     s6, s9, s2
    s.cmp.lt     s2, s8, s3
    v.extract    s3, v9, #2
    s.or         s8, s7, s10
    s.movz       s7, #15
    v.insert     v0, s6, #15
    v.insert     v3, s2, #0
    v.extract    s2, v5, #2
    s.shli       s6, s3, #32
    s.cmp.lt     s3, s8, s7
    v.extract    s7, v9, #3
    s.or         s8, s2, s6
    s.movz       s2, #15
    v.insert     v3, s3, #1
    v.extract    s3, v5, #3
    s.shli       s6, s7, #32
    s.cmp.lt     s7, s8, s2
    v.extract    s2, v9, #4
    s.or         s8, s3, s6
    s.movz       s3, #15
    v.insert     v3, s7, #2
    v.extract    s6, v5, #4
    s.shli       s7, s2, #32
    s.cmp.lt     s2, s8, s3
    v.extract    s3, v9, #5
    s.or         s8, s6, s7
    s.movz       s6, #15
    v.insert     v3, s2, #3
    v.extract    s2, v5, #5
    s.shli       s7, s3, #32
    s.cmp.lt     s3, s8, s6
    v.extract    s6, v9, #6
    s.or         s8, s2, s7
    s.movz       s2, #15
    v.insert     v3, s3, #4
    v.extract    s3, v5, #6
    s.shli       s7, s6, #32
    s.cmp.lt     s6, s8, s2
    v.movi       v11, #0
    s.or         s2, s3, s7
    v.insert     v3, s6, #5
    v.cmp.ne     p1, v0, v11
    v.extract    s3, v9, #7
    s.movz       s6, #15
    v.extract    s7, v5, #7
    s.shli       s8, s3, #32
    s.cmp.lt     s3, s2, s6
    v.extract    s2, v9, #8
    s.or         s6, s7, s8
    s.movz       s7, #15
    v.insert     v3, s3, #6
    v.extract    s3, v5, #8
    s.shli       s8, s2, #32
    s.cmp.lt     s2, s6, s7
    v.extract    s6, v9, #9
    s.or         s7, s3, s8
    s.movz       s3, #15
    v.insert     v3, s2, #7
    v.extract    s2, v5, #9
    s.shli       s8, s6, #32
    s.cmp.lt     s6, s7, s3
    v.extract    s3, v9, #10
    s.or         s7, s2, s8
    s.movz       s2, #15
    v.insert     v3, s6, #8
    v.extract    s6, v5, #10
    s.shli       s8, s3, #32
    s.cmp.lt     s3, s7, s2
    v.extract    s2, v9, #11
    s.or         s7, s6, s8
    s.movz       s6, #15
    v.insert     v3, s3, #9
    v.extract    s3, v5, #11
    s.shli       s8, s2, #32
    s.cmp.lt     s2, s7, s6
    v.extract    s6, v9, #12
    s.or         s7, s3, s8
    s.movz       s3, #15
    v.insert     v3, s2, #10
    v.extract    s2, v5, #12
    s.shli       s8, s6, #32
    s.cmp.lt     s6, s7, s3
    v.extract    s3, v9, #13
    s.or         s7, s2, s8
    s.movz       s2, #15
    v.insert     v3, s6, #11
    v.extract    s6, v5, #13
    s.shli       s8, s3, #32
    s.cmp.lt     s3, s7, s2
    v.extract    s2, v9, #14
    s.or         s7, s6, s8
    s.movz       s6, #15
    v.insert     v3, s3, #12
    v.extract    s3, v5, #14
    s.shli       s8, s2, #32
    s.cmp.lt     s2, s7, s6
    v.extract    s6, v9, #15
    v.movi       v0, #-1
    s.or         s7, s3, s8
    s.movz       s3, #15
    v.insert     v3, s2, #13
    v.extract    s2, v5, #15
    s.shli       s8, s6, #32
    s.cmp.lt     s6, s7, s3
    v.add        v5, v8, v0
    s.or         s3, s2, s8
    s.movz       s2, #15
    v.insert     v3, s6, #14
    s.cmp.lt     s6, s3, s2
    v.extract    s2, v5, #0
    v.insert     v3, s6, #15
    v.movi       v0, #0
    v.movi       v9, #-16384
    s.shli       s3, s2, #32
    v.extract    s2, v5, #1
    s.ashri      s6, s3, #32
    v.cmp.ne     p2, v3, v0
    v.add        v0, v4, v9
    v.movi       v3, #0
    v.movi       v9, #0
    s.shli       s3, s2, #32
    p.and        p3, p1, p2
    s.lshri      s2, s6, #32
    v.extract    s7, v5, #2
    s.ashri      s8, s3, #32
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v11, [s4, v0]              // index is in elements (ISA sec 9.1)
    v.insert     v3, s6, #0
    v.insert     v9, s2, #0
    s.shli       s2, s7, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v5, #3
    s.ashri      s7, s2, #32
    v.insert     v3, s8, #1
    v.insert     v9, s3, #1
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v5, #4
    s.ashri      s8, s2, #32
    v.insert     v3, s7, #2
    v.insert     v9, s3, #2
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v5, #5
    s.ashri      s7, s2, #32
    v.insert     v3, s8, #3
    v.insert     v9, s3, #3
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v5, #6
    s.ashri      s8, s2, #32
    v.insert     v3, s7, #4
    v.insert     v9, s3, #4
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    s.ashri      s6, s2, #32
    v.insert     v3, s8, #5
    v.insert     v9, s3, #5
    vf.cvt.bf16.f32 v0, v11
    s.lshri      s2, s6, #32
    v.insert     v3, s6, #6
    @p3 v.sel        v11, v0, v10
    v.insert     v9, s2, #6
    vf.mul       v0, v11, v6
    v.extract    s2, v5, #7
    vf.add       v6, v2, v0
    s.shli       s3, s2, #32
    v.extract    s2, v5, #8
    s.ashri      s6, s3, #32
    s.shli       s3, s2, #32
    s.lshri      s2, s6, #32
    v.extract    s7, v5, #9
    s.ashri      s8, s3, #32
    v.insert     v3, s6, #7
    v.insert     v9, s2, #7
    s.shli       s2, s7, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v5, #10
    s.ashri      s7, s2, #32
    v.insert     v3, s8, #8
    v.insert     v9, s3, #8
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v5, #11
    s.ashri      s8, s2, #32
    v.insert     v3, s7, #9
    v.insert     v9, s3, #9
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v5, #12
    s.ashri      s7, s2, #32
    v.insert     v3, s8, #10
    v.insert     v9, s3, #10
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v5, #13
    s.ashri      s8, s2, #32
    v.insert     v3, s7, #11
    v.insert     v9, s3, #11
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v5, #14
    s.ashri      s7, s2, #32
    v.insert     v3, s8, #12
    v.insert     v9, s3, #12
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v5, #15
    s.ashri      s8, s2, #32
    v.insert     v3, s7, #13
    v.insert     v9, s3, #13
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    s.ashri      s6, s2, #32
    v.insert     v3, s8, #14
    v.insert     v9, s3, #14
    s.lshri      s2, s6, #32
    v.insert     v3, s6, #15
    v.insert     v9, s2, #15
    s.movz       s2, #0
    v.extract    s3, v3, #0
    v.extract    s6, v9, #0
    v.extract    s7, v9, #1
    s.shli       s8, s6, #32
    v.movi       v0, #0
    s.or         s6, s3, s8
    v.extract    s3, v3, #1
    s.shli       s8, s7, #32
    s.cmp.ge     s7, s6, s2
    v.extract    s2, v9, #2
    s.or         s6, s3, s8
    s.movz       s3, #0
    v.insert     v0, s7, #0
    v.extract    s7, v3, #2
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s6, s3
    v.extract    s3, v9, #3
    s.or         s6, s7, s8
    s.movz       s7, #0
    v.insert     v0, s2, #1
    v.extract    s2, v3, #3
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s6, s7
    v.extract    s6, v9, #4
    s.or         s7, s2, s8
    s.movz       s2, #0
    v.insert     v0, s3, #2
    v.extract    s3, v3, #4
    s.shli       s8, s6, #32
    s.cmp.ge     s6, s7, s2
    v.extract    s2, v9, #5
    s.or         s7, s3, s8
    s.movz       s3, #0
    v.insert     v0, s6, #3
    v.extract    s6, v3, #5
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s7, s3
    v.extract    s3, v9, #6
    s.or         s7, s6, s8
    s.movz       s6, #0
    v.insert     v0, s2, #4
    v.extract    s2, v3, #6
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s7, s6
    v.extract    s6, v9, #7
    s.or         s7, s2, s8
    s.movz       s2, #0
    v.insert     v0, s3, #5
    v.extract    s3, v3, #7
    s.shli       s8, s6, #32
    s.cmp.ge     s6, s7, s2
    v.extract    s2, v9, #8
    s.or         s7, s3, s8
    s.movz       s3, #0
    v.insert     v0, s6, #6
    v.extract    s6, v3, #8
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s7, s3
    v.extract    s3, v9, #9
    s.or         s7, s6, s8
    s.movz       s6, #0
    v.insert     v0, s2, #7
    v.extract    s2, v3, #9
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s7, s6
    v.extract    s6, v9, #10
    s.or         s7, s2, s8
    s.movz       s2, #0
    v.insert     v0, s3, #8
    v.extract    s3, v3, #10
    s.shli       s8, s6, #32
    s.cmp.ge     s6, s7, s2
    v.extract    s2, v9, #11
    s.or         s7, s3, s8
    s.movz       s3, #0
    v.insert     v0, s6, #9
    v.extract    s6, v3, #11
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s7, s3
    v.extract    s3, v9, #12
    s.or         s7, s6, s8
    s.movz       s6, #0
    v.insert     v0, s2, #10
    v.extract    s2, v3, #12
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s7, s6
    v.extract    s6, v9, #13
    s.or         s7, s2, s8
    s.movz       s2, #0
    v.insert     v0, s3, #11
    v.extract    s3, v3, #13
    s.shli       s8, s6, #32
    s.cmp.ge     s6, s7, s2
    v.extract    s2, v9, #14
    s.or         s7, s3, s8
    s.movz       s3, #0
    v.insert     v0, s6, #12
    v.extract    s6, v3, #14
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s7, s3
    v.extract    s3, v9, #15
    v.extract    s7, v9, #0
    s.or         s9, s6, s8
    s.movz       s6, #0
    v.insert     v0, s2, #13
    v.extract    s2, v3, #15
    s.shli       s8, s3, #32
    v.extract    s3, v3, #0
    s.shli       s10, s7, #32
    s.cmp.ge     s7, s9, s6
    v.extract    s6, v9, #1
    s.or         s9, s2, s8
    s.movz       s2, #0
    s.or         s8, s3, s10
    s.movz       s3, #15
    v.insert     v0, s7, #14
    v.movi       v2, #0
    v.extract    s7, v3, #1
    s.shli       s10, s6, #32
    s.cmp.ge     s6, s9, s2
    s.cmp.lt     s2, s8, s3
    v.extract    s3, v9, #2
    s.or         s8, s7, s10
    s.movz       s7, #15
    v.insert     v0, s6, #15
    v.insert     v2, s2, #0
    v.extract    s2, v3, #2
    s.shli       s6, s3, #32
    s.cmp.lt     s3, s8, s7
    v.extract    s7, v9, #3
    s.or         s8, s2, s6
    s.movz       s2, #15
    v.insert     v2, s3, #1
    v.extract    s3, v3, #3
    s.shli       s6, s7, #32
    s.cmp.lt     s7, s8, s2
    v.extract    s2, v9, #4
    s.or         s8, s3, s6
    s.movz       s3, #15
    v.insert     v2, s7, #2
    v.extract    s6, v3, #4
    s.shli       s7, s2, #32
    s.cmp.lt     s2, s8, s3
    v.extract    s3, v9, #5
    s.or         s8, s6, s7
    s.movz       s6, #15
    v.insert     v2, s2, #3
    v.extract    s2, v3, #5
    s.shli       s7, s3, #32
    s.cmp.lt     s3, s8, s6
    v.extract    s6, v9, #6
    s.or         s8, s2, s7
    s.movz       s2, #15
    v.insert     v2, s3, #4
    v.extract    s3, v3, #6
    s.shli       s7, s6, #32
    s.cmp.lt     s6, s8, s2
    v.movi       v5, #0
    s.or         s2, s3, s7
    v.insert     v2, s6, #5
    v.cmp.ne     p1, v0, v5
    v.extract    s3, v9, #7
    s.movz       s6, #15
    v.extract    s7, v3, #7
    s.shli       s8, s3, #32
    s.cmp.lt     s3, s2, s6
    v.extract    s2, v9, #8
    s.or         s6, s7, s8
    s.movz       s7, #15
    v.insert     v2, s3, #6
    v.extract    s3, v3, #8
    s.shli       s8, s2, #32
    s.cmp.lt     s2, s6, s7
    v.extract    s6, v9, #9
    s.or         s7, s3, s8
    s.movz       s3, #15
    v.insert     v2, s2, #7
    v.extract    s2, v3, #9
    s.shli       s8, s6, #32
    s.cmp.lt     s6, s7, s3
    v.extract    s3, v9, #10
    s.or         s7, s2, s8
    s.movz       s2, #15
    v.insert     v2, s6, #8
    v.extract    s6, v3, #10
    s.shli       s8, s3, #32
    s.cmp.lt     s3, s7, s2
    v.extract    s2, v9, #11
    s.or         s7, s6, s8
    s.movz       s6, #15
    v.insert     v2, s3, #9
    v.extract    s3, v3, #11
    s.shli       s8, s2, #32
    s.cmp.lt     s2, s7, s6
    v.extract    s6, v9, #12
    s.or         s7, s3, s8
    s.movz       s3, #15
    v.insert     v2, s2, #10
    v.extract    s2, v3, #12
    s.shli       s8, s6, #32
    s.cmp.lt     s6, s7, s3
    v.extract    s3, v9, #13
    s.or         s7, s2, s8
    s.movz       s2, #15
    v.insert     v2, s6, #11
    v.extract    s6, v3, #13
    s.shli       s8, s3, #32
    s.cmp.lt     s3, s7, s2
    v.extract    s2, v9, #14
    s.or         s7, s6, s8
    s.movz       s6, #15
    v.insert     v2, s3, #12
    v.extract    s3, v3, #14
    s.shli       s8, s2, #32
    s.cmp.lt     s2, s7, s6
    v.extract    s6, v9, #15
    s.or         s7, s3, s8
    s.movz       s3, #15
    v.insert     v2, s2, #13
    v.extract    s2, v3, #15
    s.shli       s8, s6, #32
    s.cmp.lt     s6, s7, s3
    s.or         s3, s2, s8
    s.movz       s2, #15
    v.insert     v2, s6, #14
    s.cmp.lt     s6, s3, s2
    v.extract    s2, v8, #0
    v.insert     v2, s6, #15
    v.movi       v0, #0
    v.movi       v3, #-8192
    s.shli       s3, s2, #32
    v.extract    s2, v8, #1
    s.ashri      s6, s3, #32
    v.cmp.ne     p2, v2, v0
    v.add        v0, v4, v3
    v.movi       v2, #0
    v.movi       v3, #0
    s.shli       s3, s2, #32
    p.and        p3, p1, p2
    s.lshri      s2, s6, #32
    v.extract    s7, v8, #2
    s.ashri      s8, s3, #32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s4, v0]               // index is in elements (ISA sec 9.1)
    v.insert     v2, s6, #0
    v.insert     v3, s2, #0
    s.shli       s2, s7, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v8, #3
    s.ashri      s7, s2, #32
    v.insert     v2, s8, #1
    v.insert     v3, s3, #1
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v8, #4
    s.ashri      s8, s2, #32
    v.insert     v2, s7, #2
    v.insert     v3, s3, #2
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v8, #5
    s.ashri      s7, s2, #32
    v.insert     v2, s8, #3
    v.insert     v3, s3, #3
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v8, #6
    s.ashri      s8, s2, #32
    v.insert     v2, s7, #4
    v.insert     v3, s3, #4
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    s.ashri      s6, s2, #32
    v.insert     v2, s8, #5
    v.insert     v3, s3, #5
    s.lshri      s2, s6, #32
    v.insert     v2, s6, #6
    v.insert     v3, s2, #6
    vf.cvt.bf16.f32 v0, v4
    v.extract    s2, v8, #7
    @p3 v.sel        v4, v0, v10
    s.shli       s3, s2, #32
    vf.mul       v0, v4, v7
    s.ashri      s2, s3, #32
    vf.add       v4, v6, v0
    v.extract    s3, v8, #8
    s.lshri      s6, s2, #32
    s.shli       s7, s3, #32
    v.extract    s3, v8, #9
    s.ashri      s8, s7, #32
    v.insert     v2, s2, #7
    v.insert     v3, s6, #7
    s.shli       s2, s3, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v8, #10
    s.ashri      s7, s2, #32
    v.insert     v2, s8, #8
    v.insert     v3, s3, #8
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v8, #11
    s.ashri      s8, s2, #32
    v.insert     v2, s7, #9
    v.insert     v3, s3, #9
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v8, #12
    s.ashri      s7, s2, #32
    v.insert     v2, s8, #10
    v.insert     v3, s3, #10
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v8, #13
    s.ashri      s8, s2, #32
    v.insert     v2, s7, #11
    v.insert     v3, s3, #11
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    v.extract    s6, v8, #14
    s.ashri      s7, s2, #32
    v.insert     v2, s8, #12
    v.insert     v3, s3, #12
    s.shli       s2, s6, #32
    s.lshri      s3, s7, #32
    v.extract    s6, v8, #15
    s.ashri      s8, s2, #32
    v.insert     v2, s7, #13
    v.insert     v3, s3, #13
    s.shli       s2, s6, #32
    s.lshri      s3, s8, #32
    s.ashri      s6, s2, #32
    v.insert     v2, s8, #14
    v.insert     v3, s3, #14
    s.lshri      s2, s6, #32
    v.insert     v2, s6, #15
    v.insert     v3, s2, #15
    s.movz       s2, #0
    v.extract    s3, v2, #0
    v.extract    s6, v3, #0
    v.extract    s7, v3, #1
    s.shli       s8, s6, #32
    v.movi       v0, #0
    s.or         s6, s3, s8
    v.extract    s3, v2, #1
    s.shli       s8, s7, #32
    s.cmp.ge     s7, s6, s2
    v.extract    s2, v3, #2
    s.or         s6, s3, s8
    s.movz       s3, #0
    v.insert     v0, s7, #0
    v.extract    s7, v2, #2
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s6, s3
    v.extract    s3, v3, #3
    s.or         s6, s7, s8
    s.movz       s7, #0
    v.insert     v0, s2, #1
    v.extract    s2, v2, #3
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s6, s7
    v.extract    s6, v3, #4
    s.or         s7, s2, s8
    s.movz       s2, #0
    v.insert     v0, s3, #2
    v.extract    s3, v2, #4
    s.shli       s8, s6, #32
    s.cmp.ge     s6, s7, s2
    v.extract    s2, v3, #5
    s.or         s7, s3, s8
    s.movz       s3, #0
    v.insert     v0, s6, #3
    v.extract    s6, v2, #5
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s7, s3
    v.extract    s3, v3, #6
    s.or         s7, s6, s8
    s.movz       s6, #0
    v.insert     v0, s2, #4
    v.extract    s2, v2, #6
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s7, s6
    v.extract    s6, v3, #7
    s.or         s7, s2, s8
    s.movz       s2, #0
    v.insert     v0, s3, #5
    v.extract    s3, v2, #7
    s.shli       s8, s6, #32
    s.cmp.ge     s6, s7, s2
    v.extract    s2, v3, #8
    s.or         s7, s3, s8
    s.movz       s3, #0
    v.insert     v0, s6, #6
    v.extract    s6, v2, #8
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s7, s3
    v.extract    s3, v3, #9
    s.or         s7, s6, s8
    s.movz       s6, #0
    v.insert     v0, s2, #7
    v.extract    s2, v2, #9
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s7, s6
    v.extract    s6, v3, #10
    s.or         s7, s2, s8
    s.movz       s2, #0
    v.insert     v0, s3, #8
    v.extract    s3, v2, #10
    s.shli       s8, s6, #32
    s.cmp.ge     s6, s7, s2
    v.extract    s2, v3, #11
    s.or         s7, s3, s8
    s.movz       s3, #0
    v.insert     v0, s6, #9
    v.extract    s6, v2, #11
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s7, s3
    v.extract    s3, v3, #12
    s.or         s7, s6, s8
    s.movz       s6, #0
    v.insert     v0, s2, #10
    v.extract    s2, v2, #12
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s7, s6
    v.extract    s6, v3, #13
    s.or         s7, s2, s8
    s.movz       s2, #0
    v.insert     v0, s3, #11
    v.extract    s3, v2, #13
    s.shli       s8, s6, #32
    s.cmp.ge     s6, s7, s2
    v.extract    s2, v3, #14
    s.or         s7, s3, s8
    s.movz       s3, #0
    v.insert     v0, s6, #12
    v.extract    s6, v2, #14
    s.shli       s8, s2, #32
    s.cmp.ge     s2, s7, s3
    v.extract    s3, v3, #15
    v.extract    s7, v3, #0
    s.or         s9, s6, s8
    s.movz       s6, #0
    v.insert     v0, s2, #13
    v.extract    s2, v2, #15
    s.shli       s8, s3, #32
    v.extract    s3, v2, #0
    s.shli       s10, s7, #32
    s.cmp.ge     s7, s9, s6
    v.extract    s6, v3, #1
    s.or         s9, s2, s8
    s.movz       s2, #0
    s.or         s8, s3, s10
    s.movz       s3, #15
    v.insert     v0, s7, #14
    v.movi       v5, #0
    v.extract    s7, v2, #1
    s.shli       s10, s6, #32
    s.cmp.ge     s6, s9, s2
    s.cmp.lt     s2, s8, s3
    v.extract    s3, v3, #2
    s.or         s8, s7, s10
    s.movz       s7, #15
    v.insert     v0, s6, #15
    v.insert     v5, s2, #0
    v.extract    s2, v2, #2
    s.shli       s6, s3, #32
    s.cmp.lt     s3, s8, s7
    v.extract    s7, v3, #3
    s.or         s8, s2, s6
    s.movz       s2, #15
    v.insert     v5, s3, #1
    v.extract    s3, v2, #3
    s.shli       s6, s7, #32
    s.cmp.lt     s7, s8, s2
    v.extract    s2, v3, #4
    s.or         s8, s3, s6
    s.movz       s3, #15
    v.insert     v5, s7, #2
    v.extract    s6, v2, #4
    s.shli       s7, s2, #32
    s.cmp.lt     s2, s8, s3
    v.extract    s3, v3, #5
    s.or         s8, s6, s7
    s.movz       s6, #15
    v.insert     v5, s2, #3
    v.extract    s2, v2, #5
    s.shli       s7, s3, #32
    s.cmp.lt     s3, s8, s6
    v.extract    s6, v3, #6
    s.or         s8, s2, s7
    s.movz       s2, #15
    v.insert     v5, s3, #4
    v.extract    s3, v2, #6
    s.shli       s7, s6, #32
    s.cmp.lt     s6, s8, s2
    v.movi       v6, #0
    s.or         s2, s3, s7
    v.insert     v5, s6, #5
    v.cmp.ne     p1, v0, v6
    v.extract    s3, v3, #7
    s.movz       s6, #15
    v.extract    s7, v2, #7
    s.shli       s8, s3, #32
    s.cmp.lt     s3, s2, s6
    v.extract    s2, v3, #8
    s.or         s6, s7, s8
    s.movz       s7, #15
    v.insert     v5, s3, #6
    v.extract    s3, v2, #8
    s.shli       s8, s2, #32
    s.cmp.lt     s2, s6, s7
    v.extract    s6, v3, #9
    s.or         s7, s3, s8
    s.movz       s3, #15
    v.insert     v5, s2, #7
    v.extract    s2, v2, #9
    s.shli       s8, s6, #32
    s.cmp.lt     s6, s7, s3
    v.extract    s3, v3, #10
    s.or         s7, s2, s8
    s.movz       s2, #15
    v.insert     v5, s6, #8
    v.extract    s6, v2, #10
    s.shli       s8, s3, #32
    s.cmp.lt     s3, s7, s2
    v.extract    s2, v3, #11
    s.or         s7, s6, s8
    s.movz       s6, #15
    v.insert     v5, s3, #9
    v.extract    s3, v2, #11
    s.shli       s8, s2, #32
    s.cmp.lt     s2, s7, s6
    v.extract    s6, v3, #12
    s.or         s7, s3, s8
    s.movz       s3, #15
    v.insert     v5, s2, #10
    v.extract    s2, v2, #12
    s.shli       s8, s6, #32
    s.cmp.lt     s6, s7, s3
    v.extract    s3, v3, #13
    s.or         s7, s2, s8
    s.movz       s2, #15
    v.insert     v5, s6, #11
    v.extract    s6, v2, #13
    s.shli       s8, s3, #32
    s.cmp.lt     s3, s7, s2
    v.extract    s2, v3, #14
    s.or         s7, s6, s8
    s.movz       s6, #15
    v.insert     v5, s3, #12
    v.extract    s3, v2, #14
    s.shli       s8, s2, #32
    s.cmp.lt     s2, s7, s6
    v.extract    s6, v3, #15
    s.or         s7, s3, s8
    s.movz       s3, #15
    v.insert     v5, s2, #13
    v.extract    s2, v2, #15
    s.shli       s8, s6, #32
    s.cmp.lt     s6, s7, s3
    s.or         s3, s2, s8
    s.movz       s2, #15
    v.insert     v5, s6, #14
    s.cmp.lt     s6, s3, s2
    v.movi       v0, #0
    v.insert     v5, s6, #15
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    .li       s1, #1069066811
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p2, v5, v0
    p.and        p3, p1, p2
    s.add        s1, s4, s2                      // &in_ptr0[...]
    .li       s3, #1060205080
    v.splat      v0, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s1, #0]
    .li       s1, #1065353216
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s1, s5, s2                      // &out_ptr1[...]
    vf.cvt.bf16.f32 v7, v3
    @p3 v.sel        v3, v7, v10
    vf.mul       v7, v3, v1
    vf.add       v1, v4, v7
    vf.neg       v3, v1
    vf.mul       v4, v3, v2
    v.exp2.approx v7, v4                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v3, v2, v4                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v0
    vf.fma       v0, v7, v2, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v2, v0, v7
    vf.add       v0, v2, v5
    v.rcp.approx v2, v0                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v0, v2, v6
    vf.fms       v4, v2, v3, v2
    vf.neg       v3, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v4, v3, v2
    vf.mul       v2, v1, v4                      // a/y: faithful quotient
    vf.fms       v3, v2, v0, v1
    vf.fms       v0, v3, v4, v2
    vf.neg       v1, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v2
    vf.cvt.f32.bf16 v1, v0
    v.st.h       [s1, #0], v1
__rctx_next:
    exit
