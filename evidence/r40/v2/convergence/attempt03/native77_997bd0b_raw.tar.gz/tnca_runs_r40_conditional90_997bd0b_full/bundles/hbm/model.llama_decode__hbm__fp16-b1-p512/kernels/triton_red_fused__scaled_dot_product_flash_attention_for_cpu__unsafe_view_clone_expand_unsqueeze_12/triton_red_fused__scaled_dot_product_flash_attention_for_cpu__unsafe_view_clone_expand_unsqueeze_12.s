    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    v.movi       v2, #6
    v.sub        v3, v1, v0
    v.cmp.lt     p1, v0, v1
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p1 v.sel        v4, v3, v0
    s.movz       s3, #1
    v.iota       v3                              // arange(0, VLEN)
    v.lshr       v5, v4, v2
    v.splat      v2, s3
    v.movi       v4, #0
    v.sub        v6, v1, v5
    v.cmp.lt     p2, v3, v2
    v.sub        v2, v4, v0
    @p1 v.sel        v3, v6, v5
    s.ld.d       s3, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.cmp.lt     p1, v0, v4
    @p1 v.sel        v5, v2, v0
    v.movi       v0, #63
    s.movz       s5, #1
    v.movi       v2, #64
    v.and        v6, v5, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v5, s5
    v.sub        v7, v1, v2
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v9, [s2, v3]              // index is in elements (ISA sec 9.1)
    v.sub        v10, v4, v2
    s.movz       s2, #0
    v.cmp.lt     p2, v2, v1
    v.sub        v1, v4, v6
    v.cmp.lt     p3, v0, v5
    v.movi       v0, #0
    v.cmp.lt     p4, v2, v4
    s.movz       s5, #513
    s.movz       s6, #16
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #1
    @p2 v.sel        v5, v7, v2
    v.movi       v5, #1
    @p4 v.sel        v5, v10, v2
    @p1 v.sel        v2, v1, v6
    s.addi       s7, s2, #0
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v1, #0
    v.cmp.ne     p1, v9, v8
    s.ld.d       s8, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s9, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v5, [s3, v3]               // index is in elements (ISA sec 9.1)
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    v.extract    s1, v5, #0
    v.movi       v6, #0
    v.splat      v7, s1
    v.movi       v8, #2
    v.sub        v9, v6, v3
    v.rcp.approx v10, v7                         // ISA 8.8: <= 2**-22 relative
    v.cmp.lt     p2, v3, v6
    @p2 v.sel        v11, v9, v3
    v.movi       v9, #513
    v.splat      v12, s7
    v.lshr       v13, v11, v8
    v.mul        v8, v3, v9
    s.movz       s1, #32832
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v11, v6, v13
    v.extract    s1, v8, #0
    v.add        v8, v12, v4
    @p2 v.sel        v12, v11, v13
    v.splat      v11, s1
    v.movi       v13, #64
    v.movi       v14, #513
    v.extract    s1, v2, #0
    v.mul        v15, v12, v9
    .li       s3, #1065353216
    v.splat      v9, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v12, v8, v11
    v.mul        v11, v8, v13
    v.splat      v13, s1
    v.cmp.lt     p2, v8, v14
    v.extract    s1, v15, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s2, v12]              // index is in elements (ISA sec 9.1)
    v.add        v12, v13, v11
    v.splat      v11, s1
    v.movi       v13, #1
    v.movi       v14, #0
    vf.fms       v15, v7, v10, v9
    v.add        v7, v12, v11
    @p1 v.sel        v9, v13, v14
    v.movi       v11, #0
    v.movi       v12, #1
    vf.fms       v13, v10, v15, v10
    v.movi       v14, #0
    v.cmp.eq     p3, v9, v11
    v.movi       v9, #0
    @p3 v.sel        v11, v12, v14
    vf.neg       v12, v13                        // Newton step: r0*(2 - x*r0)
    v.movi       v13, #4
    v.extract    s1, v11, #0
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.h v11, [s8, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s1
    vf.cmp.o     p3, v12, v12
    @p3 v.sel        v14, v12, v10
    v.sub        v10, v6, v13
    v.cmp.lt     p3, v13, v6
    vf.mul       v6, v8, v14                     // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #64
    v.cmp.ne     p4, v7, v9
    v.movi       v7, #0
    v.movi       v8, #1
    @p4 v.sel        v8, v0, v6
    s.add        s1, s7, s6
    s.movz       s3, #1
    vf.cvt.f16.f32 v6, v11
    @p3 v.sel        v9, v10, v13
    s.movz       s10, #32832
    vf.mul       v9, v8, v6
    vf.add       v6, v1, v9
    @p2 v.sel        v8, v6, v1
    v.mov        v7, v8
    v.mov        v1, v7
    s.mov        s7, s1
    br.nz        s3, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #1                      // element offset -> bytes (x2)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s9, s2                      // &out_ptr1[...]
    vf.cvt.f32.f16 v3, v2
    v.cmp.lt     p1, v0, v1
    @p1 v.st.h       [s1, #0], v3
__rctx_next:
    exit
