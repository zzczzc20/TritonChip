# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph

def get_raw_stream(_):
    return 0


aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /tmp/torchinductor_zhongchun/wx/cwxuyqhyrapv4o5saurhf2uwccabtfjmp7ube5onixl6afltasai.py
# Topologically Sorted Source Nodes: [x, rms_norm], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   rms_norm => add, convert_element_type, convert_element_type_1, mean, mul, mul_1, pow_1, rsqrt
#   x => embedding
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 512][512, 1]cpu" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[32000, 1024][1024, 1]cpu" = PlaceHolder[target=arg0_1]
#   %buf0 : Tensor "f32[1, 512, 1][512, 1, 512]cpu" = PlaceHolder[target=buf0]
#   %arg4_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg4_1]
#   %embedding : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [2], True), kwargs = {})
#   %add : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean, 9.999999747378752e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg4_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_1, torch.float16), kwargs = {})
#   return %buf0,%convert_element_type_1
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 512, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 4096, 'r0_': 2099200}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 512
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tl.device_assert((0 <= tmp0) & (tmp0 < 32000), "index out of bounds: 0 <= tmp0 < 32000")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1024*tmp0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp17 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 32000), "index out of bounds: 0 <= tmp0 < 32000")
        tmp9 = tl.load(in_ptr1 + (r0_1 + 1024*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp9.to(tl.float32)
        tmp11 = tl.full([1], 1024.0, tl.float32)
        tmp12 = (tmp6 / tmp11)
        tmp13 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp14 = tmp12 + tmp13
        tmp15 = libdevice.rsqrt(tmp14)
        tmp16 = tmp10 * tmp15
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp16 * tmp18
        tmp20 = tmp19.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 1024*x0), tmp20, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/2i/c2i4ejmlsdmkzwtatcennxozfsow65uqxeo6sikguzlgbj2y2sd7.py
# Topologically Sorted Source Nodes: [x, rms_norm, linear], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear => mm, permute, view
#   rms_norm => add, convert_element_type, convert_element_type_1, mean, mul, mul_1, pow_1, rsqrt
#   x => embedding
# Graph fragment:
#   %convert_element_type_1 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu" = PlaceHolder[target=convert_element_type_1]
#   %arg5_1 : Tensor "f16[1024, 1024][1024, 1]cpu" = PlaceHolder[target=arg5_1]
#   %embedding : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [2], True), kwargs = {})
#   %add : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean, 9.999999747378752e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg4_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_1, torch.float16), kwargs = {})
#   %view : Tensor "f16[512, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_1, [512, 1024]), kwargs = {})
#   %permute : Tensor "f16[1024, 1024][1, 1024]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg5_1, [1, 0]), kwargs = {})
#   %mm : Tensor "f16[512, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view, %permute), kwargs = {})
#   return %mm
triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1 = async_compile.triton('triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 512
    N = 1024
    K = 1024
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 1024
    stride_ak = 1
    stride_bk = 1
    stride_bn = 1024

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 1024*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 1024*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 1024*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 1024*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/yw/cywrwljwhdh66xyek22mhg5m22lpk4mti2szrlvs2pnbxa7peot6.py
# Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_1 => mm_1, permute_2, view_3
# Graph fragment:
#   %convert_element_type_1 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu" = PlaceHolder[target=convert_element_type_1]
#   %arg6_1 : Tensor "f16[256, 1024][1024, 1]cpu" = PlaceHolder[target=arg6_1]
#   %view_3 : Tensor "f16[512, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_1, [512, 1024]), kwargs = {})
#   %permute_2 : Tensor "f16[1024, 256][1, 1024]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg6_1, [1, 0]), kwargs = {})
#   %mm_1 : Tensor "f16[512, 256][256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_3, %permute_2), kwargs = {})
#   return %mm_1
triton_tem_fused_mm_t_view_2 = async_compile.triton('triton_tem_fused_mm_t_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_2', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_2(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 512
    N = 256
    K = 1024
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 1024
    stride_ak = 1
    stride_bk = 1
    stride_bn = 1024

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 1024*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 256*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 1024*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 256*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/h7/ch7vgxe3k3dpgt3jpgne7qtroydim3udgatjgwbxvkcwcxg6qwij.py
# Topologically Sorted Source Nodes: [linear, view, q, chunk, neg], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
# Source node to ATen node mapping:
#   chunk => split
#   linear => view_1
#   neg => neg
#   q => permute_1
#   view => view_2
# Graph fragment:
#   %mm : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm]
#   %view_1 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 512, 1024]), kwargs = {})
#   %view_2 : Tensor "f16[1, 512, 16, 64][524288, 1024, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 512, 16, 64]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_1, 32, -1), kwargs = {})
#   %neg : Tensor "f16[1, 16, 512, 32][262144, 32, 512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_1,), kwargs = {})
#   return %neg
triton_poi_fused__unsafe_view_neg_split_transpose_view_3 = async_compile.triton('triton_poi_fused__unsafe_view_neg_split_transpose_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_neg_split_transpose_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_neg_split_transpose_view_3(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 32)
    x1 = ((xindex // 32) % 512)
    x2 = xindex // 16384
    x3 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (32 + x0 + 64*x2 + 1024*x1), None).to(tl.float32)
    tmp1 = -tmp0
    tl.store(out_ptr0 + (x0 + 64*x3), tmp1, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/hc/chcuhb7nybhqh5uinnbsjpanv5w3ay5kjailt2c57jg5kofnbode.py
# Topologically Sorted Source Nodes: [linear, view, q, chunk, neg, cat], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   cat => cat
#   chunk => split
#   linear => view_1
#   neg => neg
#   q => permute_1
#   view => view_2
# Graph fragment:
#   %mm : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm]
#   %view_1 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 512, 1024]), kwargs = {})
#   %view_2 : Tensor "f16[1, 512, 16, 64][524288, 1024, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 512, 16, 64]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_1, 32, -1), kwargs = {})
#   %neg : Tensor "f16[1, 16, 512, 32][262144, 32, 512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_1,), kwargs = {})
#   %cat : Tensor "f16[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %getitem], -1), kwargs = {})
#   return %buf5
triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4 = async_compile.triton('triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1572864}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 262144
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 32)
    x1 = ((xindex // 32) % 512)
    x2 = xindex // 16384
    x3 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (x0 + 64*x2 + 1024*x1), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 64*x3), tmp0, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/j7/cj7stqrrdsenwtq7gzoklm2cqyqong32v6rgkakvp26jfq6zymmw.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
# Source node to ATen node mapping:
#   chunk_1 => split_1
#   k => permute_3
#   linear_1 => view_4
#   neg_1 => neg_1
#   view_1 => view_5
# Graph fragment:
#   %mm_1 : Tensor "f16[512, 256][256, 1]cpu" = PlaceHolder[target=mm_1]
#   %view_4 : Tensor "f16[1, 512, 256][131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 512, 256]), kwargs = {})
#   %view_5 : Tensor "f16[1, 512, 4, 64][131072, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 512, 4, 64]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %split_1 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_3, 32, -1), kwargs = {})
#   %neg_1 : Tensor "f16[1, 4, 512, 32][65536, 32, 128, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_3,), kwargs = {})
#   return %neg_1
triton_poi_fused__unsafe_view_neg_split_transpose_view_5 = async_compile.triton('triton_poi_fused__unsafe_view_neg_split_transpose_view_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 65536}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_neg_split_transpose_view_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 393216}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_neg_split_transpose_view_5(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 65536
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 32)
    x1 = ((xindex // 32) % 512)
    x2 = xindex // 16384
    x3 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (32 + x0 + 64*x2 + 256*x1), None).to(tl.float32)
    tmp1 = -tmp0
    tl.store(out_ptr0 + (x0 + 64*x3), tmp1, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/yl/cylwubectqhlswxr7ycz7dvpftqsc5o2d3gmquqbk77voj2ut7m2.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1, cat_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   cat_1 => cat_1
#   chunk_1 => split_1
#   k => permute_3
#   linear_1 => view_4
#   neg_1 => neg_1
#   view_1 => view_5
# Graph fragment:
#   %mm_1 : Tensor "f16[512, 256][256, 1]cpu" = PlaceHolder[target=mm_1]
#   %view_4 : Tensor "f16[1, 512, 256][131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 512, 256]), kwargs = {})
#   %view_5 : Tensor "f16[1, 512, 4, 64][131072, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 512, 4, 64]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %split_1 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_3, 32, -1), kwargs = {})
#   %neg_1 : Tensor "f16[1, 4, 512, 32][65536, 32, 128, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_3,), kwargs = {})
#   %cat_1 : Tensor "f16[1, 4, 512, 64][131072, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %getitem_2], -1), kwargs = {})
#   return %buf8
triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6 = async_compile.triton('triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 65536}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 393216}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 65536
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 32)
    x1 = ((xindex // 32) % 512)
    x2 = xindex // 16384
    x3 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (x0 + 64*x2 + 256*x1), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 64*x3), tmp0, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/w3/cw37jtyf2vgcnyshav4ltvalrmh52cmquy6heythycxzzkde4bgg.py
# Topologically Sorted Source Nodes: [linear, view, q, linear_1, view_1, k, mul, mul_1, q_1, o, mul_2, mul_3, k_1, getitem_4, expand, k_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   expand => expand
#   getitem_4 => unsqueeze
#   k => permute_3
#   k_1 => add_2
#   k_2 => clone, view_9
#   linear => view_1
#   linear_1 => view_4
#   mul => mul_2
#   mul_1 => mul_3
#   mul_2 => mul_4
#   mul_3 => mul_5
#   o => convert_element_type_8, convert_element_type_9, mul_6, mul_7, permute_6
#   q => permute_1
#   q_1 => add_1
#   view => view_2
#   view_1 => view_5
# Graph fragment:
#   %mm : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm]
#   %arg2_1 : Tensor "f16[512, 64][64, 1]cpu" = PlaceHolder[target=arg2_1]
#   %cat : Tensor "f16[1, 16, 512, 64][524288, 32768, 64, 1]cpu" = PlaceHolder[target=cat]
#   %arg3_1 : Tensor "f16[512, 64][64, 1]cpu" = PlaceHolder[target=arg3_1]
#   %mm_1 : Tensor "f16[512, 256][256, 1]cpu" = PlaceHolder[target=mm_1]
#   %cat_1 : Tensor "f16[1, 4, 512, 64][131072, 32768, 64, 1]cpu" = PlaceHolder[target=cat_1]
#   %view_1 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 512, 1024]), kwargs = {})
#   %view_2 : Tensor "f16[1, 512, 16, 64][524288, 1024, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 512, 16, 64]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %view_4 : Tensor "f16[1, 512, 256][131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 512, 256]), kwargs = {})
#   %view_5 : Tensor "f16[1, 512, 4, 64][131072, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 512, 4, 64]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %mul_2 : Tensor "f16[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_1, %arg2_1), kwargs = {})
#   %mul_3 : Tensor "f16[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %arg3_1), kwargs = {})
#   %add_1 : Tensor "f16[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_2, %mul_3), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_1, torch.float32), kwargs = {})
#   %mul_6 : Tensor "f32[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_8, 0.3535533905932738), kwargs = {})
#   %mul_4 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_3, %arg2_1), kwargs = {})
#   %mul_5 : Tensor "f16[1, 4, 512, 64][131072, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %arg3_1), kwargs = {})
#   %add_2 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_4, %mul_5), kwargs = {})
#   %unsqueeze : Tensor "f16[1, 4, 1, 512, 64][131072, 64, 131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%add_2, 2), kwargs = {})
#   %expand : Tensor "f16[1, 4, 4, 512, 64][131072, 64, 0, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze, [1, 4, 4, 512, 64]), kwargs = {})
#   %clone : Tensor "f16[1, 4, 4, 512, 64][524288, 131072, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view_9 : Tensor "f16[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 16, 512, 64]), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_9, torch.float32), kwargs = {})
#   %permute_6 : Tensor "f32[1, 16, 64, 512][524288, 32768, 1, 64]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_9, [0, 1, 3, 2]), kwargs = {})
#   %mul_7 : Tensor "f32[1, 16, 64, 512][524288, 32768, 1, 64]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_6, 0.3535533905932738), kwargs = {})
#   return %expand_2,%expand_3
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_7 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'y': 8192, 'x': 64}, tile_hint=TileHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'in_ptr5': '*fp16', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'y': 4194304, 'x': 6946816}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_7(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, out_ptr1, ynumel, xnumel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 8192
    xnumel = 64
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None]
    ymask = tl.full([YBLOCK], True, tl.int1)[:, None]
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :]
    xmask = xindex < xnumel
    x2 = xindex
    y0 = (yindex % 512)
    y1 = yindex // 512
    y3 = yindex
    tmp0 = tl.load(in_ptr0 + (x2 + 64*y1 + 1024*y0), xmask).to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (x2 + 64*y0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x2 + 64*y3), xmask).to(tl.float32)
    tmp4 = tl.load(in_ptr3 + (x2 + 64*y0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp10 = tl.load(in_ptr4 + (x2 + 64*(y1 // 4) + 256*y0), xmask).to(tl.float32)
    tmp12 = tl.load(in_ptr5 + (x2 + 64*y0 + 32768*(y1 // 4)), xmask).to(tl.float32)
    tmp2 = tmp0 * tmp1
    tmp5 = tmp3 * tmp4
    tmp6 = tmp2 + tmp5
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tl.full([1, 1], 0.3535533905932738, tl.float32)
    tmp9 = tmp7 * tmp8
    tmp11 = tmp10 * tmp1
    tmp13 = tmp12 * tmp4
    tmp14 = tmp11 + tmp13
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tmp15 * tmp8
    tl.store(out_ptr0 + (x2 + 64*y3), tmp9, xmask)
    tl.store(out_ptr1 + (y0 + 512*x2 + 32768*y1), tmp16, xmask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/ev/cevmwb5nvnksfb2fxuerxygsegmik3aie6t54c2apua3pw2hpyor.py
# Topologically Sorted Source Nodes: [linear, view, q, linear_1, view_1, k, mul, mul_1, q_1, o, mul_2, mul_3, k_1, getitem_4, expand, k_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   expand => expand
#   getitem_4 => unsqueeze
#   k => permute_3
#   k_1 => add_2
#   k_2 => clone, view_9
#   linear => view_1
#   linear_1 => view_4
#   mul => mul_2
#   mul_1 => mul_3
#   mul_2 => mul_4
#   mul_3 => mul_5
#   o => bmm, convert_element_type_8, convert_element_type_9, mul_6, mul_7, permute_6, view_11, view_12
#   q => permute_1
#   q_1 => add_1
#   view => view_2
#   view_1 => view_5
# Graph fragment:
#   %expand_2 : Tensor "f32[1, 16, 512, 64][524288, 32768, 64, 1]cpu" = PlaceHolder[target=expand_2]
#   %expand_3 : Tensor "f32[1, 16, 64, 512][524288, 32768, 512, 1]cpu" = PlaceHolder[target=expand_3]
#   %view_1 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 512, 1024]), kwargs = {})
#   %view_2 : Tensor "f16[1, 512, 16, 64][524288, 1024, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 512, 16, 64]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %view_4 : Tensor "f16[1, 512, 256][131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 512, 256]), kwargs = {})
#   %view_5 : Tensor "f16[1, 512, 4, 64][131072, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 512, 4, 64]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %mul_2 : Tensor "f16[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_1, %arg2_1), kwargs = {})
#   %mul_3 : Tensor "f16[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %arg3_1), kwargs = {})
#   %add_1 : Tensor "f16[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_2, %mul_3), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_1, torch.float32), kwargs = {})
#   %mul_6 : Tensor "f32[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_8, 0.3535533905932738), kwargs = {})
#   %view_11 : Tensor "f32[16, 512, 64][64, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_2, [16, 512, 64]), kwargs = {})
#   %mul_4 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_3, %arg2_1), kwargs = {})
#   %mul_5 : Tensor "f16[1, 4, 512, 64][131072, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %arg3_1), kwargs = {})
#   %add_2 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_4, %mul_5), kwargs = {})
#   %unsqueeze : Tensor "f16[1, 4, 1, 512, 64][131072, 64, 131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%add_2, 2), kwargs = {})
#   %expand : Tensor "f16[1, 4, 4, 512, 64][131072, 64, 0, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze, [1, 4, 4, 512, 64]), kwargs = {})
#   %clone : Tensor "f16[1, 4, 4, 512, 64][524288, 131072, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view_9 : Tensor "f16[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 16, 512, 64]), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_9, torch.float32), kwargs = {})
#   %permute_6 : Tensor "f32[1, 16, 64, 512][524288, 32768, 1, 64]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_9, [0, 1, 3, 2]), kwargs = {})
#   %mul_7 : Tensor "f32[1, 16, 64, 512][524288, 32768, 1, 64]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_6, 0.3535533905932738), kwargs = {})
#   %view_12 : Tensor "f32[16, 64, 512][32768, 1, 64]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_3, [16, 64, 512]), kwargs = {})
#   %bmm : Tensor "f32[16, 512, 512][262144, 512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_11, %view_12), kwargs = {})
#   return %bmm
triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8 = async_compile.triton('triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 512
    N = 512
    K = 64
    BATCH = 16

    stride_aq = 32768
    stride_am = 64
    stride_ak = 1

    stride_bq = 32768
    stride_bk = 512
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 512*idx_m + 262144*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/vz/cvzy4bo3mnphbkk24mb42k3nriiivbfqgeax5thdhdihinz74g24.py
# Topologically Sorted Source Nodes: [o], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   o => add_3, amax, any_1, div, eq, exp, full_default, full_default_1, full_default_2, full_default_3, iota, iota_1, le, logical_and, logical_not, logical_not_1, sub, sub_1, sum_1, unsqueeze_2, unsqueeze_3, view_13, where, where_1
# Graph fragment:
#   %bmm : Tensor "f32[16, 512, 512][262144, 512, 1]cpu" = PlaceHolder[target=bmm]
#   %amax : Tensor "f32[1, 16, 512, 1][8192, 512, 1, 8192]cpu" = PlaceHolder[target=amax]
#   %exp : Tensor "f32[1, 16, 512, 512][4194304, 262144, 512, 1]cpu" = PlaceHolder[target=exp]
#   %any_1 : Tensor "b8[1, 16, 512, 1][8192, 512, 1, 8192]cpu" = PlaceHolder[target=any_1]
#   %sum_1 : Tensor "f32[1, 16, 512, 1][8192, 512, 1, 8192]cpu" = PlaceHolder[target=sum_1]
#   %view_13 : Tensor "f32[1, 16, 512, 512][4194304, 262144, 512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 16, 512, 512]), kwargs = {})
#   %iota : Tensor "i64[512][1]cpu"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (512,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: cpu, requires_grad: False})
#   %unsqueeze_2 : Tensor "i64[1, 512][512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota, -2), kwargs = {})
#   %iota_1 : Tensor "i64[512][1]cpu"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (512,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: cpu, requires_grad: False})
#   %unsqueeze_3 : Tensor "i64[512, 1][1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota_1, -1), kwargs = {})
#   %sub : Tensor "i64[512, 512][512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%unsqueeze_2, %unsqueeze_3), kwargs = {})
#   %le : Tensor "b8[512, 512][512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.le.Scalar](args = (%sub, 0), kwargs = {})
#   %full_default : Tensor "b8[512, 512][512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([512, 512], True), kwargs = {dtype: torch.bool, layout: torch.strided, device: cpu, pin_memory: False})
#   %logical_and : Tensor "b8[512, 512][512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.logical_and.default](args = (%le, %full_default), kwargs = {})
#   %full_default_2 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], 0.0), kwargs = {dtype: torch.float32, layout: torch.strided, device: cpu, pin_memory: False})
#   %full_default_1 : Tensor "f32[][]cpu"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], -inf), kwargs = {dtype: torch.float32, layout: torch.strided, device: cpu, pin_memory: False})
#   %where : Tensor "f32[512, 512][512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_and, %full_default_2, %full_default_1), kwargs = {})
#   %add_3 : Tensor "f32[1, 16, 512, 512][4194304, 262144, 512, 1]cpu"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%view_13, %where), kwargs = {})
#   %eq : Tensor "b8[1, 16, 512, 512][4194304, 262144, 512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%add_3, -inf), kwargs = {})
#   %logical_not : Tensor "b8[1, 16, 512, 512][4194304, 262144, 512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq,), kwargs = {})
#   %any_1 : Tensor "b8[1, 16, 512, 1][8192, 512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.any.dim](args = (%logical_not, -1, True), kwargs = {})
#   %logical_not_1 : Tensor "b8[1, 16, 512, 1][8192, 512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default_3 : Tensor "f32[1, 16, 512, 512][4194304, 262144, 512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 512, 512], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: cpu, pin_memory: False})
#   %amax : Tensor "f32[1, 16, 512, 1][8192, 512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%add_3, [-1], True), kwargs = {})
#   %sub_1 : Tensor "f32[1, 16, 512, 512][4194304, 262144, 512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%add_3, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 16, 512, 512][4194304, 262144, 512, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub_1,), kwargs = {})
#   %sum_1 : Tensor "f32[1, 16, 512, 1][8192, 512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp, [-1], True), kwargs = {})
#   %div : Tensor "f32[1, 16, 512, 512][4194304, 262144, 512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where_1 : Tensor "f32[1, 16, 512, 512][4194304, 262144, 512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default_3, %div), kwargs = {})
#   return %any_1,%amax,%exp,%sum_1,%expand_4
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_9 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 8192, 'r0_': 512},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_9', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 2, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 50331648}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_9(in_out_ptr0, in_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 8192
    XBLOCK: tl.constexpr = 1
    r0_numel = 512
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x3 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[8192, 512], strides=[512, 1], block_shape=[XBLOCK, R0_BLOCK])
    x0 = (xindex % 512)
    _tmp16 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp20 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp1 = (r0_2 + ((-1)*x0)).to(tl.int64)
        tmp2 = (tmp1).to(tl.int64)
        tmp3 = tl.full([1], 0, tl.int64)
        tmp4 = tmp2 <= tmp3
        tmp5 = tl.full([1], True, tl.int1)
        tmp6 = tmp4 & tmp5
        tmp7 = tl.full([1], 0.0, tl.float32)
        tmp8 = tl.full([1], float("-inf"), tl.float32)
        tmp9 = tl.where(tmp6, tmp7, tmp8)
        tmp10 = tmp0 + tmp9
        tmp11 = tmp10 == tmp8
        tmp12 = tmp11 == 0
        tmp13 = tmp12.to(tl.int64)
        tmp14 = (tmp13 != 0)
        tmp15 = tl.broadcast_to(tmp14, [R0_BLOCK])
        tmp17 = _tmp16 | tmp15
        _tmp16 = tl.where(r0_mask, tmp17, _tmp16)
        tmp19 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp21 = tl.maximum(_tmp20, tmp19, tl.PropagateNan.ALL)
        _tmp20 = tl.where(r0_mask, tmp21, _tmp20)
    tmp18 = _tmp16.to(tl.int8)
    tmp16 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp18, 0))
    tmp20 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp20, 0))
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[8192, 512], strides=[512, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp36 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp22 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp23 = (r0_2 + ((-1)*x0)).to(tl.int64)
        tmp24 = (tmp23).to(tl.int64)
        tmp25 = tl.full([1], 0, tl.int64)
        tmp26 = tmp24 <= tmp25
        tmp27 = tl.full([1], True, tl.int1)
        tmp28 = tmp26 & tmp27
        tmp29 = tl.full([1], 0.0, tl.float32)
        tmp30 = tl.full([1], float("-inf"), tl.float32)
        tmp31 = tl.where(tmp28, tmp29, tmp30)
        tmp32 = tmp22 + tmp31
        tmp33 = tmp32 - tmp20
        tmp34 = libdevice.exp(tmp33)
        tmp35 = tl.broadcast_to(tmp34, [R0_BLOCK])
        tmp37 = _tmp36 + tmp35
        _tmp36 = tl.where(r0_mask, tmp37, _tmp36)
        tl.store(in_out_ptr0 + (r0_2 + 512*x3), tmp34, r0_mask)
    tmp36 = triton_helpers.promote_to_tensor(tl.sum(_tmp36, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[8192, 512], strides=[512, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp39 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp38 = tmp16 == 0
        tmp40 = (tmp39 / tmp36)
        tmp41 = tl.full([1], 0.0, tl.float32)
        tmp42 = tl.where(tmp38, tmp41, tmp40)
        tl.store(in_out_ptr0 + (r0_2 + 512*x3), tmp42, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/bz/cbzqr2e2dgldqdeqslb3lgr7lwmrwz6f5nmy2zajwfj2sa3mfrxf.py
# Topologically Sorted Source Nodes: [linear_2, view_2, v, getitem_5, expand_1, v_1, o], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   expand_1 => expand_1
#   getitem_5 => unsqueeze_1
#   linear_2 => view_7
#   o => convert_element_type_10
#   v => permute_5
#   v_1 => clone_1, view_10
#   view_2 => view_8
# Graph fragment:
#   %mm_2 : Tensor "f16[512, 256][256, 1]cpu" = PlaceHolder[target=mm_2]
#   %view_7 : Tensor "f16[1, 512, 256][131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 512, 256]), kwargs = {})
#   %view_8 : Tensor "f16[1, 512, 4, 64][131072, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_7, [1, 512, 4, 64]), kwargs = {})
#   %permute_5 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_8, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze_1 : Tensor "f16[1, 4, 1, 512, 64][131072, 64, 131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute_5, 2), kwargs = {})
#   %expand_1 : Tensor "f16[1, 4, 4, 512, 64][131072, 64, 0, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, 4, 4, 512, 64]), kwargs = {})
#   %clone_1 : Tensor "f16[1, 4, 4, 512, 64][524288, 131072, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_1,), kwargs = {memory_format: torch.contiguous_format})
#   %view_10 : Tensor "f16[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_1, [1, 16, 512, 64]), kwargs = {})
#   %convert_element_type_10 : Tensor "f32[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float32), kwargs = {})
#   return %expand_5
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4456448}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 524288
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 64)
    x1 = ((xindex // 64) % 512)
    x2 = xindex // 32768
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 64*(x2 // 4) + 256*x1), None).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp1, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/df/cdfskvlppde6nx6bm2d53vgqazg77eonlfujtxd6isfwmemjzqo7.py
# Topologically Sorted Source Nodes: [o, linear_2, view_2, v, getitem_5, expand_1, v_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   expand_1 => expand_1
#   getitem_5 => unsqueeze_1
#   linear_2 => view_7
#   o => bmm_1, convert_element_type_10, div, full_default_3, logical_not_1, view_14, view_15, where_1
#   v => permute_5
#   v_1 => clone_1, view_10
#   view_2 => view_8
# Graph fragment:
#   %expand_4 : Tensor "f32[1, 16, 512, 512][4194304, 262144, 512, 1]cpu" = PlaceHolder[target=expand_4]
#   %expand_5 : Tensor "f32[1, 16, 512, 64][524288, 32768, 64, 1]cpu" = PlaceHolder[target=expand_5]
#   %logical_not_1 : Tensor "b8[1, 16, 512, 1][8192, 512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default_3 : Tensor "f32[1, 16, 512, 512][4194304, 262144, 512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 512, 512], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: cpu, pin_memory: False})
#   %div : Tensor "f32[1, 16, 512, 512][4194304, 262144, 512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where_1 : Tensor "f32[1, 16, 512, 512][4194304, 262144, 512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default_3, %div), kwargs = {})
#   %view_14 : Tensor "f32[16, 512, 512][262144, 512, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_4, [16, 512, 512]), kwargs = {})
#   %view_7 : Tensor "f16[1, 512, 256][131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 512, 256]), kwargs = {})
#   %view_8 : Tensor "f16[1, 512, 4, 64][131072, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_7, [1, 512, 4, 64]), kwargs = {})
#   %permute_5 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_8, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze_1 : Tensor "f16[1, 4, 1, 512, 64][131072, 64, 131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute_5, 2), kwargs = {})
#   %expand_1 : Tensor "f16[1, 4, 4, 512, 64][131072, 64, 0, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, 4, 4, 512, 64]), kwargs = {})
#   %clone_1 : Tensor "f16[1, 4, 4, 512, 64][524288, 131072, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_1,), kwargs = {memory_format: torch.contiguous_format})
#   %view_10 : Tensor "f16[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_1, [1, 16, 512, 64]), kwargs = {})
#   %convert_element_type_10 : Tensor "f32[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float32), kwargs = {})
#   %view_15 : Tensor "f32[16, 512, 64][32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_5, [16, 512, 64]), kwargs = {})
#   %bmm_1 : Tensor "f32[16, 512, 64][32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_14, %view_15), kwargs = {})
#   return %bmm_1
triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_11 = async_compile.triton('triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_11', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_11(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 512
    N = 64
    K = 512
    BATCH = 16

    stride_aq = 262144
    stride_am = 512
    stride_ak = 1

    stride_bq = 32768
    stride_bk = 64
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 64*idx_m + 32768*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/sr/csrz4gsgkwtzw6xqzmdmuy3qxdgqnsfdivkxrkczmcwfwigtqbzo.py
# Topologically Sorted Source Nodes: [o], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   o => clone_2, convert_element_type_11, permute_7, view_16
# Graph fragment:
#   %bmm_1 : Tensor "f32[16, 512, 64][32768, 64, 1]cpu" = PlaceHolder[target=bmm_1]
#   %view_16 : Tensor "f32[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 16, 512, 64]), kwargs = {})
#   %convert_element_type_11 : Tensor "f16[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_16, torch.float16), kwargs = {})
#   %permute_7 : Tensor "f16[512, 1, 16, 64][64, 524288, 32768, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_11, [2, 0, 1, 3]), kwargs = {})
#   %clone_2 : Tensor "f16[512, 1, 16, 64][1024, 1024, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%permute_7,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_2
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_12 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4194304}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_12(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 524288
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 64)
    x1 = ((xindex // 64) % 16)
    x2 = xindex // 1024
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 64*x2 + 32768*x1), None)
    tmp1 = tmp0.to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp1, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/xr/cxry64beuoyx2ymb3cocze3ccdcmo5wqcfbzlxnkc65fw7fxikvo.py
# Topologically Sorted Source Nodes: [x, h, x_1, y], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   x => embedding
#   x_1 => add_4
#   y => add_5, convert_element_type_15, convert_element_type_16, mean_1, mul_8, mul_9, pow_2, rsqrt_1
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 512][512, 1]cpu" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[32000, 1024][1024, 1]cpu" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_3]
#   %buf23 : Tensor "f32[1, 512, 1][512, 1, 512]cpu" = PlaceHolder[target=buf23]
#   %arg9_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg9_1]
#   %embedding : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 512, 1024]), kwargs = {})
#   %add_4 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %convert_element_type_15 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_4, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_15, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [2], True), kwargs = {})
#   %add_5 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_1, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_5,), kwargs = {})
#   %mul_8 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_15, %rsqrt_1), kwargs = {})
#   %mul_9 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_8, %arg9_1), kwargs = {})
#   %convert_element_type_16 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_9, torch.float16), kwargs = {})
#   return %buf23,%convert_element_type_16
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 512, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 4096, 'r0_': 3147776}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 512
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp8 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 32000), "index out of bounds: 0 <= tmp0 < 32000")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1024*tmp0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp5
        tmp7 = tl.broadcast_to(tmp6, [R0_BLOCK])
        tmp9 = _tmp8 + tmp7
        _tmp8 = tl.where(r0_mask, tmp9, _tmp8)
    tmp8 = triton_helpers.promote_to_tensor(tl.sum(_tmp8, 0))
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp12 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp21 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 32000), "index out of bounds: 0 <= tmp0 < 32000")
        tmp11 = tl.load(in_ptr1 + (r0_1 + 1024*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp13 = tmp11 + tmp12
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tl.full([1], 1024.0, tl.float32)
        tmp16 = (tmp8 / tmp15)
        tmp17 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp18 = tmp16 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp14 * tmp19
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp20 * tmp22
        tmp24 = tmp23.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 1024*x0), tmp24, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/vc/cvcc6eihjmvdo46poxvkisfb2jkzkt6fftpck6ngpr4njsch5mga.py
# Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_4 => mm_4, permute_11, view_20
# Graph fragment:
#   %convert_element_type_16 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu" = PlaceHolder[target=convert_element_type_16]
#   %arg10_1 : Tensor "f16[2816, 1024][1024, 1]cpu" = PlaceHolder[target=arg10_1]
#   %view_20 : Tensor "f16[512, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_16, [512, 1024]), kwargs = {})
#   %permute_11 : Tensor "f16[1024, 2816][1, 1024]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg10_1, [1, 0]), kwargs = {})
#   %mm_4 : Tensor "f16[512, 2816][2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_20, %permute_11), kwargs = {})
#   return %mm_4
triton_tem_fused_mm_t_view_14 = async_compile.triton('triton_tem_fused_mm_t_view_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_14', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_14(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 512
    N = 2816
    K = 1024
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 1024
    stride_ak = 1
    stride_bk = 1
    stride_bn = 1024

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 1024*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 2816*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 1024*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 2816*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/bs/cbs274zepdary4cyqls62s3pry6bt75vagzv56syoprefc6h7dl4.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
# Source node to ATen node mapping:
#   linear_4 => view_21
#   linear_5 => mm_5, permute_12, view_22, view_23
#   mul_4 => mul_10
#   silu => add_6, convert_element_type_19, convert_element_type_20, div_1, exp_1, neg_2
# Graph fragment:
#   %convert_element_type_16 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu" = PlaceHolder[target=convert_element_type_16]
#   %arg11_1 : Tensor "f16[2816, 1024][1024, 1]cpu" = PlaceHolder[target=arg11_1]
#   %mm_4 : Tensor "f16[512, 2816][2816, 1]cpu" = PlaceHolder[target=mm_4]
#   %mm_5 : Tensor "f16[512, 2816][2816, 1]cpu" = PlaceHolder[target=mm_5]
#   %view_21 : Tensor "f16[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 512, 2816]), kwargs = {})
#   %convert_element_type_19 : Tensor "f32[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_21, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_19,), kwargs = {})
#   %exp_1 : Tensor "f32[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_6 : Tensor "f32[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_1, 1), kwargs = {})
#   %div_1 : Tensor "f32[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_19, %add_6), kwargs = {})
#   %convert_element_type_20 : Tensor "f16[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_1, torch.float16), kwargs = {})
#   %view_22 : Tensor "f16[512, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_16, [512, 1024]), kwargs = {})
#   %permute_12 : Tensor "f16[1024, 2816][1, 1024]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg11_1, [1, 0]), kwargs = {})
#   %mm_5 : Tensor "f16[512, 2816][2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_22, %permute_12), kwargs = {})
#   %view_23 : Tensor "f16[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 512, 2816]), kwargs = {})
#   %mul_10 : Tensor "f16[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %view_23), kwargs = {})
#   return %mm_5,%mul_10
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15(arg_A, arg_B, in_ptr2, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 512
    N = 2816
    K = 1024
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 1024
    stride_ak = 1
    stride_bk = 1
    stride_bn = 1024

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 1024*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 2816*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 1024*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 2816*idx_m
    tmp0 = acc.to(tl.float16)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.load(in_ptr2 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = -tmp3
    tmp5 = libdevice.exp(tmp4)
    tmp6 = tl.full([1], 1.0, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = (tmp3 / tmp7)
    tmp9 = tmp8.to(tl.float32)
    tmp10 = tmp9 * tmp1
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp10, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/sm/csm2mchjyoepftned2nwmeye5ywxsz3xmz6hvfieevt7mkh7oprv.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4, linear_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_4 => view_21
#   linear_5 => view_23
#   linear_6 => mm_6, permute_13, view_24
#   mul_4 => mul_10
#   silu => add_6, convert_element_type_19, convert_element_type_20, div_1, exp_1, neg_2
# Graph fragment:
#   %mul_10 : Tensor "f16[1, 512, 2816][1441792, 2816, 1]cpu" = PlaceHolder[target=mul_10]
#   %arg12_1 : Tensor "f16[1024, 2816][2816, 1]cpu" = PlaceHolder[target=arg12_1]
#   %view_21 : Tensor "f16[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 512, 2816]), kwargs = {})
#   %convert_element_type_19 : Tensor "f32[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_21, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_19,), kwargs = {})
#   %exp_1 : Tensor "f32[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_6 : Tensor "f32[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_1, 1), kwargs = {})
#   %div_1 : Tensor "f32[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_19, %add_6), kwargs = {})
#   %convert_element_type_20 : Tensor "f16[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_1, torch.float16), kwargs = {})
#   %view_23 : Tensor "f16[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 512, 2816]), kwargs = {})
#   %mul_10 : Tensor "f16[1, 512, 2816][1441792, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %view_23), kwargs = {})
#   %view_24 : Tensor "f16[512, 2816][2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_10, [512, 2816]), kwargs = {})
#   %permute_13 : Tensor "f16[2816, 1024][1, 2816]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg12_1, [1, 0]), kwargs = {})
#   %mm_6 : Tensor "f16[512, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_24, %permute_13), kwargs = {})
#   return %mm_6
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 512
    N = 1024
    K = 2816
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2816
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2816

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2816*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 1024*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2816*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 1024*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/dw/cdwtaslky7dave6ttvzmfach4proxwun7jxof7kg2uvhju3ohjyc.py
# Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, rms_norm_2], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   linear_6 => view_25
#   rms_norm_2 => add_8, convert_element_type_25, convert_element_type_26, mean_2, mul_11, mul_12, pow_3, rsqrt_2
#   x => embedding
#   x_1 => add_4
#   x_2 => add_7
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 512][512, 1]cpu" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[32000, 1024][1024, 1]cpu" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_3]
#   %mm_6 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_6]
#   %buf29 : Tensor "f32[1, 512, 1][512, 1, 512]cpu" = PlaceHolder[target=buf29]
#   %arg13_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg13_1]
#   %embedding : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 512, 1024]), kwargs = {})
#   %add_4 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %view_25 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 512, 1024]), kwargs = {})
#   %add_7 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4, %view_25), kwargs = {})
#   %convert_element_type_25 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_7, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_25, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [2], True), kwargs = {})
#   %add_8 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_2, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_8,), kwargs = {})
#   %mul_11 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_25, %rsqrt_2), kwargs = {})
#   %mul_12 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_11, %arg13_1), kwargs = {})
#   %convert_element_type_26 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_12, torch.float16), kwargs = {})
#   return %buf29,%convert_element_type_26
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 512, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 4096, 'r0_': 4196352}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 512
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr3, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 32000), "index out of bounds: 0 <= tmp0 < 32000")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1024*tmp0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp14 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp16 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp25 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 32000), "index out of bounds: 0 <= tmp0 < 32000")
        tmp13 = tl.load(in_ptr1 + (r0_1 + 1024*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp15 = tmp13 + tmp14
        tmp17 = tmp15 + tmp16
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tl.full([1], 1024.0, tl.float32)
        tmp20 = (tmp10 / tmp19)
        tmp21 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp22 = tmp20 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp18 * tmp23
        tmp26 = tmp25.to(tl.float32)
        tmp27 = tmp24 * tmp26
        tmp28 = tmp27.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 1024*x0), tmp28, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/kz/ckzprybl2oad7oe43fiqju4vwuubstllwoymr4amxgw52fic5iu3.py
# Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, h_1, x_3, y_1], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   h_1 => view_45
#   linear_6 => view_25
#   x => embedding
#   x_1 => add_4
#   x_2 => add_7
#   x_3 => add_12
#   y_1 => add_13, convert_element_type_40, convert_element_type_41, mean_3, mul_19, mul_20, pow_4, rsqrt_3
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 512][512, 1]cpu" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[32000, 1024][1024, 1]cpu" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_3]
#   %mm_6 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_6]
#   %mm_10 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_10]
#   %add_12 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu" = PlaceHolder[target=add_12]
#   %buf53 : Tensor "f32[1, 512, 1][512, 1, 512]cpu" = PlaceHolder[target=buf53]
#   %arg18_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg18_1]
#   %embedding : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 512, 1024]), kwargs = {})
#   %add_4 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %view_25 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 512, 1024]), kwargs = {})
#   %add_7 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4, %view_25), kwargs = {})
#   %view_45 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_10, [1, 512, 1024]), kwargs = {})
#   %add_12 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_7, %view_45), kwargs = {})
#   %convert_element_type_40 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_12, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_40, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [2], True), kwargs = {})
#   %add_13 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_3, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_13,), kwargs = {})
#   %mul_19 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_40, %rsqrt_3), kwargs = {})
#   %mul_20 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_19, %arg18_1), kwargs = {})
#   %convert_element_type_41 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_20, torch.float16), kwargs = {})
#   return %add_12,%buf53,%convert_element_type_41
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_18 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_18', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 512, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_18', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 4096, 'r0_': 7342080}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_18(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 512
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last')
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr3, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp3 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp7 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp0) & (tmp0 < 32000), "index out of bounds: 0 <= tmp0 < 32000")
        tmp2 = tl.load(in_ptr1 + (r0_1 + 1024*tmp0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8.to(tl.float32)
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
        tl.store(in_out_ptr0 + (r0_1 + 1024*x0), tmp8, r0_mask)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_out_ptr0, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp14 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 1024.0, tl.float32)
        tmp17 = (tmp12 / tmp16)
        tmp18 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp21 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 1024*x0), tmp25, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/xf/cxfpbjtq52cfg3ruuvg3l3u7qpadkwyf6smciiifxee7oadfdykw.py
# Topologically Sorted Source Nodes: [linear_13, x_4, rms_norm_4], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   linear_13 => view_51
#   rms_norm_4 => add_16, convert_element_type_50, convert_element_type_51, mean_4, mul_22, mul_23, pow_5, rsqrt_4
#   x_4 => add_15
# Graph fragment:
#   %add_12 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu" = PlaceHolder[target=add_12]
#   %mm_13 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_13]
#   %buf59 : Tensor "f32[1, 512, 1][512, 1, 512]cpu" = PlaceHolder[target=buf59]
#   %arg22_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg22_1]
#   %view_51 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 512, 1024]), kwargs = {})
#   %add_15 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_12, %view_51), kwargs = {})
#   %convert_element_type_50 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_15, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_50, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [2], True), kwargs = {})
#   %add_16 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_4, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_16,), kwargs = {})
#   %mul_22 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_50, %rsqrt_4), kwargs = {})
#   %mul_23 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_22, %arg22_1), kwargs = {})
#   %convert_element_type_51 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_23, torch.float16), kwargs = {})
#   return %buf59,%convert_element_type_51
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_19 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_19', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 512, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_19', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 4196352}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_19(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 512
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr0, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr1, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp8 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 1024.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp17 * tmp19
        tmp21 = tmp20.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 1024*x0), tmp21, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/2t/c2tp5bqo4orcts5niqbgcmtk5jdb7vwdtzkiju7njm43yown5jnh.py
# Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, y_2], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h_2 => view_71
#   linear_13 => view_51
#   x_4 => add_15
#   x_5 => add_20
#   y_2 => add_21, convert_element_type_65, convert_element_type_66, mean_5, mul_30, mul_31, pow_6, rsqrt_5
# Graph fragment:
#   %add_12 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu" = PlaceHolder[target=add_12]
#   %mm_13 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_13]
#   %mm_17 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_17]
#   %buf82 : Tensor "f32[1, 512, 1][512, 1, 512]cpu" = PlaceHolder[target=buf82]
#   %arg27_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg27_1]
#   %view_51 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 512, 1024]), kwargs = {})
#   %add_15 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_12, %view_51), kwargs = {})
#   %view_71 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_17, [1, 512, 1024]), kwargs = {})
#   %add_20 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_15, %view_71), kwargs = {})
#   %convert_element_type_65 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_20, torch.float32), kwargs = {})
#   %pow_6 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_65, 2), kwargs = {})
#   %mean_5 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [2], True), kwargs = {})
#   %add_21 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_5, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_5 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_21,), kwargs = {})
#   %mul_30 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_65, %rsqrt_5), kwargs = {})
#   %mul_31 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_30, %arg27_1), kwargs = {})
#   %convert_element_type_66 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_31, torch.float16), kwargs = {})
#   return %buf82,%convert_element_type_66
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_20 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_20', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 512, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_20', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 5244928}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_20(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 512
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp8 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp5
        tmp7 = tl.broadcast_to(tmp6, [R0_BLOCK])
        tmp9 = _tmp8 + tmp7
        _tmp8 = tl.where(r0_mask, tmp9, _tmp8)
    tmp8 = triton_helpers.promote_to_tensor(tl.sum(_tmp8, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr1, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr2, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp10 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp11 = tl.reshape(tma_descriptor4.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tl.reshape(tma_descriptor5.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 1024.0, tl.float32)
        tmp17 = (tmp8 / tmp16)
        tmp18 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp21 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 1024*x0), tmp25, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/3n/c3n534byogsgizbyefpionycagjsnwql4bwjvflrvfgygwfpard3.py
# Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, linear_20, x_6, rms_norm_6], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h_2 => view_71
#   linear_13 => view_51
#   linear_20 => view_77
#   rms_norm_6 => add_24, convert_element_type_75, convert_element_type_76, mean_6, mul_33, mul_34, pow_7, rsqrt_6
#   x_4 => add_15
#   x_5 => add_20
#   x_6 => add_23
# Graph fragment:
#   %add_12 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu" = PlaceHolder[target=add_12]
#   %mm_13 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_13]
#   %mm_17 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_17]
#   %mm_20 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_20]
#   %buf88 : Tensor "f32[1, 512, 1][512, 1, 512]cpu" = PlaceHolder[target=buf88]
#   %arg31_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg31_1]
#   %view_51 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 512, 1024]), kwargs = {})
#   %add_15 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_12, %view_51), kwargs = {})
#   %view_71 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_17, [1, 512, 1024]), kwargs = {})
#   %add_20 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_15, %view_71), kwargs = {})
#   %view_77 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_20, [1, 512, 1024]), kwargs = {})
#   %add_23 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_20, %view_77), kwargs = {})
#   %convert_element_type_75 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_23, torch.float32), kwargs = {})
#   %pow_7 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_75, 2), kwargs = {})
#   %mean_6 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [2], True), kwargs = {})
#   %add_24 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_6, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_6 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_24,), kwargs = {})
#   %mul_33 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_75, %rsqrt_6), kwargs = {})
#   %mul_34 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_33, %arg31_1), kwargs = {})
#   %convert_element_type_76 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_34, torch.float16), kwargs = {})
#   return %buf88,%convert_element_type_76
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_21 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_21', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 512, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_21', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 6293504}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_21(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 512
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr0, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr1, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor6 = tl.make_tensor_descriptor(in_ptr2, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor7 = tl.make_tensor_descriptor(in_ptr3, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp12 = tl.reshape(tma_descriptor4.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tl.reshape(tma_descriptor5.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp15 = tl.reshape(tma_descriptor6.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp17 = tl.reshape(tma_descriptor7.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp26 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tl.full([1], 1024.0, tl.float32)
        tmp21 = (tmp10 / tmp20)
        tmp22 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp23 = tmp21 + tmp22
        tmp24 = libdevice.rsqrt(tmp23)
        tmp25 = tmp19 * tmp24
        tmp27 = tmp26.to(tl.float32)
        tmp28 = tmp25 * tmp27
        tmp29 = tmp28.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 1024*x0), tmp29, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/62/c626vu2umyzaj37fwh34w7lb7wwjl5r4coczawqjjhlizf3vvd4r.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, mul_2, mul_3, k_1, linear_8, view_4, k_3, mul_7, mul_8, k_4, linear_15, view_7, k_6, mul_12, mul_13, k_7, linear_22, view_10, k_9, mul_17, mul_18, k_10], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add]
# Source node to ATen node mapping:
#   k => permute_3
#   k_1 => add_2
#   k_10 => add_26
#   k_3 => permute_17
#   k_4 => add_10
#   k_6 => permute_31
#   k_7 => add_18
#   k_9 => permute_45
#   linear_1 => view_4
#   linear_15 => view_56
#   linear_22 => view_82
#   linear_8 => view_30
#   mul_12 => mul_26
#   mul_13 => mul_27
#   mul_17 => mul_37
#   mul_18 => mul_38
#   mul_2 => mul_4
#   mul_3 => mul_5
#   mul_7 => mul_15
#   mul_8 => mul_16
#   view_1 => view_5
#   view_10 => view_83
#   view_4 => view_31
#   view_7 => view_57
# Graph fragment:
#   %mm_1 : Tensor "f16[512, 256][256, 1]cpu" = PlaceHolder[target=mm_1]
#   %arg2_1 : Tensor "f16[512, 64][64, 1]cpu" = PlaceHolder[target=arg2_1]
#   %cat_1 : Tensor "f16[1, 4, 512, 64][131072, 32768, 64, 1]cpu" = PlaceHolder[target=cat_1]
#   %arg3_1 : Tensor "f16[512, 64][64, 1]cpu" = PlaceHolder[target=arg3_1]
#   %mm_8 : Tensor "f16[512, 256][256, 1]cpu" = PlaceHolder[target=mm_8]
#   %cat_3 : Tensor "f16[1, 4, 512, 64][131072, 32768, 64, 1]cpu" = PlaceHolder[target=cat_3]
#   %mm_15 : Tensor "f16[512, 256][256, 1]cpu" = PlaceHolder[target=mm_15]
#   %cat_5 : Tensor "f16[1, 4, 512, 64][131072, 32768, 64, 1]cpu" = PlaceHolder[target=cat_5]
#   %mm_22 : Tensor "f16[512, 256][256, 1]cpu" = PlaceHolder[target=mm_22]
#   %cat_7 : Tensor "f16[1, 4, 512, 64][131072, 32768, 64, 1]cpu" = PlaceHolder[target=cat_7]
#   %view_4 : Tensor "f16[1, 512, 256][131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 512, 256]), kwargs = {})
#   %view_5 : Tensor "f16[1, 512, 4, 64][131072, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 512, 4, 64]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %mul_4 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_3, %arg2_1), kwargs = {})
#   %mul_5 : Tensor "f16[1, 4, 512, 64][131072, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %arg3_1), kwargs = {})
#   %add_2 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_4, %mul_5), kwargs = {})
#   %view_30 : Tensor "f16[1, 512, 256][131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [1, 512, 256]), kwargs = {})
#   %view_31 : Tensor "f16[1, 512, 4, 64][131072, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_30, [1, 512, 4, 64]), kwargs = {})
#   %permute_17 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_31, [0, 2, 1, 3]), kwargs = {})
#   %mul_15 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_17, %arg2_1), kwargs = {})
#   %mul_16 : Tensor "f16[1, 4, 512, 64][131072, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_3, %arg3_1), kwargs = {})
#   %add_10 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_15, %mul_16), kwargs = {})
#   %view_56 : Tensor "f16[1, 512, 256][131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_15, [1, 512, 256]), kwargs = {})
#   %view_57 : Tensor "f16[1, 512, 4, 64][131072, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_56, [1, 512, 4, 64]), kwargs = {})
#   %permute_31 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_57, [0, 2, 1, 3]), kwargs = {})
#   %mul_26 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_31, %arg2_1), kwargs = {})
#   %mul_27 : Tensor "f16[1, 4, 512, 64][131072, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_5, %arg3_1), kwargs = {})
#   %add_18 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_26, %mul_27), kwargs = {})
#   %view_82 : Tensor "f16[1, 512, 256][131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_22, [1, 512, 256]), kwargs = {})
#   %view_83 : Tensor "f16[1, 512, 4, 64][131072, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_82, [1, 512, 4, 64]), kwargs = {})
#   %permute_45 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_83, [0, 2, 1, 3]), kwargs = {})
#   %mul_37 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_45, %arg2_1), kwargs = {})
#   %mul_38 : Tensor "f16[1, 4, 512, 64][131072, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_7, %arg3_1), kwargs = {})
#   %add_26 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_37, %mul_38), kwargs = {})
#   return %add_2,%add_10,%add_18,%add_26
triton_poi_fused__unsafe_view_add_mul_transpose_view_22 = async_compile.triton('triton_poi_fused__unsafe_view_add_mul_transpose_view_22', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'in_ptr5': '*fp16', 'in_ptr6': '*fp16', 'in_ptr7': '*fp16', 'in_ptr8': '*fp16', 'in_ptr9': '*fp16', 'out_ptr0': '*fp16', 'out_ptr1': '*fp16', 'out_ptr2': '*fp16', 'out_ptr3': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (12,): [['tt.divisibility', 16]], (13,): [['tt.divisibility', 16]], (14,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_mul_transpose_view_22', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 10, 'num_store': 4, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4325376}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_mul_transpose_view_22(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, in_ptr7, in_ptr8, in_ptr9, out_ptr0, out_ptr1, out_ptr2, out_ptr3, xnumel, XBLOCK : tl.constexpr):
    xnumel = 131072
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 64)
    x1 = ((xindex // 64) % 512)
    x2 = xindex // 32768
    x3 = (xindex % 32768)
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 64*x2 + 256*x1), None).to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (x3), None, eviction_policy='evict_last').to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x4), None).to(tl.float32)
    tmp4 = tl.load(in_ptr3 + (x3), None, eviction_policy='evict_last').to(tl.float32)
    tmp7 = tl.load(in_ptr4 + (x0 + 64*x2 + 256*x1), None).to(tl.float32)
    tmp9 = tl.load(in_ptr5 + (x4), None).to(tl.float32)
    tmp12 = tl.load(in_ptr6 + (x0 + 64*x2 + 256*x1), None).to(tl.float32)
    tmp14 = tl.load(in_ptr7 + (x4), None).to(tl.float32)
    tmp17 = tl.load(in_ptr8 + (x0 + 64*x2 + 256*x1), None).to(tl.float32)
    tmp19 = tl.load(in_ptr9 + (x4), None).to(tl.float32)
    tmp2 = tmp0 * tmp1
    tmp5 = tmp3 * tmp4
    tmp6 = tmp2 + tmp5
    tmp8 = tmp7 * tmp1
    tmp10 = tmp9 * tmp4
    tmp11 = tmp8 + tmp10
    tmp13 = tmp12 * tmp1
    tmp15 = tmp14 * tmp4
    tmp16 = tmp13 + tmp15
    tmp18 = tmp17 * tmp1
    tmp20 = tmp19 * tmp4
    tmp21 = tmp18 + tmp20
    tl.store(out_ptr0 + (x4), tmp6, None)
    tl.store(out_ptr1 + (x4), tmp11, None)
    tl.store(out_ptr2 + (x4), tmp16, None)
    tl.store(out_ptr3 + (x4), tmp21, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/je/cjeecd4al2ejrxwnxa5ze6vrgd46vv5jimcy4xhyonxldugo35mz.py
# Topologically Sorted Source Nodes: [keys, keys_1], Original ATen: [aten.stack, aten.constant_pad_nd]
# Source node to ATen node mapping:
#   keys => view_106
#   keys_1 => constant_pad_nd
# Graph fragment:
#   %cat_8 : Tensor "f16[4, 4, 512, 64][131072, 32768, 64, 1]cpu" = PlaceHolder[target=cat_8]
#   %view_106 : Tensor "f16[4, 1, 4, 512, 64][131072, 131072, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%cat_8, [4, 1, 4, 512, 64]), kwargs = {})
#   %constant_pad_nd : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.constant_pad_nd.default](args = (%view_106, [0, 0, 0, 64], 0.0), kwargs = {})
#   return %constant_pad_nd
triton_poi_fused_constant_pad_nd_stack_23 = async_compile.triton('triton_poi_fused_constant_pad_nd_stack_23', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_constant_pad_nd_stack_23', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3407872}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_constant_pad_nd_stack_23(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 589824
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = ((xindex // 64) % 576)
    x2 = xindex // 36864
    x3 = (xindex % 36864)
    x4 = xindex
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 512, tl.int64)
    tmp2 = tmp0 < tmp1
    tmp3 = tl.load(in_ptr0 + (x3 + 32768*x2), tmp2, other=0.0).to(tl.float32)
    tl.store(out_ptr0 + (x4), tmp3, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/37/c37qy45hlqyngb6svtcabdaxrs7j4cep6mt55wzdblsahdkhs327.py
# Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_2, linear_16, view_8, v_4, linear_23, view_11, v_6, values], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
# Source node to ATen node mapping:
#   linear_16 => view_59
#   linear_2 => view_7
#   linear_23 => view_85
#   linear_9 => view_33
#   v => permute_5
#   v_2 => permute_19
#   v_4 => permute_33
#   v_6 => permute_47
#   values => cat_9
#   view_11 => view_86
#   view_2 => view_8
#   view_5 => view_34
#   view_8 => view_60
# Graph fragment:
#   %mm_2 : Tensor "f16[512, 256][256, 1]cpu" = PlaceHolder[target=mm_2]
#   %view_7 : Tensor "f16[1, 512, 256][131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 512, 256]), kwargs = {})
#   %view_8 : Tensor "f16[1, 512, 4, 64][131072, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_7, [1, 512, 4, 64]), kwargs = {})
#   %permute_5 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_8, [0, 2, 1, 3]), kwargs = {})
#   %view_33 : Tensor "f16[1, 512, 256][131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_9, [1, 512, 256]), kwargs = {})
#   %view_34 : Tensor "f16[1, 512, 4, 64][131072, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_33, [1, 512, 4, 64]), kwargs = {})
#   %permute_19 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_34, [0, 2, 1, 3]), kwargs = {})
#   %view_59 : Tensor "f16[1, 512, 256][131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_16, [1, 512, 256]), kwargs = {})
#   %view_60 : Tensor "f16[1, 512, 4, 64][131072, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_59, [1, 512, 4, 64]), kwargs = {})
#   %permute_33 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_60, [0, 2, 1, 3]), kwargs = {})
#   %view_85 : Tensor "f16[1, 512, 256][131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_23, [1, 512, 256]), kwargs = {})
#   %view_86 : Tensor "f16[1, 512, 4, 64][131072, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_85, [1, 512, 4, 64]), kwargs = {})
#   %permute_47 : Tensor "f16[1, 4, 512, 64][131072, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_86, [0, 2, 1, 3]), kwargs = {})
#   %cat_9 : Tensor "f16[4, 4, 512, 64][131072, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%permute_5, %permute_19, %permute_33, %permute_47],), kwargs = {})
#   return %buf102
triton_poi_fused__unsafe_view_stack_transpose_view_24 = async_compile.triton('triton_poi_fused__unsafe_view_stack_transpose_view_24', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_stack_transpose_view_24', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 786432}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_stack_transpose_view_24(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 131072
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 64)
    x1 = ((xindex // 64) % 512)
    x2 = xindex // 32768
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 64*x2 + 256*x1), None).to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp0, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/ia/cia2anucoxylva33cyeyuzhv4cu2ddrecbbggkiaxssvgwmeyv3q.py
# Topologically Sorted Source Nodes: [linear_21, view_9, q_6, mul_15, mul_16, q_7, o_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   linear_21 => view_79
#   mul_15 => mul_35
#   mul_16 => mul_36
#   o_6 => convert_element_type_83, mul_39
#   q_6 => permute_43
#   q_7 => add_25
#   view_9 => view_80
# Graph fragment:
#   %mm_21 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_21]
#   %arg2_1 : Tensor "f16[512, 64][64, 1]cpu" = PlaceHolder[target=arg2_1]
#   %cat_6 : Tensor "f16[1, 16, 512, 64][524288, 32768, 64, 1]cpu" = PlaceHolder[target=cat_6]
#   %arg3_1 : Tensor "f16[512, 64][64, 1]cpu" = PlaceHolder[target=arg3_1]
#   %view_79 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_21, [1, 512, 1024]), kwargs = {})
#   %view_80 : Tensor "f16[1, 512, 16, 64][524288, 1024, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_79, [1, 512, 16, 64]), kwargs = {})
#   %permute_43 : Tensor "f16[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_80, [0, 2, 1, 3]), kwargs = {})
#   %mul_35 : Tensor "f16[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_43, %arg2_1), kwargs = {})
#   %mul_36 : Tensor "f16[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_6, %arg3_1), kwargs = {})
#   %add_25 : Tensor "f16[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_35, %mul_36), kwargs = {})
#   %convert_element_type_83 : Tensor "f32[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_25, torch.float32), kwargs = {})
#   %mul_39 : Tensor "f32[1, 16, 512, 64][524288, 64, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_83, 0.3535533905932738), kwargs = {})
#   return %expand_20
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_mul_transpose_view_25 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_mul_transpose_view_25', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_mul_transpose_view_25', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 6422528}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_mul_transpose_view_25(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 524288
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 64)
    x1 = ((xindex // 64) % 512)
    x2 = xindex // 32768
    x3 = (xindex % 32768)
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 64*x2 + 1024*x1), None).to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (x3), None, eviction_policy='evict_last').to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x4), None).to(tl.float32)
    tmp4 = tl.load(in_ptr3 + (x3), None, eviction_policy='evict_last').to(tl.float32)
    tmp2 = tmp0 * tmp1
    tmp5 = tmp3 * tmp4
    tmp6 = tmp2 + tmp5
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tl.full([1], 0.3535533905932738, tl.float32)
    tmp9 = tmp7 * tmp8
    tl.store(out_ptr0 + (x4), tmp9, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/u3/cu3q3nldm2gimx2gm53uw2narjgxqchw6w3uldmhqhgpakgjgo77.py
# Topologically Sorted Source Nodes: [getitem_22, expand_6, k_11, o_6], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   expand_6 => expand_18
#   getitem_22 => unsqueeze_12
#   k_11 => clone_9, view_87
#   o_6 => convert_element_type_84, mul_40, permute_48
# Graph fragment:
#   %add_26 : Tensor "f16[1, 4, 512, 64][131072, 32768, 64, 1]cpu" = PlaceHolder[target=add_26]
#   %unsqueeze_12 : Tensor "f16[1, 4, 1, 512, 64][131072, 64, 131072, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%add_26, 2), kwargs = {})
#   %expand_18 : Tensor "f16[1, 4, 4, 512, 64][131072, 64, 0, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_12, [1, 4, 4, 512, 64]), kwargs = {})
#   %clone_9 : Tensor "f16[1, 4, 4, 512, 64][524288, 131072, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_18,), kwargs = {memory_format: torch.contiguous_format})
#   %view_87 : Tensor "f16[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_9, [1, 16, 512, 64]), kwargs = {})
#   %convert_element_type_84 : Tensor "f32[1, 16, 512, 64][524288, 32768, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_87, torch.float32), kwargs = {})
#   %permute_48 : Tensor "f32[1, 16, 64, 512][524288, 32768, 1, 64]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_84, [0, 1, 3, 2]), kwargs = {})
#   %mul_40 : Tensor "f32[1, 16, 64, 512][524288, 32768, 1, 64]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_48, 0.3535533905932738), kwargs = {})
#   return %expand_21
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_26 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_26', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'y': 1024, 'x': 512}, tile_hint=TileHint.SQUARE,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_26', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'y': 262144, 'x': 4194304}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_26(in_ptr0, out_ptr0, ynumel, xnumel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 1024
    xnumel = 512
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None]
    ymask = tl.full([YBLOCK], True, tl.int1)[:, None]
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :]
    xmask = xindex < xnumel
    x2 = xindex
    y0 = (yindex % 64)
    y1 = yindex // 64
    y3 = yindex
    tmp0 = tl.load(in_ptr0 + (y0 + 64*x2 + 32768*(y1 // 4)), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.full([1, 1], 0.3535533905932738, tl.float32)
    tmp3 = tmp1 * tmp2
    tl.store(out_ptr0 + (x2 + 512*y3), tmp3, xmask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/qg/cqgvhyfoe77brcbz5oz44m3cuia4tszyq746rdir6hdcy3rgyon5.py
# Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, linear_20, x_6, h_3, x_7, y_3], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h_2 => view_71
#   h_3 => view_97
#   linear_13 => view_51
#   linear_20 => view_77
#   x_4 => add_15
#   x_5 => add_20
#   x_6 => add_23
#   x_7 => add_28
#   y_3 => add_29, convert_element_type_90, convert_element_type_91, mean_7, mul_41, mul_42, pow_8, rsqrt_7
# Graph fragment:
#   %add_12 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu" = PlaceHolder[target=add_12]
#   %mm_13 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_13]
#   %mm_17 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_17]
#   %mm_20 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_20]
#   %mm_24 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_24]
#   %add_28 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu" = PlaceHolder[target=add_28]
#   %buf124 : Tensor "f32[1, 512, 1][512, 1, 512]cpu" = PlaceHolder[target=buf124]
#   %arg36_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg36_1]
#   %view_51 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 512, 1024]), kwargs = {})
#   %add_15 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_12, %view_51), kwargs = {})
#   %view_71 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_17, [1, 512, 1024]), kwargs = {})
#   %add_20 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_15, %view_71), kwargs = {})
#   %view_77 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_20, [1, 512, 1024]), kwargs = {})
#   %add_23 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_20, %view_77), kwargs = {})
#   %view_97 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_24, [1, 512, 1024]), kwargs = {})
#   %add_28 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_23, %view_97), kwargs = {})
#   %convert_element_type_90 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_28, torch.float32), kwargs = {})
#   %pow_8 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_90, 2), kwargs = {})
#   %mean_7 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_8, [2], True), kwargs = {})
#   %add_29 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_7, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_7 : Tensor "f32[1, 512, 1][512, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_29,), kwargs = {})
#   %mul_41 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_90, %rsqrt_7), kwargs = {})
#   %mul_42 : Tensor "f32[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_41, %arg36_1), kwargs = {})
#   %convert_element_type_91 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_42, torch.float16), kwargs = {})
#   return %add_28,%buf124,%convert_element_type_91
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 512, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 9439232}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 512
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr1, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr2, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr3, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tma_descriptor3.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp7 = tl.reshape(tma_descriptor4.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8.to(tl.float32)
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
        tl.store(in_out_ptr0 + (r0_1 + 1024*x0), tmp8, r0_mask)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tma_descriptor5 = tl.make_tensor_descriptor(in_out_ptr0, shape=[512, 1024], strides=[1024, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp14 = tl.reshape(tma_descriptor5.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 1024.0, tl.float32)
        tmp17 = (tmp12 / tmp16)
        tmp18 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp21 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 1024*x0), tmp25, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/fv/cfvpejsxuil7cn4rykgpm6tcgnjlvjt33d4l7srwitw4mgg6r6y2.py
# Topologically Sorted Source Nodes: [linear_27, x_8, getitem_24, rms_norm_8], Original ATen: [aten._unsafe_view, aten.add, aten.slice, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   getitem_24 => slice_1
#   linear_27 => view_103
#   rms_norm_8 => add_32, convert_element_type_100, convert_element_type_101, mean_8, mul_44, mul_45, pow_9, rsqrt_8
#   x_8 => add_31
# Graph fragment:
#   %add_28 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu" = PlaceHolder[target=add_28]
#   %mm_27 : Tensor "f16[512, 1024][1024, 1]cpu" = PlaceHolder[target=mm_27]
#   %buf130 : Tensor "f32[1, 1, 1][1, 1, 1]cpu" = PlaceHolder[target=buf130]
#   %arg40_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg40_1]
#   %view_103 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_27, [1, 512, 1024]), kwargs = {})
#   %add_31 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_28, %view_103), kwargs = {})
#   %slice_1 : Tensor "f16[1, 1, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%add_31, 1, -1, 9223372036854775807), kwargs = {})
#   %convert_element_type_100 : Tensor "f32[1, 1, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_1, torch.float32), kwargs = {})
#   %pow_9 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_100, 2), kwargs = {})
#   %mean_8 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_9, [2], True), kwargs = {})
#   %add_32 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_8, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_8 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_32,), kwargs = {})
#   %mul_44 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_100, %rsqrt_8), kwargs = {})
#   %mul_45 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_44, %arg40_1), kwargs = {})
#   %convert_element_type_101 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_45, torch.float16), kwargs = {})
#   return %buf130,%convert_element_type_101
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_slice_28 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_slice_28', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_slice_28', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 10240}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_slice_28(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0 + (523264), shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1 + (523264), shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr0 + (523264), shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr1 + (523264), shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 1024.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp17 * tmp19
        tmp21 = tmp20.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp21, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/bg/cbgsrgxe6ofsn3447iysonamksi7f5nmbqohqwpn7z5cwn3adehi.py
# Topologically Sorted Source Nodes: [linear_27, x_8, getitem_24, rms_norm_8, logits], Original ATen: [aten._unsafe_view, aten.add, aten.slice, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   getitem_24 => slice_1
#   linear_27 => view_103
#   logits => mm_28, permute_56, view_104
#   rms_norm_8 => add_32, convert_element_type_100, convert_element_type_101, mean_8, mul_44, mul_45, pow_9, rsqrt_8
#   x_8 => add_31
# Graph fragment:
#   %convert_element_type_101 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=convert_element_type_101]
#   %arg41_1 : Tensor "f16[32000, 1024][1024, 1]cpu" = PlaceHolder[target=arg41_1]
#   %view_103 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_27, [1, 512, 1024]), kwargs = {})
#   %add_31 : Tensor "f16[1, 512, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_28, %view_103), kwargs = {})
#   %slice_1 : Tensor "f16[1, 1, 1024][524288, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%add_31, 1, -1, 9223372036854775807), kwargs = {})
#   %convert_element_type_100 : Tensor "f32[1, 1, 1024][524288, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_1, torch.float32), kwargs = {})
#   %pow_9 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_100, 2), kwargs = {})
#   %mean_8 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_9, [2], True), kwargs = {})
#   %add_32 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_8, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_8 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_32,), kwargs = {})
#   %mul_44 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_100, %rsqrt_8), kwargs = {})
#   %mul_45 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_44, %arg40_1), kwargs = {})
#   %convert_element_type_101 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_45, torch.float16), kwargs = {})
#   %view_104 : Tensor "f16[1, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_101, [1, 1024]), kwargs = {})
#   %permute_56 : Tensor "f16[1024, 32000][1, 1024]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg41_1, [1, 0]), kwargs = {})
#   %mm_28 : Tensor "f16[1, 32000][32000, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_104, %permute_56), kwargs = {})
#   return %mm_28
triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_29 = async_compile.triton('triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_29', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_29', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_29(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 32000
    K = 1024
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 1024

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 1024*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 32000*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 1024*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 32000*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/gk/cgkqltwusxyajda5a74p72jlsbpb4d5h7l5nodwrrlng7rg75udi.py
# Topologically Sorted Source Nodes: [logits, float_1, argmax], Original ATen: [aten._unsafe_view, aten._to_copy, aten.argmax]
# Source node to ATen node mapping:
#   argmax => argmax
#   float_1 => convert_element_type_104
#   logits => view_105
# Graph fragment:
#   %mm_28 : Tensor "f16[1, 32000][32000, 1]cpu" = PlaceHolder[target=mm_28]
#   %view_105 : Tensor "f16[1, 1, 32000][32000, 32000, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_28, [1, 1, 32000]), kwargs = {})
#   %convert_element_type_104 : Tensor "f32[1, 1, 32000][32000, 32000, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_105, torch.float32), kwargs = {})
#   %argmax : Tensor "i64[1, 1][1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.argmax.default](args = (%convert_element_type_104, -1), kwargs = {})
#   return %argmax
triton_red_fused__to_copy__unsafe_view_argmax_30 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_argmax_30', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 32768},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*i64', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_argmax_30', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 64000}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_argmax_30(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 32000
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[32000], strides=[1], block_shape=[R0_BLOCK])
    _tmp3 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    _tmp3_index = tl.full([R0_BLOCK], 2147483647, tl.int32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tl.broadcast_to(tmp1, [R0_BLOCK])
        _tmp3_next, _tmp3_index_next = triton_helpers.maximum_with_index(
            _tmp3, _tmp3_index, tmp2, rindex
        )
        _tmp3 = tl.where(r0_mask, _tmp3_next, _tmp3)
        _tmp3_index = tl.where(r0_mask, _tmp3_index_next, _tmp3_index)
    tmp3_val, tmp3_idx = triton_helpers.max_with_index(_tmp3, _tmp3_index, 0)
    tmp3 = triton_helpers.promote_to_tensor(tmp3_idx)
    tl.store(out_ptr0 + (tl.full([1], 0, tl.int32)), tmp3, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/4c/c4c3jm4h7vpkhzrxlqamyee5akfhc5o6nionyiolhxbygsmjktan.py
# Topologically Sorted Source Nodes: [position], Original ATen: [aten.full]
# Source node to ATen node mapping:
#   position => full_default_16
# Graph fragment:
#   %full_default_16 : Tensor "i64[1][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1], 512), kwargs = {dtype: torch.int64, layout: torch.strided, device: cpu, pin_memory: False})
#   return %full_default_16
triton_poi_fused_full_31 = async_compile.triton('triton_poi_fused_full_31', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1}, 
    filename=__file__,
    triton_meta={'signature': {'out_ptr0': '*i64', 'xnumel': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_full_31', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 0, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_full_31(out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    tmp0 = tl.full([1], 512, tl.int64)
    tl.store(out_ptr0 + (tl.full([XBLOCK], 0, tl.int32)), tmp0, None)
''', device_str='cpu')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1 = args
        args.clear()
        assert_size_stride_grouped((arg1_1, arg0_1, arg4_1), ((1, 512), (32000, 1024), (1024, )), ((512, 1), (1024, 1), (1, )), 'input')
        buf1 = empty_strided_cpu((1, 512, 1024), (524288, 1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [x, rms_norm], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0.run(arg1_1, arg0_1, arg4_1, buf1, 512, 1024, stream=raw_streamNone)
        del arg4_1
        assert_size_stride(arg5_1, (1024, 1024), (1024, 1), 'input')
        buf2 = empty_strided_cpu((512, 1024), (1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [x, rms_norm, linear], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf1, arg5_1, buf2, 2048, 1, 1, stream=raw_streamNone)
        del arg5_1
        assert_size_stride(arg6_1, (256, 1024), (1024, 1), 'input')
        buf3 = empty_strided_cpu((512, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf1, arg6_1, buf3, 512, 1, 1, stream=raw_streamNone)
        del arg6_1
        buf6 = empty_strided_cpu((1, 16, 512, 64), (524288, 32768, 64, 1), torch.float16)
        buf4 = reinterpret_tensor(buf6, (1, 16, 512, 32), (524288, 32768, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear, view, q, chunk, neg], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf2, buf4, 262144, stream=raw_streamNone)
        buf5 = reinterpret_tensor(buf6, (1, 16, 512, 32), (524288, 32768, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear, view, q, chunk, neg, cat], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf2, buf5, 262144, stream=raw_streamNone)
        buf9 = empty_strided_cpu((1, 4, 512, 64), (131072, 32768, 64, 1), torch.float16)
        buf7 = reinterpret_tensor(buf9, (1, 4, 512, 32), (131072, 32768, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf3, buf7, 65536, stream=raw_streamNone)
        del buf4
        del buf5
        buf8 = reinterpret_tensor(buf9, (1, 4, 512, 32), (131072, 32768, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1, cat_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf3, buf8, 65536, stream=raw_streamNone)
        assert_size_stride_grouped((arg2_1, arg3_1), ((512, 64), (512, 64)), ((64, 1), (64, 1)), 'input')
        buf10 = empty_strided_cpu((1, 16, 512, 64), (524288, 32768, 64, 1), torch.float32)
        buf11 = empty_strided_cpu((1, 16, 64, 512), (524288, 32768, 512, 1), torch.float32)
        # Topologically Sorted Source Nodes: [linear, view, q, linear_1, view_1, k, mul, mul_1, q_1, o, mul_2, mul_3, k_1, getitem_4, expand, k_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_7.run(buf2, arg2_1, buf6, arg3_1, buf3, buf9, buf10, buf11, 8192, 64, stream=raw_streamNone)
        del buf2
        del buf7
        del buf8
        buf12 = empty_strided_cpu((16, 512, 512), (262144, 512, 1), torch.float32)
        # Topologically Sorted Source Nodes: [linear, view, q, linear_1, view_1, k, mul, mul_1, q_1, o, mul_2, mul_3, k_1, getitem_4, expand, k_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8.run(buf10, buf11, buf12, 1024, 16, 1, stream=raw_streamNone)
        buf15 = empty_strided_cpu((1, 16, 512, 512), (4194304, 262144, 512, 1), torch.float32)
        buf18 = buf15; del buf15  # reuse
        # Topologically Sorted Source Nodes: [o], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_9.run(buf18, buf12, 8192, 512, stream=raw_streamNone)
        assert_size_stride(arg7_1, (256, 1024), (1024, 1), 'input')
        buf17 = empty_strided_cpu((512, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_2], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf1, arg7_1, buf17, 512, 1, 1, stream=raw_streamNone)
        del arg7_1
        buf19 = reinterpret_tensor(buf11, (1, 16, 512, 64), (524288, 32768, 64, 1), 0); del buf11  # reuse
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, getitem_5, expand_1, v_1, o], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf17, buf19, 524288, stream=raw_streamNone)
        buf20 = reinterpret_tensor(buf10, (16, 512, 64), (32768, 64, 1), 0); del buf10  # reuse
        # Topologically Sorted Source Nodes: [o, linear_2, view_2, v, getitem_5, expand_1, v_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_11.run(buf18, buf19, buf20, 128, 16, 1, stream=raw_streamNone)
        buf21 = reinterpret_tensor(buf1, (512, 1, 16, 64), (1024, 1, 64, 1), 0); del buf1  # reuse
        # Topologically Sorted Source Nodes: [o], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_12.run(buf20, buf21, 524288, stream=raw_streamNone)
        assert_size_stride(arg8_1, (1024, 1024), (1024, 1), 'input')
        buf22 = reinterpret_tensor(buf6, (512, 1024), (1024, 1), 0); del buf6  # reuse
        # Topologically Sorted Source Nodes: [o, transpose_3, o_1, h], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf21, arg8_1, buf22, 2048, 1, 1, stream=raw_streamNone)
        del arg8_1
        assert_size_stride(arg9_1, (1024, ), (1, ), 'input')
        buf24 = reinterpret_tensor(buf21, (1, 512, 1024), (524288, 1024, 1), 0); del buf21  # reuse
        # Topologically Sorted Source Nodes: [x, h, x_1, y], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13.run(arg1_1, arg0_1, buf22, arg9_1, buf24, 512, 1024, stream=raw_streamNone)
        del arg9_1
        assert_size_stride(arg10_1, (2816, 1024), (1024, 1), 'input')
        buf25 = empty_strided_cpu((512, 2816), (2816, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_14.run(buf24, arg10_1, buf25, 5632, 1, 1, stream=raw_streamNone)
        del arg10_1
        assert_size_stride(arg11_1, (2816, 1024), (1024, 1), 'input')
        buf27 = empty_strided_cpu((1, 512, 2816), (1441792, 2816, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf24, arg11_1, buf25, buf27, 5632, 1, 1, stream=raw_streamNone)
        del arg11_1
        del buf25
        assert_size_stride(arg12_1, (1024, 2816), (2816, 1), 'input')
        buf28 = reinterpret_tensor(buf24, (512, 1024), (1024, 1), 0); del buf24  # reuse
        # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4, linear_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf27, arg12_1, buf28, 2048, 1, 1, stream=raw_streamNone)
        del arg12_1
        del buf27
        assert_size_stride(arg13_1, (1024, ), (1, ), 'input')
        buf30 = empty_strided_cpu((1, 512, 1024), (524288, 1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, rms_norm_2], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17.run(arg1_1, arg0_1, buf22, buf28, arg13_1, buf30, 512, 1024, stream=raw_streamNone)
        del arg13_1
        assert_size_stride(arg14_1, (1024, 1024), (1024, 1), 'input')
        buf31 = empty_strided_cpu((512, 1024), (1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf30, arg14_1, buf31, 2048, 1, 1, stream=raw_streamNone)
        del arg14_1
        assert_size_stride(arg15_1, (256, 1024), (1024, 1), 'input')
        buf32 = empty_strided_cpu((512, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_8], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf30, arg15_1, buf32, 512, 1, 1, stream=raw_streamNone)
        del arg15_1
        buf35 = empty_strided_cpu((1, 16, 512, 64), (524288, 32768, 64, 1), torch.float16)
        buf33 = reinterpret_tensor(buf35, (1, 16, 512, 32), (524288, 32768, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, chunk_2, neg_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf31, buf33, 262144, stream=raw_streamNone)
        buf34 = reinterpret_tensor(buf35, (1, 16, 512, 32), (524288, 32768, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, chunk_2, neg_2, cat_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf31, buf34, 262144, stream=raw_streamNone)
        buf38 = empty_strided_cpu((1, 4, 512, 64), (131072, 32768, 64, 1), torch.float16)
        buf36 = reinterpret_tensor(buf38, (1, 4, 512, 32), (131072, 32768, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_3, chunk_3, neg_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf32, buf36, 65536, stream=raw_streamNone)
        del buf33
        del buf34
        buf37 = reinterpret_tensor(buf38, (1, 4, 512, 32), (131072, 32768, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_3, chunk_3, neg_3, cat_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf32, buf37, 65536, stream=raw_streamNone)
        buf39 = reinterpret_tensor(buf20, (1, 16, 512, 64), (524288, 32768, 64, 1), 0); del buf20  # reuse
        buf40 = reinterpret_tensor(buf19, (1, 16, 64, 512), (524288, 32768, 512, 1), 0); del buf19  # reuse
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, linear_8, view_4, k_3, mul_5, mul_6, q_3, o_2, mul_7, mul_8, k_4, getitem_10, expand_2, k_5], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_7.run(buf31, arg2_1, buf35, arg3_1, buf32, buf38, buf39, buf40, 8192, 64, stream=raw_streamNone)
        del buf31
        del buf35
        del buf36
        del buf37
        buf41 = reinterpret_tensor(buf18, (16, 512, 512), (262144, 512, 1), 0); del buf18  # reuse
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, linear_8, view_4, k_3, mul_5, mul_6, q_3, o_2, mul_7, mul_8, k_4, getitem_10, expand_2, k_5], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8.run(buf39, buf40, buf41, 1024, 16, 1, stream=raw_streamNone)
        del buf39
        buf44 = reinterpret_tensor(buf12, (1, 16, 512, 512), (4194304, 262144, 512, 1), 0); del buf12  # reuse
        buf47 = buf44; del buf44  # reuse
        # Topologically Sorted Source Nodes: [o_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_9.run(buf47, buf41, 8192, 512, stream=raw_streamNone)
        assert_size_stride(arg16_1, (256, 1024), (1024, 1), 'input')
        buf46 = empty_strided_cpu((512, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_9], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf30, arg16_1, buf46, 512, 1, 1, stream=raw_streamNone)
        del arg16_1
        buf48 = reinterpret_tensor(buf40, (1, 16, 512, 64), (524288, 32768, 64, 1), 0); del buf40  # reuse
        # Topologically Sorted Source Nodes: [linear_9, view_5, v_2, getitem_11, expand_3, v_3, o_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf46, buf48, 524288, stream=raw_streamNone)
        buf49 = empty_strided_cpu((16, 512, 64), (32768, 64, 1), torch.float32)
        # Topologically Sorted Source Nodes: [o_2, linear_9, view_5, v_2, getitem_11, expand_3, v_3], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_11.run(buf47, buf48, buf49, 128, 16, 1, stream=raw_streamNone)
        buf50 = reinterpret_tensor(buf30, (512, 1, 16, 64), (1024, 1, 64, 1), 0); del buf30  # reuse
        # Topologically Sorted Source Nodes: [o_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_12.run(buf49, buf50, 524288, stream=raw_streamNone)
        assert_size_stride(arg17_1, (1024, 1024), (1024, 1), 'input')
        buf51 = empty_strided_cpu((512, 1024), (1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [o_2, transpose_7, o_3, h_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf50, arg17_1, buf51, 2048, 1, 1, stream=raw_streamNone)
        del arg17_1
        assert_size_stride(arg18_1, (1024, ), (1, ), 'input')
        buf52 = reinterpret_tensor(buf22, (1, 512, 1024), (524288, 1024, 1), 0); del buf22  # reuse
        buf54 = reinterpret_tensor(buf50, (1, 512, 1024), (524288, 1024, 1), 0); del buf50  # reuse
        # Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, h_1, x_3, y_1], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_18.run(buf52, arg1_1, arg0_1, buf28, buf51, arg18_1, buf54, 512, 1024, stream=raw_streamNone)
        del arg0_1
        del arg18_1
        del arg1_1
        assert_size_stride(arg19_1, (2816, 1024), (1024, 1), 'input')
        buf55 = empty_strided_cpu((512, 2816), (2816, 1), torch.float16)
        # Topologically Sorted Source Nodes: [y_1, linear_11], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_14.run(buf54, arg19_1, buf55, 5632, 1, 1, stream=raw_streamNone)
        del arg19_1
        assert_size_stride(arg20_1, (2816, 1024), (1024, 1), 'input')
        buf57 = empty_strided_cpu((1, 512, 2816), (1441792, 2816, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_9], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf54, arg20_1, buf55, buf57, 5632, 1, 1, stream=raw_streamNone)
        del arg20_1
        del buf55
        assert_size_stride(arg21_1, (1024, 2816), (2816, 1), 'input')
        buf58 = reinterpret_tensor(buf54, (512, 1024), (1024, 1), 0); del buf54  # reuse
        # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_9, linear_13], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf57, arg21_1, buf58, 2048, 1, 1, stream=raw_streamNone)
        del arg21_1
        del buf57
        assert_size_stride(arg22_1, (1024, ), (1, ), 'input')
        buf60 = reinterpret_tensor(buf51, (1, 512, 1024), (524288, 1024, 1), 0); del buf51  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, rms_norm_4], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_19.run(buf52, buf58, arg22_1, buf60, 512, 1024, stream=raw_streamNone)
        del arg22_1
        assert_size_stride(arg23_1, (1024, 1024), (1024, 1), 'input')
        buf61 = buf28; del buf28  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, rms_norm_4, linear_14], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf60, arg23_1, buf61, 2048, 1, 1, stream=raw_streamNone)
        del arg23_1
        assert_size_stride(arg24_1, (256, 1024), (1024, 1), 'input')
        buf62 = empty_strided_cpu((512, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_15], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf60, arg24_1, buf62, 512, 1, 1, stream=raw_streamNone)
        del arg24_1
        buf65 = empty_strided_cpu((1, 16, 512, 64), (524288, 32768, 64, 1), torch.float16)
        buf63 = reinterpret_tensor(buf65, (1, 16, 512, 32), (524288, 32768, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_14, view_6, q_4, chunk_4, neg_4], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf61, buf63, 262144, stream=raw_streamNone)
        buf64 = reinterpret_tensor(buf65, (1, 16, 512, 32), (524288, 32768, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_14, view_6, q_4, chunk_4, neg_4, cat_4], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf61, buf64, 262144, stream=raw_streamNone)
        buf68 = empty_strided_cpu((1, 4, 512, 64), (131072, 32768, 64, 1), torch.float16)
        buf66 = reinterpret_tensor(buf68, (1, 4, 512, 32), (131072, 32768, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_15, view_7, k_6, chunk_5, neg_5], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf62, buf66, 65536, stream=raw_streamNone)
        del buf63
        del buf64
        buf67 = reinterpret_tensor(buf68, (1, 4, 512, 32), (131072, 32768, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_15, view_7, k_6, chunk_5, neg_5, cat_5], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf62, buf67, 65536, stream=raw_streamNone)
        buf69 = reinterpret_tensor(buf49, (1, 16, 512, 64), (524288, 32768, 64, 1), 0); del buf49  # reuse
        buf70 = reinterpret_tensor(buf48, (1, 16, 64, 512), (524288, 32768, 512, 1), 0); del buf48  # reuse
        # Topologically Sorted Source Nodes: [linear_14, view_6, q_4, linear_15, view_7, k_6, mul_10, mul_11, q_5, o_4, mul_12, mul_13, k_7, getitem_16, expand_4, k_8], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_7.run(buf61, arg2_1, buf65, arg3_1, buf62, buf68, buf69, buf70, 8192, 64, stream=raw_streamNone)
        del buf61
        del buf66
        del buf67
        buf71 = reinterpret_tensor(buf47, (16, 512, 512), (262144, 512, 1), 0); del buf47  # reuse
        # Topologically Sorted Source Nodes: [linear_14, view_6, q_4, linear_15, view_7, k_6, mul_10, mul_11, q_5, o_4, mul_12, mul_13, k_7, getitem_16, expand_4, k_8], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8.run(buf69, buf70, buf71, 1024, 16, 1, stream=raw_streamNone)
        del buf69
        del buf70
        buf74 = reinterpret_tensor(buf41, (1, 16, 512, 512), (4194304, 262144, 512, 1), 0); del buf41  # reuse
        buf77 = buf74; del buf74  # reuse
        # Topologically Sorted Source Nodes: [o_4], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_9.run(buf77, buf71, 8192, 512, stream=raw_streamNone)
        assert_size_stride(arg25_1, (256, 1024), (1024, 1), 'input')
        buf76 = empty_strided_cpu((512, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_16], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf60, arg25_1, buf76, 512, 1, 1, stream=raw_streamNone)
        del arg25_1
        buf78 = empty_strided_cpu((1, 16, 512, 64), (524288, 32768, 64, 1), torch.float32)
        # Topologically Sorted Source Nodes: [linear_16, view_8, v_4, getitem_17, expand_5, v_5, o_4], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf76, buf78, 524288, stream=raw_streamNone)
        buf79 = empty_strided_cpu((16, 512, 64), (32768, 64, 1), torch.float32)
        # Topologically Sorted Source Nodes: [o_4, linear_16, view_8, v_4, getitem_17, expand_5, v_5], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_11.run(buf77, buf78, buf79, 128, 16, 1, stream=raw_streamNone)
        buf80 = reinterpret_tensor(buf60, (512, 1, 16, 64), (1024, 1, 64, 1), 0); del buf60  # reuse
        # Topologically Sorted Source Nodes: [o_4], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_12.run(buf79, buf80, 524288, stream=raw_streamNone)
        assert_size_stride(arg26_1, (1024, 1024), (1024, 1), 'input')
        buf81 = reinterpret_tensor(buf65, (512, 1024), (1024, 1), 0); del buf65  # reuse
        # Topologically Sorted Source Nodes: [o_4, transpose_11, o_5, h_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf80, arg26_1, buf81, 2048, 1, 1, stream=raw_streamNone)
        del arg26_1
        assert_size_stride(arg27_1, (1024, ), (1, ), 'input')
        buf83 = reinterpret_tensor(buf80, (1, 512, 1024), (524288, 1024, 1), 0); del buf80  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, y_2], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_20.run(buf52, buf58, buf81, arg27_1, buf83, 512, 1024, stream=raw_streamNone)
        del arg27_1
        assert_size_stride(arg28_1, (2816, 1024), (1024, 1), 'input')
        buf84 = empty_strided_cpu((512, 2816), (2816, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_18], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_14.run(buf83, arg28_1, buf84, 5632, 1, 1, stream=raw_streamNone)
        del arg28_1
        assert_size_stride(arg29_1, (2816, 1024), (1024, 1), 'input')
        buf86 = empty_strided_cpu((1, 512, 2816), (1441792, 2816, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_14], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf83, arg29_1, buf84, buf86, 5632, 1, 1, stream=raw_streamNone)
        del arg29_1
        del buf84
        assert_size_stride(arg30_1, (1024, 2816), (2816, 1), 'input')
        buf87 = reinterpret_tensor(buf83, (512, 1024), (1024, 1), 0); del buf83  # reuse
        # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_14, linear_20], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf86, arg30_1, buf87, 2048, 1, 1, stream=raw_streamNone)
        del arg30_1
        del buf86
        assert_size_stride(arg31_1, (1024, ), (1, ), 'input')
        buf89 = empty_strided_cpu((1, 512, 1024), (524288, 1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, linear_20, x_6, rms_norm_6], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_21.run(buf52, buf58, buf81, buf87, arg31_1, buf89, 512, 1024, stream=raw_streamNone)
        del arg31_1
        assert_size_stride(arg32_1, (1024, 1024), (1024, 1), 'input')
        buf90 = empty_strided_cpu((512, 1024), (1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_21], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf89, arg32_1, buf90, 2048, 1, 1, stream=raw_streamNone)
        del arg32_1
        assert_size_stride(arg33_1, (256, 1024), (1024, 1), 'input')
        buf91 = empty_strided_cpu((512, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_22], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf89, arg33_1, buf91, 512, 1, 1, stream=raw_streamNone)
        del arg33_1
        buf94 = empty_strided_cpu((1, 4, 512, 64), (131072, 32768, 64, 1), torch.float16)
        buf92 = reinterpret_tensor(buf94, (1, 4, 512, 32), (131072, 32768, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_22, view_10, k_9, chunk_7, neg_7], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf91, buf92, 65536, stream=raw_streamNone)
        buf93 = reinterpret_tensor(buf94, (1, 4, 512, 32), (131072, 32768, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_22, view_10, k_9, chunk_7, neg_7, cat_7], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf91, buf93, 65536, stream=raw_streamNone)
        buf99 = empty_strided_cpu((4, 4, 512, 64), (131072, 32768, 64, 1), torch.float16)
        buf95 = reinterpret_tensor(buf99, (1, 4, 512, 64), (131072, 32768, 64, 1), 0)  # alias
        buf96 = reinterpret_tensor(buf99, (1, 4, 512, 64), (131072, 32768, 64, 1), 131072)  # alias
        buf97 = reinterpret_tensor(buf99, (1, 4, 512, 64), (131072, 32768, 64, 1), 262144)  # alias
        buf98 = reinterpret_tensor(buf99, (1, 4, 512, 64), (131072, 32768, 64, 1), 393216)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, mul_2, mul_3, k_1, linear_8, view_4, k_3, mul_7, mul_8, k_4, linear_15, view_7, k_6, mul_12, mul_13, k_7, linear_22, view_10, k_9, mul_17, mul_18, k_10], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_add_mul_transpose_view_22.run(buf3, arg2_1, buf9, arg3_1, buf32, buf38, buf62, buf68, buf91, buf94, buf95, buf96, buf97, buf98, 131072, stream=raw_streamNone)
        del buf3
        del buf32
        del buf38
        del buf62
        del buf68
        del buf9
        del buf91
        del buf92
        del buf93
        buf100 = empty_strided_cpu((4, 1, 4, 576, 64), (147456, 147456, 36864, 64, 1), torch.float16)
        # Topologically Sorted Source Nodes: [keys, keys_1], Original ATen: [aten.stack, aten.constant_pad_nd]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused_constant_pad_nd_stack_23.run(buf99, buf100, 589824, stream=raw_streamNone)
        del buf95
        del buf96
        del buf97
        assert_size_stride(arg34_1, (256, 1024), (1024, 1), 'input')
        buf101 = reinterpret_tensor(buf94, (512, 256), (256, 1), 0); del buf94  # reuse
        # Topologically Sorted Source Nodes: [linear_23], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf89, arg34_1, buf101, 512, 1, 1, stream=raw_streamNone)
        del arg34_1
        buf106 = reinterpret_tensor(buf89, (4, 4, 512, 64), (131072, 32768, 64, 1), 0); del buf89  # reuse
        buf102 = reinterpret_tensor(buf106, (1, 4, 512, 64), (131072, 32768, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_2, linear_16, view_8, v_4, linear_23, view_11, v_6, values], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_stack_transpose_view_24.run(buf17, buf102, 131072, stream=raw_streamNone)
        del buf17
        buf103 = reinterpret_tensor(buf106, (1, 4, 512, 64), (131072, 32768, 64, 1), 131072)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_2, linear_16, view_8, v_4, linear_23, view_11, v_6, values], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_stack_transpose_view_24.run(buf46, buf103, 131072, stream=raw_streamNone)
        del buf46
        buf104 = reinterpret_tensor(buf106, (1, 4, 512, 64), (131072, 32768, 64, 1), 262144)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_2, linear_16, view_8, v_4, linear_23, view_11, v_6, values], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_stack_transpose_view_24.run(buf76, buf104, 131072, stream=raw_streamNone)
        del buf76
        buf105 = reinterpret_tensor(buf106, (1, 4, 512, 64), (131072, 32768, 64, 1), 393216)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, linear_9, view_5, v_2, linear_16, view_8, v_4, linear_23, view_11, v_6, values], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.stack]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_stack_transpose_view_24.run(buf101, buf105, 131072, stream=raw_streamNone)
        buf107 = empty_strided_cpu((4, 1, 4, 576, 64), (147456, 147456, 36864, 64, 1), torch.float16)
        # Topologically Sorted Source Nodes: [values, values_1], Original ATen: [aten.stack, aten.constant_pad_nd]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused_constant_pad_nd_stack_23.run(buf106, buf107, 589824, stream=raw_streamNone)
        del buf102
        del buf103
        del buf104
        del buf105
        buf110 = reinterpret_tensor(buf106, (1, 16, 512, 64), (524288, 32768, 64, 1), 0); del buf106  # reuse
        buf108 = reinterpret_tensor(buf110, (1, 16, 512, 32), (524288, 32768, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_21, view_9, q_6, chunk_6, neg_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf90, buf108, 262144, stream=raw_streamNone)
        buf109 = reinterpret_tensor(buf110, (1, 16, 512, 32), (524288, 32768, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_21, view_9, q_6, chunk_6, neg_6, cat_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf90, buf109, 262144, stream=raw_streamNone)
        buf111 = reinterpret_tensor(buf79, (1, 16, 512, 64), (524288, 32768, 64, 1), 0); del buf79  # reuse
        # Topologically Sorted Source Nodes: [linear_21, view_9, q_6, mul_15, mul_16, q_7, o_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_mul_transpose_view_25.run(buf90, arg2_1, buf110, arg3_1, buf111, 524288, stream=raw_streamNone)
        del arg2_1
        del arg3_1
        del buf108
        del buf109
        del buf110
        del buf90
        buf112 = reinterpret_tensor(buf78, (1, 16, 64, 512), (524288, 32768, 512, 1), 0); del buf78  # reuse
        # Topologically Sorted Source Nodes: [getitem_22, expand_6, k_11, o_6], Original ATen: [aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_26.run(buf98, buf112, 1024, 512, stream=raw_streamNone)
        del buf98
        del buf99
        buf113 = reinterpret_tensor(buf77, (16, 512, 512), (262144, 512, 1), 0); del buf77  # reuse
        # Topologically Sorted Source Nodes: [linear_21, view_9, q_6, mul_15, mul_16, q_7, o_6, getitem_22, expand_6, k_11], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_8.run(buf111, buf112, buf113, 1024, 16, 1, stream=raw_streamNone)
        del buf111
        del buf112
        buf116 = reinterpret_tensor(buf71, (1, 16, 512, 512), (4194304, 262144, 512, 1), 0); del buf71  # reuse
        buf118 = buf116; del buf116  # reuse
        # Topologically Sorted Source Nodes: [o_6], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_9.run(buf118, buf113, 8192, 512, stream=raw_streamNone)
        del buf113
        buf119 = empty_strided_cpu((1, 16, 512, 64), (524288, 32768, 64, 1), torch.float32)
        # Topologically Sorted Source Nodes: [linear_23, view_11, v_6, getitem_23, expand_7, v_7, o_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten.clone, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_10.run(buf101, buf119, 524288, stream=raw_streamNone)
        del buf101
        buf120 = empty_strided_cpu((16, 512, 64), (32768, 64, 1), torch.float32)
        # Topologically Sorted Source Nodes: [linear_23, view_11, v_6, o_6, getitem_23, expand_7, v_7], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_transpose_unsqueeze_view_11.run(buf118, buf119, buf120, 128, 16, 1, stream=raw_streamNone)
        del buf118
        del buf119
        buf121 = empty_strided_cpu((512, 1, 16, 64), (1024, 1, 64, 1), torch.float16)
        # Topologically Sorted Source Nodes: [o_6], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_12.run(buf120, buf121, 524288, stream=raw_streamNone)
        del buf120
        assert_size_stride(arg35_1, (1024, 1024), (1024, 1), 'input')
        buf122 = empty_strided_cpu((512, 1024), (1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [o_6, transpose_15, o_7, h_3], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf121, arg35_1, buf122, 2048, 1, 1, stream=raw_streamNone)
        del arg35_1
        assert_size_stride(arg36_1, (1024, ), (1, ), 'input')
        buf123 = buf52; del buf52  # reuse
        buf125 = reinterpret_tensor(buf121, (1, 512, 1024), (524288, 1024, 1), 0); del buf121  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, h_2, x_5, linear_20, x_6, h_3, x_7, y_3], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_27.run(buf123, buf58, buf81, buf87, buf122, arg36_1, buf125, 512, 1024, stream=raw_streamNone)
        del arg36_1
        del buf122
        del buf58
        del buf81
        del buf87
        assert_size_stride(arg37_1, (2816, 1024), (1024, 1), 'input')
        buf126 = empty_strided_cpu((512, 2816), (2816, 1), torch.float16)
        # Topologically Sorted Source Nodes: [y_3, linear_25], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_14.run(buf125, arg37_1, buf126, 5632, 1, 1, stream=raw_streamNone)
        del arg37_1
        assert_size_stride(arg38_1, (2816, 1024), (1024, 1), 'input')
        buf128 = empty_strided_cpu((1, 512, 2816), (1441792, 2816, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_19], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf125, arg38_1, buf126, buf128, 5632, 1, 1, stream=raw_streamNone)
        del arg38_1
        del buf126
        assert_size_stride(arg39_1, (1024, 2816), (2816, 1), 'input')
        buf129 = reinterpret_tensor(buf125, (512, 1024), (1024, 1), 0); del buf125  # reuse
        # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_19, linear_27], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf128, arg39_1, buf129, 2048, 1, 1, stream=raw_streamNone)
        del arg39_1
        del buf128
        assert_size_stride(arg40_1, (1024, ), (1, ), 'input')
        buf131 = empty_strided_cpu((1, 1, 1024), (1024, 1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_27, x_8, getitem_24, rms_norm_8], Original ATen: [aten._unsafe_view, aten.add, aten.slice, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_slice_28.run(buf123, buf129, arg40_1, buf131, 1, 1024, stream=raw_streamNone)
        del arg40_1
        del buf123
        del buf129
        assert_size_stride(arg41_1, (32000, 1024), (1024, 1), 'input')
        buf132 = empty_strided_cpu((1, 32000), (32000, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_27, x_8, getitem_24, rms_norm_8, logits], Original ATen: [aten._unsafe_view, aten.add, aten.slice, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_slice_t_view_29.run(buf131, arg41_1, buf132, 2000, 1, 1, stream=raw_streamNone)
        del arg41_1
        del buf131
        buf133 = empty_strided_cpu((1, 1), (1, 1), torch.int64)
        # Topologically Sorted Source Nodes: [logits, float_1, argmax], Original ATen: [aten._unsafe_view, aten._to_copy, aten.argmax]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_argmax_30.run(buf132, buf133, 1, 32000, stream=raw_streamNone)
        buf134 = empty_strided_cpu((1, ), (1, ), torch.int64)
        # Topologically Sorted Source Nodes: [position], Original ATen: [aten.full]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused_full_31.run(buf134, 1, stream=raw_streamNone)
        return (reinterpret_tensor(buf132, (1, 1, 32000), (32000, 32000, 1), 0), buf100, buf107, buf133, buf134, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((32000, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg1_1 = rand_strided((1, 512), (512, 1), device='cpu', dtype=torch.int64)
    arg2_1 = rand_strided((512, 64), (64, 1), device='cpu', dtype=torch.float16)
    arg3_1 = rand_strided((512, 64), (64, 1), device='cpu', dtype=torch.float16)
    arg4_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg5_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg6_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg7_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg8_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg9_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg10_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg11_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg12_1 = rand_strided((1024, 2816), (2816, 1), device='cpu', dtype=torch.float16)
    arg13_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg14_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg15_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg16_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg17_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg18_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg19_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg20_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg21_1 = rand_strided((1024, 2816), (2816, 1), device='cpu', dtype=torch.float16)
    arg22_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg23_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg24_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg25_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg26_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg27_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg28_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg29_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg30_1 = rand_strided((1024, 2816), (2816, 1), device='cpu', dtype=torch.float16)
    arg31_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg32_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg33_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg34_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg35_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg36_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg37_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg38_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg39_1 = rand_strided((1024, 2816), (2816, 1), device='cpu', dtype=torch.float16)
    arg40_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg41_1 = rand_strided((32000, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cpu')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
