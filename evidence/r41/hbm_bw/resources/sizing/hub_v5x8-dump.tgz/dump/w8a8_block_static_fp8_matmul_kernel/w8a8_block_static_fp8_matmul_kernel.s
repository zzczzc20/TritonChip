    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #48]                   // N: i32 at arg_base+48
    s.movz       s4, #0
    s.movz       s5, #0
    s.movz       s6, #128
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s6, s7
    s.movz       s7, #15
    s.sub        s10, s8, s9
    s.rdspecial  s8, pid.x
    s.movz       s9, #0
    s.add        s11, s3, s2
    s.ld.sw      s12, [s1, #40]                  // M: i32 at arg_base+40
    s.cmp.lt     s13, s11, s4
    s.movz       s4, #0
    s.sub        s14, s5, s13
    s.rdspecial  s5, pid.y
    s.xor        s13, s11, s14
    s.movz       s11, #16
    s.sub        s15, s13, s14
    s.movz       s13, #0
    s.movz       s16, #0
    s.cmp.lt     s17, s11, s13
    s.add        s13, s12, s7
    s.sub        s7, s16, s17
    s.cmp.lt     s16, s13, s9
    s.xor        s9, s11, s7
    s.sub        s17, s4, s16
    s.ld.d       s4, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.xor        s16, s13, s17
    s.xor        s13, s17, s7
    s.sub        s18, s16, s17
    s.xor        s16, s6, s10
    s.lshri      s17, s18, #4
    s.sub        s19, s9, s7
    s.muli       s7, s17, #16
    s.xor        s9, s17, s13
    s.sub        s17, s9, s13
    s.ld.d       s9, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.sub        s13, s18, s7
    s.sub        s7, s16, s10
    s.ld.d       s7, [s1, #16]                   // C: device_ptr64 at arg_base+16
    s.lshri      s13, s15, #7
    s.ld.d       s16, [s1, #24]                  // As: device_ptr64 at arg_base+24
    s.muli       s18, s13, #128
    s.ld.d       s19, [s1, #32]                  // Bs: device_ptr64 at arg_base+32
    s.xor        s20, s14, s10
    s.sub        s10, s15, s18
    s.xor        s10, s13, s20
    s.ld.sw      s13, [s1, #56]                  // K: i32 at arg_base+56
    s.sub        s14, s10, s20
    s.ld.sw      s10, [s1, #64]                  // stride_am: i32 at arg_base+64
    s.mul        s15, s8, s14
    s.ld.sw      s8, [s1, #72]                   // stride_bn: i32 at arg_base+72
    s.add        s18, s15, s5
    s.ld.sw      s5, [s1, #80]                   // stride_cm: i32 at arg_base+80
    s.movz       s15, #8
    s.ld.sw      s20, [s1, #88]                  // stride_bs_n: i32 at arg_base+88
    s.mul        s1, s14, s15
    s.movz       s14, #0
    s.movz       s21, #0
    s.movz       s22, #0
    s.movz       s23, #0
    s.cmp.lt     s24, s1, s14
    s.cmp.lt     s14, s18, s21
    s.sub        s21, s22, s24
    s.sub        s22, s23, s14
    s.xor        s14, s1, s21
    s.xor        s23, s18, s22
    s.sub        s24, s14, s21
    s.movz       s14, #0
    s.movz       s25, #1
    s.sub        s26, s23, s22
    s.movz       s23, #0
    s.addi       s27, s14, #0
    s.cmp.eq     s14, s24, s25
    s.addi       s25, s23, #0
    s.mov        s27, s26
    br.nz        s14, sdiv_done_1
    s.movz       s14, #0
    s.movz       s23, #31
    s.mov        s27, s14
    s.addi       s14, s23, #0
sdiv_2:
    s.lshr       s23, s26, s14
    s.shli       s28, s25, #1
    s.andi       s29, s23, #1
    s.movz       s23, #0
    s.or         s30, s28, s29
    s.movz       s28, #1
    s.cmp.geu    s29, s30, s24
    s.shl        s31, s28, s14
    s.sub        s28, s23, s29
    s.subi       s23, s14, #1
    s.and        s29, s24, s28
    s.and        s32, s31, s28
    s.sub        s28, s30, s29
    s.or         s29, s27, s32
    s.mov        s25, s28
    s.mov        s27, s29
    s.mov        s14, s23
    s.movz       s23, #0
    s.cmp.ge     s28, s14, s23
    br.nz        s28, sdiv_2
sdiv_done_1:
    s.xor        s14, s22, s21
    s.movz       s21, #0
    s.xor        s22, s27, s14
    s.movz       s23, #0
    s.movz       s24, #0
    s.cmp.lt     s25, s1, s21
    s.sub        s21, s22, s14
    s.movz       s14, #0
    s.cmp.lt     s22, s18, s23
    s.sub        s23, s24, s25
    s.mul        s24, s21, s15
    s.sub        s21, s14, s22
    s.xor        s14, s1, s23
    s.xor        s1, s18, s21
    s.sub        s18, s14, s23
    s.movz       s14, #0
    s.movz       s22, #1
    s.sub        s23, s17, s24
    s.sub        s17, s1, s21
    s.movz       s1, #0
    s.addi       s25, s14, #0
    s.cmp.eq     s14, s18, s22
    s.min.s      s22, s23, s15
    s.addi       s15, s1, #0
    s.mov        s25, s17
    br.nz        s14, sdiv_done_3
    s.movz       s1, #0
    s.movz       s14, #31
    s.mov        s25, s1
    s.addi       s1, s14, #0
sdiv_4:
    s.lshr       s14, s17, s1
    s.shli       s23, s15, #1
    s.andi       s26, s14, #1
    s.movz       s14, #0
    s.or         s27, s23, s26
    s.movz       s23, #1
    s.cmp.geu    s26, s27, s18
    s.shl        s28, s23, s1
    s.sub        s23, s14, s26
    s.subi       s14, s1, #1
    s.and        s26, s18, s23
    s.and        s29, s28, s23
    s.sub        s23, s27, s26
    s.or         s26, s25, s29
    s.mov        s15, s23
    s.mov        s25, s26
    s.mov        s1, s14
    s.movz       s14, #0
    s.cmp.ge     s23, s1, s14
    br.nz        s23, sdiv_4
sdiv_done_3:
    s.xor        s1, s15, s21
    s.movz       s14, #0
    s.sub        s15, s1, s21
    s.movz       s1, #0
    s.movz       s17, #0
    s.cmp.lt     s18, s22, s14
    s.movz       s14, #0
    s.cmp.lt     s21, s15, s1
    s.sub        s1, s17, s18
    s.sub        s17, s14, s21
    s.xor        s14, s22, s1
    s.xor        s18, s15, s17
    s.sub        s21, s14, s1
    s.movz       s1, #0
    s.movz       s14, #1
    s.sub        s23, s18, s17
    s.movz       s18, #0
    s.addi       s25, s1, #0
    s.cmp.eq     s1, s21, s14
    s.addi       s14, s18, #0
    s.mov        s25, s23
    br.nz        s1, sdiv_done_5
    s.movz       s1, #0
    s.movz       s18, #31
    s.mov        s25, s1
    s.addi       s1, s18, #0
sdiv_6:
    s.lshr       s18, s23, s1
    s.shli       s26, s14, #1
    s.andi       s27, s18, #1
    s.movz       s18, #0
    s.or         s28, s26, s27
    s.movz       s26, #1
    s.cmp.geu    s27, s28, s21
    s.shl        s29, s26, s1
    s.sub        s26, s18, s27
    s.subi       s18, s1, #1
    s.and        s27, s21, s26
    s.and        s30, s29, s26
    s.sub        s26, s28, s27
    s.or         s27, s25, s30
    s.mov        s14, s26
    s.mov        s25, s27
    s.mov        s1, s18
    s.movz       s18, #0
    s.cmp.ge     s26, s1, s18
    br.nz        s26, sdiv_6
sdiv_done_5:
    s.movz       s1, #0
    s.movz       s18, #0
    s.movz       s21, #0
    s.cmp.lt     s23, s22, s1
    s.movz       s1, #0
    s.cmp.lt     s25, s15, s18
    s.sub        s18, s21, s23
    s.sub        s21, s1, s25
    s.xor        s1, s22, s18
    s.xor        s22, s14, s17
    s.xor        s14, s15, s21
    s.sub        s15, s1, s18
    s.movz       s1, #0
    s.movz       s23, #1
    s.sub        s25, s22, s17
    s.sub        s17, s14, s21
    s.movz       s14, #0
    s.addi       s22, s1, #0
    s.cmp.eq     s1, s15, s23
    s.add        s23, s24, s25
    s.addi       s24, s14, #0
    s.mov        s22, s17
    br.nz        s1, sdiv_done_7
    s.movz       s1, #0
    s.movz       s14, #31
    s.mov        s22, s1
    s.addi       s1, s14, #0
sdiv_8:
    s.lshr       s14, s17, s1
    s.shli       s25, s24, #1
    s.andi       s26, s14, #1
    s.movz       s14, #0
    s.or         s27, s25, s26
    s.movz       s25, #1
    s.cmp.geu    s26, s27, s15
    s.shl        s28, s25, s1
    s.sub        s25, s14, s26
    s.subi       s14, s1, #1
    s.and        s26, s15, s25
    s.and        s29, s28, s25
    s.sub        s25, s27, s26
    s.or         s26, s22, s29
    s.mov        s24, s25
    s.mov        s22, s26
    s.mov        s1, s14
    s.movz       s14, #0
    s.cmp.ge     s25, s1, s14
    br.nz        s25, sdiv_8
sdiv_done_7:
    s.mul        s1, s23, s11
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s12
    v.movi       v2, #0
    s.xor        s14, s21, s18
    v.splat      v3, s1
    v.sub        v4, v2, v1
    s.xor        s15, s22, s14
    v.add        v5, v3, v0
    v.cmp.lt     p1, v1, v2
    s.sub        s17, s15, s14
    v.sub        v0, v2, v5
    v.cmp.lt     p2, v5, v2
    v.movi       v3, #1
    @p2 v.sel        v6, v0, v5
    @p1 v.sel        v0, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s14, #31
idiv_9:
    v.splat      v5, s14
    v.shl        v7, v4, v3
    v.cmp.lt     p1, v4, v2
    v.lshr       v8, v6, v5
    v.shl        v9, v3, v5
    s.subi       s15, s14, #1
    v.and        v5, v8, v3
    s.movz       s18, #0
    v.or         v8, v7, v5
    v.cmp.geu    p3, v8, v0
    p.or         p4, p1, p3
    v.sub        v5, v8, v0
    @p4 v.sel        v7, v9, v2
    @p4 v.sel        v9, v5, v8
    v.or         v5, v1, v7
    v.mov        v4, v9
    v.mov        v1, v5
    s.mov        s14, s15
    s.cmp.ge     s15, s14, s18
    br.nz        s15, idiv_9
    s.mul        s14, s17, s6
    v.iota       v0                              // arange(0, VLEN)
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v3, #16
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s14
    v.movi       v7, #32
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #48
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #64
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #80
    v.iota       v14                             // arange(0, VLEN)
    v.movi       v15, #96
    v.iota       v16                             // arange(0, VLEN)
    v.movi       v17, #112
    v.add        v18, v6, v0
    v.splat      v0, s3
    v.sub        v6, v2, v4
    v.add        v2, v1, v3
    v.add        v1, v5, v7
    v.add        v3, v8, v9
    v.add        v5, v10, v11
    v.add        v7, v12, v13
    v.add        v8, v14, v15
    v.add        v9, v16, v17
    v.splat      v10, s14
    v.splat      v11, s14
    v.splat      v12, s14
    v.splat      v13, s14
    v.splat      v14, s14
    v.splat      v15, s14
    v.splat      v16, s14
    @p2 v.sel        v17, v6, v4
    v.movi       v4, #0
    v.add        v6, v10, v2
    v.add        v2, v11, v1
    v.sub        v1, v4, v18
    v.sub        v10, v4, v0
    v.cmp.lt     p1, v18, v4
    v.cmp.lt     p2, v0, v4
    v.add        v11, v12, v3
    v.add        v3, v13, v5
    v.add        v5, v14, v7
    v.add        v7, v15, v8
    v.add        v8, v16, v9
    v.splat      v9, s3
    v.splat      v12, s3
    v.splat      v13, s3
    v.splat      v14, s3
    v.splat      v15, s3
    v.splat      v16, s3
    v.splat      v19, s3
    v.movi       v20, #1
    @p1 v.sel        v21, v1, v18
    @p2 v.sel        v1, v10, v0
    v.movi       v0, #0
    v.movi       v10, #0
    s.movz       s15, #31
idiv_10:
    v.splat      v18, s15
    v.shl        v22, v10, v20
    v.cmp.lt     p2, v10, v4
    v.lshr       v23, v21, v18
    v.shl        v24, v20, v18
    s.subi       s17, s15, #1
    v.and        v18, v23, v20
    s.movz       s18, #0
    v.or         v23, v22, v18
    v.cmp.geu    p3, v23, v1
    p.or         p4, p2, p3
    v.sub        v18, v23, v1
    @p4 v.sel        v22, v24, v4
    @p4 v.sel        v24, v18, v23
    v.or         v18, v0, v22
    v.mov        v10, v24
    v.mov        v0, v18
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_10
    v.movi       v0, #0
    v.sub        v1, v4, v10
    v.movi       v4, #1
    v.sub        v18, v0, v6
    v.sub        v20, v0, v9
    v.cmp.lt     p2, v6, v0
    v.cmp.lt     p3, v9, v0
    @p1 v.sel        v21, v1, v10
    @p2 v.sel        v1, v18, v6
    @p3 v.sel        v6, v20, v9
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s15, #31
idiv_11:
    v.splat      v18, s15
    v.shl        v20, v10, v4
    v.cmp.lt     p1, v10, v0
    v.lshr       v22, v1, v18
    v.shl        v23, v4, v18
    s.subi       s17, s15, #1
    v.and        v18, v22, v4
    s.movz       s18, #0
    v.or         v22, v20, v18
    v.cmp.geu    p3, v22, v6
    p.or         p4, p1, p3
    v.sub        v18, v22, v6
    @p4 v.sel        v20, v23, v0
    @p4 v.sel        v23, v18, v22
    v.or         v18, v9, v20
    v.mov        v10, v23
    v.mov        v9, v18
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_11
    v.movi       v1, #0
    v.sub        v4, v0, v10
    v.movi       v0, #1
    v.sub        v6, v1, v2
    v.sub        v9, v1, v12
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p3, v12, v1
    @p2 v.sel        v18, v4, v10
    @p1 v.sel        v4, v6, v2
    @p3 v.sel        v2, v9, v12
    v.movi       v6, #0
    v.movi       v9, #0
    s.movz       s15, #31
idiv_12:
    v.splat      v10, s15
    v.shl        v12, v9, v0
    v.cmp.lt     p2, v9, v1
    v.lshr       v20, v4, v10
    v.shl        v22, v0, v10
    s.subi       s17, s15, #1
    v.and        v10, v20, v0
    s.movz       s18, #0
    v.or         v20, v12, v10
    v.cmp.geu    p3, v20, v2
    p.or         p4, p2, p3
    v.sub        v10, v20, v2
    @p4 v.sel        v12, v22, v1
    @p4 v.sel        v22, v10, v20
    v.or         v10, v6, v12
    v.mov        v9, v22
    v.mov        v6, v10
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_12
    v.movi       v0, #0
    v.sub        v2, v1, v9
    v.movi       v1, #1
    v.sub        v4, v0, v11
    v.sub        v6, v0, v13
    v.cmp.lt     p2, v11, v0
    v.cmp.lt     p3, v13, v0
    @p1 v.sel        v10, v2, v9
    @p2 v.sel        v2, v4, v11
    @p3 v.sel        v4, v6, v13
    v.movi       v6, #0
    v.movi       v9, #0
    s.movz       s15, #31
idiv_13:
    v.splat      v11, s15
    v.shl        v12, v9, v1
    v.cmp.lt     p1, v9, v0
    v.lshr       v13, v2, v11
    v.shl        v20, v1, v11
    s.subi       s17, s15, #1
    v.and        v11, v13, v1
    s.movz       s18, #0
    v.or         v13, v12, v11
    v.cmp.geu    p3, v13, v4
    p.or         p4, p1, p3
    v.sub        v11, v13, v4
    @p4 v.sel        v12, v20, v0
    @p4 v.sel        v20, v11, v13
    v.or         v11, v6, v12
    v.mov        v9, v20
    v.mov        v6, v11
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_13
    v.movi       v1, #0
    v.sub        v2, v0, v9
    v.movi       v0, #1
    v.sub        v4, v1, v3
    v.sub        v6, v1, v14
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p3, v14, v1
    @p2 v.sel        v11, v2, v9
    @p1 v.sel        v2, v4, v3
    @p3 v.sel        v3, v6, v14
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s15, #31
idiv_14:
    v.splat      v9, s15
    v.shl        v12, v6, v0
    v.cmp.lt     p2, v6, v1
    v.lshr       v13, v2, v9
    v.shl        v14, v0, v9
    s.subi       s17, s15, #1
    v.and        v9, v13, v0
    s.movz       s18, #0
    v.or         v13, v12, v9
    v.cmp.geu    p3, v13, v3
    p.or         p4, p2, p3
    v.sub        v9, v13, v3
    @p4 v.sel        v12, v14, v1
    @p4 v.sel        v14, v9, v13
    v.or         v9, v4, v12
    v.mov        v6, v14
    v.mov        v4, v9
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_14
    v.movi       v0, #0
    v.sub        v2, v1, v6
    v.movi       v1, #1
    v.sub        v3, v0, v5
    v.sub        v4, v0, v15
    v.cmp.lt     p2, v5, v0
    v.cmp.lt     p3, v15, v0
    @p1 v.sel        v9, v2, v6
    @p2 v.sel        v2, v3, v5
    @p3 v.sel        v3, v4, v15
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s15, #31
idiv_15:
    v.splat      v6, s15
    v.shl        v12, v5, v1
    v.cmp.lt     p1, v5, v0
    v.lshr       v13, v2, v6
    v.shl        v14, v1, v6
    s.subi       s17, s15, #1
    v.and        v6, v13, v1
    s.movz       s18, #0
    v.or         v13, v12, v6
    v.cmp.geu    p3, v13, v3
    p.or         p4, p1, p3
    v.sub        v6, v13, v3
    @p4 v.sel        v12, v14, v0
    @p4 v.sel        v14, v6, v13
    v.or         v6, v4, v12
    v.mov        v5, v14
    v.mov        v4, v6
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_15
    v.movi       v1, #0
    v.sub        v2, v0, v5
    v.movi       v0, #1
    v.sub        v3, v1, v7
    v.sub        v4, v1, v16
    v.cmp.lt     p1, v7, v1
    v.cmp.lt     p3, v16, v1
    @p2 v.sel        v6, v2, v5
    @p1 v.sel        v2, v3, v7
    @p3 v.sel        v3, v4, v16
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s15, #31
idiv_16:
    v.splat      v7, s15
    v.shl        v12, v5, v0
    v.cmp.lt     p2, v5, v1
    v.lshr       v13, v2, v7
    v.shl        v14, v0, v7
    s.subi       s17, s15, #1
    v.and        v7, v13, v0
    s.movz       s18, #0
    v.or         v13, v12, v7
    v.cmp.geu    p3, v13, v3
    p.or         p4, p2, p3
    v.sub        v7, v13, v3
    @p4 v.sel        v12, v14, v1
    @p4 v.sel        v14, v7, v13
    v.or         v7, v4, v12
    v.mov        v5, v14
    v.mov        v4, v7
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_16
    v.movi       v0, #0
    v.sub        v2, v1, v5
    v.movi       v1, #1
    v.sub        v3, v0, v8
    v.sub        v4, v0, v19
    v.cmp.lt     p2, v8, v0
    v.cmp.lt     p3, v19, v0
    @p1 v.sel        v7, v2, v5
    @p2 v.sel        v2, v3, v8
    @p3 v.sel        v3, v4, v19
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s15, #31
idiv_17:
    v.splat      v8, s15
    v.shl        v12, v5, v1
    v.cmp.lt     p1, v5, v0
    v.lshr       v13, v2, v8
    v.shl        v14, v1, v8
    s.subi       s17, s15, #1
    v.and        v8, v13, v1
    s.movz       s18, #0
    v.or         v13, v12, v8
    v.cmp.geu    p3, v13, v3
    p.or         p4, p1, p3
    v.sub        v8, v13, v3
    @p4 v.sel        v12, v14, v0
    @p4 v.sel        v14, v8, v13
    v.or         v8, v4, v12
    v.mov        v5, v14
    v.mov        v4, v8
    s.mov        s15, s17
    s.cmp.ge     s17, s15, s18
    br.nz        s17, idiv_17
    v.sub        v1, v0, v5
    v.movi       v0, #0
    v.movi       v2, #0
    @p2 v.sel        v3, v1, v5
    v.movi       v1, #0
    v.movi       v4, #0
    v.sub        v5, v0, v21
    v.sub        v8, v2, v18
    v.sub        v12, v1, v10
    v.cmp.lt     p1, v21, v0
    v.cmp.lt     p2, v18, v2
    v.cmp.lt     p3, v10, v1
    @p1 v.sel        v13, v5, v21
    v.movi       v5, #7
    @p2 v.sel        v14, v8, v18
    v.movi       v8, #7
    @p3 v.sel        v15, v12, v10
    v.movi       v12, #7
    v.lshr       v16, v13, v5
    v.lshr       v5, v14, v8
    v.lshr       v8, v15, v12
    v.movi       v12, #128
    v.sub        v13, v0, v16
    v.movi       v14, #128
    v.sub        v15, v2, v5
    v.movi       v19, #128
    v.sub        v20, v1, v8
    v.movi       v22, #128
    v.sub        v23, v0, v12
    @p1 v.sel        v24, v13, v16
    v.sub        v13, v2, v14
    @p2 v.sel        v16, v15, v5
    v.sub        v5, v1, v19
    @p3 v.sel        v15, v20, v8
    v.cmp.lt     p1, v12, v0
    v.cmp.lt     p2, v14, v2
    v.cmp.lt     p3, v19, v1
    s.movz       s15, #32
    s.movz       s17, #48
    s.movz       s18, #64
    v.sub        v0, v4, v11
    s.movz       s21, #80
    s.movz       s22, #96
    v.sub        v1, v4, v22
    s.movz       s23, #112
    v.movi       v2, #7
    v.movi       v8, #1
    v.movi       v8, #0
    v.movi       v20, #128
    @p1 v.sel        v25, v23, v12
    v.sub        v12, v8, v9
    v.cmp.lt     p1, v11, v4
    @p1 v.sel        v23, v0, v11
    v.movi       v0, #7
    v.sub        v25, v8, v20
    v.lshr       v26, v23, v2
    v.movi       v2, #1
    v.movi       v2, #0
    v.sub        v23, v4, v26
    v.movi       v27, #128
    @p2 v.sel        v28, v13, v14
    v.sub        v13, v2, v6
    v.cmp.lt     p2, v9, v8
    @p2 v.sel        v14, v12, v9
    v.movi       v12, #7
    @p1 v.sel        v28, v23, v26
    v.cmp.lt     p1, v6, v2
    @p1 v.sel        v23, v13, v6
    v.lshr       v13, v14, v0
    v.sub        v0, v2, v27
    v.lshr       v14, v23, v12
    v.sub        v12, v8, v13
    v.movi       v23, #1
    v.movi       v23, #0
    v.sub        v26, v2, v14
    @p2 v.sel        v29, v12, v13
    v.cmp.lt     p2, v7, v23
    v.movi       v12, #128
    @p1 v.sel        v13, v26, v14
    v.cmp.lt     p1, v22, v4
    @p3 v.sel        v4, v5, v19
    v.sub        v4, v23, v7
    v.movi       v5, #7
    v.sub        v14, v23, v12
    @p2 v.sel        v19, v4, v7
    v.cmp.lt     p3, v20, v8
    v.movi       v4, #1
    v.movi       v4, #0
    v.lshr       v8, v19, v5
    v.movi       v5, #128
    @p1 v.sel        v19, v1, v22
    v.sub        v1, v4, v3
    v.cmp.lt     p1, v3, v4
    v.movi       v19, #7
    @p1 v.sel        v22, v1, v3
    v.sub        v1, v23, v8
    v.movi       v26, #1
    v.lshr       v26, v22, v19
    @p2 v.sel        v19, v1, v8
    v.sub        v1, v4, v5
    v.sub        v8, v4, v26
    v.cmp.lt     p2, v27, v2
    v.splat      v2, s20
    @p1 v.sel        v22, v8, v26
    v.splat      v8, s20
    v.cmp.lt     p1, v12, v23
    v.splat      v23, s20
    @p3 v.sel        v26, v25, v20
    v.splat      v20, s20
    v.splat      v25, s20
    v.cmp.lt     p3, v5, v4
    v.splat      v4, s20
    v.movi       v26, #1
    @p2 v.sel        v26, v0, v27
    s.add        s24, s13, s2
    s.movz       s2, #0
    s.movz       s25, #0
    s.cmp.lt     s26, s24, s2
    s.movz       s2, #0
    s.sub        s27, s25, s26
    s.movz       s25, #0
    v.splat      v0, s20
    v.splat      v26, s20
    v.movi       v27, #1
    s.xor        s20, s24, s27
    s.cmp.lt     s24, s6, s2
    s.sub        s2, s20, s27
    s.sub        s20, s25, s24
    @p1 v.sel        v27, v14, v12
    s.lshri      s24, s2, #7
    s.xor        s25, s27, s20
    s.muli       s26, s24, #128
    s.xor        s27, s6, s20
    s.xor        s28, s24, s25
    s.movz       s24, #0
    v.movi       v12, #1
    s.movz       s29, #0
    s.movz       s30, #0
    @p3 v.sel        v12, v1, v5
    v.mul        v1, v24, v2
    v.mul        v2, v16, v8
    v.mul        v5, v15, v23
    v.mul        v8, v28, v20
    v.mul        v12, v29, v25
    v.mul        v14, v13, v4
    v.mul        v4, v19, v0
    v.mul        v0, v22, v26
    s.ld.w       s31, [s16, #0]                  // one element, not a vector
    s.sub        s16, s27, s20
    s.sub        s16, s2, s26
    s.sub        s2, s28, s25
    s.movz       s16, #1
    s.addi       s20, s24, #0
    s.addi       s25, s29, #0
    s.addi       s26, s30, #0
    s.addi       s27, s19, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_26:
    s.cmp.ge     s19, s20, s2
    br.nz        s19, endfor_27
    v.extract    s19, v21, #0
    v.iota       v13                             // arange(0, VLEN)
    v.splat      v15, s19
    s.mul        s28, s20, s6
    v.extract    s29, v18, #0
    v.add        v16, v15, v13
    v.splat      v15, s31
    s.movz       s30, #0
    v.sub        v19, v21, v16
    s.sub        s32, s13, s28
    v.splat      v16, s29
    v.reduce.or  s28, v19
    s.movz       s33, #0
    v.add        v19, v16, v13
    s.add        s34, s24, s32
    s.movz       s35, #0
    s.cmp.eq     s36, s28, s30
    s.cmp.ge     s28, s19, s33
    s.cmp.ge     s30, s34, s35
    s.and        s33, s36, s28
    v.movi       v16, #0
    v.movi       v20, #0
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s28, arg_base
    s.and        s35, s33, s30
    v.ld.gather.w v22, [s27, v1]                 // index is in elements (ISA sec 9.1)
    v.splat      v23, s8
    v.sub        v24, v18, v19
    v.splat      v19, s8
    v.splat      v25, s8
    v.splat      v26, s8
    v.splat      v27, s8
    v.splat      v28, s8
    v.splat      v29, s8
    v.splat      v30, s8
    v.mul        v31, v21, v23
    v.reduce.or  s33, v24
    s.movz       s36, #0
    v.mul        v23, v18, v19
    s.movz       s37, #0
    s.cmp.eq     s38, s33, s36
    v.mul        v19, v10, v25
    s.cmp.ge     s33, s29, s37
    v.ld.gather.w v24, [s27, v2]                 // index is in elements (ISA sec 9.1)
    s.and        s36, s38, s33
    v.mul        v25, v11, v26
    s.and        s33, s36, s30
    v.mul        v26, v9, v27
    v.extract    s36, v10, #0
    v.mul        v27, v6, v28
    v.splat      v28, s36
    v.mul        v32, v7, v29
    v.mul        v29, v3, v30
    v.add        v30, v28, v13
    s.movz       s37, #0
    s.movz       s38, #0
    v.sub        v28, v10, v30
    v.ld.gather.w v30, [s27, v5]                 // index is in elements (ISA sec 9.1)
    s.cmp.ge     s39, s36, s38
    v.ld.gather.w v33, [s27, v8]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v34, [s27, v12]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v35, [s27, v14]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v36, [s27, v4]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v37, [s27, v0]                 // index is in elements (ISA sec 9.1)
    s.ld.d       s38, [s28, #96]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.insert     v16, s35, #0
    v.extract    s28, v11, #0
    v.insert     v20, s19, #0
    v.splat      v38, s28
    v.extract    s19, v9, #0
    v.insert     v16, s33, #1
    v.add        v39, v38, v13
    v.splat      v38, s19
    v.extract    s33, v6, #0
    v.sub        v40, v11, v39
    v.add        v39, v38, v13
    v.splat      v38, s33
    v.insert     v20, s29, #1
    v.reduce.or  s29, v28
    v.sub        v28, v9, v39
    s.cmp.eq     s35, s29, s37
    v.extract    s29, v7, #0
    v.add        v39, v38, v13
    v.splat      v38, s29
    s.and        s37, s35, s39
    v.reduce.or  s35, v40
    s.and        s39, s37, s30
    v.sub        v40, v6, v39
    v.add        v39, v38, v13
    v.insert     v16, s39, #2
    s.movz       s37, #0
    v.insert     v20, s36, #2
    s.movz       s36, #0
    s.cmp.eq     s39, s35, s37
    v.extract    s35, v3, #0
    s.cmp.ge     s37, s28, s36
    v.splat      v38, s35
    s.and        s36, s39, s37
    v.reduce.or  s37, v28
    s.and        s39, s36, s30
    v.sub        v28, v7, v39
    v.add        v39, v38, v13
    v.insert     v16, s39, #3
    s.movz       s36, #0
    v.insert     v20, s28, #3
    s.movz       s28, #0
    s.cmp.eq     s39, s37, s36
    s.cmp.ge     s36, s19, s28
    v.reduce.or  s28, v40
    s.and        s37, s39, s36
    s.movz       s36, #0
    s.and        s39, s37, s30
    s.cmp.eq     s37, s28, s36
    s.movz       s28, #0
    v.sub        v13, v3, v39
    s.cmp.ge     s36, s33, s28
    v.insert     v16, s39, #4
    v.reduce.or  s28, v28
    s.and        s39, s37, s36
    s.movz       s36, #0
    v.insert     v20, s19, #4
    s.movz       s19, #0
    s.cmp.eq     s37, s28, s36
    s.cmp.ge     s28, s29, s19
    s.and        s19, s39, s30
    v.reduce.or  s36, v13
    s.and        s39, s37, s28
    s.movz       s28, #0
    v.insert     v16, s19, #5
    s.movz       s19, #0
    v.insert     v20, s33, #5
    s.cmp.eq     s33, s36, s28
    s.cmp.ge     s28, s35, s19
    s.and        s19, s39, s30
    s.and        s36, s33, s28
    v.insert     v16, s19, #6
    v.insert     v20, s29, #6
    s.muli       s19, s10, #2
    s.muli       s28, s25, #2
    s.and        s29, s36, s30
    s.add        s30, s9, s26
    s.addi       s33, s38, #0                    // TensorMap 0: W's rows for a transposed FP8 B
    v.splat      v13, s19
    .li       s19, #2147483647
    s.movz       s36, #1
    v.mul        v28, v17, v13
    .li       s37, #137438953488
    v.insert     v16, s29, #7
    v.extract    s29, v28, #0
    v.insert     v20, s35, #7
    s.movz       s35, #0
    s.add        s39, s29, s28
    v.iota       v13                             // arange(0, VLEN)
    s.add        s29, s4, s39
    s.st.d       [s33, #0], s30
    .li       s30, #7705171329024
    s.movz       s39, #0
    s.add        s39, s35, s32                   // the tile origin
    s.movz       s35, #0
    v.splat      v38, s39
    s.addi       s35, s38, #256
    v.cmp.lt     p1, v13, v38
    s.st.d       [s33, #8], s19
    s.addi       s19, s38, #768                  // TensorMap 1: the gathered fallback B tile
    s.st.d       [s33, #16], s34
    s.st.d       [s33, #48], s8
    v.rcp.approx v38, v15                        // ISA 8.8: <= 2**-22 relative
    .li       s39, #1065353216
    v.splat      v39, s39                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.st.d       [s33, #56], s36
    s.movz       s36, #32
    s.st.d       [s33, #88], s37
    s.movz       s37, #16
    vf.fms       v40, v15, v38, v39
    s.st.d       [s33, #104], s30
    s.movz       s30, #16
    td.load      d0, [s33]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s33, #1
    vf.fms       v41, v38, v40, v38
    vf.neg       v40, v41                        // Newton step: r0*(2 - x*r0)
    s.st.d       [s19, #0], s35
    .li       s35, #68719476768
    vf.cmp.o     p2, v40, v40
    @p2 v.sel        v41, v40, v38
    s.st.d       [s19, #8], s36
    .li       s36, #7705171329024
    v.movi       v38, #24
    s.st.d       [s19, #16], s37
    v.movi       v40, #128
    s.addi       s37, s38, #1024                 // 512 bytes of repack scratch
    s.st.d       [s19, #48], s30
    s.st.d       [s19, #56], s33
    s.addi       s30, s37, #0
    s.st.d       [s19, #88], s35
    v.extract    s33, v28, #1
    s.add        s35, s33, s28
    s.st.d       [s19, #104], s36
    td.load      d1, [s19]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v43, [s29, #0]
    s.add        s19, s4, s35
    v.extract    s29, v28, #2
    s.addi       s33, s37, #32
    s.add        s35, s29, s28
    s.add        s29, s4, s35
    vf.cvt.bf16.f32 v44, v43
    v.rcp.approx v43, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v44, v41                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v44
    vf.fms       v44, v15, v42, v39
    vf.fms       v47, v46, v41, v45
    vf.fms       v41, v42, v44, v42
    vf.neg       v44, v47                        // a/y: one correction to the IEEE quotient
    vf.neg       v46, v41                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v41, v44, v45
    vf.cmp.o     p2, v46, v46
    v.lshr       v44, v41, v38
    vf.cvt.f32.e4m3 v45, v41
    @p2 v.sel        v41, v46, v42
    v.and        v42, v44, v40
    vf.fms       v44, v15, v43, v39
    s.addi       s35, s37, #64
    v.or         v46, v45, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s36, v28, #3
    v.st.b       [s30, #0], v46
    vf.fms       v42, v43, v44, v43
    s.add        s30, s36, s28
    s.add        s36, s4, s30
    vf.neg       v44, v42                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v44, v44
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s19, #0]
    @p2 v.sel        v45, v44, v43
    v.rcp.approx v43, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v44, v42
    vf.mul       v42, v44, v41                   // a/y: faithful quotient
    vf.fms       v46, v42, v15, v44
    vf.fms       v44, v46, v41, v42
    vf.fms       v41, v15, v43, v39
    vf.neg       v46, v44                        // a/y: one correction to the IEEE quotient
    vf.fms       v44, v43, v41, v43
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v41, v46, v42
    vf.neg       v42, v44                        // Newton step: r0*(2 - x*r0)
    v.lshr       v44, v41, v38
    vf.cvt.f32.e4m3 v46, v41
    v.and        v41, v44, v40
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v43
    v.or         v42, v46, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s19, v28, #4
    s.addi       s30, s37, #96
    v.st.b       [s33, #0], v42
    s.add        s33, s19, s28
    s.add        s19, s4, s33
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s29, #0]
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v43, v41
    vf.mul       v41, v43, v45                   // a/y: faithful quotient
    vf.fms       v46, v41, v15, v43
    vf.fms       v43, v46, v45, v41
    vf.fms       v45, v15, v42, v39
    vf.neg       v46, v43                        // a/y: one correction to the IEEE quotient
    vf.fms       v43, v42, v45, v42
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v45, v46, v41
    vf.neg       v41, v43                        // Newton step: r0*(2 - x*r0)
    v.lshr       v43, v45, v38
    vf.cvt.f32.e4m3 v46, v45
    v.and        v45, v43, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v43, v41, v42
    v.or         v41, v46, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s29, v28, #5
    s.addi       s33, s37, #128
    v.st.b       [s35, #0], v41
    s.add        s35, s29, s28
    s.add        s29, s4, s35
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s36, #0]
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v45, v41
    vf.mul       v41, v45, v44                   // a/y: faithful quotient
    vf.fms       v46, v41, v15, v45
    vf.fms       v45, v46, v44, v41
    vf.fms       v44, v15, v42, v39
    vf.neg       v46, v45                        // a/y: one correction to the IEEE quotient
    vf.fms       v45, v42, v44, v42
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v44, v46, v41
    vf.neg       v41, v45                        // Newton step: r0*(2 - x*r0)
    v.lshr       v45, v44, v38
    vf.cvt.f32.e4m3 v46, v44
    v.and        v44, v45, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v45, v41, v42
    v.or         v41, v46, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s35, v28, #6
    s.addi       s36, s37, #160
    v.st.b       [s30, #0], v41
    s.add        s30, s35, s28
    s.add        s35, s4, s30
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s19, #0]
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v44, v41
    vf.mul       v41, v44, v43                   // a/y: faithful quotient
    vf.fms       v46, v41, v15, v44
    vf.fms       v44, v46, v43, v41
    vf.fms       v43, v15, v42, v39
    vf.neg       v46, v44                        // a/y: one correction to the IEEE quotient
    vf.fms       v44, v42, v43, v42
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v43, v46, v41
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    v.lshr       v44, v43, v38
    vf.cvt.f32.e4m3 v46, v43
    v.and        v43, v44, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v44, v41, v42
    v.or         v41, v46, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s19, v28, #7
    s.addi       s30, s37, #192
    v.st.b       [s33, #0], v41
    s.add        s33, s19, s28
    s.add        s19, s4, s33
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s29, #0]
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v43, v41
    vf.mul       v41, v43, v45                   // a/y: faithful quotient
    vf.fms       v46, v41, v15, v43
    vf.fms       v43, v46, v45, v41
    vf.fms       v45, v15, v42, v39
    vf.neg       v46, v43                        // a/y: one correction to the IEEE quotient
    vf.fms       v43, v42, v45, v42
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v45, v46, v41
    vf.neg       v41, v43                        // Newton step: r0*(2 - x*r0)
    v.lshr       v43, v45, v38
    vf.cvt.f32.e4m3 v46, v45
    v.and        v45, v43, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v43, v41, v42
    v.or         v41, v46, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s29, v28, #8
    s.addi       s33, s37, #224
    v.st.b       [s36, #0], v41
    s.add        s36, s29, s28
    s.add        s29, s4, s36
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s35, #0]
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v45, v41
    vf.mul       v41, v45, v44                   // a/y: faithful quotient
    vf.fms       v46, v41, v15, v45
    vf.fms       v45, v46, v44, v41
    vf.fms       v44, v15, v42, v39
    vf.neg       v46, v45                        // a/y: one correction to the IEEE quotient
    vf.fms       v45, v42, v44, v42
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v44, v46, v41
    vf.neg       v41, v45                        // Newton step: r0*(2 - x*r0)
    v.lshr       v45, v44, v38
    vf.cvt.f32.e4m3 v46, v44
    v.and        v44, v45, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v45, v41, v42
    v.or         v41, v46, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s35, v28, #9
    s.addi       s36, s37, #256
    v.st.b       [s30, #0], v41
    s.add        s30, s35, s28
    s.add        s35, s4, s30
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s19, #0]
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v44, v41
    vf.mul       v41, v44, v43                   // a/y: faithful quotient
    vf.fms       v46, v41, v15, v44
    vf.fms       v44, v46, v43, v41
    vf.fms       v43, v15, v42, v39
    vf.neg       v46, v44                        // a/y: one correction to the IEEE quotient
    vf.fms       v44, v42, v43, v42
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v43, v46, v41
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    v.lshr       v44, v43, v38
    vf.cvt.f32.e4m3 v46, v43
    v.and        v43, v44, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v44, v41, v42
    v.or         v41, v46, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s19, v28, #10
    s.addi       s30, s37, #288
    v.st.b       [s33, #0], v41
    s.add        s33, s19, s28
    s.add        s19, s4, s33
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s29, #0]
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v43, v41
    vf.mul       v41, v43, v45                   // a/y: faithful quotient
    vf.fms       v46, v41, v15, v43
    vf.fms       v43, v46, v45, v41
    vf.fms       v45, v15, v42, v39
    vf.neg       v46, v43                        // a/y: one correction to the IEEE quotient
    vf.fms       v43, v42, v45, v42
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v45, v46, v41
    vf.neg       v41, v43                        // Newton step: r0*(2 - x*r0)
    v.lshr       v43, v45, v38
    vf.cvt.f32.e4m3 v46, v45
    v.and        v45, v43, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v43, v41, v42
    v.or         v41, v46, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s29, v28, #11
    s.addi       s33, s37, #320
    v.st.b       [s36, #0], v41
    s.add        s36, s29, s28
    s.add        s29, s4, s36
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s35, #0]
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v45, v41
    vf.mul       v41, v45, v44                   // a/y: faithful quotient
    vf.fms       v46, v41, v15, v45
    vf.fms       v45, v46, v44, v41
    vf.fms       v44, v15, v42, v39
    vf.neg       v46, v45                        // a/y: one correction to the IEEE quotient
    vf.fms       v45, v42, v44, v42
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v44, v46, v41
    vf.neg       v41, v45                        // Newton step: r0*(2 - x*r0)
    v.lshr       v45, v44, v38
    vf.cvt.f32.e4m3 v46, v44
    v.and        v44, v45, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v45, v41, v42
    v.or         v41, v46, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s35, v28, #12
    s.addi       s36, s37, #352
    v.st.b       [s30, #0], v41
    s.add        s30, s35, s28
    s.add        s35, s4, s30
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s19, #0]
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v44, v41
    vf.mul       v41, v44, v43                   // a/y: faithful quotient
    vf.fms       v46, v41, v15, v44
    vf.fms       v44, v46, v43, v41
    vf.fms       v43, v15, v42, v39
    vf.neg       v46, v44                        // a/y: one correction to the IEEE quotient
    vf.fms       v44, v42, v43, v42
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v43, v46, v41
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    v.lshr       v44, v43, v38
    vf.cvt.f32.e4m3 v46, v43
    v.and        v43, v44, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v44, v41, v42
    v.or         v41, v46, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s19, v28, #13
    s.addi       s30, s37, #384
    v.st.b       [s33, #0], v41
    s.add        s33, s19, s28
    s.add        s19, s4, s33
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s29, #0]
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v43, v41
    vf.mul       v41, v43, v45                   // a/y: faithful quotient
    vf.fms       v46, v41, v15, v43
    vf.fms       v43, v46, v45, v41
    vf.fms       v45, v15, v42, v39
    vf.neg       v46, v43                        // a/y: one correction to the IEEE quotient
    vf.fms       v43, v42, v45, v42
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v45, v46, v41
    vf.neg       v41, v43                        // Newton step: r0*(2 - x*r0)
    v.lshr       v43, v45, v38
    vf.cvt.f32.e4m3 v46, v45
    v.and        v45, v43, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v43, v41, v42
    v.or         v41, v46, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s29, v28, #14
    s.addi       s33, s37, #416
    v.st.b       [s36, #0], v41
    s.add        s36, s29, s28
    s.add        s29, s4, s36
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s35, #0]
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v45, v41
    vf.mul       v41, v45, v44                   // a/y: faithful quotient
    vf.fms       v46, v41, v15, v45
    vf.fms       v45, v46, v44, v41
    vf.fms       v44, v15, v42, v39
    vf.neg       v46, v45                        // a/y: one correction to the IEEE quotient
    vf.fms       v45, v42, v44, v42
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v44, v46, v41
    vf.neg       v41, v45                        // Newton step: r0*(2 - x*r0)
    v.lshr       v45, v44, v38
    vf.cvt.f32.e4m3 v46, v44
    v.and        v44, v45, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v45, v41, v42
    v.or         v41, v46, v44                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s35, v28, #15
    s.addi       s36, s37, #448
    v.st.b       [s30, #0], v41
    s.add        s30, s35, s28
    s.add        s35, s4, s30
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s19, #0]
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cvt.bf16.f32 v44, v41
    vf.mul       v41, v44, v43                   // a/y: faithful quotient
    vf.fms       v46, v41, v15, v44
    vf.fms       v44, v46, v43, v41
    vf.fms       v43, v15, v42, v39
    vf.neg       v46, v44                        // a/y: one correction to the IEEE quotient
    vf.fms       v44, v42, v43, v42
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v43, v46, v41
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    v.lshr       v44, v43, v38
    vf.cvt.f32.e4m3 v46, v43
    v.and        v43, v44, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v44, v41, v42
    v.or         v41, v46, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.extract    s19, v28, #0
    s.addi       s30, s37, #480
    v.st.b       [s33, #0], v41
    s.movz       s33, #0
    s.add        s39, s19, s28
    s.addi       s19, s39, #32
    s.add        s39, s4, s19
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s29, #0]
    s.add        s19, s33, s11                   // the tile origin
    vf.cvt.bf16.f32 v42, v41
    s.movz       s29, #0
    v.splat      v41, s19
    s.add        s19, s29, s32                   // the tile origin
    vf.mul       v43, v42, v45                   // a/y: faithful quotient
    v.add        v46, v13, v41
    v.splat      v41, s19
    vf.fms       v47, v43, v15, v42
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    v.cmp.lt     p2, v46, v41
    vf.fms       v41, v47, v45, v43
    vf.neg       v45, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v45, v45
    @p3 v.sel        v41, v45, v43
    v.lshr       v43, v41, v38
    vf.cvt.f32.e4m3 v45, v41
    v.and        v41, v43, v40
    v.or         v43, v45, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v43
    vf.fms       v41, v15, v42, v39
    vf.fms       v43, v42, v41, v42
    vf.neg       v41, v43                        // Newton step: r0*(2 - x*r0)
    v.movi       v43, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v43, [s35, #0]
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v45, v41, v42
    vf.cvt.bf16.f32 v41, v43
    v.extract    s19, v28, #1
    s.addi       s29, s37, #16
    s.add        s33, s19, s28
    vf.mul       v42, v41, v44                   // a/y: faithful quotient
    s.addi       s19, s33, #32
    s.add        s33, s4, s19
    vf.fms       v43, v42, v15, v41
    vf.fms       v41, v43, v44, v42
    v.rcp.approx v43, v15                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v44, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v41, v44, v42
    v.lshr       v42, v41, v38
    vf.cvt.f32.e4m3 v44, v41
    v.and        v41, v42, v40
    v.or         v42, v44, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s30, #0], v42
    v.extract    s19, v28, #2
    s.addi       s30, s37, #48
    s.add        s35, s19, s28
    s.addi       s19, s35, #32
    vf.fms       v41, v15, v43, v39
    s.add        s35, s4, s19
    vf.fms       v42, v43, v41, v43
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s39, #0]
    vf.neg       v44, v42                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v43
    vf.cvt.bf16.f32 v43, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v43, v45                   // a/y: faithful quotient
    vf.fms       v46, v44, v15, v43
    vf.fms       v43, v46, v45, v44
    vf.neg       v45, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v45, v45
    @p1 v.sel        v43, v45, v44
    v.lshr       v44, v43, v38
    vf.cvt.f32.e4m3 v45, v43
    vf.fms       v43, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v43, v41
    s.addi       s19, s37, #80
    v.st.b       [s29, #0], v44
    v.extract    s29, v28, #3
    vf.neg       v43, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s36, s29, s28
    s.addi       s29, s36, #32
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    s.add        s36, s4, s29
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s33, #0]
    vf.cvt.bf16.f32 v43, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v43, v42                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v43
    vf.fms       v43, v46, v42, v45
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v45
    v.lshr       v42, v43, v38
    vf.cvt.f32.e4m3 v45, v43
    vf.fms       v43, v15, v41, v39
    v.and        v46, v42, v40
    v.or         v42, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v43, v41
    s.addi       s29, s37, #112
    v.st.b       [s30, #0], v42
    v.extract    s30, v28, #4
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s33, s30, s28
    s.addi       s30, s33, #32
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s33, s4, s30
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s35, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s30, s37, #144
    v.st.b       [s19, #0], v44
    v.extract    s19, v28, #5
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s35, s19, s28
    s.addi       s19, s35, #32
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s35, s4, s19
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s36, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s19, s37, #176
    v.st.b       [s29, #0], v43
    v.extract    s29, v28, #6
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s36, s29, s28
    s.addi       s29, s36, #32
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s36, s4, s29
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s33, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s29, s37, #208
    v.st.b       [s30, #0], v44
    v.extract    s30, v28, #7
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s33, s30, s28
    s.addi       s30, s33, #32
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s33, s4, s30
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s35, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s30, s37, #240
    v.st.b       [s19, #0], v43
    v.extract    s19, v28, #8
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s35, s19, s28
    s.addi       s19, s35, #32
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s35, s4, s19
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s36, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s19, s37, #272
    v.st.b       [s29, #0], v44
    v.extract    s29, v28, #9
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s36, s29, s28
    s.addi       s29, s36, #32
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s36, s4, s29
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s33, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s29, s37, #304
    v.st.b       [s30, #0], v43
    v.extract    s30, v28, #10
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s33, s30, s28
    s.addi       s30, s33, #32
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s33, s4, s30
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s35, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s30, s37, #336
    v.st.b       [s19, #0], v44
    v.extract    s19, v28, #11
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s35, s19, s28
    s.addi       s19, s35, #32
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s35, s4, s19
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s36, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s19, s37, #368
    v.st.b       [s29, #0], v43
    v.extract    s29, v28, #12
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s36, s29, s28
    s.addi       s29, s36, #32
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s36, s4, s29
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s33, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s29, s37, #400
    v.st.b       [s30, #0], v44
    v.extract    s30, v28, #13
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s33, s30, s28
    s.addi       s30, s33, #32
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s33, s4, s30
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s35, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s30, s37, #432
    v.st.b       [s19, #0], v43
    v.extract    s19, v28, #14
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s35, s19, s28
    s.addi       s19, s35, #32
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s35, s4, s19
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s36, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s19, s37, #464
    v.st.b       [s29, #0], v44
    v.extract    s29, v28, #15
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s36, s29, s28
    s.addi       s29, s36, #32
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s36, s4, s29
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s33, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s29, s37, #496
    v.st.b       [s30, #0], v43
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s35, #0]
    s.addi       s30, s37, #64
    vf.cvt.bf16.f32 v42, v41
    s.addi       s33, s37, #128
    s.addi       s35, s37, #192
    vf.mul       v41, v42, v44                   // a/y: faithful quotient
    vf.fms       v45, v41, v15, v42
    vf.fms       v42, v45, v44, v41
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v41
    v.lshr       v41, v42, v38
    vf.cvt.f32.e4m3 v44, v42
    v.and        v42, v41, v40
    v.or         v41, v44, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s19, #0], v41
    s.addi       s19, s37, #256
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s36, #0]
    s.addi       s36, s37, #320
    vf.cvt.bf16.f32 v42, v41
    vf.mul       v41, v42, v43                   // a/y: faithful quotient
    vf.fms       v44, v41, v15, v42
    vf.fms       v42, v44, v43, v41
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v41
    v.lshr       v41, v42, v38
    vf.cvt.f32.e4m3 v43, v42
    v.and        v42, v41, v40
    v.or         v41, v43, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s29, #0], v41
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s29, s37, #384
    v.ld.w       v41, [s37, #0]
    s.addi       s39, s37, #448
    v.mov        v48, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s30, #0]
    v.extract    s30, v16, #0
    v.mov        v49, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s33, #0]
    v.mov        v50, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s35, #0]
    v.mov        v51, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s19, #0]
    v.mov        v52, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s36, #0]
    v.mov        v53, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s29, #0]
    v.mov        v54, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s39, #0]
    v.mov        v55, v41                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s30, x8dot_done_28
    s.movz       s19, #0
    s.add        s29, s9, s26
    s.addi       s33, s19, #0
    s.addi       s19, s38, #256
x8dot_row_29:
    s.addi       s35, s34, #0
    v.movi       v41, #0
    s.sub        s36, s35, s33
    s.add        s35, s29, s33
    v.splat      v42, s36
    s.shli       s36, s33, #4
    s.addi       s37, s33, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s35, v31]            // index is in elements (ISA sec 9.1)
    s.add        s35, s19, s36
    s.movz       s36, #32
    v.st.b       [s35, #0], v41
    fence.acq_rel.device
    s.mov        s33, s37
    s.cmp.lt     s35, s33, s36
    br.nz        s35, x8dot_row_29
x8dot_done_28:
    v.splat      v41, s30
    v.movi       v42, #0
    v.splat      v43, s30
    v.movi       v44, #0
    mb.arm       s19, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    s.movz       s30, #0
    v.extract    s33, v20, #0
    s.movz       s35, #0
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s36, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s19            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s29, s19          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s19
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s30, v16, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s30, x8dot_done_30
    s.movz       s33, #0
    s.add        s35, s9, s26
    s.addi       s36, s33, #0
    s.addi       s33, s38, #256
x8dot_row_31:
    s.addi       s37, s34, #0
    v.movi       v41, #0
    s.sub        s39, s37, s36
    s.add        s37, s35, s36
    v.splat      v42, s39
    s.shli       s39, s36, #4
    s.addi       s40, s36, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s37, v23]            // index is in elements (ISA sec 9.1)
    s.add        s37, s33, s39
    s.movz       s39, #32
    v.st.b       [s37, #0], v41
    fence.acq_rel.device
    s.mov        s36, s40
    s.cmp.lt     s37, s36, s39
    br.nz        s37, x8dot_row_31
x8dot_done_30:
    v.splat      v41, s30
    v.movi       v42, #0
    v.splat      v43, s30
    v.movi       v44, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    s.movz       s35, #0
    v.extract    s36, v20, #1
    s.movz       s37, #0
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s39, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s39, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v16, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s33
    mb.wait      s33
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_32
    s.movz       s36, #0
    s.add        s37, s9, s26
    s.addi       s39, s36, #0
    s.addi       s36, s38, #256
x8dot_row_33:
    s.addi       s40, s34, #0
    v.movi       v41, #0
    s.sub        s41, s40, s39
    s.add        s40, s37, s39
    v.splat      v42, s41
    s.shli       s41, s39, #4
    s.addi       s42, s39, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s40, v19]            // index is in elements (ISA sec 9.1)
    s.add        s40, s36, s41
    s.movz       s41, #32
    v.st.b       [s40, #0], v41
    fence.acq_rel.device
    s.mov        s39, s42
    s.cmp.lt     s40, s39, s41
    br.nz        s40, x8dot_row_33
x8dot_done_32:
    v.splat      v41, s35
    v.movi       v42, #0
    v.splat      v43, s35
    v.movi       v44, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    s.movz       s37, #0
    v.extract    s39, v20, #2
    s.movz       s40, #0
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s41, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v16, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_34
    s.movz       s39, #0
    s.add        s40, s9, s26
    s.addi       s41, s39, #0
    s.addi       s39, s38, #256
x8dot_row_35:
    s.addi       s42, s34, #0
    v.movi       v41, #0
    s.sub        s43, s42, s41
    s.add        s42, s40, s41
    v.splat      v42, s43
    s.shli       s43, s41, #4
    s.addi       s44, s41, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s42, v25]            // index is in elements (ISA sec 9.1)
    s.add        s42, s39, s43
    s.movz       s43, #32
    v.st.b       [s42, #0], v41
    fence.acq_rel.device
    s.mov        s41, s44
    s.cmp.lt     s42, s41, s43
    br.nz        s42, x8dot_row_35
x8dot_done_34:
    v.splat      v41, s37
    v.movi       v42, #0
    v.splat      v43, s37
    v.movi       v44, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    s.movz       s40, #0
    v.extract    s41, v20, #3
    s.movz       s42, #0
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v16, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_36
    s.movz       s41, #0
    s.add        s42, s9, s26
    s.addi       s43, s41, #0
    s.addi       s41, s38, #256
x8dot_row_37:
    s.addi       s44, s34, #0
    v.movi       v41, #0
    s.sub        s45, s44, s43
    s.add        s44, s42, s43
    v.splat      v42, s45
    s.shli       s45, s43, #4
    s.addi       s46, s43, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s44, v26]            // index is in elements (ISA sec 9.1)
    s.add        s44, s41, s45
    s.movz       s45, #32
    v.st.b       [s44, #0], v41
    fence.acq_rel.device
    s.mov        s43, s46
    s.cmp.lt     s44, s43, s45
    br.nz        s44, x8dot_row_37
x8dot_done_36:
    v.splat      v41, s40
    v.movi       v42, #0
    v.splat      v43, s40
    v.movi       v44, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    s.movz       s42, #0
    v.extract    s43, v20, #4
    s.movz       s44, #0
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v16, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_38
    s.movz       s43, #0
    s.add        s44, s9, s26
    s.addi       s45, s43, #0
    s.addi       s43, s38, #256
x8dot_row_39:
    s.addi       s46, s34, #0
    v.movi       v41, #0
    s.sub        s47, s46, s45
    s.add        s46, s44, s45
    v.splat      v42, s47
    s.shli       s47, s45, #4
    s.addi       s48, s45, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s46, v27]            // index is in elements (ISA sec 9.1)
    s.add        s46, s43, s47
    s.movz       s47, #32
    v.st.b       [s46, #0], v41
    fence.acq_rel.device
    s.mov        s45, s48
    s.cmp.lt     s46, s45, s47
    br.nz        s46, x8dot_row_39
x8dot_done_38:
    v.splat      v41, s42
    v.movi       v42, #0
    v.splat      v43, s42
    v.movi       v44, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    s.movz       s44, #0
    v.extract    s45, v20, #5
    s.movz       s46, #0
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v16, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s43
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_40
    s.movz       s45, #0
    s.add        s46, s9, s26
    s.addi       s47, s45, #0
    s.addi       s45, s38, #256
x8dot_row_41:
    s.addi       s48, s34, #0
    v.movi       v41, #0
    s.sub        s49, s48, s47
    s.add        s48, s46, s47
    v.splat      v42, s49
    s.shli       s49, s47, #4
    s.addi       s50, s47, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s48, v32]            // index is in elements (ISA sec 9.1)
    s.add        s48, s45, s49
    s.movz       s49, #32
    v.st.b       [s48, #0], v41
    fence.acq_rel.device
    s.mov        s47, s50
    s.cmp.lt     s48, s47, s49
    br.nz        s48, x8dot_row_41
x8dot_done_40:
    v.splat      v41, s44
    v.movi       v42, #0
    v.splat      v43, s44
    v.movi       v44, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    s.movz       s46, #0
    v.extract    s47, v20, #6
    s.movz       s48, #0
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v16, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s45
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s46, x8dot_done_42
    s.movz       s47, #0
    s.add        s48, s9, s26
    s.addi       s49, s47, #0
    s.addi       s47, s38, #256
x8dot_row_43:
    s.addi       s50, s34, #0
    v.movi       v41, #0
    s.sub        s51, s50, s49
    s.add        s50, s48, s49
    v.splat      v42, s51
    s.shli       s51, s49, #4
    s.addi       s52, s49, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s50, v29]            // index is in elements (ISA sec 9.1)
    s.add        s50, s47, s51
    s.movz       s51, #32
    v.st.b       [s50, #0], v41
    fence.acq_rel.device
    s.mov        s49, s52
    s.cmp.lt     s50, s49, s51
    br.nz        s50, x8dot_row_43
x8dot_done_42:
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    s.movz       s47, #0
    v.extract    s48, v28, #0
    s.add        s49, s47, s15                   // the tile origin
    s.movz       s47, #0
    v.splat      v42, s46
    v.movi       v43, #0
    v.splat      v44, s46
    v.movi       v45, #0
    v.splat      v46, s49
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.add        s49, s48, s28
    s.add        s48, s47, s32                   // the tile origin
    s.movz       s47, #0
    s.movz       s50, #0
    v.extract    s51, v20, #7
    s.movz       s52, #0
    v.cmp.ne     p1, v42, v43
    v.cmp.eq     p2, v44, v45
    s.addi       s53, s49, #64
    v.add        v42, v13, v46
    v.splat      v43, s48
    s.mov        s48, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s48, s46            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s48, s4, s53
    v.cmp.lt     p1, v42, v43
    m.mma.async.k32.e4m3 a15, v48, v56, s47
    mb.wait      s47
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s48, #0]
    vf.fms       v43, v15, v41, v39
    v.rcp.approx v44, v15                        // ISA 8.8: <= 2**-22 relative
    v.extract    s48, v28, #1
    s.addi       s49, s38, #1536                 // 512 bytes of repack scratch
    s.add        s50, s48, s28
    vf.fms       v45, v41, v43, v41
    s.addi       s48, s50, #64
    s.addi       s50, s49, #0
    s.add        s51, s4, s48
    v.extract    s48, v28, #2
    vf.neg       v43, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s52, s48, s28
    s.addi       s48, s49, #32
    vf.cvt.bf16.f32 v45, v42
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v46, v43, v41
    s.addi       s53, s52, #64
    vf.mul       v41, v45, v46                   // a/y: faithful quotient
    s.add        s52, s4, s53
    vf.fms       v43, v41, v15, v45
    vf.fms       v45, v43, v46, v41
    vf.fms       v43, v15, v44, v39
    vf.neg       v46, v45                        // a/y: one correction to the IEEE quotient
    vf.fms       v45, v44, v43, v44
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v43, v46, v41
    vf.neg       v41, v45                        // Newton step: r0*(2 - x*r0)
    vf.fms       v45, v15, v42, v39
    v.lshr       v46, v43, v38
    vf.cvt.f32.e4m3 v47, v43
    v.and        v43, v46, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v46, v41, v44
    v.or         v41, v47, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v43, v42, v45, v42
    s.addi       s53, s49, #64
    v.st.b       [s50, #0], v41
    v.extract    s50, v28, #3
    vf.neg       v41, v43                        // Newton step: r0*(2 - x*r0)
    s.add        s54, s50, s28
    s.addi       s50, s54, #64
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v43, v41, v42
    s.add        s54, s4, s50
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s51, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v42, v46                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v42
    vf.fms       v42, v45, v46, v44
    vf.neg       v45, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v45, v45
    @p2 v.sel        v42, v45, v44
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s50, s49, #96
    v.st.b       [s48, #0], v44
    v.extract    s48, v28, #4
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s48, s28
    s.addi       s48, s51, #64
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s51, s4, s48
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s52, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s48, s49, #128
    v.st.b       [s53, #0], v43
    v.extract    s52, v28, #5
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s53, s52, s28
    s.addi       s52, s53, #64
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s53, s4, s52
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s54, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s52, s49, #160
    v.st.b       [s50, #0], v44
    v.extract    s50, v28, #6
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s54, s50, s28
    s.addi       s50, s54, #64
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s54, s4, s50
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s51, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s50, s49, #192
    v.st.b       [s48, #0], v43
    v.extract    s48, v28, #7
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s48, s28
    s.addi       s48, s51, #64
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s51, s4, s48
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s53, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s48, s49, #224
    v.st.b       [s52, #0], v44
    v.extract    s52, v28, #8
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s53, s52, s28
    s.addi       s52, s53, #64
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s53, s4, s52
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s54, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s52, s49, #256
    v.st.b       [s50, #0], v43
    v.extract    s50, v28, #9
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s54, s50, s28
    s.addi       s50, s54, #64
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s54, s4, s50
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s51, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s50, s49, #288
    v.st.b       [s48, #0], v44
    v.extract    s48, v28, #10
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s48, s28
    s.addi       s48, s51, #64
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s51, s4, s48
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s53, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s48, s49, #320
    v.st.b       [s52, #0], v43
    v.extract    s52, v28, #11
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s53, s52, s28
    s.addi       s52, s53, #64
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s53, s4, s52
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s54, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s52, s49, #352
    v.st.b       [s50, #0], v44
    v.extract    s50, v28, #12
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s54, s50, s28
    s.addi       s50, s54, #64
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s54, s4, s50
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s51, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s50, s49, #384
    v.st.b       [s48, #0], v43
    v.extract    s48, v28, #13
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s48, s28
    s.addi       s48, s51, #64
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s51, s4, s48
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s53, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s48, s49, #416
    v.st.b       [s52, #0], v44
    v.extract    s52, v28, #14
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s53, s52, s28
    s.addi       s52, s53, #64
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s53, s4, s52
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s54, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s52, s49, #448
    v.st.b       [s50, #0], v43
    v.extract    s50, v28, #15
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s54, s50, s28
    s.addi       s50, s54, #64
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s54, s4, s50
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s51, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s50, s49, #480
    v.st.b       [s48, #0], v44
    v.extract    s48, v28, #0
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s51, s48, s28
    s.addi       s48, s51, #96
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s51, s4, s48
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s53, #0]
    s.movz       s48, #0
    vf.cvt.bf16.f32 v42, v41
    s.add        s53, s48, s17                   // the tile origin
    s.movz       s48, #0
    v.splat      v41, s53
    s.add        s53, s48, s32                   // the tile origin
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    v.add        v46, v13, v41
    v.splat      v41, s53
    vf.fms       v47, v45, v15, v42
    v.cmp.lt     p2, v46, v41
    vf.fms       v41, v47, v43, v45
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v41, v43, v45
    v.lshr       v43, v41, v38
    vf.cvt.f32.e4m3 v45, v41
    v.and        v41, v43, v40
    v.or         v43, v45, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v43
    vf.fms       v41, v15, v42, v39
    vf.fms       v43, v42, v41, v42
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s54, #0]
    vf.neg       v45, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v45, v45
    @p1 v.sel        v43, v45, v42
    vf.cvt.bf16.f32 v42, v41
    v.extract    s48, v28, #1
    s.addi       s52, s49, #16
    s.add        s53, s48, s28
    vf.mul       v41, v42, v44                   // a/y: faithful quotient
    s.addi       s48, s53, #96
    s.add        s53, s4, s48
    vf.fms       v45, v41, v15, v42
    vf.fms       v42, v45, v44, v41
    v.rcp.approx v44, v15                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v45, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v45, v45
    @p1 v.sel        v42, v45, v41
    v.lshr       v41, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    v.and        v42, v41, v40
    v.or         v41, v45, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s50, #0], v41
    v.extract    s48, v28, #2
    s.addi       s50, s49, #48
    s.add        s54, s48, s28
    s.addi       s48, s54, #96
    vf.fms       v41, v15, v44, v39
    s.add        s54, s4, s48
    vf.fms       v42, v44, v41, v44
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s51, #0]
    vf.neg       v45, v42                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v45, v45
    @p1 v.sel        v42, v45, v44
    vf.cvt.bf16.f32 v44, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v44, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v44
    vf.fms       v44, v46, v43, v45
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v45
    v.lshr       v43, v44, v38
    vf.cvt.f32.e4m3 v45, v44
    vf.fms       v44, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v44, v41
    s.addi       s48, s49, #80
    v.st.b       [s52, #0], v43
    v.extract    s51, v28, #3
    vf.neg       v43, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s52, s51, s28
    s.addi       s51, s52, #96
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    s.add        s52, s4, s51
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s53, #0]
    vf.cvt.bf16.f32 v43, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v43, v42                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v43
    vf.fms       v43, v46, v42, v45
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v45
    v.lshr       v42, v43, v38
    vf.cvt.f32.e4m3 v45, v43
    vf.fms       v43, v15, v41, v39
    v.and        v46, v42, v40
    v.or         v42, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v43, v41
    s.addi       s51, s49, #112
    v.st.b       [s50, #0], v42
    v.extract    s50, v28, #4
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s53, s50, s28
    s.addi       s50, s53, #96
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s53, s4, s50
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s54, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s50, s49, #144
    v.st.b       [s48, #0], v44
    v.extract    s48, v28, #5
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s54, s48, s28
    s.addi       s48, s54, #96
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s54, s4, s48
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s52, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s48, s49, #176
    v.st.b       [s51, #0], v43
    v.extract    s51, v28, #6
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s52, s51, s28
    s.addi       s51, s52, #96
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s52, s4, s51
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s53, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s51, s49, #208
    v.st.b       [s50, #0], v44
    v.extract    s50, v28, #7
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s53, s50, s28
    s.addi       s50, s53, #96
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s53, s4, s50
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s54, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s50, s49, #240
    v.st.b       [s48, #0], v43
    v.extract    s48, v28, #8
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s54, s48, s28
    s.addi       s48, s54, #96
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s54, s4, s48
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s52, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s48, s49, #272
    v.st.b       [s51, #0], v44
    v.extract    s51, v28, #9
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s52, s51, s28
    s.addi       s51, s52, #96
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s52, s4, s51
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s53, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s51, s49, #304
    v.st.b       [s50, #0], v43
    v.extract    s50, v28, #10
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s53, s50, s28
    s.addi       s50, s53, #96
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s53, s4, s50
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s54, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s50, s49, #336
    v.st.b       [s48, #0], v44
    v.extract    s48, v28, #11
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s54, s48, s28
    s.addi       s48, s54, #96
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s54, s4, s48
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s52, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s48, s49, #368
    v.st.b       [s51, #0], v43
    v.extract    s51, v28, #12
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s52, s51, s28
    s.addi       s51, s52, #96
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s52, s4, s51
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s53, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s51, s49, #400
    v.st.b       [s50, #0], v44
    v.extract    s50, v28, #13
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s53, s50, s28
    s.addi       s50, s53, #96
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s53, s4, s50
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s54, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s50, s49, #432
    v.st.b       [s48, #0], v43
    v.extract    s48, v28, #14
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s54, s48, s28
    s.addi       s48, s54, #96
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s54, s4, s48
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s52, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s48, s49, #464
    v.st.b       [s51, #0], v44
    v.extract    s51, v28, #15
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s52, s51, s28
    s.addi       s51, s52, #96
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s52, s4, s51
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s53, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s51, s49, #496
    v.st.b       [s50, #0], v43
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s54, #0]
    s.addi       s50, s49, #64
    vf.cvt.bf16.f32 v42, v41
    s.addi       s53, s49, #128
    s.addi       s54, s49, #192
    vf.mul       v41, v42, v44                   // a/y: faithful quotient
    vf.fms       v45, v41, v15, v42
    vf.fms       v42, v45, v44, v41
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v41
    v.lshr       v41, v42, v38
    vf.cvt.f32.e4m3 v44, v42
    v.and        v42, v41, v40
    v.or         v41, v44, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s48, #0], v41
    s.addi       s48, s49, #256
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s52, #0]
    s.addi       s52, s49, #320
    vf.cvt.bf16.f32 v42, v41
    vf.mul       v41, v42, v43                   // a/y: faithful quotient
    vf.fms       v44, v41, v15, v42
    vf.fms       v42, v44, v43, v41
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v41
    v.lshr       v41, v42, v38
    vf.cvt.f32.e4m3 v43, v42
    v.and        v42, v41, v40
    v.or         v41, v43, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v41
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s51, s49, #384
    v.ld.w       v41, [s49, #0]
    s.addi       s55, s49, #448
    v.mov        v48, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s50, #0]
    v.extract    s49, v16, #0
    v.mov        v49, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s53, #0]
    v.mov        v50, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s54, #0]
    v.mov        v51, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s48, #0]
    v.mov        v52, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s52, #0]
    v.mov        v53, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s51, #0]
    v.mov        v54, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s55, #0]
    v.mov        v55, v41                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s49, x8dot_done_44
    s.movz       s48, #0
    s.add        s50, s9, s26
    s.addi       s51, s48, #0
    s.addi       s48, s50, #32
    s.addi       s50, s38, #256
x8dot_row_45:
    s.addi       s52, s34, #-32
    v.movi       v41, #0
    s.sub        s53, s52, s51
    s.add        s52, s48, s51
    v.splat      v42, s53
    s.shli       s53, s51, #4
    s.addi       s54, s51, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s52, v31]            // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.movz       s53, #32
    v.st.b       [s52, #0], v41
    fence.acq_rel.device
    s.mov        s51, s54
    s.cmp.lt     s52, s51, s53
    br.nz        s52, x8dot_row_45
x8dot_done_44:
    v.splat      v41, s49
    v.movi       v42, #0
    v.splat      v43, s49
    v.movi       v44, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    s.movz       s50, #0
    v.extract    s51, v20, #0
    s.movz       s52, #32
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v16, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s50, x8dot_done_46
    s.movz       s51, #0
    s.add        s52, s9, s26
    s.addi       s53, s51, #0
    s.addi       s51, s52, #32
    s.addi       s52, s38, #256
x8dot_row_47:
    s.addi       s54, s34, #-32
    v.movi       v41, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v42, s55
    s.shli       s55, s53, #4
    s.addi       s56, s53, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s54, v23]            // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.movz       s55, #32
    v.st.b       [s54, #0], v41
    fence.acq_rel.device
    s.mov        s53, s56
    s.cmp.lt     s54, s53, s55
    br.nz        s54, x8dot_row_47
x8dot_done_46:
    v.splat      v41, s50
    v.movi       v42, #0
    v.splat      v43, s50
    v.movi       v44, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s51, #0
    s.movz       s52, #0
    v.extract    s53, v20, #1
    s.movz       s54, #32
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s55, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v16, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s52, x8dot_done_48
    s.movz       s53, #0
    s.add        s54, s9, s26
    s.addi       s55, s53, #0
    s.addi       s53, s54, #32
    s.addi       s54, s38, #256
x8dot_row_49:
    s.addi       s56, s34, #-32
    v.movi       v41, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v42, s57
    s.shli       s57, s55, #4
    s.addi       s58, s55, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s56, v19]            // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.movz       s57, #32
    v.st.b       [s56, #0], v41
    fence.acq_rel.device
    s.mov        s55, s58
    s.cmp.lt     s56, s55, s57
    br.nz        s56, x8dot_row_49
x8dot_done_48:
    v.splat      v41, s52
    v.movi       v42, #0
    v.splat      v43, s52
    v.movi       v44, #0
    mb.arm       s52, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    s.movz       s54, #0
    v.extract    s55, v20, #2
    s.movz       s56, #32
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s57, s52            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v16, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s53
    mb.wait      s53
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s54, x8dot_done_50
    s.movz       s55, #0
    s.add        s56, s9, s26
    s.addi       s57, s55, #0
    s.addi       s55, s56, #32
    s.addi       s56, s38, #256
x8dot_row_51:
    s.addi       s58, s34, #-32
    v.movi       v41, #0
    s.sub        s59, s58, s57
    s.add        s58, s55, s57
    v.splat      v42, s59
    s.shli       s59, s57, #4
    s.addi       s60, s57, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s58, v25]            // index is in elements (ISA sec 9.1)
    s.add        s58, s56, s59
    s.movz       s59, #32
    v.st.b       [s58, #0], v41
    fence.acq_rel.device
    s.mov        s57, s60
    s.cmp.lt     s58, s57, s59
    br.nz        s58, x8dot_row_51
x8dot_done_50:
    v.splat      v41, s54
    v.movi       v42, #0
    v.splat      v43, s54
    v.movi       v44, #0
    mb.arm       s54, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s55, #0
    s.movz       s56, #0
    v.extract    s57, v20, #3
    s.movz       s58, #32
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s60, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s59, s54            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s57                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s58                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s54          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    mb.arm       s55, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v16, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s55
    mb.wait      s55
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s56, x8dot_done_52
    s.movz       s57, #0
    s.add        s58, s9, s26
    s.addi       s59, s57, #0
    s.addi       s57, s58, #32
    s.addi       s58, s38, #256
x8dot_row_53:
    s.addi       s60, s34, #-32
    v.movi       v41, #0
    s.sub        s19, s60, s59
    s.add        s29, s57, s59
    v.splat      v42, s19
    s.shli       s19, s59, #4
    s.addi       s30, s59, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s29, v26]            // index is in elements (ISA sec 9.1)
    s.add        s29, s58, s19
    s.movz       s19, #32
    v.st.b       [s29, #0], v41
    fence.acq_rel.device
    s.mov        s59, s30
    s.cmp.lt     s29, s59, s19
    br.nz        s29, x8dot_row_53
x8dot_done_52:
    v.splat      v41, s56
    v.movi       v42, #0
    v.splat      v43, s56
    v.movi       v44, #0
    mb.arm       s19, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s29, #0
    s.movz       s30, #0
    v.extract    s33, v20, #4
    s.movz       s35, #32
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s36, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s19            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s29, s19          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s19
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s30, v16, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s29
    mb.wait      s29
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s30, x8dot_done_54
    s.movz       s33, #0
    s.add        s35, s9, s26
    s.addi       s36, s33, #0
    s.addi       s33, s35, #32
    s.addi       s35, s38, #256
x8dot_row_55:
    s.addi       s37, s34, #-32
    v.movi       v41, #0
    s.sub        s39, s37, s36
    s.add        s37, s33, s36
    v.splat      v42, s39
    s.shli       s39, s36, #4
    s.addi       s40, s36, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s37, v27]            // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s39
    s.movz       s39, #32
    v.st.b       [s37, #0], v41
    fence.acq_rel.device
    s.mov        s36, s40
    s.cmp.lt     s37, s36, s39
    br.nz        s37, x8dot_row_55
x8dot_done_54:
    v.splat      v41, s30
    v.movi       v42, #0
    v.splat      v43, s30
    v.movi       v44, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    s.movz       s35, #0
    v.extract    s36, v20, #5
    s.movz       s37, #32
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s39, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s39, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v16, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s33
    mb.wait      s33
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_56
    s.movz       s36, #0
    s.add        s37, s9, s26
    s.addi       s39, s36, #0
    s.addi       s36, s37, #32
    s.addi       s37, s38, #256
x8dot_row_57:
    s.addi       s40, s34, #-32
    v.movi       v41, #0
    s.sub        s41, s40, s39
    s.add        s40, s36, s39
    v.splat      v42, s41
    s.shli       s41, s39, #4
    s.addi       s42, s39, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s40, v32]            // index is in elements (ISA sec 9.1)
    s.add        s40, s37, s41
    s.movz       s41, #32
    v.st.b       [s40, #0], v41
    fence.acq_rel.device
    s.mov        s39, s42
    s.cmp.lt     s40, s39, s41
    br.nz        s40, x8dot_row_57
x8dot_done_56:
    v.splat      v41, s35
    v.movi       v42, #0
    v.splat      v43, s35
    v.movi       v44, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    s.movz       s37, #0
    v.extract    s39, v20, #6
    s.movz       s40, #32
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s41, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v16, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_58
    s.movz       s39, #0
    s.add        s40, s9, s26
    s.addi       s41, s39, #0
    s.addi       s39, s40, #32
    s.addi       s40, s38, #256
x8dot_row_59:
    s.addi       s42, s34, #-32
    v.movi       v41, #0
    s.sub        s43, s42, s41
    s.add        s42, s39, s41
    v.splat      v42, s43
    s.shli       s43, s41, #4
    s.addi       s44, s41, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s42, v29]            // index is in elements (ISA sec 9.1)
    s.add        s42, s40, s43
    s.movz       s43, #32
    v.st.b       [s42, #0], v41
    fence.acq_rel.device
    s.mov        s41, s44
    s.cmp.lt     s42, s41, s43
    br.nz        s42, x8dot_row_59
x8dot_done_58:
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    s.movz       s39, #0
    v.extract    s40, v28, #0
    s.add        s41, s39, s18                   // the tile origin
    s.movz       s39, #0
    v.splat      v42, s37
    v.movi       v43, #0
    v.splat      v44, s37
    v.movi       v45, #0
    v.splat      v46, s41
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.add        s41, s40, s28
    s.add        s40, s39, s32                   // the tile origin
    s.movz       s39, #0
    s.movz       s42, #0
    v.extract    s43, v20, #7
    s.movz       s44, #32
    v.cmp.ne     p1, v42, v43
    v.cmp.eq     p2, v44, v45
    s.addi       s45, s41, #128
    v.add        v42, v13, v46
    v.splat      v43, s40
    s.mov        s40, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s40, s4, s45
    v.cmp.lt     p1, v42, v43
    m.mma.async.k32.e4m3 a15, v48, v56, s39
    mb.wait      s39
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s40, #0]
    vf.fms       v43, v15, v41, v39
    v.rcp.approx v44, v15                        // ISA 8.8: <= 2**-22 relative
    v.extract    s40, v28, #1
    s.addi       s41, s38, #2048                 // 512 bytes of repack scratch
    s.add        s42, s40, s28
    vf.fms       v45, v41, v43, v41
    s.addi       s40, s42, #128
    s.addi       s42, s41, #0
    s.add        s43, s4, s40
    v.extract    s40, v28, #2
    vf.neg       v43, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s44, s40, s28
    s.addi       s40, s41, #32
    vf.cvt.bf16.f32 v45, v42
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v46, v43, v41
    s.addi       s45, s44, #128
    vf.mul       v41, v45, v46                   // a/y: faithful quotient
    s.add        s44, s4, s45
    vf.fms       v43, v41, v15, v45
    vf.fms       v45, v43, v46, v41
    vf.fms       v43, v15, v44, v39
    vf.neg       v46, v45                        // a/y: one correction to the IEEE quotient
    vf.fms       v45, v44, v43, v44
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v43, v46, v41
    vf.neg       v41, v45                        // Newton step: r0*(2 - x*r0)
    vf.fms       v45, v15, v42, v39
    v.lshr       v46, v43, v38
    vf.cvt.f32.e4m3 v47, v43
    v.and        v43, v46, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v46, v41, v44
    v.or         v41, v47, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v43, v42, v45, v42
    s.addi       s45, s41, #64
    v.st.b       [s42, #0], v41
    v.extract    s42, v28, #3
    vf.neg       v41, v43                        // Newton step: r0*(2 - x*r0)
    s.add        s46, s42, s28
    s.addi       s42, s46, #128
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v43, v41, v42
    s.add        s46, s4, s42
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s43, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v42, v46                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v42
    vf.fms       v42, v45, v46, v44
    vf.neg       v45, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v45, v45
    @p2 v.sel        v42, v45, v44
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s42, s41, #96
    v.st.b       [s40, #0], v44
    v.extract    s40, v28, #4
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s40, s28
    s.addi       s40, s43, #128
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s43, s4, s40
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s44, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s40, s41, #128
    v.st.b       [s45, #0], v43
    v.extract    s44, v28, #5
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s45, s44, s28
    s.addi       s44, s45, #128
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s45, s4, s44
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s46, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s44, s41, #160
    v.st.b       [s42, #0], v44
    v.extract    s42, v28, #6
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s46, s42, s28
    s.addi       s42, s46, #128
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s46, s4, s42
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s43, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s42, s41, #192
    v.st.b       [s40, #0], v43
    v.extract    s40, v28, #7
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s40, s28
    s.addi       s40, s43, #128
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s43, s4, s40
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s45, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s40, s41, #224
    v.st.b       [s44, #0], v44
    v.extract    s44, v28, #8
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s45, s44, s28
    s.addi       s44, s45, #128
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s45, s4, s44
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s46, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s44, s41, #256
    v.st.b       [s42, #0], v43
    v.extract    s42, v28, #9
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s46, s42, s28
    s.addi       s42, s46, #128
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s46, s4, s42
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s43, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s42, s41, #288
    v.st.b       [s40, #0], v44
    v.extract    s40, v28, #10
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s40, s28
    s.addi       s40, s43, #128
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s43, s4, s40
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s45, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s40, s41, #320
    v.st.b       [s44, #0], v43
    v.extract    s44, v28, #11
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s45, s44, s28
    s.addi       s44, s45, #128
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s45, s4, s44
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s46, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s44, s41, #352
    v.st.b       [s42, #0], v44
    v.extract    s42, v28, #12
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s46, s42, s28
    s.addi       s42, s46, #128
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s46, s4, s42
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s43, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s42, s41, #384
    v.st.b       [s40, #0], v43
    v.extract    s40, v28, #13
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s40, s28
    s.addi       s40, s43, #128
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s43, s4, s40
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s45, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s40, s41, #416
    v.st.b       [s44, #0], v44
    v.extract    s44, v28, #14
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s45, s44, s28
    s.addi       s44, s45, #128
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s45, s4, s44
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s46, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s44, s41, #448
    v.st.b       [s42, #0], v43
    v.extract    s42, v28, #15
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s46, s42, s28
    s.addi       s42, s46, #128
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s46, s4, s42
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s43, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s42, s41, #480
    v.st.b       [s40, #0], v44
    v.extract    s40, v28, #0
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s43, s40, s28
    s.addi       s40, s43, #160
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s43, s4, s40
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s45, #0]
    s.movz       s40, #0
    vf.cvt.bf16.f32 v42, v41
    s.add        s45, s40, s21                   // the tile origin
    s.movz       s40, #0
    v.splat      v41, s45
    s.add        s45, s40, s32                   // the tile origin
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    v.add        v46, v13, v41
    v.splat      v41, s45
    vf.fms       v47, v45, v15, v42
    v.cmp.lt     p2, v46, v41
    vf.fms       v41, v47, v43, v45
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v43, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v43, v43
    @p3 v.sel        v41, v43, v45
    v.lshr       v43, v41, v38
    vf.cvt.f32.e4m3 v45, v41
    v.and        v41, v43, v40
    v.or         v43, v45, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s44, #0], v43
    vf.fms       v41, v15, v42, v39
    vf.fms       v43, v42, v41, v42
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s46, #0]
    vf.neg       v45, v43                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v45, v45
    @p1 v.sel        v43, v45, v42
    vf.cvt.bf16.f32 v42, v41
    v.extract    s40, v28, #1
    s.addi       s44, s41, #16
    s.add        s45, s40, s28
    vf.mul       v41, v42, v44                   // a/y: faithful quotient
    s.addi       s40, s45, #160
    s.add        s45, s4, s40
    vf.fms       v45, v41, v15, v42
    vf.fms       v42, v45, v44, v41
    v.rcp.approx v44, v15                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v45, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v45, v45
    @p1 v.sel        v42, v45, v41
    v.lshr       v41, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    v.and        v42, v41, v40
    v.or         v41, v45, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v41
    v.extract    s40, v28, #2
    s.addi       s42, s41, #48
    s.add        s46, s40, s28
    s.addi       s40, s46, #160
    vf.fms       v41, v15, v44, v39
    s.add        s46, s4, s40
    vf.fms       v42, v44, v41, v44
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s43, #0]
    vf.neg       v45, v42                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v45, v45
    @p1 v.sel        v42, v45, v44
    vf.cvt.bf16.f32 v44, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v44, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v44
    vf.fms       v44, v46, v43, v45
    vf.neg       v43, v44                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v45
    v.lshr       v43, v44, v38
    vf.cvt.f32.e4m3 v45, v44
    vf.fms       v44, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v44, v41
    s.addi       s40, s41, #80
    v.st.b       [s44, #0], v43
    v.extract    s43, v28, #3
    vf.neg       v43, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s44, s43, s28
    s.addi       s43, s44, #160
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    s.add        s44, s4, s43
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s45, #0]
    vf.cvt.bf16.f32 v43, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v43, v42                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v43
    vf.fms       v43, v46, v42, v45
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v45
    v.lshr       v42, v43, v38
    vf.cvt.f32.e4m3 v45, v43
    vf.fms       v43, v15, v41, v39
    v.and        v46, v42, v40
    v.or         v42, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v43, v41
    s.addi       s43, s41, #112
    v.st.b       [s42, #0], v42
    v.extract    s42, v28, #4
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s45, s42, s28
    s.addi       s42, s45, #160
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s45, s4, s42
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s46, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s42, s41, #144
    v.st.b       [s40, #0], v44
    v.extract    s40, v28, #5
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s46, s40, s28
    s.addi       s40, s46, #160
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s46, s4, s40
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s44, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s40, s41, #176
    v.st.b       [s43, #0], v43
    v.extract    s43, v28, #6
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s44, s43, s28
    s.addi       s43, s44, #160
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s44, s4, s43
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s45, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s43, s41, #208
    v.st.b       [s42, #0], v44
    v.extract    s42, v28, #7
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s45, s42, s28
    s.addi       s42, s45, #160
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s45, s4, s42
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s46, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s42, s41, #240
    v.st.b       [s40, #0], v43
    v.extract    s40, v28, #8
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s46, s40, s28
    s.addi       s40, s46, #160
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s46, s4, s40
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s44, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s40, s41, #272
    v.st.b       [s43, #0], v44
    v.extract    s43, v28, #9
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s44, s43, s28
    s.addi       s43, s44, #160
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s44, s4, s43
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s45, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s43, s41, #304
    v.st.b       [s42, #0], v43
    v.extract    s42, v28, #10
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s45, s42, s28
    s.addi       s42, s45, #160
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s45, s4, s42
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s46, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s42, s41, #336
    v.st.b       [s40, #0], v44
    v.extract    s40, v28, #11
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s46, s40, s28
    s.addi       s40, s46, #160
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s46, s4, s40
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s44, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s40, s41, #368
    v.st.b       [s43, #0], v43
    v.extract    s43, v28, #12
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s44, s43, s28
    s.addi       s43, s44, #160
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s44, s4, s43
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s45, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s43, s41, #400
    v.st.b       [s42, #0], v44
    v.extract    s42, v28, #13
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s45, s42, s28
    s.addi       s42, s45, #160
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s45, s4, s42
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s46, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s42, s41, #432
    v.st.b       [s40, #0], v43
    v.extract    s40, v28, #14
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s46, s40, s28
    s.addi       s40, s46, #160
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    s.add        s46, s4, s40
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s44, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s40, s41, #464
    v.st.b       [s43, #0], v44
    v.extract    s43, v28, #15
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s44, s43, s28
    s.addi       s43, s44, #160
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v44, v42, v41
    s.add        s44, s4, s43
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s45, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s43, s41, #496
    v.st.b       [s42, #0], v43
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s46, #0]
    s.addi       s42, s41, #64
    vf.cvt.bf16.f32 v42, v41
    s.addi       s45, s41, #128
    s.addi       s46, s41, #192
    vf.mul       v41, v42, v44                   // a/y: faithful quotient
    vf.fms       v45, v41, v15, v42
    vf.fms       v42, v45, v44, v41
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v42, v44, v41
    v.lshr       v41, v42, v38
    vf.cvt.f32.e4m3 v44, v42
    v.and        v42, v41, v40
    v.or         v41, v44, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s40, #0], v41
    s.addi       s40, s41, #256
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v41, [s44, #0]
    s.addi       s44, s41, #320
    vf.cvt.bf16.f32 v42, v41
    vf.mul       v41, v42, v43                   // a/y: faithful quotient
    vf.fms       v44, v41, v15, v42
    vf.fms       v42, v44, v43, v41
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v41
    v.lshr       v41, v42, v38
    vf.cvt.f32.e4m3 v43, v42
    v.and        v42, v41, v40
    v.or         v41, v43, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s43, #0], v41
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s43, s41, #384
    v.ld.w       v41, [s41, #0]
    s.addi       s47, s41, #448
    v.mov        v48, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s42, #0]
    v.extract    s41, v16, #0
    v.mov        v49, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s45, #0]
    v.mov        v50, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s46, #0]
    v.mov        v51, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s40, #0]
    v.mov        v52, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s44, #0]
    v.mov        v53, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s43, #0]
    v.mov        v54, v41                        // hand off through the shared window (sec 7.3)
    v.ld.w       v41, [s47, #0]
    v.mov        v55, v41                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s41, x8dot_done_60
    s.movz       s40, #0
    s.add        s42, s9, s26
    s.addi       s43, s40, #0
    s.addi       s40, s42, #64
    s.addi       s42, s38, #256
x8dot_row_61:
    s.addi       s44, s34, #-64
    v.movi       v41, #0
    s.sub        s45, s44, s43
    s.add        s44, s40, s43
    v.splat      v42, s45
    s.shli       s45, s43, #4
    s.addi       s46, s43, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s44, v31]            // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.movz       s45, #32
    v.st.b       [s44, #0], v41
    fence.acq_rel.device
    s.mov        s43, s46
    s.cmp.lt     s44, s43, s45
    br.nz        s44, x8dot_row_61
x8dot_done_60:
    v.splat      v41, s41
    v.movi       v42, #0
    v.splat      v43, s41
    v.movi       v44, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    s.movz       s42, #0
    v.extract    s43, v20, #0
    s.movz       s44, #64
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v16, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_62
    s.movz       s43, #0
    s.add        s44, s9, s26
    s.addi       s45, s43, #0
    s.addi       s43, s44, #64
    s.addi       s44, s38, #256
x8dot_row_63:
    s.addi       s46, s34, #-64
    v.movi       v41, #0
    s.sub        s47, s46, s45
    s.add        s46, s43, s45
    v.splat      v42, s47
    s.shli       s47, s45, #4
    s.addi       s48, s45, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s46, v23]            // index is in elements (ISA sec 9.1)
    s.add        s46, s44, s47
    s.movz       s47, #32
    v.st.b       [s46, #0], v41
    fence.acq_rel.device
    s.mov        s45, s48
    s.cmp.lt     s46, s45, s47
    br.nz        s46, x8dot_row_63
x8dot_done_62:
    v.splat      v41, s42
    v.movi       v42, #0
    v.splat      v43, s42
    v.movi       v44, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    s.movz       s44, #0
    v.extract    s45, v20, #1
    s.movz       s46, #64
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v16, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s43
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_64
    s.movz       s45, #0
    s.add        s46, s9, s26
    s.addi       s47, s45, #0
    s.addi       s45, s46, #64
    s.addi       s46, s38, #256
x8dot_row_65:
    s.addi       s48, s34, #-64
    v.movi       v41, #0
    s.sub        s49, s48, s47
    s.add        s48, s45, s47
    v.splat      v42, s49
    s.shli       s49, s47, #4
    s.addi       s50, s47, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s48, v19]            // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s49
    s.movz       s49, #32
    v.st.b       [s48, #0], v41
    fence.acq_rel.device
    s.mov        s47, s50
    s.cmp.lt     s48, s47, s49
    br.nz        s48, x8dot_row_65
x8dot_done_64:
    v.splat      v41, s44
    v.movi       v42, #0
    v.splat      v43, s44
    v.movi       v44, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    s.movz       s46, #0
    v.extract    s47, v20, #2
    s.movz       s48, #64
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v16, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s45
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s46, x8dot_done_66
    s.movz       s47, #0
    s.add        s48, s9, s26
    s.addi       s49, s47, #0
    s.addi       s47, s48, #64
    s.addi       s48, s38, #256
x8dot_row_67:
    s.addi       s50, s34, #-64
    v.movi       v41, #0
    s.sub        s51, s50, s49
    s.add        s50, s47, s49
    v.splat      v42, s51
    s.shli       s51, s49, #4
    s.addi       s52, s49, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s50, v25]            // index is in elements (ISA sec 9.1)
    s.add        s50, s48, s51
    s.movz       s51, #32
    v.st.b       [s50, #0], v41
    fence.acq_rel.device
    s.mov        s49, s52
    s.cmp.lt     s50, s49, s51
    br.nz        s50, x8dot_row_67
x8dot_done_66:
    v.splat      v41, s46
    v.movi       v42, #0
    v.splat      v43, s46
    v.movi       v44, #0
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    s.movz       s48, #0
    v.extract    s49, v20, #3
    s.movz       s50, #64
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s46            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v16, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s48, x8dot_done_68
    s.movz       s49, #0
    s.add        s50, s9, s26
    s.addi       s51, s49, #0
    s.addi       s49, s50, #64
    s.addi       s50, s38, #256
x8dot_row_69:
    s.addi       s52, s34, #-64
    v.movi       v41, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v42, s53
    s.shli       s53, s51, #4
    s.addi       s54, s51, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s52, v26]            // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.movz       s53, #32
    v.st.b       [s52, #0], v41
    fence.acq_rel.device
    s.mov        s51, s54
    s.cmp.lt     s52, s51, s53
    br.nz        s52, x8dot_row_69
x8dot_done_68:
    v.splat      v41, s48
    v.movi       v42, #0
    v.splat      v43, s48
    v.movi       v44, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    s.movz       s50, #0
    v.extract    s51, v20, #4
    s.movz       s52, #64
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v16, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s50, x8dot_done_70
    s.movz       s51, #0
    s.add        s52, s9, s26
    s.addi       s53, s51, #0
    s.addi       s51, s52, #64
    s.addi       s52, s38, #256
x8dot_row_71:
    s.addi       s54, s34, #-64
    v.movi       v41, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v42, s55
    s.shli       s55, s53, #4
    s.addi       s56, s53, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s54, v27]            // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.movz       s55, #32
    v.st.b       [s54, #0], v41
    fence.acq_rel.device
    s.mov        s53, s56
    s.cmp.lt     s54, s53, s55
    br.nz        s54, x8dot_row_71
x8dot_done_70:
    v.splat      v41, s50
    v.movi       v42, #0
    v.splat      v43, s50
    v.movi       v44, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s51, #0
    s.movz       s52, #0
    v.extract    s53, v20, #5
    s.movz       s54, #64
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s55, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v16, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s52, x8dot_done_72
    s.movz       s53, #0
    s.add        s54, s9, s26
    s.addi       s55, s53, #0
    s.addi       s53, s54, #64
    s.addi       s54, s38, #256
x8dot_row_73:
    s.addi       s56, s34, #-64
    v.movi       v41, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v42, s57
    s.shli       s57, s55, #4
    s.addi       s58, s55, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s56, v32]            // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.movz       s57, #32
    v.st.b       [s56, #0], v41
    fence.acq_rel.device
    s.mov        s55, s58
    s.cmp.lt     s56, s55, s57
    br.nz        s56, x8dot_row_73
x8dot_done_72:
    v.splat      v41, s52
    v.movi       v42, #0
    v.splat      v43, s52
    v.movi       v44, #0
    mb.arm       s52, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    s.movz       s54, #0
    v.extract    s55, v20, #6
    s.movz       s56, #64
    v.cmp.ne     p1, v41, v42
    v.cmp.eq     p2, v43, v44
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s57, s52            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v16, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s53
    mb.wait      s53
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s54, x8dot_done_74
    s.movz       s55, #0
    s.add        s56, s9, s26
    s.addi       s57, s55, #0
    s.addi       s55, s56, #64
    s.addi       s56, s38, #256
x8dot_row_75:
    s.addi       s58, s34, #-64
    v.movi       v41, #0
    s.sub        s59, s58, s57
    s.add        s58, s55, s57
    v.splat      v42, s59
    s.shli       s59, s57, #4
    s.addi       s60, s57, #1
    v.cmp.gt     p1, v42, v41
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v41, [s58, v29]            // index is in elements (ISA sec 9.1)
    s.add        s58, s56, s59
    s.movz       s59, #32
    v.st.b       [s58, #0], v41
    fence.acq_rel.device
    s.mov        s57, s60
    s.cmp.lt     s58, s57, s59
    br.nz        s58, x8dot_row_75
x8dot_done_74:
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    s.movz       s55, #0
    v.extract    s56, v28, #0
    s.add        s57, s55, s22                   // the tile origin
    s.movz       s55, #0
    v.splat      v42, s54
    v.movi       v43, #0
    v.splat      v44, s54
    v.movi       v45, #0
    v.splat      v46, s57
    mb.arm       s54, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.add        s57, s56, s28
    s.add        s56, s55, s32                   // the tile origin
    s.movz       s55, #0
    s.movz       s58, #0
    v.extract    s59, v20, #7
    s.movz       s60, #64
    v.cmp.ne     p1, v42, v43
    v.cmp.eq     p2, v44, v45
    s.addi       s19, s57, #192
    v.add        v42, v13, v46
    v.splat      v43, s56
    s.mov        s29, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s58                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s29, s54            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s29, s59                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s60                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s29, s54          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s30, s4, s19
    v.cmp.lt     p1, v42, v43
    m.mma.async.k32.e4m3 a15, v48, v56, s29
    mb.wait      s29
    v.movi       v42, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v42, [s30, #0]
    vf.fms       v43, v15, v41, v39
    v.rcp.approx v44, v15                        // ISA 8.8: <= 2**-22 relative
    v.extract    s19, v28, #1
    s.addi       s30, s38, #2560                 // 512 bytes of repack scratch
    s.add        s33, s19, s28
    vf.fms       v45, v41, v43, v41
    s.addi       s19, s33, #192
    s.addi       s33, s30, #0
    s.add        s35, s4, s19
    v.extract    s19, v28, #2
    vf.neg       v43, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s36, s19, s28
    s.addi       s19, s30, #32
    vf.cvt.bf16.f32 v45, v42
    v.rcp.approx v42, v15                        // ISA 8.8: <= 2**-22 relative
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v46, v43, v41
    s.addi       s37, s36, #192
    vf.mul       v41, v45, v46                   // a/y: faithful quotient
    s.add        s36, s4, s37
    vf.fms       v43, v41, v15, v45
    vf.fms       v45, v43, v46, v41
    vf.fms       v43, v15, v44, v39
    vf.neg       v46, v45                        // a/y: one correction to the IEEE quotient
    vf.fms       v45, v44, v43, v44
    vf.cmp.o     p2, v46, v46
    @p2 v.sel        v43, v46, v41
    vf.neg       v41, v45                        // Newton step: r0*(2 - x*r0)
    vf.fms       v45, v15, v42, v39
    v.lshr       v46, v43, v38
    vf.cvt.f32.e4m3 v47, v43
    v.and        v43, v46, v40
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v46, v41, v44
    v.or         v41, v47, v43                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v43, v42, v45, v42
    s.addi       s37, s30, #64
    v.st.b       [s33, #0], v41
    v.extract    s33, v28, #3
    vf.neg       v41, v43                        // Newton step: r0*(2 - x*r0)
    s.add        s39, s33, s28
    s.addi       s33, s39, #192
    vf.cmp.o     p2, v41, v41
    @p2 v.sel        v43, v41, v42
    s.add        s39, s4, s33
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s35, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v42, v46                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v42
    vf.fms       v42, v45, v46, v44
    vf.neg       v45, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v45, v45
    @p2 v.sel        v42, v45, v44
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s33, s30, #96
    v.st.b       [s19, #0], v44
    v.extract    s19, v28, #4
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s35, s19, s28
    s.addi       s19, s35, #192
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s35, s4, s19
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s36, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s19, s30, #128
    v.st.b       [s37, #0], v43
    v.extract    s36, v28, #5
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s37, s36, s28
    s.addi       s36, s37, #192
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s37, s4, s36
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s39, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s36, s30, #160
    v.st.b       [s33, #0], v44
    v.extract    s33, v28, #6
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s39, s33, s28
    s.addi       s33, s39, #192
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s39, s4, s33
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s35, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s33, s30, #192
    v.st.b       [s19, #0], v43
    v.extract    s19, v28, #7
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s35, s19, s28
    s.addi       s19, s35, #192
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s35, s4, s19
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s37, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s19, s30, #224
    v.st.b       [s36, #0], v44
    v.extract    s36, v28, #8
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s37, s36, s28
    s.addi       s36, s37, #192
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s37, s4, s36
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s39, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s36, s30, #256
    v.st.b       [s33, #0], v43
    v.extract    s33, v28, #9
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s39, s33, s28
    s.addi       s33, s39, #192
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s39, s4, s33
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s35, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s33, s30, #288
    v.st.b       [s19, #0], v44
    v.extract    s19, v28, #10
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s35, s19, s28
    s.addi       s19, s35, #192
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s35, s4, s19
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s37, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s19, s30, #320
    v.st.b       [s36, #0], v43
    v.extract    s36, v28, #11
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s37, s36, s28
    s.addi       s36, s37, #192
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s37, s4, s36
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s39, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s36, s30, #352
    v.st.b       [s33, #0], v44
    v.extract    s33, v28, #12
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s39, s33, s28
    s.addi       s33, s39, #192
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s39, s4, s33
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s35, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s33, s30, #384
    v.st.b       [s19, #0], v43
    v.extract    s19, v28, #13
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s35, s19, s28
    s.addi       s19, s35, #192
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s35, s4, s19
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s37, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s19, s30, #416
    v.st.b       [s36, #0], v44
    v.extract    s36, v28, #14
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s37, s36, s28
    s.addi       s36, s37, #192
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s37, s4, s36
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s39, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v43, v45
    vf.neg       v43, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v43, v43
    @p2 v.sel        v42, v43, v45
    v.lshr       v43, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v43, v40
    v.or         v43, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s36, s30, #448
    v.st.b       [s33, #0], v43
    v.extract    s33, v28, #15
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s39, s33, s28
    s.addi       s33, s39, #192
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v43, v42, v41
    s.add        s39, s4, s33
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s35, #0]
    vf.cvt.bf16.f32 v42, v41
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v45, v42, v44                   // a/y: faithful quotient
    vf.fms       v46, v45, v15, v42
    vf.fms       v42, v46, v44, v45
    vf.neg       v44, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v44, v44
    @p2 v.sel        v42, v44, v45
    v.lshr       v44, v42, v38
    vf.cvt.f32.e4m3 v45, v42
    vf.fms       v42, v15, v41, v39
    v.and        v46, v44, v40
    v.or         v44, v45, v46                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v45, v41, v42, v41
    s.addi       s33, s30, #480
    v.st.b       [s19, #0], v44
    v.extract    s19, v28, #0
    vf.neg       v42, v45                        // Newton step: r0*(2 - x*r0)
    s.add        s35, s19, s28
    s.addi       s19, s35, #224
    vf.cmp.o     p2, v42, v42
    @p2 v.sel        v44, v42, v41
    s.add        s35, s4, s19
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v41, [s37, #0]
    s.movz       s19, #0
    vf.cvt.bf16.f32 v42, v41
    s.add        s37, s19, s23                   // the tile origin
    s.movz       s19, #0
    v.splat      v41, s37
    s.add        s37, s19, s32                   // the tile origin
    vf.mul       v45, v42, v43                   // a/y: faithful quotient
    v.add        v46, v13, v41
    v.splat      v13, s37
    vf.fms       v41, v45, v15, v42
    v.cmp.lt     p2, v46, v13
    vf.fms       v13, v41, v43, v45
    v.rcp.approx v41, v15                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v42, v13                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v42, v42
    @p3 v.sel        v13, v42, v45
    v.lshr       v42, v13, v38
    vf.cvt.f32.e4m3 v43, v13
    v.and        v13, v42, v40
    v.or         v42, v43, v13                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    vf.fms       v13, v15, v41, v39
    vf.fms       v42, v41, v13, v41
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v13, [s39, #0]
    vf.neg       v43, v42                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v42, v43, v41
    vf.cvt.bf16.f32 v41, v13
    v.extract    s19, v28, #1
    s.addi       s32, s30, #16
    s.add        s36, s19, s28
    vf.mul       v13, v41, v44                   // a/y: faithful quotient
    s.addi       s19, s36, #224
    s.add        s36, s4, s19
    vf.fms       v43, v13, v15, v41
    vf.fms       v41, v43, v44, v13
    v.rcp.approx v43, v15                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v44, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v41, v44, v13
    v.lshr       v13, v41, v38
    vf.cvt.f32.e4m3 v44, v41
    v.and        v41, v13, v40
    v.or         v13, v44, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s33, #0], v13
    v.extract    s19, v28, #2
    s.addi       s33, s30, #48
    s.add        s37, s19, s28
    s.addi       s19, s37, #224
    vf.fms       v13, v15, v43, v39
    s.add        s37, s4, s19
    vf.fms       v41, v43, v13, v43
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s35, #0]
    vf.neg       v44, v41                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v44, v44
    @p1 v.sel        v41, v44, v43
    vf.cvt.bf16.f32 v43, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v43, v42                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v43
    vf.fms       v43, v45, v42, v44
    vf.neg       v42, v43                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v44
    v.lshr       v42, v43, v38
    vf.cvt.f32.e4m3 v44, v43
    vf.fms       v43, v15, v13, v39
    v.and        v45, v42, v40
    v.or         v42, v44, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v44, v13, v43, v13
    s.addi       s19, s30, #80
    v.st.b       [s32, #0], v42
    v.extract    s32, v28, #3
    vf.neg       v42, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s35, s32, s28
    s.addi       s32, s35, #224
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v43, v42, v13
    s.add        s35, s4, s32
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v42, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v42, v41                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v42
    vf.fms       v42, v45, v41, v44
    vf.neg       v41, v42                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v42, v41, v44
    v.lshr       v41, v42, v38
    vf.cvt.f32.e4m3 v44, v42
    vf.fms       v42, v15, v13, v39
    v.and        v45, v41, v40
    v.or         v41, v44, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v44, v13, v42, v13
    s.addi       s32, s30, #112
    v.st.b       [s33, #0], v41
    v.extract    s33, v28, #4
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s36, s33, s28
    s.addi       s33, s36, #224
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v42, v41, v13
    s.add        s36, s4, s33
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s37, #0]
    vf.cvt.bf16.f32 v41, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v41, v43                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v41
    vf.fms       v41, v45, v43, v44
    vf.neg       v43, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v41, v43, v44
    v.lshr       v43, v41, v38
    vf.cvt.f32.e4m3 v44, v41
    vf.fms       v41, v15, v13, v39
    v.and        v45, v43, v40
    v.or         v43, v44, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v44, v13, v41, v13
    s.addi       s33, s30, #144
    v.st.b       [s19, #0], v43
    v.extract    s19, v28, #5
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s37, s19, s28
    s.addi       s19, s37, #224
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v13
    s.add        s37, s4, s19
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s35, #0]
    vf.cvt.bf16.f32 v41, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v41, v42                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v41
    vf.fms       v41, v45, v42, v44
    vf.neg       v42, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v41, v42, v44
    v.lshr       v42, v41, v38
    vf.cvt.f32.e4m3 v44, v41
    vf.fms       v41, v15, v13, v39
    v.and        v45, v42, v40
    v.or         v42, v44, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v44, v13, v41, v13
    s.addi       s19, s30, #176
    v.st.b       [s32, #0], v42
    v.extract    s32, v28, #6
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s35, s32, s28
    s.addi       s32, s35, #224
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v42, v41, v13
    s.add        s35, s4, s32
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v41, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v41, v43                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v41
    vf.fms       v41, v45, v43, v44
    vf.neg       v43, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v41, v43, v44
    v.lshr       v43, v41, v38
    vf.cvt.f32.e4m3 v44, v41
    vf.fms       v41, v15, v13, v39
    v.and        v45, v43, v40
    v.or         v43, v44, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v44, v13, v41, v13
    s.addi       s32, s30, #208
    v.st.b       [s33, #0], v43
    v.extract    s33, v28, #7
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s36, s33, s28
    s.addi       s33, s36, #224
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v13
    s.add        s36, s4, s33
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s37, #0]
    vf.cvt.bf16.f32 v41, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v41, v42                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v41
    vf.fms       v41, v45, v42, v44
    vf.neg       v42, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v41, v42, v44
    v.lshr       v42, v41, v38
    vf.cvt.f32.e4m3 v44, v41
    vf.fms       v41, v15, v13, v39
    v.and        v45, v42, v40
    v.or         v42, v44, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v44, v13, v41, v13
    s.addi       s33, s30, #240
    v.st.b       [s19, #0], v42
    v.extract    s19, v28, #8
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s37, s19, s28
    s.addi       s19, s37, #224
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v42, v41, v13
    s.add        s37, s4, s19
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s35, #0]
    vf.cvt.bf16.f32 v41, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v41, v43                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v41
    vf.fms       v41, v45, v43, v44
    vf.neg       v43, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v41, v43, v44
    v.lshr       v43, v41, v38
    vf.cvt.f32.e4m3 v44, v41
    vf.fms       v41, v15, v13, v39
    v.and        v45, v43, v40
    v.or         v43, v44, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v44, v13, v41, v13
    s.addi       s19, s30, #272
    v.st.b       [s32, #0], v43
    v.extract    s32, v28, #9
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s35, s32, s28
    s.addi       s32, s35, #224
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v13
    s.add        s35, s4, s32
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v41, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v41, v42                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v41
    vf.fms       v41, v45, v42, v44
    vf.neg       v42, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v41, v42, v44
    v.lshr       v42, v41, v38
    vf.cvt.f32.e4m3 v44, v41
    vf.fms       v41, v15, v13, v39
    v.and        v45, v42, v40
    v.or         v42, v44, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v44, v13, v41, v13
    s.addi       s32, s30, #304
    v.st.b       [s33, #0], v42
    v.extract    s33, v28, #10
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s36, s33, s28
    s.addi       s33, s36, #224
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v42, v41, v13
    s.add        s36, s4, s33
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s37, #0]
    vf.cvt.bf16.f32 v41, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v41, v43                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v41
    vf.fms       v41, v45, v43, v44
    vf.neg       v43, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v41, v43, v44
    v.lshr       v43, v41, v38
    vf.cvt.f32.e4m3 v44, v41
    vf.fms       v41, v15, v13, v39
    v.and        v45, v43, v40
    v.or         v43, v44, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v44, v13, v41, v13
    s.addi       s33, s30, #336
    v.st.b       [s19, #0], v43
    v.extract    s19, v28, #11
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s37, s19, s28
    s.addi       s19, s37, #224
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v13
    s.add        s37, s4, s19
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s35, #0]
    vf.cvt.bf16.f32 v41, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v41, v42                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v41
    vf.fms       v41, v45, v42, v44
    vf.neg       v42, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v41, v42, v44
    v.lshr       v42, v41, v38
    vf.cvt.f32.e4m3 v44, v41
    vf.fms       v41, v15, v13, v39
    v.and        v45, v42, v40
    v.or         v42, v44, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v44, v13, v41, v13
    s.addi       s19, s30, #368
    v.st.b       [s32, #0], v42
    v.extract    s32, v28, #12
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s35, s32, s28
    s.addi       s32, s35, #224
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v42, v41, v13
    s.add        s35, s4, s32
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v41, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v41, v43                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v41
    vf.fms       v41, v45, v43, v44
    vf.neg       v43, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v41, v43, v44
    v.lshr       v43, v41, v38
    vf.cvt.f32.e4m3 v44, v41
    vf.fms       v41, v15, v13, v39
    v.and        v45, v43, v40
    v.or         v43, v44, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v44, v13, v41, v13
    s.addi       s32, s30, #400
    v.st.b       [s33, #0], v43
    v.extract    s33, v28, #13
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s36, s33, s28
    s.addi       s33, s36, #224
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v43, v41, v13
    s.add        s36, s4, s33
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s37, #0]
    vf.cvt.bf16.f32 v41, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v41, v42                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v41
    vf.fms       v41, v45, v42, v44
    vf.neg       v42, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v41, v42, v44
    v.lshr       v42, v41, v38
    vf.cvt.f32.e4m3 v44, v41
    vf.fms       v41, v15, v13, v39
    v.and        v45, v42, v40
    v.or         v42, v44, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v44, v13, v41, v13
    s.addi       s33, s30, #432
    v.st.b       [s19, #0], v42
    v.extract    s19, v28, #14
    vf.neg       v41, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s37, s19, s28
    s.addi       s19, s37, #224
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v42, v41, v13
    s.add        s37, s4, s19
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s35, #0]
    vf.cvt.bf16.f32 v41, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v44, v41, v43                   // a/y: faithful quotient
    vf.fms       v45, v44, v15, v41
    vf.fms       v41, v45, v43, v44
    vf.neg       v43, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v41, v43, v44
    v.lshr       v43, v41, v38
    vf.cvt.f32.e4m3 v44, v41
    vf.fms       v41, v15, v13, v39
    v.and        v45, v43, v40
    v.or         v43, v44, v45                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v44, v13, v41, v13
    s.addi       s19, s30, #464
    v.st.b       [s32, #0], v43
    v.extract    s32, v28, #15
    vf.neg       v28, v44                        // Newton step: r0*(2 - x*r0)
    s.add        s35, s32, s28
    s.addi       s28, s35, #224
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v41, v28, v13
    s.add        s32, s4, s28
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s36, #0]
    vf.cvt.bf16.f32 v28, v13
    v.rcp.approx v13, v15                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v43, v28, v42                   // a/y: faithful quotient
    vf.fms       v44, v43, v15, v28
    vf.fms       v28, v44, v42, v43
    vf.neg       v42, v28                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v28, v42, v43
    v.lshr       v42, v28, v38
    vf.cvt.f32.e4m3 v43, v28
    vf.fms       v28, v15, v13, v39
    v.and        v39, v42, v40
    v.or         v42, v43, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    vf.fms       v39, v13, v28, v13
    s.addi       s28, s30, #496
    v.st.b       [s33, #0], v42
    vf.neg       v28, v39                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v39, v28, v13
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s37, #0]
    s.addi       s33, s30, #64
    vf.cvt.bf16.f32 v28, v13
    s.addi       s35, s30, #128
    s.addi       s36, s30, #192
    vf.mul       v13, v28, v41                   // a/y: faithful quotient
    vf.fms       v42, v13, v15, v28
    s.addi       s37, s30, #256
    vf.fms       v28, v42, v41, v13
    vf.neg       v41, v28                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v28, v41, v13
    s.addi       s39, s30, #320
    v.lshr       v13, v28, v38
    vf.cvt.f32.e4m3 v41, v28
    v.and        v28, v13, v40
    v.or         v13, v41, v28                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s19, #0], v13
    s.addi       s19, s30, #384
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v13, [s32, #0]
    s.addi       s32, s30, #448
    vf.cvt.bf16.f32 v28, v13
    vf.mul       v13, v28, v39                   // a/y: faithful quotient
    vf.fms       v41, v13, v15, v28
    vf.fms       v15, v41, v39, v13
    vf.neg       v28, v15                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v28, v28
    @p1 v.sel        v15, v28, v13
    v.lshr       v13, v15, v38
    vf.cvt.f32.e4m3 v28, v15
    v.and        v15, v13, v40
    v.or         v13, v28, v15                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s28, #0], v13
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.extract    s28, v16, #0
    v.ld.w       v13, [s30, #0]
    v.mov        v48, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s33, #0]
    v.mov        v49, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s35, #0]
    v.mov        v50, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s36, #0]
    v.mov        v51, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s37, #0]
    v.mov        v52, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s39, #0]
    v.mov        v53, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s19, #0]
    v.mov        v54, v13                        // hand off through the shared window (sec 7.3)
    v.ld.w       v13, [s32, #0]
    v.mov        v55, v13                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s28, x8dot_done_76
    s.movz       s19, #0
    s.add        s30, s9, s26
    s.addi       s32, s19, #0
    s.addi       s19, s30, #96
    s.addi       s30, s38, #256
x8dot_row_77:
    s.addi       s33, s34, #-96
    v.movi       v13, #0
    s.sub        s35, s33, s32
    s.add        s33, s19, s32
    v.splat      v15, s35
    s.shli       s35, s32, #4
    s.addi       s36, s32, #1
    v.cmp.gt     p1, v15, v13
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v13, [s33, v31]            // index is in elements (ISA sec 9.1)
    s.add        s33, s30, s35
    s.movz       s35, #32
    v.st.b       [s33, #0], v13
    fence.acq_rel.device
    s.mov        s32, s36
    s.cmp.lt     s33, s32, s35
    br.nz        s33, x8dot_row_77
x8dot_done_76:
    v.splat      v13, s28
    v.movi       v15, #0
    v.splat      v28, s28
    v.movi       v31, #0
    mb.arm       s19, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s28, #0
    s.movz       s30, #0
    v.extract    s32, v20, #0
    s.movz       s33, #96
    v.cmp.ne     p1, v13, v15
    v.cmp.eq     p2, v28, v31
    s.mov        s35, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s19            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s19          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s19
    mb.arm       s28, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s30, v16, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s28
    mb.wait      s28
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s30, x8dot_done_78
    s.movz       s32, #0
    s.add        s33, s9, s26
    s.addi       s35, s32, #0
    s.addi       s32, s33, #96
    s.addi       s33, s38, #256
x8dot_row_79:
    s.addi       s36, s34, #-96
    v.movi       v13, #0
    s.sub        s37, s36, s35
    s.add        s36, s32, s35
    v.splat      v15, s37
    s.shli       s37, s35, #4
    s.addi       s39, s35, #1
    v.cmp.gt     p1, v15, v13
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v13, [s36, v23]            // index is in elements (ISA sec 9.1)
    s.add        s36, s33, s37
    s.movz       s37, #32
    v.st.b       [s36, #0], v13
    fence.acq_rel.device
    s.mov        s35, s39
    s.cmp.lt     s36, s35, s37
    br.nz        s36, x8dot_row_79
x8dot_done_78:
    v.splat      v13, s30
    v.movi       v15, #0
    v.splat      v23, s30
    v.movi       v28, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    s.movz       s33, #0
    v.extract    s35, v20, #1
    s.movz       s36, #96
    v.cmp.ne     p1, v13, v15
    v.cmp.eq     p2, v23, v28
    s.mov        s39, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s39, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s32, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v16, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_80
    s.movz       s35, #0
    s.add        s36, s9, s26
    s.addi       s37, s35, #0
    s.addi       s35, s36, #96
    s.addi       s36, s38, #256
x8dot_row_81:
    s.addi       s39, s34, #-96
    v.movi       v13, #0
    s.sub        s40, s39, s37
    s.add        s39, s35, s37
    v.splat      v15, s40
    s.shli       s40, s37, #4
    s.addi       s41, s37, #1
    v.cmp.gt     p1, v15, v13
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v13, [s39, v19]            // index is in elements (ISA sec 9.1)
    s.add        s39, s36, s40
    s.movz       s40, #32
    v.st.b       [s39, #0], v13
    fence.acq_rel.device
    s.mov        s37, s41
    s.cmp.lt     s39, s37, s40
    br.nz        s39, x8dot_row_81
x8dot_done_80:
    v.splat      v13, s33
    v.movi       v15, #0
    v.splat      v19, s33
    v.movi       v23, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s35, #0
    s.movz       s36, #0
    v.extract    s37, v20, #2
    s.movz       s39, #96
    v.cmp.ne     p1, v13, v15
    v.cmp.eq     p2, v19, v23
    s.mov        s40, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v16, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s36, x8dot_done_82
    s.movz       s37, #0
    s.add        s39, s9, s26
    s.addi       s40, s37, #0
    s.addi       s37, s39, #96
    s.addi       s39, s38, #256
x8dot_row_83:
    s.addi       s41, s34, #-96
    v.movi       v13, #0
    s.sub        s42, s41, s40
    s.add        s41, s37, s40
    v.splat      v15, s42
    s.shli       s42, s40, #4
    s.addi       s43, s40, #1
    v.cmp.gt     p1, v15, v13
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v13, [s41, v25]            // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v13
    fence.acq_rel.device
    s.mov        s40, s43
    s.cmp.lt     s41, s40, s42
    br.nz        s41, x8dot_row_83
x8dot_done_82:
    v.splat      v13, s36
    v.movi       v15, #0
    v.splat      v19, s36
    v.movi       v23, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    s.movz       s39, #0
    v.extract    s40, v20, #3
    s.movz       s41, #96
    v.cmp.ne     p1, v13, v15
    v.cmp.eq     p2, v19, v23
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v16, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s39, x8dot_done_84
    s.movz       s40, #0
    s.add        s41, s9, s26
    s.addi       s42, s40, #0
    s.addi       s40, s41, #96
    s.addi       s41, s38, #256
x8dot_row_85:
    s.addi       s43, s34, #-96
    v.movi       v13, #0
    s.sub        s44, s43, s42
    s.add        s43, s40, s42
    v.splat      v15, s44
    s.shli       s44, s42, #4
    s.addi       s45, s42, #1
    v.cmp.gt     p1, v15, v13
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v13, [s43, v26]            // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.movz       s44, #32
    v.st.b       [s43, #0], v13
    fence.acq_rel.device
    s.mov        s42, s45
    s.cmp.lt     s43, s42, s44
    br.nz        s43, x8dot_row_85
x8dot_done_84:
    v.splat      v13, s39
    v.movi       v15, #0
    v.splat      v19, s39
    v.movi       v23, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    s.movz       s41, #0
    v.extract    s42, v20, #4
    s.movz       s43, #96
    v.cmp.ne     p1, v13, v15
    v.cmp.eq     p2, v19, v23
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s44, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s40, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v16, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s40
    mb.wait      s40
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s41, x8dot_done_86
    s.movz       s42, #0
    s.add        s43, s9, s26
    s.addi       s44, s42, #0
    s.addi       s42, s43, #96
    s.addi       s43, s38, #256
x8dot_row_87:
    s.addi       s45, s34, #-96
    v.movi       v13, #0
    s.sub        s46, s45, s44
    s.add        s45, s42, s44
    v.splat      v15, s46
    s.shli       s46, s44, #4
    s.addi       s47, s44, #1
    v.cmp.gt     p1, v15, v13
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v13, [s45, v27]            // index is in elements (ISA sec 9.1)
    s.add        s45, s43, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v13
    fence.acq_rel.device
    s.mov        s44, s47
    s.cmp.lt     s45, s44, s46
    br.nz        s45, x8dot_row_87
x8dot_done_86:
    v.splat      v13, s41
    v.movi       v15, #0
    v.splat      v19, s41
    v.movi       v23, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    s.movz       s43, #0
    v.extract    s44, v20, #5
    s.movz       s45, #96
    v.cmp.ne     p1, v13, v15
    v.cmp.eq     p2, v19, v23
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s46, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v16, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s42
    mb.wait      s42
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s43, x8dot_done_88
    s.movz       s44, #0
    s.add        s45, s9, s26
    s.addi       s46, s44, #0
    s.addi       s44, s45, #96
    s.addi       s45, s38, #256
x8dot_row_89:
    s.addi       s47, s34, #-96
    v.movi       v13, #0
    s.sub        s48, s47, s46
    s.add        s47, s44, s46
    v.splat      v15, s48
    s.shli       s48, s46, #4
    s.addi       s49, s46, #1
    v.cmp.gt     p1, v15, v13
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v13, [s47, v32]            // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s48
    s.movz       s48, #32
    v.st.b       [s47, #0], v13
    fence.acq_rel.device
    s.mov        s46, s49
    s.cmp.lt     s47, s46, s48
    br.nz        s47, x8dot_row_89
x8dot_done_88:
    v.splat      v13, s43
    v.movi       v15, #0
    v.splat      v19, s43
    v.movi       v23, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    s.movz       s45, #0
    v.extract    s46, v20, #6
    s.movz       s47, #96
    v.cmp.ne     p1, v13, v15
    v.cmp.eq     p2, v19, v23
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s48, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v16, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s44
    mb.wait      s44
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s45, x8dot_done_90
    s.movz       s46, #0
    s.add        s47, s9, s26
    s.addi       s48, s46, #0
    s.addi       s46, s47, #96
    s.addi       s47, s38, #256
x8dot_row_91:
    s.addi       s49, s34, #-96
    v.movi       v13, #0
    s.sub        s50, s49, s48
    s.add        s49, s46, s48
    v.splat      v15, s50
    s.shli       s50, s48, #4
    s.addi       s51, s48, #1
    v.cmp.gt     p1, v15, v13
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v13, [s49, v29]            // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.movz       s50, #32
    v.st.b       [s49, #0], v13
    fence.acq_rel.device
    s.mov        s48, s51
    s.cmp.lt     s49, s48, s50
    br.nz        s49, x8dot_row_91
x8dot_done_90:
    v.splat      v13, s45
    v.movi       v15, #0
    v.splat      v16, s45
    v.movi       v19, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    s.movz       s46, #0
    v.extract    s47, v20, #7
    s.movz       s48, #96
    v.cmp.ne     p1, v13, v15
    v.cmp.eq     p2, v16, v19
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s46, #0
    s.addi       s47, s38, #3072
    m.mma.async.k32.e4m3 a15, v48, v56, s45
    mb.wait      s45
    a.vread      v13, a8, s46
    s.movz       s46, #1
    s.addi       s48, s47, #64
    v.st.w       [s47, #0], v13
    a.vread      v13, a8, s46
    s.movz       s46, #2
    s.addi       s49, s47, #128
    s.movz       s50, #3
    s.addi       s51, s47, #192
    s.movz       s52, #4
    v.st.w       [s48, #0], v13
    a.vread      v13, a8, s46
    s.addi       s46, s47, #256
    s.movz       s48, #5
    v.st.w       [s49, #0], v13
    a.vread      v13, a8, s50
    s.addi       s49, s47, #320
    s.movz       s50, #6
    v.st.w       [s51, #0], v13
    a.vread      v13, a8, s52
    s.addi       s51, s47, #384
    s.movz       s52, #7
    v.st.w       [s46, #0], v13
    a.vread      v13, a8, s48
    s.addi       s46, s47, #448
    s.movz       s48, #8
    v.st.w       [s49, #0], v13
    a.vread      v13, a8, s50
    s.addi       s49, s47, #512
    s.movz       s50, #9
    v.st.w       [s51, #0], v13
    a.vread      v13, a8, s52
    s.addi       s51, s47, #576
    s.movz       s52, #10
    v.st.w       [s46, #0], v13
    a.vread      v13, a8, s48
    s.addi       s46, s47, #640
    s.movz       s48, #11
    v.st.w       [s49, #0], v13
    a.vread      v13, a8, s50
    s.addi       s49, s47, #704
    s.movz       s50, #12
    v.st.w       [s51, #0], v13
    a.vread      v13, a8, s52
    s.addi       s51, s47, #768
    s.movz       s52, #13
    v.st.w       [s46, #0], v13
    a.vread      v13, a8, s48
    s.addi       s46, s47, #832
    s.movz       s48, #14
    v.st.w       [s49, #0], v13
    a.vread      v13, a8, s50
    s.addi       s49, s47, #896
    s.movz       s50, #15
    s.addi       s53, s47, #960
    v.st.w       [s51, #0], v13
    a.vread      v13, a8, s52
    s.movz       s47, #0
    s.addi       s51, s38, #4096
    v.st.w       [s46, #0], v13
    a.vread      v13, a8, s48
    s.movz       s46, #1
    s.addi       s48, s51, #64
    v.st.w       [s49, #0], v13
    a.vread      v13, a8, s50
    s.movz       s49, #2
    s.addi       s50, s51, #128
    v.st.w       [s53, #0], v13
    fence.acq_rel.device
    a.vread      v13, a9, s47
    s.movz       s47, #3
    s.addi       s52, s51, #192
    v.st.w       [s51, #0], v13
    a.vread      v13, a9, s46
    s.movz       s46, #4
    v.st.w       [s48, #0], v13
    a.vread      v13, a9, s49
    s.addi       s48, s51, #256
    s.movz       s49, #5
    v.st.w       [s50, #0], v13
    a.vread      v13, a9, s47
    s.addi       s47, s51, #320
    s.movz       s50, #6
    v.st.w       [s52, #0], v13
    a.vread      v13, a9, s46
    s.addi       s46, s51, #384
    s.movz       s52, #7
    v.st.w       [s48, #0], v13
    a.vread      v13, a9, s49
    s.addi       s48, s51, #448
    s.movz       s49, #8
    v.st.w       [s47, #0], v13
    a.vread      v13, a9, s50
    s.addi       s47, s51, #512
    s.movz       s50, #9
    v.st.w       [s46, #0], v13
    a.vread      v13, a9, s52
    s.addi       s46, s51, #576
    s.movz       s52, #10
    v.st.w       [s48, #0], v13
    a.vread      v13, a9, s49
    s.addi       s48, s51, #640
    s.movz       s49, #11
    v.st.w       [s47, #0], v13
    a.vread      v13, a9, s50
    s.addi       s47, s51, #704
    s.movz       s50, #12
    v.st.w       [s46, #0], v13
    a.vread      v13, a9, s52
    s.addi       s46, s51, #768
    s.movz       s52, #13
    v.st.w       [s48, #0], v13
    a.vread      v13, a9, s49
    s.addi       s48, s51, #832
    s.movz       s49, #14
    v.st.w       [s47, #0], v13
    a.vread      v13, a9, s50
    s.addi       s47, s51, #896
    s.movz       s50, #15
    s.addi       s53, s51, #960
    v.st.w       [s46, #0], v13
    a.vread      v13, a9, s52
    s.movz       s46, #0
    s.addi       s51, s38, #5120
    v.st.w       [s48, #0], v13
    a.vread      v13, a9, s49
    s.movz       s48, #1
    s.addi       s49, s51, #64
    v.st.w       [s47, #0], v13
    a.vread      v13, a9, s50
    s.movz       s47, #2
    s.addi       s50, s51, #128
    v.st.w       [s53, #0], v13
    fence.acq_rel.device
    a.vread      v13, a10, s46
    s.movz       s46, #3
    s.addi       s52, s51, #192
    v.st.w       [s51, #0], v13
    a.vread      v13, a10, s48
    s.movz       s48, #4
    v.st.w       [s49, #0], v13
    a.vread      v13, a10, s47
    s.addi       s47, s51, #256
    s.movz       s49, #5
    v.st.w       [s50, #0], v13
    a.vread      v13, a10, s46
    s.addi       s46, s51, #320
    s.movz       s50, #6
    v.st.w       [s52, #0], v13
    a.vread      v13, a10, s48
    s.addi       s48, s51, #384
    s.movz       s52, #7
    v.st.w       [s47, #0], v13
    a.vread      v13, a10, s49
    s.addi       s47, s51, #448
    s.movz       s49, #8
    v.st.w       [s46, #0], v13
    a.vread      v13, a10, s50
    s.addi       s46, s51, #512
    s.movz       s50, #9
    v.st.w       [s48, #0], v13
    a.vread      v13, a10, s52
    s.addi       s48, s51, #576
    s.movz       s52, #10
    v.st.w       [s47, #0], v13
    a.vread      v13, a10, s49
    s.addi       s47, s51, #640
    s.movz       s49, #11
    v.st.w       [s46, #0], v13
    a.vread      v13, a10, s50
    s.addi       s46, s51, #704
    s.movz       s50, #12
    v.st.w       [s48, #0], v13
    a.vread      v13, a10, s52
    s.addi       s48, s51, #768
    s.movz       s52, #13
    v.st.w       [s47, #0], v13
    a.vread      v13, a10, s49
    s.addi       s47, s51, #832
    s.movz       s49, #14
    v.st.w       [s46, #0], v13
    a.vread      v13, a10, s50
    s.addi       s46, s51, #896
    s.movz       s50, #15
    s.addi       s53, s51, #960
    v.st.w       [s48, #0], v13
    a.vread      v13, a10, s52
    s.movz       s48, #0
    s.addi       s51, s38, #6144
    v.st.w       [s47, #0], v13
    a.vread      v13, a10, s49
    s.movz       s47, #1
    s.addi       s49, s51, #64
    v.st.w       [s46, #0], v13
    a.vread      v13, a10, s50
    s.movz       s46, #2
    s.addi       s50, s51, #128
    v.st.w       [s53, #0], v13
    fence.acq_rel.device
    a.vread      v13, a11, s48
    s.movz       s48, #3
    s.addi       s52, s51, #192
    v.st.w       [s51, #0], v13
    a.vread      v13, a11, s47
    s.movz       s47, #4
    v.st.w       [s49, #0], v13
    a.vread      v13, a11, s46
    s.addi       s46, s51, #256
    s.movz       s49, #5
    v.st.w       [s50, #0], v13
    a.vread      v13, a11, s48
    s.addi       s48, s51, #320
    s.movz       s50, #6
    v.st.w       [s52, #0], v13
    a.vread      v13, a11, s47
    s.addi       s47, s51, #384
    s.movz       s52, #7
    v.st.w       [s46, #0], v13
    a.vread      v13, a11, s49
    s.addi       s46, s51, #448
    s.movz       s49, #8
    v.st.w       [s48, #0], v13
    a.vread      v13, a11, s50
    s.addi       s48, s51, #512
    s.movz       s50, #9
    v.st.w       [s47, #0], v13
    a.vread      v13, a11, s52
    s.addi       s47, s51, #576
    s.movz       s52, #10
    v.st.w       [s46, #0], v13
    a.vread      v13, a11, s49
    s.addi       s46, s51, #640
    s.movz       s49, #11
    v.st.w       [s48, #0], v13
    a.vread      v13, a11, s50
    s.addi       s48, s51, #704
    s.movz       s50, #12
    v.st.w       [s47, #0], v13
    a.vread      v13, a11, s52
    s.addi       s47, s51, #768
    s.movz       s52, #13
    v.st.w       [s46, #0], v13
    a.vread      v13, a11, s49
    s.addi       s46, s51, #832
    s.movz       s49, #14
    v.st.w       [s48, #0], v13
    a.vread      v13, a11, s50
    s.addi       s48, s51, #896
    s.movz       s50, #15
    s.addi       s53, s51, #960
    v.st.w       [s47, #0], v13
    a.vread      v13, a11, s52
    s.movz       s47, #0
    s.addi       s51, s38, #7168
    v.st.w       [s46, #0], v13
    a.vread      v13, a11, s49
    s.movz       s46, #1
    s.addi       s49, s51, #64
    v.st.w       [s48, #0], v13
    a.vread      v13, a11, s50
    s.movz       s48, #2
    s.addi       s50, s51, #128
    v.st.w       [s53, #0], v13
    fence.acq_rel.device
    a.vread      v13, a12, s47
    s.movz       s47, #3
    s.addi       s52, s51, #192
    v.st.w       [s51, #0], v13
    a.vread      v13, a12, s46
    s.movz       s46, #4
    v.st.w       [s49, #0], v13
    a.vread      v13, a12, s48
    s.addi       s48, s51, #256
    s.movz       s49, #5
    v.st.w       [s50, #0], v13
    a.vread      v13, a12, s47
    s.addi       s47, s51, #320
    s.movz       s50, #6
    v.st.w       [s52, #0], v13
    a.vread      v13, a12, s46
    s.addi       s46, s51, #384
    s.movz       s52, #7
    v.st.w       [s48, #0], v13
    a.vread      v13, a12, s49
    s.addi       s48, s51, #448
    s.movz       s49, #8
    v.st.w       [s47, #0], v13
    a.vread      v13, a12, s50
    s.addi       s47, s51, #512
    s.movz       s50, #9
    v.st.w       [s46, #0], v13
    a.vread      v13, a12, s52
    s.addi       s46, s51, #576
    s.movz       s52, #10
    v.st.w       [s48, #0], v13
    a.vread      v13, a12, s49
    s.addi       s48, s51, #640
    s.movz       s49, #11
    v.st.w       [s47, #0], v13
    a.vread      v13, a12, s50
    s.addi       s47, s51, #704
    s.movz       s50, #12
    v.st.w       [s46, #0], v13
    a.vread      v13, a12, s52
    s.addi       s46, s51, #768
    s.movz       s52, #13
    v.st.w       [s48, #0], v13
    a.vread      v13, a12, s49
    s.addi       s48, s51, #832
    s.movz       s49, #14
    v.st.w       [s47, #0], v13
    a.vread      v13, a12, s50
    s.addi       s47, s51, #896
    s.movz       s50, #15
    s.addi       s53, s51, #960
    v.st.w       [s46, #0], v13
    a.vread      v13, a12, s52
    s.movz       s46, #0
    s.addi       s51, s38, #8192
    v.st.w       [s48, #0], v13
    a.vread      v13, a12, s49
    s.movz       s48, #1
    s.addi       s49, s51, #64
    v.st.w       [s47, #0], v13
    a.vread      v13, a12, s50
    s.movz       s47, #2
    s.addi       s50, s51, #128
    v.st.w       [s53, #0], v13
    fence.acq_rel.device
    a.vread      v13, a13, s46
    s.movz       s46, #3
    s.addi       s52, s51, #192
    v.st.w       [s51, #0], v13
    a.vread      v13, a13, s48
    s.movz       s48, #4
    v.st.w       [s49, #0], v13
    a.vread      v13, a13, s47
    s.addi       s47, s51, #256
    s.movz       s49, #5
    v.st.w       [s50, #0], v13
    a.vread      v13, a13, s46
    s.addi       s46, s51, #320
    s.movz       s50, #6
    v.st.w       [s52, #0], v13
    a.vread      v13, a13, s48
    s.addi       s48, s51, #384
    s.movz       s52, #7
    v.st.w       [s47, #0], v13
    a.vread      v13, a13, s49
    s.addi       s47, s51, #448
    s.movz       s49, #8
    v.st.w       [s46, #0], v13
    a.vread      v13, a13, s50
    s.addi       s46, s51, #512
    s.movz       s50, #9
    v.st.w       [s48, #0], v13
    a.vread      v13, a13, s52
    s.addi       s48, s51, #576
    s.movz       s52, #10
    v.st.w       [s47, #0], v13
    a.vread      v13, a13, s49
    s.addi       s47, s51, #640
    s.movz       s49, #11
    v.st.w       [s46, #0], v13
    a.vread      v13, a13, s50
    s.addi       s46, s51, #704
    s.movz       s50, #12
    v.st.w       [s48, #0], v13
    a.vread      v13, a13, s52
    s.addi       s48, s51, #768
    s.movz       s52, #13
    v.st.w       [s47, #0], v13
    a.vread      v13, a13, s49
    s.addi       s47, s51, #832
    s.movz       s49, #14
    v.st.w       [s46, #0], v13
    a.vread      v13, a13, s50
    s.addi       s46, s51, #896
    s.movz       s50, #15
    s.addi       s53, s51, #960
    v.st.w       [s48, #0], v13
    a.vread      v13, a13, s52
    s.movz       s48, #0
    s.addi       s51, s38, #9216
    v.st.w       [s47, #0], v13
    a.vread      v13, a13, s49
    s.movz       s47, #1
    s.addi       s49, s51, #64
    v.st.w       [s46, #0], v13
    a.vread      v13, a13, s50
    s.movz       s46, #2
    s.addi       s50, s51, #128
    v.st.w       [s53, #0], v13
    fence.acq_rel.device
    a.vread      v13, a14, s48
    s.movz       s48, #3
    s.addi       s52, s51, #192
    v.st.w       [s51, #0], v13
    a.vread      v13, a14, s47
    s.movz       s47, #4
    v.st.w       [s49, #0], v13
    a.vread      v13, a14, s46
    s.addi       s46, s51, #256
    s.movz       s49, #5
    v.st.w       [s50, #0], v13
    a.vread      v13, a14, s48
    s.addi       s48, s51, #320
    s.movz       s50, #6
    v.st.w       [s52, #0], v13
    a.vread      v13, a14, s47
    s.addi       s47, s51, #384
    s.movz       s52, #7
    v.st.w       [s46, #0], v13
    a.vread      v13, a14, s49
    s.addi       s46, s51, #448
    s.movz       s49, #8
    v.st.w       [s48, #0], v13
    a.vread      v13, a14, s50
    s.addi       s48, s51, #512
    s.movz       s50, #9
    v.st.w       [s47, #0], v13
    a.vread      v13, a14, s52
    s.addi       s47, s51, #576
    s.movz       s52, #10
    v.st.w       [s46, #0], v13
    a.vread      v13, a14, s49
    s.addi       s46, s51, #640
    s.movz       s49, #11
    v.st.w       [s48, #0], v13
    a.vread      v13, a14, s50
    s.addi       s48, s51, #704
    s.movz       s50, #12
    v.st.w       [s47, #0], v13
    a.vread      v13, a14, s52
    s.addi       s47, s51, #768
    s.movz       s52, #13
    v.st.w       [s46, #0], v13
    a.vread      v13, a14, s49
    s.addi       s46, s51, #832
    s.movz       s49, #14
    v.st.w       [s48, #0], v13
    a.vread      v13, a14, s50
    s.addi       s48, s51, #896
    s.movz       s50, #15
    s.addi       s53, s51, #960
    v.st.w       [s47, #0], v13
    a.vread      v13, a14, s52
    s.movz       s47, #0
    s.addi       s51, s38, #10240
    v.st.w       [s46, #0], v13
    a.vread      v13, a14, s49
    s.movz       s46, #1
    s.addi       s49, s51, #64
    v.st.w       [s48, #0], v13
    a.vread      v13, a14, s50
    s.movz       s48, #2
    s.addi       s50, s51, #128
    v.st.w       [s53, #0], v13
    fence.acq_rel.device
    a.vread      v13, a15, s47
    s.movz       s47, #3
    s.addi       s52, s51, #192
    v.st.w       [s51, #0], v13
    a.vread      v13, a15, s46
    s.movz       s46, #4
    v.st.w       [s49, #0], v13
    a.vread      v13, a15, s48
    s.addi       s48, s51, #256
    s.movz       s49, #5
    v.st.w       [s50, #0], v13
    a.vread      v13, a15, s47
    s.addi       s47, s51, #320
    s.movz       s50, #6
    v.st.w       [s52, #0], v13
    a.vread      v13, a15, s46
    s.addi       s46, s51, #384
    s.movz       s52, #7
    v.st.w       [s48, #0], v13
    a.vread      v13, a15, s49
    s.addi       s48, s51, #448
    s.movz       s49, #8
    v.st.w       [s47, #0], v13
    a.vread      v13, a15, s50
    s.addi       s47, s51, #512
    s.movz       s50, #9
    v.st.w       [s46, #0], v13
    a.vread      v13, a15, s52
    s.addi       s46, s51, #576
    s.movz       s52, #10
    v.st.w       [s48, #0], v13
    a.vread      v13, a15, s49
    s.addi       s48, s51, #640
    s.movz       s49, #11
    v.st.w       [s47, #0], v13
    a.vread      v13, a15, s50
    s.addi       s47, s51, #704
    s.movz       s50, #12
    v.st.w       [s46, #0], v13
    a.vread      v13, a15, s52
    s.addi       s46, s51, #768
    s.movz       s52, #13
    v.st.w       [s48, #0], v13
    a.vread      v13, a15, s49
    s.addi       s48, s51, #832
    s.movz       s49, #14
    v.st.w       [s47, #0], v13
    a.vread      v13, a15, s50
    s.addi       s47, s51, #896
    s.movz       s50, #15
    s.addi       s53, s51, #960
    v.st.w       [s46, #0], v13
    a.vread      v13, a15, s52
    s.movz       s46, #0
    s.addi       s51, s38, #3072
    v.st.w       [s48, #0], v13
    a.vread      v13, a15, s49
    s.addi       s48, s38, #11264
    s.movz       s49, #1
    v.st.w       [s47, #0], v13
    a.vread      v13, a15, s50
    s.addi       s47, s38, #3136
    s.addi       s50, s48, #64
    v.st.w       [s53, #0], v13
    fence.acq_rel.device
    a.vread      v13, a0, s46
    s.movz       s46, #2
    s.addi       s52, s38, #3200
    v.ld.w       v15, [s51, #0]
    s.addi       s51, s48, #128
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s48, #0], v15
    a.vread      v13, a0, s49
    s.movz       s49, #3
    v.ld.w       v15, [s47, #0]
    s.addi       s47, s38, #3264
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s50, #0], v15
    a.vread      v13, a0, s46
    s.addi       s46, s48, #192
    s.movz       s50, #4
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #3328
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s51, #0], v15
    a.vread      v13, a0, s49
    s.addi       s49, s48, #256
    s.movz       s51, #5
    v.ld.w       v15, [s47, #0]
    s.addi       s47, s38, #3392
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a0, s50
    s.addi       s46, s48, #320
    s.movz       s50, #6
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #3456
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s49, #0], v15
    a.vread      v13, a0, s51
    s.addi       s49, s48, #384
    s.movz       s51, #7
    v.ld.w       v15, [s47, #0]
    s.addi       s47, s38, #3520
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a0, s50
    s.addi       s46, s48, #448
    s.movz       s50, #8
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #3584
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s49, #0], v15
    a.vread      v13, a0, s51
    s.addi       s49, s48, #512
    s.movz       s51, #9
    v.ld.w       v15, [s47, #0]
    s.addi       s47, s38, #3648
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a0, s50
    s.addi       s46, s48, #576
    s.movz       s50, #10
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #3712
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s49, #0], v15
    a.vread      v13, a0, s51
    s.addi       s49, s48, #640
    s.movz       s51, #11
    v.ld.w       v15, [s47, #0]
    s.addi       s47, s38, #3776
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a0, s50
    s.addi       s46, s48, #704
    s.movz       s50, #12
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #3840
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s49, #0], v15
    a.vread      v13, a0, s51
    s.addi       s49, s48, #768
    s.movz       s51, #13
    v.ld.w       v15, [s47, #0]
    s.addi       s47, s38, #3904
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a0, s50
    s.addi       s46, s48, #832
    s.movz       s50, #14
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #3968
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s49, #0], v15
    a.vread      v13, a0, s51
    s.addi       s49, s48, #896
    s.movz       s51, #15
    s.addi       s53, s48, #960
    v.ld.w       v15, [s47, #0]
    s.addi       s47, s38, #4032
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a0, s50
    s.movz       s46, #0
    s.addi       s48, s38, #4096
    v.ld.w       v15, [s52, #0]
    s.addi       s50, s38, #12288
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s49, #0], v15
    a.vread      v13, a0, s51
    s.movz       s49, #1
    s.addi       s51, s38, #4160
    v.ld.w       v15, [s47, #0]
    s.addi       s47, s50, #64
    vf.mul       v16, v15, v22
    vf.add       v15, v13, v16
    v.st.w       [s53, #0], v15
    fence.acq_rel.device
    a.vread      v13, a1, s46
    s.movz       s46, #2
    s.addi       s52, s38, #4224
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s50, #128
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s50, #0], v15
    a.vread      v13, a1, s49
    s.movz       s49, #3
    v.ld.w       v15, [s51, #0]
    s.addi       s51, s38, #4288
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a1, s46
    s.addi       s46, s50, #192
    s.movz       s47, #4
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #4352
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s48, #0], v15
    a.vread      v13, a1, s49
    s.addi       s48, s50, #256
    s.movz       s49, #5
    v.ld.w       v15, [s51, #0]
    s.addi       s51, s38, #4416
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a1, s47
    s.addi       s46, s50, #320
    s.movz       s47, #6
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #4480
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s48, #0], v15
    a.vread      v13, a1, s49
    s.addi       s48, s50, #384
    s.movz       s49, #7
    v.ld.w       v15, [s51, #0]
    s.addi       s51, s38, #4544
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a1, s47
    s.addi       s46, s50, #448
    s.movz       s47, #8
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #4608
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s48, #0], v15
    a.vread      v13, a1, s49
    s.addi       s48, s50, #512
    s.movz       s49, #9
    v.ld.w       v15, [s51, #0]
    s.addi       s51, s38, #4672
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a1, s47
    s.addi       s46, s50, #576
    s.movz       s47, #10
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #4736
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s48, #0], v15
    a.vread      v13, a1, s49
    s.addi       s48, s50, #640
    s.movz       s49, #11
    v.ld.w       v15, [s51, #0]
    s.addi       s51, s38, #4800
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a1, s47
    s.addi       s46, s50, #704
    s.movz       s47, #12
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #4864
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s48, #0], v15
    a.vread      v13, a1, s49
    s.addi       s48, s50, #768
    s.movz       s49, #13
    v.ld.w       v15, [s51, #0]
    s.addi       s51, s38, #4928
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a1, s47
    s.addi       s46, s50, #832
    s.movz       s47, #14
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #4992
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s48, #0], v15
    a.vread      v13, a1, s49
    s.addi       s48, s50, #896
    s.movz       s49, #15
    s.addi       s53, s50, #960
    v.ld.w       v15, [s51, #0]
    s.addi       s50, s38, #5056
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a1, s47
    s.movz       s46, #0
    s.addi       s47, s38, #5120
    v.ld.w       v15, [s52, #0]
    s.addi       s51, s38, #13312
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s48, #0], v15
    a.vread      v13, a1, s49
    s.movz       s48, #1
    s.addi       s49, s38, #5184
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s51, #64
    vf.mul       v16, v15, v24
    vf.add       v15, v13, v16
    v.st.w       [s53, #0], v15
    fence.acq_rel.device
    a.vread      v13, a2, s46
    s.movz       s46, #2
    s.addi       s52, s38, #5248
    v.ld.w       v15, [s47, #0]
    s.addi       s47, s51, #128
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s51, #0], v15
    a.vread      v13, a2, s48
    s.movz       s48, #3
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s38, #5312
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s50, #0], v15
    a.vread      v13, a2, s46
    s.addi       s46, s51, #192
    s.movz       s50, #4
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #5376
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a2, s48
    s.addi       s47, s51, #256
    s.movz       s48, #5
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s38, #5440
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a2, s50
    s.addi       s46, s51, #320
    s.movz       s50, #6
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #5504
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a2, s48
    s.addi       s47, s51, #384
    s.movz       s48, #7
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s38, #5568
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a2, s50
    s.addi       s46, s51, #448
    s.movz       s50, #8
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #5632
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a2, s48
    s.addi       s47, s51, #512
    s.movz       s48, #9
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s38, #5696
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a2, s50
    s.addi       s46, s51, #576
    s.movz       s50, #10
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #5760
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a2, s48
    s.addi       s47, s51, #640
    s.movz       s48, #11
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s38, #5824
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a2, s50
    s.addi       s46, s51, #704
    s.movz       s50, #12
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #5888
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a2, s48
    s.addi       s47, s51, #768
    s.movz       s48, #13
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s38, #5952
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a2, s50
    s.addi       s46, s51, #832
    s.movz       s50, #14
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #6016
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a2, s48
    s.addi       s47, s51, #896
    s.movz       s48, #15
    s.addi       s53, s51, #960
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s38, #6080
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a2, s50
    s.movz       s46, #0
    s.addi       s50, s38, #6144
    v.ld.w       v15, [s52, #0]
    s.addi       s51, s38, #14336
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a2, s48
    s.movz       s47, #1
    s.addi       s48, s38, #6208
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s51, #64
    vf.mul       v16, v15, v30
    vf.add       v15, v13, v16
    v.st.w       [s53, #0], v15
    fence.acq_rel.device
    a.vread      v13, a3, s46
    s.movz       s46, #2
    s.addi       s52, s38, #6272
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s51, #128
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s51, #0], v15
    a.vread      v13, a3, s47
    s.movz       s47, #3
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s38, #6336
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s49, #0], v15
    a.vread      v13, a3, s46
    s.addi       s46, s51, #192
    s.movz       s49, #4
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #6400
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s50, #0], v15
    a.vread      v13, a3, s47
    s.addi       s47, s51, #256
    s.movz       s50, #5
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s38, #6464
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a3, s49
    s.addi       s46, s51, #320
    s.movz       s49, #6
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #6528
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a3, s50
    s.addi       s47, s51, #384
    s.movz       s50, #7
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s38, #6592
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a3, s49
    s.addi       s46, s51, #448
    s.movz       s49, #8
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #6656
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a3, s50
    s.addi       s47, s51, #512
    s.movz       s50, #9
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s38, #6720
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a3, s49
    s.addi       s46, s51, #576
    s.movz       s49, #10
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #6784
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a3, s50
    s.addi       s47, s51, #640
    s.movz       s50, #11
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s38, #6848
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a3, s49
    s.addi       s46, s51, #704
    s.movz       s49, #12
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #6912
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a3, s50
    s.addi       s47, s51, #768
    s.movz       s50, #13
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s38, #6976
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a3, s49
    s.addi       s46, s51, #832
    s.movz       s49, #14
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #7040
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a3, s50
    s.addi       s47, s51, #896
    s.movz       s50, #15
    s.addi       s53, s51, #960
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s38, #7104
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a3, s49
    s.movz       s46, #0
    s.addi       s49, s38, #7168
    v.ld.w       v15, [s52, #0]
    s.addi       s51, s38, #15360
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a3, s50
    s.movz       s47, #1
    s.addi       s50, s38, #7232
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s51, #64
    vf.mul       v16, v15, v33
    vf.add       v15, v13, v16
    v.st.w       [s53, #0], v15
    fence.acq_rel.device
    a.vread      v13, a4, s46
    s.movz       s46, #2
    s.addi       s52, s38, #7296
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s51, #128
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s51, #0], v15
    a.vread      v13, a4, s47
    s.movz       s47, #3
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s38, #7360
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s48, #0], v15
    a.vread      v13, a4, s46
    s.addi       s46, s51, #192
    s.movz       s48, #4
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #7424
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s49, #0], v15
    a.vread      v13, a4, s47
    s.addi       s47, s51, #256
    s.movz       s49, #5
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s38, #7488
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a4, s48
    s.addi       s46, s51, #320
    s.movz       s48, #6
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #7552
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a4, s49
    s.addi       s47, s51, #384
    s.movz       s49, #7
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s38, #7616
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a4, s48
    s.addi       s46, s51, #448
    s.movz       s48, #8
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #7680
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a4, s49
    s.addi       s47, s51, #512
    s.movz       s49, #9
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s38, #7744
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a4, s48
    s.addi       s46, s51, #576
    s.movz       s48, #10
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #7808
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a4, s49
    s.addi       s47, s51, #640
    s.movz       s49, #11
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s38, #7872
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a4, s48
    s.addi       s46, s51, #704
    s.movz       s48, #12
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #7936
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a4, s49
    s.addi       s47, s51, #768
    s.movz       s49, #13
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s38, #8000
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a4, s48
    s.addi       s46, s51, #832
    s.movz       s48, #14
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #8064
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a4, s49
    s.addi       s47, s51, #896
    s.movz       s49, #15
    s.addi       s53, s51, #960
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s38, #8128
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a4, s48
    s.movz       s46, #0
    s.addi       s48, s38, #8192
    v.ld.w       v15, [s52, #0]
    s.addi       s51, s38, #16384
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a4, s49
    s.movz       s47, #1
    s.addi       s49, s38, #8256
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s51, #64
    vf.mul       v16, v15, v34
    vf.add       v15, v13, v16
    v.st.w       [s53, #0], v15
    fence.acq_rel.device
    a.vread      v13, a5, s46
    s.movz       s46, #2
    s.addi       s52, s38, #8320
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s51, #128
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s51, #0], v15
    a.vread      v13, a5, s47
    s.movz       s47, #3
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s38, #8384
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s50, #0], v15
    a.vread      v13, a5, s46
    s.addi       s46, s51, #192
    s.movz       s50, #4
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #8448
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s48, #0], v15
    a.vread      v13, a5, s47
    s.addi       s47, s51, #256
    s.movz       s48, #5
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s38, #8512
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a5, s50
    s.addi       s46, s51, #320
    s.movz       s50, #6
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #8576
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a5, s48
    s.addi       s47, s51, #384
    s.movz       s48, #7
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s38, #8640
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a5, s50
    s.addi       s46, s51, #448
    s.movz       s50, #8
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #8704
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a5, s48
    s.addi       s47, s51, #512
    s.movz       s48, #9
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s38, #8768
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a5, s50
    s.addi       s46, s51, #576
    s.movz       s50, #10
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #8832
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a5, s48
    s.addi       s47, s51, #640
    s.movz       s48, #11
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s38, #8896
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a5, s50
    s.addi       s46, s51, #704
    s.movz       s50, #12
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #8960
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a5, s48
    s.addi       s47, s51, #768
    s.movz       s48, #13
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s38, #9024
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a5, s50
    s.addi       s46, s51, #832
    s.movz       s50, #14
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #9088
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a5, s48
    s.addi       s47, s51, #896
    s.movz       s48, #15
    s.addi       s53, s51, #960
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s38, #9152
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a5, s50
    s.movz       s46, #0
    s.addi       s50, s38, #9216
    v.ld.w       v15, [s52, #0]
    s.addi       s51, s38, #17408
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a5, s48
    s.movz       s47, #1
    s.addi       s48, s38, #9280
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s51, #64
    vf.mul       v16, v15, v35
    vf.add       v15, v13, v16
    v.st.w       [s53, #0], v15
    fence.acq_rel.device
    a.vread      v13, a6, s46
    s.movz       s46, #2
    s.addi       s52, s38, #9344
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s51, #128
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s51, #0], v15
    a.vread      v13, a6, s47
    s.movz       s47, #3
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s38, #9408
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s49, #0], v15
    a.vread      v13, a6, s46
    s.addi       s46, s51, #192
    s.movz       s49, #4
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #9472
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s50, #0], v15
    a.vread      v13, a6, s47
    s.addi       s47, s51, #256
    s.movz       s50, #5
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s38, #9536
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a6, s49
    s.addi       s46, s51, #320
    s.movz       s49, #6
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #9600
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a6, s50
    s.addi       s47, s51, #384
    s.movz       s50, #7
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s38, #9664
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a6, s49
    s.addi       s46, s51, #448
    s.movz       s49, #8
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #9728
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a6, s50
    s.addi       s47, s51, #512
    s.movz       s50, #9
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s38, #9792
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a6, s49
    s.addi       s46, s51, #576
    s.movz       s49, #10
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #9856
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a6, s50
    s.addi       s47, s51, #640
    s.movz       s50, #11
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s38, #9920
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a6, s49
    s.addi       s46, s51, #704
    s.movz       s49, #12
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #9984
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a6, s50
    s.addi       s47, s51, #768
    s.movz       s50, #13
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s38, #10048
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a6, s49
    s.addi       s46, s51, #832
    s.movz       s49, #14
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #10112
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a6, s50
    s.addi       s47, s51, #896
    s.movz       s50, #15
    s.addi       s53, s51, #960
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s38, #10176
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a6, s49
    s.movz       s46, #0
    s.addi       s49, s38, #10240
    v.ld.w       v15, [s52, #0]
    s.addi       s51, s38, #18432
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a6, s50
    s.movz       s47, #1
    s.addi       s50, s38, #10304
    v.ld.w       v15, [s48, #0]
    s.addi       s48, s51, #64
    vf.mul       v16, v15, v36
    vf.add       v15, v13, v16
    v.st.w       [s53, #0], v15
    fence.acq_rel.device
    a.vread      v13, a7, s46
    s.movz       s46, #2
    s.addi       s52, s38, #10368
    v.ld.w       v15, [s49, #0]
    s.addi       s49, s51, #128
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s51, #0], v15
    a.vread      v13, a7, s47
    s.movz       s47, #3
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s38, #10432
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s48, #0], v15
    a.vread      v13, a7, s46
    s.addi       s46, s51, #192
    s.movz       s48, #4
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #10496
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s49, #0], v15
    a.vread      v13, a7, s47
    s.addi       s47, s51, #256
    s.movz       s49, #5
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s38, #10560
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a7, s48
    s.addi       s46, s51, #320
    s.movz       s48, #6
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #10624
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a7, s49
    s.addi       s47, s51, #384
    s.movz       s49, #7
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s38, #10688
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a7, s48
    s.addi       s46, s51, #448
    s.movz       s48, #8
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #10752
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a7, s49
    s.addi       s47, s51, #512
    s.movz       s49, #9
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s38, #10816
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a7, s48
    s.addi       s46, s51, #576
    s.movz       s48, #10
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #10880
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a7, s49
    s.addi       s47, s51, #640
    s.movz       s49, #11
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s38, #10944
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a7, s48
    s.addi       s46, s51, #704
    s.movz       s48, #12
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #11008
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a7, s49
    s.addi       s47, s51, #768
    s.movz       s49, #13
    s.addi       s53, s27, #4                    // &ptr_carry_19[1] (a constant offset, x4)
    s.addi       s53, s27, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    s.addi       s53, s27, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    s.addi       s53, s27, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    s.addi       s53, s27, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s38, #11072
    s.addi       s53, s27, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    vf.mul       v16, v15, v37
    s.addi       s53, s27, #4                    // &ptr_carry_25[1] (a constant offset, x4)
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a7, s48
    s.addi       s46, s51, #832
    s.movz       s48, #14
    v.ld.w       v15, [s52, #0]
    s.addi       s52, s38, #11136
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a7, s49
    s.addi       s47, s51, #896
    s.movz       s49, #15
    s.addi       s53, s51, #960
    v.ld.w       v15, [s50, #0]
    s.addi       s50, s38, #11200
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s46, #0], v15
    a.vread      v13, a7, s48
    s.addi       s46, s25, #128
    s.addi       s48, s26, #128
    s.addi       s51, s46, #0
    s.addi       s46, s48, #0
    v.ld.w       v15, [s52, #0]
    s.addi       s48, s27, #4                    // &ptr_carry_18[1] (a constant offset, x4)
    s.addi       s52, s48, #0
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s47, #0], v15
    a.vread      v13, a7, s49
    s.addi       s47, s38, #11264
    s.movz       s48, #0
    v.ld.w       v15, [s50, #0]
    s.addi       s49, s38, #11328
    vf.mul       v16, v15, v37
    vf.add       v15, v13, v16
    v.st.w       [s53, #0], v15
    fence.acq_rel.device
    s.mov        s25, s51
    s.mov        s26, s46
    s.mov        s27, s52
    s.movz       s46, #1
    s.addi       s50, s38, #11392
    s.movz       s51, #2
    s.addi       s52, s38, #11456
    s.movz       s53, #3
    s.addi       s55, s38, #11520
    s.movz       s56, #4
    v.ld.w       v13, [s47, #0]
    s.addi       s47, s38, #11584
    a.vwrite     a0, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #5
    s.addi       s49, s38, #11648
    a.vwrite     a0, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #6
    s.addi       s50, s38, #11712
    a.vwrite     a0, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #7
    s.addi       s52, s38, #11776
    a.vwrite     a0, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #8
    s.addi       s55, s38, #11840
    a.vwrite     a0, s56, v13
    v.ld.w       v13, [s47, #0]
    s.movz       s47, #9
    s.addi       s56, s38, #11904
    a.vwrite     a0, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #10
    s.addi       s49, s38, #11968
    a.vwrite     a0, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #11
    s.addi       s50, s38, #12032
    a.vwrite     a0, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #12
    s.addi       s52, s38, #12096
    a.vwrite     a0, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #13
    s.addi       s55, s38, #12160
    a.vwrite     a0, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #14
    s.addi       s56, s38, #12224
    a.vwrite     a0, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #15
    s.addi       s49, s38, #12288
    a.vwrite     a0, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #0
    s.addi       s50, s38, #12352
    a.vwrite     a0, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #1
    s.addi       s52, s38, #12416
    a.vwrite     a0, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #2
    s.addi       s55, s38, #12480
    a.vwrite     a0, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #3
    s.addi       s56, s38, #12544
    a.vwrite     a0, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #4
    s.addi       s49, s38, #12608
    a.vwrite     a1, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #5
    s.addi       s50, s38, #12672
    a.vwrite     a1, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #6
    s.addi       s52, s38, #12736
    a.vwrite     a1, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #7
    s.addi       s55, s38, #12800
    a.vwrite     a1, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #8
    s.addi       s56, s38, #12864
    a.vwrite     a1, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #9
    s.addi       s49, s38, #12928
    a.vwrite     a1, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #10
    s.addi       s50, s38, #12992
    a.vwrite     a1, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #11
    s.addi       s52, s38, #13056
    a.vwrite     a1, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #12
    s.addi       s55, s38, #13120
    a.vwrite     a1, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #13
    s.addi       s56, s38, #13184
    a.vwrite     a1, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #14
    s.addi       s49, s38, #13248
    a.vwrite     a1, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #15
    s.addi       s50, s38, #13312
    a.vwrite     a1, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #0
    s.addi       s52, s38, #13376
    a.vwrite     a1, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #1
    s.addi       s55, s38, #13440
    a.vwrite     a1, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #2
    s.addi       s56, s38, #13504
    a.vwrite     a1, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #3
    s.addi       s49, s38, #13568
    a.vwrite     a1, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #4
    s.addi       s50, s38, #13632
    a.vwrite     a2, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #5
    s.addi       s52, s38, #13696
    a.vwrite     a2, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #6
    s.addi       s55, s38, #13760
    a.vwrite     a2, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #7
    s.addi       s56, s38, #13824
    a.vwrite     a2, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #8
    s.addi       s49, s38, #13888
    a.vwrite     a2, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #9
    s.addi       s50, s38, #13952
    a.vwrite     a2, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #10
    s.addi       s52, s38, #14016
    a.vwrite     a2, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #11
    s.addi       s55, s38, #14080
    a.vwrite     a2, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #12
    s.addi       s56, s38, #14144
    a.vwrite     a2, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #13
    s.addi       s49, s38, #14208
    a.vwrite     a2, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #14
    s.addi       s50, s38, #14272
    a.vwrite     a2, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #15
    s.addi       s52, s38, #14336
    a.vwrite     a2, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #0
    s.addi       s55, s38, #14400
    a.vwrite     a2, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #1
    s.addi       s56, s38, #14464
    a.vwrite     a2, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #2
    s.addi       s49, s38, #14528
    a.vwrite     a2, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #3
    s.addi       s50, s38, #14592
    a.vwrite     a2, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #4
    s.addi       s52, s38, #14656
    a.vwrite     a3, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #5
    s.addi       s55, s38, #14720
    a.vwrite     a3, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #6
    s.addi       s56, s38, #14784
    a.vwrite     a3, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #7
    s.addi       s49, s38, #14848
    a.vwrite     a3, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #8
    s.addi       s50, s38, #14912
    a.vwrite     a3, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #9
    s.addi       s52, s38, #14976
    a.vwrite     a3, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #10
    s.addi       s55, s38, #15040
    a.vwrite     a3, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #11
    s.addi       s56, s38, #15104
    a.vwrite     a3, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #12
    s.addi       s49, s38, #15168
    a.vwrite     a3, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #13
    s.addi       s50, s38, #15232
    a.vwrite     a3, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #14
    s.addi       s52, s38, #15296
    a.vwrite     a3, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #15
    s.addi       s55, s38, #15360
    a.vwrite     a3, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #0
    s.addi       s56, s38, #15424
    a.vwrite     a3, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #1
    s.addi       s49, s38, #15488
    a.vwrite     a3, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #2
    s.addi       s50, s38, #15552
    a.vwrite     a3, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #3
    s.addi       s52, s38, #15616
    a.vwrite     a3, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #4
    s.addi       s55, s38, #15680
    a.vwrite     a4, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #5
    s.addi       s56, s38, #15744
    a.vwrite     a4, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #6
    s.addi       s49, s38, #15808
    a.vwrite     a4, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #7
    s.addi       s50, s38, #15872
    a.vwrite     a4, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #8
    s.addi       s52, s38, #15936
    a.vwrite     a4, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #9
    s.addi       s55, s38, #16000
    a.vwrite     a4, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #10
    s.addi       s56, s38, #16064
    a.vwrite     a4, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #11
    s.addi       s49, s38, #16128
    a.vwrite     a4, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #12
    s.addi       s50, s38, #16192
    a.vwrite     a4, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #13
    s.addi       s52, s38, #16256
    a.vwrite     a4, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #14
    s.addi       s55, s38, #16320
    a.vwrite     a4, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #15
    s.addi       s56, s38, #16384
    a.vwrite     a4, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #0
    s.addi       s49, s38, #16448
    a.vwrite     a4, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #1
    s.addi       s50, s38, #16512
    a.vwrite     a4, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #2
    s.addi       s52, s38, #16576
    a.vwrite     a4, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #3
    s.addi       s55, s38, #16640
    a.vwrite     a4, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #4
    s.addi       s56, s38, #16704
    a.vwrite     a5, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #5
    s.addi       s49, s38, #16768
    a.vwrite     a5, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #6
    s.addi       s50, s38, #16832
    a.vwrite     a5, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #7
    s.addi       s52, s38, #16896
    a.vwrite     a5, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #8
    s.addi       s55, s38, #16960
    a.vwrite     a5, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #9
    s.addi       s56, s38, #17024
    a.vwrite     a5, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #10
    s.addi       s49, s38, #17088
    a.vwrite     a5, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #11
    s.addi       s50, s38, #17152
    a.vwrite     a5, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #12
    s.addi       s52, s38, #17216
    a.vwrite     a5, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #13
    s.addi       s55, s38, #17280
    a.vwrite     a5, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #14
    s.addi       s56, s38, #17344
    a.vwrite     a5, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #15
    s.addi       s49, s38, #17408
    a.vwrite     a5, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #0
    s.addi       s50, s38, #17472
    a.vwrite     a5, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #1
    s.addi       s52, s38, #17536
    a.vwrite     a5, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #2
    s.addi       s55, s38, #17600
    a.vwrite     a5, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #3
    s.addi       s56, s38, #17664
    a.vwrite     a5, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #4
    s.addi       s49, s38, #17728
    a.vwrite     a6, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #5
    s.addi       s50, s38, #17792
    a.vwrite     a6, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #6
    s.addi       s52, s38, #17856
    a.vwrite     a6, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #7
    s.addi       s55, s38, #17920
    a.vwrite     a6, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #8
    s.addi       s56, s38, #17984
    a.vwrite     a6, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #9
    s.addi       s49, s38, #18048
    a.vwrite     a6, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #10
    s.addi       s50, s38, #18112
    a.vwrite     a6, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #11
    s.addi       s52, s38, #18176
    a.vwrite     a6, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #12
    s.addi       s55, s38, #18240
    a.vwrite     a6, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #13
    s.addi       s56, s38, #18304
    a.vwrite     a6, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #14
    s.addi       s49, s38, #18368
    a.vwrite     a6, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #15
    s.addi       s50, s38, #18432
    a.vwrite     a6, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #0
    s.addi       s52, s38, #18496
    a.vwrite     a6, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #1
    s.addi       s55, s38, #18560
    a.vwrite     a6, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #2
    s.addi       s56, s38, #18624
    a.vwrite     a6, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #3
    s.addi       s49, s38, #18688
    a.vwrite     a6, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #4
    s.addi       s50, s38, #18752
    a.vwrite     a7, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #5
    s.addi       s52, s38, #18816
    a.vwrite     a7, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #6
    s.addi       s55, s38, #18880
    a.vwrite     a7, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #7
    s.addi       s56, s38, #18944
    a.vwrite     a7, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #8
    s.addi       s49, s38, #19008
    s.add        s57, s20, s16
    a.vwrite     a7, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s46, #9
    s.addi       s50, s38, #19072
    a.vwrite     a7, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s51, #10
    s.addi       s52, s38, #19136
    a.vwrite     a7, s53, v13
    v.ld.w       v13, [s55, #0]
    s.movz       s53, #11
    s.addi       s55, s38, #19200
    a.vwrite     a7, s47, v13
    v.ld.w       v13, [s56, #0]
    s.movz       s47, #12
    s.addi       s56, s38, #19264
    a.vwrite     a7, s48, v13
    v.ld.w       v13, [s49, #0]
    s.movz       s48, #13
    s.addi       s49, s38, #19328
    s.addi       s58, s38, #19392
    a.vwrite     a7, s46, v13
    v.ld.w       v13, [s50, #0]
    s.movz       s38, #14
    s.movz       s46, #15
    a.vwrite     a7, s51, v13
    v.ld.w       v13, [s52, #0]
    s.movz       s50, #1
    a.vwrite     a7, s53, v13
    v.ld.w       v13, [s55, #0]
    a.vwrite     a7, s47, v13
    v.ld.w       v13, [s56, #0]
    a.vwrite     a7, s48, v13
    v.ld.w       v13, [s49, #0]
    a.vwrite     a7, s38, v13
    v.ld.w       v13, [s58, #0]
    a.vwrite     a7, s46, v13
    s.mov        s20, s57
    br.nz        s50, for_26
endfor_27:
    s.movz       s2, #0
    s.mul        s4, s1, s5
    v.splat      v0, s31
    a.vread      v1, a0, s2
    s.movz       s2, #0
    s.movz       s6, #0
    s.add        s8, s2, s14                     // the tile origin
    vf.mul       v2, v1, v0
    s.movz       s2, #0
    s.movz       s9, #0
    s.muli       s10, s4, #2
    s.muli       s4, s14, #2
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v3, s8
    s.add        s8, s6, s1                      // the tile origin
    s.add        s1, s2, s12                     // the tile origin
    s.add        s2, s9, s3                      // the tile origin
    v.splat      v4, s8
    v.splat      v5, s1
    v.add        v6, v1, v3
    v.splat      v3, s2
    vf.cvt.f32.bf16 v7, v2
    s.add        s1, s10, s4
    s.muli       s2, s5, #2
    v.cmp.lt     p1, v4, v5
    v.cmp.lt     p2, v6, v3
    s.add        s5, s7, s1
    p.and        p3, p1, p2
    s.movz       s1, #1
    @p3 v.st.h       [s5, #0], v7
    a.vread      v2, a0, s1
    s.muli       s1, s2, #1
    s.addi       s5, s8, #1
    vf.mul       v3, v2, v0
    v.splat      v2, s5
    s.addi       s5, s14, #16
    s.add        s6, s1, s10
    v.cmp.lt     p1, v2, v5
    vf.cvt.f32.bf16 v2, v3
    s.add        s1, s6, s4
    p.and        p3, p1, p2
    s.add        s6, s7, s1
    s.movz       s1, #2
    @p3 v.st.h       [s6, #0], v2
    s.addi       s6, s14, #32
    a.vread      v2, a0, s1
    s.addi       s1, s14, #48
    s.addi       s9, s14, #64
    vf.mul       v3, v2, v0
    s.addi       s11, s14, #80
    s.muli       s12, s2, #2
    s.addi       s13, s14, #96
    s.addi       s15, s14, #112
    s.addi       s14, s8, #2
    vf.cvt.f32.bf16 v2, v3
    s.add        s16, s12, s10
    v.splat      v3, s14
    s.add        s12, s16, s4
    s.movz       s14, #3
    v.cmp.lt     p1, v3, v5
    s.add        s16, s7, s12
    p.and        p3, p1, p2
    s.muli       s12, s2, #3
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a0, s14
    s.addi       s14, s8, #3
    s.movz       s16, #4
    vf.mul       v3, v2, v0
    s.add        s17, s12, s10
    v.splat      v2, s14
    s.add        s12, s17, s4
    s.muli       s14, s2, #4
    vf.cvt.f32.bf16 v4, v3
    v.cmp.lt     p1, v2, v5
    s.add        s17, s7, s12
    p.and        p3, p1, p2
    s.addi       s12, s8, #4
    @p3 v.st.h       [s17, #0], v4
    a.vread      v2, a0, s16
    s.add        s16, s14, s10
    v.splat      v3, s12
    vf.mul       v4, v2, v0
    s.add        s12, s16, s4
    v.cmp.lt     p1, v3, v5
    s.add        s14, s7, s12
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v4
    s.movz       s12, #5
    s.muli       s16, s2, #5
    s.addi       s17, s8, #5
    s.movz       s18, #6
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s12
    s.add        s12, s16, s10
    v.splat      v3, s17
    vf.mul       v4, v2, v0
    s.add        s14, s12, s4
    v.cmp.lt     p1, v3, v5
    s.add        s12, s7, s14
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v4
    s.muli       s14, s2, #6
    s.addi       s16, s8, #6
    s.movz       s17, #7
    v.splat      v3, s16
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a0, s18
    s.add        s12, s14, s10
    v.cmp.lt     p1, v3, v5
    vf.mul       v3, v2, v0
    s.add        s14, s12, s4
    p.and        p3, p1, p2
    s.add        s12, s7, s14
    s.muli       s14, s2, #7
    vf.cvt.f32.bf16 v2, v3
    s.addi       s16, s8, #7
    s.movz       s18, #8
    v.splat      v3, s16
    s.add        s16, s14, s10
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a0, s17
    s.add        s12, s16, s4
    v.cmp.lt     p1, v3, v5
    vf.mul       v3, v2, v0
    s.add        s14, s7, s12
    p.and        p3, p1, p2
    s.muli       s12, s2, #8
    s.addi       s16, s8, #8
    vf.cvt.f32.bf16 v2, v3
    v.splat      v3, s16
    s.movz       s16, #9
    s.add        s17, s12, s10
    v.cmp.lt     p1, v3, v5
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s18
    s.add        s12, s17, s4
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.add        s14, s7, s12
    s.muli       s12, s2, #9
    s.addi       s17, s8, #9
    s.movz       s18, #10
    vf.cvt.f32.bf16 v2, v3
    v.splat      v3, s17
    s.add        s17, s12, s10
    s.muli       s12, s2, #10
    s.add        s20, s17, s4
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s16
    v.cmp.lt     p1, v3, v5
    s.add        s14, s7, s20
    vf.mul       v3, v2, v0
    p.and        p3, p1, p2
    s.addi       s16, s8, #10
    s.add        s17, s12, s10
    v.splat      v2, s16
    vf.cvt.f32.bf16 v4, v3
    s.add        s12, s17, s4
    v.cmp.lt     p1, v2, v5
    s.add        s16, s7, s12
    p.and        p4, p1, p2
    @p3 v.st.h       [s14, #0], v4
    a.vread      v2, a0, s18
    s.movz       s12, #11
    s.muli       s14, s2, #11
    vf.mul       v3, v2, v0
    s.addi       s17, s8, #11
    s.movz       s18, #12
    v.splat      v2, s17
    s.add        s17, s14, s10
    vf.cvt.f32.bf16 v4, v3
    s.add        s14, s17, s4
    v.cmp.lt     p1, v2, v5
    s.add        s17, s7, s14
    p.and        p3, p1, p2
    @p4 v.st.h       [s16, #0], v4
    a.vread      v2, a0, s12
    s.muli       s12, s2, #12
    s.addi       s14, s8, #12
    vf.mul       v3, v2, v0
    v.splat      v2, s14
    s.movz       s14, #13
    s.add        s16, s12, s10
    v.cmp.lt     p1, v2, v5
    vf.cvt.f32.bf16 v2, v3
    s.add        s12, s16, s4
    p.and        p4, p1, p2
    s.add        s16, s7, s12
    s.muli       s12, s2, #13
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a0, s18
    s.addi       s17, s8, #13
    s.movz       s18, #14
    vf.mul       v3, v2, v0
    s.add        s20, s12, s10
    v.splat      v2, s17
    s.add        s12, s20, s4
    s.muli       s17, s2, #14
    vf.cvt.f32.bf16 v4, v3
    v.cmp.lt     p1, v2, v5
    s.add        s20, s7, s12
    p.and        p3, p1, p2
    s.addi       s12, s8, #14
    @p4 v.st.h       [s16, #0], v4
    a.vread      v2, a0, s14
    s.add        s14, s17, s10
    v.splat      v3, s12
    vf.mul       v4, v2, v0
    s.add        s12, s14, s4
    v.cmp.lt     p1, v3, v5
    s.add        s14, s7, s12
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v4
    s.movz       s12, #15
    s.muli       s16, s2, #15
    s.addi       s17, s8, #15
    s.movz       s21, #0
    @p3 v.st.h       [s20, #0], v2
    a.vread      v2, a0, s18
    s.add        s18, s16, s10
    v.splat      v3, s17
    vf.mul       v4, v2, v0
    s.add        s16, s18, s4
    v.cmp.lt     p1, v3, v5
    s.add        s4, s7, s16
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v4
    s.movz       s16, #0
    s.movz       s17, #0
    s.add        s18, s16, s5                    // the tile origin
    s.muli       s16, s5, #2
    @p4 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s12
    v.splat      v3, s18
    s.add        s5, s17, s3                     // the tile origin
    vf.mul       v4, v2, v0
    v.splat      v2, s8
    v.add        v6, v1, v3
    v.splat      v3, s5
    s.add        s5, s10, s16
    vf.cvt.f32.bf16 v7, v4
    v.cmp.lt     p1, v2, v5
    v.cmp.lt     p2, v6, v3
    s.add        s12, s7, s5
    p.and        p4, p1, p2
    @p3 v.st.h       [s4, #0], v7
    a.vread      v2, a1, s21
    s.movz       s4, #1
    s.muli       s5, s2, #1
    vf.mul       v3, v2, v0
    s.addi       s14, s8, #1
    s.movz       s17, #2
    v.splat      v2, s14
    s.add        s14, s5, s10
    vf.cvt.f32.bf16 v4, v3
    s.add        s5, s14, s16
    v.cmp.lt     p1, v2, v5
    s.add        s14, s7, s5
    p.and        p3, p1, p2
    @p4 v.st.h       [s12, #0], v4
    a.vread      v2, a1, s4
    s.muli       s4, s2, #2
    s.addi       s5, s8, #2
    vf.mul       v3, v2, v0
    v.splat      v2, s5
    s.movz       s5, #3
    s.add        s12, s4, s10
    v.cmp.lt     p1, v2, v5
    vf.cvt.f32.bf16 v2, v3
    s.add        s4, s12, s16
    p.and        p4, p1, p2
    s.add        s12, s7, s4
    s.muli       s4, s2, #3
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a1, s17
    s.addi       s14, s8, #3
    s.movz       s17, #4
    vf.mul       v3, v2, v0
    s.add        s18, s4, s10
    v.splat      v2, s14
    s.add        s4, s18, s16
    s.muli       s14, s2, #4
    vf.cvt.f32.bf16 v4, v3
    v.cmp.lt     p1, v2, v5
    s.add        s18, s7, s4
    p.and        p3, p1, p2
    s.addi       s4, s8, #4
    @p4 v.st.h       [s12, #0], v4
    a.vread      v2, a1, s5
    s.add        s5, s14, s10
    v.splat      v3, s4
    vf.mul       v4, v2, v0
    s.add        s4, s5, s16
    v.cmp.lt     p1, v3, v5
    s.add        s5, s7, s4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v4
    s.movz       s4, #5
    s.muli       s12, s2, #5
    s.addi       s14, s8, #5
    s.movz       s20, #6
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a1, s17
    s.add        s17, s12, s10
    v.splat      v3, s14
    vf.mul       v4, v2, v0
    s.add        s12, s17, s16
    v.cmp.lt     p1, v3, v5
    s.add        s14, s7, s12
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v4
    s.muli       s12, s2, #6
    s.addi       s17, s8, #6
    s.movz       s18, #7
    v.splat      v3, s17
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a1, s4
    s.add        s4, s12, s10
    v.cmp.lt     p1, v3, v5
    vf.mul       v3, v2, v0
    s.add        s5, s4, s16
    p.and        p4, p1, p2
    s.add        s4, s7, s5
    s.muli       s5, s2, #7
    vf.cvt.f32.bf16 v2, v3
    s.addi       s12, s8, #7
    s.movz       s17, #8
    v.splat      v3, s12
    s.add        s12, s5, s10
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a1, s20
    s.add        s5, s12, s16
    v.cmp.lt     p1, v3, v5
    vf.mul       v3, v2, v0
    s.add        s12, s7, s5
    p.and        p3, p1, p2
    s.muli       s5, s2, #8
    s.addi       s14, s8, #8
    vf.cvt.f32.bf16 v2, v3
    v.splat      v3, s14
    s.movz       s14, #9
    s.add        s20, s5, s10
    s.muli       s5, s2, #9
    @p4 v.st.h       [s4, #0], v2
    a.vread      v2, a1, s18
    s.add        s4, s20, s16
    v.cmp.lt     p1, v3, v5
    vf.mul       v3, v2, v0
    s.add        s18, s7, s4
    p.and        p4, p1, p2
    s.addi       s4, s8, #9
    s.add        s20, s5, s10
    vf.cvt.f32.bf16 v2, v3
    v.splat      v3, s4
    s.add        s4, s20, s16
    s.movz       s5, #10
    s.add        s20, s7, s4
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a1, s17
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.muli       s4, s2, #10
    s.addi       s12, s8, #10
    s.movz       s17, #11
    v.splat      v2, s12
    vf.cvt.f32.bf16 v4, v3
    s.add        s12, s4, s10
    s.muli       s4, s2, #11
    s.add        s21, s12, s16
    s.addi       s12, s8, #11
    @p4 v.st.h       [s18, #0], v4
    a.vread      v3, a1, s14
    v.cmp.lt     p1, v2, v5
    s.add        s14, s7, s21
    vf.mul       v2, v3, v0
    p.and        p4, p1, p2
    s.add        s18, s4, s10
    v.splat      v3, s12
    s.add        s4, s18, s16
    vf.cvt.f32.bf16 v4, v2
    s.add        s12, s7, s4
    s.movz       s4, #12
    s.muli       s18, s2, #12
    s.addi       s21, s8, #12
    @p3 v.st.h       [s20, #0], v4
    a.vread      v2, a1, s5
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.add        s5, s18, s10
    v.splat      v2, s21
    s.add        s18, s5, s16
    s.movz       s5, #13
    vf.cvt.f32.bf16 v4, v3
    s.add        s20, s7, s18
    s.muli       s18, s2, #13
    s.addi       s21, s8, #13
    s.movz       s22, #14
    @p4 v.st.h       [s14, #0], v4
    a.vread      v3, a1, s17
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    s.add        s14, s18, s10
    v.splat      v3, s21
    s.add        s17, s14, s16
    s.muli       s14, s2, #14
    vf.cvt.f32.bf16 v4, v2
    s.add        s18, s7, s17
    s.addi       s17, s8, #14
    s.movz       s21, #15
    s.add        s23, s14, s10
    @p3 v.st.h       [s12, #0], v4
    a.vread      v2, a1, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    v.splat      v2, s17
    s.add        s4, s23, s16
    s.muli       s12, s2, #15
    s.add        s14, s7, s4
    vf.cvt.f32.bf16 v4, v3
    s.addi       s4, s8, #15
    s.movz       s17, #0
    s.add        s23, s12, s10
    v.splat      v3, s4
    @p4 v.st.h       [s20, #0], v4
    a.vread      v4, a1, s5
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s23, s16
    s.movz       s5, #0
    s.add        s12, s7, s4
    s.add        s4, s5, s6                      // the tile origin
    vf.cvt.f32.bf16 v4, v2
    s.movz       s5, #0
    s.muli       s16, s6, #2
    v.splat      v2, s4
    s.add        s4, s5, s3                      // the tile origin
    @p3 v.st.h       [s18, #0], v4
    a.vread      v4, a1, s22
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    v.splat      v4, s8
    v.add        v6, v1, v2
    v.splat      v2, s4
    s.add        s4, s10, s16
    vf.cvt.f32.bf16 v7, v3
    v.cmp.lt     p1, v4, v5
    s.add        s5, s7, s4
    s.movz       s4, #1
    s.muli       s6, s2, #1
    @p4 v.st.h       [s14, #0], v7
    a.vread      v3, a1, s21
    v.cmp.lt     p2, v6, v2
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    s.addi       s14, s8, #1
    s.add        s18, s6, s10
    v.splat      v3, s14
    s.add        s6, s18, s16
    vf.cvt.f32.bf16 v4, v2
    s.add        s14, s7, s6
    s.movz       s6, #2
    s.muli       s18, s2, #2
    s.addi       s20, s8, #2
    @p3 v.st.h       [s12, #0], v4
    a.vread      v2, a2, s17
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.add        s12, s18, s10
    v.splat      v2, s20
    s.add        s17, s12, s16
    s.movz       s12, #3
    vf.cvt.f32.bf16 v4, v3
    s.add        s18, s7, s17
    s.muli       s17, s2, #3
    s.addi       s20, s8, #3
    s.movz       s21, #4
    @p4 v.st.h       [s5, #0], v4
    a.vread      v3, a2, s4
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    s.add        s4, s17, s10
    v.splat      v3, s20
    s.add        s5, s4, s16
    s.muli       s4, s2, #4
    vf.cvt.f32.bf16 v4, v2
    s.add        s17, s7, s5
    s.addi       s5, s8, #4
    s.movz       s20, #5
    s.add        s22, s4, s10
    @p3 v.st.h       [s14, #0], v4
    a.vread      v2, a2, s6
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    v.splat      v2, s5
    s.add        s4, s22, s16
    s.muli       s5, s2, #5
    s.add        s6, s7, s4
    vf.cvt.f32.bf16 v4, v3
    s.addi       s4, s8, #5
    s.movz       s14, #6
    s.add        s22, s5, s10
    v.splat      v3, s4
    @p4 v.st.h       [s18, #0], v4
    a.vread      v4, a2, s12
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s22, s16
    s.muli       s5, s2, #6
    s.add        s12, s7, s4
    s.addi       s4, s8, #6
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s4
    s.add        s4, s5, s10
    s.movz       s5, #7
    s.add        s18, s4, s16
    @p3 v.st.h       [s17, #0], v4
    a.vread      v4, a2, s21
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s4, s7, s18
    s.muli       s17, s2, #7
    s.addi       s18, s8, #7
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s18
    s.add        s18, s17, s10
    s.movz       s17, #8
    s.add        s21, s18, s16
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a2, s20
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s6, s7, s21
    s.muli       s18, s2, #8
    s.addi       s20, s8, #8
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s20
    s.add        s20, s18, s10
    s.movz       s18, #9
    s.add        s21, s20, s16
    @p3 v.st.h       [s12, #0], v4
    a.vread      v4, a2, s14
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s12, s7, s21
    s.muli       s14, s2, #9
    s.addi       s20, s8, #9
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s20
    s.add        s20, s14, s10
    s.movz       s14, #10
    s.add        s21, s20, s16
    @p4 v.st.h       [s4, #0], v4
    a.vread      v4, a2, s5
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s7, s21
    s.muli       s5, s2, #10
    s.addi       s20, s8, #10
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s20
    s.add        s20, s5, s10
    s.movz       s5, #11
    s.add        s21, s20, s16
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a2, s17
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s6, s7, s21
    s.muli       s17, s2, #11
    s.addi       s20, s8, #11
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s20
    s.add        s20, s17, s10
    s.movz       s17, #12
    s.add        s21, s20, s16
    @p4 v.st.h       [s12, #0], v4
    a.vread      v4, a2, s18
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s12, s7, s21
    s.muli       s18, s2, #12
    s.addi       s20, s8, #12
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s20
    s.add        s20, s18, s10
    s.movz       s18, #13
    s.add        s21, s20, s16
    @p3 v.st.h       [s4, #0], v4
    a.vread      v4, a2, s14
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s4, s7, s21
    s.muli       s14, s2, #13
    s.addi       s20, s8, #13
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s20
    s.add        s20, s14, s10
    s.movz       s14, #14
    s.add        s21, s20, s16
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a2, s5
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s21
    s.muli       s6, s2, #14
    s.addi       s20, s8, #14
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s20
    s.add        s20, s6, s10
    s.movz       s6, #15
    s.add        s21, s20, s16
    @p3 v.st.h       [s12, #0], v4
    a.vread      v4, a2, s17
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s12, s7, s21
    s.muli       s17, s2, #15
    s.addi       s20, s8, #15
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s20
    s.add        s20, s17, s10
    s.movz       s17, #0
    s.add        s21, s20, s16
    @p4 v.st.h       [s4, #0], v4
    a.vread      v4, a2, s18
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s7, s21
    s.movz       s16, #0
    s.muli       s18, s1, #2
    s.add        s20, s16, s1                    // the tile origin
    vf.cvt.f32.bf16 v4, v2
    s.movz       s1, #0
    v.splat      v2, s20
    s.add        s16, s1, s3                     // the tile origin
    v.splat      v6, s8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a2, s14
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    v.add        v4, v1, v2
    v.splat      v2, s16
    s.add        s1, s10, s18
    v.cmp.lt     p1, v6, v5
    vf.cvt.f32.bf16 v6, v3
    s.add        s5, s7, s1
    s.movz       s1, #1
    s.muli       s14, s2, #1
    s.addi       s16, s8, #1
    @p4 v.st.h       [s12, #0], v6
    a.vread      v3, a2, s6
    v.cmp.lt     p2, v4, v2
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    s.add        s6, s14, s10
    v.splat      v3, s16
    s.add        s12, s6, s18
    s.movz       s6, #2
    vf.cvt.f32.bf16 v4, v2
    s.add        s14, s7, s12
    s.muli       s12, s2, #2
    s.addi       s16, s8, #2
    s.movz       s20, #3
    @p3 v.st.h       [s4, #0], v4
    a.vread      v2, a3, s17
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.add        s4, s12, s10
    v.splat      v2, s16
    s.add        s12, s4, s18
    s.muli       s4, s2, #3
    vf.cvt.f32.bf16 v4, v3
    s.add        s16, s7, s12
    s.addi       s12, s8, #3
    s.movz       s17, #4
    s.add        s21, s4, s10
    @p4 v.st.h       [s5, #0], v4
    a.vread      v3, a3, s1
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    v.splat      v3, s12
    s.add        s1, s21, s18
    s.muli       s4, s2, #4
    s.add        s5, s7, s1
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s8, #4
    s.movz       s12, #5
    s.add        s21, s4, s10
    v.splat      v2, s1
    @p3 v.st.h       [s14, #0], v4
    a.vread      v4, a3, s6
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s21, s18
    s.muli       s4, s2, #5
    s.add        s6, s7, s1
    s.addi       s1, s8, #5
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s1
    s.add        s1, s4, s10
    s.movz       s4, #6
    s.add        s14, s1, s18
    @p4 v.st.h       [s16, #0], v4
    a.vread      v4, a3, s20
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s14
    s.muli       s14, s2, #6
    s.addi       s16, s8, #6
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s16
    s.add        s16, s14, s10
    s.movz       s14, #7
    s.add        s20, s16, s18
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a3, s17
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s5, s7, s20
    s.muli       s16, s2, #7
    s.addi       s17, s8, #7
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s17
    s.add        s17, s16, s10
    s.movz       s16, #8
    s.add        s20, s17, s18
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a3, s12
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s6, s7, s20
    s.muli       s12, s2, #8
    s.addi       s17, s8, #8
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s17
    s.add        s17, s12, s10
    s.movz       s12, #9
    s.add        s20, s17, s18
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a3, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s20
    s.muli       s4, s2, #9
    s.addi       s17, s8, #9
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s17
    s.add        s17, s4, s10
    s.movz       s4, #10
    s.add        s20, s17, s18
    @p4 v.st.h       [s5, #0], v4
    a.vread      v4, a3, s14
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s20
    s.muli       s14, s2, #10
    s.addi       s17, s8, #10
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s17
    s.add        s17, s14, s10
    s.movz       s14, #11
    s.add        s20, s17, s18
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a3, s16
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s6, s7, s20
    s.muli       s16, s2, #11
    s.addi       s17, s8, #11
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s17
    s.add        s17, s16, s10
    s.movz       s16, #12
    s.add        s20, s17, s18
    @p4 v.st.h       [s1, #0], v4
    a.vread      v4, a3, s12
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s20
    s.muli       s12, s2, #12
    s.addi       s17, s8, #12
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s17
    s.add        s17, s12, s10
    s.movz       s12, #13
    s.add        s20, s17, s18
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a3, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s4, s7, s20
    s.muli       s5, s2, #13
    s.addi       s17, s8, #13
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s17
    s.add        s17, s5, s10
    s.movz       s5, #14
    s.add        s20, s17, s18
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a3, s14
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s6, s7, s20
    s.muli       s14, s2, #14
    s.addi       s17, s8, #14
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s17
    s.add        s17, s14, s10
    s.movz       s14, #15
    s.add        s20, s17, s18
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a3, s16
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s20
    s.muli       s16, s2, #15
    s.addi       s17, s8, #15
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s17
    s.add        s17, s16, s10
    s.movz       s16, #0
    s.add        s20, s17, s18
    @p4 v.st.h       [s4, #0], v4
    a.vread      v4, a3, s12
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s7, s20
    s.movz       s12, #0
    s.muli       s17, s9, #2
    s.add        s18, s12, s9                    // the tile origin
    vf.cvt.f32.bf16 v4, v2
    s.movz       s9, #0
    v.splat      v2, s18
    s.add        s12, s9, s3                     // the tile origin
    v.splat      v6, s8
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a3, s5
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    v.add        v4, v1, v2
    v.splat      v2, s12
    s.add        s5, s10, s17
    v.cmp.lt     p1, v6, v5
    vf.cvt.f32.bf16 v6, v3
    s.add        s6, s7, s5
    s.movz       s5, #1
    s.muli       s9, s2, #1
    s.addi       s12, s8, #1
    @p4 v.st.h       [s1, #0], v6
    a.vread      v3, a3, s14
    v.cmp.lt     p2, v4, v2
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    s.add        s1, s9, s10
    v.splat      v3, s12
    s.add        s9, s1, s17
    s.movz       s1, #2
    vf.cvt.f32.bf16 v4, v2
    s.add        s12, s7, s9
    s.muli       s9, s2, #2
    s.addi       s14, s8, #2
    s.movz       s18, #3
    @p3 v.st.h       [s4, #0], v4
    a.vread      v2, a4, s16
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.add        s4, s9, s10
    v.splat      v2, s14
    s.add        s9, s4, s17
    s.muli       s4, s2, #3
    vf.cvt.f32.bf16 v4, v3
    s.add        s14, s7, s9
    s.addi       s9, s8, #3
    s.movz       s16, #4
    s.add        s20, s4, s10
    @p4 v.st.h       [s6, #0], v4
    a.vread      v3, a4, s5
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    v.splat      v3, s9
    s.add        s4, s20, s17
    s.muli       s5, s2, #4
    s.add        s6, s7, s4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s4, s8, #4
    s.movz       s9, #5
    s.add        s20, s5, s10
    v.splat      v2, s4
    @p3 v.st.h       [s12, #0], v4
    a.vread      v4, a4, s1
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s20, s17
    s.muli       s4, s2, #5
    s.add        s5, s7, s1
    s.addi       s1, s8, #5
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s1
    s.add        s1, s4, s10
    s.movz       s4, #6
    s.add        s12, s1, s17
    @p4 v.st.h       [s14, #0], v4
    a.vread      v4, a4, s18
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s12
    s.muli       s12, s2, #6
    s.addi       s14, s8, #6
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s14
    s.add        s14, s12, s10
    s.movz       s12, #7
    s.add        s18, s14, s17
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a4, s16
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s6, s7, s18
    s.muli       s14, s2, #7
    s.addi       s16, s8, #7
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s16
    s.add        s16, s14, s10
    s.movz       s14, #8
    s.add        s18, s16, s17
    @p4 v.st.h       [s5, #0], v4
    a.vread      v4, a4, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s18
    s.muli       s9, s2, #8
    s.addi       s16, s8, #8
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s16
    s.add        s16, s9, s10
    s.movz       s9, #9
    s.add        s18, s16, s17
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a4, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s18
    s.muli       s4, s2, #9
    s.addi       s16, s8, #9
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s16
    s.add        s16, s4, s10
    s.movz       s4, #10
    s.add        s18, s16, s17
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a4, s12
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s6, s7, s18
    s.muli       s12, s2, #10
    s.addi       s16, s8, #10
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s16
    s.add        s16, s12, s10
    s.movz       s12, #11
    s.add        s18, s16, s17
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a4, s14
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s5, s7, s18
    s.muli       s14, s2, #11
    s.addi       s16, s8, #11
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s16
    s.add        s16, s14, s10
    s.movz       s14, #12
    s.add        s18, s16, s17
    @p4 v.st.h       [s1, #0], v4
    a.vread      v4, a4, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s18
    s.muli       s9, s2, #12
    s.addi       s16, s8, #12
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s16
    s.add        s16, s9, s10
    s.movz       s9, #13
    s.add        s18, s16, s17
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a4, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s4, s7, s18
    s.muli       s6, s2, #13
    s.addi       s16, s8, #13
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s16
    s.add        s16, s6, s10
    s.movz       s6, #14
    s.add        s18, s16, s17
    @p4 v.st.h       [s5, #0], v4
    a.vread      v4, a4, s12
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s18
    s.muli       s12, s2, #14
    s.addi       s16, s8, #14
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s16
    s.add        s16, s12, s10
    s.movz       s12, #15
    s.add        s18, s16, s17
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a4, s14
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s18
    s.muli       s14, s2, #15
    s.addi       s16, s8, #15
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s16
    s.add        s16, s14, s10
    s.movz       s14, #0
    s.add        s18, s16, s17
    @p4 v.st.h       [s4, #0], v4
    a.vread      v4, a4, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s7, s18
    s.movz       s9, #0
    s.muli       s16, s11, #2
    s.add        s17, s9, s11                    // the tile origin
    vf.cvt.f32.bf16 v4, v2
    s.movz       s9, #0
    v.splat      v2, s17
    s.add        s11, s9, s3                     // the tile origin
    v.splat      v6, s8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a4, s6
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    v.add        v4, v1, v2
    v.splat      v2, s11
    s.add        s5, s10, s16
    v.cmp.lt     p1, v6, v5
    vf.cvt.f32.bf16 v6, v3
    s.add        s6, s7, s5
    s.movz       s5, #1
    s.muli       s9, s2, #1
    s.addi       s11, s8, #1
    @p4 v.st.h       [s1, #0], v6
    a.vread      v3, a4, s12
    v.cmp.lt     p2, v4, v2
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    s.add        s1, s9, s10
    v.splat      v3, s11
    s.add        s9, s1, s16
    s.movz       s1, #2
    vf.cvt.f32.bf16 v4, v2
    s.add        s11, s7, s9
    s.muli       s9, s2, #2
    s.addi       s12, s8, #2
    s.movz       s17, #3
    @p3 v.st.h       [s4, #0], v4
    a.vread      v2, a5, s14
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.add        s4, s9, s10
    v.splat      v2, s12
    s.add        s9, s4, s16
    s.muli       s4, s2, #3
    vf.cvt.f32.bf16 v4, v3
    s.add        s12, s7, s9
    s.addi       s9, s8, #3
    s.movz       s14, #4
    s.add        s18, s4, s10
    @p4 v.st.h       [s6, #0], v4
    a.vread      v3, a5, s5
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    v.splat      v3, s9
    s.add        s4, s18, s16
    s.muli       s5, s2, #4
    s.add        s6, s7, s4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s4, s8, #4
    s.movz       s9, #5
    s.add        s18, s5, s10
    v.splat      v2, s4
    @p3 v.st.h       [s11, #0], v4
    a.vread      v4, a5, s1
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s18, s16
    s.muli       s4, s2, #5
    s.add        s5, s7, s1
    s.addi       s1, s8, #5
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s1
    s.add        s1, s4, s10
    s.movz       s4, #6
    s.add        s11, s1, s16
    @p4 v.st.h       [s12, #0], v4
    a.vread      v4, a5, s17
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s11
    s.muli       s11, s2, #6
    s.addi       s12, s8, #6
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s12
    s.add        s12, s11, s10
    s.movz       s11, #7
    s.add        s17, s12, s16
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a5, s14
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s6, s7, s17
    s.muli       s12, s2, #7
    s.addi       s14, s8, #7
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s14
    s.add        s14, s12, s10
    s.movz       s12, #8
    s.add        s17, s14, s16
    @p4 v.st.h       [s5, #0], v4
    a.vread      v4, a5, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s17
    s.muli       s9, s2, #8
    s.addi       s14, s8, #8
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s14
    s.add        s14, s9, s10
    s.movz       s9, #9
    s.add        s17, s14, s16
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a5, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s17
    s.muli       s4, s2, #9
    s.addi       s14, s8, #9
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s14
    s.add        s14, s4, s10
    s.movz       s4, #10
    s.add        s17, s14, s16
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a5, s11
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s6, s7, s17
    s.muli       s11, s2, #10
    s.addi       s14, s8, #10
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s14
    s.add        s14, s11, s10
    s.movz       s11, #11
    s.add        s17, s14, s16
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a5, s12
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s5, s7, s17
    s.muli       s12, s2, #11
    s.addi       s14, s8, #11
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s14
    s.add        s14, s12, s10
    s.movz       s12, #12
    s.add        s17, s14, s16
    @p4 v.st.h       [s1, #0], v4
    a.vread      v4, a5, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s17
    s.muli       s9, s2, #12
    s.addi       s14, s8, #12
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s14
    s.add        s14, s9, s10
    s.movz       s9, #13
    s.add        s17, s14, s16
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a5, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s4, s7, s17
    s.muli       s6, s2, #13
    s.addi       s14, s8, #13
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s14
    s.add        s14, s6, s10
    s.movz       s6, #14
    s.add        s17, s14, s16
    @p4 v.st.h       [s5, #0], v4
    a.vread      v4, a5, s11
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s17
    s.muli       s11, s2, #14
    s.addi       s14, s8, #14
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s14
    s.add        s14, s11, s10
    s.movz       s11, #15
    s.add        s17, s14, s16
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a5, s12
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s17
    s.muli       s12, s2, #15
    s.addi       s14, s8, #15
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s14
    s.add        s14, s12, s10
    s.movz       s12, #0
    s.add        s17, s14, s16
    @p4 v.st.h       [s4, #0], v4
    a.vread      v4, a5, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s7, s17
    s.movz       s9, #0
    s.muli       s14, s13, #2
    s.add        s16, s9, s13                    // the tile origin
    vf.cvt.f32.bf16 v4, v2
    s.movz       s9, #0
    v.splat      v2, s16
    s.add        s13, s9, s3                     // the tile origin
    v.splat      v6, s8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a5, s6
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    v.add        v4, v1, v2
    v.splat      v2, s13
    s.add        s5, s10, s14
    v.cmp.lt     p1, v6, v5
    vf.cvt.f32.bf16 v6, v3
    s.add        s6, s7, s5
    s.movz       s5, #1
    s.muli       s9, s2, #1
    s.addi       s13, s8, #1
    @p4 v.st.h       [s1, #0], v6
    a.vread      v3, a5, s11
    v.cmp.lt     p2, v4, v2
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    s.add        s1, s9, s10
    v.splat      v3, s13
    s.add        s9, s1, s14
    s.movz       s1, #2
    vf.cvt.f32.bf16 v4, v2
    s.add        s11, s7, s9
    s.muli       s9, s2, #2
    s.addi       s13, s8, #2
    s.movz       s16, #3
    @p3 v.st.h       [s4, #0], v4
    a.vread      v2, a6, s12
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v2, v0
    s.add        s4, s9, s10
    v.splat      v2, s13
    s.add        s9, s4, s14
    s.muli       s4, s2, #3
    vf.cvt.f32.bf16 v4, v3
    s.add        s12, s7, s9
    s.addi       s9, s8, #3
    s.movz       s13, #4
    s.add        s17, s4, s10
    @p4 v.st.h       [s6, #0], v4
    a.vread      v3, a6, s5
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v3, v0
    v.splat      v3, s9
    s.add        s4, s17, s14
    s.muli       s5, s2, #4
    s.add        s6, s7, s4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s4, s8, #4
    s.movz       s9, #5
    s.add        s17, s5, s10
    v.splat      v2, s4
    @p3 v.st.h       [s11, #0], v4
    a.vread      v4, a6, s1
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s17, s14
    s.muli       s4, s2, #5
    s.add        s5, s7, s1
    s.addi       s1, s8, #5
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s1
    s.add        s1, s4, s10
    s.movz       s4, #6
    s.add        s11, s1, s14
    @p4 v.st.h       [s12, #0], v4
    a.vread      v4, a6, s16
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s11
    s.muli       s11, s2, #6
    s.addi       s12, s8, #6
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s12
    s.add        s12, s11, s10
    s.movz       s11, #7
    s.add        s16, s12, s14
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a6, s13
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s6, s7, s16
    s.muli       s12, s2, #7
    s.addi       s13, s8, #7
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s13
    s.add        s13, s12, s10
    s.movz       s12, #8
    s.add        s16, s13, s14
    @p4 v.st.h       [s5, #0], v4
    a.vread      v4, a6, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s16
    s.muli       s9, s2, #8
    s.addi       s13, s8, #8
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s13
    s.add        s13, s9, s10
    s.movz       s9, #9
    s.add        s16, s13, s14
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a6, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s16
    s.muli       s4, s2, #9
    s.addi       s13, s8, #9
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s13
    s.add        s13, s4, s10
    s.movz       s4, #10
    s.add        s16, s13, s14
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a6, s11
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s6, s7, s16
    s.muli       s11, s2, #10
    s.addi       s13, s8, #10
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s13
    s.add        s13, s11, s10
    s.movz       s11, #11
    s.add        s16, s13, s14
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a6, s12
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s5, s7, s16
    s.muli       s12, s2, #11
    s.addi       s13, s8, #11
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s13
    s.add        s13, s12, s10
    s.movz       s12, #12
    s.add        s16, s13, s14
    @p4 v.st.h       [s1, #0], v4
    a.vread      v4, a6, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s1, s7, s16
    s.muli       s9, s2, #12
    s.addi       s13, s8, #12
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s13
    s.add        s13, s9, s10
    s.movz       s9, #13
    s.add        s16, s13, s14
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a6, s4
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s4, s7, s16
    s.muli       s6, s2, #13
    s.addi       s13, s8, #13
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s13
    s.add        s13, s6, s10
    s.movz       s6, #14
    s.add        s16, s13, s14
    @p4 v.st.h       [s5, #0], v4
    a.vread      v4, a6, s11
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s5, s7, s16
    s.muli       s11, s2, #14
    s.addi       s13, s8, #14
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s13
    s.add        s13, s11, s10
    s.movz       s11, #15
    s.add        s16, s13, s14
    @p3 v.st.h       [s1, #0], v4
    a.vread      v4, a6, s12
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    s.add        s1, s7, s16
    s.muli       s12, s2, #15
    s.addi       s13, s8, #15
    vf.cvt.f32.bf16 v4, v3
    v.splat      v3, s13
    s.add        s13, s12, s10
    s.movz       s12, #0
    s.add        s16, s13, s14
    @p4 v.st.h       [s4, #0], v4
    a.vread      v4, a6, s9
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v0
    s.add        s4, s7, s16
    s.movz       s9, #0
    s.muli       s13, s15, #2
    s.add        s14, s9, s15                    // the tile origin
    vf.cvt.f32.bf16 v4, v2
    s.movz       s9, #0
    v.splat      v2, s14
    s.add        s14, s9, s3                     // the tile origin
    v.splat      v6, s8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a6, s6
    v.cmp.lt     p1, v3, v5
    p.and        p3, p1, p2
    vf.mul       v3, v4, v0
    v.add        v4, v1, v2
    v.splat      v1, s14
    s.add        s3, s10, s13
    v.cmp.lt     p1, v6, v5
    vf.cvt.f32.bf16 v2, v3
    s.add        s5, s7, s3
    s.movz       s3, #1
    s.muli       s6, s2, #1
    s.addi       s9, s8, #1
    @p4 v.st.h       [s1, #0], v2
    a.vread      v2, a6, s11
    v.cmp.lt     p2, v4, v1
    p.and        p4, p1, p2
    vf.mul       v1, v2, v0
    s.add        s1, s6, s10
    v.splat      v2, s9
    s.add        s6, s1, s13
    s.movz       s1, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s9, s7, s6
    s.muli       s6, s2, #2
    s.addi       s11, s8, #2
    s.movz       s14, #3
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s12
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v1, v0
    s.add        s4, s6, s10
    v.splat      v1, s11
    s.add        s6, s4, s13
    s.muli       s4, s2, #3
    vf.cvt.f32.bf16 v3, v2
    s.add        s11, s7, s6
    s.addi       s6, s8, #3
    s.movz       s12, #4
    s.add        s15, s4, s10
    @p4 v.st.h       [s5, #0], v3
    a.vread      v2, a7, s3
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.mul       v1, v2, v0
    v.splat      v2, s6
    s.add        s3, s15, s13
    s.muli       s4, s2, #4
    s.add        s5, s7, s3
    vf.cvt.f32.bf16 v3, v1
    s.addi       s3, s8, #4
    s.movz       s6, #5
    s.add        s15, s4, s10
    v.splat      v1, s3
    @p3 v.st.h       [s9, #0], v3
    a.vread      v3, a7, s1
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v3, v0
    s.add        s1, s15, s13
    s.muli       s3, s2, #5
    s.add        s4, s7, s1
    s.addi       s1, s8, #5
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s1
    s.add        s1, s3, s10
    s.movz       s3, #6
    s.add        s9, s1, s13
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a7, s14
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.mul       v1, v3, v0
    s.add        s1, s7, s9
    s.muli       s9, s2, #6
    s.addi       s11, s8, #6
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s11
    s.add        s11, s9, s10
    s.movz       s9, #7
    s.add        s14, s11, s13
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a7, s12
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v3, v0
    s.add        s5, s7, s14
    s.muli       s11, s2, #7
    s.addi       s12, s8, #7
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s12
    s.add        s12, s11, s10
    s.movz       s11, #8
    s.add        s14, s12, s13
    @p4 v.st.h       [s4, #0], v3
    a.vread      v3, a7, s6
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.mul       v1, v3, v0
    s.add        s4, s7, s14
    s.muli       s6, s2, #8
    s.addi       s12, s8, #8
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    s.add        s12, s6, s10
    s.movz       s6, #9
    s.add        s14, s12, s13
    @p3 v.st.h       [s1, #0], v3
    a.vread      v3, a7, s3
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v3, v0
    s.add        s1, s7, s14
    s.muli       s3, s2, #9
    s.addi       s12, s8, #9
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s12
    s.add        s12, s3, s10
    s.movz       s3, #10
    s.add        s14, s12, s13
    @p4 v.st.h       [s5, #0], v3
    a.vread      v3, a7, s9
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.mul       v1, v3, v0
    s.add        s5, s7, s14
    s.muli       s9, s2, #10
    s.addi       s12, s8, #10
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    s.add        s12, s9, s10
    s.movz       s9, #11
    s.add        s14, s12, s13
    @p3 v.st.h       [s4, #0], v3
    a.vread      v3, a7, s11
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v3, v0
    s.add        s4, s7, s14
    s.muli       s11, s2, #11
    s.addi       s12, s8, #11
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s12
    s.add        s12, s11, s10
    s.movz       s11, #12
    s.add        s14, s12, s13
    @p4 v.st.h       [s1, #0], v3
    a.vread      v3, a7, s6
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.mul       v1, v3, v0
    s.add        s1, s7, s14
    s.muli       s6, s2, #12
    s.addi       s12, s8, #12
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    s.add        s12, s6, s10
    s.movz       s6, #13
    s.add        s14, s12, s13
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a7, s3
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v3, v0
    s.add        s3, s7, s14
    s.muli       s5, s2, #13
    s.addi       s12, s8, #13
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s12
    s.add        s12, s5, s10
    s.movz       s5, #14
    s.add        s14, s12, s13
    @p4 v.st.h       [s4, #0], v3
    a.vread      v3, a7, s9
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.mul       v1, v3, v0
    s.add        s4, s7, s14
    s.muli       s9, s2, #14
    s.addi       s12, s8, #14
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    s.add        s12, s9, s10
    s.movz       s9, #15
    s.add        s14, s12, s13
    @p3 v.st.h       [s1, #0], v3
    a.vread      v3, a7, s11
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v3, v0
    s.add        s1, s7, s14
    s.muli       s11, s2, #15
    s.addi       s2, s8, #15
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s2
    s.add        s2, s11, s10
    s.add        s8, s2, s13
    @p4 v.st.h       [s3, #0], v3
    a.vread      v3, a7, s6
    v.cmp.lt     p1, v1, v5
    p.and        p4, p1, p2
    vf.mul       v1, v3, v0
    s.add        s2, s7, s8
    vf.cvt.f32.bf16 v3, v1
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a7, s5
    v.cmp.lt     p1, v2, v5
    p.and        p3, p1, p2
    vf.mul       v2, v1, v0
    vf.cvt.f32.bf16 v1, v2
    @p4 v.st.h       [s1, #0], v1
    a.vread      v1, a7, s9
    vf.mul       v2, v1, v0
    vf.cvt.f32.bf16 v0, v2
    @p3 v.st.h       [s2, #0], v0
    exit
    exit
