set_param general.maxThreads 2
set source [lindex $argv 0]
set out [lindex $argv 1]
file mkdir $out
open_checkpoint $source
set f [open $out/tmu_state_locations.tsv {WRONLY CREAT EXCL}]
puts $f "replica\tcell\tprimitive\tloc\tsites\tactual_slrs"
set primitives [get_cells -hierarchical -quiet -filter {IS_PRIMITIVE == 1}]
set primitive_names [get_property NAME $primitives]
set primitive_refs [get_property REF_NAME $primitives]
set failures [list]
for {set tile 0} {$tile<3} {incr tile} {
 set prefix [format {tmu/g_replica[%d].local_tmu/} $tile]
 set count 0
 foreach cell $primitives name $primitive_names ref $primitive_refs {
  if {[string first $prefix $name]!=0 || ![regexp {^(FD|RAM|SRL)} $ref]} {continue}
  set sites [get_sites -quiet -of_objects $cell]
  set regions [list]
  if {[llength $sites]} {set regions [get_slrs -quiet -of_objects $sites]}
  set slrs [list]
  if {[llength $regions]} {set slrs [lsort -unique [get_property NAME $regions]]}
  puts $f [join [list $tile $name $ref [get_property LOC $cell] $sites $slrs] "\t"]
  if {$slrs ne [list "SLR$tile"]} {lappend failures [list $name $sites $slrs]}
  incr count
 }
 if {$count<100} {lappend failures "replica$tile insufficient-state:$count"}
 puts "TMU_STATE tile=$tile rows=$count"
}
close $f
set f [open $out/location_failures.txt w]
foreach failure $failures {puts $f $failure}
close $f
set ranks [get_cells -hierarchical -quiet -filter {REF_NAME =~ "FD*" && NAME =~ "*victim_pair_q_reg*"}]
if {![llength $ranks]} {error "expected first-pair-min register boundary"}
set owners [get_cells -hierarchical -quiet -filter {REF_NAME =~ "FD*" && NAME =~ "*victim_owner_q_reg*"}]
set selected [get_cells -hierarchical -quiet -filter {REF_NAME =~ "FD*" && NAME =~ "*selected_way_q_reg*"}]
set f [open $out/registered_boundaries.tsv {WRONLY CREAT EXCL}]
puts $f "kind\tcell\tprimitive\tloc"
foreach {kind cells} [list owner $owners selected_way $selected] {
    foreach cell $cells {puts $f "$kind\t[get_property NAME $cell]\t[get_property REF_NAME $cell]\t[get_property LOC $cell]"}
}
close $f
if {[llength $selected]} {
    report_timing -from $owners -to $selected -max_paths 10 -file $out/owner_to_selected.rpt
    report_timing -from $owners -to $ranks -max_paths 10 -file $out/owner_to_pair.rpt
    report_timing -from $ranks -to $selected -max_paths 10 -file $out/pair_to_selected.rpt
    report_timing -from $selected -max_paths 10 -file $out/selected_output.rpt
}
set f [open $out/tag_mapping.tsv {WRONLY CREAT EXCL}]
puts $f "cell\tprimitive\tis_primitive\tloc"
set tags [get_cells -hierarchical -quiet -filter {NAME =~ "*g_sync_tags*" && NAME =~ "*bank_reg*"}]
foreach name [get_property NAME $tags] ref [get_property REF_NAME $tags] primitive [get_property IS_PRIMITIVE $tags] loc [get_property LOC $tags] {
    puts $f "$name\t$ref\t$primitive\t$loc"
}
close $f

if {[llength $failures]} {error "unresolved or misplaced TMU state: [llength $failures]"}
puts "R4_MAPPING_COMPLETION_PASS"
exit
