"""Run hbm_child.py capacity, reporting who ends the process (diagnostic)."""
import atexit, faulthandler, os, sys, threading, traceback, runpy, time
faulthandler.enable()
t0 = time.time()
def stamp(msg):
    sys.stderr.write(f'[probe {time.time()-t0:8.1f}s] {msg}\n'); sys.stderr.flush()
real_exit, real_os_exit = sys.exit, os._exit
def my_exit(code=0):
    stamp(f'sys.exit({code!r}) from:\n' + ''.join(traceback.format_stack()))
    real_exit(code)
def my_os_exit(code):
    stamp(f'os._exit({code!r}) from:\n' + ''.join(traceback.format_stack()))
    for tid, frame in sys._current_frames().items():
        stamp(f'thread {tid}:\n' + ''.join(traceback.format_stack(frame)))
    real_os_exit(code)
sys.exit, os._exit = my_exit, my_os_exit
atexit.register(lambda: stamp('atexit reached'))
def hook(args):
    stamp('thread exception: ' + ''.join(traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback)))
threading.excepthook = hook
faulthandler.dump_traceback_later(870, repeat=False, file=sys.stderr)
sys.argv = ['hbm_child.py', 'capacity']
try:
    runpy.run_path('hbm_child.py', run_name='__main__')
except BaseException as e:
    stamp('main raised ' + ''.join(traceback.format_exception(type(e), e, e.__traceback__)))
    raise
stamp('main returned')
