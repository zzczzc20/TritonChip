    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    .li       s1, #2576980378
    s.sub        s5, s2, s3
    s.movz       s2, #5
    s.xor        s3, s4, s5
    s.movz       s6, #0
    s.sub        s7, s3, s5
    s.movz       s3, #0
    s.mul        s8, s7, s1
    s.cmp.lt     s1, s2, s6
    s.movz       s6, #3
    s.sub        s9, s3, s1
    s.movz       s1, #1
    s.lshri      s3, s8, #32
    s.xor        s8, s5, s9
    s.sub        s5, s7, s3
    s.movz       s10, #0
    s.lshri      s11, s5, #1
    s.movz       s5, #0
    s.add        s12, s3, s11
    s.movz       s3, #0
    s.lshri      s11, s12, #2
    s.movz       s12, #0
    s.xor        s13, s11, s8
    s.cmp.lt     s14, s4, s5
    s.sub        s5, s13, s8
    s.sub        s8, s12, s14
    s.sub        s12, s6, s5
    s.muli       s13, s11, #5
    s.min.s      s11, s12, s1
    s.movz       s12, #0
    s.cmp.lt     s14, s11, s10
    s.movz       s10, #1
    s.sub        s15, s3, s14
    s.xor        s3, s4, s8
    s.rdspecial  s14, arg_base
    s.xor        s16, s2, s9
    s.movz       s17, #0
    s.sub        s18, s3, s8
    s.ld.d       s3, [s14, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.xor        s19, s11, s15
    s.sub        s20, s16, s9
    s.sub        s9, s7, s13
    s.ld.d       s7, [s14, #8]                   // arg_B: device_ptr64 at arg_base+8
    s.sub        s9, s19, s15
    s.ld.d       s13, [s14, #16]                 // in_ptr2: device_ptr64 at arg_base+16
    s.addi       s15, s12, #0
    s.ld.d       s12, [s14, #24]                 // in_ptr3: device_ptr64 at arg_base+24
    s.addi       s16, s17, #0
    s.ld.d       s17, [s14, #32]                 // in_ptr4: device_ptr64 at arg_base+32
    s.cmp.eq     s19, s9, s10
    s.ld.d       s10, [s14, #40]                 // out_ptr0: device_ptr64 at arg_base+40
    s.mov        s15, s18
    br.nz        s19, sdiv_done_1
    s.movz       s14, #0
    s.movz       s19, #31
    s.mov        s15, s14
    s.addi       s14, s19, #0
sdiv_2:
    s.lshr       s19, s18, s14
    s.shli       s20, s16, #1
    s.andi       s21, s19, #1
    s.movz       s19, #0
    s.or         s22, s20, s21
    s.movz       s20, #1
    s.cmp.geu    s21, s22, s9
    s.shl        s23, s20, s14
    s.sub        s20, s19, s21
    s.subi       s19, s14, #1
    s.and        s21, s9, s20
    s.and        s24, s23, s20
    s.sub        s20, s22, s21
    s.or         s21, s15, s24
    s.mov        s16, s20
    s.mov        s15, s21
    s.mov        s14, s19
    s.movz       s19, #0
    s.cmp.ge     s20, s14, s19
    br.nz        s20, sdiv_2
sdiv_done_1:
    s.movz       s9, #0
    s.movz       s14, #0
    s.cmp.lt     s15, s4, s9
    .li       s9, #2576980378
    s.sub        s18, s14, s15
    s.movz       s14, #0
    s.xor        s15, s4, s18
    s.movz       s4, #0
    s.sub        s19, s15, s18
    s.movz       s15, #0
    s.mul        s20, s19, s9
    s.cmp.lt     s9, s11, s14
    s.movz       s14, #0
    s.movz       s21, #0
    s.sub        s22, s15, s9
    s.lshri      s9, s20, #32
    s.movz       s15, #0
    s.cmp.lt     s20, s2, s14
    s.xor        s14, s11, s22
    s.xor        s11, s16, s8
    s.sub        s16, s15, s20
    s.sub        s15, s19, s9
    s.sub        s20, s14, s22
    s.lshri      s14, s15, #1
    s.sub        s15, s11, s8
    s.add        s8, s9, s14
    s.movz       s9, #0
    s.lshri      s11, s8, #2
    s.movz       s8, #1
    s.muli       s14, s11, #5
    s.addi       s11, s9, #0
    s.cmp.eq     s9, s20, s8
    s.add        s8, s5, s15
    s.xor        s5, s2, s16
    s.sub        s15, s19, s14
    s.movz       s14, #0
    s.xor        s19, s15, s18
    s.sub        s15, s5, s16
    s.sub        s5, s19, s18
    s.addi       s15, s14, #0
    s.cmp.lt     s14, s5, s4
    s.sub        s4, s21, s14
    s.xor        s14, s5, s4
    s.sub        s5, s14, s4
    s.mov        s11, s5
    br.nz        s9, sdiv_done_3
    s.movz       s9, #0
    s.movz       s14, #31
    s.mov        s11, s9
    s.addi       s9, s14, #0
sdiv_4:
    s.lshr       s14, s5, s9
    s.shli       s16, s15, #1
    s.andi       s18, s14, #1
    s.movz       s14, #0
    s.or         s19, s16, s18
    s.movz       s16, #1
    s.cmp.geu    s18, s19, s20
    s.shl        s21, s16, s9
    s.sub        s16, s14, s18
    s.subi       s14, s9, #1
    s.and        s18, s20, s16
    s.and        s23, s21, s16
    s.sub        s16, s19, s18
    s.or         s18, s11, s23
    s.mov        s15, s16
    s.mov        s11, s18
    s.mov        s9, s14
    s.movz       s14, #0
    s.cmp.ge     s16, s9, s14
    br.nz        s16, sdiv_4
sdiv_done_3:
    s.movz       s5, #16
    s.xor        s9, s4, s22
    s.mul        s4, s8, s5
    s.xor        s14, s11, s9
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s11, s14, s9
    v.movi       v1, #40
    v.splat      v2, s4
    s.mul        s9, s11, s5
    v.movi       v3, #0
    v.add        v4, v2, v0
    s.movz       s14, #0
    v.splat      v2, s8
    v.splat      v5, s14
    v.splat      v6, s11
    v.splat      v7, s14
    v.splat      v8, s9
    v.sub        v9, v3, v4
    v.sub        v10, v3, v1
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.cmp.ge     p3, v2, v5
    v.cmp.ge     p3, v6, v7
    v.add        v2, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v4
    @p2 v.sel        v4, v10, v1
    v.movi       v1, #0
    v.movi       v6, #0
    s.movz       s8, #31
idiv_5:
    v.splat      v7, s8
    v.shl        v8, v6, v0
    v.cmp.lt     p2, v6, v3
    v.lshr       v9, v5, v7
    v.shl        v10, v0, v7
    s.subi       s11, s8, #1
    v.and        v7, v9, v0
    s.movz       s15, #0
    v.or         v9, v8, v7
    v.cmp.geu    p3, v9, v4
    p.or         p4, p2, p3
    v.sub        v7, v9, v4
    @p4 v.sel        v8, v10, v3
    @p4 v.sel        v10, v7, v9
    v.or         v7, v1, v8
    v.mov        v6, v10
    v.mov        v1, v7
    s.mov        s8, s11
    s.cmp.ge     s11, s8, s15
    br.nz        s11, idiv_5
    v.movi       v0, #72
    v.movi       v1, #0
    v.sub        v4, v3, v6
    v.movi       v3, #1
    v.sub        v5, v1, v2
    v.sub        v7, v1, v0
    v.cmp.lt     p2, v2, v1
    v.cmp.lt     p3, v0, v1
    @p1 v.sel        v8, v4, v6
    @p2 v.sel        v4, v5, v2
    @p3 v.sel        v2, v7, v0
    v.movi       v0, #0
    v.movi       v5, #0
    s.movz       s8, #31
idiv_6:
    v.splat      v6, s8
    v.shl        v7, v5, v3
    v.cmp.lt     p1, v5, v1
    v.lshr       v9, v4, v6
    v.shl        v10, v3, v6
    s.subi       s11, s8, #1
    v.and        v6, v9, v3
    s.movz       s15, #0
    v.or         v9, v7, v6
    v.cmp.geu    p3, v9, v2
    p.or         p4, p1, p3
    v.sub        v6, v9, v2
    @p4 v.sel        v7, v10, v1
    @p4 v.sel        v10, v6, v9
    v.or         v6, v0, v7
    v.mov        v5, v10
    v.mov        v0, v6
    s.mov        s8, s11
    s.cmp.ge     s11, s8, s15
    br.nz        s11, idiv_6
    v.sub        v0, v1, v5
    s.movz       s8, #13
    s.addi       s11, s14, #0
    @p2 v.sel        v1, v0, v5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_7:
    s.cmp.ge     s15, s11, s8
    br.nz        s15, endfor_8
    s.mul        s15, s11, s5
    s.rdspecial  s16, arg_base
    s.movz       s18, #0
    s.ld.d       s19, [s16, #48]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s16, #200
    s.add        s20, s18, s15                   // the tile origin
    v.extract    s18, v8, #0
    v.extract    s21, v8, #1
    v.extract    s22, v8, #2
    v.extract    s23, v8, #3
    v.extract    s24, v8, #4
    s.rdspecial  s25, role_id
    s.movz       s26, #2560
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s20
    v.splat      v3, s18
    v.splat      v4, s16
    v.splat      v5, s21
    v.splat      v6, s22
    v.splat      v7, s23
    v.splat      v9, s24
    s.mul        s18, s25, s26
    v.add        v10, v0, v2
    v.mul        v2, v3, v4
    v.mul        v3, v5, v4
    v.mul        v5, v6, v4
    v.mul        v6, v7, v4
    v.mul        v7, v9, v4
    s.add        s20, s19, s18                   // this context's own scratch
    v.splat      v9, s14
    v.add        v11, v10, v2
    v.add        v2, v10, v3
    v.add        v3, v10, v5
    v.add        v5, v10, v6
    v.add        v6, v10, v7
    s.addi       s18, s20, #0
    v.add        v7, v9, v11
    v.add        v11, v9, v2
    v.add        v2, v9, v3
    v.add        v3, v9, v5
    v.add        v5, v9, v6
    s.addi       s19, s18, #64
    s.addi       s21, s18, #128
    s.addi       s22, s18, #192
    s.addi       s23, s18, #256
    v.st.w       [s18, #0], v7
    s.sub        s24, s16, s15
    v.extract    s25, v8, #5
    v.extract    s26, v8, #6
    v.splat      v6, s25
    v.extract    s25, v8, #7
    v.mul        v7, v6, v4
    v.add        v6, v10, v7
    v.add        v7, v9, v6
    v.st.w       [s19, #0], v11
    v.extract    s19, v8, #8
    v.splat      v6, s26
    v.extract    s26, v8, #9
    v.mul        v11, v6, v4
    v.add        v6, v10, v11
    v.add        v11, v9, v6
    v.st.w       [s21, #0], v2
    v.extract    s21, v8, #10
    v.splat      v2, s25
    s.addi       s25, s18, #320
    v.mul        v6, v2, v4
    v.add        v2, v10, v6
    v.add        v6, v9, v2
    v.st.w       [s22, #0], v3
    v.extract    s22, v8, #11
    v.splat      v2, s19
    s.addi       s19, s18, #384
    v.mul        v3, v2, v4
    v.add        v2, v10, v3
    v.add        v3, v9, v2
    v.st.w       [s23, #0], v5
    v.extract    s23, v8, #12
    v.splat      v2, s26
    s.addi       s26, s18, #448
    v.mul        v5, v2, v4
    v.add        v2, v10, v5
    v.add        v5, v9, v2
    v.st.w       [s25, #0], v7
    v.extract    s25, v8, #13
    v.splat      v2, s21
    s.addi       s21, s18, #512
    v.mul        v7, v2, v4
    v.add        v2, v10, v7
    v.add        v7, v9, v2
    v.st.w       [s19, #0], v11
    v.extract    s19, v8, #14
    v.splat      v2, s22
    s.addi       s22, s18, #576
    v.mul        v11, v2, v4
    v.add        v2, v10, v11
    v.add        v11, v9, v2
    v.st.w       [s26, #0], v6
    v.extract    s26, v8, #15
    v.splat      v2, s23
    v.splat      v6, s25
    s.addi       s23, s18, #640
    v.mul        v12, v2, v4
    v.mul        v2, v6, v4
    s.addi       s25, s18, #704
    v.add        v6, v10, v12
    v.add        v12, v10, v2
    v.add        v2, v9, v6
    v.add        v6, v9, v12
    v.st.w       [s21, #0], v3
    s.movz       s21, #0
    v.splat      v3, s19
    s.add        s19, s21, s15                   // the tile origin
    s.addi       s15, s20, #1024
    v.mul        v12, v3, v4
    s.addi       s21, s18, #768
    v.add        v3, v10, v12
    v.add        v12, v9, v3
    v.st.w       [s22, #0], v5
    v.splat      v3, s26
    s.addi       s22, s18, #832
    s.addi       s26, s18, #896
    v.mul        v5, v3, v4
    v.splat      v3, s16
    s.addi       s16, s18, #960
    v.add        v4, v10, v5
    v.splat      v5, s19
    s.addi       s18, s15, #64
    v.add        v10, v9, v4
    v.mul        v4, v1, v3
    v.add        v9, v5, v4
    v.splat      v4, s14
    v.add        v5, v4, v9
    v.st.w       [s23, #0], v7
    s.addi       s23, s19, #1
    v.mul        v7, v1, v3
    v.st.w       [s25, #0], v11
    s.addi       s25, s19, #2
    v.splat      v9, s23
    s.addi       s23, s15, #128
    v.add        v11, v9, v7
    v.splat      v7, s25
    s.addi       s25, s15, #192
    v.add        v9, v4, v11
    v.st.w       [s21, #0], v2
    s.addi       s21, s19, #3
    v.mul        v2, v1, v3
    v.add        v11, v7, v2
    v.splat      v2, s21
    s.addi       s21, s15, #256
    v.add        v7, v4, v11
    v.st.w       [s22, #0], v6
    s.addi       s22, s19, #4
    v.mul        v6, v1, v3
    v.add        v11, v2, v6
    v.splat      v2, s22
    s.addi       s22, s15, #320
    v.add        v6, v4, v11
    v.st.w       [s26, #0], v12
    s.addi       s26, s19, #5
    v.mul        v11, v1, v3
    v.add        v12, v2, v11
    v.splat      v2, s26
    s.addi       s26, s15, #384
    v.add        v11, v4, v12
    v.st.w       [s16, #0], v10
    s.addi       s16, s19, #6
    v.mul        v10, v1, v3
    fence.acq_rel.device
    v.add        v12, v2, v10
    v.splat      v2, s16
    s.addi       s16, s19, #7
    v.add        v10, v4, v12
    v.st.w       [s15, #0], v5
    v.mul        v5, v1, v3
    v.add        v12, v2, v5
    v.splat      v2, s16
    s.addi       s16, s19, #8
    v.add        v5, v4, v12
    v.st.w       [s18, #0], v9
    s.addi       s18, s19, #9
    v.mul        v9, v1, v3
    v.add        v12, v2, v9
    v.splat      v2, s16
    s.addi       s16, s15, #448
    v.add        v9, v4, v12
    v.st.w       [s23, #0], v7
    s.addi       s23, s19, #10
    v.mul        v7, v1, v3
    v.add        v12, v2, v7
    v.splat      v2, s18
    s.addi       s18, s15, #512
    v.add        v7, v4, v12
    v.st.w       [s25, #0], v6
    s.addi       s25, s19, #11
    v.mul        v6, v1, v3
    v.add        v12, v2, v6
    v.splat      v2, s23
    s.addi       s23, s15, #576
    v.add        v6, v4, v12
    v.st.w       [s21, #0], v11
    s.addi       s21, s19, #12
    v.mul        v11, v1, v3
    v.add        v12, v2, v11
    v.splat      v2, s25
    s.addi       s25, s15, #640
    v.add        v11, v4, v12
    v.st.w       [s22, #0], v10
    s.addi       s22, s19, #13
    v.mul        v10, v1, v3
    v.add        v12, v2, v10
    v.splat      v2, s21
    s.addi       s21, s15, #704
    v.add        v10, v4, v12
    v.st.w       [s26, #0], v5
    s.addi       s26, s19, #14
    v.mul        v5, v1, v3
    v.add        v12, v2, v5
    v.splat      v2, s22
    s.addi       s22, s15, #768
    v.add        v5, v4, v12
    v.st.w       [s16, #0], v9
    s.addi       s16, s19, #15
    v.mul        v9, v1, v3
    s.addi       s19, s15, #832
    v.add        v12, v2, v9
    v.splat      v2, s26
    s.addi       s26, s15, #896
    v.add        v9, v4, v12
    s.addi       s27, s15, #960
    v.st.w       [s18, #0], v7
    v.mul        v7, v1, v3
    v.mul        v12, v1, v3
    v.splat      v3, s16
    v.add        v13, v2, v7
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s15, s20, #0
    v.add        v2, v3, v12
    v.add        v3, v4, v13
    s.movz       s16, #0
    v.add        v7, v4, v2
    v.st.w       [s23, #0], v6
    s.add        s18, s16, s24                   // the tile origin
    s.addi       s16, s20, #2048                 // 256 bytes of repack scratch
    v.splat      v2, s18
    s.addi       s18, s20, #64
    v.cmp.lt     p1, v0, v2
    v.st.w       [s25, #0], v11
    s.addi       s23, s16, #16                   // row 1
    v.st.w       [s21, #0], v10
    s.addi       s21, s20, #128
    v.st.w       [s22, #0], v5
    s.addi       s22, s16, #32                   // row 2
    v.st.w       [s19, #0], v9
    s.addi       s19, s20, #192
    v.st.w       [s26, #0], v3
    s.addi       s25, s16, #48                   // row 3
    v.st.w       [s27, #0], v7
    fence.acq_rel.device
    s.addi       s26, s20, #256
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s16, #64                   // row 4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.b       [s16, #0], v2
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s20, #320
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.b       [s23, #0], v2
    s.addi       s23, s16, #80                   // row 5
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s20, #384
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.b       [s22, #0], v2
    s.addi       s22, s16, #96                   // row 6
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s20, #448
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.b       [s25, #0], v2
    s.addi       s25, s16, #112                  // row 7
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s20, #512
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.b       [s15, #0], v2
    s.addi       s15, s16, #128                  // row 8
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s20, #576
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.b       [s23, #0], v2
    s.addi       s23, s16, #144                  // row 9
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s20, #640
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.b       [s22, #0], v2
    s.addi       s22, s16, #160                  // row 10
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s20, #704
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.b       [s25, #0], v2
    s.addi       s25, s16, #176                  // row 11
    v.ld.w       v0, [s26, #0]
    s.addi       s26, s20, #768
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.b       [s15, #0], v2
    s.addi       s15, s16, #192                  // row 12
    v.ld.w       v0, [s18, #0]
    s.addi       s18, s20, #832
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.splat      v0, s14
    s.addi       s27, s16, #208                  // row 13
    v.st.b       [s23, #0], v2
    s.addi       s23, s20, #896
    v.ld.w       v2, [s21, #0]
    s.addi       s21, s16, #224                  // row 14
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s3, v2]               // index is in elements (ISA sec 9.1)
    v.st.b       [s22, #0], v3
    s.addi       s22, s20, #960
    v.ld.w       v2, [s19, #0]
    s.addi       s19, s16, #240                  // row 15
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s3, v2]               // index is in elements (ISA sec 9.1)
    v.splat      v2, s1
    v.st.b       [s25, #0], v3
    s.addi       s25, s16, #64
    v.ld.w       v3, [s26, #0]
    s.addi       s26, s16, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v4, [s3, v3]               // index is in elements (ISA sec 9.1)
    v.st.b       [s15, #0], v4
    s.addi       s15, s16, #192
    v.ld.w       v3, [s18, #0]
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s18, s20, #1024
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v4, [s3, v3]               // index is in elements (ISA sec 9.1)
    v.st.b       [s27, #0], v4
    s.movz       s27, #0
    s.add        s28, s27, s24                   // the tile origin
    s.addi       s24, s20, #2304                 // 256 bytes of repack scratch
    v.splat      v3, s28
    s.addi       s27, s20, #1088
    v.cmp.lt     p2, v0, v3
    v.ld.w       v0, [s23, #0]
    s.addi       s23, s24, #16                   // row 1
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v4, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.splat      v0, s6
    s.addi       s28, s20, #1152
    v.st.b       [s21, #0], v4
    s.movz       s21, #2
    v.splat      v4, s21
    s.addi       s21, s24, #32                   // row 2
    v.ld.w       v5, [s22, #0]
    s.addi       s22, s20, #1216
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v6, [s3, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v3
    s.addi       s29, s24, #48                   // row 3
    v.st.b       [s19, #0], v6
    w.def        w0, #60, #4                     // v60..v63
    fence.acq_rel.device
    s.addi       s19, s20, #1280
    v.ld.w       v2, [s16, #0]
    s.movz       s16, #4
    v.splat      v5, s16
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s25, #0]
    s.addi       s16, s24, #64                   // row 4
    s.addi       s25, s20, #1344
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s26, #0]
    v.splat      v6, s2
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s24, #80                   // row 5
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s18, #0]
    s.addi       s18, s20, #1408
    s.movz       s26, #6
    s.addi       s30, s24, #96                   // row 6
    v.splat      v7, s26
    s.addi       s26, s20, #1472
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v9, [s7, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v3
    v.st.b       [s24, #0], v9
    v.ld.w       v2, [s27, #0]
    s.movz       s27, #7
    v.splat      v4, s27
    s.addi       s27, s24, #112                  // row 7
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v9, [s7, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v0, v3
    v.st.b       [s23, #0], v9
    s.addi       s23, s20, #1536
    v.ld.w       v0, [s28, #0]
    s.movz       s28, #8
    v.splat      v2, s28
    s.addi       s28, s24, #128                  // row 8
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v3
    v.st.b       [s21, #0], v9
    s.addi       s21, s20, #1600
    v.ld.w       v0, [s22, #0]
    s.movz       s22, #9
    v.splat      v5, s22
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v3
    s.addi       s22, s24, #144                  // row 9
    v.st.b       [s29, #0], v9
    s.addi       s29, s20, #1664
    v.ld.w       v0, [s19, #0]
    s.movz       s19, #10
    v.splat      v6, s19
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v7, v3
    s.addi       s19, s24, #160                  // row 10
    v.st.b       [s16, #0], v9
    s.addi       s16, s20, #1728
    v.ld.w       v0, [s25, #0]
    s.movz       s25, #11
    v.splat      v7, s25
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v3
    s.addi       s25, s24, #176                  // row 11
    v.st.b       [s15, #0], v9
    s.addi       s15, s20, #1792
    v.ld.w       v0, [s18, #0]
    s.movz       s18, #12
    v.splat      v4, s18
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v3
    s.addi       s18, s24, #192                  // row 12
    v.st.b       [s30, #0], v9
    s.addi       s30, s20, #1856
    v.ld.w       v0, [s26, #0]
    v.splat      v2, s8
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v3
    s.addi       s26, s24, #208                  // row 13
    v.st.b       [s27, #0], v9
    s.addi       s27, s20, #1920
    v.ld.w       v0, [s23, #0]
    s.movz       s23, #14
    v.splat      v5, s23
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v3
    s.addi       s23, s24, #224                  // row 14
    v.st.b       [s28, #0], v9
    s.addi       s28, s20, #1984
    v.ld.w       v0, [s21, #0]
    s.movz       s20, #15
    v.splat      v6, s20
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v9, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v3
    s.addi       s20, s24, #240                  // row 15
    v.st.b       [s22, #0], v9
    v.ld.w       v0, [s29, #0]
    s.addi       s21, s24, #64
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v7, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v3
    s.addi       s22, s24, #128
    v.st.b       [s19, #0], v7
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s24, #192
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v4, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v3
    v.st.b       [s25, #0], v4
    s.add        s19, s11, s1
    v.ld.w       v0, [s15, #0]
    s.movz       s15, #1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v2, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v3
    v.st.b       [s18, #0], v2
    v.ld.w       v0, [s30, #0]
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v3
    v.st.b       [s26, #0], v2
    v.ld.w       v0, [s27, #0]
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v2, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.b       [s23, #0], v2
    v.ld.w       v0, [s28, #0]
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.b       [s20, #0], v2
    w.def        w1, #56, #4                     // v56..v59
    fence.acq_rel.device
    v.ld.w       v0, [s24, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s21, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s22, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s16, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s16, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.e4m3 a0, v60, v56, s16
    mb.wait      s16
    s.mov        s11, s19
    br.nz        s15, for_7
endfor_8:
    s.ld.w       s1, [s13, #0]                   // one element, not a vector
    v.splat      v0, s1
    s.ld.w       s1, [s12, #0]                   // one element, not a vector
    v.splat      v1, s1
    s.muli       s1, s9, #2                      // a runtime tile origin, x2
    s.add        s2, s17, s1                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s1, s9, #2                      // a runtime tile origin, x2
    s.add        s3, s10, s1                     // the tile origin
    s.muli       s1, s4, #144                    // a runtime tile origin, x144
    s.add        s5, s3, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v2, a0, s1
    vf.mul       v3, v0, v1
    vf.mul       v4, v2, v3
    s.movz       s1, #0
    s.add        s3, s1, s4                      // the tile origin
    v.splat      v2, s3
    s.movz       s1, #40
    v.splat      v3, s1
    v.cmp.lt     p1, v2, v3
    s.movz       s1, #0
    s.add        s4, s1, s9                      // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v5, s4
    v.add        v6, v2, v5
    s.movz       s1, #72
    v.splat      v2, s1
    v.cmp.lt     p2, v6, v2
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v5, v2
    vf.add       v2, v4, v5
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s3
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s5, #0], v4
    s.movz       s1, #1
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #1
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #144                    // row 1
    s.addi       s4, s3, #1
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #2
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #2
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #288                    // row 2
    s.addi       s4, s3, #2
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #3
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #3
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #432                    // row 3
    s.addi       s4, s3, #3
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #4
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #4
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #576                    // row 4
    s.addi       s4, s3, #4
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #5
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #5
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #720                    // row 5
    s.addi       s4, s3, #5
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #6
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #6
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #864                    // row 6
    s.addi       s4, s3, #6
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #7
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #7
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1008                   // row 7
    s.addi       s4, s3, #7
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #8
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #8
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1152                   // row 8
    s.addi       s4, s3, #8
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #9
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #9
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1296                   // row 9
    s.addi       s4, s3, #9
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #10
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #10
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1440                   // row 10
    s.addi       s4, s3, #10
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #11
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #11
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1584                   // row 11
    s.addi       s4, s3, #11
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #12
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #12
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1728                   // row 12
    s.addi       s4, s3, #12
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #13
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #13
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #1872                   // row 13
    s.addi       s4, s3, #13
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #14
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v5, v2, v4
    s.addi       s1, s3, #14
    v.splat      v2, s1
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    vf.cvt.bf16.f32 v4, v2
    vf.add       v2, v5, v4
    vf.cvt.f32.bf16 v4, v2
    s.addi       s1, s5, #2016                   // row 14
    s.addi       s4, s3, #14
    v.splat      v2, s4
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v4
    s.movz       s1, #15
    a.vread      v2, a0, s1
    vf.mul       v4, v0, v1
    vf.mul       v0, v2, v4
    s.addi       s1, s3, #15
    v.splat      v1, s1
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.bf16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s5, #2160                   // row 15
    s.addi       s2, s3, #15
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
__rctx_next:
    exit
