    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #32
    s.movz       s6, #48
    s.shli       s7, s4, #6                      // x64 as a shift
    .li       s4, #1069066811
    v.splat      v0, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s4, s2, s7
    s.add        s2, s5, s7
    s.add        s5, s6, s7
    s.shli       s6, s7, #1                      // element offset -> bytes (x2)
    s.shli       s8, s4, #1                      // element offset -> bytes (x2)
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    s.shli       s2, s5, #1                      // element offset -> bytes (x2)
    s.add        s5, s3, s6                      // &in_ptr0[...]
    s.add        s9, s3, s8                      // &in_ptr0[...]
    s.add        s10, s3, s4                     // &in_ptr0[...]
    s.add        s11, s3, s2                     // &in_ptr0[...]
    v.ld.h       v1, [s5, #0]
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #16
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #32
    v.iota       v6                              // arange(0, VLEN)
    v.movi       v7, #48
    v.iota       v8                              // arange(0, VLEN)
    v.add        v9, v2, v3
    v.add        v2, v4, v5
    v.add        v3, v6, v7
    v.splat      v4, s7
    v.splat      v5, s7
    v.splat      v6, s7
    v.ld.h       v7, [s9, #0]
    vf.cvt.f16.f32 v10, v1
    v.splat      v1, s7
    v.add        v11, v4, v8
    v.add        v4, v5, v9
    v.add        v4, v6, v2
    vf.neg       v2, v10
    v.add        v4, v1, v3
    vf.mul       v1, v2, v0
    v.ld.h       v3, [s10, #0]
    vf.cvt.f16.f32 v4, v7
    vf.neg       v5, v4
    v.ld.h       v6, [s11, #0]
    vf.cvt.f16.f32 v7, v3
    vf.neg       v3, v7
    vf.cvt.f16.f32 v8, v6
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    vf.mul       v6, v5, v0
    vf.mul       v9, v3, v0
    v.exp2.approx v11, v1                        // ISA 8.8: <= 2**-22 relative
    vf.neg       v12, v8
    vf.fms       v13, v2, v0, v1                 // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v6                         // ISA 8.8: <= 2**-22 relative
    v.exp2.approx v2, v9                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v14, v5, v0, v6                 // the exact rounding error of x*log2(e)
    vf.mul       v5, v12, v0
    vf.fms       v6, v3, v0, v9                  // the exact rounding error of x*log2(e)
    .li       s1, #1060205080
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v15, v12, v0, v5                // the exact rounding error of x*log2(e)
    v.exp2.approx v0, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v13, v3
    vf.mul       v12, v14, v3
    vf.mul       v13, v6, v3
    vf.mul       v6, v15, v3
    .li       s1, #1065353216
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v15, v11, v5, v11               // 2**t * 2**d
    vf.fma       v5, v1, v12, v1                 // 2**t * 2**d
    vf.fma       v12, v2, v13, v2                // 2**t * 2**d
    vf.cmp.o     p1, v15, v15
    @p1 v.sel        v13, v15, v11
    .li       s1, #1065353216
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.o     p1, v5, v5
    vf.cmp.o     p2, v12, v12
    @p1 v.sel        v15, v5, v1
    @p2 v.sel        v1, v12, v2
    vf.fma       v2, v0, v6, v0                  // 2**t * 2**d
    vf.add       v5, v13, v9
    vf.add       v6, v15, v3
    vf.add       v3, v1, v14
    .li       s1, #1065353216
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v9, v2, v0
    v.rcp.approx v0, v5                          // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v2, v6                          // ISA 8.8: <= 2**-22 relative
    vf.add       v12, v9, v11
    v.rcp.approx v9, v3                          // ISA 8.8: <= 2**-22 relative
    s.add        s1, s3, s6                      // &out_ptr0[...]
    s.add        s5, s3, s8                      // &out_ptr0[...]
    s.add        s6, s3, s4                      // &out_ptr0[...]
    v.rcp.approx v11, v12                        // ISA 8.8: <= 2**-22 relative
    s.add        s4, s3, s2                      // &out_ptr0[...]
    vf.fms       v13, v5, v0, v1
    vf.fms       v5, v6, v2, v1
    vf.fms       v6, v3, v9, v1
    vf.fms       v3, v0, v13, v0
    vf.fms       v13, v2, v5, v2
    vf.fms       v5, v12, v11, v1
    vf.fms       v1, v9, v6, v9
    vf.neg       v6, v3                          // Newton step: r0*(2 - x*r0)
    vf.neg       v3, v13                         // Newton step: r0*(2 - x*r0)
    vf.fms       v12, v11, v5, v11
    vf.neg       v5, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v6, v6
    vf.cmp.o     p2, v3, v3
    vf.neg       v1, v12                         // Newton step: r0*(2 - x*r0)
    @p1 v.sel        v12, v6, v0
    vf.cmp.o     p1, v5, v5
    @p2 v.sel        v0, v3, v2
    @p1 v.sel        v2, v5, v9
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v3, v1, v11
    vf.mul       v1, v10, v12                    // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v5, v4, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v0, v7, v2                      // a/y as a refined reciprocal (ISA has no divide)
    vf.mul       v2, v8, v3                      // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.f16 v3, v1
    vf.cvt.f32.f16 v1, v5
    vf.cvt.f32.f16 v4, v0
    vf.cvt.f32.f16 v0, v2
    v.st.h       [s1, #0], v3
    v.st.h       [s5, #0], v1
    v.st.h       [s6, #0], v4
    v.st.h       [s4, #0], v0
__rctx_next:
    exit
