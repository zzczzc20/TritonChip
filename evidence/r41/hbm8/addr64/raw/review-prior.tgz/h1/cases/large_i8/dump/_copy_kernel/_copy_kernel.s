    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    v.iota       v0                              // arange(0, VLEN)
    s.ld.d       s2, [s1, #0]                    // SRC: device_ptr64 at arg_base+0
    v.movi       v1, #16
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #32
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #48
    v.iota       v6                              // arange(0, VLEN)
    v.movi       v7, #64
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #80
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #96
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #112
    s.shli       s3, s4, #7                      // x128 as a shift
    s.movz       s4, #16
    s.movz       s5, #32
    s.movz       s6, #48
    s.movz       s7, #64
    s.movz       s8, #80
    s.movz       s9, #96
    s.movz       s10, #112
    v.iota       v14                             // arange(0, VLEN)
    v.add        v15, v0, v1
    v.add        v0, v2, v3
    v.add        v1, v4, v5
    v.add        v2, v6, v7
    v.add        v3, v8, v9
    v.add        v4, v10, v11
    v.add        v5, v12, v13
    v.splat      v6, s3
    v.splat      v7, s3
    v.splat      v8, s3
    v.splat      v9, s3
    v.splat      v10, s3
    v.splat      v11, s3
    v.splat      v12, s3
    v.splat      v13, s3
    s.add        s11, s4, s3
    s.add        s4, s5, s3
    s.add        s5, s6, s3
    s.add        s6, s7, s3
    v.add        v16, v6, v14
    v.add        v6, v7, v15
    v.add        v7, v8, v0
    v.add        v0, v9, v1
    v.add        v1, v10, v2
    s.ld.d       s7, [s1, #8]                    // DST: device_ptr64 at arg_base+8
    s.add        s1, s8, s3
    s.add        s8, s9, s3
    s.add        s9, s10, s3
    v.add        v2, v11, v3
    v.add        v3, v12, v4
    v.add        v4, v13, v5
    s.movz       s10, #32768
    v.splat      v5, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s10, s3, #0                     // element offset -> bytes (x1)
    s.movz       s3, #32768
    v.splat      v8, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s3, s11, #0                     // element offset -> bytes (x1)
    s.movz       s11, #32768
    v.splat      v9, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s11, s4, #0                     // element offset -> bytes (x1)
    s.movz       s4, #32768
    v.splat      v10, s4                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s4, s5, #0                      // element offset -> bytes (x1)
    s.movz       s5, #32768
    v.splat      v11, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s5, s6, #0                      // element offset -> bytes (x1)
    s.movz       s6, #32768
    v.splat      v12, s6                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s6, s1, #0                      // element offset -> bytes (x1)
    s.movz       s1, #32768
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s1, s8, #0                      // element offset -> bytes (x1)
    s.movz       s8, #32768
    v.splat      v14, s8                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s8, s9, #0                      // element offset -> bytes (x1)
    s.add        s9, s2, s10                     // &SRC[...]
    s.add        s12, s2, s3                     // &SRC[...]
    s.add        s13, s2, s11                    // &SRC[...]
    s.add        s14, s2, s4                     // &SRC[...]
    s.add        s15, s2, s5                     // &SRC[...]
    v.cmp.lt     p1, v16, v5
    v.cmp.lt     p2, v6, v8
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p1 v.ld.sb      v15, [s9, #0]
    s.add        s9, s2, s6                      // &SRC[...]
    v.cmp.lt     p1, v7, v9
    s.add        s16, s7, s10                    // &DST[...]
    s.add        s10, s7, s3                     // &DST[...]
    s.add        s3, s7, s11                     // &DST[...]
    s.add        s11, s7, s4                     // &DST[...]
    s.add        s4, s7, s5                      // &DST[...]
    s.add        s5, s7, s6                      // &DST[...]
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.sb      v17, [s12, #0]
    s.add        s6, s2, s1                      // &SRC[...]
    s.add        s12, s2, s8                     // &SRC[...]
    v.cmp.lt     p2, v0, v10
    s.add        s2, s7, s1                      // &DST[...]
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p1 v.ld.sb      v18, [s13, #0]
    v.cmp.lt     p1, v1, v11
    s.add        s1, s7, s8                      // &DST[...]
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.sb      v19, [s14, #0]
    v.cmp.lt     p2, v2, v12
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.sb      v20, [s15, #0]
    v.cmp.lt     p1, v3, v13
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p2 v.ld.sb      v21, [s9, #0]
    v.cmp.lt     p2, v4, v14
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.sb      v22, [s6, #0]
    v.cmp.lt     p1, v16, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.sb      v5, [s12, #0]
    v.cmp.lt     p2, v6, v8
    @p1 v.st.b       [s16, #0], v15
    v.cmp.lt     p1, v7, v9
    @p2 v.st.b       [s10, #0], v17
    v.cmp.lt     p2, v0, v10
    @p1 v.st.b       [s3, #0], v18
    v.cmp.lt     p1, v1, v11
    @p2 v.st.b       [s11, #0], v19
    v.cmp.lt     p2, v2, v12
    @p1 v.st.b       [s4, #0], v20
    v.cmp.lt     p1, v3, v13
    @p2 v.st.b       [s5, #0], v21
    v.cmp.lt     p2, v4, v14
    @p1 v.st.b       [s2, #0], v22
    @p2 v.st.b       [s1, #0], v5
__rctx_next:
    exit
