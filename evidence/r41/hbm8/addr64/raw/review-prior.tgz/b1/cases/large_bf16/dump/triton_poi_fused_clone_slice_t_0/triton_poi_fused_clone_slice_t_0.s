    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    s.rdspecial  s2, pid.y
    s.muli       s3, s1, #2048                   // a runtime tile origin, x2048
    s.shli       s4, s2, #4                      // x16 as a shift
    s.movz       s2, #0
    s.rdspecial  s5, arg_base
    s.add        s6, s2, s4                      // the tile origin
    s.ld.d       s7, [s5, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s8, #2048
    s.add        s9, s2, s1                      // the tile origin
    s.add        s10, s6, s3                     // the tile origin
    .li       s3, #1207928784
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s8
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s9
    s.add        s6, s10, s3
    s.add        s3, s2, s4                      // the tile origin
    v.mul        v4, v0, v1
    v.splat      v0, s6
    v.add        v1, v2, v3
    v.splat      v2, s3
    s.rdspecial  s2, arg_base
    v.add        v3, v4, v0
    v.cmpi.lt    p1, v1, #16
    v.cmpi.lt    p2, v2, #48
    p.and        p3, p1, p2
    s.ld.d       s6, [s2, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, role_id
    s.movz       s8, #1024
    .li       s9, #1207928785
    s.mul        s11, s2, s8
    s.add        s2, s10, s9
    s.addi       s8, s3, #1
    v.splat      v0, s2
    v.splat      v1, s8
    .li       s2, #1207928786
    v.add        v2, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v0, [s7, v3]               // index is in elements (ISA sec 9.1)
    s.add        s8, s6, s11                     // this context's own scratch
    v.cmpi.lt    p2, v1, #48
    s.addi       s6, s8, #0
    p.and        p3, p1, p2
    s.add        s9, s10, s2
    s.addi       s2, s6, #64
    s.addi       s11, s6, #128
    s.ld.d       s12, [s5, #8]                   // out_ptr0: device_ptr64 at arg_base+8
    s.addi       s5, s3, #2
    v.splat      v1, s9
    v.splat      v3, s5
    .li       s5, #1207928787
    v.add        v5, v4, v1
    v.cmpi.lt    p2, v3, #48
    p.and        p4, p1, p2
    s.add        s9, s10, s5
    s.addi       s5, s3, #3
    v.splat      v1, s9
    v.st.w       [s6, #0], v0
    v.splat      v0, s5
    v.add        v3, v4, v1
    .li       s5, #1207928788
    s.addi       s9, s3, #4
    s.add        s13, s10, s5
    v.splat      v1, s9
    v.splat      v6, s13
    s.addi       s5, s6, #192
    .li       s9, #1207928789
    v.add        v7, v4, v6
    s.add        s13, s10, s9
    s.addi       s9, s3, #5
    v.splat      v6, s13
    s.addi       s13, s6, #256
    .li       s14, #1207928790
    v.add        v8, v4, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s7, v2]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v0, #48
    p.and        p3, p1, p2
    v.splat      v0, s9
    s.add        s9, s10, s14
    s.addi       s14, s6, #320
    v.st.w       [s2, #0], v6
    s.addi       s2, s3, #6
    v.splat      v2, s9
    .li       s9, #1207928791
    v.add        v6, v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v2, [s7, v5]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #48
    p.and        p4, p1, p2
    v.splat      v1, s2
    s.add        s2, s10, s9
    s.addi       s9, s6, #384
    v.st.w       [s11, #0], v2
    s.addi       s11, s3, #7
    v.splat      v2, s2
    .li       s2, #1207928792
    v.add        v5, v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s7, v3]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v0, #48
    p.and        p3, p1, p2
    v.splat      v0, s11
    s.add        s11, s10, s2
    s.addi       s2, s6, #448
    v.st.w       [s5, #0], v2
    s.addi       s5, s3, #8
    v.splat      v2, s11
    .li       s11, #1207928793
    v.add        v3, v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v2, [s7, v7]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #48
    p.and        p4, p1, p2
    v.splat      v1, s5
    s.add        s5, s10, s11
    s.addi       s11, s6, #512
    v.st.w       [s13, #0], v2
    s.addi       s13, s3, #9
    v.splat      v2, s5
    .li       s5, #1207928794
    v.add        v7, v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s7, v8]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v0, #48
    p.and        p3, p1, p2
    v.splat      v0, s13
    s.add        s13, s10, s5
    s.addi       s5, s6, #576
    v.st.w       [s14, #0], v2
    s.addi       s14, s3, #10
    v.splat      v2, s13
    .li       s13, #1207928795
    v.add        v8, v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v2, [s7, v6]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #48
    p.and        p4, p1, p2
    v.splat      v1, s14
    s.add        s14, s10, s13
    s.addi       s13, s6, #640
    v.st.w       [s9, #0], v2
    s.addi       s9, s3, #11
    v.splat      v2, s14
    .li       s14, #1207928796
    v.add        v6, v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s7, v5]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v0, #48
    p.and        p3, p1, p2
    v.splat      v0, s9
    s.add        s9, s10, s14
    s.addi       s14, s6, #704
    v.st.w       [s2, #0], v2
    s.addi       s2, s3, #12
    v.splat      v2, s9
    .li       s9, #1207928797
    v.add        v5, v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v2, [s7, v3]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #48
    p.and        p4, p1, p2
    v.splat      v1, s2
    s.add        s2, s10, s9
    s.addi       s9, s6, #768
    v.st.w       [s11, #0], v2
    s.addi       s11, s3, #13
    v.splat      v2, s2
    .li       s2, #1207928798
    v.add        v3, v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s7, v7]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v0, #48
    p.and        p3, p1, p2
    v.splat      v0, s11
    s.add        s11, s10, s2
    s.addi       s2, s6, #832
    v.st.w       [s5, #0], v2
    s.addi       s5, s3, #14
    v.splat      v2, s11
    .li       s11, #1207928799
    v.add        v7, v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v2, [s7, v8]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #48
    p.and        p4, p1, p2
    v.splat      v1, s5
    s.add        s5, s10, s11
    s.addi       s10, s6, #896
    s.addi       s11, s6, #960
    v.st.w       [s13, #0], v2
    s.addi       s6, s3, #15
    v.splat      v2, s5
    s.muli       s5, s1, #2                      // a runtime tile origin, x2
    v.add        v8, v4, v2
    v.splat      v2, s6
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v4, [s7, v6]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v0, #48
    p.and        p3, p1, p2
    s.add        s1, s12, s5                     // the tile origin
    v.st.w       [s14, #0], v4
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s5, s8, #0
    s.muli       s6, s4, #32                     // a runtime tile origin, x32
    v.splat      v0, s3
    s.addi       s4, s8, #64
    s.add        s12, s1, s6                     // the tile origin
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v4, [s7, v5]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #48
    p.and        p4, p1, p2
    s.addi       s1, s12, #32                    // row 1
    v.st.w       [s9, #0], v4
    s.addi       s6, s3, #1
    s.addi       s9, s8, #128
    v.splat      v1, s6
    s.addi       s6, s3, #2
    s.addi       s13, s12, #64                   // row 2
    v.splat      v4, s6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v5, [s7, v3]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v2, #48
    p.and        p3, p1, p2
    v.st.w       [s2, #0], v5
    s.addi       s2, s8, #192
    s.addi       s6, s3, #3
    s.addi       s14, s12, #96                   // row 3
    v.splat      v2, s6
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s7, v7]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v0, #48
    p.and        p4, p1, p2
    s.addi       s6, s8, #256
    v.st.w       [s10, #0], v3
    s.addi       s10, s3, #4
    v.splat      v0, s10
    s.addi       s10, s12, #128                  // row 4
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s7, v8]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #48
    p.and        p3, p1, p2
    s.addi       s7, s8, #320
    v.st.w       [s11, #0], v3
    fence.acq_rel.device
    s.addi       s11, s3, #5
    v.splat      v1, s11
    s.addi       s11, s12, #160                  // row 5
    v.ld.w       v3, [s5, #0]
    s.addi       s5, s8, #384
    @p4 v.st.h       [s12, #0], v3
    v.cmpi.lt    p2, v4, #48
    p.and        p4, p1, p2
    v.ld.w       v3, [s4, #0]
    s.addi       s4, s3, #6
    v.splat      v4, s4
    s.addi       s4, s12, #192                   // row 6
    @p3 v.st.h       [s1, #0], v3
    v.cmpi.lt    p2, v2, #48
    p.and        p3, p1, p2
    s.addi       s1, s8, #448
    v.ld.w       v2, [s9, #0]
    s.addi       s9, s3, #7
    v.splat      v3, s9
    s.addi       s9, s12, #224                   // row 7
    @p4 v.st.h       [s13, #0], v2
    v.cmpi.lt    p2, v0, #48
    p.and        p4, p1, p2
    s.addi       s13, s8, #512
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s3, #8
    v.splat      v2, s2
    s.addi       s2, s12, #256                   // row 8
    @p3 v.st.h       [s14, #0], v0
    v.cmpi.lt    p2, v1, #48
    p.and        p3, p1, p2
    s.addi       s14, s8, #576
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s3, #9
    v.splat      v1, s6
    s.addi       s6, s12, #288                   // row 9
    @p4 v.st.h       [s10, #0], v0
    v.cmpi.lt    p2, v4, #48
    p.and        p4, p1, p2
    s.addi       s10, s8, #640
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s3, #10
    v.splat      v4, s7
    s.addi       s7, s12, #320                   // row 10
    @p3 v.st.h       [s11, #0], v0
    v.cmpi.lt    p2, v3, #48
    p.and        p3, p1, p2
    s.addi       s11, s8, #704
    v.ld.w       v0, [s5, #0]
    s.addi       s5, s3, #11
    v.splat      v3, s5
    s.addi       s5, s12, #352                   // row 11
    @p4 v.st.h       [s4, #0], v0
    v.cmpi.lt    p2, v2, #48
    p.and        p4, p1, p2
    s.addi       s4, s8, #768
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s3, #12
    v.splat      v2, s1
    s.addi       s1, s12, #384                   // row 12
    @p3 v.st.h       [s9, #0], v0
    v.cmpi.lt    p2, v1, #48
    p.and        p3, p1, p2
    s.addi       s9, s8, #832
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s3, #13
    v.splat      v1, s13
    s.addi       s13, s12, #416                  // row 13
    @p4 v.st.h       [s2, #0], v0
    v.cmpi.lt    p2, v4, #48
    p.and        p4, p1, p2
    s.addi       s2, s8, #896
    s.addi       s15, s8, #960
    v.ld.w       v0, [s14, #0]
    s.addi       s8, s3, #14
    s.addi       s14, s3, #15
    v.splat      v4, s8
    s.addi       s3, s12, #448                   // row 14
    v.splat      v5, s14
    s.addi       s8, s12, #480                   // row 15
    @p3 v.st.h       [s6, #0], v0
    v.cmpi.lt    p2, v3, #48
    p.and        p3, p1, p2
    v.ld.w       v0, [s10, #0]
    @p4 v.st.h       [s7, #0], v0
    v.cmpi.lt    p2, v2, #48
    p.and        p4, p1, p2
    v.ld.w       v0, [s11, #0]
    @p3 v.st.h       [s5, #0], v0
    v.cmpi.lt    p2, v1, #48
    p.and        p3, p1, p2
    v.ld.w       v0, [s4, #0]
    @p4 v.st.h       [s1, #0], v0
    v.cmpi.lt    p2, v4, #48
    p.and        p4, p1, p2
    v.ld.w       v0, [s9, #0]
    @p3 v.st.h       [s13, #0], v0
    v.cmpi.lt    p2, v5, #48
    p.and        p3, p1, p2
    v.ld.w       v0, [s2, #0]
    @p4 v.st.h       [s3, #0], v0
    v.ld.w       v0, [s15, #0]
    @p3 v.st.h       [s8, #0], v0
__rctx_next:
    exit
