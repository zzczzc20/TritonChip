    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    s.movz       s2, #0
    s.rdspecial  s3, pid.y
    s.add        s4, s2, s1                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s4
    s.shli       s4, s3, #4                      // x16 as a shift
    v.add        v2, v0, v1
    v.movi       v0, #0
    v.movi       v1, #0
    s.rdspecial  s3, role_id
    s.movz       s5, #5376
    s.muli       s6, s4, #64                     // a runtime tile origin, x64
    v.sub        v3, v0, v2
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.rdspecial  s7, arg_base
    s.mul        s8, s3, s5
    v.cmp.lt     p1, v2, v0
    v.cmp.lt     p2, v2, v1
    @p1 v.sel        v4, v3, v2
    v.movi       v3, #63
    s.ld.d       s3, [s7, #72]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.and        v5, v4, v3
    s.add        s5, s2, s6                      // the tile origin
    s.add        s2, s3, s8                      // this context's own scratch
    v.sub        v3, v0, v5
    s.addi       s3, s2, #0
    @p1 v.sel        v4, v3, v5
    v.splat      v3, s5
    s.rdspecial  s6, arg_base
    v.add        v5, v4, v3
    s.addi       s7, s3, #64
    s.ld.d       s8, [s6, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.sub        v3, v1, v2
    s.muli       s9, s1, #2                      // a runtime tile origin, x2
    s.ld.d       s10, [s6, #8]                   // in_ptr1: device_ptr64 at arg_base+8
    @p2 v.sel        v4, v3, v2
    s.muli       s11, s4, #6144                  // a runtime tile origin, x6144
    s.ld.d       s12, [s6, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.add        s13, s8, s9                     // the tile origin
    s.movz       s9, #64
    s.ld.d       s14, [s6, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.add        s15, s13, s11                   // the tile origin
    v.splat      v3, s9
    s.ld.d       s9, [s6, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    v.movi       v6, #63
    v.sub        v7, v0, v3
    s.ld.d       s11, [s6, #40]                  // out_ptr0: device_ptr64 at arg_base+40
    v.and        v8, v4, v6
    v.sub        v4, v1, v3
    s.ld.d       s13, [s6, #48]                  // out_ptr1: device_ptr64 at arg_base+48
    v.movi       v6, #0
    v.movi       v9, #0
    v.sub        v10, v6, v2
    v.cmp.lt     p1, v2, v6
    @p1 v.sel        v11, v10, v2
    v.movi       v10, #63
    v.sub        v12, v1, v8
    v.and        v13, v11, v10
    s.addi       s6, s5, #64
    v.sub        v10, v6, v13
    s.addi       s16, s5, #128
    @p2 v.sel        v11, v12, v8
    v.splat      v8, s6
    @p1 v.sel        v12, v10, v13
    v.splat      v10, s16
    v.add        v13, v11, v8
    s.addi       s6, s3, #128
    v.add        v8, v12, v10
    s.addi       s16, s3, #192
    v.st.w       [s3, #0], v5
    v.sub        v5, v6, v3
    v.cmp.lt     p1, v3, v0
    v.sub        v0, v9, v2
    v.cmp.lt     p2, v2, v9
    @p2 v.sel        v10, v0, v2
    v.cmp.lt     p3, v3, v1
    v.cmp.lt     p4, v3, v6
    @p1 v.sel        v0, v7, v3
    v.movi       v0, #0
    v.movi       v1, #63
    v.sub        v6, v0, v2
    v.cmp.lt     p1, v2, v0
    @p1 v.sel        v7, v6, v2
    v.and        v6, v10, v1
    s.addi       s17, s5, #192
    v.sub        v1, v9, v6
    v.splat      v10, s17
    @p2 v.sel        v11, v1, v6
    s.addi       s17, s3, #256
    v.add        v1, v11, v10
    v.st.w       [s7, #0], v13
    v.sub        v6, v9, v3
    v.sub        v10, v0, v3
    v.cmp.lt     p2, v3, v9
    @p3 v.sel        v9, v4, v3
    v.movi       v4, #0
    v.movi       v9, #63
    v.sub        v11, v4, v2
    v.cmp.lt     p3, v2, v4
    @p3 v.sel        v12, v11, v2
    v.and        v11, v7, v9
    s.addi       s7, s5, #256
    v.sub        v7, v0, v11
    v.splat      v9, s7
    @p1 v.sel        v13, v7, v11
    s.addi       s7, s3, #320
    v.add        v7, v13, v9
    v.st.w       [s6, #0], v8
    v.sub        v8, v4, v3
    v.cmp.lt     p1, v3, v0
    @p4 v.sel        v0, v5, v3
    v.movi       v0, #0
    v.movi       v5, #63
    v.sub        v9, v0, v2
    v.cmp.lt     p4, v2, v0
    @p4 v.sel        v11, v9, v2
    v.and        v9, v12, v5
    s.addi       s6, s5, #320
    v.sub        v5, v4, v9
    v.splat      v12, s6
    @p3 v.sel        v13, v5, v9
    s.addi       s6, s3, #384
    v.add        v5, v13, v12
    v.st.w       [s16, #0], v1
    v.sub        v1, v0, v3
    v.cmp.lt     p3, v3, v4
    @p2 v.sel        v4, v6, v3
    v.movi       v4, #0
    v.movi       v6, #63
    v.sub        v9, v4, v2
    v.cmp.lt     p2, v2, v4
    @p2 v.sel        v12, v9, v2
    v.and        v9, v11, v6
    s.addi       s16, s5, #384
    v.sub        v6, v0, v9
    v.splat      v11, s16
    @p4 v.sel        v13, v6, v9
    s.addi       s16, s3, #448
    v.add        v6, v13, v11
    v.st.w       [s17, #0], v7
    v.sub        v7, v4, v3
    v.cmp.lt     p4, v3, v0
    @p1 v.sel        v0, v10, v3
    v.movi       v0, #0
    v.movi       v9, #63
    v.sub        v10, v0, v2
    v.cmp.lt     p1, v2, v0
    @p1 v.sel        v11, v10, v2
    v.and        v10, v12, v9
    s.addi       s17, s5, #448
    v.sub        v9, v4, v10
    v.splat      v12, s17
    @p2 v.sel        v13, v9, v10
    s.addi       s17, s3, #512
    v.add        v9, v13, v12
    v.st.w       [s7, #0], v5
    v.sub        v5, v0, v3
    v.cmp.lt     p2, v3, v4
    @p3 v.sel        v4, v8, v3
    v.movi       v4, #0
    v.movi       v8, #63
    v.sub        v10, v4, v2
    v.cmp.lt     p3, v2, v4
    @p3 v.sel        v12, v10, v2
    v.and        v10, v11, v8
    s.addi       s7, s5, #512
    v.sub        v8, v0, v10
    v.splat      v11, s7
    @p1 v.sel        v13, v8, v10
    s.addi       s7, s3, #576
    v.add        v8, v13, v11
    v.st.w       [s6, #0], v6
    v.sub        v6, v4, v3
    v.cmp.lt     p1, v3, v0
    @p4 v.sel        v0, v1, v3
    v.movi       v0, #0
    v.movi       v1, #63
    v.sub        v10, v0, v2
    v.cmp.lt     p4, v2, v0
    @p4 v.sel        v11, v10, v2
    v.and        v10, v12, v1
    s.addi       s6, s5, #576
    v.sub        v1, v4, v10
    v.splat      v12, s6
    @p3 v.sel        v13, v1, v10
    s.addi       s6, s3, #640
    v.add        v1, v13, v12
    v.st.w       [s16, #0], v9
    v.sub        v9, v0, v3
    v.cmp.lt     p3, v3, v4
    @p2 v.sel        v4, v7, v3
    v.movi       v4, #0
    v.movi       v7, #63
    v.sub        v10, v4, v2
    v.cmp.lt     p2, v2, v4
    @p2 v.sel        v12, v10, v2
    v.and        v10, v11, v7
    s.addi       s16, s5, #640
    v.sub        v7, v0, v10
    v.splat      v11, s16
    @p4 v.sel        v13, v7, v10
    s.addi       s16, s3, #704
    v.add        v7, v13, v11
    v.st.w       [s17, #0], v8
    v.sub        v8, v4, v3
    v.cmp.lt     p4, v3, v0
    @p1 v.sel        v0, v5, v3
    v.movi       v0, #0
    v.movi       v5, #63
    v.sub        v10, v0, v2
    v.cmp.lt     p1, v2, v0
    @p1 v.sel        v11, v10, v2
    v.and        v10, v12, v5
    s.addi       s17, s5, #704
    v.sub        v5, v4, v10
    v.splat      v12, s17
    @p2 v.sel        v13, v5, v10
    s.addi       s17, s3, #768
    v.add        v5, v13, v12
    v.st.w       [s7, #0], v1
    v.sub        v1, v0, v3
    v.cmp.lt     p2, v3, v4
    @p3 v.sel        v4, v6, v3
    v.movi       v4, #0
    v.movi       v6, #63
    v.sub        v10, v4, v2
    v.cmp.lt     p3, v2, v4
    @p3 v.sel        v12, v10, v2
    v.and        v10, v11, v6
    s.addi       s7, s5, #768
    v.sub        v6, v0, v10
    v.splat      v11, s7
    @p1 v.sel        v13, v6, v10
    s.addi       s7, s3, #832
    v.add        v6, v13, v11
    v.st.w       [s6, #0], v7
    v.sub        v7, v4, v3
    v.cmp.lt     p1, v3, v0
    @p4 v.sel        v0, v9, v3
    v.movi       v0, #0
    v.movi       v9, #63
    v.sub        v10, v0, v2
    v.cmp.lt     p4, v2, v0
    @p4 v.sel        v11, v10, v2
    v.and        v10, v12, v9
    s.addi       s6, s5, #832
    v.sub        v9, v4, v10
    v.splat      v12, s6
    @p3 v.sel        v13, v9, v10
    s.addi       s6, s3, #896
    v.add        v9, v13, v12
    v.st.w       [s16, #0], v5
    v.sub        v5, v0, v3
    v.cmp.lt     p3, v3, v4
    @p2 v.sel        v4, v8, v3
    v.movi       v4, #0
    v.movi       v8, #63
    v.sub        v10, v4, v2
    v.cmp.lt     p2, v2, v4
    @p2 v.sel        v12, v10, v2
    v.and        v10, v11, v8
    s.addi       s16, s5, #896
    v.sub        v8, v0, v10
    v.splat      v11, s16
    @p4 v.sel        v13, v8, v10
    s.addi       s16, s3, #960
    v.add        v8, v13, v11
    v.st.w       [s17, #0], v6
    v.sub        v6, v4, v3
    v.cmp.lt     p4, v3, v0
    @p1 v.sel        v0, v1, v3
    v.movi       v0, #63
    s.addi       s3, s5, #960
    v.and        v1, v12, v0
    v.splat      v0, s3
    v.sub        v10, v4, v1
    s.addi       s3, s2, #0
    @p2 v.sel        v11, v10, v1
    v.st.w       [s7, #0], v9
    v.add        v1, v11, v0
    s.movz       s5, #0
    s.addi       s7, s2, #1024
    v.splat      v0, s5
    v.cmp.lt     p1, v3, v4
    @p3 v.sel        v4, v7, v3
    s.addi       s17, s2, #64
    s.addi       s18, s7, #64
    s.addi       s19, s2, #128
    v.st.w       [s6, #0], v8
    s.addi       s6, s7, #128
    @p4 v.sel        v4, v5, v3
    @p1 v.sel        v4, v6, v3
    v.st.w       [s16, #0], v1
    fence.acq_rel.device
    s.addi       s16, s2, #192
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s7, #192
    v.add        v4, v0, v1
    v.st.w       [s7, #0], v4
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s2, #256
    v.add        v4, v0, v1
    v.st.w       [s18, #0], v4
    s.addi       s18, s7, #256
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s2, #320
    v.add        v4, v0, v1
    v.st.w       [s6, #0], v4
    s.addi       s6, s7, #320
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s2, #384
    v.add        v4, v0, v1
    v.st.w       [s3, #0], v4
    s.addi       s3, s7, #384
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s2, #448
    v.add        v4, v0, v1
    v.st.w       [s18, #0], v4
    s.addi       s18, s7, #448
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s2, #512
    v.add        v4, v0, v1
    v.st.w       [s6, #0], v4
    s.addi       s6, s7, #512
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s2, #576
    v.add        v4, v0, v1
    v.st.w       [s3, #0], v4
    s.addi       s3, s7, #576
    v.cmpi.lt    p1, v2, #1024
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s2, #640
    v.add        v4, v0, v1
    v.st.w       [s18, #0], v4
    s.addi       s18, s7, #640
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s2, #704
    v.add        v4, v0, v1
    v.st.w       [s6, #0], v4
    s.addi       s6, s7, #704
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s2, #768
    v.add        v4, v0, v1
    v.st.w       [s3, #0], v4
    s.addi       s3, s7, #768
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s2, #832
    v.add        v4, v0, v1
    v.st.w       [s18, #0], v4
    s.addi       s18, s7, #832
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s2, #896
    v.add        v4, v0, v1
    v.st.w       [s6, #0], v4
    s.addi       s6, s7, #896
    s.addi       s20, s7, #960
    v.ld.w       v1, [s16, #0]
    s.addi       s7, s2, #960
    v.add        v4, v0, v1
    v.st.w       [s3, #0], v4
    s.addi       s3, s2, #1024
    v.ld.w       v1, [s17, #0]
    s.movz       s16, #0
    s.add        s17, s16, s4                    // the tile origin
    v.splat      v4, s17
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    v.add        v4, v0, v1
    v.st.w       [s18, #0], v4
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s16, #0
    v.ld.w       v1, [s19, #0]
    s.addi       s18, s2, #1088
    v.add        v4, v0, v1
    v.st.w       [s6, #0], v4
    s.addi       s6, s17, #1
    v.splat      v1, s6
    s.movz       s6, #1
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s2, #1152
    v.add        v4, v0, v1
    v.st.w       [s20, #0], v4
    fence.acq_rel.device
    s.addi       s19, s17, #2
    v.splat      v0, s19
    s.movz       s19, #2
    v.cmpi.lt    p2, v0, #256
    p.and        p5, p1, p2
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #1216
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s16, v1
    v.ld.w       v0, [s18, #0]
    s.addi       s16, s17, #3
    s.movz       s18, #3
    v.splat      v1, s16
    s.addi       s16, s2, #1280
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s6, v1
    v.ld.w       v0, [s7, #0]
    s.addi       s6, s17, #4
    s.movz       s7, #4
    v.splat      v1, s6
    s.addi       s6, s2, #1344
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s19, v1
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s17, #5
    s.movz       s19, #5
    v.splat      v1, s3
    s.addi       s3, s2, #1408
    v.cmpi.lt    p2, v1, #256
    p.and        p5, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s18, v1
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s17, #6
    s.movz       s18, #6
    v.splat      v1, s16
    s.addi       s16, s2, #1472
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s7, v1
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s17, #7
    s.movz       s7, #7
    v.splat      v1, s6
    s.addi       s6, s2, #1536
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s19, v1
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s17, #8
    s.movz       s19, #8
    v.splat      v1, s3
    s.addi       s3, s2, #1600
    v.cmpi.lt    p2, v1, #256
    p.and        p5, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s18, v1
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s17, #9
    s.movz       s18, #9
    v.splat      v1, s16
    s.addi       s16, s2, #1664
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s7, v1
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s17, #10
    s.movz       s7, #10
    v.splat      v1, s6
    s.addi       s6, s2, #1728
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s19, v1
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s17, #11
    s.movz       s19, #11
    v.splat      v1, s3
    s.addi       s3, s2, #1792
    v.cmpi.lt    p2, v1, #256
    p.and        p5, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s18, v1
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s17, #12
    s.movz       s18, #12
    v.splat      v1, s16
    s.addi       s16, s2, #1856
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v1, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s7, v1
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s17, #13
    s.movz       s7, #13
    v.splat      v1, s6
    s.addi       s6, s2, #1920
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    v.splat      v1, s5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s19, v4
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s17, #14
    s.movz       s19, #14
    v.splat      v4, s3
    s.addi       s3, s2, #1984
    v.cmpi.lt    p2, v4, #256
    p.and        p5, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s18, v4
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s17, #15
    s.movz       s18, #15
    v.splat      v4, s16
    s.addi       s16, s2, #0
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s7, v4
    v.ld.w       v0, [s6, #0]
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.addi       s6, s2, #2048
    s.addi       s7, s2, #64
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s10, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s19, v4
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s6, #64
    s.addi       s19, s2, #128
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s10, v0]              // index is in elements (ISA sec 9.1)
    s.addi       s10, s6, #128
    a.vwrite     a0, s18, v4
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s2, #192
    s.addi       s18, s6, #192
    v.add        v4, v1, v0
    v.st.w       [s6, #0], v4
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #256
    v.add        v4, v1, v0
    v.st.w       [s3, #0], v4
    s.addi       s3, s6, #256
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #320
    v.add        v4, v1, v0
    v.st.w       [s10, #0], v4
    s.addi       s10, s6, #320
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s2, #384
    v.add        v4, v1, v0
    v.st.w       [s18, #0], v4
    s.addi       s18, s6, #384
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #448
    v.add        v4, v1, v0
    v.st.w       [s3, #0], v4
    s.addi       s3, s6, #448
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #512
    v.add        v4, v1, v0
    v.st.w       [s10, #0], v4
    s.addi       s10, s6, #512
    v.ld.w       v0, [s16, #0]
    s.muli       s16, s1, #4                     // a runtime tile origin, x4
    s.add        s20, s12, s16                   // the tile origin
    s.muli       s12, s4, #4096                  // a runtime tile origin, x4096
    v.add        v4, v1, v0
    v.st.w       [s18, #0], v4
    s.addi       s16, s6, #576
    s.add        s18, s20, s12                   // the tile origin
    s.addi       s12, s2, #576
    v.splat      v0, s17
    v.ld.w       v4, [s7, #0]
    s.addi       s7, s2, #640
    v.cmpi.lt    p2, v0, #256
    v.add        v0, v1, v4
    p.and        p3, p1, p2
    v.st.w       [s3, #0], v0
    s.addi       s3, s6, #640
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #704
    v.add        v4, v1, v0
    v.st.w       [s10, #0], v4
    s.addi       s10, s6, #704
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s2, #768
    v.add        v4, v1, v0
    v.st.w       [s16, #0], v4
    s.addi       s16, s6, #768
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #832
    v.add        v4, v1, v0
    v.st.w       [s3, #0], v4
    s.addi       s3, s6, #832
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s2, #896
    v.add        v4, v1, v0
    v.st.w       [s10, #0], v4
    s.addi       s10, s6, #896
    s.addi       s20, s6, #960
    v.ld.w       v0, [s12, #0]
    s.addi       s6, s2, #960
    v.add        v4, v1, v0
    v.st.w       [s16, #0], v4
    s.addi       s12, s2, #2048
    v.ld.w       v0, [s7, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s7, #0
    v.add        v4, v1, v0
    v.st.w       [s3, #0], v4
    s.addi       s3, s2, #2112
    v.ld.w       v0, [s19, #0]
    s.addi       s16, s17, #1
    v.splat      v4, s16
    s.movz       s16, #1
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    v.add        v4, v1, v0
    v.st.w       [s10, #0], v4
    s.addi       s10, s2, #2176
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s17, #2
    v.splat      v4, s6
    s.movz       s6, #2
    v.cmpi.lt    p2, v4, #256
    p.and        p5, p1, p2
    v.add        v4, v1, v0
    v.st.w       [s20, #0], v4
    fence.acq_rel.device
    s.addi       s19, s2, #2240
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s17, #3
    v.splat      v1, s12
    s.movz       s12, #3
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    a.vwrite     a1, s7, v4
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #2304
    s.addi       s7, s17, #4
    v.splat      v1, s7
    s.movz       s7, #4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    a.vwrite     a1, s16, v4
    v.ld.w       v0, [s10, #0]
    s.addi       s10, s2, #2368
    s.addi       s16, s17, #5
    v.splat      v1, s16
    s.movz       s16, #5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p5, p1, p2
    a.vwrite     a1, s6, v4
    v.ld.w       v0, [s19, #0]
    s.addi       s6, s2, #2432
    s.addi       s19, s17, #6
    v.splat      v1, s19
    s.movz       s19, #6
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    a.vwrite     a1, s12, v4
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #2496
    s.addi       s12, s17, #7
    v.splat      v1, s12
    s.movz       s12, #7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    a.vwrite     a1, s7, v4
    v.ld.w       v0, [s10, #0]
    s.addi       s7, s2, #2560
    s.addi       s10, s17, #8
    v.splat      v1, s10
    s.movz       s10, #8
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p5, p1, p2
    a.vwrite     a1, s16, v4
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s2, #2624
    s.addi       s16, s17, #9
    v.splat      v1, s16
    s.movz       s16, #9
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    a.vwrite     a1, s19, v4
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #2688
    s.addi       s19, s17, #10
    v.splat      v1, s19
    s.movz       s19, #10
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    a.vwrite     a1, s12, v4
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #2752
    s.addi       s12, s17, #11
    v.splat      v1, s12
    s.movz       s12, #11
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p5, p1, p2
    a.vwrite     a1, s10, v4
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s2, #2816
    s.addi       s10, s17, #12
    v.splat      v1, s10
    s.movz       s10, #12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    a.vwrite     a1, s16, v4
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #2880
    s.addi       s16, s17, #13
    s.addi       s20, s8, #2048                  // the tile's origin
    v.splat      v1, s16
    s.movz       s8, #13
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #256
    p.and        p4, p1, p2
    a.vwrite     a1, s19, v4
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s2, #2944
    s.addi       s16, s17, #14
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    .li       s19, #1052050675
    v.splat      v1, s19                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v4, s16
    s.movz       s16, #14
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v5, [s14, v0]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v4, #256
    p.and        p5, p1, p2
    .li       s19, #1052050675
    v.splat      v0, s19                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    a.vwrite     a1, s12, v5
    v.ld.w       v4, [s6, #0]
    s.addi       s6, s2, #3008
    s.addi       s12, s17, #15
    v.splat      v5, s17
    v.splat      v6, s12
    s.muli       s12, s1, #2                     // a runtime tile origin, x2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s14, v4]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v6, #256
    p.and        p3, p1, p2
    s.add        s19, s20, s12                   // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s12, s1, #4                     // a runtime tile origin, x4
    s.add        s20, s9, s12                    // the tile origin
    a.vwrite     a1, s10, v7
    v.ld.w       v4, [s3, #0]
    s.muli       s3, s4, #6144                   // a runtime tile origin, x6144
    s.muli       s9, s4, #4096                   // a runtime tile origin, x4096
    v.splat      v6, s17
    s.movz       s10, #15
    s.add        s12, s19, s3                    // the tile origin
    s.add        s3, s20, s9                     // the tile origin
    s.movz       s9, #0
    s.movz       s19, #0
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v7, [s14, v4]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v5, #256
    p.and        p4, p1, p2
    a.vwrite     a1, s8, v7
    v.ld.w       v4, [s7, #0]
    s.addi       s7, s17, #1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s8, #0
    v.splat      v5, s7
    s.addi       s7, s12, #6144                  // row 1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v7, [s14, v4]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v6, #256
    p.and        p5, p1, p2
    a.vwrite     a1, s16, v7
    v.ld.w       v4, [s6, #0]
    s.addi       s6, s17, #1
    s.movz       s16, #1
    v.splat      v6, s6
    s.addi       s6, s3, #4096                   // row 1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s14, v4]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    s.movz       s14, #1
    a.vwrite     a1, s10, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s12, #0]
    a.vread      v5, a0, s9
    v.cmpi.lt    p2, v6, #256
    p.and        p4, p1, p2
    s.movz       s9, #1
    s.addi       s10, s17, #2
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v6, [s3, #0]
    vf.cvt.bf16.f32 v7, v4
    a.vread      v4, a1, s19
    s.addi       s19, s17, #2
    v.splat      v8, s10
    vf.mul       v9, v7, v5
    v.splat      v5, s19
    v.cmpi.lt    p2, v8, #256
    s.addi       s10, s12, #12288                // row 2
    p.and        p5, p1, p2
    vf.mul       v7, v6, v4
    s.movz       s19, #2
    vf.add       v4, v9, v7
    vf.mul       v6, v4, v0
    a.vwrite     a2, s8, v6
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s7, #0]
    a.vread      v6, a0, s16
    v.cmpi.lt    p2, v5, #256
    s.addi       s7, s3, #8192                   // row 2
    p.and        p3, p1, p2
    s.movz       s8, #2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s6, #0]
    vf.cvt.bf16.f32 v7, v4
    a.vread      v4, a1, s9
    s.addi       s6, s17, #3
    s.movz       s9, #2
    vf.mul       v8, v7, v6
    s.addi       s16, s17, #3
    v.splat      v6, s6
    v.splat      v7, s16
    v.cmpi.lt    p2, v6, #256
    vf.mul       v6, v5, v4
    s.addi       s6, s12, #18432                 // row 3
    p.and        p4, p1, p2
    s.movz       s16, #3
    vf.add       v4, v8, v6
    vf.mul       v5, v4, v0
    a.vwrite     a2, s14, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s10, #0]
    a.vread      v5, a0, s19
    v.cmpi.lt    p2, v7, #256
    s.addi       s10, s3, #12288                 // row 3
    p.and        p5, p1, p2
    s.movz       s14, #3
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s7, #0]
    vf.cvt.bf16.f32 v7, v4
    a.vread      v4, a1, s8
    s.addi       s7, s17, #4
    s.movz       s8, #3
    vf.mul       v8, v7, v5
    s.addi       s19, s17, #4
    v.splat      v5, s7
    v.splat      v7, s19
    v.cmpi.lt    p2, v5, #256
    vf.mul       v5, v6, v4
    s.addi       s7, s12, #24576                 // row 4
    p.and        p3, p1, p2
    s.movz       s19, #4
    vf.add       v4, v8, v5
    vf.mul       v5, v4, v0
    a.vwrite     a2, s9, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s6, #0]
    a.vread      v5, a0, s16
    v.cmpi.lt    p2, v7, #256
    s.addi       s6, s3, #16384                  // row 4
    p.and        p4, p1, p2
    s.movz       s9, #4
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v6, [s10, #0]
    vf.cvt.bf16.f32 v7, v4
    a.vread      v4, a1, s14
    s.addi       s10, s17, #5
    s.movz       s14, #4
    vf.mul       v8, v7, v5
    s.addi       s16, s17, #5
    v.splat      v5, s10
    v.splat      v7, s16
    v.cmpi.lt    p2, v5, #256
    vf.mul       v5, v6, v4
    s.addi       s10, s12, #30720                // row 5
    p.and        p5, p1, p2
    s.movz       s16, #5
    vf.add       v4, v8, v5
    vf.mul       v5, v4, v0
    a.vwrite     a2, s8, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s7, #0]
    a.vread      v5, a0, s19
    v.cmpi.lt    p2, v7, #256
    s.addi       s7, s3, #20480                  // row 5
    p.and        p3, p1, p2
    s.movz       s8, #5
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s6, #0]
    vf.cvt.bf16.f32 v7, v4
    a.vread      v4, a1, s9
    s.addi       s6, s17, #6
    s.movz       s9, #36864
    vf.mul       v8, v7, v5
    s.addi       s19, s17, #6
    v.splat      v5, s6
    v.splat      v7, s19
    v.cmpi.lt    p2, v5, #256
    vf.mul       v5, v6, v4
    s.movz       s6, #5
    s.add        s19, s12, s9                    // row 6
    p.and        p4, p1, p2
    vf.add       v4, v8, v5
    s.movz       s9, #6
    vf.mul       v5, v4, v0
    a.vwrite     a2, s14, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s10, #0]
    a.vread      v5, a0, s16
    v.cmpi.lt    p2, v7, #256
    s.addi       s10, s3, #24576                 // row 6
    p.and        p5, p1, p2
    s.movz       s14, #6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s7, #0]
    vf.cvt.bf16.f32 v7, v4
    a.vread      v4, a1, s8
    s.addi       s7, s17, #7
    s.movz       s8, #43008
    vf.mul       v8, v7, v5
    s.addi       s16, s17, #7
    v.splat      v5, s7
    v.splat      v7, s16
    v.cmpi.lt    p2, v5, #256
    vf.mul       v5, v6, v4
    s.movz       s7, #6
    s.add        s16, s12, s8                    // row 7
    p.and        p3, p1, p2
    vf.add       v4, v8, v5
    s.movz       s8, #7
    vf.mul       v5, v4, v0
    a.vwrite     a2, s6, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s19, #0]
    a.vread      v5, a0, s9
    v.cmpi.lt    p2, v7, #256
    s.addi       s6, s3, #28672                  // row 7
    p.and        p4, p1, p2
    s.movz       s9, #7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v6, [s10, #0]
    vf.cvt.bf16.f32 v7, v4
    a.vread      v4, a1, s14
    s.addi       s10, s17, #8
    s.movz       s14, #49152
    vf.mul       v8, v7, v5
    s.addi       s19, s17, #8
    v.splat      v5, s10
    v.splat      v7, s19
    s.movz       s10, #32768
    vf.mul       v9, v6, v4
    v.cmpi.lt    p2, v5, #256
    s.movz       s19, #7
    s.add        s20, s12, s14                   // row 8
    vf.add       v4, v8, v9
    p.and        p5, p1, p2
    s.add        s14, s3, s10                    // row 8
    vf.mul       v5, v4, v0
    a.vwrite     a2, s7, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s16, #0]
    a.vread      v5, a0, s8
    v.cmpi.lt    p2, v7, #256
    s.movz       s7, #8
    p.and        p3, p1, p2
    s.movz       s8, #8
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s6, #0]
    vf.cvt.bf16.f32 v7, v4
    a.vread      v4, a1, s9
    s.addi       s6, s17, #9
    s.movz       s9, #55296
    vf.mul       v8, v7, v5
    s.addi       s10, s17, #9
    v.splat      v5, s6
    v.splat      v7, s10
    s.movz       s6, #36864
    vf.mul       v9, v6, v4
    v.cmpi.lt    p2, v5, #256
    s.movz       s10, #8
    s.add        s16, s12, s9                    // row 9
    vf.add       v4, v8, v9
    p.and        p4, p1, p2
    s.add        s9, s3, s6                      // row 9
    vf.mul       v5, v4, v0
    a.vwrite     a2, s19, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s20, #0]
    a.vread      v5, a0, s7
    v.cmpi.lt    p2, v7, #256
    s.movz       s6, #9
    p.and        p5, p1, p2
    s.movz       s7, #9
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s14, #0]
    vf.cvt.bf16.f32 v7, v4
    a.vread      v4, a1, s8
    s.addi       s8, s17, #10
    s.movz       s14, #61440
    vf.mul       v8, v7, v5
    s.addi       s19, s17, #10
    v.splat      v5, s8
    v.splat      v7, s19
    s.movz       s8, #40960
    vf.mul       v9, v6, v4
    v.cmpi.lt    p2, v5, #256
    s.movz       s19, #9
    s.add        s20, s12, s14                   // row 10
    vf.add       v4, v8, v9
    p.and        p3, p1, p2
    s.add        s14, s3, s8                     // row 10
    vf.mul       v5, v4, v0
    a.vwrite     a2, s10, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s16, #0]
    a.vread      v5, a0, s6
    v.cmpi.lt    p2, v7, #256
    s.movz       s6, #10
    p.and        p4, p1, p2
    s.movz       s8, #10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v6, [s9, #0]
    vf.cvt.bf16.f32 v7, v4
    a.vread      v4, a1, s7
    s.addi       s7, s17, #11
    .li       s9, #67584
    vf.mul       v8, v7, v5
    s.addi       s10, s17, #11
    v.splat      v5, s7
    v.splat      v7, s10
    s.movz       s7, #45056
    vf.mul       v9, v6, v4
    v.cmpi.lt    p2, v5, #256
    s.movz       s10, #10
    s.add        s16, s12, s9                    // row 11
    vf.add       v4, v8, v9
    p.and        p5, p1, p2
    s.add        s9, s3, s7                      // row 11
    vf.mul       v5, v4, v0
    a.vwrite     a2, s19, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s20, #0]
    a.vread      v5, a0, s6
    v.cmpi.lt    p2, v7, #256
    s.movz       s6, #11
    p.and        p3, p1, p2
    s.movz       s7, #11
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s14, #0]
    vf.cvt.bf16.f32 v7, v4
    a.vread      v4, a1, s8
    s.addi       s8, s17, #12
    .li       s14, #73728
    vf.mul       v8, v7, v5
    s.addi       s19, s17, #12
    v.splat      v5, s8
    v.splat      v7, s19
    s.movz       s8, #49152
    vf.mul       v9, v6, v4
    v.cmpi.lt    p2, v5, #256
    s.movz       s19, #11
    s.add        s20, s12, s14                   // row 12
    vf.add       v4, v8, v9
    p.and        p4, p1, p2
    s.add        s14, s3, s8                     // row 12
    vf.mul       v5, v4, v0
    a.vwrite     a2, s10, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s16, #0]
    a.vread      v5, a0, s6
    v.cmpi.lt    p2, v7, #256
    s.movz       s6, #12
    p.and        p5, p1, p2
    s.movz       s8, #12
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s9, #0]
    vf.cvt.bf16.f32 v7, v4
    a.vread      v4, a1, s7
    s.addi       s7, s17, #13
    .li       s9, #79872
    vf.mul       v8, v7, v5
    s.addi       s10, s17, #13
    v.splat      v5, s7
    v.splat      v7, s10
    s.movz       s7, #53248
    vf.mul       v9, v6, v4
    v.cmpi.lt    p2, v5, #256
    s.movz       s10, #12
    s.add        s16, s12, s9                    // row 13
    vf.add       v4, v8, v9
    p.and        p3, p1, p2
    s.add        s9, s3, s7                      // row 13
    vf.mul       v5, v4, v0
    a.vwrite     a2, s19, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s20, #0]
    a.vread      v5, a0, s6
    v.cmpi.lt    p2, v7, #256
    s.movz       s6, #13
    p.and        p4, p1, p2
    s.movz       s7, #13
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p5 v.ld.w       v6, [s14, #0]
    vf.cvt.bf16.f32 v7, v4
    a.vread      v4, a1, s8
    s.addi       s8, s17, #14
    .li       s14, #86016
    vf.mul       v8, v7, v5
    s.addi       s19, s17, #14
    v.splat      v5, s8
    v.splat      v7, s19
    s.movz       s8, #57344
    vf.mul       v9, v6, v4
    v.cmpi.lt    p2, v5, #256
    s.movz       s19, #13
    s.add        s20, s12, s14                   // row 14
    vf.add       v4, v8, v9
    p.and        p5, p1, p2
    s.add        s14, s3, s8                     // row 14
    vf.mul       v5, v4, v0
    a.vwrite     a2, s10, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s16, #0]
    a.vread      v5, a0, s6
    v.cmpi.lt    p2, v7, #256
    s.movz       s6, #14
    p.and        p3, p1, p2
    s.movz       s8, #14
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s9, #0]
    vf.cvt.bf16.f32 v7, v4
    a.vread      v4, a1, s7
    s.addi       s7, s17, #15
    .li       s9, #92160
    vf.mul       v8, v7, v5
    s.addi       s10, s17, #15
    v.splat      v5, s7
    v.splat      v7, s10
    s.movz       s7, #61440
    vf.mul       v9, v6, v4
    v.cmpi.lt    p2, v5, #256
    s.movz       s10, #14
    s.add        s16, s12, s9                    // row 15
    vf.add       v4, v8, v9
    p.and        p4, p1, p2
    s.movz       s9, #15
    s.add        s12, s3, s7                     // row 15
    vf.mul       v5, v4, v0
    s.movz       s3, #15
    a.vwrite     a2, s19, v5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s20, #0]
    a.vread      v5, a0, s6
    v.cmpi.lt    p2, v7, #256
    p.and        p5, p1, p2
    v.movi       v6, #0
    s.movz       s6, #15
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v7, [s14, #0]
    vf.cvt.bf16.f32 v8, v4
    a.vread      v4, a1, s8
    s.addi       s7, s2, #0
    v.sub        v9, v6, v2
    vf.mul       v10, v8, v5
    v.cmp.lt     p2, v2, v6
    @p2 v.sel        v5, v9, v2
    v.movi       v8, #6
    s.movz       s8, #16384
    vf.mul       v9, v7, v4
    v.lshr       v4, v5, v8
    v.splat      v5, s8
    v.sub        v7, v6, v4
    vf.add       v8, v10, v9
    @p2 v.sel        v9, v7, v4
    v.splat      v4, s5
    v.mul        v7, v9, v5
    vf.mul       v9, v8, v0
    s.addi       s5, s2, #3072
    v.sub        v8, v6, v3
    s.addi       s8, s5, #64
    a.vwrite     a2, s10, v9
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v9, [s16, #0]
    a.vread      v10, a0, s9
    v.movi       v11, #0
    s.addi       s9, s2, #64
    v.sub        v12, v11, v2
    v.cmp.lt     p2, v2, v11
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p5 v.ld.w       v13, [s12, #0]
    vf.cvt.bf16.f32 v14, v9
    a.vread      v9, a1, s3
    @p2 v.sel        v15, v12, v2
    v.movi       v12, #6
    vf.mul       v16, v14, v10
    v.lshr       v10, v15, v12
    v.movi       v12, #0
    v.sub        v14, v11, v10
    s.addi       s3, s2, #128
    vf.mul       v15, v13, v9
    @p2 v.sel        v9, v14, v10
    v.cmp.lt     p2, v2, v12
    v.mul        v10, v9, v5
    vf.add       v9, v16, v15
    v.sub        v13, v12, v2
    s.addi       s10, s5, #128
    v.sub        v14, v11, v3
    vf.mul       v15, v9, v0
    @p2 v.sel        v0, v13, v2
    v.cmp.lt     p3, v3, v6
    v.cmp.lt     p4, v3, v11
    a.vwrite     a2, s6, v15
    v.ld.w       v6, [s7, #0]
    v.movi       v9, #6
    s.addi       s6, s5, #192
    v.lshr       v11, v0, v9
    v.sub        v0, v12, v3
    v.sub        v9, v12, v11
    @p3 v.sel        v13, v8, v3
    @p2 v.sel        v8, v9, v11
    v.movi       v9, #0
    v.mul        v11, v8, v5
    v.add        v8, v6, v7
    s.addi       s7, s2, #192
    v.add        v6, v4, v8
    v.sub        v7, v9, v2
    v.st.w       [s5, #0], v6
    v.cmp.lt     p2, v2, v9
    @p2 v.sel        v6, v7, v2
    v.movi       v7, #6
    v.sub        v8, v9, v3
    v.lshr       v13, v6, v7
    v.cmp.lt     p3, v3, v12
    v.sub        v6, v9, v13
    @p4 v.sel        v7, v14, v3
    @p2 v.sel        v7, v6, v13
    v.ld.w       v6, [s9, #0]
    v.mul        v12, v7, v5
    v.movi       v7, #0
    s.addi       s9, s2, #256
    v.sub        v13, v7, v2
    v.cmp.lt     p2, v2, v7
    @p2 v.sel        v14, v13, v2
    s.addi       s12, s5, #256
    v.sub        v13, v7, v3
    v.cmp.lt     p4, v3, v9
    v.add        v9, v6, v10
    @p3 v.sel        v6, v0, v3
    v.add        v0, v4, v9
    v.movi       v6, #6
    v.st.w       [s8, #0], v0
    v.lshr       v0, v14, v6
    v.cmp.lt     p3, v3, v7
    v.sub        v6, v7, v0
    @p4 v.sel        v7, v8, v3
    @p2 v.sel        v7, v6, v0
    @p3 v.sel        v0, v13, v3
    v.ld.w       v0, [s3, #0]
    v.mul        v6, v7, v5
    v.movi       v7, #0
    s.addi       s3, s2, #320
    v.sub        v8, v7, v2
    v.cmp.lt     p2, v2, v7
    @p2 v.sel        v9, v8, v2
    s.addi       s8, s5, #320
    v.sub        v8, v7, v3
    v.cmp.lt     p3, v3, v7
    v.add        v10, v0, v11
    @p3 v.sel        v0, v8, v3
    v.add        v0, v4, v10
    v.movi       v8, #6
    v.st.w       [s10, #0], v0
    v.lshr       v0, v9, v8
    v.sub        v8, v7, v0
    @p2 v.sel        v7, v8, v0
    v.ld.w       v0, [s7, #0]
    v.mul        v8, v7, v5
    v.movi       v7, #0
    s.addi       s7, s2, #384
    v.sub        v9, v7, v2
    v.cmp.lt     p2, v2, v7
    @p2 v.sel        v10, v9, v2
    s.addi       s10, s5, #384
    v.sub        v9, v7, v3
    v.cmp.lt     p3, v3, v7
    v.add        v11, v0, v12
    @p3 v.sel        v0, v9, v3
    v.add        v0, v4, v11
    v.movi       v9, #6
    v.st.w       [s6, #0], v0
    v.lshr       v0, v10, v9
    v.sub        v9, v7, v0
    @p2 v.sel        v7, v9, v0
    v.ld.w       v0, [s9, #0]
    v.mul        v9, v7, v5
    v.movi       v7, #0
    s.addi       s6, s2, #448
    v.sub        v10, v7, v2
    v.cmp.lt     p2, v2, v7
    @p2 v.sel        v11, v10, v2
    s.addi       s9, s5, #448
    v.sub        v10, v7, v3
    v.cmp.lt     p3, v3, v7
    v.add        v12, v0, v6
    @p3 v.sel        v0, v10, v3
    v.add        v0, v4, v12
    v.movi       v6, #6
    v.st.w       [s12, #0], v0
    v.lshr       v0, v11, v6
    v.sub        v6, v7, v0
    @p2 v.sel        v7, v6, v0
    v.ld.w       v0, [s3, #0]
    v.mul        v6, v7, v5
    v.movi       v7, #0
    s.addi       s3, s2, #512
    v.sub        v10, v7, v2
    v.cmp.lt     p2, v2, v7
    @p2 v.sel        v11, v10, v2
    s.addi       s12, s5, #512
    v.sub        v10, v7, v3
    v.cmp.lt     p3, v3, v7
    v.add        v12, v0, v8
    @p3 v.sel        v0, v10, v3
    v.add        v0, v4, v12
    v.movi       v8, #6
    v.st.w       [s8, #0], v0
    v.lshr       v0, v11, v8
    v.sub        v8, v7, v0
    @p2 v.sel        v7, v8, v0
    v.ld.w       v0, [s7, #0]
    v.mul        v8, v7, v5
    v.movi       v7, #0
    s.addi       s7, s2, #576
    v.sub        v10, v7, v2
    v.cmp.lt     p2, v2, v7
    @p2 v.sel        v11, v10, v2
    s.addi       s8, s5, #576
    v.sub        v10, v7, v3
    v.cmp.lt     p3, v3, v7
    v.add        v12, v0, v9
    @p3 v.sel        v0, v10, v3
    v.add        v0, v4, v12
    v.movi       v9, #6
    v.st.w       [s10, #0], v0
    v.lshr       v0, v11, v9
    v.sub        v9, v7, v0
    @p2 v.sel        v7, v9, v0
    v.ld.w       v0, [s6, #0]
    v.mul        v9, v7, v5
    v.movi       v7, #0
    s.addi       s6, s2, #640
    v.sub        v10, v7, v2
    v.cmp.lt     p2, v2, v7
    @p2 v.sel        v11, v10, v2
    s.addi       s10, s5, #640
    v.sub        v10, v7, v3
    v.cmp.lt     p3, v3, v7
    v.add        v12, v0, v6
    @p3 v.sel        v0, v10, v3
    v.add        v0, v4, v12
    v.movi       v6, #6
    v.st.w       [s9, #0], v0
    v.lshr       v0, v11, v6
    v.sub        v6, v7, v0
    @p2 v.sel        v7, v6, v0
    v.ld.w       v0, [s3, #0]
    v.mul        v6, v7, v5
    v.movi       v7, #0
    s.addi       s3, s2, #704
    v.sub        v10, v7, v2
    v.cmp.lt     p2, v2, v7
    @p2 v.sel        v11, v10, v2
    s.addi       s9, s5, #704
    v.sub        v10, v7, v3
    v.cmp.lt     p3, v3, v7
    v.add        v12, v0, v8
    @p3 v.sel        v0, v10, v3
    v.add        v0, v4, v12
    v.movi       v8, #6
    v.st.w       [s12, #0], v0
    v.lshr       v0, v11, v8
    v.sub        v8, v7, v0
    @p2 v.sel        v7, v8, v0
    v.ld.w       v0, [s7, #0]
    v.mul        v8, v7, v5
    v.movi       v7, #0
    s.addi       s7, s2, #768
    v.sub        v10, v7, v2
    v.cmp.lt     p2, v2, v7
    @p2 v.sel        v11, v10, v2
    s.addi       s12, s5, #768
    v.sub        v10, v7, v3
    v.cmp.lt     p3, v3, v7
    v.add        v12, v0, v9
    @p3 v.sel        v0, v10, v3
    v.add        v0, v4, v12
    v.movi       v9, #6
    v.st.w       [s8, #0], v0
    v.lshr       v0, v11, v9
    v.sub        v9, v7, v0
    @p2 v.sel        v7, v9, v0
    v.ld.w       v0, [s6, #0]
    v.mul        v9, v7, v5
    v.movi       v7, #0
    s.addi       s6, s2, #832
    v.sub        v10, v7, v2
    v.cmp.lt     p2, v2, v7
    @p2 v.sel        v11, v10, v2
    s.addi       s8, s5, #832
    v.sub        v10, v7, v3
    v.cmp.lt     p3, v3, v7
    v.add        v12, v0, v6
    @p3 v.sel        v0, v10, v3
    v.add        v0, v4, v12
    v.movi       v6, #6
    v.st.w       [s10, #0], v0
    v.lshr       v0, v11, v6
    v.sub        v6, v7, v0
    @p2 v.sel        v7, v6, v0
    v.ld.w       v0, [s3, #0]
    v.mul        v6, v7, v5
    v.movi       v7, #0
    s.addi       s3, s2, #896
    v.sub        v10, v7, v2
    v.cmp.lt     p2, v2, v7
    @p2 v.sel        v11, v10, v2
    s.addi       s10, s5, #896
    v.sub        v10, v7, v3
    v.cmp.lt     p3, v3, v7
    v.add        v12, v0, v8
    @p3 v.sel        v0, v10, v3
    v.add        v0, v4, v12
    v.movi       v8, #6
    v.st.w       [s9, #0], v0
    v.lshr       v0, v11, v8
    v.sub        v8, v7, v0
    @p2 v.sel        v7, v8, v0
    v.ld.w       v0, [s7, #0]
    v.mul        v8, v7, v5
    v.movi       v7, #0
    s.addi       s7, s2, #960
    v.sub        v10, v7, v2
    v.cmp.lt     p2, v2, v7
    @p2 v.sel        v11, v10, v2
    s.addi       s9, s5, #960
    v.sub        v2, v7, v3
    v.cmp.lt     p3, v3, v7
    v.add        v10, v0, v9
    @p3 v.sel        v0, v2, v3
    v.add        v0, v4, v10
    v.movi       v2, #6
    v.st.w       [s12, #0], v0
    v.lshr       v0, v11, v2
    v.sub        v2, v7, v0
    @p2 v.sel        v3, v2, v0
    v.ld.w       v0, [s6, #0]
    v.mul        v2, v3, v5
    v.splat      v3, s17
    s.movz       s5, #0
    v.cmpi.lt    p2, v3, #256
    p.and        p3, p1, p2
    v.add        v3, v0, v6
    v.splat      v0, s17
    v.add        v5, v4, v3
    v.cmpi.lt    p2, v0, #256
    v.st.w       [s8, #0], v5
    p.and        p4, p1, p2
    s.movz       s6, #0
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s2, #3072
    s.addi       s8, s17, #1
    v.splat      v3, s17
    v.splat      v5, s8
    v.cmpi.lt    p2, v3, #256
    p.and        p5, p1, p2
    s.addi       s8, s15, #6144                  // row 1
    v.add        v3, v0, v8
    v.add        v0, v4, v3
    v.st.w       [s10, #0], v0
    s.movz       s10, #1
    v.ld.w       v0, [s7, #0]
    s.addi       s7, s17, #1
    s.addi       s12, s18, #4096                 // row 1
    v.splat      v3, s7
    s.movz       s7, #1
    v.add        v6, v0, v2
    s.addi       s14, s2, #3136
    v.add        v0, v4, v6
    v.st.w       [s9, #0], v0
    fence.acq_rel.device
    s.addi       s9, s17, #1
    v.splat      v0, s9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s15, #0]
    a.vread      v4, a0, s5
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    s.addi       s5, s15, #12288                 // row 2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s18, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s6
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    vf.mul       v3, v6, v4
    s.addi       s6, s17, #2
    s.movz       s9, #2
    v.splat      v4, s6
    s.addi       s6, s18, #8192                  // row 2
    vf.mul       v6, v5, v2
    v.ld.w       v2, [s3, #0]
    s.addi       s3, s17, #2
    vf.add       v5, v3, v6
    v.splat      v3, s3
    vf.mul       v6, v5, v1
    s.movz       s3, #2
    @p5 v.st.scatter.w [s11, v2], v6
    v.cmpi.lt    p2, v0, #256
    p.and        p5, p1, p2
    s.addi       s16, s2, #3200
    s.addi       s19, s17, #2
    v.splat      v0, s19
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s8, #0]
    a.vread      v5, a0, s10
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s12, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s7
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    vf.mul       v3, v6, v5
    s.addi       s7, s17, #3
    s.addi       s8, s15, #18432                 // row 3
    v.splat      v5, s7
    s.movz       s7, #3
    vf.mul       v6, v4, v2
    v.ld.w       v2, [s14, #0]
    s.addi       s10, s18, #12288                // row 3
    vf.add       v4, v3, v6
    s.addi       s12, s17, #3
    vf.mul       v3, v4, v1
    v.splat      v4, s12
    s.movz       s12, #3
    @p5 v.st.scatter.w [s11, v2], v3
    v.cmpi.lt    p2, v0, #256
    p.and        p5, p1, p2
    s.addi       s14, s2, #3264
    s.addi       s19, s17, #3
    v.splat      v0, s19
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s5, #0]
    a.vread      v3, a0, s9
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s6, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s3
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    vf.mul       v4, v6, v3
    s.addi       s3, s17, #4
    s.addi       s5, s15, #24576                 // row 4
    v.splat      v3, s3
    s.movz       s3, #4
    vf.mul       v6, v5, v2
    v.ld.w       v2, [s16, #0]
    s.addi       s6, s18, #16384                 // row 4
    vf.add       v5, v4, v6
    s.addi       s9, s17, #4
    vf.mul       v4, v5, v1
    v.splat      v5, s9
    s.movz       s9, #4
    @p5 v.st.scatter.w [s11, v2], v4
    v.cmpi.lt    p2, v0, #256
    p.and        p5, p1, p2
    s.addi       s16, s2, #3328
    s.addi       s19, s17, #4
    v.splat      v0, s19
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s8, #0]
    a.vread      v4, a0, s7
    v.cmpi.lt    p2, v3, #256
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s10, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s12
    v.cmpi.lt    p2, v5, #256
    p.and        p4, p1, p2
    vf.mul       v5, v6, v4
    s.addi       s7, s17, #5
    s.addi       s8, s15, #30720                 // row 5
    v.splat      v4, s7
    s.movz       s7, #5
    vf.mul       v6, v3, v2
    v.ld.w       v2, [s14, #0]
    s.addi       s10, s18, #20480                // row 5
    vf.add       v3, v5, v6
    s.addi       s12, s17, #5
    vf.mul       v5, v3, v1
    v.splat      v3, s12
    s.movz       s12, #5
    @p5 v.st.scatter.w [s11, v2], v5
    v.cmpi.lt    p2, v0, #256
    p.and        p5, p1, p2
    s.addi       s14, s2, #3392
    s.addi       s19, s17, #5
    v.splat      v0, s19
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s5, #0]
    a.vread      v5, a0, s3
    v.cmpi.lt    p2, v4, #256
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s6, #0]
    vf.cvt.bf16.f32 v6, v2
    a.vread      v2, a1, s9
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    vf.mul       v3, v6, v5
    s.addi       s3, s17, #6
    s.movz       s5, #36864
    v.splat      v5, s3
    s.add        s3, s15, s5                     // row 6
    vf.mul       v6, v4, v2
    v.ld.w       v2, [s16, #0]
    s.movz       s5, #6
    vf.add       v4, v3, v6
    s.addi       s6, s18, #24576                 // row 6
    vf.mul       v3, v4, v1
    s.addi       s9, s17, #6
    s.movz       s16, #6
    v.splat      v4, s9
    @p5 v.st.scatter.w [s11, v2], v3
    v.cmpi.lt    p2, v0, #256
    p.and        p5, p1, p2
    s.addi       s9, s2, #3456
    s.addi       s19, s17, #6
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s8, #0]
    a.vread      v2, a0, s7
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.splat      v3, s19
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s10, #0]
    vf.cvt.bf16.f32 v6, v0
    a.vread      v0, a1, s12
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    vf.mul       v4, v6, v2
    s.addi       s7, s17, #7
    s.movz       s8, #43008
    v.splat      v2, s7
    s.add        s7, s15, s8                     // row 7
    vf.mul       v6, v5, v0
    v.ld.w       v0, [s14, #0]
    s.movz       s8, #7
    vf.add       v5, v4, v6
    vf.mul       v4, v5, v1
    s.addi       s10, s17, #7
    s.addi       s12, s18, #28672                // row 7
    v.splat      v5, s10
    @p5 v.st.scatter.w [s11, v0], v4
    v.cmpi.lt    p2, v3, #256
    p.and        p5, p1, p2
    s.movz       s10, #7
    s.addi       s14, s2, #3520
    s.addi       s19, s17, #7
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    a.vread      v3, a0, s5
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.splat      v2, s19
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s6, #0]
    vf.cvt.bf16.f32 v6, v0
    a.vread      v0, a1, s16
    v.cmpi.lt    p2, v5, #256
    p.and        p4, p1, p2
    vf.mul       v5, v6, v3
    s.addi       s3, s17, #8
    s.movz       s5, #49152
    v.splat      v3, s3
    s.add        s3, s15, s5                     // row 8
    vf.mul       v6, v4, v0
    v.ld.w       v0, [s9, #0]
    s.movz       s5, #8
    vf.add       v4, v5, v6
    vf.mul       v5, v4, v1
    s.addi       s6, s17, #8
    s.movz       s9, #32768
    v.splat      v4, s6
    @p5 v.st.scatter.w [s11, v0], v5
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s6, s18, s9                     // row 8
    s.movz       s9, #8
    s.addi       s16, s2, #3584
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s7, #0]
    a.vread      v2, a0, s8
    v.cmpi.lt    p2, v3, #256
    p.and        p3, p1, p2
    s.addi       s7, s17, #8
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s12, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s10
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    vf.mul       v4, v5, v2
    s.addi       s8, s17, #9
    v.splat      v2, s7
    v.splat      v5, s8
    s.movz       s7, #55296
    vf.mul       v6, v3, v0
    v.ld.w       v0, [s14, #0]
    s.add        s8, s15, s7                     // row 9
    s.movz       s7, #9
    vf.add       v3, v4, v6
    vf.mul       v4, v3, v1
    s.addi       s10, s17, #9
    s.movz       s12, #36864
    v.splat      v3, s10
    @p5 v.st.scatter.w [s11, v0], v4
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s10, s18, s12                   // row 9
    s.movz       s12, #9
    s.addi       s14, s2, #3648
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s3, #0]
    a.vread      v2, a0, s5
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s6, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s9
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    vf.mul       v3, v5, v2
    s.addi       s3, s17, #9
    s.addi       s5, s17, #10
    v.splat      v2, s3
    v.splat      v5, s5
    vf.mul       v6, v4, v0
    v.ld.w       v0, [s16, #0]
    s.movz       s3, #61440
    s.movz       s5, #10
    vf.add       v4, v3, v6
    s.add        s6, s15, s3                     // row 10
    vf.mul       v3, v4, v1
    s.addi       s3, s17, #10
    s.movz       s9, #40960
    v.splat      v4, s3
    @p5 v.st.scatter.w [s11, v0], v3
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s3, s18, s9                     // row 10
    s.movz       s9, #10
    s.addi       s16, s2, #3712
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s8, #0]
    a.vread      v2, a0, s7
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s10, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s12
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    vf.mul       v4, v5, v2
    s.addi       s7, s17, #10
    s.addi       s8, s17, #11
    v.splat      v2, s7
    v.splat      v5, s8
    vf.mul       v6, v3, v0
    v.ld.w       v0, [s14, #0]
    .li       s7, #67584
    s.movz       s8, #11
    vf.add       v3, v4, v6
    s.add        s10, s15, s7                    // row 11
    vf.mul       v4, v3, v1
    s.addi       s7, s17, #11
    s.movz       s12, #45056
    v.splat      v3, s7
    @p5 v.st.scatter.w [s11, v0], v4
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s7, s18, s12                    // row 11
    s.movz       s12, #11
    s.addi       s14, s2, #3776
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s6, #0]
    a.vread      v2, a0, s5
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s9
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    vf.mul       v3, v5, v2
    s.addi       s3, s17, #11
    s.addi       s5, s17, #12
    v.splat      v2, s3
    v.splat      v5, s5
    vf.mul       v6, v4, v0
    v.ld.w       v0, [s16, #0]
    .li       s3, #73728
    s.movz       s5, #12
    vf.add       v4, v3, v6
    s.add        s6, s15, s3                     // row 12
    vf.mul       v3, v4, v1
    s.addi       s3, s17, #12
    s.movz       s9, #49152
    v.splat      v4, s3
    @p5 v.st.scatter.w [s11, v0], v3
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s3, s18, s9                     // row 12
    s.movz       s9, #12
    s.addi       s16, s2, #3840
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s10, #0]
    a.vread      v2, a0, s8
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s7, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s12
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    vf.mul       v4, v5, v2
    s.addi       s7, s17, #12
    s.addi       s8, s17, #13
    v.splat      v2, s7
    v.splat      v5, s8
    vf.mul       v6, v3, v0
    v.ld.w       v0, [s14, #0]
    .li       s7, #79872
    s.movz       s8, #13
    vf.add       v3, v4, v6
    s.add        s10, s15, s7                    // row 13
    vf.mul       v4, v3, v1
    s.addi       s7, s17, #13
    s.movz       s12, #53248
    v.splat      v3, s7
    @p5 v.st.scatter.w [s11, v0], v4
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s7, s18, s12                    // row 13
    s.movz       s12, #13
    s.addi       s14, s2, #3904
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s6, #0]
    a.vread      v2, a0, s5
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s9
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    vf.mul       v3, v5, v2
    s.addi       s3, s17, #13
    s.addi       s5, s17, #14
    v.splat      v2, s3
    v.splat      v5, s5
    vf.mul       v6, v4, v0
    v.ld.w       v0, [s16, #0]
    .li       s3, #86016
    s.movz       s5, #14
    vf.add       v4, v3, v6
    s.add        s6, s15, s3                     // row 14
    vf.mul       v3, v4, v1
    s.addi       s3, s17, #14
    s.movz       s9, #57344
    v.splat      v4, s3
    @p5 v.st.scatter.w [s11, v0], v3
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s3, s18, s9                     // row 14
    s.movz       s9, #14
    s.addi       s16, s2, #3968
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s10, #0]
    a.vread      v2, a0, s8
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s7, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s12
    v.cmpi.lt    p2, v4, #256
    p.and        p4, p1, p2
    vf.mul       v4, v5, v2
    s.addi       s7, s17, #14
    s.addi       s8, s17, #15
    v.splat      v2, s7
    v.splat      v5, s8
    vf.mul       v6, v3, v0
    v.ld.w       v0, [s14, #0]
    .li       s7, #92160
    s.movz       s8, #15
    vf.add       v3, v4, v6
    s.add        s10, s15, s7                    // row 15
    vf.mul       v4, v3, v1
    s.addi       s7, s17, #15
    s.movz       s12, #61440
    v.splat      v3, s7
    @p5 v.st.scatter.w [s11, v0], v4
    v.cmpi.lt    p2, v2, #256
    p.and        p5, p1, p2
    s.add        s7, s18, s12                    // row 15
    s.movz       s12, #15
    s.addi       s14, s2, #4032
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s6, #0]
    a.vread      v2, a0, s5
    v.cmpi.lt    p2, v5, #256
    p.and        p3, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v5, v0
    a.vread      v0, a1, s9
    v.cmpi.lt    p2, v3, #256
    p.and        p4, p1, p2
    vf.mul       v3, v5, v2
    s.addi       s3, s17, #15
    s.addi       s5, s2, #4096                   // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    v.splat      v2, s3
    s.movz       s3, #1024
    vf.mul       v5, v4, v0
    v.ld.w       v0, [s16, #0]
    s.movz       s6, #256
    s.movz       s9, #1024
    vf.add       v4, v3, v5
    s.movz       s15, #4
    vf.mul       v3, v4, v1
    .li       s16, #68719476752
    .li       s17, #2207613190144
    s.addi       s18, s2, #4352                  // 1024 bytes of repack scratch
    @p5 v.st.scatter.w [s11, v0], v3
    s.movz       s2, #1
    v.cmpi.lt    p2, v2, #256
    s.muli       s19, s2, #64
    p.and        p5, p1, p2
    // tile epilogue: 16 rows through the vector unit, as f32 (ISA sec 9B)
    s.movz       s2, #0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s10, #0]
    a.vread      v2, a0, s8
    s.movz       s8, #1
    s.add        s10, s18, s19
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s7, #0]
    vf.cvt.bf16.f32 v4, v0
    a.vread      v0, a1, s12
    s.movz       s7, #2
    vf.mul       v5, v4, v2
    s.movz       s12, #2
    s.movz       s19, #3
    s.muli       s20, s12, #64
    s.muli       s12, s19, #64
    vf.mul       v2, v3, v0
    v.ld.w       v0, [s14, #0]
    s.movz       s14, #3
    s.add        s19, s18, s20
    vf.add       v3, v5, v2
    s.add        s20, s18, s12
    vf.mul       v2, v3, v1
    @p5 v.st.scatter.w [s11, v0], v2
    s.movz       s11, #4
    s.muli       s12, s11, #64
    s.add        s11, s18, s12
    s.st.d       [s5, #0], s13
    s.st.d       [s5, #8], s3
    s.movz       s3, #5
    s.st.d       [s5, #16], s6
    s.muli       s6, s3, #64
    s.movz       s3, #6
    s.st.d       [s5, #48], s9
    s.movz       s9, #4
    s.muli       s12, s3, #64
    s.st.d       [s5, #56], s15
    s.movz       s3, #7
    s.add        s15, s18, s6
    s.st.d       [s5, #88], s16
    s.movz       s6, #5
    s.muli       s16, s3, #64
    s.st.d       [s5, #104], s17
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    a.vread      v0, a2, s2
    s.movz       s2, #8
    v.st.w       [s18, #0], v0
    a.vread      v0, a2, s8
    s.movz       s3, #6
    s.muli       s5, s2, #64
    s.movz       s2, #9
    s.add        s8, s18, s12
    s.movz       s12, #7
    s.muli       s17, s2, #64
    s.add        s2, s18, s16
    s.add        s16, s18, s5
    v.st.w       [s10, #0], v0
    a.vread      v0, a2, s7
    s.movz       s5, #10
    s.movz       s7, #8
    s.muli       s10, s5, #64
    s.add        s5, s18, s17
    s.add        s17, s18, s10
    v.st.w       [s19, #0], v0
    a.vread      v0, a2, s14
    s.movz       s10, #11
    s.movz       s14, #9
    s.muli       s19, s10, #64
    s.add        s10, s18, s19
    v.st.w       [s20, #0], v0
    a.vread      v0, a2, s9
    s.movz       s9, #12
    s.movz       s19, #10
    s.muli       s20, s9, #64
    s.add        s9, s18, s20
    v.st.w       [s11, #0], v0
    a.vread      v0, a2, s6
    s.movz       s6, #13
    s.movz       s11, #11
    s.muli       s20, s6, #64
    s.add        s6, s18, s20
    v.st.w       [s15, #0], v0
    a.vread      v0, a2, s3
    s.movz       s3, #14
    s.movz       s15, #12
    s.muli       s20, s3, #64
    s.add        s3, s18, s20
    v.st.w       [s8, #0], v0
    a.vread      v0, a2, s12
    s.movz       s8, #15
    s.movz       s12, #13
    s.muli       s20, s8, #64
    s.add        s8, s18, s20
    v.st.w       [s2, #0], v0
    a.vread      v0, a2, s7
    s.movz       s2, #0
    s.movz       s7, #0
    s.muli       s20, s2, #64
    v.st.w       [s16, #0], v0
    a.vread      v0, a2, s14
    s.muli       s2, s7, #4
    s.movz       s7, #14
    s.movz       s14, #16
    s.add        s16, s18, s20
    s.movz       s18, #15
    s.add        s20, s16, s2
    // tl.trans: 16 columns, gathered %c1885:scalar elements apart (ISA sec 9.1)
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s14
    v.st.w       [s5, #0], v0
    a.vread      v0, a2, s19
    v.mul        v3, v1, v2                      // one element per source row
    s.addi       s2, s20, #4                     // column 1
    s.addi       s5, s20, #8                     // column 2
    s.addi       s14, s20, #12                   // column 3
    v.st.w       [s17, #0], v0
    a.vread      v0, a2, s11
    s.addi       s11, s20, #16                   // column 4
    s.addi       s16, s20, #20                   // column 5
    s.addi       s17, s20, #24                   // column 6
    v.st.w       [s10, #0], v0
    a.vread      v0, a2, s15
    s.addi       s10, s20, #28                   // column 7
    s.addi       s15, s20, #32                   // column 8
    v.st.w       [s9, #0], v0
    a.vread      v0, a2, s12
    s.addi       s9, s20, #36                    // column 9
    s.addi       s12, s20, #40                   // column 10
    v.st.w       [s6, #0], v0
    a.vread      v0, a2, s7
    s.addi       s6, s20, #44                    // column 11
    s.addi       s7, s20, #48                    // column 12
    v.st.w       [s3, #0], v0
    a.vread      v0, a2, s18
    s.addi       s3, s20, #52                    // column 13
    s.addi       s18, s20, #56                   // column 14
    v.splat      v1, s4
    s.muli       s19, s4, #4
    v.st.w       [s8, #0], v0
    s.addi       s4, s20, #60                    // column 15
    fence.acq_rel.device
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v2, #0
    v.add        v4, v1, v0
    v.splat      v0, s1
    v.movi       v1, #0
    v.cmp.ge     p1, v4, v2
    v.cmpi.lt    p2, v4, #256
    v.ld.gather.w v2, [s20, v3]                  // index is in elements (ISA sec 9.1)
    s.muli       s8, s1, #1024
    v.cmp.ge     p3, v0, v1
    v.cmpi.lt    p4, v0, #1024
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s20, s13, s8
    s.movz       s8, #1
    s.add        s13, s20, s19
    p.and        p2, p5, p1
    v.ld.gather.w v0, [s2, v3]                   // index is in elements (ISA sec 9.1)
    s.muli       s2, s8, #1024
    s.add        s8, s13, s2
    v.ld.gather.w v1, [s5, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s2, s1, #1
    v.splat      v4, s2
    v.ld.gather.w v5, [s14, v3]                  // index is in elements (ISA sec 9.1)
    v.movi       v6, #0
    v.cmp.ge     p1, v4, v6
    v.ld.gather.w v6, [s11, v3]                  // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p3, v4, #1024
    p.and        p4, p1, p3
    v.ld.gather.w v4, [s16, v3]                  // index is in elements (ISA sec 9.1)
    p.and        p1, p5, p4
    v.ld.gather.w v7, [s17, v3]                  // index is in elements (ISA sec 9.1)
    s.movz       s2, #2
    s.muli       s5, s2, #1024
    v.ld.gather.w v8, [s10, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s2, s1, #2
    s.add        s10, s13, s5
    v.ld.gather.w v9, [s15, v3]                  // index is in elements (ISA sec 9.1)
    v.splat      v10, s2
    v.movi       v11, #0
    v.ld.gather.w v12, [s9, v3]                  // index is in elements (ISA sec 9.1)
    v.cmp.ge     p3, v10, v11
    v.ld.gather.w v11, [s12, v3]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v13, [s6, v3]                  // index is in elements (ISA sec 9.1)
    s.movz       s2, #3
    v.ld.gather.w v14, [s7, v3]                  // index is in elements (ISA sec 9.1)
    s.muli       s5, s2, #1024
    s.add        s2, s13, s5
    v.ld.gather.w v15, [s3, v3]                  // index is in elements (ISA sec 9.1)
    s.addi       s3, s1, #3
    v.splat      v16, s3
    v.ld.gather.w v17, [s18, v3]                 // index is in elements (ISA sec 9.1)
    v.movi       v18, #0
    v.ld.gather.w v19, [s4, v3]                  // index is in elements (ISA sec 9.1)
    s.movz       s3, #4
    s.addi       s4, s1, #4
    s.movz       s5, #5
    s.muli       s6, s3, #1024
    v.splat      v3, s4
    v.movi       v20, #0
    s.muli       s3, s5, #1024
    s.add        s4, s13, s6
    @p2 v.st.w       [s13, #0], v2
    s.addi       s5, s1, #5
    s.movz       s6, #6
    v.splat      v2, s5
    v.movi       v21, #0
    s.muli       s5, s6, #1024
    v.cmpi.lt    p2, v10, #1024
    p.and        p4, p3, p2
    v.cmp.ge     p2, v16, v18
    p.and        p3, p5, p4
    s.add        s6, s13, s3
    s.add        s3, s13, s5
    @p1 v.st.w       [s8, #0], v0
    s.addi       s5, s1, #6
    s.movz       s7, #7
    v.splat      v0, s5
    v.movi       v10, #0
    s.muli       s5, s7, #1024
    v.cmpi.lt    p1, v16, #1024
    p.and        p4, p2, p1
    v.cmp.ge     p1, v3, v20
    p.and        p2, p5, p4
    s.add        s7, s13, s5
    @p3 v.st.w       [s10, #0], v1
    s.addi       s5, s1, #7
    s.movz       s8, #8
    v.splat      v1, s5
    v.movi       v16, #0
    s.muli       s5, s8, #1024
    v.cmpi.lt    p3, v3, #1024
    p.and        p4, p1, p3
    v.cmp.ge     p1, v2, v21
    p.and        p3, p5, p4
    s.add        s8, s13, s5
    @p2 v.st.w       [s2, #0], v5
    s.addi       s2, s1, #8
    s.movz       s5, #9
    v.splat      v3, s2
    v.movi       v5, #0
    s.muli       s2, s5, #1024
    v.cmpi.lt    p2, v2, #1024
    p.and        p4, p1, p2
    v.cmp.ge     p1, v0, v10
    p.and        p2, p5, p4
    s.add        s5, s13, s2
    @p3 v.st.w       [s4, #0], v6
    s.addi       s2, s1, #9
    s.movz       s4, #10
    v.splat      v2, s2
    v.movi       v6, #0
    s.muli       s2, s4, #1024
    v.cmpi.lt    p3, v0, #1024
    p.and        p4, p1, p3
    v.cmp.ge     p1, v1, v16
    p.and        p3, p5, p4
    s.add        s4, s13, s2
    @p2 v.st.w       [s6, #0], v4
    s.addi       s2, s1, #10
    s.movz       s6, #11
    v.splat      v0, s2
    v.movi       v4, #0
    s.muli       s2, s6, #1024
    v.cmpi.lt    p2, v1, #1024
    p.and        p4, p1, p2
    v.cmp.ge     p1, v3, v5
    p.and        p2, p5, p4
    s.add        s6, s13, s2
    @p3 v.st.w       [s3, #0], v7
    s.addi       s2, s1, #11
    s.movz       s3, #12
    v.splat      v1, s2
    v.movi       v5, #0
    s.muli       s2, s3, #1024
    v.cmpi.lt    p3, v3, #1024
    p.and        p4, p1, p3
    v.cmp.ge     p1, v2, v6
    p.and        p3, p5, p4
    s.add        s3, s13, s2
    @p2 v.st.w       [s7, #0], v8
    s.addi       s2, s1, #12
    s.movz       s7, #13
    v.splat      v3, s2
    v.movi       v6, #0
    s.muli       s2, s7, #1024
    v.cmpi.lt    p2, v2, #1024
    p.and        p4, p1, p2
    v.cmp.ge     p1, v0, v4
    p.and        p2, p5, p4
    s.add        s7, s13, s2
    @p3 v.st.w       [s8, #0], v9
    s.addi       s2, s1, #13
    s.movz       s8, #14
    v.splat      v2, s2
    v.movi       v4, #0
    s.muli       s2, s8, #1024
    v.cmpi.lt    p3, v0, #1024
    p.and        p4, p1, p3
    v.cmp.ge     p1, v1, v5
    p.and        p3, p5, p4
    s.add        s8, s13, s2
    @p2 v.st.w       [s5, #0], v12
    s.addi       s2, s1, #14
    s.movz       s5, #15
    v.splat      v0, s2
    v.movi       v5, #0
    s.muli       s2, s5, #1024
    v.cmpi.lt    p2, v1, #1024
    p.and        p4, p1, p2
    v.cmp.ge     p1, v3, v6
    p.and        p2, p5, p4
    s.add        s5, s13, s2
    @p3 v.st.w       [s4, #0], v11
    s.addi       s2, s1, #15
    v.movi       v1, #0
    v.splat      v6, s2
    v.cmpi.lt    p3, v3, #1024
    p.and        p4, p1, p3
    v.cmp.ge     p1, v2, v4
    p.and        p3, p5, p4
    @p2 v.st.w       [s6, #0], v13
    v.cmpi.lt    p2, v2, #1024
    p.and        p4, p1, p2
    v.cmp.ge     p1, v0, v5
    p.and        p2, p5, p4
    @p3 v.st.w       [s3, #0], v14
    v.cmpi.lt    p3, v0, #1024
    p.and        p4, p1, p3
    v.cmp.ge     p1, v6, v1
    p.and        p3, p5, p4
    @p2 v.st.w       [s7, #0], v15
    v.cmpi.lt    p2, v6, #1024
    p.and        p4, p1, p2
    p.and        p1, p5, p4
    @p3 v.st.w       [s8, #0], v17
    @p1 v.st.w       [s5, #0], v19
__rctx_next:
    exit
