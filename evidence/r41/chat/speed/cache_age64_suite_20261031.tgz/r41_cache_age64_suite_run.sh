#!/bin/bash
set -eu
export OMP_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES= HF_HUB_OFFLINE=1 HF_HOME="$HOME/r41-fp8-kern-hf"
export TNCA_PROFILE=core-vrf-sync-v5-x8-g2c4-dp TNCA_BACKEND=systemc-tlm-grid TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip" TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg" TNCA_TLM_OUT="$HOME/r41_cache_age64_suite_tlm" TNCA_HOST_TIMEOUT=180 TNCA_CODE_CACHE_POLICY=lfu-sqrt
unset TNCA_EQUAL_ROWS TNCA_X8_SPILL_LANES TNCA_X8_PIPELINE
cd "$HOME/r41_chat_cache_age64_20261031"
exec "$HOME/flux-venv/bin/python" -u "$HOME/r41_cache_pinned_fp8_20261031.py" --group v4 --group compile --quick --out "$HOME/r41_cache_age64_suite"
