    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s6, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s7, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s8, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s9, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s10, [s1, #48]                  // in_ptr6: device_ptr64 at arg_base+48
    s.ld.d       s11, [s1, #56]                  // in_ptr7: device_ptr64 at arg_base+56
    s.ld.d       s12, [s1, #64]                  // in_ptr8: device_ptr64 at arg_base+64
    s.ld.d       s13, [s1, #72]                  // in_ptr9: device_ptr64 at arg_base+72
    s.ld.d       s14, [s1, #80]                  // out_ptr0: device_ptr64 at arg_base+80
    s.ld.d       s15, [s1, #88]                  // out_ptr1: device_ptr64 at arg_base+88
    s.ld.d       s16, [s1, #96]                  // out_ptr2: device_ptr64 at arg_base+96
    s.ld.d       s17, [s1, #104]                 // out_ptr3: device_ptr64 at arg_base+104
__rctx_program:
    s.shli       s1, s2, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #6
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.movi       v6, #0
    @p1 v.sel        v7, v5, v4
    v.sub        v5, v0, v4
    v.cmp.lt     p2, v4, v0
    v.lshr       v8, v7, v3
    v.sub        v3, v1, v4
    @p2 v.sel        v7, v5, v4
    v.sub        v5, v2, v8
    v.movi       v9, #15
    v.cmp.lt     p3, v4, v1
    @p1 v.sel        v10, v5, v8
    @p3 v.sel        v5, v3, v4
    v.movi       v3, #63
    v.sub        v8, v6, v10
    v.cmp.lt     p1, v10, v6
    v.movi       v11, #511
    @p1 v.sel        v12, v8, v10
    v.lshr       v8, v7, v9
    v.movi       v7, #0
    v.and        v9, v5, v3
    v.and        v3, v12, v11
    v.sub        v5, v0, v8
    v.movi       v10, #64
    v.sub        v11, v7, v4
    v.sub        v12, v1, v9
    v.sub        v13, v6, v3
    @p2 v.sel        v14, v5, v8
    v.cmp.lt     p2, v4, v7
    @p3 v.sel        v5, v12, v9
    @p1 v.sel        v8, v13, v3
    v.movi       v3, #512
    s.movz       s18, #32768
    v.splat      v9, s18                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v12, v1, v10
    v.cmp.lt     p1, v10, v1
    @p2 v.sel        v1, v11, v4
    v.movi       v4, #32767
    v.sub        v11, v2, v10
    v.cmp.lt     p3, v10, v2
    v.sub        v2, v6, v3
    @p1 v.sel        v13, v12, v10
    v.and        v12, v1, v4
    v.mul        v1, v14, v10
    v.movi       v4, #256
    v.sub        v13, v7, v12
    v.add        v14, v5, v1
    v.mul        v1, v8, v4
    @p2 v.sel        v4, v13, v12
    v.sub        v5, v0, v9
    v.add        v8, v14, v1
    v.ld.gather.h v1, [s5, v4]                   // index is in elements (ISA sec 9.1)
    v.sub        v12, v7, v9
    v.cmp.lt     p1, v3, v6
    v.cmp.lt     p2, v9, v0
    @p3 v.sel        v0, v11, v10
    s.shli       s18, s1, #1                     // element offset -> bytes (x2)
    v.cmp.lt     p3, v9, v7
    s.add        s1, s6, s18                     // &in_ptr2[...]
    s.add        s19, s9, s18                    // &in_ptr5[...]
    @p1 v.sel        v0, v2, v3
    s.add        s20, s11, s18                   // &in_ptr7[...]
    s.add        s21, s13, s18                   // &in_ptr9[...]
    @p2 v.sel        v0, v5, v9
    @p3 v.sel        v0, v12, v9
    v.ld.gather.h v0, [s3, v8]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v2, v1
    s.add        s22, s14, s18                   // &out_ptr0[...]
    v.ld.h       v1, [s1, #0]
    vf.cvt.f16.f32 v3, v0
    s.add        s1, s15, s18                    // &out_ptr1[...]
    vf.mul       v0, v3, v2
    v.ld.gather.h v3, [s7, v4]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v4, v1
    v.ld.gather.h v1, [s8, v8]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v5, v3
    vf.mul       v3, v4, v5
    vf.add       v4, v0, v3
    v.ld.h       v0, [s19, #0]
    vf.cvt.f16.f32 v3, v1
    vf.cvt.f32.f16 v1, v4
    s.add        s19, s16, s18                   // &out_ptr2[...]
    s.add        s23, s17, s18                   // &out_ptr3[...]
    vf.mul       v4, v3, v2
    v.ld.gather.h v3, [s10, v8]                  // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v6, v0
    vf.mul       v0, v6, v5
    vf.add       v6, v4, v0
    v.ld.h       v0, [s20, #0]
    vf.cvt.f16.f32 v4, v3
    vf.cvt.f32.f16 v3, v6
    vf.mul       v6, v4, v2
    v.ld.gather.h v4, [s12, v8]                  // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v7, v0
    vf.mul       v0, v7, v5
    vf.add       v7, v6, v0
    v.ld.h       v0, [s21, #0]
    vf.cvt.f16.f32 v6, v4
    vf.cvt.f32.f16 v4, v7
    vf.mul       v7, v6, v2
    vf.cvt.f16.f32 v2, v0
    v.st.h       [s22, #0], v1
    vf.mul       v0, v2, v5
    vf.add       v1, v7, v0
    vf.cvt.f32.f16 v0, v1
    v.st.h       [s1, #0], v3
    v.st.h       [s19, #0], v4
    v.st.h       [s23, #0], v0
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s18, s1, s4
    s.mov        s2, s1
    br.nz        s18, __rctx_program
    exit
