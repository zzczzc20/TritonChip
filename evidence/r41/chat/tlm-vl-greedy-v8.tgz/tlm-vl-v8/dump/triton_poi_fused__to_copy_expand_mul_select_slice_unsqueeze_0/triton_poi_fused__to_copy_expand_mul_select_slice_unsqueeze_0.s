    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.mul        s5, s4, s2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #0
    v.movi       v2, #192
    s.movz       s2, #1
    v.splat      v3, s5
    s.movz       s4, #1
    s.movz       s6, #1
    v.add        v4, v3, v0
    s.movz       s7, #1
    s.addi       s8, s3, #8                      // &in_ptr0[1] (a constant offset, x8)
    s.ld.d       s9, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.addi       s10, s3, #4
    v.cmp.lt     p1, v4, v2
    s.movz       s11, #1
    s.movz       s12, #1
    s.movz       s13, #1
    s.movz       s14, #1
    s.movz       s15, #1
    s.movz       s16, #1
    s.movz       s17, #1
    s.movz       s18, #1
    s.ld.d       s19, [s1, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    v.cmp.lt     p2, v4, v1
    s.movz       s20, #1
    s.movz       s21, #1
    s.movz       s22, #1
    s.movz       s23, #1
    s.movz       s24, #60
    s.movz       s25, #60
    s.movz       s26, #60
    s.movz       s27, #60
    s.movz       s28, #60
    s.ld.d       s29, [s1, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    v.sub        v0, v1, v4
    s.movz       s1, #60
    s.movz       s30, #60
    @p2 v.sel        v2, v0, v4
    s.movz       s31, #60
    s.movz       s32, #60
    s.movz       s33, #60
    s.movz       s34, #60
    s.movz       s35, #60
    s.movz       s36, #60
    s.movz       s37, #60
    s.movz       s38, #60
    s.movz       s39, #60
    v.movi       v0, #64
    s.movz       s40, #1
    s.ld.d       s40, [s8, #0]                   // one element, not a vector
    v.movi       v3, #0
    v.movi       v5, #0
    v.movi       v6, #0
    v.movi       v7, #63
    v.movi       v8, #6
    v.sub        v9, v6, v4
    v.cmp.lt     p3, v4, v6
    v.lshr       v10, v2, v8
    @p3 v.sel        v2, v9, v4
    v.sub        v4, v1, v0
    s.lshri      s8, s40, #32
    v.insert     v3, s40, #0
    v.insert     v5, s8, #0
    s.lshri      s8, s40, #32
    v.insert     v3, s40, #1
    v.insert     v5, s8, #1
    s.lshri      s8, s40, #32
    v.insert     v3, s40, #2
    v.insert     v5, s8, #2
    s.lshri      s8, s40, #32
    v.insert     v3, s40, #3
    v.insert     v5, s8, #3
    v.and        v8, v2, v7
    v.insert     v3, s40, #4
    v.sub        v2, v1, v10
    v.sub        v7, v6, v8
    v.sub        v9, v6, v0
    @p2 v.sel        v11, v2, v10
    @p3 v.sel        v2, v7, v8
    v.cmp.lt     p2, v0, v1
    v.cmp.lt     p3, v0, v6
    .li       s8, #-1
    s.lshri      s8, s40, #32
    s.lshri      s41, s40, #32
    v.insert     v5, s8, #4
    v.insert     v3, s40, #5
    s.lshri      s8, s40, #32
    v.insert     v5, s41, #5
    v.insert     v3, s40, #6
    v.movi       v1, #1
    v.insert     v5, s8, #6
    s.lshri      s8, s40, #32
    v.insert     v3, s40, #7
    v.insert     v5, s8, #7
    s.lshri      s8, s40, #32
    v.insert     v3, s40, #8
    v.insert     v5, s8, #8
    @p2 v.sel        v1, v4, v0
    s.lshri      s8, s40, #32
    v.insert     v3, s40, #9
    v.insert     v5, s8, #9
    s.lshri      s8, s40, #32
    v.insert     v3, s40, #10
    v.insert     v5, s8, #10
    v.movi       v1, #1
    s.lshri      s8, s40, #32
    v.insert     v3, s40, #11
    v.insert     v5, s8, #11
    s.lshri      s8, s40, #32
    v.insert     v3, s40, #12
    v.insert     v5, s8, #12
    @p3 v.sel        v1, v9, v0
    v.movi       v0, #1
    s.lshri      s8, s40, #32
    v.extract    s41, v2, #0
    v.insert     v3, s40, #13
    v.insert     v5, s8, #13
    v.add        v1, v11, v0
    v.movi       v4, #1
    s.shli       s8, s41, #32
    s.lshri      s41, s40, #32
    v.extract    s42, v2, #1
    s.ashri      s43, s8, #32
    v.insert     v3, s40, #14
    v.insert     v5, s41, #14
    v.shl        v6, v1, v4
    v.movi       v1, #0
    v.movi       v4, #0
    s.shli       s8, s42, #32
    s.lshri      s41, s40, #32
    s.lshri      s42, s43, #32
    v.extract    s44, v2, #2
    s.ashri      s45, s8, #32
    v.insert     v3, s40, #15
    v.insert     v5, s41, #15
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s9, v2]               // index is in elements (ISA sec 9.1)
    s.shli       s8, s44, #32
    s.lshri      s40, s45, #32
    v.extract    s41, v2, #3
    s.ashri      s44, s8, #32
    s.shli       s8, s41, #32
    v.movi       v8, #0
    s.ashri      s41, s8, #32
    v.cmp.eq     p2, v11, v8
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v9, [s3, v6]               // index is in elements (ISA sec 9.1)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v10, [s10, v6]             // index is in elements (ISA sec 9.1)
    v.insert     v1, s43, #0
    v.insert     v4, s42, #0
    s.lshri      s8, s44, #32
    v.insert     v1, s45, #1
    v.insert     v4, s40, #1
    v.extract    s10, v2, #4
    v.insert     v1, s44, #2
    v.insert     v4, s8, #2
    s.shli       s8, s10, #32
    s.lshri      s10, s41, #32
    v.extract    s40, v2, #5
    s.ashri      s42, s8, #32
    v.insert     v1, s41, #3
    v.insert     v4, s10, #3
    s.shli       s8, s40, #32
    s.lshri      s10, s42, #32
    v.extract    s40, v2, #6
    s.ashri      s41, s8, #32
    v.insert     v1, s42, #4
    v.insert     v4, s10, #4
    s.shli       s8, s40, #32
    s.lshri      s10, s41, #32
    v.extract    s40, v2, #7
    s.ashri      s42, s8, #32
    v.insert     v1, s41, #5
    v.insert     v4, s10, #5
    s.shli       s8, s40, #32
    s.lshri      s10, s42, #32
    v.extract    s40, v2, #8
    s.ashri      s41, s8, #32
    v.insert     v1, s42, #6
    v.insert     v4, s10, #6
    s.shli       s8, s40, #32
    s.lshri      s10, s41, #32
    v.extract    s40, v2, #9
    s.ashri      s42, s8, #32
    v.insert     v1, s41, #7
    v.insert     v4, s10, #7
    s.shli       s8, s40, #32
    s.lshri      s10, s42, #32
    v.extract    s40, v2, #10
    s.ashri      s41, s8, #32
    v.insert     v1, s42, #8
    v.insert     v4, s10, #8
    s.shli       s8, s40, #32
    s.lshri      s10, s41, #32
    v.extract    s40, v2, #11
    s.ashri      s42, s8, #32
    v.insert     v1, s41, #9
    v.insert     v4, s10, #9
    s.shli       s8, s40, #32
    s.lshri      s10, s42, #32
    v.extract    s40, v2, #12
    s.ashri      s41, s8, #32
    v.insert     v1, s42, #10
    v.insert     v4, s10, #10
    s.shli       s8, s40, #32
    s.lshri      s10, s41, #32
    v.extract    s40, v2, #13
    s.ashri      s42, s8, #32
    v.insert     v1, s41, #11
    v.insert     v4, s10, #11
    s.shli       s8, s40, #32
    s.lshri      s10, s42, #32
    v.extract    s40, v2, #14
    s.ashri      s41, s8, #32
    v.insert     v1, s42, #12
    v.insert     v4, s10, #12
    s.shli       s8, s40, #32
    s.lshri      s10, s41, #32
    v.extract    s40, v2, #15
    s.ashri      s42, s8, #32
    v.insert     v1, s41, #13
    v.insert     v4, s10, #13
    s.shli       s8, s40, #32
    s.lshri      s10, s42, #32
    s.ashri      s40, s8, #32
    v.insert     v1, s42, #14
    v.insert     v4, s10, #14
    s.lshri      s8, s40, #32
    v.insert     v1, s40, #15
    v.insert     v4, s8, #15
    v.movi       v6, #0
    v.extract    s8, v1, #0
    v.extract    s10, v4, #0
    v.extract    s40, v4, #1
    s.shli       s41, s10, #32
    v.extract    s10, v1, #1
    s.or         s42, s8, s41
    s.shli       s8, s40, #32
    s.cmp.ge     s40, s42, s2
    v.extract    s2, v4, #2
    s.or         s41, s10, s8
    v.insert     v6, s40, #0
    v.extract    s8, v1, #2
    s.shli       s10, s2, #32
    s.cmp.ge     s2, s41, s4
    v.extract    s4, v4, #3
    s.or         s40, s8, s10
    v.insert     v6, s2, #1
    v.extract    s2, v1, #3
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s40, s6
    v.extract    s6, v4, #4
    s.or         s10, s2, s8
    v.insert     v6, s4, #2
    v.extract    s2, v1, #4
    s.shli       s4, s6, #32
    s.cmp.ge     s6, s10, s7
    v.extract    s7, v4, #5
    s.or         s8, s2, s4
    v.insert     v6, s6, #3
    v.extract    s2, v1, #5
    s.shli       s4, s7, #32
    s.cmp.ge     s6, s8, s11
    v.extract    s7, v4, #6
    s.or         s8, s2, s4
    v.insert     v6, s6, #4
    v.extract    s2, v1, #6
    s.shli       s4, s7, #32
    s.cmp.ge     s6, s8, s12
    v.extract    s7, v4, #7
    s.or         s8, s2, s4
    v.insert     v6, s6, #5
    v.extract    s2, v1, #7
    s.shli       s4, s7, #32
    s.cmp.ge     s6, s8, s13
    v.extract    s7, v4, #8
    s.or         s8, s2, s4
    v.insert     v6, s6, #6
    v.extract    s2, v1, #8
    s.shli       s4, s7, #32
    s.cmp.ge     s6, s8, s14
    v.extract    s7, v4, #9
    s.or         s8, s2, s4
    v.insert     v6, s6, #7
    v.extract    s2, v1, #9
    s.shli       s4, s7, #32
    s.cmp.ge     s6, s8, s15
    v.extract    s7, v4, #10
    s.or         s8, s2, s4
    v.insert     v6, s6, #8
    v.extract    s2, v1, #10
    s.shli       s4, s7, #32
    s.cmp.ge     s6, s8, s16
    v.extract    s7, v4, #11
    s.or         s8, s2, s4
    v.insert     v6, s6, #9
    v.extract    s2, v1, #11
    s.shli       s4, s7, #32
    s.cmp.ge     s6, s8, s17
    v.extract    s7, v4, #12
    s.or         s8, s2, s4
    v.insert     v6, s6, #10
    v.extract    s2, v1, #12
    s.shli       s4, s7, #32
    s.cmp.ge     s6, s8, s18
    v.extract    s7, v4, #13
    s.or         s8, s2, s4
    v.insert     v6, s6, #11
    v.extract    s2, v1, #13
    s.shli       s4, s7, #32
    s.cmp.ge     s6, s8, s20
    v.extract    s7, v4, #14
    s.or         s8, s2, s4
    v.insert     v6, s6, #12
    v.extract    s2, v1, #14
    s.shli       s4, s7, #32
    s.cmp.ge     s6, s8, s21
    v.extract    s7, v4, #15
    v.extract    s8, v4, #0
    s.or         s10, s2, s4
    v.insert     v6, s6, #13
    v.extract    s2, v1, #15
    s.shli       s4, s7, #32
    v.extract    s6, v1, #0
    s.shli       s7, s8, #32
    s.cmp.ge     s8, s10, s22
    v.extract    s10, v4, #1
    s.or         s11, s2, s4
    s.or         s2, s6, s7
    v.insert     v6, s8, #14
    v.movi       v11, #0
    v.extract    s4, v1, #1
    s.shli       s6, s10, #32
    s.cmp.ge     s7, s11, s23
    s.cmp.lt     s8, s2, s24
    v.extract    s2, v4, #2
    s.or         s10, s4, s6
    v.insert     v6, s7, #15
    v.insert     v11, s8, #0
    v.extract    s4, v1, #2
    s.shli       s6, s2, #32
    s.cmp.lt     s2, s10, s25
    v.extract    s7, v4, #3
    s.or         s8, s4, s6
    v.insert     v11, s2, #1
    v.extract    s2, v1, #3
    s.shli       s4, s7, #32
    s.cmp.lt     s6, s8, s26
    v.extract    s7, v4, #4
    s.or         s8, s2, s4
    v.insert     v11, s6, #2
    v.extract    s2, v1, #4
    s.shli       s4, s7, #32
    s.cmp.lt     s6, s8, s27
    v.extract    s7, v4, #5
    s.or         s8, s2, s4
    v.insert     v11, s6, #3
    v.extract    s2, v1, #5
    s.shli       s4, s7, #32
    s.cmp.lt     s6, s8, s28
    v.extract    s7, v4, #6
    s.or         s8, s2, s4
    v.insert     v11, s6, #4
    v.extract    s2, v1, #6
    s.shli       s4, s7, #32
    s.cmp.lt     s6, s8, s1
    v.extract    s1, v4, #7
    s.or         s7, s2, s4
    v.insert     v11, s6, #5
    v.extract    s2, v1, #7
    s.shli       s4, s1, #32
    s.cmp.lt     s1, s7, s30
    v.movi       v12, #0
    s.or         s6, s2, s4
    v.insert     v11, s1, #6
    v.cmp.ne     p3, v6, v12
    v.extract    s1, v4, #8
    v.extract    s2, v1, #8
    s.shli       s4, s1, #32
    s.cmp.lt     s1, s6, s31
    v.extract    s6, v4, #9
    s.or         s7, s2, s4
    v.insert     v11, s1, #7
    v.extract    s1, v1, #9
    s.shli       s2, s6, #32
    s.cmp.lt     s4, s7, s32
    v.extract    s6, v4, #10
    s.or         s7, s1, s2
    v.insert     v11, s4, #8
    v.extract    s1, v1, #10
    s.shli       s2, s6, #32
    s.cmp.lt     s4, s7, s33
    v.extract    s6, v4, #11
    s.or         s7, s1, s2
    v.insert     v11, s4, #9
    v.extract    s1, v1, #11
    s.shli       s2, s6, #32
    s.cmp.lt     s4, s7, s34
    v.extract    s6, v4, #12
    s.or         s7, s1, s2
    v.insert     v11, s4, #10
    v.extract    s1, v1, #12
    s.shli       s2, s6, #32
    s.cmp.lt     s4, s7, s35
    v.extract    s6, v4, #13
    s.or         s7, s1, s2
    v.insert     v11, s4, #11
    v.extract    s1, v1, #13
    s.shli       s2, s6, #32
    s.cmp.lt     s4, s7, s36
    v.extract    s6, v4, #14
    s.or         s7, s1, s2
    v.insert     v11, s4, #12
    v.extract    s1, v1, #14
    s.shli       s2, s6, #32
    s.cmp.lt     s4, s7, s37
    v.extract    s6, v4, #15
    s.or         s7, s1, s2
    v.insert     v11, s4, #13
    v.extract    s1, v1, #15
    s.shli       s2, s6, #32
    v.movi       v1, #-1
    s.cmp.lt     s4, s7, s38
    s.or         s6, s1, s2
    v.insert     v11, s4, #14
    v.add        v4, v2, v1
    v.movi       v1, #3
    v.movi       v2, #0
    s.cmp.lt     s1, s6, s39
    v.movi       v6, #0
    v.insert     v11, s1, #15
    v.sub        v12, v2, v4
    v.sub        v13, v2, v1
    v.cmp.lt     p4, v4, v2
    v.cmp.lt     p5, v1, v2
    v.cmp.ne     p6, v11, v6
    v.movi       v6, #1
    @p4 v.sel        v11, v12, v4
    @p5 v.sel        v12, v13, v1
    v.movi       v13, #0
    v.movi       v14, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v15, s1
    v.shl        v16, v14, v6
    v.cmp.lt     p5, v14, v2
    v.lshr       v17, v11, v15
    v.shl        v18, v6, v15
    s.subi       s2, s1, #1
    v.and        v15, v17, v6
    s.movz       s4, #0
    v.or         v17, v16, v15
    v.cmp.geu    p7, v17, v12
    p.or         p8, p5, p7
    v.sub        v15, v17, v12
    @p8 v.sel        v16, v18, v2
    @p8 v.sel        v18, v15, v17
    v.or         v15, v13, v16
    v.mov        v14, v18
    v.mov        v13, v15
    s.mov        s1, s2
    s.cmp.ge     s2, s1, s4
    br.nz        s2, idiv_1
    v.sub        v6, v2, v14
    @p4 v.sel        v2, v6, v14
    v.movi       v6, #0
    v.movi       v11, #0
    v.extract    s1, v2, #0
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #0
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #0
    v.extract    s1, v2, #1
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #1
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #1
    v.extract    s1, v2, #2
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #2
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #2
    v.extract    s1, v2, #3
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #3
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #3
    v.extract    s1, v2, #4
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #4
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #4
    v.extract    s1, v2, #5
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #5
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #5
    v.extract    s1, v2, #6
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #6
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #6
    v.extract    s1, v2, #7
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #7
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #7
    v.extract    s1, v2, #8
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #8
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #8
    v.extract    s1, v2, #9
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #9
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #9
    v.extract    s1, v2, #10
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #10
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #10
    v.extract    s1, v2, #11
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #11
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #11
    v.extract    s1, v2, #12
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #12
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #12
    v.extract    s1, v2, #13
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #13
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #13
    v.extract    s1, v2, #14
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #14
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #14
    v.extract    s1, v2, #15
    s.shli       s2, s1, #32
    s.ashri      s1, s2, #32
    v.insert     v6, s1, #15
    s.lshri      s2, s1, #32
    v.insert     v11, s2, #15
    v.movi       v12, #0
    v.extract    s1, v6, #0
    v.extract    s2, v11, #0
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #0
    v.extract    s1, v6, #1
    v.extract    s2, v11, #1
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #1
    v.extract    s1, v6, #2
    v.extract    s2, v11, #2
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #2
    v.extract    s1, v6, #3
    v.extract    s2, v11, #3
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #3
    v.extract    s1, v6, #4
    v.extract    s2, v11, #4
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #4
    v.extract    s1, v6, #5
    v.extract    s2, v11, #5
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #5
    v.extract    s1, v6, #6
    v.extract    s2, v11, #6
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #6
    v.extract    s1, v6, #7
    v.extract    s2, v11, #7
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #7
    v.extract    s1, v6, #8
    v.extract    s2, v11, #8
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #8
    v.extract    s1, v6, #9
    v.extract    s2, v11, #9
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #9
    v.extract    s1, v6, #10
    v.extract    s2, v11, #10
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #10
    v.extract    s1, v6, #11
    v.extract    s2, v11, #11
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #11
    v.extract    s1, v6, #12
    v.extract    s2, v11, #12
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #12
    v.extract    s1, v6, #13
    v.extract    s2, v11, #13
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #13
    v.extract    s1, v6, #14
    v.extract    s2, v11, #14
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #14
    v.extract    s1, v6, #15
    v.extract    s2, v11, #15
    s.shli       s4, s2, #32
    s.or         s2, s1, s4
    s.movz       s1, #0
    s.cmp.eq     s4, s2, s1
    v.insert     v12, s4, #15
    v.movi       v6, #0
    v.cmp.ne     p4, v12, v6
    p.and        p5, p3, p6
    p.and        p3, p5, p4
    s.addi       s1, s3, #16                     // &in_ptr0[2] (a constant offset, x8)
    s.ld.d       s2, [s1, #0]                    // one element, not a vector
    v.movi       v6, #0
    v.movi       v11, #0
    v.insert     v6, s2, #0
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #0
    v.insert     v6, s2, #1
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #1
    v.insert     v6, s2, #2
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #2
    v.insert     v6, s2, #3
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #3
    v.insert     v6, s2, #4
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #4
    v.insert     v6, s2, #5
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #5
    v.insert     v6, s2, #6
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #6
    v.insert     v6, s2, #7
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #7
    v.insert     v6, s2, #8
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #8
    v.insert     v6, s2, #9
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #9
    v.insert     v6, s2, #10
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #10
    v.insert     v6, s2, #11
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #11
    v.insert     v6, s2, #12
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #12
    v.insert     v6, s2, #13
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #13
    v.insert     v6, s2, #14
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #14
    v.insert     v6, s2, #15
    s.lshri      s1, s2, #32
    v.insert     v11, s1, #15
    v.movi       v12, #1
    v.movi       v13, #0
    @p3 v.sel        v14, v12, v13
    v.movi       v12, #0
    v.movi       v13, #0
    v.extract    s1, v14, #0
    v.extract    s2, v6, #0
    v.extract    s3, v11, #0
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #0
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #0
    v.extract    s1, v14, #1
    v.extract    s2, v6, #1
    v.extract    s3, v11, #1
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #1
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #1
    v.extract    s1, v14, #2
    v.extract    s2, v6, #2
    v.extract    s3, v11, #2
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #2
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #2
    v.extract    s1, v14, #3
    v.extract    s2, v6, #3
    v.extract    s3, v11, #3
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #3
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #3
    v.extract    s1, v14, #4
    v.extract    s2, v6, #4
    v.extract    s3, v11, #4
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #4
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #4
    v.extract    s1, v14, #5
    v.extract    s2, v6, #5
    v.extract    s3, v11, #5
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #5
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #5
    v.extract    s1, v14, #6
    v.extract    s2, v6, #6
    v.extract    s3, v11, #6
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #6
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #6
    v.extract    s1, v14, #7
    v.extract    s2, v6, #7
    v.extract    s3, v11, #7
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #7
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #7
    v.extract    s1, v14, #8
    v.extract    s2, v6, #8
    v.extract    s3, v11, #8
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #8
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #8
    v.extract    s1, v14, #9
    v.extract    s2, v6, #9
    v.extract    s3, v11, #9
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #9
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #9
    v.extract    s1, v14, #10
    v.extract    s2, v6, #10
    v.extract    s3, v11, #10
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #10
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #10
    v.extract    s1, v14, #11
    v.extract    s2, v6, #11
    v.extract    s3, v11, #11
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #11
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #11
    v.extract    s1, v14, #12
    v.extract    s2, v6, #12
    v.extract    s3, v11, #12
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #12
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #12
    v.extract    s1, v14, #13
    v.extract    s2, v6, #13
    v.extract    s3, v11, #13
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #13
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #13
    v.extract    s1, v14, #14
    v.extract    s2, v6, #14
    v.extract    s3, v11, #14
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #14
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #14
    v.extract    s1, v14, #15
    v.extract    s2, v6, #15
    v.extract    s3, v11, #15
    s.shli       s4, s3, #32
    s.or         s3, s2, s4
    s.movz       s2, #0
    s.sub        s4, s3, s2
    s.mul        s3, s1, s4
    s.add        s1, s2, s3
    v.insert     v12, s1, #15
    s.lshri      s2, s1, #32
    v.insert     v13, s2, #15
    v.movi       v6, #31
    v.ashr       v11, v13, v6
    v.xor        v6, v12, v11
    v.sub        v12, v6, v11
    v.movi       v6, #0
    v.cmp.eq     p4, v12, v6
    v.movi       v6, #1
    v.movi       v14, #0
    @p4 v.sel        v15, v6, v14
    v.and        v6, v11, v15
    v.xor        v14, v13, v11
    v.add        v11, v14, v6
    vf.cvt.u32.f32 v6, v12                       // |x| < 2**32: one rounding
    v.clz        v14, v11
    v.movi       v15, #32
    v.sub        v16, v15, v14
    v.shl        v15, v11, v14
    v.movi       v17, #1
    v.sub        v18, v16, v17
    v.lshr       v17, v12, v18
    v.movi       v18, #1
    v.lshr       v19, v17, v18
    v.or         v17, v15, v19
    v.movi       v15, #-1
    v.lshr       v18, v15, v14
    v.and        v14, v12, v18
    v.movi       v12, #0
    v.cmp.ne     p4, v14, v12
    v.movi       v12, #1
    v.movi       v14, #0
    @p4 v.sel        v15, v12, v14
    v.or         v12, v17, v15
    vf.cvt.u32.f32 v14, v12                      // top 32 bits + sticky: one rounding
    v.movi       v12, #127
    v.add        v15, v16, v12
    v.movi       v12, #23
    v.shl        v16, v15, v12
    vf.mul       v12, v14, v16                   // * 2**n, exact
    v.movi       v14, #0
    v.cmp.eq     p4, v11, v14
    @p4 v.sel        v11, v6, v12
    v.movi       v6, #0
    v.cmp.lt     p4, v13, v6
    vf.neg       v6, v11
    @p4 v.sel        v12, v6, v11
    v.movi       v6, #0
    v.movi       v11, #1
    v.cmp.lt     p4, v4, v6
    v.cmp.lt     p5, v1, v6
    v.sub        v13, v6, v4
    @p4 v.sel        v14, v13, v4
    v.sub        v13, v6, v1
    @p5 v.sel        v15, v13, v1
    v.movi       v13, #0
    v.movi       v16, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v17, s1
    v.shl        v18, v16, v11
    v.cmp.lt     p6, v16, v6
    v.lshr       v19, v14, v17
    v.shl        v20, v11, v17
    s.subi       s2, s1, #1
    v.and        v17, v19, v11
    s.movz       s3, #0
    v.or         v19, v18, v17
    v.cmp.geu    p7, v19, v15
    p.or         p8, p6, p7
    v.sub        v17, v19, v15
    @p8 v.sel        v18, v20, v6
    @p8 v.sel        v20, v17, v19
    v.or         v17, v13, v18
    v.mov        v16, v20
    v.mov        v13, v17
    s.mov        s1, s2
    s.cmp.ge     s2, s1, s3
    br.nz        s2, idiv_2
    p.xor        p6, p4, p5
    v.sub        v11, v6, v13
    @p6 v.sel        v6, v11, v13
    v.cmp.ne     p4, v2, v8
    v.sub        v2, v6, v0
    @p4 v.sel        v11, v2, v6
    v.cmp.lt     p4, v4, v8
    @p4 v.sel        v2, v11, v6
    s.movz       s1, #3
    v.mul        v4, v2, v1
    v.add        v1, v4, v0
    p.and        p4, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s9, v1]               // index is in elements (ISA sec 9.1)
    vf.mul       v1, v12, v0
    vf.abs       v0, v1
    v.movi       v2, #23
    v.lshr       v4, v0, v2
    v.movi       v2, #127
    v.sub        v6, v4, v2
    .li       s1, #8388607
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v4, v0, v2
    .li       s1, #8388608
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.or         v8, v4, v2
    v.movi       v2, #-1
    v.max.s      v4, v6, v2
    v.movi       v2, #7
    v.add        v11, v4, v2
    v.movi       v2, #5
    v.lshr       v4, v11, v2
    v.movi       v2, #31
    v.and        v12, v11, v2
    v.movi       v2, #1
    v.cmp.eq     p4, v4, v2
    v.movi       v2, #2
    v.cmp.eq     p5, v4, v2
    v.movi       v2, #3
    v.cmp.eq     p6, v4, v2
    v.movi       v2, #4
    v.cmp.eq     p7, v4, v2
    v.movi       v2, #0
    .li       s1, #-1560706194
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v11, v4, v2
    .li       s1, #1313084713
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v4, v2, v11
    .li       s1, #-64530479
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v11, v2, v4
    .li       s1, #-181084736
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v4, v2, v11
    .li       s1, #-1560706194
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1313084713
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v13, v11, v2
    .li       s1, #-64530479
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v11, v2, v13
    .li       s1, #-181084736
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v13, v2, v11
    .li       s1, #-614296167
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v11, v2, v13
    .li       s1, #1313084713
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-64530479
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v14, v13, v2
    .li       s1, #-181084736
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v13, v2, v14
    .li       s1, #-614296167
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v14, v2, v13
    .li       s1, #1011060801
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v13, v2, v14
    .li       s1, #-64530479
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-181084736
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v15, v14, v2
    .li       s1, #-614296167
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v14, v2, v15
    .li       s1, #1011060801
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v15, v2, v14
    .li       s1, #-28220501
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v14, v2, v15
    v.movi       v2, #31
    v.sub        v15, v2, v12
    v.shl        v2, v4, v12
    v.movi       v4, #1
    v.lshr       v16, v11, v4
    v.lshr       v4, v16, v15
    v.or         v16, v2, v4
    v.shl        v2, v11, v12
    v.movi       v4, #1
    v.lshr       v11, v13, v4
    v.lshr       v4, v11, v15
    v.or         v11, v2, v4
    v.shl        v2, v13, v12
    v.movi       v4, #1
    v.lshr       v12, v14, v4
    v.lshr       v4, v12, v15
    v.or         v12, v2, v4
    v.mul        v2, v8, v12
    v.mulh.u     v4, v8, v12
    v.mul        v12, v8, v11
    v.add        v13, v12, v4
    v.cmp.ltu    p4, v13, v4
    v.movi       v4, #1
    v.movi       v12, #0
    @p4 v.sel        v14, v4, v12
    v.mul        v4, v8, v16
    v.mulh.u     v12, v8, v11
    v.add        v8, v4, v12
    v.add        v4, v8, v14
    .li       s1, #536870912
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v11, v4, v8
    v.movi       v8, #30
    v.lshr       v12, v11, v8
    v.movi       v8, #2
    v.shl        v11, v4, v8
    v.movi       v4, #30
    v.lshr       v8, v13, v4
    v.or         v4, v11, v8
    v.movi       v8, #2
    v.shl        v11, v13, v8
    v.movi       v8, #30
    v.lshr       v13, v2, v8
    v.or         v2, v11, v13
    v.movi       v8, #31
    v.ashr       v11, v4, v8
    v.xor        v8, v4, v11
    v.xor        v4, v2, v11
    v.movi       v2, #0
    v.cmp.ne     p4, v8, v2
    @p4 v.sel        v2, v8, v4
    v.movi       v8, #0
    @p4 v.sel        v13, v4, v8
    v.clz        v4, v2
    v.shl        v8, v2, v4
    v.movi       v14, #1
    v.lshr       v15, v13, v14
    v.movi       v14, #31
    v.sub        v16, v14, v4
    v.lshr       v14, v15, v16
    v.or         v15, v8, v14
    v.shl        v8, v13, v4
    v.movi       v13, #0
    v.movi       v14, #32
    @p4 v.sel        v16, v13, v14
    v.add        v13, v4, v16
    v.movi       v4, #8
    v.lshr       v14, v15, v4
    vf.cvt.u32.f32 v4, v14
    v.movi       v14, #255
    v.and        v16, v15, v14
    v.movi       v14, #16
    v.shl        v15, v16, v14
    v.movi       v14, #16
    v.lshr       v16, v8, v14
    v.or         v8, v15, v16
    vf.cvt.u32.f32 v14, v8
    v.movi       v8, #103
    v.sub        v15, v8, v13
    v.movi       v8, #23
    v.shl        v16, v15, v8
    vf.mul       v8, v4, v16
    v.movi       v4, #79
    v.sub        v15, v4, v13
    v.movi       v4, #23
    v.shl        v13, v15, v4
    vf.mul       v4, v14, v13
    v.movi       v13, #0
    v.cmp.eq     p4, v2, v13
    .li       s1, #-2147483648
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v13, v11, v2
    v.movi       v2, #0
    v.xor        v11, v8, v13
    @p4 v.sel        v8, v2, v11
    v.xor        v11, v4, v13
    @p4 v.sel        v4, v2, v11
    .li       s1, #1070141403
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v13, v8, v11
    vf.fms       v14, v8, v11, v13               // exact error of f_hi*pi/2
    .li       s1, #3007036718
    v.splat      v15, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v16, v8, v15, v14
    vf.fma       v8, v4, v11, v16
    v.movi       v4, #-1
    v.cmp.lt     p4, v6, v4
    v.movi       v4, #0
    @p4 v.sel        v14, v4, v12
    @p4 v.sel        v4, v0, v13
    @p4 v.sel        v0, v2, v8
    vf.mul       v8, v4, v4
    vf.fms       v12, v4, v4, v8                 // exact error of r*r
    .li       s1, #1056964608
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v16, v8, v13
    vf.mul       v17, v4, v8
    vf.neg       v18, v16
    vf.fma       v19, v18, v0, v0
    .li       s1, #909535061
    v.splat      v18, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3109029817
    v.splat      v20, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v21, v18, v8, v20
    .li       s1, #1007192196
    v.splat      v22, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v23, v21, v8, v22
    .li       s1, #3190467243
    v.splat      v21, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v24, v23, v8, v21
    vf.fma       v23, v17, v24, v19
    vf.add       v17, v4, v23
    .li       s1, #1065353216
    v.splat      v19, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.sub       v23, v19, v16
    vf.sub       v24, v19, v23
    vf.sub       v25, v24, v16
    .li       s1, #3204448256
    v.splat      v16, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v24, v16, v12, v25
    vf.neg       v12, v4
    vf.fma       v4, v12, v0, v24
    vf.mul       v0, v8, v8
    .li       s1, #936178630
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3132491283
    v.splat      v24, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v25, v12, v8, v24
    .li       s1, #1026206373
    v.splat      v26, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v27, v25, v8, v26
    vf.fma       v8, v0, v27, v4
    vf.add       v0, v23, v8
    v.movi       v4, #1
    v.and        v8, v14, v4
    v.movi       v4, #0
    v.cmp.ne     p4, v8, v4
    v.movi       v4, #128
    v.cmp.eq     p5, v6, v4
    v.movi       v4, #2
    v.and        v6, v14, v4
    v.movi       v4, #30
    v.shl        v8, v6, v4
    .li       s1, #-2147483648
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v6, v1, v4
    v.xor        v1, v8, v6
    .li       s1, #2143289344
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v6, v0, v17
    v.xor        v8, v6, v1
    @p5 v.sel        v1, v4, v8
    v.movi       v6, #1
    v.add        v8, v14, v6
    v.movi       v6, #2
    v.and        v14, v8, v6
    v.movi       v6, #30
    v.shl        v8, v14, v6
    @p4 v.sel        v6, v17, v0
    v.xor        v0, v6, v8
    @p5 v.sel        v6, v4, v0
    v.movi       v0, #31
    v.ashr       v8, v5, v0
    v.xor        v0, v3, v8
    v.sub        v3, v0, v8
    v.movi       v0, #0
    v.cmp.eq     p4, v3, v0
    v.movi       v0, #1
    v.movi       v14, #0
    @p4 v.sel        v17, v0, v14
    v.and        v0, v8, v17
    v.xor        v14, v5, v8
    v.add        v8, v14, v0
    vf.cvt.u32.f32 v0, v3                        // |x| < 2**32: one rounding
    v.clz        v14, v8
    v.movi       v17, #32
    v.sub        v23, v17, v14
    v.shl        v17, v8, v14
    v.movi       v25, #1
    v.sub        v27, v23, v25
    v.lshr       v25, v3, v27
    v.movi       v27, #1
    v.lshr       v28, v25, v27
    v.or         v25, v17, v28
    v.movi       v17, #-1
    v.lshr       v27, v17, v14
    v.and        v14, v3, v27
    v.movi       v3, #0
    v.cmp.ne     p4, v14, v3
    v.movi       v3, #1
    v.movi       v14, #0
    @p4 v.sel        v17, v3, v14
    v.or         v3, v25, v17
    vf.cvt.u32.f32 v14, v3                       // top 32 bits + sticky: one rounding
    v.movi       v3, #127
    v.add        v17, v23, v3
    v.movi       v3, #23
    v.shl        v23, v17, v3
    vf.mul       v3, v14, v23                    // * 2**n, exact
    v.movi       v14, #0
    v.cmp.eq     p4, v8, v14
    @p4 v.sel        v8, v0, v3
    v.movi       v0, #0
    v.cmp.lt     p4, v5, v0
    vf.neg       v0, v8
    @p4 v.sel        v3, v0, v8
    vf.mul       v0, v3, v7
    vf.abs       v3, v0
    v.movi       v5, #23
    v.lshr       v8, v3, v5
    v.movi       v5, #127
    v.sub        v14, v8, v5
    .li       s1, #8388607
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v8, v3, v5
    .li       s1, #8388608
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.or         v17, v8, v5
    v.movi       v5, #-1
    v.max.s      v8, v14, v5
    v.movi       v5, #7
    v.add        v23, v8, v5
    v.movi       v5, #5
    v.lshr       v8, v23, v5
    v.movi       v5, #31
    v.and        v25, v23, v5
    v.movi       v5, #1
    v.cmp.eq     p4, v8, v5
    v.movi       v5, #2
    v.cmp.eq     p5, v8, v5
    v.movi       v5, #3
    v.cmp.eq     p6, v8, v5
    v.movi       v5, #4
    v.cmp.eq     p7, v8, v5
    v.movi       v5, #0
    .li       s1, #-1560706194
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v23, v8, v5
    .li       s1, #1313084713
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v8, v5, v23
    .li       s1, #-64530479
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v23, v5, v8
    .li       s1, #-181084736
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v8, v5, v23
    .li       s1, #-1560706194
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1313084713
    v.splat      v23, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v27, v23, v5
    .li       s1, #-64530479
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v23, v5, v27
    .li       s1, #-181084736
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v27, v5, v23
    .li       s1, #-614296167
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v23, v5, v27
    .li       s1, #1313084713
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-64530479
    v.splat      v27, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v28, v27, v5
    .li       s1, #-181084736
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v27, v5, v28
    .li       s1, #-614296167
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v28, v5, v27
    .li       s1, #1011060801
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v27, v5, v28
    .li       s1, #-64530479
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-181084736
    v.splat      v28, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v29, v28, v5
    .li       s1, #-614296167
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v28, v5, v29
    .li       s1, #1011060801
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v29, v5, v28
    .li       s1, #-28220501
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v28, v5, v29
    v.movi       v5, #31
    v.sub        v29, v5, v25
    v.shl        v5, v8, v25
    v.movi       v8, #1
    v.lshr       v30, v23, v8
    v.lshr       v8, v30, v29
    v.or         v30, v5, v8
    v.shl        v5, v23, v25
    v.movi       v8, #1
    v.lshr       v23, v27, v8
    v.lshr       v8, v23, v29
    v.or         v23, v5, v8
    v.shl        v5, v27, v25
    v.movi       v8, #1
    v.lshr       v25, v28, v8
    v.lshr       v8, v25, v29
    v.or         v25, v5, v8
    v.mul        v5, v17, v25
    v.mulh.u     v8, v17, v25
    v.mul        v25, v17, v23
    v.add        v27, v25, v8
    v.cmp.ltu    p4, v27, v8
    v.movi       v8, #1
    v.movi       v25, #0
    @p4 v.sel        v28, v8, v25
    v.mul        v8, v17, v30
    v.mulh.u     v25, v17, v23
    v.add        v17, v8, v25
    v.add        v8, v17, v28
    .li       s1, #536870912
    v.splat      v17, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v23, v8, v17
    v.movi       v17, #30
    v.lshr       v25, v23, v17
    v.movi       v17, #2
    v.shl        v23, v8, v17
    v.movi       v8, #30
    v.lshr       v17, v27, v8
    v.or         v8, v23, v17
    v.movi       v17, #2
    v.shl        v23, v27, v17
    v.movi       v17, #30
    v.lshr       v27, v5, v17
    v.or         v5, v23, v27
    v.movi       v17, #31
    v.ashr       v23, v8, v17
    v.xor        v17, v8, v23
    v.xor        v8, v5, v23
    v.movi       v5, #0
    v.cmp.ne     p4, v17, v5
    @p4 v.sel        v5, v17, v8
    v.movi       v17, #0
    @p4 v.sel        v27, v8, v17
    v.clz        v8, v5
    v.shl        v17, v5, v8
    v.movi       v28, #1
    v.lshr       v29, v27, v28
    v.movi       v28, #31
    v.sub        v30, v28, v8
    v.lshr       v28, v29, v30
    v.or         v29, v17, v28
    v.shl        v17, v27, v8
    v.movi       v27, #0
    v.movi       v28, #32
    @p4 v.sel        v30, v27, v28
    v.add        v27, v8, v30
    v.movi       v8, #8
    v.lshr       v28, v29, v8
    vf.cvt.u32.f32 v8, v28
    v.movi       v28, #255
    v.and        v30, v29, v28
    v.movi       v28, #16
    v.shl        v29, v30, v28
    v.movi       v28, #16
    v.lshr       v30, v17, v28
    v.or         v17, v29, v30
    vf.cvt.u32.f32 v28, v17
    v.movi       v17, #103
    v.sub        v29, v17, v27
    v.movi       v17, #23
    v.shl        v30, v29, v17
    vf.mul       v17, v8, v30
    v.movi       v8, #79
    v.sub        v29, v8, v27
    v.movi       v8, #23
    v.shl        v27, v29, v8
    vf.mul       v8, v28, v27
    v.movi       v27, #0
    v.cmp.eq     p4, v5, v27
    .li       s1, #-2147483648
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v27, v23, v5
    v.xor        v5, v17, v27
    @p4 v.sel        v17, v2, v5
    v.xor        v5, v8, v27
    @p4 v.sel        v8, v2, v5
    vf.mul       v5, v17, v11
    vf.fms       v23, v17, v11, v5               // exact error of f_hi*pi/2
    vf.fma       v27, v17, v15, v23
    vf.fma       v17, v8, v11, v27
    v.movi       v8, #-1
    v.cmp.lt     p4, v14, v8
    v.movi       v8, #0
    @p4 v.sel        v23, v8, v25
    @p4 v.sel        v8, v3, v5
    @p4 v.sel        v3, v2, v17
    vf.mul       v5, v8, v8
    vf.fms       v17, v8, v8, v5                 // exact error of r*r
    vf.mul       v25, v5, v13
    vf.mul       v27, v8, v5
    vf.neg       v28, v25
    vf.fma       v29, v28, v3, v3
    vf.fma       v28, v18, v5, v20
    vf.fma       v30, v28, v5, v22
    vf.fma       v28, v30, v5, v21
    vf.fma       v30, v27, v28, v29
    vf.add       v27, v8, v30
    vf.sub       v28, v19, v25
    vf.sub       v29, v19, v28
    vf.sub       v30, v29, v25
    vf.fma       v25, v16, v17, v30
    vf.neg       v17, v8
    vf.fma       v8, v17, v3, v25
    vf.mul       v3, v5, v5
    vf.fma       v17, v12, v5, v24
    vf.fma       v25, v17, v5, v26
    vf.fma       v5, v3, v25, v8
    vf.add       v3, v28, v5
    v.movi       v5, #1
    v.and        v8, v23, v5
    v.movi       v5, #0
    v.cmp.ne     p4, v8, v5
    v.movi       v5, #128
    v.cmp.eq     p5, v14, v5
    v.movi       v5, #2
    v.and        v8, v23, v5
    v.movi       v5, #30
    v.shl        v14, v8, v5
    .li       s1, #-2147483648
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v8, v0, v5
    v.xor        v0, v14, v8
    @p4 v.sel        v5, v3, v27
    v.xor        v8, v5, v0
    @p5 v.sel        v0, v4, v8
    v.movi       v5, #1
    v.add        v8, v23, v5
    v.movi       v5, #2
    v.and        v14, v8, v5
    v.movi       v5, #30
    v.shl        v8, v14, v5
    @p4 v.sel        v5, v27, v3
    v.xor        v3, v5, v8
    @p5 v.sel        v5, v4, v3
    @p3 v.sel        v3, v1, v0
    v.movi       v0, #31
    v.ashr       v1, v10, v0
    v.xor        v0, v9, v1
    v.sub        v8, v0, v1
    v.movi       v0, #0
    v.cmp.eq     p4, v8, v0
    v.movi       v0, #1
    v.movi       v9, #0
    @p4 v.sel        v14, v0, v9
    v.and        v0, v1, v14
    v.xor        v9, v10, v1
    v.add        v1, v9, v0
    vf.cvt.u32.f32 v0, v8                        // |x| < 2**32: one rounding
    v.clz        v9, v1
    v.movi       v14, #32
    v.sub        v17, v14, v9
    v.shl        v14, v1, v9
    v.movi       v23, #1
    v.sub        v25, v17, v23
    v.lshr       v23, v8, v25
    v.movi       v25, #1
    v.lshr       v27, v23, v25
    v.or         v23, v14, v27
    v.movi       v14, #-1
    v.lshr       v25, v14, v9
    v.and        v9, v8, v25
    v.movi       v8, #0
    v.cmp.ne     p4, v9, v8
    v.movi       v8, #1
    v.movi       v9, #0
    @p4 v.sel        v14, v8, v9
    v.or         v8, v23, v14
    vf.cvt.u32.f32 v9, v8                        // top 32 bits + sticky: one rounding
    v.movi       v8, #127
    v.add        v14, v17, v8
    v.movi       v8, #23
    v.shl        v17, v14, v8
    vf.mul       v8, v9, v17                     // * 2**n, exact
    v.movi       v9, #0
    v.cmp.eq     p4, v1, v9
    @p4 v.sel        v1, v0, v8
    v.movi       v0, #0
    v.cmp.lt     p4, v10, v0
    vf.neg       v0, v1
    @p4 v.sel        v8, v0, v1
    vf.mul       v0, v8, v7
    vf.abs       v1, v0
    v.movi       v7, #23
    v.lshr       v8, v1, v7
    v.movi       v7, #127
    v.sub        v9, v8, v7
    .li       s1, #8388607
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v8, v1, v7
    .li       s1, #8388608
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.or         v10, v8, v7
    v.movi       v7, #-1
    v.max.s      v8, v9, v7
    v.movi       v7, #7
    v.add        v14, v8, v7
    v.movi       v7, #5
    v.lshr       v8, v14, v7
    v.movi       v7, #31
    v.and        v17, v14, v7
    v.movi       v7, #1
    v.cmp.eq     p4, v8, v7
    v.movi       v7, #2
    v.cmp.eq     p5, v8, v7
    v.movi       v7, #3
    v.cmp.eq     p6, v8, v7
    v.movi       v7, #4
    v.cmp.eq     p7, v8, v7
    v.movi       v7, #0
    .li       s1, #-1560706194
    v.splat      v8, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v14, v8, v7
    .li       s1, #1313084713
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v8, v7, v14
    .li       s1, #-64530479
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v14, v7, v8
    .li       s1, #-181084736
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v8, v7, v14
    .li       s1, #-1560706194
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1313084713
    v.splat      v14, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v23, v14, v7
    .li       s1, #-64530479
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v14, v7, v23
    .li       s1, #-181084736
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v23, v7, v14
    .li       s1, #-614296167
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v14, v7, v23
    .li       s1, #1313084713
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-64530479
    v.splat      v23, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v25, v23, v7
    .li       s1, #-181084736
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v23, v7, v25
    .li       s1, #-614296167
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v25, v7, v23
    .li       s1, #1011060801
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v23, v7, v25
    .li       s1, #-64530479
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #-181084736
    v.splat      v25, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p4 v.sel        v27, v25, v7
    .li       s1, #-614296167
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p5 v.sel        v25, v7, v27
    .li       s1, #1011060801
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p6 v.sel        v27, v7, v25
    .li       s1, #-28220501
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p7 v.sel        v25, v7, v27
    v.movi       v7, #31
    v.sub        v27, v7, v17
    v.shl        v7, v8, v17
    v.movi       v8, #1
    v.lshr       v28, v14, v8
    v.lshr       v8, v28, v27
    v.or         v28, v7, v8
    v.shl        v7, v14, v17
    v.movi       v8, #1
    v.lshr       v14, v23, v8
    v.lshr       v8, v14, v27
    v.or         v14, v7, v8
    v.shl        v7, v23, v17
    v.movi       v8, #1
    v.lshr       v17, v25, v8
    v.lshr       v8, v17, v27
    v.or         v17, v7, v8
    v.mul        v7, v10, v17
    v.mulh.u     v8, v10, v17
    v.mul        v17, v10, v14
    v.add        v23, v17, v8
    v.cmp.ltu    p4, v23, v8
    v.movi       v8, #1
    v.movi       v17, #0
    @p4 v.sel        v25, v8, v17
    v.mul        v8, v10, v28
    v.mulh.u     v17, v10, v14
    v.add        v10, v8, v17
    v.add        v8, v10, v25
    .li       s1, #536870912
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v14, v8, v10
    v.movi       v10, #30
    v.lshr       v17, v14, v10
    v.movi       v10, #2
    v.shl        v14, v8, v10
    v.movi       v8, #30
    v.lshr       v10, v23, v8
    v.or         v8, v14, v10
    v.movi       v10, #2
    v.shl        v14, v23, v10
    v.movi       v10, #30
    v.lshr       v23, v7, v10
    v.or         v7, v14, v23
    v.movi       v10, #31
    v.ashr       v14, v8, v10
    v.xor        v10, v8, v14
    v.xor        v8, v7, v14
    v.movi       v7, #0
    v.cmp.ne     p4, v10, v7
    @p4 v.sel        v7, v10, v8
    v.movi       v10, #0
    @p4 v.sel        v23, v8, v10
    v.clz        v8, v7
    v.shl        v10, v7, v8
    v.movi       v25, #1
    v.lshr       v27, v23, v25
    v.movi       v25, #31
    v.sub        v28, v25, v8
    v.lshr       v25, v27, v28
    v.or         v27, v10, v25
    v.shl        v10, v23, v8
    v.movi       v23, #0
    v.movi       v25, #32
    @p4 v.sel        v28, v23, v25
    v.add        v23, v8, v28
    v.movi       v8, #8
    v.lshr       v25, v27, v8
    vf.cvt.u32.f32 v8, v25
    v.movi       v25, #255
    v.and        v28, v27, v25
    v.movi       v25, #16
    v.shl        v27, v28, v25
    v.movi       v25, #16
    v.lshr       v28, v10, v25
    v.or         v10, v27, v28
    vf.cvt.u32.f32 v25, v10
    v.movi       v10, #103
    v.sub        v27, v10, v23
    v.movi       v10, #23
    v.shl        v28, v27, v10
    vf.mul       v10, v8, v28
    v.movi       v8, #79
    v.sub        v27, v8, v23
    v.movi       v8, #23
    v.shl        v23, v27, v8
    vf.mul       v8, v25, v23
    v.movi       v23, #0
    v.cmp.eq     p4, v7, v23
    .li       s1, #-2147483648
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v23, v14, v7
    v.xor        v7, v10, v23
    @p4 v.sel        v10, v2, v7
    v.xor        v7, v8, v23
    @p4 v.sel        v8, v2, v7
    vf.mul       v7, v10, v11
    vf.fms       v14, v10, v11, v7               // exact error of f_hi*pi/2
    vf.fma       v23, v10, v15, v14
    vf.fma       v10, v8, v11, v23
    v.movi       v8, #-1
    v.cmp.lt     p4, v9, v8
    v.movi       v8, #0
    @p4 v.sel        v11, v8, v17
    @p4 v.sel        v8, v1, v7
    @p4 v.sel        v1, v2, v10
    vf.mul       v2, v8, v8
    vf.fms       v7, v8, v8, v2                  // exact error of r*r
    vf.mul       v10, v2, v13
    vf.mul       v13, v8, v2
    vf.neg       v14, v10
    vf.fma       v15, v14, v1, v1
    vf.fma       v14, v18, v2, v20
    vf.fma       v17, v14, v2, v22
    vf.fma       v14, v17, v2, v21
    vf.fma       v17, v13, v14, v15
    vf.add       v13, v8, v17
    vf.sub       v14, v19, v10
    vf.sub       v15, v19, v14
    vf.sub       v17, v15, v10
    vf.fma       v10, v16, v7, v17
    vf.neg       v7, v8
    vf.fma       v8, v7, v1, v10
    vf.mul       v1, v2, v2
    vf.fma       v7, v12, v2, v24
    vf.fma       v10, v7, v2, v26
    vf.fma       v2, v1, v10, v8
    vf.add       v1, v14, v2
    v.movi       v2, #1
    v.and        v7, v11, v2
    v.movi       v2, #0
    v.cmp.ne     p4, v7, v2
    v.movi       v2, #128
    v.cmp.eq     p5, v9, v2
    v.movi       v2, #2
    v.and        v7, v11, v2
    v.movi       v2, #30
    v.shl        v8, v7, v2
    .li       s1, #-2147483648
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v7, v0, v2
    v.xor        v0, v8, v7
    @p4 v.sel        v2, v1, v13
    v.xor        v7, v2, v0
    @p5 v.sel        v0, v4, v7
    v.movi       v2, #1
    v.add        v7, v11, v2
    v.movi       v2, #2
    v.and        v8, v7, v2
    v.movi       v2, #30
    v.shl        v7, v8, v2
    @p4 v.sel        v2, v13, v1
    v.xor        v1, v2, v7
    @p5 v.sel        v2, v4, v1
    @p2 v.sel        v1, v3, v0
    @p3 v.sel        v0, v6, v5
    @p2 v.sel        v3, v0, v2
    s.shli       s1, s5, #2                      // element offset -> bytes (x4)
    s.add        s2, s19, s1                     // &out_ptr0[...]
    @p1 v.st.w       [s2, #0], v1
    s.add        s2, s29, s1                     // &out_ptr1[...]
    @p1 v.st.w       [s2, #0], v3
__rctx_next:
    exit
