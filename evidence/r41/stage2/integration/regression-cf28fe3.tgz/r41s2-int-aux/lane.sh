#!/bin/bash
# lane.sh TREE NAME CMD... : run commands sequentially in ~/TREE, logs to ~/r41s2-int-logs
tree=$1; name=$2; shift 2
. ~/tc_env/env.sh
export PATH=$HOME/tc_env/vlroot/bin:$PATH PYTHONPATH=$HOME/$tree/python CUDA_VISIBLE_DEVICES=
logdir=$HOME/r41s2-int-logs; mkdir -p $logdir
cd ~/$tree || exit 9
i=0
for c in "$@"; do
  i=$((i+1)); tag=$(printf %02d $i)_$(echo "$c" | tr -c 'a-zA-Z0-9-' _ | cut -c1-50)
  start=$(date +%s)
  echo "$(date -u +%FT%TZ) START $c" >> $logdir/$name.lane
  bash -c "$c" > $logdir/$name.$tag.log 2>&1
  rc=$?
  echo "$(date -u +%FT%TZ) END rc=$rc secs=$(( $(date +%s)-start )) $c" >> $logdir/$name.lane
done
echo "$(date -u +%FT%TZ) LANE-DONE" >> $logdir/$name.lane
