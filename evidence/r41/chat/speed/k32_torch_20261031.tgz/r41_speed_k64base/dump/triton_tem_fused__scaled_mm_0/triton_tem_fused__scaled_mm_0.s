    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // out_ptr0: device_ptr64 at arg_base+32
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #40]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s1, s7, #4096                   // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s7, #0
    s.st.d       [s1, #0], s3
    .li       s3, #2147483647
    s.st.d       [s1, #8], s3
    s.st.d       [s1, #16], s3
    s.movz       s3, #64
    s.st.d       [s1, #48], s3
    s.movz       s3, #1
    s.st.d       [s1, #56], s3
    .li       s8, #68719476752
    s.st.d       [s1, #88], s8
    .li       s8, #7705171329024
    s.st.d       [s1, #104], s8
    fence.release.device
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s1, pid.x
    s.sub        s8, s3, s1
    s.min.s      s9, s8, s3
    s.cmp.lt     s8, s1, s7
    s.sub        s10, s7, s8
    s.cmp.lt     s8, s9, s7
    s.sub        s11, s7, s8
    s.xor        s8, s1, s10
    s.sub        s12, s8, s10
    s.xor        s8, s9, s11
    s.sub        s13, s8, s11
    s.addi       s8, s7, #0
    s.addi       s11, s7, #0
    s.cmp.eq     s14, s13, s3
    s.mov        s8, s12
    br.nz        s14, sdiv_done_1
    s.movz       s14, #0
    s.movz       s15, #31
    s.mov        s8, s14
    s.addi       s14, s15, #0
sdiv_2:
    s.lshr       s15, s12, s14
    s.shli       s16, s11, #1
    s.andi       s17, s15, #1
    s.shl        s15, s3, s14
    s.or         s18, s16, s17
    s.subi       s16, s14, #1
    s.cmp.geu    s17, s18, s13
    s.sub        s19, s7, s17
    s.and        s17, s13, s19
    s.and        s20, s15, s19
    s.sub        s15, s18, s17
    s.or         s17, s8, s20
    s.mov        s11, s15
    s.mov        s8, s17
    s.mov        s14, s16
    s.cmp.ge     s15, s14, s7
    br.nz        s15, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.xor        s7, s11, s10
    s.cmp.lt     s8, s9, s3
    s.cmp.lt     s11, s3, s3
    s.sub        s12, s3, s8
    s.sub        s8, s3, s11
    s.xor        s11, s9, s12
    s.xor        s9, s3, s8
    s.sub        s13, s11, s12
    s.movz       s11, #1
    s.sub        s14, s7, s10
    s.sub        s7, s9, s8
    s.addi       s9, s3, #0
    s.cmp.eq     s10, s13, s11
    s.add        s15, s1, s14
    s.addi       s1, s3, #0
    s.mov        s9, s7
    br.nz        s10, sdiv_done_3
    s.movz       s10, #0
    s.movz       s14, #31
    s.mov        s9, s10
    s.addi       s10, s14, #0
sdiv_4:
    s.lshr       s14, s7, s10
    s.shli       s16, s1, #1
    s.andi       s17, s14, #1
    s.shl        s14, s11, s10
    s.or         s18, s16, s17
    s.subi       s16, s10, #1
    s.cmp.geu    s17, s18, s13
    s.sub        s19, s3, s17
    s.and        s17, s13, s19
    s.and        s20, s14, s19
    s.sub        s14, s18, s17
    s.or         s17, s9, s20
    s.mov        s1, s14
    s.mov        s9, s17
    s.mov        s10, s16
    s.cmp.ge     s14, s10, s3
    br.nz        s14, sdiv_4
sdiv_done_3:
    s.movz       s1, #16
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.rdspecial  s7, arg_base
    s.mul        s10, s15, s1
    s.ld.d       s11, [s7, #40]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.movz       s7, #32
    s.movz       s13, #48
    s.xor        s14, s8, s12
    s.andi       s8, s10, #15
    s.xor        s12, s9, s14
    s.muli       s9, s8, #64                     // a runtime tile origin, x64
    s.sub        s16, s12, s14
    v.splat      v0, s15
    s.mul        s12, s16, s1
    v.splat      v1, s3
    s.add        s3, s2, s9                      // the tile origin
    s.addi       s9, s11, #0
    v.ld.b       v2, [s3, #0]
    s.addi       s14, s3, #64                    // row 1
    s.addi       s15, s9, #64
    s.addi       s17, s3, #128                   // row 2
    s.addi       s18, s9, #128
    s.addi       s19, s3, #192                   // row 3
    s.addi       s20, s9, #192
    v.splat      v3, s16
    s.addi       s16, s3, #256                   // row 4
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s10
    v.splat      v6, s12
    v.st.w       [s9, #0], v2
    v.splat      v2, s8
    v.iota       v7                              // arange(0, VLEN)
    v.movi       v8, #16
    v.movi       v9, #32
    v.iota       v10                             // arange(0, VLEN)
    v.cmp.ge     p1, v0, v1
    v.movi       v0, #48
    v.cmp.ge     p1, v3, v1
    v.add        v1, v5, v4
    v.add        v1, v6, v4
    v.add        v1, v2, v4
    v.add        v1, v7, v8
    v.add        v1, v7, v9
    v.add        v1, v10, v0
    v.ld.b       v0, [s14, #0]
    s.addi       s14, s9, #256
    v.st.w       [s15, #0], v0
    s.addi       s15, s3, #320                   // row 5
    v.ld.b       v0, [s17, #0]
    s.addi       s17, s9, #320
    v.st.w       [s18, #0], v0
    s.addi       s18, s3, #384                   // row 6
    v.ld.b       v0, [s19, #0]
    s.addi       s19, s9, #384
    v.st.w       [s20, #0], v0
    s.addi       s20, s3, #448                   // row 7
    v.ld.b       v0, [s16, #0]
    s.addi       s16, s9, #448
    v.st.w       [s14, #0], v0
    s.andi       s14, s12, #15
    v.splat      v0, s14
    v.add        v1, v0, v7
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s3, #512                   // row 8
    v.st.w       [s17, #0], v0
    s.addi       s17, s9, #512
    v.ld.b       v0, [s18, #0]
    s.addi       s18, s3, #576                   // row 9
    v.st.w       [s19, #0], v0
    s.addi       s19, s9, #576
    v.ld.b       v0, [s20, #0]
    s.addi       s20, s3, #640                   // row 10
    v.st.w       [s16, #0], v0
    s.addi       s16, s9, #640
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s3, #704                   // row 11
    v.st.w       [s17, #0], v0
    s.addi       s17, s9, #704
    v.ld.b       v0, [s18, #0]
    s.addi       s18, s3, #768                   // row 12
    v.st.w       [s19, #0], v0
    s.addi       s19, s9, #768
    v.ld.b       v0, [s20, #0]
    s.addi       s20, s3, #832                   // row 13
    v.st.w       [s16, #0], v0
    s.addi       s16, s9, #832
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s3, #896                   // row 14
    s.addi       s21, s3, #960                   // row 15
    v.st.w       [s17, #0], v0
    s.addi       s3, s9, #896
    s.addi       s17, s9, #960
    v.ld.b       v0, [s18, #0]
    s.muli       s9, s8, #64                     // a runtime tile origin, x64
    v.st.w       [s19, #0], v0
    s.add        s18, s2, s1                     // the tile origin
    s.add        s19, s18, s9                    // the tile origin
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.addi       s9, s11, #1024
    v.ld.b       v0, [s20, #0]
    s.addi       s18, s19, #64                   // row 1
    v.st.w       [s16, #0], v0
    s.addi       s16, s9, #64
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s19, #128                  // row 2
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #128
    v.ld.b       v0, [s21, #0]
    s.addi       s20, s19, #192                  // row 3
    v.st.w       [s17, #0], v0
    fence.acq_rel.device
    s.addi       s17, s9, #192
    v.ld.b       v0, [s19, #0]
    v.st.w       [s9, #0], v0
    v.ld.b       v0, [s18, #0]
    s.addi       s18, s19, #256                  // row 4
    v.st.w       [s16, #0], v0
    s.addi       s16, s9, #256
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s19, #320                  // row 5
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #320
    v.ld.b       v0, [s20, #0]
    s.addi       s20, s19, #384                  // row 6
    v.st.w       [s17, #0], v0
    s.addi       s17, s9, #384
    v.ld.b       v0, [s18, #0]
    s.addi       s18, s19, #448                  // row 7
    v.st.w       [s16, #0], v0
    s.addi       s16, s9, #448
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s19, #512                  // row 8
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #512
    v.ld.b       v0, [s20, #0]
    s.addi       s20, s19, #576                  // row 9
    v.st.w       [s17, #0], v0
    s.addi       s17, s9, #576
    v.ld.b       v0, [s18, #0]
    s.addi       s18, s19, #640                  // row 10
    v.st.w       [s16, #0], v0
    s.addi       s16, s9, #640
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s19, #704                  // row 11
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #704
    v.ld.b       v0, [s20, #0]
    s.addi       s20, s19, #768                  // row 12
    v.st.w       [s17, #0], v0
    s.addi       s17, s9, #768
    v.ld.b       v0, [s18, #0]
    s.addi       s18, s19, #832                  // row 13
    v.st.w       [s16, #0], v0
    s.addi       s16, s9, #832
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s19, #896                  // row 14
    s.addi       s21, s19, #960                  // row 15
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #896
    s.addi       s19, s9, #960
    v.ld.b       v0, [s20, #0]
    s.muli       s9, s8, #64                     // a runtime tile origin, x64
    v.st.w       [s17, #0], v0
    s.add        s17, s2, s7                     // the tile origin
    s.add        s20, s17, s9                    // the tile origin
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.addi       s9, s11, #2048
    v.ld.b       v0, [s18, #0]
    s.addi       s17, s20, #64                   // row 1
    v.st.w       [s16, #0], v0
    s.addi       s16, s9, #64
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s20, #128                  // row 2
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #128
    v.ld.b       v0, [s21, #0]
    s.addi       s18, s20, #192                  // row 3
    v.st.w       [s19, #0], v0
    fence.acq_rel.device
    s.addi       s19, s9, #192
    v.ld.b       v0, [s20, #0]
    v.st.w       [s9, #0], v0
    v.ld.b       v0, [s17, #0]
    s.addi       s17, s20, #256                  // row 4
    v.st.w       [s16, #0], v0
    s.addi       s16, s9, #256
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s20, #320                  // row 5
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #320
    v.ld.b       v0, [s18, #0]
    s.addi       s18, s20, #384                  // row 6
    v.st.w       [s19, #0], v0
    s.addi       s19, s9, #384
    s.add        s21, s2, s13                    // the tile origin
    v.ld.b       v0, [s17, #0]
    s.addi       s2, s20, #448                   // row 7
    s.muli       s17, s8, #64                    // a runtime tile origin, x64
    v.st.w       [s16, #0], v0
    s.addi       s8, s9, #448
    s.add        s16, s21, s17                   // the tile origin
    s.addi       s17, s20, #512                  // row 8
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s9, #512
    v.st.w       [s3, #0], v0
    s.addi       s3, s20, #576                   // row 9
    v.ld.b       v0, [s18, #0]
    s.addi       s18, s9, #576
    v.st.w       [s19, #0], v0
    s.addi       s19, s20, #640                  // row 10
    v.ld.b       v0, [s2, #0]
    s.addi       s2, s9, #640
    v.st.w       [s8, #0], v0
    s.addi       s8, s20, #704                   // row 11
    v.ld.b       v0, [s17, #0]
    s.addi       s17, s9, #704
    v.st.w       [s15, #0], v0
    s.addi       s15, s20, #768                  // row 12
    v.ld.b       v0, [s3, #0]
    s.addi       s3, s9, #768
    v.st.w       [s18, #0], v0
    s.addi       s18, s20, #832                  // row 13
    v.ld.b       v0, [s19, #0]
    s.addi       s19, s9, #832
    v.st.w       [s2, #0], v0
    s.addi       s2, s20, #896                   // row 14
    s.addi       s21, s20, #960                  // row 15
    v.ld.b       v0, [s8, #0]
    s.addi       s8, s9, #896
    s.addi       s20, s9, #960
    v.st.w       [s17, #0], v0
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.addi       s9, s11, #3072
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s16, #64                   // row 1
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #64
    v.ld.b       v0, [s18, #0]
    s.addi       s17, s16, #128                  // row 2
    v.st.w       [s19, #0], v0
    s.addi       s18, s9, #128
    v.ld.b       v0, [s2, #0]
    s.addi       s2, s16, #192                   // row 3
    v.st.w       [s8, #0], v0
    s.addi       s8, s9, #192
    v.ld.b       v0, [s21, #0]
    s.addi       s19, s16, #256                  // row 4
    v.st.w       [s20, #0], v0
    fence.acq_rel.device
    s.addi       s20, s9, #256
    v.ld.b       v0, [s16, #0]
    v.st.w       [s9, #0], v0
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s16, #320                  // row 5
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #320
    v.ld.b       v0, [s17, #0]
    s.addi       s17, s16, #384                  // row 6
    v.st.w       [s18, #0], v0
    s.addi       s18, s9, #384
    v.ld.b       v0, [s2, #0]
    s.addi       s2, s16, #448                   // row 7
    v.st.w       [s8, #0], v0
    s.addi       s8, s9, #448
    v.ld.b       v0, [s19, #0]
    s.addi       s19, s16, #512                  // row 8
    v.st.w       [s20, #0], v0
    s.addi       s20, s9, #512
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s16, #576                  // row 9
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #576
    v.ld.b       v0, [s17, #0]
    s.addi       s17, s16, #640                  // row 10
    v.st.w       [s18, #0], v0
    s.addi       s18, s9, #640
    v.ld.b       v0, [s2, #0]
    s.addi       s2, s16, #704                   // row 11
    v.st.w       [s8, #0], v0
    s.addi       s8, s9, #704
    v.ld.b       v0, [s19, #0]
    s.addi       s19, s16, #768                  // row 12
    v.st.w       [s20, #0], v0
    s.addi       s20, s9, #768
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s16, #832                  // row 13
    v.st.w       [s3, #0], v0
    s.addi       s3, s9, #832
    v.ld.b       v0, [s17, #0]
    s.addi       s17, s16, #896                  // row 14
    s.addi       s21, s16, #960                  // row 15
    v.st.w       [s18, #0], v0
    s.addi       s16, s9, #896
    s.addi       s18, s9, #960
    v.ld.b       v0, [s2, #0]
    s.movz       s2, #0
    v.st.w       [s8, #0], v0
    s.addi       s8, s11, #0
    v.ld.b       v0, [s19, #0]
    s.addi       s9, s11, #4352                  // 1024 bytes of repack scratch
    v.st.w       [s20, #0], v0
    s.addi       s19, s11, #64
    v.ld.b       v0, [s15, #0]
    s.addi       s15, s9, #64
    v.st.w       [s3, #0], v0
    s.addi       s3, s11, #128
    v.ld.b       v0, [s17, #0]
    s.addi       s17, s9, #128
    v.st.w       [s16, #0], v0
    s.addi       s16, s11, #192
    v.ld.b       v0, [s21, #0]
    s.addi       s20, s9, #192
    v.st.w       [s18, #0], v0
    fence.acq_rel.device
    w.def        w0, #16, #4                     // v16..v19
    mb.arm       s18, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s21, s11, #256
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s22, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s23, s2                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b.t w0, d0, s22, s18
    mb.wait      s18
    w.def        w1, #20, #4                     // v20..v23
    mb.arm       s2, b1, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.addi       s22, s9, #256
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s23, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s24, s1                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b.t w1, d0, s23, s2
    mb.wait      s2
    w.def        w2, #24, #4                     // v24..v27
    mb.arm       s23, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s24, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s25, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b.t w2, d0, s24, s23
    mb.wait      s23
    w.def        w3, #28, #4                     // v28..v31
    mb.arm       s7, b3, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.addi       s24, s11, #320
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s25, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s26, s13                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b.t w3, d0, s25, s7
    mb.wait      s7
    v.ld.w       v0, [s8, #0]
    s.addi       s8, s9, #320
    s.addi       s13, s11, #384
    s.addi       s14, s9, #384
    v.st.b       [s9, #0], v0
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s11, #448
    v.st.b       [s15, #0], v0
    s.addi       s15, s9, #448
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s11, #512
    v.st.b       [s17, #0], v0
    s.addi       s17, s9, #512
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #576
    v.st.b       [s20, #0], v0
    s.addi       s20, s9, #576
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s11, #640
    v.st.b       [s22, #0], v0
    s.addi       s22, s9, #640
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s11, #704
    v.st.b       [s8, #0], v0
    s.addi       s8, s9, #704
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #768
    v.st.b       [s14, #0], v0
    s.addi       s14, s9, #768
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s11, #832
    v.st.b       [s15, #0], v0
    s.addi       s15, s9, #832
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s11, #896
    v.st.b       [s17, #0], v0
    s.addi       s17, s9, #896
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #960
    v.st.b       [s20, #0], v0
    s.addi       s20, s9, #960
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s11, #1024
    v.st.b       [s22, #0], v0
    s.addi       s22, s9, #16
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s11, #1088
    v.st.b       [s8, #0], v0
    s.addi       s8, s9, #80
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #1152
    v.st.b       [s14, #0], v0
    s.addi       s14, s9, #144
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s11, #1216
    v.st.b       [s15, #0], v0
    s.addi       s15, s9, #208
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s11, #1280
    v.st.b       [s17, #0], v0
    s.addi       s17, s9, #272
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #1344
    v.st.b       [s20, #0], v0
    s.addi       s20, s9, #336
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s11, #1408
    v.st.b       [s22, #0], v0
    s.addi       s22, s9, #400
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s11, #1472
    v.st.b       [s8, #0], v0
    s.addi       s8, s9, #464
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #1536
    v.st.b       [s14, #0], v0
    s.addi       s14, s9, #528
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s11, #1600
    v.st.b       [s15, #0], v0
    s.addi       s15, s9, #592
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s11, #1664
    v.st.b       [s17, #0], v0
    s.addi       s17, s9, #656
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #1728
    v.st.b       [s20, #0], v0
    s.addi       s20, s9, #720
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s11, #1792
    v.st.b       [s22, #0], v0
    s.addi       s22, s9, #784
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s11, #1856
    v.st.b       [s8, #0], v0
    s.addi       s8, s9, #848
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #1920
    v.st.b       [s14, #0], v0
    s.addi       s14, s9, #912
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s11, #1984
    v.st.b       [s15, #0], v0
    s.addi       s15, s9, #976
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s11, #2048
    v.st.b       [s17, #0], v0
    s.addi       s17, s9, #32
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #2112
    v.st.b       [s20, #0], v0
    s.addi       s20, s9, #96
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s11, #2176
    v.st.b       [s22, #0], v0
    s.addi       s22, s9, #160
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s11, #2240
    v.st.b       [s8, #0], v0
    s.addi       s8, s9, #224
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #2304
    v.st.b       [s14, #0], v0
    s.addi       s14, s9, #288
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s11, #2368
    v.st.b       [s15, #0], v0
    s.addi       s15, s9, #352
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s11, #2432
    v.st.b       [s17, #0], v0
    s.addi       s17, s9, #416
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #2496
    v.st.b       [s20, #0], v0
    s.addi       s20, s9, #480
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s11, #2560
    v.st.b       [s22, #0], v0
    s.addi       s22, s9, #544
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s11, #2624
    v.st.b       [s8, #0], v0
    s.addi       s8, s9, #608
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #2688
    v.st.b       [s14, #0], v0
    s.addi       s14, s9, #672
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s11, #2752
    v.st.b       [s15, #0], v0
    s.addi       s15, s9, #736
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s11, #2816
    v.st.b       [s17, #0], v0
    s.addi       s17, s9, #800
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #2880
    v.st.b       [s20, #0], v0
    s.addi       s20, s9, #864
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s11, #2944
    v.st.b       [s22, #0], v0
    s.addi       s22, s9, #928
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s11, #3008
    v.st.b       [s8, #0], v0
    s.addi       s8, s9, #992
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #3072
    v.st.b       [s14, #0], v0
    s.addi       s14, s9, #48
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s11, #3136
    v.st.b       [s15, #0], v0
    s.addi       s15, s9, #112
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s11, #3200
    v.st.b       [s17, #0], v0
    s.addi       s17, s9, #176
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #3264
    v.st.b       [s20, #0], v0
    s.addi       s20, s9, #240
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s11, #3328
    v.st.b       [s22, #0], v0
    s.addi       s22, s9, #304
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s11, #3392
    v.st.b       [s8, #0], v0
    s.addi       s8, s9, #368
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #3456
    v.st.b       [s14, #0], v0
    s.addi       s14, s9, #432
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s11, #3520
    v.st.b       [s15, #0], v0
    s.addi       s15, s9, #496
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s11, #3584
    v.st.b       [s17, #0], v0
    s.addi       s17, s9, #560
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #3648
    v.st.b       [s20, #0], v0
    s.addi       s20, s9, #624
    v.ld.w       v0, [s21, #0]
    s.addi       s21, s11, #3712
    v.st.b       [s22, #0], v0
    s.addi       s22, s9, #688
    v.ld.w       v0, [s24, #0]
    s.addi       s24, s11, #3776
    v.st.b       [s8, #0], v0
    s.addi       s8, s9, #752
    v.ld.w       v0, [s13, #0]
    s.addi       s13, s11, #3840
    v.st.b       [s14, #0], v0
    s.addi       s14, s9, #816
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s11, #3904
    v.st.b       [s15, #0], v0
    s.addi       s15, s9, #880
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s11, #3968
    v.st.b       [s17, #0], v0
    s.addi       s17, s9, #944
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s11, #4032
    s.addi       s25, s11, #5376                 // TensorMap 1: K-wide matrix repack
    v.st.b       [s20, #0], v0
    s.addi       s11, s9, #1008
    v.ld.w       v0, [s21, #0]
    s.movz       s20, #16
    v.st.b       [s22, #0], v0
    s.movz       s21, #64
    v.ld.w       v0, [s24, #0]
    s.movz       s22, #1
    v.st.b       [s8, #0], v0
    .li       s8, #274877906960
    v.ld.w       v0, [s13, #0]
    .li       s13, #7705171329024
    v.st.b       [s14, #0], v0
    s.movz       s14, #0
    v.ld.w       v0, [s19, #0]
    v.st.b       [s15, #0], v0
    v.ld.w       v0, [s3, #0]
    v.st.b       [s17, #0], v0
    v.ld.w       v0, [s16, #0]
    v.st.b       [s11, #0], v0
    fence.acq_rel.device
    s.st.d       [s25, #0], s9
    s.st.d       [s25, #8], s20
    s.st.d       [s25, #16], s21
    s.st.d       [s25, #48], s21
    s.st.d       [s25, #56], s22
    v.movi       v0, #0
    s.st.d       [s25, #88], s8
    s.st.d       [s25, #104], s13
    fence.release.device
    td.load      d1, [s25]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w4, #32, #16                    // v32..v47
    mb.arm       s3, b4, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.muli       s8, s12, #2                     // a runtime tile origin, x2
    s.muli       s9, s10, #32                    // a runtime tile origin, x32
    // K-wide matrix repack: one tile into a window (ISA sec 9E)
    s.mov        s15, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s16, s14                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w4, d1, s15, s3
    mb.wait      s3
    w.def        w5, #48, #16                    // v48..v63
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s11, #0
    s.add        s13, s6, s8                     // the tile origin
    v.mov        v48, v16                        // hand off through the shared window (sec 7.3)
    v.mov        v49, v17                        // hand off through the shared window (sec 7.3)
    v.mov        v50, v18                        // hand off through the shared window (sec 7.3)
    v.mov        v51, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v52, v20                        // hand off through the shared window (sec 7.3)
    v.mov        v53, v21                        // hand off through the shared window (sec 7.3)
    v.mov        v54, v22                        // hand off through the shared window (sec 7.3)
    v.mov        v55, v23                        // hand off through the shared window (sec 7.3)
    v.mov        v56, v24                        // hand off through the shared window (sec 7.3)
    v.mov        v57, v25                        // hand off through the shared window (sec 7.3)
    v.mov        v58, v26                        // hand off through the shared window (sec 7.3)
    v.mov        v59, v27                        // hand off through the shared window (sec 7.3)
    v.mov        v60, v28                        // hand off through the shared window (sec 7.3)
    v.mov        v61, v29                        // hand off through the shared window (sec 7.3)
    v.mov        v62, v30                        // hand off through the shared window (sec 7.3)
    v.mov        v63, v31                        // hand off through the shared window (sec 7.3)
    m.zero       a0
    mb.arm       s6, b5, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.add        s8, s11, s12                    // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    m.mma.dp.async.k64.e4m3 a0, v32, v48, s6
    mb.wait      s6
    s.ld.w       s12, [s4, #0]                   // one element, not a vector
    v.splat      v2, s8
    s.add        s4, s11, s10                    // the tile origin
    v.splat      v3, s1
    v.splat      v4, s4
    v.add        v5, v1, v2
    s.add        s1, s13, s9                     // the tile origin
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v5, v3
    p.and        p3, p1, p2
    s.movz       s8, #1
    s.ld.w       s9, [s5, #0]                    // one element, not a vector
    v.splat      v1, s12
    a.vread      v2, a0, s11
    s.addi       s5, s4, #1
    s.addi       s10, s1, #32                    // row 1
    vf.add       v4, v2, v0
    v.splat      v2, s5
    s.movz       s5, #2
    s.addi       s11, s4, #2
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    v.splat      v2, s9
    v.splat      v5, s11
    s.addi       s9, s1, #64                     // row 2
    vf.mul       v6, v1, v2
    vf.mul       v7, v1, v2
    vf.mul       v8, v1, v2
    s.movz       s11, #3
    vf.mul       v9, v1, v2
    vf.mul       v10, v4, v6
    s.addi       s12, s4, #3
    s.addi       s13, s1, #96                    // row 3
    v.splat      v4, s12
    vf.cvt.f32.bf16 v6, v10
    s.movz       s12, #4
    vf.mul       v10, v1, v2
    s.addi       s14, s4, #4
    s.addi       s15, s1, #128                   // row 4
    @p3 v.st.h       [s1, #0], v6
    a.vread      v6, a0, s8
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.add       v5, v6, v0
    v.splat      v6, s14
    s.movz       s8, #5
    vf.mul       v11, v5, v7
    vf.mul       v5, v1, v2
    vf.cvt.f32.bf16 v7, v11
    s.addi       s14, s4, #5
    s.addi       s16, s1, #160                   // row 5
    @p4 v.st.h       [s10, #0], v7
    a.vread      v7, a0, s5
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    vf.add       v4, v7, v0
    v.splat      v7, s14
    s.movz       s5, #6
    vf.mul       v11, v4, v8
    vf.mul       v4, v1, v2
    vf.cvt.f32.bf16 v8, v11
    s.addi       s10, s4, #6
    s.addi       s14, s1, #192                   // row 6
    @p3 v.st.h       [s9, #0], v8
    a.vread      v8, a0, s11
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.add       v6, v8, v0
    v.splat      v8, s10
    s.movz       s9, #7
    vf.mul       v11, v6, v9
    vf.mul       v6, v1, v2
    vf.cvt.f32.bf16 v9, v11
    s.addi       s10, s4, #7
    s.addi       s11, s1, #224                   // row 7
    @p4 v.st.h       [s13, #0], v9
    a.vread      v9, a0, s12
    v.cmp.lt     p1, v7, v3
    p.and        p4, p1, p2
    vf.add       v7, v9, v0
    v.splat      v9, s10
    s.movz       s10, #8
    vf.mul       v11, v7, v10
    vf.mul       v7, v1, v2
    vf.cvt.f32.bf16 v10, v11
    s.addi       s12, s4, #8
    s.addi       s13, s1, #256                   // row 8
    @p3 v.st.h       [s15, #0], v10
    a.vread      v10, a0, s8
    v.cmp.lt     p1, v8, v3
    p.and        p3, p1, p2
    vf.add       v8, v10, v0
    v.splat      v10, s12
    s.movz       s8, #9
    vf.mul       v11, v8, v5
    vf.mul       v5, v1, v2
    vf.cvt.f32.bf16 v8, v11
    s.addi       s12, s4, #9
    s.addi       s15, s1, #288                   // row 9
    @p4 v.st.h       [s16, #0], v8
    a.vread      v8, a0, s5
    v.cmp.lt     p1, v9, v3
    p.and        p4, p1, p2
    vf.add       v9, v8, v0
    v.splat      v8, s12
    s.movz       s5, #10
    vf.mul       v11, v9, v4
    vf.mul       v4, v1, v2
    vf.cvt.f32.bf16 v9, v11
    s.addi       s12, s4, #10
    s.addi       s16, s1, #320                   // row 10
    @p3 v.st.h       [s14, #0], v9
    a.vread      v9, a0, s9
    v.cmp.lt     p1, v10, v3
    p.and        p3, p1, p2
    vf.add       v10, v9, v0
    v.splat      v9, s12
    s.movz       s9, #11
    vf.mul       v11, v10, v6
    vf.mul       v6, v1, v2
    vf.cvt.f32.bf16 v10, v11
    s.addi       s12, s4, #11
    s.addi       s14, s1, #352                   // row 11
    @p4 v.st.h       [s11, #0], v10
    a.vread      v10, a0, s10
    v.cmp.lt     p1, v8, v3
    p.and        p4, p1, p2
    vf.add       v8, v10, v0
    v.splat      v10, s12
    s.movz       s10, #12
    vf.mul       v11, v8, v7
    vf.mul       v7, v1, v2
    vf.cvt.f32.bf16 v8, v11
    s.addi       s11, s4, #12
    s.addi       s12, s1, #384                   // row 12
    @p3 v.st.h       [s13, #0], v8
    a.vread      v8, a0, s8
    v.cmp.lt     p1, v9, v3
    p.and        p3, p1, p2
    vf.add       v9, v8, v0
    v.splat      v8, s11
    s.movz       s8, #13
    vf.mul       v11, v9, v5
    vf.mul       v5, v1, v2
    vf.cvt.f32.bf16 v9, v11
    s.addi       s11, s4, #13
    s.addi       s13, s1, #416                   // row 13
    @p4 v.st.h       [s15, #0], v9
    a.vread      v9, a0, s5
    v.cmp.lt     p1, v10, v3
    p.and        p4, p1, p2
    vf.add       v10, v9, v0
    v.splat      v9, s11
    s.movz       s5, #14
    vf.mul       v11, v10, v4
    vf.mul       v4, v1, v2
    vf.cvt.f32.bf16 v10, v11
    s.addi       s11, s4, #14
    s.addi       s15, s1, #448                   // row 14
    @p3 v.st.h       [s16, #0], v10
    a.vread      v10, a0, s9
    v.cmp.lt     p1, v8, v3
    p.and        p3, p1, p2
    vf.add       v8, v10, v0
    v.splat      v10, s11
    s.movz       s9, #15
    vf.mul       v11, v1, v2
    vf.mul       v1, v8, v6
    vf.cvt.f32.bf16 v2, v1
    s.addi       s11, s4, #15
    s.addi       s4, s1, #480                    // row 15
    v.splat      v1, s11
    @p4 v.st.h       [s14, #0], v2
    a.vread      v2, a0, s10
    v.cmp.lt     p1, v9, v3
    p.and        p4, p1, p2
    vf.add       v6, v2, v0
    vf.mul       v2, v6, v7
    vf.cvt.f32.bf16 v6, v2
    @p3 v.st.h       [s12, #0], v6
    a.vread      v2, a0, s8
    v.cmp.lt     p1, v10, v3
    p.and        p3, p1, p2
    vf.add       v6, v2, v0
    vf.mul       v2, v6, v5
    vf.cvt.f32.bf16 v5, v2
    @p4 v.st.h       [s13, #0], v5
    a.vread      v2, a0, s5
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    vf.add       v1, v2, v0
    vf.mul       v2, v1, v4
    vf.cvt.f32.bf16 v1, v2
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a0, s9
    vf.add       v2, v1, v0
    vf.mul       v0, v2, v11
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s4, #0], v1
    exit
    exit
