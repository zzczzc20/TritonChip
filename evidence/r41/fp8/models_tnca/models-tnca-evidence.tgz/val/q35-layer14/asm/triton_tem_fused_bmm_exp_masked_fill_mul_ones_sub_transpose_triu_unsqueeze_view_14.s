    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #4
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #2
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s1, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s6, #0
    s.cmp.lt     s8, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s8
    s.sub        s8, s6, s9
    s.xor        s6, s12, s3
    s.muli       s9, s5, #4
    s.movz       s5, #0
    s.movz       s11, #1
    s.xor        s13, s4, s8
    s.sub        s14, s6, s3
    s.rdspecial  s3, arg_base
    s.xor        s6, s1, s7
    s.movz       s15, #0
    s.sub        s16, s13, s8
    s.addi       s13, s5, #0
    s.cmp.eq     s5, s14, s11
    s.ld.d       s11, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s17, s6, s7
    s.sub        s6, s2, s9
    s.ld.d       s2, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.addi       s6, s15, #0
    s.ld.d       s7, [s3, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s9, [s3, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s15, [s3, #32]                  // out_ptr0: device_ptr64 at arg_base+32
    s.ld.d       s17, [s3, #40]                  // out_ptr1: device_ptr64 at arg_base+40
    s.ld.d       s18, [s3, #48]                  // out_ptr2: device_ptr64 at arg_base+48
    s.ld.d       s19, [s3, #56]                  // out_ptr3: device_ptr64 at arg_base+56
    s.mov        s13, s16
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s13, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s16, s3
    s.shli       s20, s6, #1
    s.andi       s21, s5, #1
    s.movz       s5, #0
    s.or         s22, s20, s21
    s.movz       s20, #1
    s.cmp.geu    s21, s22, s14
    s.shl        s23, s20, s3
    s.sub        s20, s5, s21
    s.subi       s5, s3, #1
    s.and        s21, s14, s20
    s.and        s24, s23, s20
    s.sub        s20, s22, s21
    s.or         s21, s13, s24
    s.mov        s6, s20
    s.mov        s13, s21
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s20, s3, s5
    br.nz        s20, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s13, s4, s3
    s.movz       s3, #0
    s.sub        s14, s5, s13
    s.movz       s5, #0
    s.xor        s13, s4, s14
    s.movz       s4, #0
    s.sub        s16, s13, s14
    s.cmp.lt     s13, s12, s3
    s.lshri      s3, s16, #2
    s.movz       s20, #0
    s.muli       s21, s3, #4
    s.sub        s3, s4, s13
    s.movz       s4, #0
    s.cmp.lt     s13, s1, s20
    s.xor        s20, s12, s3
    s.sub        s12, s16, s21
    s.movz       s16, #0
    s.xor        s21, s12, s14
    s.xor        s12, s6, s8
    s.sub        s6, s21, s14
    s.sub        s14, s16, s13
    s.cmp.lt     s13, s6, s5
    s.sub        s5, s20, s3
    s.sub        s16, s4, s13
    s.movz       s4, #0
    s.xor        s13, s6, s16
    s.movz       s6, #1
    s.sub        s20, s12, s8
    s.xor        s8, s1, s14
    s.sub        s1, s13, s16
    s.movz       s12, #0
    s.addi       s13, s4, #0
    s.cmp.eq     s4, s5, s6
    s.add        s6, s10, s20
    s.sub        s10, s8, s14
    s.addi       s8, s12, #0
    s.mov        s13, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s10, #31
    s.mov        s13, s4
    s.addi       s4, s10, #0
sdiv_4:
    s.lshr       s10, s1, s4
    s.shli       s12, s8, #1
    s.andi       s14, s10, #1
    s.movz       s10, #0
    s.or         s20, s12, s14
    s.movz       s12, #1
    s.cmp.geu    s14, s20, s5
    s.shl        s21, s12, s4
    s.sub        s12, s10, s14
    s.subi       s10, s4, #1
    s.and        s14, s5, s12
    s.and        s22, s21, s12
    s.sub        s12, s20, s14
    s.or         s14, s13, s22
    s.mov        s8, s12
    s.mov        s13, s14
    s.mov        s4, s10
    s.movz       s10, #0
    s.cmp.ge     s12, s4, s10
    br.nz        s12, sdiv_4
sdiv_done_3:
    s.xor        s1, s16, s3
    s.movz       s3, #16
    s.xor        s4, s13, s1
    s.rdspecial  s5, pid.z
    s.sub        s8, s4, s1
    s.rdspecial  s1, npid.y
    s.mul        s4, s6, s3
    s.mul        s10, s8, s3
    s.mul        s12, s5, s1
    s.rdspecial  s1, pid.y
    s.movz       s5, #63
    s.andi       s13, s4, #63
    s.andi       s14, s10, #63
    s.add        s16, s1, s12
    s.movz       s1, #8192
    s.min.s      s12, s16, s5
    s.muli       s5, s13, #128                   // a runtime tile origin, x128
    s.mul        s20, s12, s1
    s.rdspecial  s1, role_id
    s.movz       s12, #7168
    s.movz       s21, #0
    s.rdspecial  s22, arg_base
    s.mul        s23, s1, s12
    s.add        s1, s21, s5                     // the tile origin
    s.ld.d       s5, [s22, #64]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s12, s1, s20                    // the tile origin
    s.movz       s1, #0
    s.add        s21, s5, s23                    // this context's own scratch
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s5, s21, #0
    v.splat      v1, s12
    v.splat      v2, s6
    v.splat      v3, s1
    s.addi       s6, s12, #128
    v.splat      v4, s8
    v.splat      v5, s1
    v.iota       v6                              // arange(0, VLEN)
    v.add        v7, v0, v1
    s.addi       s8, s5, #64
    v.cmp.ge     p1, v2, v3
    v.splat      v1, s6
    v.splat      v2, s4
    v.add        v3, v0, v1
    v.cmp.ge     p1, v4, v5
    s.addi       s6, s12, #256
    v.splat      v1, s10
    v.splat      v4, s6
    s.addi       s6, s5, #128
    v.add        v5, v0, v4
    v.add        v4, v2, v6
    s.addi       s22, s12, #384
    v.splat      v2, s13
    s.addi       s13, s5, #192
    v.add        v4, v1, v6
    v.splat      v1, s22
    v.iota       v4                              // arange(0, VLEN)
    s.addi       s22, s12, #512
    v.add        v6, v0, v1
    s.addi       s23, s5, #256
    v.add        v1, v2, v4
    v.splat      v1, s22
    v.splat      v2, s14
    v.add        v4, v0, v1
    s.movz       s22, #128
    s.addi       s24, s1, #0
    v.st.w       [s5, #0], v7
    v.iota       v1                              // arange(0, VLEN)
    s.addi       s1, s5, #320
    v.add        v7, v2, v1
    s.addi       s25, s12, #640
    v.splat      v1, s25
    s.addi       s25, s12, #768
    v.add        v2, v0, v1
    v.splat      v1, s25
    s.addi       s25, s12, #896
    v.add        v7, v0, v1
    v.st.w       [s8, #0], v3
    s.addi       s8, s12, #1024
    v.splat      v1, s25
    s.addi       s25, s12, #1152
    v.add        v3, v0, v1
    v.st.w       [s6, #0], v5
    s.addi       s6, s12, #1280
    v.splat      v1, s8
    s.addi       s8, s12, #1408
    v.add        v5, v0, v1
    v.st.w       [s13, #0], v6
    s.addi       s13, s12, #1536
    v.splat      v1, s25
    s.addi       s25, s12, #1664
    v.add        v6, v0, v1
    v.st.w       [s23, #0], v4
    s.addi       s23, s12, #1792
    s.addi       s26, s12, #1920
    v.splat      v1, s6
    s.addi       s6, s5, #384
    v.add        v4, v0, v1
    v.st.w       [s1, #0], v2
    v.splat      v1, s8
    s.addi       s1, s21, #1024
    s.addi       s8, s5, #448
    v.add        v2, v0, v1
    v.st.w       [s6, #0], v7
    s.muli       s6, s14, #128                   // a runtime tile origin, x128
    s.movz       s12, #0
    v.iota       v1                              // arange(0, VLEN)
    s.add        s14, s12, s6                    // the tile origin
    s.addi       s6, s5, #512
    s.add        s12, s14, s20                   // the tile origin
    s.addi       s14, s5, #576
    v.st.w       [s8, #0], v3
    s.movz       s8, #128
    v.splat      v3, s13
    s.addi       s13, s5, #640
    v.add        v7, v0, v3
    v.st.w       [s6, #0], v5
    v.splat      v3, s8
    s.addi       s6, s12, #1
    v.mul        v5, v1, v3
    v.splat      v1, s25
    s.addi       s8, s5, #704
    s.addi       s20, s5, #768
    v.add        v3, v0, v1
    v.st.w       [s14, #0], v6
    s.addi       s14, s12, #2
    v.splat      v1, s23
    s.addi       s23, s5, #832
    v.add        v6, v0, v1
    v.st.w       [s13, #0], v4
    s.addi       s13, s12, #3
    v.splat      v1, s26
    s.addi       s25, s5, #896
    s.addi       s26, s5, #960
    v.add        v4, v0, v1
    v.st.w       [s8, #0], v2
    s.addi       s5, s12, #4
    v.splat      v1, s12
    v.add        v2, v5, v1
    v.st.w       [s20, #0], v7
    s.addi       s8, s12, #5
    v.splat      v1, s6
    s.addi       s6, s1, #64
    v.add        v7, v5, v1
    v.st.w       [s23, #0], v3
    s.addi       s20, s12, #6
    v.splat      v1, s14
    s.addi       s14, s1, #128
    v.add        v3, v5, v1
    v.st.w       [s25, #0], v6
    s.addi       s23, s12, #7
    v.splat      v1, s13
    s.addi       s13, s1, #192
    v.add        v6, v5, v1
    v.st.w       [s26, #0], v4
    v.splat      v1, s5
    s.addi       s5, s1, #256
    v.add        v4, v5, v1
    s.addi       s25, s1, #320
    fence.acq_rel.device
    v.st.w       [s1, #0], v2
    v.splat      v1, s8
    s.addi       s8, s12, #8
    v.add        v2, v5, v1
    v.st.w       [s6, #0], v7
    s.addi       s6, s12, #9
    v.splat      v1, s20
    s.addi       s20, s12, #10
    v.add        v7, v5, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s12, #11
    v.splat      v1, s23
    s.addi       s23, s12, #12
    v.add        v3, v5, v1
    v.st.w       [s13, #0], v6
    s.addi       s13, s12, #13
    v.splat      v1, s8
    s.addi       s8, s12, #14
    v.add        v6, v5, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s12, #15
    v.splat      v1, s6
    s.addi       s6, s1, #384
    s.addi       s12, s1, #448
    v.add        v4, v5, v1
    v.st.w       [s25, #0], v2
    v.splat      v1, s20
    s.addi       s20, s1, #512
    s.addi       s25, s1, #576
    v.add        v2, v5, v1
    v.st.w       [s6, #0], v7
    v.splat      v1, s14
    s.addi       s6, s1, #640
    s.addi       s14, s1, #704
    v.add        v7, v5, v1
    v.st.w       [s12, #0], v3
    v.splat      v1, s23
    s.addi       s12, s1, #768
    v.add        v3, v5, v1
    s.addi       s23, s1, #832
    v.st.w       [s20, #0], v6
    v.splat      v1, s13
    s.addi       s13, s1, #896
    v.add        v6, v5, v1
    s.addi       s20, s1, #960
    v.st.w       [s25, #0], v4
    v.splat      v1, s8
    v.add        v4, v5, v1
    v.st.w       [s6, #0], v2
    v.splat      v1, s5
    v.add        v2, v5, v1
    v.st.w       [s14, #0], v7
    v.st.w       [s12, #0], v3
    v.st.w       [s23, #0], v6
    v.st.w       [s13, #0], v4
    v.st.w       [s20, #0], v2
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s1, s24, s22
    br.nz        s1, endfor_6
    s.addi       s1, s21, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s5, #0
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #64
    s.movz       s6, #1
    s.addi       s8, s21, #128
    s.movz       s12, #2
    s.addi       s13, s21, #192
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s5, v2
    v.ld.w       v1, [s1, #0]
    s.movz       s1, #3
    s.addi       s5, s21, #256
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s8, #0]
    s.movz       s6, #4
    s.addi       s8, s21, #320
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s12, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s12, #5
    s.addi       s13, s21, #384
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s1, #6
    s.addi       s5, s21, #448
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s8, #0]
    s.movz       s6, #7
    s.addi       s8, s21, #512
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s12, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s12, #8
    s.addi       s13, s21, #576
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s1, #9
    s.addi       s5, s21, #640
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s8, #0]
    s.movz       s6, #10
    s.addi       s8, s21, #704
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s12, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s12, #11
    s.addi       s13, s21, #768
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s1, #12
    s.addi       s5, s21, #832
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s8, #0]
    s.movz       s6, #13
    s.addi       s8, s21, #896
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s12, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s12, #14
    s.addi       s13, s21, #960
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s5, #0]
    s.movz       s1, #15
    s.addi       s5, s21, #1024
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s6, v2
    v.ld.w       v1, [s8, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s6, #0
    s.addi       s8, s21, #1088
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s12, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s12, #1
    s.addi       s13, s21, #1152
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    s.movz       s14, #2
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s5, #0]
    s.addi       s1, s21, #1216
    s.movz       s5, #3
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s6, v2
    v.ld.w       v1, [s8, #0]
    s.addi       s6, s21, #1280
    s.movz       s8, #4
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s12, v2
    v.ld.w       v1, [s13, #0]
    s.addi       s12, s21, #1344
    s.movz       s13, #5
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v2
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #1408
    s.movz       s14, #6
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s5, v2
    v.ld.w       v1, [s6, #0]
    s.addi       s5, s21, #1472
    s.movz       s6, #7
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s8, v2
    v.ld.w       v1, [s12, #0]
    s.addi       s8, s21, #1536
    s.movz       s12, #8
    v.ld.gather.w v2, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v2
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #1600
    s.movz       s13, #9
    v.movi       v2, #0
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v3
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s21, #1664
    s.movz       s14, #10
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s6, v3
    v.ld.w       v1, [s8, #0]
    s.addi       s6, s21, #1728
    s.movz       s8, #11
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s12, v3
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #1792
    s.movz       s12, #12
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v3
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s21, #1856
    s.movz       s13, #13
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v3
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s21, #1920
    s.movz       s14, #14
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s8, v3
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #1984
    s.movz       s8, #15
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s12, v3
    v.ld.w       v1, [s5, #0]
    s.movz       s5, #0
    s.movz       s12, #0
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v3
    v.ld.w       v1, [s6, #0]
    s.movz       s6, #1
    s.movz       s13, #2
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v3
    v.ld.w       v1, [s1, #0]
    s.movz       s1, #3
    s.movz       s14, #4
    v.ld.gather.w v3, [s2, v1]                   // index is in elements (ISA sec 9.1)
    s.movz       s20, #5
    a.vwrite     a2, s8, v3
    a.vread      v1, a1, s5
    a.vread      v3, a2, s12
    v.extract    s5, v1, #0
    v.splat      v4, s5
    v.extract    s5, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s5
    a.vread      v4, a2, s6
    v.extract    s5, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s5
    a.vread      v4, a2, s13
    v.extract    s5, v1, #3
    vf.fma       v5, v3, v4, v6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    v.extract    s1, v1, #4
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s14
    v.extract    s1, v1, #5
    vf.fma       v5, v3, v4, v6
    v.splat      v3, s1
    a.vread      v4, a2, s20
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s1, #0
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #1
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #1
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #2
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #2
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #3
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #4
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #5
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #6
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #7
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #8
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #9
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #9
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #10
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #10
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #11
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #11
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #12
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #12
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #13
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #13
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #14
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s1
    a.vread      v4, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s1
    a.vread      v4, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #3
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #4
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #5
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #6
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s5, v1, #7
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s5, v1, #8
    v.splat      v3, s5
    a.vread      v4, a2, s1
    s.movz       s1, #14
    vf.fma       v5, v3, v4, v6
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #10
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #11
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #12
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #13
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s6, v1, #14
    v.splat      v3, s6
    a.vread      v4, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v3, a2, s5
    s.movz       s5, #15
    vf.fma       v4, v1, v3, v5
    s.movz       s6, #0
    s.movz       s8, #1
    s.movz       s12, #2
    a.vwrite     a3, s1, v4
    a.vread      v1, a1, s5
    a.vread      v3, a2, s6
    v.extract    s1, v1, #0
    v.splat      v4, s1
    v.extract    s1, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v2, s1
    a.vread      v3, a2, s8
    v.extract    s1, v1, #2
    vf.fma       v4, v2, v3, v5
    v.splat      v2, s1
    a.vread      v3, a2, s12
    s.movz       s1, #3
    vf.fma       v5, v2, v3, v4
    v.extract    s5, v1, #3
    v.splat      v2, s5
    a.vread      v3, a2, s1
    s.movz       s1, #4
    vf.fma       v4, v2, v3, v5
    v.extract    s5, v1, #4
    v.splat      v2, s5
    a.vread      v3, a2, s1
    s.movz       s1, #5
    vf.fma       v5, v2, v3, v4
    v.extract    s5, v1, #5
    v.splat      v2, s5
    a.vread      v3, a2, s1
    s.movz       s1, #6
    vf.fma       v4, v2, v3, v5
    v.extract    s5, v1, #6
    v.splat      v2, s5
    a.vread      v3, a2, s1
    s.movz       s1, #7
    vf.fma       v5, v2, v3, v4
    v.extract    s5, v1, #7
    v.splat      v2, s5
    a.vread      v3, a2, s1
    s.movz       s1, #8
    vf.fma       v4, v2, v3, v5
    v.extract    s5, v1, #8
    v.splat      v2, s5
    a.vread      v3, a2, s1
    s.movz       s1, #15
    vf.fma       v5, v2, v3, v4
    s.movz       s5, #9
    v.extract    s6, v1, #9
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #10
    vf.fma       v4, v2, v3, v5
    v.extract    s6, v1, #10
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #11
    vf.fma       v5, v2, v3, v4
    v.extract    s6, v1, #11
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #12
    vf.fma       v4, v2, v3, v5
    v.extract    s6, v1, #12
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #13
    vf.fma       v5, v2, v3, v4
    v.extract    s6, v1, #13
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #14
    vf.fma       v4, v2, v3, v5
    v.extract    s6, v1, #14
    v.splat      v2, s6
    a.vread      v3, a2, s5
    s.movz       s5, #15
    vf.fma       v5, v2, v3, v4
    v.extract    s6, v1, #15
    v.splat      v1, s6
    a.vread      v2, a2, s5
    s.addi       s5, s21, #0
    vf.fma       v3, v1, v2, v5
    v.splat      v1, s3
    s.addi       s6, s21, #2048
    s.addi       s8, s21, #64
    a.vwrite     a3, s1, v3
    v.ld.w       v2, [s5, #0]
    s.addi       s1, s6, #64
    s.addi       s5, s21, #128
    s.addi       s12, s6, #128
    s.addi       s13, s21, #192
    s.addi       s14, s6, #192
    s.addi       s20, s21, #256
    v.add        v3, v2, v1
    v.st.w       [s6, #0], v3
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s6, #256
    v.add        v3, v2, v1
    v.st.w       [s1, #0], v3
    s.addi       s1, s21, #320
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s6, #320
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s21, #384
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s6, #384
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s21, #448
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s6, #448
    v.add        v3, v2, v1
    v.st.w       [s8, #0], v3
    s.addi       s8, s21, #512
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s6, #512
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    s.addi       s5, s21, #576
    v.ld.w       v2, [s12, #0]
    s.addi       s12, s6, #576
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s21, #640
    v.ld.w       v2, [s14, #0]
    s.addi       s14, s6, #640
    v.add        v3, v2, v1
    v.st.w       [s20, #0], v3
    s.addi       s20, s21, #704
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s6, #704
    v.add        v3, v2, v1
    v.st.w       [s1, #0], v3
    s.addi       s1, s21, #768
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s6, #768
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s21, #832
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s6, #832
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s21, #896
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s6, #896
    s.addi       s23, s6, #960
    v.add        v3, v2, v1
    v.st.w       [s8, #0], v3
    s.addi       s6, s21, #960
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s21, #1024
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    s.addi       s5, s21, #3072
    v.ld.w       v2, [s12, #0]
    s.addi       s8, s21, #1088
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s12, s5, #64
    v.ld.w       v2, [s14, #0]
    s.addi       s13, s21, #1152
    v.add        v3, v2, v1
    v.st.w       [s20, #0], v3
    s.addi       s14, s5, #128
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s21, #1216
    v.add        v3, v2, v1
    v.st.w       [s23, #0], v3
    fence.acq_rel.device
    s.addi       s20, s5, #192
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s21, #1280
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s5, #256
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s21, #1344
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s5, #320
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s21, #1408
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s5, #384
    v.add        v3, v2, v1
    v.st.w       [s20, #0], v3
    s.addi       s20, s21, #1472
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s5, #448
    v.add        v3, v2, v1
    v.st.w       [s8, #0], v3
    s.addi       s8, s21, #1536
    v.ld.w       v2, [s12, #0]
    s.addi       s12, s5, #512
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s21, #1600
    v.ld.w       v2, [s14, #0]
    s.addi       s14, s5, #576
    v.add        v3, v2, v1
    v.st.w       [s6, #0], v3
    s.addi       s6, s21, #1664
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s5, #640
    v.add        v3, v2, v1
    v.st.w       [s1, #0], v3
    s.addi       s1, s21, #1728
    v.ld.w       v2, [s8, #0]
    s.addi       s8, s5, #704
    v.add        v3, v2, v1
    v.st.w       [s12, #0], v3
    s.addi       s12, s21, #1792
    v.ld.w       v2, [s13, #0]
    s.addi       s13, s5, #768
    v.add        v3, v2, v1
    v.st.w       [s14, #0], v3
    s.addi       s14, s21, #1856
    v.ld.w       v2, [s6, #0]
    s.addi       s6, s5, #832
    v.add        v3, v2, v1
    v.st.w       [s20, #0], v3
    s.addi       s20, s21, #1920
    v.ld.w       v2, [s1, #0]
    s.addi       s1, s5, #896
    s.addi       s23, s5, #960
    v.add        v3, v2, v1
    v.st.w       [s8, #0], v3
    s.addi       s5, s21, #1984
    v.ld.w       v2, [s12, #0]
    s.addi       s8, s21, #2048
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s12, s21, #4096
    v.ld.w       v2, [s14, #0]
    s.addi       s13, s21, #2112
    v.add        v3, v2, v1
    v.st.w       [s6, #0], v3
    s.addi       s6, s12, #64
    v.ld.w       v2, [s20, #0]
    s.addi       s14, s21, #2176
    v.add        v3, v2, v1
    v.st.w       [s1, #0], v3
    s.addi       s1, s12, #128
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s21, #2240
    v.add        v3, v2, v1
    v.st.w       [s23, #0], v3
    fence.acq_rel.device
    s.addi       s20, s12, #192
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s21, #2304
    v.st.w       [s12, #0], v1
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s12, #256
    v.st.w       [s6, #0], v1
    s.addi       s6, s21, #2368
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s12, #320
    v.st.w       [s1, #0], v1
    s.addi       s1, s21, #2432
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s12, #384
    v.st.w       [s20, #0], v1
    s.addi       s20, s21, #2496
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s12, #448
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #2560
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s12, #512
    v.st.w       [s14, #0], v1
    s.addi       s14, s21, #2624
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s12, #576
    v.st.w       [s5, #0], v1
    s.addi       s5, s21, #2688
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s12, #640
    v.st.w       [s8, #0], v1
    s.addi       s8, s21, #2752
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s12, #704
    v.st.w       [s6, #0], v1
    s.addi       s6, s21, #2816
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s12, #768
    v.st.w       [s1, #0], v1
    s.addi       s1, s21, #2880
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s12, #832
    v.st.w       [s20, #0], v1
    s.addi       s20, s21, #2944
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s12, #896
    s.addi       s23, s12, #960
    v.st.w       [s13, #0], v1
    s.addi       s12, s21, #3008
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s21, #3072
    v.st.w       [s14, #0], v1
    s.addi       s13, s21, #5120
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #3136
    v.st.w       [s5, #0], v1
    s.addi       s5, s13, #64
    v.ld.w       v1, [s20, #0]
    s.addi       s14, s21, #3200
    v.st.w       [s8, #0], v1
    s.addi       s8, s13, #128
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s21, #3264
    v.st.w       [s23, #0], v1
    fence.acq_rel.device
    s.addi       s20, s13, #192
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s21, #3328
    v.st.w       [s13, #0], v1
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s13, #256
    v.st.w       [s5, #0], v1
    s.addi       s5, s21, #3392
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s13, #320
    v.st.w       [s8, #0], v1
    s.addi       s8, s21, #3456
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s13, #384
    v.st.w       [s20, #0], v1
    s.addi       s20, s21, #3520
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s13, #448
    v.st.w       [s1, #0], v1
    s.addi       s1, s21, #3584
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s13, #512
    v.st.w       [s14, #0], v1
    s.addi       s14, s21, #3648
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s13, #576
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #3712
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s13, #640
    v.st.w       [s6, #0], v1
    s.addi       s6, s21, #3776
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s13, #704
    v.st.w       [s5, #0], v1
    s.addi       s5, s21, #3840
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s13, #768
    v.st.w       [s8, #0], v1
    s.addi       s8, s21, #3904
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s13, #832
    v.st.w       [s20, #0], v1
    s.addi       s20, s21, #3968
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s13, #896
    s.addi       s23, s13, #960
    v.st.w       [s1, #0], v1
    s.addi       s1, s21, #4032
    v.ld.w       v1, [s5, #0]
    s.movz       s5, #0
    v.st.w       [s14, #0], v1
    s.movz       s13, #0
    v.ld.w       v1, [s8, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s8, #0
    v.st.w       [s12, #0], v1
    s.movz       s12, #1
    v.ld.w       v1, [s20, #0]
    s.movz       s14, #1
    v.st.w       [s6, #0], v1
    s.movz       s6, #1
    v.ld.w       v1, [s1, #0]
    s.movz       s1, #2
    v.st.w       [s23, #0], v1
    fence.acq_rel.device
    a.vread      v1, a0, s5
    a.vread      v2, a3, s13
    s.movz       s5, #2
    vf.add       v3, v1, v2
    s.movz       s13, #2
    s.movz       s20, #3
    a.vwrite     a4, s8, v3
    a.vread      v1, a0, s12
    a.vread      v2, a3, s14
    s.movz       s8, #3
    vf.add       v3, v1, v2
    s.movz       s12, #3
    s.movz       s14, #4
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s1
    a.vread      v2, a3, s5
    s.movz       s1, #4
    vf.add       v3, v1, v2
    s.movz       s5, #4
    s.movz       s6, #5
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s8
    s.movz       s8, #5
    vf.add       v3, v1, v2
    s.movz       s13, #5
    s.movz       s20, #6
    a.vwrite     a4, s12, v3
    a.vread      v1, a0, s14
    a.vread      v2, a3, s1
    s.movz       s1, #6
    vf.add       v3, v1, v2
    s.movz       s12, #6
    s.movz       s14, #7
    a.vwrite     a4, s5, v3
    a.vread      v1, a0, s6
    a.vread      v2, a3, s8
    s.movz       s5, #7
    vf.add       v3, v1, v2
    s.movz       s6, #7
    s.movz       s8, #8
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s1
    s.movz       s1, #8
    vf.add       v3, v1, v2
    s.movz       s13, #8
    s.movz       s20, #9
    a.vwrite     a4, s12, v3
    a.vread      v1, a0, s14
    a.vread      v2, a3, s5
    s.movz       s5, #9
    vf.add       v3, v1, v2
    s.movz       s12, #9
    s.movz       s14, #10
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s8
    a.vread      v2, a3, s1
    s.movz       s1, #10
    vf.add       v3, v1, v2
    s.movz       s6, #10
    s.movz       s8, #11
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s5
    s.movz       s5, #11
    vf.add       v3, v1, v2
    s.movz       s13, #11
    s.movz       s20, #12
    a.vwrite     a4, s12, v3
    a.vread      v1, a0, s14
    a.vread      v2, a3, s1
    s.movz       s1, #12
    vf.add       v3, v1, v2
    s.movz       s12, #12
    s.movz       s14, #13
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s8
    a.vread      v2, a3, s5
    s.movz       s5, #13
    vf.add       v3, v1, v2
    s.movz       s6, #13
    s.movz       s8, #14
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s1
    s.movz       s1, #14
    vf.add       v3, v1, v2
    s.movz       s13, #14
    s.movz       s20, #15
    a.vwrite     a4, s12, v3
    a.vread      v1, a0, s14
    a.vread      v2, a3, s5
    s.movz       s5, #15
    vf.add       v3, v1, v2
    s.movz       s12, #15
    s.addi       s14, s21, #4096
    a.vwrite     a4, s6, v3
    a.vread      v1, a0, s8
    a.vread      v2, a3, s1
    s.addi       s1, s21, #0
    vf.add       v3, v1, v2
    s.addi       s6, s21, #4160
    s.addi       s8, s21, #64
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s5
    s.addi       s5, s21, #4224
    vf.add       v3, v1, v2
    s.addi       s13, s21, #128
    s.addi       s20, s21, #4288
    a.vwrite     a4, s12, v3
    v.ld.w       v1, [s14, #0]
    s.addi       s12, s21, #192
    s.addi       s14, s21, #4352
    v.st.w       [s1, #0], v1
    s.addi       s1, s21, #256
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s21, #4416
    v.st.w       [s8, #0], v1
    s.addi       s8, s21, #320
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s21, #4480
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #384
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s21, #4544
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #448
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s21, #4608
    v.st.w       [s1, #0], v1
    s.addi       s1, s21, #512
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s21, #4672
    v.st.w       [s8, #0], v1
    s.addi       s8, s21, #576
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s21, #4736
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #640
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s21, #4800
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #704
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s21, #4864
    v.st.w       [s1, #0], v1
    s.addi       s1, s21, #768
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s21, #4928
    v.st.w       [s8, #0], v1
    s.addi       s8, s21, #832
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s21, #4992
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #896
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s21, #5056
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #960
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s21, #5120
    v.st.w       [s1, #0], v1
    s.addi       s1, s21, #1024
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s21, #5184
    v.st.w       [s8, #0], v1
    s.addi       s8, s21, #1088
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s21, #5248
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #1152
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s21, #5312
    v.st.w       [s12, #0], v1
    fence.acq_rel.device
    s.addi       s12, s21, #1216
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s21, #5376
    v.st.w       [s1, #0], v1
    s.addi       s1, s21, #1280
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s21, #5440
    v.st.w       [s8, #0], v1
    s.addi       s8, s21, #1344
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s21, #5504
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #1408
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s21, #5568
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #1472
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s21, #5632
    v.st.w       [s1, #0], v1
    s.addi       s1, s21, #1536
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s21, #5696
    v.st.w       [s8, #0], v1
    s.addi       s8, s21, #1600
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s21, #5760
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #1664
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s21, #5824
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #1728
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s21, #5888
    v.st.w       [s1, #0], v1
    s.addi       s1, s21, #1792
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s21, #5952
    v.st.w       [s8, #0], v1
    s.addi       s8, s21, #1856
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s21, #6016
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #1920
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s21, #6080
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #1984
    v.ld.w       v1, [s14, #0]
    s.movz       s14, #0
    v.st.w       [s1, #0], v1
    s.movz       s1, #0
    v.ld.w       v1, [s6, #0]
    s.movz       s6, #1
    v.st.w       [s8, #0], v1
    s.movz       s8, #1
    v.ld.w       v1, [s5, #0]
    s.movz       s5, #2
    v.st.w       [s13, #0], v1
    s.movz       s13, #2
    v.ld.w       v1, [s20, #0]
    s.movz       s20, #3
    v.st.w       [s12, #0], v1
    fence.acq_rel.device
    a.vread      v1, a4, s14
    s.movz       s12, #3
    a.vwrite     a0, s1, v1
    a.vread      v1, a4, s6
    s.movz       s1, #4
    a.vwrite     a0, s8, v1
    a.vread      v1, a4, s5
    s.movz       s5, #4
    a.vwrite     a0, s13, v1
    a.vread      v1, a4, s20
    s.movz       s6, #5
    a.vwrite     a0, s12, v1
    a.vread      v1, a4, s1
    s.movz       s1, #5
    a.vwrite     a0, s5, v1
    a.vread      v1, a4, s6
    s.movz       s5, #6
    a.vwrite     a0, s1, v1
    s.movz       s1, #6
    a.vread      v1, a4, s5
    s.movz       s5, #7
    a.vwrite     a0, s1, v1
    s.movz       s1, #7
    a.vread      v1, a4, s5
    s.movz       s5, #8
    a.vwrite     a0, s1, v1
    s.movz       s1, #8
    a.vread      v1, a4, s5
    s.movz       s5, #9
    a.vwrite     a0, s1, v1
    s.movz       s1, #9
    a.vread      v1, a4, s5
    s.movz       s5, #10
    a.vwrite     a0, s1, v1
    s.movz       s1, #10
    a.vread      v1, a4, s5
    s.movz       s5, #11
    a.vwrite     a0, s1, v1
    s.movz       s1, #11
    a.vread      v1, a4, s5
    s.movz       s5, #12
    a.vwrite     a0, s1, v1
    s.movz       s1, #12
    a.vread      v1, a4, s5
    s.movz       s5, #13
    a.vwrite     a0, s1, v1
    s.movz       s1, #13
    a.vread      v1, a4, s5
    s.movz       s5, #14
    a.vwrite     a0, s1, v1
    s.movz       s1, #14
    a.vread      v1, a4, s5
    s.movz       s5, #15
    a.vwrite     a0, s1, v1
    s.movz       s1, #15
    a.vread      v1, a4, s5
    s.add        s5, s24, s3
    s.movz       s6, #1
    a.vwrite     a0, s1, v1
    s.mov        s24, s5
    br.nz        s6, for_5
endfor_6:
    v.splat      v1, s16
    s.movz       s1, #64
    v.splat      v2, s1
    v.cmp.lt     p1, v1, v2
    p.ballot     s2, p1
    s.movz       s3, #4096
    s.mul        s5, s16, s3
    s.muli       s3, s10, #4                     // a runtime tile origin, x4
    s.add        s6, s15, s3                     // the tile origin
    s.muli       s3, s4, #256                    // a runtime tile origin, x256
    s.add        s8, s6, s3                      // the tile origin
    s.muli       s3, s5, #4                      // a runtime tile origin, x4
    s.add        s6, s8, s3                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    a.vread      v1, a0, s3
    s.movz       s3, #0
    s.add        s8, s3, s4                      // the tile origin
    v.splat      v2, s8
    v.splat      v3, s1
    v.cmp.lt     p1, v2, v3
    s.movz       s3, #0
    s.add        s11, s3, s10                    // the tile origin
    v.splat      v2, s11
    v.add        v4, v0, v2
    v.splat      v2, s1
    v.cmp.lt     p2, v4, v2
    p.ballot     s3, p2
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s6, #0], v1
    s.movz       s11, #1
    a.vread      v1, a0, s11
    s.addi       s11, s6, #256                   // row 1
    s.addi       s12, s8, #1
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.movz       s11, #2
    a.vread      v1, a0, s11
    s.addi       s11, s6, #512                   // row 2
    s.addi       s12, s8, #2
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.movz       s11, #3
    a.vread      v1, a0, s11
    s.addi       s11, s6, #768                   // row 3
    s.addi       s12, s8, #3
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.movz       s11, #4
    a.vread      v1, a0, s11
    s.addi       s11, s6, #1024                  // row 4
    s.addi       s12, s8, #4
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.movz       s11, #5
    a.vread      v1, a0, s11
    s.addi       s11, s6, #1280                  // row 5
    s.addi       s12, s8, #5
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.movz       s11, #6
    a.vread      v1, a0, s11
    s.addi       s11, s6, #1536                  // row 6
    s.addi       s12, s8, #6
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.movz       s11, #7
    a.vread      v1, a0, s11
    s.addi       s11, s6, #1792                  // row 7
    s.addi       s12, s8, #7
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.movz       s11, #8
    a.vread      v1, a0, s11
    s.addi       s11, s6, #2048                  // row 8
    s.addi       s12, s8, #8
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.movz       s11, #9
    a.vread      v1, a0, s11
    s.addi       s11, s6, #2304                  // row 9
    s.addi       s12, s8, #9
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.movz       s11, #10
    a.vread      v1, a0, s11
    s.addi       s11, s6, #2560                  // row 10
    s.addi       s12, s8, #10
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.movz       s11, #11
    a.vread      v1, a0, s11
    s.addi       s11, s6, #2816                  // row 11
    s.addi       s12, s8, #11
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.movz       s11, #12
    a.vread      v1, a0, s11
    s.addi       s11, s6, #3072                  // row 12
    s.addi       s12, s8, #12
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.movz       s11, #13
    a.vread      v1, a0, s11
    s.addi       s11, s6, #3328                  // row 13
    s.addi       s12, s8, #13
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.movz       s11, #14
    a.vread      v1, a0, s11
    s.addi       s11, s6, #3584                  // row 14
    s.addi       s12, s8, #14
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.movz       s11, #15
    a.vread      v1, a0, s11
    s.addi       s11, s6, #3840                  // row 15
    s.addi       s6, s8, #15
    v.splat      v2, s6
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s11, #0], v1
    s.mul        s6, s16, s1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s1, #0
    s.movz       s11, #0
    s.add        s12, s11, s4                    // the tile origin
    s.add        s11, s12, s6                    // the tile origin
    v.splat      v1, s11
    v.splat      v2, s8
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #1
    s.addi       s12, s11, #1
    v.splat      v1, s12
    s.addi       s12, s8, #1
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #2
    s.addi       s12, s11, #2
    v.splat      v1, s12
    s.addi       s12, s8, #2
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #3
    s.addi       s12, s11, #3
    v.splat      v1, s12
    s.addi       s12, s8, #3
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #4
    s.addi       s12, s11, #4
    v.splat      v1, s12
    s.addi       s12, s8, #4
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #5
    s.addi       s12, s11, #5
    v.splat      v1, s12
    s.addi       s12, s8, #5
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #6
    s.addi       s12, s11, #6
    v.splat      v1, s12
    s.addi       s12, s8, #6
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #7
    s.addi       s12, s11, #7
    v.splat      v1, s12
    s.addi       s12, s8, #7
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #8
    s.addi       s12, s11, #8
    v.splat      v1, s12
    s.addi       s12, s8, #8
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #9
    s.addi       s12, s11, #9
    v.splat      v1, s12
    s.addi       s12, s8, #9
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #10
    s.addi       s12, s11, #10
    v.splat      v1, s12
    s.addi       s12, s8, #10
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #11
    s.addi       s12, s11, #11
    v.splat      v1, s12
    s.addi       s12, s8, #11
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #12
    s.addi       s12, s11, #12
    v.splat      v1, s12
    s.addi       s12, s8, #12
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #13
    s.addi       s12, s11, #13
    v.splat      v1, s12
    s.addi       s12, s8, #13
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #14
    s.addi       s12, s11, #14
    v.splat      v1, s12
    s.addi       s12, s8, #14
    v.splat      v2, s12
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.movz       s1, #15
    s.addi       s12, s11, #15
    v.splat      v1, s12
    s.addi       s11, s8, #15
    v.splat      v2, s11
    v.cmp.lt     p1, v2, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s7, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v2
    s.muli       s1, s10, #4                     // a runtime tile origin, x4
    s.add        s11, s7, s1                     // the tile origin
    s.muli       s1, s6, #4                      // a runtime tile origin, x4
    s.add        s6, s11, s1                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s1, s10, #4                     // a runtime tile origin, x4
    s.add        s7, s9, s1                      // the tile origin
    s.muli       s1, s4, #256                    // a runtime tile origin, x256
    s.add        s9, s7, s1                      // the tile origin
    s.muli       s1, s5, #4                      // a runtime tile origin, x4
    s.add        s7, s9, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.movz       s1, #0
    s.add        s9, s1, s10                     // the tile origin
    s.muli       s1, s4, #-1                     // a runtime tile origin, x-1
    s.add        s11, s9, s1                     // the tile origin
    v.splat      v1, s11
    v.add        v2, v0, v1
    v.movi       v1, #0
    v.movi       v4, #0
    v.extract    s1, v2, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #0
    v.extract    s1, v2, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #1
    v.extract    s1, v2, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #2
    v.extract    s1, v2, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #3
    v.extract    s1, v2, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #4
    v.extract    s1, v2, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #5
    v.extract    s1, v2, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #6
    v.extract    s1, v2, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #7
    v.extract    s1, v2, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #8
    v.extract    s1, v2, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #9
    v.extract    s1, v2, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #10
    v.extract    s1, v2, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #11
    v.extract    s1, v2, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #12
    v.extract    s1, v2, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #13
    v.extract    s1, v2, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #14
    v.extract    s1, v2, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v1, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v4, s9, #15
    s.addi       s1, s11, #-1
    v.splat      v2, s1
    v.add        v5, v0, v2
    v.movi       v2, #0
    v.movi       v6, #0
    v.extract    s1, v5, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #0
    v.extract    s1, v5, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #1
    v.extract    s1, v5, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #2
    v.extract    s1, v5, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #3
    v.extract    s1, v5, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #4
    v.extract    s1, v5, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #5
    v.extract    s1, v5, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #6
    v.extract    s1, v5, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #7
    v.extract    s1, v5, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #8
    v.extract    s1, v5, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #9
    v.extract    s1, v5, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #10
    v.extract    s1, v5, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #11
    v.extract    s1, v5, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #12
    v.extract    s1, v5, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #13
    v.extract    s1, v5, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #14
    v.extract    s1, v5, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v2, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v6, s9, #15
    s.addi       s1, s11, #-2
    v.splat      v5, s1
    v.add        v7, v0, v5
    v.movi       v5, #0
    v.movi       v8, #0
    v.extract    s1, v7, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #0
    v.extract    s1, v7, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #1
    v.extract    s1, v7, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #2
    v.extract    s1, v7, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #3
    v.extract    s1, v7, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #4
    v.extract    s1, v7, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #5
    v.extract    s1, v7, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #6
    v.extract    s1, v7, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #7
    v.extract    s1, v7, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #8
    v.extract    s1, v7, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #9
    v.extract    s1, v7, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #10
    v.extract    s1, v7, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #11
    v.extract    s1, v7, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #12
    v.extract    s1, v7, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #13
    v.extract    s1, v7, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #14
    v.extract    s1, v7, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v5, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v8, s9, #15
    s.addi       s1, s11, #-3
    v.splat      v7, s1
    v.add        v9, v0, v7
    v.movi       v7, #0
    v.movi       v10, #0
    v.extract    s1, v9, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #0
    v.extract    s1, v9, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #1
    v.extract    s1, v9, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #2
    v.extract    s1, v9, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #3
    v.extract    s1, v9, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #4
    v.extract    s1, v9, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #5
    v.extract    s1, v9, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #6
    v.extract    s1, v9, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #7
    v.extract    s1, v9, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #8
    v.extract    s1, v9, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #9
    v.extract    s1, v9, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #10
    v.extract    s1, v9, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #11
    v.extract    s1, v9, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #12
    v.extract    s1, v9, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #13
    v.extract    s1, v9, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #14
    v.extract    s1, v9, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v7, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v10, s9, #15
    s.addi       s1, s11, #-4
    v.splat      v9, s1
    v.add        v11, v0, v9
    v.movi       v9, #0
    v.movi       v12, #0
    v.extract    s1, v11, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #0
    v.extract    s1, v11, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #1
    v.extract    s1, v11, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #2
    v.extract    s1, v11, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #3
    v.extract    s1, v11, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #4
    v.extract    s1, v11, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #5
    v.extract    s1, v11, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #6
    v.extract    s1, v11, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #7
    v.extract    s1, v11, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #8
    v.extract    s1, v11, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #9
    v.extract    s1, v11, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #10
    v.extract    s1, v11, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #11
    v.extract    s1, v11, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #12
    v.extract    s1, v11, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #13
    v.extract    s1, v11, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #14
    v.extract    s1, v11, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v9, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v12, s9, #15
    s.addi       s1, s11, #-5
    v.splat      v11, s1
    v.add        v13, v0, v11
    v.movi       v11, #0
    v.movi       v14, #0
    v.extract    s1, v13, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #0
    v.extract    s1, v13, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #1
    v.extract    s1, v13, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #2
    v.extract    s1, v13, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #3
    v.extract    s1, v13, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #4
    v.extract    s1, v13, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #5
    v.extract    s1, v13, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #6
    v.extract    s1, v13, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #7
    v.extract    s1, v13, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #8
    v.extract    s1, v13, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #9
    v.extract    s1, v13, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #10
    v.extract    s1, v13, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #11
    v.extract    s1, v13, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #12
    v.extract    s1, v13, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #13
    v.extract    s1, v13, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #14
    v.extract    s1, v13, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v11, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v14, s9, #15
    s.addi       s1, s11, #-6
    v.splat      v13, s1
    v.add        v15, v0, v13
    v.movi       v13, #0
    v.movi       v16, #0
    v.extract    s1, v15, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #0
    v.extract    s1, v15, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #1
    v.extract    s1, v15, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #2
    v.extract    s1, v15, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #3
    v.extract    s1, v15, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #4
    v.extract    s1, v15, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #5
    v.extract    s1, v15, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #6
    v.extract    s1, v15, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #7
    v.extract    s1, v15, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #8
    v.extract    s1, v15, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #9
    v.extract    s1, v15, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #10
    v.extract    s1, v15, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #11
    v.extract    s1, v15, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #12
    v.extract    s1, v15, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #13
    v.extract    s1, v15, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #14
    v.extract    s1, v15, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v13, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v16, s9, #15
    s.addi       s1, s11, #-7
    v.splat      v15, s1
    v.add        v17, v0, v15
    v.movi       v15, #0
    v.movi       v18, #0
    v.extract    s1, v17, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #0
    v.extract    s1, v17, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #1
    v.extract    s1, v17, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #2
    v.extract    s1, v17, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #3
    v.extract    s1, v17, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #4
    v.extract    s1, v17, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #5
    v.extract    s1, v17, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #6
    v.extract    s1, v17, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #7
    v.extract    s1, v17, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #8
    v.extract    s1, v17, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #9
    v.extract    s1, v17, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #10
    v.extract    s1, v17, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #11
    v.extract    s1, v17, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #12
    v.extract    s1, v17, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #13
    v.extract    s1, v17, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #14
    v.extract    s1, v17, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v15, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v18, s9, #15
    s.addi       s1, s11, #-8
    v.splat      v17, s1
    v.add        v19, v0, v17
    v.movi       v17, #0
    v.movi       v20, #0
    v.extract    s1, v19, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #0
    v.extract    s1, v19, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #1
    v.extract    s1, v19, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #2
    v.extract    s1, v19, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #3
    v.extract    s1, v19, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #4
    v.extract    s1, v19, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #5
    v.extract    s1, v19, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #6
    v.extract    s1, v19, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #7
    v.extract    s1, v19, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #8
    v.extract    s1, v19, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #9
    v.extract    s1, v19, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #10
    v.extract    s1, v19, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #11
    v.extract    s1, v19, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #12
    v.extract    s1, v19, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #13
    v.extract    s1, v19, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #14
    v.extract    s1, v19, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v17, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v20, s9, #15
    s.addi       s1, s11, #-9
    v.splat      v19, s1
    v.add        v21, v0, v19
    v.movi       v19, #0
    v.movi       v22, #0
    v.extract    s1, v21, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #0
    v.extract    s1, v21, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #1
    v.extract    s1, v21, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #2
    v.extract    s1, v21, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #3
    v.extract    s1, v21, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #4
    v.extract    s1, v21, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #5
    v.extract    s1, v21, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #6
    v.extract    s1, v21, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #7
    v.extract    s1, v21, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #8
    v.extract    s1, v21, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #9
    v.extract    s1, v21, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #10
    v.extract    s1, v21, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #11
    v.extract    s1, v21, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #12
    v.extract    s1, v21, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #13
    v.extract    s1, v21, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #14
    v.extract    s1, v21, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v19, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v22, s9, #15
    s.addi       s1, s11, #-10
    v.splat      v21, s1
    v.add        v23, v0, v21
    v.movi       v21, #0
    v.movi       v24, #0
    v.extract    s1, v23, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #0
    v.extract    s1, v23, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #1
    v.extract    s1, v23, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #2
    v.extract    s1, v23, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #3
    v.extract    s1, v23, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #4
    v.extract    s1, v23, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #5
    v.extract    s1, v23, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #6
    v.extract    s1, v23, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #7
    v.extract    s1, v23, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #8
    v.extract    s1, v23, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #9
    v.extract    s1, v23, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #10
    v.extract    s1, v23, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #11
    v.extract    s1, v23, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #12
    v.extract    s1, v23, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #13
    v.extract    s1, v23, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #14
    v.extract    s1, v23, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v21, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v24, s9, #15
    s.addi       s1, s11, #-11
    v.splat      v23, s1
    v.add        v25, v0, v23
    v.movi       v23, #0
    v.movi       v26, #0
    v.extract    s1, v25, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #0
    v.extract    s1, v25, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #1
    v.extract    s1, v25, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #2
    v.extract    s1, v25, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #3
    v.extract    s1, v25, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #4
    v.extract    s1, v25, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #5
    v.extract    s1, v25, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #6
    v.extract    s1, v25, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #7
    v.extract    s1, v25, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #8
    v.extract    s1, v25, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #9
    v.extract    s1, v25, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #10
    v.extract    s1, v25, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #11
    v.extract    s1, v25, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #12
    v.extract    s1, v25, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #13
    v.extract    s1, v25, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #14
    v.extract    s1, v25, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v23, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v26, s9, #15
    s.addi       s1, s11, #-12
    v.splat      v25, s1
    v.add        v27, v0, v25
    v.movi       v25, #0
    v.movi       v28, #0
    v.extract    s1, v27, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #0
    v.extract    s1, v27, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #1
    v.extract    s1, v27, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #2
    v.extract    s1, v27, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #3
    v.extract    s1, v27, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #4
    v.extract    s1, v27, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #5
    v.extract    s1, v27, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #6
    v.extract    s1, v27, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #7
    v.extract    s1, v27, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #8
    v.extract    s1, v27, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #9
    v.extract    s1, v27, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #10
    v.extract    s1, v27, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #11
    v.extract    s1, v27, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #12
    v.extract    s1, v27, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #13
    v.extract    s1, v27, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #14
    v.extract    s1, v27, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v25, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v28, s9, #15
    s.addi       s1, s11, #-13
    v.splat      v27, s1
    v.add        v29, v0, v27
    v.movi       v27, #0
    v.movi       v30, #0
    v.extract    s1, v29, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #0
    v.extract    s1, v29, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #1
    v.extract    s1, v29, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #2
    v.extract    s1, v29, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #3
    v.extract    s1, v29, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #4
    v.extract    s1, v29, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #5
    v.extract    s1, v29, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #6
    v.extract    s1, v29, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #7
    v.extract    s1, v29, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #8
    v.extract    s1, v29, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #9
    v.extract    s1, v29, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #10
    v.extract    s1, v29, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #11
    v.extract    s1, v29, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #12
    v.extract    s1, v29, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #13
    v.extract    s1, v29, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #14
    v.extract    s1, v29, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v27, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v30, s9, #15
    s.addi       s1, s11, #-14
    v.splat      v29, s1
    v.add        v31, v0, v29
    v.movi       v29, #0
    v.movi       v32, #0
    v.extract    s1, v31, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #0
    v.extract    s1, v31, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #1
    v.extract    s1, v31, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #2
    v.extract    s1, v31, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #3
    v.extract    s1, v31, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #4
    v.extract    s1, v31, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #5
    v.extract    s1, v31, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #6
    v.extract    s1, v31, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #7
    v.extract    s1, v31, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #8
    v.extract    s1, v31, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #9
    v.extract    s1, v31, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #10
    v.extract    s1, v31, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #11
    v.extract    s1, v31, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #12
    v.extract    s1, v31, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #13
    v.extract    s1, v31, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #14
    v.extract    s1, v31, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v29, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v32, s9, #15
    s.addi       s1, s11, #-15
    v.splat      v31, s1
    v.add        v33, v0, v31
    v.movi       v0, #0
    v.movi       v31, #0
    v.extract    s1, v33, #0
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #0
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #0
    v.extract    s1, v33, #1
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #1
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #1
    v.extract    s1, v33, #2
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #2
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #2
    v.extract    s1, v33, #3
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #3
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #3
    v.extract    s1, v33, #4
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #4
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #4
    v.extract    s1, v33, #5
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #5
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #5
    v.extract    s1, v33, #6
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #6
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #6
    v.extract    s1, v33, #7
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #7
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #7
    v.extract    s1, v33, #8
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #8
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #8
    v.extract    s1, v33, #9
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #9
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #9
    v.extract    s1, v33, #10
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #10
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #10
    v.extract    s1, v33, #11
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #11
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #11
    v.extract    s1, v33, #12
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #12
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #12
    v.extract    s1, v33, #13
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #13
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #13
    v.extract    s1, v33, #14
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #14
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #14
    v.extract    s1, v33, #15
    s.shli       s9, s1, #32
    s.ashri      s1, s9, #32
    v.insert     v0, s1, #15
    s.lshri      s9, s1, #32
    v.insert     v31, s9, #15
    v.movi       v33, #0
    v.extract    s1, v1, #0
    v.extract    s9, v4, #0
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #0
    v.extract    s1, v1, #1
    v.extract    s9, v4, #1
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #1
    v.extract    s1, v1, #2
    v.extract    s9, v4, #2
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #2
    v.extract    s1, v1, #3
    v.extract    s9, v4, #3
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #3
    v.extract    s1, v1, #4
    v.extract    s9, v4, #4
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #4
    v.extract    s1, v1, #5
    v.extract    s9, v4, #5
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #5
    v.extract    s1, v1, #6
    v.extract    s9, v4, #6
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #6
    v.extract    s1, v1, #7
    v.extract    s9, v4, #7
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #7
    v.extract    s1, v1, #8
    v.extract    s9, v4, #8
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #8
    v.extract    s1, v1, #9
    v.extract    s9, v4, #9
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #9
    v.extract    s1, v1, #10
    v.extract    s9, v4, #10
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #10
    v.extract    s1, v1, #11
    v.extract    s9, v4, #11
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #11
    v.extract    s1, v1, #12
    v.extract    s9, v4, #12
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #12
    v.extract    s1, v1, #13
    v.extract    s9, v4, #13
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #13
    v.extract    s1, v1, #14
    v.extract    s9, v4, #14
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #14
    v.extract    s1, v1, #15
    v.extract    s9, v4, #15
    s.shli       s11, s9, #32
    s.or         s9, s1, s11
    s.movz       s1, #1
    s.cmp.ge     s11, s9, s1
    v.insert     v33, s11, #15
    v.movi       v1, #0
    v.cmp.ne     p1, v33, v1
    p.ballot     s1, p1
    v.movi       v1, #0
    v.extract    s9, v2, #0
    v.extract    s11, v6, #0
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #0
    v.extract    s9, v2, #1
    v.extract    s11, v6, #1
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #1
    v.extract    s9, v2, #2
    v.extract    s11, v6, #2
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #2
    v.extract    s9, v2, #3
    v.extract    s11, v6, #3
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #3
    v.extract    s9, v2, #4
    v.extract    s11, v6, #4
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #4
    v.extract    s9, v2, #5
    v.extract    s11, v6, #5
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #5
    v.extract    s9, v2, #6
    v.extract    s11, v6, #6
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #6
    v.extract    s9, v2, #7
    v.extract    s11, v6, #7
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #7
    v.extract    s9, v2, #8
    v.extract    s11, v6, #8
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #8
    v.extract    s9, v2, #9
    v.extract    s11, v6, #9
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #9
    v.extract    s9, v2, #10
    v.extract    s11, v6, #10
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #10
    v.extract    s9, v2, #11
    v.extract    s11, v6, #11
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #11
    v.extract    s9, v2, #12
    v.extract    s11, v6, #12
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #12
    v.extract    s9, v2, #13
    v.extract    s11, v6, #13
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #13
    v.extract    s9, v2, #14
    v.extract    s11, v6, #14
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #14
    v.extract    s9, v2, #15
    v.extract    s11, v6, #15
    s.shli       s12, s11, #32
    s.or         s11, s9, s12
    s.movz       s9, #1
    s.cmp.ge     s12, s11, s9
    v.insert     v1, s12, #15
    v.movi       v2, #0
    v.cmp.ne     p1, v1, v2
    p.ballot     s9, p1
    v.movi       v1, #0
    v.extract    s11, v5, #0
    v.extract    s12, v8, #0
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #0
    v.extract    s11, v5, #1
    v.extract    s12, v8, #1
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #1
    v.extract    s11, v5, #2
    v.extract    s12, v8, #2
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #2
    v.extract    s11, v5, #3
    v.extract    s12, v8, #3
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #3
    v.extract    s11, v5, #4
    v.extract    s12, v8, #4
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #4
    v.extract    s11, v5, #5
    v.extract    s12, v8, #5
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #5
    v.extract    s11, v5, #6
    v.extract    s12, v8, #6
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #6
    v.extract    s11, v5, #7
    v.extract    s12, v8, #7
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #7
    v.extract    s11, v5, #8
    v.extract    s12, v8, #8
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #8
    v.extract    s11, v5, #9
    v.extract    s12, v8, #9
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #9
    v.extract    s11, v5, #10
    v.extract    s12, v8, #10
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #10
    v.extract    s11, v5, #11
    v.extract    s12, v8, #11
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #11
    v.extract    s11, v5, #12
    v.extract    s12, v8, #12
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #12
    v.extract    s11, v5, #13
    v.extract    s12, v8, #13
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #13
    v.extract    s11, v5, #14
    v.extract    s12, v8, #14
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #14
    v.extract    s11, v5, #15
    v.extract    s12, v8, #15
    s.shli       s13, s12, #32
    s.or         s12, s11, s13
    s.movz       s11, #1
    s.cmp.ge     s13, s12, s11
    v.insert     v1, s13, #15
    v.movi       v2, #0
    v.cmp.ne     p1, v1, v2
    p.ballot     s11, p1
    v.movi       v1, #0
    v.extract    s12, v7, #0
    v.extract    s13, v10, #0
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #0
    v.extract    s12, v7, #1
    v.extract    s13, v10, #1
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #1
    v.extract    s12, v7, #2
    v.extract    s13, v10, #2
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #2
    v.extract    s12, v7, #3
    v.extract    s13, v10, #3
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #3
    v.extract    s12, v7, #4
    v.extract    s13, v10, #4
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #4
    v.extract    s12, v7, #5
    v.extract    s13, v10, #5
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #5
    v.extract    s12, v7, #6
    v.extract    s13, v10, #6
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #6
    v.extract    s12, v7, #7
    v.extract    s13, v10, #7
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #7
    v.extract    s12, v7, #8
    v.extract    s13, v10, #8
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #8
    v.extract    s12, v7, #9
    v.extract    s13, v10, #9
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #9
    v.extract    s12, v7, #10
    v.extract    s13, v10, #10
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #10
    v.extract    s12, v7, #11
    v.extract    s13, v10, #11
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #11
    v.extract    s12, v7, #12
    v.extract    s13, v10, #12
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #12
    v.extract    s12, v7, #13
    v.extract    s13, v10, #13
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #13
    v.extract    s12, v7, #14
    v.extract    s13, v10, #14
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #14
    v.extract    s12, v7, #15
    v.extract    s13, v10, #15
    s.shli       s14, s13, #32
    s.or         s13, s12, s14
    s.movz       s12, #1
    s.cmp.ge     s14, s13, s12
    v.insert     v1, s14, #15
    v.movi       v2, #0
    v.cmp.ne     p1, v1, v2
    p.ballot     s12, p1
    v.movi       v1, #0
    v.extract    s13, v9, #0
    v.extract    s14, v12, #0
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #0
    v.extract    s13, v9, #1
    v.extract    s14, v12, #1
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #1
    v.extract    s13, v9, #2
    v.extract    s14, v12, #2
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #2
    v.extract    s13, v9, #3
    v.extract    s14, v12, #3
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #3
    v.extract    s13, v9, #4
    v.extract    s14, v12, #4
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #4
    v.extract    s13, v9, #5
    v.extract    s14, v12, #5
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #5
    v.extract    s13, v9, #6
    v.extract    s14, v12, #6
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #6
    v.extract    s13, v9, #7
    v.extract    s14, v12, #7
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #7
    v.extract    s13, v9, #8
    v.extract    s14, v12, #8
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #8
    v.extract    s13, v9, #9
    v.extract    s14, v12, #9
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #9
    v.extract    s13, v9, #10
    v.extract    s14, v12, #10
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #10
    v.extract    s13, v9, #11
    v.extract    s14, v12, #11
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #11
    v.extract    s13, v9, #12
    v.extract    s14, v12, #12
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #12
    v.extract    s13, v9, #13
    v.extract    s14, v12, #13
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #13
    v.extract    s13, v9, #14
    v.extract    s14, v12, #14
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #14
    v.extract    s13, v9, #15
    v.extract    s14, v12, #15
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #15
    v.movi       v2, #0
    v.cmp.ne     p1, v1, v2
    v.movi       v1, #0
    v.extract    s13, v11, #0
    v.extract    s14, v14, #0
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #0
    v.extract    s13, v11, #1
    v.extract    s14, v14, #1
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #1
    v.extract    s13, v11, #2
    v.extract    s14, v14, #2
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #2
    v.extract    s13, v11, #3
    v.extract    s14, v14, #3
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #3
    v.extract    s13, v11, #4
    v.extract    s14, v14, #4
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #4
    v.extract    s13, v11, #5
    v.extract    s14, v14, #5
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #5
    v.extract    s13, v11, #6
    v.extract    s14, v14, #6
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #6
    v.extract    s13, v11, #7
    v.extract    s14, v14, #7
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #7
    v.extract    s13, v11, #8
    v.extract    s14, v14, #8
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #8
    v.extract    s13, v11, #9
    v.extract    s14, v14, #9
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #9
    v.extract    s13, v11, #10
    v.extract    s14, v14, #10
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #10
    v.extract    s13, v11, #11
    v.extract    s14, v14, #11
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #11
    v.extract    s13, v11, #12
    v.extract    s14, v14, #12
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #12
    v.extract    s13, v11, #13
    v.extract    s14, v14, #13
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #13
    v.extract    s13, v11, #14
    v.extract    s14, v14, #14
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #14
    v.extract    s13, v11, #15
    v.extract    s14, v14, #15
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #15
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    v.movi       v1, #0
    v.extract    s13, v13, #0
    v.extract    s14, v16, #0
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #0
    v.extract    s13, v13, #1
    v.extract    s14, v16, #1
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #1
    v.extract    s13, v13, #2
    v.extract    s14, v16, #2
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #2
    v.extract    s13, v13, #3
    v.extract    s14, v16, #3
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #3
    v.extract    s13, v13, #4
    v.extract    s14, v16, #4
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #4
    v.extract    s13, v13, #5
    v.extract    s14, v16, #5
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #5
    v.extract    s13, v13, #6
    v.extract    s14, v16, #6
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #6
    v.extract    s13, v13, #7
    v.extract    s14, v16, #7
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #7
    v.extract    s13, v13, #8
    v.extract    s14, v16, #8
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #8
    v.extract    s13, v13, #9
    v.extract    s14, v16, #9
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #9
    v.extract    s13, v13, #10
    v.extract    s14, v16, #10
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #10
    v.extract    s13, v13, #11
    v.extract    s14, v16, #11
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #11
    v.extract    s13, v13, #12
    v.extract    s14, v16, #12
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #12
    v.extract    s13, v13, #13
    v.extract    s14, v16, #13
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #13
    v.extract    s13, v13, #14
    v.extract    s14, v16, #14
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #14
    v.extract    s13, v13, #15
    v.extract    s14, v16, #15
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #15
    v.movi       v2, #0
    v.cmp.ne     p3, v1, v2
    v.movi       v1, #0
    v.extract    s13, v15, #0
    v.extract    s14, v18, #0
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #0
    v.extract    s13, v15, #1
    v.extract    s14, v18, #1
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #1
    v.extract    s13, v15, #2
    v.extract    s14, v18, #2
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #2
    v.extract    s13, v15, #3
    v.extract    s14, v18, #3
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #3
    v.extract    s13, v15, #4
    v.extract    s14, v18, #4
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #4
    v.extract    s13, v15, #5
    v.extract    s14, v18, #5
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #5
    v.extract    s13, v15, #6
    v.extract    s14, v18, #6
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #6
    v.extract    s13, v15, #7
    v.extract    s14, v18, #7
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #7
    v.extract    s13, v15, #8
    v.extract    s14, v18, #8
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #8
    v.extract    s13, v15, #9
    v.extract    s14, v18, #9
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #9
    v.extract    s13, v15, #10
    v.extract    s14, v18, #10
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #10
    v.extract    s13, v15, #11
    v.extract    s14, v18, #11
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #11
    v.extract    s13, v15, #12
    v.extract    s14, v18, #12
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #12
    v.extract    s13, v15, #13
    v.extract    s14, v18, #13
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #13
    v.extract    s13, v15, #14
    v.extract    s14, v18, #14
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #14
    v.extract    s13, v15, #15
    v.extract    s14, v18, #15
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #15
    v.movi       v2, #0
    v.cmp.ne     p4, v1, v2
    v.movi       v1, #0
    v.extract    s13, v17, #0
    v.extract    s14, v20, #0
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #0
    v.extract    s13, v17, #1
    v.extract    s14, v20, #1
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #1
    v.extract    s13, v17, #2
    v.extract    s14, v20, #2
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #2
    v.extract    s13, v17, #3
    v.extract    s14, v20, #3
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #3
    v.extract    s13, v17, #4
    v.extract    s14, v20, #4
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #4
    v.extract    s13, v17, #5
    v.extract    s14, v20, #5
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #5
    v.extract    s13, v17, #6
    v.extract    s14, v20, #6
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #6
    v.extract    s13, v17, #7
    v.extract    s14, v20, #7
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #7
    v.extract    s13, v17, #8
    v.extract    s14, v20, #8
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #8
    v.extract    s13, v17, #9
    v.extract    s14, v20, #9
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #9
    v.extract    s13, v17, #10
    v.extract    s14, v20, #10
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #10
    v.extract    s13, v17, #11
    v.extract    s14, v20, #11
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #11
    v.extract    s13, v17, #12
    v.extract    s14, v20, #12
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #12
    v.extract    s13, v17, #13
    v.extract    s14, v20, #13
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #13
    v.extract    s13, v17, #14
    v.extract    s14, v20, #14
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #14
    v.extract    s13, v17, #15
    v.extract    s14, v20, #15
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #15
    v.movi       v2, #0
    v.cmp.ne     p5, v1, v2
    v.movi       v1, #0
    v.extract    s13, v19, #0
    v.extract    s14, v22, #0
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #0
    v.extract    s13, v19, #1
    v.extract    s14, v22, #1
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #1
    v.extract    s13, v19, #2
    v.extract    s14, v22, #2
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #2
    v.extract    s13, v19, #3
    v.extract    s14, v22, #3
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #3
    v.extract    s13, v19, #4
    v.extract    s14, v22, #4
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #4
    v.extract    s13, v19, #5
    v.extract    s14, v22, #5
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #5
    v.extract    s13, v19, #6
    v.extract    s14, v22, #6
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #6
    v.extract    s13, v19, #7
    v.extract    s14, v22, #7
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #7
    v.extract    s13, v19, #8
    v.extract    s14, v22, #8
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #8
    v.extract    s13, v19, #9
    v.extract    s14, v22, #9
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #9
    v.extract    s13, v19, #10
    v.extract    s14, v22, #10
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #10
    v.extract    s13, v19, #11
    v.extract    s14, v22, #11
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #11
    v.extract    s13, v19, #12
    v.extract    s14, v22, #12
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #12
    v.extract    s13, v19, #13
    v.extract    s14, v22, #13
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #13
    v.extract    s13, v19, #14
    v.extract    s14, v22, #14
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #14
    v.extract    s13, v19, #15
    v.extract    s14, v22, #15
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #15
    v.movi       v2, #0
    v.cmp.ne     p6, v1, v2
    v.movi       v1, #0
    v.extract    s13, v21, #0
    v.extract    s14, v24, #0
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #0
    v.extract    s13, v21, #1
    v.extract    s14, v24, #1
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #1
    v.extract    s13, v21, #2
    v.extract    s14, v24, #2
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #2
    v.extract    s13, v21, #3
    v.extract    s14, v24, #3
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #3
    v.extract    s13, v21, #4
    v.extract    s14, v24, #4
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #4
    v.extract    s13, v21, #5
    v.extract    s14, v24, #5
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #5
    v.extract    s13, v21, #6
    v.extract    s14, v24, #6
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #6
    v.extract    s13, v21, #7
    v.extract    s14, v24, #7
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #7
    v.extract    s13, v21, #8
    v.extract    s14, v24, #8
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #8
    v.extract    s13, v21, #9
    v.extract    s14, v24, #9
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #9
    v.extract    s13, v21, #10
    v.extract    s14, v24, #10
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #10
    v.extract    s13, v21, #11
    v.extract    s14, v24, #11
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #11
    v.extract    s13, v21, #12
    v.extract    s14, v24, #12
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #12
    v.extract    s13, v21, #13
    v.extract    s14, v24, #13
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #13
    v.extract    s13, v21, #14
    v.extract    s14, v24, #14
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #14
    v.extract    s13, v21, #15
    v.extract    s14, v24, #15
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #15
    v.movi       v2, #0
    v.cmp.ne     p7, v1, v2
    v.movi       v1, #0
    v.extract    s13, v23, #0
    v.extract    s14, v26, #0
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #0
    v.extract    s13, v23, #1
    v.extract    s14, v26, #1
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #1
    v.extract    s13, v23, #2
    v.extract    s14, v26, #2
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #2
    v.extract    s13, v23, #3
    v.extract    s14, v26, #3
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #3
    v.extract    s13, v23, #4
    v.extract    s14, v26, #4
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #4
    v.extract    s13, v23, #5
    v.extract    s14, v26, #5
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #5
    v.extract    s13, v23, #6
    v.extract    s14, v26, #6
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #6
    v.extract    s13, v23, #7
    v.extract    s14, v26, #7
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #7
    v.extract    s13, v23, #8
    v.extract    s14, v26, #8
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #8
    v.extract    s13, v23, #9
    v.extract    s14, v26, #9
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #9
    v.extract    s13, v23, #10
    v.extract    s14, v26, #10
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #10
    v.extract    s13, v23, #11
    v.extract    s14, v26, #11
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #11
    v.extract    s13, v23, #12
    v.extract    s14, v26, #12
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #12
    v.extract    s13, v23, #13
    v.extract    s14, v26, #13
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #13
    v.extract    s13, v23, #14
    v.extract    s14, v26, #14
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #14
    v.extract    s13, v23, #15
    v.extract    s14, v26, #15
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #15
    v.movi       v2, #0
    v.cmp.ne     p8, v1, v2
    v.movi       v1, #0
    v.extract    s13, v25, #0
    v.extract    s14, v28, #0
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #0
    v.extract    s13, v25, #1
    v.extract    s14, v28, #1
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #1
    v.extract    s13, v25, #2
    v.extract    s14, v28, #2
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #2
    v.extract    s13, v25, #3
    v.extract    s14, v28, #3
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #3
    v.extract    s13, v25, #4
    v.extract    s14, v28, #4
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #4
    v.extract    s13, v25, #5
    v.extract    s14, v28, #5
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #5
    v.extract    s13, v25, #6
    v.extract    s14, v28, #6
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #6
    v.extract    s13, v25, #7
    v.extract    s14, v28, #7
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #7
    v.extract    s13, v25, #8
    v.extract    s14, v28, #8
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #8
    v.extract    s13, v25, #9
    v.extract    s14, v28, #9
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #9
    v.extract    s13, v25, #10
    v.extract    s14, v28, #10
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #10
    v.extract    s13, v25, #11
    v.extract    s14, v28, #11
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #11
    v.extract    s13, v25, #12
    v.extract    s14, v28, #12
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #12
    v.extract    s13, v25, #13
    v.extract    s14, v28, #13
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #13
    v.extract    s13, v25, #14
    v.extract    s14, v28, #14
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #14
    v.extract    s13, v25, #15
    v.extract    s14, v28, #15
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #15
    v.movi       v2, #0
    v.cmp.ne     p9, v1, v2
    v.movi       v1, #0
    v.extract    s13, v27, #0
    v.extract    s14, v30, #0
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #0
    v.extract    s13, v27, #1
    v.extract    s14, v30, #1
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #1
    v.extract    s13, v27, #2
    v.extract    s14, v30, #2
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #2
    v.extract    s13, v27, #3
    v.extract    s14, v30, #3
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #3
    v.extract    s13, v27, #4
    v.extract    s14, v30, #4
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #4
    v.extract    s13, v27, #5
    v.extract    s14, v30, #5
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #5
    v.extract    s13, v27, #6
    v.extract    s14, v30, #6
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #6
    v.extract    s13, v27, #7
    v.extract    s14, v30, #7
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #7
    v.extract    s13, v27, #8
    v.extract    s14, v30, #8
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #8
    v.extract    s13, v27, #9
    v.extract    s14, v30, #9
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #9
    v.extract    s13, v27, #10
    v.extract    s14, v30, #10
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #10
    v.extract    s13, v27, #11
    v.extract    s14, v30, #11
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #11
    v.extract    s13, v27, #12
    v.extract    s14, v30, #12
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #12
    v.extract    s13, v27, #13
    v.extract    s14, v30, #13
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #13
    v.extract    s13, v27, #14
    v.extract    s14, v30, #14
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #14
    v.extract    s13, v27, #15
    v.extract    s14, v30, #15
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #15
    v.movi       v2, #0
    v.cmp.ne     p10, v1, v2
    v.movi       v1, #0
    v.extract    s13, v29, #0
    v.extract    s14, v32, #0
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #0
    v.extract    s13, v29, #1
    v.extract    s14, v32, #1
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #1
    v.extract    s13, v29, #2
    v.extract    s14, v32, #2
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #2
    v.extract    s13, v29, #3
    v.extract    s14, v32, #3
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #3
    v.extract    s13, v29, #4
    v.extract    s14, v32, #4
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #4
    v.extract    s13, v29, #5
    v.extract    s14, v32, #5
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #5
    v.extract    s13, v29, #6
    v.extract    s14, v32, #6
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #6
    v.extract    s13, v29, #7
    v.extract    s14, v32, #7
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #7
    v.extract    s13, v29, #8
    v.extract    s14, v32, #8
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #8
    v.extract    s13, v29, #9
    v.extract    s14, v32, #9
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #9
    v.extract    s13, v29, #10
    v.extract    s14, v32, #10
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #10
    v.extract    s13, v29, #11
    v.extract    s14, v32, #11
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #11
    v.extract    s13, v29, #12
    v.extract    s14, v32, #12
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #12
    v.extract    s13, v29, #13
    v.extract    s14, v32, #13
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #13
    v.extract    s13, v29, #14
    v.extract    s14, v32, #14
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #14
    v.extract    s13, v29, #15
    v.extract    s14, v32, #15
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #15
    v.movi       v2, #0
    v.cmp.ne     p11, v1, v2
    v.movi       v1, #0
    v.extract    s13, v0, #0
    v.extract    s14, v31, #0
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #0
    v.extract    s13, v0, #1
    v.extract    s14, v31, #1
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #1
    v.extract    s13, v0, #2
    v.extract    s14, v31, #2
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #2
    v.extract    s13, v0, #3
    v.extract    s14, v31, #3
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #3
    v.extract    s13, v0, #4
    v.extract    s14, v31, #4
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #4
    v.extract    s13, v0, #5
    v.extract    s14, v31, #5
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #5
    v.extract    s13, v0, #6
    v.extract    s14, v31, #6
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #6
    v.extract    s13, v0, #7
    v.extract    s14, v31, #7
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #7
    v.extract    s13, v0, #8
    v.extract    s14, v31, #8
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #8
    v.extract    s13, v0, #9
    v.extract    s14, v31, #9
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #9
    v.extract    s13, v0, #10
    v.extract    s14, v31, #10
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #10
    v.extract    s13, v0, #11
    v.extract    s14, v31, #11
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #11
    v.extract    s13, v0, #12
    v.extract    s14, v31, #12
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #12
    v.extract    s13, v0, #13
    v.extract    s14, v31, #13
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #13
    v.extract    s13, v0, #14
    v.extract    s14, v31, #14
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #14
    v.extract    s13, v0, #15
    v.extract    s14, v31, #15
    s.shli       s15, s14, #32
    s.or         s14, s13, s15
    s.movz       s13, #1
    s.cmp.ge     s15, s14, s13
    v.insert     v1, s15, #15
    v.movi       v0, #0
    v.cmp.ne     p12, v1, v0
    .li       s13, #4286578688
    v.splat      v0, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s13, #0
    s.movz       s14, #0
    a.vread      v1, a5, s14
    v.splat      v2, s8
    v.cmp.lt     p13, v2, v3
    p.frombits   p14, s3
    p.and        p15, p13, p14
    p.frombits   p13, s2
    p.and        p14, p15, p13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p14 v.ld.w       v2, [s6, #0]
    vf.sub       v4, v1, v2
    p.frombits   p13, s1
    @p13 v.sel        v1, v0, v4
    .li       s1, #1069066811
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v4, v1, v2
    vf.fms       v5, v1, v2, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v4                         // ISA 8.8: <= 2**-22 relative
    .li       s1, #1060205080
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v6, v5, v4
    vf.fma       v5, v1, v6, v1                  // 2**t * 2**d
    vf.cmp.o     p13, v5, v5
    @p13 v.sel        v6, v5, v1
    a.vwrite     a6, s13, v6
    s.movz       s1, #1
    s.movz       s13, #1
    a.vread      v1, a5, s13
    s.addi       s13, s8, #1
    v.splat      v5, s13
    v.cmp.lt     p13, v5, v3
    p.frombits   p14, s3
    p.and        p15, p13, p14
    p.frombits   p13, s2
    p.and        p14, p15, p13
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p14 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    p.frombits   p13, s9
    @p13 v.sel        v1, v0, v6
    vf.mul       v5, v1, v2
    vf.fms       v6, v1, v2, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v6, v4
    vf.fma       v6, v1, v5, v1                  // 2**t * 2**d
    vf.cmp.o     p13, v6, v6
    @p13 v.sel        v5, v6, v1
    a.vwrite     a6, s1, v5
    s.movz       s1, #2
    s.movz       s9, #2
    a.vread      v1, a5, s9
    s.addi       s9, s8, #2
    v.splat      v5, s9
    v.cmp.lt     p13, v5, v3
    p.frombits   p14, s3
    p.and        p15, p13, p14
    p.frombits   p13, s2
    p.and        p14, p15, p13
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p14 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    p.frombits   p13, s11
    @p13 v.sel        v1, v0, v6
    vf.mul       v5, v1, v2
    vf.fms       v6, v1, v2, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v6, v4
    vf.fma       v6, v1, v5, v1                  // 2**t * 2**d
    vf.cmp.o     p13, v6, v6
    @p13 v.sel        v5, v6, v1
    a.vwrite     a6, s1, v5
    s.movz       s1, #3
    s.movz       s9, #3
    a.vread      v1, a5, s9
    s.addi       s9, s8, #3
    v.splat      v5, s9
    v.cmp.lt     p13, v5, v3
    p.frombits   p14, s3
    p.and        p15, p13, p14
    p.frombits   p13, s2
    p.and        p14, p15, p13
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p14 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    p.frombits   p13, s12
    @p13 v.sel        v1, v0, v6
    vf.mul       v5, v1, v2
    vf.fms       v6, v1, v2, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v6, v4
    vf.fma       v6, v1, v5, v1                  // 2**t * 2**d
    vf.cmp.o     p13, v6, v6
    @p13 v.sel        v5, v6, v1
    a.vwrite     a6, s1, v5
    s.movz       s1, #4
    s.movz       s9, #4
    a.vread      v1, a5, s9
    s.addi       s9, s8, #4
    v.splat      v5, s9
    v.cmp.lt     p13, v5, v3
    p.frombits   p14, s3
    p.and        p15, p13, p14
    p.frombits   p13, s2
    p.and        p14, p15, p13
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p14 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    @p1 v.sel        v1, v0, v6
    vf.mul       v5, v1, v2
    vf.fms       v6, v1, v2, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v6, v4
    vf.fma       v6, v1, v5, v1                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v1
    a.vwrite     a6, s1, v5
    s.movz       s1, #5
    s.movz       s9, #5
    a.vread      v1, a5, s9
    s.addi       s9, s8, #5
    v.splat      v5, s9
    v.cmp.lt     p1, v5, v3
    p.frombits   p13, s3
    p.and        p14, p1, p13
    p.frombits   p1, s2
    p.and        p13, p14, p1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p13 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    @p2 v.sel        v1, v0, v6
    vf.mul       v5, v1, v2
    vf.fms       v6, v1, v2, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v6, v4
    vf.fma       v6, v1, v5, v1                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v1
    a.vwrite     a6, s1, v5
    s.movz       s1, #6
    s.movz       s9, #6
    a.vread      v1, a5, s9
    s.addi       s9, s8, #6
    v.splat      v5, s9
    v.cmp.lt     p1, v5, v3
    p.frombits   p2, s3
    p.and        p13, p1, p2
    p.frombits   p1, s2
    p.and        p2, p13, p1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    @p3 v.sel        v1, v0, v6
    vf.mul       v5, v1, v2
    vf.fms       v6, v1, v2, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v6, v4
    vf.fma       v6, v1, v5, v1                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v1
    a.vwrite     a6, s1, v5
    s.movz       s1, #7
    s.movz       s9, #7
    a.vread      v1, a5, s9
    s.addi       s9, s8, #7
    v.splat      v5, s9
    v.cmp.lt     p1, v5, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    @p4 v.sel        v1, v0, v6
    vf.mul       v5, v1, v2
    vf.fms       v6, v1, v2, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v6, v4
    vf.fma       v6, v1, v5, v1                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v1
    a.vwrite     a6, s1, v5
    s.movz       s1, #8
    s.movz       s9, #8
    a.vread      v1, a5, s9
    s.addi       s9, s8, #8
    v.splat      v5, s9
    v.cmp.lt     p1, v5, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    @p5 v.sel        v1, v0, v6
    vf.mul       v5, v1, v2
    vf.fms       v6, v1, v2, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v6, v4
    vf.fma       v6, v1, v5, v1                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v1
    a.vwrite     a6, s1, v5
    s.movz       s1, #9
    s.movz       s9, #9
    a.vread      v1, a5, s9
    s.addi       s9, s8, #9
    v.splat      v5, s9
    v.cmp.lt     p1, v5, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    @p6 v.sel        v1, v0, v6
    vf.mul       v5, v1, v2
    vf.fms       v6, v1, v2, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v6, v4
    vf.fma       v6, v1, v5, v1                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v1
    a.vwrite     a6, s1, v5
    s.movz       s1, #10
    s.movz       s9, #10
    a.vread      v1, a5, s9
    s.addi       s9, s8, #10
    v.splat      v5, s9
    v.cmp.lt     p1, v5, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    @p7 v.sel        v1, v0, v6
    vf.mul       v5, v1, v2
    vf.fms       v6, v1, v2, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v6, v4
    vf.fma       v6, v1, v5, v1                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v1
    a.vwrite     a6, s1, v5
    s.movz       s1, #11
    s.movz       s9, #11
    a.vread      v1, a5, s9
    s.addi       s9, s8, #11
    v.splat      v5, s9
    v.cmp.lt     p1, v5, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    @p8 v.sel        v1, v0, v6
    vf.mul       v5, v1, v2
    vf.fms       v6, v1, v2, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v6, v4
    vf.fma       v6, v1, v5, v1                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v1
    a.vwrite     a6, s1, v5
    s.movz       s1, #12
    s.movz       s9, #12
    a.vread      v1, a5, s9
    s.addi       s9, s8, #12
    v.splat      v5, s9
    v.cmp.lt     p1, v5, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    @p9 v.sel        v1, v0, v6
    vf.mul       v5, v1, v2
    vf.fms       v6, v1, v2, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v6, v4
    vf.fma       v6, v1, v5, v1                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v1
    a.vwrite     a6, s1, v5
    s.movz       s1, #13
    s.movz       s9, #13
    a.vread      v1, a5, s9
    s.addi       s9, s8, #13
    v.splat      v5, s9
    v.cmp.lt     p1, v5, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    @p10 v.sel        v1, v0, v6
    vf.mul       v5, v1, v2
    vf.fms       v6, v1, v2, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v6, v4
    vf.fma       v6, v1, v5, v1                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v1
    a.vwrite     a6, s1, v5
    s.movz       s1, #14
    s.movz       s9, #14
    a.vread      v1, a5, s9
    s.addi       s9, s8, #14
    v.splat      v5, s9
    v.cmp.lt     p1, v5, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    @p11 v.sel        v1, v0, v6
    vf.mul       v5, v1, v2
    vf.fms       v6, v1, v2, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v5                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v6, v4
    vf.fma       v6, v1, v5, v1                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v5, v6, v1
    a.vwrite     a6, s1, v5
    s.movz       s1, #15
    s.movz       s9, #15
    a.vread      v1, a5, s9
    s.addi       s9, s8, #15
    v.splat      v5, s9
    v.cmp.lt     p1, v5, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s6, #0]
    vf.sub       v6, v1, v5
    @p12 v.sel        v1, v0, v6
    vf.mul       v0, v1, v2
    vf.fms       v5, v1, v2, v0                  // the exact rounding error of x*log2(e)
    v.exp2.approx v1, v0                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v0, v5, v4
    vf.fma       v2, v1, v0, v1                  // 2**t * 2**d
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v0, v2, v1
    a.vwrite     a6, s1, v0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s1, #0
    s.movz       s6, #0
    a.vread      v0, a0, s6
    s.movz       s6, #0
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #1
    s.movz       s6, #1
    a.vread      v0, a0, s6
    s.movz       s6, #1
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #2
    s.movz       s6, #2
    a.vread      v0, a0, s6
    s.movz       s6, #2
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #3
    s.movz       s6, #3
    a.vread      v0, a0, s6
    s.movz       s6, #3
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #4
    s.movz       s6, #4
    a.vread      v0, a0, s6
    s.movz       s6, #4
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #5
    s.movz       s6, #5
    a.vread      v0, a0, s6
    s.movz       s6, #5
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #6
    s.movz       s6, #6
    a.vread      v0, a0, s6
    s.movz       s6, #6
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #7
    s.movz       s6, #7
    a.vread      v0, a0, s6
    s.movz       s6, #7
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #8
    s.movz       s6, #8
    a.vread      v0, a0, s6
    s.movz       s6, #8
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #9
    s.movz       s6, #9
    a.vread      v0, a0, s6
    s.movz       s6, #9
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #10
    s.movz       s6, #10
    a.vread      v0, a0, s6
    s.movz       s6, #10
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #11
    s.movz       s6, #11
    a.vread      v0, a0, s6
    s.movz       s6, #11
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #12
    s.movz       s6, #12
    a.vread      v0, a0, s6
    s.movz       s6, #12
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #13
    s.movz       s6, #13
    a.vread      v0, a0, s6
    s.movz       s6, #13
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #14
    s.movz       s6, #14
    a.vread      v0, a0, s6
    s.movz       s6, #14
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.movz       s1, #15
    s.movz       s6, #15
    a.vread      v0, a0, s6
    s.movz       s6, #15
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    a.vwrite     a7, s1, v2
    s.addi       s1, s21, #6144
    v.splat      v0, s8
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s7, #0]
    s.movz       s6, #0
    a.vread      v1, a6, s6
    vf.mul       v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s6, s1, #64
    s.addi       s9, s7, #256                    // row 1
    s.addi       s11, s8, #1
    v.splat      v0, s11
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s9, #0]
    s.movz       s9, #1
    a.vread      v1, a6, s9
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #128
    s.addi       s9, s7, #512                    // row 2
    s.addi       s11, s8, #2
    v.splat      v0, s11
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s9, #0]
    s.movz       s9, #2
    a.vread      v1, a6, s9
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #192
    s.addi       s9, s7, #768                    // row 3
    s.addi       s11, s8, #3
    v.splat      v0, s11
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s9, #0]
    s.movz       s9, #3
    a.vread      v1, a6, s9
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #256
    s.addi       s9, s7, #1024                   // row 4
    s.addi       s11, s8, #4
    v.splat      v0, s11
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s9, #0]
    s.movz       s9, #4
    a.vread      v1, a6, s9
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #320
    s.addi       s9, s7, #1280                   // row 5
    s.addi       s11, s8, #5
    v.splat      v0, s11
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s9, #0]
    s.movz       s9, #5
    a.vread      v1, a6, s9
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #384
    s.addi       s9, s7, #1536                   // row 6
    s.addi       s11, s8, #6
    v.splat      v0, s11
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s9, #0]
    s.movz       s9, #6
    a.vread      v1, a6, s9
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #448
    s.addi       s9, s7, #1792                   // row 7
    s.addi       s11, s8, #7
    v.splat      v0, s11
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s9, #0]
    s.movz       s9, #7
    a.vread      v1, a6, s9
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #512
    s.addi       s9, s7, #2048                   // row 8
    s.addi       s11, s8, #8
    v.splat      v0, s11
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s9, #0]
    s.movz       s9, #8
    a.vread      v1, a6, s9
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #576
    s.addi       s9, s7, #2304                   // row 9
    s.addi       s11, s8, #9
    v.splat      v0, s11
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s9, #0]
    s.movz       s9, #9
    a.vread      v1, a6, s9
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #640
    s.addi       s9, s7, #2560                   // row 10
    s.addi       s11, s8, #10
    v.splat      v0, s11
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s9, #0]
    s.movz       s9, #10
    a.vread      v1, a6, s9
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #704
    s.addi       s9, s7, #2816                   // row 11
    s.addi       s11, s8, #11
    v.splat      v0, s11
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s9, #0]
    s.movz       s9, #11
    a.vread      v1, a6, s9
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #768
    s.addi       s9, s7, #3072                   // row 12
    s.addi       s11, s8, #12
    v.splat      v0, s11
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s9, #0]
    s.movz       s9, #12
    a.vread      v1, a6, s9
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #832
    s.addi       s9, s7, #3328                   // row 13
    s.addi       s11, s8, #13
    v.splat      v0, s11
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s9, #0]
    s.movz       s9, #13
    a.vread      v1, a6, s9
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #896
    s.addi       s9, s7, #3584                   // row 14
    s.addi       s11, s8, #14
    v.splat      v0, s11
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s9, #0]
    s.movz       s9, #14
    a.vread      v1, a6, s9
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    s.addi       s6, s1, #960
    s.addi       s1, s7, #3840                   // row 15
    s.addi       s7, s8, #15
    v.splat      v0, s7
    v.cmp.lt     p1, v0, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #15
    a.vread      v1, a6, s1
    vf.mul       v2, v0, v1
    v.st.w       [s6, #0], v2
    fence.acq_rel.device
    s.muli       s1, s10, #4                     // a runtime tile origin, x4
    s.add        s6, s17, s1                     // the tile origin
    s.muli       s1, s4, #256                    // a runtime tile origin, x256
    s.add        s7, s6, s1                      // the tile origin
    s.muli       s1, s5, #4                      // a runtime tile origin, x4
    s.add        s6, s7, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v0, a6, s1
    v.splat      v1, s8
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s6, #0], v0
    s.movz       s1, #1
    a.vread      v0, a6, s1
    s.addi       s1, s6, #256                    // row 1
    s.addi       s7, s8, #1
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #2
    a.vread      v0, a6, s1
    s.addi       s1, s6, #512                    // row 2
    s.addi       s7, s8, #2
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #3
    a.vread      v0, a6, s1
    s.addi       s1, s6, #768                    // row 3
    s.addi       s7, s8, #3
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #4
    a.vread      v0, a6, s1
    s.addi       s1, s6, #1024                   // row 4
    s.addi       s7, s8, #4
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #5
    a.vread      v0, a6, s1
    s.addi       s1, s6, #1280                   // row 5
    s.addi       s7, s8, #5
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #6
    a.vread      v0, a6, s1
    s.addi       s1, s6, #1536                   // row 6
    s.addi       s7, s8, #6
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #7
    a.vread      v0, a6, s1
    s.addi       s1, s6, #1792                   // row 7
    s.addi       s7, s8, #7
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #8
    a.vread      v0, a6, s1
    s.addi       s1, s6, #2048                   // row 8
    s.addi       s7, s8, #8
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #9
    a.vread      v0, a6, s1
    s.addi       s1, s6, #2304                   // row 9
    s.addi       s7, s8, #9
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #10
    a.vread      v0, a6, s1
    s.addi       s1, s6, #2560                   // row 10
    s.addi       s7, s8, #10
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #11
    a.vread      v0, a6, s1
    s.addi       s1, s6, #2816                   // row 11
    s.addi       s7, s8, #11
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #12
    a.vread      v0, a6, s1
    s.addi       s1, s6, #3072                   // row 12
    s.addi       s7, s8, #12
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #13
    a.vread      v0, a6, s1
    s.addi       s1, s6, #3328                   // row 13
    s.addi       s7, s8, #13
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #14
    a.vread      v0, a6, s1
    s.addi       s1, s6, #3584                   // row 14
    s.addi       s7, s8, #14
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #15
    a.vread      v0, a6, s1
    s.addi       s1, s6, #3840                   // row 15
    s.addi       s6, s8, #15
    v.splat      v1, s6
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.muli       s1, s10, #4                     // a runtime tile origin, x4
    s.add        s6, s18, s1                     // the tile origin
    s.muli       s1, s4, #256                    // a runtime tile origin, x256
    s.add        s7, s6, s1                      // the tile origin
    s.muli       s1, s5, #4                      // a runtime tile origin, x4
    s.add        s6, s7, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v0, a7, s1
    v.splat      v1, s8
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s6, #0], v0
    s.movz       s1, #1
    a.vread      v0, a7, s1
    s.addi       s1, s6, #256                    // row 1
    s.addi       s7, s8, #1
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #2
    a.vread      v0, a7, s1
    s.addi       s1, s6, #512                    // row 2
    s.addi       s7, s8, #2
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #3
    a.vread      v0, a7, s1
    s.addi       s1, s6, #768                    // row 3
    s.addi       s7, s8, #3
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #4
    a.vread      v0, a7, s1
    s.addi       s1, s6, #1024                   // row 4
    s.addi       s7, s8, #4
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #5
    a.vread      v0, a7, s1
    s.addi       s1, s6, #1280                   // row 5
    s.addi       s7, s8, #5
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #6
    a.vread      v0, a7, s1
    s.addi       s1, s6, #1536                   // row 6
    s.addi       s7, s8, #6
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #7
    a.vread      v0, a7, s1
    s.addi       s1, s6, #1792                   // row 7
    s.addi       s7, s8, #7
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #8
    a.vread      v0, a7, s1
    s.addi       s1, s6, #2048                   // row 8
    s.addi       s7, s8, #8
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #9
    a.vread      v0, a7, s1
    s.addi       s1, s6, #2304                   // row 9
    s.addi       s7, s8, #9
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #10
    a.vread      v0, a7, s1
    s.addi       s1, s6, #2560                   // row 10
    s.addi       s7, s8, #10
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #11
    a.vread      v0, a7, s1
    s.addi       s1, s6, #2816                   // row 11
    s.addi       s7, s8, #11
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #12
    a.vread      v0, a7, s1
    s.addi       s1, s6, #3072                   // row 12
    s.addi       s7, s8, #12
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #13
    a.vread      v0, a7, s1
    s.addi       s1, s6, #3328                   // row 13
    s.addi       s7, s8, #13
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #14
    a.vread      v0, a7, s1
    s.addi       s1, s6, #3584                   // row 14
    s.addi       s7, s8, #14
    v.splat      v1, s7
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #15
    a.vread      v0, a7, s1
    s.addi       s1, s6, #3840                   // row 15
    s.addi       s6, s8, #15
    v.splat      v1, s6
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.muli       s1, s10, #4                     // a runtime tile origin, x4
    s.add        s6, s19, s1                     // the tile origin
    s.muli       s1, s4, #256                    // a runtime tile origin, x256
    s.add        s4, s6, s1                      // the tile origin
    s.muli       s1, s5, #4                      // a runtime tile origin, x4
    s.add        s5, s4, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s1, s21, #6144
    v.ld.w       v0, [s1, #0]
    v.splat      v1, s8
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s5, #0], v0
    s.addi       s1, s21, #6208
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #256                    // row 1
    s.addi       s4, s8, #1
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.addi       s1, s21, #6272
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #512                    // row 2
    s.addi       s4, s8, #2
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.addi       s1, s21, #6336
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #768                    // row 3
    s.addi       s4, s8, #3
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.addi       s1, s21, #6400
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #1024                   // row 4
    s.addi       s4, s8, #4
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.addi       s1, s21, #6464
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #1280                   // row 5
    s.addi       s4, s8, #5
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.addi       s1, s21, #6528
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #1536                   // row 6
    s.addi       s4, s8, #6
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.addi       s1, s21, #6592
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #1792                   // row 7
    s.addi       s4, s8, #7
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.addi       s1, s21, #6656
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #2048                   // row 8
    s.addi       s4, s8, #8
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.addi       s1, s21, #6720
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #2304                   // row 9
    s.addi       s4, s8, #9
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.addi       s1, s21, #6784
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #2560                   // row 10
    s.addi       s4, s8, #10
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.addi       s1, s21, #6848
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #2816                   // row 11
    s.addi       s4, s8, #11
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.addi       s1, s21, #6912
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #3072                   // row 12
    s.addi       s4, s8, #12
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.addi       s1, s21, #6976
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #3328                   // row 13
    s.addi       s4, s8, #13
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.addi       s1, s21, #7040
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #3584                   // row 14
    s.addi       s4, s8, #14
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
    s.addi       s1, s21, #7104
    v.ld.w       v0, [s1, #0]
    s.addi       s1, s5, #3840                   // row 15
    s.addi       s4, s8, #15
    v.splat      v1, s4
    v.cmp.lt     p1, v1, v3
    p.frombits   p2, s3
    p.and        p3, p1, p2
    p.frombits   p1, s2
    p.and        p2, p3, p1
    @p2 v.st.w       [s1, #0], v0
__rctx_next:
    exit
