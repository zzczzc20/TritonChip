    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #4
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #2
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s1, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s6, #0
    s.cmp.lt     s8, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s8
    s.sub        s8, s6, s9
    s.xor        s6, s12, s3
    s.muli       s9, s5, #4
    s.movz       s5, #0
    s.movz       s11, #1
    s.xor        s13, s4, s8
    s.sub        s14, s6, s3
    s.rdspecial  s3, arg_base
    s.xor        s6, s1, s7
    s.movz       s15, #0
    s.sub        s16, s13, s8
    s.addi       s13, s5, #0
    s.cmp.eq     s5, s14, s11
    s.ld.d       s11, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s17, s6, s7
    s.sub        s6, s2, s9
    s.addi       s2, s15, #0
    s.ld.d       s6, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s7, [s3, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s9, [s3, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s15, [s3, #32]                  // out_ptr1: device_ptr64 at arg_base+32
    s.ld.d       s17, [s3, #40]                  // out_ptr2: device_ptr64 at arg_base+40
    s.mov        s13, s16
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s13, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s16, s3
    s.shli       s18, s2, #1
    s.andi       s19, s5, #1
    s.movz       s5, #0
    s.or         s20, s18, s19
    s.movz       s18, #1
    s.cmp.geu    s19, s20, s14
    s.shl        s21, s18, s3
    s.sub        s18, s5, s19
    s.subi       s5, s3, #1
    s.and        s19, s14, s18
    s.and        s22, s21, s18
    s.sub        s18, s20, s19
    s.or         s19, s13, s22
    s.mov        s2, s18
    s.mov        s13, s19
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s18, s3, s5
    br.nz        s18, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s13, s4, s3
    s.movz       s3, #0
    s.sub        s14, s5, s13
    s.movz       s5, #0
    s.xor        s13, s4, s14
    s.movz       s4, #0
    s.sub        s16, s13, s14
    s.cmp.lt     s13, s12, s3
    s.lshri      s3, s16, #2
    s.movz       s18, #0
    s.muli       s19, s3, #4
    s.sub        s3, s4, s13
    s.movz       s4, #0
    s.cmp.lt     s13, s1, s18
    s.xor        s18, s12, s3
    s.sub        s12, s16, s19
    s.movz       s16, #0
    s.xor        s19, s12, s14
    s.xor        s12, s2, s8
    s.sub        s2, s19, s14
    s.sub        s14, s16, s13
    s.cmp.lt     s13, s2, s5
    s.sub        s5, s18, s3
    s.sub        s16, s4, s13
    s.movz       s4, #0
    s.xor        s13, s2, s16
    s.movz       s2, #1
    s.sub        s18, s12, s8
    s.xor        s8, s1, s14
    s.sub        s1, s13, s16
    s.movz       s12, #0
    s.addi       s13, s4, #0
    s.cmp.eq     s4, s5, s2
    s.add        s2, s10, s18
    s.sub        s10, s8, s14
    s.addi       s8, s12, #0
    s.mov        s13, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s10, #31
    s.mov        s13, s4
    s.addi       s4, s10, #0
sdiv_4:
    s.lshr       s10, s1, s4
    s.shli       s12, s8, #1
    s.andi       s14, s10, #1
    s.movz       s10, #0
    s.or         s18, s12, s14
    s.movz       s12, #1
    s.cmp.geu    s14, s18, s5
    s.shl        s19, s12, s4
    s.sub        s12, s10, s14
    s.subi       s10, s4, #1
    s.and        s14, s5, s12
    s.and        s20, s19, s12
    s.sub        s12, s18, s14
    s.or         s14, s13, s20
    s.mov        s8, s12
    s.mov        s13, s14
    s.mov        s4, s10
    s.movz       s10, #0
    s.cmp.ge     s12, s4, s10
    br.nz        s12, sdiv_4
sdiv_done_3:
    s.xor        s1, s16, s3
    s.movz       s3, #16
    s.xor        s4, s13, s1
    s.rdspecial  s5, pid.z
    s.sub        s8, s4, s1
    s.rdspecial  s1, npid.y
    s.mul        s4, s2, s3
    s.mul        s10, s8, s3
    s.mul        s12, s5, s1
    s.rdspecial  s1, pid.y
    s.movz       s5, #31
    s.andi       s13, s4, #63
    s.andi       s14, s10, #63
    s.add        s16, s1, s12
    s.rdspecial  s1, arg_base
    s.min.s      s12, s16, s5
    s.movz       s5, #8192
    s.ld.d       s18, [s1, #48]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.muli       s1, s13, #128                   // a runtime tile origin, x128
    s.mul        s19, s12, s5
    s.movz       s12, #0
    s.rdspecial  s20, role_id
    s.movz       s21, #7168
    s.add        s22, s12, s1                    // the tile origin
    s.mul        s1, s20, s21
    s.add        s12, s22, s19                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s12
    s.movz       s20, #0
    s.add        s21, s18, s1                    // this context's own scratch
    v.splat      v2, s2
    s.addi       s1, s21, #0
    v.splat      v3, s20
    s.addi       s2, s12, #128
    v.splat      v4, s8
    v.splat      v5, s20
    v.iota       v6                              // arange(0, VLEN)
    v.add        v7, v0, v1
    s.addi       s8, s1, #64
    v.cmp.ge     p1, v2, v3
    v.splat      v1, s2
    v.splat      v2, s4
    v.cmp.ge     p1, v4, v5
    s.addi       s2, s12, #256
    v.splat      v3, s10
    v.splat      v4, s2
    v.add        v5, v0, v1
    s.addi       s2, s1, #128
    v.add        v1, v0, v4
    v.add        v4, v2, v6
    s.addi       s18, s12, #384
    v.splat      v2, s13
    s.addi       s13, s1, #192
    v.add        v4, v3, v6
    v.splat      v3, s18
    v.iota       v4                              // arange(0, VLEN)
    s.addi       s18, s12, #512
    v.add        v6, v0, v3
    s.addi       s22, s1, #256
    v.add        v3, v2, v4
    v.splat      v2, s18
    v.splat      v3, s14
    s.movz       s18, #128
    v.add        v4, v0, v2
    s.addi       s23, s20, #0
    v.st.w       [s1, #0], v7
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s24, s1, #320
    v.add        v7, v3, v2
    s.addi       s25, s12, #640
    v.splat      v2, s25
    s.addi       s25, s12, #768
    v.splat      v3, s25
    s.addi       s25, s12, #896
    v.add        v7, v0, v2
    v.add        v2, v0, v3
    v.st.w       [s8, #0], v5
    s.addi       s8, s12, #1024
    v.splat      v3, s25
    s.addi       s25, s12, #1152
    v.add        v5, v0, v3
    v.st.w       [s2, #0], v1
    s.addi       s2, s12, #1280
    v.splat      v1, s8
    s.addi       s8, s12, #1408
    v.add        v3, v0, v1
    v.st.w       [s13, #0], v6
    s.addi       s13, s12, #1536
    v.splat      v1, s25
    s.addi       s25, s12, #1664
    v.add        v6, v0, v1
    v.st.w       [s22, #0], v4
    s.addi       s22, s12, #1792
    s.addi       s26, s12, #1920
    v.splat      v1, s2
    s.addi       s2, s1, #384
    v.add        v4, v0, v1
    v.st.w       [s24, #0], v7
    v.splat      v1, s8
    s.addi       s8, s21, #1024
    s.addi       s12, s1, #448
    v.add        v7, v0, v1
    v.st.w       [s2, #0], v2
    s.muli       s2, s14, #128                   // a runtime tile origin, x128
    s.movz       s14, #0
    v.iota       v1                              // arange(0, VLEN)
    s.add        s24, s14, s2                    // the tile origin
    s.addi       s2, s1, #512
    s.add        s14, s24, s19                   // the tile origin
    s.addi       s19, s1, #576
    v.st.w       [s12, #0], v5
    s.movz       s12, #128
    v.splat      v2, s13
    s.addi       s13, s1, #640
    v.add        v5, v0, v2
    v.st.w       [s2, #0], v3
    v.splat      v2, s12
    s.addi       s2, s14, #1
    s.addi       s12, s1, #704
    v.mul        v3, v1, v2
    v.splat      v1, s25
    s.addi       s24, s1, #768
    v.add        v2, v0, v1
    v.st.w       [s19, #0], v6
    s.addi       s19, s14, #2
    v.splat      v1, s22
    s.addi       s22, s1, #832
    v.add        v6, v0, v1
    v.st.w       [s13, #0], v4
    s.addi       s13, s14, #3
    v.splat      v1, s26
    s.addi       s25, s1, #896
    s.addi       s26, s1, #960
    v.add        v4, v0, v1
    v.st.w       [s12, #0], v7
    s.addi       s1, s14, #4
    v.splat      v1, s14
    v.add        v7, v3, v1
    v.st.w       [s24, #0], v5
    s.addi       s12, s14, #5
    v.splat      v1, s2
    s.addi       s2, s8, #64
    v.add        v5, v3, v1
    v.st.w       [s22, #0], v2
    s.addi       s22, s14, #6
    v.splat      v1, s19
    s.addi       s19, s8, #128
    v.add        v2, v3, v1
    v.st.w       [s25, #0], v6
    s.addi       s24, s14, #7
    v.splat      v1, s13
    s.addi       s13, s8, #192
    v.add        v6, v3, v1
    v.st.w       [s26, #0], v4
    v.splat      v1, s1
    s.addi       s1, s8, #256
    s.addi       s25, s8, #320
    v.add        v4, v3, v1
    fence.acq_rel.device
    v.st.w       [s8, #0], v7
    v.splat      v1, s12
    s.addi       s12, s14, #8
    v.add        v7, v3, v1
    v.st.w       [s2, #0], v5
    s.addi       s2, s14, #9
    v.splat      v1, s22
    s.addi       s22, s14, #10
    v.add        v5, v3, v1
    v.st.w       [s19, #0], v2
    s.addi       s19, s14, #11
    v.splat      v1, s24
    s.addi       s24, s14, #12
    v.add        v2, v3, v1
    v.st.w       [s13, #0], v6
    s.addi       s13, s14, #13
    v.splat      v1, s12
    s.addi       s12, s14, #14
    v.add        v6, v3, v1
    v.st.w       [s1, #0], v4
    s.addi       s1, s14, #15
    v.splat      v1, s2
    s.addi       s2, s8, #384
    s.addi       s14, s8, #448
    v.add        v4, v3, v1
    v.st.w       [s25, #0], v7
    v.splat      v1, s22
    s.addi       s22, s8, #512
    s.addi       s25, s8, #576
    v.add        v7, v3, v1
    v.st.w       [s2, #0], v5
    v.splat      v1, s19
    s.addi       s2, s8, #640
    s.addi       s19, s8, #704
    v.add        v5, v3, v1
    v.st.w       [s14, #0], v2
    v.splat      v1, s24
    s.addi       s14, s8, #768
    s.addi       s24, s8, #832
    v.add        v2, v3, v1
    v.st.w       [s22, #0], v6
    v.splat      v1, s13
    s.addi       s13, s8, #896
    s.addi       s22, s8, #960
    v.add        v6, v3, v1
    v.st.w       [s25, #0], v4
    v.splat      v1, s12
    v.add        v4, v3, v1
    v.st.w       [s2, #0], v7
    v.splat      v1, s1
    v.add        v7, v3, v1
    v.st.w       [s19, #0], v5
    v.st.w       [s14, #0], v2
    v.st.w       [s24, #0], v6
    v.st.w       [s13, #0], v4
    v.st.w       [s22, #0], v7
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s1, s23, s18
    br.nz        s1, endfor_6
    s.addi       s1, s21, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s2, #0
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #64
    s.movz       s8, #1
    s.addi       s12, s21, #128
    s.movz       s13, #2
    s.addi       s14, s21, #192
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s2, v2
    v.ld.w       v1, [s1, #0]
    s.movz       s1, #3
    s.addi       s2, s21, #256
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s8, v2
    v.ld.w       v1, [s12, #0]
    s.movz       s8, #4
    s.addi       s12, s21, #320
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v2
    v.ld.w       v1, [s14, #0]
    s.movz       s13, #5
    s.addi       s14, s21, #384
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s2, #0]
    s.movz       s1, #6
    s.addi       s2, s21, #448
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s8, v2
    v.ld.w       v1, [s12, #0]
    s.movz       s8, #7
    s.addi       s12, s21, #512
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v2
    v.ld.w       v1, [s14, #0]
    s.movz       s13, #8
    s.addi       s14, s21, #576
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s2, #0]
    s.movz       s1, #9
    s.addi       s2, s21, #640
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s8, v2
    v.ld.w       v1, [s12, #0]
    s.movz       s8, #10
    s.addi       s12, s21, #704
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v2
    v.ld.w       v1, [s14, #0]
    s.movz       s13, #11
    s.addi       s14, s21, #768
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s2, #0]
    s.movz       s1, #12
    s.addi       s2, s21, #832
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s8, v2
    v.ld.w       v1, [s12, #0]
    s.movz       s8, #13
    s.addi       s12, s21, #896
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v2
    v.ld.w       v1, [s14, #0]
    s.movz       s13, #14
    s.addi       s14, s21, #960
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s2, #0]
    s.movz       s1, #15
    s.addi       s2, s21, #1024
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s8, v2
    v.ld.w       v1, [s12, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s8, #0
    s.addi       s12, s21, #1088
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v2
    v.ld.w       v1, [s14, #0]
    s.movz       s13, #1
    s.addi       s14, s21, #1152
    v.ld.gather.w v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    s.movz       s19, #2
    a.vwrite     a1, s1, v2
    v.ld.w       v1, [s2, #0]
    s.addi       s1, s21, #1216
    s.movz       s2, #3
    v.ld.gather.w v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s8, v2
    v.ld.w       v1, [s12, #0]
    s.addi       s8, s21, #1280
    s.movz       s12, #4
    v.ld.gather.w v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v2
    v.ld.w       v1, [s14, #0]
    s.addi       s13, s21, #1344
    s.movz       s14, #5
    v.ld.gather.w v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s19, v2
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #1408
    s.movz       s19, #6
    v.ld.gather.w v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s2, v2
    v.ld.w       v1, [s8, #0]
    s.addi       s2, s21, #1472
    s.movz       s8, #7
    v.ld.gather.w v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s12, v2
    v.ld.w       v1, [s13, #0]
    s.addi       s12, s21, #1536
    s.movz       s13, #8
    v.ld.gather.w v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v2
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #1600
    s.movz       s14, #9
    v.movi       v2, #0
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s19, v3
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s21, #1664
    s.movz       s19, #10
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s8, v3
    v.ld.w       v1, [s12, #0]
    s.addi       s8, s21, #1728
    s.movz       s12, #11
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v3
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #1792
    s.movz       s13, #12
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v3
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s21, #1856
    s.movz       s14, #13
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s19, v3
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s21, #1920
    s.movz       s19, #14
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s12, v3
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #1984
    s.movz       s12, #15
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v3
    v.ld.w       v1, [s2, #0]
    s.movz       s2, #0
    s.movz       s13, #0
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s14, v3
    v.ld.w       v1, [s8, #0]
    s.movz       s8, #1
    s.movz       s14, #2
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s19, v3
    v.ld.w       v1, [s1, #0]
    s.movz       s1, #3
    s.movz       s19, #4
    v.ld.gather.w v3, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.movz       s22, #5
    a.vwrite     a2, s12, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s13
    a.vread      v4, a2, s8
    v.extract    s2, v1, #0
    v.extract    s8, v1, #1
    v.splat      v5, s2
    v.splat      v6, s8
    v.extract    s2, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s2
    a.vread      v5, a2, s14
    v.extract    s2, v1, #3
    a.vread      v8, a2, s1
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s2
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s1, #0
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #1
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s1
    a.vread      v5, a2, s13
    v.extract    s1, v1, #3
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    s.movz       s1, #1
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #2
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s1
    a.vread      v5, a2, s13
    v.extract    s1, v1, #3
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    s.movz       s1, #2
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #3
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s1
    a.vread      v5, a2, s13
    v.extract    s1, v1, #3
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    s.movz       s1, #3
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #4
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s1
    a.vread      v5, a2, s13
    v.extract    s1, v1, #3
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    s.movz       s1, #4
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #5
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s1
    a.vread      v5, a2, s13
    v.extract    s1, v1, #3
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    s.movz       s1, #5
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #6
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s1
    a.vread      v5, a2, s13
    v.extract    s1, v1, #3
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    s.movz       s1, #6
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #7
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s1
    a.vread      v5, a2, s13
    v.extract    s1, v1, #3
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    s.movz       s1, #7
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #8
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s1
    a.vread      v5, a2, s13
    v.extract    s1, v1, #3
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    s.movz       s1, #8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #9
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s1
    a.vread      v5, a2, s13
    v.extract    s1, v1, #3
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    s.movz       s1, #9
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #10
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s1
    a.vread      v5, a2, s13
    v.extract    s1, v1, #3
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    s.movz       s1, #10
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #11
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s1
    a.vread      v5, a2, s13
    v.extract    s1, v1, #3
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    s.movz       s1, #11
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #12
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s1
    a.vread      v5, a2, s13
    v.extract    s1, v1, #3
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    s.movz       s1, #12
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #13
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s1
    a.vread      v5, a2, s13
    v.extract    s1, v1, #3
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    s.movz       s1, #13
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #14
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s1
    a.vread      v5, a2, s13
    v.extract    s1, v1, #3
    a.vread      v8, a2, s14
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v10, v3, v5, v9
    v.extract    s1, v1, #5
    a.vread      v3, a2, s22
    v.splat      v5, s1
    v.extract    s1, v1, #6
    vf.fma       v9, v4, v8, v10
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v8, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v10, v7, v6, v9
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v9, v5, v3, v10
    s.movz       s2, #8
    v.splat      v3, s1
    a.vread      v5, a2, s2
    s.movz       s1, #14
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v9, v6, v7, v10
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v10, v3, v5, v9
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v4, v8, v10
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v8, a2, s8
    vf.fma       v10, v6, v7, v9
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v3, v5, v10
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v3, s2
    a.vread      v5, a2, s8
    vf.fma       v10, v4, v8, v9
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v8, v6, v7, v10
    s.movz       s2, #15
    s.movz       s8, #0
    s.movz       s12, #1
    s.movz       s13, #2
    vf.fma       v6, v3, v5, v8
    s.movz       s14, #3
    s.movz       s19, #4
    s.movz       s22, #5
    vf.fma       v3, v1, v4, v6
    a.vwrite     a3, s1, v3
    a.vread      v1, a1, s2
    a.vread      v3, a2, s8
    a.vread      v4, a2, s12
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v5, s1
    v.splat      v6, s2
    v.extract    s1, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v2, s1
    a.vread      v3, a2, s13
    v.extract    s1, v1, #3
    a.vread      v5, a2, s14
    vf.fma       v8, v6, v4, v7
    v.splat      v4, s1
    v.extract    s1, v1, #4
    a.vread      v6, a2, s19
    v.splat      v7, s1
    vf.fma       v9, v2, v3, v8
    v.extract    s1, v1, #5
    a.vread      v2, a2, s22
    v.splat      v3, s1
    v.extract    s1, v1, #6
    vf.fma       v8, v4, v5, v9
    s.movz       s2, #6
    v.splat      v4, s1
    a.vread      v5, a2, s2
    v.extract    s1, v1, #7
    vf.fma       v9, v7, v6, v8
    s.movz       s2, #7
    v.splat      v6, s1
    a.vread      v7, a2, s2
    v.extract    s1, v1, #8
    vf.fma       v8, v3, v2, v9
    s.movz       s2, #8
    v.splat      v2, s1
    a.vread      v3, a2, s2
    s.movz       s1, #15
    vf.fma       v9, v4, v5, v8
    v.extract    s2, v1, #9
    s.movz       s8, #9
    v.splat      v4, s2
    a.vread      v5, a2, s8
    vf.fma       v8, v6, v7, v9
    v.extract    s2, v1, #10
    s.movz       s8, #10
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v9, v2, v3, v8
    v.extract    s2, v1, #11
    s.movz       s8, #11
    v.splat      v2, s2
    a.vread      v3, a2, s8
    vf.fma       v8, v4, v5, v9
    v.extract    s2, v1, #12
    s.movz       s8, #12
    v.splat      v4, s2
    a.vread      v5, a2, s8
    vf.fma       v9, v6, v7, v8
    v.extract    s2, v1, #13
    s.movz       s8, #13
    v.splat      v6, s2
    a.vread      v7, a2, s8
    vf.fma       v8, v2, v3, v9
    v.extract    s2, v1, #14
    s.movz       s8, #14
    v.splat      v2, s2
    a.vread      v3, a2, s8
    vf.fma       v9, v4, v5, v8
    v.extract    s2, v1, #15
    s.movz       s8, #15
    v.splat      v1, s2
    a.vread      v4, a2, s8
    vf.fma       v5, v6, v7, v9
    s.addi       s2, s21, #0
    v.splat      v6, s3
    s.addi       s8, s21, #2048
    s.addi       s12, s21, #64
    vf.fma       v7, v2, v3, v5
    s.addi       s13, s8, #64
    s.addi       s14, s21, #128
    s.addi       s19, s8, #128
    s.addi       s22, s21, #192
    vf.fma       v2, v1, v4, v7
    a.vwrite     a3, s1, v2
    v.ld.w       v1, [s2, #0]
    s.addi       s1, s8, #192
    s.addi       s2, s21, #256
    v.add        v2, v1, v6
    v.st.w       [s8, #0], v2
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s8, #256
    v.add        v2, v1, v6
    v.st.w       [s13, #0], v2
    s.addi       s13, s21, #320
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s8, #320
    v.add        v2, v1, v6
    v.st.w       [s19, #0], v2
    s.addi       s19, s21, #384
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s8, #384
    v.add        v2, v1, v6
    v.st.w       [s1, #0], v2
    s.addi       s1, s21, #448
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s8, #448
    v.add        v2, v1, v6
    v.st.w       [s12, #0], v2
    s.addi       s12, s21, #512
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s8, #512
    v.add        v2, v1, v6
    v.st.w       [s14, #0], v2
    s.addi       s14, s21, #576
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s8, #576
    v.add        v2, v1, v6
    v.st.w       [s22, #0], v2
    s.addi       s22, s21, #640
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #640
    v.add        v2, v1, v6
    v.st.w       [s2, #0], v2
    s.addi       s2, s21, #704
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s8, #704
    v.add        v2, v1, v6
    v.st.w       [s13, #0], v2
    s.addi       s13, s21, #768
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s8, #768
    v.add        v2, v1, v6
    v.st.w       [s19, #0], v2
    s.addi       s19, s21, #832
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s8, #832
    v.add        v2, v1, v6
    v.st.w       [s1, #0], v2
    s.addi       s1, s21, #896
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s8, #896
    s.addi       s24, s8, #960
    v.add        v2, v1, v6
    v.st.w       [s12, #0], v2
    s.addi       s8, s21, #960
    v.ld.w       v1, [s13, #0]
    s.addi       s12, s21, #1024
    v.add        v2, v1, v6
    v.st.w       [s14, #0], v2
    s.addi       s13, s21, #3072
    v.ld.w       v1, [s19, #0]
    s.addi       s14, s21, #1088
    v.add        v2, v1, v6
    v.st.w       [s22, #0], v2
    s.addi       s19, s13, #64
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #1152
    v.add        v2, v1, v6
    v.st.w       [s2, #0], v2
    s.addi       s2, s13, #128
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s21, #1216
    v.add        v2, v1, v6
    v.st.w       [s24, #0], v2
    fence.acq_rel.device
    s.addi       s22, s13, #192
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s21, #1280
    v.add        v2, v1, v6
    v.st.w       [s13, #0], v2
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s13, #256
    v.add        v2, v1, v6
    v.st.w       [s19, #0], v2
    s.addi       s19, s21, #1344
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s13, #320
    v.add        v2, v1, v6
    v.st.w       [s2, #0], v2
    s.addi       s2, s21, #1408
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s13, #384
    v.add        v2, v1, v6
    v.st.w       [s22, #0], v2
    s.addi       s22, s21, #1472
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s13, #448
    v.add        v2, v1, v6
    v.st.w       [s14, #0], v2
    s.addi       s14, s21, #1536
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s13, #512
    v.add        v2, v1, v6
    v.st.w       [s1, #0], v2
    s.addi       s1, s21, #1600
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s13, #576
    v.add        v2, v1, v6
    v.st.w       [s8, #0], v2
    s.addi       s8, s21, #1664
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s13, #640
    v.add        v2, v1, v6
    v.st.w       [s12, #0], v2
    s.addi       s12, s21, #1728
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s13, #704
    v.add        v2, v1, v6
    v.st.w       [s19, #0], v2
    s.addi       s19, s21, #1792
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s13, #768
    v.add        v2, v1, v6
    v.st.w       [s2, #0], v2
    s.addi       s2, s21, #1856
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s13, #832
    v.add        v2, v1, v6
    v.st.w       [s22, #0], v2
    s.addi       s22, s21, #1920
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s13, #896
    s.addi       s24, s13, #960
    v.add        v2, v1, v6
    v.st.w       [s14, #0], v2
    s.addi       s13, s21, #1984
    v.ld.w       v1, [s19, #0]
    s.addi       s14, s21, #2048
    v.add        v2, v1, v6
    v.st.w       [s1, #0], v2
    s.addi       s1, s21, #4096
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s21, #2112
    v.add        v2, v1, v6
    v.st.w       [s8, #0], v2
    s.addi       s8, s1, #64
    v.ld.w       v1, [s22, #0]
    s.addi       s19, s21, #2176
    v.add        v2, v1, v6
    v.st.w       [s12, #0], v2
    s.addi       s12, s1, #128
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s21, #2240
    v.add        v2, v1, v6
    v.st.w       [s24, #0], v2
    fence.acq_rel.device
    s.addi       s22, s1, #192
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s21, #2304
    v.st.w       [s1, #0], v1
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #256
    v.st.w       [s8, #0], v1
    s.addi       s8, s21, #2368
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s1, #320
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #2432
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s1, #384
    v.st.w       [s22, #0], v1
    s.addi       s22, s21, #2496
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s1, #448
    v.st.w       [s2, #0], v1
    s.addi       s2, s21, #2560
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s1, #512
    v.st.w       [s19, #0], v1
    s.addi       s19, s21, #2624
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s1, #576
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #2688
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s1, #640
    v.st.w       [s14, #0], v1
    s.addi       s14, s21, #2752
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s1, #704
    v.st.w       [s8, #0], v1
    s.addi       s8, s21, #2816
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s1, #768
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #2880
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s1, #832
    v.st.w       [s22, #0], v1
    s.addi       s22, s21, #2944
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s1, #896
    s.addi       s24, s1, #960
    v.st.w       [s2, #0], v1
    s.addi       s1, s21, #3008
    v.ld.w       v1, [s8, #0]
    s.addi       s2, s21, #3072
    v.st.w       [s19, #0], v1
    s.addi       s8, s21, #5120
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s21, #3136
    v.st.w       [s13, #0], v1
    s.addi       s13, s8, #64
    v.ld.w       v1, [s22, #0]
    s.addi       s19, s21, #3200
    v.st.w       [s14, #0], v1
    s.addi       s14, s8, #128
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #3264
    v.st.w       [s24, #0], v1
    fence.acq_rel.device
    s.addi       s22, s8, #192
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s21, #3328
    v.st.w       [s8, #0], v1
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s8, #256
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #3392
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s8, #320
    v.st.w       [s14, #0], v1
    s.addi       s14, s21, #3456
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #384
    v.st.w       [s22, #0], v1
    s.addi       s22, s21, #3520
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s8, #448
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #3584
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s8, #512
    v.st.w       [s19, #0], v1
    s.addi       s19, s21, #3648
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s8, #576
    v.st.w       [s1, #0], v1
    s.addi       s1, s21, #3712
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s8, #640
    v.st.w       [s2, #0], v1
    s.addi       s2, s21, #3776
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s8, #704
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #3840
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s8, #768
    v.st.w       [s14, #0], v1
    s.addi       s14, s21, #3904
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s8, #832
    v.st.w       [s22, #0], v1
    s.addi       s22, s21, #3968
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s8, #896
    s.addi       s24, s8, #960
    v.st.w       [s12, #0], v1
    s.addi       s8, s21, #4032
    v.ld.w       v1, [s13, #0]
    s.movz       s12, #0
    v.st.w       [s19, #0], v1
    s.movz       s13, #0
    v.ld.w       v1, [s14, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s14, #0
    v.st.w       [s1, #0], v1
    s.movz       s1, #1
    v.ld.w       v1, [s22, #0]
    s.movz       s19, #1
    v.st.w       [s2, #0], v1
    s.movz       s2, #1
    v.ld.w       v1, [s8, #0]
    s.movz       s8, #2
    v.st.w       [s24, #0], v1
    fence.acq_rel.device
    a.vread      v1, a0, s12
    a.vread      v2, a3, s13
    s.movz       s12, #2
    s.movz       s13, #2
    vf.add       v3, v1, v2
    s.movz       s22, #3
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s1
    a.vread      v2, a3, s19
    s.movz       s1, #3
    s.movz       s14, #3
    vf.add       v3, v1, v2
    s.movz       s19, #4
    a.vwrite     a4, s2, v3
    a.vread      v1, a0, s8
    a.vread      v2, a3, s12
    s.movz       s2, #4
    s.movz       s8, #4
    vf.add       v3, v1, v2
    s.movz       s12, #5
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s22
    a.vread      v2, a3, s1
    s.movz       s1, #5
    s.movz       s13, #5
    vf.add       v3, v1, v2
    s.movz       s22, #6
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s2
    s.movz       s2, #6
    s.movz       s14, #6
    vf.add       v3, v1, v2
    s.movz       s19, #7
    a.vwrite     a4, s8, v3
    a.vread      v1, a0, s12
    a.vread      v2, a3, s1
    s.movz       s1, #7
    s.movz       s8, #7
    vf.add       v3, v1, v2
    s.movz       s12, #8
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s22
    a.vread      v2, a3, s2
    s.movz       s2, #8
    s.movz       s13, #8
    vf.add       v3, v1, v2
    s.movz       s22, #9
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s1
    s.movz       s1, #9
    s.movz       s14, #9
    vf.add       v3, v1, v2
    s.movz       s19, #10
    a.vwrite     a4, s8, v3
    a.vread      v1, a0, s12
    a.vread      v2, a3, s2
    s.movz       s2, #10
    s.movz       s8, #10
    vf.add       v3, v1, v2
    s.movz       s12, #11
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s22
    a.vread      v2, a3, s1
    s.movz       s1, #11
    s.movz       s13, #11
    vf.add       v3, v1, v2
    s.movz       s22, #12
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s2
    s.movz       s2, #12
    s.movz       s14, #12
    vf.add       v3, v1, v2
    s.movz       s19, #13
    a.vwrite     a4, s8, v3
    a.vread      v1, a0, s12
    a.vread      v2, a3, s1
    s.movz       s1, #13
    s.movz       s8, #13
    vf.add       v3, v1, v2
    s.movz       s12, #14
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s22
    a.vread      v2, a3, s2
    s.movz       s2, #14
    s.movz       s13, #14
    vf.add       v3, v1, v2
    s.movz       s22, #15
    a.vwrite     a4, s14, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s1
    s.movz       s1, #15
    s.movz       s14, #15
    vf.add       v3, v1, v2
    s.addi       s19, s21, #4096
    a.vwrite     a4, s8, v3
    a.vread      v1, a0, s12
    a.vread      v2, a3, s2
    s.addi       s2, s21, #0
    s.addi       s8, s21, #4160
    vf.add       v3, v1, v2
    s.addi       s12, s21, #64
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s22
    a.vread      v2, a3, s1
    s.addi       s1, s21, #4224
    s.addi       s13, s21, #128
    vf.add       v3, v1, v2
    s.addi       s22, s21, #4288
    a.vwrite     a4, s14, v3
    v.ld.w       v1, [s19, #0]
    s.addi       s14, s21, #192
    s.addi       s19, s21, #4352
    v.st.w       [s2, #0], v1
    s.addi       s2, s21, #256
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s21, #4416
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #320
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #4480
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #384
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s21, #4544
    v.st.w       [s14, #0], v1
    s.addi       s14, s21, #448
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s21, #4608
    v.st.w       [s2, #0], v1
    s.addi       s2, s21, #512
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s21, #4672
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #576
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #4736
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #640
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s21, #4800
    v.st.w       [s14, #0], v1
    s.addi       s14, s21, #704
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s21, #4864
    v.st.w       [s2, #0], v1
    s.addi       s2, s21, #768
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s21, #4928
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #832
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #4992
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #896
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s21, #5056
    v.st.w       [s14, #0], v1
    s.addi       s14, s21, #960
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s21, #5120
    v.st.w       [s2, #0], v1
    s.addi       s2, s21, #1024
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s21, #5184
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #1088
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #5248
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #1152
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s21, #5312
    v.st.w       [s14, #0], v1
    fence.acq_rel.device
    s.addi       s14, s21, #1216
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s21, #5376
    v.st.w       [s2, #0], v1
    s.addi       s2, s21, #1280
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s21, #5440
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #1344
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #5504
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #1408
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s21, #5568
    v.st.w       [s14, #0], v1
    s.addi       s14, s21, #1472
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s21, #5632
    v.st.w       [s2, #0], v1
    s.addi       s2, s21, #1536
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s21, #5696
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #1600
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #5760
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #1664
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s21, #5824
    v.st.w       [s14, #0], v1
    s.addi       s14, s21, #1728
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s21, #5888
    v.st.w       [s2, #0], v1
    s.addi       s2, s21, #1792
    v.ld.w       v1, [s8, #0]
    s.addi       s8, s21, #5952
    v.st.w       [s12, #0], v1
    s.addi       s12, s21, #1856
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s21, #6016
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #1920
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s21, #6080
    v.st.w       [s14, #0], v1
    s.addi       s14, s21, #1984
    v.ld.w       v1, [s19, #0]
    s.movz       s19, #0
    v.st.w       [s2, #0], v1
    s.movz       s2, #0
    v.ld.w       v1, [s8, #0]
    s.movz       s8, #1
    v.st.w       [s12, #0], v1
    s.movz       s12, #1
    v.ld.w       v1, [s1, #0]
    s.movz       s1, #2
    v.st.w       [s13, #0], v1
    s.movz       s13, #2
    v.ld.w       v1, [s22, #0]
    s.movz       s22, #3
    v.st.w       [s14, #0], v1
    fence.acq_rel.device
    a.vread      v1, a4, s19
    s.movz       s14, #3
    s.movz       s19, #4
    a.vwrite     a0, s2, v1
    a.vread      v1, a4, s8
    s.movz       s2, #4
    s.movz       s8, #5
    a.vwrite     a0, s12, v1
    a.vread      v1, a4, s1
    s.movz       s1, #5
    s.movz       s12, #6
    a.vwrite     a0, s13, v1
    a.vread      v1, a4, s22
    s.movz       s13, #6
    s.movz       s22, #7
    a.vwrite     a0, s14, v1
    a.vread      v1, a4, s19
    s.movz       s14, #7
    s.movz       s19, #8
    a.vwrite     a0, s2, v1
    a.vread      v1, a4, s8
    s.movz       s2, #8
    s.movz       s8, #9
    a.vwrite     a0, s1, v1
    a.vread      v1, a4, s12
    s.movz       s1, #9
    s.movz       s12, #10
    a.vwrite     a0, s13, v1
    a.vread      v1, a4, s22
    s.movz       s13, #10
    s.movz       s22, #11
    a.vwrite     a0, s14, v1
    a.vread      v1, a4, s19
    s.movz       s14, #11
    s.movz       s19, #12
    a.vwrite     a0, s2, v1
    a.vread      v1, a4, s8
    s.movz       s2, #12
    s.movz       s8, #13
    a.vwrite     a0, s1, v1
    a.vread      v1, a4, s12
    s.movz       s1, #13
    s.movz       s12, #14
    a.vwrite     a0, s13, v1
    a.vread      v1, a4, s22
    s.movz       s13, #14
    s.movz       s22, #15
    a.vwrite     a0, s14, v1
    a.vread      v1, a4, s19
    s.movz       s14, #15
    s.add        s19, s23, s3
    a.vwrite     a0, s2, v1
    a.vread      v1, a4, s8
    s.movz       s2, #1
    a.vwrite     a0, s1, v1
    a.vread      v1, a4, s12
    a.vwrite     a0, s13, v1
    a.vread      v1, a4, s22
    a.vwrite     a0, s14, v1
    s.mov        s23, s19
    br.nz        s2, for_5
endfor_6:
    v.splat      v1, s16
    s.movz       s1, #32
    v.splat      v2, s1
    v.cmp.lt     p1, v1, v2
    s.movz       s1, #4096
    s.mul        s2, s16, s1
    s.muli       s3, s10, #4                     // a runtime tile origin, x4
    s.add        s6, s7, s3                      // the tile origin
    s.muli       s3, s4, #256                    // a runtime tile origin, x256
    s.add        s7, s6, s3                      // the tile origin
    s.muli       s3, s2, #4                      // a runtime tile origin, x4
    s.add        s6, s7, s3                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.addi       s3, s21, #6144
    v.splat      v1, s20
    s.movz       s7, #0
    s.add        s8, s7, s10                     // the tile origin
    s.muli       s7, s4, #64                     // a runtime tile origin, x64
    s.add        s11, s8, s7                     // the tile origin
    s.add        s7, s11, s2                     // the tile origin
    v.splat      v2, s7
    v.add        v3, v0, v2
    v.splat      v2, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.cmp.lt     p2, v3, v4
    v.cmp.lt     p3, v2, v4
    v.sub        v5, v4, v3
    @p2 v.sel        v6, v5, v3
    v.sub        v3, v4, v2
    @p3 v.sel        v5, v3, v2
    v.movi       v3, #4095
    v.and        v5, v6, v3
    v.sub        v3, v4, v5
    @p2 v.sel        v4, v3, v5
    v.splat      v3, s7
    v.add        v5, v0, v3
    v.splat      v3, s5
    v.movi       v6, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v5, v6
    v.cmp.lt     p3, v3, v6
    v.sub        v7, v6, v5
    @p2 v.sel        v8, v7, v5
    v.sub        v5, v6, v3
    @p3 v.sel        v7, v5, v3
    v.movi       v5, #13
    v.lshr       v7, v8, v5
    v.sub        v5, v6, v7
    @p2 v.sel        v6, v5, v7
    v.mul        v5, v6, v2
    v.add        v6, v4, v5
    v.splat      v4, s7
    v.add        v5, v0, v4
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p2, v5, v4
    v.cmp.lt     p3, v2, v4
    v.sub        v7, v4, v5
    @p2 v.sel        v8, v7, v5
    v.sub        v5, v4, v2
    @p3 v.sel        v7, v5, v2
    v.movi       v5, #12
    v.lshr       v7, v8, v5
    v.sub        v5, v4, v7
    @p2 v.sel        v4, v5, v7
    s.movz       s1, #2
    v.splat      v5, s1
    v.movi       v7, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v4, v7
    v.cmp.lt     p3, v5, v7
    v.sub        v8, v7, v4
    @p2 v.sel        v9, v8, v4
    v.sub        v4, v7, v5
    @p3 v.sel        v8, v4, v5
    v.movi       v4, #1
    v.and        v8, v9, v4
    v.sub        v4, v7, v8
    @p2 v.sel        v7, v4, v8
    .li       s1, #65536
    v.splat      v4, s1
    v.mul        v8, v7, v4
    v.add        v7, v6, v8
    v.add        v6, v1, v7
    v.st.w       [s3, #0], v6
    s.addi       s1, s3, #64
    s.addi       s5, s7, #64
    v.splat      v6, s5
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s5, s7, #64
    v.splat      v7, s5
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v8, #13
    v.lshr       v9, v10, v8
    v.sub        v8, v7, v9
    @p2 v.sel        v7, v8, v9
    v.mul        v8, v7, v2
    v.add        v7, v6, v8
    s.addi       s5, s7, #64
    v.splat      v6, s5
    v.add        v8, v0, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v9, v6, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v6, v2
    @p3 v.sel        v9, v8, v2
    v.movi       v8, #12
    v.lshr       v9, v10, v8
    v.sub        v8, v6, v9
    @p2 v.sel        v6, v8, v9
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v5, v8
    v.sub        v9, v8, v6
    @p2 v.sel        v10, v9, v6
    v.sub        v6, v8, v5
    @p3 v.sel        v9, v6, v5
    v.movi       v6, #1
    v.and        v9, v10, v6
    v.sub        v6, v8, v9
    @p2 v.sel        v8, v6, v9
    v.mul        v6, v8, v4
    v.add        v8, v7, v6
    v.add        v6, v1, v8
    v.st.w       [s1, #0], v6
    s.addi       s1, s3, #128
    s.addi       s5, s7, #128
    v.splat      v6, s5
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s5, s7, #128
    v.splat      v7, s5
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v8, #13
    v.lshr       v9, v10, v8
    v.sub        v8, v7, v9
    @p2 v.sel        v7, v8, v9
    v.mul        v8, v7, v2
    v.add        v7, v6, v8
    s.addi       s5, s7, #128
    v.splat      v6, s5
    v.add        v8, v0, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v9, v6, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v6, v2
    @p3 v.sel        v9, v8, v2
    v.movi       v8, #12
    v.lshr       v9, v10, v8
    v.sub        v8, v6, v9
    @p2 v.sel        v6, v8, v9
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v5, v8
    v.sub        v9, v8, v6
    @p2 v.sel        v10, v9, v6
    v.sub        v6, v8, v5
    @p3 v.sel        v9, v6, v5
    v.movi       v6, #1
    v.and        v9, v10, v6
    v.sub        v6, v8, v9
    @p2 v.sel        v8, v6, v9
    v.mul        v6, v8, v4
    v.add        v8, v7, v6
    v.add        v6, v1, v8
    v.st.w       [s1, #0], v6
    s.addi       s1, s3, #192
    s.addi       s5, s7, #192
    v.splat      v6, s5
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s5, s7, #192
    v.splat      v7, s5
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v8, #13
    v.lshr       v9, v10, v8
    v.sub        v8, v7, v9
    @p2 v.sel        v7, v8, v9
    v.mul        v8, v7, v2
    v.add        v7, v6, v8
    s.addi       s5, s7, #192
    v.splat      v6, s5
    v.add        v8, v0, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v9, v6, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v6, v2
    @p3 v.sel        v9, v8, v2
    v.movi       v8, #12
    v.lshr       v9, v10, v8
    v.sub        v8, v6, v9
    @p2 v.sel        v6, v8, v9
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v5, v8
    v.sub        v9, v8, v6
    @p2 v.sel        v10, v9, v6
    v.sub        v6, v8, v5
    @p3 v.sel        v9, v6, v5
    v.movi       v6, #1
    v.and        v9, v10, v6
    v.sub        v6, v8, v9
    @p2 v.sel        v8, v6, v9
    v.mul        v6, v8, v4
    v.add        v8, v7, v6
    v.add        v6, v1, v8
    v.st.w       [s1, #0], v6
    s.addi       s1, s3, #256
    s.addi       s5, s7, #256
    v.splat      v6, s5
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s5, s7, #256
    v.splat      v7, s5
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v8, #13
    v.lshr       v9, v10, v8
    v.sub        v8, v7, v9
    @p2 v.sel        v7, v8, v9
    v.mul        v8, v7, v2
    v.add        v7, v6, v8
    s.addi       s5, s7, #256
    v.splat      v6, s5
    v.add        v8, v0, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v9, v6, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v6, v2
    @p3 v.sel        v9, v8, v2
    v.movi       v8, #12
    v.lshr       v9, v10, v8
    v.sub        v8, v6, v9
    @p2 v.sel        v6, v8, v9
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v5, v8
    v.sub        v9, v8, v6
    @p2 v.sel        v10, v9, v6
    v.sub        v6, v8, v5
    @p3 v.sel        v9, v6, v5
    v.movi       v6, #1
    v.and        v9, v10, v6
    v.sub        v6, v8, v9
    @p2 v.sel        v8, v6, v9
    v.mul        v6, v8, v4
    v.add        v8, v7, v6
    v.add        v6, v1, v8
    v.st.w       [s1, #0], v6
    s.addi       s1, s3, #320
    s.addi       s5, s7, #320
    v.splat      v6, s5
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s5, s7, #320
    v.splat      v7, s5
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v8, #13
    v.lshr       v9, v10, v8
    v.sub        v8, v7, v9
    @p2 v.sel        v7, v8, v9
    v.mul        v8, v7, v2
    v.add        v7, v6, v8
    s.addi       s5, s7, #320
    v.splat      v6, s5
    v.add        v8, v0, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v9, v6, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v6, v2
    @p3 v.sel        v9, v8, v2
    v.movi       v8, #12
    v.lshr       v9, v10, v8
    v.sub        v8, v6, v9
    @p2 v.sel        v6, v8, v9
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v5, v8
    v.sub        v9, v8, v6
    @p2 v.sel        v10, v9, v6
    v.sub        v6, v8, v5
    @p3 v.sel        v9, v6, v5
    v.movi       v6, #1
    v.and        v9, v10, v6
    v.sub        v6, v8, v9
    @p2 v.sel        v8, v6, v9
    v.mul        v6, v8, v4
    v.add        v8, v7, v6
    v.add        v6, v1, v8
    v.st.w       [s1, #0], v6
    s.addi       s1, s3, #384
    s.addi       s5, s7, #384
    v.splat      v6, s5
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s5, s7, #384
    v.splat      v7, s5
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v8, #13
    v.lshr       v9, v10, v8
    v.sub        v8, v7, v9
    @p2 v.sel        v7, v8, v9
    v.mul        v8, v7, v2
    v.add        v7, v6, v8
    s.addi       s5, s7, #384
    v.splat      v6, s5
    v.add        v8, v0, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v9, v6, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v6, v2
    @p3 v.sel        v9, v8, v2
    v.movi       v8, #12
    v.lshr       v9, v10, v8
    v.sub        v8, v6, v9
    @p2 v.sel        v6, v8, v9
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v5, v8
    v.sub        v9, v8, v6
    @p2 v.sel        v10, v9, v6
    v.sub        v6, v8, v5
    @p3 v.sel        v9, v6, v5
    v.movi       v6, #1
    v.and        v9, v10, v6
    v.sub        v6, v8, v9
    @p2 v.sel        v8, v6, v9
    v.mul        v6, v8, v4
    v.add        v8, v7, v6
    v.add        v6, v1, v8
    v.st.w       [s1, #0], v6
    s.addi       s1, s3, #448
    s.addi       s5, s7, #448
    v.splat      v6, s5
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s5, s7, #448
    v.splat      v7, s5
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v8, #13
    v.lshr       v9, v10, v8
    v.sub        v8, v7, v9
    @p2 v.sel        v7, v8, v9
    v.mul        v8, v7, v2
    v.add        v7, v6, v8
    s.addi       s5, s7, #448
    v.splat      v6, s5
    v.add        v8, v0, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v9, v6, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v6, v2
    @p3 v.sel        v9, v8, v2
    v.movi       v8, #12
    v.lshr       v9, v10, v8
    v.sub        v8, v6, v9
    @p2 v.sel        v6, v8, v9
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v5, v8
    v.sub        v9, v8, v6
    @p2 v.sel        v10, v9, v6
    v.sub        v6, v8, v5
    @p3 v.sel        v9, v6, v5
    v.movi       v6, #1
    v.and        v9, v10, v6
    v.sub        v6, v8, v9
    @p2 v.sel        v8, v6, v9
    v.mul        v6, v8, v4
    v.add        v8, v7, v6
    v.add        v6, v1, v8
    v.st.w       [s1, #0], v6
    s.addi       s1, s3, #512
    s.addi       s5, s7, #512
    v.splat      v6, s5
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s5, s7, #512
    v.splat      v7, s5
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v8, #13
    v.lshr       v9, v10, v8
    v.sub        v8, v7, v9
    @p2 v.sel        v7, v8, v9
    v.mul        v8, v7, v2
    v.add        v7, v6, v8
    s.addi       s5, s7, #512
    v.splat      v6, s5
    v.add        v8, v0, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v9, v6, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v6, v2
    @p3 v.sel        v9, v8, v2
    v.movi       v8, #12
    v.lshr       v9, v10, v8
    v.sub        v8, v6, v9
    @p2 v.sel        v6, v8, v9
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v5, v8
    v.sub        v9, v8, v6
    @p2 v.sel        v10, v9, v6
    v.sub        v6, v8, v5
    @p3 v.sel        v9, v6, v5
    v.movi       v6, #1
    v.and        v9, v10, v6
    v.sub        v6, v8, v9
    @p2 v.sel        v8, v6, v9
    v.mul        v6, v8, v4
    v.add        v8, v7, v6
    v.add        v6, v1, v8
    v.st.w       [s1, #0], v6
    s.addi       s1, s3, #576
    s.addi       s5, s7, #576
    v.splat      v6, s5
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s5, s7, #576
    v.splat      v7, s5
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v8, #13
    v.lshr       v9, v10, v8
    v.sub        v8, v7, v9
    @p2 v.sel        v7, v8, v9
    v.mul        v8, v7, v2
    v.add        v7, v6, v8
    s.addi       s5, s7, #576
    v.splat      v6, s5
    v.add        v8, v0, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v9, v6, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v6, v2
    @p3 v.sel        v9, v8, v2
    v.movi       v8, #12
    v.lshr       v9, v10, v8
    v.sub        v8, v6, v9
    @p2 v.sel        v6, v8, v9
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v5, v8
    v.sub        v9, v8, v6
    @p2 v.sel        v10, v9, v6
    v.sub        v6, v8, v5
    @p3 v.sel        v9, v6, v5
    v.movi       v6, #1
    v.and        v9, v10, v6
    v.sub        v6, v8, v9
    @p2 v.sel        v8, v6, v9
    v.mul        v6, v8, v4
    v.add        v8, v7, v6
    v.add        v6, v1, v8
    v.st.w       [s1, #0], v6
    s.addi       s1, s3, #640
    s.addi       s5, s7, #640
    v.splat      v6, s5
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s5, s7, #640
    v.splat      v7, s5
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v8, #13
    v.lshr       v9, v10, v8
    v.sub        v8, v7, v9
    @p2 v.sel        v7, v8, v9
    v.mul        v8, v7, v2
    v.add        v7, v6, v8
    s.addi       s5, s7, #640
    v.splat      v6, s5
    v.add        v8, v0, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v9, v6, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v6, v2
    @p3 v.sel        v9, v8, v2
    v.movi       v8, #12
    v.lshr       v9, v10, v8
    v.sub        v8, v6, v9
    @p2 v.sel        v6, v8, v9
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v5, v8
    v.sub        v9, v8, v6
    @p2 v.sel        v10, v9, v6
    v.sub        v6, v8, v5
    @p3 v.sel        v9, v6, v5
    v.movi       v6, #1
    v.and        v9, v10, v6
    v.sub        v6, v8, v9
    @p2 v.sel        v8, v6, v9
    v.mul        v6, v8, v4
    v.add        v8, v7, v6
    v.add        v6, v1, v8
    v.st.w       [s1, #0], v6
    s.addi       s1, s3, #704
    s.addi       s5, s7, #704
    v.splat      v6, s5
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s5, s7, #704
    v.splat      v7, s5
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v8, #13
    v.lshr       v9, v10, v8
    v.sub        v8, v7, v9
    @p2 v.sel        v7, v8, v9
    v.mul        v8, v7, v2
    v.add        v7, v6, v8
    s.addi       s5, s7, #704
    v.splat      v6, s5
    v.add        v8, v0, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v9, v6, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v6, v2
    @p3 v.sel        v9, v8, v2
    v.movi       v8, #12
    v.lshr       v9, v10, v8
    v.sub        v8, v6, v9
    @p2 v.sel        v6, v8, v9
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v5, v8
    v.sub        v9, v8, v6
    @p2 v.sel        v10, v9, v6
    v.sub        v6, v8, v5
    @p3 v.sel        v9, v6, v5
    v.movi       v6, #1
    v.and        v9, v10, v6
    v.sub        v6, v8, v9
    @p2 v.sel        v8, v6, v9
    v.mul        v6, v8, v4
    v.add        v8, v7, v6
    v.add        v6, v1, v8
    v.st.w       [s1, #0], v6
    s.addi       s1, s3, #768
    s.addi       s5, s7, #768
    v.splat      v6, s5
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s5, s7, #768
    v.splat      v7, s5
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v8, #13
    v.lshr       v9, v10, v8
    v.sub        v8, v7, v9
    @p2 v.sel        v7, v8, v9
    v.mul        v8, v7, v2
    v.add        v7, v6, v8
    s.addi       s5, s7, #768
    v.splat      v6, s5
    v.add        v8, v0, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v9, v6, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v6, v2
    @p3 v.sel        v9, v8, v2
    v.movi       v8, #12
    v.lshr       v9, v10, v8
    v.sub        v8, v6, v9
    @p2 v.sel        v6, v8, v9
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v5, v8
    v.sub        v9, v8, v6
    @p2 v.sel        v10, v9, v6
    v.sub        v6, v8, v5
    @p3 v.sel        v9, v6, v5
    v.movi       v6, #1
    v.and        v9, v10, v6
    v.sub        v6, v8, v9
    @p2 v.sel        v8, v6, v9
    v.mul        v6, v8, v4
    v.add        v8, v7, v6
    v.add        v6, v1, v8
    v.st.w       [s1, #0], v6
    s.addi       s1, s3, #832
    s.addi       s5, s7, #832
    v.splat      v6, s5
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s5, s7, #832
    v.splat      v7, s5
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v8, #13
    v.lshr       v9, v10, v8
    v.sub        v8, v7, v9
    @p2 v.sel        v7, v8, v9
    v.mul        v8, v7, v2
    v.add        v7, v6, v8
    s.addi       s5, s7, #832
    v.splat      v6, s5
    v.add        v8, v0, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v9, v6, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v6, v2
    @p3 v.sel        v9, v8, v2
    v.movi       v8, #12
    v.lshr       v9, v10, v8
    v.sub        v8, v6, v9
    @p2 v.sel        v6, v8, v9
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v5, v8
    v.sub        v9, v8, v6
    @p2 v.sel        v10, v9, v6
    v.sub        v6, v8, v5
    @p3 v.sel        v9, v6, v5
    v.movi       v6, #1
    v.and        v9, v10, v6
    v.sub        v6, v8, v9
    @p2 v.sel        v8, v6, v9
    v.mul        v6, v8, v4
    v.add        v8, v7, v6
    v.add        v6, v1, v8
    v.st.w       [s1, #0], v6
    s.addi       s1, s3, #896
    s.addi       s5, s7, #896
    v.splat      v6, s5
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s5, s7, #896
    v.splat      v7, s5
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v8, #13
    v.lshr       v9, v10, v8
    v.sub        v8, v7, v9
    @p2 v.sel        v7, v8, v9
    v.mul        v8, v7, v2
    v.add        v7, v6, v8
    s.addi       s5, s7, #896
    v.splat      v6, s5
    v.add        v8, v0, v6
    v.movi       v6, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v9, v6, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v6, v2
    @p3 v.sel        v9, v8, v2
    v.movi       v8, #12
    v.lshr       v9, v10, v8
    v.sub        v8, v6, v9
    @p2 v.sel        v6, v8, v9
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v6, v8
    v.cmp.lt     p3, v5, v8
    v.sub        v9, v8, v6
    @p2 v.sel        v10, v9, v6
    v.sub        v6, v8, v5
    @p3 v.sel        v9, v6, v5
    v.movi       v6, #1
    v.and        v9, v10, v6
    v.sub        v6, v8, v9
    @p2 v.sel        v8, v6, v9
    v.mul        v6, v8, v4
    v.add        v8, v7, v6
    v.add        v6, v1, v8
    v.st.w       [s1, #0], v6
    s.addi       s1, s3, #960
    s.addi       s3, s7, #960
    v.splat      v6, s3
    v.add        v7, v0, v6
    v.movi       v6, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v7, v6
    v.cmp.lt     p3, v2, v6
    v.sub        v8, v6, v7
    @p2 v.sel        v9, v8, v7
    v.sub        v7, v6, v2
    @p3 v.sel        v8, v7, v2
    v.movi       v7, #4095
    v.and        v8, v9, v7
    v.sub        v7, v6, v8
    @p2 v.sel        v6, v7, v8
    s.addi       s3, s7, #960
    v.splat      v7, s3
    v.add        v8, v0, v7
    v.movi       v7, #0
    v.movi       v9, #1
    v.cmp.lt     p2, v8, v7
    v.cmp.lt     p3, v3, v7
    v.sub        v9, v7, v8
    @p2 v.sel        v10, v9, v8
    v.sub        v8, v7, v3
    @p3 v.sel        v9, v8, v3
    v.movi       v3, #13
    v.lshr       v8, v10, v3
    v.sub        v3, v7, v8
    @p2 v.sel        v7, v3, v8
    v.mul        v3, v7, v2
    v.add        v7, v6, v3
    s.addi       s3, s7, #960
    v.splat      v3, s3
    v.add        v6, v0, v3
    v.movi       v3, #0
    v.movi       v8, #1
    v.cmp.lt     p2, v6, v3
    v.cmp.lt     p3, v2, v3
    v.sub        v8, v3, v6
    @p2 v.sel        v9, v8, v6
    v.sub        v6, v3, v2
    @p3 v.sel        v8, v6, v2
    v.movi       v2, #12
    v.lshr       v6, v9, v2
    v.sub        v2, v3, v6
    @p2 v.sel        v3, v2, v6
    v.movi       v2, #0
    v.movi       v6, #1
    v.cmp.lt     p2, v3, v2
    v.cmp.lt     p3, v5, v2
    v.sub        v6, v2, v3
    @p2 v.sel        v8, v6, v3
    v.sub        v3, v2, v5
    @p3 v.sel        v6, v3, v5
    v.movi       v3, #1
    v.and        v5, v8, v3
    v.sub        v3, v2, v5
    @p2 v.sel        v2, v3, v5
    v.mul        v3, v2, v4
    v.add        v2, v7, v3
    v.add        v3, v1, v2
    v.st.w       [s1, #0], v3
    fence.acq_rel.device
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s1, #0
    s.addi       s3, s21, #6144
    v.ld.w       v1, [s3, #0]
    s.movz       s3, #0
    s.add        s5, s3, s4                      // the tile origin
    v.splat      v2, s5
    s.movz       s3, #64
    v.splat      v3, s3
    v.cmp.lt     p2, v2, v3
    v.movi       v2, #1
    v.movi       v4, #0
    @p2 v.sel        v5, v2, v4
    v.extract    s7, v5, #0
    v.splat      v2, s7
    v.movi       v4, #0
    v.cmp.ne     p2, v2, v4
    s.movz       s7, #0
    s.add        s8, s7, s10                     // the tile origin
    v.splat      v2, s8
    v.add        v4, v0, v2
    v.splat      v0, s3
    v.cmp.lt     p3, v4, v0
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v0, [s9, v1]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v0
    s.movz       s1, #1
    s.addi       s3, s21, #6208
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #1
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    s.movz       s1, #2
    s.addi       s3, s21, #6272
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #2
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    s.movz       s1, #3
    s.addi       s3, s21, #6336
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #3
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    s.movz       s1, #4
    s.addi       s3, s21, #6400
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #4
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    s.movz       s1, #5
    s.addi       s3, s21, #6464
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #5
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    s.movz       s1, #6
    s.addi       s3, s21, #6528
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #6
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    s.movz       s1, #7
    s.addi       s3, s21, #6592
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #7
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    s.movz       s1, #8
    s.addi       s3, s21, #6656
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #8
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    s.movz       s1, #9
    s.addi       s3, s21, #6720
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #9
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    s.movz       s1, #10
    s.addi       s3, s21, #6784
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #10
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    s.movz       s1, #11
    s.addi       s3, s21, #6848
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #11
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    s.movz       s1, #12
    s.addi       s3, s21, #6912
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #12
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    s.movz       s1, #13
    s.addi       s3, s21, #6976
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #13
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    s.movz       s1, #14
    s.addi       s3, s21, #7040
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #14
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    s.movz       s1, #15
    s.addi       s3, s21, #7104
    v.ld.w       v0, [s3, #0]
    s.addi       s3, s5, #15
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s9, v0]               // index is in elements (ISA sec 9.1)
    a.vwrite     a5, s1, v1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s1, #0
    s.movz       s3, #0
    a.vread      v0, a0, s3
    s.movz       s3, #0
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #1
    s.movz       s3, #1
    a.vread      v0, a0, s3
    s.movz       s3, #1
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #2
    s.movz       s3, #2
    a.vread      v0, a0, s3
    s.movz       s3, #2
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #3
    s.movz       s3, #3
    a.vread      v0, a0, s3
    s.movz       s3, #3
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #4
    s.movz       s3, #4
    a.vread      v0, a0, s3
    s.movz       s3, #4
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #5
    s.movz       s3, #5
    a.vread      v0, a0, s3
    s.movz       s3, #5
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #6
    s.movz       s3, #6
    a.vread      v0, a0, s3
    s.movz       s3, #6
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #7
    s.movz       s3, #7
    a.vread      v0, a0, s3
    s.movz       s3, #7
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #8
    s.movz       s3, #8
    a.vread      v0, a0, s3
    s.movz       s3, #8
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #9
    s.movz       s3, #9
    a.vread      v0, a0, s3
    s.movz       s3, #9
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #10
    s.movz       s3, #10
    a.vread      v0, a0, s3
    s.movz       s3, #10
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #11
    s.movz       s3, #11
    a.vread      v0, a0, s3
    s.movz       s3, #11
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #12
    s.movz       s3, #12
    a.vread      v0, a0, s3
    s.movz       s3, #12
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #13
    s.movz       s3, #13
    a.vread      v0, a0, s3
    s.movz       s3, #13
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #14
    s.movz       s3, #14
    a.vread      v0, a0, s3
    s.movz       s3, #14
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.movz       s1, #15
    s.movz       s3, #15
    a.vread      v0, a0, s3
    s.movz       s3, #15
    a.vread      v1, a5, s3
    vf.mul       v2, v0, v1
    a.vwrite     a6, s1, v2
    s.muli       s1, s10, #4                     // a runtime tile origin, x4
    s.add        s3, s15, s1                     // the tile origin
    s.muli       s1, s4, #256                    // a runtime tile origin, x256
    s.add        s7, s3, s1                      // the tile origin
    s.muli       s1, s2, #4                      // a runtime tile origin, x4
    s.add        s3, s7, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    v.splat      v0, s5
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s1, v2, #0
    v.splat      v0, s1
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s6, #0]
    s.movz       s1, #0
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    v.splat      v0, s5
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s1, v4, #0
    v.splat      v0, s1
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s3, #0], v2
    s.addi       s1, s6, #256                    // row 1
    s.addi       s7, s5, #1
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s7, v2, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #1
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #256                    // row 1
    s.addi       s7, s5, #1
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.addi       s1, s6, #512                    // row 2
    s.addi       s7, s5, #2
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s7, v2, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #2
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #512                    // row 2
    s.addi       s7, s5, #2
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.addi       s1, s6, #768                    // row 3
    s.addi       s7, s5, #3
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s7, v2, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #3
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #768                    // row 3
    s.addi       s7, s5, #3
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.addi       s1, s6, #1024                   // row 4
    s.addi       s7, s5, #4
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s7, v2, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #4
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #1024                   // row 4
    s.addi       s7, s5, #4
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.addi       s1, s6, #1280                   // row 5
    s.addi       s7, s5, #5
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s7, v2, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #5
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #1280                   // row 5
    s.addi       s7, s5, #5
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.addi       s1, s6, #1536                   // row 6
    s.addi       s7, s5, #6
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s7, v2, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #6
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #1536                   // row 6
    s.addi       s7, s5, #6
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.addi       s1, s6, #1792                   // row 7
    s.addi       s7, s5, #7
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s7, v2, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #7
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #1792                   // row 7
    s.addi       s7, s5, #7
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.addi       s1, s6, #2048                   // row 8
    s.addi       s7, s5, #8
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s7, v2, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #8
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #2048                   // row 8
    s.addi       s7, s5, #8
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.addi       s1, s6, #2304                   // row 9
    s.addi       s7, s5, #9
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s7, v2, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #9
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #2304                   // row 9
    s.addi       s7, s5, #9
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.addi       s1, s6, #2560                   // row 10
    s.addi       s7, s5, #10
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s7, v2, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #10
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #2560                   // row 10
    s.addi       s7, s5, #10
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.addi       s1, s6, #2816                   // row 11
    s.addi       s7, s5, #11
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s7, v2, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #11
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #2816                   // row 11
    s.addi       s7, s5, #11
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.addi       s1, s6, #3072                   // row 12
    s.addi       s7, s5, #12
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s7, v2, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #12
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #3072                   // row 12
    s.addi       s7, s5, #12
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.addi       s1, s6, #3328                   // row 13
    s.addi       s7, s5, #13
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s7, v2, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #13
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #3328                   // row 13
    s.addi       s7, s5, #13
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.addi       s1, s6, #3584                   // row 14
    s.addi       s7, s5, #14
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s7, v2, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #14
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #3584                   // row 14
    s.addi       s7, s5, #14
    v.splat      v0, s7
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s7, v4, #0
    v.splat      v0, s7
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.addi       s1, s6, #3840                   // row 15
    s.addi       s6, s5, #15
    v.splat      v0, s6
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v2, v0, v1
    v.extract    s6, v2, #0
    v.splat      v0, s6
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s1, #0]
    s.movz       s1, #15
    a.vread      v1, a5, s1
    vf.mul       v2, v0, v1
    s.addi       s1, s3, #3840                   // row 15
    s.addi       s3, s5, #15
    v.splat      v0, s3
    v.cmp.lt     p2, v0, v3
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v4, v0, v1
    v.extract    s3, v4, #0
    v.splat      v0, s3
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v2
    s.muli       s1, s10, #4                     // a runtime tile origin, x4
    s.add        s3, s17, s1                     // the tile origin
    s.muli       s1, s4, #256                    // a runtime tile origin, x256
    s.add        s4, s3, s1                      // the tile origin
    s.muli       s1, s2, #4                      // a runtime tile origin, x4
    s.add        s2, s4, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v0, a6, s1
    v.splat      v1, s5
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s1, v4, #0
    v.splat      v1, s1
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s2, #0], v0
    s.movz       s1, #1
    a.vread      v0, a6, s1
    s.addi       s1, s2, #256                    // row 1
    s.addi       s3, s5, #1
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #2
    a.vread      v0, a6, s1
    s.addi       s1, s2, #512                    // row 2
    s.addi       s3, s5, #2
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #3
    a.vread      v0, a6, s1
    s.addi       s1, s2, #768                    // row 3
    s.addi       s3, s5, #3
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #4
    a.vread      v0, a6, s1
    s.addi       s1, s2, #1024                   // row 4
    s.addi       s3, s5, #4
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #5
    a.vread      v0, a6, s1
    s.addi       s1, s2, #1280                   // row 5
    s.addi       s3, s5, #5
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #6
    a.vread      v0, a6, s1
    s.addi       s1, s2, #1536                   // row 6
    s.addi       s3, s5, #6
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #7
    a.vread      v0, a6, s1
    s.addi       s1, s2, #1792                   // row 7
    s.addi       s3, s5, #7
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #8
    a.vread      v0, a6, s1
    s.addi       s1, s2, #2048                   // row 8
    s.addi       s3, s5, #8
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #9
    a.vread      v0, a6, s1
    s.addi       s1, s2, #2304                   // row 9
    s.addi       s3, s5, #9
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #10
    a.vread      v0, a6, s1
    s.addi       s1, s2, #2560                   // row 10
    s.addi       s3, s5, #10
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #11
    a.vread      v0, a6, s1
    s.addi       s1, s2, #2816                   // row 11
    s.addi       s3, s5, #11
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #12
    a.vread      v0, a6, s1
    s.addi       s1, s2, #3072                   // row 12
    s.addi       s3, s5, #12
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #13
    a.vread      v0, a6, s1
    s.addi       s1, s2, #3328                   // row 13
    s.addi       s3, s5, #13
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #14
    a.vread      v0, a6, s1
    s.addi       s1, s2, #3584                   // row 14
    s.addi       s3, s5, #14
    v.splat      v1, s3
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v4, v1, v2
    v.extract    s3, v4, #0
    v.splat      v1, s3
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
    s.movz       s1, #15
    a.vread      v0, a6, s1
    s.addi       s1, s2, #3840                   // row 15
    s.addi       s2, s5, #15
    v.splat      v1, s2
    v.cmp.lt     p2, v1, v3
    v.movi       v1, #1
    v.movi       v2, #0
    @p2 v.sel        v3, v1, v2
    v.extract    s2, v3, #0
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p2, v1, v2
    p.and        p4, p2, p3
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v0
__rctx_next:
    exit
