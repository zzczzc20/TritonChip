    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #2047
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.and        v5, v4, v0
    v.movi       v0, #0
    v.sub        v4, v2, v5
    v.sub        v6, v1, v3
    @p1 v.sel        v7, v4, v5
    v.cmp.lt     p1, v3, v1
    v.sub        v4, v0, v7
    v.cmp.lt     p2, v7, v0
    @p1 v.sel        v5, v6, v3
    v.movi       v6, #11
    @p2 v.sel        v8, v4, v7
    v.movi       v4, #7
    v.lshr       v9, v5, v6
    v.lshr       v5, v8, v4
    v.sub        v4, v1, v9
    v.sub        v6, v0, v5
    @p1 v.sel        v8, v4, v9
    v.movi       v4, #128
    @p2 v.sel        v9, v6, v5
    v.movi       v5, #1664
    v.mul        v6, v8, v4
    v.mul        v8, v9, v5
    s.rdspecial  s2, arg_base
    v.movi       v5, #0
    v.add        v9, v6, v8
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.cmp.lt     p1, v7, v5
    v.movi       v6, #26624
    s.ld.d       s4, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.sub        v8, v5, v7
    v.cmp.lt     p2, v3, v6
    @p1 v.sel        v3, v8, v7
    v.movi       v6, #127
    v.movi       v7, #2048
    v.and        v8, v3, v6
    v.sub        v3, v2, v7
    v.sub        v6, v5, v8
    v.cmp.lt     p3, v7, v2
    @p1 v.sel        v2, v6, v8
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    v.add        v6, v9, v2
    v.sub        v2, v1, v7
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s3, v6]               // index is in elements (ISA sec 9.1)
    v.sub        v6, v0, v4
    v.sub        v9, v5, v4
    s.add        s1, s4, s2                      // &out_ptr0[...]
    v.cmp.lt     p1, v7, v1
    v.cmp.lt     p4, v4, v0
    @p3 v.sel        v0, v3, v7
    v.cmp.lt     p3, v4, v5
    @p1 v.sel        v0, v2, v7
    @p4 v.sel        v0, v6, v4
    vf.cvt.f32.bf16 v0, v8
    @p3 v.sel        v1, v9, v4
    @p2 v.st.h       [s1, #0], v0
__rctx_next:
    exit
