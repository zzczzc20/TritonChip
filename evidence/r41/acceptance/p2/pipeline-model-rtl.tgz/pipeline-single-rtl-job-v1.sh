#!/bin/bash
set -euo pipefail
ROOT="$HOME/r41-accept-p2-pipeline-v3";OUT="$HOME/r41-accept-p2/pipeline-single-rtl-v1"
source "$HOME/tc_env/env.sh"
export PYTHONPATH="$ROOT:$ROOT/python:$ROOT/compiler/python:$ROOT/tools/asm"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MAX_JOBS=2
export TNCA_PROFILE=core-vrf-sync-v5-x8 TNCA_BACKEND=sim-file
export TNCA_SINGLE_ROLE_PIPELINE=1 TNCA_RCTX_ROLES=0 TNCA_RCTX_SPMD=0 TNCA_SCHEDULE=0 TNCA_WINDOW_REUSE=0 TNCA_IEEE_DIV=1
unset TNCA_ACTIVE_CORES TNCA_DEVICE
export TORCH_EXTENSIONS_DIR="$HOME/r41-accept-p2/extensions"
cd "$ROOT"
"$HOME/tc_env/torchenv/bin/python" -c 'from tnca.device import prepare;prepare("core-vrf-sync-v5-x8")'
"$HOME/tc_env/torchenv/bin/python" tools/performance_harness/fragment_case.py --out "$OUT" --columns 16 --shapes 16x16x32,16x16x48 --bitwise --cancel --require-resident --require-single-role-pipeline --rtl-engine-trace > "$HOME/r41-accept-p2/pipeline-single-rtl-v1.log" 2>&1
