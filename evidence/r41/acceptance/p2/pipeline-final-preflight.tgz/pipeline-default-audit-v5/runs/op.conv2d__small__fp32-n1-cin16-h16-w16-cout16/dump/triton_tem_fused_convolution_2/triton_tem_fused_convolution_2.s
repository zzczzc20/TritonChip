    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    s.rdspecial  s3, pid.y
    s.rdspecial  s4, arg_base
    s.mul        s5, s3, s1
    s.ld.d       s3, [s4, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.splat      v1, s2
    v.movi       v2, #0
    s.rdspecial  s2, role_id
    v.add        v3, v1, v0
    s.movz       s4, #4160
    s.movz       s6, #0
    v.sub        v1, v2, v3
    s.mul        s7, s2, s4
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #16
    s.rdspecial  s2, arg_base
    v.movi       v5, #15
    s.add        s4, s3, s7                      // this context's own scratch
    v.sub        v6, v2, v1
    s.addi       s3, s4, #0
    s.addi       s7, s4, #1024
    s.addi       s8, s3, #64
    s.addi       s9, s3, #128
    s.addi       s10, s3, #192
    s.addi       s11, s3, #256
    s.addi       s12, s3, #320
    s.addi       s13, s3, #384
    s.addi       s14, s3, #448
    s.addi       s15, s3, #512
    s.addi       s16, s3, #576
    s.addi       s17, s3, #640
    s.addi       s18, s3, #704
    s.addi       s19, s3, #768
    s.addi       s20, s3, #832
    s.addi       s21, s3, #896
    s.addi       s22, s3, #960
    v.cmp.lt     p2, v1, v2
    s.ld.d       s23, [s2, #0]                   // arg_X: device_ptr64 at arg_base+0
    v.and        v7, v4, v5
    s.movz       s24, #4096
    s.movz       s24, #144
    s.movz       s24, #9
    s.movz       s25, #1
    v.movi       v4, #1
    @p2 v.sel        v4, v6, v1
    s.ld.d       s26, [s2, #8]                   // arg_W: device_ptr64 at arg_base+8
    v.sub        v4, v2, v7
    s.ld.d       s27, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    v.movi       v2, #0
    v.movi       v5, #4
    v.movi       v6, #0
    v.sub        v8, v2, v3
    v.cmp.lt     p2, v3, v2
    v.movi       v9, #4
    @p2 v.sel        v10, v8, v3
    v.movi       v3, #0
    v.movi       v8, #4096
    v.lshr       v11, v10, v5
    v.splat      v5, s5
    v.movi       v10, #15
    v.sub        v12, v2, v11
    v.add        v13, v5, v0
    v.cmp.lt     p3, v1, v2
    @p2 v.sel        v5, v12, v11
    v.splat      v11, s6
    v.sub        v12, v2, v1
    v.cmp.lt     p2, v5, v6
    @p1 v.sel        v2, v4, v7
    v.sub        v4, v6, v5
    v.cmp.lt     p1, v5, v3
    v.movi       v7, #1
    @p2 v.sel        v7, v4, v5
    @p3 v.sel        v4, v12, v1
    v.sub        v4, v3, v5
    v.lshr       v12, v7, v9
    v.sub        v7, v3, v1
    @p1 v.sel        v9, v4, v5
    v.sub        v4, v6, v12
    v.cmp.lt     p3, v1, v3
    v.and        v5, v9, v10
    @p2 v.sel        v9, v4, v12
    v.sub        v4, v6, v1
    v.sub        v10, v3, v5
    v.mul        v3, v9, v8
    v.cmp.lt     p2, v1, v6
    v.movi       v6, #1
    v.extract    s2, v3, #0
    v.extract    s28, v3, #1
    v.extract    s29, v3, #2
    v.extract    s30, v3, #3
    v.extract    s31, v3, #4
    v.splat      v6, s2
    v.extract    s2, v3, #5
    v.splat      v8, s28
    v.extract    s28, v3, #6
    v.add        v12, v11, v6
    v.add        v6, v11, v8
    @p3 v.sel        v8, v7, v1
    v.splat      v7, s29
    v.extract    s29, v3, #7
    @p1 v.sel        v8, v10, v5
    v.splat      v5, s30
    v.add        v10, v11, v7
    v.movi       v7, #1
    v.extract    s30, v3, #8
    v.add        v7, v11, v5
    @p2 v.sel        v5, v4, v1
    v.splat      v4, s31
    v.extract    s31, v3, #9
    v.st.w       [s3, #0], v12
    v.extract    s3, v3, #10
    v.splat      v5, s2
    v.extract    s2, v3, #11
    v.add        v12, v11, v4
    v.add        v4, v11, v5
    v.st.w       [s8, #0], v6
    v.extract    s8, v3, #12
    v.splat      v5, s28
    v.extract    s28, v3, #13
    v.add        v6, v11, v5
    v.st.w       [s9, #0], v10
    v.extract    s9, v3, #14
    v.splat      v5, s29
    v.extract    s29, v3, #15
    v.splat      v3, s30
    v.add        v10, v11, v5
    v.add        v5, v11, v3
    v.st.w       [s10, #0], v7
    v.movi       v3, #144
    v.mul        v7, v13, v3
    v.st.w       [s11, #0], v12
    v.splat      v3, s31
    v.add        v12, v11, v3
    v.st.w       [s12, #0], v4
    v.splat      v3, s3
    s.addi       s3, s6, #0
    v.add        v4, v11, v3
    v.st.w       [s13, #0], v6
    v.splat      v3, s2
    v.add        v6, v11, v3
    v.st.w       [s14, #0], v10
    v.splat      v3, s8
    v.add        v10, v11, v3
    v.st.w       [s15, #0], v5
    v.splat      v3, s28
    v.add        v5, v11, v3
    v.st.w       [s16, #0], v12
    v.splat      v3, s9
    v.add        v12, v11, v3
    v.st.w       [s17, #0], v4
    v.splat      v3, s29
    v.add        v4, v11, v3
    v.splat      v3, s6
    v.add        v11, v3, v7
    v.st.w       [s18, #0], v6
    v.st.w       [s19, #0], v10
    v.st.w       [s20, #0], v5
    v.st.w       [s21, #0], v12
    v.st.w       [s22, #0], v4
    fence.acq_rel.device
    v.st.w       [s7, #0], v11
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_1:
    s.cmp.ge     s2, s3, s24
    br.nz        s2, endfor_2
    s.movz       s2, #0
    s.movz       s7, #0
    s.cmp.lt     s8, s3, s2
    s.movz       s2, #0
    s.sub        s9, s7, s8
    .li       s7, #1431655766
    s.xor        s8, s3, s9
    s.movz       s10, #0
    s.sub        s11, s8, s9
    s.cmp.lt     s8, s3, s2
    s.mul        s2, s11, s7
    s.sub        s7, s10, s8
    .li       s8, #1431655766
    s.xor        s10, s3, s7
    s.movz       s12, #3
    s.sub        s13, s10, s7
    s.lshri      s10, s2, #32
    s.mul        s2, s13, s8
    s.sub        s8, s11, s10
    s.movz       s14, #0
    s.lshri      s15, s8, #1
    s.movz       s8, #0
    s.add        s16, s10, s15
    s.lshri      s10, s2, #32
    s.lshri      s2, s16, #1
    s.sub        s15, s13, s10
    s.muli       s16, s2, #3
    s.cmp.lt     s2, s12, s14
    s.lshri      s14, s15, #1
    s.sub        s15, s8, s2
    s.add        s2, s10, s14
    s.xor        s8, s7, s15
    s.lshri      s7, s2, #1
    s.sub        s2, s11, s16
    s.xor        s10, s7, s8
    s.xor        s11, s2, s9
    s.sub        s2, s10, s8
    s.sub        s8, s11, s9
    s.sub        s9, s2, s25
    s.sub        s10, s8, s25
    v.splat      v3, s9
    v.splat      v4, s10
    v.movi       v5, #256
    v.add        v6, v3, v8
    v.add        v3, v4, v2
    s.addi       s9, s4, #1088
    v.mul        v4, v6, v5
    v.mul        v5, v3, v1
    s.movz       s10, #0
    s.movz       s11, #0
    s.cmp.lt     s14, s12, s10
    s.muli       s10, s7, #3
    s.sub        s7, s11, s14
    s.xor        s11, s12, s15
    s.addi       s14, s4, #0
    s.sub        s16, s11, s15
    v.ld.w       v7, [s14, #0]
    v.extract    s11, v4, #0
    v.extract    s14, v5, #0
    v.splat      v10, s11
    v.splat      v11, s14
    v.iota       v12                             // arange(0, VLEN)
    s.xor        s11, s12, s7
    v.add        v14, v10, v11
    s.sub        s14, s13, s10
    s.addi       s10, s4, #64
    v.add        v10, v14, v12
    v.extract    s13, v4, #1
    v.extract    s14, v5, #1
    v.splat      v11, s13
    v.splat      v14, s14
    s.addi       s13, s9, #64
    s.addi       s14, s4, #128
    v.add        v15, v11, v14
    v.add        v11, v7, v10
    s.addi       s15, s9, #128
    v.add        v7, v15, v12
    v.st.w       [s9, #0], v11
    s.sub        s16, s11, s7
    v.extract    s7, v4, #2
    v.extract    s11, v5, #2
    v.splat      v10, s7
    v.splat      v11, s11
    s.addi       s7, s4, #192
    v.extract    s11, v4, #3
    v.add        v14, v10, v11
    v.splat      v10, s11
    v.extract    s11, v5, #3
    v.add        v11, v14, v12
    v.splat      v14, s11
    s.addi       s11, s9, #192
    s.movz       s16, #256
    v.add        v15, v10, v14
    v.ld.w       v10, [s10, #0]
    v.add        v14, v15, v12
    s.addi       s10, s4, #256
    v.add        v15, v10, v7
    v.st.w       [s13, #0], v15
    v.extract    s13, v4, #4
    v.splat      v7, s13
    v.extract    s13, v5, #4
    v.splat      v10, s13
    s.addi       s13, s9, #256
    v.add        v15, v7, v10
    v.add        v7, v15, v12
    v.ld.w       v10, [s14, #0]
    s.addi       s14, s4, #320
    v.add        v15, v10, v11
    v.st.w       [s15, #0], v15
    v.extract    s15, v4, #5
    v.splat      v10, s15
    v.extract    s15, v5, #5
    v.splat      v11, s15
    s.addi       s15, s9, #320
    v.add        v15, v10, v11
    v.add        v10, v15, v12
    v.ld.w       v11, [s7, #0]
    s.addi       s7, s4, #384
    v.add        v15, v11, v14
    v.st.w       [s11, #0], v15
    v.extract    s11, v4, #6
    v.splat      v11, s11
    v.extract    s11, v5, #6
    v.splat      v14, s11
    s.addi       s11, s9, #384
    v.add        v15, v11, v14
    v.add        v11, v15, v12
    v.ld.w       v14, [s10, #0]
    s.addi       s10, s4, #448
    v.add        v15, v14, v7
    v.st.w       [s13, #0], v15
    v.extract    s13, v4, #7
    v.splat      v7, s13
    v.extract    s13, v5, #7
    v.splat      v14, s13
    s.addi       s13, s9, #448
    v.add        v15, v7, v14
    v.add        v7, v15, v12
    v.ld.w       v14, [s14, #0]
    s.addi       s14, s4, #512
    v.add        v15, v14, v10
    v.st.w       [s15, #0], v15
    v.extract    s15, v4, #8
    v.splat      v10, s15
    v.extract    s15, v5, #8
    v.splat      v14, s15
    s.addi       s15, s9, #512
    v.add        v15, v10, v14
    v.add        v10, v15, v12
    v.ld.w       v14, [s7, #0]
    s.addi       s7, s4, #576
    v.add        v15, v14, v11
    v.st.w       [s11, #0], v15
    v.extract    s11, v4, #9
    v.splat      v11, s11
    v.extract    s11, v5, #9
    v.splat      v14, s11
    s.addi       s11, s9, #576
    v.add        v15, v11, v14
    v.add        v11, v15, v12
    v.ld.w       v14, [s10, #0]
    s.addi       s10, s4, #640
    v.add        v15, v14, v7
    v.st.w       [s13, #0], v15
    v.extract    s13, v4, #10
    v.splat      v7, s13
    v.extract    s13, v5, #10
    v.splat      v14, s13
    s.addi       s13, s9, #640
    v.add        v15, v7, v14
    v.add        v7, v15, v12
    v.ld.w       v14, [s14, #0]
    s.addi       s14, s4, #704
    v.add        v15, v14, v10
    v.st.w       [s15, #0], v15
    v.extract    s15, v4, #11
    v.splat      v10, s15
    v.extract    s15, v5, #11
    v.splat      v14, s15
    s.addi       s15, s9, #704
    v.add        v15, v10, v14
    v.add        v10, v15, v12
    v.ld.w       v14, [s7, #0]
    s.addi       s7, s4, #768
    v.add        v15, v14, v11
    v.st.w       [s11, #0], v15
    v.extract    s11, v4, #12
    v.splat      v11, s11
    v.extract    s11, v5, #12
    v.splat      v14, s11
    s.addi       s11, s9, #768
    v.add        v15, v11, v14
    v.add        v11, v15, v12
    v.ld.w       v14, [s10, #0]
    s.addi       s10, s4, #832
    v.add        v15, v14, v7
    v.st.w       [s13, #0], v15
    v.extract    s13, v4, #13
    v.splat      v7, s13
    v.extract    s13, v5, #13
    v.splat      v14, s13
    s.addi       s13, s9, #832
    v.add        v15, v7, v14
    v.add        v7, v15, v12
    v.ld.w       v14, [s14, #0]
    s.addi       s14, s4, #896
    v.movi       v15, #1
    v.add        v16, v14, v10
    v.cmp.lt     p1, v9, v15
    v.st.w       [s15, #0], v16
    v.extract    s15, v4, #14
    v.movi       v10, #1
    v.splat      v14, s15
    v.extract    s15, v5, #14
    v.movi       v15, #0
    v.splat      v16, s15
    s.addi       s15, s9, #896
    s.addi       s16, s9, #960
    v.add        v17, v14, v16
    @p1 v.sel        v14, v10, v15
    v.add        v10, v17, v12
    v.ld.w       v15, [s7, #0]
    s.addi       s7, s4, #960
    v.movi       v16, #0
    v.movi       v17, #1
    v.cmp.lt     p1, v6, v1
    v.cmp.ge     p2, v6, v16
    v.movi       v6, #0
    @p2 v.sel        v18, v17, v6
    v.movi       v6, #1
    v.add        v17, v15, v11
    v.movi       v11, #0
    v.st.w       [s11, #0], v17
    v.extract    s9, v4, #15
    v.movi       v4, #1
    v.splat      v15, s9
    v.extract    s9, v5, #15
    @p1 v.sel        v5, v6, v11
    v.splat      v6, s9
    v.cmp.ge     p1, v3, v16
    v.add        v11, v15, v6
    v.add        v6, v11, v12
    v.ld.w       v11, [s10, #0]
    v.movi       v15, #0
    v.movi       v16, #1
    v.cmp.lt     p2, v3, v1
    v.movi       v3, #0
    @p1 v.sel        v17, v4, v15
    v.cmp.lt     p1, v0, v1
    @p2 v.sel        v4, v16, v3
    v.add        v3, v11, v7
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s9, #0
    v.st.w       [s13, #0], v3
    s.addi       s10, s4, #1088
    v.extract    s11, v14, #0
    v.ld.w       v3, [s14, #0]
    v.extract    s13, v18, #0
    v.splat      v7, s11
    v.movi       v11, #0
    v.splat      v15, s13
    v.movi       v16, #0
    v.cmp.ne     p2, v7, v11
    v.cmp.ne     p3, v15, v16
    v.add        v7, v3, v10
    p.and        p4, p2, p3
    v.st.w       [s15, #0], v7
    v.extract    s11, v5, #0
    v.movi       v3, #0
    v.splat      v7, s11
    v.ld.w       v10, [s7, #0]
    v.extract    s7, v17, #0
    v.movi       v11, #0
    v.splat      v15, s7
    v.cmp.ne     p2, v7, v3
    p.and        p3, p4, p2
    v.cmp.ne     p2, v15, v11
    p.and        p4, p3, p2
    v.add        v3, v10, v6
    v.extract    s7, v4, #0
    v.st.w       [s16, #0], v3
    fence.acq_rel.device
    v.splat      v3, s7
    v.movi       v6, #0
    s.addi       s7, s4, #1152
    v.extract    s11, v14, #1
    v.cmp.ne     p2, v3, v6
    p.and        p3, p4, p2
    v.extract    s13, v18, #1
    p.and        p2, p3, p1
    v.splat      v3, s11
    v.movi       v6, #0
    v.splat      v7, s13
    v.movi       v10, #0
    v.extract    s11, v5, #1
    v.movi       v11, #0
    v.splat      v15, s11
    v.extract    s11, v17, #1
    v.ld.w       v16, [s10, #0]
    v.cmp.ne     p3, v3, v6
    v.cmp.ne     p4, v7, v10
    p.and        p5, p3, p4
    v.splat      v3, s11
    v.movi       v6, #0
    v.extract    s10, v4, #1
    v.cmp.ne     p3, v15, v11
    p.and        p4, p5, p3
    v.splat      v7, s10
    v.movi       v10, #0
    v.cmp.ne     p3, v3, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v7, v10
    p.and        p4, p5, p3
    s.movz       s10, #1
    p.and        p3, p4, p1
    s.addi       s11, s4, #1216
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v3, [s23, v16]             // index is in elements (ISA sec 9.1)
    v.extract    s13, v14, #2
    v.extract    s14, v18, #2
    v.splat      v6, s13
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0
    v.extract    s13, v5, #2
    v.movi       v15, #0
    v.splat      v16, s13
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v11
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v15
    p.and        p4, p5, p2
    s.movz       s13, #2
    a.vwrite     a1, s9, v3
    v.ld.w       v3, [s7, #0]
    v.extract    s7, v17, #2
    v.movi       v6, #0
    v.splat      v7, s7
    v.extract    s7, v4, #2
    v.movi       v10, #0
    v.splat      v11, s7
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s7, s4, #1280
    p.and        p2, p4, p1
    v.extract    s9, v14, #3
    v.extract    s14, v18, #3
    v.splat      v6, s9
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s9, v5, #3
    v.movi       v15, #0
    v.splat      v16, s9
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v15
    p.and        p4, p5, p3
    s.movz       s9, #3
    a.vwrite     a1, s10, v11
    v.ld.w       v3, [s11, #0]
    v.extract    s10, v17, #3
    v.movi       v6, #0
    v.splat      v7, s10
    v.extract    s10, v4, #3
    v.movi       v10, #0
    v.splat      v11, s10
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s10, s4, #1344
    p.and        p3, p4, p1
    v.extract    s11, v14, #4
    v.extract    s14, v18, #4
    v.splat      v6, s11
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s11, v5, #4
    v.movi       v15, #0
    v.splat      v16, s11
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v15
    p.and        p4, p5, p2
    s.movz       s11, #4
    a.vwrite     a1, s13, v11
    v.ld.w       v3, [s7, #0]
    v.extract    s7, v17, #4
    v.movi       v6, #0
    v.splat      v7, s7
    v.extract    s7, v4, #4
    v.movi       v10, #0
    v.splat      v11, s7
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s7, s4, #1408
    p.and        p2, p4, p1
    v.extract    s13, v14, #5
    v.extract    s14, v18, #5
    v.splat      v6, s13
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s13, v5, #5
    v.movi       v15, #0
    v.splat      v16, s13
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v15
    p.and        p4, p5, p3
    s.movz       s13, #5
    a.vwrite     a1, s9, v11
    v.ld.w       v3, [s10, #0]
    v.extract    s9, v17, #5
    v.movi       v6, #0
    v.splat      v7, s9
    v.extract    s9, v4, #5
    v.movi       v10, #0
    v.splat      v11, s9
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s9, s4, #1472
    p.and        p3, p4, p1
    v.extract    s10, v14, #6
    v.extract    s14, v18, #6
    v.splat      v6, s10
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s10, v5, #6
    v.movi       v15, #0
    v.splat      v16, s10
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v15
    p.and        p4, p5, p2
    s.movz       s10, #6
    a.vwrite     a1, s11, v11
    v.ld.w       v3, [s7, #0]
    v.extract    s7, v17, #6
    v.movi       v6, #0
    v.splat      v7, s7
    v.extract    s7, v4, #6
    v.movi       v10, #0
    v.splat      v11, s7
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s7, s4, #1536
    p.and        p2, p4, p1
    v.extract    s11, v14, #7
    v.extract    s14, v18, #7
    v.splat      v6, s11
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s11, v5, #7
    v.movi       v15, #0
    v.splat      v16, s11
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v15
    p.and        p4, p5, p3
    s.movz       s11, #7
    a.vwrite     a1, s13, v11
    v.ld.w       v3, [s9, #0]
    v.extract    s9, v17, #7
    v.movi       v6, #0
    v.splat      v7, s9
    v.extract    s9, v4, #7
    v.movi       v10, #0
    v.splat      v11, s9
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s9, s4, #1600
    p.and        p3, p4, p1
    v.extract    s13, v14, #8
    v.extract    s14, v18, #8
    v.splat      v6, s13
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s13, v5, #8
    v.movi       v15, #0
    v.splat      v16, s13
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v15
    p.and        p4, p5, p2
    s.movz       s13, #8
    a.vwrite     a1, s10, v11
    v.ld.w       v3, [s7, #0]
    v.extract    s7, v17, #8
    v.movi       v6, #0
    v.splat      v7, s7
    v.extract    s7, v4, #8
    v.movi       v10, #0
    v.splat      v11, s7
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s7, s4, #1664
    p.and        p2, p4, p1
    v.extract    s10, v14, #9
    v.extract    s14, v18, #9
    v.splat      v6, s10
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s10, v5, #9
    v.movi       v15, #0
    v.splat      v16, s10
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v15
    p.and        p4, p5, p3
    s.movz       s10, #9
    a.vwrite     a1, s11, v11
    v.ld.w       v3, [s9, #0]
    v.extract    s9, v17, #9
    v.movi       v6, #0
    v.splat      v7, s9
    v.extract    s9, v4, #9
    v.movi       v10, #0
    v.splat      v11, s9
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s9, s4, #1728
    p.and        p3, p4, p1
    v.extract    s11, v14, #10
    v.extract    s14, v18, #10
    v.splat      v6, s11
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s11, v5, #10
    v.movi       v15, #0
    v.splat      v16, s11
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v15
    p.and        p4, p5, p2
    s.movz       s11, #10
    a.vwrite     a1, s13, v11
    v.ld.w       v3, [s7, #0]
    v.extract    s7, v17, #10
    v.movi       v6, #0
    v.splat      v7, s7
    v.extract    s7, v4, #10
    v.movi       v10, #0
    v.splat      v11, s7
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s7, s4, #1792
    p.and        p2, p4, p1
    v.extract    s13, v14, #11
    v.extract    s14, v18, #11
    v.splat      v6, s13
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s13, v5, #11
    v.movi       v15, #0
    v.splat      v16, s13
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v15
    p.and        p4, p5, p3
    s.movz       s13, #11
    a.vwrite     a1, s10, v11
    v.ld.w       v3, [s9, #0]
    v.extract    s9, v17, #11
    v.movi       v6, #0
    v.splat      v7, s9
    v.extract    s9, v4, #11
    v.movi       v10, #0
    v.splat      v11, s9
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s9, s4, #1856
    p.and        p3, p4, p1
    v.extract    s10, v14, #12
    v.extract    s14, v18, #12
    v.splat      v6, s10
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s10, v5, #12
    v.movi       v15, #0
    v.splat      v16, s10
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v15
    p.and        p4, p5, p2
    s.movz       s10, #12
    a.vwrite     a1, s11, v11
    v.ld.w       v3, [s7, #0]
    v.extract    s7, v17, #12
    v.movi       v6, #0
    v.splat      v7, s7
    v.extract    s7, v4, #12
    v.movi       v10, #0
    v.splat      v11, s7
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s7, s4, #1920
    p.and        p2, p4, p1
    v.extract    s11, v14, #13
    v.extract    s14, v18, #13
    v.splat      v6, s11
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s11, v5, #13
    v.movi       v15, #0
    v.splat      v16, s11
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v16, v15
    p.and        p4, p5, p3
    s.movz       s11, #13
    a.vwrite     a1, s13, v11
    v.ld.w       v3, [s9, #0]
    v.extract    s9, v17, #13
    v.movi       v6, #0
    v.splat      v7, s9
    v.extract    s9, v4, #13
    v.movi       v10, #0
    v.splat      v11, s9
    v.cmp.ne     p3, v7, v6
    p.and        p5, p4, p3
    v.cmp.ne     p3, v11, v10
    p.and        p4, p5, p3
    s.addi       s9, s4, #1984
    p.and        p3, p4, p1
    v.extract    s13, v14, #14
    v.extract    s14, v18, #14
    v.splat      v6, s13
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s13, v5, #14
    v.movi       v15, #0
    v.splat      v16, s13
    v.cmp.ne     p2, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p2, p4
    v.cmp.ne     p2, v16, v15
    p.and        p4, p5, p2
    s.movz       s13, #14
    a.vwrite     a1, s10, v11
    v.ld.w       v3, [s7, #0]
    v.extract    s7, v17, #14
    v.movi       v6, #0
    v.splat      v7, s7
    v.extract    s7, v4, #14
    v.movi       v10, #0
    v.splat      v11, s7
    v.cmp.ne     p2, v7, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v11, v10
    p.and        p4, p5, p2
    s.addi       s7, s4, #2048
    p.and        p2, p4, p1
    v.extract    s10, v14, #15
    v.extract    s14, v18, #15
    v.splat      v6, s10
    v.movi       v7, #0
    v.splat      v10, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.w v11, [s23, v3]             // index is in elements (ISA sec 9.1)
    v.movi       v3, #0
    v.extract    s10, v5, #15
    v.movi       v5, #0
    v.splat      v14, s10
    v.cmp.ne     p3, v6, v7
    v.cmp.ne     p4, v10, v3
    p.and        p5, p3, p4
    v.cmp.ne     p3, v14, v5
    p.and        p4, p5, p3
    s.movz       s10, #15
    a.vwrite     a1, s11, v11
    v.ld.w       v3, [s9, #0]
    v.extract    s9, v17, #15
    v.movi       v5, #0
    v.splat      v6, s9
    v.extract    s9, v4, #15
    v.movi       v4, #0
    v.splat      v7, s9
    v.cmp.ne     p3, v6, v5
    p.and        p5, p4, p3
    v.cmp.ne     p3, v7, v4
    p.and        p4, p5, p3
    s.addi       s9, s4, #1024
    p.and        p3, p4, p1
    s.movz       s11, #48
    s.mul        s14, s8, s1
    s.mul        s8, s2, s11
    s.movz       s2, #0
    s.addi       s11, s4, #2112
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s23, v3]              // index is in elements (ISA sec 9.1)
    s.addi       s15, s4, #1024
    s.add        s16, s2, s8                     // the tile origin
    s.addi       s2, s11, #64
    s.add        s8, s16, s14                    // the tile origin
    v.splat      v3, s8
    s.addi       s14, s8, #1
    v.splat      v5, s14
    a.vwrite     a1, s13, v4
    v.ld.w       v4, [s7, #0]
    s.addi       s7, s4, #1024
    s.addi       s13, s8, #2
    s.addi       s14, s11, #128
    v.splat      v6, s13
    s.addi       s13, s4, #1024
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v7, [s23, v4]              // index is in elements (ISA sec 9.1)
    s.addi       s16, s8, #3
    v.splat      v4, s16
    s.addi       s16, s11, #192
    a.vwrite     a1, s10, v7
    v.ld.w       v7, [s9, #0]
    s.addi       s9, s4, #1024
    s.addi       s10, s8, #4
    v.splat      v10, s10
    s.addi       s10, s11, #256
    v.add        v11, v7, v3
    v.st.w       [s11, #0], v11
    v.ld.w       v3, [s15, #0]
    s.addi       s15, s4, #1024
    v.add        v7, v3, v5
    v.st.w       [s2, #0], v7
    s.addi       s2, s8, #5
    v.splat      v3, s2
    s.addi       s2, s11, #320
    v.ld.w       v5, [s7, #0]
    s.addi       s7, s4, #1024
    v.add        v7, v5, v6
    v.st.w       [s14, #0], v7
    s.addi       s14, s8, #6
    v.splat      v5, s14
    s.addi       s14, s11, #384
    v.ld.w       v6, [s13, #0]
    s.addi       s13, s4, #1024
    v.add        v7, v6, v4
    v.st.w       [s16, #0], v7
    s.addi       s16, s8, #7
    v.splat      v4, s16
    s.addi       s16, s11, #448
    v.ld.w       v6, [s9, #0]
    s.addi       s9, s4, #1024
    v.add        v7, v6, v10
    v.st.w       [s10, #0], v7
    s.addi       s10, s8, #8
    v.splat      v6, s10
    s.addi       s10, s11, #512
    v.ld.w       v7, [s15, #0]
    s.addi       s15, s4, #1024
    v.add        v10, v7, v3
    v.st.w       [s2, #0], v10
    s.addi       s2, s8, #9
    v.splat      v3, s2
    s.addi       s2, s11, #576
    v.ld.w       v7, [s7, #0]
    s.addi       s7, s4, #1024
    v.add        v10, v7, v5
    v.st.w       [s14, #0], v10
    s.addi       s14, s8, #10
    v.splat      v5, s14
    s.addi       s14, s11, #640
    v.ld.w       v7, [s13, #0]
    s.addi       s13, s4, #1024
    v.add        v10, v7, v4
    v.st.w       [s16, #0], v10
    s.addi       s16, s8, #11
    v.splat      v4, s16
    s.addi       s16, s11, #704
    v.ld.w       v7, [s9, #0]
    s.addi       s9, s4, #1024
    v.add        v10, v7, v6
    v.st.w       [s10, #0], v10
    s.addi       s10, s8, #12
    v.splat      v6, s10
    s.addi       s10, s11, #768
    v.ld.w       v7, [s15, #0]
    s.addi       s15, s4, #1024
    v.add        v10, v7, v3
    v.splat      v3, s6
    v.st.w       [s2, #0], v10
    s.addi       s2, s8, #13
    v.splat      v7, s1
    v.splat      v10, s2
    s.addi       s2, s11, #832
    v.cmp.lt     p1, v3, v7
    v.ld.w       v3, [s7, #0]
    s.addi       s7, s4, #1024
    v.add        v11, v3, v5
    v.splat      v3, s1
    v.st.w       [s14, #0], v11
    s.addi       s14, s8, #14
    s.addi       s17, s8, #15
    v.splat      v5, s14
    s.addi       s8, s11, #896
    v.splat      v11, s17
    s.addi       s14, s4, #1024
    s.addi       s17, s11, #960
    v.ld.w       v14, [s13, #0]
    s.addi       s11, s4, #2112
    v.add        v15, v14, v4
    v.st.w       [s16, #0], v15
    s.movz       s13, #0
    v.splat      v4, s25
    s.add        s16, s13, s5                    // the tile origin
    v.splat      v14, s16
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s13, #0
    v.cmp.lt     p2, v4, v7
    v.add        v4, v12, v14
    v.cmp.lt     p3, v4, v3
    p.and        p4, p1, p3
    p.and        p1, p2, p3
    v.ld.w       v3, [s9, #0]
    s.addi       s9, s4, #2176
    v.add        v4, v3, v6
    v.st.w       [s10, #0], v4
    s.movz       s10, #1
    v.ld.w       v3, [s15, #0]
    s.addi       s15, s4, #2240
    v.add        v4, v3, v10
    v.st.w       [s2, #0], v4
    s.movz       s2, #2
    v.splat      v3, s2
    s.movz       s2, #2
    v.cmp.lt     p2, v3, v7
    p.and        p5, p2, p3
    v.ld.w       v3, [s7, #0]
    s.addi       s7, s4, #2304
    v.splat      v4, s12
    s.movz       s12, #3
    v.add        v6, v3, v5
    v.st.w       [s8, #0], v6
    s.addi       s8, s4, #2368
    v.ld.w       v3, [s14, #0]
    s.movz       s14, #4
    v.splat      v5, s14
    s.movz       s14, #4
    v.add        v6, v3, v11
    v.st.w       [s17, #0], v6
    fence.acq_rel.device
    s.movz       s16, #5
    v.ld.w       v3, [s11, #0]
    s.addi       s11, s4, #2432
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v6, [s26, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v7
    p.and        p4, p2, p3
    a.vwrite     a2, s13, v6
    v.ld.w       v3, [s9, #0]
    s.movz       s9, #5
    s.addi       s13, s4, #2496
    v.splat      v4, s9
    s.movz       s9, #6
    v.splat      v6, s9
    s.movz       s9, #6
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v7
    p.and        p2, p1, p3
    a.vwrite     a2, s10, v10
    v.ld.w       v3, [s15, #0]
    s.addi       s10, s4, #2560
    s.movz       s15, #7
    v.splat      v5, s15
    s.movz       s15, #7
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v7
    p.and        p5, p1, p3
    a.vwrite     a2, s2, v10
    v.ld.w       v3, [s7, #0]
    s.addi       s2, s4, #2624
    s.movz       s7, #8
    v.splat      v4, s7
    s.movz       s7, #8
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v7
    p.and        p4, p1, p3
    a.vwrite     a2, s12, v10
    v.ld.w       v3, [s8, #0]
    s.addi       s8, s4, #2688
    v.splat      v6, s24
    s.movz       s12, #9
    s.addi       s17, s4, #2752
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v7
    p.and        p2, p1, p3
    a.vwrite     a2, s14, v10
    v.ld.w       v3, [s11, #0]
    s.movz       s11, #10
    s.movz       s14, #10
    v.splat      v5, s11
    s.addi       s11, s4, #2816
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v7
    p.and        p5, p1, p3
    a.vwrite     a2, s16, v10
    v.ld.w       v3, [s13, #0]
    s.movz       s13, #11
    s.movz       s16, #11
    v.splat      v4, s13
    s.addi       s13, s4, #2880
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v7
    p.and        p4, p1, p3
    a.vwrite     a2, s9, v10
    v.ld.w       v3, [s10, #0]
    s.movz       s9, #12
    s.movz       s10, #12
    v.splat      v6, s9
    s.addi       s9, s4, #2944
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v7
    p.and        p2, p1, p3
    a.vwrite     a2, s15, v10
    v.ld.w       v3, [s2, #0]
    s.movz       s2, #13
    s.movz       s15, #13
    v.splat      v5, s2
    s.addi       s2, s4, #3008
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v7
    p.and        p5, p1, p3
    a.vwrite     a2, s7, v10
    v.ld.w       v3, [s8, #0]
    s.movz       s7, #14
    s.movz       s8, #14
    v.splat      v4, s7
    s.movz       s7, #15
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.w v10, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v7
    p.and        p4, p1, p3
    a.vwrite     a2, s12, v10
    v.ld.w       v3, [s17, #0]
    s.addi       s12, s4, #3072
    s.movz       s17, #15
    v.movi       v6, #0
    v.splat      v10, s17
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s26, v3]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v7
    p.and        p2, p1, p3
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s17, #0
    a.vwrite     a2, s14, v11
    v.ld.w       v3, [s11, #0]
    s.movz       s11, #0
    s.movz       s14, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v5, [s26, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v7
    p.and        p5, p1, p3
    a.vwrite     a2, s16, v5
    v.ld.w       v3, [s13, #0]
    s.movz       s13, #1
    s.movz       s16, #2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s26, v3]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v10, v7
    p.and        p4, p1, p3
    a.vwrite     a2, s10, v4
    v.ld.w       v3, [s9, #0]
    s.movz       s9, #3
    s.movz       s10, #4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v4, [s26, v3]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v4
    v.ld.w       v3, [s2, #0]
    s.movz       s2, #5
    s.movz       s15, #6
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s26, v3]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s8, v4
    v.ld.w       v3, [s12, #0]
    s.movz       s8, #7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s26, v3]              // index is in elements (ISA sec 9.1)
    s.movz       s12, #8
    a.vwrite     a2, s7, v4
    a.vread      v3, a1, s11
    a.vread      v4, a2, s14
    a.vread      v5, a2, s13
    v.extract    s7, v3, #0
    v.extract    s11, v3, #1
    v.splat      v7, s7
    v.splat      v10, s11
    v.extract    s7, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s7
    a.vread      v7, a2, s16
    v.extract    s7, v3, #3
    a.vread      v12, a2, s9
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s7
    v.extract    s7, v3, #4
    a.vread      v10, a2, s10
    v.splat      v11, s7
    vf.fma       v15, v4, v7, v14
    v.extract    s7, v3, #5
    a.vread      v4, a2, s2
    v.splat      v7, s7
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s15
    v.extract    s2, v3, #7
    a.vread      v15, a2, s8
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s12
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #1
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #1
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v7, a2, s9
    v.extract    s2, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v15, v4, v7, v14
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s2
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s13
    v.extract    s2, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #2
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s17, #2
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v7, a2, s9
    v.extract    s2, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v15, v4, v7, v14
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s2
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s13
    v.extract    s2, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #3
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #3
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v7, a2, s9
    v.extract    s2, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v15, v4, v7, v14
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s2
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s13
    v.extract    s2, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #4
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s17, #4
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v7, a2, s9
    v.extract    s2, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v15, v4, v7, v14
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s2
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s13
    v.extract    s2, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #5
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #5
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v7, a2, s9
    v.extract    s2, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v15, v4, v7, v14
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s2
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s13
    v.extract    s2, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #6
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s17, #6
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v7, a2, s9
    v.extract    s2, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v15, v4, v7, v14
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s2
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s13
    v.extract    s2, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #7
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #7
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v7, a2, s9
    v.extract    s2, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v15, v4, v7, v14
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s2
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s13
    v.extract    s2, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #8
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s17, #8
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v7, a2, s9
    v.extract    s2, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v15, v4, v7, v14
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s2
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s13
    v.extract    s2, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #9
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #9
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v7, a2, s9
    v.extract    s2, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v15, v4, v7, v14
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s2
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s13
    v.extract    s2, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #10
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s17, #10
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v7, a2, s9
    v.extract    s2, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v15, v4, v7, v14
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s2
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s13
    v.extract    s2, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #11
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #11
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v7, a2, s9
    v.extract    s2, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v15, v4, v7, v14
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s2
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s13
    v.extract    s2, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #12
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s17, #12
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v7, a2, s9
    v.extract    s2, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v15, v4, v7, v14
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s2
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s13
    v.extract    s2, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #13
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #13
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v7, a2, s9
    v.extract    s2, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v15, v4, v7, v14
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s2
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s13
    v.extract    s2, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #14
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s17, #14
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v7, a2, s9
    v.extract    s2, v3, #3
    a.vread      v12, a2, s10
    vf.fma       v14, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v15, v4, v7, v14
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v7, s2
    v.extract    s2, v3, #6
    vf.fma       v14, v5, v12, v15
    v.splat      v5, s2
    a.vread      v12, a2, s13
    v.extract    s2, v3, #7
    a.vread      v15, a2, s14
    vf.fma       v16, v11, v10, v14
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v14, s2
    vf.fma       v17, v7, v4, v16
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v15, a2, s7
    vf.fma       v16, v14, v11, v17
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v14, a2, s7
    vf.fma       v17, v4, v7, v16
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v5, v12, v17
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v12, a2, s7
    vf.fma       v17, v10, v15, v16
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v15, v11, v14, v17
    s.movz       s2, #15
    s.movz       s7, #0
    s.movz       s8, #1
    s.movz       s9, #2
    vf.fma       v11, v4, v7, v15
    s.movz       s10, #3
    s.movz       s11, #4
    s.movz       s12, #5
    s.movz       s13, #6
    vf.fma       v4, v5, v12, v11
    s.movz       s14, #7
    s.movz       s15, #8
    s.movz       s16, #15
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s17, v5
    a.vread      v3, a1, s2
    a.vread      v4, a2, s7
    a.vread      v5, a2, s8
    v.extract    s2, v3, #0
    v.extract    s7, v3, #1
    v.splat      v7, s2
    v.splat      v10, s7
    v.extract    s2, v3, #2
    vf.fma       v11, v7, v4, v6
    v.splat      v4, s2
    a.vread      v6, a2, s9
    v.extract    s2, v3, #3
    a.vread      v7, a2, s10
    vf.fma       v12, v10, v5, v11
    v.splat      v5, s2
    v.extract    s2, v3, #4
    a.vread      v10, a2, s11
    v.splat      v11, s2
    vf.fma       v14, v4, v6, v12
    v.extract    s2, v3, #5
    a.vread      v4, a2, s12
    v.splat      v6, s2
    v.extract    s2, v3, #6
    vf.fma       v12, v5, v7, v14
    v.splat      v5, s2
    a.vread      v7, a2, s13
    v.extract    s2, v3, #7
    a.vread      v14, a2, s14
    vf.fma       v15, v11, v10, v12
    v.splat      v10, s2
    v.extract    s2, v3, #8
    a.vread      v11, a2, s15
    v.splat      v12, s2
    vf.fma       v16, v6, v4, v15
    v.extract    s2, v3, #9
    s.movz       s7, #9
    v.splat      v4, s2
    a.vread      v6, a2, s7
    vf.fma       v15, v5, v7, v16
    v.extract    s2, v3, #10
    s.movz       s7, #10
    v.splat      v5, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v10, v14, v15
    v.extract    s2, v3, #11
    s.movz       s7, #11
    v.splat      v10, s2
    a.vread      v14, a2, s7
    vf.fma       v15, v12, v11, v16
    v.extract    s2, v3, #12
    s.movz       s7, #12
    v.splat      v11, s2
    a.vread      v12, a2, s7
    vf.fma       v16, v4, v6, v15
    v.extract    s2, v3, #13
    s.movz       s7, #13
    v.splat      v4, s2
    a.vread      v6, a2, s7
    vf.fma       v15, v5, v7, v16
    v.extract    s2, v3, #14
    s.movz       s7, #14
    v.splat      v5, s2
    a.vread      v7, a2, s7
    vf.fma       v16, v10, v14, v15
    v.extract    s2, v3, #15
    s.movz       s7, #15
    v.splat      v3, s2
    a.vread      v10, a2, s7
    vf.fma       v14, v11, v12, v16
    s.movz       s2, #0
    s.movz       s7, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s8, #0
    s.movz       s9, #1
    vf.fma       v11, v4, v6, v14
    s.movz       s10, #1
    s.movz       s11, #1
    s.movz       s12, #2
    s.movz       s13, #2
    vf.fma       v4, v5, v7, v11
    s.movz       s14, #2
    s.movz       s15, #3
    s.movz       s17, #3
    s.movz       s18, #3
    vf.fma       v5, v3, v10, v4
    a.vwrite     a3, s16, v5
    a.vread      v3, a0, s2
    a.vread      v4, a3, s7
    s.movz       s2, #4
    s.movz       s7, #4
    vf.add       v5, v3, v4
    s.movz       s16, #4
    a.vwrite     a4, s8, v5
    a.vread      v3, a0, s9
    a.vread      v4, a3, s10
    s.movz       s8, #5
    s.movz       s9, #5
    vf.add       v5, v3, v4
    s.movz       s10, #5
    a.vwrite     a4, s11, v5
    a.vread      v3, a0, s12
    a.vread      v4, a3, s13
    s.movz       s11, #6
    s.movz       s12, #6
    vf.add       v5, v3, v4
    s.movz       s13, #6
    a.vwrite     a4, s14, v5
    a.vread      v3, a0, s15
    a.vread      v4, a3, s17
    s.movz       s14, #7
    s.movz       s15, #7
    vf.add       v5, v3, v4
    s.movz       s17, #7
    a.vwrite     a4, s18, v5
    a.vread      v3, a0, s2
    a.vread      v4, a3, s7
    s.movz       s2, #8
    s.movz       s7, #8
    vf.add       v5, v3, v4
    s.movz       s18, #8
    a.vwrite     a4, s16, v5
    a.vread      v3, a0, s8
    a.vread      v4, a3, s9
    s.movz       s8, #9
    s.movz       s9, #9
    vf.add       v5, v3, v4
    s.movz       s16, #9
    a.vwrite     a4, s10, v5
    a.vread      v3, a0, s11
    a.vread      v4, a3, s12
    s.movz       s10, #10
    s.movz       s11, #10
    vf.add       v5, v3, v4
    s.movz       s12, #10
    a.vwrite     a4, s13, v5
    a.vread      v3, a0, s14
    a.vread      v4, a3, s15
    s.movz       s13, #11
    s.movz       s14, #11
    vf.add       v5, v3, v4
    s.movz       s15, #11
    a.vwrite     a4, s17, v5
    a.vread      v3, a0, s2
    a.vread      v4, a3, s7
    s.movz       s2, #12
    s.movz       s7, #12
    vf.add       v5, v3, v4
    s.movz       s17, #12
    a.vwrite     a4, s18, v5
    a.vread      v3, a0, s8
    a.vread      v4, a3, s9
    s.movz       s8, #13
    s.movz       s9, #13
    vf.add       v5, v3, v4
    s.movz       s18, #13
    a.vwrite     a4, s16, v5
    a.vread      v3, a0, s10
    a.vread      v4, a3, s11
    s.movz       s10, #14
    s.movz       s11, #14
    vf.add       v5, v3, v4
    s.movz       s16, #14
    a.vwrite     a4, s12, v5
    a.vread      v3, a0, s13
    a.vread      v4, a3, s14
    s.movz       s12, #15
    s.movz       s13, #15
    vf.add       v5, v3, v4
    s.movz       s14, #15
    a.vwrite     a4, s15, v5
    a.vread      v3, a0, s2
    a.vread      v4, a3, s7
    s.movz       s2, #0
    s.movz       s7, #0
    vf.add       v5, v3, v4
    s.movz       s15, #1
    a.vwrite     a4, s17, v5
    a.vread      v3, a0, s8
    a.vread      v4, a3, s9
    s.movz       s8, #1
    s.movz       s9, #2
    vf.add       v5, v3, v4
    s.movz       s17, #2
    a.vwrite     a4, s18, v5
    a.vread      v3, a0, s10
    a.vread      v4, a3, s11
    s.movz       s10, #3
    s.movz       s11, #3
    vf.add       v5, v3, v4
    s.movz       s18, #4
    a.vwrite     a4, s16, v5
    a.vread      v3, a0, s12
    a.vread      v4, a3, s13
    s.movz       s12, #4
    s.movz       s13, #5
    vf.add       v5, v3, v4
    s.movz       s16, #5
    a.vwrite     a4, s14, v5
    a.vread      v3, a4, s2
    s.movz       s2, #6
    s.movz       s14, #6
    a.vwrite     a0, s7, v3
    a.vread      v3, a4, s15
    s.movz       s7, #7
    s.movz       s15, #7
    a.vwrite     a0, s8, v3
    a.vread      v3, a4, s9
    s.movz       s8, #8
    s.movz       s9, #8
    a.vwrite     a0, s17, v3
    a.vread      v3, a4, s10
    s.movz       s10, #9
    s.movz       s17, #9
    a.vwrite     a0, s11, v3
    a.vread      v3, a4, s18
    s.movz       s11, #10
    s.movz       s18, #10
    a.vwrite     a0, s12, v3
    a.vread      v3, a4, s13
    s.movz       s12, #11
    s.movz       s13, #11
    a.vwrite     a0, s16, v3
    a.vread      v3, a4, s2
    s.movz       s2, #12
    s.movz       s16, #12
    a.vwrite     a0, s14, v3
    a.vread      v3, a4, s7
    s.movz       s7, #13
    s.movz       s14, #13
    a.vwrite     a0, s15, v3
    a.vread      v3, a4, s8
    s.movz       s8, #14
    s.movz       s15, #14
    a.vwrite     a0, s9, v3
    a.vread      v3, a4, s10
    s.movz       s9, #15
    s.movz       s10, #15
    a.vwrite     a0, s17, v3
    a.vread      v3, a4, s11
    s.add        s11, s3, s25
    s.movz       s17, #1
    a.vwrite     a0, s18, v3
    a.vread      v3, a4, s12
    a.vwrite     a0, s13, v3
    a.vread      v3, a4, s2
    a.vwrite     a0, s16, v3
    a.vread      v3, a4, s7
    a.vwrite     a0, s14, v3
    a.vread      v3, a4, s8
    a.vwrite     a0, s15, v3
    a.vread      v3, a4, s9
    a.vwrite     a0, s10, v3
    s.mov        s3, s11
    br.nz        s17, for_1
endfor_2:
    s.muli       s2, s5, #256                    // a runtime tile origin, x256
    v.extract    s3, v8, #0
    s.movz       s5, #256
    v.extract    s7, v8, #1
    s.movz       s8, #0
    v.splat      v0, s3
    v.splat      v3, s1
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s5
    v.splat      v6, s7
    v.extract    s1, v2, #0
    s.add        s3, s8, s2                      // the tile origin
    v.extract    s2, v2, #1
    v.extract    s5, v2, #2
    v.splat      v7, s1
    v.mul        v10, v0, v3
    v.mul        v0, v4, v5
    v.splat      v4, s3
    v.splat      v5, s2
    v.mul        v11, v6, v3
    v.splat      v6, s5
    v.add        v12, v7, v10
    v.add        v7, v0, v4
    v.add        v0, v5, v11
    v.splat      v4, s6
    v.add        v5, v12, v7
    v.add        v10, v0, v7
    s.addi       s1, s4, #3136
    v.add        v0, v4, v5
    v.add        v5, v4, v10
    s.addi       s2, s1, #64
    s.addi       s3, s1, #128
    v.movi       v10, #1
    v.extract    s5, v8, #2
    v.movi       v11, #1
    v.movi       v12, #0
    v.st.w       [s1, #0], v0
    v.movi       v0, #1
    v.cmp.lt     p1, v9, v10
    v.splat      v9, s5
    v.movi       v10, #0
    v.cmp.lt     p2, v8, v1
    v.mul        v14, v9, v3
    @p1 v.sel        v9, v11, v12
    s.addi       s5, s1, #192
    v.add        v11, v6, v14
    v.movi       v6, #1
    v.movi       v12, #0
    v.add        v14, v11, v7
    @p2 v.sel        v11, v0, v10
    v.extract    s6, v2, #3
    v.add        v0, v4, v14
    v.cmp.lt     p1, v2, v1
    v.extract    s7, v8, #3
    v.splat      v10, s6
    v.st.w       [s2, #0], v5
    v.splat      v5, s7
    @p1 v.sel        v14, v6, v12
    v.cmp.lt     p1, v13, v1
    v.extract    s2, v8, #4
    v.extract    s6, v8, #5
    v.extract    s7, v8, #6
    v.extract    s8, v8, #7
    v.splat      v1, s2
    v.splat      v6, s6
    v.splat      v12, s7
    v.extract    s2, v2, #4
    v.extract    s6, v2, #5
    v.extract    s7, v2, #6
    v.extract    s9, v2, #7
    v.mul        v13, v5, v3
    v.mul        v5, v1, v3
    v.mul        v1, v6, v3
    v.mul        v6, v12, v3
    v.add        v12, v10, v13
    v.splat      v10, s8
    s.addi       s8, s1, #256
    v.add        v13, v12, v7
    v.mul        v12, v10, v3
    v.st.w       [s3, #0], v0
    v.extract    s3, v8, #8
    v.splat      v0, s2
    v.extract    s2, v2, #8
    v.add        v10, v4, v13
    v.add        v13, v0, v5
    v.splat      v0, s3
    s.addi       s3, s1, #320
    v.add        v5, v13, v7
    v.mul        v13, v0, v3
    v.add        v0, v4, v5
    v.st.w       [s5, #0], v10
    v.extract    s5, v8, #9
    v.splat      v5, s6
    v.extract    s6, v2, #9
    v.add        v10, v5, v1
    v.splat      v1, s5
    s.addi       s5, s1, #384
    v.add        v5, v10, v7
    v.mul        v10, v1, v3
    v.add        v1, v4, v5
    v.st.w       [s8, #0], v0
    v.extract    s8, v8, #10
    v.splat      v0, s7
    v.extract    s7, v2, #10
    v.add        v5, v0, v6
    v.splat      v0, s8
    s.addi       s8, s1, #448
    v.add        v6, v5, v7
    v.mul        v5, v0, v3
    v.add        v0, v4, v6
    v.st.w       [s3, #0], v1
    v.extract    s3, v8, #11
    v.splat      v1, s9
    v.extract    s9, v2, #11
    v.add        v6, v1, v12
    v.splat      v1, s3
    s.addi       s3, s1, #512
    v.add        v12, v6, v7
    v.mul        v6, v1, v3
    v.add        v1, v4, v12
    v.st.w       [s5, #0], v0
    v.extract    s5, v8, #12
    v.splat      v0, s2
    v.extract    s2, v2, #12
    v.add        v12, v0, v13
    v.splat      v0, s5
    s.addi       s5, s1, #576
    v.add        v13, v12, v7
    v.mul        v12, v0, v3
    v.add        v0, v4, v13
    v.st.w       [s8, #0], v1
    v.extract    s8, v8, #13
    v.splat      v1, s6
    v.extract    s6, v2, #13
    v.add        v13, v1, v10
    v.splat      v1, s8
    s.addi       s8, s1, #640
    v.add        v10, v13, v7
    v.mul        v13, v1, v3
    v.add        v1, v4, v10
    v.st.w       [s3, #0], v0
    v.extract    s3, v8, #14
    v.splat      v0, s7
    v.extract    s7, v2, #14
    v.add        v10, v0, v5
    v.splat      v0, s3
    s.addi       s3, s1, #704
    v.add        v5, v10, v7
    v.mul        v10, v0, v3
    v.add        v0, v4, v5
    v.st.w       [s5, #0], v1
    v.extract    s5, v8, #15
    v.splat      v1, s9
    v.splat      v5, s5
    v.extract    s5, v2, #15
    v.splat      v2, s2
    v.mul        v8, v5, v3
    v.splat      v3, s6
    v.add        v5, v1, v6
    v.splat      v1, s7
    v.add        v6, v2, v12
    v.splat      v2, s5
    v.add        v12, v3, v13
    v.add        v3, v1, v10
    v.add        v1, v2, v8
    v.add        v2, v5, v7
    v.add        v5, v6, v7
    v.add        v6, v12, v7
    v.add        v8, v3, v7
    v.add        v3, v4, v2
    v.add        v2, v4, v5
    v.add        v5, v4, v6
    v.add        v6, v4, v8
    s.addi       s2, s1, #768
    s.addi       s5, s1, #832
    s.addi       s6, s1, #896
    s.addi       s7, s1, #960
    v.st.w       [s8, #0], v0
    v.add        v0, v1, v7
    s.movz       s1, #0
    s.addi       s8, s4, #3136
    v.add        v1, v4, v0
    v.extract    s9, v9, #0
    v.splat      v0, s9
    v.st.w       [s3, #0], v3
    v.extract    s3, v11, #0
    v.movi       v3, #0
    v.splat      v4, s3
    v.movi       v7, #0
    v.extract    s3, v14, #0
    v.movi       v8, #0
    v.splat      v10, s3
    v.cmp.ne     p2, v0, v3
    v.cmp.ne     p3, v4, v7
    p.and        p4, p2, p3
    v.st.w       [s2, #0], v2
    v.cmp.ne     p2, v10, v8
    p.and        p3, p4, p2
    s.movz       s2, #1
    p.and        p2, p3, p1
    s.addi       s3, s4, #3200
    v.extract    s9, v9, #1
    v.splat      v0, s9
    v.st.w       [s5, #0], v5
    v.extract    s5, v11, #1
    v.movi       v2, #0
    v.splat      v3, s5
    v.movi       v4, #0
    v.extract    s5, v14, #1
    v.movi       v5, #0
    v.splat      v7, s5
    v.cmp.ne     p3, v0, v2
    v.cmp.ne     p4, v3, v4
    p.and        p5, p3, p4
    v.st.w       [s6, #0], v6
    v.cmp.ne     p3, v7, v5
    p.and        p4, p5, p3
    s.movz       s5, #2
    p.and        p3, p4, p1
    s.addi       s6, s4, #3264
    v.extract    s9, v9, #2
    v.splat      v0, s9
    v.st.w       [s7, #0], v1
    fence.acq_rel.device
    a.vread      v1, a0, s1
    v.extract    s1, v11, #2
    v.movi       v2, #0
    v.splat      v3, s1
    v.movi       v4, #0
    v.cmp.ne     p4, v0, v2
    v.ld.w       v0, [s8, #0]
    v.extract    s1, v14, #2
    v.movi       v2, #0
    v.splat      v5, s1
    s.movz       s1, #3
    s.addi       s7, s4, #3328
    v.extract    s8, v9, #3
    v.movi       v6, #0
    v.splat      v7, s8
    @p2 v.st.scatter.w [s27, v0], v1
    a.vread      v0, a0, s2
    v.cmp.ne     p2, v3, v4
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v2
    p.and        p4, p5, p2
    v.extract    s2, v11, #3
    p.and        p2, p4, p1
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p4, v7, v6
    v.ld.w       v3, [s3, #0]
    v.extract    s2, v14, #3
    v.movi       v4, #0
    v.splat      v5, s2
    s.movz       s2, #4
    s.addi       s3, s4, #3392
    v.extract    s8, v9, #4
    v.movi       v6, #0
    v.splat      v7, s8
    @p3 v.st.scatter.w [s27, v3], v0
    a.vread      v0, a0, s5
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    v.extract    s5, v11, #4
    p.and        p3, p4, p1
    v.splat      v1, s5
    v.movi       v2, #0
    v.cmp.ne     p4, v7, v6
    v.ld.w       v3, [s6, #0]
    v.extract    s5, v14, #4
    v.movi       v4, #0
    v.splat      v5, s5
    s.movz       s5, #5
    s.addi       s6, s4, #3456
    v.extract    s8, v9, #5
    v.movi       v6, #0
    v.splat      v7, s8
    @p2 v.st.scatter.w [s27, v3], v0
    a.vread      v0, a0, s1
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v4
    p.and        p4, p5, p2
    v.extract    s1, v11, #5
    p.and        p2, p4, p1
    v.splat      v1, s1
    v.movi       v2, #0
    v.cmp.ne     p4, v7, v6
    v.ld.w       v3, [s7, #0]
    v.extract    s1, v14, #5
    v.movi       v4, #0
    v.splat      v5, s1
    s.movz       s1, #6
    s.addi       s7, s4, #3520
    v.extract    s8, v9, #6
    v.movi       v6, #0
    v.splat      v7, s8
    @p3 v.st.scatter.w [s27, v3], v0
    a.vread      v0, a0, s2
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    v.extract    s2, v11, #6
    p.and        p3, p4, p1
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p4, v7, v6
    v.ld.w       v3, [s3, #0]
    v.extract    s2, v14, #6
    v.movi       v4, #0
    v.splat      v5, s2
    s.movz       s2, #7
    s.addi       s3, s4, #3584
    v.extract    s8, v9, #7
    v.movi       v6, #0
    v.splat      v7, s8
    @p2 v.st.scatter.w [s27, v3], v0
    a.vread      v0, a0, s5
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v4
    p.and        p4, p5, p2
    v.extract    s5, v11, #7
    p.and        p2, p4, p1
    v.splat      v1, s5
    v.movi       v2, #0
    v.cmp.ne     p4, v7, v6
    v.ld.w       v3, [s6, #0]
    v.extract    s5, v14, #7
    v.movi       v4, #0
    v.splat      v5, s5
    s.movz       s5, #8
    s.addi       s6, s4, #3648
    v.extract    s8, v9, #8
    v.movi       v6, #0
    v.splat      v7, s8
    @p3 v.st.scatter.w [s27, v3], v0
    a.vread      v0, a0, s1
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    v.extract    s1, v11, #8
    p.and        p3, p4, p1
    v.splat      v1, s1
    v.movi       v2, #0
    v.cmp.ne     p4, v7, v6
    v.ld.w       v3, [s7, #0]
    v.extract    s1, v14, #8
    v.movi       v4, #0
    v.splat      v5, s1
    s.movz       s1, #9
    s.addi       s7, s4, #3712
    v.extract    s8, v9, #9
    v.movi       v6, #0
    v.splat      v7, s8
    @p2 v.st.scatter.w [s27, v3], v0
    a.vread      v0, a0, s2
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v4
    p.and        p4, p5, p2
    v.extract    s2, v11, #9
    p.and        p2, p4, p1
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p4, v7, v6
    v.ld.w       v3, [s3, #0]
    v.extract    s2, v14, #9
    v.movi       v4, #0
    v.splat      v5, s2
    s.movz       s2, #10
    s.addi       s3, s4, #3776
    v.extract    s8, v9, #10
    v.movi       v6, #0
    v.splat      v7, s8
    @p3 v.st.scatter.w [s27, v3], v0
    a.vread      v0, a0, s5
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    v.extract    s5, v11, #10
    p.and        p3, p4, p1
    v.splat      v1, s5
    v.movi       v2, #0
    v.cmp.ne     p4, v7, v6
    v.ld.w       v3, [s6, #0]
    v.extract    s5, v14, #10
    v.movi       v4, #0
    v.splat      v5, s5
    s.movz       s5, #11
    s.addi       s6, s4, #3840
    v.extract    s8, v9, #11
    v.movi       v6, #0
    v.splat      v7, s8
    @p2 v.st.scatter.w [s27, v3], v0
    a.vread      v0, a0, s1
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v4
    p.and        p4, p5, p2
    v.extract    s1, v11, #11
    p.and        p2, p4, p1
    v.splat      v1, s1
    v.movi       v2, #0
    v.cmp.ne     p4, v7, v6
    v.ld.w       v3, [s7, #0]
    v.extract    s1, v14, #11
    v.movi       v4, #0
    v.splat      v5, s1
    s.movz       s1, #12
    s.addi       s7, s4, #3904
    v.extract    s8, v9, #12
    v.movi       v6, #0
    v.splat      v7, s8
    @p3 v.st.scatter.w [s27, v3], v0
    a.vread      v0, a0, s2
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    v.extract    s2, v11, #12
    p.and        p3, p4, p1
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p4, v7, v6
    v.ld.w       v3, [s3, #0]
    v.extract    s2, v14, #12
    v.movi       v4, #0
    v.splat      v5, s2
    s.movz       s2, #13
    s.addi       s3, s4, #3968
    v.extract    s8, v9, #13
    v.movi       v6, #0
    v.splat      v7, s8
    @p2 v.st.scatter.w [s27, v3], v0
    a.vread      v0, a0, s5
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v4
    p.and        p4, p5, p2
    v.extract    s5, v11, #13
    p.and        p2, p4, p1
    v.splat      v1, s5
    v.movi       v2, #0
    v.cmp.ne     p4, v7, v6
    v.ld.w       v3, [s6, #0]
    v.extract    s5, v14, #13
    v.movi       v4, #0
    v.splat      v5, s5
    s.movz       s5, #14
    s.addi       s6, s4, #4032
    v.extract    s8, v9, #14
    v.movi       v6, #0
    v.splat      v7, s8
    @p3 v.st.scatter.w [s27, v3], v0
    a.vread      v0, a0, s1
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    v.extract    s1, v11, #14
    p.and        p3, p4, p1
    v.splat      v1, s1
    v.movi       v2, #0
    v.cmp.ne     p4, v7, v6
    v.ld.w       v3, [s7, #0]
    v.extract    s1, v14, #14
    v.movi       v4, #0
    v.splat      v5, s1
    s.movz       s1, #15
    s.addi       s7, s4, #4096
    v.extract    s4, v9, #15
    v.movi       v6, #0
    v.splat      v7, s4
    @p2 v.st.scatter.w [s27, v3], v0
    a.vread      v0, a0, s2
    v.cmp.ne     p2, v1, v2
    p.and        p5, p4, p2
    v.cmp.ne     p2, v5, v4
    p.and        p4, p5, p2
    v.extract    s2, v11, #15
    p.and        p2, p4, p1
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p4, v7, v6
    v.ld.w       v3, [s3, #0]
    v.extract    s2, v14, #15
    v.movi       v4, #0
    v.splat      v5, s2
    @p3 v.st.scatter.w [s27, v3], v0
    a.vread      v0, a0, s5
    v.cmp.ne     p3, v1, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v5, v4
    p.and        p4, p5, p3
    p.and        p3, p4, p1
    v.ld.w       v1, [s6, #0]
    @p2 v.st.scatter.w [s27, v1], v0
    a.vread      v0, a0, s1
    v.ld.w       v1, [s7, #0]
    @p3 v.st.scatter.w [s27, v1], v0
__rctx_next:
    exit
