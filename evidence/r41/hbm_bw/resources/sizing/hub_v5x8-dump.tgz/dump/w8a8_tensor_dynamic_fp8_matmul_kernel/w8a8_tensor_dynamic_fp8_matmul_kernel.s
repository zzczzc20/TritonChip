    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #48]                   // N: i32 at arg_base+48
    s.movz       s4, #0
    s.movz       s5, #0
    s.movz       s6, #128
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s6, s7
    s.movz       s7, #15
    s.sub        s10, s8, s9
    s.rdspecial  s8, pid.x
    s.movz       s9, #0
    s.add        s11, s3, s2
    s.ld.sw      s12, [s1, #40]                  // M: i32 at arg_base+40
    s.cmp.lt     s13, s11, s4
    s.movz       s4, #0
    s.sub        s14, s5, s13
    s.rdspecial  s5, pid.y
    s.xor        s13, s11, s14
    s.movz       s11, #16
    s.sub        s15, s13, s14
    s.movz       s13, #0
    s.movz       s16, #0
    s.cmp.lt     s17, s11, s13
    s.add        s13, s12, s7
    s.sub        s7, s16, s17
    s.cmp.lt     s16, s13, s9
    s.xor        s9, s11, s7
    s.sub        s17, s4, s16
    s.xor        s4, s6, s10
    s.xor        s16, s13, s17
    s.xor        s13, s17, s7
    s.sub        s18, s16, s17
    s.ld.d       s16, [s1, #0]                   // A: device_ptr64 at arg_base+0
    s.lshri      s17, s18, #4
    s.sub        s19, s9, s7
    s.muli       s7, s17, #16
    s.xor        s9, s17, s13
    s.sub        s17, s4, s10
    s.sub        s4, s9, s13
    s.sub        s9, s18, s7
    s.ld.d       s7, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.lshri      s9, s15, #7
    s.ld.d       s13, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.muli       s17, s9, #128
    s.ld.d       s18, [s1, #24]                  // As: device_ptr64 at arg_base+24
    s.sub        s19, s15, s17
    s.ld.d       s15, [s1, #32]                  // Bs: device_ptr64 at arg_base+32
    s.xor        s17, s14, s10
    s.xor        s10, s9, s17
    s.sub        s9, s10, s17
    s.ld.sw      s10, [s1, #56]                  // K: i32 at arg_base+56
    s.mul        s14, s8, s9
    s.ld.sw      s8, [s1, #64]                   // stride_am: i32 at arg_base+64
    s.add        s17, s14, s5
    s.ld.sw      s5, [s1, #72]                   // stride_bn: i32 at arg_base+72
    s.movz       s14, #8
    s.ld.sw      s19, [s1, #80]                  // stride_cm: i32 at arg_base+80
    s.mul        s1, s9, s14
    s.movz       s9, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.movz       s22, #0
    s.cmp.lt     s23, s1, s9
    s.cmp.lt     s9, s17, s20
    s.sub        s20, s21, s23
    s.sub        s21, s22, s9
    s.xor        s9, s1, s20
    s.xor        s22, s17, s21
    s.sub        s23, s9, s20
    s.movz       s9, #0
    s.movz       s24, #1
    s.sub        s25, s22, s21
    s.movz       s22, #0
    s.addi       s26, s9, #0
    s.cmp.eq     s9, s23, s24
    s.addi       s24, s22, #0
    s.mov        s26, s25
    br.nz        s9, sdiv_done_1
    s.movz       s9, #0
    s.movz       s22, #31
    s.mov        s26, s9
    s.addi       s9, s22, #0
sdiv_2:
    s.lshr       s22, s25, s9
    s.shli       s27, s24, #1
    s.andi       s28, s22, #1
    s.movz       s22, #0
    s.or         s29, s27, s28
    s.movz       s27, #1
    s.cmp.geu    s28, s29, s23
    s.shl        s30, s27, s9
    s.sub        s27, s22, s28
    s.subi       s22, s9, #1
    s.and        s28, s23, s27
    s.and        s31, s30, s27
    s.sub        s27, s29, s28
    s.or         s28, s26, s31
    s.mov        s24, s27
    s.mov        s26, s28
    s.mov        s9, s22
    s.movz       s22, #0
    s.cmp.ge     s27, s9, s22
    br.nz        s27, sdiv_2
sdiv_done_1:
    s.xor        s9, s21, s20
    s.movz       s20, #0
    s.xor        s21, s26, s9
    s.movz       s22, #0
    s.movz       s23, #0
    s.cmp.lt     s24, s1, s20
    s.sub        s20, s21, s9
    s.movz       s9, #0
    s.cmp.lt     s21, s17, s22
    s.sub        s22, s23, s24
    s.mul        s23, s20, s14
    s.sub        s20, s9, s21
    s.xor        s9, s1, s22
    s.xor        s1, s17, s20
    s.sub        s17, s9, s22
    s.movz       s9, #0
    s.movz       s21, #1
    s.sub        s22, s4, s23
    s.sub        s4, s1, s20
    s.movz       s1, #0
    s.addi       s24, s9, #0
    s.cmp.eq     s9, s17, s21
    s.min.s      s21, s22, s14
    s.addi       s14, s1, #0
    s.mov        s24, s4
    br.nz        s9, sdiv_done_3
    s.movz       s1, #0
    s.movz       s9, #31
    s.mov        s24, s1
    s.addi       s1, s9, #0
sdiv_4:
    s.lshr       s9, s4, s1
    s.shli       s22, s14, #1
    s.andi       s25, s9, #1
    s.movz       s9, #0
    s.or         s26, s22, s25
    s.movz       s22, #1
    s.cmp.geu    s25, s26, s17
    s.shl        s27, s22, s1
    s.sub        s22, s9, s25
    s.subi       s9, s1, #1
    s.and        s25, s17, s22
    s.and        s28, s27, s22
    s.sub        s22, s26, s25
    s.or         s25, s24, s28
    s.mov        s14, s22
    s.mov        s24, s25
    s.mov        s1, s9
    s.movz       s9, #0
    s.cmp.ge     s22, s1, s9
    br.nz        s22, sdiv_4
sdiv_done_3:
    s.xor        s1, s14, s20
    s.movz       s4, #0
    s.sub        s9, s1, s20
    s.movz       s1, #0
    s.movz       s14, #0
    s.cmp.lt     s17, s21, s4
    s.movz       s4, #0
    s.cmp.lt     s20, s9, s1
    s.sub        s1, s14, s17
    s.sub        s14, s4, s20
    s.xor        s4, s21, s1
    s.xor        s17, s9, s14
    s.sub        s20, s4, s1
    s.movz       s1, #0
    s.movz       s4, #1
    s.sub        s22, s17, s14
    s.movz       s17, #0
    s.addi       s24, s1, #0
    s.cmp.eq     s1, s20, s4
    s.addi       s4, s17, #0
    s.mov        s24, s22
    br.nz        s1, sdiv_done_5
    s.movz       s1, #0
    s.movz       s17, #31
    s.mov        s24, s1
    s.addi       s1, s17, #0
sdiv_6:
    s.lshr       s17, s22, s1
    s.shli       s25, s4, #1
    s.andi       s26, s17, #1
    s.movz       s17, #0
    s.or         s27, s25, s26
    s.movz       s25, #1
    s.cmp.geu    s26, s27, s20
    s.shl        s28, s25, s1
    s.sub        s25, s17, s26
    s.subi       s17, s1, #1
    s.and        s26, s20, s25
    s.and        s29, s28, s25
    s.sub        s25, s27, s26
    s.or         s26, s24, s29
    s.mov        s4, s25
    s.mov        s24, s26
    s.mov        s1, s17
    s.movz       s17, #0
    s.cmp.ge     s25, s1, s17
    br.nz        s25, sdiv_6
sdiv_done_5:
    s.movz       s1, #0
    s.movz       s17, #0
    s.movz       s20, #0
    s.cmp.lt     s22, s21, s1
    s.movz       s1, #0
    s.cmp.lt     s24, s9, s17
    s.sub        s17, s20, s22
    s.sub        s20, s1, s24
    s.xor        s1, s21, s17
    s.xor        s21, s4, s14
    s.xor        s4, s9, s20
    s.sub        s9, s1, s17
    s.movz       s1, #0
    s.movz       s22, #1
    s.sub        s24, s21, s14
    s.sub        s14, s4, s20
    s.movz       s4, #0
    s.addi       s21, s1, #0
    s.cmp.eq     s1, s9, s22
    s.add        s22, s23, s24
    s.addi       s23, s4, #0
    s.mov        s21, s14
    br.nz        s1, sdiv_done_7
    s.movz       s1, #0
    s.movz       s4, #31
    s.mov        s21, s1
    s.addi       s1, s4, #0
sdiv_8:
    s.lshr       s4, s14, s1
    s.shli       s24, s23, #1
    s.andi       s25, s4, #1
    s.movz       s4, #0
    s.or         s26, s24, s25
    s.movz       s24, #1
    s.cmp.geu    s25, s26, s9
    s.shl        s27, s24, s1
    s.sub        s24, s4, s25
    s.subi       s4, s1, #1
    s.and        s25, s9, s24
    s.and        s28, s27, s24
    s.sub        s24, s26, s25
    s.or         s25, s21, s28
    s.mov        s23, s24
    s.mov        s21, s25
    s.mov        s1, s4
    s.movz       s4, #0
    s.cmp.ge     s24, s1, s4
    br.nz        s24, sdiv_8
sdiv_done_7:
    s.mul        s1, s22, s11
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s12
    v.movi       v2, #0
    s.xor        s4, s20, s17
    v.splat      v3, s1
    v.sub        v4, v2, v1
    s.xor        s9, s21, s4
    v.add        v5, v3, v0
    v.cmp.lt     p1, v1, v2
    s.sub        s14, s9, s4
    v.sub        v0, v2, v5
    v.cmp.lt     p2, v5, v2
    v.movi       v3, #1
    @p2 v.sel        v6, v0, v5
    @p1 v.sel        v0, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s4, #31
idiv_9:
    v.splat      v5, s4
    v.shl        v7, v4, v3
    v.cmp.lt     p1, v4, v2
    v.lshr       v8, v6, v5
    v.shl        v9, v3, v5
    s.subi       s9, s4, #1
    v.and        v5, v8, v3
    s.movz       s17, #0
    v.or         v8, v7, v5
    v.cmp.geu    p3, v8, v0
    p.or         p4, p1, p3
    v.sub        v5, v8, v0
    @p4 v.sel        v7, v9, v2
    @p4 v.sel        v9, v5, v8
    v.or         v5, v1, v7
    v.mov        v4, v9
    v.mov        v1, v5
    s.mov        s4, s9
    s.cmp.ge     s9, s4, s17
    br.nz        s9, idiv_9
    s.mul        s4, s14, s6
    v.iota       v0                              // arange(0, VLEN)
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v3, #16
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s4
    v.movi       v7, #32
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #48
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #64
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #80
    v.iota       v14                             // arange(0, VLEN)
    v.movi       v15, #96
    v.iota       v16                             // arange(0, VLEN)
    v.movi       v17, #112
    v.add        v18, v6, v0
    v.splat      v0, s3
    v.sub        v6, v2, v4
    v.add        v2, v1, v3
    v.add        v1, v5, v7
    v.add        v3, v8, v9
    v.add        v5, v10, v11
    v.add        v7, v12, v13
    v.add        v8, v14, v15
    v.add        v9, v16, v17
    v.splat      v10, s4
    v.splat      v11, s4
    v.splat      v12, s4
    v.splat      v13, s4
    v.splat      v14, s4
    v.splat      v15, s4
    v.splat      v16, s4
    @p2 v.sel        v17, v6, v4
    v.movi       v4, #0
    v.add        v6, v10, v2
    v.add        v2, v11, v1
    v.sub        v1, v4, v18
    v.sub        v10, v4, v0
    v.cmp.lt     p1, v18, v4
    v.cmp.lt     p2, v0, v4
    v.add        v11, v12, v3
    v.add        v3, v13, v5
    v.add        v5, v14, v7
    v.add        v7, v15, v8
    v.add        v8, v16, v9
    v.splat      v9, s3
    v.splat      v12, s3
    v.splat      v13, s3
    v.splat      v14, s3
    v.splat      v15, s3
    v.splat      v16, s3
    v.splat      v19, s3
    v.movi       v20, #1
    @p1 v.sel        v21, v1, v18
    @p2 v.sel        v1, v10, v0
    v.movi       v0, #0
    v.movi       v10, #0
    s.movz       s9, #31
idiv_10:
    v.splat      v18, s9
    v.shl        v22, v10, v20
    v.cmp.lt     p2, v10, v4
    v.lshr       v23, v21, v18
    v.shl        v24, v20, v18
    s.subi       s14, s9, #1
    v.and        v18, v23, v20
    s.movz       s17, #0
    v.or         v23, v22, v18
    v.cmp.geu    p3, v23, v1
    p.or         p4, p2, p3
    v.sub        v18, v23, v1
    @p4 v.sel        v22, v24, v4
    @p4 v.sel        v24, v18, v23
    v.or         v18, v0, v22
    v.mov        v10, v24
    v.mov        v0, v18
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_10
    v.movi       v0, #0
    v.sub        v1, v4, v10
    v.movi       v4, #1
    v.sub        v18, v0, v6
    v.sub        v20, v0, v9
    v.cmp.lt     p2, v6, v0
    v.cmp.lt     p3, v9, v0
    @p1 v.sel        v21, v1, v10
    @p2 v.sel        v1, v18, v6
    @p3 v.sel        v6, v20, v9
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s9, #31
idiv_11:
    v.splat      v18, s9
    v.shl        v20, v10, v4
    v.cmp.lt     p1, v10, v0
    v.lshr       v22, v1, v18
    v.shl        v23, v4, v18
    s.subi       s14, s9, #1
    v.and        v18, v22, v4
    s.movz       s17, #0
    v.or         v22, v20, v18
    v.cmp.geu    p3, v22, v6
    p.or         p4, p1, p3
    v.sub        v18, v22, v6
    @p4 v.sel        v20, v23, v0
    @p4 v.sel        v23, v18, v22
    v.or         v18, v9, v20
    v.mov        v10, v23
    v.mov        v9, v18
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_11
    v.movi       v1, #0
    v.sub        v4, v0, v10
    v.movi       v0, #1
    v.sub        v6, v1, v2
    v.sub        v9, v1, v12
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p3, v12, v1
    @p2 v.sel        v18, v4, v10
    @p1 v.sel        v4, v6, v2
    @p3 v.sel        v2, v9, v12
    v.movi       v6, #0
    v.movi       v9, #0
    s.movz       s9, #31
idiv_12:
    v.splat      v10, s9
    v.shl        v12, v9, v0
    v.cmp.lt     p2, v9, v1
    v.lshr       v20, v4, v10
    v.shl        v22, v0, v10
    s.subi       s14, s9, #1
    v.and        v10, v20, v0
    s.movz       s17, #0
    v.or         v20, v12, v10
    v.cmp.geu    p3, v20, v2
    p.or         p4, p2, p3
    v.sub        v10, v20, v2
    @p4 v.sel        v12, v22, v1
    @p4 v.sel        v22, v10, v20
    v.or         v10, v6, v12
    v.mov        v9, v22
    v.mov        v6, v10
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_12
    v.movi       v0, #0
    v.sub        v2, v1, v9
    v.movi       v1, #1
    v.sub        v4, v0, v11
    v.sub        v6, v0, v13
    v.cmp.lt     p2, v11, v0
    v.cmp.lt     p3, v13, v0
    @p1 v.sel        v10, v2, v9
    @p2 v.sel        v2, v4, v11
    @p3 v.sel        v4, v6, v13
    v.movi       v6, #0
    v.movi       v9, #0
    s.movz       s9, #31
idiv_13:
    v.splat      v11, s9
    v.shl        v12, v9, v1
    v.cmp.lt     p1, v9, v0
    v.lshr       v13, v2, v11
    v.shl        v20, v1, v11
    s.subi       s14, s9, #1
    v.and        v11, v13, v1
    s.movz       s17, #0
    v.or         v13, v12, v11
    v.cmp.geu    p3, v13, v4
    p.or         p4, p1, p3
    v.sub        v11, v13, v4
    @p4 v.sel        v12, v20, v0
    @p4 v.sel        v20, v11, v13
    v.or         v11, v6, v12
    v.mov        v9, v20
    v.mov        v6, v11
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_13
    v.movi       v1, #0
    v.sub        v2, v0, v9
    v.movi       v0, #1
    v.sub        v4, v1, v3
    v.sub        v6, v1, v14
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p3, v14, v1
    @p2 v.sel        v11, v2, v9
    @p1 v.sel        v2, v4, v3
    @p3 v.sel        v3, v6, v14
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s9, #31
idiv_14:
    v.splat      v9, s9
    v.shl        v12, v6, v0
    v.cmp.lt     p2, v6, v1
    v.lshr       v13, v2, v9
    v.shl        v14, v0, v9
    s.subi       s14, s9, #1
    v.and        v9, v13, v0
    s.movz       s17, #0
    v.or         v13, v12, v9
    v.cmp.geu    p3, v13, v3
    p.or         p4, p2, p3
    v.sub        v9, v13, v3
    @p4 v.sel        v12, v14, v1
    @p4 v.sel        v14, v9, v13
    v.or         v9, v4, v12
    v.mov        v6, v14
    v.mov        v4, v9
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_14
    v.movi       v0, #0
    v.sub        v2, v1, v6
    v.movi       v1, #1
    v.sub        v3, v0, v5
    v.sub        v4, v0, v15
    v.cmp.lt     p2, v5, v0
    v.cmp.lt     p3, v15, v0
    @p1 v.sel        v9, v2, v6
    @p2 v.sel        v2, v3, v5
    @p3 v.sel        v3, v4, v15
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s9, #31
idiv_15:
    v.splat      v6, s9
    v.shl        v12, v5, v1
    v.cmp.lt     p1, v5, v0
    v.lshr       v13, v2, v6
    v.shl        v14, v1, v6
    s.subi       s14, s9, #1
    v.and        v6, v13, v1
    s.movz       s17, #0
    v.or         v13, v12, v6
    v.cmp.geu    p3, v13, v3
    p.or         p4, p1, p3
    v.sub        v6, v13, v3
    @p4 v.sel        v12, v14, v0
    @p4 v.sel        v14, v6, v13
    v.or         v6, v4, v12
    v.mov        v5, v14
    v.mov        v4, v6
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_15
    v.movi       v1, #0
    v.sub        v2, v0, v5
    v.movi       v0, #1
    v.sub        v3, v1, v7
    v.sub        v4, v1, v16
    v.cmp.lt     p1, v7, v1
    v.cmp.lt     p3, v16, v1
    @p2 v.sel        v6, v2, v5
    @p1 v.sel        v2, v3, v7
    @p3 v.sel        v3, v4, v16
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s9, #31
idiv_16:
    v.splat      v7, s9
    v.shl        v12, v5, v0
    v.cmp.lt     p2, v5, v1
    v.lshr       v13, v2, v7
    v.shl        v14, v0, v7
    s.subi       s14, s9, #1
    v.and        v7, v13, v0
    s.movz       s17, #0
    v.or         v13, v12, v7
    v.cmp.geu    p3, v13, v3
    p.or         p4, p2, p3
    v.sub        v7, v13, v3
    @p4 v.sel        v12, v14, v1
    @p4 v.sel        v14, v7, v13
    v.or         v7, v4, v12
    v.mov        v5, v14
    v.mov        v4, v7
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_16
    v.movi       v0, #0
    v.sub        v2, v1, v5
    v.movi       v1, #1
    v.sub        v3, v0, v8
    v.sub        v4, v0, v19
    v.cmp.lt     p2, v8, v0
    v.cmp.lt     p3, v19, v0
    @p1 v.sel        v7, v2, v5
    @p2 v.sel        v2, v3, v8
    @p3 v.sel        v3, v4, v19
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s9, #31
idiv_17:
    v.splat      v8, s9
    v.shl        v12, v5, v1
    v.cmp.lt     p1, v5, v0
    v.lshr       v13, v2, v8
    v.shl        v14, v1, v8
    s.subi       s14, s9, #1
    v.and        v8, v13, v1
    s.movz       s17, #0
    v.or         v13, v12, v8
    v.cmp.geu    p3, v13, v3
    p.or         p4, p1, p3
    v.sub        v8, v13, v3
    @p4 v.sel        v12, v14, v0
    @p4 v.sel        v14, v8, v13
    v.or         v8, v4, v12
    v.mov        v5, v14
    v.mov        v4, v8
    s.mov        s9, s14
    s.cmp.ge     s14, s9, s17
    br.nz        s14, idiv_17
    s.add        s9, s10, s2
    s.movz       s2, #0
    s.movz       s14, #0
    s.cmp.lt     s17, s9, s2
    s.movz       s2, #0
    s.sub        s20, s14, s17
    s.movz       s14, #0
    s.xor        s17, s9, s20
    s.cmp.lt     s9, s6, s2
    s.sub        s2, s17, s20
    s.sub        s17, s14, s9
    s.lshri      s9, s2, #7
    s.xor        s14, s20, s17
    s.muli       s20, s9, #128
    v.sub        v1, v0, v5
    s.xor        s21, s6, s17
    s.xor        s22, s9, s14
    s.movz       s9, #0
    s.movz       s23, #0
    s.movz       s24, #0
    @p2 v.sel        v0, v1, v5
    s.movz       s25, #32
    s.movz       s26, #48
    s.movz       s27, #64
    s.movz       s28, #80
    s.movz       s29, #96
    s.movz       s30, #112
    v.ld.gather.w v1, [s18, v17]                 // index is in elements (ISA sec 9.1)
    s.sub        s18, s21, s17
    s.sub        s17, s2, s20
    s.sub        s2, s22, s14
    s.movz       s14, #1
    s.addi       s17, s9, #0
    s.addi       s18, s23, #0
    s.addi       s20, s24, #0
    s.ld.w       s21, [s15, #0]                  // one element, not a vector
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_18:
    s.cmp.ge     s15, s17, s2
    br.nz        s15, endfor_19
    v.extract    s15, v21, #0
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s15
    v.extract    s22, v18, #0
    s.mul        s23, s17, s6
    v.add        v4, v3, v2
    v.splat      v3, s22
    s.movz       s24, #0
    v.sub        v5, v21, v4
    v.add        v4, v3, v2
    s.sub        s31, s10, s23
    v.reduce.or  s23, v5
    s.movz       s32, #0
    v.sub        v3, v18, v4
    s.add        s33, s9, s31
    s.movz       s34, #0
    s.cmp.eq     s35, s23, s24
    s.cmp.ge     s23, s15, s32
    v.reduce.or  s24, v3
    s.movz       s32, #0
    s.movz       s36, #0
    s.cmp.ge     s37, s33, s34
    s.and        s34, s35, s23
    v.movi       v3, #0
    v.movi       v4, #0
    s.cmp.eq     s23, s24, s32
    s.cmp.ge     s24, s22, s36
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s32, arg_base
    s.and        s35, s34, s37
    s.and        s34, s23, s24
    s.ld.d       s23, [s32, #88]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.insert     v3, s35, #0
    v.insert     v4, s15, #0
    s.and        s15, s34, s37
    v.splat      v5, s5
    v.insert     v3, s15, #1
    v.splat      v8, s5
    v.splat      v12, s5
    v.splat      v13, s5
    v.splat      v14, s5
    v.splat      v15, s5
    v.splat      v16, s5
    v.splat      v19, s5
    v.mul        v20, v21, v5
    v.extract    s15, v10, #0
    v.insert     v4, s22, #1
    v.mul        v5, v18, v8
    v.splat      v8, s15
    v.mul        v22, v10, v12
    v.mul        v12, v11, v13
    v.add        v13, v8, v2
    s.movz       s22, #0
    v.mul        v8, v9, v14
    v.sub        v14, v10, v13
    s.movz       s24, #0
    v.mul        v13, v6, v15
    v.reduce.or  s32, v14
    s.cmp.ge     s34, s15, s24
    s.cmp.eq     s24, s32, s22
    v.mul        v14, v7, v16
    s.and        s22, s24, s34
    v.mul        v15, v0, v19
    v.extract    s24, v11, #0
    v.extract    s32, v9, #0
    v.splat      v16, s24
    v.splat      v19, s32
    v.extract    s34, v6, #0
    v.add        v23, v16, v2
    v.add        v16, v19, v2
    v.splat      v19, s34
    v.sub        v24, v11, v23
    v.extract    s35, v7, #0
    s.movz       s36, #0
    v.sub        v23, v9, v16
    v.add        v16, v19, v2
    v.splat      v19, s35
    s.and        s38, s22, s37
    v.sub        v25, v6, v16
    v.add        v16, v19, v2
    v.insert     v3, s38, #2
    v.reduce.or  s22, v24
    v.insert     v4, s15, #2
    s.movz       s15, #0
    s.cmp.eq     s38, s22, s36
    v.extract    s22, v0, #0
    s.cmp.ge     s36, s24, s15
    v.splat      v19, s22
    s.and        s15, s38, s36
    v.reduce.or  s36, v23
    s.and        s38, s15, s37
    v.sub        v23, v7, v16
    v.add        v16, v19, v2
    v.insert     v3, s38, #3
    s.movz       s15, #0
    v.insert     v4, s24, #3
    s.movz       s24, #0
    s.cmp.eq     s38, s36, s15
    s.cmp.ge     s15, s32, s24
    v.reduce.or  s24, v25
    s.and        s36, s38, s15
    s.movz       s15, #0
    s.and        s38, s36, s37
    s.cmp.eq     s36, s24, s15
    s.movz       s15, #0
    v.sub        v2, v0, v16
    s.cmp.ge     s24, s34, s15
    v.insert     v3, s38, #4
    v.reduce.or  s15, v23
    s.and        s38, s36, s24
    s.movz       s24, #0
    v.insert     v4, s32, #4
    s.movz       s32, #0
    s.cmp.eq     s36, s15, s24
    s.cmp.ge     s15, s35, s32
    s.and        s24, s38, s37
    v.reduce.or  s32, v2
    s.and        s38, s36, s15
    s.movz       s15, #0
    v.insert     v3, s24, #5
    s.movz       s24, #0
    v.insert     v4, s34, #5
    s.cmp.eq     s34, s32, s15
    s.cmp.ge     s15, s22, s24
    s.and        s24, s38, s37
    s.and        s32, s34, s15
    v.insert     v3, s24, #6
    v.insert     v4, s35, #6
    v.splat      v2, s8
    s.and        s15, s32, s37
    s.add        s24, s7, s20
    v.mul        v16, v17, v2
    s.addi       s32, s23, #0                    // TensorMap 0: W's rows for a transposed FP8 B
    .li       s34, #2147483647
    v.extract    s35, v16, #0
    s.movz       s36, #1
    s.add        s37, s35, s18
    .li       s35, #137438953488
    s.add        s38, s16, s37
    v.insert     v3, s15, #7
    v.iota       v2                              // arange(0, VLEN)
    .li       s15, #7705171329024
    v.insert     v4, s22, #7
    s.movz       s22, #0
    s.st.d       [s32, #0], s24
    s.add        s24, s22, s31                   // the tile origin
    s.addi       s22, s23, #256
    v.splat      v19, s24
    s.addi       s24, s23, #768                  // TensorMap 1: the gathered fallback B tile
    s.movz       s37, #0
    v.cmp.lt     p1, v2, v19
    s.movz       s37, #0
    s.st.d       [s32, #8], s34
    s.movz       s34, #32
    s.st.d       [s32, #16], s33
    s.st.d       [s32, #48], s5
    s.st.d       [s32, #56], s36
    s.movz       s36, #16
    s.st.d       [s32, #88], s35
    s.movz       s35, #16
    s.st.d       [s32, #104], s15
    s.movz       s15, #1
    td.load      d0, [s32]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    .li       s32, #68719476768
    s.st.d       [s24, #0], s22
    .li       s22, #7705171329024
    s.st.d       [s24, #8], s34
    v.extract    s34, v16, #1
    s.add        s37, s34, s18
    s.add        s34, s16, s37
    s.st.d       [s24, #16], s36
    s.addi       s36, s23, #1024                 // 512 bytes of repack scratch
    s.st.d       [s24, #48], s35
    s.addi       s35, s36, #0
    s.st.d       [s24, #56], s15
    v.extract    s15, v16, #2
    s.add        s37, s15, s18
    s.add        s15, s16, s37
    s.st.d       [s24, #88], s32
    s.addi       s32, s36, #32
    s.st.d       [s24, #104], s22
    td.load      d1, [s24]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    v.extract    s22, v16, #3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s38, #0]
    s.add        s24, s22, s18
    s.addi       s22, s36, #64
    s.add        s37, s16, s24
    v.extract    s24, v16, #4
    s.add        s38, s24, s18
    s.add        s24, s16, s38
    v.st.b       [s35, #0], v19
    s.addi       s35, s36, #96
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s34, #0]
    v.extract    s34, v16, #5
    s.add        s38, s34, s18
    s.add        s34, s16, s38
    v.st.b       [s32, #0], v19
    s.addi       s32, s36, #128
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s15, #0]
    v.extract    s15, v16, #6
    s.add        s38, s15, s18
    s.add        s15, s16, s38
    v.st.b       [s22, #0], v19
    s.addi       s22, s36, #160
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s37, #0]
    v.extract    s37, v16, #7
    s.add        s38, s37, s18
    s.add        s37, s16, s38
    v.st.b       [s35, #0], v19
    s.addi       s35, s36, #192
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s24, #0]
    v.extract    s24, v16, #8
    s.add        s38, s24, s18
    s.add        s24, s16, s38
    v.st.b       [s32, #0], v19
    s.addi       s32, s36, #224
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s34, #0]
    v.extract    s34, v16, #9
    s.add        s38, s34, s18
    s.add        s34, s16, s38
    v.st.b       [s22, #0], v19
    s.addi       s22, s36, #256
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s15, #0]
    v.extract    s15, v16, #10
    s.add        s38, s15, s18
    s.add        s15, s16, s38
    v.st.b       [s35, #0], v19
    s.addi       s35, s36, #288
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s37, #0]
    v.extract    s37, v16, #11
    s.add        s38, s37, s18
    s.add        s37, s16, s38
    v.st.b       [s32, #0], v19
    s.addi       s32, s36, #320
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s24, #0]
    v.extract    s24, v16, #12
    s.add        s38, s24, s18
    s.add        s24, s16, s38
    v.st.b       [s22, #0], v19
    s.addi       s22, s36, #352
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s34, #0]
    v.extract    s34, v16, #13
    s.add        s38, s34, s18
    s.add        s34, s16, s38
    v.st.b       [s35, #0], v19
    s.addi       s35, s36, #384
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s15, #0]
    v.extract    s15, v16, #14
    s.add        s38, s15, s18
    s.add        s15, s16, s38
    v.st.b       [s32, #0], v19
    s.addi       s32, s36, #416
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s37, #0]
    v.extract    s37, v16, #15
    s.add        s38, s37, s18
    s.add        s37, s16, s38
    v.st.b       [s22, #0], v19
    s.addi       s22, s36, #448
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s24, #0]
    s.movz       s24, #0
    s.add        s38, s24, s11                   // the tile origin
    v.splat      v23, s38
    v.extract    s24, v16, #0
    s.add        s38, s24, s18
    v.add        v24, v2, v23
    s.addi       s24, s38, #16
    v.st.b       [s35, #0], v19
    s.movz       s35, #0
    s.add        s38, s16, s24
    s.add        s24, s35, s31                   // the tile origin
    v.splat      v19, s24
    s.addi       s24, s36, #480
    v.cmp.lt     p2, v24, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s34, #0]
    v.extract    s34, v16, #1
    s.add        s35, s34, s18
    s.addi       s34, s35, #16
    s.add        s35, s16, s34
    v.st.b       [s32, #0], v19
    s.addi       s32, s36, #16
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s15, #0]
    v.extract    s15, v16, #2
    s.add        s34, s15, s18
    s.addi       s15, s34, #16
    s.add        s34, s16, s15
    v.st.b       [s22, #0], v19
    s.addi       s15, s36, #48
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s37, #0]
    v.extract    s22, v16, #3
    s.add        s37, s22, s18
    s.addi       s22, s37, #16
    s.add        s37, s16, s22
    v.st.b       [s24, #0], v19
    s.addi       s22, s36, #80
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s38, #0]
    v.extract    s24, v16, #4
    s.add        s38, s24, s18
    s.addi       s24, s38, #16
    s.add        s38, s16, s24
    v.st.b       [s32, #0], v19
    s.addi       s24, s36, #112
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s35, #0]
    v.extract    s32, v16, #5
    s.add        s35, s32, s18
    s.addi       s32, s35, #16
    s.add        s35, s16, s32
    v.st.b       [s15, #0], v19
    s.addi       s15, s36, #144
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s34, #0]
    v.extract    s32, v16, #6
    s.add        s34, s32, s18
    s.addi       s32, s34, #16
    s.add        s34, s16, s32
    v.st.b       [s22, #0], v19
    s.addi       s22, s36, #176
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s37, #0]
    v.extract    s32, v16, #7
    s.add        s37, s32, s18
    s.addi       s32, s37, #16
    s.add        s37, s16, s32
    v.st.b       [s24, #0], v19
    s.addi       s24, s36, #208
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s38, #0]
    v.extract    s32, v16, #8
    s.add        s38, s32, s18
    s.addi       s32, s38, #16
    s.add        s38, s16, s32
    v.st.b       [s15, #0], v19
    s.addi       s15, s36, #240
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s35, #0]
    v.extract    s32, v16, #9
    s.add        s35, s32, s18
    s.addi       s32, s35, #16
    s.add        s35, s16, s32
    v.st.b       [s22, #0], v19
    s.addi       s22, s36, #272
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s34, #0]
    v.extract    s32, v16, #10
    s.add        s34, s32, s18
    s.addi       s32, s34, #16
    s.add        s34, s16, s32
    v.st.b       [s24, #0], v19
    s.addi       s24, s36, #304
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s37, #0]
    v.extract    s32, v16, #11
    s.add        s37, s32, s18
    s.addi       s32, s37, #16
    s.add        s37, s16, s32
    v.st.b       [s15, #0], v19
    s.addi       s15, s36, #336
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s38, #0]
    v.extract    s32, v16, #12
    s.add        s38, s32, s18
    s.addi       s32, s38, #16
    s.add        s38, s16, s32
    v.st.b       [s22, #0], v19
    s.addi       s22, s36, #368
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s35, #0]
    v.extract    s32, v16, #13
    s.add        s35, s32, s18
    s.addi       s32, s35, #16
    s.add        s35, s16, s32
    v.st.b       [s24, #0], v19
    s.addi       s24, s36, #400
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s34, #0]
    v.extract    s32, v16, #14
    s.add        s34, s32, s18
    s.addi       s32, s34, #16
    s.add        s34, s16, s32
    v.st.b       [s15, #0], v19
    s.addi       s15, s36, #432
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s37, #0]
    v.extract    s32, v16, #15
    s.add        s37, s32, s18
    s.addi       s32, s37, #16
    s.add        s37, s16, s32
    v.st.b       [s22, #0], v19
    s.addi       s22, s36, #464
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s38, #0]
    s.addi       s32, s36, #496
    v.st.b       [s24, #0], v19
    s.addi       s24, s36, #64
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s35, #0]
    s.addi       s35, s36, #128
    v.st.b       [s15, #0], v19
    s.addi       s15, s36, #192
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s34, #0]
    s.addi       s34, s36, #256
    v.st.b       [s22, #0], v19
    s.addi       s22, s36, #320
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s37, #0]
    s.addi       s37, s36, #384
    v.st.b       [s32, #0], v19
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s32, s36, #448
    v.ld.w       v19, [s36, #0]
    v.extract    s36, v3, #0
    v.mov        v48, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s24, #0]
    v.mov        v49, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s35, #0]
    v.mov        v50, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s15, #0]
    v.mov        v51, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s34, #0]
    v.mov        v52, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s22, #0]
    v.mov        v53, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s37, #0]
    v.mov        v54, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s32, #0]
    v.mov        v55, v19                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s36, x8dot_done_20
    s.movz       s15, #0
    s.add        s22, s7, s20
    s.addi       s24, s15, #0
    s.addi       s15, s23, #256
x8dot_row_21:
    s.addi       s32, s33, #0
    v.movi       v19, #0
    s.sub        s34, s32, s24
    s.add        s32, s22, s24
    v.splat      v23, s34
    s.shli       s34, s24, #4
    s.addi       s35, s24, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s32, v20]            // index is in elements (ISA sec 9.1)
    s.add        s32, s15, s34
    s.movz       s34, #32
    v.st.b       [s32, #0], v19
    fence.acq_rel.device
    s.mov        s24, s35
    s.cmp.lt     s32, s24, s34
    br.nz        s32, x8dot_row_21
x8dot_done_20:
    v.splat      v19, s36
    v.movi       v23, #0
    v.splat      v24, s36
    v.movi       v25, #0
    mb.arm       s15, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s22, #0
    s.movz       s24, #0
    v.extract    s32, v4, #0
    s.movz       s34, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s35, s22                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s24                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s15            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s15          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s15
    mb.arm       s22, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s24, v3, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s22
    mb.wait      s22
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s24, x8dot_done_22
    s.movz       s32, #0
    s.add        s34, s7, s20
    s.addi       s35, s32, #0
    s.addi       s32, s23, #256
x8dot_row_23:
    s.addi       s36, s33, #0
    v.movi       v19, #0
    s.sub        s37, s36, s35
    s.add        s36, s34, s35
    v.splat      v23, s37
    s.shli       s37, s35, #4
    s.addi       s38, s35, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s36, v5]             // index is in elements (ISA sec 9.1)
    s.add        s36, s32, s37
    s.movz       s37, #32
    v.st.b       [s36, #0], v19
    fence.acq_rel.device
    s.mov        s35, s38
    s.cmp.lt     s36, s35, s37
    br.nz        s36, x8dot_row_23
x8dot_done_22:
    v.splat      v19, s24
    v.movi       v23, #0
    v.splat      v24, s24
    v.movi       v25, #0
    mb.arm       s24, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    s.movz       s34, #0
    v.extract    s35, v4, #1
    s.movz       s36, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s24            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s24          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s24
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v3, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_24
    s.movz       s35, #0
    s.add        s36, s7, s20
    s.addi       s37, s35, #0
    s.addi       s35, s23, #256
x8dot_row_25:
    s.addi       s38, s33, #0
    v.movi       v19, #0
    s.sub        s39, s38, s37
    s.add        s38, s36, s37
    v.splat      v23, s39
    s.shli       s39, s37, #4
    s.addi       s40, s37, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s38, v22]            // index is in elements (ISA sec 9.1)
    s.add        s38, s35, s39
    s.movz       s39, #32
    v.st.b       [s38, #0], v19
    fence.acq_rel.device
    s.mov        s37, s40
    s.cmp.lt     s38, s37, s39
    br.nz        s38, x8dot_row_25
x8dot_done_24:
    v.splat      v19, s34
    v.movi       v23, #0
    v.splat      v24, s34
    v.movi       v25, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s35, #0
    s.movz       s36, #0
    v.extract    s37, v4, #2
    s.movz       s38, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s39, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v3, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s36, x8dot_done_26
    s.movz       s37, #0
    s.add        s38, s7, s20
    s.addi       s39, s37, #0
    s.addi       s37, s23, #256
x8dot_row_27:
    s.addi       s40, s33, #0
    v.movi       v19, #0
    s.sub        s41, s40, s39
    s.add        s40, s38, s39
    v.splat      v23, s41
    s.shli       s41, s39, #4
    s.addi       s42, s39, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s40, v12]            // index is in elements (ISA sec 9.1)
    s.add        s40, s37, s41
    s.movz       s41, #32
    v.st.b       [s40, #0], v19
    fence.acq_rel.device
    s.mov        s39, s42
    s.cmp.lt     s40, s39, s41
    br.nz        s40, x8dot_row_27
x8dot_done_26:
    v.splat      v19, s36
    v.movi       v23, #0
    v.splat      v24, s36
    v.movi       v25, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    s.movz       s38, #0
    v.extract    s39, v4, #3
    s.movz       s40, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v3, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s38, x8dot_done_28
    s.movz       s39, #0
    s.add        s40, s7, s20
    s.addi       s41, s39, #0
    s.addi       s39, s23, #256
x8dot_row_29:
    s.addi       s42, s33, #0
    v.movi       v19, #0
    s.sub        s43, s42, s41
    s.add        s42, s40, s41
    v.splat      v23, s43
    s.shli       s43, s41, #4
    s.addi       s44, s41, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s42, v8]             // index is in elements (ISA sec 9.1)
    s.add        s42, s39, s43
    s.movz       s43, #32
    v.st.b       [s42, #0], v19
    fence.acq_rel.device
    s.mov        s41, s44
    s.cmp.lt     s42, s41, s43
    br.nz        s42, x8dot_row_29
x8dot_done_28:
    v.splat      v19, s38
    v.movi       v23, #0
    v.splat      v24, s38
    v.movi       v25, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    s.movz       s40, #0
    v.extract    s41, v4, #4
    s.movz       s42, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v3, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_30
    s.movz       s41, #0
    s.add        s42, s7, s20
    s.addi       s43, s41, #0
    s.addi       s41, s23, #256
x8dot_row_31:
    s.addi       s44, s33, #0
    v.movi       v19, #0
    s.sub        s45, s44, s43
    s.add        s44, s42, s43
    v.splat      v23, s45
    s.shli       s45, s43, #4
    s.addi       s46, s43, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s44, v13]            // index is in elements (ISA sec 9.1)
    s.add        s44, s41, s45
    s.movz       s45, #32
    v.st.b       [s44, #0], v19
    fence.acq_rel.device
    s.mov        s43, s46
    s.cmp.lt     s44, s43, s45
    br.nz        s44, x8dot_row_31
x8dot_done_30:
    v.splat      v19, s40
    v.movi       v23, #0
    v.splat      v24, s40
    v.movi       v25, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    s.movz       s42, #0
    v.extract    s43, v4, #5
    s.movz       s44, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v3, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_32
    s.movz       s43, #0
    s.add        s44, s7, s20
    s.addi       s45, s43, #0
    s.addi       s43, s23, #256
x8dot_row_33:
    s.addi       s46, s33, #0
    v.movi       v19, #0
    s.sub        s47, s46, s45
    s.add        s46, s44, s45
    v.splat      v23, s47
    s.shli       s47, s45, #4
    s.addi       s48, s45, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s46, v14]            // index is in elements (ISA sec 9.1)
    s.add        s46, s43, s47
    s.movz       s47, #32
    v.st.b       [s46, #0], v19
    fence.acq_rel.device
    s.mov        s45, s48
    s.cmp.lt     s46, s45, s47
    br.nz        s46, x8dot_row_33
x8dot_done_32:
    v.splat      v19, s42
    v.movi       v23, #0
    v.splat      v24, s42
    v.movi       v25, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    s.movz       s44, #0
    v.extract    s45, v4, #6
    s.movz       s46, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v3, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s43
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_34
    s.movz       s45, #0
    s.add        s46, s7, s20
    s.addi       s47, s45, #0
    s.addi       s45, s23, #256
x8dot_row_35:
    s.addi       s48, s33, #0
    v.movi       v19, #0
    s.sub        s49, s48, s47
    s.add        s48, s46, s47
    v.splat      v23, s49
    s.shli       s49, s47, #4
    s.addi       s50, s47, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s48, v15]            // index is in elements (ISA sec 9.1)
    s.add        s48, s45, s49
    s.movz       s49, #32
    v.st.b       [s48, #0], v19
    fence.acq_rel.device
    s.mov        s47, s50
    s.cmp.lt     s48, s47, s49
    br.nz        s48, x8dot_row_35
x8dot_done_34:
    s.movz       s45, #0
    v.extract    s46, v16, #0
    s.add        s47, s45, s25                   // the tile origin
    s.movz       s45, #0
    v.splat      v19, s44
    v.movi       v23, #0
    v.splat      v24, s44
    v.movi       v25, #0
    v.splat      v26, s47
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.add        s47, s46, s18
    s.add        s46, s45, s31                   // the tile origin
    s.movz       s45, #0
    s.movz       s48, #0
    v.extract    s49, v4, #7
    s.movz       s50, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.addi       s51, s47, #32
    v.add        v19, v2, v26
    v.splat      v23, s46
    s.mov        s46, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s46, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s46, s16, s51
    v.cmp.lt     p1, v19, v23
    m.mma.async.k32.e4m3 a15, v48, v56, s45
    mb.wait      s45
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s46, #0]
    v.extract    s46, v16, #1
    s.addi       s47, s23, #1536                 // 512 bytes of repack scratch
    s.add        s48, s46, s18
    s.addi       s46, s47, #0
    s.addi       s49, s48, #32
    v.extract    s48, v16, #2
    s.add        s50, s16, s49
    s.add        s49, s48, s18
    s.addi       s48, s47, #32
    s.addi       s51, s49, #32
    v.extract    s49, v16, #3
    v.st.b       [s46, #0], v19
    s.add        s46, s16, s51
    s.add        s51, s49, s18
    s.addi       s49, s47, #64
    s.addi       s52, s51, #32
    v.extract    s51, v16, #4
    s.add        s53, s16, s52
    s.add        s52, s51, s18
    s.addi       s51, s52, #32
    s.add        s52, s16, s51
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s50, #0]
    s.addi       s50, s47, #96
    v.st.b       [s48, #0], v19
    v.extract    s48, v16, #5
    s.add        s51, s48, s18
    s.addi       s48, s51, #32
    s.add        s51, s16, s48
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s46, #0]
    s.addi       s46, s47, #128
    v.st.b       [s49, #0], v19
    v.extract    s48, v16, #6
    s.add        s49, s48, s18
    s.addi       s48, s49, #32
    s.add        s49, s16, s48
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s53, #0]
    s.addi       s48, s47, #160
    v.st.b       [s50, #0], v19
    v.extract    s50, v16, #7
    s.add        s53, s50, s18
    s.addi       s50, s53, #32
    s.add        s53, s16, s50
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s52, #0]
    s.addi       s50, s47, #192
    v.st.b       [s46, #0], v19
    v.extract    s46, v16, #8
    s.add        s52, s46, s18
    s.addi       s46, s52, #32
    s.add        s52, s16, s46
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s51, #0]
    s.addi       s46, s47, #224
    v.st.b       [s48, #0], v19
    v.extract    s48, v16, #9
    s.add        s51, s48, s18
    s.addi       s48, s51, #32
    s.add        s51, s16, s48
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s49, #0]
    s.addi       s48, s47, #256
    v.st.b       [s50, #0], v19
    v.extract    s49, v16, #10
    s.add        s50, s49, s18
    s.addi       s49, s50, #32
    s.add        s50, s16, s49
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s53, #0]
    s.addi       s49, s47, #288
    v.st.b       [s46, #0], v19
    v.extract    s46, v16, #11
    s.add        s53, s46, s18
    s.addi       s46, s53, #32
    s.add        s53, s16, s46
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s52, #0]
    s.addi       s46, s47, #320
    v.st.b       [s48, #0], v19
    v.extract    s48, v16, #12
    s.add        s52, s48, s18
    s.addi       s48, s52, #32
    s.add        s52, s16, s48
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s51, #0]
    s.addi       s48, s47, #352
    v.st.b       [s49, #0], v19
    v.extract    s49, v16, #13
    s.add        s51, s49, s18
    s.addi       s49, s51, #32
    s.add        s51, s16, s49
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s50, #0]
    s.addi       s49, s47, #384
    v.st.b       [s46, #0], v19
    v.extract    s46, v16, #14
    s.add        s50, s46, s18
    s.addi       s46, s50, #32
    s.add        s50, s16, s46
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s53, #0]
    s.addi       s46, s47, #416
    v.st.b       [s48, #0], v19
    v.extract    s48, v16, #15
    s.add        s53, s48, s18
    s.addi       s48, s53, #32
    s.add        s53, s16, s48
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s52, #0]
    s.addi       s48, s47, #448
    v.st.b       [s49, #0], v19
    s.movz       s49, #0
    s.add        s52, s49, s26                   // the tile origin
    v.splat      v19, s52
    v.extract    s49, v16, #0
    s.add        s52, s49, s18
    v.add        v23, v2, v19
    s.addi       s49, s52, #48
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s51, #0]
    s.movz       s51, #0
    s.add        s52, s16, s49
    s.add        s49, s51, s31                   // the tile origin
    v.splat      v24, s49
    s.addi       s49, s47, #480
    v.cmp.lt     p2, v23, v24
    v.st.b       [s46, #0], v19
    v.extract    s46, v16, #1
    s.add        s51, s46, s18
    s.addi       s46, s51, #48
    s.add        s51, s16, s46
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s50, #0]
    s.addi       s46, s47, #16
    v.st.b       [s48, #0], v19
    v.extract    s48, v16, #2
    s.add        s50, s48, s18
    s.addi       s48, s50, #48
    s.add        s50, s16, s48
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s53, #0]
    s.addi       s48, s47, #48
    v.st.b       [s49, #0], v19
    v.extract    s49, v16, #3
    s.add        s53, s49, s18
    s.addi       s49, s53, #48
    s.add        s53, s16, s49
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s52, #0]
    s.addi       s49, s47, #80
    v.st.b       [s46, #0], v19
    v.extract    s46, v16, #4
    s.add        s52, s46, s18
    s.addi       s46, s52, #48
    s.add        s52, s16, s46
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s51, #0]
    s.addi       s46, s47, #112
    v.st.b       [s48, #0], v19
    v.extract    s48, v16, #5
    s.add        s51, s48, s18
    s.addi       s48, s51, #48
    s.add        s51, s16, s48
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s50, #0]
    s.addi       s48, s47, #144
    v.st.b       [s49, #0], v19
    v.extract    s49, v16, #6
    s.add        s50, s49, s18
    s.addi       s49, s50, #48
    s.add        s50, s16, s49
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s53, #0]
    s.addi       s49, s47, #176
    v.st.b       [s46, #0], v19
    v.extract    s46, v16, #7
    s.add        s53, s46, s18
    s.addi       s46, s53, #48
    s.add        s53, s16, s46
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s52, #0]
    s.addi       s46, s47, #208
    v.st.b       [s48, #0], v19
    v.extract    s48, v16, #8
    s.add        s52, s48, s18
    s.addi       s48, s52, #48
    s.add        s52, s16, s48
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s51, #0]
    s.addi       s48, s47, #240
    v.st.b       [s49, #0], v19
    v.extract    s49, v16, #9
    s.add        s51, s49, s18
    s.addi       s49, s51, #48
    s.add        s51, s16, s49
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s50, #0]
    s.addi       s49, s47, #272
    v.st.b       [s46, #0], v19
    v.extract    s46, v16, #10
    s.add        s50, s46, s18
    s.addi       s46, s50, #48
    s.add        s50, s16, s46
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s53, #0]
    s.addi       s46, s47, #304
    v.st.b       [s48, #0], v19
    v.extract    s48, v16, #11
    s.add        s53, s48, s18
    s.addi       s48, s53, #48
    s.add        s53, s16, s48
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s52, #0]
    s.addi       s48, s47, #336
    v.st.b       [s49, #0], v19
    v.extract    s49, v16, #12
    s.add        s52, s49, s18
    s.addi       s49, s52, #48
    s.add        s52, s16, s49
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s51, #0]
    s.addi       s49, s47, #368
    v.st.b       [s46, #0], v19
    v.extract    s46, v16, #13
    s.add        s51, s46, s18
    s.addi       s46, s51, #48
    s.add        s51, s16, s46
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s50, #0]
    s.addi       s46, s47, #400
    v.st.b       [s48, #0], v19
    v.extract    s48, v16, #14
    s.add        s50, s48, s18
    s.addi       s48, s50, #48
    s.add        s50, s16, s48
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s53, #0]
    s.addi       s48, s47, #432
    v.st.b       [s49, #0], v19
    v.extract    s49, v16, #15
    s.add        s53, s49, s18
    s.addi       s49, s53, #48
    s.add        s53, s16, s49
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s52, #0]
    s.addi       s49, s47, #464
    v.st.b       [s46, #0], v19
    s.addi       s46, s47, #496
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s51, #0]
    s.addi       s51, s47, #64
    v.st.b       [s48, #0], v19
    s.addi       s48, s47, #128
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s50, #0]
    s.addi       s50, s47, #192
    v.st.b       [s49, #0], v19
    s.addi       s49, s47, #256
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s53, #0]
    s.addi       s52, s47, #320
    v.st.b       [s46, #0], v19
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s46, s47, #384
    v.ld.w       v19, [s47, #0]
    s.addi       s53, s47, #448
    v.mov        v48, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s51, #0]
    v.extract    s47, v3, #0
    v.mov        v49, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s48, #0]
    v.mov        v50, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s50, #0]
    v.mov        v51, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s49, #0]
    v.mov        v52, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s52, #0]
    v.mov        v53, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s46, #0]
    v.mov        v54, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s53, #0]
    v.mov        v55, v19                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s47, x8dot_done_36
    s.movz       s46, #0
    s.add        s48, s7, s20
    s.addi       s49, s46, #0
    s.addi       s46, s48, #32
    s.addi       s48, s23, #256
x8dot_row_37:
    s.addi       s50, s33, #-32
    v.movi       v19, #0
    s.sub        s51, s50, s49
    s.add        s50, s46, s49
    v.splat      v23, s51
    s.shli       s51, s49, #4
    s.addi       s52, s49, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s50, v20]            // index is in elements (ISA sec 9.1)
    s.add        s50, s48, s51
    s.movz       s51, #32
    v.st.b       [s50, #0], v19
    fence.acq_rel.device
    s.mov        s49, s52
    s.cmp.lt     s50, s49, s51
    br.nz        s50, x8dot_row_37
x8dot_done_36:
    v.splat      v19, s47
    v.movi       v23, #0
    v.splat      v24, s47
    v.movi       v25, #0
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    s.movz       s48, #0
    v.extract    s49, v4, #0
    s.movz       s50, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s46            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v3, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s48, x8dot_done_38
    s.movz       s49, #0
    s.add        s50, s7, s20
    s.addi       s51, s49, #0
    s.addi       s49, s50, #32
    s.addi       s50, s23, #256
x8dot_row_39:
    s.addi       s52, s33, #-32
    v.movi       v19, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v23, s53
    s.shli       s53, s51, #4
    s.addi       s54, s51, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s52, v5]             // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.movz       s53, #32
    v.st.b       [s52, #0], v19
    fence.acq_rel.device
    s.mov        s51, s54
    s.cmp.lt     s52, s51, s53
    br.nz        s52, x8dot_row_39
x8dot_done_38:
    v.splat      v19, s48
    v.movi       v23, #0
    v.splat      v24, s48
    v.movi       v25, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    s.movz       s50, #0
    v.extract    s51, v4, #1
    s.movz       s52, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v3, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s50, x8dot_done_40
    s.movz       s51, #0
    s.add        s52, s7, s20
    s.addi       s53, s51, #0
    s.addi       s51, s52, #32
    s.addi       s52, s23, #256
x8dot_row_41:
    s.addi       s54, s33, #-32
    v.movi       v19, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v23, s55
    s.shli       s55, s53, #4
    s.addi       s56, s53, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s54, v22]            // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.movz       s55, #32
    v.st.b       [s54, #0], v19
    fence.acq_rel.device
    s.mov        s53, s56
    s.cmp.lt     s54, s53, s55
    br.nz        s54, x8dot_row_41
x8dot_done_40:
    v.splat      v19, s50
    v.movi       v23, #0
    v.splat      v24, s50
    v.movi       v25, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s51, #0
    s.movz       s52, #0
    v.extract    s53, v4, #2
    s.movz       s54, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s55, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v3, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s52, x8dot_done_42
    s.movz       s53, #0
    s.add        s54, s7, s20
    s.addi       s55, s53, #0
    s.addi       s53, s54, #32
    s.addi       s54, s23, #256
x8dot_row_43:
    s.addi       s56, s33, #-32
    v.movi       v19, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v23, s57
    s.shli       s57, s55, #4
    s.addi       s58, s55, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s56, v12]            // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.movz       s57, #32
    v.st.b       [s56, #0], v19
    fence.acq_rel.device
    s.mov        s55, s58
    s.cmp.lt     s56, s55, s57
    br.nz        s56, x8dot_row_43
x8dot_done_42:
    v.splat      v19, s52
    v.movi       v23, #0
    v.splat      v24, s52
    v.movi       v25, #0
    mb.arm       s52, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    s.movz       s54, #0
    v.extract    s55, v4, #3
    s.movz       s56, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s57, s52            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v3, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s53
    mb.wait      s53
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s54, x8dot_done_44
    s.movz       s55, #0
    s.add        s56, s7, s20
    s.addi       s57, s55, #0
    s.addi       s55, s56, #32
    s.addi       s56, s23, #256
x8dot_row_45:
    s.addi       s58, s33, #-32
    v.movi       v19, #0
    s.sub        s59, s58, s57
    s.add        s58, s55, s57
    v.splat      v23, s59
    s.shli       s59, s57, #4
    s.addi       s60, s57, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s58, v8]             // index is in elements (ISA sec 9.1)
    s.add        s58, s56, s59
    s.movz       s59, #32
    v.st.b       [s58, #0], v19
    fence.acq_rel.device
    s.mov        s57, s60
    s.cmp.lt     s58, s57, s59
    br.nz        s58, x8dot_row_45
x8dot_done_44:
    v.splat      v19, s54
    v.movi       v23, #0
    v.splat      v24, s54
    v.movi       v25, #0
    mb.arm       s54, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s55, #0
    s.movz       s56, #0
    v.extract    s57, v4, #4
    s.movz       s58, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s60, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s59, s54            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s57                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s58                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s54          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    mb.arm       s55, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v3, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s55
    mb.wait      s55
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s56, x8dot_done_46
    s.movz       s57, #0
    s.add        s58, s7, s20
    s.addi       s59, s57, #0
    s.addi       s57, s58, #32
    s.addi       s58, s23, #256
x8dot_row_47:
    s.addi       s60, s33, #-32
    v.movi       v19, #0
    s.sub        s15, s60, s59
    s.add        s22, s57, s59
    v.splat      v23, s15
    s.shli       s15, s59, #4
    s.addi       s24, s59, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s22, v13]            // index is in elements (ISA sec 9.1)
    s.add        s22, s58, s15
    s.movz       s15, #32
    v.st.b       [s22, #0], v19
    fence.acq_rel.device
    s.mov        s59, s24
    s.cmp.lt     s22, s59, s15
    br.nz        s22, x8dot_row_47
x8dot_done_46:
    v.splat      v19, s56
    v.movi       v23, #0
    v.splat      v24, s56
    v.movi       v25, #0
    mb.arm       s15, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s22, #0
    s.movz       s24, #0
    v.extract    s32, v4, #5
    s.movz       s34, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s35, s22                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s24                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s35, s15            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s15          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s15
    mb.arm       s22, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s24, v3, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s22
    mb.wait      s22
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s24, x8dot_done_48
    s.movz       s32, #0
    s.add        s34, s7, s20
    s.addi       s35, s32, #0
    s.addi       s32, s34, #32
    s.addi       s34, s23, #256
x8dot_row_49:
    s.addi       s36, s33, #-32
    v.movi       v19, #0
    s.sub        s37, s36, s35
    s.add        s36, s32, s35
    v.splat      v23, s37
    s.shli       s37, s35, #4
    s.addi       s38, s35, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s36, v14]            // index is in elements (ISA sec 9.1)
    s.add        s36, s34, s37
    s.movz       s37, #32
    v.st.b       [s36, #0], v19
    fence.acq_rel.device
    s.mov        s35, s38
    s.cmp.lt     s36, s35, s37
    br.nz        s36, x8dot_row_49
x8dot_done_48:
    v.splat      v19, s24
    v.movi       v23, #0
    v.splat      v24, s24
    v.movi       v25, #0
    mb.arm       s24, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    s.movz       s34, #0
    v.extract    s35, v4, #6
    s.movz       s36, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s24            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s24          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s24
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v3, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s32
    mb.wait      s32
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s34, x8dot_done_50
    s.movz       s35, #0
    s.add        s36, s7, s20
    s.addi       s37, s35, #0
    s.addi       s35, s36, #32
    s.addi       s36, s23, #256
x8dot_row_51:
    s.addi       s38, s33, #-32
    v.movi       v19, #0
    s.sub        s39, s38, s37
    s.add        s38, s35, s37
    v.splat      v23, s39
    s.shli       s39, s37, #4
    s.addi       s40, s37, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s38, v15]            // index is in elements (ISA sec 9.1)
    s.add        s38, s36, s39
    s.movz       s39, #32
    v.st.b       [s38, #0], v19
    fence.acq_rel.device
    s.mov        s37, s40
    s.cmp.lt     s38, s37, s39
    br.nz        s38, x8dot_row_51
x8dot_done_50:
    s.movz       s35, #0
    v.extract    s36, v16, #0
    s.add        s37, s35, s27                   // the tile origin
    s.movz       s35, #0
    v.splat      v19, s34
    v.movi       v23, #0
    v.splat      v24, s34
    v.movi       v25, #0
    v.splat      v26, s37
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.add        s37, s36, s18
    s.add        s36, s35, s31                   // the tile origin
    s.movz       s35, #0
    s.movz       s38, #0
    v.extract    s39, v4, #7
    s.movz       s40, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.addi       s41, s37, #64
    v.add        v19, v2, v26
    v.splat      v23, s36
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s36, s16, s41
    v.cmp.lt     p1, v19, v23
    m.mma.async.k32.e4m3 a15, v48, v56, s35
    mb.wait      s35
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s36, #0]
    v.extract    s36, v16, #1
    s.addi       s37, s23, #2048                 // 512 bytes of repack scratch
    s.add        s38, s36, s18
    s.addi       s36, s37, #0
    s.addi       s39, s38, #64
    v.extract    s38, v16, #2
    s.add        s40, s16, s39
    s.add        s39, s38, s18
    s.addi       s38, s37, #32
    s.addi       s41, s39, #64
    v.extract    s39, v16, #3
    v.st.b       [s36, #0], v19
    s.add        s36, s16, s41
    s.add        s41, s39, s18
    s.addi       s39, s37, #64
    s.addi       s42, s41, #64
    v.extract    s41, v16, #4
    s.add        s43, s16, s42
    s.add        s42, s41, s18
    s.addi       s41, s42, #64
    s.add        s42, s16, s41
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s40, #0]
    s.addi       s40, s37, #96
    v.st.b       [s38, #0], v19
    v.extract    s38, v16, #5
    s.add        s41, s38, s18
    s.addi       s38, s41, #64
    s.add        s41, s16, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s36, #0]
    s.addi       s36, s37, #128
    v.st.b       [s39, #0], v19
    v.extract    s38, v16, #6
    s.add        s39, s38, s18
    s.addi       s38, s39, #64
    s.add        s39, s16, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s43, #0]
    s.addi       s38, s37, #160
    v.st.b       [s40, #0], v19
    v.extract    s40, v16, #7
    s.add        s43, s40, s18
    s.addi       s40, s43, #64
    s.add        s43, s16, s40
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s42, #0]
    s.addi       s40, s37, #192
    v.st.b       [s36, #0], v19
    v.extract    s36, v16, #8
    s.add        s42, s36, s18
    s.addi       s36, s42, #64
    s.add        s42, s16, s36
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s41, #0]
    s.addi       s36, s37, #224
    v.st.b       [s38, #0], v19
    v.extract    s38, v16, #9
    s.add        s41, s38, s18
    s.addi       s38, s41, #64
    s.add        s41, s16, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s39, #0]
    s.addi       s38, s37, #256
    v.st.b       [s40, #0], v19
    v.extract    s39, v16, #10
    s.add        s40, s39, s18
    s.addi       s39, s40, #64
    s.add        s40, s16, s39
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s43, #0]
    s.addi       s39, s37, #288
    v.st.b       [s36, #0], v19
    v.extract    s36, v16, #11
    s.add        s43, s36, s18
    s.addi       s36, s43, #64
    s.add        s43, s16, s36
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s42, #0]
    s.addi       s36, s37, #320
    v.st.b       [s38, #0], v19
    v.extract    s38, v16, #12
    s.add        s42, s38, s18
    s.addi       s38, s42, #64
    s.add        s42, s16, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s41, #0]
    s.addi       s38, s37, #352
    v.st.b       [s39, #0], v19
    v.extract    s39, v16, #13
    s.add        s41, s39, s18
    s.addi       s39, s41, #64
    s.add        s41, s16, s39
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s40, #0]
    s.addi       s39, s37, #384
    v.st.b       [s36, #0], v19
    v.extract    s36, v16, #14
    s.add        s40, s36, s18
    s.addi       s36, s40, #64
    s.add        s40, s16, s36
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s43, #0]
    s.addi       s36, s37, #416
    v.st.b       [s38, #0], v19
    v.extract    s38, v16, #15
    s.add        s43, s38, s18
    s.addi       s38, s43, #64
    s.add        s43, s16, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s42, #0]
    s.addi       s38, s37, #448
    v.st.b       [s39, #0], v19
    s.movz       s39, #0
    s.add        s42, s39, s28                   // the tile origin
    v.splat      v19, s42
    v.extract    s39, v16, #0
    s.add        s42, s39, s18
    v.add        v23, v2, v19
    s.addi       s39, s42, #80
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s41, #0]
    s.movz       s41, #0
    s.add        s42, s16, s39
    s.add        s39, s41, s31                   // the tile origin
    v.splat      v24, s39
    s.addi       s39, s37, #480
    v.cmp.lt     p2, v23, v24
    v.st.b       [s36, #0], v19
    v.extract    s36, v16, #1
    s.add        s41, s36, s18
    s.addi       s36, s41, #80
    s.add        s41, s16, s36
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s40, #0]
    s.addi       s36, s37, #16
    v.st.b       [s38, #0], v19
    v.extract    s38, v16, #2
    s.add        s40, s38, s18
    s.addi       s38, s40, #80
    s.add        s40, s16, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s43, #0]
    s.addi       s38, s37, #48
    v.st.b       [s39, #0], v19
    v.extract    s39, v16, #3
    s.add        s43, s39, s18
    s.addi       s39, s43, #80
    s.add        s43, s16, s39
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s42, #0]
    s.addi       s39, s37, #80
    v.st.b       [s36, #0], v19
    v.extract    s36, v16, #4
    s.add        s42, s36, s18
    s.addi       s36, s42, #80
    s.add        s42, s16, s36
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s41, #0]
    s.addi       s36, s37, #112
    v.st.b       [s38, #0], v19
    v.extract    s38, v16, #5
    s.add        s41, s38, s18
    s.addi       s38, s41, #80
    s.add        s41, s16, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s40, #0]
    s.addi       s38, s37, #144
    v.st.b       [s39, #0], v19
    v.extract    s39, v16, #6
    s.add        s40, s39, s18
    s.addi       s39, s40, #80
    s.add        s40, s16, s39
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s43, #0]
    s.addi       s39, s37, #176
    v.st.b       [s36, #0], v19
    v.extract    s36, v16, #7
    s.add        s43, s36, s18
    s.addi       s36, s43, #80
    s.add        s43, s16, s36
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s42, #0]
    s.addi       s36, s37, #208
    v.st.b       [s38, #0], v19
    v.extract    s38, v16, #8
    s.add        s42, s38, s18
    s.addi       s38, s42, #80
    s.add        s42, s16, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s41, #0]
    s.addi       s38, s37, #240
    v.st.b       [s39, #0], v19
    v.extract    s39, v16, #9
    s.add        s41, s39, s18
    s.addi       s39, s41, #80
    s.add        s41, s16, s39
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s40, #0]
    s.addi       s39, s37, #272
    v.st.b       [s36, #0], v19
    v.extract    s36, v16, #10
    s.add        s40, s36, s18
    s.addi       s36, s40, #80
    s.add        s40, s16, s36
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s43, #0]
    s.addi       s36, s37, #304
    v.st.b       [s38, #0], v19
    v.extract    s38, v16, #11
    s.add        s43, s38, s18
    s.addi       s38, s43, #80
    s.add        s43, s16, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s42, #0]
    s.addi       s38, s37, #336
    v.st.b       [s39, #0], v19
    v.extract    s39, v16, #12
    s.add        s42, s39, s18
    s.addi       s39, s42, #80
    s.add        s42, s16, s39
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s41, #0]
    s.addi       s39, s37, #368
    v.st.b       [s36, #0], v19
    v.extract    s36, v16, #13
    s.add        s41, s36, s18
    s.addi       s36, s41, #80
    s.add        s41, s16, s36
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s40, #0]
    s.addi       s36, s37, #400
    v.st.b       [s38, #0], v19
    v.extract    s38, v16, #14
    s.add        s40, s38, s18
    s.addi       s38, s40, #80
    s.add        s40, s16, s38
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s43, #0]
    s.addi       s38, s37, #432
    v.st.b       [s39, #0], v19
    v.extract    s39, v16, #15
    s.add        s43, s39, s18
    s.addi       s39, s43, #80
    s.add        s43, s16, s39
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s42, #0]
    s.addi       s39, s37, #464
    v.st.b       [s36, #0], v19
    s.addi       s36, s37, #496
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s41, #0]
    s.addi       s41, s37, #64
    v.st.b       [s38, #0], v19
    s.addi       s38, s37, #128
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s40, #0]
    s.addi       s40, s37, #192
    v.st.b       [s39, #0], v19
    s.addi       s39, s37, #256
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p2 v.ld.b       v19, [s43, #0]
    s.addi       s42, s37, #320
    v.st.b       [s36, #0], v19
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s36, s37, #384
    v.ld.w       v19, [s37, #0]
    s.addi       s43, s37, #448
    v.mov        v48, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s41, #0]
    v.extract    s37, v3, #0
    v.mov        v49, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s38, #0]
    v.mov        v50, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s40, #0]
    v.mov        v51, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s39, #0]
    v.mov        v52, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s42, #0]
    v.mov        v53, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s36, #0]
    v.mov        v54, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s43, #0]
    v.mov        v55, v19                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_52
    s.movz       s36, #0
    s.add        s38, s7, s20
    s.addi       s39, s36, #0
    s.addi       s36, s38, #64
    s.addi       s38, s23, #256
x8dot_row_53:
    s.addi       s40, s33, #-64
    v.movi       v19, #0
    s.sub        s41, s40, s39
    s.add        s40, s36, s39
    v.splat      v23, s41
    s.shli       s41, s39, #4
    s.addi       s42, s39, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s40, v20]            // index is in elements (ISA sec 9.1)
    s.add        s40, s38, s41
    s.movz       s41, #32
    v.st.b       [s40, #0], v19
    fence.acq_rel.device
    s.mov        s39, s42
    s.cmp.lt     s40, s39, s41
    br.nz        s40, x8dot_row_53
x8dot_done_52:
    v.splat      v19, s37
    v.movi       v23, #0
    v.splat      v24, s37
    v.movi       v25, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    s.movz       s38, #0
    v.extract    s39, v4, #0
    s.movz       s40, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v3, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s38, x8dot_done_54
    s.movz       s39, #0
    s.add        s40, s7, s20
    s.addi       s41, s39, #0
    s.addi       s39, s40, #64
    s.addi       s40, s23, #256
x8dot_row_55:
    s.addi       s42, s33, #-64
    v.movi       v19, #0
    s.sub        s43, s42, s41
    s.add        s42, s39, s41
    v.splat      v23, s43
    s.shli       s43, s41, #4
    s.addi       s44, s41, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s42, v5]             // index is in elements (ISA sec 9.1)
    s.add        s42, s40, s43
    s.movz       s43, #32
    v.st.b       [s42, #0], v19
    fence.acq_rel.device
    s.mov        s41, s44
    s.cmp.lt     s42, s41, s43
    br.nz        s42, x8dot_row_55
x8dot_done_54:
    v.splat      v19, s38
    v.movi       v23, #0
    v.splat      v24, s38
    v.movi       v25, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    s.movz       s40, #0
    v.extract    s41, v4, #1
    s.movz       s42, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v3, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s40, x8dot_done_56
    s.movz       s41, #0
    s.add        s42, s7, s20
    s.addi       s43, s41, #0
    s.addi       s41, s42, #64
    s.addi       s42, s23, #256
x8dot_row_57:
    s.addi       s44, s33, #-64
    v.movi       v19, #0
    s.sub        s45, s44, s43
    s.add        s44, s41, s43
    v.splat      v23, s45
    s.shli       s45, s43, #4
    s.addi       s46, s43, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s44, v22]            // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.movz       s45, #32
    v.st.b       [s44, #0], v19
    fence.acq_rel.device
    s.mov        s43, s46
    s.cmp.lt     s44, s43, s45
    br.nz        s44, x8dot_row_57
x8dot_done_56:
    v.splat      v19, s40
    v.movi       v23, #0
    v.splat      v24, s40
    v.movi       v25, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    s.movz       s42, #0
    v.extract    s43, v4, #2
    s.movz       s44, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v3, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s42, x8dot_done_58
    s.movz       s43, #0
    s.add        s44, s7, s20
    s.addi       s45, s43, #0
    s.addi       s43, s44, #64
    s.addi       s44, s23, #256
x8dot_row_59:
    s.addi       s46, s33, #-64
    v.movi       v19, #0
    s.sub        s47, s46, s45
    s.add        s46, s43, s45
    v.splat      v23, s47
    s.shli       s47, s45, #4
    s.addi       s48, s45, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s46, v12]            // index is in elements (ISA sec 9.1)
    s.add        s46, s44, s47
    s.movz       s47, #32
    v.st.b       [s46, #0], v19
    fence.acq_rel.device
    s.mov        s45, s48
    s.cmp.lt     s46, s45, s47
    br.nz        s46, x8dot_row_59
x8dot_done_58:
    v.splat      v19, s42
    v.movi       v23, #0
    v.splat      v24, s42
    v.movi       v25, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    s.movz       s44, #0
    v.extract    s45, v4, #3
    s.movz       s46, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s47, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v3, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s43
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s44, x8dot_done_60
    s.movz       s45, #0
    s.add        s46, s7, s20
    s.addi       s47, s45, #0
    s.addi       s45, s46, #64
    s.addi       s46, s23, #256
x8dot_row_61:
    s.addi       s48, s33, #-64
    v.movi       v19, #0
    s.sub        s49, s48, s47
    s.add        s48, s45, s47
    v.splat      v23, s49
    s.shli       s49, s47, #4
    s.addi       s50, s47, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s48, v8]             // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s49
    s.movz       s49, #32
    v.st.b       [s48, #0], v19
    fence.acq_rel.device
    s.mov        s47, s50
    s.cmp.lt     s48, s47, s49
    br.nz        s48, x8dot_row_61
x8dot_done_60:
    v.splat      v19, s44
    v.movi       v23, #0
    v.splat      v24, s44
    v.movi       v25, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    s.movz       s46, #0
    v.extract    s47, v4, #4
    s.movz       s48, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s49, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v3, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s45
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s46, x8dot_done_62
    s.movz       s47, #0
    s.add        s48, s7, s20
    s.addi       s49, s47, #0
    s.addi       s47, s48, #64
    s.addi       s48, s23, #256
x8dot_row_63:
    s.addi       s50, s33, #-64
    v.movi       v19, #0
    s.sub        s51, s50, s49
    s.add        s50, s47, s49
    v.splat      v23, s51
    s.shli       s51, s49, #4
    s.addi       s52, s49, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s50, v13]            // index is in elements (ISA sec 9.1)
    s.add        s50, s48, s51
    s.movz       s51, #32
    v.st.b       [s50, #0], v19
    fence.acq_rel.device
    s.mov        s49, s52
    s.cmp.lt     s50, s49, s51
    br.nz        s50, x8dot_row_63
x8dot_done_62:
    v.splat      v19, s46
    v.movi       v23, #0
    v.splat      v24, s46
    v.movi       v25, #0
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    s.movz       s48, #0
    v.extract    s49, v4, #5
    s.movz       s50, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s51, s46            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s47, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v3, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s48, x8dot_done_64
    s.movz       s49, #0
    s.add        s50, s7, s20
    s.addi       s51, s49, #0
    s.addi       s49, s50, #64
    s.addi       s50, s23, #256
x8dot_row_65:
    s.addi       s52, s33, #-64
    v.movi       v19, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v23, s53
    s.shli       s53, s51, #4
    s.addi       s54, s51, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s52, v14]            // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.movz       s53, #32
    v.st.b       [s52, #0], v19
    fence.acq_rel.device
    s.mov        s51, s54
    s.cmp.lt     s52, s51, s53
    br.nz        s52, x8dot_row_65
x8dot_done_64:
    v.splat      v19, s48
    v.movi       v23, #0
    v.splat      v24, s48
    v.movi       v25, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    s.movz       s50, #0
    v.extract    s51, v4, #6
    s.movz       s52, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v3, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s50, x8dot_done_66
    s.movz       s51, #0
    s.add        s52, s7, s20
    s.addi       s53, s51, #0
    s.addi       s51, s52, #64
    s.addi       s52, s23, #256
x8dot_row_67:
    s.addi       s54, s33, #-64
    v.movi       v19, #0
    s.sub        s55, s54, s53
    s.add        s54, s51, s53
    v.splat      v23, s55
    s.shli       s55, s53, #4
    s.addi       s56, s53, #1
    v.cmp.gt     p1, v23, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s54, v15]            // index is in elements (ISA sec 9.1)
    s.add        s54, s52, s55
    s.movz       s55, #32
    v.st.b       [s54, #0], v19
    fence.acq_rel.device
    s.mov        s53, s56
    s.cmp.lt     s54, s53, s55
    br.nz        s54, x8dot_row_67
x8dot_done_66:
    s.movz       s51, #0
    v.extract    s52, v16, #0
    s.add        s53, s51, s29                   // the tile origin
    s.movz       s51, #0
    v.splat      v19, s50
    v.movi       v23, #0
    v.splat      v24, s50
    v.movi       v25, #0
    v.splat      v26, s53
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.add        s53, s52, s18
    s.add        s52, s51, s31                   // the tile origin
    s.movz       s51, #0
    s.movz       s54, #0
    v.extract    s55, v4, #7
    s.movz       s56, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v24, v25
    s.addi       s57, s53, #96
    v.add        v19, v2, v26
    v.splat      v23, s52
    s.mov        s52, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s52, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s52, s16, s57
    v.cmp.lt     p1, v19, v23
    m.mma.async.k32.e4m3 a15, v48, v56, s51
    mb.wait      s51
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s52, #0]
    v.extract    s52, v16, #1
    s.addi       s53, s23, #2560                 // 512 bytes of repack scratch
    s.add        s54, s52, s18
    s.addi       s52, s53, #0
    s.addi       s55, s54, #96
    v.extract    s54, v16, #2
    s.add        s56, s16, s55
    s.add        s55, s54, s18
    s.addi       s54, s53, #32
    s.addi       s57, s55, #96
    v.extract    s55, v16, #3
    v.st.b       [s52, #0], v19
    s.add        s52, s16, s57
    s.add        s57, s55, s18
    s.addi       s55, s53, #64
    s.addi       s58, s57, #96
    v.extract    s57, v16, #4
    s.add        s59, s16, s58
    s.add        s58, s57, s18
    s.addi       s57, s58, #96
    s.add        s58, s16, s57
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s56, #0]
    s.addi       s56, s53, #96
    v.st.b       [s54, #0], v19
    v.extract    s54, v16, #5
    s.add        s57, s54, s18
    s.addi       s54, s57, #96
    s.add        s57, s16, s54
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s52, #0]
    s.addi       s52, s53, #128
    v.st.b       [s55, #0], v19
    v.extract    s54, v16, #6
    s.add        s55, s54, s18
    s.addi       s54, s55, #96
    s.add        s55, s16, s54
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s59, #0]
    s.addi       s54, s53, #160
    v.st.b       [s56, #0], v19
    v.extract    s56, v16, #7
    s.add        s59, s56, s18
    s.addi       s56, s59, #96
    s.add        s59, s16, s56
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s58, #0]
    s.addi       s56, s53, #192
    v.st.b       [s52, #0], v19
    v.extract    s52, v16, #8
    s.add        s58, s52, s18
    s.addi       s52, s58, #96
    s.add        s58, s16, s52
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s57, #0]
    s.addi       s52, s53, #224
    v.st.b       [s54, #0], v19
    v.extract    s54, v16, #9
    s.add        s57, s54, s18
    s.addi       s54, s57, #96
    s.add        s57, s16, s54
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s55, #0]
    s.addi       s54, s53, #256
    v.st.b       [s56, #0], v19
    v.extract    s55, v16, #10
    s.add        s56, s55, s18
    s.addi       s55, s56, #96
    s.add        s56, s16, s55
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s59, #0]
    s.addi       s55, s53, #288
    v.st.b       [s52, #0], v19
    v.extract    s52, v16, #11
    s.add        s59, s52, s18
    s.addi       s52, s59, #96
    s.add        s59, s16, s52
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s58, #0]
    s.addi       s52, s53, #320
    v.st.b       [s54, #0], v19
    v.extract    s54, v16, #12
    s.add        s58, s54, s18
    s.addi       s54, s58, #96
    s.add        s58, s16, s54
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s57, #0]
    s.addi       s54, s53, #352
    v.st.b       [s55, #0], v19
    v.extract    s55, v16, #13
    s.add        s57, s55, s18
    s.addi       s55, s57, #96
    s.add        s57, s16, s55
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s56, #0]
    s.addi       s55, s53, #384
    v.st.b       [s52, #0], v19
    v.extract    s52, v16, #14
    s.add        s56, s52, s18
    s.addi       s52, s56, #96
    s.add        s56, s16, s52
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s59, #0]
    s.addi       s52, s53, #416
    v.st.b       [s54, #0], v19
    v.extract    s54, v16, #15
    s.add        s59, s54, s18
    s.addi       s54, s59, #96
    s.add        s59, s16, s54
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v19, [s58, #0]
    s.addi       s54, s53, #448
    v.st.b       [s55, #0], v19
    s.movz       s55, #0
    s.add        s58, s55, s30                   // the tile origin
    v.splat      v19, s58
    v.extract    s55, v16, #0
    s.add        s58, s55, s18
    v.add        v23, v2, v19
    s.addi       s55, s58, #112
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s57, #0]
    s.movz       s57, #0
    s.add        s58, s16, s55
    s.add        s55, s57, s31                   // the tile origin
    s.addi       s31, s53, #480
    v.splat      v19, s55
    v.extract    s55, v16, #1
    v.cmp.lt     p2, v23, v19
    s.add        s57, s55, s18
    s.addi       s55, s57, #112
    v.st.b       [s52, #0], v2
    s.addi       s52, s53, #16
    s.add        s57, s16, s55
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s56, #0]
    v.extract    s55, v16, #2
    s.add        s56, s55, s18
    s.addi       s55, s56, #112
    s.add        s56, s16, s55
    v.st.b       [s54, #0], v2
    s.addi       s54, s53, #48
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s59, #0]
    v.extract    s55, v16, #3
    s.add        s59, s55, s18
    s.addi       s55, s59, #112
    s.add        s59, s16, s55
    v.st.b       [s31, #0], v2
    s.addi       s31, s53, #80
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s58, #0]
    v.extract    s55, v16, #4
    s.add        s58, s55, s18
    s.addi       s55, s58, #112
    s.add        s58, s16, s55
    v.st.b       [s52, #0], v2
    s.addi       s52, s53, #112
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s57, #0]
    v.extract    s55, v16, #5
    s.add        s57, s55, s18
    s.addi       s55, s57, #112
    s.add        s57, s16, s55
    v.st.b       [s54, #0], v2
    s.addi       s54, s53, #144
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s56, #0]
    v.extract    s55, v16, #6
    s.add        s56, s55, s18
    s.addi       s55, s56, #112
    s.add        s56, s16, s55
    v.st.b       [s31, #0], v2
    s.addi       s31, s53, #176
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s59, #0]
    v.extract    s55, v16, #7
    s.add        s59, s55, s18
    s.addi       s55, s59, #112
    s.add        s59, s16, s55
    v.st.b       [s52, #0], v2
    s.addi       s52, s53, #208
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s58, #0]
    v.extract    s55, v16, #8
    s.add        s58, s55, s18
    s.addi       s55, s58, #112
    s.add        s58, s16, s55
    v.st.b       [s54, #0], v2
    s.addi       s54, s53, #240
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s57, #0]
    v.extract    s55, v16, #9
    s.add        s57, s55, s18
    s.addi       s55, s57, #112
    s.add        s57, s16, s55
    v.st.b       [s31, #0], v2
    s.addi       s31, s53, #272
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s56, #0]
    v.extract    s55, v16, #10
    s.add        s56, s55, s18
    s.addi       s55, s56, #112
    s.add        s56, s16, s55
    v.st.b       [s52, #0], v2
    s.addi       s52, s53, #304
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s59, #0]
    v.extract    s55, v16, #11
    s.add        s59, s55, s18
    s.addi       s55, s59, #112
    s.add        s59, s16, s55
    v.st.b       [s54, #0], v2
    s.addi       s54, s53, #336
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s58, #0]
    v.extract    s55, v16, #12
    s.add        s58, s55, s18
    s.addi       s55, s58, #112
    s.add        s58, s16, s55
    v.st.b       [s31, #0], v2
    s.addi       s31, s53, #368
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s57, #0]
    v.extract    s55, v16, #13
    s.add        s57, s55, s18
    s.addi       s55, s57, #112
    s.add        s57, s16, s55
    v.st.b       [s52, #0], v2
    s.addi       s52, s53, #400
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s56, #0]
    v.extract    s55, v16, #14
    s.add        s56, s55, s18
    s.addi       s55, s56, #112
    s.add        s56, s16, s55
    v.st.b       [s54, #0], v2
    s.addi       s54, s53, #432
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s59, #0]
    v.extract    s55, v16, #15
    s.add        s59, s55, s18
    s.addi       s55, s59, #112
    s.add        s59, s16, s55
    v.st.b       [s31, #0], v2
    s.addi       s31, s53, #464
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s58, #0]
    s.addi       s55, s53, #496
    v.st.b       [s52, #0], v2
    s.addi       s52, s53, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s57, #0]
    s.addi       s57, s53, #128
    v.st.b       [s54, #0], v2
    s.addi       s54, s53, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s56, #0]
    s.addi       s56, s53, #256
    v.st.b       [s31, #0], v2
    s.addi       s31, s53, #320
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.b       v2, [s59, #0]
    s.addi       s58, s53, #384
    v.st.b       [s55, #0], v2
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s55, s53, #448
    v.ld.w       v2, [s53, #0]
    v.extract    s53, v3, #0
    v.mov        v48, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s52, #0]
    v.mov        v49, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s57, #0]
    v.mov        v50, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s54, #0]
    v.mov        v51, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s56, #0]
    v.mov        v52, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s31, #0]
    v.mov        v53, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s58, #0]
    v.mov        v54, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s55, #0]
    v.mov        v55, v2                         // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s53, x8dot_done_68
    s.movz       s31, #0
    s.add        s52, s7, s20
    s.addi       s54, s31, #0
    s.addi       s31, s52, #96
    s.addi       s52, s23, #256
x8dot_row_69:
    s.addi       s55, s33, #-96
    v.movi       v2, #0
    s.sub        s56, s55, s54
    s.add        s55, s31, s54
    v.splat      v16, s56
    s.shli       s56, s54, #4
    s.addi       s57, s54, #1
    v.cmp.gt     p1, v16, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s55, v20]             // index is in elements (ISA sec 9.1)
    s.add        s55, s52, s56
    s.movz       s56, #32
    v.st.b       [s55, #0], v2
    fence.acq_rel.device
    s.mov        s54, s57
    s.cmp.lt     s55, s54, s56
    br.nz        s55, x8dot_row_69
x8dot_done_68:
    v.splat      v2, s53
    v.movi       v16, #0
    v.splat      v19, s53
    v.movi       v20, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    s.movz       s53, #0
    v.extract    s54, v4, #0
    s.movz       s55, #96
    v.cmp.ne     p1, v2, v16
    v.cmp.eq     p2, v19, v20
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s56, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s52, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v3, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s52
    mb.wait      s52
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s53, x8dot_done_70
    s.movz       s54, #0
    s.add        s55, s7, s20
    s.addi       s56, s54, #0
    s.addi       s54, s55, #96
    s.addi       s55, s23, #256
x8dot_row_71:
    s.addi       s57, s33, #-96
    v.movi       v2, #0
    s.sub        s58, s57, s56
    s.add        s57, s54, s56
    v.splat      v16, s58
    s.shli       s58, s56, #4
    s.addi       s59, s56, #1
    v.cmp.gt     p1, v16, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s57, v5]              // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.movz       s58, #32
    v.st.b       [s57, #0], v2
    fence.acq_rel.device
    s.mov        s56, s59
    s.cmp.lt     s57, s56, s58
    br.nz        s57, x8dot_row_71
x8dot_done_70:
    v.splat      v2, s53
    v.movi       v5, #0
    v.splat      v16, s53
    v.movi       v19, #0
    mb.arm       s53, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    s.movz       s55, #0
    v.extract    s56, v4, #1
    s.movz       s57, #96
    v.cmp.ne     p1, v2, v5
    v.cmp.eq     p2, v16, v19
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s59, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s58, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s56                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s57                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s54, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v3, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s54
    mb.wait      s54
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s55, x8dot_done_72
    s.movz       s56, #0
    s.add        s57, s7, s20
    s.addi       s58, s56, #0
    s.addi       s56, s57, #96
    s.addi       s57, s23, #256
x8dot_row_73:
    s.addi       s59, s33, #-96
    v.movi       v2, #0
    s.sub        s60, s59, s58
    s.add        s59, s56, s58
    v.splat      v5, s60
    s.shli       s60, s58, #4
    s.addi       s15, s58, #1
    v.cmp.gt     p1, v5, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s59, v22]             // index is in elements (ISA sec 9.1)
    s.add        s22, s57, s60
    s.movz       s24, #32
    v.st.b       [s22, #0], v2
    fence.acq_rel.device
    s.mov        s58, s15
    s.cmp.lt     s15, s58, s24
    br.nz        s15, x8dot_row_73
x8dot_done_72:
    v.splat      v2, s55
    v.movi       v5, #0
    v.splat      v16, s55
    v.movi       v19, #0
    mb.arm       s15, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s22, #0
    s.movz       s24, #0
    v.extract    s31, v4, #2
    s.movz       s32, #96
    v.cmp.ne     p1, v2, v5
    v.cmp.eq     p2, v16, v19
    s.mov        s34, s22                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s24                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s15            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s15          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s15
    mb.arm       s22, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s24, v3, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s22
    mb.wait      s22
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s24, x8dot_done_74
    s.movz       s31, #0
    s.add        s32, s7, s20
    s.addi       s34, s31, #0
    s.addi       s31, s32, #96
    s.addi       s32, s23, #256
x8dot_row_75:
    s.addi       s35, s33, #-96
    v.movi       v2, #0
    s.sub        s36, s35, s34
    s.add        s35, s31, s34
    v.splat      v5, s36
    s.shli       s36, s34, #4
    s.addi       s37, s34, #1
    v.cmp.gt     p1, v5, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s35, v12]             // index is in elements (ISA sec 9.1)
    s.add        s35, s32, s36
    s.movz       s36, #32
    v.st.b       [s35, #0], v2
    fence.acq_rel.device
    s.mov        s34, s37
    s.cmp.lt     s35, s34, s36
    br.nz        s35, x8dot_row_75
x8dot_done_74:
    v.splat      v2, s24
    v.movi       v5, #0
    v.splat      v12, s24
    v.movi       v16, #0
    mb.arm       s24, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s31, #0
    s.movz       s32, #0
    v.extract    s34, v4, #3
    s.movz       s35, #96
    v.cmp.ne     p1, v2, v5
    v.cmp.eq     p2, v12, v16
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s24            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s31, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s31, s24          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s24
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s32, v3, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s32, x8dot_done_76
    s.movz       s34, #0
    s.add        s35, s7, s20
    s.addi       s36, s34, #0
    s.addi       s34, s35, #96
    s.addi       s35, s23, #256
x8dot_row_77:
    s.addi       s37, s33, #-96
    v.movi       v2, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v5, s38
    s.shli       s38, s36, #4
    s.addi       s39, s36, #1
    v.cmp.gt     p1, v5, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s37, v8]              // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v2
    fence.acq_rel.device
    s.mov        s36, s39
    s.cmp.lt     s37, s36, s38
    br.nz        s37, x8dot_row_77
x8dot_done_76:
    v.splat      v2, s32
    v.movi       v5, #0
    v.splat      v8, s32
    v.movi       v12, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    s.movz       s35, #0
    v.extract    s36, v4, #4
    s.movz       s37, #96
    v.cmp.ne     p1, v2, v5
    v.cmp.eq     p2, v8, v12
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v3, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s34
    mb.wait      s34
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_78
    s.movz       s36, #0
    s.add        s37, s7, s20
    s.addi       s38, s36, #0
    s.addi       s36, s37, #96
    s.addi       s37, s23, #256
x8dot_row_79:
    s.addi       s39, s33, #-96
    v.movi       v2, #0
    s.sub        s40, s39, s38
    s.add        s39, s36, s38
    v.splat      v5, s40
    s.shli       s40, s38, #4
    s.addi       s41, s38, #1
    v.cmp.gt     p1, v5, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s39, v13]             // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.movz       s40, #32
    v.st.b       [s39, #0], v2
    fence.acq_rel.device
    s.mov        s38, s41
    s.cmp.lt     s39, s38, s40
    br.nz        s39, x8dot_row_79
x8dot_done_78:
    v.splat      v2, s35
    v.movi       v5, #0
    v.splat      v8, s35
    v.movi       v12, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    s.movz       s37, #0
    v.extract    s38, v4, #5
    s.movz       s39, #96
    v.cmp.ne     p1, v2, v5
    v.cmp.eq     p2, v8, v12
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v3, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s36
    mb.wait      s36
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_80
    s.movz       s38, #0
    s.add        s39, s7, s20
    s.addi       s40, s38, #0
    s.addi       s38, s39, #96
    s.addi       s39, s23, #256
x8dot_row_81:
    s.addi       s41, s33, #-96
    v.movi       v2, #0
    s.sub        s42, s41, s40
    s.add        s41, s38, s40
    v.splat      v5, s42
    s.shli       s42, s40, #4
    s.addi       s43, s40, #1
    v.cmp.gt     p1, v5, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s41, v14]             // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v2
    fence.acq_rel.device
    s.mov        s40, s43
    s.cmp.lt     s41, s40, s42
    br.nz        s41, x8dot_row_81
x8dot_done_80:
    v.splat      v2, s37
    v.movi       v5, #0
    v.splat      v8, s37
    v.movi       v12, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    s.movz       s39, #0
    v.extract    s40, v4, #6
    s.movz       s41, #96
    v.cmp.ne     p1, v2, v5
    v.cmp.eq     p2, v8, v12
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v3, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s38
    mb.wait      s38
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s39, x8dot_done_82
    s.movz       s40, #0
    s.add        s41, s7, s20
    s.addi       s42, s40, #0
    s.addi       s40, s41, #96
    s.addi       s41, s23, #256
x8dot_row_83:
    s.addi       s43, s33, #-96
    v.movi       v2, #0
    s.sub        s44, s43, s42
    s.add        s43, s40, s42
    v.splat      v3, s44
    s.shli       s44, s42, #4
    s.addi       s45, s42, #1
    v.cmp.gt     p1, v3, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v2, [s43, v15]             // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.movz       s44, #32
    v.st.b       [s43, #0], v2
    fence.acq_rel.device
    s.mov        s42, s45
    s.cmp.lt     s43, s42, s44
    br.nz        s43, x8dot_row_83
x8dot_done_82:
    v.splat      v2, s39
    v.movi       v3, #0
    v.splat      v5, s39
    v.movi       v8, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    s.movz       s40, #0
    v.extract    s41, v4, #7
    s.movz       s42, #96
    v.cmp.ne     p1, v2, v3
    v.cmp.eq     p2, v5, v8
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s43, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s39, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s40, #0
    s.addi       s41, s23, #3072
    m.mma.async.k32.e4m3 a15, v48, v56, s39
    mb.wait      s39
    a.vread      v2, a8, s40
    s.movz       s40, #1
    s.addi       s42, s41, #64
    v.st.w       [s41, #0], v2
    a.vread      v2, a8, s40
    s.movz       s40, #2
    s.addi       s43, s41, #128
    s.movz       s44, #3
    s.addi       s45, s41, #192
    s.movz       s46, #4
    v.st.w       [s42, #0], v2
    a.vread      v2, a8, s40
    s.addi       s40, s41, #256
    s.movz       s42, #5
    v.st.w       [s43, #0], v2
    a.vread      v2, a8, s44
    s.addi       s43, s41, #320
    s.movz       s44, #6
    v.st.w       [s45, #0], v2
    a.vread      v2, a8, s46
    s.addi       s45, s41, #384
    s.movz       s46, #7
    v.st.w       [s40, #0], v2
    a.vread      v2, a8, s42
    s.addi       s40, s41, #448
    s.movz       s42, #8
    v.st.w       [s43, #0], v2
    a.vread      v2, a8, s44
    s.addi       s43, s41, #512
    s.movz       s44, #9
    v.st.w       [s45, #0], v2
    a.vread      v2, a8, s46
    s.addi       s45, s41, #576
    s.movz       s46, #10
    v.st.w       [s40, #0], v2
    a.vread      v2, a8, s42
    s.addi       s40, s41, #640
    s.movz       s42, #11
    v.st.w       [s43, #0], v2
    a.vread      v2, a8, s44
    s.addi       s43, s41, #704
    s.movz       s44, #12
    v.st.w       [s45, #0], v2
    a.vread      v2, a8, s46
    s.addi       s45, s41, #768
    s.movz       s46, #13
    v.st.w       [s40, #0], v2
    a.vread      v2, a8, s42
    s.addi       s40, s41, #832
    s.movz       s42, #14
    v.st.w       [s43, #0], v2
    a.vread      v2, a8, s44
    s.addi       s43, s41, #896
    s.movz       s44, #15
    s.addi       s47, s41, #960
    v.st.w       [s45, #0], v2
    a.vread      v2, a8, s46
    s.movz       s41, #0
    s.addi       s45, s23, #4096
    v.st.w       [s40, #0], v2
    a.vread      v2, a8, s42
    s.movz       s40, #1
    s.addi       s42, s45, #64
    v.st.w       [s43, #0], v2
    a.vread      v2, a8, s44
    s.movz       s43, #2
    s.addi       s44, s45, #128
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a9, s41
    s.movz       s41, #3
    s.addi       s46, s45, #192
    v.st.w       [s45, #0], v2
    a.vread      v2, a9, s40
    s.movz       s40, #4
    v.st.w       [s42, #0], v2
    a.vread      v2, a9, s43
    s.addi       s42, s45, #256
    s.movz       s43, #5
    v.st.w       [s44, #0], v2
    a.vread      v2, a9, s41
    s.addi       s41, s45, #320
    s.movz       s44, #6
    v.st.w       [s46, #0], v2
    a.vread      v2, a9, s40
    s.addi       s40, s45, #384
    s.movz       s46, #7
    v.st.w       [s42, #0], v2
    a.vread      v2, a9, s43
    s.addi       s42, s45, #448
    s.movz       s43, #8
    v.st.w       [s41, #0], v2
    a.vread      v2, a9, s44
    s.addi       s41, s45, #512
    s.movz       s44, #9
    v.st.w       [s40, #0], v2
    a.vread      v2, a9, s46
    s.addi       s40, s45, #576
    s.movz       s46, #10
    v.st.w       [s42, #0], v2
    a.vread      v2, a9, s43
    s.addi       s42, s45, #640
    s.movz       s43, #11
    v.st.w       [s41, #0], v2
    a.vread      v2, a9, s44
    s.addi       s41, s45, #704
    s.movz       s44, #12
    v.st.w       [s40, #0], v2
    a.vread      v2, a9, s46
    s.addi       s40, s45, #768
    s.movz       s46, #13
    v.st.w       [s42, #0], v2
    a.vread      v2, a9, s43
    s.addi       s42, s45, #832
    s.movz       s43, #14
    v.st.w       [s41, #0], v2
    a.vread      v2, a9, s44
    s.addi       s41, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.st.w       [s40, #0], v2
    a.vread      v2, a9, s46
    s.movz       s40, #0
    s.addi       s45, s23, #5120
    v.st.w       [s42, #0], v2
    a.vread      v2, a9, s43
    s.movz       s42, #1
    s.addi       s43, s45, #64
    v.st.w       [s41, #0], v2
    a.vread      v2, a9, s44
    s.movz       s41, #2
    s.addi       s44, s45, #128
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a10, s40
    s.movz       s40, #3
    s.addi       s46, s45, #192
    v.st.w       [s45, #0], v2
    a.vread      v2, a10, s42
    s.movz       s42, #4
    v.st.w       [s43, #0], v2
    a.vread      v2, a10, s41
    s.addi       s41, s45, #256
    s.movz       s43, #5
    v.st.w       [s44, #0], v2
    a.vread      v2, a10, s40
    s.addi       s40, s45, #320
    s.movz       s44, #6
    v.st.w       [s46, #0], v2
    a.vread      v2, a10, s42
    s.addi       s42, s45, #384
    s.movz       s46, #7
    v.st.w       [s41, #0], v2
    a.vread      v2, a10, s43
    s.addi       s41, s45, #448
    s.movz       s43, #8
    v.st.w       [s40, #0], v2
    a.vread      v2, a10, s44
    s.addi       s40, s45, #512
    s.movz       s44, #9
    v.st.w       [s42, #0], v2
    a.vread      v2, a10, s46
    s.addi       s42, s45, #576
    s.movz       s46, #10
    v.st.w       [s41, #0], v2
    a.vread      v2, a10, s43
    s.addi       s41, s45, #640
    s.movz       s43, #11
    v.st.w       [s40, #0], v2
    a.vread      v2, a10, s44
    s.addi       s40, s45, #704
    s.movz       s44, #12
    v.st.w       [s42, #0], v2
    a.vread      v2, a10, s46
    s.addi       s42, s45, #768
    s.movz       s46, #13
    v.st.w       [s41, #0], v2
    a.vread      v2, a10, s43
    s.addi       s41, s45, #832
    s.movz       s43, #14
    v.st.w       [s40, #0], v2
    a.vread      v2, a10, s44
    s.addi       s40, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.st.w       [s42, #0], v2
    a.vread      v2, a10, s46
    s.movz       s42, #0
    s.addi       s45, s23, #6144
    v.st.w       [s41, #0], v2
    a.vread      v2, a10, s43
    s.movz       s41, #1
    s.addi       s43, s45, #64
    v.st.w       [s40, #0], v2
    a.vread      v2, a10, s44
    s.movz       s40, #2
    s.addi       s44, s45, #128
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a11, s42
    s.movz       s42, #3
    s.addi       s46, s45, #192
    v.st.w       [s45, #0], v2
    a.vread      v2, a11, s41
    s.movz       s41, #4
    v.st.w       [s43, #0], v2
    a.vread      v2, a11, s40
    s.addi       s40, s45, #256
    s.movz       s43, #5
    v.st.w       [s44, #0], v2
    a.vread      v2, a11, s42
    s.addi       s42, s45, #320
    s.movz       s44, #6
    v.st.w       [s46, #0], v2
    a.vread      v2, a11, s41
    s.addi       s41, s45, #384
    s.movz       s46, #7
    v.st.w       [s40, #0], v2
    a.vread      v2, a11, s43
    s.addi       s40, s45, #448
    s.movz       s43, #8
    v.st.w       [s42, #0], v2
    a.vread      v2, a11, s44
    s.addi       s42, s45, #512
    s.movz       s44, #9
    v.st.w       [s41, #0], v2
    a.vread      v2, a11, s46
    s.addi       s41, s45, #576
    s.movz       s46, #10
    v.st.w       [s40, #0], v2
    a.vread      v2, a11, s43
    s.addi       s40, s45, #640
    s.movz       s43, #11
    v.st.w       [s42, #0], v2
    a.vread      v2, a11, s44
    s.addi       s42, s45, #704
    s.movz       s44, #12
    v.st.w       [s41, #0], v2
    a.vread      v2, a11, s46
    s.addi       s41, s45, #768
    s.movz       s46, #13
    v.st.w       [s40, #0], v2
    a.vread      v2, a11, s43
    s.addi       s40, s45, #832
    s.movz       s43, #14
    v.st.w       [s42, #0], v2
    a.vread      v2, a11, s44
    s.addi       s42, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.st.w       [s41, #0], v2
    a.vread      v2, a11, s46
    s.movz       s41, #0
    s.addi       s45, s23, #7168
    v.st.w       [s40, #0], v2
    a.vread      v2, a11, s43
    s.movz       s40, #1
    s.addi       s43, s45, #64
    v.st.w       [s42, #0], v2
    a.vread      v2, a11, s44
    s.movz       s42, #2
    s.addi       s44, s45, #128
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a12, s41
    s.movz       s41, #3
    s.addi       s46, s45, #192
    v.st.w       [s45, #0], v2
    a.vread      v2, a12, s40
    s.movz       s40, #4
    v.st.w       [s43, #0], v2
    a.vread      v2, a12, s42
    s.addi       s42, s45, #256
    s.movz       s43, #5
    v.st.w       [s44, #0], v2
    a.vread      v2, a12, s41
    s.addi       s41, s45, #320
    s.movz       s44, #6
    v.st.w       [s46, #0], v2
    a.vread      v2, a12, s40
    s.addi       s40, s45, #384
    s.movz       s46, #7
    v.st.w       [s42, #0], v2
    a.vread      v2, a12, s43
    s.addi       s42, s45, #448
    s.movz       s43, #8
    v.st.w       [s41, #0], v2
    a.vread      v2, a12, s44
    s.addi       s41, s45, #512
    s.movz       s44, #9
    v.st.w       [s40, #0], v2
    a.vread      v2, a12, s46
    s.addi       s40, s45, #576
    s.movz       s46, #10
    v.st.w       [s42, #0], v2
    a.vread      v2, a12, s43
    s.addi       s42, s45, #640
    s.movz       s43, #11
    v.st.w       [s41, #0], v2
    a.vread      v2, a12, s44
    s.addi       s41, s45, #704
    s.movz       s44, #12
    v.st.w       [s40, #0], v2
    a.vread      v2, a12, s46
    s.addi       s40, s45, #768
    s.movz       s46, #13
    v.st.w       [s42, #0], v2
    a.vread      v2, a12, s43
    s.addi       s42, s45, #832
    s.movz       s43, #14
    v.st.w       [s41, #0], v2
    a.vread      v2, a12, s44
    s.addi       s41, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.st.w       [s40, #0], v2
    a.vread      v2, a12, s46
    s.movz       s40, #0
    s.addi       s45, s23, #8192
    v.st.w       [s42, #0], v2
    a.vread      v2, a12, s43
    s.movz       s42, #1
    s.addi       s43, s45, #64
    v.st.w       [s41, #0], v2
    a.vread      v2, a12, s44
    s.movz       s41, #2
    s.addi       s44, s45, #128
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a13, s40
    s.movz       s40, #3
    s.addi       s46, s45, #192
    v.st.w       [s45, #0], v2
    a.vread      v2, a13, s42
    s.movz       s42, #4
    v.st.w       [s43, #0], v2
    a.vread      v2, a13, s41
    s.addi       s41, s45, #256
    s.movz       s43, #5
    v.st.w       [s44, #0], v2
    a.vread      v2, a13, s40
    s.addi       s40, s45, #320
    s.movz       s44, #6
    v.st.w       [s46, #0], v2
    a.vread      v2, a13, s42
    s.addi       s42, s45, #384
    s.movz       s46, #7
    v.st.w       [s41, #0], v2
    a.vread      v2, a13, s43
    s.addi       s41, s45, #448
    s.movz       s43, #8
    v.st.w       [s40, #0], v2
    a.vread      v2, a13, s44
    s.addi       s40, s45, #512
    s.movz       s44, #9
    v.st.w       [s42, #0], v2
    a.vread      v2, a13, s46
    s.addi       s42, s45, #576
    s.movz       s46, #10
    v.st.w       [s41, #0], v2
    a.vread      v2, a13, s43
    s.addi       s41, s45, #640
    s.movz       s43, #11
    v.st.w       [s40, #0], v2
    a.vread      v2, a13, s44
    s.addi       s40, s45, #704
    s.movz       s44, #12
    v.st.w       [s42, #0], v2
    a.vread      v2, a13, s46
    s.addi       s42, s45, #768
    s.movz       s46, #13
    v.st.w       [s41, #0], v2
    a.vread      v2, a13, s43
    s.addi       s41, s45, #832
    s.movz       s43, #14
    v.st.w       [s40, #0], v2
    a.vread      v2, a13, s44
    s.addi       s40, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.st.w       [s42, #0], v2
    a.vread      v2, a13, s46
    s.movz       s42, #0
    s.addi       s45, s23, #9216
    v.st.w       [s41, #0], v2
    a.vread      v2, a13, s43
    s.movz       s41, #1
    s.addi       s43, s45, #64
    v.st.w       [s40, #0], v2
    a.vread      v2, a13, s44
    s.movz       s40, #2
    s.addi       s44, s45, #128
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a14, s42
    s.movz       s42, #3
    s.addi       s46, s45, #192
    v.st.w       [s45, #0], v2
    a.vread      v2, a14, s41
    s.movz       s41, #4
    v.st.w       [s43, #0], v2
    a.vread      v2, a14, s40
    s.addi       s40, s45, #256
    s.movz       s43, #5
    v.st.w       [s44, #0], v2
    a.vread      v2, a14, s42
    s.addi       s42, s45, #320
    s.movz       s44, #6
    v.st.w       [s46, #0], v2
    a.vread      v2, a14, s41
    s.addi       s41, s45, #384
    s.movz       s46, #7
    v.st.w       [s40, #0], v2
    a.vread      v2, a14, s43
    s.addi       s40, s45, #448
    s.movz       s43, #8
    v.st.w       [s42, #0], v2
    a.vread      v2, a14, s44
    s.addi       s42, s45, #512
    s.movz       s44, #9
    v.st.w       [s41, #0], v2
    a.vread      v2, a14, s46
    s.addi       s41, s45, #576
    s.movz       s46, #10
    v.st.w       [s40, #0], v2
    a.vread      v2, a14, s43
    s.addi       s40, s45, #640
    s.movz       s43, #11
    v.st.w       [s42, #0], v2
    a.vread      v2, a14, s44
    s.addi       s42, s45, #704
    s.movz       s44, #12
    v.st.w       [s41, #0], v2
    a.vread      v2, a14, s46
    s.addi       s41, s45, #768
    s.movz       s46, #13
    v.st.w       [s40, #0], v2
    a.vread      v2, a14, s43
    s.addi       s40, s45, #832
    s.movz       s43, #14
    v.st.w       [s42, #0], v2
    a.vread      v2, a14, s44
    s.addi       s42, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.st.w       [s41, #0], v2
    a.vread      v2, a14, s46
    s.movz       s41, #0
    s.addi       s45, s23, #10240
    v.st.w       [s40, #0], v2
    a.vread      v2, a14, s43
    s.movz       s40, #1
    s.addi       s43, s45, #64
    v.st.w       [s42, #0], v2
    a.vread      v2, a14, s44
    s.movz       s42, #2
    s.addi       s44, s45, #128
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a15, s41
    s.movz       s41, #3
    s.addi       s46, s45, #192
    v.st.w       [s45, #0], v2
    a.vread      v2, a15, s40
    s.movz       s40, #4
    v.st.w       [s43, #0], v2
    a.vread      v2, a15, s42
    s.addi       s42, s45, #256
    s.movz       s43, #5
    v.st.w       [s44, #0], v2
    a.vread      v2, a15, s41
    s.addi       s41, s45, #320
    s.movz       s44, #6
    v.st.w       [s46, #0], v2
    a.vread      v2, a15, s40
    s.addi       s40, s45, #384
    s.movz       s46, #7
    v.st.w       [s42, #0], v2
    a.vread      v2, a15, s43
    s.addi       s42, s45, #448
    s.movz       s43, #8
    v.st.w       [s41, #0], v2
    a.vread      v2, a15, s44
    s.addi       s41, s45, #512
    s.movz       s44, #9
    v.st.w       [s40, #0], v2
    a.vread      v2, a15, s46
    s.addi       s40, s45, #576
    s.movz       s46, #10
    v.st.w       [s42, #0], v2
    a.vread      v2, a15, s43
    s.addi       s42, s45, #640
    s.movz       s43, #11
    v.st.w       [s41, #0], v2
    a.vread      v2, a15, s44
    s.addi       s41, s45, #704
    s.movz       s44, #12
    v.st.w       [s40, #0], v2
    a.vread      v2, a15, s46
    s.addi       s40, s45, #768
    s.movz       s46, #13
    v.st.w       [s42, #0], v2
    a.vread      v2, a15, s43
    s.addi       s42, s45, #832
    s.movz       s43, #14
    v.st.w       [s41, #0], v2
    a.vread      v2, a15, s44
    s.addi       s41, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.st.w       [s40, #0], v2
    a.vread      v2, a15, s46
    s.movz       s40, #0
    s.addi       s45, s23, #3072
    v.st.w       [s42, #0], v2
    a.vread      v2, a15, s43
    s.addi       s42, s23, #11264
    s.movz       s43, #1
    v.st.w       [s41, #0], v2
    a.vread      v2, a15, s44
    s.addi       s41, s23, #3136
    s.addi       s44, s42, #64
    v.st.w       [s47, #0], v2
    fence.acq_rel.device
    a.vread      v2, a0, s40
    s.movz       s40, #2
    s.addi       s46, s23, #3200
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s42, #128
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a0, s43
    s.movz       s43, #3
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s23, #3264
    vf.add       v4, v2, v3
    v.st.w       [s44, #0], v4
    a.vread      v2, a0, s40
    s.addi       s40, s42, #192
    s.movz       s44, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #3328
    vf.add       v4, v2, v3
    v.st.w       [s45, #0], v4
    a.vread      v2, a0, s43
    s.addi       s43, s42, #256
    s.movz       s45, #5
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s23, #3392
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a0, s44
    s.addi       s40, s42, #320
    s.movz       s44, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #3456
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a0, s45
    s.addi       s43, s42, #384
    s.movz       s45, #7
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s23, #3520
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a0, s44
    s.addi       s40, s42, #448
    s.movz       s44, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #3584
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a0, s45
    s.addi       s43, s42, #512
    s.movz       s45, #9
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s23, #3648
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a0, s44
    s.addi       s40, s42, #576
    s.movz       s44, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #3712
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a0, s45
    s.addi       s43, s42, #640
    s.movz       s45, #11
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s23, #3776
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a0, s44
    s.addi       s40, s42, #704
    s.movz       s44, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #3840
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a0, s45
    s.addi       s43, s42, #768
    s.movz       s45, #13
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s23, #3904
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a0, s44
    s.addi       s40, s42, #832
    s.movz       s44, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #3968
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a0, s45
    s.addi       s43, s42, #896
    s.movz       s45, #15
    s.addi       s47, s42, #960
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s23, #4032
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a0, s44
    s.movz       s40, #0
    s.addi       s42, s23, #4096
    v.ld.w       v3, [s46, #0]
    s.addi       s44, s23, #12288
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a0, s45
    s.movz       s43, #1
    s.addi       s45, s23, #4160
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s44, #64
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    a.vread      v2, a1, s40
    s.movz       s40, #2
    s.addi       s46, s23, #4224
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s44, #128
    vf.add       v4, v2, v3
    v.st.w       [s44, #0], v4
    a.vread      v2, a1, s43
    s.movz       s43, #3
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s23, #4288
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a1, s40
    s.addi       s40, s44, #192
    s.movz       s41, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #4352
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a1, s43
    s.addi       s42, s44, #256
    s.movz       s43, #5
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s23, #4416
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a1, s41
    s.addi       s40, s44, #320
    s.movz       s41, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #4480
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a1, s43
    s.addi       s42, s44, #384
    s.movz       s43, #7
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s23, #4544
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a1, s41
    s.addi       s40, s44, #448
    s.movz       s41, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #4608
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a1, s43
    s.addi       s42, s44, #512
    s.movz       s43, #9
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s23, #4672
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a1, s41
    s.addi       s40, s44, #576
    s.movz       s41, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #4736
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a1, s43
    s.addi       s42, s44, #640
    s.movz       s43, #11
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s23, #4800
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a1, s41
    s.addi       s40, s44, #704
    s.movz       s41, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #4864
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a1, s43
    s.addi       s42, s44, #768
    s.movz       s43, #13
    v.ld.w       v3, [s45, #0]
    s.addi       s45, s23, #4928
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a1, s41
    s.addi       s40, s44, #832
    s.movz       s41, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #4992
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a1, s43
    s.addi       s42, s44, #896
    s.movz       s43, #15
    s.addi       s47, s44, #960
    v.ld.w       v3, [s45, #0]
    s.addi       s44, s23, #5056
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a1, s41
    s.movz       s40, #0
    s.addi       s41, s23, #5120
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s23, #13312
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a1, s43
    s.movz       s42, #1
    s.addi       s43, s23, #5184
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s45, #64
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    a.vread      v2, a2, s40
    s.movz       s40, #2
    s.addi       s46, s23, #5248
    v.ld.w       v3, [s41, #0]
    s.addi       s41, s45, #128
    vf.add       v4, v2, v3
    v.st.w       [s45, #0], v4
    a.vread      v2, a2, s42
    s.movz       s42, #3
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #5312
    vf.add       v4, v2, v3
    v.st.w       [s44, #0], v4
    a.vread      v2, a2, s40
    s.addi       s40, s45, #192
    s.movz       s44, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #5376
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a2, s42
    s.addi       s41, s45, #256
    s.movz       s42, #5
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #5440
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a2, s44
    s.addi       s40, s45, #320
    s.movz       s44, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #5504
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a2, s42
    s.addi       s41, s45, #384
    s.movz       s42, #7
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #5568
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a2, s44
    s.addi       s40, s45, #448
    s.movz       s44, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #5632
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a2, s42
    s.addi       s41, s45, #512
    s.movz       s42, #9
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #5696
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a2, s44
    s.addi       s40, s45, #576
    s.movz       s44, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #5760
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a2, s42
    s.addi       s41, s45, #640
    s.movz       s42, #11
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #5824
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a2, s44
    s.addi       s40, s45, #704
    s.movz       s44, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #5888
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a2, s42
    s.addi       s41, s45, #768
    s.movz       s42, #13
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #5952
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a2, s44
    s.addi       s40, s45, #832
    s.movz       s44, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #6016
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a2, s42
    s.addi       s41, s45, #896
    s.movz       s42, #15
    s.addi       s47, s45, #960
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #6080
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a2, s44
    s.movz       s40, #0
    s.addi       s44, s23, #6144
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s23, #14336
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a2, s42
    s.movz       s41, #1
    s.addi       s42, s23, #6208
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s45, #64
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    a.vread      v2, a3, s40
    s.movz       s40, #2
    s.addi       s46, s23, #6272
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s45, #128
    vf.add       v4, v2, v3
    v.st.w       [s45, #0], v4
    a.vread      v2, a3, s41
    s.movz       s41, #3
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s23, #6336
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a3, s40
    s.addi       s40, s45, #192
    s.movz       s43, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #6400
    vf.add       v4, v2, v3
    v.st.w       [s44, #0], v4
    a.vread      v2, a3, s41
    s.addi       s41, s45, #256
    s.movz       s44, #5
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s23, #6464
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a3, s43
    s.addi       s40, s45, #320
    s.movz       s43, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #6528
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a3, s44
    s.addi       s41, s45, #384
    s.movz       s44, #7
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s23, #6592
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a3, s43
    s.addi       s40, s45, #448
    s.movz       s43, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #6656
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a3, s44
    s.addi       s41, s45, #512
    s.movz       s44, #9
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s23, #6720
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a3, s43
    s.addi       s40, s45, #576
    s.movz       s43, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #6784
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a3, s44
    s.addi       s41, s45, #640
    s.movz       s44, #11
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s23, #6848
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a3, s43
    s.addi       s40, s45, #704
    s.movz       s43, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #6912
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a3, s44
    s.addi       s41, s45, #768
    s.movz       s44, #13
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s23, #6976
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a3, s43
    s.addi       s40, s45, #832
    s.movz       s43, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #7040
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a3, s44
    s.addi       s41, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s23, #7104
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a3, s43
    s.movz       s40, #0
    s.addi       s43, s23, #7168
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s23, #15360
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a3, s44
    s.movz       s41, #1
    s.addi       s44, s23, #7232
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s45, #64
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    a.vread      v2, a4, s40
    s.movz       s40, #2
    s.addi       s46, s23, #7296
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s45, #128
    vf.add       v4, v2, v3
    v.st.w       [s45, #0], v4
    a.vread      v2, a4, s41
    s.movz       s41, #3
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s23, #7360
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a4, s40
    s.addi       s40, s45, #192
    s.movz       s42, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #7424
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a4, s41
    s.addi       s41, s45, #256
    s.movz       s43, #5
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s23, #7488
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a4, s42
    s.addi       s40, s45, #320
    s.movz       s42, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #7552
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a4, s43
    s.addi       s41, s45, #384
    s.movz       s43, #7
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s23, #7616
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a4, s42
    s.addi       s40, s45, #448
    s.movz       s42, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #7680
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a4, s43
    s.addi       s41, s45, #512
    s.movz       s43, #9
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s23, #7744
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a4, s42
    s.addi       s40, s45, #576
    s.movz       s42, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #7808
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a4, s43
    s.addi       s41, s45, #640
    s.movz       s43, #11
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s23, #7872
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a4, s42
    s.addi       s40, s45, #704
    s.movz       s42, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #7936
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a4, s43
    s.addi       s41, s45, #768
    s.movz       s43, #13
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s23, #8000
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a4, s42
    s.addi       s40, s45, #832
    s.movz       s42, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #8064
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a4, s43
    s.addi       s41, s45, #896
    s.movz       s43, #15
    s.addi       s47, s45, #960
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s23, #8128
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a4, s42
    s.movz       s40, #0
    s.addi       s42, s23, #8192
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s23, #16384
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a4, s43
    s.movz       s41, #1
    s.addi       s43, s23, #8256
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s45, #64
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    a.vread      v2, a5, s40
    s.movz       s40, #2
    s.addi       s46, s23, #8320
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s45, #128
    vf.add       v4, v2, v3
    v.st.w       [s45, #0], v4
    a.vread      v2, a5, s41
    s.movz       s41, #3
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #8384
    vf.add       v4, v2, v3
    v.st.w       [s44, #0], v4
    a.vread      v2, a5, s40
    s.addi       s40, s45, #192
    s.movz       s44, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #8448
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a5, s41
    s.addi       s41, s45, #256
    s.movz       s42, #5
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #8512
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a5, s44
    s.addi       s40, s45, #320
    s.movz       s44, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #8576
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a5, s42
    s.addi       s41, s45, #384
    s.movz       s42, #7
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #8640
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a5, s44
    s.addi       s40, s45, #448
    s.movz       s44, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #8704
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a5, s42
    s.addi       s41, s45, #512
    s.movz       s42, #9
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #8768
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a5, s44
    s.addi       s40, s45, #576
    s.movz       s44, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #8832
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a5, s42
    s.addi       s41, s45, #640
    s.movz       s42, #11
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #8896
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a5, s44
    s.addi       s40, s45, #704
    s.movz       s44, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #8960
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a5, s42
    s.addi       s41, s45, #768
    s.movz       s42, #13
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #9024
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a5, s44
    s.addi       s40, s45, #832
    s.movz       s44, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #9088
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a5, s42
    s.addi       s41, s45, #896
    s.movz       s42, #15
    s.addi       s47, s45, #960
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s23, #9152
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a5, s44
    s.movz       s40, #0
    s.addi       s44, s23, #9216
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s23, #17408
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a5, s42
    s.movz       s41, #1
    s.addi       s42, s23, #9280
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s45, #64
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    a.vread      v2, a6, s40
    s.movz       s40, #2
    s.addi       s46, s23, #9344
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s45, #128
    vf.add       v4, v2, v3
    v.st.w       [s45, #0], v4
    a.vread      v2, a6, s41
    s.movz       s41, #3
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s23, #9408
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a6, s40
    s.addi       s40, s45, #192
    s.movz       s43, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #9472
    vf.add       v4, v2, v3
    v.st.w       [s44, #0], v4
    a.vread      v2, a6, s41
    s.addi       s41, s45, #256
    s.movz       s44, #5
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s23, #9536
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a6, s43
    s.addi       s40, s45, #320
    s.movz       s43, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #9600
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a6, s44
    s.addi       s41, s45, #384
    s.movz       s44, #7
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s23, #9664
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a6, s43
    s.addi       s40, s45, #448
    s.movz       s43, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #9728
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a6, s44
    s.addi       s41, s45, #512
    s.movz       s44, #9
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s23, #9792
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a6, s43
    s.addi       s40, s45, #576
    s.movz       s43, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #9856
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a6, s44
    s.addi       s41, s45, #640
    s.movz       s44, #11
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s23, #9920
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a6, s43
    s.addi       s40, s45, #704
    s.movz       s43, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #9984
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a6, s44
    s.addi       s41, s45, #768
    s.movz       s44, #13
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s23, #10048
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a6, s43
    s.addi       s40, s45, #832
    s.movz       s43, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #10112
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a6, s44
    s.addi       s41, s45, #896
    s.movz       s44, #15
    s.addi       s47, s45, #960
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s23, #10176
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a6, s43
    s.movz       s40, #0
    s.addi       s43, s23, #10240
    v.ld.w       v3, [s46, #0]
    s.addi       s45, s23, #18432
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a6, s44
    s.movz       s41, #1
    s.addi       s44, s23, #10304
    v.ld.w       v3, [s42, #0]
    s.addi       s42, s45, #64
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    a.vread      v2, a7, s40
    s.movz       s40, #2
    s.addi       s46, s23, #10368
    v.ld.w       v3, [s43, #0]
    s.addi       s43, s45, #128
    vf.add       v4, v2, v3
    v.st.w       [s45, #0], v4
    a.vread      v2, a7, s41
    s.movz       s41, #3
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s23, #10432
    vf.add       v4, v2, v3
    v.st.w       [s42, #0], v4
    a.vread      v2, a7, s40
    s.addi       s40, s45, #192
    s.movz       s42, #4
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #10496
    vf.add       v4, v2, v3
    v.st.w       [s43, #0], v4
    a.vread      v2, a7, s41
    s.addi       s41, s45, #256
    s.movz       s43, #5
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s23, #10560
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a7, s42
    s.addi       s40, s45, #320
    s.movz       s42, #6
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #10624
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a7, s43
    s.addi       s41, s45, #384
    s.movz       s43, #7
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s23, #10688
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a7, s42
    s.addi       s40, s45, #448
    s.movz       s42, #8
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #10752
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a7, s43
    s.addi       s41, s45, #512
    s.movz       s43, #9
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s23, #10816
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a7, s42
    s.addi       s40, s45, #576
    s.movz       s42, #10
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #10880
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a7, s43
    s.addi       s41, s45, #640
    s.movz       s43, #11
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s23, #10944
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a7, s42
    s.addi       s40, s45, #704
    s.movz       s42, #12
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #11008
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a7, s43
    s.addi       s41, s45, #768
    s.movz       s43, #13
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s23, #11072
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a7, s42
    s.addi       s40, s45, #832
    s.movz       s42, #14
    v.ld.w       v3, [s46, #0]
    s.addi       s46, s23, #11136
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a7, s43
    s.addi       s41, s45, #896
    s.movz       s43, #15
    s.addi       s47, s45, #960
    v.ld.w       v3, [s44, #0]
    s.addi       s44, s23, #11200
    vf.add       v4, v2, v3
    v.st.w       [s40, #0], v4
    a.vread      v2, a7, s42
    s.addi       s40, s18, #128
    s.addi       s42, s20, #128
    s.addi       s45, s40, #0
    s.addi       s40, s42, #0
    v.ld.w       v3, [s46, #0]
    s.addi       s42, s23, #11264
    vf.add       v4, v2, v3
    v.st.w       [s41, #0], v4
    a.vread      v2, a7, s43
    s.movz       s41, #0
    s.addi       s43, s23, #11328
    v.ld.w       v3, [s44, #0]
    s.movz       s44, #1
    vf.add       v4, v2, v3
    v.st.w       [s47, #0], v4
    fence.acq_rel.device
    s.mov        s18, s45
    s.mov        s20, s40
    s.addi       s40, s23, #11392
    s.movz       s45, #2
    s.addi       s46, s23, #11456
    s.movz       s47, #3
    s.addi       s48, s23, #11520
    v.ld.w       v2, [s42, #0]
    s.movz       s42, #4
    a.vwrite     a0, s41, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s41, s23, #11584
    s.movz       s43, #5
    a.vwrite     a0, s44, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #11648
    s.movz       s44, #6
    a.vwrite     a0, s45, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s45, s23, #11712
    s.movz       s46, #7
    a.vwrite     a0, s47, v2
    v.ld.w       v2, [s48, #0]
    s.addi       s47, s23, #11776
    s.movz       s48, #8
    a.vwrite     a0, s42, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #11840
    s.movz       s42, #9
    a.vwrite     a0, s43, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #11904
    s.movz       s43, #10
    a.vwrite     a0, s44, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s44, s23, #11968
    s.movz       s45, #11
    a.vwrite     a0, s46, v2
    v.ld.w       v2, [s47, #0]
    s.addi       s46, s23, #12032
    s.movz       s47, #12
    a.vwrite     a0, s48, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #12096
    s.movz       s48, #13
    a.vwrite     a0, s42, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #12160
    s.movz       s42, #14
    a.vwrite     a0, s43, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s43, s23, #12224
    s.movz       s44, #15
    a.vwrite     a0, s45, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s45, s23, #12288
    s.movz       s46, #0
    a.vwrite     a0, s47, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #12352
    s.movz       s47, #1
    a.vwrite     a0, s48, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #12416
    s.movz       s48, #2
    a.vwrite     a0, s42, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s42, s23, #12480
    s.movz       s43, #3
    a.vwrite     a0, s44, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s44, s23, #12544
    s.movz       s45, #4
    a.vwrite     a1, s46, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #12608
    s.movz       s46, #5
    a.vwrite     a1, s47, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #12672
    s.movz       s47, #6
    a.vwrite     a1, s48, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #12736
    s.movz       s48, #7
    a.vwrite     a1, s43, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s43, s23, #12800
    s.movz       s44, #8
    a.vwrite     a1, s45, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #12864
    s.movz       s45, #9
    a.vwrite     a1, s46, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #12928
    s.movz       s46, #10
    a.vwrite     a1, s47, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #12992
    s.movz       s47, #11
    a.vwrite     a1, s48, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #13056
    s.movz       s48, #12
    a.vwrite     a1, s44, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #13120
    s.movz       s44, #13
    a.vwrite     a1, s45, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #13184
    s.movz       s45, #14
    a.vwrite     a1, s46, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #13248
    s.movz       s46, #15
    a.vwrite     a1, s47, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #13312
    s.movz       s47, #0
    a.vwrite     a1, s48, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #13376
    s.movz       s48, #1
    a.vwrite     a1, s44, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #13440
    s.movz       s44, #2
    a.vwrite     a1, s45, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #13504
    s.movz       s45, #3
    a.vwrite     a1, s46, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #13568
    s.movz       s46, #4
    a.vwrite     a2, s47, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #13632
    s.movz       s47, #5
    a.vwrite     a2, s48, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #13696
    s.movz       s48, #6
    a.vwrite     a2, s44, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #13760
    s.movz       s44, #7
    a.vwrite     a2, s45, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #13824
    s.movz       s45, #8
    a.vwrite     a2, s46, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #13888
    s.movz       s46, #9
    a.vwrite     a2, s47, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #13952
    s.movz       s47, #10
    a.vwrite     a2, s48, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #14016
    s.movz       s48, #11
    a.vwrite     a2, s44, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #14080
    s.movz       s44, #12
    a.vwrite     a2, s45, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #14144
    s.movz       s45, #13
    a.vwrite     a2, s46, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #14208
    s.movz       s46, #14
    a.vwrite     a2, s47, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #14272
    s.movz       s47, #15
    a.vwrite     a2, s48, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #14336
    s.movz       s48, #0
    a.vwrite     a2, s44, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #14400
    s.movz       s44, #1
    a.vwrite     a2, s45, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #14464
    s.movz       s45, #2
    a.vwrite     a2, s46, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #14528
    s.movz       s46, #3
    a.vwrite     a2, s47, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #14592
    s.movz       s47, #4
    a.vwrite     a3, s48, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #14656
    s.movz       s48, #5
    a.vwrite     a3, s44, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #14720
    s.movz       s44, #6
    a.vwrite     a3, s45, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #14784
    s.movz       s45, #7
    a.vwrite     a3, s46, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #14848
    s.movz       s46, #8
    a.vwrite     a3, s47, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #14912
    s.movz       s47, #9
    a.vwrite     a3, s48, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #14976
    s.movz       s48, #10
    a.vwrite     a3, s44, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #15040
    s.movz       s44, #11
    a.vwrite     a3, s45, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #15104
    s.movz       s45, #12
    a.vwrite     a3, s46, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #15168
    s.movz       s46, #13
    a.vwrite     a3, s47, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #15232
    s.movz       s47, #14
    a.vwrite     a3, s48, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #15296
    s.movz       s48, #15
    a.vwrite     a3, s44, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #15360
    s.movz       s44, #0
    a.vwrite     a3, s45, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #15424
    s.movz       s45, #1
    a.vwrite     a3, s46, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #15488
    s.movz       s46, #2
    a.vwrite     a3, s47, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #15552
    s.movz       s47, #3
    a.vwrite     a3, s48, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #15616
    s.movz       s48, #4
    a.vwrite     a4, s44, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #15680
    s.movz       s44, #5
    a.vwrite     a4, s45, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #15744
    s.movz       s45, #6
    a.vwrite     a4, s46, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #15808
    s.movz       s46, #7
    a.vwrite     a4, s47, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #15872
    s.movz       s47, #8
    a.vwrite     a4, s48, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #15936
    s.movz       s48, #9
    a.vwrite     a4, s44, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #16000
    s.movz       s44, #10
    a.vwrite     a4, s45, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #16064
    s.movz       s45, #11
    a.vwrite     a4, s46, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #16128
    s.movz       s46, #12
    a.vwrite     a4, s47, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #16192
    s.movz       s47, #13
    a.vwrite     a4, s48, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #16256
    s.movz       s48, #14
    a.vwrite     a4, s44, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #16320
    s.movz       s44, #15
    a.vwrite     a4, s45, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #16384
    s.movz       s45, #0
    a.vwrite     a4, s46, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #16448
    s.movz       s46, #1
    a.vwrite     a4, s47, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #16512
    s.movz       s47, #2
    a.vwrite     a4, s48, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #16576
    s.movz       s48, #3
    a.vwrite     a4, s44, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #16640
    s.movz       s44, #4
    a.vwrite     a5, s45, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #16704
    s.movz       s45, #5
    a.vwrite     a5, s46, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #16768
    s.movz       s46, #6
    a.vwrite     a5, s47, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #16832
    s.movz       s47, #7
    a.vwrite     a5, s48, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #16896
    s.movz       s48, #8
    a.vwrite     a5, s44, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #16960
    s.movz       s44, #9
    a.vwrite     a5, s45, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #17024
    s.movz       s45, #10
    a.vwrite     a5, s46, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #17088
    s.movz       s46, #11
    a.vwrite     a5, s47, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #17152
    s.movz       s47, #12
    a.vwrite     a5, s48, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #17216
    s.movz       s48, #13
    a.vwrite     a5, s44, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #17280
    s.movz       s44, #14
    a.vwrite     a5, s45, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #17344
    s.movz       s45, #15
    a.vwrite     a5, s46, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #17408
    s.movz       s46, #0
    a.vwrite     a5, s47, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #17472
    s.movz       s47, #1
    a.vwrite     a5, s48, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #17536
    s.movz       s48, #2
    a.vwrite     a5, s44, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #17600
    s.movz       s44, #3
    a.vwrite     a5, s45, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #17664
    s.movz       s45, #4
    a.vwrite     a6, s46, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #17728
    s.movz       s46, #5
    a.vwrite     a6, s47, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #17792
    s.movz       s47, #6
    a.vwrite     a6, s48, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #17856
    s.movz       s48, #7
    a.vwrite     a6, s44, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #17920
    s.movz       s44, #8
    a.vwrite     a6, s45, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #17984
    s.movz       s45, #9
    a.vwrite     a6, s46, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #18048
    s.movz       s46, #10
    a.vwrite     a6, s47, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #18112
    s.movz       s47, #11
    a.vwrite     a6, s48, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #18176
    s.movz       s48, #12
    a.vwrite     a6, s44, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #18240
    s.movz       s44, #13
    a.vwrite     a6, s45, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #18304
    s.movz       s45, #14
    a.vwrite     a6, s46, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #18368
    s.movz       s46, #15
    a.vwrite     a6, s47, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #18432
    s.movz       s47, #0
    a.vwrite     a6, s48, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #18496
    s.movz       s48, #1
    a.vwrite     a6, s44, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #18560
    s.movz       s44, #2
    a.vwrite     a6, s45, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #18624
    s.movz       s45, #3
    a.vwrite     a6, s46, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #18688
    s.movz       s46, #4
    a.vwrite     a7, s47, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #18752
    s.movz       s47, #5
    a.vwrite     a7, s48, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #18816
    s.movz       s48, #6
    a.vwrite     a7, s44, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #18880
    s.movz       s44, #7
    a.vwrite     a7, s45, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #18944
    s.movz       s45, #8
    s.add        s49, s17, s14
    a.vwrite     a7, s46, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #19008
    s.movz       s46, #9
    a.vwrite     a7, s47, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #19072
    s.movz       s47, #10
    a.vwrite     a7, s48, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s23, #19136
    s.movz       s48, #11
    a.vwrite     a7, s44, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s23, #19200
    s.movz       s44, #12
    a.vwrite     a7, s45, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s23, #19264
    s.movz       s45, #13
    a.vwrite     a7, s46, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s23, #19328
    s.movz       s46, #14
    s.addi       s50, s23, #19392
    a.vwrite     a7, s47, v2
    v.ld.w       v2, [s42, #0]
    s.movz       s23, #15
    s.movz       s42, #1
    a.vwrite     a7, s48, v2
    v.ld.w       v2, [s43, #0]
    a.vwrite     a7, s44, v2
    v.ld.w       v2, [s41, #0]
    a.vwrite     a7, s45, v2
    v.ld.w       v2, [s40, #0]
    a.vwrite     a7, s46, v2
    v.ld.w       v2, [s50, #0]
    a.vwrite     a7, s23, v2
    s.mov        s17, s49
    br.nz        s42, for_18
endfor_19:
    s.movz       s2, #0
    v.extract    s5, v1, #0
    a.vread      v0, a0, s2
    v.splat      v2, s5
    s.mul        s2, s1, s19
    v.splat      v3, s21
    vf.mul       v4, v0, v2
    s.movz       s5, #0
    s.movz       s6, #0
    s.add        s7, s5, s4                      // the tile origin
    s.movz       s5, #0
    vf.mul       v0, v4, v3
    s.movz       s8, #0
    s.muli       s9, s2, #2
    s.muli       s2, s4, #2
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s7
    s.add        s7, s6, s1                      // the tile origin
    s.add        s1, s5, s12                     // the tile origin
    s.add        s5, s8, s3                      // the tile origin
    v.splat      v5, s7
    v.splat      v6, s1
    v.add        v7, v2, v4
    v.splat      v4, s5
    vf.cvt.f32.bf16 v8, v0
    s.add        s1, s9, s2
    v.cmp.lt     p1, v5, v6
    v.cmp.lt     p2, v7, v4
    s.add        s5, s13, s1
    p.and        p3, p1, p2
    s.movz       s1, #1
    v.extract    s6, v1, #1
    @p3 v.st.h       [s5, #0], v8
    a.vread      v0, a0, s1
    v.splat      v4, s6
    s.muli       s1, s19, #2
    s.addi       s5, s4, #16
    vf.mul       v5, v0, v4
    s.addi       s6, s4, #32
    s.addi       s8, s7, #1
    s.muli       s10, s1, #1
    s.addi       s11, s4, #48
    vf.mul       v0, v5, v3
    v.splat      v4, s8
    s.addi       s8, s4, #64
    s.add        s12, s10, s9
    v.cmp.lt     p1, v4, v6
    vf.cvt.f32.bf16 v4, v0
    s.add        s10, s12, s2
    s.addi       s12, s4, #80
    s.add        s14, s13, s10
    p.and        p3, p1, p2
    s.addi       s10, s4, #96
    @p3 v.st.h       [s14, #0], v4
    s.addi       s14, s4, #112
    s.movz       s4, #2
    v.extract    s16, v1, #2
    a.vread      v0, a0, s4
    v.splat      v4, s16
    s.muli       s4, s1, #2
    s.addi       s16, s7, #2
    vf.mul       v5, v0, v4
    v.splat      v0, s16
    s.movz       s16, #3
    s.add        s17, s4, s9
    v.cmp.lt     p1, v0, v6
    vf.mul       v0, v5, v3
    s.add        s4, s17, s2
    p.and        p3, p1, p2
    s.add        s17, s13, s4
    v.extract    s4, v1, #3
    vf.cvt.f32.bf16 v4, v0
    v.splat      v0, s4
    s.muli       s4, s1, #3
    s.addi       s18, s7, #3
    s.movz       s19, #4
    @p3 v.st.h       [s17, #0], v4
    a.vread      v4, a0, s16
    s.add        s16, s4, s9
    v.splat      v5, s18
    vf.mul       v7, v4, v0
    s.add        s4, s16, s2
    v.cmp.lt     p1, v5, v6
    s.add        s16, s13, s4
    p.and        p3, p1, p2
    vf.mul       v0, v7, v3
    v.extract    s4, v1, #4
    s.muli       s17, s1, #4
    v.splat      v4, s4
    s.addi       s4, s7, #4
    vf.cvt.f32.bf16 v5, v0
    v.splat      v0, s4
    s.add        s4, s17, s9
    s.movz       s17, #5
    s.add        s18, s4, s2
    @p3 v.st.h       [s16, #0], v5
    a.vread      v5, a0, s19
    v.cmp.lt     p1, v0, v6
    s.add        s4, s13, s18
    vf.mul       v0, v5, v4
    p.and        p3, p1, p2
    v.extract    s16, v1, #5
    s.muli       s18, s1, #5
    v.splat      v4, s16
    vf.mul       v5, v0, v3
    s.addi       s16, s7, #5
    s.movz       s19, #6
    s.add        s20, s18, s9
    v.splat      v0, s16
    vf.cvt.f32.bf16 v7, v5
    s.add        s16, s20, s2
    v.cmp.lt     p1, v0, v6
    s.add        s18, s13, s16
    p.and        p4, p1, p2
    @p3 v.st.h       [s4, #0], v7
    a.vread      v0, a0, s17
    v.extract    s4, v1, #6
    s.muli       s16, s1, #6
    vf.mul       v5, v0, v4
    v.splat      v0, s4
    s.addi       s4, s7, #6
    s.movz       s17, #7
    s.add        s20, s16, s9
    vf.mul       v4, v5, v3
    v.splat      v5, s4
    s.add        s4, s20, s2
    v.extract    s16, v1, #7
    v.cmp.lt     p1, v5, v6
    vf.cvt.f32.bf16 v5, v4
    s.add        s20, s13, s4
    p.and        p3, p1, p2
    v.splat      v4, s16
    s.muli       s4, s1, #7
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a0, s19
    s.addi       s16, s7, #7
    s.movz       s18, #8
    vf.mul       v7, v5, v0
    s.add        s19, s4, s9
    v.splat      v0, s16
    s.add        s4, s19, s2
    v.extract    s16, v1, #8
    vf.mul       v5, v7, v3
    v.cmp.lt     p1, v0, v6
    s.add        s19, s13, s4
    p.and        p4, p1, p2
    v.splat      v0, s16
    vf.cvt.f32.bf16 v7, v5
    s.muli       s4, s1, #8
    s.addi       s16, s7, #8
    s.movz       s21, #9
    v.splat      v5, s16
    @p3 v.st.h       [s20, #0], v7
    a.vread      v7, a0, s17
    s.add        s16, s4, s9
    v.cmp.lt     p1, v5, v6
    vf.mul       v5, v7, v4
    s.add        s4, s16, s2
    p.and        p3, p1, p2
    s.add        s16, s13, s4
    v.extract    s4, v1, #9
    vf.mul       v4, v5, v3
    v.splat      v5, s4
    s.muli       s4, s1, #9
    s.addi       s17, s7, #9
    s.movz       s20, #10
    vf.cvt.f32.bf16 v7, v4
    v.splat      v4, s17
    s.add        s17, s4, s9
    v.extract    s4, v1, #10
    s.add        s23, s17, s2
    @p4 v.st.h       [s19, #0], v7
    a.vread      v7, a0, s18
    v.cmp.lt     p1, v4, v6
    s.add        s17, s13, s23
    vf.mul       v4, v7, v0
    p.and        p4, p1, p2
    v.splat      v0, s4
    s.muli       s4, s1, #10
    s.addi       s18, s7, #10
    vf.mul       v7, v4, v3
    v.splat      v4, s18
    s.movz       s18, #11
    s.add        s19, s4, s9
    v.extract    s4, v1, #11
    vf.cvt.f32.bf16 v8, v7
    s.add        s23, s19, s2
    v.splat      v7, s4
    s.add        s4, s13, s23
    s.muli       s19, s1, #11
    @p3 v.st.h       [s16, #0], v8
    a.vread      v8, a0, s21
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v8, v5
    s.addi       s16, s7, #11
    s.add        s21, s19, s9
    v.splat      v5, s16
    s.add        s16, s21, s2
    vf.mul       v8, v4, v3
    s.add        s19, s13, s16
    s.movz       s16, #12
    v.extract    s21, v1, #12
    vf.cvt.f32.bf16 v4, v8
    v.splat      v8, s21
    s.muli       s21, s1, #12
    s.addi       s23, s7, #12
    @p4 v.st.h       [s17, #0], v4
    a.vread      v4, a0, s20
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v4, v0
    s.add        s17, s21, s9
    v.splat      v0, s23
    s.add        s20, s17, s2
    s.movz       s17, #13
    vf.mul       v4, v5, v3
    s.add        s21, s13, s20
    v.extract    s20, v1, #13
    v.splat      v5, s20
    vf.cvt.f32.bf16 v9, v4
    s.muli       s20, s1, #13
    s.addi       s23, s7, #13
    v.splat      v4, s23
    @p3 v.st.h       [s4, #0], v9
    a.vread      v9, a0, s18
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s4, s20, s9
    s.movz       s18, #14
    s.add        s20, s4, s2
    v.extract    s4, v1, #14
    vf.mul       v7, v0, v3
    s.add        s23, s13, s20
    v.splat      v0, s4
    vf.cvt.f32.bf16 v9, v7
    s.muli       s4, s1, #14
    s.addi       s20, s7, #14
    v.splat      v7, s20
    @p4 v.st.h       [s19, #0], v9
    a.vread      v9, a0, s16
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v8
    s.add        s16, s4, s9
    s.movz       s4, #15
    s.add        s19, s16, s2
    v.extract    s16, v1, #15
    vf.mul       v8, v4, v3
    s.add        s20, s13, s19
    v.splat      v4, s16
    vf.cvt.f32.bf16 v9, v8
    s.muli       s16, s1, #15
    s.addi       s19, s7, #15
    v.splat      v8, s19
    @p3 v.st.h       [s21, #0], v9
    a.vread      v9, a0, s17
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v5
    s.add        s17, s16, s9
    s.movz       s16, #0
    s.add        s19, s17, s2
    v.extract    s2, v1, #0
    vf.mul       v5, v7, v3
    s.add        s17, s13, s19
    v.splat      v7, s2
    vf.cvt.f32.bf16 v9, v5
    s.movz       s2, #0
    s.muli       s19, s5, #2
    s.add        s21, s2, s5                     // the tile origin
    v.splat      v5, s7
    @p4 v.st.h       [s23, #0], v9
    a.vread      v9, a0, s18
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.movz       s2, #0
    v.splat      v0, s21
    s.add        s5, s2, s3                      // the tile origin
    s.add        s2, s9, s19
    vf.mul       v9, v8, v3
    v.add        v8, v2, v0
    v.splat      v0, s5
    v.cmp.lt     p1, v5, v6
    s.add        s5, s13, s2
    vf.cvt.f32.bf16 v5, v9
    s.movz       s2, #1
    v.extract    s18, v1, #1
    s.muli       s21, s1, #1
    v.splat      v9, s18
    @p3 v.st.h       [s20, #0], v5
    a.vread      v5, a0, s4
    v.cmp.lt     p2, v8, v0
    p.and        p3, p1, p2
    vf.mul       v0, v5, v4
    s.addi       s4, s7, #1
    s.add        s18, s21, s9
    v.splat      v4, s4
    s.add        s4, s18, s19
    vf.mul       v5, v0, v3
    s.add        s18, s13, s4
    vf.cvt.f32.bf16 v0, v5
    s.movz       s4, #2
    v.extract    s20, v1, #2
    s.muli       s21, s1, #2
    v.splat      v5, s20
    @p4 v.st.h       [s17, #0], v0
    a.vread      v0, a1, s16
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v7
    s.addi       s16, s7, #2
    s.add        s17, s21, s9
    v.splat      v0, s16
    s.add        s16, s17, s19
    vf.mul       v7, v4, v3
    s.add        s17, s13, s16
    vf.cvt.f32.bf16 v4, v7
    s.movz       s16, #3
    v.extract    s20, v1, #3
    s.muli       s21, s1, #3
    v.splat      v7, s20
    @p3 v.st.h       [s5, #0], v4
    a.vread      v4, a1, s2
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s2, s7, #3
    s.add        s5, s21, s9
    v.splat      v4, s2
    s.add        s2, s5, s19
    vf.mul       v8, v0, v3
    s.add        s5, s13, s2
    s.movz       s2, #4
    v.extract    s20, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s20
    s.muli       s20, s1, #4
    s.addi       s21, s7, #4
    @p4 v.st.h       [s18, #0], v0
    a.vread      v0, a1, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v5
    s.add        s4, s20, s9
    v.splat      v0, s21
    s.add        s18, s4, s19
    s.movz       s4, #5
    vf.mul       v5, v4, v3
    s.add        s20, s13, s18
    v.extract    s18, v1, #5
    v.splat      v4, s18
    vf.cvt.f32.bf16 v9, v5
    s.muli       s18, s1, #5
    s.addi       s21, s7, #5
    v.splat      v5, s21
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a1, s16
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s16, s18, s9
    s.movz       s17, #6
    s.add        s18, s16, s19
    v.extract    s16, v1, #6
    vf.mul       v7, v0, v3
    s.add        s21, s13, s18
    v.splat      v0, s16
    vf.cvt.f32.bf16 v9, v7
    s.muli       s16, s1, #6
    s.addi       s18, s7, #6
    v.splat      v7, s18
    @p4 v.st.h       [s5, #0], v9
    a.vread      v9, a1, s2
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.add        s2, s16, s9
    s.movz       s5, #7
    s.add        s16, s2, s19
    v.extract    s2, v1, #7
    vf.mul       v8, v5, v3
    s.add        s18, s13, s16
    v.splat      v5, s2
    vf.cvt.f32.bf16 v9, v8
    s.muli       s2, s1, #7
    s.addi       s16, s7, #7
    v.splat      v8, s16
    @p3 v.st.h       [s20, #0], v9
    a.vread      v9, a1, s4
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s4, s2, s9
    s.movz       s2, #8
    s.add        s16, s4, s19
    v.extract    s4, v1, #8
    vf.mul       v4, v7, v3
    s.add        s20, s13, s16
    v.splat      v7, s4
    vf.cvt.f32.bf16 v9, v4
    s.muli       s4, s1, #8
    s.addi       s16, s7, #8
    v.splat      v4, s16
    @p4 v.st.h       [s21, #0], v9
    a.vread      v9, a1, s17
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s16, s4, s9
    s.movz       s4, #9
    s.add        s17, s16, s19
    v.extract    s16, v1, #9
    vf.mul       v0, v8, v3
    s.add        s21, s13, s17
    v.splat      v8, s16
    vf.cvt.f32.bf16 v9, v0
    s.muli       s16, s1, #9
    s.addi       s17, s7, #9
    v.splat      v0, s17
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a1, s5
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s5, s16, s9
    s.movz       s16, #10
    s.add        s17, s5, s19
    v.extract    s5, v1, #10
    vf.mul       v5, v4, v3
    s.add        s18, s13, s17
    v.splat      v4, s5
    vf.cvt.f32.bf16 v9, v5
    s.muli       s5, s1, #10
    s.addi       s17, s7, #10
    v.splat      v5, s17
    @p4 v.st.h       [s20, #0], v9
    a.vread      v9, a1, s2
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v7
    s.add        s2, s5, s9
    s.movz       s5, #11
    s.add        s17, s2, s19
    v.extract    s2, v1, #11
    vf.mul       v7, v0, v3
    s.add        s20, s13, s17
    v.splat      v0, s2
    vf.cvt.f32.bf16 v9, v7
    s.muli       s2, s1, #11
    s.addi       s17, s7, #11
    v.splat      v7, s17
    @p3 v.st.h       [s21, #0], v9
    a.vread      v9, a1, s4
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v8
    s.add        s4, s2, s9
    s.movz       s2, #12
    s.add        s17, s4, s19
    v.extract    s4, v1, #12
    vf.mul       v8, v5, v3
    s.add        s21, s13, s17
    v.splat      v5, s4
    vf.cvt.f32.bf16 v9, v8
    s.muli       s4, s1, #12
    s.addi       s17, s7, #12
    v.splat      v8, s17
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a1, s16
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s16, s4, s9
    s.movz       s4, #13
    s.add        s17, s16, s19
    v.extract    s16, v1, #13
    vf.mul       v4, v7, v3
    s.add        s18, s13, s17
    v.splat      v7, s16
    vf.cvt.f32.bf16 v9, v4
    s.muli       s16, s1, #13
    s.addi       s17, s7, #13
    v.splat      v4, s17
    @p3 v.st.h       [s20, #0], v9
    a.vread      v9, a1, s5
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s5, s16, s9
    s.movz       s16, #14
    s.add        s17, s5, s19
    v.extract    s5, v1, #14
    vf.mul       v0, v8, v3
    s.add        s20, s13, s17
    v.splat      v8, s5
    vf.cvt.f32.bf16 v9, v0
    s.muli       s5, s1, #14
    s.addi       s17, s7, #14
    v.splat      v0, s17
    @p4 v.st.h       [s21, #0], v9
    a.vread      v9, a1, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s2, s5, s9
    s.movz       s5, #15
    s.add        s17, s2, s19
    v.extract    s2, v1, #15
    vf.mul       v5, v4, v3
    s.add        s21, s13, s17
    v.splat      v4, s2
    vf.cvt.f32.bf16 v9, v5
    s.muli       s2, s1, #15
    s.addi       s17, s7, #15
    v.splat      v5, s17
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a1, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s4, s2, s9
    s.movz       s2, #0
    s.add        s17, s4, s19
    v.extract    s4, v1, #0
    vf.mul       v7, v0, v3
    s.add        s18, s13, s17
    v.splat      v0, s4
    vf.cvt.f32.bf16 v9, v7
    s.movz       s4, #0
    s.muli       s17, s6, #2
    s.add        s19, s4, s6                     // the tile origin
    v.splat      v7, s7
    @p4 v.st.h       [s20, #0], v9
    a.vread      v9, a1, s16
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.movz       s4, #0
    v.splat      v8, s19
    s.add        s6, s4, s3                      // the tile origin
    s.add        s4, s9, s17
    vf.mul       v9, v5, v3
    v.add        v5, v2, v8
    v.splat      v8, s6
    v.cmp.lt     p1, v7, v6
    s.add        s6, s13, s4
    vf.cvt.f32.bf16 v7, v9
    s.movz       s4, #1
    v.extract    s16, v1, #1
    s.muli       s19, s1, #1
    v.splat      v9, s16
    @p3 v.st.h       [s21, #0], v7
    a.vread      v7, a1, s5
    v.cmp.lt     p2, v5, v8
    p.and        p3, p1, p2
    vf.mul       v5, v7, v4
    s.addi       s5, s7, #1
    s.add        s16, s19, s9
    v.splat      v4, s5
    s.add        s5, s16, s17
    vf.mul       v7, v5, v3
    s.add        s16, s13, s5
    vf.cvt.f32.bf16 v5, v7
    s.movz       s5, #2
    v.extract    s19, v1, #2
    s.muli       s20, s1, #2
    v.splat      v7, s19
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a2, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v5, v0
    s.addi       s2, s7, #2
    s.add        s18, s20, s9
    v.splat      v0, s2
    s.add        s2, s18, s17
    vf.mul       v5, v4, v3
    s.add        s18, s13, s2
    vf.cvt.f32.bf16 v4, v5
    s.movz       s2, #3
    v.extract    s19, v1, #3
    s.muli       s20, s1, #3
    v.splat      v5, s19
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a2, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s4, s7, #3
    s.add        s6, s20, s9
    v.splat      v4, s4
    s.add        s4, s6, s17
    vf.mul       v8, v0, v3
    s.add        s6, s13, s4
    s.movz       s4, #4
    v.extract    s19, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s19
    s.muli       s19, s1, #4
    s.addi       s20, s7, #4
    @p4 v.st.h       [s16, #0], v0
    a.vread      v0, a2, s5
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v7
    s.add        s5, s19, s9
    v.splat      v0, s20
    s.add        s16, s5, s17
    s.movz       s5, #5
    vf.mul       v7, v4, v3
    s.add        s19, s13, s16
    v.extract    s16, v1, #5
    v.splat      v4, s16
    vf.cvt.f32.bf16 v9, v7
    s.muli       s16, s1, #5
    s.addi       s20, s7, #5
    v.splat      v7, s20
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a2, s2
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s2, s16, s9
    s.movz       s16, #6
    s.add        s18, s2, s17
    v.extract    s2, v1, #6
    vf.mul       v5, v0, v3
    s.add        s20, s13, s18
    v.splat      v0, s2
    vf.cvt.f32.bf16 v9, v5
    s.muli       s2, s1, #6
    s.addi       s18, s7, #6
    v.splat      v5, s18
    @p4 v.st.h       [s6, #0], v9
    a.vread      v9, a2, s4
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.add        s4, s2, s9
    s.movz       s2, #7
    s.add        s6, s4, s17
    v.extract    s4, v1, #7
    vf.mul       v8, v7, v3
    s.add        s18, s13, s6
    v.splat      v7, s4
    vf.cvt.f32.bf16 v9, v8
    s.muli       s4, s1, #7
    s.addi       s6, s7, #7
    v.splat      v8, s6
    @p3 v.st.h       [s19, #0], v9
    a.vread      v9, a2, s5
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v4
    s.add        s5, s4, s9
    s.movz       s4, #8
    s.add        s6, s5, s17
    v.extract    s5, v1, #8
    vf.mul       v4, v5, v3
    s.add        s19, s13, s6
    v.splat      v5, s5
    vf.cvt.f32.bf16 v9, v4
    s.muli       s5, s1, #8
    s.addi       s6, s7, #8
    v.splat      v4, s6
    @p4 v.st.h       [s20, #0], v9
    a.vread      v9, a2, s16
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s6, s5, s9
    s.movz       s5, #9
    s.add        s16, s6, s17
    v.extract    s6, v1, #9
    vf.mul       v0, v8, v3
    s.add        s20, s13, s16
    v.splat      v8, s6
    vf.cvt.f32.bf16 v9, v0
    s.muli       s6, s1, #9
    s.addi       s16, s7, #9
    v.splat      v0, s16
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a2, s2
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.add        s2, s6, s9
    s.movz       s6, #10
    s.add        s16, s2, s17
    v.extract    s2, v1, #10
    vf.mul       v7, v4, v3
    s.add        s18, s13, s16
    v.splat      v4, s2
    vf.cvt.f32.bf16 v9, v7
    s.muli       s2, s1, #10
    s.addi       s16, s7, #10
    v.splat      v7, s16
    @p4 v.st.h       [s19, #0], v9
    a.vread      v9, a2, s4
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v5
    s.add        s4, s2, s9
    s.movz       s2, #11
    s.add        s16, s4, s17
    v.extract    s4, v1, #11
    vf.mul       v5, v0, v3
    s.add        s19, s13, s16
    v.splat      v0, s4
    vf.cvt.f32.bf16 v9, v5
    s.muli       s4, s1, #11
    s.addi       s16, s7, #11
    v.splat      v5, s16
    @p3 v.st.h       [s20, #0], v9
    a.vread      v9, a2, s5
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v8
    s.add        s5, s4, s9
    s.movz       s4, #12
    s.add        s16, s5, s17
    v.extract    s5, v1, #12
    vf.mul       v8, v7, v3
    s.add        s20, s13, s16
    v.splat      v7, s5
    vf.cvt.f32.bf16 v9, v8
    s.muli       s5, s1, #12
    s.addi       s16, s7, #12
    v.splat      v8, s16
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a2, s6
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v4
    s.add        s6, s5, s9
    s.movz       s5, #13
    s.add        s16, s6, s17
    v.extract    s6, v1, #13
    vf.mul       v4, v5, v3
    s.add        s18, s13, s16
    v.splat      v5, s6
    vf.cvt.f32.bf16 v9, v4
    s.muli       s6, s1, #13
    s.addi       s16, s7, #13
    v.splat      v4, s16
    @p3 v.st.h       [s19, #0], v9
    a.vread      v9, a2, s2
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s2, s6, s9
    s.movz       s6, #14
    s.add        s16, s2, s17
    v.extract    s2, v1, #14
    vf.mul       v0, v8, v3
    s.add        s19, s13, s16
    v.splat      v8, s2
    vf.cvt.f32.bf16 v9, v0
    s.muli       s2, s1, #14
    s.addi       s16, s7, #14
    v.splat      v0, s16
    @p4 v.st.h       [s20, #0], v9
    a.vread      v9, a2, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v7
    s.add        s4, s2, s9
    s.movz       s2, #15
    s.add        s16, s4, s17
    v.extract    s4, v1, #15
    vf.mul       v7, v4, v3
    s.add        s20, s13, s16
    v.splat      v4, s4
    vf.cvt.f32.bf16 v9, v7
    s.muli       s4, s1, #15
    s.addi       s16, s7, #15
    v.splat      v7, s16
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a2, s5
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s5, s4, s9
    s.movz       s4, #0
    s.add        s16, s5, s17
    v.extract    s5, v1, #0
    vf.mul       v5, v0, v3
    s.add        s17, s13, s16
    v.splat      v0, s5
    vf.cvt.f32.bf16 v9, v5
    s.movz       s5, #0
    s.muli       s16, s11, #2
    s.add        s18, s5, s11                    // the tile origin
    v.splat      v5, s7
    @p4 v.st.h       [s19, #0], v9
    a.vread      v9, a2, s6
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.movz       s5, #0
    v.splat      v8, s18
    s.add        s6, s5, s3                      // the tile origin
    s.add        s5, s9, s16
    vf.mul       v9, v7, v3
    v.add        v7, v2, v8
    v.splat      v8, s6
    v.cmp.lt     p1, v5, v6
    s.add        s6, s13, s5
    vf.cvt.f32.bf16 v5, v9
    s.movz       s5, #1
    v.extract    s11, v1, #1
    s.muli       s18, s1, #1
    v.splat      v9, s11
    @p3 v.st.h       [s20, #0], v5
    a.vread      v5, a2, s2
    v.cmp.lt     p2, v7, v8
    p.and        p3, p1, p2
    vf.mul       v7, v5, v4
    s.addi       s2, s7, #1
    s.add        s11, s18, s9
    v.splat      v4, s2
    s.add        s2, s11, s16
    vf.mul       v5, v7, v3
    s.add        s11, s13, s2
    vf.cvt.f32.bf16 v7, v5
    s.movz       s2, #2
    v.extract    s18, v1, #2
    s.muli       s19, s1, #2
    v.splat      v5, s18
    @p4 v.st.h       [s17, #0], v7
    a.vread      v7, a3, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v7, v0
    s.addi       s4, s7, #2
    s.add        s17, s19, s9
    v.splat      v0, s4
    s.add        s4, s17, s16
    vf.mul       v7, v4, v3
    s.add        s17, s13, s4
    vf.cvt.f32.bf16 v4, v7
    s.movz       s4, #3
    v.extract    s18, v1, #3
    s.muli       s19, s1, #3
    v.splat      v7, s18
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a3, s5
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s5, s7, #3
    s.add        s6, s19, s9
    v.splat      v4, s5
    s.add        s5, s6, s16
    vf.mul       v8, v0, v3
    s.add        s6, s13, s5
    s.movz       s5, #4
    v.extract    s18, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s18
    s.muli       s18, s1, #4
    s.addi       s19, s7, #4
    @p4 v.st.h       [s11, #0], v0
    a.vread      v0, a3, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v5
    s.add        s2, s18, s9
    v.splat      v0, s19
    s.add        s11, s2, s16
    s.movz       s2, #5
    vf.mul       v5, v4, v3
    s.add        s18, s13, s11
    v.extract    s11, v1, #5
    v.splat      v4, s11
    vf.cvt.f32.bf16 v9, v5
    s.muli       s11, s1, #5
    s.addi       s19, s7, #5
    v.splat      v5, s19
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a3, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s4, s11, s9
    s.movz       s11, #6
    s.add        s17, s4, s16
    v.extract    s4, v1, #6
    vf.mul       v7, v0, v3
    s.add        s19, s13, s17
    v.splat      v0, s4
    vf.cvt.f32.bf16 v9, v7
    s.muli       s4, s1, #6
    s.addi       s17, s7, #6
    v.splat      v7, s17
    @p4 v.st.h       [s6, #0], v9
    a.vread      v9, a3, s5
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.add        s5, s4, s9
    s.movz       s4, #7
    s.add        s6, s5, s16
    v.extract    s5, v1, #7
    vf.mul       v8, v5, v3
    s.add        s17, s13, s6
    v.splat      v5, s5
    vf.cvt.f32.bf16 v9, v8
    s.muli       s5, s1, #7
    s.addi       s6, s7, #7
    v.splat      v8, s6
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a3, s2
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s2, s5, s9
    s.movz       s5, #8
    s.add        s6, s2, s16
    v.extract    s2, v1, #8
    vf.mul       v4, v7, v3
    s.add        s18, s13, s6
    v.splat      v7, s2
    vf.cvt.f32.bf16 v9, v4
    s.muli       s2, s1, #8
    s.addi       s6, s7, #8
    v.splat      v4, s6
    @p4 v.st.h       [s19, #0], v9
    a.vread      v9, a3, s11
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s6, s2, s9
    s.movz       s2, #9
    s.add        s11, s6, s16
    v.extract    s6, v1, #9
    vf.mul       v0, v8, v3
    s.add        s19, s13, s11
    v.splat      v8, s6
    vf.cvt.f32.bf16 v9, v0
    s.muli       s6, s1, #9
    s.addi       s11, s7, #9
    v.splat      v0, s11
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a3, s4
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s4, s6, s9
    s.movz       s6, #10
    s.add        s11, s4, s16
    v.extract    s4, v1, #10
    vf.mul       v5, v4, v3
    s.add        s17, s13, s11
    v.splat      v4, s4
    vf.cvt.f32.bf16 v9, v5
    s.muli       s4, s1, #10
    s.addi       s11, s7, #10
    v.splat      v5, s11
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a3, s5
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v7
    s.add        s5, s4, s9
    s.movz       s4, #11
    s.add        s11, s5, s16
    v.extract    s5, v1, #11
    vf.mul       v7, v0, v3
    s.add        s18, s13, s11
    v.splat      v0, s5
    vf.cvt.f32.bf16 v9, v7
    s.muli       s5, s1, #11
    s.addi       s11, s7, #11
    v.splat      v7, s11
    @p3 v.st.h       [s19, #0], v9
    a.vread      v9, a3, s2
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v8
    s.add        s2, s5, s9
    s.movz       s5, #12
    s.add        s11, s2, s16
    v.extract    s2, v1, #12
    vf.mul       v8, v5, v3
    s.add        s19, s13, s11
    v.splat      v5, s2
    vf.cvt.f32.bf16 v9, v8
    s.muli       s2, s1, #12
    s.addi       s11, s7, #12
    v.splat      v8, s11
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a3, s6
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s6, s2, s9
    s.movz       s2, #13
    s.add        s11, s6, s16
    v.extract    s6, v1, #13
    vf.mul       v4, v7, v3
    s.add        s17, s13, s11
    v.splat      v7, s6
    vf.cvt.f32.bf16 v9, v4
    s.muli       s6, s1, #13
    s.addi       s11, s7, #13
    v.splat      v4, s11
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a3, s4
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s4, s6, s9
    s.movz       s6, #14
    s.add        s11, s4, s16
    v.extract    s4, v1, #14
    vf.mul       v0, v8, v3
    s.add        s18, s13, s11
    v.splat      v8, s4
    vf.cvt.f32.bf16 v9, v0
    s.muli       s4, s1, #14
    s.addi       s11, s7, #14
    v.splat      v0, s11
    @p4 v.st.h       [s19, #0], v9
    a.vread      v9, a3, s5
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s5, s4, s9
    s.movz       s4, #15
    s.add        s11, s5, s16
    v.extract    s5, v1, #15
    vf.mul       v5, v4, v3
    s.add        s19, s13, s11
    v.splat      v4, s5
    vf.cvt.f32.bf16 v9, v5
    s.muli       s5, s1, #15
    s.addi       s11, s7, #15
    v.splat      v5, s11
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a3, s2
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s2, s5, s9
    s.movz       s5, #0
    s.add        s11, s2, s16
    v.extract    s2, v1, #0
    vf.mul       v7, v0, v3
    s.add        s16, s13, s11
    v.splat      v0, s2
    vf.cvt.f32.bf16 v9, v7
    s.movz       s2, #0
    s.muli       s11, s8, #2
    s.add        s17, s2, s8                     // the tile origin
    v.splat      v7, s7
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a3, s6
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.movz       s2, #0
    v.splat      v8, s17
    s.add        s6, s2, s3                      // the tile origin
    s.add        s2, s9, s11
    vf.mul       v9, v5, v3
    v.add        v5, v2, v8
    v.splat      v8, s6
    v.cmp.lt     p1, v7, v6
    s.add        s6, s13, s2
    vf.cvt.f32.bf16 v7, v9
    s.movz       s2, #1
    v.extract    s8, v1, #1
    s.muli       s17, s1, #1
    v.splat      v9, s8
    @p3 v.st.h       [s19, #0], v7
    a.vread      v7, a3, s4
    v.cmp.lt     p2, v5, v8
    p.and        p3, p1, p2
    vf.mul       v5, v7, v4
    s.addi       s4, s7, #1
    s.add        s8, s17, s9
    v.splat      v4, s4
    s.add        s4, s8, s11
    vf.mul       v7, v5, v3
    s.add        s8, s13, s4
    vf.cvt.f32.bf16 v5, v7
    s.movz       s4, #2
    v.extract    s17, v1, #2
    s.muli       s18, s1, #2
    v.splat      v7, s17
    @p4 v.st.h       [s16, #0], v5
    a.vread      v5, a4, s5
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v5, v0
    s.addi       s5, s7, #2
    s.add        s16, s18, s9
    v.splat      v0, s5
    s.add        s5, s16, s11
    vf.mul       v5, v4, v3
    s.add        s16, s13, s5
    vf.cvt.f32.bf16 v4, v5
    s.movz       s5, #3
    v.extract    s17, v1, #3
    s.muli       s18, s1, #3
    v.splat      v5, s17
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a4, s2
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s2, s7, #3
    s.add        s6, s18, s9
    v.splat      v4, s2
    s.add        s2, s6, s11
    vf.mul       v8, v0, v3
    s.add        s6, s13, s2
    s.movz       s2, #4
    v.extract    s17, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s17
    s.muli       s17, s1, #4
    s.addi       s18, s7, #4
    @p4 v.st.h       [s8, #0], v0
    a.vread      v0, a4, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v7
    s.add        s4, s17, s9
    v.splat      v0, s18
    s.add        s8, s4, s11
    s.movz       s4, #5
    vf.mul       v7, v4, v3
    s.add        s17, s13, s8
    v.extract    s8, v1, #5
    v.splat      v4, s8
    vf.cvt.f32.bf16 v9, v7
    s.muli       s8, s1, #5
    s.addi       s18, s7, #5
    v.splat      v7, s18
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a4, s5
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s5, s8, s9
    s.movz       s8, #6
    s.add        s16, s5, s11
    v.extract    s5, v1, #6
    vf.mul       v5, v0, v3
    s.add        s18, s13, s16
    v.splat      v0, s5
    vf.cvt.f32.bf16 v9, v5
    s.muli       s5, s1, #6
    s.addi       s16, s7, #6
    v.splat      v5, s16
    @p4 v.st.h       [s6, #0], v9
    a.vread      v9, a4, s2
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.add        s2, s5, s9
    s.movz       s5, #7
    s.add        s6, s2, s11
    v.extract    s2, v1, #7
    vf.mul       v8, v7, v3
    s.add        s16, s13, s6
    v.splat      v7, s2
    vf.cvt.f32.bf16 v9, v8
    s.muli       s2, s1, #7
    s.addi       s6, s7, #7
    v.splat      v8, s6
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a4, s4
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v4
    s.add        s4, s2, s9
    s.movz       s2, #8
    s.add        s6, s4, s11
    v.extract    s4, v1, #8
    vf.mul       v4, v5, v3
    s.add        s17, s13, s6
    v.splat      v5, s4
    vf.cvt.f32.bf16 v9, v4
    s.muli       s4, s1, #8
    s.addi       s6, s7, #8
    v.splat      v4, s6
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a4, s8
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s6, s4, s9
    s.movz       s4, #9
    s.add        s8, s6, s11
    v.extract    s6, v1, #9
    vf.mul       v0, v8, v3
    s.add        s18, s13, s8
    v.splat      v8, s6
    vf.cvt.f32.bf16 v9, v0
    s.muli       s6, s1, #9
    s.addi       s8, s7, #9
    v.splat      v0, s8
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a4, s5
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.add        s5, s6, s9
    s.movz       s6, #10
    s.add        s8, s5, s11
    v.extract    s5, v1, #10
    vf.mul       v7, v4, v3
    s.add        s16, s13, s8
    v.splat      v4, s5
    vf.cvt.f32.bf16 v9, v7
    s.muli       s5, s1, #10
    s.addi       s8, s7, #10
    v.splat      v7, s8
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a4, s2
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v5
    s.add        s2, s5, s9
    s.movz       s5, #11
    s.add        s8, s2, s11
    v.extract    s2, v1, #11
    vf.mul       v5, v0, v3
    s.add        s17, s13, s8
    v.splat      v0, s2
    vf.cvt.f32.bf16 v9, v5
    s.muli       s2, s1, #11
    s.addi       s8, s7, #11
    v.splat      v5, s8
    @p3 v.st.h       [s18, #0], v9
    a.vread      v9, a4, s4
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v8
    s.add        s4, s2, s9
    s.movz       s2, #12
    s.add        s8, s4, s11
    v.extract    s4, v1, #12
    vf.mul       v8, v7, v3
    s.add        s18, s13, s8
    v.splat      v7, s4
    vf.cvt.f32.bf16 v9, v8
    s.muli       s4, s1, #12
    s.addi       s8, s7, #12
    v.splat      v8, s8
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a4, s6
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v4
    s.add        s6, s4, s9
    s.movz       s4, #13
    s.add        s8, s6, s11
    v.extract    s6, v1, #13
    vf.mul       v4, v5, v3
    s.add        s16, s13, s8
    v.splat      v5, s6
    vf.cvt.f32.bf16 v9, v4
    s.muli       s6, s1, #13
    s.addi       s8, s7, #13
    v.splat      v4, s8
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a4, s5
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s5, s6, s9
    s.movz       s6, #14
    s.add        s8, s5, s11
    v.extract    s5, v1, #14
    vf.mul       v0, v8, v3
    s.add        s17, s13, s8
    v.splat      v8, s5
    vf.cvt.f32.bf16 v9, v0
    s.muli       s5, s1, #14
    s.addi       s8, s7, #14
    v.splat      v0, s8
    @p4 v.st.h       [s18, #0], v9
    a.vread      v9, a4, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v7
    s.add        s2, s5, s9
    s.movz       s5, #15
    s.add        s8, s2, s11
    v.extract    s2, v1, #15
    vf.mul       v7, v4, v3
    s.add        s18, s13, s8
    v.splat      v4, s2
    vf.cvt.f32.bf16 v9, v7
    s.muli       s2, s1, #15
    s.addi       s8, s7, #15
    v.splat      v7, s8
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a4, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s4, s2, s9
    s.movz       s2, #0
    s.add        s8, s4, s11
    v.extract    s4, v1, #0
    vf.mul       v5, v0, v3
    s.add        s11, s13, s8
    v.splat      v0, s4
    vf.cvt.f32.bf16 v9, v5
    s.movz       s4, #0
    s.muli       s8, s12, #2
    s.add        s16, s4, s12                    // the tile origin
    v.splat      v5, s7
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a4, s6
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.movz       s4, #0
    v.splat      v8, s16
    s.add        s6, s4, s3                      // the tile origin
    s.add        s4, s9, s8
    vf.mul       v9, v7, v3
    v.add        v7, v2, v8
    v.splat      v8, s6
    v.cmp.lt     p1, v5, v6
    s.add        s6, s13, s4
    vf.cvt.f32.bf16 v5, v9
    s.movz       s4, #1
    v.extract    s12, v1, #1
    s.muli       s16, s1, #1
    v.splat      v9, s12
    @p3 v.st.h       [s18, #0], v5
    a.vread      v5, a4, s5
    v.cmp.lt     p2, v7, v8
    p.and        p3, p1, p2
    vf.mul       v7, v5, v4
    s.addi       s5, s7, #1
    s.add        s12, s16, s9
    v.splat      v4, s5
    s.add        s5, s12, s8
    vf.mul       v5, v7, v3
    s.add        s12, s13, s5
    vf.cvt.f32.bf16 v7, v5
    s.movz       s5, #2
    v.extract    s16, v1, #2
    s.muli       s17, s1, #2
    v.splat      v5, s16
    @p4 v.st.h       [s11, #0], v7
    a.vread      v7, a5, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v7, v0
    s.addi       s2, s7, #2
    s.add        s11, s17, s9
    v.splat      v0, s2
    s.add        s2, s11, s8
    vf.mul       v7, v4, v3
    s.add        s11, s13, s2
    vf.cvt.f32.bf16 v4, v7
    s.movz       s2, #3
    v.extract    s16, v1, #3
    s.muli       s17, s1, #3
    v.splat      v7, s16
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a5, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s4, s7, #3
    s.add        s6, s17, s9
    v.splat      v4, s4
    s.add        s4, s6, s8
    vf.mul       v8, v0, v3
    s.add        s6, s13, s4
    s.movz       s4, #4
    v.extract    s16, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s16
    s.muli       s16, s1, #4
    s.addi       s17, s7, #4
    @p4 v.st.h       [s12, #0], v0
    a.vread      v0, a5, s5
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v5
    s.add        s5, s16, s9
    v.splat      v0, s17
    s.add        s12, s5, s8
    s.movz       s5, #5
    vf.mul       v5, v4, v3
    s.add        s16, s13, s12
    v.extract    s12, v1, #5
    v.splat      v4, s12
    vf.cvt.f32.bf16 v9, v5
    s.muli       s12, s1, #5
    s.addi       s17, s7, #5
    v.splat      v5, s17
    @p3 v.st.h       [s11, #0], v9
    a.vread      v9, a5, s2
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s2, s12, s9
    s.movz       s11, #6
    s.add        s12, s2, s8
    v.extract    s2, v1, #6
    vf.mul       v7, v0, v3
    s.add        s17, s13, s12
    v.splat      v0, s2
    vf.cvt.f32.bf16 v9, v7
    s.muli       s2, s1, #6
    s.addi       s12, s7, #6
    v.splat      v7, s12
    @p4 v.st.h       [s6, #0], v9
    a.vread      v9, a5, s4
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.add        s4, s2, s9
    s.movz       s2, #7
    s.add        s6, s4, s8
    v.extract    s4, v1, #7
    vf.mul       v8, v5, v3
    s.add        s12, s13, s6
    v.splat      v5, s4
    vf.cvt.f32.bf16 v9, v8
    s.muli       s4, s1, #7
    s.addi       s6, s7, #7
    v.splat      v8, s6
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a5, s5
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v4
    s.add        s5, s4, s9
    s.movz       s4, #8
    s.add        s6, s5, s8
    v.extract    s5, v1, #8
    vf.mul       v4, v7, v3
    s.add        s16, s13, s6
    v.splat      v7, s5
    vf.cvt.f32.bf16 v9, v4
    s.muli       s5, s1, #8
    s.addi       s6, s7, #8
    v.splat      v4, s6
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a5, s11
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s6, s5, s9
    s.movz       s5, #9
    s.add        s11, s6, s8
    v.extract    s6, v1, #9
    vf.mul       v0, v8, v3
    s.add        s17, s13, s11
    v.splat      v8, s6
    vf.cvt.f32.bf16 v9, v0
    s.muli       s6, s1, #9
    s.addi       s11, s7, #9
    v.splat      v0, s11
    @p3 v.st.h       [s12, #0], v9
    a.vread      v9, a5, s2
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v5
    s.add        s2, s6, s9
    s.movz       s6, #10
    s.add        s11, s2, s8
    v.extract    s2, v1, #10
    vf.mul       v5, v4, v3
    s.add        s12, s13, s11
    v.splat      v4, s2
    vf.cvt.f32.bf16 v9, v5
    s.muli       s2, s1, #10
    s.addi       s11, s7, #10
    v.splat      v5, s11
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a5, s4
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v7
    s.add        s4, s2, s9
    s.movz       s2, #11
    s.add        s11, s4, s8
    v.extract    s4, v1, #11
    vf.mul       v7, v0, v3
    s.add        s16, s13, s11
    v.splat      v0, s4
    vf.cvt.f32.bf16 v9, v7
    s.muli       s4, s1, #11
    s.addi       s11, s7, #11
    v.splat      v7, s11
    @p3 v.st.h       [s17, #0], v9
    a.vread      v9, a5, s5
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v8
    s.add        s5, s4, s9
    s.movz       s4, #12
    s.add        s11, s5, s8
    v.extract    s5, v1, #12
    vf.mul       v8, v5, v3
    s.add        s17, s13, s11
    v.splat      v5, s5
    vf.cvt.f32.bf16 v9, v8
    s.muli       s5, s1, #12
    s.addi       s11, s7, #12
    v.splat      v8, s11
    @p4 v.st.h       [s12, #0], v9
    a.vread      v9, a5, s6
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v4
    s.add        s6, s5, s9
    s.movz       s5, #13
    s.add        s11, s6, s8
    v.extract    s6, v1, #13
    vf.mul       v4, v7, v3
    s.add        s12, s13, s11
    v.splat      v7, s6
    vf.cvt.f32.bf16 v9, v4
    s.muli       s6, s1, #13
    s.addi       s11, s7, #13
    v.splat      v4, s11
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a5, s2
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s2, s6, s9
    s.movz       s6, #14
    s.add        s11, s2, s8
    v.extract    s2, v1, #14
    vf.mul       v0, v8, v3
    s.add        s16, s13, s11
    v.splat      v8, s2
    vf.cvt.f32.bf16 v9, v0
    s.muli       s2, s1, #14
    s.addi       s11, s7, #14
    v.splat      v0, s11
    @p4 v.st.h       [s17, #0], v9
    a.vread      v9, a5, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v5
    s.add        s4, s2, s9
    s.movz       s2, #15
    s.add        s11, s4, s8
    v.extract    s4, v1, #15
    vf.mul       v5, v4, v3
    s.add        s17, s13, s11
    v.splat      v4, s4
    vf.cvt.f32.bf16 v9, v5
    s.muli       s4, s1, #15
    s.addi       s11, s7, #15
    v.splat      v5, s11
    @p3 v.st.h       [s12, #0], v9
    a.vread      v9, a5, s5
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v7
    s.add        s5, s4, s9
    s.movz       s4, #0
    s.add        s11, s5, s8
    v.extract    s5, v1, #0
    vf.mul       v7, v0, v3
    s.add        s8, s13, s11
    v.splat      v0, s5
    vf.cvt.f32.bf16 v9, v7
    s.movz       s5, #0
    s.muli       s11, s10, #2
    s.add        s12, s5, s10                    // the tile origin
    v.splat      v7, s7
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a5, s6
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v8
    s.movz       s5, #0
    v.splat      v8, s12
    s.add        s6, s5, s3                      // the tile origin
    s.add        s5, s9, s11
    vf.mul       v9, v5, v3
    v.add        v5, v2, v8
    v.splat      v8, s6
    v.cmp.lt     p1, v7, v6
    s.add        s6, s13, s5
    vf.cvt.f32.bf16 v7, v9
    s.movz       s5, #1
    v.extract    s10, v1, #1
    s.muli       s12, s1, #1
    v.splat      v9, s10
    @p3 v.st.h       [s17, #0], v7
    a.vread      v7, a5, s2
    v.cmp.lt     p2, v5, v8
    p.and        p3, p1, p2
    vf.mul       v5, v7, v4
    s.addi       s2, s7, #1
    s.add        s10, s12, s9
    v.splat      v4, s2
    s.add        s2, s10, s11
    vf.mul       v7, v5, v3
    s.add        s10, s13, s2
    vf.cvt.f32.bf16 v5, v7
    s.movz       s2, #2
    v.extract    s12, v1, #2
    s.muli       s16, s1, #2
    v.splat      v7, s12
    @p4 v.st.h       [s8, #0], v5
    a.vread      v5, a6, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v5, v0
    s.addi       s4, s7, #2
    s.add        s8, s16, s9
    v.splat      v0, s4
    s.add        s4, s8, s11
    vf.mul       v5, v4, v3
    s.add        s8, s13, s4
    vf.cvt.f32.bf16 v4, v5
    s.movz       s4, #3
    v.extract    s12, v1, #3
    s.muli       s16, s1, #3
    v.splat      v5, s12
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a6, s5
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v9
    s.addi       s5, s7, #3
    s.add        s6, s16, s9
    v.splat      v4, s5
    s.add        s5, s6, s11
    vf.mul       v8, v0, v3
    s.add        s6, s13, s5
    s.movz       s5, #4
    v.extract    s12, v1, #4
    vf.cvt.f32.bf16 v0, v8
    v.splat      v8, s12
    s.muli       s12, s1, #4
    s.addi       s16, s7, #4
    @p4 v.st.h       [s10, #0], v0
    a.vread      v0, a6, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v7
    s.add        s2, s12, s9
    v.splat      v0, s16
    s.add        s10, s2, s11
    s.movz       s2, #5
    vf.mul       v7, v4, v3
    s.add        s12, s13, s10
    v.extract    s10, v1, #5
    v.splat      v4, s10
    vf.cvt.f32.bf16 v9, v7
    s.muli       s10, s1, #5
    s.addi       s16, s7, #5
    v.splat      v7, s16
    @p3 v.st.h       [s8, #0], v9
    a.vread      v9, a6, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s4, s10, s9
    s.movz       s8, #6
    s.add        s10, s4, s11
    v.extract    s4, v1, #6
    vf.mul       v5, v0, v3
    s.add        s16, s13, s10
    v.splat      v0, s4
    vf.cvt.f32.bf16 v9, v5
    s.muli       s4, s1, #6
    s.addi       s10, s7, #6
    v.splat      v5, s10
    @p4 v.st.h       [s6, #0], v9
    a.vread      v9, a6, s5
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.add        s5, s4, s9
    s.movz       s4, #7
    s.add        s6, s5, s11
    v.extract    s5, v1, #7
    vf.mul       v8, v7, v3
    s.add        s10, s13, s6
    v.splat      v7, s5
    vf.cvt.f32.bf16 v9, v8
    s.muli       s5, s1, #7
    s.addi       s6, s7, #7
    v.splat      v8, s6
    @p3 v.st.h       [s12, #0], v9
    a.vread      v9, a6, s2
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v9, v4
    s.add        s2, s5, s9
    s.movz       s5, #8
    s.add        s6, s2, s11
    v.extract    s2, v1, #8
    vf.mul       v4, v5, v3
    s.add        s12, s13, s6
    v.splat      v5, s2
    vf.cvt.f32.bf16 v9, v4
    s.muli       s2, s1, #8
    s.addi       s6, s7, #8
    v.splat      v4, s6
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a6, s8
    v.cmp.lt     p1, v8, v6
    p.and        p4, p1, p2
    vf.mul       v8, v9, v0
    s.add        s6, s2, s9
    s.movz       s2, #9
    s.add        s8, s6, s11
    v.extract    s6, v1, #9
    vf.mul       v0, v8, v3
    s.add        s16, s13, s8
    v.splat      v8, s6
    vf.cvt.f32.bf16 v9, v0
    s.muli       s6, s1, #9
    s.addi       s8, s7, #9
    v.splat      v0, s8
    @p3 v.st.h       [s10, #0], v9
    a.vread      v9, a6, s4
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v9, v7
    s.add        s4, s6, s9
    s.movz       s6, #10
    s.add        s8, s4, s11
    v.extract    s4, v1, #10
    vf.mul       v7, v4, v3
    s.add        s10, s13, s8
    v.splat      v4, s4
    vf.cvt.f32.bf16 v9, v7
    s.muli       s4, s1, #10
    s.addi       s8, s7, #10
    v.splat      v7, s8
    @p4 v.st.h       [s12, #0], v9
    a.vread      v9, a6, s5
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v9, v5
    s.add        s5, s4, s9
    s.movz       s4, #11
    s.add        s8, s5, s11
    v.extract    s5, v1, #11
    vf.mul       v5, v0, v3
    s.add        s12, s13, s8
    v.splat      v0, s5
    vf.cvt.f32.bf16 v9, v5
    s.muli       s5, s1, #11
    s.addi       s8, s7, #11
    v.splat      v5, s8
    @p3 v.st.h       [s16, #0], v9
    a.vread      v9, a6, s2
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v9, v8
    s.add        s2, s5, s9
    s.movz       s5, #12
    s.add        s8, s2, s11
    v.extract    s2, v1, #12
    vf.mul       v8, v7, v3
    s.add        s16, s13, s8
    v.splat      v7, s2
    vf.cvt.f32.bf16 v9, v8
    s.muli       s2, s1, #12
    s.addi       s8, s7, #12
    v.splat      v8, s8
    @p4 v.st.h       [s10, #0], v9
    a.vread      v9, a6, s6
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v9, v4
    s.add        s6, s2, s9
    s.movz       s2, #13
    s.add        s8, s6, s11
    v.extract    s6, v1, #13
    vf.mul       v4, v5, v3
    s.add        s10, s13, s8
    v.splat      v5, s6
    vf.cvt.f32.bf16 v9, v4
    s.muli       s6, s1, #13
    s.addi       s8, s7, #13
    v.splat      v4, s8
    @p3 v.st.h       [s12, #0], v9
    a.vread      v9, a6, s4
    v.cmp.lt     p1, v8, v6
    p.and        p3, p1, p2
    vf.mul       v8, v9, v0
    s.add        s4, s6, s9
    s.movz       s6, #14
    s.add        s8, s4, s11
    v.extract    s4, v1, #14
    vf.mul       v0, v8, v3
    s.add        s12, s13, s8
    v.splat      v8, s4
    vf.cvt.f32.bf16 v9, v0
    s.muli       s4, s1, #14
    s.addi       s8, s7, #14
    v.splat      v0, s8
    @p4 v.st.h       [s16, #0], v9
    a.vread      v9, a6, s5
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v9, v7
    s.add        s5, s4, s9
    s.movz       s4, #15
    s.add        s8, s5, s11
    v.extract    s5, v1, #15
    vf.mul       v7, v4, v3
    s.add        s16, s13, s8
    v.splat      v4, s5
    vf.cvt.f32.bf16 v9, v7
    s.muli       s5, s1, #15
    s.addi       s8, s7, #15
    v.splat      v7, s8
    @p3 v.st.h       [s10, #0], v9
    a.vread      v9, a6, s2
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v9, v5
    s.add        s2, s5, s9
    s.movz       s5, #0
    s.add        s8, s2, s11
    v.extract    s2, v1, #0
    vf.mul       v5, v0, v3
    s.add        s10, s13, s8
    v.splat      v0, s2
    vf.cvt.f32.bf16 v9, v5
    s.movz       s2, #0
    s.muli       s8, s14, #2
    s.add        s11, s2, s14                    // the tile origin
    v.splat      v5, s7
    @p4 v.st.h       [s12, #0], v9
    a.vread      v9, a6, s6
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v9, v8
    s.movz       s2, #0
    v.splat      v8, s11
    s.add        s6, s2, s3                      // the tile origin
    s.add        s2, s9, s8
    vf.mul       v9, v7, v3
    v.add        v7, v2, v8
    v.splat      v2, s6
    v.cmp.lt     p1, v5, v6
    s.add        s3, s13, s2
    vf.cvt.f32.bf16 v5, v9
    s.movz       s2, #1
    v.extract    s6, v1, #1
    s.muli       s11, s1, #1
    v.splat      v8, s6
    @p3 v.st.h       [s16, #0], v5
    a.vread      v5, a6, s4
    v.cmp.lt     p2, v7, v2
    p.and        p3, p1, p2
    vf.mul       v2, v5, v4
    s.addi       s4, s7, #1
    s.add        s6, s11, s9
    v.splat      v4, s4
    s.add        s4, s6, s8
    vf.mul       v5, v2, v3
    s.add        s6, s13, s4
    vf.cvt.f32.bf16 v2, v5
    s.movz       s4, #2
    v.extract    s11, v1, #2
    s.muli       s12, s1, #2
    v.splat      v5, s11
    @p4 v.st.h       [s10, #0], v2
    a.vread      v2, a7, s5
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v2, v0
    s.addi       s5, s7, #2
    s.add        s10, s12, s9
    v.splat      v0, s5
    s.add        s5, s10, s8
    vf.mul       v2, v4, v3
    s.add        s10, s13, s5
    vf.cvt.f32.bf16 v4, v2
    s.movz       s5, #3
    v.extract    s11, v1, #3
    s.muli       s12, s1, #3
    v.splat      v2, s11
    @p3 v.st.h       [s3, #0], v4
    a.vread      v4, a7, s2
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v4, v8
    s.addi       s2, s7, #3
    s.add        s3, s12, s9
    v.splat      v4, s2
    s.add        s2, s3, s8
    vf.mul       v7, v0, v3
    s.add        s3, s13, s2
    s.movz       s2, #4
    v.extract    s11, v1, #4
    vf.cvt.f32.bf16 v0, v7
    v.splat      v7, s11
    s.muli       s11, s1, #4
    s.addi       s12, s7, #4
    @p4 v.st.h       [s6, #0], v0
    a.vread      v0, a7, s4
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v0, v5
    s.add        s4, s11, s9
    v.splat      v0, s12
    s.add        s6, s4, s8
    s.movz       s4, #5
    vf.mul       v5, v4, v3
    s.add        s11, s13, s6
    v.extract    s6, v1, #5
    v.splat      v4, s6
    vf.cvt.f32.bf16 v8, v5
    s.muli       s6, s1, #5
    s.addi       s12, s7, #5
    v.splat      v5, s12
    @p3 v.st.h       [s10, #0], v8
    a.vread      v8, a7, s5
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v8, v2
    s.add        s5, s6, s9
    s.movz       s6, #6
    s.add        s10, s5, s8
    v.extract    s5, v1, #6
    vf.mul       v2, v0, v3
    s.add        s12, s13, s10
    v.splat      v0, s5
    vf.cvt.f32.bf16 v8, v2
    s.muli       s5, s1, #6
    s.addi       s10, s7, #6
    v.splat      v2, s10
    @p4 v.st.h       [s3, #0], v8
    a.vread      v8, a7, s2
    v.cmp.lt     p1, v5, v6
    p.and        p4, p1, p2
    vf.mul       v5, v8, v7
    s.add        s2, s5, s9
    s.movz       s3, #7
    s.add        s5, s2, s8
    v.extract    s2, v1, #7
    vf.mul       v7, v5, v3
    s.add        s10, s13, s5
    v.splat      v5, s2
    vf.cvt.f32.bf16 v8, v7
    s.muli       s2, s1, #7
    s.addi       s5, s7, #7
    v.splat      v7, s5
    @p3 v.st.h       [s11, #0], v8
    a.vread      v8, a7, s4
    v.cmp.lt     p1, v2, v6
    p.and        p3, p1, p2
    vf.mul       v2, v8, v4
    s.add        s4, s2, s9
    s.movz       s2, #8
    s.add        s5, s4, s8
    v.extract    s4, v1, #8
    vf.mul       v4, v2, v3
    s.add        s11, s13, s5
    v.splat      v2, s4
    vf.cvt.f32.bf16 v8, v4
    s.muli       s4, s1, #8
    s.addi       s5, s7, #8
    v.splat      v4, s5
    @p4 v.st.h       [s12, #0], v8
    a.vread      v8, a7, s6
    v.cmp.lt     p1, v7, v6
    p.and        p4, p1, p2
    vf.mul       v7, v8, v0
    s.add        s5, s4, s9
    s.movz       s4, #9
    s.add        s6, s5, s8
    v.extract    s5, v1, #9
    vf.mul       v0, v7, v3
    s.add        s12, s13, s6
    v.splat      v7, s5
    vf.cvt.f32.bf16 v8, v0
    s.muli       s5, s1, #9
    s.addi       s6, s7, #9
    v.splat      v0, s6
    @p3 v.st.h       [s10, #0], v8
    a.vread      v8, a7, s3
    v.cmp.lt     p1, v4, v6
    p.and        p3, p1, p2
    vf.mul       v4, v8, v5
    s.add        s3, s5, s9
    s.movz       s5, #10
    s.add        s6, s3, s8
    v.extract    s3, v1, #10
    vf.mul       v5, v4, v3
    s.add        s10, s13, s6
    v.splat      v4, s3
    vf.cvt.f32.bf16 v8, v5
    s.muli       s3, s1, #10
    s.addi       s6, s7, #10
    v.splat      v5, s6
    @p4 v.st.h       [s11, #0], v8
    a.vread      v8, a7, s2
    v.cmp.lt     p1, v0, v6
    p.and        p4, p1, p2
    vf.mul       v0, v8, v2
    s.add        s2, s3, s9
    s.movz       s3, #11
    s.add        s6, s2, s8
    v.extract    s2, v1, #11
    vf.mul       v2, v0, v3
    s.add        s11, s13, s6
    v.splat      v0, s2
    vf.cvt.f32.bf16 v8, v2
    s.muli       s2, s1, #11
    s.addi       s6, s7, #11
    v.splat      v2, s6
    @p3 v.st.h       [s12, #0], v8
    a.vread      v8, a7, s4
    v.cmp.lt     p1, v5, v6
    p.and        p3, p1, p2
    vf.mul       v5, v8, v7
    s.add        s4, s2, s9
    s.movz       s2, #12
    s.add        s6, s4, s8
    v.extract    s4, v1, #12
    vf.mul       v7, v5, v3
    s.add        s12, s13, s6
    v.splat      v5, s4
    vf.cvt.f32.bf16 v8, v7
    s.muli       s4, s1, #12
    s.addi       s6, s7, #12
    v.splat      v7, s6
    @p4 v.st.h       [s10, #0], v8
    a.vread      v8, a7, s5
    v.cmp.lt     p1, v2, v6
    p.and        p4, p1, p2
    vf.mul       v2, v8, v4
    s.add        s5, s4, s9
    s.movz       s4, #13
    s.add        s6, s5, s8
    v.extract    s5, v1, #13
    vf.mul       v4, v2, v3
    s.add        s10, s13, s6
    v.splat      v2, s5
    vf.cvt.f32.bf16 v8, v4
    s.muli       s5, s1, #13
    s.addi       s6, s7, #13
    v.splat      v4, s6
    @p3 v.st.h       [s11, #0], v8
    a.vread      v8, a7, s3
    v.cmp.lt     p1, v7, v6
    p.and        p3, p1, p2
    vf.mul       v7, v8, v0
    s.add        s3, s5, s9
    s.movz       s5, #14
    s.add        s6, s3, s8
    v.extract    s3, v1, #14
    vf.mul       v0, v7, v3
    s.add        s11, s13, s6
    v.splat      v7, s3
    vf.cvt.f32.bf16 v8, v0
    s.muli       s3, s1, #14
    s.addi       s6, s7, #14
    v.splat      v0, s6
    @p4 v.st.h       [s12, #0], v8
    a.vread      v8, a7, s2
    v.cmp.lt     p1, v4, v6
    p.and        p4, p1, p2
    vf.mul       v4, v8, v5
    s.add        s2, s3, s9
    s.movz       s3, #15
    s.add        s6, s2, s8
    v.extract    s2, v1, #15
    vf.mul       v1, v4, v3
    s.add        s12, s13, s6
    v.splat      v4, s2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s2, s1, #15
    s.addi       s1, s7, #15
    v.splat      v1, s1
    @p3 v.st.h       [s10, #0], v5
    a.vread      v5, a7, s4
    v.cmp.lt     p1, v0, v6
    p.and        p3, p1, p2
    vf.mul       v0, v5, v2
    s.add        s1, s2, s9
    s.add        s2, s1, s8
    vf.mul       v2, v0, v3
    s.add        s1, s13, s2
    vf.cvt.f32.bf16 v0, v2
    @p4 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s5
    v.cmp.lt     p1, v1, v6
    p.and        p4, p1, p2
    vf.mul       v1, v0, v7
    vf.mul       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s12, #0], v1
    a.vread      v0, a7, s3
    vf.mul       v1, v0, v4
    vf.mul       v0, v1, v3
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s1, #0], v1
    exit
    exit
