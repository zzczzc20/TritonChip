    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #0
    v.movi       v2, #0
    v.extract    s1, v0, #0
    v.extract    s2, v0, #1
    s.shli       s3, s1, #32
    s.shli       s1, s2, #32
    s.ashri      s2, s3, #32
    s.rdspecial  s3, arg_base
    s.lshri      s5, s2, #32
    v.extract    s6, v0, #2
    s.ashri      s7, s1, #32
    s.ld.d       s1, [s3, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.shli       s8, s6, #32
    s.lshri      s6, s7, #32
    v.extract    s9, v0, #3
    s.ashri      s10, s8, #32
    s.shli       s8, s9, #32
    s.lshri      s9, s10, #32
    s.ashri      s11, s8, #32
    s.shli       s8, s4, #32
    s.lshri      s4, s11, #32
    s.movz       s12, #16
    s.ld.d       s13, [s3, #8]                   // out_ptr0: device_ptr64 at arg_base+8
    v.insert     v1, s2, #0
    v.insert     v2, s5, #0
    v.extract    s2, v0, #4
    v.insert     v1, s7, #1
    v.insert     v2, s6, #1
    s.ashri      s3, s8, #32
    v.insert     v1, s10, #2
    v.insert     v2, s9, #2
    s.mul        s5, s3, s12
    v.insert     v1, s11, #3
    v.insert     v2, s4, #3
    .li       s3, #2415886336
    s.shli       s4, s2, #32
    .li       s2, #2415886336
    s.ashri      s6, s4, #32
    .li       s4, #2415886336
    v.insert     v1, s6, #4
    .li       s7, #2415886336
    s.lshri      s8, s6, #32
    .li       s6, #2415886336
    v.insert     v2, s8, #4
    .li       s8, #2415886336
    v.extract    s9, v0, #5
    .li       s10, #2415886336
    s.shli       s11, s9, #32
    .li       s9, #2415886336
    s.ashri      s12, s11, #32
    .li       s11, #2415886336
    v.insert     v1, s12, #5
    .li       s14, #2415886336
    s.lshri      s15, s12, #32
    .li       s12, #2415886336
    v.insert     v2, s15, #5
    .li       s15, #2415886336
    v.extract    s16, v0, #6
    .li       s17, #2415886336
    s.shli       s18, s16, #32
    .li       s16, #2415886336
    s.ashri      s19, s18, #32
    .li       s18, #2415886336
    v.insert     v1, s19, #6
    .li       s20, #2415886336
    s.lshri      s21, s19, #32
    s.movz       s19, #0
    v.extract    s22, v0, #7
    v.extract    s23, v0, #8
    s.shli       s24, s22, #32
    v.insert     v2, s21, #6
    s.ashri      s21, s24, #32
    s.shli       s22, s23, #32
    s.lshri      s23, s21, #32
    v.extract    s24, v0, #9
    s.ashri      s25, s22, #32
    v.insert     v1, s21, #7
    v.insert     v2, s23, #7
    s.shli       s21, s24, #32
    s.lshri      s22, s25, #32
    v.extract    s23, v0, #10
    s.ashri      s24, s21, #32
    v.insert     v1, s25, #8
    v.insert     v2, s22, #8
    s.shli       s21, s23, #32
    s.lshri      s22, s24, #32
    v.extract    s23, v0, #11
    s.ashri      s25, s21, #32
    v.insert     v1, s24, #9
    v.insert     v2, s22, #9
    s.shli       s21, s23, #32
    s.lshri      s22, s25, #32
    v.extract    s23, v0, #12
    s.ashri      s24, s21, #32
    v.insert     v1, s25, #10
    v.insert     v2, s22, #10
    s.shli       s21, s23, #32
    s.lshri      s22, s24, #32
    v.extract    s23, v0, #13
    s.ashri      s25, s21, #32
    v.insert     v1, s24, #11
    v.insert     v2, s22, #11
    s.shli       s21, s23, #32
    s.lshri      s22, s25, #32
    v.extract    s23, v0, #14
    s.ashri      s24, s21, #32
    v.insert     v1, s25, #12
    v.insert     v2, s22, #12
    s.shli       s21, s23, #32
    s.lshri      s22, s24, #32
    v.extract    s23, v0, #15
    s.ashri      s25, s21, #32
    v.insert     v1, s24, #13
    v.insert     v2, s22, #13
    s.shli       s21, s23, #32
    s.lshri      s22, s25, #32
    s.ashri      s23, s21, #32
    v.insert     v1, s25, #14
    v.insert     v2, s22, #14
    v.movi       v0, #0
    v.movi       v3, #0
    s.lshri      s21, s23, #32
    s.lshri      s22, s5, #32
    v.insert     v1, s23, #15
    v.insert     v2, s21, #15
    v.insert     v0, s5, #0
    v.insert     v3, s22, #0
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #1
    v.insert     v3, s21, #1
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #2
    v.insert     v3, s21, #2
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #3
    v.insert     v3, s21, #3
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #4
    v.insert     v3, s21, #4
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #5
    v.insert     v3, s21, #5
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #6
    v.insert     v3, s21, #6
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #7
    v.insert     v3, s21, #7
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #8
    v.insert     v3, s21, #8
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #9
    v.insert     v3, s21, #9
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #10
    v.insert     v3, s21, #10
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #11
    v.insert     v3, s21, #11
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #12
    v.insert     v3, s21, #12
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #13
    v.insert     v3, s21, #13
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #14
    v.insert     v3, s21, #14
    s.lshri      s21, s5, #32
    v.insert     v0, s5, #15
    v.insert     v3, s21, #15
    v.extract    s5, v2, #0
    v.extract    s21, v0, #0
    v.extract    s22, v3, #0
    v.extract    s23, v1, #0
    s.shli       s24, s22, #32
    s.shli       s22, s5, #32
    v.extract    s5, v3, #1
    v.extract    s25, v2, #1
    s.or         s26, s21, s24
    s.or         s21, s23, s22
    v.extract    s22, v0, #1
    s.shli       s23, s5, #32
    v.extract    s5, v1, #1
    s.shli       s24, s25, #32
    s.add        s25, s26, s21
    v.extract    s21, v3, #2
    v.extract    s26, v2, #2
    v.movi       v4, #0
    v.movi       v5, #0
    s.or         s27, s22, s23
    s.or         s22, s5, s24
    s.lshri      s5, s25, #32
    v.extract    s23, v0, #2
    s.shli       s24, s21, #32
    s.shli       s21, s26, #32
    s.add        s26, s27, s22
    v.extract    s22, v1, #2
    v.insert     v4, s25, #0
    v.extract    s25, v3, #3
    v.insert     v5, s5, #0
    v.extract    s5, v2, #3
    s.or         s27, s23, s24
    s.or         s23, s22, s21
    s.lshri      s21, s26, #32
    v.extract    s22, v0, #3
    s.shli       s24, s25, #32
    s.shli       s25, s5, #32
    s.add        s5, s27, s23
    v.extract    s23, v1, #3
    v.insert     v4, s26, #1
    v.extract    s26, v3, #4
    v.insert     v5, s21, #1
    v.extract    s21, v2, #4
    s.or         s27, s22, s24
    s.or         s22, s23, s25
    s.lshri      s23, s5, #32
    v.extract    s24, v0, #4
    s.shli       s25, s26, #32
    s.shli       s26, s21, #32
    s.add        s21, s27, s22
    v.extract    s22, v1, #4
    v.insert     v4, s5, #2
    v.extract    s5, v3, #5
    v.insert     v5, s23, #2
    v.extract    s23, v2, #5
    s.or         s27, s24, s25
    s.or         s24, s22, s26
    s.lshri      s22, s21, #32
    v.extract    s25, v0, #5
    s.shli       s26, s5, #32
    s.shli       s5, s23, #32
    s.add        s23, s27, s24
    v.extract    s24, v1, #5
    v.insert     v4, s21, #3
    v.extract    s21, v3, #6
    v.insert     v5, s22, #3
    v.extract    s22, v2, #6
    s.or         s27, s25, s26
    s.or         s25, s24, s5
    s.lshri      s5, s23, #32
    v.extract    s24, v0, #6
    s.shli       s26, s21, #32
    s.shli       s21, s22, #32
    s.add        s22, s27, s25
    v.extract    s25, v1, #6
    v.insert     v4, s23, #4
    v.extract    s23, v3, #7
    v.insert     v5, s5, #4
    v.extract    s5, v2, #7
    s.or         s27, s24, s26
    s.or         s24, s25, s21
    s.lshri      s21, s22, #32
    v.extract    s25, v0, #7
    s.shli       s26, s23, #32
    s.shli       s23, s5, #32
    s.add        s5, s27, s24
    v.extract    s24, v1, #7
    v.insert     v4, s22, #5
    v.extract    s22, v3, #8
    v.insert     v5, s21, #5
    v.extract    s21, v2, #8
    s.or         s27, s25, s26
    s.or         s25, s24, s23
    s.lshri      s23, s5, #32
    v.extract    s24, v0, #8
    s.shli       s26, s22, #32
    s.shli       s22, s21, #32
    s.add        s21, s27, s25
    v.extract    s25, v1, #8
    v.insert     v4, s5, #6
    v.extract    s5, v3, #9
    v.insert     v5, s23, #6
    v.extract    s23, v2, #9
    s.or         s27, s24, s26
    s.or         s24, s25, s22
    s.lshri      s22, s21, #32
    v.extract    s25, v0, #9
    s.shli       s26, s5, #32
    s.shli       s5, s23, #32
    s.add        s23, s27, s24
    v.extract    s24, v1, #9
    v.insert     v4, s21, #7
    v.extract    s21, v3, #10
    v.insert     v5, s22, #7
    v.extract    s22, v2, #10
    s.or         s27, s25, s26
    s.or         s25, s24, s5
    s.lshri      s5, s23, #32
    v.extract    s24, v0, #10
    s.shli       s26, s21, #32
    s.shli       s21, s22, #32
    s.add        s22, s27, s25
    v.extract    s25, v1, #10
    v.insert     v4, s23, #8
    v.extract    s23, v3, #11
    v.insert     v5, s5, #8
    v.extract    s5, v2, #11
    s.or         s27, s24, s26
    s.or         s24, s25, s21
    s.lshri      s21, s22, #32
    v.extract    s25, v0, #11
    s.shli       s26, s23, #32
    s.shli       s23, s5, #32
    s.add        s5, s27, s24
    v.extract    s24, v1, #11
    v.insert     v4, s22, #9
    v.extract    s22, v3, #12
    v.insert     v5, s21, #9
    v.extract    s21, v2, #12
    s.or         s27, s25, s26
    s.or         s25, s24, s23
    s.lshri      s23, s5, #32
    v.extract    s24, v0, #12
    s.shli       s26, s22, #32
    s.shli       s22, s21, #32
    s.add        s21, s27, s25
    v.extract    s25, v1, #12
    v.insert     v4, s5, #10
    v.extract    s5, v3, #13
    v.insert     v5, s23, #10
    v.extract    s23, v2, #13
    s.or         s27, s24, s26
    s.or         s24, s25, s22
    s.lshri      s22, s21, #32
    v.extract    s25, v0, #13
    s.shli       s26, s5, #32
    s.shli       s5, s23, #32
    s.add        s23, s27, s24
    v.extract    s24, v1, #13
    v.insert     v4, s21, #11
    v.extract    s21, v3, #14
    v.insert     v5, s22, #11
    v.extract    s22, v2, #14
    s.or         s27, s25, s26
    s.or         s25, s24, s5
    s.lshri      s5, s23, #32
    v.extract    s24, v0, #14
    s.shli       s26, s21, #32
    s.shli       s21, s22, #32
    s.add        s22, s27, s25
    v.extract    s25, v1, #14
    v.insert     v4, s23, #12
    v.extract    s23, v3, #15
    v.insert     v5, s5, #12
    v.extract    s5, v2, #15
    s.or         s27, s24, s26
    s.or         s24, s25, s21
    s.lshri      s21, s22, #32
    v.extract    s25, v0, #15
    s.shli       s26, s23, #32
    s.shli       s23, s5, #32
    s.add        s5, s27, s24
    v.extract    s24, v1, #15
    v.insert     v4, s22, #13
    v.insert     v5, s21, #13
    s.or         s21, s25, s26
    s.or         s22, s24, s23
    s.lshri      s23, s5, #32
    s.add        s24, s21, s22
    v.insert     v4, s5, #14
    v.insert     v5, s23, #14
    s.lshri      s5, s24, #32
    v.insert     v4, s24, #15
    v.insert     v5, s5, #15
    v.movi       v0, #0
    v.extract    s5, v4, #0
    v.extract    s21, v5, #0
    v.extract    s22, v5, #1
    s.shli       s23, s21, #32
    v.extract    s21, v4, #1
    s.or         s24, s5, s23
    s.shli       s5, s22, #32
    s.add        s22, s24, s3
    v.extract    s3, v5, #2
    s.or         s23, s21, s5
    v.movi       v1, #0
    v.insert     v0, s22, #0
    v.extract    s5, v4, #2
    s.shli       s21, s3, #32
    s.lshri      s3, s22, #32
    s.add        s22, s23, s2
    v.extract    s2, v5, #3
    s.or         s23, s5, s21
    v.insert     v1, s3, #0
    v.insert     v0, s22, #1
    v.extract    s3, v4, #3
    s.shli       s5, s2, #32
    s.lshri      s2, s22, #32
    s.add        s21, s23, s4
    v.extract    s4, v5, #4
    s.or         s22, s3, s5
    v.insert     v1, s2, #1
    v.insert     v0, s21, #2
    v.extract    s2, v4, #4
    s.shli       s3, s4, #32
    s.lshri      s4, s21, #32
    s.add        s5, s22, s7
    v.extract    s7, v5, #5
    s.or         s21, s2, s3
    v.insert     v1, s4, #2
    v.insert     v0, s5, #3
    v.extract    s2, v4, #5
    s.shli       s3, s7, #32
    s.lshri      s4, s5, #32
    s.add        s5, s21, s6
    v.extract    s6, v5, #6
    s.or         s7, s2, s3
    v.insert     v1, s4, #3
    v.insert     v0, s5, #4
    v.extract    s2, v4, #6
    s.shli       s3, s6, #32
    s.lshri      s4, s5, #32
    s.add        s5, s7, s8
    v.extract    s6, v5, #7
    s.or         s7, s2, s3
    v.insert     v1, s4, #4
    v.insert     v0, s5, #5
    v.extract    s2, v4, #7
    s.shli       s3, s6, #32
    s.lshri      s4, s5, #32
    s.add        s5, s7, s10
    v.extract    s6, v5, #8
    s.or         s7, s2, s3
    v.insert     v1, s4, #5
    v.insert     v0, s5, #6
    v.extract    s2, v4, #8
    s.shli       s3, s6, #32
    s.lshri      s4, s5, #32
    s.add        s5, s7, s9
    v.extract    s6, v5, #9
    s.or         s7, s2, s3
    v.insert     v1, s4, #6
    v.insert     v0, s5, #7
    v.extract    s2, v4, #9
    s.shli       s3, s6, #32
    s.lshri      s4, s5, #32
    s.add        s5, s7, s11
    v.extract    s6, v5, #10
    s.or         s7, s2, s3
    v.insert     v1, s4, #7
    v.insert     v0, s5, #8
    v.extract    s2, v4, #10
    s.shli       s3, s6, #32
    s.lshri      s4, s5, #32
    s.add        s5, s7, s14
    v.extract    s6, v5, #11
    s.or         s7, s2, s3
    v.insert     v1, s4, #8
    v.insert     v0, s5, #9
    v.extract    s2, v4, #11
    s.shli       s3, s6, #32
    s.lshri      s4, s5, #32
    s.add        s5, s7, s12
    v.extract    s6, v5, #12
    s.or         s7, s2, s3
    v.insert     v1, s4, #9
    v.insert     v0, s5, #10
    v.extract    s2, v4, #12
    s.shli       s3, s6, #32
    s.lshri      s4, s5, #32
    s.add        s5, s7, s15
    v.extract    s6, v5, #13
    s.or         s7, s2, s3
    v.insert     v1, s4, #10
    v.insert     v0, s5, #11
    v.extract    s2, v4, #13
    s.shli       s3, s6, #32
    s.lshri      s4, s5, #32
    s.add        s5, s7, s17
    v.extract    s6, v5, #14
    s.or         s7, s2, s3
    v.insert     v1, s4, #11
    v.insert     v0, s5, #12
    v.extract    s2, v4, #14
    s.shli       s3, s6, #32
    s.lshri      s4, s5, #32
    s.add        s5, s7, s16
    v.extract    s6, v5, #15
    s.or         s7, s2, s3
    v.insert     v1, s4, #12
    v.insert     v0, s5, #13
    v.extract    s2, v4, #15
    s.shli       s3, s6, #32
    s.lshri      s4, s5, #32
    s.add        s5, s7, s18
    s.or         s6, s2, s3
    v.insert     v1, s4, #13
    v.insert     v0, s5, #14
    s.lshri      s2, s5, #32
    s.add        s3, s6, s20
    v.insert     v1, s2, #14
    v.insert     v0, s3, #15
    v.movi       v2, #31
    s.lshri      s2, s3, #32
    v.movi       v3, #1
    v.insert     v1, s2, #15
    v.ashr       v6, v0, v2
    v.movi       v2, #0
    v.cmp.ne     p1, v1, v6
    @p1 v.sel        v1, v3, v2
    v.reduce.or  s2, v1
    s.cmp.eq     s3, s2, s19
    br.nz        s3, narrow_ok_1
    trap         #677220
narrow_ok_1:
    v.ld.gather.sb v1, [s1, v0]                  // index is in elements (ISA sec 9.1)
    v.movi       v0, #31
    v.movi       v2, #1
    v.movi       v3, #0
    v.ashr       v6, v4, v0
    v.movi       v0, #2
    s.movz       s1, #0
    v.cmp.ne     p1, v5, v6
    @p1 v.sel        v5, v2, v3
    v.movi       v2, #1
    s.movz       s2, #2
    v.reduce.or  s2, v5
    s.movz       s3, #1
    s.cmp.eq     s3, s2, s1
    v.mul        v3, v1, v0
    v.add        v0, v3, v2
    br.nz        s3, narrow_ok_2
    trap         #677220
narrow_ok_2:
    v.st.scatter.b [s13, v4], v0
__rctx_next:
    exit
