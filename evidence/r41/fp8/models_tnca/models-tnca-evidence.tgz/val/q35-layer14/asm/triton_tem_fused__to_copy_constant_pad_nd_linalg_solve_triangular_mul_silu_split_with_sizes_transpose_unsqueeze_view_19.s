    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    s.rdspecial  s3, role_id
    s.movz       s6, #512
    s.add        s7, s1, s5                      // this context's own scratch
    s.ld.d       s1, [s2, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.addi       s5, s7, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s7, #2147483647
    .li       s8, #2147483647
    s.movz       s9, #64
    s.movz       s10, #4
    .li       s11, #68719476752
    .li       s12, #2207613190144
    s.rdspecial  s13, arg_base
    s.mul        s14, s3, s6
    s.ld.d       s3, [s2, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.movz       s6, #8
    .li       s15, #2147483647
    s.ld.d       s16, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.movz       s2, #0
    s.movz       s17, #0
    s.movz       s18, #0
    s.movz       s19, #0
    s.cmp.lt     s20, s6, s18
    s.st.d       [s5, #0], s1
    s.sub        s1, s19, s20
    .li       s18, #2147483647
    s.st.d       [s5, #8], s7
    s.movz       s7, #512
    s.movz       s19, #4
    s.st.d       [s5, #16], s8
    .li       s8, #68719476752
    .li       s20, #2207613190144
    s.st.d       [s5, #48], s9
    s.xor        s9, s6, s1
    s.movz       s21, #0
    s.cmp.lt     s21, s4, s2
    s.st.d       [s5, #56], s10
    s.sub        s2, s17, s21
    s.movz       s10, #1
    s.xor        s17, s4, s2
    s.st.d       [s5, #88], s11
    s.sub        s11, s17, s2
    s.movz       s17, #0
    s.st.d       [s5, #104], s12
    s.lshri      s12, s11, #3
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s5, s2, s1
    s.movz       s2, #0
    s.ld.d       s21, [s13, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.cmp.lt     s13, s4, s2
    s.movz       s2, #0
    s.add        s2, s21, s14                    // this context's own scratch
    s.xor        s14, s12, s5
    s.muli       s21, s12, #8
    s.sub        s12, s14, s5
    s.movz       s5, #0
    s.addi       s14, s2, #256                   // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.sub        s2, s9, s1
    s.sub        s1, s10, s12
    s.movz       s2, #0
    s.min.s      s9, s1, s10
    s.sub        s1, s2, s13
    s.cmp.lt     s2, s9, s17
    s.movz       s10, #0
    s.sub        s13, s5, s2
    s.movz       s2, #1
    s.movz       s5, #0
    s.st.d       [s14, #0], s3
    s.xor        s3, s4, s1
    s.sub        s17, s11, s21
    s.sub        s11, s3, s1
    s.st.d       [s14, #8], s15
    s.xor        s3, s9, s13
    s.sub        s15, s3, s13
    s.st.d       [s14, #16], s18
    s.addi       s3, s10, #0
    s.addi       s10, s5, #0
    s.st.d       [s14, #48], s7
    s.cmp.eq     s5, s15, s2
    s.st.d       [s14, #56], s19
    s.st.d       [s14, #88], s8
    s.st.d       [s14, #104], s20
    fence.release.device
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s3, s11
    br.nz        s5, sdiv_done_1
    s.movz       s2, #0
    s.movz       s5, #31
    s.mov        s3, s2
    s.addi       s2, s5, #0
sdiv_2:
    s.lshr       s5, s11, s2
    s.shli       s7, s10, #1
    s.andi       s8, s5, #1
    s.movz       s5, #0
    s.or         s13, s7, s8
    s.movz       s7, #1
    s.cmp.geu    s8, s13, s15
    s.shl        s14, s7, s2
    s.sub        s7, s5, s8
    s.subi       s5, s2, #1
    s.and        s8, s15, s7
    s.and        s17, s14, s7
    s.sub        s7, s13, s8
    s.or         s8, s3, s17
    s.mov        s10, s7
    s.mov        s3, s8
    s.mov        s2, s5
    s.movz       s5, #0
    s.cmp.ge     s7, s2, s5
    br.nz        s7, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.movz       s3, #0
    s.cmp.lt     s5, s4, s2
    s.movz       s2, #0
    s.sub        s7, s3, s5
    s.movz       s3, #0
    s.xor        s5, s4, s7
    s.movz       s4, #0
    s.sub        s8, s5, s7
    s.cmp.lt     s5, s9, s2
    s.lshri      s2, s8, #3
    s.movz       s11, #0
    s.muli       s13, s2, #8
    s.sub        s2, s4, s5
    s.movz       s4, #0
    s.cmp.lt     s5, s6, s11
    s.xor        s11, s9, s2
    s.sub        s9, s8, s13
    s.movz       s8, #0
    s.xor        s13, s9, s7
    s.xor        s9, s10, s1
    s.sub        s10, s13, s7
    s.sub        s7, s8, s5
    s.cmp.lt     s5, s10, s3
    s.sub        s3, s11, s2
    s.sub        s8, s4, s5
    s.movz       s4, #0
    s.xor        s5, s10, s8
    s.movz       s10, #1
    s.sub        s11, s9, s1
    s.xor        s1, s6, s7
    s.sub        s6, s5, s8
    s.movz       s5, #0
    s.addi       s9, s4, #0
    s.cmp.eq     s4, s3, s10
    s.add        s10, s12, s11
    s.sub        s11, s1, s7
    s.addi       s1, s5, #0
    s.mov        s9, s6
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s5, #31
    s.mov        s9, s4
    s.addi       s4, s5, #0
sdiv_4:
    s.lshr       s5, s6, s4
    s.shli       s7, s1, #1
    s.andi       s11, s5, #1
    s.movz       s5, #0
    s.or         s12, s7, s11
    s.movz       s7, #1
    s.cmp.geu    s11, s12, s3
    s.shl        s13, s7, s4
    s.sub        s7, s5, s11
    s.subi       s5, s4, #1
    s.and        s11, s3, s7
    s.and        s14, s13, s7
    s.sub        s7, s12, s11
    s.or         s11, s9, s14
    s.mov        s1, s7
    s.mov        s9, s11
    s.mov        s4, s5
    s.movz       s5, #0
    s.cmp.ge     s7, s4, s5
    br.nz        s7, sdiv_4
sdiv_done_3:
    s.rdspecial  s1, pid.z
    s.rdspecial  s3, npid.y
    s.xor        s4, s8, s2
    s.mul        s2, s1, s3
    s.xor        s1, s9, s4
    s.rdspecial  s3, pid.y
    s.sub        s5, s1, s4
    s.movz       s1, #16
    s.add        s4, s3, s2
    s.movz       s2, #63
    s.mul        s3, s10, s1
    s.mul        s6, s5, s1
    s.min.s      s7, s4, s2
    s.movz       s2, #1024
    s.movz       s8, #8192
    s.mul        s9, s7, s2
    s.mul        s2, s7, s8
    s.andi       s7, s3, #15
    s.andi       s8, s6, #127
    w.def        w0, #48, #16                    // v48..v63
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s12, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s9                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w0, d0, s13, s11
    mb.wait      s11
    s.add        s9, s8, s2
    w.def        w1, #32, #16                    // v32..v47
    mb.arm       s2, b1, #0, #1                  // 0 arrival(s), 1 operation(s)
    v.movi       v0, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s12                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s9                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w1, d1, s13, s2
    mb.wait      s2
    v.extract    s9, v48, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s12, #0
    s.movz       s13, #0
    v.splat      v1, s10
    v.splat      v2, s9
    v.splat      v3, s13
    vf.fma       v4, v2, v32, v0
    v.splat      v2, s5
    v.splat      v5, s13
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v7, s3
    v.cmp.ge     p1, v1, v3
    v.extract    s5, v48, #1
    v.splat      v1, s5
    v.cmp.ge     p1, v2, v5
    vf.fma       v2, v1, v33, v4
    v.extract    s5, v48, #2
    v.splat      v1, s5
    v.splat      v3, s6
    vf.fma       v4, v1, v34, v2
    v.splat      v1, s7
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v5, s8
    v.add        v8, v7, v6
    v.extract    s5, v48, #3
    v.splat      v7, s5
    v.add        v8, v3, v6
    vf.fma       v3, v7, v35, v4
    v.extract    s5, v48, #4
    v.splat      v4, s5
    v.iota       v6                              // arange(0, VLEN)
    v.add        v7, v1, v2
    vf.fma       v1, v4, v36, v3
    v.extract    s5, v48, #5
    v.splat      v2, s5
    v.add        v3, v5, v6
    vf.fma       v3, v2, v37, v1
    v.extract    s5, v48, #6
    v.splat      v1, s5
    v.extract    s5, v48, #7
    vf.fma       v2, v1, v38, v3
    v.splat      v1, s5
    v.extract    s5, v48, #8
    v.splat      v3, s5
    vf.fma       v4, v1, v39, v2
    v.extract    s5, v48, #9
    v.splat      v1, s5
    v.extract    s5, v48, #10
    vf.fma       v2, v3, v40, v4
    v.splat      v3, s5
    v.extract    s5, v48, #11
    v.splat      v4, s5
    vf.fma       v5, v1, v41, v2
    v.extract    s5, v48, #12
    v.splat      v1, s5
    v.extract    s5, v48, #13
    vf.fma       v2, v3, v42, v5
    v.splat      v3, s5
    v.extract    s5, v48, #14
    v.splat      v5, s5
    vf.fma       v6, v4, v43, v2
    v.extract    s5, v48, #15
    v.splat      v2, s5
    s.movz       s5, #1
    vf.fma       v4, v1, v44, v6
    vf.fma       v1, v3, v45, v4
    vf.fma       v3, v5, v46, v1
    vf.fma       v1, v2, v47, v3
    a.vwrite     a0, s12, v1
    v.extract    s7, v49, #0
    v.splat      v1, s7
    v.extract    s7, v49, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v49, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v49, #3
    v.splat      v1, s7
    v.extract    s7, v49, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v49, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v49, #6
    v.splat      v1, s7
    v.extract    s7, v49, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v49, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v49, #9
    v.splat      v2, s7
    v.extract    s7, v49, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v49, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v49, #12
    v.splat      v3, s7
    v.extract    s7, v49, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v49, #14
    v.extract    s8, v49, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s7
    v.splat      v4, s8
    s.movz       s7, #2
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s5, v1
    v.extract    s5, v50, #0
    v.splat      v1, s5
    v.extract    s5, v50, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s5
    v.extract    s5, v50, #2
    v.splat      v3, s5
    vf.fma       v4, v1, v33, v2
    v.extract    s5, v50, #3
    v.splat      v1, s5
    v.extract    s5, v50, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s5
    v.extract    s5, v50, #5
    v.splat      v4, s5
    vf.fma       v5, v1, v35, v2
    v.extract    s5, v50, #6
    v.splat      v1, s5
    v.extract    s5, v50, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s5
    v.extract    s5, v50, #8
    v.splat      v5, s5
    vf.fma       v6, v4, v37, v2
    v.extract    s5, v50, #9
    v.splat      v2, s5
    v.extract    s5, v50, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s5
    v.extract    s5, v50, #11
    v.splat      v6, s5
    vf.fma       v7, v3, v39, v4
    v.extract    s5, v50, #12
    v.splat      v3, s5
    v.extract    s5, v50, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s5
    v.extract    s5, v50, #14
    v.extract    s8, v50, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s5
    v.splat      v4, s8
    s.movz       s5, #3
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v51, #0
    v.splat      v1, s7
    v.extract    s7, v51, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v51, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v51, #3
    v.splat      v1, s7
    v.extract    s7, v51, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v51, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v51, #6
    v.splat      v1, s7
    v.extract    s7, v51, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v51, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v51, #9
    v.splat      v2, s7
    v.extract    s7, v51, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v51, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v51, #12
    v.splat      v3, s7
    v.extract    s7, v51, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v51, #14
    v.extract    s8, v51, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s7
    v.splat      v4, s8
    s.movz       s7, #4
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s5, v1
    v.extract    s5, v52, #0
    v.splat      v1, s5
    v.extract    s5, v52, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s5
    v.extract    s5, v52, #2
    v.splat      v3, s5
    vf.fma       v4, v1, v33, v2
    v.extract    s5, v52, #3
    v.splat      v1, s5
    v.extract    s5, v52, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s5
    v.extract    s5, v52, #5
    v.splat      v4, s5
    vf.fma       v5, v1, v35, v2
    v.extract    s5, v52, #6
    v.splat      v1, s5
    v.extract    s5, v52, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s5
    v.extract    s5, v52, #8
    v.splat      v5, s5
    vf.fma       v6, v4, v37, v2
    v.extract    s5, v52, #9
    v.splat      v2, s5
    v.extract    s5, v52, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s5
    v.extract    s5, v52, #11
    v.splat      v6, s5
    vf.fma       v7, v3, v39, v4
    v.extract    s5, v52, #12
    v.splat      v3, s5
    v.extract    s5, v52, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s5
    v.extract    s5, v52, #14
    v.extract    s8, v52, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s5
    v.splat      v4, s8
    s.movz       s5, #5
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v53, #0
    v.splat      v1, s7
    v.extract    s7, v53, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v53, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v53, #3
    v.splat      v1, s7
    v.extract    s7, v53, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v53, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v53, #6
    v.splat      v1, s7
    v.extract    s7, v53, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v53, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v53, #9
    v.splat      v2, s7
    v.extract    s7, v53, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v53, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v53, #12
    v.splat      v3, s7
    v.extract    s7, v53, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v53, #14
    v.extract    s8, v53, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s7
    v.splat      v4, s8
    s.movz       s7, #6
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s5, v1
    v.extract    s5, v54, #0
    v.splat      v1, s5
    v.extract    s5, v54, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s5
    v.extract    s5, v54, #2
    v.splat      v3, s5
    vf.fma       v4, v1, v33, v2
    v.extract    s5, v54, #3
    v.splat      v1, s5
    v.extract    s5, v54, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s5
    v.extract    s5, v54, #5
    v.splat      v4, s5
    vf.fma       v5, v1, v35, v2
    v.extract    s5, v54, #6
    v.splat      v1, s5
    v.extract    s5, v54, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s5
    v.extract    s5, v54, #8
    v.splat      v5, s5
    vf.fma       v6, v4, v37, v2
    v.extract    s5, v54, #9
    v.splat      v2, s5
    v.extract    s5, v54, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s5
    v.extract    s5, v54, #11
    v.splat      v6, s5
    vf.fma       v7, v3, v39, v4
    v.extract    s5, v54, #12
    v.splat      v3, s5
    v.extract    s5, v54, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s5
    v.extract    s5, v54, #14
    v.extract    s8, v54, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s5
    v.splat      v4, s8
    s.movz       s5, #7
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v55, #0
    v.splat      v1, s7
    v.extract    s7, v55, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v55, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v55, #3
    v.splat      v1, s7
    v.extract    s7, v55, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v55, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v55, #6
    v.splat      v1, s7
    v.extract    s7, v55, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v55, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v55, #9
    v.splat      v2, s7
    v.extract    s7, v55, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v55, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v55, #12
    v.splat      v3, s7
    v.extract    s7, v55, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v55, #14
    v.extract    s8, v55, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s7
    v.splat      v4, s8
    s.movz       s7, #8
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s5, v1
    v.extract    s5, v56, #0
    v.splat      v1, s5
    v.extract    s5, v56, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s5
    v.extract    s5, v56, #2
    v.splat      v3, s5
    vf.fma       v4, v1, v33, v2
    v.extract    s5, v56, #3
    v.splat      v1, s5
    v.extract    s5, v56, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s5
    v.extract    s5, v56, #5
    v.splat      v4, s5
    vf.fma       v5, v1, v35, v2
    v.extract    s5, v56, #6
    v.splat      v1, s5
    v.extract    s5, v56, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s5
    v.extract    s5, v56, #8
    v.splat      v5, s5
    vf.fma       v6, v4, v37, v2
    v.extract    s5, v56, #9
    v.splat      v2, s5
    v.extract    s5, v56, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s5
    v.extract    s5, v56, #11
    v.splat      v6, s5
    vf.fma       v7, v3, v39, v4
    v.extract    s5, v56, #12
    v.splat      v3, s5
    v.extract    s5, v56, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s5
    v.extract    s5, v56, #14
    v.extract    s8, v56, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s5
    v.splat      v4, s8
    s.movz       s5, #9
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v57, #0
    v.splat      v1, s7
    v.extract    s7, v57, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v57, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v57, #3
    v.splat      v1, s7
    v.extract    s7, v57, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v57, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v57, #6
    v.splat      v1, s7
    v.extract    s7, v57, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v57, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v57, #9
    v.splat      v2, s7
    v.extract    s7, v57, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v57, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v57, #12
    v.splat      v3, s7
    v.extract    s7, v57, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v57, #14
    v.extract    s8, v57, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s7
    v.splat      v4, s8
    s.movz       s7, #10
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s5, v1
    v.extract    s5, v58, #0
    v.splat      v1, s5
    v.extract    s5, v58, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s5
    v.extract    s5, v58, #2
    v.splat      v3, s5
    vf.fma       v4, v1, v33, v2
    v.extract    s5, v58, #3
    v.splat      v1, s5
    v.extract    s5, v58, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s5
    v.extract    s5, v58, #5
    v.splat      v4, s5
    vf.fma       v5, v1, v35, v2
    v.extract    s5, v58, #6
    v.splat      v1, s5
    v.extract    s5, v58, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s5
    v.extract    s5, v58, #8
    v.splat      v5, s5
    vf.fma       v6, v4, v37, v2
    v.extract    s5, v58, #9
    v.splat      v2, s5
    v.extract    s5, v58, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s5
    v.extract    s5, v58, #11
    v.splat      v6, s5
    vf.fma       v7, v3, v39, v4
    v.extract    s5, v58, #12
    v.splat      v3, s5
    v.extract    s5, v58, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s5
    v.extract    s5, v58, #14
    v.extract    s8, v58, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s5
    v.splat      v4, s8
    s.movz       s5, #11
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v59, #0
    v.splat      v1, s7
    v.extract    s7, v59, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v59, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v59, #3
    v.splat      v1, s7
    v.extract    s7, v59, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v59, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v59, #6
    v.splat      v1, s7
    v.extract    s7, v59, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v59, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v59, #9
    v.splat      v2, s7
    v.extract    s7, v59, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v59, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v59, #12
    v.splat      v3, s7
    v.extract    s7, v59, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v59, #14
    v.extract    s8, v59, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s7
    v.splat      v4, s8
    s.movz       s7, #12
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s5, v1
    v.extract    s5, v60, #0
    v.splat      v1, s5
    v.extract    s5, v60, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s5
    v.extract    s5, v60, #2
    v.splat      v3, s5
    vf.fma       v4, v1, v33, v2
    v.extract    s5, v60, #3
    v.splat      v1, s5
    v.extract    s5, v60, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s5
    v.extract    s5, v60, #5
    v.splat      v4, s5
    vf.fma       v5, v1, v35, v2
    v.extract    s5, v60, #6
    v.splat      v1, s5
    v.extract    s5, v60, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s5
    v.extract    s5, v60, #8
    v.splat      v5, s5
    vf.fma       v6, v4, v37, v2
    v.extract    s5, v60, #9
    v.splat      v2, s5
    v.extract    s5, v60, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s5
    v.extract    s5, v60, #11
    v.splat      v6, s5
    vf.fma       v7, v3, v39, v4
    v.extract    s5, v60, #12
    v.splat      v3, s5
    v.extract    s5, v60, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s5
    v.extract    s5, v60, #14
    v.extract    s8, v60, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s5
    v.splat      v4, s8
    s.movz       s5, #13
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v61, #0
    v.splat      v1, s7
    v.extract    s7, v61, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s7
    v.extract    s7, v61, #2
    v.splat      v3, s7
    vf.fma       v4, v1, v33, v2
    v.extract    s7, v61, #3
    v.splat      v1, s7
    v.extract    s7, v61, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s7
    v.extract    s7, v61, #5
    v.splat      v4, s7
    vf.fma       v5, v1, v35, v2
    v.extract    s7, v61, #6
    v.splat      v1, s7
    v.extract    s7, v61, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s7
    v.extract    s7, v61, #8
    v.splat      v5, s7
    vf.fma       v6, v4, v37, v2
    v.extract    s7, v61, #9
    v.splat      v2, s7
    v.extract    s7, v61, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s7
    v.extract    s7, v61, #11
    v.splat      v6, s7
    vf.fma       v7, v3, v39, v4
    v.extract    s7, v61, #12
    v.splat      v3, s7
    v.extract    s7, v61, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s7
    v.extract    s7, v61, #14
    v.extract    s8, v61, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s7
    v.splat      v4, s8
    s.movz       s7, #14
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s5, v1
    v.extract    s5, v62, #0
    v.splat      v1, s5
    v.extract    s5, v62, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v1, s5
    v.extract    s5, v62, #2
    v.splat      v3, s5
    vf.fma       v4, v1, v33, v2
    v.extract    s5, v62, #3
    v.splat      v1, s5
    v.extract    s5, v62, #4
    vf.fma       v2, v3, v34, v4
    v.splat      v3, s5
    v.extract    s5, v62, #5
    v.splat      v4, s5
    vf.fma       v5, v1, v35, v2
    v.extract    s5, v62, #6
    v.splat      v1, s5
    v.extract    s5, v62, #7
    vf.fma       v2, v3, v36, v5
    v.splat      v3, s5
    v.extract    s5, v62, #8
    v.splat      v5, s5
    vf.fma       v6, v4, v37, v2
    v.extract    s5, v62, #9
    v.splat      v2, s5
    v.extract    s5, v62, #10
    vf.fma       v4, v1, v38, v6
    v.splat      v1, s5
    v.extract    s5, v62, #11
    v.splat      v6, s5
    vf.fma       v7, v3, v39, v4
    v.extract    s5, v62, #12
    v.splat      v3, s5
    v.extract    s5, v62, #13
    vf.fma       v4, v5, v40, v7
    v.splat      v5, s5
    v.extract    s5, v62, #14
    v.extract    s8, v62, #15
    vf.fma       v7, v2, v41, v4
    v.splat      v2, s5
    v.splat      v4, s8
    s.movz       s5, #15
    vf.fma       v8, v1, v42, v7
    vf.fma       v1, v6, v43, v8
    vf.fma       v6, v3, v44, v1
    vf.fma       v1, v5, v45, v6
    vf.fma       v3, v2, v46, v1
    vf.fma       v1, v4, v47, v3
    a.vwrite     a0, s7, v1
    v.extract    s7, v63, #0
    v.splat      v1, s7
    v.extract    s7, v63, #1
    vf.fma       v2, v1, v32, v0
    v.splat      v0, s7
    v.extract    s7, v63, #2
    v.splat      v1, s7
    vf.fma       v3, v0, v33, v2
    v.extract    s7, v63, #3
    v.splat      v0, s7
    v.extract    s7, v63, #4
    vf.fma       v2, v1, v34, v3
    v.splat      v1, s7
    v.extract    s7, v63, #5
    v.splat      v3, s7
    vf.fma       v4, v0, v35, v2
    v.extract    s7, v63, #6
    v.splat      v0, s7
    v.extract    s7, v63, #7
    vf.fma       v2, v1, v36, v4
    v.splat      v1, s7
    v.extract    s7, v63, #8
    v.splat      v4, s7
    vf.fma       v5, v3, v37, v2
    v.extract    s7, v63, #9
    v.splat      v2, s7
    v.extract    s7, v63, #10
    vf.fma       v3, v0, v38, v5
    v.splat      v0, s7
    v.extract    s7, v63, #11
    v.splat      v5, s7
    vf.fma       v6, v1, v39, v3
    v.extract    s7, v63, #12
    v.splat      v1, s7
    v.extract    s7, v63, #13
    vf.fma       v3, v4, v40, v6
    v.splat      v4, s7
    v.extract    s7, v63, #14
    v.splat      v6, s7
    vf.fma       v7, v2, v41, v3
    s.movz       s7, #2048
    v.extract    s8, v63, #15
    s.movz       s9, #0
    vf.fma       v2, v0, v42, v7
    v.splat      v0, s8
    s.mul        s8, s4, s7
    s.muli       s7, s6, #4                      // a runtime tile origin, x4
    vf.fma       v3, v5, v43, v2
    s.movz       s10, #0
    s.add        s12, s9, s6                     // the tile origin
    s.muli       s6, s3, #512                    // a runtime tile origin, x512
    vf.fma       v2, v1, v44, v3
    s.add        s9, s10, s3                     // the tile origin
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v3, s12
    vf.fma       v5, v4, v45, v2
    s.movz       s3, #128
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s10, #0
    s.movz       s12, #64
    vf.fma       v2, v6, v46, v5
    s.muli       s13, s8, #4                     // a runtime tile origin, x4
    v.splat      v4, s9
    v.splat      v5, s1
    vf.fma       v6, v0, v47, v2
    v.add        v0, v1, v3
    v.splat      v1, s3
    v.movi       v2, #0
    a.vwrite     a0, s5, v6
    s.add        s1, s16, s7                     // the tile origin
    a.vread      v3, a0, s10
    v.splat      v6, s4
    v.splat      v7, s12
    v.cmp.lt     p1, v4, v5
    v.cmp.lt     p2, v0, v1
    s.add        s3, s1, s6                      // the tile origin
    vf.add       v0, v3, v2
    p.and        p3, p1, p2
    v.cmp.lt     p1, v6, v7
    s.addi       s1, s9, #1
    s.add        s4, s3, s13                     // the tile origin
    p.and        p4, p3, p1
    s.movz       s3, #1
    v.splat      v1, s1
    @p4 v.st.w       [s4, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p3, v1, v5
    vf.add       v1, v0, v2
    p.and        p4, p3, p2
    s.addi       s1, s9, #2
    s.addi       s3, s4, #512                    // row 1
    p.and        p3, p4, p1
    s.movz       s5, #2
    v.splat      v0, s1
    @p3 v.st.w       [s3, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v5
    vf.add       v0, v1, v2
    p.and        p4, p3, p2
    s.addi       s1, s9, #3
    s.addi       s3, s4, #1024                   // row 2
    p.and        p3, p4, p1
    s.movz       s5, #3
    v.splat      v1, s1
    @p3 v.st.w       [s3, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v5
    vf.add       v1, v0, v2
    p.and        p4, p3, p2
    s.addi       s1, s9, #4
    s.addi       s3, s4, #1536                   // row 3
    p.and        p3, p4, p1
    s.movz       s5, #4
    v.splat      v0, s1
    @p3 v.st.w       [s3, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v5
    vf.add       v0, v1, v2
    p.and        p4, p3, p2
    s.addi       s1, s9, #5
    s.addi       s3, s4, #2048                   // row 4
    p.and        p3, p4, p1
    s.movz       s5, #5
    v.splat      v1, s1
    @p3 v.st.w       [s3, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v5
    vf.add       v1, v0, v2
    p.and        p4, p3, p2
    s.addi       s1, s9, #6
    s.addi       s3, s4, #2560                   // row 5
    p.and        p3, p4, p1
    s.movz       s5, #6
    v.splat      v0, s1
    @p3 v.st.w       [s3, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v5
    vf.add       v0, v1, v2
    p.and        p4, p3, p2
    s.addi       s1, s9, #7
    s.addi       s3, s4, #3072                   // row 6
    p.and        p3, p4, p1
    s.movz       s5, #7
    v.splat      v1, s1
    @p3 v.st.w       [s3, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v5
    vf.add       v1, v0, v2
    p.and        p4, p3, p2
    s.addi       s1, s9, #8
    s.addi       s3, s4, #3584                   // row 7
    p.and        p3, p4, p1
    s.movz       s5, #8
    v.splat      v0, s1
    @p3 v.st.w       [s3, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v5
    vf.add       v0, v1, v2
    p.and        p4, p3, p2
    s.addi       s1, s9, #9
    s.addi       s3, s4, #4096                   // row 8
    p.and        p3, p4, p1
    s.movz       s5, #9
    v.splat      v1, s1
    @p3 v.st.w       [s3, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v5
    vf.add       v1, v0, v2
    p.and        p4, p3, p2
    s.addi       s1, s9, #10
    s.addi       s3, s4, #4608                   // row 9
    p.and        p3, p4, p1
    s.movz       s5, #10
    v.splat      v0, s1
    @p3 v.st.w       [s3, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v5
    vf.add       v0, v1, v2
    p.and        p4, p3, p2
    s.addi       s1, s9, #11
    s.addi       s3, s4, #5120                   // row 10
    p.and        p3, p4, p1
    s.movz       s5, #11
    v.splat      v1, s1
    @p3 v.st.w       [s3, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v5
    vf.add       v1, v0, v2
    p.and        p4, p3, p2
    s.addi       s1, s9, #12
    s.addi       s3, s4, #5632                   // row 11
    p.and        p3, p4, p1
    s.movz       s5, #12
    v.splat      v0, s1
    @p3 v.st.w       [s3, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v5
    vf.add       v0, v1, v2
    p.and        p4, p3, p2
    s.addi       s1, s9, #13
    s.addi       s3, s4, #6144                   // row 12
    p.and        p3, p4, p1
    s.movz       s5, #13
    v.splat      v1, s1
    @p3 v.st.w       [s3, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v5
    vf.add       v1, v0, v2
    p.and        p4, p3, p2
    s.addi       s1, s9, #14
    s.addi       s3, s4, #6656                   // row 13
    p.and        p3, p4, p1
    s.movz       s5, #14
    v.splat      v0, s1
    @p3 v.st.w       [s3, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p3, v0, v5
    vf.add       v0, v1, v2
    p.and        p4, p3, p2
    s.addi       s1, s9, #15
    s.addi       s3, s4, #7168                   // row 14
    p.and        p3, p4, p1
    s.movz       s5, #15
    v.splat      v1, s1
    @p3 v.st.w       [s3, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v5
    vf.add       v1, v0, v2
    p.and        p4, p3, p2
    s.addi       s1, s4, #7680                   // row 15
    p.and        p2, p4, p1
    @p2 v.st.w       [s1, #0], v1
__rctx_next:
    exit
