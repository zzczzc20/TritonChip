    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.movi       v0, #0
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #128
    s.movz       s6, #16
    v.splat      v2, s4
    v.iota       v3                              // arange(0, VLEN)
    s.addi       s7, s2, #0
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s8, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    v.movi       v0, #0
    v.movi       v4, #0
    v.movi       v5, #5
    v.sub        v6, v0, v2
    v.cmp.lt     p1, v2, v0
    v.sub        v7, v4, v2
    @p1 v.sel        v8, v6, v2
    v.cmp.lt     p2, v2, v4
    @p2 v.sel        v6, v7, v2
    v.lshr       v7, v8, v5
    v.movi       v5, #31
    v.movi       v8, #128
    v.sub        v9, v0, v7
    v.and        v10, v6, v5
    v.movi       v5, #8192
    @p1 v.sel        v6, v9, v7
    v.sub        v7, v4, v10
    v.splat      v9, s7
    v.mul        v11, v6, v8
    @p2 v.sel        v6, v7, v10
    v.add        v7, v9, v3
    v.extract    s1, v11, #0
    v.mul        v8, v6, v5
    v.splat      v5, s1
    v.movi       v6, #128
    v.extract    s1, v8, #0
    v.add        v8, v7, v5
    v.splat      v5, s1
    v.cmp.lt     p1, v7, v6
    v.movi       v6, #32
    v.add        v7, v8, v5
    v.movi       v5, #0
    v.sub        v8, v0, v6
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v9, [s3, v7]               // index is in elements (ISA sec 9.1)
    v.sub        v10, v4, v6
    s.add        s1, s7, s6
    s.movz       s9, #1
    v.cmp.lt     p2, v6, v0
    v.cmp.lt     p3, v6, v4
    v.movi       v0, #1
    @p2 v.sel        v0, v8, v6
    v.movi       v0, #1
    @p3 v.sel        v0, v10, v6
    s.movz       s10, #8192
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s2, v7]               // index is in elements (ISA sec 9.1)
    vf.add       v4, v9, v0
    vf.mul       v0, v4, v4
    vf.add       v4, v1, v0
    @p1 v.sel        v0, v4, v1
    v.mov        v5, v0
    v.mov        v1, v5
    s.mov        s7, s1
    br.nz        s9, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s8, s2                      // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
