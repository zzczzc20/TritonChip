    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    s.rdspecial  s3, role_id
    s.movz       s6, #512
    s.add        s7, s1, s5                      // this context's own scratch
    s.ld.d       s1, [s2, #8]                    // arg_A: device_ptr64 at arg_base+8
    s.addi       s5, s7, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s7, #2147483647
    .li       s8, #2147483647
    s.movz       s9, #8192
    s.movz       s10, #2
    .li       s11, #68719476752
    .li       s12, #1108101562368
    s.rdspecial  s13, arg_base
    s.mul        s14, s3, s6
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    .li       s6, #2147483647
    .li       s15, #2147483647
    s.ld.d       s16, [s2, #16]                  // arg_B: device_ptr64 at arg_base+16
    s.movz       s17, #256
    s.movz       s18, #8192
    s.ld.d       s19, [s2, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    s.movz       s2, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.movz       s22, #0
    s.cmp.lt     s23, s17, s21
    s.st.d       [s5, #0], s1
    s.sub        s1, s22, s23
    s.movz       s21, #2
    s.st.d       [s5, #8], s7
    .li       s7, #68719476752
    .li       s22, #1108101562368
    s.st.d       [s5, #16], s8
    s.xor        s8, s17, s1
    s.movz       s23, #0
    s.st.d       [s5, #48], s9
    s.movz       s9, #4
    s.movz       s23, #0
    s.st.d       [s5, #56], s10
    s.cmp.lt     s10, s4, s2
    s.movz       s2, #1
    s.sub        s23, s20, s10
    s.movz       s10, #0
    s.st.d       [s5, #88], s11
    s.xor        s11, s4, s23
    s.sub        s20, s8, s1
    s.sub        s8, s11, s23
    s.movz       s11, #0
    s.st.d       [s5, #104], s12
    s.lshri      s12, s8, #8
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s5, s23, s1
    s.movz       s1, #0
    s.movz       s20, #0
    s.ld.d       s23, [s13, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s13, s23, s14                   // this context's own scratch
    s.xor        s14, s12, s5
    s.cmp.lt     s23, s4, s11
    s.sub        s11, s14, s5
    s.muli       s5, s12, #256
    s.sub        s12, s9, s11
    s.movz       s9, #0
    s.min.s      s14, s12, s2
    s.addi       s12, s13, #256                  // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.cmp.lt     s13, s14, s10
    s.sub        s10, s20, s23
    s.movz       s20, #1
    s.st.d       [s12, #0], s16
    s.sub        s16, s1, s13
    s.xor        s1, s4, s10
    s.movz       s13, #0
    s.st.d       [s12, #8], s6
    s.xor        s6, s14, s16
    s.sub        s23, s1, s10
    s.st.d       [s12, #16], s15
    s.sub        s1, s6, s16
    s.addi       s6, s9, #0
    s.st.d       [s12, #48], s18
    s.cmp.eq     s9, s1, s20
    s.sub        s15, s8, s5
    s.st.d       [s12, #56], s21
    s.addi       s5, s13, #0
    s.st.d       [s12, #88], s7
    s.st.d       [s12, #104], s22
    fence.release.device
    td.load      d1, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s6, s23
    br.nz        s9, sdiv_done_1
    s.movz       s7, #0
    s.movz       s8, #31
    s.mov        s6, s7
    s.addi       s7, s8, #0
sdiv_2:
    s.lshr       s8, s23, s7
    s.shli       s9, s5, #1
    s.andi       s12, s8, #1
    s.movz       s8, #0
    s.or         s13, s9, s12
    s.movz       s9, #1
    s.cmp.geu    s12, s13, s1
    s.shl        s15, s9, s7
    s.sub        s9, s8, s12
    s.subi       s8, s7, #1
    s.and        s12, s1, s9
    s.and        s16, s15, s9
    s.sub        s9, s13, s12
    s.or         s12, s6, s16
    s.mov        s5, s9
    s.mov        s6, s12
    s.mov        s7, s8
    s.movz       s8, #0
    s.cmp.ge     s9, s7, s8
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s6, #0
    s.cmp.lt     s7, s4, s1
    s.movz       s1, #0
    s.sub        s8, s6, s7
    s.movz       s6, #0
    s.xor        s7, s4, s8
    s.movz       s4, #0
    s.sub        s9, s7, s8
    s.cmp.lt     s7, s14, s1
    s.lshri      s1, s9, #8
    s.movz       s12, #0
    s.muli       s13, s1, #256
    s.movz       s1, #0
    s.sub        s15, s4, s7
    s.movz       s4, #0
    s.cmp.lt     s7, s17, s12
    s.sub        s12, s9, s13
    s.xor        s9, s14, s15
    s.xor        s13, s12, s8
    s.xor        s12, s5, s10
    s.sub        s5, s13, s8
    s.sub        s8, s4, s7
    s.cmp.lt     s4, s5, s6
    s.sub        s6, s9, s15
    s.sub        s7, s1, s4
    s.movz       s1, #0
    s.xor        s4, s5, s7
    s.movz       s5, #1
    s.sub        s9, s12, s10
    s.xor        s10, s17, s8
    s.sub        s12, s4, s7
    s.movz       s4, #0
    s.addi       s13, s1, #0
    s.cmp.eq     s1, s6, s5
    s.add        s5, s11, s9
    s.sub        s9, s10, s8
    s.addi       s8, s4, #0
    s.mov        s13, s12
    br.nz        s1, sdiv_done_3
    s.movz       s1, #0
    s.movz       s4, #31
    s.mov        s13, s1
    s.addi       s1, s4, #0
sdiv_4:
    s.lshr       s4, s12, s1
    s.shli       s9, s8, #1
    s.andi       s10, s4, #1
    s.movz       s4, #0
    s.or         s11, s9, s10
    s.movz       s9, #1
    s.cmp.geu    s10, s11, s6
    s.shl        s14, s9, s1
    s.sub        s9, s4, s10
    s.subi       s4, s1, #1
    s.and        s10, s6, s9
    s.and        s16, s14, s9
    s.sub        s9, s11, s10
    s.or         s10, s13, s16
    s.mov        s8, s9
    s.mov        s13, s10
    s.mov        s1, s4
    s.movz       s4, #0
    s.cmp.ge     s9, s1, s4
    br.nz        s9, sdiv_4
sdiv_done_3:
    s.xor        s1, s7, s15
    s.movz       s4, #16
    s.xor        s6, s13, s1
    s.mul        s7, s5, s4
    s.sub        s8, s6, s1
    s.movz       s1, #0
    s.mul        s6, s8, s4
    v.splat      v0, s5
    s.andi       s5, s7, #63
    v.splat      v1, s1
    v.splat      v2, s8
    s.andi       s8, s6, #4095
    v.splat      v3, s1
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s7
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s6
    v.splat      v1, s5
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s8
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.addi       s9, s1, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s1, s9, s17
    br.nz        s1, endfor_6
    s.mul        s1, s9, s4
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s10, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s11, s9, s2
    s.movz       s12, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s5                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s1                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s13, s10
    mb.wait      s10
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s14, s8                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s1                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s14, s13
    mb.wait      s13
    mb.arm       s1, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v56, v48, s1
    mb.wait      s1
    s.mov        s9, s11
    br.nz        s12, for_5
endfor_6:
    s.movz       s2, #0
    s.movz       s4, #0
    s.add        s5, s2, s6                      // the tile origin
    s.muli       s2, s6, #2                      // a runtime tile origin, x2
    s.add        s8, s4, s7                      // the tile origin
    s.movz       s4, #64
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s5
    s.movz       s5, #4096
    v.splat      v2, s8
    v.splat      v3, s4
    v.add        v4, v0, v1
    v.splat      v0, s5
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    s.add        s4, s3, s2                      // the tile origin
    s.movz       s2, #0
    p.and        p3, p1, p2
    a.vread      v0, a0, s2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    s.addi       s2, s8, #1
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s3, #0
    v.splat      v2, s2
    s.movz       s2, #1
    v.cmp.lt     p1, v2, v3
    vf.cvt.bf16.f32 v2, v1
    p.and        p3, p1, p2
    s.addi       s5, s8, #2
    s.movz       s9, #1
    vf.add       v1, v0, v2
    v.splat      v0, s5
    s.movz       s5, #2
    v.cmp.lt     p1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    p.and        p4, p1, p2
    s.addi       s11, s8, #3
    s.movz       s12, #2
    vf.cvt.bf16.f32 v1, v0
    v.splat      v0, s11
    s.movz       s11, #3
    a.vwrite     a1, s3, v1
    a.vread      v1, a0, s2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s2, s8, #4
    s.movz       s3, #3
    v.splat      v0, s2
    vf.cvt.bf16.f32 v4, v2
    s.movz       s2, #4
    vf.add       v2, v1, v4
    vf.cvt.f32.bf16 v1, v2
    vf.cvt.bf16.f32 v2, v1
    a.vwrite     a1, s9, v2
    a.vread      v1, a0, s5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s5, s8, #5
    s.movz       s9, #4
    v.splat      v0, s5
    vf.cvt.bf16.f32 v4, v2
    s.movz       s5, #5
    vf.add       v2, v1, v4
    vf.cvt.f32.bf16 v1, v2
    vf.cvt.bf16.f32 v2, v1
    a.vwrite     a1, s12, v2
    a.vread      v1, a0, s11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s11, s8, #6
    s.movz       s12, #5
    v.splat      v0, s11
    vf.cvt.bf16.f32 v4, v2
    s.movz       s11, #6
    vf.add       v2, v1, v4
    vf.cvt.f32.bf16 v1, v2
    vf.cvt.bf16.f32 v2, v1
    a.vwrite     a1, s3, v2
    a.vread      v1, a0, s2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s2, s8, #7
    s.movz       s3, #6
    v.splat      v0, s2
    vf.cvt.bf16.f32 v4, v2
    s.movz       s2, #7
    vf.add       v2, v1, v4
    vf.cvt.f32.bf16 v1, v2
    vf.cvt.bf16.f32 v2, v1
    a.vwrite     a1, s9, v2
    a.vread      v1, a0, s5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s5, s8, #8
    s.movz       s9, #7
    v.splat      v0, s5
    vf.cvt.bf16.f32 v4, v2
    s.movz       s5, #8
    vf.add       v2, v1, v4
    vf.cvt.f32.bf16 v1, v2
    vf.cvt.bf16.f32 v2, v1
    a.vwrite     a1, s12, v2
    a.vread      v1, a0, s11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s11, s8, #9
    s.movz       s12, #8
    v.splat      v0, s11
    vf.cvt.bf16.f32 v4, v2
    s.movz       s11, #9
    vf.add       v2, v1, v4
    vf.cvt.f32.bf16 v1, v2
    vf.cvt.bf16.f32 v2, v1
    a.vwrite     a1, s3, v2
    a.vread      v1, a0, s2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s2, s8, #10
    s.movz       s3, #9
    v.splat      v0, s2
    vf.cvt.bf16.f32 v4, v2
    s.movz       s2, #10
    vf.add       v2, v1, v4
    vf.cvt.f32.bf16 v1, v2
    vf.cvt.bf16.f32 v2, v1
    a.vwrite     a1, s9, v2
    a.vread      v1, a0, s5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s5, s8, #11
    s.movz       s9, #10
    v.splat      v0, s5
    vf.cvt.bf16.f32 v4, v2
    s.movz       s5, #11
    vf.add       v2, v1, v4
    vf.cvt.f32.bf16 v1, v2
    vf.cvt.bf16.f32 v2, v1
    a.vwrite     a1, s12, v2
    a.vread      v1, a0, s11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s11, s8, #12
    s.movz       s12, #11
    v.splat      v0, s11
    vf.cvt.bf16.f32 v4, v2
    s.movz       s11, #12
    vf.add       v2, v1, v4
    vf.cvt.f32.bf16 v1, v2
    vf.cvt.bf16.f32 v2, v1
    a.vwrite     a1, s3, v2
    a.vread      v1, a0, s2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s2, s8, #13
    s.movz       s3, #12
    v.splat      v0, s2
    vf.cvt.bf16.f32 v4, v2
    s.movz       s2, #13
    vf.add       v2, v1, v4
    vf.cvt.f32.bf16 v1, v2
    vf.cvt.bf16.f32 v2, v1
    a.vwrite     a1, s9, v2
    a.vread      v1, a0, s5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.addi       s5, s8, #14
    s.movz       s9, #13
    v.splat      v0, s5
    vf.cvt.bf16.f32 v4, v2
    s.movz       s5, #14
    vf.add       v2, v1, v4
    vf.cvt.f32.bf16 v1, v2
    vf.cvt.bf16.f32 v2, v1
    a.vwrite     a1, s12, v2
    a.vread      v1, a0, s11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s11, s8, #15
    s.movz       s12, #14
    v.splat      v0, s11
    vf.cvt.bf16.f32 v4, v2
    s.movz       s11, #15
    .li       s14, #1060439283
    v.splat      v2, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s14, #1056964608
    v.splat      v5, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v6, v1, v4
    .li       s14, #1065353216
    v.splat      v1, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s14, s6, #2                     // a runtime tile origin, x2
    s.muli       s6, s7, #8192                   // a runtime tile origin, x8192
    vf.cvt.f32.bf16 v4, v6
    s.add        s7, s19, s14                    // the tile origin
    vf.cvt.bf16.f32 v6, v4
    s.movz       s14, #15
    s.add        s15, s7, s6                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s6, #0
    a.vwrite     a1, s3, v6
    a.vread      v4, a0, s2
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s4, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.movz       s2, #0
    .li       s3, #3054550917
    v.splat      v0, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #951369979
    v.splat      v7, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.bf16.f32 v8, v6
    vf.add       v6, v4, v8
    .li       s3, #3126118730
    v.splat      v4, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.f32.bf16 v8, v6
    vf.cvt.bf16.f32 v6, v8
    .li       s3, #1001013584
    v.splat      v8, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    a.vwrite     a1, s9, v6
    a.vread      v6, a0, s5
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v9, [s4, #0]
    .li       s3, #3168535077
    v.splat      v10, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1038554810
    v.splat      v11, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #3200291744
    v.splat      v12, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1040414164
    v.splat      v13, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.bf16.f32 v14, v9
    vf.add       v9, v6, v14
    .li       s3, #1081802752
    v.splat      v6, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.f32.bf16 v14, v9
    vf.cvt.bf16.f32 v9, v14
    a.vwrite     a1, s12, v9
    a.vread      v9, a0, s11
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v14, [s4, #0]
    .li       s3, #1065353216
    v.splat      v15, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #971895886
    v.splat      v16, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #3143235307
    v.splat      v17, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1008707431
    v.splat      v18, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #3161341843
    v.splat      v19, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.bf16.f32 v20, v14
    .li       s3, #1009556701
    v.splat      v14, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v21, v9, v20
    vf.cvt.f32.bf16 v9, v21
    .li       s3, #998679498
    v.splat      v20, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.bf16.f32 v21, v9
    a.vwrite     a1, s14, v21
    a.vread      v9, a1, s6
    a.vread      v21, a1, s2
    .li       s2, #3173260768
    v.splat      v22, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v23, v21, v2
    .li       s2, #3210207623
    v.splat      v21, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3223905464
    v.splat      v24, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3219963872
    v.splat      v25, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v26, v23
    .li       s2, #1069066811
    v.splat      v27, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1262485504
    v.splat      v28, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v29, v23, v23
    vf.cmp.lt    p1, v26, v6
    @p1 v.sel        v30, v26, v6
    vf.mul       v31, v9, v5
    vf.sub       v9, v30, v15                    // t - 1, exact on [0.5, 4]
    .li       s2, #1060205056
    v.splat      v30, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v32, v0, v29, v7
    .li       s2, #901758606
    v.splat      v33, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v34, v16, v9, v17
    .li       s2, #1262485504
    v.splat      v35, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v36, v32, v29, v4
    .li       s2, #961512523
    v.splat      v32, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v37, v34, v9, v18
    .li       s2, #985056900
    v.splat      v34, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v38, v36, v29, v8
    .li       s2, #1007192376
    v.splat      v36, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v39, v37, v9, v19
    vf.fma       v37, v38, v29, v10
    .li       s2, #1026206279
    v.splat      v38, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v40, v39, v9, v14
    vf.fma       v39, v37, v29, v11
    .li       s2, #1042983594
    v.splat      v37, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v41, v40, v9, v20
    vf.fma       v40, v39, v29, v12
    .li       s2, #1056964608
    v.splat      v39, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fma       v42, v41, v9, v22
    vf.fma       v41, v40, v29, v13
    vf.fma       v29, v42, v9, v21
    vf.fma       v40, v23, v41, v23              // x + x*P(x*x)
    v.movi       v41, #127
    vf.fma       v42, v29, v9, v24
    v.movi       v29, #23
    .li       s2, #-2147483648
    v.splat      v43, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.lt    p1, v26, v6
    vf.fma       v44, v42, v9, v25
    v.and        v9, v23, v43
    vf.cmp.lt    p3, v26, v15
    v.splat      v26, s8
    vf.fma       v42, v44, v27, v28
    s.movz       s2, #1
    s.movz       s3, #1
    vf.sub       v43, v42, v28
    v.sub        v45, v42, v35
    v.add        v35, v45, v41
    vf.neg       v41, v43
    vf.neg       v42, v43
    v.shl        v43, v35, v29
    vf.fma       v29, v41, v30, v44              // q - n*ln2_hi, exact
    vf.fma       v35, v42, v33, v29
    vf.fma       v29, v32, v35, v34
    vf.mul       v41, v35, v35
    vf.fma       v42, v29, v35, v36
    vf.fma       v29, v42, v35, v38
    vf.fma       v42, v29, v35, v37
    vf.fma       v29, v42, v35, v39
    vf.fma       v42, v41, v29, v35
    vf.add       v29, v42, v15                   // e**f
    .li       s4, #1262485504
    v.splat      v35, s4                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.neg       v41, v29
    vf.fma       v29, v41, v43, v15              // 1 - e**f * 2**n
    @p1 v.sel        v41, v29, v15
    vf.cmp.uo    p1, v23, v23
    v.or         v29, v41, v9
    @p3 v.sel        v9, v40, v29
    v.cmp.lt     p3, v26, v3
    @p1 v.sel        v26, v23, v9
    p.and        p1, p3, p2
    vf.add       v9, v26, v1
    vf.mul       v23, v31, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v26, #23
    @p1 v.st.h       [s15, #0], v9
    a.vread      v9, a1, s2
    a.vread      v29, a1, s3
    vf.mul       v31, v9, v5
    vf.mul       v9, v29, v2
    .li       s2, #-2147483648
    v.splat      v29, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v40, v9
    vf.mul       v41, v9, v9
    v.and        v42, v9, v29
    vf.cmp.lt    p1, v40, v6
    @p1 v.sel        v29, v40, v6
    vf.fma       v43, v0, v41, v7
    vf.sub       v44, v29, v15                   // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v40, v6
    vf.cmp.lt    p3, v40, v15
    vf.fma       v29, v43, v41, v4
    vf.fma       v40, v16, v44, v17
    vf.fma       v43, v29, v41, v8
    vf.fma       v29, v40, v44, v18
    vf.fma       v40, v43, v41, v10
    vf.fma       v43, v29, v44, v19
    vf.fma       v29, v40, v41, v11
    vf.fma       v40, v43, v44, v14
    vf.fma       v43, v29, v41, v12
    vf.fma       v29, v40, v44, v20
    vf.fma       v40, v43, v41, v13
    vf.fma       v41, v29, v44, v22
    s.addi       s2, s15, #8192                  // row 1
    vf.fma       v29, v9, v40, v9                // x + x*P(x*x)
    vf.fma       v40, v41, v44, v21
    s.addi       s3, s8, #1
    s.movz       s4, #2
    v.splat      v41, s3
    vf.fma       v43, v40, v44, v24
    s.movz       s3, #2
    vf.fma       v40, v43, v44, v25
    vf.fma       v43, v40, v27, v28
    vf.sub       v44, v43, v28
    v.sub        v45, v43, v35
    v.add        v35, v45, v23
    vf.neg       v23, v44
    vf.neg       v43, v44
    v.shl        v44, v35, v26
    vf.fma       v26, v23, v30, v40              // q - n*ln2_hi, exact
    vf.fma       v23, v43, v33, v26
    vf.fma       v26, v32, v23, v34
    vf.mul       v35, v23, v23
    vf.fma       v40, v26, v23, v36
    vf.fma       v26, v40, v23, v38
    vf.fma       v40, v26, v23, v37
    vf.fma       v26, v40, v23, v39
    vf.fma       v40, v35, v26, v23
    vf.add       v23, v40, v15                   // e**f
    vf.neg       v26, v23
    vf.fma       v23, v26, v44, v15              // 1 - e**f * 2**n
    .li       s5, #1262485504
    v.splat      v26, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v35, v23, v15
    vf.cmp.uo    p1, v9, v9
    v.or         v23, v35, v42
    @p3 v.sel        v35, v29, v23
    v.cmp.lt     p3, v41, v3
    @p1 v.sel        v23, v9, v35
    p.and        p1, p3, p2
    vf.add       v9, v23, v1
    vf.mul       v23, v31, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v29, #23
    @p1 v.st.h       [s2, #0], v9
    a.vread      v9, a1, s4
    a.vread      v31, a1, s3
    vf.mul       v35, v9, v5
    vf.mul       v9, v31, v2
    .li       s2, #-2147483648
    v.splat      v31, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v40, v9
    vf.mul       v41, v9, v9
    v.and        v42, v9, v31
    vf.cmp.lt    p1, v40, v6
    @p1 v.sel        v31, v40, v6
    vf.fma       v43, v0, v41, v7
    vf.sub       v44, v31, v15                   // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v40, v6
    vf.cmp.lt    p3, v40, v15
    vf.fma       v31, v43, v41, v4
    vf.fma       v40, v16, v44, v17
    vf.fma       v43, v31, v41, v8
    vf.fma       v31, v40, v44, v18
    vf.fma       v40, v43, v41, v10
    vf.fma       v43, v31, v44, v19
    vf.fma       v31, v40, v41, v11
    vf.fma       v40, v43, v44, v14
    vf.fma       v43, v31, v41, v12
    vf.fma       v31, v40, v44, v20
    vf.fma       v40, v43, v41, v13
    vf.fma       v41, v31, v44, v22
    s.addi       s2, s15, #16384                 // row 2
    vf.fma       v31, v9, v40, v9                // x + x*P(x*x)
    vf.fma       v40, v41, v44, v21
    s.addi       s3, s8, #2
    s.movz       s4, #3
    v.splat      v41, s3
    vf.fma       v43, v40, v44, v24
    s.movz       s3, #3
    vf.fma       v40, v43, v44, v25
    vf.fma       v43, v40, v27, v28
    vf.sub       v44, v43, v28
    v.sub        v45, v43, v26
    v.add        v26, v45, v23
    vf.neg       v23, v44
    vf.neg       v43, v44
    v.shl        v44, v26, v29
    vf.fma       v26, v23, v30, v40              // q - n*ln2_hi, exact
    vf.fma       v23, v43, v33, v26
    vf.fma       v26, v32, v23, v34
    vf.mul       v29, v23, v23
    vf.fma       v40, v26, v23, v36
    vf.fma       v26, v40, v23, v38
    vf.fma       v40, v26, v23, v37
    vf.fma       v26, v40, v23, v39
    vf.fma       v40, v29, v26, v23
    vf.add       v23, v40, v15                   // e**f
    vf.neg       v26, v23
    vf.fma       v23, v26, v44, v15              // 1 - e**f * 2**n
    .li       s5, #1262485504
    v.splat      v26, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v29, v23, v15
    vf.cmp.uo    p1, v9, v9
    v.or         v23, v29, v42
    @p3 v.sel        v29, v31, v23
    v.cmp.lt     p3, v41, v3
    @p1 v.sel        v23, v9, v29
    p.and        p1, p3, p2
    vf.add       v9, v23, v1
    vf.mul       v23, v35, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v29, #23
    @p1 v.st.h       [s2, #0], v9
    a.vread      v9, a1, s4
    a.vread      v31, a1, s3
    vf.mul       v35, v9, v5
    vf.mul       v9, v31, v2
    .li       s2, #-2147483648
    v.splat      v31, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v40, v9
    vf.mul       v41, v9, v9
    v.and        v42, v9, v31
    vf.cmp.lt    p1, v40, v6
    @p1 v.sel        v31, v40, v6
    vf.fma       v43, v0, v41, v7
    vf.sub       v44, v31, v15                   // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v40, v6
    vf.cmp.lt    p3, v40, v15
    vf.fma       v31, v43, v41, v4
    vf.fma       v40, v16, v44, v17
    vf.fma       v43, v31, v41, v8
    vf.fma       v31, v40, v44, v18
    vf.fma       v40, v43, v41, v10
    vf.fma       v43, v31, v44, v19
    vf.fma       v31, v40, v41, v11
    vf.fma       v40, v43, v44, v14
    vf.fma       v43, v31, v41, v12
    vf.fma       v31, v40, v44, v20
    vf.fma       v40, v43, v41, v13
    vf.fma       v41, v31, v44, v22
    s.addi       s2, s15, #24576                 // row 3
    vf.fma       v31, v9, v40, v9                // x + x*P(x*x)
    vf.fma       v40, v41, v44, v21
    s.addi       s3, s8, #3
    s.movz       s4, #4
    v.splat      v41, s3
    vf.fma       v43, v40, v44, v24
    s.movz       s3, #4
    vf.fma       v40, v43, v44, v25
    vf.fma       v43, v40, v27, v28
    vf.sub       v44, v43, v28
    v.sub        v45, v43, v26
    v.add        v26, v45, v23
    vf.neg       v23, v44
    vf.neg       v43, v44
    v.shl        v44, v26, v29
    vf.fma       v26, v23, v30, v40              // q - n*ln2_hi, exact
    vf.fma       v23, v43, v33, v26
    vf.fma       v26, v32, v23, v34
    vf.mul       v29, v23, v23
    vf.fma       v40, v26, v23, v36
    vf.fma       v26, v40, v23, v38
    vf.fma       v40, v26, v23, v37
    vf.fma       v26, v40, v23, v39
    vf.fma       v40, v29, v26, v23
    vf.add       v23, v40, v15                   // e**f
    vf.neg       v26, v23
    vf.fma       v23, v26, v44, v15              // 1 - e**f * 2**n
    .li       s5, #1262485504
    v.splat      v26, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v29, v23, v15
    vf.cmp.uo    p1, v9, v9
    v.or         v23, v29, v42
    @p3 v.sel        v29, v31, v23
    v.cmp.lt     p3, v41, v3
    @p1 v.sel        v23, v9, v29
    p.and        p1, p3, p2
    vf.add       v9, v23, v1
    vf.mul       v23, v35, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v29, #23
    @p1 v.st.h       [s2, #0], v9
    a.vread      v9, a1, s4
    a.vread      v31, a1, s3
    vf.mul       v35, v9, v5
    vf.mul       v9, v31, v2
    .li       s2, #-2147483648
    v.splat      v31, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v40, v9
    vf.mul       v41, v9, v9
    v.and        v42, v9, v31
    vf.cmp.lt    p1, v40, v6
    @p1 v.sel        v31, v40, v6
    vf.fma       v43, v0, v41, v7
    vf.sub       v44, v31, v15                   // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v40, v6
    vf.cmp.lt    p3, v40, v15
    vf.fma       v31, v43, v41, v4
    vf.fma       v40, v16, v44, v17
    vf.fma       v43, v31, v41, v8
    vf.fma       v31, v40, v44, v18
    vf.fma       v40, v43, v41, v10
    vf.fma       v43, v31, v44, v19
    vf.fma       v31, v40, v41, v11
    vf.fma       v40, v43, v44, v14
    vf.fma       v43, v31, v41, v12
    vf.fma       v31, v40, v44, v20
    vf.fma       v40, v43, v41, v13
    vf.fma       v41, v31, v44, v22
    s.movz       s2, #32768
    vf.fma       v31, v9, v40, v9                // x + x*P(x*x)
    vf.fma       v40, v41, v44, v21
    s.addi       s3, s8, #4
    s.add        s4, s15, s2                     // row 4
    v.splat      v41, s3
    vf.fma       v43, v40, v44, v24
    s.movz       s2, #5
    s.movz       s3, #5
    vf.fma       v40, v43, v44, v25
    vf.fma       v43, v40, v27, v28
    vf.sub       v44, v43, v28
    v.sub        v45, v43, v26
    v.add        v26, v45, v23
    vf.neg       v23, v44
    vf.neg       v43, v44
    v.shl        v44, v26, v29
    vf.fma       v26, v23, v30, v40              // q - n*ln2_hi, exact
    vf.fma       v23, v43, v33, v26
    vf.fma       v26, v32, v23, v34
    vf.mul       v29, v23, v23
    vf.fma       v40, v26, v23, v36
    vf.fma       v26, v40, v23, v38
    vf.fma       v40, v26, v23, v37
    vf.fma       v26, v40, v23, v39
    vf.fma       v40, v29, v26, v23
    vf.add       v23, v40, v15                   // e**f
    vf.neg       v26, v23
    vf.fma       v23, v26, v44, v15              // 1 - e**f * 2**n
    .li       s5, #1262485504
    v.splat      v26, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v29, v23, v15
    vf.cmp.uo    p1, v9, v9
    v.or         v23, v29, v42
    @p3 v.sel        v29, v31, v23
    v.cmp.lt     p3, v41, v3
    @p1 v.sel        v23, v9, v29
    p.and        p1, p3, p2
    vf.add       v9, v23, v1
    vf.mul       v23, v35, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v29, #23
    @p1 v.st.h       [s4, #0], v9
    a.vread      v9, a1, s2
    a.vread      v31, a1, s3
    vf.mul       v35, v9, v5
    vf.mul       v9, v31, v2
    .li       s2, #-2147483648
    v.splat      v31, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v40, v9
    vf.mul       v41, v9, v9
    v.and        v42, v9, v31
    vf.cmp.lt    p1, v40, v6
    @p1 v.sel        v31, v40, v6
    vf.fma       v43, v0, v41, v7
    vf.sub       v44, v31, v15                   // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v40, v6
    vf.cmp.lt    p3, v40, v15
    vf.fma       v31, v43, v41, v4
    vf.fma       v40, v16, v44, v17
    vf.fma       v43, v31, v41, v8
    vf.fma       v31, v40, v44, v18
    vf.fma       v40, v43, v41, v10
    vf.fma       v43, v31, v44, v19
    vf.fma       v31, v40, v41, v11
    vf.fma       v40, v43, v44, v14
    vf.fma       v43, v31, v41, v12
    vf.fma       v31, v40, v44, v20
    vf.fma       v40, v43, v41, v13
    vf.fma       v41, v31, v44, v22
    s.movz       s2, #40960
    vf.fma       v31, v9, v40, v9                // x + x*P(x*x)
    vf.fma       v40, v41, v44, v21
    s.addi       s3, s8, #5
    s.add        s4, s15, s2                     // row 5
    v.splat      v41, s3
    vf.fma       v43, v40, v44, v24
    s.movz       s2, #6
    s.movz       s3, #6
    vf.fma       v40, v43, v44, v25
    vf.fma       v43, v40, v27, v28
    vf.sub       v44, v43, v28
    v.sub        v45, v43, v26
    v.add        v26, v45, v23
    vf.neg       v23, v44
    vf.neg       v43, v44
    v.shl        v44, v26, v29
    vf.fma       v26, v23, v30, v40              // q - n*ln2_hi, exact
    vf.fma       v23, v43, v33, v26
    vf.fma       v26, v32, v23, v34
    vf.mul       v29, v23, v23
    vf.fma       v40, v26, v23, v36
    vf.fma       v26, v40, v23, v38
    vf.fma       v40, v26, v23, v37
    vf.fma       v26, v40, v23, v39
    vf.fma       v40, v29, v26, v23
    vf.add       v23, v40, v15                   // e**f
    vf.neg       v26, v23
    vf.fma       v23, v26, v44, v15              // 1 - e**f * 2**n
    .li       s5, #1262485504
    v.splat      v26, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v29, v23, v15
    vf.cmp.uo    p1, v9, v9
    v.or         v23, v29, v42
    @p3 v.sel        v29, v31, v23
    v.cmp.lt     p3, v41, v3
    @p1 v.sel        v23, v9, v29
    p.and        p1, p3, p2
    vf.add       v9, v23, v1
    vf.mul       v23, v35, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v29, #23
    @p1 v.st.h       [s4, #0], v9
    a.vread      v9, a1, s2
    a.vread      v31, a1, s3
    vf.mul       v35, v9, v5
    vf.mul       v9, v31, v2
    .li       s2, #-2147483648
    v.splat      v31, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v40, v9
    vf.mul       v41, v9, v9
    v.and        v42, v9, v31
    vf.cmp.lt    p1, v40, v6
    @p1 v.sel        v31, v40, v6
    vf.fma       v43, v0, v41, v7
    vf.sub       v44, v31, v15                   // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v40, v6
    vf.cmp.lt    p3, v40, v15
    vf.fma       v31, v43, v41, v4
    vf.fma       v40, v16, v44, v17
    vf.fma       v43, v31, v41, v8
    vf.fma       v31, v40, v44, v18
    vf.fma       v40, v43, v41, v10
    vf.fma       v43, v31, v44, v19
    vf.fma       v31, v40, v41, v11
    vf.fma       v40, v43, v44, v14
    vf.fma       v43, v31, v41, v12
    vf.fma       v31, v40, v44, v20
    vf.fma       v40, v43, v41, v13
    vf.fma       v41, v31, v44, v22
    s.movz       s2, #49152
    vf.fma       v31, v9, v40, v9                // x + x*P(x*x)
    vf.fma       v40, v41, v44, v21
    s.addi       s3, s8, #6
    s.add        s4, s15, s2                     // row 6
    v.splat      v41, s3
    vf.fma       v43, v40, v44, v24
    s.movz       s2, #7
    s.movz       s3, #7
    vf.fma       v40, v43, v44, v25
    vf.fma       v43, v40, v27, v28
    vf.sub       v44, v43, v28
    v.sub        v45, v43, v26
    v.add        v26, v45, v23
    vf.neg       v23, v44
    vf.neg       v43, v44
    v.shl        v44, v26, v29
    vf.fma       v26, v23, v30, v40              // q - n*ln2_hi, exact
    vf.fma       v23, v43, v33, v26
    vf.fma       v26, v32, v23, v34
    vf.mul       v29, v23, v23
    vf.fma       v40, v26, v23, v36
    vf.fma       v26, v40, v23, v38
    vf.fma       v40, v26, v23, v37
    vf.fma       v26, v40, v23, v39
    vf.fma       v40, v29, v26, v23
    vf.add       v23, v40, v15                   // e**f
    vf.neg       v26, v23
    vf.fma       v23, v26, v44, v15              // 1 - e**f * 2**n
    .li       s5, #1262485504
    v.splat      v26, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v29, v23, v15
    vf.cmp.uo    p1, v9, v9
    v.or         v23, v29, v42
    @p3 v.sel        v29, v31, v23
    v.cmp.lt     p3, v41, v3
    @p1 v.sel        v23, v9, v29
    p.and        p1, p3, p2
    vf.add       v9, v23, v1
    vf.mul       v23, v35, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v29, #23
    @p1 v.st.h       [s4, #0], v9
    a.vread      v9, a1, s2
    a.vread      v31, a1, s3
    vf.mul       v35, v9, v5
    vf.mul       v9, v31, v2
    .li       s2, #-2147483648
    v.splat      v31, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v40, v9
    vf.mul       v41, v9, v9
    v.and        v42, v9, v31
    vf.cmp.lt    p1, v40, v6
    @p1 v.sel        v31, v40, v6
    vf.fma       v43, v0, v41, v7
    vf.sub       v44, v31, v15                   // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v40, v6
    vf.cmp.lt    p3, v40, v15
    vf.fma       v31, v43, v41, v4
    vf.fma       v40, v16, v44, v17
    vf.fma       v43, v31, v41, v8
    vf.fma       v31, v40, v44, v18
    vf.fma       v40, v43, v41, v10
    vf.fma       v43, v31, v44, v19
    vf.fma       v31, v40, v41, v11
    vf.fma       v40, v43, v44, v14
    vf.fma       v43, v31, v41, v12
    vf.fma       v31, v40, v44, v20
    vf.fma       v40, v43, v41, v13
    vf.fma       v41, v31, v44, v22
    s.movz       s2, #57344
    vf.fma       v31, v9, v40, v9                // x + x*P(x*x)
    vf.fma       v40, v41, v44, v21
    s.addi       s3, s8, #7
    s.add        s4, s15, s2                     // row 7
    v.splat      v41, s3
    vf.fma       v43, v40, v44, v24
    s.movz       s2, #8
    s.movz       s3, #8
    vf.fma       v40, v43, v44, v25
    vf.fma       v43, v40, v27, v28
    vf.sub       v44, v43, v28
    v.sub        v45, v43, v26
    v.add        v26, v45, v23
    vf.neg       v23, v44
    vf.neg       v43, v44
    v.shl        v44, v26, v29
    vf.fma       v26, v23, v30, v40              // q - n*ln2_hi, exact
    vf.fma       v23, v43, v33, v26
    vf.fma       v26, v32, v23, v34
    vf.mul       v29, v23, v23
    vf.fma       v40, v26, v23, v36
    vf.fma       v26, v40, v23, v38
    vf.fma       v40, v26, v23, v37
    vf.fma       v26, v40, v23, v39
    vf.fma       v40, v29, v26, v23
    vf.add       v23, v40, v15                   // e**f
    vf.neg       v26, v23
    vf.fma       v23, v26, v44, v15              // 1 - e**f * 2**n
    .li       s5, #1262485504
    v.splat      v26, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v29, v23, v15
    vf.cmp.uo    p1, v9, v9
    v.or         v23, v29, v42
    @p3 v.sel        v29, v31, v23
    v.cmp.lt     p3, v41, v3
    @p1 v.sel        v23, v9, v29
    p.and        p1, p3, p2
    vf.add       v9, v23, v1
    vf.mul       v23, v35, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v29, #23
    @p1 v.st.h       [s4, #0], v9
    a.vread      v9, a1, s2
    a.vread      v31, a1, s3
    vf.mul       v35, v9, v5
    vf.mul       v9, v31, v2
    .li       s2, #-2147483648
    v.splat      v31, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v40, v9
    vf.mul       v41, v9, v9
    v.and        v42, v9, v31
    vf.cmp.lt    p1, v40, v6
    @p1 v.sel        v31, v40, v6
    vf.fma       v43, v0, v41, v7
    vf.sub       v44, v31, v15                   // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v40, v6
    vf.cmp.lt    p3, v40, v15
    vf.fma       v31, v43, v41, v4
    vf.fma       v40, v16, v44, v17
    vf.fma       v43, v31, v41, v8
    vf.fma       v31, v40, v44, v18
    vf.fma       v40, v43, v41, v10
    vf.fma       v43, v31, v44, v19
    vf.fma       v31, v40, v41, v11
    vf.fma       v40, v43, v44, v14
    vf.fma       v43, v31, v41, v12
    vf.fma       v31, v40, v44, v20
    vf.fma       v40, v43, v41, v13
    vf.fma       v41, v31, v44, v22
    .li       s2, #65536
    vf.fma       v31, v9, v40, v9                // x + x*P(x*x)
    vf.fma       v40, v41, v44, v21
    s.addi       s3, s8, #8
    s.add        s4, s15, s2                     // row 8
    v.splat      v41, s3
    vf.fma       v43, v40, v44, v24
    s.movz       s2, #9
    s.movz       s3, #9
    vf.fma       v40, v43, v44, v25
    vf.fma       v43, v40, v27, v28
    vf.sub       v44, v43, v28
    v.sub        v45, v43, v26
    v.add        v26, v45, v23
    vf.neg       v23, v44
    vf.neg       v43, v44
    v.shl        v44, v26, v29
    vf.fma       v26, v23, v30, v40              // q - n*ln2_hi, exact
    vf.fma       v23, v43, v33, v26
    vf.fma       v26, v32, v23, v34
    vf.mul       v29, v23, v23
    vf.fma       v40, v26, v23, v36
    vf.fma       v26, v40, v23, v38
    vf.fma       v40, v26, v23, v37
    vf.fma       v26, v40, v23, v39
    vf.fma       v40, v29, v26, v23
    vf.add       v23, v40, v15                   // e**f
    vf.neg       v26, v23
    vf.fma       v23, v26, v44, v15              // 1 - e**f * 2**n
    .li       s5, #1262485504
    v.splat      v26, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v29, v23, v15
    vf.cmp.uo    p1, v9, v9
    v.or         v23, v29, v42
    @p3 v.sel        v29, v31, v23
    v.cmp.lt     p3, v41, v3
    @p1 v.sel        v23, v9, v29
    p.and        p1, p3, p2
    vf.add       v9, v23, v1
    vf.mul       v23, v35, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v29, #23
    @p1 v.st.h       [s4, #0], v9
    a.vread      v9, a1, s2
    a.vread      v31, a1, s3
    vf.mul       v35, v9, v5
    vf.mul       v9, v31, v2
    .li       s2, #-2147483648
    v.splat      v31, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v40, v9
    vf.mul       v41, v9, v9
    v.and        v42, v9, v31
    vf.cmp.lt    p1, v40, v6
    @p1 v.sel        v31, v40, v6
    vf.fma       v43, v0, v41, v7
    vf.sub       v44, v31, v15                   // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v40, v6
    vf.cmp.lt    p3, v40, v15
    vf.fma       v31, v43, v41, v4
    vf.fma       v40, v16, v44, v17
    vf.fma       v43, v31, v41, v8
    vf.fma       v31, v40, v44, v18
    vf.fma       v40, v43, v41, v10
    vf.fma       v43, v31, v44, v19
    vf.fma       v31, v40, v41, v11
    vf.fma       v40, v43, v44, v14
    vf.fma       v43, v31, v41, v12
    vf.fma       v31, v40, v44, v20
    vf.fma       v40, v43, v41, v13
    vf.fma       v41, v31, v44, v22
    .li       s2, #73728
    vf.fma       v31, v9, v40, v9                // x + x*P(x*x)
    vf.fma       v40, v41, v44, v21
    s.addi       s3, s8, #9
    s.add        s4, s15, s2                     // row 9
    v.splat      v41, s3
    vf.fma       v43, v40, v44, v24
    s.movz       s2, #10
    s.movz       s3, #10
    vf.fma       v40, v43, v44, v25
    vf.fma       v43, v40, v27, v28
    vf.sub       v44, v43, v28
    v.sub        v45, v43, v26
    v.add        v26, v45, v23
    vf.neg       v23, v44
    vf.neg       v43, v44
    v.shl        v44, v26, v29
    vf.fma       v26, v23, v30, v40              // q - n*ln2_hi, exact
    vf.fma       v23, v43, v33, v26
    vf.fma       v26, v32, v23, v34
    vf.mul       v29, v23, v23
    vf.fma       v40, v26, v23, v36
    vf.fma       v26, v40, v23, v38
    vf.fma       v40, v26, v23, v37
    vf.fma       v26, v40, v23, v39
    vf.fma       v40, v29, v26, v23
    vf.add       v23, v40, v15                   // e**f
    vf.neg       v26, v23
    vf.fma       v23, v26, v44, v15              // 1 - e**f * 2**n
    .li       s5, #1262485504
    v.splat      v26, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v29, v23, v15
    vf.cmp.uo    p1, v9, v9
    v.or         v23, v29, v42
    @p3 v.sel        v29, v31, v23
    v.cmp.lt     p3, v41, v3
    @p1 v.sel        v23, v9, v29
    p.and        p1, p3, p2
    vf.add       v9, v23, v1
    vf.mul       v23, v35, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v29, #23
    @p1 v.st.h       [s4, #0], v9
    a.vread      v9, a1, s2
    a.vread      v31, a1, s3
    vf.mul       v35, v9, v5
    vf.mul       v9, v31, v2
    .li       s2, #-2147483648
    v.splat      v31, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v40, v9
    vf.mul       v41, v9, v9
    v.and        v42, v9, v31
    vf.cmp.lt    p1, v40, v6
    @p1 v.sel        v31, v40, v6
    vf.fma       v43, v0, v41, v7
    vf.sub       v44, v31, v15                   // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v40, v6
    vf.cmp.lt    p3, v40, v15
    vf.fma       v31, v43, v41, v4
    vf.fma       v40, v16, v44, v17
    vf.fma       v43, v31, v41, v8
    vf.fma       v31, v40, v44, v18
    vf.fma       v40, v43, v41, v10
    vf.fma       v43, v31, v44, v19
    vf.fma       v31, v40, v41, v11
    vf.fma       v40, v43, v44, v14
    vf.fma       v43, v31, v41, v12
    vf.fma       v31, v40, v44, v20
    vf.fma       v40, v43, v41, v13
    vf.fma       v41, v31, v44, v22
    .li       s2, #81920
    vf.fma       v31, v9, v40, v9                // x + x*P(x*x)
    vf.fma       v40, v41, v44, v21
    s.addi       s3, s8, #10
    s.add        s4, s15, s2                     // row 10
    v.splat      v41, s3
    vf.fma       v43, v40, v44, v24
    s.movz       s2, #11
    s.movz       s3, #11
    vf.fma       v40, v43, v44, v25
    vf.fma       v43, v40, v27, v28
    vf.sub       v44, v43, v28
    v.sub        v45, v43, v26
    v.add        v26, v45, v23
    vf.neg       v23, v44
    vf.neg       v43, v44
    v.shl        v44, v26, v29
    vf.fma       v26, v23, v30, v40              // q - n*ln2_hi, exact
    vf.fma       v23, v43, v33, v26
    vf.fma       v26, v32, v23, v34
    vf.mul       v29, v23, v23
    vf.fma       v40, v26, v23, v36
    vf.fma       v26, v40, v23, v38
    vf.fma       v40, v26, v23, v37
    vf.fma       v26, v40, v23, v39
    vf.fma       v40, v29, v26, v23
    vf.add       v23, v40, v15                   // e**f
    vf.neg       v26, v23
    vf.fma       v23, v26, v44, v15              // 1 - e**f * 2**n
    .li       s5, #1262485504
    v.splat      v26, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v29, v23, v15
    vf.cmp.uo    p1, v9, v9
    v.or         v23, v29, v42
    @p3 v.sel        v29, v31, v23
    v.cmp.lt     p3, v41, v3
    @p1 v.sel        v23, v9, v29
    p.and        p1, p3, p2
    vf.add       v9, v23, v1
    vf.mul       v23, v35, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v29, #23
    @p1 v.st.h       [s4, #0], v9
    a.vread      v9, a1, s2
    a.vread      v31, a1, s3
    vf.mul       v35, v9, v5
    vf.mul       v9, v31, v2
    .li       s2, #-2147483648
    v.splat      v31, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v40, v9
    vf.mul       v41, v9, v9
    v.and        v42, v9, v31
    vf.cmp.lt    p1, v40, v6
    @p1 v.sel        v31, v40, v6
    vf.fma       v43, v0, v41, v7
    vf.sub       v44, v31, v15                   // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v40, v6
    vf.cmp.lt    p3, v40, v15
    vf.fma       v31, v43, v41, v4
    vf.fma       v40, v16, v44, v17
    vf.fma       v43, v31, v41, v8
    vf.fma       v31, v40, v44, v18
    vf.fma       v40, v43, v41, v10
    vf.fma       v43, v31, v44, v19
    vf.fma       v31, v40, v41, v11
    vf.fma       v40, v43, v44, v14
    vf.fma       v43, v31, v41, v12
    vf.fma       v31, v40, v44, v20
    vf.fma       v40, v43, v41, v13
    vf.fma       v41, v31, v44, v22
    .li       s2, #90112
    vf.fma       v31, v9, v40, v9                // x + x*P(x*x)
    vf.fma       v40, v41, v44, v21
    s.addi       s3, s8, #11
    s.add        s4, s15, s2                     // row 11
    v.splat      v41, s3
    vf.fma       v43, v40, v44, v24
    s.movz       s2, #12
    s.movz       s3, #12
    vf.fma       v40, v43, v44, v25
    vf.fma       v43, v40, v27, v28
    vf.sub       v44, v43, v28
    v.sub        v45, v43, v26
    v.add        v26, v45, v23
    vf.neg       v23, v44
    vf.neg       v43, v44
    v.shl        v44, v26, v29
    vf.fma       v26, v23, v30, v40              // q - n*ln2_hi, exact
    vf.fma       v23, v43, v33, v26
    vf.fma       v26, v32, v23, v34
    vf.mul       v29, v23, v23
    vf.fma       v40, v26, v23, v36
    vf.fma       v26, v40, v23, v38
    vf.fma       v40, v26, v23, v37
    vf.fma       v26, v40, v23, v39
    vf.fma       v40, v29, v26, v23
    vf.add       v23, v40, v15                   // e**f
    vf.neg       v26, v23
    vf.fma       v23, v26, v44, v15              // 1 - e**f * 2**n
    .li       s5, #1262485504
    v.splat      v26, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v29, v23, v15
    vf.cmp.uo    p1, v9, v9
    v.or         v23, v29, v42
    @p3 v.sel        v29, v31, v23
    v.cmp.lt     p3, v41, v3
    @p1 v.sel        v23, v9, v29
    p.and        p1, p3, p2
    vf.add       v9, v23, v1
    vf.mul       v23, v35, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v29, #23
    @p1 v.st.h       [s4, #0], v9
    a.vread      v9, a1, s2
    a.vread      v31, a1, s3
    vf.mul       v35, v9, v5
    vf.mul       v9, v31, v2
    .li       s2, #-2147483648
    v.splat      v31, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v40, v9
    vf.mul       v41, v9, v9
    v.and        v42, v9, v31
    vf.cmp.lt    p1, v40, v6
    @p1 v.sel        v31, v40, v6
    vf.fma       v43, v0, v41, v7
    vf.sub       v44, v31, v15                   // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v40, v6
    vf.cmp.lt    p3, v40, v15
    vf.fma       v31, v43, v41, v4
    vf.fma       v40, v16, v44, v17
    vf.fma       v43, v31, v41, v8
    vf.fma       v31, v40, v44, v18
    vf.fma       v40, v43, v41, v10
    vf.fma       v43, v31, v44, v19
    vf.fma       v31, v40, v41, v11
    vf.fma       v40, v43, v44, v14
    vf.fma       v43, v31, v41, v12
    vf.fma       v31, v40, v44, v20
    vf.fma       v40, v43, v41, v13
    vf.fma       v41, v31, v44, v22
    .li       s2, #98304
    vf.fma       v31, v9, v40, v9                // x + x*P(x*x)
    vf.fma       v40, v41, v44, v21
    s.addi       s3, s8, #12
    s.add        s4, s15, s2                     // row 12
    v.splat      v41, s3
    vf.fma       v43, v40, v44, v24
    s.movz       s2, #13
    s.movz       s3, #13
    vf.fma       v40, v43, v44, v25
    vf.fma       v43, v40, v27, v28
    vf.sub       v44, v43, v28
    v.sub        v45, v43, v26
    v.add        v26, v45, v23
    vf.neg       v23, v44
    vf.neg       v43, v44
    v.shl        v44, v26, v29
    vf.fma       v26, v23, v30, v40              // q - n*ln2_hi, exact
    vf.fma       v23, v43, v33, v26
    vf.fma       v26, v32, v23, v34
    vf.mul       v29, v23, v23
    vf.fma       v40, v26, v23, v36
    vf.fma       v26, v40, v23, v38
    vf.fma       v40, v26, v23, v37
    vf.fma       v26, v40, v23, v39
    vf.fma       v40, v29, v26, v23
    vf.add       v23, v40, v15                   // e**f
    vf.neg       v26, v23
    vf.fma       v23, v26, v44, v15              // 1 - e**f * 2**n
    .li       s5, #1262485504
    v.splat      v26, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v29, v23, v15
    vf.cmp.uo    p1, v9, v9
    v.or         v23, v29, v42
    @p3 v.sel        v29, v31, v23
    v.cmp.lt     p3, v41, v3
    @p1 v.sel        v23, v9, v29
    p.and        p1, p3, p2
    vf.add       v9, v23, v1
    vf.mul       v23, v35, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v29, #23
    @p1 v.st.h       [s4, #0], v9
    a.vread      v9, a1, s2
    a.vread      v31, a1, s3
    vf.mul       v35, v9, v5
    vf.mul       v9, v31, v2
    .li       s2, #-2147483648
    v.splat      v31, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v40, v9
    vf.mul       v41, v9, v9
    v.and        v42, v9, v31
    vf.cmp.lt    p1, v40, v6
    @p1 v.sel        v31, v40, v6
    vf.fma       v43, v0, v41, v7
    vf.sub       v44, v31, v15                   // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v40, v6
    vf.cmp.lt    p3, v40, v15
    vf.fma       v31, v43, v41, v4
    vf.fma       v40, v16, v44, v17
    vf.fma       v43, v31, v41, v8
    vf.fma       v31, v40, v44, v18
    vf.fma       v40, v43, v41, v10
    vf.fma       v43, v31, v44, v19
    vf.fma       v31, v40, v41, v11
    vf.fma       v40, v43, v44, v14
    vf.fma       v43, v31, v41, v12
    vf.fma       v31, v40, v44, v20
    vf.fma       v40, v43, v41, v13
    vf.fma       v41, v31, v44, v22
    .li       s2, #106496
    vf.fma       v31, v9, v40, v9                // x + x*P(x*x)
    vf.fma       v40, v41, v44, v21
    s.addi       s3, s8, #13
    s.add        s4, s15, s2                     // row 13
    v.splat      v41, s3
    vf.fma       v43, v40, v44, v24
    s.movz       s2, #14
    s.movz       s3, #14
    vf.fma       v40, v43, v44, v25
    vf.fma       v43, v40, v27, v28
    vf.sub       v44, v43, v28
    v.sub        v45, v43, v26
    v.add        v26, v45, v23
    vf.neg       v23, v44
    vf.neg       v43, v44
    v.shl        v44, v26, v29
    vf.fma       v26, v23, v30, v40              // q - n*ln2_hi, exact
    vf.fma       v23, v43, v33, v26
    vf.fma       v26, v32, v23, v34
    vf.mul       v29, v23, v23
    vf.fma       v40, v26, v23, v36
    vf.fma       v26, v40, v23, v38
    vf.fma       v40, v26, v23, v37
    vf.fma       v26, v40, v23, v39
    vf.fma       v40, v29, v26, v23
    vf.add       v23, v40, v15                   // e**f
    vf.neg       v26, v23
    vf.fma       v23, v26, v44, v15              // 1 - e**f * 2**n
    .li       s5, #1262485504
    v.splat      v26, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v29, v23, v15
    vf.cmp.uo    p1, v9, v9
    v.or         v23, v29, v42
    @p3 v.sel        v29, v31, v23
    v.cmp.lt     p3, v41, v3
    @p1 v.sel        v23, v9, v29
    p.and        p1, p3, p2
    vf.add       v9, v23, v1
    vf.mul       v23, v35, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v29, #23
    @p1 v.st.h       [s4, #0], v9
    a.vread      v9, a1, s2
    a.vread      v31, a1, s3
    vf.mul       v35, v9, v5
    vf.mul       v9, v31, v2
    .li       s2, #-2147483648
    v.splat      v31, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v40, v9
    vf.mul       v41, v9, v9
    v.and        v42, v9, v31
    vf.cmp.lt    p1, v40, v6
    @p1 v.sel        v31, v40, v6
    vf.fma       v43, v0, v41, v7
    vf.sub       v44, v31, v15                   // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v40, v6
    vf.cmp.lt    p3, v40, v15
    vf.fma       v31, v43, v41, v4
    vf.fma       v40, v16, v44, v17
    vf.fma       v43, v31, v41, v8
    vf.fma       v31, v40, v44, v18
    vf.fma       v40, v43, v41, v10
    vf.fma       v43, v31, v44, v19
    vf.fma       v31, v40, v41, v11
    vf.fma       v40, v43, v44, v14
    vf.fma       v43, v31, v41, v12
    vf.fma       v31, v40, v44, v20
    vf.fma       v40, v43, v41, v13
    vf.fma       v41, v31, v44, v22
    .li       s2, #114688
    vf.fma       v31, v9, v40, v9                // x + x*P(x*x)
    vf.fma       v40, v41, v44, v21
    s.addi       s3, s8, #14
    s.add        s4, s15, s2                     // row 14
    v.splat      v41, s3
    vf.fma       v43, v40, v44, v24
    s.movz       s2, #15
    s.movz       s3, #15
    vf.fma       v40, v43, v44, v25
    vf.fma       v43, v40, v27, v28
    vf.sub       v44, v43, v28
    v.sub        v45, v43, v26
    v.add        v26, v45, v23
    vf.neg       v23, v44
    vf.neg       v43, v44
    v.shl        v44, v26, v29
    vf.fma       v26, v23, v30, v40              // q - n*ln2_hi, exact
    vf.fma       v23, v43, v33, v26
    vf.fma       v26, v32, v23, v34
    vf.mul       v29, v23, v23
    vf.fma       v40, v26, v23, v36
    vf.fma       v26, v40, v23, v38
    vf.fma       v40, v26, v23, v37
    vf.fma       v26, v40, v23, v39
    vf.fma       v40, v29, v26, v23
    vf.add       v23, v40, v15                   // e**f
    vf.neg       v26, v23
    vf.fma       v23, v26, v44, v15              // 1 - e**f * 2**n
    .li       s5, #1262485504
    v.splat      v26, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v29, v23, v15
    vf.cmp.uo    p1, v9, v9
    v.or         v23, v29, v42
    @p3 v.sel        v29, v31, v23
    v.cmp.lt     p3, v41, v3
    @p1 v.sel        v23, v9, v29
    p.and        p1, p3, p2
    vf.add       v9, v23, v1
    vf.mul       v23, v35, v9
    vf.cvt.f32.bf16 v9, v23
    v.movi       v23, #127
    v.movi       v29, #23
    @p1 v.st.h       [s4, #0], v9
    a.vread      v9, a1, s2
    a.vread      v31, a1, s3
    vf.mul       v35, v9, v5
    vf.mul       v5, v31, v2
    .li       s2, #-2147483648
    v.splat      v2, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.abs       v9, v5
    vf.mul       v31, v5, v5
    v.and        v40, v5, v2
    vf.cmp.lt    p1, v9, v6
    @p1 v.sel        v2, v9, v6
    vf.fma       v41, v0, v31, v7
    vf.sub       v0, v2, v15                     // t - 1, exact on [0.5, 4]
    vf.cmp.lt    p1, v9, v6
    vf.cmp.lt    p3, v9, v15
    vf.fma       v2, v41, v31, v4
    vf.fma       v4, v16, v0, v17
    vf.fma       v6, v2, v31, v8
    vf.fma       v2, v4, v0, v18
    vf.fma       v4, v6, v31, v10
    vf.fma       v6, v2, v0, v19
    vf.fma       v2, v4, v31, v11
    vf.fma       v4, v6, v0, v14
    vf.fma       v6, v2, v31, v12
    vf.fma       v2, v4, v0, v20
    vf.fma       v4, v6, v31, v13
    vf.fma       v6, v2, v0, v22
    .li       s2, #122880
    vf.fma       v2, v5, v4, v5                  // x + x*P(x*x)
    vf.fma       v4, v6, v0, v21
    s.addi       s3, s8, #15
    s.add        s4, s15, s2                     // row 15
    v.splat      v6, s3
    vf.fma       v7, v4, v0, v24
    vf.fma       v4, v7, v0, v25
    vf.fma       v0, v4, v27, v28
    vf.sub       v7, v0, v28
    v.sub        v8, v0, v26
    v.add        v0, v8, v23
    vf.neg       v8, v7
    vf.neg       v9, v7
    v.shl        v7, v0, v29
    vf.fma       v0, v8, v30, v4                 // q - n*ln2_hi, exact
    vf.fma       v4, v9, v33, v0
    vf.fma       v0, v32, v4, v34
    vf.mul       v8, v4, v4
    vf.fma       v9, v0, v4, v36
    vf.fma       v0, v9, v4, v38
    vf.fma       v9, v0, v4, v37
    vf.fma       v0, v9, v4, v39
    vf.fma       v9, v8, v0, v4
    vf.add       v0, v9, v15                     // e**f
    vf.neg       v4, v0
    vf.fma       v0, v4, v7, v15                 // 1 - e**f * 2**n
    @p1 v.sel        v4, v0, v15
    vf.cmp.uo    p1, v5, v5
    v.or         v0, v4, v40
    @p3 v.sel        v4, v2, v0
    v.cmp.lt     p3, v6, v3
    @p1 v.sel        v0, v5, v4
    p.and        p1, p3, p2
    vf.add       v2, v0, v1
    vf.mul       v0, v35, v2
    vf.cvt.f32.bf16 v1, v0
    @p1 v.st.h       [s4, #0], v1
__rctx_next:
    exit
