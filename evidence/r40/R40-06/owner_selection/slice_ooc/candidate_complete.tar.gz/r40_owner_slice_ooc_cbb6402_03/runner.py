import hashlib,json,os,sys
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(Path.home()/'tnca_srcR40convergence_8abf527/tools/r1'))
import r1lib as R
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=root/'input/experiment.json';identity=json.loads(manifest.read_text())
baseline=Path(identity['baseline_reuse_root']);old=json.loads((baseline/'input/experiment.json').read_text())
old_run=json.loads((baseline/'run.json').read_text())
if old_run['results'][0]['status']!=R.PASS:raise RuntimeError('baseline did not complete')
for key in ('part','clock_target_hz','toolchain','threads','parameters','contract_sha256'):
    if old[key]!=identity[key]:raise RuntimeError('baseline configuration changed: '+key)
used=('baseline.v','common/tnca_defs.vh','common/tnca_amo.vh','synth.tcl')
for name in used:
    if old['input_sha256'][name]!=identity['input_sha256'][name]:
        raise RuntimeError('baseline dependency mismatch: '+name)
artifacts={str(p.relative_to(baseline)):sha(p) for p in (baseline/'baseline/ooc').iterdir() if p.is_file()}
if not all('baseline/ooc/'+name in artifacts for name in ('synth.dcp','utilization.rpt','timing.rpt','critical_paths.rpt','check_timing.rpt')):
    raise RuntimeError('baseline reports/checkpoint incomplete')
def verify():
    for name,digest in identity['input_sha256'].items():
        if sha(root/'input'/name)!=digest:raise RuntimeError('candidate input changed: '+name)
    for name in used:
        if sha(baseline/'input'/name)!=old['input_sha256'][name]:raise RuntimeError('baseline input changed: '+name)
    for name,digest in artifacts.items():
        if sha(baseline/name)!=digest:raise RuntimeError('baseline artifact changed: '+name)
verify()
report=dict(schema='tnca-slice-ooc-run/1',status='running',pid=os.getpid(),
    experiment_sha256=sha(manifest),supervisor_sha256=sha(Path(R.__file__)),runner_sha256=sha(Path(__file__)),
    baseline_reuse=dict(root=str(baseline),status='dependency-match',
        experiment_sha256=sha(baseline/'input/experiment.json'),run_sha256=sha(baseline/'run.json'),
        used_dependency_sha256={n:old['input_sha256'][n] for n in used},artifact_sha256=artifacts),
    per_variant_timeout_seconds=1800,results=[],gate_status='not-measured')
out=root/'run.json';out.write_text(json.dumps(report,indent=2)+'\n')
work=root/'candidate';work.mkdir(exist_ok=False)
print('BASELINE DEPENDENCIES VERIFIED; START corrected candidate',flush=True)
result=R.run_step(['bash',str(root/'run_variant.sh'),str(root),'candidate'],kind='build',
    case_dir=str(work),cwd=str(work),name='vivado',cap_seconds=1800)
report['results'].append(result)
verify()
report['status']='complete-diagnostic' if result['status']==R.PASS else 'incomplete-or-fail'
out.write_text(json.dumps(report,indent=2)+'\n')
(root/'experiment.exit').write_text(str(int(result['status']!=R.PASS))+'\n')
print(report['status'],flush=True)
