    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    v.movi       v2, #11
    v.sub        v3, v1, v0
    v.cmp.lt     p1, v0, v1
    @p1 v.sel        v4, v3, v0
    v.movi       v0, #2048
    v.lshr       v3, v4, v2
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    v.sub        v2, v1, v0
    v.sub        v4, v1, v3
    v.movi       v5, #0
    v.movi       v6, #0
    v.cmp.lt     p2, v0, v1
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #64
    s.movz       s6, #16
    s.ld.d       s7, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v7, #1
    s.ld.d       s8, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    @p2 v.sel        v7, v2, v0
    @p1 v.sel        v0, v4, v3
    s.addi       s1, s2, #0
    v.mov        v6, v5
for_1:
    s.cmp.ge     s2, s1, s5
    br.nz        s2, endfor_2
    s.mul        s2, s4, s5
    v.movi       v2, #64
    v.splat      v3, s1
    v.mul        v4, v0, v2
    v.add        v2, v3, v1
    s.add        s9, s1, s2
    v.extract    s10, v4, #0
    v.splat      v3, s10
    s.shli       s10, s9, #1                     // element offset -> bytes (x2)
    v.movi       v4, #64
    v.add        v5, v2, v3
    s.add        s9, s7, s10                     // &in_ptr1[...]
    v.cmp.lt     p1, v2, v4
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s3, v5]               // index is in elements (ISA sec 9.1)
    .li       s10, #1052050675
    v.splat      v4, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v5, #0
    v.splat      v7, s2
    s.add        s2, s1, s6
    s.movz       s10, #1
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v8, [s9, #0]
    vf.cvt.f16.f32 v9, v3
    v.add        v3, v2, v7
    vf.mul       v2, v9, v4
    vf.cvt.f16.f32 v3, v8
    vf.mul       v7, v3, v4
    vf.mul       v3, v2, v7
    vf.add       v2, v6, v3
    @p1 v.sel        v3, v2, v6
    v.mov        v5, v3
    v.mov        v6, v5
    s.mov        s1, s2
    br.nz        s10, for_1
endfor_2:
    vf.reduce.add.b v0, v6
    v.movi       v1, #0
    s.movz       s1, #1
    vf.add       v2, v0, v1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s8, s2                      // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
