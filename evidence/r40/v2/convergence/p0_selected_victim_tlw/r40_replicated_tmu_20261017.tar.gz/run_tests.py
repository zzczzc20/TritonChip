from pathlib import Path
import subprocess,json
root=Path.cwd();out=root/'functional';out.mkdir(exist_ok=False);records=[]
def step(name,args,expected=0):
 p=subprocess.run(args,capture_output=True,text=True,timeout=120);text=p.stdout+p.stderr;(out/(name+'.log')).write_text(text)
 assert p.returncode==expected,(name,p.returncode,text[-3000:]);return text
for ports in [1,3]:
 binary=str(out/('ports'+str(ports)+'.vvp'))
 args=['iverilog','-g2012','-I','rtl/common','-s','tb_tmu_registered_ranges',f'-Ptb_tmu_registered_ranges.PORTS={ports}','-o',binary,'rtl/nuca/tnca_tmu.v','rtl/nuca/tnca_replicated_tmu.v','tb/nuca/tb_tmu_replicated.v']
 step('build'+str(ports),args);text=step('run'+str(ports),['vvp',binary]);assert 'TMU REGISTERED RANGES PASS' in text,text
 records.append(dict(ports=ports,status='cycle-equivalent-observed',scope='concurrent staging, clear/commit epoch, high64/overflow, TLW/dead and all MMIO reads'));print(text,flush=True)
source=(root/'rtl/nuca/tnca_replicated_tmu.v').read_text();needle='.mw_valid(mw_valid)';assert source.count(needle)==1
mutant=out/'replica_mutant.v';mutant.write_text(source.replace(needle,".mw_valid(local_id==N_SLICE-1 ? {N_SLICE{1'b0}} : mw_valid)"))
args[-2]=str(mutant);step('mutant_build',args);text=step('mutant_run',['vvp',binary],1);assert 'replica ' in text,text
records.append(dict(status='missing-broadcast-mutation-detected',log='mutant_run.log'))
(out/'report.json').write_text(json.dumps(records,indent=2)+'\n')
print('REPLICATED_TMU_FUNCTIONAL_SCREEN_DONE',flush=True)
