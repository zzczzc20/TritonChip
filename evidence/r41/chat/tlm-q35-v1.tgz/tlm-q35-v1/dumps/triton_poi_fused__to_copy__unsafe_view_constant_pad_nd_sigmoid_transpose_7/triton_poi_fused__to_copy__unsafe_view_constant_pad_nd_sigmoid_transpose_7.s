    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    s.movz       s2, #0
    v.iota       v0                              // arange(0, VLEN)
    s.add        s3, s2, s1                      // the tile origin
    v.movi       v1, #0
    v.splat      v2, s3
    v.movi       v3, #0
    s.rdspecial  s2, arg_base
    v.add        v4, v0, v2
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, pid.y
    v.extract    s5, v4, #0
    v.extract    s6, v4, #1
    s.shli       s7, s5, #32
    s.shli       s5, s6, #32
    s.ashri      s6, s7, #32
    v.extract    s7, v4, #2
    s.lshri      s8, s6, #32
    s.ashri      s9, s5, #32
    s.shli       s5, s7, #32
    s.ld.d       s7, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.insert     v1, s6, #0
    v.insert     v3, s8, #0
    s.lshri      s2, s9, #32
    v.extract    s6, v4, #3
    s.ashri      s8, s5, #32
    v.insert     v1, s9, #1
    v.insert     v3, s2, #1
    s.shli       s2, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v4, #4
    s.ashri      s9, s2, #32
    v.insert     v1, s8, #2
    v.insert     v3, s5, #2
    s.shli       s2, s6, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v4, #5
    s.ashri      s8, s2, #32
    v.insert     v1, s9, #3
    v.insert     v3, s5, #3
    s.shli       s2, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v4, #6
    s.ashri      s9, s2, #32
    v.insert     v1, s8, #4
    v.insert     v3, s5, #4
    s.shli       s2, s6, #32
    s.lshri      s5, s9, #32
    s.ashri      s6, s2, #32
    v.insert     v1, s9, #5
    v.insert     v3, s5, #5
    s.shli       s2, s4, #4                      // x16 as a shift
    v.extract    s4, v4, #7
    s.lshri      s5, s6, #32
    s.shli       s8, s4, #32
    v.extract    s4, v4, #8
    s.ashri      s9, s8, #32
    v.insert     v1, s6, #6
    v.insert     v3, s5, #6
    s.shli       s5, s4, #32
    s.lshri      s4, s9, #32
    v.extract    s6, v4, #9
    s.ashri      s8, s5, #32
    v.insert     v1, s9, #7
    v.insert     v3, s4, #7
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v4, #10
    s.ashri      s9, s4, #32
    v.insert     v1, s8, #8
    v.insert     v3, s5, #8
    s.shli       s4, s6, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v4, #11
    s.ashri      s8, s4, #32
    v.insert     v1, s9, #9
    v.insert     v3, s5, #9
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v4, #12
    s.ashri      s9, s4, #32
    v.insert     v1, s8, #10
    v.insert     v3, s5, #10
    s.shli       s4, s6, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v4, #13
    s.ashri      s8, s4, #32
    v.insert     v1, s9, #11
    v.insert     v3, s5, #11
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v4, #14
    s.ashri      s9, s4, #32
    v.insert     v1, s8, #12
    v.insert     v3, s5, #12
    s.shli       s4, s6, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v4, #15
    s.ashri      s8, s4, #32
    v.insert     v1, s9, #13
    v.insert     v3, s5, #13
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    s.ashri      s6, s4, #32
    v.insert     v1, s8, #14
    v.insert     v3, s5, #14
    s.lshri      s4, s6, #32
    v.insert     v1, s6, #15
    v.insert     v3, s4, #15
    s.movz       s4, #15
    v.extract    s5, v1, #0
    v.extract    s6, v3, #0
    v.extract    s8, v3, #1
    s.shli       s9, s6, #32
    v.movi       v0, #0
    s.or         s6, s5, s9
    v.extract    s5, v1, #1
    s.shli       s9, s8, #32
    s.cmp.lt     s8, s6, s4
    v.extract    s6, v3, #2
    s.or         s10, s5, s9
    v.insert     v0, s8, #0
    v.extract    s5, v1, #2
    s.shli       s8, s6, #32
    s.cmp.lt     s6, s10, s4
    v.extract    s9, v3, #3
    s.or         s10, s5, s8
    v.insert     v0, s6, #1
    v.extract    s5, v1, #3
    s.shli       s6, s9, #32
    s.cmp.lt     s8, s10, s4
    v.extract    s9, v3, #4
    s.or         s10, s5, s6
    v.insert     v0, s8, #2
    v.extract    s5, v1, #4
    s.shli       s6, s9, #32
    s.cmp.lt     s8, s10, s4
    v.extract    s9, v3, #5
    s.or         s10, s5, s6
    v.insert     v0, s8, #3
    v.extract    s5, v1, #5
    s.shli       s6, s9, #32
    s.cmp.lt     s8, s10, s4
    v.extract    s4, v3, #6
    s.or         s9, s5, s6
    s.movz       s5, #15
    v.insert     v0, s8, #4
    v.extract    s6, v1, #6
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s9, s5
    v.extract    s5, v3, #7
    s.or         s9, s6, s8
    s.movz       s6, #15
    v.insert     v0, s4, #5
    v.extract    s4, v1, #7
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s9, s6
    v.extract    s6, v3, #8
    s.or         s9, s4, s8
    s.movz       s4, #15
    v.insert     v0, s5, #6
    v.extract    s5, v1, #8
    s.shli       s8, s6, #32
    s.cmp.lt     s6, s9, s4
    v.extract    s4, v3, #9
    s.or         s9, s5, s8
    s.movz       s5, #15
    v.insert     v0, s6, #7
    v.extract    s6, v1, #9
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s9, s5
    v.extract    s5, v3, #10
    s.or         s9, s6, s8
    s.movz       s6, #15
    v.insert     v0, s4, #8
    v.extract    s4, v1, #10
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s9, s6
    v.extract    s6, v3, #11
    s.or         s9, s4, s8
    s.movz       s4, #15
    v.insert     v0, s5, #9
    v.extract    s5, v1, #11
    s.shli       s8, s6, #32
    s.cmp.lt     s6, s9, s4
    v.extract    s4, v3, #12
    s.or         s9, s5, s8
    s.movz       s5, #15
    v.insert     v0, s6, #10
    v.extract    s6, v1, #12
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s9, s5
    v.extract    s5, v3, #13
    s.or         s9, s6, s8
    s.movz       s6, #15
    v.insert     v0, s4, #11
    v.extract    s4, v1, #13
    s.shli       s8, s5, #32
    s.cmp.lt     s5, s9, s6
    v.extract    s6, v3, #14
    s.or         s9, s4, s8
    s.movz       s4, #15
    v.insert     v0, s5, #12
    v.extract    s5, v1, #14
    s.shli       s8, s6, #32
    s.cmp.lt     s6, s9, s4
    v.extract    s4, v3, #15
    s.or         s9, s5, s8
    s.movz       s5, #15
    v.insert     v0, s6, #13
    v.extract    s6, v1, #15
    s.shli       s8, s4, #32
    s.cmp.lt     s4, s9, s5
    s.muli       s5, s1, #32                     // a runtime tile origin, x32
    s.or         s9, s6, s8
    s.movz       s6, #15
    s.movz       s8, #0
    v.insert     v0, s4, #14
    s.movz       s4, #32
    s.cmp.lt     s10, s9, s6
    s.add        s6, s8, s2                      // the tile origin
    s.movz       s8, #0
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v2, s4
    v.insert     v0, s10, #15
    v.movi       v3, #0
    s.add        s4, s6, s5                      // the tile origin
    s.add        s5, s8, s2                      // the tile origin
    v.mul        v5, v1, v2
    v.splat      v1, s4
    v.splat      v2, s5
    v.cmp.ne     p1, v0, v3
    v.cmpi.lt    p2, v4, #64
    p.and        p3, p1, p2
    s.rdspecial  s6, arg_base
    v.add        v0, v5, v1
    v.cmpi.lt    p4, v2, #32
    p.and        p5, p3, p4
    s.ld.d       s8, [s6, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s6, role_id
    s.movz       s9, #1024
    s.addi       s10, s4, #1
    s.mul        s11, s6, s9
    s.addi       s6, s5, #1
    v.splat      v1, s10
    v.splat      v2, s6
    p.and        p3, p1, p2
    v.add        v3, v5, v1
    v.cmpi.lt    p4, v2, #32
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v1, [s3, v0]               // index is in elements (ISA sec 9.1)
    s.add        s6, s8, s11                     // this context's own scratch
    p.and        p5, p3, p4
    s.addi       s8, s6, #0
    s.addi       s9, s4, #2
    s.addi       s10, s5, #2
    v.splat      v0, s9
    v.splat      v2, s10
    p.and        p3, p1, p2
    v.add        v4, v5, v0
    v.cmpi.lt    p4, v2, #32
    s.addi       s9, s8, #64
    p.and        p6, p3, p4
    s.addi       s10, s4, #3
    v.st.w       [s8, #0], v1
    s.addi       s11, s5, #3
    v.splat      v0, s10
    v.splat      v1, s11
    p.and        p3, p1, p2
    v.add        v2, v5, v0
    s.addi       s10, s8, #128
    s.addi       s11, s4, #4
    s.addi       s12, s5, #4
    v.splat      v0, s11
    v.splat      v6, s12
    s.addi       s11, s8, #192
    v.add        v7, v5, v0
    s.addi       s12, s4, #5
    s.addi       s13, s5, #5
    v.splat      v0, s12
    v.splat      v8, s13
    s.addi       s12, s8, #256
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v9, [s3, v3]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v1, #32
    p.and        p5, p3, p4
    p.and        p3, p1, p2
    v.add        v1, v5, v0
    s.addi       s13, s4, #6
    s.addi       s14, s8, #320
    v.splat      v0, s13
    s.addi       s13, s8, #384
    v.st.w       [s9, #0], v9
    s.addi       s9, s5, #6
    v.add        v3, v5, v0
    v.splat      v0, s9
    s.addi       s9, s4, #7
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p6 v.ld.gather.h v9, [s3, v4]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v6, #32
    p.and        p6, p3, p4
    p.and        p3, p1, p2
    v.splat      v4, s9
    s.addi       s9, s8, #448
    v.st.w       [s10, #0], v9
    s.addi       s10, s5, #7
    v.add        v6, v5, v4
    v.splat      v4, s10
    s.addi       s10, s4, #8
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v9, [s3, v2]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v8, #32
    p.and        p5, p3, p4
    p.and        p3, p1, p2
    v.splat      v2, s10
    s.addi       s10, s8, #512
    v.st.w       [s11, #0], v9
    s.addi       s11, s5, #8
    v.add        v8, v5, v2
    v.splat      v2, s11
    s.addi       s11, s4, #9
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p6 v.ld.gather.h v9, [s3, v7]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v0, #32
    p.and        p6, p3, p4
    p.and        p3, p1, p2
    v.splat      v0, s11
    s.addi       s11, s8, #576
    v.st.w       [s12, #0], v9
    s.addi       s12, s5, #9
    v.add        v7, v5, v0
    v.splat      v0, s12
    s.addi       s12, s4, #10
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v9, [s3, v1]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v4, #32
    p.and        p5, p3, p4
    p.and        p3, p1, p2
    v.splat      v1, s12
    s.addi       s12, s8, #640
    v.st.w       [s14, #0], v9
    s.addi       s14, s5, #10
    v.add        v4, v5, v1
    v.splat      v1, s14
    s.addi       s14, s4, #11
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p6 v.ld.gather.h v9, [s3, v3]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v2, #32
    p.and        p6, p3, p4
    p.and        p3, p1, p2
    v.splat      v2, s14
    s.addi       s14, s8, #704
    v.st.w       [s13, #0], v9
    s.addi       s13, s5, #11
    v.add        v3, v5, v2
    v.splat      v2, s13
    s.addi       s13, s4, #12
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v9, [s3, v6]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v0, #32
    p.and        p5, p3, p4
    p.and        p3, p1, p2
    v.splat      v0, s13
    s.addi       s13, s8, #768
    v.st.w       [s9, #0], v9
    s.addi       s9, s5, #12
    v.add        v6, v5, v0
    v.splat      v0, s9
    s.addi       s9, s4, #13
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p6 v.ld.gather.h v9, [s3, v8]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v1, #32
    p.and        p6, p3, p4
    p.and        p3, p1, p2
    v.splat      v1, s9
    s.addi       s9, s8, #832
    v.st.w       [s10, #0], v9
    s.addi       s10, s5, #13
    v.add        v8, v5, v1
    v.splat      v1, s10
    s.addi       s10, s4, #14
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v9, [s3, v7]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v2, #32
    p.and        p5, p3, p4
    p.and        p3, p1, p2
    v.splat      v2, s10
    s.addi       s10, s8, #896
    v.st.w       [s11, #0], v9
    s.addi       s11, s5, #14
    v.add        v7, v5, v2
    v.splat      v2, s11
    s.addi       s11, s4, #15
    s.addi       s4, s8, #960
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p6 v.ld.gather.h v9, [s3, v4]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v0, #32
    p.and        p6, p3, p4
    p.and        p3, p1, p2
    v.splat      v0, s11
    v.st.w       [s12, #0], v9
    s.addi       s8, s5, #15
    v.add        v4, v5, v0
    v.splat      v0, s8
    .li       s8, #1065353216
    v.splat      v5, s8                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v9, [s3, v3]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v1, #32
    p.and        p5, p3, p4
    p.and        p3, p1, p2
    .li       s8, #1065353216
    v.splat      v1, s8                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s14, #0], v9
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s8, s6, #0
    v.movi       v3, #0
    s.muli       s11, s1, #4                     // a runtime tile origin, x4
    s.muli       s1, s2, #256                    // a runtime tile origin, x256
    v.movi       v9, #0
    s.add        s2, s7, s11                     // the tile origin
    s.add        s7, s2, s1                      // the tile origin
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p6 v.ld.gather.h v10, [s3, v6]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v2, #32
    p.and        p6, p3, p4
    p.and        p3, p1, p2
    .li       s1, #1069066811
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s13, #0], v10
    .li       s1, #1060205080
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.h v10, [s3, v8]              // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p4, v0, #32
    p.and        p5, p3, p4
    .li       s1, #1065353216
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.st.w       [s9, #0], v10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p6 v.ld.gather.h v8, [s3, v7]               // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v8
    v.splat      v7, s5
    s.addi       s1, s6, #64
    v.cmpi.lt    p3, v7, #32
    p.and        p4, p2, p3
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v7, [s3, v4]               // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v7
    fence.acq_rel.device
    v.ld.w       v4, [s8, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s2, s5, #1
    s.addi       s3, s7, #256                    // row 1
    vf.add       v7, v4, v5
    v.splat      v4, s2
    v.rcp.approx v8, v7                          // ISA 8.8: <= 2**-22 relative
    v.cmpi.lt    p3, v4, #32
    p.and        p5, p2, p3
    vf.fms       v4, v7, v8, v0
    vf.fms       v10, v8, v4, v8
    s.addi       s2, s6, #128
    vf.neg       v4, v10                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v4, v4
    @p3 v.sel        v10, v4, v8
    vf.mul       v4, v1, v10                     // a/y: faithful quotient
    vf.fms       v8, v4, v7, v1
    vf.fms       v7, v8, v10, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p4 v.st.w       [s7, #0], v7
    v.ld.w       v4, [s1, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s1, s7, #512                    // row 2
    vf.add       v7, v4, v5
    s.addi       s4, s5, #2
    v.rcp.approx v4, v7                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s4
    vf.fms       v10, v7, v4, v0
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p4, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s4, s6, #192
    vf.mul       v4, v1, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v7, v1
    vf.fms       v7, v10, v8, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p5 v.st.w       [s3, #0], v7
    v.ld.w       v4, [s2, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s2, s7, #768                    // row 3
    vf.add       v7, v4, v5
    s.addi       s3, s5, #3
    v.rcp.approx v4, v7                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s3
    vf.fms       v10, v7, v4, v0
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p5, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s3, s6, #256
    vf.mul       v4, v1, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v7, v1
    vf.fms       v7, v10, v8, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p4 v.st.w       [s1, #0], v7
    v.ld.w       v4, [s4, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s1, s7, #1024                   // row 4
    vf.add       v7, v4, v5
    s.addi       s4, s5, #4
    v.rcp.approx v4, v7                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s4
    vf.fms       v10, v7, v4, v0
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p4, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s4, s6, #320
    vf.mul       v4, v1, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v7, v1
    vf.fms       v7, v10, v8, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p5 v.st.w       [s2, #0], v7
    v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s2, s7, #1280                   // row 5
    vf.add       v7, v4, v5
    s.addi       s3, s5, #5
    v.rcp.approx v4, v7                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s3
    vf.fms       v10, v7, v4, v0
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p5, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s3, s6, #384
    vf.mul       v4, v1, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v7, v1
    vf.fms       v7, v10, v8, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p4 v.st.w       [s1, #0], v7
    v.ld.w       v4, [s4, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s1, s7, #1536                   // row 6
    vf.add       v7, v4, v5
    s.addi       s4, s5, #6
    v.rcp.approx v4, v7                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s4
    vf.fms       v10, v7, v4, v0
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p4, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s4, s6, #448
    vf.mul       v4, v1, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v7, v1
    vf.fms       v7, v10, v8, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p5 v.st.w       [s2, #0], v7
    v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s2, s7, #1792                   // row 7
    vf.add       v7, v4, v5
    s.addi       s3, s5, #7
    v.rcp.approx v4, v7                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s3
    vf.fms       v10, v7, v4, v0
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p5, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s3, s6, #512
    vf.mul       v4, v1, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v7, v1
    vf.fms       v7, v10, v8, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p4 v.st.w       [s1, #0], v7
    v.ld.w       v4, [s4, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s1, s7, #2048                   // row 8
    vf.add       v7, v4, v5
    s.addi       s4, s5, #8
    v.rcp.approx v4, v7                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s4
    vf.fms       v10, v7, v4, v0
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p4, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s4, s6, #576
    vf.mul       v4, v1, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v7, v1
    vf.fms       v7, v10, v8, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p5 v.st.w       [s2, #0], v7
    v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s2, s7, #2304                   // row 9
    vf.add       v7, v4, v5
    s.addi       s3, s5, #9
    v.rcp.approx v4, v7                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s3
    vf.fms       v10, v7, v4, v0
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p5, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s3, s6, #640
    vf.mul       v4, v1, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v7, v1
    vf.fms       v7, v10, v8, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p4 v.st.w       [s1, #0], v7
    v.ld.w       v4, [s4, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s1, s7, #2560                   // row 10
    vf.add       v7, v4, v5
    s.addi       s4, s5, #10
    v.rcp.approx v4, v7                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s4
    vf.fms       v10, v7, v4, v0
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p4, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s4, s6, #704
    vf.mul       v4, v1, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v7, v1
    vf.fms       v7, v10, v8, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p5 v.st.w       [s2, #0], v7
    v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s2, s7, #2816                   // row 11
    vf.add       v7, v4, v5
    s.addi       s3, s5, #11
    v.rcp.approx v4, v7                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s3
    vf.fms       v10, v7, v4, v0
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p5, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s3, s6, #768
    vf.mul       v4, v1, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v7, v1
    vf.fms       v7, v10, v8, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p4 v.st.w       [s1, #0], v7
    v.ld.w       v4, [s4, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s1, s7, #3072                   // row 12
    vf.add       v7, v4, v5
    s.addi       s4, s5, #12
    v.rcp.approx v4, v7                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s4
    vf.fms       v10, v7, v4, v0
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p4, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s4, s6, #832
    vf.mul       v4, v1, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v7, v1
    vf.fms       v7, v10, v8, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p5 v.st.w       [s2, #0], v7
    v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s2, s7, #3328                   // row 13
    vf.add       v7, v4, v5
    s.addi       s3, s5, #13
    v.rcp.approx v4, v7                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s3
    vf.fms       v10, v7, v4, v0
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p5, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s3, s6, #896
    vf.mul       v4, v1, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v7, v1
    vf.fms       v7, v10, v8, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p4 v.st.w       [s1, #0], v7
    v.ld.w       v4, [s4, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s1, s7, #3584                   // row 14
    vf.add       v7, v4, v5
    s.addi       s4, s5, #14
    v.rcp.approx v4, v7                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s4
    vf.fms       v10, v7, v4, v0
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p4, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v10, v10
    @p3 v.sel        v8, v10, v4
    s.addi       s4, s6, #960
    vf.mul       v4, v1, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v7, v1
    vf.fms       v7, v10, v8, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p5 v.st.w       [s2, #0], v7
    v.ld.w       v4, [s3, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v4, v10, v6
    vf.fma       v7, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v4, v7, v8
    s.addi       s2, s7, #3840                   // row 15
    vf.add       v7, v4, v5
    s.addi       s3, s5, #15
    v.rcp.approx v4, v7                          // ISA 8.8: <= 2**-22 relative
    v.splat      v8, s3
    vf.fms       v10, v7, v4, v0
    v.cmpi.lt    p3, v8, #32
    vf.fms       v8, v4, v10, v4
    p.and        p5, p2, p3
    vf.neg       v10, v8                         // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v8, v10, v4
    vf.mul       v4, v1, v8                      // a/y: faithful quotient
    vf.fms       v10, v4, v7, v1
    vf.fms       v7, v10, v8, v4
    vf.neg       v8, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v7, v8, v4
    @p1 v.sel        v4, v7, v3
    @p1 v.sel        v7, v4, v9
    @p4 v.st.w       [s1, #0], v7
    v.ld.w       v4, [s4, #0]
    vf.cvt.bf16.f32 v7, v4
    vf.neg       v4, v7
    vf.mul       v7, v4, v2
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v4, v2, v7                 // the exact rounding error of x*log2(e)
    vf.mul       v2, v10, v6
    vf.fma       v4, v8, v2, v8                  // 2**t * 2**d
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v2, v4, v8
    vf.add       v4, v2, v5
    v.rcp.approx v2, v4                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v4, v2, v0
    vf.fms       v0, v2, v5, v2
    vf.neg       v5, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v5, v5
    @p2 v.sel        v0, v5, v2
    vf.mul       v2, v1, v0                      // a/y: faithful quotient
    vf.fms       v5, v2, v4, v1
    vf.fms       v1, v5, v0, v2
    vf.neg       v0, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v0, v0
    @p2 v.sel        v1, v0, v2
    @p1 v.sel        v0, v1, v3
    @p1 v.sel        v1, v0, v9
    @p5 v.st.w       [s2, #0], v1
__rctx_next:
    exit
