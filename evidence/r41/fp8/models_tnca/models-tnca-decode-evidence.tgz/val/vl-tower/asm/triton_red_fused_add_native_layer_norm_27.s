    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s9, [s1, #48]                   // in_ptr6: device_ptr64 at arg_base+48
    s.ld.d       s10, [s1, #56]                  // out_ptr0: device_ptr64 at arg_base+56
    s.ld.d       s11, [s1, #64]                  // out_ptr2: device_ptr64 at arg_base+64
    s.rdspecial  s1, arg_base
    s.ld.d       s12, [s1, #88]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s13, #1536
    s.mul        s14, s1, s13
    s.add        s1, s12, s14                    // this context's own scratch
    s.addi       s12, s1, #0                     // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s13, #0
    s.st.d       [s12, #0], s2
    s.movz       s13, #256
    s.st.d       [s12, #8], s13
    s.movz       s13, #1024
    s.st.d       [s12, #16], s13
    s.movz       s13, #2048
    s.st.d       [s12, #48], s13
    s.movz       s13, #2
    s.st.d       [s12, #56], s13
    .li       s13, #68719476737
    s.st.d       [s12, #88], s13
    .li       s13, #1108101562368
    s.st.d       [s12, #104], s13
    fence.release.device
    td.load      d0, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s12, s1, #256                   // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s13, #0
    s.st.d       [s12, #0], s3
    s.movz       s13, #256
    s.st.d       [s12, #8], s13
    s.movz       s13, #1024
    s.st.d       [s12, #16], s13
    s.movz       s13, #2048
    s.st.d       [s12, #48], s13
    s.movz       s13, #2
    s.st.d       [s12, #56], s13
    .li       s13, #68719476737
    s.st.d       [s12, #88], s13
    .li       s13, #1108101562368
    s.st.d       [s12, #104], s13
    fence.release.device
    td.load      d1, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s12, s1, #512                   // TensorMap 2: tl.make_tensor_descriptor (rank 2)
    s.movz       s13, #0
    s.st.d       [s12, #0], s5
    s.movz       s13, #256
    s.st.d       [s12, #8], s13
    s.movz       s13, #1024
    s.st.d       [s12, #16], s13
    s.movz       s13, #2048
    s.st.d       [s12, #48], s13
    s.movz       s13, #2
    s.st.d       [s12, #56], s13
    .li       s13, #68719476737
    s.st.d       [s12, #88], s13
    .li       s13, #1108101562368
    s.st.d       [s12, #104], s13
    fence.release.device
    td.load      d2, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s12, s1, #768                   // TensorMap 3: tl.make_tensor_descriptor (rank 2)
    s.movz       s13, #0
    s.st.d       [s12, #0], s6
    s.movz       s13, #256
    s.st.d       [s12, #8], s13
    s.movz       s13, #1024
    s.st.d       [s12, #16], s13
    s.movz       s13, #2048
    s.st.d       [s12, #48], s13
    s.movz       s13, #2
    s.st.d       [s12, #56], s13
    .li       s13, #68719476737
    s.st.d       [s12, #88], s13
    .li       s13, #1108101562368
    s.st.d       [s12, #104], s13
    fence.release.device
    td.load      d3, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s12, s1, #1024                  // TensorMap 4: tl.make_tensor_descriptor (rank 2)
    s.movz       s13, #0
    s.st.d       [s12, #0], s7
    s.movz       s13, #256
    s.st.d       [s12, #8], s13
    s.movz       s13, #1024
    s.st.d       [s12, #16], s13
    s.movz       s13, #2048
    s.st.d       [s12, #48], s13
    s.movz       s13, #2
    s.st.d       [s12, #56], s13
    .li       s13, #68719476737
    s.st.d       [s12, #88], s13
    .li       s13, #1108101562368
    s.st.d       [s12, #104], s13
    fence.release.device
    td.load      d4, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s12, #0
    s.movz       s13, #1024
    s.movz       s14, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s15, s12, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s16, s15, s13
    br.nz        s16, endfor_2
    s.muli       s16, s4, #2048
    v.splat      v3, s15
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s17, #1024
    s.movz       s18, #256
    s.muli       s19, s4, #2048
    v.splat      v5, s15
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s20, #1024
    v.add        v7, v3, v4
    v.movi       v3, #0
    v.splat      v4, s17
    s.movz       s17, #256
    v.splat      v8, s4
    v.movi       v9, #0
    v.splat      v10, s18
    s.muli       s18, s15, #2
    v.add        v11, v5, v6
    v.movi       v5, #0
    v.splat      v6, s20
    s.muli       s20, s15, #2
    v.splat      v12, s4
    v.movi       v13, #0
    v.cmp.ge     p1, v7, v3
    v.splat      v3, s17
    v.cmp.lt     p2, v7, v4
    v.cmp.ge     p3, v8, v9
    v.cmp.lt     p4, v8, v10
    v.cmp.ge     p5, v11, v5
    s.add        s17, s2, s16
    p.and        p6, p1, p2
    v.cmp.lt     p1, v11, v6
    p.and        p2, p3, p4
    v.cmp.ge     p3, v12, v13
    s.add        s16, s3, s19
    p.and        p4, p5, p1
    v.cmp.lt     p1, v12, v3
    p.and        p5, p3, p1
    s.add        s19, s17, s18
    p.and        p1, p6, p2
    s.add        s17, s16, s20
    p.and        p2, p4, p5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s19, #0]
    v.splat      v4, s15
    v.movi       v5, #1024
    v.add        v6, v4, v0
    s.muli       s16, s4, #2048
    v.cmp.lt     p1, v6, v5
    v.splat      v4, s15
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s18, #1024
    s.movz       s19, #256
    s.muli       s20, s15, #2
    v.add        v7, v4, v5
    v.movi       v4, #0
    v.splat      v5, s18
    v.splat      v8, s4
    v.movi       v9, #0
    v.splat      v10, s19
    v.cmp.ge     p3, v7, v4
    v.cmp.lt     p4, v7, v5
    v.cmp.ge     p5, v8, v9
    s.muli       s18, s4, #2048
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s17, #0]
    v.cmp.lt     p2, v8, v10
    s.add        s17, s5, s16
    p.and        p6, p3, p4
    p.and        p3, p5, p2
    s.add        s16, s17, s20
    p.and        p2, p6, p3
    vf.cvt.bf16.f32 v5, v3
    v.splat      v3, s15
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s17, #1024
    s.movz       s19, #256
    s.muli       s20, s15, #2
    v.add        v8, v3, v7
    v.movi       v3, #0
    v.splat      v7, s17
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s19
    v.cmp.ge     p3, v8, v3
    v.cmp.lt     p4, v8, v7
    v.cmp.ge     p5, v9, v10
    s.muli       s17, s4, #2048
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v3, [s16, #0]
    v.cmp.lt     p2, v9, v11
    s.add        s16, s6, s18
    p.and        p6, p3, p4
    p.and        p3, p5, p2
    vf.cvt.bf16.f32 v7, v4
    v.splat      v4, s15
    v.iota       v8                              // arange(0, VLEN)
    s.movz       s18, #1024
    s.movz       s19, #256
    s.muli       s21, s15, #2
    v.add        v9, v4, v8
    v.movi       v4, #0
    v.splat      v8, s18
    v.splat      v10, s4
    v.movi       v11, #0
    v.splat      v12, s19
    s.add        s18, s16, s20
    p.and        p2, p6, p3
    v.cmp.ge     p3, v9, v4
    v.cmp.lt     p4, v9, v8
    v.cmp.ge     p5, v10, v11
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s18, #0]
    v.cmp.lt     p2, v10, v12
    s.add        s16, s7, s17
    p.and        p6, p3, p4
    p.and        p3, p5, p2
    vf.cvt.bf16.f32 v8, v3
    s.add        s17, s16, s21
    p.and        p2, p6, p3
    vf.add       v3, v5, v7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v5, [s17, #0]
    vf.cvt.bf16.f32 v7, v4
    s.mul        s16, s4, s13
    vf.add       v4, v3, v8
    v.movi       v3, #0
    s.add        s17, s15, s14
    vf.cvt.bf16.f32 v8, v5
    vf.add       v5, v4, v7
    s.add        s18, s15, s16
    v.splat      v4, s16
    s.shli       s16, s18, #2                    // element offset -> bytes (x4)
    vf.add       v7, v5, v8
    s.add        s18, s10, s16                   // &out_ptr0[...]
    s.movz       s16, #1
    v.add        v5, v6, v4
    vf.add       v4, v2, v7
    @p1 v.st.w       [s18, #0], v7
    @p1 v.sel        v5, v4, v2
    v.mov        v3, v5
    v.mov        v2, v3
    s.mov        s15, s17
    br.nz        s16, for_1
endfor_2:
    .li       s2, #1149239296
    v.splat      v3, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v3                          // ISA 8.8: <= 2**-22 relative
    vf.reduce.add.b v6, v2
    v.movi       v2, #0
    s.addi       s2, s1, #1280                   // TensorMap 5: tl.make_tensor_descriptor (rank 2)
    vf.add       v7, v6, v2
    s.movz       s1, #256
    s.movz       s3, #1024
    s.movz       s5, #4096
    s.movz       s6, #4
    .li       s7, #68719476737
    v.movi       v6, #0
    s.movz       s15, #0
    s.st.d       [s2, #0], s10
    s.st.d       [s2, #8], s1
    .li       s1, #2207613190144
    s.st.d       [s2, #16], s3
    s.addi       s3, s12, #0
    s.st.d       [s2, #48], s5
    s.st.d       [s2, #56], s6
    vf.fms       v8, v3, v5, v4
    s.st.d       [s2, #88], s7
    vf.fms       v9, v5, v8, v5
    s.st.d       [s2, #104], s1
    fence.release.device
    td.load      d5, [s2]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    v.mov        v6, v1
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v1, v8, v5
    vf.mul       v5, v7, v1                      // a/y: faithful quotient
    vf.fms       v8, v5, v3, v7
    vf.fms       v7, v8, v1, v5
    vf.neg       v1, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v7, v1, v5
for_3:
    s.cmp.ge     s1, s3, s13
    br.nz        s1, endfor_4
    s.muli       s1, s4, #4096
    v.splat      v1, s3
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s2, #1024
    s.movz       s5, #256
    s.muli       s6, s3, #4
    v.add        v8, v1, v5
    v.movi       v1, #0
    v.splat      v5, s2
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s5
    v.cmp.ge     p1, v8, v1
    v.cmp.lt     p2, v8, v5
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    s.add        s2, s10, s1
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s1, s2, s6
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s1, #0]
    v.extract    s1, v7, #0
    v.splat      v5, s1
    v.splat      v8, s3
    v.movi       v9, #1024
    v.add        v10, v8, v0
    v.movi       v8, #0
    v.cmp.lt     p1, v10, v9
    s.add        s1, s3, s14
    s.movz       s2, #1
    vf.sub       v9, v1, v5
    vf.mul       v1, v9, v9
    vf.add       v5, v6, v1
    @p1 v.sel        v1, v5, v6
    v.mov        v8, v1
    v.mov        v6, v8
    s.mov        s3, s1
    br.nz        s2, for_3
endfor_4:
    vf.reduce.add.b v1, v6
    s.addi       s1, s12, #0
    vf.add       v5, v1, v2
for_5:
    s.cmp.ge     s2, s1, s13
    br.nz        s2, endfor_6
    v.rcp.approx v1, v3                          // ISA 8.8: <= 2**-22 relative
    s.muli       s2, s4, #4096
    v.splat      v2, s1
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s3, #1024
    s.movz       s5, #256
    s.muli       s6, s1, #4
    v.add        v8, v2, v6
    v.movi       v2, #0
    v.splat      v6, s3
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s5
    v.cmp.ge     p1, v8, v2
    v.cmp.lt     p2, v8, v6
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    s.add        s3, s10, s2
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s2, s3, s6
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v2, [s2, #0]
    v.splat      v6, s1
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    v.add        v8, v6, v0
    vf.fms       v6, v3, v1, v4
    .li       s3, #897988541
    v.splat      v9, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v10, #1024
    s.add        s3, s8, s2                      // &in_ptr5[...]
    vf.fms       v11, v1, v6, v1
    v.cmp.lt     p1, v8, v10
    .li       s5, #1077936128
    v.splat      v6, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s5, #3204448256
    v.splat      v10, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.neg       v12, v11                        // Newton step: r0*(2 - x*r0)
    v.extract    s5, v7, #0
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v11, [s3, #0]
    v.splat      v13, s5
    vf.cmp.o     p2, v12, v12
    @p2 v.sel        v14, v12, v1
    s.add        s3, s9, s2                      // &in_ptr6[...]
    vf.mul       v1, v5, v14                     // a/y: faithful quotient
    vf.sub       v12, v2, v13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s3, #0]
    vf.cvt.bf16.f32 v13, v11
    vf.fms       v11, v1, v3, v5
    s.mul        s2, s4, s13
    s.add        s3, s1, s14
    s.movz       s5, #1
    vf.fms       v15, v11, v14, v1
    vf.cvt.bf16.f32 v11, v2
    s.add        s6, s1, s2
    v.splat      v2, s2
    vf.neg       v14, v15                        // a/y: one correction to the IEEE quotient
    s.shli       s2, s6, #1                      // element offset -> bytes (x2)
    v.add        v15, v8, v2
    s.add        s6, s11, s2                     // &out_ptr2[...]
    vf.cmp.o     p2, v14, v14
    @p2 v.sel        v2, v14, v1
    vf.add       v1, v2, v9
    v.rsqrt.approx v2, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.mul       v9, v2, v10
    vf.fms       v10, v1, v8, v6
    vf.mul       v1, v9, v10                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v6, v1, v2
    v.extract    s2, v6, #0
    v.splat      v1, s2
    vf.mul       v2, v12, v1
    vf.mul       v1, v2, v13
    vf.add       v2, v1, v11
    vf.cvt.f32.bf16 v1, v2
    @p1 v.st.h       [s6, #0], v1
    s.mov        s1, s3
    br.nz        s5, for_5
endfor_6:
__rctx_next:
    exit
