    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #0
    v.movi       v2, #0
    v.movi       v3, #5
    v.movi       v4, #31
    v.splat      v5, s2
    v.movi       v6, #32
    v.movi       v7, #5
    v.add        v8, v5, v0
    v.movi       v0, #0
    v.movi       v5, #10240
    v.sub        v9, v1, v8
    v.cmp.lt     p1, v8, v1
    v.sub        v10, v2, v8
    @p1 v.sel        v11, v9, v8
    v.cmp.lt     p2, v8, v2
    @p2 v.sel        v9, v10, v8
    v.lshr       v10, v11, v3
    v.sub        v3, v2, v6
    v.and        v11, v9, v4
    v.sub        v4, v1, v10
    v.sub        v9, v1, v6
    v.sub        v12, v2, v11
    @p1 v.sel        v13, v4, v10
    v.sub        v4, v0, v7
    s.rdspecial  s1, arg_base
    v.cmp.lt     p1, v6, v2
    v.sub        v2, v0, v13
    v.cmp.lt     p3, v6, v1
    v.cmp.lt     p4, v13, v0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #1
    @p1 v.sel        v1, v3, v6
    v.cmp.lt     p1, v7, v0
    @p2 v.sel        v1, v12, v11
    v.cmp.lt     p2, v8, v5
    v.movi       v3, #1
    @p3 v.sel        v3, v9, v6
    v.movi       v3, #1
    @p4 v.sel        v5, v2, v13
    @p1 v.sel        v2, v4, v7
    s.ld.d       s4, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v4, #0
    v.movi       v7, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v9, s1
    v.shl        v10, v7, v3
    v.cmp.lt     p1, v7, v0
    v.lshr       v11, v5, v9
    v.shl        v12, v3, v9
    s.subi       s5, s1, #1
    v.and        v9, v11, v3
    s.movz       s6, #0
    v.or         v11, v10, v9
    v.cmp.geu    p3, v11, v2
    p.or         p5, p1, p3
    v.sub        v9, v11, v2
    @p5 v.sel        v10, v12, v0
    @p5 v.sel        v12, v9, v11
    v.or         v9, v4, v10
    v.mov        v7, v12
    v.mov        v4, v9
    s.mov        s1, s5
    s.cmp.ge     s5, s1, s6
    br.nz        s5, idiv_1
    v.movi       v2, #160
    v.movi       v3, #0
    v.sub        v4, v0, v7
    v.movi       v0, #1
    v.sub        v5, v3, v8
    v.sub        v9, v3, v2
    v.cmp.lt     p1, v8, v3
    v.cmp.lt     p3, v2, v3
    @p4 v.sel        v10, v4, v7
    @p1 v.sel        v4, v5, v8
    @p3 v.sel        v5, v9, v2
    v.movi       v2, #0
    v.movi       v7, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v8, s1
    v.shl        v9, v7, v0
    v.cmp.lt     p4, v7, v3
    v.lshr       v11, v4, v8
    v.shl        v12, v0, v8
    s.subi       s5, s1, #1
    v.and        v8, v11, v0
    s.movz       s6, #0
    v.or         v11, v9, v8
    v.cmp.geu    p5, v11, v5
    p.or         p6, p4, p5
    v.sub        v8, v11, v5
    @p6 v.sel        v9, v12, v3
    @p6 v.sel        v12, v8, v11
    v.or         v8, v2, v9
    v.mov        v7, v12
    v.mov        v2, v8
    s.mov        s1, s5
    s.cmp.ge     s5, s1, s6
    br.nz        s5, idiv_2
    v.sub        v0, v3, v2
    p.xor        p4, p1, p3
    v.movi       v3, #2048
    @p4 v.sel        v4, v0, v2
    s.shli       s1, s2, #1                      // element offset -> bytes (x2)
    v.mul        v0, v10, v3
    v.mul        v2, v4, v6
    s.add        s2, s4, s1                      // &out_ptr0[...]
    s.movz       s1, #32
    v.add        v3, v1, v2
    s.movz       s1, #2048
    v.add        v1, v3, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v0, [s3, v1]               // index is in elements (ISA sec 9.1)
    vf.cvt.f32.f16 v1, v0
    @p2 v.st.h       [s2, #0], v1
__rctx_next:
    exit
