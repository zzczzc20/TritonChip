source ~/tc_env/env.sh
cd /home/zhongchun/r40_local_rank_preflight_20261017
export OMP_NUM_THREADS=2 MAX_JOBS=2
~/tc_env/torchenv/bin/python run_preflight.py > preflight.log 2>&1
echo $? > preflight.exit
