    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    .li       s5, #1054295293
    v.splat      v0, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s5, s3, s4                      // &in_ptr0[...]
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.shli       s1, s2, #2                      // element offset -> bytes (x4)
    v.iota       v1                              // arange(0, VLEN)
    v.ld.h       v2, [s5, #0]
    v.splat      v3, s2
    s.add        s2, s3, s1                      // &out_ptr0[...]
    v.add        v4, v3, v1
    vf.cvt.f16.f32 v1, v2
    vf.mul       v2, v1, v0
    v.st.w       [s2, #0], v2
__rctx_next:
    exit
