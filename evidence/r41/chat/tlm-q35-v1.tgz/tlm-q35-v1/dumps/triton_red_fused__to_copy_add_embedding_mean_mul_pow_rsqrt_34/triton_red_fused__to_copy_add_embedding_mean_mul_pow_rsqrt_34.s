    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s9, [s1, #48]                   // out_ptr0: device_ptr64 at arg_base+48
    s.ld.d       s10, [s1, #56]                  // out_ptr2: device_ptr64 at arg_base+56
    s.ld.d       s11, [s1, #64]                  // out_ptr3: device_ptr64 at arg_base+64
    s.movz       s1, #1
    s.rdspecial  s12, arg_base
    s.ld.d       s13, [s12, #88]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s12, role_id
    s.movz       s14, #1024
    s.mul        s15, s12, s14
    s.add        s12, s13, s15                   // this context's own scratch
    s.addi       s13, s12, #0                    // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s14, #0
    s.st.d       [s13, #0], s5
    s.movz       s14, #15
    s.st.d       [s13, #8], s14
    s.movz       s14, #2560
    s.st.d       [s13, #16], s14
    s.movz       s14, #5120
    s.st.d       [s13, #48], s14
    s.movz       s14, #2
    s.st.d       [s13, #56], s14
    .li       s14, #68719476737
    s.st.d       [s13, #88], s14
    .li       s14, #1108101562368
    s.st.d       [s13, #104], s14
    fence.release.device
    td.load      d0, [s13]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s13, s12, #256                  // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s14, #0
    s.st.d       [s13, #0], s6
    s.movz       s14, #15
    s.st.d       [s13, #8], s14
    s.movz       s14, #2560
    s.st.d       [s13, #16], s14
    s.movz       s14, #5120
    s.st.d       [s13, #48], s14
    s.movz       s14, #2
    s.st.d       [s13, #56], s14
    .li       s14, #68719476737
    s.st.d       [s13, #88], s14
    .li       s14, #1108101562368
    s.st.d       [s13, #104], s14
    fence.release.device
    td.load      d1, [s13]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s13, s12, #512                  // TensorMap 2: tl.make_tensor_descriptor (rank 2)
    s.movz       s14, #0
    s.st.d       [s13, #0], s7
    s.movz       s14, #15
    s.st.d       [s13, #8], s14
    s.movz       s14, #2560
    s.st.d       [s13, #16], s14
    s.movz       s14, #5120
    s.st.d       [s13, #48], s14
    s.movz       s14, #2
    s.st.d       [s13, #56], s14
    .li       s14, #68719476737
    s.st.d       [s13, #88], s14
    .li       s14, #1108101562368
    s.st.d       [s13, #104], s14
    fence.release.device
    td.load      d2, [s13]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s13, #0
    s.movz       s14, #2560
    s.movz       s15, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.shli       s16, s4, #3                     // element offset -> bytes (x8)
    s.add        s17, s2, s16                    // &in_ptr0[...]
    v.movi       v1, #0
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s1
    v.cmp.lt     p1, v2, v3
    v.movi       v2, #1
    v.shl        v3, v1, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s17, v3]              // index is in elements (ISA sec 9.1)
    s.addi       s1, s17, #4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v2, [s1, v3]               // index is in elements (ISA sec 9.1)
    s.addi       s1, s13, #0
    v.movi       v3, #0
    v.movi       v4, #0
    v.mov        v4, v3
for_1:
    s.cmp.ge     s2, s1, s14
    br.nz        s2, endfor_2
    v.splat      v3, s1
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s1
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s2, #2560
    s.movz       s16, #15
    s.movz       s17, #2560
    s.movz       s18, #15
    s.muli       s19, s4, #5120
    s.muli       s20, s4, #5120
    v.add        v8, v3, v5
    v.movi       v3, #0
    v.splat      v5, s2
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s16
    v.add        v12, v6, v7
    v.movi       v6, #0
    v.splat      v7, s17
    v.splat      v13, s4
    v.movi       v14, #0
    s.muli       s2, s1, #2
    s.muli       s16, s1, #2
    v.cmp.ge     p1, v8, v3
    v.splat      v3, s18
    v.cmp.lt     p2, v8, v5
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    v.cmp.ge     p5, v12, v6
    s.add        s17, s5, s19
    p.and        p6, p1, p2
    v.cmp.lt     p1, v12, v7
    p.and        p2, p3, p4
    v.cmp.ge     p3, v13, v14
    s.add        s18, s6, s20
    p.and        p4, p5, p1
    v.cmp.lt     p1, v13, v3
    p.and        p5, p3, p1
    s.add        s19, s17, s2
    p.and        p1, p6, p2
    s.add        s2, s18, s16
    p.and        p2, p4, p5
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s19, #0]
    v.splat      v5, s1
    v.movi       v6, #2560
    v.add        v7, v5, v0
    s.muli       s16, s4, #5120
    v.cmp.lt     p1, v7, v6
    v.splat      v5, s1
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s17, #2560
    s.movz       s18, #15
    v.add        v8, v5, v6
    v.movi       v5, #0
    v.splat      v6, s17
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s18
    s.muli       s17, s1, #2
    v.cmp.ge     p3, v8, v5
    v.cmp.lt     p4, v8, v6
    v.cmp.ge     p5, v9, v10
    s.add        s18, s7, s16
    p.and        p6, p3, p4
    v.cmp.lt     p3, v9, v11
    p.and        p4, p5, p3
    s.add        s16, s18, s17
    p.and        p3, p6, p4
    v.movi       v5, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v6, [s2, #0]
    vf.cvt.bf16.f32 v8, v3
    v.extract    s2, v2, #0
    v.extract    s17, v2, #0
    v.extract    s18, v1, #0
    s.shli       s19, s2, #32
    v.extract    s2, v1, #0
    s.shli       s20, s17, #32
    s.or         s17, s18, s19
    s.movz       s18, #0
    s.or         s19, s2, s20
    .li       s2, #248320
    v.movi       v3, #0
    s.cmp.ge     s20, s17, s18
    s.cmp.lt     s17, s19, s2
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s16, #0]
    v.insert     v5, s20, #0
    v.movi       v10, #0
    v.insert     v3, s17, #0
    v.movi       v11, #0
    v.cmp.ne     p2, v5, v10
    v.movi       v5, #0
    v.cmp.ne     p3, v3, v11
    v.movi       v3, #1
    p.and        p4, p2, p3
    vf.cvt.bf16.f32 v10, v6
    s.movz       s2, #1
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v11, s2
    @p4 v.sel        v12, v5, v3
    s.movz       s2, #0
    v.cmp.lt     p2, v6, v11
    @p2 v.reduce.or  s16, v12
    vf.cvt.bf16.f32 v3, v9
    s.cmp.eq     s17, s16, s2
    br.nz        s17, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s2, v2, #0
    v.extract    s16, v1, #0
    s.shli       s17, s2, #32
    s.movz       s2, #2560
    s.or         s18, s16, s17
    v.extract    s16, v7, #0
    s.mul        s17, s18, s2
    s.shli       s2, s16, #32
    v.extract    s16, v7, #1
    s.ashri      s18, s2, #32
    v.movi       v5, #0
    v.movi       v6, #0
    v.movi       v9, #0
    v.movi       v11, #0
    s.shli       s2, s16, #32
    s.lshri      s16, s17, #32
    s.lshri      s19, s18, #32
    v.extract    s20, v7, #2
    s.ashri      s21, s2, #32
    v.insert     v5, s17, #0
    v.insert     v6, s16, #0
    v.insert     v9, s18, #0
    v.insert     v11, s19, #0
    s.shli       s2, s20, #32
    s.lshri      s16, s21, #32
    v.extract    s17, v7, #3
    s.ashri      s18, s2, #32
    v.insert     v9, s21, #1
    v.insert     v11, s16, #1
    s.shli       s2, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v7, #4
    s.ashri      s19, s2, #32
    v.insert     v9, s18, #2
    v.insert     v11, s16, #2
    s.shli       s2, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v7, #5
    s.ashri      s18, s2, #32
    v.insert     v9, s19, #3
    v.insert     v11, s16, #3
    s.shli       s2, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v7, #6
    s.ashri      s19, s2, #32
    v.insert     v9, s18, #4
    v.insert     v11, s16, #4
    s.shli       s2, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v7, #7
    s.ashri      s18, s2, #32
    v.insert     v9, s19, #5
    v.insert     v11, s16, #5
    s.shli       s2, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v7, #8
    s.ashri      s19, s2, #32
    v.insert     v9, s18, #6
    v.insert     v11, s16, #6
    s.shli       s2, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v7, #9
    s.ashri      s18, s2, #32
    v.insert     v9, s19, #7
    v.insert     v11, s16, #7
    s.shli       s2, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v7, #10
    s.ashri      s19, s2, #32
    v.insert     v9, s18, #8
    v.insert     v11, s16, #8
    s.shli       s2, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v7, #11
    s.ashri      s18, s2, #32
    v.insert     v9, s19, #9
    v.insert     v11, s16, #9
    s.shli       s2, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v7, #12
    s.ashri      s19, s2, #32
    v.insert     v9, s18, #10
    v.insert     v11, s16, #10
    s.shli       s2, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v7, #13
    s.ashri      s18, s2, #32
    v.insert     v9, s19, #11
    v.insert     v11, s16, #11
    s.shli       s2, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v7, #14
    s.ashri      s19, s2, #32
    v.insert     v9, s18, #12
    v.insert     v11, s16, #12
    s.shli       s2, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v7, #15
    v.extract    s18, v6, #0
    s.ashri      s20, s2, #32
    v.insert     v9, s19, #13
    v.insert     v11, s16, #13
    s.shli       s2, s17, #32
    v.extract    s16, v5, #0
    s.shli       s17, s18, #32
    s.lshri      s18, s20, #32
    v.extract    s19, v6, #0
    s.ashri      s21, s2, #32
    s.or         s2, s16, s17
    v.insert     v9, s20, #14
    v.insert     v11, s18, #14
    v.movi       v12, #0
    v.movi       v13, #0
    v.extract    s16, v5, #0
    s.shli       s17, s19, #32
    s.lshri      s18, s21, #32
    s.lshri      s19, s2, #32
    v.extract    s20, v6, #0
    s.or         s22, s16, s17
    v.insert     v9, s21, #15
    v.insert     v11, s18, #15
    v.insert     v12, s2, #0
    v.insert     v13, s19, #0
    v.extract    s2, v5, #0
    s.shli       s16, s20, #32
    s.lshri      s17, s22, #32
    v.extract    s18, v6, #0
    s.or         s19, s2, s16
    v.insert     v12, s22, #1
    v.insert     v13, s17, #1
    v.extract    s2, v5, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v6, #0
    s.or         s20, s2, s16
    v.insert     v12, s19, #2
    v.insert     v13, s17, #2
    v.extract    s2, v5, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v6, #0
    s.or         s19, s2, s16
    v.insert     v12, s20, #3
    v.insert     v13, s17, #3
    v.extract    s2, v5, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v6, #0
    s.or         s20, s2, s16
    v.insert     v12, s19, #4
    v.insert     v13, s17, #4
    v.extract    s2, v5, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v6, #0
    s.or         s19, s2, s16
    v.insert     v12, s20, #5
    v.insert     v13, s17, #5
    v.extract    s2, v5, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v6, #0
    s.or         s20, s2, s16
    v.insert     v12, s19, #6
    v.insert     v13, s17, #6
    v.extract    s2, v5, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v6, #0
    s.or         s19, s2, s16
    v.insert     v12, s20, #7
    v.insert     v13, s17, #7
    v.extract    s2, v5, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v6, #0
    s.or         s20, s2, s16
    v.insert     v12, s19, #8
    v.insert     v13, s17, #8
    v.extract    s2, v5, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v6, #0
    s.or         s19, s2, s16
    v.insert     v12, s20, #9
    v.insert     v13, s17, #9
    v.extract    s2, v5, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v6, #0
    s.or         s20, s2, s16
    v.insert     v12, s19, #10
    v.insert     v13, s17, #10
    v.extract    s2, v5, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v6, #0
    s.or         s19, s2, s16
    v.insert     v12, s20, #11
    v.insert     v13, s17, #11
    v.extract    s2, v5, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    v.extract    s18, v6, #0
    s.or         s20, s2, s16
    v.insert     v12, s19, #12
    v.insert     v13, s17, #12
    v.extract    s2, v5, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s20, #32
    v.extract    s18, v6, #0
    s.or         s19, s2, s16
    v.insert     v12, s20, #13
    v.insert     v13, s17, #13
    v.extract    s2, v5, #0
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    s.or         s18, s2, s16
    v.insert     v12, s19, #14
    v.insert     v13, s17, #14
    s.lshri      s2, s18, #32
    v.insert     v12, s18, #15
    v.insert     v13, s2, #15
    v.extract    s2, v11, #0
    v.extract    s16, v9, #0
    v.extract    s17, v13, #0
    s.shli       s18, s2, #32
    v.extract    s2, v12, #0
    s.shli       s19, s17, #32
    v.extract    s17, v11, #1
    v.extract    s20, v13, #1
    s.or         s21, s16, s18
    s.or         s16, s2, s19
    v.movi       v5, #0
    v.extract    s2, v9, #1
    s.shli       s18, s17, #32
    v.extract    s17, v12, #1
    s.shli       s19, s20, #32
    s.add        s20, s21, s16
    v.extract    s16, v11, #2
    v.extract    s21, v13, #2
    s.or         s22, s2, s18
    s.or         s2, s17, s19
    v.movi       v6, #0
    v.insert     v5, s20, #0
    v.extract    s17, v9, #2
    s.shli       s18, s16, #32
    v.extract    s16, v12, #2
    s.shli       s19, s21, #32
    s.lshri      s21, s20, #32
    s.add        s20, s22, s2
    v.extract    s2, v11, #3
    s.or         s22, s17, s18
    v.extract    s17, v13, #3
    s.or         s18, s16, s19
    v.insert     v6, s21, #0
    v.insert     v5, s20, #1
    v.extract    s16, v9, #3
    s.shli       s19, s2, #32
    v.extract    s2, v12, #3
    s.shli       s21, s17, #32
    s.lshri      s17, s20, #32
    s.add        s20, s22, s18
    v.extract    s18, v11, #4
    s.or         s22, s16, s19
    v.extract    s16, v13, #4
    s.or         s19, s2, s21
    v.insert     v6, s17, #1
    v.insert     v5, s20, #2
    v.extract    s2, v9, #4
    s.shli       s17, s18, #32
    v.extract    s18, v12, #4
    s.shli       s21, s16, #32
    s.lshri      s16, s20, #32
    s.add        s20, s22, s19
    v.extract    s19, v11, #5
    s.or         s22, s2, s17
    v.extract    s2, v13, #5
    s.or         s17, s18, s21
    v.insert     v6, s16, #2
    v.insert     v5, s20, #3
    v.extract    s16, v9, #5
    s.shli       s18, s19, #32
    v.extract    s19, v12, #5
    s.shli       s21, s2, #32
    s.lshri      s2, s20, #32
    s.add        s20, s22, s17
    v.extract    s17, v11, #6
    s.or         s22, s16, s18
    v.extract    s16, v13, #6
    s.or         s18, s19, s21
    v.insert     v6, s2, #3
    v.insert     v5, s20, #4
    v.extract    s2, v9, #6
    s.shli       s19, s17, #32
    v.extract    s17, v12, #6
    s.shli       s21, s16, #32
    s.lshri      s16, s20, #32
    s.add        s20, s22, s18
    v.extract    s18, v11, #7
    s.or         s22, s2, s19
    v.extract    s2, v13, #7
    s.or         s19, s17, s21
    v.insert     v6, s16, #4
    v.insert     v5, s20, #5
    v.extract    s16, v9, #7
    s.shli       s17, s18, #32
    v.extract    s18, v12, #7
    s.shli       s21, s2, #32
    s.lshri      s2, s20, #32
    s.add        s20, s22, s19
    v.extract    s19, v11, #8
    s.or         s22, s16, s17
    v.extract    s16, v13, #8
    s.or         s17, s18, s21
    v.insert     v6, s2, #5
    v.insert     v5, s20, #6
    v.extract    s2, v9, #8
    s.shli       s18, s19, #32
    v.extract    s19, v12, #8
    s.shli       s21, s16, #32
    s.lshri      s16, s20, #32
    s.add        s20, s22, s17
    v.extract    s17, v11, #9
    s.or         s22, s2, s18
    v.extract    s2, v13, #9
    s.or         s18, s19, s21
    v.insert     v6, s16, #6
    v.insert     v5, s20, #7
    v.extract    s16, v9, #9
    s.shli       s19, s17, #32
    v.extract    s17, v12, #9
    s.shli       s21, s2, #32
    s.lshri      s2, s20, #32
    s.add        s20, s22, s18
    v.extract    s18, v11, #10
    s.or         s22, s16, s19
    v.extract    s16, v13, #10
    s.or         s19, s17, s21
    v.insert     v6, s2, #7
    v.insert     v5, s20, #8
    v.extract    s2, v9, #10
    s.shli       s17, s18, #32
    v.extract    s18, v12, #10
    s.shli       s21, s16, #32
    s.lshri      s16, s20, #32
    s.add        s20, s22, s19
    v.extract    s19, v11, #11
    s.or         s22, s2, s17
    v.extract    s2, v13, #11
    s.or         s17, s18, s21
    v.insert     v6, s16, #8
    v.insert     v5, s20, #9
    v.extract    s16, v9, #11
    s.shli       s18, s19, #32
    v.extract    s19, v12, #11
    s.shli       s21, s2, #32
    s.lshri      s2, s20, #32
    s.add        s20, s22, s17
    v.extract    s17, v11, #12
    s.or         s22, s16, s18
    v.extract    s16, v13, #12
    s.or         s18, s19, s21
    v.insert     v6, s2, #9
    v.insert     v5, s20, #10
    v.extract    s2, v9, #12
    s.shli       s19, s17, #32
    v.extract    s17, v12, #12
    s.shli       s21, s16, #32
    s.lshri      s16, s20, #32
    s.add        s20, s22, s18
    v.extract    s18, v11, #13
    s.or         s22, s2, s19
    v.extract    s2, v13, #13
    s.or         s19, s17, s21
    v.insert     v6, s16, #10
    v.insert     v5, s20, #11
    v.extract    s16, v9, #13
    s.shli       s17, s18, #32
    v.extract    s18, v12, #13
    s.shli       s21, s2, #32
    s.lshri      s2, s20, #32
    s.add        s20, s22, s19
    v.extract    s19, v11, #14
    s.or         s22, s16, s17
    v.extract    s16, v13, #14
    s.or         s17, s18, s21
    v.insert     v6, s2, #11
    v.insert     v5, s20, #12
    v.extract    s2, v9, #14
    s.shli       s18, s19, #32
    v.extract    s19, v12, #14
    s.shli       s21, s16, #32
    s.lshri      s16, s20, #32
    s.add        s20, s22, s17
    v.extract    s17, v11, #15
    s.or         s22, s2, s18
    v.extract    s2, v13, #15
    s.or         s18, s19, s21
    v.insert     v6, s16, #12
    v.insert     v5, s20, #13
    v.extract    s16, v9, #15
    s.shli       s19, s17, #32
    v.extract    s17, v12, #15
    s.shli       s21, s2, #32
    s.lshri      s2, s20, #32
    s.add        s20, s22, s18
    s.or         s18, s16, s19
    s.or         s16, s17, s21
    v.insert     v6, s2, #13
    v.insert     v5, s20, #14
    s.lshri      s2, s20, #32
    s.add        s17, s18, s16
    v.insert     v6, s2, #14
    v.insert     v5, s17, #15
    v.movi       v9, #31
    s.lshri      s2, s17, #32
    v.movi       v11, #1
    v.insert     v6, s2, #15
    v.ashr       v12, v5, v9
    v.movi       v9, #0
    s.movz       s2, #0
    v.cmp.ne     p2, v6, v12
    @p2 v.sel        v6, v11, v9
    v.reduce.or  s16, v6
    s.cmp.eq     s17, s16, s2
    br.nz        s17, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v6, [s3, v5]               // index is in elements (ISA sec 9.1)
    s.mul        s2, s4, s14
    v.movi       v5, #0
    s.add        s16, s1, s15
    s.movz       s17, #1
    s.add        s18, s1, s2
    v.splat      v9, s2
    s.shli       s2, s18, #1                     // element offset -> bytes (x2)
    s.add        s18, s9, s2                     // &out_ptr0[...]
    v.add        v11, v7, v9
    vf.cvt.bf16.f32 v7, v6
    vf.add       v6, v7, v8
    vf.add       v7, v6, v10
    vf.add       v6, v7, v3
    vf.mul       v3, v6, v6
    vf.cvt.f32.bf16 v7, v6
    vf.add       v6, v4, v3
    @p1 v.st.h       [s18, #0], v7
    @p1 v.sel        v3, v6, v4
    v.mov        v5, v3
    v.mov        v4, v5
    s.mov        s1, s16
    br.nz        s17, for_1
endfor_2:
    vf.reduce.add.b v1, v4
    v.movi       v2, #0
    vf.add       v3, v1, v2
    s.addi       s1, s12, #768                   // TensorMap 3: tl.make_tensor_descriptor (rank 2)
    s.movz       s2, #0
    s.st.d       [s1, #0], s9
    s.movz       s2, #15
    s.st.d       [s1, #8], s2
    s.movz       s2, #2560
    s.st.d       [s1, #16], s2
    s.movz       s2, #5120
    s.st.d       [s1, #48], s2
    s.movz       s2, #2
    s.st.d       [s1, #56], s2
    .li       s2, #68719476737
    s.st.d       [s1, #88], s2
    .li       s2, #1108101562368
    s.st.d       [s1, #104], s2
    fence.release.device
    td.load      d3, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s13, #0
for_5:
    s.cmp.ge     s2, s1, s14
    br.nz        s2, endfor_6
    .li       s2, #1159725056
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v2, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #897988541
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v1                          // ISA 8.8: <= 2**-22 relative
    v.splat      v6, s1
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s2, #2560
    s.movz       s3, #15
    s.muli       s5, s4, #5120
    v.add        v8, v6, v7
    v.movi       v6, #0
    v.splat      v7, s2
    v.splat      v9, s4
    v.movi       v10, #0
    s.muli       s2, s1, #2
    v.cmp.ge     p1, v8, v6
    v.splat      v6, s3
    v.cmp.lt     p2, v8, v7
    v.splat      v7, s1
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v6
    v.add        v6, v7, v0
    v.movi       v7, #2560
    s.add        s3, s9, s5
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.shli       s5, s1, #1                      // element offset -> bytes (x2)
    s.add        s6, s3, s2
    p.and        p2, p5, p1
    s.add        s2, s8, s5                      // &in_ptr5[...]
    v.cmp.lt     p1, v6, v7
    vf.fms       v7, v1, v5, v2
    .li       s3, #1077936128
    v.splat      v2, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    fence.acq_rel.device
    .li       s3, #3204448256
    v.splat      v8, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v9, [s6, #0]
    vf.fms       v10, v5, v7, v5
    .li       s3, #1065353216
    v.splat      v7, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s3, s4, s14
    s.add        s5, s1, s15
    vf.neg       v11, v10                        // Newton step: r0*(2 - x*r0)
    s.add        s6, s1, s3
    v.splat      v10, s3
    s.shli       s3, s6, #1                      // element offset -> bytes (x2)
    vf.cmp.o     p2, v11, v11
    @p2 v.sel        v12, v11, v5
    s.add        s6, s10, s3                     // &out_ptr2[...]
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v5, [s2, #0]
    vf.cvt.bf16.f32 v11, v9
    s.add        s2, s11, s3                     // &out_ptr3[...]
    s.movz       s3, #1
    fence.acq_rel.device
    v.add        v9, v6, v10
    vf.mul       v6, v3, v12                     // a/y: faithful quotient
    vf.fms       v9, v6, v1, v3
    vf.cvt.bf16.f32 v1, v5
    vf.fms       v5, v9, v12, v6
    vf.add       v9, v1, v7
    vf.neg       v1, v5                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v5, v1, v6
    vf.add       v1, v5, v4
    v.rsqrt.approx v4, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v4, v4
    vf.mul       v6, v4, v8
    vf.fms       v7, v1, v5, v2
    vf.mul       v1, v6, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v2, v1, v4
    v.extract    s7, v2, #0
    v.splat      v1, s7
    vf.mul       v2, v11, v1
    vf.mul       v1, v2, v9
    vf.cvt.f32.bf16 v2, v1
    @p1 v.st.h       [s6, #0], v2
    @p1 v.st.h       [s2, #0], v2
    s.mov        s1, s5
    br.nz        s3, for_5
endfor_6:
__rctx_next:
    exit
