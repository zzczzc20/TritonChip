from pathlib import Path
import sys,json,hashlib,traceback
home=Path.home();source=home/'tnca_src_r40_conditional_12a0340_full';sys.path[:0]=[str(source),str(source/'python'),str(source/'compiler/python'),str(source/'tools/asm'),str(source/'tools/r40')]
p=Path(__file__).parent
try:
 from archbench.provenance import software_tree
 assert software_tree(refresh=True)=='files:3cd958b8e17ad47b21e195cbae768630af6a6c49e31797e12daa3ca4ec81093b'
 import triton
 from tnca.triton_backend.driver import _Sessions
 def forbidden(*a,**kw):raise RuntimeError('readiness preflight forbids backend/session opens')
 _Sessions.get=classmethod(forbidden)
 import importlib
 origins={}
 for name in ['archbench.platforms.tnca','archbench.registry','board_checkpoint','native_inventory','native_model','hbm_board','conditional_delivery']:
  module=importlib.import_module(name);path=Path(module.__file__).resolve();assert path.is_relative_to(source)
  origins[name]=dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
 import torch,triton
 import tnca.torch_device as D
 D.register();assert not _Sessions.open
 module=Path(D._ext.__file__)
 r=dict(status='ready-no-device-opened',origins=origins,torch=torch.__version__,triton=triton.__version__,extension=str(module),extension_sha256=hashlib.sha256(module.read_bytes()).hexdigest(),open_sessions=0,software_tree=software_tree(refresh=True))
except Exception:r=dict(status='failed',error=traceback.format_exc())
(p/'preflight.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
if r['status']=='failed':raise SystemExit(1)
