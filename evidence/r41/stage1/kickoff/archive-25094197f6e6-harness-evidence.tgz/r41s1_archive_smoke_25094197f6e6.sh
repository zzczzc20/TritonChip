#!/bin/bash
# Clean-archive Stage 1 harness smoke: git archive of 25094197f6e6, fresh caches, GB10.
set -u
A=$HOME/r41s1_25094197f6e6.tar.gz; R=$HOME/r41s1-archive-25094197f6e6; O=$HOME/r41s1-archive-25094197f6e6-out
test ! -e $R && mkdir -p $R/cache/{ext,triton,inductor} && tar xzf $A -C $R
source $HOME/tc_env/env.sh >/dev/null 2>&1
export TORCH_EXTENSIONS_DIR=$R/cache/ext TRITON_CACHE_DIR=$R/cache/triton TORCHINDUCTOR_CACHE_DIR=$R/cache/inductor PYTHONDONTWRITEBYTECODE=1 MAX_JOBS=4 OMP_NUM_THREADS=1 CUDA_VISIBLE_DEVICES=
cd $R && echo "archive_sha256 $(sha256sum $A | cut -c1-64)" > $HOME/r41s1-archive-25094197f6e6.log
nice $HOME/tc_env/torchenv/bin/python tools/performance_harness/experiment.py spec/r41/stage1/experiments/harness-smoke.json --root $R --out $O --python $HOME/tc_env/torchenv/bin/python >> $HOME/r41s1-archive-25094197f6e6.log 2>&1
echo "exit $? SMOKE-DONE" >> $HOME/r41s1-archive-25094197f6e6.log
