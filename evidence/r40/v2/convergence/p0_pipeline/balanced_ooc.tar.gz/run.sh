source /tools/Xilinx/Vivado/2023.2/settings64.sh
cd /home/zzhouch/tnca_build/r40_balanced_screen
for balanced in 0 1; do
 timeout -k 15 1800 vivado -mode batch -source /home/zzhouch/tnca_build/r40_balanced_screen/source/flow/fpga/synth_r40_range_slice.tcl -tclargs /home/zzhouch/tnca_build/r40_balanced_screen/source /home/zzhouch/tnca_build/r40_balanced_screen/case$balanced 1 32 5 1 1 $balanced > /home/zzhouch/tnca_build/r40_balanced_screen/case$balanced.log 2>&1
 result=$?
 echo $result > /home/zzhouch/tnca_build/r40_balanced_screen/case$balanced.exit
 if [ "$result" -ne 0 ]; then exit "$result"; fi
done
