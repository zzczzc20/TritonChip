    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    s.shli       s1, s2, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #0
    v.add        v4, v1, v0
    v.movi       v0, #15
    v.movi       v1, #4
    v.sub        v5, v2, v4
    v.sub        v6, v3, v4
    v.cmp.lt     p1, v4, v2
    v.cmp.lt     p2, v4, v3
    @p1 v.sel        v7, v5, v4
    @p2 v.sel        v5, v6, v4
    v.movi       v6, #32
    v.and        v8, v7, v0
    v.lshr       v0, v5, v1
    v.movi       v1, #16
    v.sub        v5, v2, v8
    v.sub        v7, v3, v0
    v.cmp.lt     p3, v4, v6
    @p1 v.sel        v4, v5, v8
    @p2 v.sel        v5, v7, v0
    v.sub        v0, v2, v1
    v.add        v7, v4, v1
    v.mul        v8, v5, v6
    v.sub        v5, v3, v1
    v.cmp.lt     p1, v1, v2
    v.add        v2, v7, v8
    v.add        v6, v4, v8
    v.cmp.lt     p2, v1, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s3, v2]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v2, v0, v1
    @p2 v.sel        v0, v5, v1
    vf.cvt.f16.f32 v0, v3
    vf.neg       v1, v0
    vf.cvt.f32.f16 v0, v1
    @p3 v.st.scatter.h [s5, v6], v0
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s6, s1, s4
    s.mov        s2, s1
    br.nz        s6, __rctx_program
    exit
