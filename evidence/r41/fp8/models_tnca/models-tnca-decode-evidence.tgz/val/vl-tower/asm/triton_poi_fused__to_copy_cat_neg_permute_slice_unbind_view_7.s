    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #5
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.lshr       v5, v4, v0
    v.movi       v0, #0
    v.sub        v4, v2, v5
    v.movi       v6, #0
    @p1 v.sel        v7, v4, v5
    v.sub        v4, v0, v3
    v.sub        v5, v1, v7
    v.cmp.lt     p1, v7, v1
    @p1 v.sel        v8, v5, v7
    v.movi       v5, #15
    v.sub        v9, v6, v3
    v.cmp.lt     p2, v3, v0
    v.cmp.lt     p3, v3, v6
    @p2 v.sel        v10, v4, v3
    v.movi       v4, #31
    v.and        v11, v8, v5
    @p3 v.sel        v5, v9, v3
    v.and        v3, v10, v4
    v.sub        v4, v1, v11
    v.sub        v8, v0, v3
    @p1 v.sel        v9, v4, v11
    @p2 v.sel        v4, v8, v3
    s.rdspecial  s1, arg_base
    v.movi       v3, #32
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v8, #16
    v.movi       v10, #512
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.cmp.lt     p1, v3, v0
    v.sub        v11, v0, v3
    v.cmp.lt     p2, v3, v2
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v11, v3
    v.movi       v2, #9
    v.cmp.lt     p1, v8, v1
    v.lshr       v11, v5, v2
    v.movi       v2, #64
    v.sub        v5, v1, v8
    v.mul        v1, v9, v2
    v.mul        v9, v7, v2
    v.sub        v2, v6, v11
    v.add        v7, v4, v1
    @p3 v.sel        v1, v2, v11
    v.movi       v2, #3072
    v.add        v11, v4, v9
    v.mul        v4, v1, v2
    v.sub        v1, v6, v10
    v.add        v2, v7, v4
    v.cmp.lt     p3, v10, v6
    v.ld.gather.h v4, [s2, v2]                   // index is in elements (ISA sec 9.1)
    @p2 v.sel        v2, v0, v3
    @p1 v.sel        v0, v5, v8
    @p3 v.sel        v0, v1, v10
    vf.cvt.bf16.f32 v0, v4
    v.st.scatter.w [s3, v11], v0
__rctx_next:
    exit
