    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s5, #512
    .li       s6, #2147483647
    s.mul        s7, s1, s5
    .li       s1, #2147483647
    s.movz       s5, #4096
    s.movz       s8, #2
    .li       s9, #68719476752
    .li       s10, #1108101562368
    s.rdspecial  s11, arg_base
    s.ld.d       s12, [s2, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.add        s13, s3, s7                     // this context's own scratch
    s.rdspecial  s3, role_id
    s.addi       s7, s13, #0                     // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s13, #512
    .li       s14, #2147483647
    s.mul        s15, s3, s13
    .li       s3, #2147483647
    s.movz       s13, #4096
    s.movz       s16, #2
    .li       s17, #68719476752
    s.ld.d       s18, [s2, #8]                   // arg_B: device_ptr64 at arg_base+8
    s.movz       s19, #32
    .li       s20, #1108101562368
    s.movz       s21, #0
    s.movz       s21, #0
    s.ld.d       s21, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.movz       s2, #0
    s.st.d       [s7, #0], s12
    s.movz       s12, #0
    s.st.d       [s7, #8], s6
    s.movz       s6, #0
    s.cmp.lt     s22, s19, s6
    s.st.d       [s7, #16], s1
    s.movz       s1, #0
    s.sub        s6, s1, s22
    s.movz       s1, #8
    s.st.d       [s7, #48], s5
    s.movz       s5, #1
    s.st.d       [s7, #56], s8
    s.cmp.lt     s8, s4, s2
    s.movz       s2, #0
    s.sub        s22, s12, s8
    s.movz       s8, #0
    s.st.d       [s7, #88], s9
    s.xor        s9, s4, s22
    s.sub        s12, s9, s22
    s.st.d       [s7, #104], s10
    s.lshri      s9, s12, #5
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s7, s22, s6
    s.movz       s10, #0
    s.ld.d       s22, [s11, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s11, s22, s15                   // this context's own scratch
    s.xor        s15, s9, s7
    s.cmp.lt     s22, s4, s8
    s.sub        s8, s15, s7
    s.movz       s7, #0
    s.sub        s15, s1, s8
    s.muli       s1, s9, #32
    s.min.s      s9, s15, s5
    s.addi       s15, s11, #256                  // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.cmp.lt     s11, s9, s2
    s.sub        s2, s7, s22
    s.movz       s7, #0
    s.st.d       [s15, #0], s18
    s.sub        s18, s10, s11
    s.movz       s10, #1
    s.xor        s11, s4, s2
    s.sub        s22, s12, s1
    s.xor        s1, s19, s6
    s.movz       s12, #0
    s.sub        s22, s1, s6
    s.st.d       [s15, #8], s14
    s.xor        s1, s9, s18
    s.sub        s6, s11, s2
    s.st.d       [s15, #16], s3
    s.sub        s3, s1, s18
    s.addi       s1, s7, #0
    s.st.d       [s15, #48], s13
    s.cmp.eq     s7, s3, s10
    s.addi       s10, s12, #0
    s.st.d       [s15, #56], s16
    s.st.d       [s15, #88], s17
    s.st.d       [s15, #104], s20
    fence.release.device
    td.load      d1, [s15]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s1, s6
    br.nz        s7, sdiv_done_1
    s.movz       s7, #0
    s.movz       s11, #31
    s.mov        s1, s7
    s.addi       s7, s11, #0
sdiv_2:
    s.lshr       s11, s6, s7
    s.shli       s12, s10, #1
    s.andi       s13, s11, #1
    s.movz       s11, #0
    s.or         s14, s12, s13
    s.movz       s12, #1
    s.cmp.geu    s13, s14, s3
    s.shl        s15, s12, s7
    s.sub        s12, s11, s13
    s.subi       s11, s7, #1
    s.and        s13, s3, s12
    s.and        s16, s15, s12
    s.sub        s12, s14, s13
    s.or         s13, s1, s16
    s.mov        s10, s12
    s.mov        s1, s13
    s.mov        s7, s11
    s.movz       s11, #0
    s.cmp.ge     s12, s7, s11
    br.nz        s12, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s3, #0
    s.cmp.lt     s6, s4, s1
    s.movz       s1, #0
    s.sub        s7, s3, s6
    s.movz       s3, #0
    s.xor        s6, s4, s7
    s.movz       s4, #0
    s.sub        s11, s6, s7
    s.cmp.lt     s6, s9, s1
    s.lshri      s1, s11, #5
    s.movz       s12, #0
    s.muli       s13, s1, #32
    s.sub        s1, s4, s6
    s.movz       s4, #0
    s.cmp.lt     s6, s19, s12
    s.xor        s12, s9, s1
    s.sub        s9, s11, s13
    s.movz       s11, #0
    s.xor        s13, s9, s7
    s.xor        s9, s10, s2
    s.sub        s10, s13, s7
    s.sub        s7, s11, s6
    s.cmp.lt     s6, s10, s3
    s.sub        s3, s12, s1
    s.sub        s11, s4, s6
    s.movz       s4, #0
    s.xor        s6, s10, s11
    s.movz       s10, #1
    s.sub        s12, s9, s2
    s.xor        s2, s19, s7
    s.sub        s9, s6, s11
    s.movz       s6, #0
    s.addi       s13, s4, #0
    s.cmp.eq     s4, s3, s10
    s.add        s10, s8, s12
    s.sub        s8, s2, s7
    s.addi       s2, s6, #0
    s.mov        s13, s9
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s6, #31
    s.mov        s13, s4
    s.addi       s4, s6, #0
sdiv_4:
    s.lshr       s6, s9, s4
    s.shli       s7, s2, #1
    s.andi       s8, s6, #1
    s.movz       s6, #0
    s.or         s12, s7, s8
    s.movz       s7, #1
    s.cmp.geu    s8, s12, s3
    s.shl        s14, s7, s4
    s.sub        s7, s6, s8
    s.subi       s6, s4, #1
    s.and        s8, s3, s7
    s.and        s15, s14, s7
    s.sub        s7, s12, s8
    s.or         s8, s13, s15
    s.mov        s2, s7
    s.mov        s13, s8
    s.mov        s4, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s4, s6
    br.nz        s7, sdiv_4
sdiv_done_3:
    s.xor        s2, s11, s1
    s.movz       s1, #16
    s.xor        s3, s13, s2
    s.mul        s4, s10, s1
    s.sub        s6, s3, s2
    s.movz       s2, #0
    s.mul        s3, s6, s1
    v.splat      v0, s10
    s.andi       s7, s4, #127
    v.splat      v1, s2
    v.splat      v2, s6
    s.andi       s6, s3, #511
    v.splat      v3, s2
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s4
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s3
    v.splat      v1, s7
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s6
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.movz       s8, #128
    s.addi       s9, s2, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s2, s9, s8
    br.nz        s2, endfor_6
    s.mul        s2, s9, s1
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s10, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s11, s9, s5
    s.movz       s12, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s2                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s13, s10
    mb.wait      s10
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s14, s6                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s2                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s14, s13
    mb.wait      s13
    mb.arm       s2, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v56, v48, s2
    mb.wait      s2
    s.mov        s9, s11
    br.nz        s12, for_5
endfor_6:
    s.movz       s1, #0
    v.splat      v0, s8
    s.add        s5, s1, s4                      // the tile origin
    v.movi       v1, #1
    v.splat      v2, s5
    v.movi       v3, #0
    s.movz       s1, #0
    v.cmp.lt     p1, v2, v0
    @p1 v.sel        v2, v1, v3
    s.add        s6, s1, s3                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    s.muli       s7, s3, #2                      // a runtime tile origin, x2
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v3, s6
    s.addi       s3, s5, #1
    a.vread      v4, a0, s1
    v.extract    s1, v2, #0
    s.movz       s6, #512
    s.muli       s8, s4, #1024                   // a runtime tile origin, x1024
    v.splat      v2, s3
    v.splat      v5, s1
    v.movi       v6, #0
    v.add        v7, v1, v3
    v.splat      v1, s6
    v.movi       v3, #1
    vf.cvt.f32.bf16 v8, v4
    s.add        s1, s21, s7                     // the tile origin
    v.cmp.lt     p1, v2, v0
    v.movi       v2, #0
    v.cmp.ne     p2, v5, v6
    v.cmp.lt     p3, v7, v1
    @p1 v.sel        v1, v3, v2
    s.add        s3, s1, s8                      // the tile origin
    p.and        p1, p2, p3
    s.movz       s1, #1
    s.addi       s4, s5, #2
    @p1 v.st.h       [s3, #0], v8
    a.vread      v2, a0, s1
    v.extract    s1, v1, #0
    v.splat      v1, s4
    v.splat      v3, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    s.addi       s1, s3, #1024                   // row 1
    p.and        p1, p2, p3
    s.movz       s4, #2
    s.addi       s6, s5, #3
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s4
    v.extract    s1, v1, #0
    v.splat      v1, s6
    v.splat      v3, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    s.addi       s1, s3, #2048                   // row 2
    p.and        p1, p2, p3
    s.movz       s4, #3
    s.addi       s6, s5, #4
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s4
    v.extract    s1, v1, #0
    v.splat      v1, s6
    v.splat      v3, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    s.addi       s1, s3, #3072                   // row 3
    p.and        p1, p2, p3
    s.movz       s4, #4
    s.addi       s6, s5, #5
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s4
    v.extract    s1, v1, #0
    v.splat      v1, s6
    v.splat      v3, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    s.addi       s1, s3, #4096                   // row 4
    p.and        p1, p2, p3
    s.movz       s4, #5
    s.addi       s6, s5, #6
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s4
    v.extract    s1, v1, #0
    v.splat      v1, s6
    v.splat      v3, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    s.addi       s1, s3, #5120                   // row 5
    p.and        p1, p2, p3
    s.movz       s4, #6
    s.addi       s6, s5, #7
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s4
    v.extract    s1, v1, #0
    v.splat      v1, s6
    v.splat      v3, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    s.addi       s1, s3, #6144                   // row 6
    p.and        p1, p2, p3
    s.movz       s4, #7
    s.addi       s6, s5, #8
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s4
    v.extract    s1, v1, #0
    v.splat      v1, s6
    v.splat      v3, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    s.addi       s1, s3, #7168                   // row 7
    p.and        p1, p2, p3
    s.movz       s4, #8
    s.addi       s6, s5, #9
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s4
    v.extract    s1, v1, #0
    v.splat      v1, s6
    v.splat      v3, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    s.addi       s1, s3, #8192                   // row 8
    p.and        p1, p2, p3
    s.movz       s4, #9
    s.addi       s6, s5, #10
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s4
    v.extract    s1, v1, #0
    v.splat      v1, s6
    v.splat      v3, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    s.addi       s1, s3, #9216                   // row 9
    p.and        p1, p2, p3
    s.movz       s4, #10
    s.addi       s6, s5, #11
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s4
    v.extract    s1, v1, #0
    v.splat      v1, s6
    v.splat      v3, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    s.addi       s1, s3, #10240                  // row 10
    p.and        p1, p2, p3
    s.movz       s4, #11
    s.addi       s6, s5, #12
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s4
    v.extract    s1, v1, #0
    v.splat      v1, s6
    v.splat      v3, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    s.addi       s1, s3, #11264                  // row 11
    p.and        p1, p2, p3
    s.movz       s4, #12
    s.addi       s6, s5, #13
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s4
    v.extract    s1, v1, #0
    v.splat      v1, s6
    v.splat      v3, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    s.addi       s1, s3, #12288                  // row 12
    p.and        p1, p2, p3
    s.movz       s4, #13
    s.addi       s6, s5, #14
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s4
    v.extract    s1, v1, #0
    v.splat      v1, s6
    v.splat      v3, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v1, v5, v6
    s.addi       s1, s3, #13312                  // row 13
    p.and        p1, p2, p3
    s.movz       s4, #14
    s.addi       s6, s5, #15
    @p1 v.st.h       [s1, #0], v7
    a.vread      v2, a0, s4
    v.extract    s1, v1, #0
    v.splat      v1, s6
    v.splat      v3, s1
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    vf.cvt.f32.bf16 v7, v2
    v.cmp.lt     p1, v1, v0
    v.cmp.ne     p2, v3, v4
    @p1 v.sel        v0, v5, v6
    s.addi       s1, s3, #14336                  // row 14
    p.and        p1, p2, p3
    s.movz       s4, #15
    @p1 v.st.h       [s1, #0], v7
    a.vread      v1, a0, s4
    v.extract    s1, v0, #0
    v.movi       v0, #0
    v.splat      v2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #15360                  // row 15
    v.cmp.ne     p1, v2, v0
    p.and        p2, p1, p3
    @p2 v.st.h       [s1, #0], v3
__rctx_next:
    exit
