    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #4
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.movi       v6, #0
    @p1 v.sel        v7, v5, v4
    v.sub        v5, v0, v4
    v.cmp.lt     p2, v4, v0
    v.lshr       v8, v7, v3
    v.sub        v3, v1, v4
    v.cmp.lt     p3, v4, v1
    v.sub        v7, v2, v8
    @p3 v.sel        v9, v3, v4
    v.movi       v3, #15
    @p1 v.sel        v10, v7, v8
    v.movi       v7, #15
    v.and        v8, v9, v3
    v.sub        v3, v6, v10
    v.cmp.lt     p1, v10, v6
    s.rdspecial  s2, arg_base
    @p2 v.sel        v9, v5, v4
    @p1 v.sel        v5, v3, v10
    v.movi       v3, #16
    v.sub        v10, v1, v8
    v.and        v11, v5, v7
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p3 v.sel        v5, v10, v8
    v.sub        v7, v6, v11
    v.movi       v8, #1024
    v.cmp.lt     p3, v3, v1
    @p1 v.sel        v10, v7, v11
    v.cmp.lt     p1, v4, v8
    v.movi       v4, #256
    v.sub        v7, v1, v3
    v.sub        v1, v2, v3
    v.sub        v8, v6, v3
    s.ld.d       s4, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.cmp.lt     p4, v3, v2
    v.movi       v2, #8
    @p3 v.sel        v11, v7, v3
    v.movi       v7, #192
    v.lshr       v11, v9, v2
    .li       s2, #1056964608
    v.splat      v2, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.mul        v9, v10, v7
    v.sub        v7, v0, v11
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    v.cmp.lt     p3, v3, v6
    @p2 v.sel        v6, v7, v11
    v.sub        v7, v0, v4
    s.add        s1, s4, s2                      // &out_ptr0[...]
    v.mul        v10, v6, v3
    v.cmp.lt     p2, v4, v0
    @p4 v.sel        v0, v1, v3
    v.add        v0, v5, v10
    @p3 v.sel        v1, v8, v3
    @p2 v.sel        v1, v7, v4
    v.add        v1, v0, v9
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v0, [s3, v1]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v1, v0
    vf.mul       v0, v1, v2
    @p1 v.st.w       [s1, #0], v0
__rctx_next:
    exit
