    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s5, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s6, #512
    s.mul        s7, s1, s6
    s.add        s1, s5, s7                      // this context's own scratch
    s.addi       s5, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.st.d       [s5, #0], s2
    .li       s1, #2147483647
    s.st.d       [s5, #8], s1
    s.st.d       [s5, #16], s1
    s.movz       s2, #512
    s.st.d       [s5, #48], s2
    s.movz       s6, #4
    s.st.d       [s5, #56], s6
    .li       s7, #68719476752
    s.st.d       [s5, #88], s7
    .li       s8, #2207613190144
    s.st.d       [s5, #104], s8
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s5, arg_base
    s.ld.d       s9, [s5, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s5, role_id
    s.movz       s10, #512
    s.mul        s11, s5, s10
    s.add        s5, s9, s11                     // this context's own scratch
    s.addi       s9, s5, #256                    // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.st.d       [s9, #0], s3
    s.st.d       [s9, #8], s1
    s.st.d       [s9, #16], s1
    s.st.d       [s9, #48], s2
    s.st.d       [s9, #56], s6
    s.st.d       [s9, #88], s7
    s.st.d       [s9, #104], s8
    fence.release.device
    td.load      d1, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #8
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s2
    s.sub        s5, s2, s3
    s.movz       s3, #1
    s.rdspecial  s7, role_id
    s.rdspecial  s8, npid.x
__rctx_program:
    s.cmp.lt     s9, s7, s2
    s.addi       s10, s2, #0
    s.sub        s11, s2, s9
    s.addi       s9, s2, #0
    s.xor        s12, s7, s11
    s.xor        s13, s11, s5
    s.sub        s14, s12, s11
    s.lshri      s15, s14, #3
    s.mov        s10, s14
    s.xor        s16, s15, s13
    s.sub        s15, s16, s13
    s.sub        s13, s6, s15
    s.min.s      s16, s13, s3
    s.cmp.lt     s13, s16, s2
    s.sub        s17, s2, s13
    s.xor        s13, s16, s17
    s.sub        s16, s13, s17
    s.cmp.eq     s13, s16, s3
    br.nz        s13, sdiv_done_1
    s.movz       s18, #0
    s.movz       s19, #31
    s.mov        s10, s18
    s.addi       s20, s19, #0
sdiv_2:
    s.lshr       s19, s14, s20
    s.shli       s21, s9, #1
    s.andi       s22, s19, #1
    s.shl        s19, s3, s20
    s.or         s23, s21, s22
    s.cmp.geu    s21, s23, s16
    s.sub        s22, s18, s21
    s.and        s21, s16, s22
    s.and        s24, s19, s22
    s.sub        s9, s23, s21
    s.or         s10, s10, s24
    s.subi       s20, s20, #1
    s.cmp.ge     s19, s20, s18
    br.nz        s19, sdiv_2
sdiv_done_1:
    s.sub        s10, s12, s11
    s.xor        s12, s9, s11
    s.lshri      s9, s10, #3
    s.sub        s14, s12, s11
    s.muli       s12, s9, #8
    s.addi       s9, s2, #0
    s.add        s18, s15, s14
    s.addi       s14, s2, #0
    s.sub        s15, s10, s12
    s.xor        s10, s15, s11
    s.sub        s12, s10, s11
    s.cmp.lt     s10, s12, s2
    s.sub        s11, s2, s10
    s.xor        s10, s12, s11
    s.sub        s12, s10, s11
    s.mov        s9, s12
    br.nz        s13, sdiv_done_3
    s.movz       s10, #0
    s.movz       s13, #31
    s.mov        s9, s10
    s.addi       s15, s13, #0
    s.movz       s13, #1
sdiv_4:
    s.lshr       s19, s12, s15
    s.shli       s20, s14, #1
    s.andi       s21, s19, #1
    s.shl        s19, s13, s15
    s.or         s22, s20, s21
    s.cmp.geu    s20, s22, s16
    s.sub        s21, s10, s20
    s.and        s20, s16, s21
    s.and        s23, s19, s21
    s.sub        s14, s22, s20
    s.or         s9, s9, s23
    s.subi       s15, s15, #1
    s.cmp.ge     s19, s15, s10
    br.nz        s19, sdiv_4
sdiv_done_3:
    s.xor        s10, s11, s17
    s.movz       s11, #16
    s.xor        s12, s9, s10
    s.mul        s9, s18, s11
    s.sub        s13, s12, s10
    s.movz       s10, #0
    s.mul        s12, s13, s11
    s.addi       s13, s10, #0
    s.andi       s10, s9, #63
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.andi       s14, s12, #127
for_5:
    s.cmp.ge     s15, s13, s1
    br.nz        s15, endfor_6
    s.mul        s15, s13, s11
    w.def        w0, #48, #16                    // v48..v63
    mb.arm       s16, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.movi       v0, #0
    v.movi       v1, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s17, s10                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s18, s15                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w0, d0, s17, s16
    mb.wait      s16
    w.def        w1, #32, #16                    // v32..v47
    mb.arm       s17, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.movi       v2, #1
    v.movi       v3, #2
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s18, s15                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s19, s14                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.w w1, d1, s18, s17
    mb.wait      s17
    v.permute    v4, v48, v0
    v.permute    v5, v49, v0
    v.permute    v6, v50, v0
    v.permute    v7, v51, v0
    vf.fma       v8, v4, v32, v1
    vf.fma       v4, v5, v32, v1
    vf.fma       v5, v6, v32, v1
    vf.fma       v6, v7, v32, v1
    v.permute    v7, v48, v2
    v.permute    v9, v49, v2
    v.permute    v10, v50, v2
    v.permute    v11, v51, v2
    vf.fma       v12, v7, v33, v8
    vf.fma       v7, v9, v33, v4
    vf.fma       v4, v10, v33, v5
    vf.fma       v5, v11, v33, v6
    v.permute    v6, v48, v3
    v.permute    v8, v49, v3
    v.permute    v9, v50, v3
    v.permute    v10, v51, v3
    v.movi       v11, #3
    vf.fma       v13, v6, v34, v12
    vf.fma       v6, v8, v34, v7
    vf.fma       v7, v9, v34, v4
    vf.fma       v4, v10, v34, v5
    v.permute    v5, v48, v11
    v.permute    v8, v49, v11
    v.permute    v9, v50, v11
    v.permute    v10, v51, v11
    v.movi       v12, #4
    vf.fma       v14, v5, v35, v13
    vf.fma       v5, v8, v35, v6
    vf.fma       v6, v9, v35, v7
    vf.fma       v7, v10, v35, v4
    v.permute    v4, v48, v12
    v.permute    v8, v49, v12
    v.permute    v9, v50, v12
    v.permute    v10, v51, v12
    v.movi       v13, #5
    vf.fma       v15, v4, v36, v14
    vf.fma       v4, v8, v36, v5
    vf.fma       v5, v9, v36, v6
    vf.fma       v6, v10, v36, v7
    v.permute    v7, v48, v13
    v.permute    v8, v49, v13
    v.permute    v9, v50, v13
    v.permute    v10, v51, v13
    v.movi       v14, #6
    vf.fma       v16, v7, v37, v15
    vf.fma       v7, v8, v37, v4
    vf.fma       v4, v9, v37, v5
    vf.fma       v5, v10, v37, v6
    v.permute    v6, v48, v14
    v.permute    v8, v49, v14
    v.permute    v9, v50, v14
    v.permute    v10, v51, v14
    v.movi       v15, #7
    vf.fma       v17, v6, v38, v16
    vf.fma       v6, v8, v38, v7
    vf.fma       v7, v9, v38, v4
    vf.fma       v4, v10, v38, v5
    v.permute    v5, v48, v15
    v.permute    v8, v49, v15
    v.permute    v9, v50, v15
    v.permute    v10, v51, v15
    v.movi       v16, #8
    vf.fma       v18, v5, v39, v17
    vf.fma       v5, v8, v39, v6
    vf.fma       v6, v9, v39, v7
    vf.fma       v7, v10, v39, v4
    v.permute    v4, v48, v16
    v.permute    v8, v49, v16
    v.permute    v9, v50, v16
    v.permute    v10, v51, v16
    v.movi       v17, #9
    vf.fma       v19, v4, v40, v18
    vf.fma       v4, v8, v40, v5
    vf.fma       v5, v9, v40, v6
    vf.fma       v6, v10, v40, v7
    v.permute    v7, v48, v17
    v.permute    v8, v49, v17
    v.permute    v9, v50, v17
    v.permute    v10, v51, v17
    v.movi       v18, #10
    vf.fma       v20, v7, v41, v19
    vf.fma       v7, v8, v41, v4
    vf.fma       v4, v9, v41, v5
    vf.fma       v5, v10, v41, v6
    v.permute    v6, v48, v18
    v.permute    v8, v49, v18
    v.permute    v9, v50, v18
    v.permute    v10, v51, v18
    v.movi       v19, #11
    vf.fma       v21, v6, v42, v20
    vf.fma       v6, v8, v42, v7
    vf.fma       v7, v9, v42, v4
    vf.fma       v4, v10, v42, v5
    v.permute    v5, v48, v19
    v.permute    v8, v49, v19
    v.permute    v9, v50, v19
    v.permute    v10, v51, v19
    v.movi       v20, #12
    vf.fma       v22, v5, v43, v21
    vf.fma       v5, v8, v43, v6
    vf.fma       v6, v9, v43, v7
    vf.fma       v7, v10, v43, v4
    v.permute    v4, v48, v20
    v.permute    v8, v49, v20
    v.permute    v9, v50, v20
    v.permute    v10, v51, v20
    v.movi       v21, #13
    vf.fma       v23, v4, v44, v22
    vf.fma       v4, v8, v44, v5
    vf.fma       v5, v9, v44, v6
    vf.fma       v6, v10, v44, v7
    v.permute    v7, v48, v21
    v.permute    v8, v49, v21
    v.permute    v9, v50, v21
    v.permute    v10, v51, v21
    v.movi       v22, #14
    vf.fma       v24, v7, v45, v23
    vf.fma       v7, v8, v45, v4
    vf.fma       v4, v9, v45, v5
    vf.fma       v5, v10, v45, v6
    v.permute    v6, v48, v22
    v.permute    v8, v49, v22
    v.permute    v9, v50, v22
    v.permute    v10, v51, v22
    v.movi       v23, #15
    vf.fma       v25, v6, v46, v24
    vf.fma       v6, v8, v46, v7
    vf.fma       v7, v9, v46, v4
    vf.fma       v4, v10, v46, v5
    v.permute    v5, v48, v23
    v.permute    v8, v49, v23
    v.permute    v9, v50, v23
    v.permute    v10, v51, v23
    vf.fma       v24, v5, v47, v25
    s.movz       s15, #0
    vf.fma       v5, v8, v47, v6
    vf.fma       v6, v9, v47, v7
    vf.fma       v7, v10, v47, v4
    a.vread      v4, a0, s15
    s.movz       s18, #1
    s.movz       s19, #2
    vf.add       v8, v4, v24
    s.movz       s20, #3
    a.vwrite     a0, s15, v8
    a.vread      v4, a0, s18
    vf.add       v8, v4, v5
    a.vwrite     a0, s18, v8
    a.vread      v4, a0, s19
    vf.add       v5, v4, v6
    a.vwrite     a0, s19, v5
    a.vread      v4, a0, s20
    vf.add       v5, v4, v7
    a.vwrite     a0, s20, v5
    v.permute    v4, v52, v0
    v.permute    v5, v53, v0
    v.permute    v6, v54, v0
    v.permute    v7, v55, v0
    vf.fma       v8, v4, v32, v1
    vf.fma       v4, v5, v32, v1
    vf.fma       v5, v6, v32, v1
    vf.fma       v6, v7, v32, v1
    v.permute    v7, v52, v2
    v.permute    v9, v53, v2
    v.permute    v10, v54, v2
    v.permute    v24, v55, v2
    vf.fma       v25, v7, v33, v8
    vf.fma       v7, v9, v33, v4
    vf.fma       v4, v10, v33, v5
    vf.fma       v5, v24, v33, v6
    v.permute    v6, v52, v3
    v.permute    v8, v53, v3
    v.permute    v9, v54, v3
    v.permute    v10, v55, v3
    vf.fma       v24, v6, v34, v25
    vf.fma       v6, v8, v34, v7
    vf.fma       v7, v9, v34, v4
    vf.fma       v4, v10, v34, v5
    v.permute    v5, v52, v11
    v.permute    v8, v53, v11
    v.permute    v9, v54, v11
    v.permute    v10, v55, v11
    vf.fma       v25, v5, v35, v24
    vf.fma       v5, v8, v35, v6
    vf.fma       v6, v9, v35, v7
    vf.fma       v7, v10, v35, v4
    v.permute    v4, v52, v12
    v.permute    v8, v53, v12
    v.permute    v9, v54, v12
    v.permute    v10, v55, v12
    vf.fma       v24, v4, v36, v25
    vf.fma       v4, v8, v36, v5
    vf.fma       v5, v9, v36, v6
    vf.fma       v6, v10, v36, v7
    v.permute    v7, v52, v13
    v.permute    v8, v53, v13
    v.permute    v9, v54, v13
    v.permute    v10, v55, v13
    vf.fma       v25, v7, v37, v24
    vf.fma       v7, v8, v37, v4
    vf.fma       v4, v9, v37, v5
    vf.fma       v5, v10, v37, v6
    v.permute    v6, v52, v14
    v.permute    v8, v53, v14
    v.permute    v9, v54, v14
    v.permute    v10, v55, v14
    vf.fma       v24, v6, v38, v25
    vf.fma       v6, v8, v38, v7
    vf.fma       v7, v9, v38, v4
    vf.fma       v4, v10, v38, v5
    v.permute    v5, v52, v15
    v.permute    v8, v53, v15
    v.permute    v9, v54, v15
    v.permute    v10, v55, v15
    vf.fma       v25, v5, v39, v24
    vf.fma       v5, v8, v39, v6
    vf.fma       v6, v9, v39, v7
    vf.fma       v7, v10, v39, v4
    v.permute    v4, v52, v16
    v.permute    v8, v53, v16
    v.permute    v9, v54, v16
    v.permute    v10, v55, v16
    vf.fma       v24, v4, v40, v25
    vf.fma       v4, v8, v40, v5
    vf.fma       v5, v9, v40, v6
    vf.fma       v6, v10, v40, v7
    v.permute    v7, v52, v17
    v.permute    v8, v53, v17
    v.permute    v9, v54, v17
    v.permute    v10, v55, v17
    vf.fma       v25, v7, v41, v24
    vf.fma       v7, v8, v41, v4
    vf.fma       v4, v9, v41, v5
    vf.fma       v5, v10, v41, v6
    v.permute    v6, v52, v18
    v.permute    v8, v53, v18
    v.permute    v9, v54, v18
    v.permute    v10, v55, v18
    vf.fma       v24, v6, v42, v25
    vf.fma       v6, v8, v42, v7
    vf.fma       v7, v9, v42, v4
    vf.fma       v4, v10, v42, v5
    v.permute    v5, v52, v19
    v.permute    v8, v53, v19
    v.permute    v9, v54, v19
    v.permute    v10, v55, v19
    vf.fma       v25, v5, v43, v24
    vf.fma       v5, v8, v43, v6
    vf.fma       v6, v9, v43, v7
    vf.fma       v7, v10, v43, v4
    v.permute    v4, v52, v20
    v.permute    v8, v53, v20
    v.permute    v9, v54, v20
    v.permute    v10, v55, v20
    vf.fma       v24, v4, v44, v25
    vf.fma       v4, v8, v44, v5
    vf.fma       v5, v9, v44, v6
    vf.fma       v6, v10, v44, v7
    v.permute    v7, v52, v21
    v.permute    v8, v53, v21
    v.permute    v9, v54, v21
    v.permute    v10, v55, v21
    vf.fma       v25, v7, v45, v24
    vf.fma       v7, v8, v45, v4
    vf.fma       v4, v9, v45, v5
    vf.fma       v5, v10, v45, v6
    v.permute    v6, v52, v22
    v.permute    v8, v53, v22
    v.permute    v9, v54, v22
    v.permute    v10, v55, v22
    vf.fma       v24, v6, v46, v25
    vf.fma       v6, v8, v46, v7
    vf.fma       v7, v9, v46, v4
    vf.fma       v4, v10, v46, v5
    v.permute    v5, v52, v23
    v.permute    v8, v53, v23
    v.permute    v9, v54, v23
    v.permute    v10, v55, v23
    vf.fma       v25, v5, v47, v24
    s.movz       s15, #4
    vf.fma       v5, v8, v47, v6
    vf.fma       v6, v9, v47, v7
    vf.fma       v7, v10, v47, v4
    a.vread      v4, a0, s15
    s.movz       s19, #5
    s.movz       s20, #6
    vf.add       v8, v4, v25
    s.movz       s21, #7
    a.vwrite     a0, s15, v8
    a.vread      v4, a0, s19
    vf.add       v8, v4, v5
    a.vwrite     a0, s19, v8
    a.vread      v4, a0, s20
    vf.add       v5, v4, v6
    a.vwrite     a0, s20, v5
    a.vread      v4, a0, s21
    vf.add       v5, v4, v7
    a.vwrite     a0, s21, v5
    v.permute    v4, v56, v0
    v.permute    v5, v57, v0
    v.permute    v6, v58, v0
    v.permute    v7, v59, v0
    vf.fma       v8, v4, v32, v1
    vf.fma       v4, v5, v32, v1
    vf.fma       v5, v6, v32, v1
    vf.fma       v6, v7, v32, v1
    v.permute    v7, v56, v2
    v.permute    v9, v57, v2
    v.permute    v10, v58, v2
    v.permute    v24, v59, v2
    vf.fma       v25, v7, v33, v8
    vf.fma       v7, v9, v33, v4
    vf.fma       v4, v10, v33, v5
    vf.fma       v5, v24, v33, v6
    v.permute    v6, v56, v3
    v.permute    v8, v57, v3
    v.permute    v9, v58, v3
    v.permute    v10, v59, v3
    vf.fma       v24, v6, v34, v25
    vf.fma       v6, v8, v34, v7
    vf.fma       v7, v9, v34, v4
    vf.fma       v4, v10, v34, v5
    v.permute    v5, v56, v11
    v.permute    v8, v57, v11
    v.permute    v9, v58, v11
    v.permute    v10, v59, v11
    vf.fma       v25, v5, v35, v24
    vf.fma       v5, v8, v35, v6
    vf.fma       v6, v9, v35, v7
    vf.fma       v7, v10, v35, v4
    v.permute    v4, v56, v12
    v.permute    v8, v57, v12
    v.permute    v9, v58, v12
    v.permute    v10, v59, v12
    vf.fma       v24, v4, v36, v25
    vf.fma       v4, v8, v36, v5
    vf.fma       v5, v9, v36, v6
    vf.fma       v6, v10, v36, v7
    v.permute    v7, v56, v13
    v.permute    v8, v57, v13
    v.permute    v9, v58, v13
    v.permute    v10, v59, v13
    vf.fma       v25, v7, v37, v24
    vf.fma       v7, v8, v37, v4
    vf.fma       v4, v9, v37, v5
    vf.fma       v5, v10, v37, v6
    v.permute    v6, v56, v14
    v.permute    v8, v57, v14
    v.permute    v9, v58, v14
    v.permute    v10, v59, v14
    vf.fma       v24, v6, v38, v25
    vf.fma       v6, v8, v38, v7
    vf.fma       v7, v9, v38, v4
    vf.fma       v4, v10, v38, v5
    v.permute    v5, v56, v15
    v.permute    v8, v57, v15
    v.permute    v9, v58, v15
    v.permute    v10, v59, v15
    vf.fma       v25, v5, v39, v24
    vf.fma       v5, v8, v39, v6
    vf.fma       v6, v9, v39, v7
    vf.fma       v7, v10, v39, v4
    v.permute    v4, v56, v16
    v.permute    v8, v57, v16
    v.permute    v9, v58, v16
    v.permute    v10, v59, v16
    vf.fma       v24, v4, v40, v25
    vf.fma       v4, v8, v40, v5
    vf.fma       v5, v9, v40, v6
    vf.fma       v6, v10, v40, v7
    v.permute    v7, v56, v17
    v.permute    v8, v57, v17
    v.permute    v9, v58, v17
    v.permute    v10, v59, v17
    vf.fma       v25, v7, v41, v24
    vf.fma       v7, v8, v41, v4
    vf.fma       v4, v9, v41, v5
    vf.fma       v5, v10, v41, v6
    v.permute    v6, v56, v18
    v.permute    v8, v57, v18
    v.permute    v9, v58, v18
    v.permute    v10, v59, v18
    vf.fma       v24, v6, v42, v25
    vf.fma       v6, v8, v42, v7
    vf.fma       v7, v9, v42, v4
    vf.fma       v4, v10, v42, v5
    v.permute    v5, v56, v19
    v.permute    v8, v57, v19
    v.permute    v9, v58, v19
    v.permute    v10, v59, v19
    vf.fma       v25, v5, v43, v24
    vf.fma       v5, v8, v43, v6
    vf.fma       v6, v9, v43, v7
    vf.fma       v7, v10, v43, v4
    v.permute    v4, v56, v20
    v.permute    v8, v57, v20
    v.permute    v9, v58, v20
    v.permute    v10, v59, v20
    vf.fma       v24, v4, v44, v25
    vf.fma       v4, v8, v44, v5
    vf.fma       v5, v9, v44, v6
    vf.fma       v6, v10, v44, v7
    v.permute    v7, v56, v21
    v.permute    v8, v57, v21
    v.permute    v9, v58, v21
    v.permute    v10, v59, v21
    vf.fma       v25, v7, v45, v24
    vf.fma       v7, v8, v45, v4
    vf.fma       v4, v9, v45, v5
    vf.fma       v5, v10, v45, v6
    v.permute    v6, v56, v22
    v.permute    v8, v57, v22
    v.permute    v9, v58, v22
    v.permute    v10, v59, v22
    vf.fma       v24, v6, v46, v25
    vf.fma       v6, v8, v46, v7
    vf.fma       v7, v9, v46, v4
    vf.fma       v4, v10, v46, v5
    v.permute    v5, v56, v23
    v.permute    v8, v57, v23
    v.permute    v9, v58, v23
    v.permute    v10, v59, v23
    vf.fma       v25, v5, v47, v24
    s.movz       s15, #8
    vf.fma       v5, v8, v47, v6
    vf.fma       v6, v9, v47, v7
    vf.fma       v7, v10, v47, v4
    a.vread      v4, a0, s15
    s.movz       s19, #9
    s.movz       s20, #10
    vf.add       v8, v4, v25
    s.movz       s21, #11
    a.vwrite     a0, s15, v8
    a.vread      v4, a0, s19
    vf.add       v8, v4, v5
    a.vwrite     a0, s19, v8
    a.vread      v4, a0, s20
    vf.add       v5, v4, v6
    a.vwrite     a0, s20, v5
    a.vread      v4, a0, s21
    vf.add       v5, v4, v7
    a.vwrite     a0, s21, v5
    v.permute    v4, v60, v0
    v.permute    v5, v61, v0
    v.permute    v6, v62, v0
    v.permute    v7, v63, v0
    vf.fma       v0, v4, v32, v1
    vf.fma       v4, v5, v32, v1
    vf.fma       v5, v6, v32, v1
    vf.fma       v6, v7, v32, v1
    v.permute    v1, v60, v2
    v.permute    v7, v61, v2
    v.permute    v8, v62, v2
    v.permute    v9, v63, v2
    vf.fma       v2, v1, v33, v0
    vf.fma       v0, v7, v33, v4
    vf.fma       v1, v8, v33, v5
    vf.fma       v4, v9, v33, v6
    v.permute    v5, v60, v3
    v.permute    v6, v61, v3
    v.permute    v7, v62, v3
    v.permute    v8, v63, v3
    vf.fma       v3, v5, v34, v2
    vf.fma       v2, v6, v34, v0
    vf.fma       v0, v7, v34, v1
    vf.fma       v1, v8, v34, v4
    v.permute    v4, v60, v11
    v.permute    v5, v61, v11
    v.permute    v6, v62, v11
    v.permute    v7, v63, v11
    vf.fma       v8, v4, v35, v3
    vf.fma       v3, v5, v35, v2
    vf.fma       v2, v6, v35, v0
    vf.fma       v0, v7, v35, v1
    v.permute    v1, v60, v12
    v.permute    v4, v61, v12
    v.permute    v5, v62, v12
    v.permute    v6, v63, v12
    vf.fma       v7, v1, v36, v8
    vf.fma       v1, v4, v36, v3
    vf.fma       v3, v5, v36, v2
    vf.fma       v2, v6, v36, v0
    v.permute    v0, v60, v13
    v.permute    v4, v61, v13
    v.permute    v5, v62, v13
    v.permute    v6, v63, v13
    vf.fma       v8, v0, v37, v7
    vf.fma       v0, v4, v37, v1
    vf.fma       v1, v5, v37, v3
    vf.fma       v3, v6, v37, v2
    v.permute    v2, v60, v14
    v.permute    v4, v61, v14
    v.permute    v5, v62, v14
    v.permute    v6, v63, v14
    vf.fma       v7, v2, v38, v8
    vf.fma       v2, v4, v38, v0
    vf.fma       v0, v5, v38, v1
    vf.fma       v1, v6, v38, v3
    v.permute    v3, v60, v15
    v.permute    v4, v61, v15
    v.permute    v5, v62, v15
    v.permute    v6, v63, v15
    vf.fma       v8, v3, v39, v7
    vf.fma       v3, v4, v39, v2
    vf.fma       v2, v5, v39, v0
    vf.fma       v0, v6, v39, v1
    v.permute    v1, v60, v16
    v.permute    v4, v61, v16
    v.permute    v5, v62, v16
    v.permute    v6, v63, v16
    vf.fma       v7, v1, v40, v8
    vf.fma       v1, v4, v40, v3
    vf.fma       v3, v5, v40, v2
    vf.fma       v2, v6, v40, v0
    v.permute    v0, v60, v17
    v.permute    v4, v61, v17
    v.permute    v5, v62, v17
    v.permute    v6, v63, v17
    vf.fma       v8, v0, v41, v7
    vf.fma       v0, v4, v41, v1
    vf.fma       v1, v5, v41, v3
    vf.fma       v3, v6, v41, v2
    v.permute    v2, v60, v18
    v.permute    v4, v61, v18
    v.permute    v5, v62, v18
    v.permute    v6, v63, v18
    vf.fma       v7, v2, v42, v8
    vf.fma       v2, v4, v42, v0
    vf.fma       v0, v5, v42, v1
    vf.fma       v1, v6, v42, v3
    v.permute    v3, v60, v19
    v.permute    v4, v61, v19
    v.permute    v5, v62, v19
    v.permute    v6, v63, v19
    vf.fma       v8, v3, v43, v7
    vf.fma       v3, v4, v43, v2
    vf.fma       v2, v5, v43, v0
    vf.fma       v0, v6, v43, v1
    v.permute    v1, v60, v20
    v.permute    v4, v61, v20
    v.permute    v5, v62, v20
    v.permute    v6, v63, v20
    vf.fma       v7, v1, v44, v8
    vf.fma       v1, v4, v44, v3
    vf.fma       v3, v5, v44, v2
    vf.fma       v2, v6, v44, v0
    v.permute    v0, v60, v21
    v.permute    v4, v61, v21
    v.permute    v5, v62, v21
    v.permute    v6, v63, v21
    vf.fma       v8, v0, v45, v7
    vf.fma       v0, v4, v45, v1
    vf.fma       v1, v5, v45, v3
    vf.fma       v3, v6, v45, v2
    v.permute    v2, v60, v22
    v.permute    v4, v61, v22
    v.permute    v5, v62, v22
    v.permute    v6, v63, v22
    vf.fma       v7, v2, v46, v8
    vf.fma       v2, v4, v46, v0
    vf.fma       v0, v5, v46, v1
    vf.fma       v1, v6, v46, v3
    v.permute    v3, v60, v23
    v.permute    v4, v61, v23
    v.permute    v5, v62, v23
    v.permute    v6, v63, v23
    vf.fma       v8, v3, v47, v7
    s.movz       s15, #12
    vf.fma       v3, v4, v47, v2
    vf.fma       v2, v5, v47, v0
    vf.fma       v0, v6, v47, v1
    a.vread      v1, a0, s15
    s.movz       s19, #13
    s.movz       s20, #14
    vf.add       v4, v1, v8
    s.movz       s21, #15
    a.vwrite     a0, s15, v4
    a.vread      v1, a0, s19
    vf.add       v4, v1, v3
    a.vwrite     a0, s19, v4
    a.vread      v1, a0, s20
    vf.add       v3, v1, v2
    a.vwrite     a0, s20, v3
    a.vread      v1, a0, s21
    vf.add       v2, v1, v0
    a.vwrite     a0, s21, v2
    s.add        s13, s13, s3
    br.nz        s18, for_5
endfor_6:
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s10, #0
    s.muli       s11, s12, #4                    // a runtime tile origin, x4
    s.add        s13, s10, s12                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s13
    s.add        s12, s10, s9                    // the tile origin
    s.movz       s13, #64
    s.movz       s14, #128
    s.muli       s15, s9, #512                   // a runtime tile origin, x512
    v.splat      v2, s12
    v.splat      v3, s13
    v.add        v4, v0, v1
    v.splat      v0, s14
    s.addi       s9, s12, #1
    s.add        s13, s4, s11                    // the tile origin
    a.vread      v1, a0, s10
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s9
    s.add        s9, s13, s15                    // the tile origin
    p.and        p3, p1, p2
    s.movz       s10, #1
    s.addi       s11, s12, #2
    @p3 v.st.w       [s9, #0], v1
    a.vread      v1, a0, s10
    v.cmp.lt     p1, v0, v3
    v.splat      v0, s11
    s.addi       s10, s9, #512                   // row 1
    p.and        p3, p1, p2
    s.movz       s11, #2
    s.addi       s13, s12, #3
    v.cmp.lt     p1, v0, v3
    v.splat      v0, s13
    s.addi       s13, s9, #1024                  // row 2
    p.and        p4, p1, p2
    s.movz       s14, #3
    s.addi       s15, s12, #4
    s.addi       s18, s9, #1536                  // row 3
    v.splat      v2, s15
    s.movz       s15, #4
    s.addi       s19, s12, #5
    @p3 v.st.w       [s10, #0], v1
    a.vread      v1, a0, s11
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    v.splat      v0, s19
    s.addi       s10, s9, #2048                  // row 4
    s.movz       s11, #5
    s.addi       s19, s12, #6
    v.splat      v4, s19
    s.addi       s19, s9, #2560                  // row 5
    @p4 v.st.w       [s13, #0], v1
    a.vread      v1, a0, s14
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s13, #6
    s.addi       s14, s12, #7
    v.splat      v2, s14
    s.addi       s14, s9, #3072                  // row 6
    @p3 v.st.w       [s18, #0], v1
    a.vread      v1, a0, s15
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.movz       s15, #7
    s.addi       s18, s12, #8
    v.splat      v0, s18
    s.addi       s18, s9, #3584                  // row 7
    @p4 v.st.w       [s10, #0], v1
    a.vread      v1, a0, s11
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.movz       s10, #8
    s.addi       s11, s12, #9
    v.splat      v4, s11
    s.addi       s11, s9, #4096                  // row 8
    @p3 v.st.w       [s19, #0], v1
    a.vread      v1, a0, s13
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.movz       s13, #9
    s.addi       s19, s12, #10
    v.splat      v2, s19
    s.addi       s19, s9, #4608                  // row 9
    @p4 v.st.w       [s14, #0], v1
    a.vread      v1, a0, s15
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.movz       s14, #10
    s.addi       s15, s12, #11
    v.splat      v0, s15
    s.addi       s15, s9, #5120                  // row 10
    @p3 v.st.w       [s18, #0], v1
    a.vread      v1, a0, s10
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    s.movz       s10, #11
    s.addi       s18, s12, #12
    v.splat      v4, s18
    s.addi       s18, s9, #5632                  // row 11
    @p4 v.st.w       [s11, #0], v1
    a.vread      v1, a0, s13
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s11, #12
    s.addi       s13, s12, #13
    v.splat      v2, s13
    s.addi       s13, s9, #6144                  // row 12
    @p3 v.st.w       [s19, #0], v1
    a.vread      v1, a0, s14
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.movz       s14, #13
    s.addi       s19, s12, #14
    s.addi       s20, s12, #15
    v.splat      v0, s19
    s.addi       s12, s9, #6656                  // row 13
    v.splat      v5, s20
    s.movz       s19, #14
    @p4 v.st.w       [s15, #0], v1
    a.vread      v1, a0, s10
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.addi       s10, s9, #7168                  // row 14
    s.movz       s15, #15
    s.addi       s20, s9, #7680                  // row 15
    @p3 v.st.w       [s18, #0], v1
    a.vread      v1, a0, s11
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    @p4 v.st.w       [s13, #0], v1
    a.vread      v1, a0, s14
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    @p3 v.st.w       [s12, #0], v1
    a.vread      v0, a0, s19
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    @p4 v.st.w       [s10, #0], v0
    a.vread      v0, a0, s15
    @p3 v.st.w       [s20, #0], v0
__rctx_next:
    s.addi       s9, s7, #2                      // the next program of this context: + 2
    s.cmp.lt     s10, s9, s8
    s.mov        s7, s9
    br.nz        s10, __rctx_program
    exit
