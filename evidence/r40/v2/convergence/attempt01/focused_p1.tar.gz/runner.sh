source /tools/Xilinx/Vivado/2023.2/settings64.sh
cd "$HOME/tnca_build/r40_attempt01_focused_p1"
timeout -k 15 1800 vivado -mode batch -source probe.tcl -tclargs "$HOME/tnca_build/r40_attempt01_20261016/xo/tmp/link/vivado/vpl/prj/prj.runs/impl_1/level0_wrapper_routed_error.dcp" "$PWD/reports" "$PWD/drivers.txt" > stdout.log 2>&1
echo $? > exit
