    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #513
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.iota       v3                              // arange(0, VLEN)
    v.sub        v4, v2, v0
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v6, #1
    @p1 v.sel        v7, v4, v0
    @p2 v.sel        v4, v5, v1
    v.movi       v5, #0
    v.movi       v8, #0
    s.movz       s3, #31
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s6, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s7, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s8, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s9, [s1, #40]                   // out_ptr0: device_ptr64 at arg_base+40
idiv_1:
    v.splat      v9, s3
    v.shl        v10, v8, v6
    v.cmp.lt     p3, v8, v2
    v.lshr       v11, v7, v9
    v.shl        v12, v6, v9
    s.subi       s1, s3, #1
    v.and        v9, v11, v6
    s.movz       s10, #0
    v.or         v11, v10, v9
    v.cmp.geu    p4, v11, v4
    p.or         p5, p3, p4
    v.sub        v9, v11, v4
    @p5 v.sel        v10, v12, v2
    @p5 v.sel        v12, v9, v11
    v.or         v9, v5, v10
    v.mov        v8, v12
    v.mov        v5, v9
    s.mov        s3, s1
    s.cmp.ge     s1, s3, s10
    br.nz        s1, idiv_1
    v.movi       v4, #0
    v.sub        v6, v2, v5
    p.xor        p3, p1, p2
    v.sub        v2, v4, v0
    v.sub        v7, v4, v1
    v.cmp.lt     p1, v0, v4
    v.cmp.lt     p2, v1, v4
    @p3 v.sel        v8, v6, v5
    v.movi       v5, #1
    @p1 v.sel        v6, v2, v0
    @p2 v.sel        v0, v7, v1
    v.movi       v1, #0
    v.movi       v2, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v7, s1
    v.shl        v9, v2, v5
    v.cmp.lt     p2, v2, v4
    v.lshr       v10, v6, v7
    v.shl        v11, v5, v7
    s.subi       s3, s1, #1
    v.and        v7, v10, v5
    s.movz       s10, #0
    v.or         v10, v9, v7
    v.cmp.geu    p3, v10, v0
    p.or         p4, p2, p3
    v.sub        v7, v10, v0
    @p4 v.sel        v9, v11, v4
    @p4 v.sel        v11, v7, v10
    v.or         v7, v1, v9
    v.mov        v2, v11
    v.mov        v1, v7
    s.mov        s1, s3
    s.cmp.ge     s3, s1, s10
    br.nz        s3, idiv_2
    v.sub        v0, v4, v2
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s1, #0
    @p1 v.sel        v5, v0, v2
    s.movz       s3, #64
    s.movz       s10, #16
    s.addi       s11, s1, #0
    v.mov        v4, v1
for_3:
    s.cmp.ge     s1, s11, s3
    br.nz        s1, endfor_4
    v.movi       v0, #0
    v.movi       v1, #64
    v.movi       v2, #2
    v.sub        v6, v0, v8
    v.cmp.lt     p1, v8, v0
    v.mul        v7, v8, v1
    @p1 v.sel        v9, v6, v8
    v.splat      v6, s11
    v.extract    s1, v7, #0
    v.lshr       v7, v9, v2
    v.add        v2, v6, v3
    v.splat      v6, s1
    v.sub        v9, v0, v7
    v.movi       v10, #64
    s.shli       s1, s11, #1                     // element offset -> bytes (x2)
    v.mul        v11, v5, v1
    @p1 v.sel        v1, v9, v7
    s.movz       s12, #32832
    v.splat      v7, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v9, v2, v6
    s.add        s12, s5, s1                     // &in_ptr1[...]
    s.add        s13, s7, s1                     // &in_ptr3[...]
    v.cmp.lt     p1, v2, v10
    v.extract    s1, v11, #0
    v.mul        v6, v1, v7
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s2, v9]               // index is in elements (ISA sec 9.1)
    v.splat      v7, s1
    v.extract    s1, v6, #0
    .li       s14, #1052050675
    v.splat      v6, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v10, v2, v7
    v.splat      v2, s1
    v.movi       v7, #4
    v.movi       v11, #0
    v.add        v12, v10, v2
    v.sub        v2, v0, v7
    s.add        s1, s11, s10
    v.cmp.lt     p2, v7, v0
    v.movi       v0, #1
    @p2 v.sel        v0, v2, v7
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s12, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s12, #1
    s.movz       s14, #32832
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s6, v9]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v7, v0
    vf.mul       v0, v2, v7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v7, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s8, v12]              // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v9, v2
    vf.mul       v2, v7, v9
    vf.add       v7, v0, v2
    vf.cvt.f16.f32 v0, v1
    vf.mul       v1, v7, v6
    vf.mul       v2, v0, v6
    vf.mul       v0, v1, v2
    vf.add       v1, v4, v0
    @p1 v.sel        v0, v1, v4
    v.mov        v11, v0
    v.mov        v4, v11
    s.mov        s11, s1
    br.nz        s12, for_3
endfor_4:
    vf.reduce.add.b v0, v4
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s9, s2                      // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
