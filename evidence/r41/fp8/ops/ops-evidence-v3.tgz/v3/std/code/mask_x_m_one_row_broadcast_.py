# AOT ID: ['49_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/y4/cy4mtab4pmf676bmdoh3oqxhy2lofq5ocfsyqklmqmnr6tftkagv.py
# Topologically Sorted Source Nodes: [eq, setitem, getitem], Original ATen: [aten.eq, aten.index_put, aten.select]
# Source node to ATen node mapping:
#   eq => eq
#   getitem => select
#   setitem => expand, select_1, unsqueeze, view, where
# Graph fragment:
#   %arg2_1 : Tensor "i64[2, 128][128, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %arg1_1 : Tensor "f32[1, 64][64, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f32[2, 128, 64][8192, 64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %eq : Tensor "b8[2, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%arg2_1, 7), kwargs = {})
#   %view : Tensor "b8[2, 128, 1][128, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [2, 128, 1]), kwargs = {})
#   %expand : Tensor "b8[2, 128, 64][128, 1, 0]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%view, [2, 128, 64]), kwargs = {})
#   %select : Tensor "f32[64][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg1_1, 0, 0), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select, 0), kwargs = {})
#   %select_1 : Tensor "f32[64][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%unsqueeze, 0, 0), kwargs = {})
#   %where : Tensor "f32[2, 128, 64][8192, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%expand, %expand_1, %arg0_1), kwargs = {})
#   return %where
triton_poi_fused_eq_index_put_select_0 = async_compile.triton('triton_poi_fused_eq_index_put_select_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16384}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_eq_index_put_select_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 198912}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_eq_index_put_select_0(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 16384
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = xindex // 64
    x0 = (xindex % 64)
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last')
    tmp3 = tl.load(in_ptr1 + (x0), None, eviction_policy='evict_last')
    tmp4 = tl.load(in_ptr2 + (x2), None)
    tmp1 = tl.full([1], 7, tl.int64)
    tmp2 = tmp0 == tmp1
    tmp5 = tl.where(tmp2, tmp3, tmp4)
    tl.store(out_ptr0 + (x2), tmp5, None)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1 = args
        args.clear()
        assert_size_stride_grouped((arg2_1, arg1_1, arg0_1), ((2, 128), (1, 64), (2, 128, 64)), ((128, 1), (64, 1), (8192, 64, 1)), 'input')
        buf0 = empty_strided((2, 128, 64), (8192, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [eq, setitem, getitem], Original ATen: [aten.eq, aten.index_put, aten.select]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_eq_index_put_select_0.run(arg2_1, arg1_1, arg0_1, buf0, 16384, stream=raw_stream0)
        del arg0_1
        del arg1_1
        del arg2_1
        return (buf0, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((2, 128, 64), (8192, 64, 1), device='tnca:0', dtype=torch.float32)
    arg1_1 = rand_strided((1, 64), (64, 1), device='tnca:0', dtype=torch.float32)
    arg2_1 = rand_strided((2, 128), (128, 1), device='tnca:0', dtype=torch.int64)
    return [arg0_1, arg1_1, arg2_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
