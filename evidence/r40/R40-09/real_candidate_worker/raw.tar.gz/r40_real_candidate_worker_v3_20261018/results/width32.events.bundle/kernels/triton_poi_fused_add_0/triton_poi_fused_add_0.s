    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    v.iota       v0                              // arange(0, VLEN)
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #16
    s.shli       s3, s4, #5                      // x32 as a shift
    s.movz       s4, #16
    v.iota       v2                              // arange(0, VLEN)
    v.add        v3, v0, v1
    v.splat      v0, s3
    v.splat      v1, s3
    s.add        s5, s4, s3
    v.add        v4, v0, v2
    v.add        v0, v1, v3
    s.ld.d       s4, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.movi       v1, #1000
    s.shli       s6, s3, #1                      // element offset -> bytes (x2)
    v.movi       v2, #1000
    s.shli       s3, s5, #1                      // element offset -> bytes (x2)
    s.add        s5, s2, s6                      // &in_ptr0[...]
    s.add        s7, s2, s3                      // &in_ptr0[...]
    v.cmp.lt     p1, v4, v1
    v.cmp.lt     p2, v0, v2
    s.add        s2, s4, s6                      // &in_ptr1[...]
    s.add        s8, s4, s3                      // &in_ptr1[...]
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s5, #0]
    v.cmp.lt     p1, v4, v1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v5, [s7, #0]
    v.cmp.lt     p2, v0, v2
    vf.cvt.f16.f32 v6, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s2, #0]
    vf.cvt.f16.f32 v7, v5
    v.cmp.lt     p1, v4, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s8, #0]
    vf.cvt.f16.f32 v4, v3
    v.cmp.lt     p2, v0, v2
    vf.add       v0, v6, v4
    vf.cvt.f32.f16 v2, v0
    vf.cvt.f16.f32 v0, v1
    s.ld.d       s2, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    vf.add       v1, v7, v0
    vf.cvt.f32.f16 v0, v1
    s.add        s1, s2, s6                      // &out_ptr0[...]
    s.add        s4, s2, s3                      // &out_ptr0[...]
    @p1 v.st.h       [s1, #0], v2
    @p2 v.st.h       [s4, #0], v0
__rctx_next:
    exit
