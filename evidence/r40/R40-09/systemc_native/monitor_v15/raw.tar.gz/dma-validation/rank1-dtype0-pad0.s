
        .li s1, #0x30000
        td.load d0, [s1]
        .li s2, #0x30100
        td.load d1, [s2]
        w.def w0, #0, #8
        
        mb.arm s3, b0, #0, #1
        .li s10, #-1
        t.ld.async.h w0, d0, s10, s3
        mb.wait s3
        mb.arm s4, b0, #0, #1
        .li s10, #2
        t.st.async.h w0, d1, s10, s4
        
        mb.wait s4
        exit
    