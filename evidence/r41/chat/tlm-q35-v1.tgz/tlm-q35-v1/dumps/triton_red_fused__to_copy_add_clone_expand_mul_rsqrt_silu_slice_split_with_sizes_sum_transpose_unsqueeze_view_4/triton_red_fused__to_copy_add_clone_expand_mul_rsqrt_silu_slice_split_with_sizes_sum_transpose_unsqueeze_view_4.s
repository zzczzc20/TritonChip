    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #15
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.iota       v3                              // arange(0, VLEN)
    v.sub        v4, v2, v0
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v6, #1
    @p1 v.sel        v7, v4, v0
    @p2 v.sel        v4, v5, v1
    v.movi       v5, #0
    v.movi       v8, #0
    s.movz       s3, #31
    s.ld.d       s4, [s1, #8]                    // out_ptr1: device_ptr64 at arg_base+8
idiv_1:
    v.splat      v9, s3
    v.shl        v10, v8, v6
    v.cmp.lt     p2, v8, v2
    v.lshr       v11, v7, v9
    v.shl        v12, v6, v9
    s.subi       s1, s3, #1
    v.and        v9, v11, v6
    s.movz       s5, #0
    v.or         v11, v10, v9
    v.cmp.geu    p3, v11, v4
    p.or         p4, p2, p3
    v.sub        v9, v11, v4
    @p4 v.sel        v10, v12, v2
    @p4 v.sel        v12, v9, v11
    v.or         v9, v5, v10
    v.mov        v8, v12
    v.mov        v5, v9
    s.mov        s3, s1
    s.cmp.ge     s1, s3, s5
    br.nz        s1, idiv_1
    v.movi       v4, #0
    v.sub        v5, v2, v8
    v.movi       v2, #1
    v.sub        v6, v4, v0
    v.sub        v7, v4, v1
    v.cmp.lt     p2, v0, v4
    v.cmp.lt     p3, v1, v4
    @p1 v.sel        v9, v5, v8
    @p2 v.sel        v5, v6, v0
    @p3 v.sel        v0, v7, v1
    v.movi       v1, #0
    v.movi       v6, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v7, s1
    v.shl        v8, v6, v2
    v.cmp.lt     p1, v6, v4
    v.lshr       v10, v5, v7
    v.shl        v11, v2, v7
    s.subi       s3, s1, #1
    v.and        v7, v10, v2
    s.movz       s5, #0
    v.or         v10, v8, v7
    v.cmp.geu    p4, v10, v0
    p.or         p5, p1, p4
    v.sub        v7, v10, v0
    @p5 v.sel        v8, v11, v4
    @p5 v.sel        v11, v7, v10
    v.or         v7, v1, v8
    v.mov        v6, v11
    v.mov        v1, v7
    s.mov        s1, s3
    s.cmp.ge     s3, s1, s5
    br.nz        s3, idiv_2
    v.sub        v0, v4, v1
    v.movi       v2, #0
    v.movi       v4, #0
    p.xor        p1, p2, p3
    s.movz       s1, #0
    @p1 v.sel        v5, v0, v1
    s.movz       s3, #128
    s.movz       s5, #16
    s.addi       s6, s1, #0
    v.mov        v4, v2
for_3:
    s.cmp.ge     s7, s6, s3
    br.nz        s7, endfor_4
    v.movi       v0, #0
    v.movi       v1, #1
    v.movi       v2, #128
    v.sub        v6, v0, v5
    v.cmp.lt     p1, v5, v0
    v.splat      v7, s6
    @p1 v.sel        v8, v6, v5
    v.movi       v6, #8192
    v.add        v10, v7, v3
    v.lshr       v7, v8, v1
    v.movi       v1, #2048
    v.mul        v8, v9, v6
    v.sub        v6, v0, v7
    v.add        v11, v10, v1
    v.extract    s7, v8, #0
    @p1 v.sel        v1, v6, v7
    v.splat      v6, s7
    v.movi       v7, #128
    v.mul        v8, v1, v2
    v.movi       v1, #2
    v.cmp.lt     p1, v10, v7
    v.extract    s7, v8, #0
    v.movi       v2, #0
    v.splat      v7, s7
    v.sub        v8, v0, v1
    s.add        s7, s6, s5
    v.add        v10, v11, v7
    s.movz       s8, #1
    v.cmp.lt     p2, v1, v0
    v.add        v0, v10, v6
    s.movz       s9, #2048
    v.movi       v6, #1
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v6, [s2, v0]               // index is in elements (ISA sec 9.1)
    @p2 v.sel        v0, v8, v1
    s.movz       s9, #8192
    vf.cvt.bf16.f32 v0, v6
    vf.mul       v1, v0, v0
    vf.add       v0, v4, v1
    @p1 v.sel        v1, v0, v4
    v.mov        v2, v1
    v.mov        v4, v2
    s.mov        s6, s7
    br.nz        s8, for_3
endfor_4:
    vf.reduce.add.b v0, v4
    v.movi       v1, #0
    s.addi       s6, s1, #0
    vf.add       v2, v0, v1
for_5:
    s.cmp.ge     s1, s6, s3
    br.nz        s1, endfor_6
    .li       s1, #897988541
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    v.movi       v4, #1
    vf.add       v6, v2, v0
    v.sub        v0, v1, v5
    v.cmp.lt     p1, v5, v1
    v.movi       v7, #128
    @p1 v.sel        v8, v0, v5
    v.rsqrt.approx v0, v6                        // ISA 8.8: <= 2**-22 relative
    v.splat      v10, s6
    v.lshr       v11, v8, v4
    v.movi       v4, #8192
    v.add        v8, v10, v3
    v.sub        v10, v1, v11
    v.movi       v12, #2048
    v.mul        v13, v9, v4
    @p1 v.sel        v14, v10, v11
    v.add        v10, v8, v12
    v.extract    s1, v13, #0
    v.mul        v11, v14, v7
    v.splat      v12, s1
    v.movi       v13, #128
    v.extract    s1, v11, #0
    .li       s7, #1077936128
    v.splat      v11, s7                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v14, s1
    .li       s1, #3204448256
    v.splat      v15, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p1, v8, v13
    v.add        v13, v10, v14
    v.mul        v10, v9, v7
    v.mul        v7, v5, v4
    v.add        v4, v13, v12
    v.extract    s1, v10, #0
    v.movi       v10, #2
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v12, [s2, v4]              // index is in elements (ISA sec 9.1)
    v.splat      v4, s1
    v.sub        v13, v1, v10
    vf.mul       v14, v0, v0
    vf.mul       v16, v0, v15
    v.add        v15, v8, v4
    v.cmp.lt     p2, v10, v1
    s.movz       s1, #2048
    vf.fms       v1, v6, v14, v11
    v.extract    s1, v7, #0
    s.add        s7, s6, s5
    v.splat      v4, s1
    v.movi       v6, #1
    vf.mul       v6, v16, v1                     // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cvt.bf16.f32 v1, v12
    v.add        v7, v15, v4
    s.movz       s1, #1
    @p2 v.sel        v4, v13, v10
    vf.cmp.o     p2, v6, v6
    @p2 v.sel        v4, v6, v0
    s.movz       s8, #8192
    v.extract    s8, v4, #0
    v.splat      v0, s8
    vf.mul       v4, v1, v0
    @p1 v.st.scatter.w [s4, v7], v4
    s.mov        s6, s7
    br.nz        s1, for_5
endfor_6:
__rctx_next:
    exit
