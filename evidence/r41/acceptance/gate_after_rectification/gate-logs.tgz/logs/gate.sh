#!/bin/bash
# Non-regression gate after the r41 rectification (AUDIT.md section 2.4 / R16, R17).
# usage: gate.sh TREE_LABEL   (head or base); run from ~/r41fix_gate
set -u
source ~/tc_env/env.sh
G=~/r41fix_gate; T=$1; R=$G/$T; L=$G/logs/$T; mkdir -p $L
P=~/tc_env/torchenv/bin/python
LLVM=~/tc_env/root/usr/lib/llvm-20
export R1_STRICT=1
# The torchenv carries an editable tnca install from another tree (~/tritonchip);
# every lane must import this tree's packages instead.
export PYTHONPATH=$R/python:$R/compiler/python:$R
stamp() { date -u +%FT%TZ; }
lane() { # lane NAME command...
  local n=$1; shift
  echo "# $(stamp) start $n: $*" > $L/$n.log
  ( cd $R && nice -n 10 "$@" ) >> $L/$n.log 2>&1; local rc=$?
  echo "# $(stamp) end $n exit $rc" >> $L/$n.log
  echo "$n $rc" >> $L/exit_codes.txt
}
: > $L/exit_codes.txt
echo "tree $T $(cat $R/.gate_commit) started $(stamp) host $(hostname) PYTHONPATH=$PYTHONPATH" > $L/run.txt
( cd $R && $P -c "import tnca, tnca_cc; print('imports', tnca.__file__, tnca_cc.__file__)" ) >> $L/run.txt 2>&1
if [ $T = head ]; then
  [ -x $R/compiler/build/tools/tnca-opt/tnca-opt ] || lane tnca-opt make tnca-opt LLVM_PREFIX=$LLVM -j6
  lane compiler make compiler PYTHON=$P LLVM_PREFIX=$LLVM
fi
for t in core core-slowmem core-ooo core-vrf core-r39hw core-r39sw core-r39sw4 core-r39sw5 \
         r41-core-boundary top r38-xpose-rtl r41-xpose8-rtl lsu-reqreg unit fma-deep lint \
         r40-multicore-shell r40-line-axi r40-grid-dispatch r40-cache-maintenance \
         r40-multicore-dma r40-coherent-host r40-barrier-epoch r40-core-parameters \
         compiler-rtl triton-e2e r40-pipeline-checks; do
  lane make-$t make $t PYTHON=$P TRITON_PYTHON=$P
done
lane multicore-mmio-board-top env PYTHONPATH=python:compiler/python:. $P tools/r40/multicore_mmio_tests.py --cores 3 --ports 3 --pipeline 2 --board-top
echo "finished $(stamp)" >> $L/run.txt
