    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #0
    v.movi       v2, #0
    v.movi       v3, #5
    v.movi       v4, #31
    v.splat      v5, s2
    v.movi       v6, #32
    v.add        v7, v5, v0
    v.movi       v0, #5
    v.sub        v5, v1, v7
    v.cmp.lt     p1, v7, v1
    @p1 v.sel        v8, v5, v7
    v.sub        v5, v2, v7
    v.lshr       v9, v8, v3
    v.cmp.lt     p2, v7, v2
    @p2 v.sel        v3, v5, v7
    v.sub        v5, v1, v9
    v.and        v8, v3, v4
    @p1 v.sel        v3, v5, v9
    v.movi       v4, #0
    s.rdspecial  s1, arg_base
    v.movi       v5, #10240
    v.sub        v9, v2, v6
    v.sub        v10, v2, v8
    v.sub        v11, v1, v6
    v.sub        v12, v4, v3
    v.cmp.lt     p1, v6, v2
    v.sub        v2, v4, v0
    v.cmp.lt     p3, v6, v1
    v.cmp.lt     p4, v3, v4
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #1
    @p1 v.sel        v1, v9, v6
    v.cmp.lt     p1, v0, v4
    s.ld.d       s4, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    @p2 v.sel        v1, v10, v8
    v.cmp.lt     p2, v7, v5
    v.movi       v5, #1
    @p3 v.sel        v5, v11, v6
    v.movi       v5, #1
    @p4 v.sel        v8, v12, v3
    @p1 v.sel        v3, v2, v0
    v.movi       v0, #0
    v.movi       v2, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v9, s1
    v.shl        v10, v2, v5
    v.lshr       v11, v8, v9
    v.cmp.lt     p1, v2, v4
    v.and        v12, v11, v5
    v.shl        v11, v5, v9
    v.or         v9, v10, v12
    s.subi       s5, s1, #1
    v.cmp.geu    p3, v9, v3
    p.or         p5, p1, p3
    v.sub        v10, v9, v3
    @p5 v.sel        v12, v11, v4
    @p5 v.sel        v11, v10, v9
    v.or         v9, v0, v12
    v.mov        v2, v11
    v.mov        v0, v9
    s.mov        s1, s5
    s.movz       s5, #0
    s.cmp.ge     s6, s1, s5
    br.nz        s6, idiv_1
    v.movi       v0, #160
    v.movi       v3, #0
    v.sub        v5, v4, v2
    v.sub        v4, v3, v7
    v.sub        v8, v3, v0
    v.cmp.lt     p1, v7, v3
    v.cmp.lt     p3, v0, v3
    @p4 v.sel        v9, v5, v2
    v.movi       v2, #1
    @p1 v.sel        v5, v4, v7
    @p3 v.sel        v4, v8, v0
    v.movi       v0, #0
    v.movi       v7, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v8, s1
    v.shl        v10, v7, v2
    v.lshr       v11, v5, v8
    v.cmp.lt     p4, v7, v3
    v.and        v12, v11, v2
    v.shl        v11, v2, v8
    v.or         v8, v10, v12
    s.subi       s5, s1, #1
    v.cmp.geu    p5, v8, v4
    p.or         p6, p4, p5
    v.sub        v10, v8, v4
    @p6 v.sel        v12, v11, v3
    @p6 v.sel        v11, v10, v8
    v.or         v8, v0, v12
    v.mov        v7, v11
    v.mov        v0, v8
    s.mov        s1, s5
    s.movz       s5, #0
    s.cmp.ge     s6, s1, s5
    br.nz        s6, idiv_2
    p.xor        p4, p1, p3
    v.sub        v2, v3, v0
    v.movi       v3, #2048
    @p4 v.sel        v4, v2, v0
    v.mul        v0, v9, v3
    v.mul        v2, v4, v6
    s.shli       s1, s2, #1                      // element offset -> bytes (x2)
    v.add        v3, v1, v2
    s.add        s2, s4, s1                      // &out_ptr0[...]
    v.add        v1, v3, v0
    s.movz       s1, #32
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v0, [s3, v1]               // index is in elements (ISA sec 9.1)
    s.movz       s1, #2048
    vf.cvt.f32.f16 v1, v0
    @p2 v.st.h       [s2, #0], v1
__rctx_next:
    exit
