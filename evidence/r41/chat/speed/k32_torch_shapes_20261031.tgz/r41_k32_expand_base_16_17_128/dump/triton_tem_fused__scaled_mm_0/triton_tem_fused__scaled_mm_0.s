    s.rdspecial  s1, pid.x
    s.movz       s2, #0
    s.movz       s3, #2
    s.cmp.lt     s4, s1, s2
    s.cmp.lt     s5, s3, s2
    s.sub        s6, s2, s4
    s.sub        s4, s2, s5
    s.xor        s5, s1, s6
    s.xor        s7, s6, s4
    s.sub        s8, s5, s6
    s.movz       s9, #1
    s.lshri      s10, s8, #1
    s.rdspecial  s11, arg_base
    s.xor        s12, s10, s7
    s.muli       s13, s10, #2
    s.sub        s10, s12, s7
    s.xor        s7, s3, s4
    s.sub        s12, s9, s10
    s.sub        s14, s5, s6
    s.min.s      s5, s12, s9
    s.addi       s12, s2, #0
    s.cmp.lt     s15, s5, s2
    s.ld.d       s16, [s11, #0]                  // arg_A: device_ptr64 at arg_base+0
    s.sub        s17, s2, s15
    s.sub        s15, s7, s4
    s.xor        s4, s5, s17
    s.sub        s7, s8, s13
    s.sub        s7, s4, s17
    s.addi       s4, s2, #0
    s.cmp.eq     s8, s7, s9
    s.ld.d       s13, [s11, #8]                  // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s15, [s11, #16]                 // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s17, [s11, #24]                 // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s18, [s11, #32]                 // out_ptr0: device_ptr64 at arg_base+32
    s.mov        s12, s14
    br.nz        s8, sdiv_done_1
    s.movz       s8, #0
    s.movz       s11, #31
    s.mov        s12, s8
    s.addi       s8, s11, #0
sdiv_2:
    s.lshr       s11, s14, s8
    s.shli       s19, s4, #1
    s.andi       s20, s11, #1
    s.shl        s11, s9, s8
    s.or         s21, s19, s20
    s.subi       s19, s8, #1
    s.cmp.geu    s20, s21, s7
    s.sub        s22, s2, s20
    s.and        s20, s7, s22
    s.and        s23, s11, s22
    s.sub        s11, s21, s20
    s.or         s20, s12, s23
    s.mov        s4, s11
    s.mov        s12, s20
    s.mov        s8, s19
    s.cmp.ge     s11, s8, s2
    br.nz        s11, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.xor        s7, s4, s6
    s.cmp.lt     s4, s1, s2
    s.cmp.lt     s8, s5, s2
    s.sub        s11, s2, s4
    s.sub        s4, s2, s8
    s.xor        s8, s1, s11
    s.cmp.lt     s1, s3, s2
    s.sub        s12, s8, s11
    s.xor        s8, s5, s4
    s.lshri      s5, s12, #1
    s.sub        s14, s2, s1
    s.muli       s1, s5, #2
    s.sub        s5, s8, s4
    s.movz       s8, #1
    s.sub        s19, s7, s6
    s.xor        s6, s3, s14
    s.sub        s7, s12, s1
    s.addi       s1, s2, #0
    s.xor        s12, s7, s11
    s.cmp.eq     s7, s5, s8
    s.sub        s20, s12, s11
    s.add        s11, s10, s19
    s.cmp.lt     s10, s20, s2
    s.sub        s12, s6, s14
    s.sub        s6, s2, s10
    s.addi       s10, s2, #0
    s.xor        s12, s20, s6
    s.sub        s14, s12, s6
    s.mov        s1, s14
    br.nz        s7, sdiv_done_3
    s.movz       s7, #0
    s.movz       s12, #31
    s.mov        s1, s7
    s.addi       s7, s12, #0
sdiv_4:
    s.lshr       s12, s14, s7
    s.shli       s19, s10, #1
    s.andi       s20, s12, #1
    s.shl        s12, s8, s7
    s.or         s21, s19, s20
    s.subi       s19, s7, #1
    s.cmp.geu    s20, s21, s5
    s.sub        s22, s2, s20
    s.and        s20, s5, s22
    s.and        s23, s12, s22
    s.sub        s12, s21, s20
    s.or         s20, s1, s23
    s.mov        s10, s12
    s.mov        s1, s20
    s.mov        s7, s19
    s.cmp.ge     s12, s7, s2
    br.nz        s12, sdiv_4
sdiv_done_3:
    s.xor        s2, s6, s4
    s.movz       s4, #16
    s.xor        s5, s1, s2
    s.mul        s1, s11, s4
    s.sub        s6, s5, s2
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s6, s4
    v.movi       v1, #17
    v.movi       v2, #0
    s.movz       s5, #0
    s.andi       s7, s1, #15
    v.splat      v3, s2
    v.splat      v4, s11
    v.splat      v5, s5
    v.add        v6, v3, v0
    v.splat      v3, s6
    v.splat      v7, s1
    v.splat      v8, s7
    v.sub        v9, v2, v6
    v.cmp.lt     p1, v6, v2
    v.cmp.lt     p2, v1, v2
    v.cmp.ge     p3, v4, v5
    v.sub        v4, v2, v1
    v.cmp.ge     p3, v3, v5
    v.add        v3, v7, v0
    v.add        v3, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v3, v9, v6
    @p2 v.sel        v5, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s6, #31
idiv_5:
    v.splat      v6, s6
    v.shl        v7, v4, v0
    v.cmp.lt     p2, v4, v2
    v.lshr       v8, v3, v6
    v.shl        v9, v0, v6
    s.subi       s8, s6, #1
    v.and        v6, v8, v0
    v.or         v8, v7, v6
    v.cmp.geu    p3, v8, v5
    p.or         p4, p2, p3
    v.sub        v6, v8, v5
    @p4 v.sel        v7, v9, v2
    @p4 v.sel        v9, v6, v8
    v.or         v6, v1, v7
    v.mov        v4, v9
    v.mov        v1, v6
    s.mov        s6, s8
    s.cmp.ge     s8, s6, s5
    br.nz        s8, idiv_5
    v.sub        v0, v2, v4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #16
    v.movi       v3, #32
    v.movi       v5, #48
    @p1 v.sel        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v1, v3
    s.movz       s6, #32
    v.add        v0, v1, v5
    s.movz       s8, #48
    s.addi       s10, s5, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_6:
    s.cmp.ge     s11, s10, s3
    br.nz        s11, endfor_7
    s.movz       s11, #64
    s.mul        s12, s10, s11
    s.add        s11, s16, s12                   // the tile origin
    s.muli       s14, s7, #128                   // a runtime tile origin, x128
    s.add        s19, s11, s14                   // the tile origin
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.rdspecial  s11, arg_base
    s.ld.d       s14, [s11, #40]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s11, s14, #0
    v.ld.b       v0, [s19, #0]
    v.st.w       [s11, #0], v0
    s.addi       s20, s11, #64
    s.addi       s21, s19, #128                  // row 1
    v.ld.b       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s11, #128
    s.addi       s21, s19, #256                  // row 2
    v.ld.b       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s11, #192
    s.addi       s21, s19, #384                  // row 3
    v.ld.b       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s11, #256
    s.addi       s21, s19, #512                  // row 4
    v.ld.b       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s11, #320
    s.addi       s21, s19, #640                  // row 5
    v.ld.b       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s11, #384
    s.addi       s21, s19, #768                  // row 6
    v.ld.b       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s11, #448
    s.addi       s21, s19, #896                  // row 7
    v.ld.b       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s11, #512
    s.addi       s21, s19, #1024                 // row 8
    v.ld.b       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s11, #576
    s.addi       s21, s19, #1152                 // row 9
    v.ld.b       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s11, #640
    s.addi       s21, s19, #1280                 // row 10
    v.ld.b       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s11, #704
    s.addi       s21, s19, #1408                 // row 11
    v.ld.b       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s11, #768
    s.addi       s21, s19, #1536                 // row 12
    v.ld.b       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s11, #832
    s.addi       s21, s19, #1664                 // row 13
    v.ld.b       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s11, #896
    s.addi       s21, s19, #1792                 // row 14
    v.ld.b       v0, [s21, #0]
    v.st.w       [s20, #0], v0
    s.addi       s20, s11, #960
    s.addi       s11, s19, #1920                 // row 15
    v.ld.b       v0, [s11, #0]
    v.st.w       [s20, #0], v0
    fence.acq_rel.device
    s.add        s11, s16, s4                    // the tile origin
    s.add        s19, s11, s12                   // the tile origin
    s.muli       s11, s7, #128                   // a runtime tile origin, x128
    s.add        s20, s19, s11                   // the tile origin
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.addi       s11, s14, #1024
    v.ld.b       v0, [s20, #0]
    v.st.w       [s11, #0], v0
    s.addi       s19, s11, #64
    s.addi       s21, s20, #128                  // row 1
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #128
    s.addi       s21, s20, #256                  // row 2
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #192
    s.addi       s21, s20, #384                  // row 3
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #256
    s.addi       s21, s20, #512                  // row 4
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #320
    s.addi       s21, s20, #640                  // row 5
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #384
    s.addi       s21, s20, #768                  // row 6
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #448
    s.addi       s21, s20, #896                  // row 7
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #512
    s.addi       s21, s20, #1024                 // row 8
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #576
    s.addi       s21, s20, #1152                 // row 9
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #640
    s.addi       s21, s20, #1280                 // row 10
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #704
    s.addi       s21, s20, #1408                 // row 11
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #768
    s.addi       s21, s20, #1536                 // row 12
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #832
    s.addi       s21, s20, #1664                 // row 13
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #896
    s.addi       s21, s20, #1792                 // row 14
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #960
    s.addi       s11, s20, #1920                 // row 15
    v.ld.b       v0, [s11, #0]
    v.st.w       [s19, #0], v0
    fence.acq_rel.device
    s.add        s11, s16, s6                    // the tile origin
    s.add        s19, s11, s12                   // the tile origin
    s.muli       s11, s7, #128                   // a runtime tile origin, x128
    s.add        s20, s19, s11                   // the tile origin
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.addi       s11, s14, #2048
    v.ld.b       v0, [s20, #0]
    v.st.w       [s11, #0], v0
    s.addi       s19, s11, #64
    s.addi       s21, s20, #128                  // row 1
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #128
    s.addi       s21, s20, #256                  // row 2
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #192
    s.addi       s21, s20, #384                  // row 3
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #256
    s.addi       s21, s20, #512                  // row 4
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #320
    s.addi       s21, s20, #640                  // row 5
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #384
    s.addi       s21, s20, #768                  // row 6
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #448
    s.addi       s21, s20, #896                  // row 7
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #512
    s.addi       s21, s20, #1024                 // row 8
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #576
    s.addi       s21, s20, #1152                 // row 9
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #640
    s.addi       s21, s20, #1280                 // row 10
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #704
    s.addi       s21, s20, #1408                 // row 11
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #768
    s.addi       s21, s20, #1536                 // row 12
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #832
    s.addi       s21, s20, #1664                 // row 13
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #896
    s.addi       s21, s20, #1792                 // row 14
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #960
    s.addi       s11, s20, #1920                 // row 15
    v.ld.b       v0, [s11, #0]
    v.st.w       [s19, #0], v0
    fence.acq_rel.device
    s.add        s11, s16, s8                    // the tile origin
    s.add        s19, s11, s12                   // the tile origin
    s.muli       s11, s7, #128                   // a runtime tile origin, x128
    s.add        s20, s19, s11                   // the tile origin
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.addi       s11, s14, #3072
    v.ld.b       v0, [s20, #0]
    v.st.w       [s11, #0], v0
    s.addi       s19, s11, #64
    s.addi       s21, s20, #128                  // row 1
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #128
    s.addi       s21, s20, #256                  // row 2
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #192
    s.addi       s21, s20, #384                  // row 3
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #256
    s.addi       s21, s20, #512                  // row 4
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #320
    s.addi       s21, s20, #640                  // row 5
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #384
    s.addi       s21, s20, #768                  // row 6
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #448
    s.addi       s21, s20, #896                  // row 7
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #512
    s.addi       s21, s20, #1024                 // row 8
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #576
    s.addi       s21, s20, #1152                 // row 9
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #640
    s.addi       s21, s20, #1280                 // row 10
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #704
    s.addi       s21, s20, #1408                 // row 11
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #768
    s.addi       s21, s20, #1536                 // row 12
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #832
    s.addi       s21, s20, #1664                 // row 13
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #896
    s.addi       s21, s20, #1792                 // row 14
    v.ld.b       v0, [s21, #0]
    v.st.w       [s19, #0], v0
    s.addi       s19, s11, #960
    s.addi       s11, s20, #1920                 // row 15
    v.ld.b       v0, [s11, #0]
    v.st.w       [s19, #0], v0
    fence.acq_rel.device
    s.movz       s11, #128
    v.splat      v0, s11
    v.mul        v1, v6, v0
    s.addi       s11, s14, #4096
    v.st.w       [s11, #0], v1
    fence.acq_rel.device
    s.addi       s19, s14, #4160
    v.splat      v0, s5
    s.movz       s20, #0
    s.add        s21, s20, s12                   // the tile origin
    v.splat      v1, s21
    v.ld.w       v2, [s11, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s19, #0], v1
    s.addi       s20, s19, #64
    s.addi       s22, s21, #1
    v.splat      v1, s22
    v.ld.w       v2, [s11, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s19, #128
    s.addi       s22, s21, #2
    v.splat      v1, s22
    v.ld.w       v2, [s11, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s19, #192
    s.addi       s22, s21, #3
    v.splat      v1, s22
    v.ld.w       v2, [s11, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s19, #256
    s.addi       s22, s21, #4
    v.splat      v1, s22
    v.ld.w       v2, [s11, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s19, #320
    s.addi       s22, s21, #5
    v.splat      v1, s22
    v.ld.w       v2, [s11, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s19, #384
    s.addi       s22, s21, #6
    v.splat      v1, s22
    v.ld.w       v2, [s11, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s19, #448
    s.addi       s22, s21, #7
    v.splat      v1, s22
    v.ld.w       v2, [s11, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s11, s19, #512
    s.addi       s20, s21, #8
    v.splat      v1, s20
    s.addi       s20, s14, #4096
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s11, #0], v1
    s.addi       s11, s19, #576
    s.addi       s22, s21, #9
    v.splat      v1, s22
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s11, #0], v1
    s.addi       s11, s19, #640
    s.addi       s22, s21, #10
    v.splat      v1, s22
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s11, #0], v1
    s.addi       s11, s19, #704
    s.addi       s22, s21, #11
    v.splat      v1, s22
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s11, #0], v1
    s.addi       s11, s19, #768
    s.addi       s22, s21, #12
    v.splat      v1, s22
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s11, #0], v1
    s.addi       s11, s19, #832
    s.addi       s22, s21, #13
    v.splat      v1, s22
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s11, #0], v1
    s.addi       s11, s19, #896
    s.addi       s22, s21, #14
    v.splat      v1, s22
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s11, #0], v1
    s.addi       s11, s19, #960
    s.addi       s19, s21, #15
    v.splat      v1, s19
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s11, #0], v1
    fence.acq_rel.device
    s.addi       s11, s14, #5184
    v.splat      v0, s5
    s.movz       s19, #0
    s.add        s20, s19, s4                    // the tile origin
    s.add        s19, s20, s12                   // the tile origin
    v.splat      v1, s19
    s.addi       s20, s14, #4096
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s11, #0], v1
    s.addi       s21, s11, #64
    s.addi       s22, s19, #1
    v.splat      v1, s22
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s21, #0], v1
    s.addi       s21, s11, #128
    s.addi       s22, s19, #2
    v.splat      v1, s22
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s21, #0], v1
    s.addi       s21, s11, #192
    s.addi       s22, s19, #3
    v.splat      v1, s22
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s21, #0], v1
    s.addi       s21, s11, #256
    s.addi       s22, s19, #4
    v.splat      v1, s22
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s21, #0], v1
    s.addi       s21, s11, #320
    s.addi       s22, s19, #5
    v.splat      v1, s22
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s21, #0], v1
    s.addi       s21, s11, #384
    s.addi       s22, s19, #6
    v.splat      v1, s22
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s21, #0], v1
    s.addi       s21, s11, #448
    s.addi       s22, s19, #7
    v.splat      v1, s22
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s21, #0], v1
    s.addi       s21, s11, #512
    s.addi       s22, s19, #8
    v.splat      v1, s22
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s21, #0], v1
    s.addi       s20, s11, #576
    s.addi       s21, s19, #9
    v.splat      v1, s21
    s.addi       s21, s14, #4096
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #640
    s.addi       s22, s19, #10
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #704
    s.addi       s22, s19, #11
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #768
    s.addi       s22, s19, #12
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #832
    s.addi       s22, s19, #13
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #896
    s.addi       s22, s19, #14
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #960
    s.addi       s11, s19, #15
    v.splat      v1, s11
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    fence.acq_rel.device
    s.addi       s11, s14, #6208
    v.splat      v0, s5
    s.movz       s19, #0
    s.add        s20, s19, s6                    // the tile origin
    s.add        s19, s20, s12                   // the tile origin
    v.splat      v1, s19
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s11, #0], v1
    s.addi       s20, s11, #64
    s.addi       s21, s19, #1
    v.splat      v1, s21
    s.addi       s21, s14, #4096
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #128
    s.addi       s22, s19, #2
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #192
    s.addi       s22, s19, #3
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #256
    s.addi       s22, s19, #4
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #320
    s.addi       s22, s19, #5
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #384
    s.addi       s22, s19, #6
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #448
    s.addi       s22, s19, #7
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #512
    s.addi       s22, s19, #8
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #576
    s.addi       s22, s19, #9
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #640
    s.addi       s21, s19, #10
    v.splat      v1, s21
    s.addi       s21, s14, #4096
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #704
    s.addi       s22, s19, #11
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #768
    s.addi       s22, s19, #12
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #832
    s.addi       s22, s19, #13
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #896
    s.addi       s22, s19, #14
    v.splat      v1, s22
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    s.addi       s20, s11, #960
    s.addi       s11, s19, #15
    v.splat      v1, s11
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s20, #0], v1
    fence.acq_rel.device
    s.addi       s11, s14, #7232
    v.splat      v0, s5
    s.movz       s19, #0
    s.add        s20, s19, s8                    // the tile origin
    s.add        s19, s20, s12                   // the tile origin
    v.splat      v1, s19
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s11, #0], v1
    s.addi       s12, s11, #64
    s.addi       s20, s19, #1
    v.splat      v1, s20
    v.ld.w       v2, [s21, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #128
    s.addi       s20, s19, #2
    v.splat      v1, s20
    s.addi       s20, s14, #4096
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #192
    s.addi       s21, s19, #3
    v.splat      v1, s21
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #256
    s.addi       s21, s19, #4
    v.splat      v1, s21
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #320
    s.addi       s21, s19, #5
    v.splat      v1, s21
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #384
    s.addi       s21, s19, #6
    v.splat      v1, s21
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #448
    s.addi       s21, s19, #7
    v.splat      v1, s21
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #512
    s.addi       s21, s19, #8
    v.splat      v1, s21
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #576
    s.addi       s21, s19, #9
    v.splat      v1, s21
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #640
    s.addi       s21, s19, #10
    v.splat      v1, s21
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #704
    s.addi       s20, s19, #11
    v.splat      v1, s20
    s.addi       s20, s14, #4096
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #768
    s.addi       s21, s19, #12
    v.splat      v1, s21
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #832
    s.addi       s21, s19, #13
    v.splat      v1, s21
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #896
    s.addi       s21, s19, #14
    v.splat      v1, s21
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #960
    s.addi       s11, s19, #15
    v.splat      v1, s11
    v.ld.w       v2, [s20, #0]
    v.add        v3, v1, v2
    v.add        v1, v0, v3
    v.st.w       [s12, #0], v1
    fence.acq_rel.device
    s.addi       s11, s14, #8256
    s.addi       s12, s14, #4160
    v.ld.w       v0, [s12, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s11, #0], v1
    s.addi       s12, s11, #64
    s.addi       s19, s14, #4224
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #128
    s.addi       s19, s14, #4288
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #192
    s.addi       s19, s14, #4352
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #256
    s.addi       s19, s14, #4416
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #320
    s.addi       s19, s14, #4480
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #384
    s.addi       s19, s14, #4544
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #448
    s.addi       s19, s14, #4608
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #512
    s.addi       s19, s14, #4672
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #576
    s.addi       s19, s14, #4736
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #640
    s.addi       s19, s14, #4800
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #704
    s.addi       s19, s14, #4864
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #768
    s.addi       s19, s14, #4928
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #832
    s.addi       s19, s14, #4992
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #896
    s.addi       s19, s14, #5056
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #960
    s.addi       s11, s14, #5120
    v.ld.w       v0, [s11, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    fence.acq_rel.device
    s.addi       s11, s14, #9280
    s.addi       s12, s14, #5184
    v.ld.w       v0, [s12, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s11, #0], v1
    s.addi       s12, s11, #64
    s.addi       s19, s14, #5248
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #128
    s.addi       s19, s14, #5312
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #192
    s.addi       s19, s14, #5376
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #256
    s.addi       s19, s14, #5440
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #320
    s.addi       s19, s14, #5504
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #384
    s.addi       s19, s14, #5568
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #448
    s.addi       s19, s14, #5632
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #512
    s.addi       s19, s14, #5696
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #576
    s.addi       s19, s14, #5760
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #640
    s.addi       s19, s14, #5824
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #704
    s.addi       s19, s14, #5888
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #768
    s.addi       s19, s14, #5952
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #832
    s.addi       s19, s14, #6016
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #896
    s.addi       s19, s14, #6080
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #960
    s.addi       s11, s14, #6144
    v.ld.w       v0, [s11, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    fence.acq_rel.device
    s.addi       s11, s14, #10304
    s.addi       s12, s14, #6208
    v.ld.w       v0, [s12, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s11, #0], v1
    s.addi       s12, s11, #64
    s.addi       s19, s14, #6272
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #128
    s.addi       s19, s14, #6336
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #192
    s.addi       s19, s14, #6400
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #256
    s.addi       s19, s14, #6464
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #320
    s.addi       s19, s14, #6528
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #384
    s.addi       s19, s14, #6592
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #448
    s.addi       s19, s14, #6656
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #512
    s.addi       s19, s14, #6720
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #576
    s.addi       s19, s14, #6784
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #640
    s.addi       s19, s14, #6848
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #704
    s.addi       s19, s14, #6912
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #768
    s.addi       s19, s14, #6976
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #832
    s.addi       s19, s14, #7040
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #896
    s.addi       s19, s14, #7104
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #960
    s.addi       s11, s14, #7168
    v.ld.w       v0, [s11, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    fence.acq_rel.device
    s.addi       s11, s14, #11328
    s.addi       s12, s14, #7232
    v.ld.w       v0, [s12, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s11, #0], v1
    s.addi       s12, s11, #64
    s.addi       s19, s14, #7296
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #128
    s.addi       s19, s14, #7360
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #192
    s.addi       s19, s14, #7424
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #256
    s.addi       s19, s14, #7488
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #320
    s.addi       s19, s14, #7552
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #384
    s.addi       s19, s14, #7616
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #448
    s.addi       s19, s14, #7680
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #512
    s.addi       s19, s14, #7744
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #576
    s.addi       s19, s14, #7808
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #640
    s.addi       s19, s14, #7872
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #704
    s.addi       s19, s14, #7936
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #768
    s.addi       s19, s14, #8000
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #832
    s.addi       s19, s14, #8064
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #896
    s.addi       s19, s14, #8128
    v.ld.w       v0, [s19, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    s.addi       s12, s11, #960
    s.addi       s11, s14, #8192
    v.ld.w       v0, [s11, #0]
    v.ld.gather.b v1, [s13, v0]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v1
    fence.acq_rel.device
    s.addi       s11, s14, #12352                // 1024 bytes of repack scratch
    s.addi       s12, s14, #0
    v.ld.w       v0, [s12, #0]
    v.st.b       [s11, #0], v0
    s.addi       s12, s14, #64
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #64
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #128
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #128
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #192
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #192
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #256
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #256
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #320
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #320
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #384
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #384
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #448
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #448
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #512
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #512
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #576
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #576
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #640
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #640
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #704
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #704
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #768
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #768
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #832
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #832
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #896
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #896
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #960
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #960
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1024
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #16
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1088
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #80
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1152
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #144
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1216
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #208
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1280
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #272
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1344
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #336
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1408
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #400
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1472
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #464
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1536
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #528
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1600
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #592
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1664
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #656
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1728
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #720
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1792
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #784
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1856
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #848
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1920
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #912
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #1984
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #976
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2048
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #32
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2112
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #96
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2176
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #160
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2240
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #224
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2304
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #288
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2368
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #352
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2432
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #416
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2496
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #480
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2560
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #544
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2624
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #608
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2688
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #672
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2752
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #736
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2816
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #800
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2880
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #864
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #2944
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #928
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3008
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #992
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3072
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #48
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3136
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #112
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3200
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #176
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3264
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #240
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3328
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #304
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3392
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #368
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3456
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #432
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3520
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #496
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3584
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #560
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3648
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #624
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3712
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #688
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3776
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #752
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3840
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #816
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3904
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #880
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #3968
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #944
    v.st.b       [s12, #0], v0
    s.addi       s12, s14, #4032
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s11, #1008
    v.st.b       [s12, #0], v0
    fence.acq_rel.device
    s.addi       s12, s14, #13376                // TensorMap 0: K-wide matrix repack
    s.movz       s19, #0
    s.st.d       [s12, #0], s11
    s.movz       s11, #16
    s.st.d       [s12, #8], s11
    s.movz       s11, #64
    s.st.d       [s12, #16], s11
    s.st.d       [s12, #48], s11
    s.movz       s11, #1
    s.st.d       [s12, #56], s11
    .li       s11, #274877906960
    s.st.d       [s12, #88], s11
    .li       s11, #7705171329024
    s.st.d       [s12, #104], s11
    fence.release.device
    td.load      d0, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w0, #32, #16                    // v32..v47
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // K-wide matrix repack: one tile into a window (ISA sec 9E)
    s.mov        s20, s19                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s21, s19                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s20, s11
    mb.wait      s11
    s.addi       s12, s14, #13632                // 1024 bytes of repack scratch
    // repack 64x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s19, s14, #8256
    v.ld.w       v0, [s19, #0]
    v.st.b       [s12, #0], v0
    s.addi       s19, s14, #8320
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #16                   // row 1
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #8384
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #32                   // row 2
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #8448
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #48                   // row 3
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #8512
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #64                   // row 4
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #8576
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #80                   // row 5
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #8640
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #96                   // row 6
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #8704
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #112                  // row 7
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #8768
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #128                  // row 8
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #8832
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #144                  // row 9
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #8896
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #160                  // row 10
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #8960
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #176                  // row 11
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9024
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #192                  // row 12
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9088
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #208                  // row 13
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9152
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #224                  // row 14
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9216
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #240                  // row 15
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9280
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #256                  // row 16
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9344
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #272                  // row 17
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9408
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #288                  // row 18
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9472
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #304                  // row 19
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9536
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #320                  // row 20
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9600
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #336                  // row 21
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9664
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #352                  // row 22
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9728
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #368                  // row 23
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9792
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #384                  // row 24
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9856
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #400                  // row 25
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9920
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #416                  // row 26
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #9984
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #432                  // row 27
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10048
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #448                  // row 28
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10112
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #464                  // row 29
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10176
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #480                  // row 30
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10240
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #496                  // row 31
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10304
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #512                  // row 32
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10368
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #528                  // row 33
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10432
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #544                  // row 34
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10496
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #560                  // row 35
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10560
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #576                  // row 36
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10624
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #592                  // row 37
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10688
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #608                  // row 38
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10752
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #624                  // row 39
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10816
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #640                  // row 40
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10880
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #656                  // row 41
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #10944
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #672                  // row 42
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11008
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #688                  // row 43
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11072
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #704                  // row 44
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11136
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #720                  // row 45
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11200
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #736                  // row 46
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11264
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #752                  // row 47
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11328
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #768                  // row 48
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11392
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #784                  // row 49
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11456
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #800                  // row 50
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11520
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #816                  // row 51
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11584
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #832                  // row 52
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11648
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #848                  // row 53
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11712
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #864                  // row 54
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11776
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #880                  // row 55
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11840
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #896                  // row 56
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11904
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #912                  // row 57
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #11968
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #928                  // row 58
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #12032
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #944                  // row 59
    v.st.b       [s19, #0], v0
    s.addi       s19, s14, #12096
    v.ld.w       v0, [s19, #0]
    s.addi       s19, s12, #960                  // row 60
    v.st.b       [s19, #0], v0
    s.addi       s20, s14, #12160
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s12, #976                  // row 61
    v.st.b       [s20, #0], v0
    s.addi       s20, s14, #12224
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s12, #992                  // row 62
    v.st.b       [s20, #0], v0
    s.addi       s20, s14, #12288
    v.ld.w       v0, [s20, #0]
    s.addi       s14, s12, #1008                 // row 63
    v.st.b       [s14, #0], v0
    w.def        w1, #48, #16                    // v48..v63
    fence.acq_rel.device
    v.ld.w       v0, [s12, #0]
    v.mov        v48, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #64
    v.ld.w       v0, [s14, #0]
    v.mov        v49, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #128
    v.ld.w       v0, [s14, #0]
    v.mov        v50, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #192
    v.ld.w       v0, [s14, #0]
    v.mov        v51, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #256
    v.ld.w       v0, [s14, #0]
    v.mov        v52, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #320
    v.ld.w       v0, [s14, #0]
    v.mov        v53, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #384
    v.ld.w       v0, [s14, #0]
    v.mov        v54, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #448
    v.ld.w       v0, [s14, #0]
    v.mov        v55, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #512
    v.ld.w       v0, [s14, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #576
    v.ld.w       v0, [s14, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #640
    v.ld.w       v0, [s14, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #704
    v.ld.w       v0, [s14, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #768
    v.ld.w       v0, [s14, #0]
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #832
    v.ld.w       v0, [s14, #0]
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    s.addi       s14, s12, #896
    v.ld.w       v0, [s14, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s19, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s12, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k64.e4m3 a0, v32, v48, s12
    mb.wait      s12
    s.add        s14, s10, s9
    s.mov        s10, s14
    s.movz       s14, #1
    br.nz        s14, for_6
endfor_7:
    s.ld.w       s3, [s15, #0]                   // one element, not a vector
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s5, #0
    s.muli       s6, s2, #2                      // a runtime tile origin, x2
    s.add        s7, s5, s2                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s7
    s.add        s2, s5, s1                      // the tile origin
    s.movz       s7, #17
    s.muli       s8, s1, #34                     // a runtime tile origin, x34
    v.splat      v2, s2
    v.splat      v3, s4
    s.ld.w       s1, [s17, #0]                   // one element, not a vector
    v.splat      v4, s3
    a.vread      v5, a0, s5
    v.add        v6, v0, v1
    v.splat      v0, s7
    s.add        s3, s18, s6                     // the tile origin
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v6, v0
    s.add        s4, s3, s8                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s3, #1
    v.splat      v0, s1
    s.addi       s1, s2, #1
    s.addi       s5, s4, #34                     // row 1
    vf.mul       v1, v4, v0
    vf.mul       v2, v4, v0
    v.splat      v6, s1
    s.movz       s1, #2
    vf.mul       v7, v4, v0
    vf.mul       v8, v5, v1
    v.cmp.lt     p1, v6, v3
    p.and        p4, p1, p2
    s.addi       s6, s2, #2
    s.addi       s7, s4, #68                     // row 2
    vf.cvt.f32.bf16 v1, v8
    v.splat      v5, s6
    s.movz       s6, #3
    vf.mul       v6, v4, v0
    s.addi       s8, s2, #3
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a0, s3
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.mul       v5, v1, v2
    v.splat      v1, s8
    s.addi       s3, s4, #102                    // row 3
    s.movz       s8, #4
    vf.mul       v2, v4, v0
    vf.cvt.f32.bf16 v8, v5
    s.addi       s9, s2, #4
    s.addi       s10, s4, #136                   // row 4
    v.splat      v5, s9
    s.movz       s9, #5
    @p4 v.st.h       [s5, #0], v8
    a.vread      v8, a0, s1
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    vf.mul       v1, v8, v7
    vf.mul       v7, v4, v0
    s.addi       s1, s2, #5
    s.addi       s5, s4, #170                    // row 5
    v.splat      v8, s1
    vf.cvt.f32.bf16 v9, v1
    s.movz       s1, #6
    vf.mul       v1, v4, v0
    @p3 v.st.h       [s7, #0], v9
    a.vread      v9, a0, s6
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.mul       v5, v9, v6
    s.addi       s6, s2, #6
    s.addi       s7, s4, #204                    // row 6
    v.splat      v6, s6
    s.movz       s6, #7
    vf.cvt.f32.bf16 v9, v5
    vf.mul       v5, v4, v0
    @p4 v.st.h       [s3, #0], v9
    a.vread      v9, a0, s8
    v.cmp.lt     p1, v8, v3
    p.and        p4, p1, p2
    vf.mul       v8, v9, v2
    s.addi       s3, s2, #7
    s.addi       s8, s4, #238                    // row 7
    v.splat      v2, s3
    s.movz       s3, #8
    vf.cvt.f32.bf16 v9, v8
    vf.mul       v8, v4, v0
    @p3 v.st.h       [s10, #0], v9
    a.vread      v9, a0, s9
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.mul       v6, v9, v7
    s.addi       s9, s2, #8
    s.addi       s10, s4, #272                   // row 8
    v.splat      v7, s9
    s.movz       s9, #9
    vf.cvt.f32.bf16 v9, v6
    vf.mul       v6, v4, v0
    @p4 v.st.h       [s5, #0], v9
    a.vread      v9, a0, s1
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    vf.mul       v2, v9, v1
    s.addi       s1, s2, #9
    s.addi       s5, s4, #306                    // row 9
    v.splat      v1, s1
    s.movz       s1, #10
    vf.cvt.f32.bf16 v9, v2
    vf.mul       v2, v4, v0
    @p3 v.st.h       [s7, #0], v9
    a.vread      v9, a0, s6
    v.cmp.lt     p1, v7, v3
    p.and        p3, p1, p2
    vf.mul       v7, v9, v5
    s.addi       s6, s2, #10
    s.addi       s7, s4, #340                    // row 10
    v.splat      v5, s6
    s.movz       s6, #11
    vf.cvt.f32.bf16 v9, v7
    vf.mul       v7, v4, v0
    @p4 v.st.h       [s8, #0], v9
    a.vread      v9, a0, s3
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    vf.mul       v1, v9, v8
    s.addi       s3, s2, #11
    s.addi       s8, s4, #374                    // row 11
    v.splat      v8, s3
    s.movz       s3, #12
    vf.cvt.f32.bf16 v9, v1
    vf.mul       v1, v4, v0
    @p3 v.st.h       [s10, #0], v9
    a.vread      v9, a0, s9
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.mul       v5, v9, v6
    s.addi       s9, s2, #12
    s.addi       s10, s4, #408                   // row 12
    v.splat      v6, s9
    s.movz       s9, #13
    vf.cvt.f32.bf16 v9, v5
    vf.mul       v5, v4, v0
    @p4 v.st.h       [s5, #0], v9
    a.vread      v9, a0, s1
    v.cmp.lt     p1, v8, v3
    p.and        p4, p1, p2
    vf.mul       v8, v9, v2
    s.addi       s1, s2, #13
    s.addi       s5, s4, #442                    // row 13
    v.splat      v2, s1
    s.movz       s1, #14
    vf.cvt.f32.bf16 v9, v8
    vf.mul       v8, v4, v0
    vf.mul       v10, v4, v0
    @p3 v.st.h       [s7, #0], v9
    a.vread      v0, a0, s6
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.mul       v4, v0, v7
    s.addi       s6, s2, #14
    s.addi       s7, s4, #476                    // row 14
    v.splat      v0, s6
    s.movz       s6, #15
    vf.cvt.f32.bf16 v6, v4
    s.addi       s13, s2, #15
    s.addi       s2, s4, #510                    // row 15
    v.splat      v4, s13
    @p4 v.st.h       [s8, #0], v6
    a.vread      v6, a0, s3
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    vf.mul       v2, v6, v1
    vf.cvt.f32.bf16 v1, v2
    @p3 v.st.h       [s10, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    vf.mul       v0, v1, v5
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s5, #0], v1
    a.vread      v0, a0, s1
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    vf.mul       v1, v0, v8
    vf.cvt.f32.bf16 v0, v1
    @p3 v.st.h       [s7, #0], v0
    a.vread      v0, a0, s6
    vf.mul       v1, v0, v10
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s2, #0], v0
    exit
    exit
