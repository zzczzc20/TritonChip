    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #4
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #2
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s1, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s6, #0
    s.cmp.lt     s8, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s8
    s.sub        s8, s6, s9
    s.xor        s6, s12, s3
    s.muli       s9, s5, #4
    s.movz       s5, #0
    s.movz       s11, #1
    s.xor        s13, s4, s8
    s.sub        s14, s6, s3
    s.rdspecial  s3, arg_base
    s.xor        s6, s1, s7
    s.movz       s15, #0
    s.sub        s16, s13, s8
    s.addi       s13, s5, #0
    s.cmp.eq     s5, s14, s11
    s.ld.d       s11, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s17, s6, s7
    s.sub        s6, s2, s9
    s.addi       s2, s15, #0
    s.ld.d       s6, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s7, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s13, s16
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s13, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s16, s3
    s.shli       s9, s2, #1
    s.andi       s15, s5, #1
    s.movz       s5, #0
    s.or         s17, s9, s15
    s.movz       s9, #1
    s.cmp.geu    s15, s17, s14
    s.shl        s18, s9, s3
    s.sub        s9, s5, s15
    s.subi       s5, s3, #1
    s.and        s15, s14, s9
    s.and        s19, s18, s9
    s.sub        s9, s17, s15
    s.or         s15, s13, s19
    s.mov        s2, s9
    s.mov        s13, s15
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s3, s5
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s3
    s.movz       s3, #0
    s.sub        s13, s5, s9
    s.movz       s5, #0
    s.xor        s9, s4, s13
    s.movz       s4, #0
    s.sub        s14, s9, s13
    s.cmp.lt     s9, s12, s3
    s.lshri      s3, s14, #2
    s.movz       s15, #0
    s.muli       s16, s3, #4
    s.sub        s3, s4, s9
    s.movz       s4, #0
    s.cmp.lt     s9, s1, s15
    s.xor        s15, s12, s3
    s.sub        s12, s14, s16
    s.movz       s14, #0
    s.xor        s16, s12, s13
    s.xor        s12, s2, s8
    s.sub        s2, s16, s13
    s.sub        s13, s14, s9
    s.cmp.lt     s9, s2, s5
    s.sub        s5, s15, s3
    s.sub        s14, s4, s9
    s.movz       s4, #0
    s.xor        s9, s2, s14
    s.movz       s2, #1
    s.sub        s15, s12, s8
    s.xor        s8, s1, s13
    s.sub        s1, s9, s14
    s.movz       s9, #0
    s.addi       s12, s4, #0
    s.cmp.eq     s4, s5, s2
    s.add        s2, s10, s15
    s.sub        s10, s8, s13
    s.addi       s8, s9, #0
    s.mov        s12, s1
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s9, #31
    s.mov        s12, s4
    s.addi       s4, s9, #0
sdiv_4:
    s.lshr       s9, s1, s4
    s.shli       s10, s8, #1
    s.andi       s13, s9, #1
    s.movz       s9, #0
    s.or         s15, s10, s13
    s.movz       s10, #1
    s.cmp.geu    s13, s15, s5
    s.shl        s16, s10, s4
    s.sub        s10, s9, s13
    s.subi       s9, s4, #1
    s.and        s13, s5, s10
    s.and        s17, s16, s10
    s.sub        s10, s15, s13
    s.or         s13, s12, s17
    s.mov        s8, s10
    s.mov        s12, s13
    s.mov        s4, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s4, s9
    br.nz        s10, sdiv_4
sdiv_done_3:
    s.movz       s1, #16
    s.rdspecial  s4, pid.z
    s.rdspecial  s5, npid.y
    s.xor        s8, s14, s3
    s.mul        s3, s2, s1
    s.mul        s9, s4, s5
    s.xor        s4, s12, s8
    s.rdspecial  s5, pid.y
    s.sub        s10, s4, s8
    s.andi       s4, s3, #63
    s.mul        s8, s10, s1
    s.add        s12, s5, s9
    s.movz       s5, #15
    s.rdspecial  s9, arg_base
    s.min.s      s13, s12, s5
    s.movz       s5, #2048
    s.ld.d       s14, [s9, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.muli       s9, s4, #32                     // a runtime tile origin, x32
    s.mul        s15, s13, s5
    s.andi       s5, s8, #63
    s.movz       s13, #0
    s.rdspecial  s16, role_id
    s.movz       s17, #9728
    s.add        s18, s13, s9                    // the tile origin
    s.mul        s9, s16, s17
    s.add        s13, s18, s15                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s13
    s.movz       s16, #0
    s.add        s17, s14, s9                    // this context's own scratch
    v.splat      v2, s2
    s.addi       s2, s17, #0
    v.splat      v3, s16
    s.addi       s9, s13, #32
    v.splat      v4, s10
    v.splat      v5, s16
    v.add        v6, v0, v1
    s.addi       s10, s2, #64
    v.cmp.ge     p1, v2, v3
    v.splat      v1, s9
    v.iota       v2                              // arange(0, VLEN)
    v.cmp.ge     p1, v4, v5
    s.addi       s9, s13, #64
    v.splat      v3, s3
    v.splat      v4, s9
    v.add        v5, v0, v1
    s.addi       s9, s2, #128
    v.add        v1, v0, v4
    v.add        v4, v3, v2
    s.addi       s14, s13, #96
    v.splat      v3, s8
    s.addi       s18, s2, #192
    s.movz       s19, #32
    v.add        v4, v3, v2
    v.splat      v2, s14
    v.splat      v3, s4
    s.addi       s4, s2, #256
    v.add        v4, v0, v2
    s.addi       s14, s16, #0
    v.st.w       [s2, #0], v6
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s16, s13, #128
    v.add        v6, v3, v2
    v.splat      v2, s16
    v.splat      v3, s5
    v.add        v6, v0, v2
    v.st.w       [s10, #0], v5
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s10, s2, #320
    v.add        v5, v3, v2
    s.addi       s16, s13, #160
    s.addi       s20, s13, #192
    v.splat      v2, s16
    s.addi       s16, s13, #224
    v.splat      v3, s20
    s.addi       s20, s13, #256
    v.add        v5, v0, v2
    v.add        v2, v0, v3
    v.st.w       [s9, #0], v1
    s.addi       s9, s13, #288
    v.splat      v1, s16
    s.addi       s16, s13, #320
    v.add        v3, v0, v1
    v.st.w       [s18, #0], v4
    s.addi       s18, s13, #352
    v.splat      v1, s20
    s.addi       s20, s13, #384
    v.add        v4, v0, v1
    v.st.w       [s4, #0], v6
    s.addi       s4, s13, #416
    v.splat      v1, s9
    s.addi       s9, s13, #448
    s.addi       s21, s13, #480
    v.add        v6, v0, v1
    v.st.w       [s10, #0], v5
    v.splat      v1, s16
    s.addi       s10, s2, #384
    s.addi       s13, s17, #1024
    v.add        v5, v0, v1
    v.st.w       [s10, #0], v2
    s.movz       s10, #0
    v.splat      v1, s18
    s.addi       s16, s2, #448
    s.add        s18, s10, s5                    // the tile origin
    v.add        v2, v0, v1
    s.add        s5, s18, s15                    // the tile origin
    s.addi       s10, s2, #512
    s.addi       s15, s2, #576
    v.st.w       [s16, #0], v3
    s.addi       s16, s5, #64
    v.splat      v1, s20
    s.addi       s18, s2, #640
    v.add        v3, v0, v1
    v.st.w       [s10, #0], v4
    s.addi       s10, s5, #128
    v.splat      v1, s4
    s.addi       s4, s2, #704
    v.add        v4, v0, v1
    v.st.w       [s15, #0], v6
    s.addi       s15, s5, #192
    v.splat      v1, s9
    s.addi       s9, s2, #768
    v.add        v6, v0, v1
    v.st.w       [s18, #0], v5
    s.addi       s18, s5, #256
    v.splat      v1, s21
    s.addi       s20, s2, #832
    v.add        v5, v0, v1
    v.st.w       [s4, #0], v2
    s.addi       s4, s5, #320
    v.splat      v1, s5
    v.add        v2, v0, v1
    v.st.w       [s9, #0], v3
    s.addi       s9, s5, #384
    v.splat      v1, s16
    s.addi       s16, s2, #896
    s.addi       s21, s2, #960
    v.add        v3, v0, v1
    v.st.w       [s20, #0], v4
    s.addi       s2, s5, #448
    v.splat      v1, s10
    s.addi       s10, s13, #64
    v.add        v4, v0, v1
    v.st.w       [s16, #0], v6
    s.addi       s16, s5, #512
    v.splat      v1, s15
    s.addi       s15, s13, #128
    v.add        v6, v0, v1
    v.st.w       [s21, #0], v5
    v.splat      v1, s18
    s.addi       s18, s13, #192
    s.addi       s20, s13, #256
    v.add        v5, v0, v1
    fence.acq_rel.device
    v.st.w       [s13, #0], v2
    v.splat      v1, s4
    s.addi       s4, s5, #576
    v.add        v2, v0, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s5, #640
    v.splat      v1, s9
    s.addi       s9, s5, #704
    v.add        v3, v0, v1
    v.st.w       [s15, #0], v4
    s.addi       s15, s5, #768
    v.splat      v1, s2
    s.addi       s2, s5, #832
    v.add        v4, v0, v1
    v.st.w       [s18, #0], v6
    s.addi       s18, s5, #896
    v.splat      v1, s16
    s.addi       s16, s13, #320
    v.add        v6, v0, v1
    v.st.w       [s20, #0], v5
    s.addi       s20, s5, #960
    v.splat      v1, s4
    s.addi       s4, s13, #384
    s.addi       s5, s13, #448
    v.add        v5, v0, v1
    v.st.w       [s16, #0], v2
    v.splat      v1, s10
    s.addi       s10, s13, #512
    s.addi       s16, s13, #576
    v.add        v2, v0, v1
    v.st.w       [s4, #0], v3
    v.splat      v1, s9
    s.addi       s4, s13, #640
    s.addi       s9, s13, #704
    v.add        v3, v0, v1
    v.st.w       [s5, #0], v4
    v.splat      v1, s15
    s.addi       s5, s13, #768
    s.addi       s15, s13, #832
    v.add        v4, v0, v1
    v.st.w       [s10, #0], v6
    v.splat      v1, s2
    s.addi       s2, s13, #896
    s.addi       s10, s13, #960
    v.add        v6, v0, v1
    v.st.w       [s16, #0], v5
    v.splat      v1, s18
    v.add        v5, v0, v1
    v.st.w       [s4, #0], v2
    v.splat      v1, s20
    v.add        v2, v0, v1
    v.st.w       [s9, #0], v3
    v.st.w       [s5, #0], v4
    v.st.w       [s15, #0], v6
    v.st.w       [s2, #0], v5
    v.st.w       [s10, #0], v2
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s2, s14, s19
    br.nz        s2, endfor_6
    s.addi       s2, s17, #0
    s.addi       s4, s17, #2048
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s17, #64
    s.addi       s5, s4, #64
    s.addi       s9, s17, #128
    s.addi       s10, s4, #128
    s.addi       s13, s17, #192
    s.addi       s15, s4, #192
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v2
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s17, #256
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s4, #256
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s17, #320
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s4, #320
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s17, #384
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s4, #384
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s17, #448
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s4, #448
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s17, #512
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s4, #512
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s17, #576
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s4, #576
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s17, #640
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s4, #640
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s17, #704
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s4, #704
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s17, #768
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s4, #768
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s17, #832
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s4, #832
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s17, #896
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s4, #896
    s.addi       s16, s4, #960
    v.ld.w       v1, [s13, #0]
    s.addi       s4, s17, #960
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s13, s17, #1024
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s17, #3072
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s17, #1088
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s2, #64
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s17, #1152
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s2, #128
    v.ld.gather.h v2, [s11, v1]                  // index is in elements (ISA sec 9.1)
    s.addi       s15, s17, #1216
    v.st.w       [s16, #0], v2
    fence.acq_rel.device
    s.addi       s16, s2, #192
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s17, #1280
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s2, #0], v2
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s2, #256
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v2
    s.addi       s9, s17, #1344
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s2, #320
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v2
    s.addi       s4, s17, #1408
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s2, #384
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s17, #1472
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s2, #448
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s5, s17, #1536
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s2, #512
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s10, s17, #1600
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s2, #576
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s17, #1664
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s2, #640
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s13, #0], v2
    s.addi       s13, s17, #1728
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s2, #704
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s9, #0], v2
    s.addi       s9, s17, #1792
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s2, #768
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s4, #0], v2
    s.addi       s4, s17, #1856
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s2, #832
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v2
    s.addi       s16, s17, #1920
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s2, #896
    s.addi       s18, s2, #960
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s5, #0], v2
    s.addi       s2, s17, #1984
    v.ld.w       v1, [s9, #0]
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s5, s17, #2048
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v2
    s.addi       s9, s17, #4096                  // 512 bytes of repack scratch
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #2112
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s10, s9, #32                    // row 1
    v.ld.w       v1, [s16, #0]
    s.addi       s15, s17, #2176
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s13, #0], v2
    s.addi       s13, s9, #64                    // row 2
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s17, #2240
    v.ld.gather.h v2, [s6, v1]                   // index is in elements (ISA sec 9.1)
    s.addi       s16, s9, #96                    // row 3
    v.st.w       [s18, #0], v2
    fence.acq_rel.device
    s.addi       s18, s17, #2304
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s9, #128                    // row 4
    v.st.h       [s9, #0], v1
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #2368
    v.st.h       [s10, #0], v1
    s.addi       s10, s9, #160                   // row 5
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #2432
    v.st.h       [s13, #0], v1
    s.addi       s13, s9, #192                   // row 6
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s17, #2496
    v.st.h       [s16, #0], v1
    s.addi       s16, s9, #224                   // row 7
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s17, #2560
    s.movz       s20, #0
    v.st.h       [s5, #0], v1
    s.addi       s5, s9, #256                    // row 8
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #2624
    v.st.h       [s10, #0], v1
    s.addi       s10, s9, #288                   // row 9
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #2688
    v.st.h       [s13, #0], v1
    s.addi       s13, s9, #320                   // row 10
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s17, #2752
    v.st.h       [s16, #0], v1
    s.addi       s16, s9, #352                   // row 11
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s17, #2816
    v.st.h       [s5, #0], v1
    s.addi       s5, s9, #384                    // row 12
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #2880
    v.st.h       [s10, #0], v1
    s.addi       s10, s9, #416                   // row 13
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #2944
    v.st.h       [s13, #0], v1
    s.addi       s13, s9, #448                   // row 14
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s17, #3008
    v.st.h       [s16, #0], v1
    s.addi       s16, s9, #480                   // row 15
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s17, #4608                 // TensorMap 0: a repacked tile
    v.st.h       [s5, #0], v1
    s.movz       s5, #16
    v.ld.w       v1, [s4, #0]
    s.movz       s4, #16
    v.st.h       [s10, #0], v1
    s.movz       s10, #32
    v.ld.w       v1, [s15, #0]
    s.movz       s15, #2
    v.st.h       [s13, #0], v1
    .li       s13, #68719476752
    v.ld.w       v1, [s2, #0]
    .li       s2, #8589934592
    v.st.h       [s16, #0], v1
    s.movz       s16, #0
    s.st.d       [s18, #0], s9
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s9, s17, #3072
    s.st.d       [s18, #8], s5
    s.addi       s5, s17, #4864                  // 512 bytes of repack scratch
    s.st.d       [s18, #16], s4
    s.addi       s4, s17, #3136
    s.st.d       [s18, #48], s10
    s.addi       s10, s5, #32                    // row 1
    s.st.d       [s18, #56], s15
    s.addi       s15, s17, #3200
    s.st.d       [s18, #88], s13
    s.addi       s13, s5, #64                    // row 2
    s.st.d       [s18, #104], s2
    fence.release.device
    td.load      d0, [s18]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s2, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.addi       s18, s17, #3264
    s.addi       s20, s5, #96                    // row 3
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s21, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s22, s16                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s21, s2
    mb.wait      s2
    s.addi       s16, s17, #3328
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s5, #128                    // row 4
    v.st.h       [s5, #0], v1
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #3392
    v.st.h       [s10, #0], v1
    s.addi       s10, s5, #160                   // row 5
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #3456
    v.st.h       [s13, #0], v1
    s.addi       s13, s5, #192                   // row 6
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s17, #3520
    v.st.h       [s20, #0], v1
    s.addi       s20, s5, #224                   // row 7
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s17, #3584
    s.movz       s21, #0
    v.st.h       [s9, #0], v1
    s.addi       s9, s5, #256                    // row 8
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #3648
    v.st.h       [s10, #0], v1
    s.addi       s10, s5, #288                   // row 9
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #3712
    v.st.h       [s13, #0], v1
    s.addi       s13, s5, #320                   // row 10
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s17, #3776
    v.st.h       [s20, #0], v1
    s.addi       s20, s5, #352                   // row 11
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s17, #3840
    v.st.h       [s9, #0], v1
    s.addi       s9, s5, #384                    // row 12
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #3904
    v.st.h       [s10, #0], v1
    s.addi       s10, s5, #416                   // row 13
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #3968
    v.st.h       [s13, #0], v1
    s.addi       s13, s5, #448                   // row 14
    v.splat      v1, s1
    v.ld.w       v2, [s18, #0]
    s.addi       s18, s17, #4032
    v.st.h       [s20, #0], v2
    s.addi       s20, s5, #480                   // row 15
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s17, #5376                 // TensorMap 1: a repacked tile
    v.st.h       [s9, #0], v2
    s.movz       s9, #16
    v.ld.w       v2, [s4, #0]
    s.movz       s4, #16
    v.st.h       [s10, #0], v2
    s.movz       s10, #32
    v.ld.w       v2, [s15, #0]
    s.movz       s15, #2
    v.st.h       [s13, #0], v2
    .li       s13, #68719476752
    v.ld.w       v2, [s18, #0]
    .li       s18, #8589934592
    v.st.h       [s20, #0], v2
    s.movz       s20, #0
    s.st.d       [s16, #0], s5
    s.addi       s5, s17, #0
    s.st.d       [s16, #8], s9
    s.addi       s9, s17, #5632
    s.st.d       [s16, #16], s4
    s.addi       s4, s17, #64
    s.st.d       [s16, #48], s10
    s.addi       s10, s9, #64
    s.st.d       [s16, #56], s15
    s.addi       s15, s17, #128
    s.st.d       [s16, #88], s13
    s.addi       s13, s9, #128
    s.st.d       [s16, #104], s18
    fence.release.device
    td.load      d1, [s16]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s16, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s18, s17, #192
    s.addi       s21, s9, #192
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s22, s20                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s23, s20                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s22, s16
    mb.wait      s16
    mb.arm       s20, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s22, s17, #256
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s20
    mb.wait      s20
    v.ld.w       v2, [s5, #0]
    s.addi       s5, s9, #256
    v.add        v3, v2, v1
    v.st.w       [s9, #0], v3
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s17, #320
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s9, #320
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s17, #384
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s9, #384
    v.ld.w       v2, [s18, #0]
    s.addi       s18, s17, #448
    v.add        v3, v2, v1
    v.st.w       [s21, #0], v3
    s.addi       s21, s9, #448
    v.ld.w       v2, [s22, #0]
    s.addi       s22, s17, #512
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    s.addi       s5, s9, #512
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s17, #576
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s9, #576
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s17, #640
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s9, #640
    v.ld.w       v2, [s18, #0]
    s.addi       s18, s17, #704
    v.add        v3, v2, v1
    v.st.w       [s21, #0], v3
    s.addi       s21, s9, #704
    v.ld.w       v2, [s22, #0]
    s.addi       s22, s17, #768
    v.add        v3, v2, v1
    v.st.w       [s5, #0], v3
    s.addi       s5, s9, #768
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s17, #832
    v.add        v3, v2, v1
    v.st.w       [s10, #0], v3
    s.addi       s10, s9, #832
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s17, #896
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    s.addi       s13, s9, #896
    s.addi       s23, s9, #960
    v.ld.w       v2, [s18, #0]
    s.addi       s9, s17, #960
    v.add        v3, v2, v1
    v.st.w       [s21, #0], v3
    s.addi       s18, s17, #1024
    v.ld.w       v2, [s22, #0]
    s.movz       s21, #1024
    v.splat      v3, s21
    s.addi       s21, s17, #6656
    v.add        v4, v2, v1
    v.st.w       [s5, #0], v4
    s.addi       s5, s17, #1088
    v.ld.w       v2, [s4, #0]
    s.addi       s4, s21, #64
    v.add        v4, v2, v1
    v.st.w       [s10, #0], v4
    s.addi       s10, s17, #1152
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s21, #128
    v.add        v4, v2, v1
    v.st.w       [s13, #0], v4
    s.addi       s13, s17, #1216
    v.ld.w       v2, [s9, #0]
    s.addi       s9, s21, #192
    v.add        v4, v2, v1
    v.st.w       [s23, #0], v4
    fence.acq_rel.device
    s.addi       s22, s17, #1280
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s21, #256
    v.add        v2, v1, v3
    v.st.w       [s21, #0], v2
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #1344
    v.add        v2, v1, v3
    v.st.w       [s4, #0], v2
    s.addi       s4, s21, #320
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #1408
    v.add        v2, v1, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s21, #384
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s17, #1472
    v.add        v2, v1, v3
    v.st.w       [s9, #0], v2
    s.addi       s9, s21, #448
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #1536
    v.add        v2, v1, v3
    v.st.w       [s18, #0], v2
    s.addi       s18, s21, #512
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #1600
    v.add        v2, v1, v3
    v.st.w       [s4, #0], v2
    s.addi       s4, s21, #576
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #1664
    v.add        v2, v1, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s21, #640
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s17, #1728
    v.add        v2, v1, v3
    v.st.w       [s9, #0], v2
    s.addi       s9, s21, #704
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #1792
    v.add        v2, v1, v3
    v.st.w       [s18, #0], v2
    s.addi       s18, s21, #768
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #1856
    v.add        v2, v1, v3
    v.st.w       [s4, #0], v2
    s.addi       s4, s21, #832
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #1920
    v.add        v2, v1, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s21, #896
    s.addi       s23, s21, #960
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s17, #1984
    v.add        v2, v1, v3
    v.st.w       [s9, #0], v2
    s.addi       s9, s17, #5632
    v.ld.w       v1, [s22, #0]
    s.addi       s21, s17, #7680
    v.add        v2, v1, v3
    v.st.w       [s18, #0], v2
    s.addi       s18, s17, #5696
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s21, #64
    v.add        v2, v1, v3
    v.st.w       [s4, #0], v2
    s.addi       s4, s17, #5760
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s21, #128
    v.add        v2, v1, v3
    v.st.w       [s15, #0], v2
    s.addi       s15, s17, #5824
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s21, #192
    v.add        v2, v1, v3
    v.st.w       [s23, #0], v2
    fence.acq_rel.device
    s.addi       s22, s17, #5888
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s21, #256
    v.st.w       [s21, #0], v1
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s17, #5952
    v.st.w       [s5, #0], v1
    s.addi       s5, s21, #320
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #6016
    v.st.w       [s10, #0], v1
    s.addi       s10, s21, #384
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #6080
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #448
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #6144
    v.st.w       [s9, #0], v1
    s.addi       s9, s21, #512
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s17, #6208
    v.st.w       [s5, #0], v1
    s.addi       s5, s21, #576
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #6272
    v.st.w       [s10, #0], v1
    s.addi       s10, s21, #640
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #6336
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #704
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #6400
    v.st.w       [s9, #0], v1
    s.addi       s9, s21, #768
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s17, #6464
    v.st.w       [s5, #0], v1
    s.addi       s5, s21, #832
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #6528
    v.st.w       [s10, #0], v1
    s.addi       s10, s21, #896
    s.addi       s23, s21, #960
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #6592
    v.st.w       [s13, #0], v1
    s.addi       s13, s17, #6656
    v.ld.w       v1, [s22, #0]
    s.addi       s21, s17, #8704
    v.st.w       [s9, #0], v1
    s.addi       s9, s17, #6720
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s21, #64
    v.st.w       [s5, #0], v1
    s.addi       s5, s17, #6784
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s21, #128
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #6848
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s21, #192
    v.st.w       [s23, #0], v1
    fence.acq_rel.device
    s.addi       s22, s17, #6912
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s21, #256
    v.st.w       [s21, #0], v1
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s17, #6976
    v.st.w       [s18, #0], v1
    s.addi       s18, s21, #320
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #7040
    v.st.w       [s4, #0], v1
    s.addi       s4, s21, #384
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #7104
    v.st.w       [s15, #0], v1
    s.addi       s15, s21, #448
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #7168
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #512
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s17, #7232
    v.st.w       [s18, #0], v1
    s.addi       s18, s21, #576
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #7296
    v.st.w       [s4, #0], v1
    s.addi       s4, s21, #640
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #7360
    v.st.w       [s15, #0], v1
    s.addi       s15, s21, #704
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #7424
    v.st.w       [s13, #0], v1
    s.addi       s13, s21, #768
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s17, #7488
    v.st.w       [s18, #0], v1
    s.addi       s18, s21, #832
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #7552
    v.st.w       [s4, #0], v1
    s.addi       s4, s21, #896
    s.addi       s23, s21, #960
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #7616
    v.st.w       [s15, #0], v1
    s.addi       s15, s17, #7680
    v.ld.w       v1, [s22, #0]
    s.addi       s21, s17, #0
    v.st.w       [s13, #0], v1
    s.addi       s13, s17, #7744
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s17, #64
    v.st.w       [s18, #0], v1
    s.addi       s18, s17, #7808
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #128
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #7872
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #192
    v.st.w       [s23, #0], v1
    fence.acq_rel.device
    s.addi       s22, s17, #7936
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #256
    v.st.w       [s21, #0], v1
    s.addi       s21, s17, #8000
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s17, #320
    v.st.w       [s9, #0], v1
    s.addi       s9, s17, #8064
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s17, #384
    v.st.w       [s5, #0], v1
    s.addi       s5, s17, #8128
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #448
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #8192
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #512
    v.st.w       [s15, #0], v1
    s.addi       s15, s17, #8256
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s17, #576
    v.st.w       [s13, #0], v1
    s.addi       s13, s17, #8320
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s17, #640
    v.st.w       [s18, #0], v1
    s.addi       s18, s17, #8384
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #704
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #8448
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #768
    v.st.w       [s22, #0], v1
    s.addi       s22, s17, #8512
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #832
    v.st.w       [s21, #0], v1
    s.addi       s21, s17, #8576
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s17, #896
    v.st.w       [s9, #0], v1
    s.addi       s9, s17, #8640
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s17, #960
    v.st.w       [s5, #0], v1
    s.addi       s5, s17, #8704
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #1024
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #8768
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #1088
    v.st.w       [s15, #0], v1
    s.addi       s15, s17, #8832
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s17, #1152
    v.st.w       [s13, #0], v1
    s.addi       s13, s17, #8896
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s17, #1216
    v.st.w       [s18, #0], v1
    fence.acq_rel.device
    s.addi       s18, s17, #8960
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #1280
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #9024
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #1344
    v.st.w       [s22, #0], v1
    s.addi       s22, s17, #9088
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #1408
    v.st.w       [s21, #0], v1
    s.addi       s21, s17, #9152
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s17, #1472
    v.st.w       [s9, #0], v1
    s.addi       s9, s17, #9216
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s17, #1536
    v.st.w       [s5, #0], v1
    s.addi       s5, s17, #9280
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s17, #1600
    v.st.w       [s10, #0], v1
    s.addi       s10, s17, #9344
    v.ld.w       v1, [s22, #0]
    s.addi       s22, s17, #1664
    v.st.w       [s15, #0], v1
    s.addi       s15, s17, #9408
    v.ld.w       v1, [s21, #0]
    s.addi       s21, s17, #1728
    v.st.w       [s13, #0], v1
    s.addi       s13, s17, #9472
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s17, #1792
    v.st.w       [s18, #0], v1
    s.addi       s18, s17, #9536
    v.ld.w       v1, [s5, #0]
    s.addi       s5, s17, #1856
    v.st.w       [s4, #0], v1
    s.addi       s4, s17, #9600
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s17, #1920
    v.st.w       [s22, #0], v1
    s.addi       s22, s17, #9664
    s.addi       s23, s17, #1984
    v.ld.w       v1, [s15, #0]
    s.add        s15, s14, s1
    v.st.w       [s21, #0], v1
    s.movz       s21, #1
    v.ld.w       v1, [s13, #0]
    v.st.w       [s9, #0], v1
    v.ld.w       v1, [s18, #0]
    v.st.w       [s5, #0], v1
    v.ld.w       v1, [s4, #0]
    v.st.w       [s10, #0], v1
    v.ld.w       v1, [s22, #0]
    v.st.w       [s23, #0], v1
    fence.acq_rel.device
    s.mov        s14, s15
    br.nz        s21, for_5
endfor_6:
    s.movz       s4, #0
    s.movz       s5, #4096
    s.add        s6, s4, s8                      // the tile origin
    s.mul        s4, s12, s5
    s.movz       s5, #0
    s.muli       s9, s8, #2                      // a runtime tile origin, x2
    v.splat      v1, s6
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s6, #0
    s.add        s8, s5, s3                      // the tile origin
    s.movz       s5, #64
    s.muli       s10, s3, #128                   // a runtime tile origin, x128
    a.vread      v2, a0, s6
    v.splat      v3, s8
    v.splat      v4, s5
    v.add        v5, v0, v1
    v.splat      v0, s5
    s.muli       s3, s4, #2                      // a runtime tile origin, x2
    v.splat      v1, s12
    v.splat      v6, s1
    s.add        s1, s7, s9                      // the tile origin
    vf.cvt.f32.f16 v7, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s4, s1, s10                     // the tile origin
    p.and        p3, p1, p2
    v.cmp.lt     p1, v1, v6
    s.add        s1, s4, s3                      // the tile origin
    p.and        p4, p3, p1
    s.movz       s3, #1
    s.addi       s4, s8, #1
    @p4 v.st.h       [s1, #0], v7
    a.vread      v0, a0, s3
    v.splat      v1, s4
    s.addi       s3, s1, #128                    // row 1
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p3, v1, v4
    p.and        p4, p3, p2
    s.movz       s4, #2
    p.and        p3, p4, p1
    s.addi       s5, s8, #2
    s.addi       s6, s1, #256                    // row 2
    v.splat      v0, s5
    s.movz       s5, #3
    s.addi       s7, s8, #3
    @p3 v.st.h       [s3, #0], v2
    a.vread      v1, a0, s4
    v.cmp.lt     p3, v0, v4
    p.and        p4, p3, p2
    vf.cvt.f32.f16 v0, v1
    p.and        p3, p4, p1
    v.splat      v1, s7
    s.addi       s3, s1, #384                    // row 3
    s.movz       s4, #4
    v.cmp.lt     p4, v1, v4
    p.and        p5, p4, p2
    s.addi       s7, s8, #4
    p.and        p4, p5, p1
    v.splat      v1, s7
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v1, v0
    s.addi       s5, s1, #512                    // row 4
    p.and        p3, p5, p1
    s.movz       s6, #5
    s.addi       s7, s8, #5
    s.addi       s9, s1, #640                    // row 5
    v.splat      v0, s7
    s.movz       s7, #6
    s.addi       s10, s8, #6
    @p4 v.st.h       [s3, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p4, v0, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v0, v1
    p.and        p4, p5, p1
    v.splat      v1, s10
    s.addi       s3, s1, #768                    // row 6
    s.movz       s4, #7
    s.addi       s10, s8, #7
    v.splat      v2, s10
    s.addi       s10, s1, #896                   // row 7
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s6
    v.cmp.lt     p3, v1, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v1, v0
    p.and        p3, p5, p1
    s.movz       s5, #8
    s.addi       s6, s8, #8
    v.splat      v0, s6
    s.addi       s6, s1, #1024                   // row 8
    @p4 v.st.h       [s9, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p4, v2, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v2, v1
    p.and        p4, p5, p1
    s.movz       s7, #9
    s.addi       s9, s8, #9
    v.splat      v1, s9
    s.addi       s9, s1, #1152                   // row 9
    @p3 v.st.h       [s3, #0], v2
    a.vread      v2, a0, s4
    v.cmp.lt     p3, v0, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v0, v2
    p.and        p3, p5, p1
    s.movz       s3, #10
    s.addi       s4, s8, #10
    v.splat      v2, s4
    s.addi       s4, s1, #1280                   // row 10
    @p4 v.st.h       [s10, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p4, v1, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v1, v0
    p.and        p4, p5, p1
    s.movz       s5, #11
    s.addi       s10, s8, #11
    v.splat      v0, s10
    s.addi       s10, s1, #1408                  // row 11
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a0, s7
    v.cmp.lt     p3, v2, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v2, v1
    p.and        p3, p5, p1
    s.movz       s6, #12
    s.addi       s7, s8, #12
    v.splat      v1, s7
    s.addi       s7, s1, #1536                   // row 12
    @p4 v.st.h       [s9, #0], v2
    a.vread      v2, a0, s3
    v.cmp.lt     p4, v0, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v0, v2
    p.and        p4, p5, p1
    s.movz       s3, #13
    s.addi       s9, s8, #13
    v.splat      v2, s9
    s.addi       s9, s1, #1664                   // row 13
    @p3 v.st.h       [s4, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p3, v1, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v1, v0
    p.and        p3, p5, p1
    s.movz       s4, #14
    s.addi       s5, s8, #14
    s.addi       s11, s8, #15
    v.splat      v0, s5
    s.addi       s5, s1, #1792                   // row 14
    v.splat      v3, s11
    s.movz       s8, #15
    s.addi       s11, s1, #1920                  // row 15
    @p4 v.st.h       [s10, #0], v1
    a.vread      v1, a0, s6
    v.cmp.lt     p4, v2, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v2, v1
    p.and        p4, p5, p1
    @p3 v.st.h       [s7, #0], v2
    a.vread      v1, a0, s3
    v.cmp.lt     p3, v0, v4
    p.and        p5, p3, p2
    vf.cvt.f32.f16 v0, v1
    p.and        p3, p5, p1
    @p4 v.st.h       [s9, #0], v0
    a.vread      v0, a0, s4
    v.cmp.lt     p4, v3, v4
    p.and        p5, p4, p2
    vf.cvt.f32.f16 v1, v0
    p.and        p2, p5, p1
    @p3 v.st.h       [s5, #0], v1
    a.vread      v0, a0, s8
    vf.cvt.f32.f16 v1, v0
    @p2 v.st.h       [s11, #0], v1
__rctx_next:
    exit
