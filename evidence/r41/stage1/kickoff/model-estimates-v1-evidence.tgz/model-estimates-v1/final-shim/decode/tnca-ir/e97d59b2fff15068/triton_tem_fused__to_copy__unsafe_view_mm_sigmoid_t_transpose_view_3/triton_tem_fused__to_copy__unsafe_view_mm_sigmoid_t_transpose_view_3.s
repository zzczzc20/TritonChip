    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #1024
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: a tile contiguous down its columns (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s6, #0], s3
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    .li       s1, #2147483647
    s.st.d       [s6, #16], s1
    s.movz       s1, #4096
    s.st.d       [s6, #48], s1
    s.movz       s1, #2
    s.st.d       [s6, #56], s1
    .li       s1, #68719476752
    s.st.d       [s6, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #1
    s.movz       s3, #0
    s.movz       s6, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.movz       s10, #0
    s.movz       s11, #1
    s.sub        s12, s1, s4
    s.min.s      s13, s12, s1
    s.cmp.lt     s12, s4, s6
    s.sub        s6, s3, s12
    s.cmp.lt     s3, s13, s8
    s.sub        s8, s7, s3
    s.xor        s3, s4, s6
    s.sub        s7, s3, s6
    s.xor        s3, s13, s8
    s.sub        s12, s3, s8
    s.addi       s3, s9, #0
    s.addi       s8, s10, #0
    s.cmp.eq     s9, s12, s11
    s.mov        s3, s7
    br.nz        s9, sdiv_done_1
    s.movz       s9, #0
    s.movz       s10, #31
    s.mov        s3, s9
    s.addi       s9, s10, #0
sdiv_2:
    s.lshr       s10, s7, s9
    s.shli       s11, s8, #1
    s.andi       s14, s10, #1
    s.movz       s10, #0
    s.or         s15, s11, s14
    s.movz       s11, #1
    s.cmp.geu    s14, s15, s12
    s.shl        s16, s11, s9
    s.sub        s11, s10, s14
    s.subi       s10, s9, #1
    s.and        s14, s12, s11
    s.and        s17, s16, s11
    s.sub        s11, s15, s14
    s.or         s14, s3, s17
    s.mov        s8, s11
    s.mov        s3, s14
    s.mov        s9, s10
    s.movz       s10, #0
    s.cmp.ge     s11, s9, s10
    br.nz        s11, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s7, #0
    s.movz       s9, #0
    s.movz       s10, #0
    s.cmp.lt     s11, s13, s3
    s.movz       s3, #0
    s.cmp.lt     s12, s7, s9
    s.sub        s9, s10, s11
    s.sub        s10, s3, s12
    s.xor        s3, s13, s9
    s.xor        s11, s8, s6
    s.xor        s8, s7, s10
    s.sub        s12, s3, s9
    s.movz       s3, #0
    s.movz       s13, #1
    s.sub        s14, s11, s6
    s.sub        s6, s8, s10
    s.movz       s8, #0
    s.addi       s11, s3, #0
    s.cmp.eq     s3, s12, s13
    s.add        s13, s4, s14
    s.addi       s4, s8, #0
    s.mov        s11, s6
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s8, #31
    s.mov        s11, s3
    s.addi       s3, s8, #0
sdiv_4:
    s.lshr       s8, s6, s3
    s.shli       s14, s4, #1
    s.andi       s15, s8, #1
    s.movz       s8, #0
    s.or         s16, s14, s15
    s.movz       s14, #1
    s.cmp.geu    s15, s16, s12
    s.shl        s17, s14, s3
    s.sub        s14, s8, s15
    s.subi       s8, s3, #1
    s.and        s15, s12, s14
    s.and        s18, s17, s14
    s.sub        s14, s16, s15
    s.or         s15, s11, s18
    s.mov        s4, s14
    s.mov        s11, s15
    s.mov        s3, s8
    s.movz       s8, #0
    s.cmp.ge     s14, s3, s8
    br.nz        s14, sdiv_4
sdiv_done_3:
    s.xor        s3, s10, s9
    s.movz       s4, #16
    s.xor        s6, s11, s3
    v.splat      v0, s13
    s.sub        s8, s6, s3
    v.splat      v1, s7
    s.mul        s3, s8, s4
    v.splat      v2, s8
    v.splat      v3, s7
    v.iota       v4                              // arange(0, VLEN)
    v.iota       v5                              // arange(0, VLEN)
    s.andi       s6, s3, #15
    v.splat      v6, s3
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s6
    v.cmp.ge     p1, v2, v3
    v.add        v1, v6, v4
    v.add        v1, v0, v5
    s.movz       s8, #128
    s.addi       s9, s7, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s7, s9, s8
    br.nz        s7, endfor_6
    s.mul        s7, s9, s4
    s.muli       s10, s7, #2                     // a runtime tile origin, x2
    s.add        s11, s2, s10                    // the tile origin
    v.ld.h       v0, [s11, #0]
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s10, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s11, s6                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s12, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w0, d0, s11, s10
    mb.wait      s10
    s.rdspecial  s7, arg_base
    s.ld.d       s11, [s7, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s7, role_id
    s.movz       s12, #1024
    s.mul        s14, s7, s12
    s.add        s7, s11, s14                    // this context's own scratch
    s.addi       s11, s7, #256                   // 512 bytes of repack scratch
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    v.st.h       [s11, #0], v0
    s.addi       s12, s11, #32                   // row 1
    v.st.h       [s12, #0], v0
    s.addi       s12, s11, #64                   // row 2
    v.st.h       [s12, #0], v0
    s.addi       s12, s11, #96                   // row 3
    v.st.h       [s12, #0], v0
    s.addi       s12, s11, #128                  // row 4
    v.st.h       [s12, #0], v0
    s.addi       s12, s11, #160                  // row 5
    v.st.h       [s12, #0], v0
    s.addi       s12, s11, #192                  // row 6
    v.st.h       [s12, #0], v0
    s.addi       s12, s11, #224                  // row 7
    v.st.h       [s12, #0], v0
    s.addi       s12, s11, #256                  // row 8
    v.st.h       [s12, #0], v0
    s.addi       s12, s11, #288                  // row 9
    v.st.h       [s12, #0], v0
    s.addi       s12, s11, #320                  // row 10
    v.st.h       [s12, #0], v0
    s.addi       s12, s11, #352                  // row 11
    v.st.h       [s12, #0], v0
    s.addi       s12, s11, #384                  // row 12
    v.st.h       [s12, #0], v0
    s.addi       s12, s11, #416                  // row 13
    v.st.h       [s12, #0], v0
    s.addi       s12, s11, #448                  // row 14
    v.st.h       [s12, #0], v0
    s.addi       s12, s11, #480                  // row 15
    v.st.h       [s12, #0], v0
    s.addi       s12, s7, #768                   // TensorMap 1: a repacked tile
    s.movz       s7, #0
    s.st.d       [s12, #0], s11
    s.movz       s7, #16
    s.st.d       [s12, #8], s7
    s.movz       s7, #16
    s.st.d       [s12, #16], s7
    s.movz       s7, #32
    s.st.d       [s12, #48], s7
    s.movz       s7, #2
    s.st.d       [s12, #56], s7
    .li       s7, #68719476752
    s.st.d       [s12, #88], s7
    .li       s7, #1108101562368
    s.st.d       [s12, #104], s7
    fence.release.device
    td.load      d1, [s12]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s7, #0
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s11, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s14, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s14, s11
    mb.wait      s11
    mb.arm       s7, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v48, v56, s7
    mb.wait      s7
    s.add        s12, s9, s1
    s.mov        s9, s12
    s.movz       s12, #1
    br.nz        s12, for_5
endfor_6:
    s.mul        s2, s13, s4
    v.splat      v0, s2
    v.add        v1, v0, v4
    .li       s6, #1065353216
    v.splat      v0, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s6, #1065353216
    v.splat      v1, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s6, s3, #4                      // a runtime tile origin, x4
    s.add        s8, s5, s6                      // the tile origin
    s.muli       s5, s2, #64                     // a runtime tile origin, x64
    s.add        s6, s8, s5                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s5, #0
    a.vread      v2, a0, s5
    vf.cvt.f32.bf16 v3, v2
    vf.cvt.bf16.f32 v2, v3
    vf.neg       v3, v2
    .li       s5, #1069066811
    v.splat      v2, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v4, v3, v2
    vf.fms       v5, v3, v2, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v3, v4                         // ISA 8.8: <= 2**-22 relative
    .li       s5, #1060205080
    v.splat      v4, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v6, v5, v4
    vf.fma       v5, v3, v6, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v6, v5, v3
    vf.add       v3, v6, v0
    v.rcp.approx v5, v3                          // ISA 8.8: <= 2**-22 relative
    .li       s5, #1065353216
    v.splat      v6, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v7, v3, v5, v6
    vf.fms       v3, v5, v7, v5
    vf.neg       v7, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v7, v7
    @p1 v.sel        v3, v7, v5
    vf.mul       v5, v1, v3                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s5, #0
    s.add        s8, s5, s2                      // the tile origin
    v.splat      v3, s8
    v.splat      v7, s1
    v.cmp.lt     p1, v3, v7
    v.movi       v3, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v3, v8
    v.extract    s1, v9, #0
    v.splat      v3, s1
    v.movi       v8, #0
    v.cmp.ne     p1, v3, v8
    s.movz       s1, #0
    s.add        s2, s1, s3                      // the tile origin
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v8, s2
    v.add        v9, v3, v8
    v.splat      v3, s4
    v.cmp.lt     p2, v9, v3
    p.and        p3, p1, p2
    @p3 v.st.w       [s6, #0], v5
    s.movz       s1, #1
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v5, v3, v8, v3
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    vf.mul       v3, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #64                     // row 1
    s.addi       s2, s8, #1
    v.splat      v5, s2
    v.cmp.lt     p1, v5, v7
    v.movi       v5, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v5, v8
    v.extract    s2, v9, #0
    v.splat      v5, s2
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v8
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v3
    s.movz       s1, #2
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v5, v3, v8, v3
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    vf.mul       v3, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #128                    // row 2
    s.addi       s2, s8, #2
    v.splat      v5, s2
    v.cmp.lt     p1, v5, v7
    v.movi       v5, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v5, v8
    v.extract    s2, v9, #0
    v.splat      v5, s2
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v8
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v3
    s.movz       s1, #3
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v5, v3, v8, v3
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    vf.mul       v3, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #192                    // row 3
    s.addi       s2, s8, #3
    v.splat      v5, s2
    v.cmp.lt     p1, v5, v7
    v.movi       v5, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v5, v8
    v.extract    s2, v9, #0
    v.splat      v5, s2
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v8
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v3
    s.movz       s1, #4
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v5, v3, v8, v3
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    vf.mul       v3, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #256                    // row 4
    s.addi       s2, s8, #4
    v.splat      v5, s2
    v.cmp.lt     p1, v5, v7
    v.movi       v5, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v5, v8
    v.extract    s2, v9, #0
    v.splat      v5, s2
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v8
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v3
    s.movz       s1, #5
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v5, v3, v8, v3
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    vf.mul       v3, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #320                    // row 5
    s.addi       s2, s8, #5
    v.splat      v5, s2
    v.cmp.lt     p1, v5, v7
    v.movi       v5, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v5, v8
    v.extract    s2, v9, #0
    v.splat      v5, s2
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v8
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v3
    s.movz       s1, #6
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v5, v3, v8, v3
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    vf.mul       v3, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #384                    // row 6
    s.addi       s2, s8, #6
    v.splat      v5, s2
    v.cmp.lt     p1, v5, v7
    v.movi       v5, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v5, v8
    v.extract    s2, v9, #0
    v.splat      v5, s2
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v8
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v3
    s.movz       s1, #7
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v5, v3, v8, v3
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    vf.mul       v3, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #448                    // row 7
    s.addi       s2, s8, #7
    v.splat      v5, s2
    v.cmp.lt     p1, v5, v7
    v.movi       v5, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v5, v8
    v.extract    s2, v9, #0
    v.splat      v5, s2
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v8
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v3
    s.movz       s1, #8
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v5, v3, v8, v3
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    vf.mul       v3, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #512                    // row 8
    s.addi       s2, s8, #8
    v.splat      v5, s2
    v.cmp.lt     p1, v5, v7
    v.movi       v5, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v5, v8
    v.extract    s2, v9, #0
    v.splat      v5, s2
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v8
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v3
    s.movz       s1, #9
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v5, v3, v8, v3
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    vf.mul       v3, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #576                    // row 9
    s.addi       s2, s8, #9
    v.splat      v5, s2
    v.cmp.lt     p1, v5, v7
    v.movi       v5, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v5, v8
    v.extract    s2, v9, #0
    v.splat      v5, s2
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v8
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v3
    s.movz       s1, #10
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v5, v3, v8, v3
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    vf.mul       v3, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #640                    // row 10
    s.addi       s2, s8, #10
    v.splat      v5, s2
    v.cmp.lt     p1, v5, v7
    v.movi       v5, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v5, v8
    v.extract    s2, v9, #0
    v.splat      v5, s2
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v8
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v3
    s.movz       s1, #11
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v5, v3, v8, v3
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    vf.mul       v3, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #704                    // row 11
    s.addi       s2, s8, #11
    v.splat      v5, s2
    v.cmp.lt     p1, v5, v7
    v.movi       v5, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v5, v8
    v.extract    s2, v9, #0
    v.splat      v5, s2
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v8
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v3
    s.movz       s1, #12
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v5, v3, v8, v3
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    vf.mul       v3, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #768                    // row 12
    s.addi       s2, s8, #12
    v.splat      v5, s2
    v.cmp.lt     p1, v5, v7
    v.movi       v5, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v5, v8
    v.extract    s2, v9, #0
    v.splat      v5, s2
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v8
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v3
    s.movz       s1, #13
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v5, v3, v8, v3
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    vf.mul       v3, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #832                    // row 13
    s.addi       s2, s8, #13
    v.splat      v5, s2
    v.cmp.lt     p1, v5, v7
    v.movi       v5, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v5, v8
    v.extract    s2, v9, #0
    v.splat      v5, s2
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v8
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v3
    s.movz       s1, #14
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v5, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v8, v5, v3, v5                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v3, v8, v5
    vf.add       v5, v3, v0
    v.rcp.approx v3, v5                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v5, v3, v6
    vf.fms       v5, v3, v8, v3
    vf.neg       v8, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v5, v8, v3
    vf.mul       v3, v1, v5                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #896                    // row 14
    s.addi       s2, s8, #14
    v.splat      v5, s2
    v.cmp.lt     p1, v5, v7
    v.movi       v5, #1
    v.movi       v8, #0
    @p1 v.sel        v9, v5, v8
    v.extract    s2, v9, #0
    v.splat      v5, s2
    v.movi       v8, #0
    v.cmp.ne     p1, v5, v8
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v3
    s.movz       s1, #15
    a.vread      v3, a0, s1
    vf.cvt.f32.bf16 v5, v3
    vf.cvt.bf16.f32 v3, v5
    vf.neg       v5, v3
    vf.mul       v3, v5, v2
    vf.fms       v8, v5, v2, v3                  // the exact rounding error of x*log2(e)
    v.exp2.approx v2, v3                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v8, v4
    vf.fma       v4, v2, v3, v2                  // 2**t * 2**d
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v2
    vf.add       v2, v3, v0
    v.rcp.approx v0, v2                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v2, v0, v6
    vf.fms       v2, v0, v3, v0
    vf.neg       v3, v2                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v2, v3, v0
    vf.mul       v0, v1, v2                      // a/y as a refined reciprocal (ISA has no divide)
    s.addi       s1, s6, #960                    // row 15
    s.addi       s2, s8, #15
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v7
    v.movi       v1, #1
    v.movi       v2, #0
    @p1 v.sel        v3, v1, v2
    v.extract    s2, v3, #0
    v.splat      v1, s2
    v.movi       v2, #0
    v.cmp.ne     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.w       [s1, #0], v0
__rctx_next:
    exit
