    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #6
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v0, v4
    @p1 v.sel        v7, v5, v4
    v.cmp.lt     p2, v4, v0
    @p2 v.sel        v5, v6, v4
    v.lshr       v6, v7, v3
    v.movi       v3, #63
    s.rdspecial  s2, arg_base
    v.sub        v7, v2, v6
    v.and        v8, v5, v3
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p1 v.sel        v3, v7, v6
    v.movi       v5, #63
    v.sub        v6, v0, v8
    v.sub        v7, v1, v3
    v.cmp.lt     p1, v3, v1
    @p2 v.sel        v9, v6, v8
    @p1 v.sel        v6, v7, v3
    v.movi       v7, #64
    s.movz       s4, #1
    s.movz       s5, #1
    s.ld.d       s6, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.and        v8, v6, v5
    s.movz       s2, #1
    s.movz       s7, #1
    v.movi       v5, #0
    v.sub        v6, v1, v8
    s.movz       s8, #1
    v.cmp.lt     p2, v4, v5
    @p1 v.sel        v10, v6, v8
    s.movz       s9, #1
    s.movz       s10, #1
    v.sub        v6, v5, v4
    s.movz       s11, #1
    s.movz       s12, #1
    @p2 v.sel        v8, v6, v4
    s.movz       s13, #1
    s.movz       s14, #1
    v.movi       v4, #12
    s.movz       s15, #1
    v.sub        v6, v9, v10
    v.lshr       v10, v8, v4
    v.ld.gather.w v4, [s3, v3]                   // index is in elements (ISA sec 9.1)
    v.movi       v3, #4096
    v.sub        v8, v5, v10
    v.sub        v11, v0, v7
    v.cmp.lt     p1, v7, v0
    @p2 v.sel        v0, v8, v10
    v.extract    s16, v6, #0
    v.movi       v8, #0
    v.mul        v10, v0, v7
    s.shli       s17, s16, #32
    v.movi       v0, #0
    v.add        v12, v9, v10
    v.sub        v9, v2, v7
    v.cmp.lt     p2, v7, v2
    v.sub        v2, v1, v7
    v.cmp.lt     p3, v7, v1
    v.sub        v1, v5, v3
    @p1 v.sel        v10, v11, v7
    v.extract    s16, v6, #1
    s.ashri      s18, s17, #32
    s.shli       s17, s16, #32
    s.lshri      s16, s18, #32
    v.extract    s19, v6, #2
    s.ashri      s20, s17, #32
    v.ld.gather.w v10, [s3, v12]                 // index is in elements (ISA sec 9.1)
    v.insert     v8, s18, #0
    v.insert     v0, s16, #0
    s.lshri      s3, s20, #32
    v.insert     v8, s20, #1
    v.insert     v0, s3, #1
    v.cmp.lt     p1, v3, v5
    @p2 v.sel        v5, v9, v7
    s.shli       s3, s19, #32
    v.extract    s16, v6, #3
    s.ashri      s17, s3, #32
    s.shli       s3, s16, #32
    s.lshri      s16, s17, #32
    s.ashri      s18, s3, #32
    v.insert     v8, s17, #2
    v.insert     v0, s16, #2
    s.lshri      s3, s18, #32
    v.insert     v8, s18, #3
    v.insert     v0, s3, #3
    @p3 v.sel        v5, v2, v7
    v.extract    s3, v6, #4
    v.extract    s16, v6, #5
    s.shli       s17, s3, #32
    s.shli       s3, s16, #32
    s.ashri      s16, s17, #32
    s.ashri      s17, s3, #32
    s.lshri      s3, s16, #32
    v.insert     v8, s16, #4
    v.insert     v0, s3, #4
    s.lshri      s3, s17, #32
    v.insert     v8, s17, #5
    v.insert     v0, s3, #5
    @p1 v.sel        v2, v1, v3
    v.extract    s3, v6, #6
    v.extract    s16, v6, #7
    s.shli       s17, s3, #32
    s.shli       s3, s16, #32
    s.ashri      s16, s17, #32
    v.extract    s17, v6, #8
    s.lshri      s18, s16, #32
    s.ashri      s19, s3, #32
    v.insert     v8, s16, #6
    v.insert     v0, s18, #6
    s.shli       s3, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v6, #9
    s.ashri      s18, s3, #32
    v.insert     v8, s19, #7
    v.insert     v0, s16, #7
    s.shli       s3, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v6, #10
    s.ashri      s19, s3, #32
    v.insert     v8, s18, #8
    v.insert     v0, s16, #8
    s.shli       s3, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v6, #11
    s.ashri      s18, s3, #32
    v.insert     v8, s19, #9
    v.insert     v0, s16, #9
    s.shli       s3, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v6, #12
    s.ashri      s19, s3, #32
    v.insert     v8, s18, #10
    v.insert     v0, s16, #10
    s.shli       s3, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v6, #13
    s.ashri      s18, s3, #32
    v.insert     v8, s19, #11
    v.insert     v0, s16, #11
    s.shli       s3, s17, #32
    s.lshri      s16, s18, #32
    v.extract    s17, v6, #14
    s.ashri      s19, s3, #32
    v.insert     v8, s18, #12
    v.insert     v0, s16, #12
    s.shli       s3, s17, #32
    s.lshri      s16, s19, #32
    v.extract    s17, v6, #15
    s.ashri      s18, s3, #32
    v.insert     v8, s19, #13
    v.insert     v0, s16, #13
    s.shli       s3, s17, #32
    s.lshri      s16, s18, #32
    s.ashri      s17, s3, #32
    v.insert     v8, s18, #14
    v.insert     v0, s16, #14
    s.lshri      s3, s17, #32
    v.insert     v8, s17, #15
    v.insert     v0, s3, #15
    v.movi       v1, #0
    v.extract    s3, v8, #0
    v.extract    s16, v0, #0
    v.extract    s17, v0, #1
    s.shli       s18, s16, #32
    v.extract    s16, v8, #1
    s.or         s19, s3, s18
    s.shli       s3, s17, #32
    s.cmp.ge     s17, s19, s4
    v.extract    s18, v0, #2
    s.or         s19, s16, s3
    v.insert     v1, s17, #0
    v.extract    s3, v8, #2
    s.shli       s16, s18, #32
    s.cmp.ge     s17, s19, s4
    v.extract    s18, v0, #3
    s.or         s19, s3, s16
    v.insert     v1, s17, #1
    v.extract    s3, v8, #3
    s.shli       s16, s18, #32
    s.cmp.ge     s17, s19, s4
    v.extract    s18, v0, #4
    s.or         s19, s3, s16
    v.insert     v1, s17, #2
    v.extract    s3, v8, #4
    s.shli       s16, s18, #32
    s.cmp.ge     s17, s19, s4
    v.extract    s18, v0, #5
    s.or         s19, s3, s16
    v.insert     v1, s17, #3
    v.extract    s3, v8, #5
    s.shli       s16, s18, #32
    s.cmp.ge     s17, s19, s4
    v.extract    s4, v0, #6
    s.or         s18, s3, s16
    v.insert     v1, s17, #4
    v.extract    s3, v8, #6
    s.shli       s16, s4, #32
    s.cmp.ge     s4, s18, s5
    v.extract    s5, v0, #7
    s.or         s17, s3, s16
    v.insert     v1, s4, #5
    v.extract    s3, v8, #7
    s.shli       s4, s5, #32
    s.cmp.ge     s5, s17, s2
    v.extract    s2, v0, #8
    s.or         s16, s3, s4
    v.insert     v1, s5, #6
    v.extract    s3, v8, #8
    s.shli       s4, s2, #32
    s.cmp.ge     s2, s16, s7
    v.extract    s5, v0, #9
    s.or         s7, s3, s4
    v.insert     v1, s2, #7
    v.extract    s2, v8, #9
    s.shli       s3, s5, #32
    s.cmp.ge     s4, s7, s8
    v.extract    s5, v0, #10
    s.or         s7, s2, s3
    v.insert     v1, s4, #8
    v.extract    s2, v8, #10
    s.shli       s3, s5, #32
    s.cmp.ge     s4, s7, s9
    v.extract    s5, v0, #11
    s.or         s7, s2, s3
    v.insert     v1, s4, #9
    v.extract    s2, v8, #11
    s.shli       s3, s5, #32
    s.cmp.ge     s4, s7, s10
    v.extract    s5, v0, #12
    s.or         s7, s2, s3
    v.insert     v1, s4, #10
    v.extract    s2, v8, #12
    s.shli       s3, s5, #32
    s.cmp.ge     s4, s7, s11
    v.extract    s5, v0, #13
    s.or         s7, s2, s3
    v.insert     v1, s4, #11
    v.extract    s2, v8, #13
    s.shli       s3, s5, #32
    s.cmp.ge     s4, s7, s12
    v.extract    s5, v0, #14
    s.or         s7, s2, s3
    v.insert     v1, s4, #12
    v.extract    s2, v8, #14
    s.shli       s3, s5, #32
    s.cmp.ge     s4, s7, s13
    v.extract    s5, v0, #15
    s.or         s7, s2, s3
    v.insert     v1, s4, #13
    v.extract    s2, v8, #15
    s.shli       s3, s5, #32
    s.cmp.ge     s4, s7, s14
    s.or         s5, s2, s3
    v.insert     v1, s4, #14
    s.cmp.ge     s2, s5, s15
    vf.sub       v0, v4, v10
    v.insert     v1, s2, #15
    v.movi       v2, #0
    .li       s2, #4286578688
    v.splat      v3, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1069066811
    v.splat      v4, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p1, v1, v2
    @p1 v.sel        v1, v3, v0
    .li       s2, #1060205080
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    vf.mul       v2, v1, v4
    s.add        s1, s6, s2                      // &out_ptr0[...]
    v.exp2.approx v3, v2                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v1, v4, v2                  // the exact rounding error of x*log2(e)
    vf.mul       v1, v5, v0
    vf.fma       v0, v3, v1, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v1, v0, v3
    v.st.w       [s1, #0], v1
__rctx_next:
    exit
