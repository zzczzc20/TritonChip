source ~/tc_env/env.sh
PY=~/tc_env/torchenv/bin/python
SRC=$HOME/m2/src_fe1b
for k in $($PY -c "
import json,hashlib
for r in json.load(open(\"dataset.json\"))[\"rows\"]:
    k={x:y for x,y in sorted(r[\"knobs\"].items())}
    print(r[\"point\"]+\"@\"+hashlib.sha256(json.dumps(k,sort_keys=True).encode()).hexdigest()[:10])"); do
  d=out/$(echo $k | tr "/@" "__")
  $PY $SRC/tools/performance_harness/systemc/run_graphs.py --source-root $SRC --binary $HOME/diag_gemm/tnca-chip \
    --torch-extensions-dir $HOME/m2/ext_fe1b --config $HOME/diag_gemm/final.cfg --out $d --dataset dataset.json --split other \
    --tree files:fe1b --key $k --memory-bytes 8589934592 --monitor aggregate --timed-auto --untimed-cold --jobs 1 --timeout 7200 > $d.log 2>&1 &
done
wait; echo ALLDONE
