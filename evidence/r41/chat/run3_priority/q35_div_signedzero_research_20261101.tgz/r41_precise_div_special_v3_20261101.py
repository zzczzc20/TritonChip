#!/usr/bin/env python3
"""DP TLM div_rn special values; preserves zero signs and checks NaNs."""
import json,os,tempfile
from pathlib import Path
import torch,triton,triton.language as tl
@triton.jit
def divide(A,B,C,BLOCK:tl.constexpr):
 i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK);a=tl.load(A+i);b=tl.load(B+i);tl.store(C+i,a/b)
def main():
 from tnca import aot
 from tnca.runtime import Session
 import tlm_backend
 tlm_backend.register()
 aa=torch.tensor([0.,-0.,0.,-0.,0.,-0.,0.,-0.,1.,-1.,1.,-1.,float('inf'),-float('inf'),float('nan'),1.]*16,dtype=torch.float32)
 bb=torch.tensor([2.,2.,-2.,-2.,float('inf'),float('inf'),-float('inf'),-float('inf'),0.,0.,-0.,-0.,2.,-2.,2.,float('nan')]*16,dtype=torch.float32)
 want=aa/bb;path=Path(tempfile.mkdtemp())/'divide.tnca';art=aot.compile_aot(divide,signature={'A':'*fp32','B':'*fp32','C':'*fp32','BLOCK':'constexpr'},constexprs={'BLOCK':16},profile='core-vrf-sync-v5-x8-g2c4-dp',options={'index_opt':1,'ieee_div':1},output=str(path))
 with Session(profile='core-vrf-sync-v5-x8-g2c4-dp',backend='systemc-tlm-grid',host_timeout=180) as sess:
  mod=sess.load(art.path);a,b,c=[sess.allocate(1024) for _ in range(3)];sess.upload(a,aa.numpy().tobytes());sess.upload(b,bb.numpy().tobytes());before=sess.dev.counters_snapshot();ev=sess.submit(mod,{'A':a,'B':b,'C':c},grid=(16,1,1));sess.wait(ev);after=sess.dev.counters_snapshot()
  if not ev.ok:raise RuntimeError(str(ev.error))
  got=torch.frombuffer(bytearray(sess.download(c)),dtype=torch.float32).clone();is_nan=torch.isnan(want);bad=(got.view(torch.int32)!=want.view(torch.int32))&~is_nan | (torch.isnan(got)!=is_nan);ids=torch.nonzero(bad).flatten().tolist();ins=sum(v-before.get(k,0) for k,v in after.items() if k.startswith('core_') and k.endswith('_instructions'))
  rows=[{'index':i,'a_bits':f'{int(aa.view(torch.int32)[i])&0xffffffff:08x}','b_bits':f'{int(bb.view(torch.int32)[i])&0xffffffff:08x}','expected_bits':f'{int(want.view(torch.int32)[i])&0xffffffff:08x}','got_bits':f'{int(got.view(torch.int32)[i])&0xffffffff:08x}'} for i in ids[:20]]
  result={'scope':'DP TLM, IEEE special values, NaNs compared by classification','elements':got.numel(),'bit_mismatches':len(ids),'first_mismatches':rows,'device_cycles':ev.device_cycles,'instructions':ins,'launches':1,'code_loads_during_launch':0};print(json.dumps(result,indent=2),flush=True)
  out=Path(os.environ['R41_DIV_SPECIAL_OUT']);out.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
