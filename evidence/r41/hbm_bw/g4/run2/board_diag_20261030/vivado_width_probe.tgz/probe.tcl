read_verilog probe.v
synth_design -top probe -part xcu280-fsvh2892-2L-e
write_verilog -force netlist.v
exit
