
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*i64', 'out_ptr2': '*fp32', 'out_ptr4': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 196608}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_add_arange_expand_le_scalar_tensor_unsqueeze_where_10(in_ptr0, in_ptr1, out_ptr2, out_ptr4, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 64
    XBLOCK: tl.constexpr = 1
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x3 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[64, 256], strides=[256, 1], block_shape=[XBLOCK, R0_BLOCK])
    tmp1 = tl.load(in_ptr1 + (0))
    tmp2 = tl.broadcast_to(tmp1, [R0_BLOCK])
    x0 = (xindex % 4)
    _tmp19 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp23 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp3 = (x0).to(tl.int64)
        tmp4 = (tmp3).to(tl.int64)
        tmp5 = tmp4 + tmp2
        tmp6 = (r0_2).to(tl.int64)
        tmp7 = (tmp6).to(tl.int64)
        tmp8 = tmp7 <= tmp5
        tmp9 = tl.full([1], 0.0, tl.float32)
        tmp10 = tl.full([1], float("-inf"), tl.float32)
        tmp11 = tl.where(tmp8, tmp9, tmp10)
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tmp0 + tmp12
        tmp14 = tmp13 == tmp10
        tmp15 = tmp14 == 0
        tmp16 = tmp15.to(tl.int64)
        tmp17 = (tmp16 != 0)
        tmp18 = tl.broadcast_to(tmp17, [R0_BLOCK])
        tmp20 = _tmp19 | tmp18
        _tmp19 = tl.where(r0_mask, tmp20, _tmp19)
        tmp22 = tl.broadcast_to(tmp13, [R0_BLOCK])
        tmp24 = tl.maximum(_tmp23, tmp22, tl.PropagateNan.ALL)
        _tmp23 = tl.where(r0_mask, tmp24, _tmp23)
    tmp21 = _tmp19.to(tl.int8)
    tmp19 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp21, 0))
    tmp23 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp23, 0))
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[64, 256], strides=[256, 1], block_shape=[XBLOCK, R0_BLOCK])
    tmp26 = tl.load(in_ptr1 + (0))
    tmp27 = tl.broadcast_to(tmp26, [R0_BLOCK])
    _tmp42 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp25 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp28 = (x0).to(tl.int64)
        tmp29 = (tmp28).to(tl.int64)
        tmp30 = tmp29 + tmp27
        tmp31 = (r0_2).to(tl.int64)
        tmp32 = (tmp31).to(tl.int64)
        tmp33 = tmp32 <= tmp30
        tmp34 = tl.full([1], 0.0, tl.float32)
        tmp35 = tl.full([1], float("-inf"), tl.float32)
        tmp36 = tl.where(tmp33, tmp34, tmp35)
        tmp37 = tmp36.to(tl.float32)
        tmp38 = tmp25 + tmp37
        tmp39 = tmp38 - tmp23
        tmp40 = libdevice.exp(tmp39)
        tmp41 = tl.broadcast_to(tmp40, [R0_BLOCK])
        tmp43 = _tmp42 + tmp41
        _tmp42 = tl.where(r0_mask, tmp43, _tmp42)
        tl.store(out_ptr2 + (r0_2 + 256*x3), tmp40, r0_mask)
    tmp42 = triton_helpers.promote_to_tensor(tl.sum(_tmp42, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(out_ptr2, shape=[64, 256], strides=[256, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tl.debug_barrier()
        tmp45 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp44 = tmp19 == 0
        tmp46 = (tmp45 / tmp42)
        tmp47 = tl.full([1], 0.0, tl.float32)
        tmp48 = tl.where(tmp44, tmp47, tmp46)
        tl.store(out_ptr4 + (r0_2 + 256*x3), tmp48, r0_mask)
