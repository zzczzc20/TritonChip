    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    v.movi       v0, #0
    v.movi       v1, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #2560
    s.movz       s6, #16
    s.ld.d       s7, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.ld.d       s8, [s1, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    s.addi       s9, s2, #0
    s.ld.d       s10, [s1, #24]                  // out_ptr2: device_ptr64 at arg_base+24
    s.ld.d       s11, [s1, #32]                  // out_ptr3: device_ptr64 at arg_base+32
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s9, s5
    br.nz        s1, endfor_2
    s.mul        s1, s4, s5
    v.splat      v0, s9
    v.movi       v3, #2560
    v.add        v4, v0, v2
    v.movi       v0, #0
    s.add        s12, s9, s1
    v.cmp.lt     p1, v4, v3
    s.shli       s13, s12, #1                    // element offset -> bytes (x2)
    v.splat      v3, s1
    s.add        s1, s3, s13                     // &in_ptr0[...]
    s.add        s12, s9, s6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v5, [s1, #0]
    s.movz       s1, #1
    v.add        v6, v4, v3
    vf.cvt.bf16.f32 v3, v5
    vf.mul       v4, v3, v3
    vf.add       v3, v1, v4
    @p1 v.sel        v4, v3, v1
    v.mov        v0, v4
    v.mov        v1, v0
    s.mov        s9, s12
    br.nz        s1, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.addi       s1, s2, #0
    vf.add       v3, v0, v1
for_3:
    s.cmp.ge     s2, s1, s5
    br.nz        s2, endfor_4
    .li       s2, #1159725056
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v4, v0                          // ISA 8.8: <= 2**-22 relative
    .li       s2, #897988541
    v.splat      v5, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s2, s4, s5
    .li       s9, #1077936128
    v.splat      v6, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s9, #3204448256
    v.splat      v7, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v8, s1
    s.shli       s9, s1, #1                      // element offset -> bytes (x2)
    s.add        s12, s1, s2
    v.add        v9, v8, v2
    s.shli       s13, s12, #1                    // element offset -> bytes (x2)
    v.movi       v8, #2560
    s.add        s12, s3, s13                    // &in_ptr0[...]
    s.add        s14, s7, s9                     // &in_ptr1[...]
    v.cmp.lt     p1, v9, v8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v8, [s12, #0]
    .li       s9, #1065353216
    v.splat      v10, s9                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s9, s8, s13                     // &out_ptr1[...]
    s.add        s12, s10, s13                   // &out_ptr2[...]
    s.add        s15, s11, s13                   // &out_ptr3[...]
    vf.cvt.bf16.f32 v11, v8
    vf.fms       v8, v0, v4, v1
    vf.fms       v1, v4, v8, v4
    vf.neg       v8, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v1, v8, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s14, #0]
    vf.cvt.bf16.f32 v8, v4
    vf.add       v4, v8, v10
    vf.mul       v8, v3, v1                      // a/y: faithful quotient
    vf.fms       v10, v8, v0, v3
    v.splat      v0, s2
    v.add        v12, v9, v0
    vf.fms       v0, v10, v1, v8
    s.add        s2, s1, s6
    s.movz       s13, #1
    vf.neg       v1, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v0, v1, v8
    vf.add       v1, v0, v5
    v.rsqrt.approx v0, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v0, v0
    vf.mul       v8, v0, v7
    vf.fms       v7, v1, v5, v6
    vf.mul       v1, v8, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v5, v1, v0
    v.extract    s14, v5, #0
    v.splat      v0, s14
    vf.mul       v1, v11, v0
    vf.mul       v0, v1, v4
    vf.cvt.f32.bf16 v1, v0
    @p1 v.st.h       [s9, #0], v1
    @p1 v.st.h       [s12, #0], v1
    @p1 v.st.h       [s15, #0], v1
    s.mov        s1, s2
    br.nz        s13, for_3
endfor_4:
__rctx_next:
    exit
