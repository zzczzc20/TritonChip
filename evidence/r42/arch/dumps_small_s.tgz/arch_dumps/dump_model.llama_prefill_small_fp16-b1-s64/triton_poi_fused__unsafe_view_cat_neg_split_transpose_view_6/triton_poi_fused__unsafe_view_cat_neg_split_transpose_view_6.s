    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    v.movi       v0, #16
    v.movi       v1, #64
    v.movi       v2, #0
    v.movi       v3, #1024
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #32
    v.movi       v6, #48
    v.movi       v7, #80
    v.movi       v8, #96
    v.movi       v9, #112
    v.sub        v10, v2, v0
    v.sub        v11, v2, v1
    v.sub        v12, v2, v3
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (0 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
    v.add        v13, v4, v0
    v.add        v14, v4, v5
    v.add        v15, v4, v6
    v.add        v6, v4, v1
    v.add        v16, v4, v7
    v.add        v7, v4, v8
    v.add        v8, v4, v9
    @p1 v.sel        v9, v10, v0
    v.cmp.lt     p1, v3, v2
    v.movi       v0, #15
    v.movi       v9, #4
    @p2 v.sel        v10, v11, v1
    v.movi       v10, #63
    @p1 v.sel        v11, v12, v3
    v.movi       v3, #10
    v.movi       v11, #2048
tiles_1:
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s9, s1, s8
    v.splat      v12, s9
    v.add        v17, v12, v4
    v.add        v18, v12, v13
    v.add        v19, v12, v14
    v.add        v20, v12, v15
    v.add        v21, v12, v6
    v.add        v22, v12, v16
    v.add        v23, v12, v7
    v.add        v24, v12, v8
    v.sub        v12, v2, v17
    v.sub        v25, v2, v18
    v.sub        v26, v2, v19
    v.sub        v27, v2, v20
    v.sub        v28, v2, v21
    v.sub        v29, v2, v22
    v.sub        v30, v2, v23
    v.sub        v31, v2, v24
    v.cmp.lt     p1, v17, v2
    v.cmp.lt     p2, v18, v2
    v.cmp.lt     p3, v19, v2
    v.cmp.lt     p4, v20, v2
    v.cmp.lt     p5, v21, v2
    v.cmp.lt     p6, v22, v2
    v.cmp.lt     p7, v23, v2
    v.cmp.lt     p8, v24, v2
    @p1 v.sel        v32, v12, v17
    @p2 v.sel        v12, v25, v18
    @p3 v.sel        v25, v26, v19
    @p4 v.sel        v26, v27, v20
    @p5 v.sel        v27, v28, v21
    @p6 v.sel        v28, v29, v22
    @p7 v.sel        v29, v30, v23
    @p8 v.sel        v30, v31, v24
    v.lshr       v31, v32, v9
    v.and        v33, v32, v0
    v.lshr       v34, v12, v9
    v.sub        v35, v2, v31
    v.and        v36, v12, v0
    v.and        v37, v25, v0
    @p1 v.sel        v38, v35, v31
    v.and        v31, v26, v0
    v.and        v35, v27, v0
    v.and        v39, v28, v0
    v.and        v40, v29, v0
    v.and        v41, v30, v0
    v.sub        v42, v2, v33
    v.sub        v43, v2, v34
    v.sub        v44, v2, v36
    v.sub        v45, v2, v37
    v.sub        v46, v2, v31
    v.sub        v47, v2, v35
    v.sub        v48, v2, v39
    v.sub        v49, v2, v40
    v.sub        v50, v2, v41
    @p1 v.sel        v51, v42, v33
    v.lshr       v33, v25, v9
    v.lshr       v42, v26, v9
    @p2 v.sel        v52, v43, v34
    v.sub        v34, v2, v33
    v.sub        v43, v2, v42
    @p2 v.sel        v53, v44, v36
    v.lshr       v36, v27, v9
    v.lshr       v44, v28, v9
    @p3 v.sel        v54, v34, v33
    v.sub        v33, v2, v36
    v.sub        v34, v2, v44
    @p4 v.sel        v55, v43, v42
    @p5 v.sel        v42, v33, v36
    @p3 v.sel        v33, v45, v37
    v.lshr       v36, v29, v9
    v.lshr       v37, v30, v9
    @p6 v.sel        v43, v34, v44
    v.sub        v34, v2, v36
    v.sub        v44, v2, v37
    @p4 v.sel        v45, v46, v31
    @p7 v.sel        v31, v34, v36
    @p8 v.sel        v34, v44, v37
    v.sub        v36, v2, v38
    v.cmp.lt     p9, v38, v2
    @p5 v.sel        v37, v47, v35
    v.sub        v35, v2, v52
    v.cmp.lt     p10, v52, v2
    @p9 v.sel        v44, v36, v38
    @p10 v.sel        v36, v35, v52
    @p6 v.sel        v35, v48, v39
    v.sub        v39, v2, v54
    v.and        v46, v44, v10
    v.and        v44, v36, v10
    @p7 v.sel        v36, v49, v40
    v.sub        v40, v2, v55
    v.sub        v47, v2, v46
    v.sub        v48, v2, v44
    @p8 v.sel        v49, v50, v41
    v.sub        v41, v2, v42
    v.sub        v50, v2, v43
    v.sub        v56, v2, v31
    v.sub        v57, v2, v34
    v.lshr       v58, v32, v3
    v.lshr       v32, v12, v3
    @p9 v.sel        v12, v47, v46
    v.cmp.lt     p9, v54, v2
    @p9 v.sel        v46, v39, v54
    v.lshr       v39, v25, v3
    v.lshr       v25, v26, v3
    v.and        v26, v46, v10
    v.sub        v46, v2, v58
    v.sub        v47, v2, v32
    v.sub        v59, v2, v39
    @p1 v.sel        v60, v46, v58
    v.cmp.lt     p1, v55, v2
    @p1 v.sel        v46, v40, v55
    v.sub        v40, v2, v25
    @p2 v.sel        v58, v47, v32
    v.cmp.lt     p2, v42, v2
    @p2 v.sel        v32, v41, v42
    v.and        v41, v46, v10
    v.sub        v46, v2, v26
    v.and        v47, v32, v10
    @p3 v.sel        v32, v59, v39
    v.cmp.lt     p3, v43, v2
    @p3 v.sel        v39, v50, v43
    v.sub        v50, v2, v41
    @p10 v.sel        v59, v48, v44
    v.cmp.lt     p10, v31, v2
    @p10 v.sel        v44, v56, v31
    v.lshr       v48, v27, v3
    v.lshr       v27, v28, v3
    v.and        v28, v39, v10
    v.and        v39, v44, v10
    v.sub        v44, v2, v48
    @p4 v.sel        v56, v40, v25
    v.cmp.lt     p4, v34, v2
    @p4 v.sel        v25, v57, v34
    v.sub        v40, v2, v27
    @p5 v.sel        v57, v44, v48
    v.and        v44, v25, v10
    v.sub        v25, v2, v47
    v.sub        v48, v2, v28
    @p9 v.sel        v61, v46, v26
    v.lshr       v26, v29, v3
    v.lshr       v29, v30, v3
    v.sub        v30, v2, v39
    v.sub        v46, v2, v26
    @p6 v.sel        v62, v40, v27
    v.sub        v27, v2, v29
    v.sub        v40, v2, v44
    @p7 v.sel        v63, v46, v26
    @p1 v.sel        v26, v50, v41
    @p8 v.sel        v41, v27, v29
    @p2 v.sel        v27, v25, v47
    @p3 v.sel        v25, v48, v28
    @p10 v.sel        v28, v30, v39
    @p4 v.sel        v29, v40, v44
    v.mul        v30, v60, v5
    v.mul        v39, v58, v5
    v.mul        v40, v32, v5
    v.mul        v32, v56, v5
    v.mul        v44, v57, v5
    v.mul        v46, v62, v5
    v.mul        v47, v63, v5
    v.mul        v48, v41, v5
    v.add        v41, v51, v30
    v.add        v30, v53, v39
    v.add        v39, v33, v40
    v.add        v40, v45, v32
    v.add        v32, v37, v44
    v.add        v44, v35, v46
    v.add        v46, v36, v47
    v.add        v47, v49, v48
    v.mul        v48, v12, v1
    v.mul        v12, v59, v1
    v.mul        v50, v61, v1
    v.mul        v56, v26, v1
    v.mul        v26, v27, v1
    v.mul        v27, v25, v1
    v.mul        v25, v28, v1
    v.mul        v28, v29, v1
    v.add        v29, v41, v48
    v.add        v41, v30, v12
    v.add        v12, v39, v50
    v.add        v30, v40, v56
    v.add        v39, v32, v26
    v.add        v26, v44, v27
    v.add        v27, v46, v25
    v.add        v25, v47, v28
    v.cmp.lt     p1, v17, v11
    v.cmp.lt     p2, v18, v11
    v.cmp.lt     p3, v19, v11
    v.cmp.lt     p4, v20, v11
    v.cmp.lt     p5, v21, v11
    v.cmp.lt     p6, v22, v11
    v.cmp.lt     p7, v23, v11
    v.cmp.lt     p8, v24, v11
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v17, [s3, v29]             // index is in elements (ISA sec 9.1)
    v.mul        v18, v38, v5
    v.mul        v19, v52, v5
    v.mul        v20, v54, v5
    v.mul        v21, v55, v5
    v.mul        v22, v42, v5
    v.mul        v23, v43, v5
    v.mul        v24, v31, v5
    v.mul        v28, v34, v5
    v.add        v29, v51, v18
    v.add        v18, v53, v19
    v.add        v19, v33, v20
    v.add        v20, v45, v21
    v.add        v21, v37, v22
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.h v22, [s3, v41]             // index is in elements (ISA sec 9.1)
    v.add        v31, v35, v23
    v.add        v23, v36, v24
    v.add        v24, v49, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v28, [s3, v12]             // index is in elements (ISA sec 9.1)
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p4 v.ld.gather.h v12, [s3, v30]             // index is in elements (ISA sec 9.1)
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.h v30, [s3, v39]             // index is in elements (ISA sec 9.1)
    v.movi       v32, #0                         // other=, materialised (sec 12)
    @p6 v.ld.gather.h v32, [s3, v26]             // index is in elements (ISA sec 9.1)
    v.movi       v26, #0                         // other=, materialised (sec 12)
    @p7 v.ld.gather.h v26, [s3, v27]             // index is in elements (ISA sec 9.1)
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p8 v.ld.gather.h v27, [s3, v25]             // index is in elements (ISA sec 9.1)
    @p1 v.st.scatter.h [s7, v29], v17
    @p2 v.st.scatter.h [s7, v18], v22
    @p3 v.st.scatter.h [s7, v19], v28
    @p4 v.st.scatter.h [s7, v20], v12
    @p5 v.st.scatter.h [s7, v21], v30
    @p6 v.st.scatter.h [s7, v31], v32
    @p7 v.st.scatter.h [s7, v23], v26
    @p8 v.st.scatter.h [s7, v24], v27
    s.addi       s8, s8, #128
    s.cmp.lt     s9, s8, s2
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
