    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s5, #512
    .li       s6, #2147483647
    s.mul        s7, s1, s5
    .li       s1, #2147483647
    s.movz       s5, #128
    s.movz       s8, #2
    .li       s9, #68719476752
    .li       s10, #8589934592
    s.rdspecial  s11, arg_base
    s.ld.d       s12, [s2, #8]                   // arg_A: device_ptr64 at arg_base+8
    s.add        s13, s3, s7                     // this context's own scratch
    s.rdspecial  s3, role_id
    s.addi       s7, s13, #0                     // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s13, #512
    .li       s14, #2147483647
    s.mul        s15, s3, s13
    .li       s3, #2147483647
    s.movz       s13, #128
    s.movz       s16, #2
    .li       s17, #68719476752
    s.ld.d       s18, [s2, #0]                   // in_ptr0: device_ptr64 at arg_base+0
    .li       s19, #8589934592
    s.movz       s20, #0
    s.movz       s20, #0
    s.ld.d       s20, [s2, #16]                  // arg_B: device_ptr64 at arg_base+16
    s.movz       s21, #12
    s.ld.d       s22, [s2, #24]                  // out_ptr0: device_ptr64 at arg_base+24
    s.st.d       [s7, #0], s12
    s.movz       s2, #0
    s.st.d       [s7, #8], s6
    s.movz       s6, #0
    s.st.d       [s7, #16], s1
    .li       s1, #1431655766
    s.st.d       [s7, #48], s5
    s.movz       s5, #0
    s.cmp.lt     s12, s21, s5
    s.st.d       [s7, #56], s8
    s.cmp.lt     s5, s4, s2
    s.movz       s2, #0
    s.sub        s8, s6, s5
    s.sub        s5, s2, s12
    s.movz       s2, #1
    s.movz       s6, #0
    s.st.d       [s7, #88], s9
    s.xor        s9, s4, s8
    s.sub        s12, s9, s8
    s.st.d       [s7, #104], s10
    s.mul        s9, s12, s1
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s7, #0
    s.lshri      s10, s9, #32
    s.ld.d       s9, [s11, #32]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s11, s9, s15                    // this context's own scratch
    s.sub        s9, s12, s10
    s.xor        s15, s8, s5
    s.lshri      s8, s9, #1
    s.addi       s9, s11, #256                   // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.add        s11, s10, s8
    s.movz       s8, #0
    s.lshri      s10, s11, #3
    s.st.d       [s9, #0], s20
    s.xor        s11, s10, s15
    s.muli       s20, s10, #12
    s.sub        s10, s11, s15
    s.movz       s11, #0
    s.sub        s15, s12, s20
    s.sub        s12, s2, s10
    s.movz       s15, #1
    s.min.s      s20, s12, s2
    s.st.d       [s9, #8], s14
    s.cmp.lt     s12, s4, s1
    s.xor        s1, s21, s5
    s.sub        s14, s8, s12
    s.movz       s8, #0
    s.sub        s12, s1, s5
    s.st.d       [s9, #16], s3
    s.cmp.lt     s1, s20, s6
    s.sub        s3, s7, s1
    s.st.d       [s9, #48], s13
    s.xor        s1, s4, s14
    s.sub        s5, s1, s14
    s.st.d       [s9, #56], s16
    s.xor        s1, s20, s3
    s.sub        s6, s1, s3
    s.st.d       [s9, #88], s17
    s.addi       s1, s11, #0
    s.addi       s3, s8, #0
    s.st.d       [s9, #104], s19
    s.cmp.eq     s7, s6, s15
    fence.release.device
    td.load      d1, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s1, s5
    br.nz        s7, sdiv_done_1
    s.movz       s7, #0
    s.movz       s8, #31
    s.mov        s1, s7
    s.addi       s7, s8, #0
sdiv_2:
    s.lshr       s8, s5, s7
    s.shli       s9, s3, #1
    s.andi       s11, s8, #1
    s.movz       s8, #0
    s.or         s12, s9, s11
    s.movz       s9, #1
    s.cmp.geu    s11, s12, s6
    s.shl        s13, s9, s7
    s.sub        s9, s8, s11
    s.subi       s8, s7, #1
    s.and        s11, s6, s9
    s.and        s15, s13, s9
    s.sub        s9, s12, s11
    s.or         s11, s1, s15
    s.mov        s3, s9
    s.mov        s1, s11
    s.mov        s7, s8
    s.movz       s8, #0
    s.cmp.ge     s9, s7, s8
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s5, #0
    s.cmp.lt     s6, s4, s1
    .li       s1, #1431655766
    s.sub        s7, s5, s6
    s.movz       s5, #0
    s.xor        s6, s4, s7
    s.movz       s4, #0
    s.sub        s8, s6, s7
    s.movz       s6, #0
    s.mul        s9, s8, s1
    s.cmp.lt     s1, s20, s5
    s.movz       s5, #0
    s.sub        s11, s6, s1
    s.movz       s1, #0
    s.lshri      s6, s9, #32
    s.cmp.lt     s9, s21, s5
    s.xor        s5, s20, s11
    s.xor        s12, s3, s14
    s.sub        s3, s5, s11
    s.sub        s5, s12, s14
    s.sub        s12, s8, s6
    s.add        s13, s10, s5
    s.lshri      s5, s12, #1
    s.movz       s10, #0
    s.add        s12, s6, s5
    s.sub        s5, s10, s9
    s.lshri      s6, s12, #3
    s.movz       s9, #0
    s.muli       s10, s6, #12
    s.movz       s6, #1
    s.xor        s12, s21, s5
    s.addi       s14, s9, #0
    s.cmp.eq     s9, s3, s6
    s.sub        s6, s8, s10
    s.movz       s8, #0
    s.xor        s10, s6, s7
    s.sub        s6, s12, s5
    s.sub        s5, s10, s7
    s.addi       s6, s8, #0
    s.cmp.lt     s7, s5, s4
    s.sub        s4, s1, s7
    s.xor        s1, s5, s4
    s.sub        s5, s1, s4
    s.mov        s14, s5
    br.nz        s9, sdiv_done_3
    s.movz       s1, #0
    s.movz       s7, #31
    s.mov        s14, s1
    s.addi       s1, s7, #0
sdiv_4:
    s.lshr       s7, s5, s1
    s.shli       s8, s6, #1
    s.andi       s9, s7, #1
    s.movz       s7, #0
    s.or         s10, s8, s9
    s.movz       s8, #1
    s.cmp.geu    s9, s10, s3
    s.shl        s12, s8, s1
    s.sub        s8, s7, s9
    s.subi       s7, s1, #1
    s.and        s9, s3, s8
    s.and        s15, s12, s8
    s.sub        s8, s10, s9
    s.or         s9, s14, s15
    s.mov        s6, s8
    s.mov        s14, s9
    s.mov        s1, s7
    s.movz       s7, #0
    s.cmp.ge     s8, s1, s7
    br.nz        s8, sdiv_4
sdiv_done_3:
    s.xor        s1, s4, s11
    s.movz       s3, #16
    s.xor        s4, s14, s1
    .li       s5, #1431655766
    s.sub        s6, s4, s1
    s.mul        s1, s13, s3
    s.mul        s4, s6, s3
    s.movz       s7, #0
    v.splat      v0, s13
    v.splat      v1, s7
    s.andi       s8, s1, #15
    s.mul        s9, s4, s5
    v.splat      v2, s6
    v.splat      v3, s7
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s1
    s.lshri      s5, s9, #32
    v.cmp.ge     p1, v0, v1
    s.sub        s6, s4, s5
    v.splat      v0, s4
    s.lshri      s9, s6, #1
    v.splat      v1, s8
    s.add        s6, s5, s9
    v.cmp.ge     p1, v2, v3
    s.lshri      s5, s6, #7
    v.iota       v2                              // arange(0, VLEN)
    s.muli       s6, s5, #192
    v.iota       v3                              // arange(0, VLEN)
    v.add        v6, v5, v4
    v.add        v5, v0, v4
    v.add        v0, v1, v2
    s.sub        s5, s4, s6
    s.movz       s6, #4
    v.splat      v0, s5
    s.addi       s9, s7, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    v.add        v1, v0, v3
for_5:
    s.cmp.ge     s7, s9, s6
    br.nz        s7, endfor_6
    s.mul        s7, s9, s3
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s10, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s11, s9, s2
    s.movz       s12, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s8                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s13, s10
    mb.wait      s10
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s14, s5                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s14, s13
    mb.wait      s13
    mb.arm       s7, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s7
    mb.wait      s7
    s.mov        s9, s11
    br.nz        s12, for_5
endfor_6:
    s.movz       s2, #0
    s.movz       s5, #0
    s.add        s6, s2, s4                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s6
    s.add        s2, s5, s1                      // the tile origin
    s.movz       s5, #192
    s.muli       s6, s4, #2                      // a runtime tile origin, x2
    v.splat      v2, s2
    v.splat      v3, s3
    v.add        v4, v0, v1
    v.splat      v0, s5
    v.cmp.lt     p1, v2, v3
    s.add        s3, s18, s6                     // the tile origin
    v.cmp.lt     p2, v4, v0
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s5, #0
    p.and        p3, p1, p2
    a.vread      v0, a0, s5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s3, #0]
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s5, s4, #2                      // a runtime tile origin, x2
    s.addi       s4, s2, #1
    s.muli       s6, s1, #384                    // a runtime tile origin, x384
    v.splat      v2, s2
    v.splat      v4, s4
    s.add        s1, s22, s5                     // the tile origin
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p3, v4, v3
    s.add        s4, s1, s6                      // the tile origin
    p.and        p4, p1, p2
    s.movz       s1, #1
    p.and        p1, p3, p2
    s.addi       s5, s2, #1
    vf.cvt.f16.f32 v2, v1
    s.addi       s6, s2, #2
    v.splat      v1, s5
    v.splat      v4, s6
    s.addi       s5, s4, #384                    // row 1
    vf.add       v5, v0, v2
    s.movz       s6, #2
    s.addi       s8, s2, #2
    s.addi       s9, s2, #3
    v.splat      v0, s8
    vf.cvt.f32.f16 v2, v5
    v.splat      v5, s9
    s.addi       s8, s4, #768                    // row 2
    s.movz       s9, #3
    s.addi       s11, s2, #3
    @p4 v.st.h       [s4, #0], v2
    a.vread      v2, a0, s1
    v.cmp.lt     p3, v1, v3
    p.and        p4, p3, p2
    s.addi       s1, s2, #4
    v.splat      v1, s11
    v.splat      v6, s1
    s.addi       s1, s4, #1152                   // row 3
    s.movz       s11, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v4, v7
    vf.add       v7, v2, v4
    vf.cvt.f32.f16 v2, v7
    s.addi       s12, s2, #4
    v.splat      v4, s12
    s.addi       s12, s4, #1536                  // row 4
    @p4 v.st.h       [s5, #0], v2
    a.vread      v2, a0, s6
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.addi       s5, s2, #5
    s.movz       s6, #5
    v.splat      v0, s5
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v5, v7
    vf.add       v7, v2, v5
    vf.cvt.f32.f16 v2, v7
    s.addi       s5, s2, #5
    v.splat      v5, s5
    s.addi       s5, s4, #1920                   // row 5
    @p4 v.st.h       [s8, #0], v2
    a.vread      v2, a0, s9
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s8, s2, #6
    s.movz       s9, #6
    v.splat      v1, s8
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v6, v7
    vf.add       v7, v2, v6
    vf.cvt.f32.f16 v2, v7
    s.addi       s8, s2, #6
    v.splat      v6, s8
    s.addi       s8, s4, #2304                   // row 6
    @p4 v.st.h       [s1, #0], v2
    a.vread      v2, a0, s11
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.addi       s1, s2, #7
    s.movz       s11, #7
    v.splat      v4, s1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v0, v7
    vf.add       v7, v2, v0
    vf.cvt.f32.f16 v0, v7
    s.addi       s1, s2, #7
    v.splat      v2, s1
    s.addi       s1, s4, #2688                   // row 7
    @p4 v.st.h       [s12, #0], v0
    a.vread      v0, a0, s6
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    s.addi       s6, s2, #8
    s.movz       s12, #8
    v.splat      v5, s6
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v1, v7
    vf.add       v7, v0, v1
    vf.cvt.f32.f16 v0, v7
    s.addi       s6, s2, #8
    v.splat      v1, s6
    s.addi       s6, s4, #3072                   // row 8
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s9
    v.cmp.lt     p1, v6, v3
    p.and        p4, p1, p2
    s.addi       s5, s2, #9
    s.movz       s9, #9
    v.splat      v6, s5
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v4, v7
    vf.add       v7, v0, v4
    vf.cvt.f32.f16 v0, v7
    s.addi       s5, s2, #9
    v.splat      v4, s5
    s.addi       s5, s4, #3456                   // row 9
    @p4 v.st.h       [s8, #0], v0
    a.vread      v0, a0, s11
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s8, s2, #10
    s.movz       s11, #10
    v.splat      v2, s8
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v5, v7
    vf.add       v7, v0, v5
    vf.cvt.f32.f16 v0, v7
    s.addi       s8, s2, #10
    v.splat      v5, s8
    s.addi       s8, s4, #3840                   // row 10
    @p4 v.st.h       [s1, #0], v0
    a.vread      v0, a0, s12
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s1, s2, #11
    s.movz       s12, #11
    v.splat      v1, s1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v6, v7
    vf.add       v7, v0, v6
    vf.cvt.f32.f16 v0, v7
    s.addi       s1, s2, #11
    v.splat      v6, s1
    s.addi       s1, s4, #4224                   // row 11
    @p4 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s9
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.addi       s6, s2, #12
    s.movz       s9, #12
    v.splat      v4, s6
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v2, v7
    vf.add       v7, v0, v2
    vf.cvt.f32.f16 v0, v7
    s.addi       s6, s2, #12
    v.splat      v2, s6
    s.addi       s6, s4, #4608                   // row 12
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s11
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    s.addi       s5, s2, #13
    s.movz       s11, #13
    v.splat      v5, s5
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v1, v7
    vf.add       v7, v0, v1
    vf.cvt.f32.f16 v0, v7
    s.addi       s5, s2, #13
    v.splat      v1, s5
    s.addi       s5, s4, #4992                   // row 13
    @p4 v.st.h       [s8, #0], v0
    a.vread      v0, a0, s12
    v.cmp.lt     p1, v6, v3
    p.and        p4, p1, p2
    s.addi       s8, s2, #14
    s.movz       s12, #14
    v.splat      v6, s8
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v4, v7
    vf.add       v7, v0, v4
    vf.cvt.f32.f16 v0, v7
    s.addi       s8, s2, #14
    v.splat      v4, s8
    s.addi       s8, s4, #5376                   // row 14
    @p4 v.st.h       [s1, #0], v0
    a.vread      v0, a0, s9
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s1, s2, #15
    s.movz       s9, #15
    v.splat      v2, s1
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v7, [s3, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v5, v7
    vf.add       v7, v0, v5
    vf.cvt.f32.f16 v0, v7
    s.addi       s1, s2, #15
    s.addi       s2, s4, #5760                   // row 15
    v.splat      v5, s1
    @p4 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s11
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s3, #0]
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v6, v1
    vf.add       v1, v0, v6
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s12
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s3, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s8, #0], v0
    a.vread      v0, a0, s9
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s3, #0]
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s2, #0], v0
__rctx_next:
    exit
