#!/bin/bash
set -euo pipefail
ROOT="$HOME/r41-accept-p1-v2"; OUT="$HOME/r41-accept-p1/transfer-queue"
mkdir -p "$OUT"
source "$HOME/tc_env/env.sh"
export PYTHONPATH="$ROOT:$ROOT/python:$ROOT/compiler/python:$ROOT/tools/asm:$ROOT/tools/performance_harness/systemc"
export TNCA_BACKEND=systemc-tlm-grid TNCA_PROFILE=core-vrf-sync-v5-x8 TNCA_TLM_BINARY="$HOME/r41-accept-p1/model-build/tnca-chip" TNCA_TLM_MEMORY_BYTES=0x200000000
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 TNCA_IEEE_DIV=1
export TORCH_EXTENSIONS_DIR="$HOME/r41-accept-p1/extensions"
for slots in 1 2; do
 sed "s/^dma_queue=.*/dma_queue=$slots/" "$ROOT/tools/performance_harness/systemc/configs/r40-three-core.cfg" > "$OUT/queue-$slots.cfg"
 export TNCA_TLM_CONFIG="$OUT/queue-$slots.cfg" TNCA_TLM_OUT="$OUT/queue-$slots-model"
 "$HOME/tc_env/torchenv/bin/python" "$ROOT/tools/performance_harness/fragment_case.py" --out "$OUT/queue-$slots" --columns 32 --shapes 17x65x33,128x128x192 --bitwise --require-resident > "$OUT/queue-$slots.log" 2>&1
done
