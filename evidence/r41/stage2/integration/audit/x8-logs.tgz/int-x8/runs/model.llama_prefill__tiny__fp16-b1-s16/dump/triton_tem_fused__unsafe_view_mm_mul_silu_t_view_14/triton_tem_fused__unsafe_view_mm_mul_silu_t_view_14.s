    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    s.rdspecial  s3, role_id
    s.movz       s6, #512
    s.add        s7, s1, s5                      // this context's own scratch
    s.ld.d       s1, [s2, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.addi       s5, s7, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s7, #2147483647
    .li       s8, #2147483647
    s.movz       s9, #128
    s.movz       s10, #2
    .li       s11, #68719476752
    .li       s12, #8589934592
    s.rdspecial  s13, arg_base
    s.mul        s14, s3, s6
    s.ld.d       s3, [s2, #8]                    // arg_B: device_ptr64 at arg_base+8
    .li       s6, #2147483647
    .li       s15, #2147483647
    s.ld.d       s16, [s2, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.movz       s17, #8
    s.movz       s18, #128
    s.ld.d       s19, [s2, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    s.movz       s2, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.st.d       [s5, #0], s1
    s.movz       s1, #0
    s.cmp.lt     s22, s17, s21
    s.st.d       [s5, #8], s7
    s.sub        s7, s1, s22
    s.movz       s1, #2
    s.st.d       [s5, #16], s8
    .li       s8, #68719476752
    .li       s21, #8589934592
    s.st.d       [s5, #48], s9
    s.xor        s9, s17, s7
    s.movz       s22, #0
    s.cmp.lt     s22, s4, s2
    s.st.d       [s5, #56], s10
    s.sub        s2, s20, s22
    s.movz       s10, #1
    s.xor        s20, s4, s2
    s.st.d       [s5, #88], s11
    s.sub        s11, s20, s2
    s.movz       s20, #0
    s.st.d       [s5, #104], s12
    s.lshri      s12, s11, #3
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s5, s2, s7
    s.movz       s2, #0
    s.ld.d       s22, [s13, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.cmp.lt     s13, s4, s2
    s.movz       s2, #0
    s.add        s2, s22, s14                    // this context's own scratch
    s.xor        s14, s12, s5
    s.muli       s22, s12, #8
    s.sub        s12, s14, s5
    s.movz       s5, #0
    s.addi       s14, s2, #256                   // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.sub        s2, s9, s7
    s.sub        s2, s10, s12
    s.movz       s7, #0
    s.min.s      s9, s2, s10
    s.sub        s2, s7, s13
    s.cmp.lt     s7, s9, s20
    s.movz       s13, #0
    s.sub        s20, s5, s7
    s.movz       s5, #1
    s.st.d       [s14, #0], s3
    s.xor        s3, s4, s2
    s.sub        s7, s11, s22
    s.movz       s7, #0
    s.sub        s11, s3, s2
    s.st.d       [s14, #8], s6
    s.xor        s3, s9, s20
    s.sub        s6, s3, s20
    s.st.d       [s14, #16], s15
    s.addi       s3, s13, #0
    s.addi       s13, s7, #0
    s.st.d       [s14, #48], s18
    s.cmp.eq     s7, s6, s5
    s.st.d       [s14, #56], s1
    s.st.d       [s14, #88], s8
    s.st.d       [s14, #104], s21
    fence.release.device
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s3, s11
    br.nz        s7, sdiv_done_1
    s.movz       s1, #0
    s.movz       s5, #31
    s.mov        s3, s1
    s.addi       s1, s5, #0
sdiv_2:
    s.lshr       s5, s11, s1
    s.shli       s7, s13, #1
    s.andi       s8, s5, #1
    s.movz       s5, #0
    s.or         s14, s7, s8
    s.movz       s7, #1
    s.cmp.geu    s8, s14, s6
    s.shl        s15, s7, s1
    s.sub        s7, s5, s8
    s.subi       s5, s1, #1
    s.and        s8, s6, s7
    s.and        s18, s15, s7
    s.sub        s7, s14, s8
    s.or         s8, s3, s18
    s.mov        s13, s7
    s.mov        s3, s8
    s.mov        s1, s5
    s.movz       s5, #0
    s.cmp.ge     s7, s1, s5
    br.nz        s7, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s3, #0
    s.cmp.lt     s5, s4, s1
    s.movz       s1, #0
    s.sub        s6, s3, s5
    s.movz       s3, #0
    s.xor        s5, s4, s6
    s.movz       s4, #0
    s.sub        s7, s5, s6
    s.cmp.lt     s5, s9, s1
    s.lshri      s1, s7, #3
    s.movz       s8, #0
    s.muli       s11, s1, #8
    s.sub        s1, s4, s5
    s.movz       s4, #0
    s.cmp.lt     s5, s17, s8
    s.xor        s8, s9, s1
    s.sub        s9, s7, s11
    s.movz       s7, #0
    s.xor        s11, s9, s6
    s.xor        s9, s13, s2
    s.sub        s13, s11, s6
    s.sub        s6, s7, s5
    s.cmp.lt     s5, s13, s3
    s.sub        s3, s8, s1
    s.sub        s7, s4, s5
    s.movz       s4, #0
    s.xor        s5, s13, s7
    s.movz       s8, #1
    s.sub        s11, s9, s2
    s.xor        s2, s17, s6
    s.sub        s9, s5, s7
    s.movz       s5, #0
    s.addi       s13, s4, #0
    s.cmp.eq     s4, s3, s8
    s.add        s8, s12, s11
    s.sub        s11, s2, s6
    s.addi       s2, s5, #0
    s.mov        s13, s9
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s5, #31
    s.mov        s13, s4
    s.addi       s4, s5, #0
sdiv_4:
    s.lshr       s5, s9, s4
    s.shli       s6, s2, #1
    s.andi       s11, s5, #1
    s.movz       s5, #0
    s.or         s12, s6, s11
    s.movz       s6, #1
    s.cmp.geu    s11, s12, s3
    s.shl        s14, s6, s4
    s.sub        s6, s5, s11
    s.subi       s5, s4, #1
    s.and        s11, s3, s6
    s.and        s15, s14, s6
    s.sub        s6, s12, s11
    s.or         s11, s13, s15
    s.mov        s2, s6
    s.mov        s13, s11
    s.mov        s4, s5
    s.movz       s5, #0
    s.cmp.ge     s6, s4, s5
    br.nz        s6, sdiv_4
sdiv_done_3:
    s.xor        s2, s7, s1
    s.movz       s1, #16
    s.xor        s3, s13, s2
    s.mul        s4, s8, s1
    s.sub        s5, s3, s2
    s.movz       s2, #0
    s.mul        s3, s5, s1
    v.splat      v0, s8
    s.andi       s6, s4, #15
    v.splat      v1, s2
    v.splat      v2, s5
    s.andi       s5, s3, #127
    v.splat      v3, s2
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s4
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s3
    v.splat      v1, s6
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s5
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.movz       s7, #4
    s.addi       s8, s2, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s2, s8, s7
    br.nz        s2, endfor_6
    s.mul        s2, s8, s1
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s9, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.add        s11, s8, s10
    s.movz       s12, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s6                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s2                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s13, s9
    mb.wait      s9
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s14, s5                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s2                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s14, s13
    mb.wait      s13
    mb.arm       s2, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s2
    mb.wait      s2
    s.mov        s8, s11
    br.nz        s12, for_5
endfor_6:
    s.muli       s5, s3, #2                      // a runtime tile origin, x2
    s.add        s6, s16, s5                     // the tile origin
    s.muli       s5, s4, #256                    // a runtime tile origin, x256
    s.add        s7, s6, s5                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s5, #0
    s.movz       s6, #0
    s.add        s8, s6, s4                      // the tile origin
    v.splat      v0, s8
    v.splat      v1, s1
    v.cmp.lt     p1, v0, v1
    s.movz       s1, #0
    s.add        s6, s1, s3                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s6
    v.add        v3, v0, v2
    s.movz       s1, #128
    v.splat      v0, s1
    v.cmp.lt     p2, v3, v0
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s7, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s5, v2
    s.movz       s1, #1
    s.addi       s5, s7, #256                    // row 1
    s.addi       s6, s8, #1
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #2
    s.addi       s5, s7, #512                    // row 2
    s.addi       s6, s8, #2
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #3
    s.addi       s5, s7, #768                    // row 3
    s.addi       s6, s8, #3
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #4
    s.addi       s5, s7, #1024                   // row 4
    s.addi       s6, s8, #4
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #5
    s.addi       s5, s7, #1280                   // row 5
    s.addi       s6, s8, #5
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #6
    s.addi       s5, s7, #1536                   // row 6
    s.addi       s6, s8, #6
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #7
    s.addi       s5, s7, #1792                   // row 7
    s.addi       s6, s8, #7
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #8
    s.addi       s5, s7, #2048                   // row 8
    s.addi       s6, s8, #8
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #9
    s.addi       s5, s7, #2304                   // row 9
    s.addi       s6, s8, #9
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #10
    s.addi       s5, s7, #2560                   // row 10
    s.addi       s6, s8, #10
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #11
    s.addi       s5, s7, #2816                   // row 11
    s.addi       s6, s8, #11
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #12
    s.addi       s5, s7, #3072                   // row 12
    s.addi       s6, s8, #12
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #13
    s.addi       s5, s7, #3328                   // row 13
    s.addi       s6, s8, #13
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #14
    s.addi       s5, s7, #3584                   // row 14
    s.addi       s6, s8, #14
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    s.movz       s1, #15
    s.addi       s5, s7, #3840                   // row 15
    s.addi       s6, s8, #15
    v.splat      v0, s6
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s1, v2
    .li       s1, #1065353216
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.muli       s1, s3, #2                      // a runtime tile origin, x2
    s.add        s3, s19, s1                     // the tile origin
    s.muli       s1, s4, #256                    // a runtime tile origin, x256
    s.add        s4, s3, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v2, a1, s1
    s.movz       s1, #0
    a.vread      v3, a1, s1
    vf.neg       v4, v3
    .li       s1, #1069066811
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v5, v4, v3
    vf.fms       v6, v4, v3, v5                  // the exact rounding error of x*log2(e)
    v.exp2.approx v4, v5                         // ISA 8.8: <= 2**-22 relative
    .li       s1, #1060205080
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v7, v6, v5
    vf.fma       v6, v4, v7, v4                  // 2**t * 2**d
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v7, v6, v4
    vf.add       v4, v7, v0
    v.rcp.approx v6, v4                          // ISA 8.8: <= 2**-22 relative
    .li       s1, #1065353216
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v8, v4, v6, v7
    vf.fms       v4, v6, v8, v6
    vf.neg       v8, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.mul       v6, v2, v4                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #0
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v4, v2
    vf.cvt.f16.f32 v2, v4
    vf.mul       v4, v6, v2
    vf.cvt.f32.f16 v2, v4
    v.splat      v4, s8
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s4, #0], v2
    s.movz       s1, #1
    a.vread      v2, a1, s1
    s.movz       s1, #1
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #1
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s4, #256                    // row 1
    s.addi       s3, s8, #1
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #2
    a.vread      v2, a1, s1
    s.movz       s1, #2
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #2
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s4, #512                    // row 2
    s.addi       s3, s8, #2
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #3
    a.vread      v2, a1, s1
    s.movz       s1, #3
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #3
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s4, #768                    // row 3
    s.addi       s3, s8, #3
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #4
    a.vread      v2, a1, s1
    s.movz       s1, #4
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #4
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s4, #1024                   // row 4
    s.addi       s3, s8, #4
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #5
    a.vread      v2, a1, s1
    s.movz       s1, #5
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #5
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s4, #1280                   // row 5
    s.addi       s3, s8, #5
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #6
    a.vread      v2, a1, s1
    s.movz       s1, #6
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #6
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s4, #1536                   // row 6
    s.addi       s3, s8, #6
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #7
    a.vread      v2, a1, s1
    s.movz       s1, #7
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #7
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s4, #1792                   // row 7
    s.addi       s3, s8, #7
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #8
    a.vread      v2, a1, s1
    s.movz       s1, #8
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #8
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s4, #2048                   // row 8
    s.addi       s3, s8, #8
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #9
    a.vread      v2, a1, s1
    s.movz       s1, #9
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #9
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s4, #2304                   // row 9
    s.addi       s3, s8, #9
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #10
    a.vread      v2, a1, s1
    s.movz       s1, #10
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #10
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s4, #2560                   // row 10
    s.addi       s3, s8, #10
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #11
    a.vread      v2, a1, s1
    s.movz       s1, #11
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #11
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s4, #2816                   // row 11
    s.addi       s3, s8, #11
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #12
    a.vread      v2, a1, s1
    s.movz       s1, #12
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #12
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s4, #3072                   // row 12
    s.addi       s3, s8, #12
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #13
    a.vread      v2, a1, s1
    s.movz       s1, #13
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #13
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s4, #3328                   // row 13
    s.addi       s3, s8, #13
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #14
    a.vread      v2, a1, s1
    s.movz       s1, #14
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v6, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v8, v6, v4, v6                  // 2**t * 2**d
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v4, v8, v6
    vf.add       v6, v4, v0
    v.rcp.approx v4, v6                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v6, v4, v7
    vf.fms       v6, v4, v8, v4
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v8, v8
    @p1 v.sel        v6, v8, v4
    vf.mul       v4, v2, v6                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #14
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v6, v2
    vf.cvt.f16.f32 v2, v6
    vf.mul       v6, v4, v2
    vf.cvt.f32.f16 v2, v6
    s.addi       s1, s4, #3584                   // row 14
    s.addi       s3, s8, #14
    v.splat      v4, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v2
    s.movz       s1, #15
    a.vread      v2, a1, s1
    s.movz       s1, #15
    a.vread      v4, a1, s1
    vf.neg       v6, v4
    vf.mul       v4, v6, v3
    vf.fms       v8, v6, v3, v4                  // the exact rounding error of x*log2(e)
    v.exp2.approx v3, v4                         // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v8, v5
    vf.fma       v5, v3, v4, v3                  // 2**t * 2**d
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v4, v5, v3
    vf.add       v3, v4, v0
    v.rcp.approx v0, v3                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v4, v3, v0, v7
    vf.fms       v3, v0, v4, v0
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v0
    vf.mul       v0, v2, v3                      // a/y as a refined reciprocal (ISA has no divide)
    s.movz       s1, #15
    a.vread      v2, a0, s1
    vf.cvt.f32.f16 v3, v2
    vf.cvt.f16.f32 v2, v3
    vf.mul       v3, v0, v2
    vf.cvt.f32.f16 v0, v3
    s.addi       s1, s4, #3840                   // row 15
    s.addi       s3, s8, #15
    v.splat      v2, s3
    v.cmp.lt     p1, v2, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v0
__rctx_next:
    exit
