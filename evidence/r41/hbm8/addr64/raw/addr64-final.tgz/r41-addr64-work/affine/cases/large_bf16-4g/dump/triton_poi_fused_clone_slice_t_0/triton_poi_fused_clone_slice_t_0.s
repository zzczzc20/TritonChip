    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.rdspecial  s1, pid.y
    s.shli       s5, s1, #32
    s.ashri      s1, s5, #32
    s.movz       s5, #8
    s.mul        s6, s1, s5
    v.iota       v0                              // arange(0, VLEN)
    s.movz       s1, #0
    v.splat      v0, s1
    v.movi       v1, #0
    v.movi       v2, #0
    v.extract    s1, v0, #0
    s.shli       s7, s1, #32
    s.ashri      s1, s7, #32
    v.insert     v1, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v2, s7, #0
    s.movz       s1, #1
    v.splat      v0, s1
    v.movi       v3, #0
    v.movi       v4, #0
    v.extract    s1, v0, #0
    s.shli       s7, s1, #32
    s.ashri      s1, s7, #32
    v.insert     v3, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v4, s7, #0
    s.movz       s1, #2
    v.splat      v0, s1
    v.movi       v5, #0
    v.movi       v6, #0
    v.extract    s1, v0, #0
    s.shli       s7, s1, #32
    s.ashri      s1, s7, #32
    v.insert     v5, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v6, s7, #0
    s.movz       s1, #3
    v.splat      v0, s1
    v.movi       v7, #0
    v.movi       v8, #0
    v.extract    s1, v0, #0
    s.shli       s7, s1, #32
    s.ashri      s1, s7, #32
    v.insert     v7, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v8, s7, #0
    s.movz       s1, #4
    v.splat      v0, s1
    v.movi       v9, #0
    v.movi       v10, #0
    v.extract    s1, v0, #0
    s.shli       s7, s1, #32
    s.ashri      s1, s7, #32
    v.insert     v9, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v10, s7, #0
    s.movz       s1, #5
    v.splat      v0, s1
    v.movi       v11, #0
    v.movi       v12, #0
    v.extract    s1, v0, #0
    s.shli       s7, s1, #32
    s.ashri      s1, s7, #32
    v.insert     v11, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v12, s7, #0
    s.movz       s1, #6
    v.splat      v0, s1
    v.movi       v13, #0
    v.movi       v14, #0
    v.extract    s1, v0, #0
    s.shli       s7, s1, #32
    s.ashri      s1, s7, #32
    v.insert     v13, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v14, s7, #0
    s.movz       s1, #7
    v.splat      v0, s1
    v.movi       v15, #0
    v.movi       v16, #0
    v.extract    s1, v0, #0
    s.shli       s7, s1, #32
    s.ashri      s1, s7, #32
    v.insert     v15, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v16, s7, #0
    s.movz       s1, #0
    s.add        s7, s1, s6                      // the tile origin
    v.movi       v0, #0
    v.movi       v17, #0
    v.insert     v0, s7, #0
    s.lshri      s1, s7, #32
    v.insert     v17, s1, #0
    v.movi       v18, #0
    v.movi       v19, #0
    v.extract    s1, v0, #0
    v.extract    s7, v17, #0
    s.shli       s8, s7, #32
    s.or         s7, s1, s8
    v.extract    s1, v1, #0
    v.extract    s8, v2, #0
    s.shli       s9, s8, #32
    s.or         s8, s1, s9
    s.add        s1, s7, s8
    v.insert     v18, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v19, s7, #0
    s.movz       s1, #0
    s.add        s7, s1, s6                      // the tile origin
    v.movi       v0, #0
    v.movi       v1, #0
    v.insert     v0, s7, #0
    s.lshri      s1, s7, #32
    v.insert     v1, s1, #0
    v.movi       v2, #0
    v.movi       v17, #0
    v.extract    s1, v0, #0
    v.extract    s7, v1, #0
    s.shli       s8, s7, #32
    s.or         s7, s1, s8
    v.extract    s1, v3, #0
    v.extract    s8, v4, #0
    s.shli       s9, s8, #32
    s.or         s8, s1, s9
    s.add        s1, s7, s8
    v.insert     v2, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v17, s7, #0
    s.movz       s1, #0
    s.add        s7, s1, s6                      // the tile origin
    v.movi       v0, #0
    v.movi       v1, #0
    v.insert     v0, s7, #0
    s.lshri      s1, s7, #32
    v.insert     v1, s1, #0
    v.movi       v3, #0
    v.movi       v4, #0
    v.extract    s1, v0, #0
    v.extract    s7, v1, #0
    s.shli       s8, s7, #32
    s.or         s7, s1, s8
    v.extract    s1, v5, #0
    v.extract    s8, v6, #0
    s.shli       s9, s8, #32
    s.or         s8, s1, s9
    s.add        s1, s7, s8
    v.insert     v3, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v4, s7, #0
    s.movz       s1, #0
    s.add        s7, s1, s6                      // the tile origin
    v.movi       v0, #0
    v.movi       v1, #0
    v.insert     v0, s7, #0
    s.lshri      s1, s7, #32
    v.insert     v1, s1, #0
    v.movi       v5, #0
    v.movi       v6, #0
    v.extract    s1, v0, #0
    v.extract    s7, v1, #0
    s.shli       s8, s7, #32
    s.or         s7, s1, s8
    v.extract    s1, v7, #0
    v.extract    s8, v8, #0
    s.shli       s9, s8, #32
    s.or         s8, s1, s9
    s.add        s1, s7, s8
    v.insert     v5, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v6, s7, #0
    s.movz       s1, #0
    s.add        s7, s1, s6                      // the tile origin
    v.movi       v0, #0
    v.movi       v1, #0
    v.insert     v0, s7, #0
    s.lshri      s1, s7, #32
    v.insert     v1, s1, #0
    v.movi       v7, #0
    v.movi       v8, #0
    v.extract    s1, v0, #0
    v.extract    s7, v1, #0
    s.shli       s8, s7, #32
    s.or         s7, s1, s8
    v.extract    s1, v9, #0
    v.extract    s8, v10, #0
    s.shli       s9, s8, #32
    s.or         s8, s1, s9
    s.add        s1, s7, s8
    v.insert     v7, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v8, s7, #0
    s.movz       s1, #0
    s.add        s7, s1, s6                      // the tile origin
    v.movi       v0, #0
    v.movi       v1, #0
    v.insert     v0, s7, #0
    s.lshri      s1, s7, #32
    v.insert     v1, s1, #0
    v.movi       v9, #0
    v.movi       v10, #0
    v.extract    s1, v0, #0
    v.extract    s7, v1, #0
    s.shli       s8, s7, #32
    s.or         s7, s1, s8
    v.extract    s1, v11, #0
    v.extract    s8, v12, #0
    s.shli       s9, s8, #32
    s.or         s8, s1, s9
    s.add        s1, s7, s8
    v.insert     v9, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v10, s7, #0
    s.movz       s1, #0
    s.add        s7, s1, s6                      // the tile origin
    v.movi       v0, #0
    v.movi       v1, #0
    v.insert     v0, s7, #0
    s.lshri      s1, s7, #32
    v.insert     v1, s1, #0
    v.movi       v11, #0
    v.movi       v12, #0
    v.extract    s1, v0, #0
    v.extract    s7, v1, #0
    s.shli       s8, s7, #32
    s.or         s7, s1, s8
    v.extract    s1, v13, #0
    v.extract    s8, v14, #0
    s.shli       s9, s8, #32
    s.or         s8, s1, s9
    s.add        s1, s7, s8
    v.insert     v11, s1, #0
    s.lshri      s7, s1, #32
    v.insert     v12, s7, #0
    s.movz       s1, #0
    s.add        s7, s1, s6                      // the tile origin
    v.movi       v0, #0
    v.movi       v1, #0
    v.insert     v0, s7, #0
    s.lshri      s1, s7, #32
    v.insert     v1, s1, #0
    v.movi       v13, #0
    v.movi       v14, #0
    v.extract    s1, v0, #0
    v.extract    s6, v1, #0
    s.shli       s7, s6, #32
    s.or         s6, s1, s7
    v.extract    s1, v15, #0
    v.extract    s7, v16, #0
    s.shli       s8, s7, #32
    s.or         s7, s1, s8
    s.add        s1, s6, s7
    v.insert     v13, s1, #0
    s.lshri      s6, s1, #32
    v.insert     v14, s6, #0
    v.movi       v0, #0
    v.extract    s1, v18, #0
    v.extract    s6, v19, #0
    s.shli       s7, s6, #32
    s.or         s6, s1, s7
    s.movz       s1, #48
    s.cmp.lt     s7, s6, s1
    v.insert     v0, s7, #0
    v.movi       v1, #0
    v.cmp.ne     p1, v0, v1
    v.movi       v0, #1
    v.movi       v1, #0
    @p1 v.sel        v15, v0, v1
    v.extract    s1, v15, #0
    v.splat      v0, s1
    v.movi       v1, #0
    v.cmp.ne     p1, v0, v1
    v.movi       v0, #0
    v.extract    s1, v2, #0
    v.extract    s6, v17, #0
    s.shli       s7, s6, #32
    s.or         s6, s1, s7
    s.movz       s1, #48
    s.cmp.lt     s7, s6, s1
    v.insert     v0, s7, #0
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    v.movi       v0, #1
    v.movi       v1, #0
    @p2 v.sel        v15, v0, v1
    v.extract    s1, v15, #0
    v.splat      v0, s1
    v.movi       v1, #0
    v.cmp.ne     p2, v0, v1
    v.movi       v0, #0
    v.extract    s1, v3, #0
    v.extract    s6, v4, #0
    s.shli       s7, s6, #32
    s.or         s6, s1, s7
    s.movz       s1, #48
    s.cmp.lt     s7, s6, s1
    v.insert     v0, s7, #0
    v.movi       v1, #0
    v.cmp.ne     p3, v0, v1
    v.movi       v0, #1
    v.movi       v1, #0
    @p3 v.sel        v15, v0, v1
    v.extract    s1, v15, #0
    v.splat      v0, s1
    v.movi       v1, #0
    v.cmp.ne     p3, v0, v1
    v.movi       v0, #0
    v.extract    s1, v5, #0
    v.extract    s6, v6, #0
    s.shli       s7, s6, #32
    s.or         s6, s1, s7
    s.movz       s1, #48
    s.cmp.lt     s7, s6, s1
    v.insert     v0, s7, #0
    v.movi       v1, #0
    v.cmp.ne     p4, v0, v1
    v.movi       v0, #1
    v.movi       v1, #0
    @p4 v.sel        v15, v0, v1
    v.extract    s1, v15, #0
    v.splat      v0, s1
    v.movi       v1, #0
    v.cmp.ne     p4, v0, v1
    v.movi       v0, #0
    v.extract    s1, v7, #0
    v.extract    s6, v8, #0
    s.shli       s7, s6, #32
    s.or         s6, s1, s7
    s.movz       s1, #48
    s.cmp.lt     s7, s6, s1
    v.insert     v0, s7, #0
    v.movi       v1, #0
    v.cmp.ne     p5, v0, v1
    v.movi       v0, #1
    v.movi       v1, #0
    @p5 v.sel        v15, v0, v1
    v.extract    s1, v15, #0
    v.splat      v0, s1
    v.movi       v1, #0
    v.cmp.ne     p5, v0, v1
    v.movi       v0, #0
    v.extract    s1, v9, #0
    v.extract    s6, v10, #0
    s.shli       s7, s6, #32
    s.or         s6, s1, s7
    s.movz       s1, #48
    s.cmp.lt     s7, s6, s1
    v.insert     v0, s7, #0
    v.movi       v1, #0
    v.cmp.ne     p6, v0, v1
    v.movi       v0, #1
    v.movi       v1, #0
    @p6 v.sel        v15, v0, v1
    v.extract    s1, v15, #0
    v.splat      v0, s1
    v.movi       v1, #0
    v.cmp.ne     p6, v0, v1
    v.movi       v0, #0
    v.extract    s1, v11, #0
    v.extract    s6, v12, #0
    s.shli       s7, s6, #32
    s.or         s6, s1, s7
    s.movz       s1, #48
    s.cmp.lt     s7, s6, s1
    v.insert     v0, s7, #0
    v.movi       v1, #0
    v.cmp.ne     p7, v0, v1
    v.movi       v0, #1
    v.movi       v1, #0
    @p7 v.sel        v15, v0, v1
    v.extract    s1, v15, #0
    v.splat      v0, s1
    v.movi       v1, #0
    v.cmp.ne     p7, v0, v1
    v.movi       v0, #0
    v.extract    s1, v13, #0
    v.extract    s6, v14, #0
    s.shli       s7, s6, #32
    s.or         s6, s1, s7
    s.movz       s1, #48
    s.cmp.lt     s7, s6, s1
    v.insert     v0, s7, #0
    v.movi       v1, #0
    v.cmp.ne     p8, v0, v1
    v.movi       v0, #1
    v.movi       v1, #0
    @p8 v.sel        v15, v0, v1
    v.extract    s1, v15, #0
    v.splat      v0, s1
    v.movi       v1, #0
    v.cmp.ne     p8, v0, v1
    s.shli       s1, s4, #32
    s.ashri      s4, s1, #32
    s.mul        s1, s4, s5
    v.movi       v0, #0
    v.movi       v1, #0
    v.iota       v15                             // arange(0, VLEN)
    v.extract    s4, v15, #0
    s.shli       s5, s4, #32
    s.ashri      s4, s5, #32
    v.insert     v0, s4, #0
    s.lshri      s5, s4, #32
    v.insert     v1, s5, #0
    v.extract    s4, v15, #1
    s.shli       s5, s4, #32
    s.ashri      s4, s5, #32
    v.insert     v0, s4, #1
    s.lshri      s5, s4, #32
    v.insert     v1, s5, #1
    v.extract    s4, v15, #2
    s.shli       s5, s4, #32
    s.ashri      s4, s5, #32
    v.insert     v0, s4, #2
    s.lshri      s5, s4, #32
    v.insert     v1, s5, #2
    v.extract    s4, v15, #3
    s.shli       s5, s4, #32
    s.ashri      s4, s5, #32
    v.insert     v0, s4, #3
    s.lshri      s5, s4, #32
    v.insert     v1, s5, #3
    v.extract    s4, v15, #4
    s.shli       s5, s4, #32
    s.ashri      s4, s5, #32
    v.insert     v0, s4, #4
    s.lshri      s5, s4, #32
    v.insert     v1, s5, #4
    v.extract    s4, v15, #5
    s.shli       s5, s4, #32
    s.ashri      s4, s5, #32
    v.insert     v0, s4, #5
    s.lshri      s5, s4, #32
    v.insert     v1, s5, #5
    v.extract    s4, v15, #6
    s.shli       s5, s4, #32
    s.ashri      s4, s5, #32
    v.insert     v0, s4, #6
    s.lshri      s5, s4, #32
    v.insert     v1, s5, #6
    v.extract    s4, v15, #7
    s.shli       s5, s4, #32
    s.ashri      s4, s5, #32
    v.insert     v0, s4, #7
    s.lshri      s5, s4, #32
    v.insert     v1, s5, #7
    s.movz       s4, #0
    s.add        s5, s4, s1                      // the tile origin
    v.movi       v15, #0
    v.movi       v16, #0
    v.insert     v15, s5, #0
    s.lshri      s1, s5, #32
    v.insert     v16, s1, #0
    v.insert     v15, s5, #1
    s.lshri      s1, s5, #32
    v.insert     v16, s1, #1
    v.insert     v15, s5, #2
    s.lshri      s1, s5, #32
    v.insert     v16, s1, #2
    v.insert     v15, s5, #3
    s.lshri      s1, s5, #32
    v.insert     v16, s1, #3
    v.insert     v15, s5, #4
    s.lshri      s1, s5, #32
    v.insert     v16, s1, #4
    v.insert     v15, s5, #5
    s.lshri      s1, s5, #32
    v.insert     v16, s1, #5
    v.insert     v15, s5, #6
    s.lshri      s1, s5, #32
    v.insert     v16, s1, #6
    v.insert     v15, s5, #7
    s.lshri      s1, s5, #32
    v.insert     v16, s1, #7
    v.movi       v20, #0
    v.movi       v21, #0
    v.extract    s1, v15, #0
    v.extract    s4, v16, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v0, #0
    v.extract    s5, v1, #0
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v20, s1, #0
    s.lshri      s4, s1, #32
    v.insert     v21, s4, #0
    v.extract    s1, v15, #1
    v.extract    s4, v16, #1
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v0, #1
    v.extract    s5, v1, #1
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v20, s1, #1
    s.lshri      s4, s1, #32
    v.insert     v21, s4, #1
    v.extract    s1, v15, #2
    v.extract    s4, v16, #2
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v0, #2
    v.extract    s5, v1, #2
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v20, s1, #2
    s.lshri      s4, s1, #32
    v.insert     v21, s4, #2
    v.extract    s1, v15, #3
    v.extract    s4, v16, #3
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v0, #3
    v.extract    s5, v1, #3
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v20, s1, #3
    s.lshri      s4, s1, #32
    v.insert     v21, s4, #3
    v.extract    s1, v15, #4
    v.extract    s4, v16, #4
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v0, #4
    v.extract    s5, v1, #4
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v20, s1, #4
    s.lshri      s4, s1, #32
    v.insert     v21, s4, #4
    v.extract    s1, v15, #5
    v.extract    s4, v16, #5
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v0, #5
    v.extract    s5, v1, #5
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v20, s1, #5
    s.lshri      s4, s1, #32
    v.insert     v21, s4, #5
    v.extract    s1, v15, #6
    v.extract    s4, v16, #6
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v0, #6
    v.extract    s5, v1, #6
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v20, s1, #6
    s.lshri      s4, s1, #32
    v.insert     v21, s4, #6
    v.extract    s1, v15, #7
    v.extract    s4, v16, #7
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v0, #7
    v.extract    s5, v1, #7
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v20, s1, #7
    s.lshri      s4, s1, #32
    v.insert     v21, s4, #7
    v.movi       v0, #0
    v.extract    s1, v20, #0
    v.extract    s4, v21, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #16
    s.cmp.lt     s5, s4, s1
    v.insert     v0, s5, #0
    v.extract    s1, v20, #1
    v.extract    s4, v21, #1
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #16
    s.cmp.lt     s5, s4, s1
    v.insert     v0, s5, #1
    v.extract    s1, v20, #2
    v.extract    s4, v21, #2
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #16
    s.cmp.lt     s5, s4, s1
    v.insert     v0, s5, #2
    v.extract    s1, v20, #3
    v.extract    s4, v21, #3
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #16
    s.cmp.lt     s5, s4, s1
    v.insert     v0, s5, #3
    v.extract    s1, v20, #4
    v.extract    s4, v21, #4
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #16
    s.cmp.lt     s5, s4, s1
    v.insert     v0, s5, #4
    v.extract    s1, v20, #5
    v.extract    s4, v21, #5
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #16
    s.cmp.lt     s5, s4, s1
    v.insert     v0, s5, #5
    v.extract    s1, v20, #6
    v.extract    s4, v21, #6
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #16
    s.cmp.lt     s5, s4, s1
    v.insert     v0, s5, #6
    v.extract    s1, v20, #7
    v.extract    s4, v21, #7
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #16
    s.cmp.lt     s5, s4, s1
    v.insert     v0, s5, #7
    v.movi       v1, #0
    v.cmp.ne     p9, v0, v1
    v.movi       v0, #0
    v.movi       v1, #0
    v.extract    s1, v18, #0
    v.extract    s4, v19, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    .li       s1, #2281670608
    s.add        s5, s4, s1
    v.insert     v0, s5, #0
    s.lshri      s1, s5, #32
    v.insert     v1, s1, #0
    v.movi       v15, #0
    v.movi       v16, #0
    v.extract    s1, v2, #0
    v.extract    s4, v17, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    .li       s1, #2281670608
    s.add        s5, s4, s1
    v.insert     v15, s5, #0
    s.lshri      s1, s5, #32
    v.insert     v16, s1, #0
    v.movi       v22, #0
    v.movi       v23, #0
    v.extract    s1, v3, #0
    v.extract    s4, v4, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    .li       s1, #2281670608
    s.add        s5, s4, s1
    v.insert     v22, s5, #0
    s.lshri      s1, s5, #32
    v.insert     v23, s1, #0
    v.movi       v24, #0
    v.movi       v25, #0
    v.extract    s1, v5, #0
    v.extract    s4, v6, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    .li       s1, #2281670608
    s.add        s5, s4, s1
    v.insert     v24, s5, #0
    s.lshri      s1, s5, #32
    v.insert     v25, s1, #0
    v.movi       v26, #0
    v.movi       v27, #0
    v.extract    s1, v7, #0
    v.extract    s4, v8, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    .li       s1, #2281670608
    s.add        s5, s4, s1
    v.insert     v26, s5, #0
    s.lshri      s1, s5, #32
    v.insert     v27, s1, #0
    v.movi       v28, #0
    v.movi       v29, #0
    v.extract    s1, v9, #0
    v.extract    s4, v10, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    .li       s1, #2281670608
    s.add        s5, s4, s1
    v.insert     v28, s5, #0
    s.lshri      s1, s5, #32
    v.insert     v29, s1, #0
    v.movi       v30, #0
    v.movi       v31, #0
    v.extract    s1, v11, #0
    v.extract    s4, v12, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    .li       s1, #2281670608
    s.add        s5, s4, s1
    v.insert     v30, s5, #0
    s.lshri      s1, s5, #32
    v.insert     v31, s1, #0
    v.movi       v32, #0
    v.movi       v33, #0
    v.extract    s1, v13, #0
    v.extract    s4, v14, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    .li       s1, #2281670608
    s.add        s5, s4, s1
    v.insert     v32, s5, #0
    s.lshri      s1, s5, #32
    v.insert     v33, s1, #0
    v.movi       v34, #0
    v.movi       v35, #0
    v.extract    s1, v20, #0
    v.extract    s4, v21, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #2048
    s.mul        s5, s4, s1
    v.insert     v34, s5, #0
    s.lshri      s1, s5, #32
    v.insert     v35, s1, #0
    v.extract    s1, v20, #1
    v.extract    s4, v21, #1
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #2048
    s.mul        s5, s4, s1
    v.insert     v34, s5, #1
    s.lshri      s1, s5, #32
    v.insert     v35, s1, #1
    v.extract    s1, v20, #2
    v.extract    s4, v21, #2
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #2048
    s.mul        s5, s4, s1
    v.insert     v34, s5, #2
    s.lshri      s1, s5, #32
    v.insert     v35, s1, #2
    v.extract    s1, v20, #3
    v.extract    s4, v21, #3
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #2048
    s.mul        s5, s4, s1
    v.insert     v34, s5, #3
    s.lshri      s1, s5, #32
    v.insert     v35, s1, #3
    v.extract    s1, v20, #4
    v.extract    s4, v21, #4
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #2048
    s.mul        s5, s4, s1
    v.insert     v34, s5, #4
    s.lshri      s1, s5, #32
    v.insert     v35, s1, #4
    v.extract    s1, v20, #5
    v.extract    s4, v21, #5
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #2048
    s.mul        s5, s4, s1
    v.insert     v34, s5, #5
    s.lshri      s1, s5, #32
    v.insert     v35, s1, #5
    v.extract    s1, v20, #6
    v.extract    s4, v21, #6
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #2048
    s.mul        s5, s4, s1
    v.insert     v34, s5, #6
    s.lshri      s1, s5, #32
    v.insert     v35, s1, #6
    v.extract    s1, v20, #7
    v.extract    s4, v21, #7
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    s.movz       s1, #2048
    s.mul        s5, s4, s1
    v.insert     v34, s5, #7
    s.lshri      s1, s5, #32
    v.insert     v35, s1, #7
    v.movi       v36, #0
    v.movi       v37, #0
    v.extract    s1, v0, #0
    v.extract    s4, v1, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v36, s4, #0
    s.lshri      s1, s4, #32
    v.insert     v37, s1, #0
    v.extract    s1, v0, #0
    v.extract    s4, v1, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v36, s4, #1
    s.lshri      s1, s4, #32
    v.insert     v37, s1, #1
    v.extract    s1, v0, #0
    v.extract    s4, v1, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v36, s4, #2
    s.lshri      s1, s4, #32
    v.insert     v37, s1, #2
    v.extract    s1, v0, #0
    v.extract    s4, v1, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v36, s4, #3
    s.lshri      s1, s4, #32
    v.insert     v37, s1, #3
    v.extract    s1, v0, #0
    v.extract    s4, v1, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v36, s4, #4
    s.lshri      s1, s4, #32
    v.insert     v37, s1, #4
    v.extract    s1, v0, #0
    v.extract    s4, v1, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v36, s4, #5
    s.lshri      s1, s4, #32
    v.insert     v37, s1, #5
    v.extract    s1, v0, #0
    v.extract    s4, v1, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v36, s4, #6
    s.lshri      s1, s4, #32
    v.insert     v37, s1, #6
    v.extract    s1, v0, #0
    v.extract    s4, v1, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v36, s4, #7
    s.lshri      s1, s4, #32
    v.insert     v37, s1, #7
    v.movi       v0, #0
    v.movi       v1, #0
    v.extract    s1, v15, #0
    v.extract    s4, v16, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v0, s4, #0
    s.lshri      s1, s4, #32
    v.insert     v1, s1, #0
    v.extract    s1, v15, #0
    v.extract    s4, v16, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v0, s4, #1
    s.lshri      s1, s4, #32
    v.insert     v1, s1, #1
    v.extract    s1, v15, #0
    v.extract    s4, v16, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v0, s4, #2
    s.lshri      s1, s4, #32
    v.insert     v1, s1, #2
    v.extract    s1, v15, #0
    v.extract    s4, v16, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v0, s4, #3
    s.lshri      s1, s4, #32
    v.insert     v1, s1, #3
    v.extract    s1, v15, #0
    v.extract    s4, v16, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v0, s4, #4
    s.lshri      s1, s4, #32
    v.insert     v1, s1, #4
    v.extract    s1, v15, #0
    v.extract    s4, v16, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v0, s4, #5
    s.lshri      s1, s4, #32
    v.insert     v1, s1, #5
    v.extract    s1, v15, #0
    v.extract    s4, v16, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v0, s4, #6
    s.lshri      s1, s4, #32
    v.insert     v1, s1, #6
    v.extract    s1, v15, #0
    v.extract    s4, v16, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v0, s4, #7
    s.lshri      s1, s4, #32
    v.insert     v1, s1, #7
    v.movi       v15, #0
    v.movi       v16, #0
    v.extract    s1, v22, #0
    v.extract    s4, v23, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v15, s4, #0
    s.lshri      s1, s4, #32
    v.insert     v16, s1, #0
    v.extract    s1, v22, #0
    v.extract    s4, v23, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v15, s4, #1
    s.lshri      s1, s4, #32
    v.insert     v16, s1, #1
    v.extract    s1, v22, #0
    v.extract    s4, v23, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v15, s4, #2
    s.lshri      s1, s4, #32
    v.insert     v16, s1, #2
    v.extract    s1, v22, #0
    v.extract    s4, v23, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v15, s4, #3
    s.lshri      s1, s4, #32
    v.insert     v16, s1, #3
    v.extract    s1, v22, #0
    v.extract    s4, v23, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v15, s4, #4
    s.lshri      s1, s4, #32
    v.insert     v16, s1, #4
    v.extract    s1, v22, #0
    v.extract    s4, v23, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v15, s4, #5
    s.lshri      s1, s4, #32
    v.insert     v16, s1, #5
    v.extract    s1, v22, #0
    v.extract    s4, v23, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v15, s4, #6
    s.lshri      s1, s4, #32
    v.insert     v16, s1, #6
    v.extract    s1, v22, #0
    v.extract    s4, v23, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v15, s4, #7
    s.lshri      s1, s4, #32
    v.insert     v16, s1, #7
    v.movi       v22, #0
    v.movi       v23, #0
    v.extract    s1, v24, #0
    v.extract    s4, v25, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v22, s4, #0
    s.lshri      s1, s4, #32
    v.insert     v23, s1, #0
    v.extract    s1, v24, #0
    v.extract    s4, v25, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v22, s4, #1
    s.lshri      s1, s4, #32
    v.insert     v23, s1, #1
    v.extract    s1, v24, #0
    v.extract    s4, v25, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v22, s4, #2
    s.lshri      s1, s4, #32
    v.insert     v23, s1, #2
    v.extract    s1, v24, #0
    v.extract    s4, v25, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v22, s4, #3
    s.lshri      s1, s4, #32
    v.insert     v23, s1, #3
    v.extract    s1, v24, #0
    v.extract    s4, v25, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v22, s4, #4
    s.lshri      s1, s4, #32
    v.insert     v23, s1, #4
    v.extract    s1, v24, #0
    v.extract    s4, v25, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v22, s4, #5
    s.lshri      s1, s4, #32
    v.insert     v23, s1, #5
    v.extract    s1, v24, #0
    v.extract    s4, v25, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v22, s4, #6
    s.lshri      s1, s4, #32
    v.insert     v23, s1, #6
    v.extract    s1, v24, #0
    v.extract    s4, v25, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v22, s4, #7
    s.lshri      s1, s4, #32
    v.insert     v23, s1, #7
    v.movi       v24, #0
    v.movi       v25, #0
    v.extract    s1, v26, #0
    v.extract    s4, v27, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v24, s4, #0
    s.lshri      s1, s4, #32
    v.insert     v25, s1, #0
    v.extract    s1, v26, #0
    v.extract    s4, v27, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v24, s4, #1
    s.lshri      s1, s4, #32
    v.insert     v25, s1, #1
    v.extract    s1, v26, #0
    v.extract    s4, v27, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v24, s4, #2
    s.lshri      s1, s4, #32
    v.insert     v25, s1, #2
    v.extract    s1, v26, #0
    v.extract    s4, v27, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v24, s4, #3
    s.lshri      s1, s4, #32
    v.insert     v25, s1, #3
    v.extract    s1, v26, #0
    v.extract    s4, v27, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v24, s4, #4
    s.lshri      s1, s4, #32
    v.insert     v25, s1, #4
    v.extract    s1, v26, #0
    v.extract    s4, v27, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v24, s4, #5
    s.lshri      s1, s4, #32
    v.insert     v25, s1, #5
    v.extract    s1, v26, #0
    v.extract    s4, v27, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v24, s4, #6
    s.lshri      s1, s4, #32
    v.insert     v25, s1, #6
    v.extract    s1, v26, #0
    v.extract    s4, v27, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v24, s4, #7
    s.lshri      s1, s4, #32
    v.insert     v25, s1, #7
    v.movi       v26, #0
    v.movi       v27, #0
    v.extract    s1, v28, #0
    v.extract    s4, v29, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v26, s4, #0
    s.lshri      s1, s4, #32
    v.insert     v27, s1, #0
    v.extract    s1, v28, #0
    v.extract    s4, v29, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v26, s4, #1
    s.lshri      s1, s4, #32
    v.insert     v27, s1, #1
    v.extract    s1, v28, #0
    v.extract    s4, v29, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v26, s4, #2
    s.lshri      s1, s4, #32
    v.insert     v27, s1, #2
    v.extract    s1, v28, #0
    v.extract    s4, v29, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v26, s4, #3
    s.lshri      s1, s4, #32
    v.insert     v27, s1, #3
    v.extract    s1, v28, #0
    v.extract    s4, v29, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v26, s4, #4
    s.lshri      s1, s4, #32
    v.insert     v27, s1, #4
    v.extract    s1, v28, #0
    v.extract    s4, v29, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v26, s4, #5
    s.lshri      s1, s4, #32
    v.insert     v27, s1, #5
    v.extract    s1, v28, #0
    v.extract    s4, v29, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v26, s4, #6
    s.lshri      s1, s4, #32
    v.insert     v27, s1, #6
    v.extract    s1, v28, #0
    v.extract    s4, v29, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v26, s4, #7
    s.lshri      s1, s4, #32
    v.insert     v27, s1, #7
    v.movi       v28, #0
    v.movi       v29, #0
    v.extract    s1, v30, #0
    v.extract    s4, v31, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v28, s4, #0
    s.lshri      s1, s4, #32
    v.insert     v29, s1, #0
    v.extract    s1, v30, #0
    v.extract    s4, v31, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v28, s4, #1
    s.lshri      s1, s4, #32
    v.insert     v29, s1, #1
    v.extract    s1, v30, #0
    v.extract    s4, v31, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v28, s4, #2
    s.lshri      s1, s4, #32
    v.insert     v29, s1, #2
    v.extract    s1, v30, #0
    v.extract    s4, v31, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v28, s4, #3
    s.lshri      s1, s4, #32
    v.insert     v29, s1, #3
    v.extract    s1, v30, #0
    v.extract    s4, v31, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v28, s4, #4
    s.lshri      s1, s4, #32
    v.insert     v29, s1, #4
    v.extract    s1, v30, #0
    v.extract    s4, v31, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v28, s4, #5
    s.lshri      s1, s4, #32
    v.insert     v29, s1, #5
    v.extract    s1, v30, #0
    v.extract    s4, v31, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v28, s4, #6
    s.lshri      s1, s4, #32
    v.insert     v29, s1, #6
    v.extract    s1, v30, #0
    v.extract    s4, v31, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v28, s4, #7
    s.lshri      s1, s4, #32
    v.insert     v29, s1, #7
    v.movi       v30, #0
    v.movi       v31, #0
    v.extract    s1, v32, #0
    v.extract    s4, v33, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v30, s4, #0
    s.lshri      s1, s4, #32
    v.insert     v31, s1, #0
    v.extract    s1, v32, #0
    v.extract    s4, v33, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v30, s4, #1
    s.lshri      s1, s4, #32
    v.insert     v31, s1, #1
    v.extract    s1, v32, #0
    v.extract    s4, v33, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v30, s4, #2
    s.lshri      s1, s4, #32
    v.insert     v31, s1, #2
    v.extract    s1, v32, #0
    v.extract    s4, v33, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v30, s4, #3
    s.lshri      s1, s4, #32
    v.insert     v31, s1, #3
    v.extract    s1, v32, #0
    v.extract    s4, v33, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v30, s4, #4
    s.lshri      s1, s4, #32
    v.insert     v31, s1, #4
    v.extract    s1, v32, #0
    v.extract    s4, v33, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v30, s4, #5
    s.lshri      s1, s4, #32
    v.insert     v31, s1, #5
    v.extract    s1, v32, #0
    v.extract    s4, v33, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v30, s4, #6
    s.lshri      s1, s4, #32
    v.insert     v31, s1, #6
    v.extract    s1, v32, #0
    v.extract    s4, v33, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.insert     v30, s4, #7
    s.lshri      s1, s4, #32
    v.insert     v31, s1, #7
    v.movi       v32, #0
    v.movi       v33, #0
    v.extract    s1, v36, #0
    v.extract    s4, v37, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #0
    v.extract    s5, v35, #0
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v32, s1, #0
    s.lshri      s4, s1, #32
    v.insert     v33, s4, #0
    v.extract    s1, v36, #1
    v.extract    s4, v37, #1
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #1
    v.extract    s5, v35, #1
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v32, s1, #1
    s.lshri      s4, s1, #32
    v.insert     v33, s4, #1
    v.extract    s1, v36, #2
    v.extract    s4, v37, #2
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #2
    v.extract    s5, v35, #2
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v32, s1, #2
    s.lshri      s4, s1, #32
    v.insert     v33, s4, #2
    v.extract    s1, v36, #3
    v.extract    s4, v37, #3
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #3
    v.extract    s5, v35, #3
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v32, s1, #3
    s.lshri      s4, s1, #32
    v.insert     v33, s4, #3
    v.extract    s1, v36, #4
    v.extract    s4, v37, #4
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #4
    v.extract    s5, v35, #4
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v32, s1, #4
    s.lshri      s4, s1, #32
    v.insert     v33, s4, #4
    v.extract    s1, v36, #5
    v.extract    s4, v37, #5
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #5
    v.extract    s5, v35, #5
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v32, s1, #5
    s.lshri      s4, s1, #32
    v.insert     v33, s4, #5
    v.extract    s1, v36, #6
    v.extract    s4, v37, #6
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #6
    v.extract    s5, v35, #6
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v32, s1, #6
    s.lshri      s4, s1, #32
    v.insert     v33, s4, #6
    v.extract    s1, v36, #7
    v.extract    s4, v37, #7
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #7
    v.extract    s5, v35, #7
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v32, s1, #7
    s.lshri      s4, s1, #32
    v.insert     v33, s4, #7
    v.movi       v36, #0
    v.movi       v37, #0
    v.extract    s1, v0, #0
    v.extract    s4, v1, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #0
    v.extract    s5, v35, #0
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v36, s1, #0
    s.lshri      s4, s1, #32
    v.insert     v37, s4, #0
    v.extract    s1, v0, #1
    v.extract    s4, v1, #1
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #1
    v.extract    s5, v35, #1
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v36, s1, #1
    s.lshri      s4, s1, #32
    v.insert     v37, s4, #1
    v.extract    s1, v0, #2
    v.extract    s4, v1, #2
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #2
    v.extract    s5, v35, #2
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v36, s1, #2
    s.lshri      s4, s1, #32
    v.insert     v37, s4, #2
    v.extract    s1, v0, #3
    v.extract    s4, v1, #3
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #3
    v.extract    s5, v35, #3
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v36, s1, #3
    s.lshri      s4, s1, #32
    v.insert     v37, s4, #3
    v.extract    s1, v0, #4
    v.extract    s4, v1, #4
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #4
    v.extract    s5, v35, #4
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v36, s1, #4
    s.lshri      s4, s1, #32
    v.insert     v37, s4, #4
    v.extract    s1, v0, #5
    v.extract    s4, v1, #5
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #5
    v.extract    s5, v35, #5
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v36, s1, #5
    s.lshri      s4, s1, #32
    v.insert     v37, s4, #5
    v.extract    s1, v0, #6
    v.extract    s4, v1, #6
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #6
    v.extract    s5, v35, #6
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v36, s1, #6
    s.lshri      s4, s1, #32
    v.insert     v37, s4, #6
    v.extract    s1, v0, #7
    v.extract    s4, v1, #7
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #7
    v.extract    s5, v35, #7
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v36, s1, #7
    s.lshri      s4, s1, #32
    v.insert     v37, s4, #7
    v.movi       v0, #0
    v.movi       v1, #0
    v.extract    s1, v15, #0
    v.extract    s4, v16, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #0
    v.extract    s5, v35, #0
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v0, s1, #0
    s.lshri      s4, s1, #32
    v.insert     v1, s4, #0
    v.extract    s1, v15, #1
    v.extract    s4, v16, #1
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #1
    v.extract    s5, v35, #1
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v0, s1, #1
    s.lshri      s4, s1, #32
    v.insert     v1, s4, #1
    v.extract    s1, v15, #2
    v.extract    s4, v16, #2
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #2
    v.extract    s5, v35, #2
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v0, s1, #2
    s.lshri      s4, s1, #32
    v.insert     v1, s4, #2
    v.extract    s1, v15, #3
    v.extract    s4, v16, #3
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #3
    v.extract    s5, v35, #3
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v0, s1, #3
    s.lshri      s4, s1, #32
    v.insert     v1, s4, #3
    v.extract    s1, v15, #4
    v.extract    s4, v16, #4
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #4
    v.extract    s5, v35, #4
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v0, s1, #4
    s.lshri      s4, s1, #32
    v.insert     v1, s4, #4
    v.extract    s1, v15, #5
    v.extract    s4, v16, #5
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #5
    v.extract    s5, v35, #5
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v0, s1, #5
    s.lshri      s4, s1, #32
    v.insert     v1, s4, #5
    v.extract    s1, v15, #6
    v.extract    s4, v16, #6
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #6
    v.extract    s5, v35, #6
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v0, s1, #6
    s.lshri      s4, s1, #32
    v.insert     v1, s4, #6
    v.extract    s1, v15, #7
    v.extract    s4, v16, #7
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #7
    v.extract    s5, v35, #7
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v0, s1, #7
    s.lshri      s4, s1, #32
    v.insert     v1, s4, #7
    v.movi       v15, #0
    v.movi       v16, #0
    v.extract    s1, v22, #0
    v.extract    s4, v23, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #0
    v.extract    s5, v35, #0
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v15, s1, #0
    s.lshri      s4, s1, #32
    v.insert     v16, s4, #0
    v.extract    s1, v22, #1
    v.extract    s4, v23, #1
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #1
    v.extract    s5, v35, #1
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v15, s1, #1
    s.lshri      s4, s1, #32
    v.insert     v16, s4, #1
    v.extract    s1, v22, #2
    v.extract    s4, v23, #2
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #2
    v.extract    s5, v35, #2
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v15, s1, #2
    s.lshri      s4, s1, #32
    v.insert     v16, s4, #2
    v.extract    s1, v22, #3
    v.extract    s4, v23, #3
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #3
    v.extract    s5, v35, #3
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v15, s1, #3
    s.lshri      s4, s1, #32
    v.insert     v16, s4, #3
    v.extract    s1, v22, #4
    v.extract    s4, v23, #4
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #4
    v.extract    s5, v35, #4
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v15, s1, #4
    s.lshri      s4, s1, #32
    v.insert     v16, s4, #4
    v.extract    s1, v22, #5
    v.extract    s4, v23, #5
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #5
    v.extract    s5, v35, #5
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v15, s1, #5
    s.lshri      s4, s1, #32
    v.insert     v16, s4, #5
    v.extract    s1, v22, #6
    v.extract    s4, v23, #6
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #6
    v.extract    s5, v35, #6
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v15, s1, #6
    s.lshri      s4, s1, #32
    v.insert     v16, s4, #6
    v.extract    s1, v22, #7
    v.extract    s4, v23, #7
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #7
    v.extract    s5, v35, #7
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v15, s1, #7
    s.lshri      s4, s1, #32
    v.insert     v16, s4, #7
    v.movi       v22, #0
    v.movi       v23, #0
    v.extract    s1, v24, #0
    v.extract    s4, v25, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #0
    v.extract    s5, v35, #0
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v22, s1, #0
    s.lshri      s4, s1, #32
    v.insert     v23, s4, #0
    v.extract    s1, v24, #1
    v.extract    s4, v25, #1
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #1
    v.extract    s5, v35, #1
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v22, s1, #1
    s.lshri      s4, s1, #32
    v.insert     v23, s4, #1
    v.extract    s1, v24, #2
    v.extract    s4, v25, #2
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #2
    v.extract    s5, v35, #2
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v22, s1, #2
    s.lshri      s4, s1, #32
    v.insert     v23, s4, #2
    v.extract    s1, v24, #3
    v.extract    s4, v25, #3
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #3
    v.extract    s5, v35, #3
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v22, s1, #3
    s.lshri      s4, s1, #32
    v.insert     v23, s4, #3
    v.extract    s1, v24, #4
    v.extract    s4, v25, #4
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #4
    v.extract    s5, v35, #4
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v22, s1, #4
    s.lshri      s4, s1, #32
    v.insert     v23, s4, #4
    v.extract    s1, v24, #5
    v.extract    s4, v25, #5
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #5
    v.extract    s5, v35, #5
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v22, s1, #5
    s.lshri      s4, s1, #32
    v.insert     v23, s4, #5
    v.extract    s1, v24, #6
    v.extract    s4, v25, #6
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #6
    v.extract    s5, v35, #6
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v22, s1, #6
    s.lshri      s4, s1, #32
    v.insert     v23, s4, #6
    v.extract    s1, v24, #7
    v.extract    s4, v25, #7
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #7
    v.extract    s5, v35, #7
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v22, s1, #7
    s.lshri      s4, s1, #32
    v.insert     v23, s4, #7
    v.movi       v24, #0
    v.movi       v25, #0
    v.extract    s1, v26, #0
    v.extract    s4, v27, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #0
    v.extract    s5, v35, #0
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v24, s1, #0
    s.lshri      s4, s1, #32
    v.insert     v25, s4, #0
    v.extract    s1, v26, #1
    v.extract    s4, v27, #1
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #1
    v.extract    s5, v35, #1
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v24, s1, #1
    s.lshri      s4, s1, #32
    v.insert     v25, s4, #1
    v.extract    s1, v26, #2
    v.extract    s4, v27, #2
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #2
    v.extract    s5, v35, #2
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v24, s1, #2
    s.lshri      s4, s1, #32
    v.insert     v25, s4, #2
    v.extract    s1, v26, #3
    v.extract    s4, v27, #3
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #3
    v.extract    s5, v35, #3
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v24, s1, #3
    s.lshri      s4, s1, #32
    v.insert     v25, s4, #3
    v.extract    s1, v26, #4
    v.extract    s4, v27, #4
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #4
    v.extract    s5, v35, #4
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v24, s1, #4
    s.lshri      s4, s1, #32
    v.insert     v25, s4, #4
    v.extract    s1, v26, #5
    v.extract    s4, v27, #5
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #5
    v.extract    s5, v35, #5
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v24, s1, #5
    s.lshri      s4, s1, #32
    v.insert     v25, s4, #5
    v.extract    s1, v26, #6
    v.extract    s4, v27, #6
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #6
    v.extract    s5, v35, #6
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v24, s1, #6
    s.lshri      s4, s1, #32
    v.insert     v25, s4, #6
    v.extract    s1, v26, #7
    v.extract    s4, v27, #7
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #7
    v.extract    s5, v35, #7
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v24, s1, #7
    s.lshri      s4, s1, #32
    v.insert     v25, s4, #7
    v.movi       v26, #0
    v.movi       v27, #0
    v.extract    s1, v28, #0
    v.extract    s4, v29, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #0
    v.extract    s5, v35, #0
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v26, s1, #0
    s.lshri      s4, s1, #32
    v.insert     v27, s4, #0
    v.extract    s1, v28, #1
    v.extract    s4, v29, #1
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #1
    v.extract    s5, v35, #1
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v26, s1, #1
    s.lshri      s4, s1, #32
    v.insert     v27, s4, #1
    v.extract    s1, v28, #2
    v.extract    s4, v29, #2
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #2
    v.extract    s5, v35, #2
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v26, s1, #2
    s.lshri      s4, s1, #32
    v.insert     v27, s4, #2
    v.extract    s1, v28, #3
    v.extract    s4, v29, #3
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #3
    v.extract    s5, v35, #3
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v26, s1, #3
    s.lshri      s4, s1, #32
    v.insert     v27, s4, #3
    v.extract    s1, v28, #4
    v.extract    s4, v29, #4
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #4
    v.extract    s5, v35, #4
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v26, s1, #4
    s.lshri      s4, s1, #32
    v.insert     v27, s4, #4
    v.extract    s1, v28, #5
    v.extract    s4, v29, #5
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #5
    v.extract    s5, v35, #5
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v26, s1, #5
    s.lshri      s4, s1, #32
    v.insert     v27, s4, #5
    v.extract    s1, v28, #6
    v.extract    s4, v29, #6
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #6
    v.extract    s5, v35, #6
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v26, s1, #6
    s.lshri      s4, s1, #32
    v.insert     v27, s4, #6
    v.extract    s1, v28, #7
    v.extract    s4, v29, #7
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #7
    v.extract    s5, v35, #7
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v26, s1, #7
    s.lshri      s4, s1, #32
    v.insert     v27, s4, #7
    v.movi       v28, #0
    v.movi       v29, #0
    v.extract    s1, v30, #0
    v.extract    s4, v31, #0
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #0
    v.extract    s5, v35, #0
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v28, s1, #0
    s.lshri      s4, s1, #32
    v.insert     v29, s4, #0
    v.extract    s1, v30, #1
    v.extract    s4, v31, #1
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #1
    v.extract    s5, v35, #1
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v28, s1, #1
    s.lshri      s4, s1, #32
    v.insert     v29, s4, #1
    v.extract    s1, v30, #2
    v.extract    s4, v31, #2
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #2
    v.extract    s5, v35, #2
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v28, s1, #2
    s.lshri      s4, s1, #32
    v.insert     v29, s4, #2
    v.extract    s1, v30, #3
    v.extract    s4, v31, #3
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #3
    v.extract    s5, v35, #3
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v28, s1, #3
    s.lshri      s4, s1, #32
    v.insert     v29, s4, #3
    v.extract    s1, v30, #4
    v.extract    s4, v31, #4
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #4
    v.extract    s5, v35, #4
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v28, s1, #4
    s.lshri      s4, s1, #32
    v.insert     v29, s4, #4
    v.extract    s1, v30, #5
    v.extract    s4, v31, #5
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #5
    v.extract    s5, v35, #5
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v28, s1, #5
    s.lshri      s4, s1, #32
    v.insert     v29, s4, #5
    v.extract    s1, v30, #6
    v.extract    s4, v31, #6
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #6
    v.extract    s5, v35, #6
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v28, s1, #6
    s.lshri      s4, s1, #32
    v.insert     v29, s4, #6
    v.extract    s1, v30, #7
    v.extract    s4, v31, #7
    s.shli       s5, s4, #32
    s.or         s4, s1, s5
    v.extract    s1, v34, #7
    v.extract    s5, v35, #7
    s.shli       s6, s5, #32
    s.or         s5, s1, s6
    s.add        s1, s4, s5
    v.insert     v28, s1, #7
    s.lshri      s4, s1, #32
    v.insert     v29, s4, #7
    v.extract    s1, v32, #0
    v.extract    s4, v33, #0
    s.shli       s5, s4, #32
    s.or         s6, s1, s5
    v.splat      v30, s1
    v.splat      v31, s4
    v.sub        v34, v32, v30
    v.cmp.ltu    p10, v32, v30
    v.movi       v32, #1
    v.movi       v35, #0
    @p10 v.sel        v38, v32, v35
    v.sub        v32, v33, v31
    v.sub        v33, v32, v38
    v.movi       v32, #31
    v.ashr       v35, v34, v32
    v.cmp.ne     p10, v33, v35
    v.movi       v32, #1
    v.movi       v33, #0
    @p10 v.sel        v35, v32, v33
    v.iota       v32                             // arange(0, VLEN)
    s.movz       s1, #8
    v.splat      v33, s1
    v.cmp.lt     p10, v32, v33
    @p10 v.reduce.or  s1, v35
    s.movz       s4, #0
    s.cmp.eq     s5, s1, s4
    br.nz        s5, narrow_ok_1
    trap         #677220
narrow_ok_1:
    v.movi       v32, #1
    v.movi       v33, #0
    v.cmp.ltu    p10, v36, v30
    v.sub        v35, v36, v30
    @p10 v.sel        v36, v32, v33
    v.sub        v32, v37, v31
    v.movi       v33, #31
    v.movi       v37, #1
    v.sub        v38, v32, v36
    v.ashr       v32, v35, v33
    v.movi       v33, #0
    s.movz       s1, #8
    v.cmp.ne     p10, v38, v32
    v.iota       v32                             // arange(0, VLEN)
    v.splat      v36, s1
    @p10 v.sel        v38, v37, v33
    s.movz       s1, #0
    v.cmp.lt     p10, v32, v36
    @p10 v.reduce.or  s4, v38
    s.cmp.eq     s5, s4, s1
    br.nz        s5, narrow_ok_2
    trap         #677220
narrow_ok_2:
    v.movi       v32, #1
    v.movi       v33, #0
    v.cmp.ltu    p10, v0, v30
    v.sub        v36, v0, v30
    @p10 v.sel        v0, v32, v33
    v.sub        v32, v1, v31
    v.movi       v1, #31
    v.movi       v33, #1
    v.sub        v37, v32, v0
    v.ashr       v0, v36, v1
    v.movi       v1, #0
    s.movz       s1, #8
    v.cmp.ne     p10, v37, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v32, s1
    @p10 v.sel        v37, v33, v1
    s.movz       s1, #0
    v.cmp.lt     p10, v0, v32
    @p10 v.reduce.or  s4, v37
    s.cmp.eq     s5, s4, s1
    br.nz        s5, narrow_ok_3
    trap         #677220
narrow_ok_3:
    v.movi       v0, #1
    v.movi       v1, #0
    v.cmp.ltu    p10, v15, v30
    v.sub        v32, v15, v30
    @p10 v.sel        v15, v0, v1
    v.sub        v0, v16, v31
    v.movi       v1, #31
    v.movi       v16, #1
    v.sub        v33, v0, v15
    v.ashr       v0, v32, v1
    v.movi       v1, #0
    s.movz       s1, #8
    v.cmp.ne     p10, v33, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v15, s1
    @p10 v.sel        v33, v16, v1
    s.movz       s1, #0
    v.cmp.lt     p10, v0, v15
    @p10 v.reduce.or  s4, v33
    s.cmp.eq     s5, s4, s1
    br.nz        s5, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.movi       v0, #1
    v.movi       v1, #0
    v.cmp.ltu    p10, v22, v30
    v.sub        v15, v22, v30
    @p10 v.sel        v16, v0, v1
    v.sub        v0, v23, v31
    v.movi       v1, #31
    v.movi       v22, #1
    v.sub        v23, v0, v16
    v.ashr       v0, v15, v1
    v.movi       v1, #0
    s.movz       s1, #8
    v.cmp.ne     p10, v23, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v16, s1
    @p10 v.sel        v23, v22, v1
    s.movz       s1, #0
    v.cmp.lt     p10, v0, v16
    @p10 v.reduce.or  s4, v23
    s.cmp.eq     s5, s4, s1
    br.nz        s5, narrow_ok_5
    trap         #677220
narrow_ok_5:
    v.movi       v0, #1
    v.movi       v1, #0
    v.cmp.ltu    p10, v24, v30
    v.sub        v16, v24, v30
    @p10 v.sel        v22, v0, v1
    v.sub        v0, v25, v31
    v.movi       v1, #31
    v.movi       v23, #1
    v.sub        v24, v0, v22
    v.ashr       v0, v16, v1
    v.movi       v1, #0
    s.movz       s1, #8
    v.cmp.ne     p10, v24, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v22, s1
    @p10 v.sel        v24, v23, v1
    s.movz       s1, #0
    v.cmp.lt     p10, v0, v22
    @p10 v.reduce.or  s4, v24
    s.cmp.eq     s5, s4, s1
    br.nz        s5, narrow_ok_6
    trap         #677220
narrow_ok_6:
    v.movi       v0, #1
    v.movi       v1, #0
    v.cmp.ltu    p10, v26, v30
    v.sub        v22, v26, v30
    @p10 v.sel        v23, v0, v1
    v.sub        v0, v27, v31
    v.movi       v1, #31
    v.movi       v24, #1
    v.sub        v25, v0, v23
    v.ashr       v0, v22, v1
    v.movi       v1, #0
    s.movz       s1, #8
    v.cmp.ne     p10, v25, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v23, s1
    @p10 v.sel        v25, v24, v1
    s.movz       s1, #0
    v.cmp.lt     p10, v0, v23
    @p10 v.reduce.or  s4, v25
    s.cmp.eq     s5, s4, s1
    br.nz        s5, narrow_ok_7
    trap         #677220
narrow_ok_7:
    v.movi       v0, #1
    v.movi       v1, #0
    v.cmp.ltu    p10, v28, v30
    v.sub        v23, v28, v30
    @p10 v.sel        v24, v0, v1
    v.sub        v0, v29, v31
    v.movi       v1, #31
    v.movi       v25, #1
    v.sub        v26, v0, v24
    v.ashr       v0, v23, v1
    v.movi       v1, #0
    s.movz       s1, #8
    v.cmp.ne     p10, v26, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v24, s1
    @p10 v.sel        v26, v25, v1
    s.movz       s1, #0
    v.cmp.lt     p10, v0, v24
    @p10 v.reduce.or  s4, v26
    s.cmp.eq     s5, s4, s1
    br.nz        s5, narrow_ok_8
    trap         #677220
narrow_ok_8:
    v.movi       v0, #1
    v.movi       v1, #0
    v.movi       v24, #0
    s.movz       s1, #8
    @p1 v.sel        v25, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.extract    s1, v25, #0
    s.shli       s4, s6, #1
    v.splat      v25, s1
    s.rdspecial  s1, arg_base
    v.cmp.lt     p10, v0, v1
    v.cmp.ne     p11, v25, v24
    p.and        p12, p9, p11
    s.add        s5, s2, s4                      // a 64-bit tile origin
    p.and        p11, p10, p12
    v.movi       v0, #1
    v.movi       v1, #0
    s.ld.d       s2, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    @p2 v.sel        v24, v0, v1
    s.movz       s4, #512
    v.movi       v0, #0
    v.extract    s6, v24, #0
    s.mul        s7, s1, s4
    v.splat      v1, s6
    s.movz       s1, #8
    v.iota       v24                             // arange(0, VLEN)
    v.splat      v25, s1
    v.movi       v26, #0                         // other=, materialised (sec 12)
    @p11 v.ld.gather.h v26, [s5, v34]            // index is in elements (ISA sec 9.1)
    v.cmp.ne     p10, v1, v0
    s.add        s1, s2, s7                      // this context's own scratch
    p.and        p11, p9, p10
    v.cmp.lt     p10, v24, v25
    s.addi       s2, s1, #0
    p.and        p12, p10, p11
    v.movi       v0, #1
    v.movi       v1, #0
    v.movi       v24, #0
    s.movz       s4, #8
    @p3 v.sel        v25, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s4
    v.st.w       [s2, #0], v26
    v.extract    s4, v25, #0
    v.cmp.lt     p10, v0, v1
    v.splat      v0, s4
    s.addi       s4, s2, #64
    v.movi       v1, #1
    v.cmp.ne     p11, v0, v24
    p.and        p13, p9, p11
    v.movi       v0, #0
    p.and        p11, p10, p13
    v.movi       v24, #0
    @p4 v.sel        v25, v1, v0
    s.movz       s6, #8
    v.iota       v0                              // arange(0, VLEN)
    v.extract    s7, v25, #0
    v.splat      v1, s6
    v.splat      v25, s7
    s.addi       s6, s2, #128
    v.movi       v26, #0                         // other=, materialised (sec 12)
    @p12 v.ld.gather.h v26, [s5, v35]            // index is in elements (ISA sec 9.1)
    v.cmp.ne     p10, v25, v24
    p.and        p12, p9, p10
    v.cmp.lt     p10, v0, v1
    p.and        p13, p10, p12
    v.movi       v0, #1
    v.movi       v1, #0
    v.movi       v24, #0
    s.movz       s7, #8
    @p5 v.sel        v25, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s7
    v.extract    s7, v25, #0
    s.addi       s8, s2, #192
    v.st.w       [s4, #0], v26
    v.splat      v25, s7
    v.cmp.lt     p10, v0, v1
    v.movi       v0, #1
    v.movi       v1, #0
    v.movi       v26, #0
    s.movz       s4, #8
    @p6 v.sel        v27, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s4
    v.extract    s4, v27, #0
    s.addi       s7, s2, #256
    v.splat      v27, s4
    s.addi       s4, s2, #320
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p11 v.ld.gather.h v28, [s5, v36]            // index is in elements (ISA sec 9.1)
    v.cmp.ne     p11, v25, v24
    p.and        p12, p9, p11
    p.and        p11, p10, p12
    v.cmp.ne     p10, v27, v26
    p.and        p12, p9, p10
    v.st.w       [s6, #0], v28
    v.movi       v24, #1
    v.movi       v25, #0
    v.movi       v26, #0
    s.movz       s6, #8
    @p7 v.sel        v27, v24, v25
    v.iota       v24                             // arange(0, VLEN)
    v.splat      v25, s6
    v.extract    s6, v27, #0
    s.addi       s9, s2, #384
    v.splat      v27, s6
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p13 v.ld.gather.h v28, [s5, v32]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p10, v0, v1
    p.and        p13, p10, p12
    v.cmp.ne     p10, v27, v26
    p.and        p12, p9, p10
    v.st.w       [s8, #0], v28
    v.movi       v0, #1
    v.movi       v1, #0
    v.movi       v26, #0
    s.movz       s6, #8
    @p8 v.sel        v27, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s6
    v.extract    s6, v27, #0
    s.addi       s8, s2, #448
    v.splat      v27, s6
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p11 v.ld.gather.h v28, [s5, v15]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p10, v24, v25
    p.and        p11, p10, p12
    v.cmp.ne     p10, v27, v26
    p.and        p12, p9, p10
    v.st.w       [s7, #0], v28
    v.extract    s2, v19, #0
    v.extract    s6, v18, #0
    s.shli       s7, s2, #32
    s.movz       s2, #16
    s.or         s10, s6, s7
    v.movi       v15, #0
    s.mul        s6, s10, s2
    v.movi       v18, #0
    v.movi       v19, #0
    v.movi       v24, #0
    s.lshri      s2, s6, #32
    v.movi       v25, #0                         // other=, materialised (sec 12)
    @p13 v.ld.gather.h v25, [s5, v16]            // index is in elements (ISA sec 9.1)
    v.cmp.lt     p10, v0, v1
    p.and        p13, p10, p12
    v.extract    s7, v2, #0
    v.st.w       [s4, #0], v25
    v.extract    s4, v17, #0
    v.extract    s10, v4, #0
    s.shli       s11, s4, #32
    s.shli       s4, s10, #32
    s.or         s10, s7, s11
    v.extract    s7, v3, #0
    v.movi       v0, #0
    s.or         s11, s7, s4
    s.movz       s4, #16
    v.movi       v1, #0
    s.mul        s7, s10, s4
    s.movz       s4, #16
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p11 v.ld.gather.h v2, [s5, v22]             // index is in elements (ISA sec 9.1)
    s.mul        s10, s11, s4
    s.lshri      s4, s7, #32
    v.st.w       [s9, #0], v2
    v.extract    s9, v6, #0
    v.movi       v2, #0
    s.shli       s11, s9, #32
    v.movi       v3, #0
    v.movi       v4, #0
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p13 v.ld.gather.h v6, [s5, v23]             // index is in elements (ISA sec 9.1)
    v.extract    s5, v5, #0
    v.movi       v5, #0
    s.or         s9, s5, s11
    s.movz       s5, #16
    s.mul        s11, s9, s5
    s.lshri      s5, s10, #32
    v.st.w       [s8, #0], v6
    fence.acq_rel.device
    v.extract    s8, v8, #0
    v.insert     v15, s6, #0
    v.insert     v18, s2, #0
    v.extract    s2, v10, #0
    v.extract    s6, v7, #0
    s.shli       s9, s8, #32
    s.shli       s8, s2, #32
    s.or         s2, s6, s9
    v.extract    s6, v9, #0
    v.movi       v6, #0
    s.or         s9, s6, s8
    s.movz       s6, #16
    v.movi       v7, #0
    s.mul        s8, s2, s6
    s.movz       s2, #16
    v.movi       v8, #0
    s.mul        s6, s9, s2
    s.lshri      s2, s11, #32
    v.insert     v19, s7, #0
    v.extract    s7, v11, #0
    v.movi       v9, #0
    v.insert     v24, s4, #0
    v.extract    s4, v12, #0
    v.movi       v10, #0
    s.shli       s9, s4, #32
    v.insert     v0, s10, #0
    v.extract    s4, v13, #0
    s.or         s10, s7, s9
    s.movz       s7, #16
    v.movi       v11, #0
    s.mul        s9, s10, s7
    s.lshri      s7, s8, #32
    v.insert     v1, s5, #0
    v.extract    s5, v14, #0
    v.movi       v12, #0
    s.shli       s10, s5, #32
    v.insert     v2, s11, #0
    s.or         s5, s4, s10
    s.movz       s4, #16
    v.extract    s10, v15, #0
    s.mul        s11, s5, s4
    v.movi       v13, #0
    s.lshri      s4, s6, #32
    v.insert     v3, s2, #0
    v.extract    s2, v18, #0
    v.insert     v4, s8, #0
    s.shli       s5, s2, #32
    v.extract    s2, v18, #0
    s.or         s8, s10, s5
    v.extract    s5, v15, #0
    s.shli       s10, s2, #32
    v.insert     v5, s7, #0
    s.lshri      s2, s9, #32
    s.or         s7, s5, s10
    s.lshri      s5, s11, #32
    v.insert     v6, s6, #0
    s.lshri      s6, s8, #32
    v.insert     v7, s4, #0
    v.extract    s4, v18, #0
    v.insert     v8, s9, #0
    v.insert     v9, s2, #0
    v.insert     v10, s11, #0
    v.insert     v11, s5, #0
    v.insert     v12, s8, #0
    v.insert     v13, s6, #0
    v.extract    s2, v15, #0
    s.shli       s5, s4, #32
    s.lshri      s4, s7, #32
    v.extract    s6, v18, #0
    s.or         s8, s2, s5
    v.insert     v12, s7, #1
    v.insert     v13, s4, #1
    v.extract    s2, v15, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v18, #0
    s.or         s7, s2, s4
    v.insert     v12, s8, #2
    v.insert     v13, s5, #2
    v.extract    s2, v15, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v18, #0
    s.or         s8, s2, s4
    v.insert     v12, s7, #3
    v.insert     v13, s5, #3
    v.extract    s2, v15, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v18, #0
    s.or         s7, s2, s4
    v.insert     v12, s8, #4
    v.insert     v13, s5, #4
    v.extract    s2, v15, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v18, #0
    v.extract    s8, v24, #0
    s.or         s9, s2, s4
    v.insert     v12, s7, #5
    v.insert     v13, s5, #5
    v.extract    s2, v15, #0
    s.shli       s4, s6, #32
    v.extract    s5, v19, #0
    s.shli       s6, s8, #32
    s.lshri      s7, s9, #32
    v.extract    s8, v24, #0
    s.or         s10, s2, s4
    s.or         s2, s5, s6
    v.insert     v12, s9, #6
    v.insert     v13, s7, #6
    v.movi       v14, #0
    v.movi       v15, #0
    v.extract    s4, v19, #0
    s.shli       s5, s8, #32
    s.lshri      s6, s10, #32
    s.lshri      s7, s2, #32
    v.extract    s8, v24, #0
    s.or         s9, s4, s5
    v.insert     v12, s10, #7
    v.insert     v13, s6, #7
    v.insert     v14, s2, #0
    v.insert     v15, s7, #0
    v.extract    s2, v19, #0
    s.shli       s4, s8, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v24, #0
    s.or         s7, s2, s4
    v.insert     v14, s9, #1
    v.insert     v15, s5, #1
    v.extract    s2, v19, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v24, #0
    s.or         s8, s2, s4
    v.insert     v14, s7, #2
    v.insert     v15, s5, #2
    v.extract    s2, v19, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v24, #0
    s.or         s7, s2, s4
    v.insert     v14, s8, #3
    v.insert     v15, s5, #3
    v.extract    s2, v19, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v24, #0
    s.or         s8, s2, s4
    v.insert     v14, s7, #4
    v.insert     v15, s5, #4
    v.extract    s2, v19, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v24, #0
    v.extract    s7, v1, #0
    s.or         s9, s2, s4
    v.insert     v14, s8, #5
    v.insert     v15, s5, #5
    v.extract    s2, v19, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #0
    s.shli       s6, s7, #32
    s.lshri      s7, s9, #32
    v.extract    s8, v1, #0
    s.or         s10, s2, s4
    s.or         s2, s5, s6
    v.insert     v14, s9, #6
    v.insert     v15, s7, #6
    v.movi       v16, #0
    v.movi       v17, #0
    v.extract    s4, v0, #0
    s.shli       s5, s8, #32
    s.lshri      s6, s10, #32
    s.lshri      s7, s2, #32
    v.extract    s8, v1, #0
    s.or         s9, s4, s5
    v.insert     v14, s10, #7
    v.insert     v15, s6, #7
    v.insert     v16, s2, #0
    v.insert     v17, s7, #0
    v.extract    s2, v0, #0
    s.shli       s4, s8, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v1, #0
    s.or         s7, s2, s4
    v.insert     v16, s9, #1
    v.insert     v17, s5, #1
    v.extract    s2, v0, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v1, #0
    s.or         s8, s2, s4
    v.insert     v16, s7, #2
    v.insert     v17, s5, #2
    v.extract    s2, v0, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v1, #0
    s.or         s7, s2, s4
    v.insert     v16, s8, #3
    v.insert     v17, s5, #3
    v.extract    s2, v0, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v1, #0
    s.or         s8, s2, s4
    v.insert     v16, s7, #4
    v.insert     v17, s5, #4
    v.extract    s2, v0, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v1, #0
    v.extract    s7, v3, #0
    s.or         s9, s2, s4
    v.insert     v16, s8, #5
    v.insert     v17, s5, #5
    v.extract    s2, v0, #0
    s.shli       s4, s6, #32
    v.extract    s5, v2, #0
    s.shli       s6, s7, #32
    s.lshri      s7, s9, #32
    v.extract    s8, v3, #0
    s.or         s10, s2, s4
    s.or         s2, s5, s6
    v.insert     v16, s9, #6
    v.insert     v17, s7, #6
    v.movi       v0, #0
    v.movi       v1, #0
    v.extract    s4, v2, #0
    s.shli       s5, s8, #32
    s.lshri      s6, s10, #32
    s.lshri      s7, s2, #32
    v.extract    s8, v3, #0
    s.or         s9, s4, s5
    v.insert     v16, s10, #7
    v.insert     v17, s6, #7
    v.insert     v0, s2, #0
    v.insert     v1, s7, #0
    v.extract    s2, v2, #0
    s.shli       s4, s8, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v3, #0
    s.or         s7, s2, s4
    v.insert     v0, s9, #1
    v.insert     v1, s5, #1
    v.extract    s2, v2, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v3, #0
    s.or         s8, s2, s4
    v.insert     v0, s7, #2
    v.insert     v1, s5, #2
    v.extract    s2, v2, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v3, #0
    s.or         s7, s2, s4
    v.insert     v0, s8, #3
    v.insert     v1, s5, #3
    v.extract    s2, v2, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v3, #0
    s.or         s8, s2, s4
    v.insert     v0, s7, #4
    v.insert     v1, s5, #4
    v.extract    s2, v2, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v3, #0
    v.extract    s7, v5, #0
    s.or         s9, s2, s4
    v.insert     v0, s8, #5
    v.insert     v1, s5, #5
    v.extract    s2, v2, #0
    s.shli       s4, s6, #32
    v.extract    s5, v4, #0
    s.shli       s6, s7, #32
    s.lshri      s7, s9, #32
    v.extract    s8, v5, #0
    s.or         s10, s2, s4
    s.or         s2, s5, s6
    v.insert     v0, s9, #6
    v.insert     v1, s7, #6
    v.movi       v2, #0
    v.movi       v3, #0
    v.extract    s4, v4, #0
    s.shli       s5, s8, #32
    s.lshri      s6, s10, #32
    s.lshri      s7, s2, #32
    v.extract    s8, v5, #0
    s.or         s9, s4, s5
    v.insert     v0, s10, #7
    v.insert     v1, s6, #7
    v.insert     v2, s2, #0
    v.insert     v3, s7, #0
    v.extract    s2, v4, #0
    s.shli       s4, s8, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v5, #0
    s.or         s7, s2, s4
    v.insert     v2, s9, #1
    v.insert     v3, s5, #1
    v.extract    s2, v4, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v5, #0
    s.or         s8, s2, s4
    v.insert     v2, s7, #2
    v.insert     v3, s5, #2
    v.extract    s2, v4, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v5, #0
    s.or         s7, s2, s4
    v.insert     v2, s8, #3
    v.insert     v3, s5, #3
    v.extract    s2, v4, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v5, #0
    s.or         s8, s2, s4
    v.insert     v2, s7, #4
    v.insert     v3, s5, #4
    v.extract    s2, v4, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v5, #0
    v.extract    s7, v7, #0
    s.or         s9, s2, s4
    v.insert     v2, s8, #5
    v.insert     v3, s5, #5
    v.extract    s2, v4, #0
    s.shli       s4, s6, #32
    v.extract    s5, v6, #0
    s.shli       s6, s7, #32
    s.lshri      s7, s9, #32
    v.extract    s8, v7, #0
    s.or         s10, s2, s4
    s.or         s2, s5, s6
    v.insert     v2, s9, #6
    v.insert     v3, s7, #6
    v.movi       v4, #0
    v.movi       v5, #0
    v.extract    s4, v6, #0
    s.shli       s5, s8, #32
    s.lshri      s6, s10, #32
    s.lshri      s7, s2, #32
    v.extract    s8, v7, #0
    s.or         s9, s4, s5
    v.insert     v2, s10, #7
    v.insert     v3, s6, #7
    v.insert     v4, s2, #0
    v.insert     v5, s7, #0
    v.extract    s2, v6, #0
    s.shli       s4, s8, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v7, #0
    s.or         s7, s2, s4
    v.insert     v4, s9, #1
    v.insert     v5, s5, #1
    v.extract    s2, v6, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v7, #0
    s.or         s8, s2, s4
    v.insert     v4, s7, #2
    v.insert     v5, s5, #2
    v.extract    s2, v6, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v7, #0
    s.or         s7, s2, s4
    v.insert     v4, s8, #3
    v.insert     v5, s5, #3
    v.extract    s2, v6, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v7, #0
    s.or         s8, s2, s4
    v.insert     v4, s7, #4
    v.insert     v5, s5, #4
    v.extract    s2, v6, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v7, #0
    v.extract    s7, v9, #0
    s.or         s9, s2, s4
    v.insert     v4, s8, #5
    v.insert     v5, s5, #5
    v.extract    s2, v6, #0
    s.shli       s4, s6, #32
    v.extract    s5, v8, #0
    s.shli       s6, s7, #32
    s.lshri      s7, s9, #32
    v.extract    s8, v9, #0
    s.or         s10, s2, s4
    s.or         s2, s5, s6
    v.insert     v4, s9, #6
    v.insert     v5, s7, #6
    v.movi       v6, #0
    v.movi       v7, #0
    v.extract    s4, v8, #0
    s.shli       s5, s8, #32
    s.lshri      s6, s10, #32
    s.lshri      s7, s2, #32
    v.extract    s8, v9, #0
    s.or         s9, s4, s5
    v.insert     v4, s10, #7
    v.insert     v5, s6, #7
    v.insert     v6, s2, #0
    v.insert     v7, s7, #0
    v.extract    s2, v8, #0
    s.shli       s4, s8, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v9, #0
    s.or         s7, s2, s4
    v.insert     v6, s9, #1
    v.insert     v7, s5, #1
    v.extract    s2, v8, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v9, #0
    s.or         s8, s2, s4
    v.insert     v6, s7, #2
    v.insert     v7, s5, #2
    v.extract    s2, v8, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v9, #0
    s.or         s7, s2, s4
    v.insert     v6, s8, #3
    v.insert     v7, s5, #3
    v.extract    s2, v8, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v9, #0
    s.or         s8, s2, s4
    v.insert     v6, s7, #4
    v.insert     v7, s5, #4
    v.extract    s2, v8, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v9, #0
    v.extract    s7, v11, #0
    s.or         s9, s2, s4
    v.insert     v6, s8, #5
    v.insert     v7, s5, #5
    v.extract    s2, v8, #0
    s.shli       s4, s6, #32
    v.extract    s5, v10, #0
    s.shli       s6, s7, #32
    s.lshri      s7, s9, #32
    v.extract    s8, v11, #0
    s.or         s10, s2, s4
    s.or         s2, s5, s6
    v.insert     v6, s9, #6
    v.insert     v7, s7, #6
    v.movi       v8, #0
    v.movi       v9, #0
    v.extract    s4, v10, #0
    s.shli       s5, s8, #32
    s.lshri      s6, s10, #32
    s.lshri      s7, s2, #32
    v.extract    s8, v11, #0
    s.or         s9, s4, s5
    v.insert     v6, s10, #7
    v.insert     v7, s6, #7
    v.insert     v8, s2, #0
    v.insert     v9, s7, #0
    v.extract    s2, v10, #0
    s.shli       s4, s8, #32
    s.lshri      s5, s9, #32
    v.extract    s6, v11, #0
    s.or         s7, s2, s4
    v.insert     v8, s9, #1
    v.insert     v9, s5, #1
    v.extract    s2, v10, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v11, #0
    s.or         s8, s2, s4
    v.insert     v8, s7, #2
    v.insert     v9, s5, #2
    v.extract    s2, v10, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    v.extract    s6, v11, #0
    s.or         s7, s2, s4
    v.insert     v8, s8, #3
    v.insert     v9, s5, #3
    v.extract    s2, v10, #0
    s.shli       s4, s6, #32
    s.lshri      s5, s7, #32
    v.extract    s6, v11, #0
    s.or         s8, s2, s4
    v.extract    s2, v21, #0
    v.extract    s4, v13, #0
    v.insert     v8, s7, #4
    v.insert     v9, s5, #4
    v.extract    s5, v10, #0
    s.shli       s7, s6, #32
    s.lshri      s6, s8, #32
    v.extract    s9, v11, #0
    v.extract    s10, v20, #0
    s.shli       s11, s2, #32
    s.shli       s2, s4, #32
    s.or         s4, s5, s7
    v.extract    s5, v12, #0
    v.insert     v8, s8, #5
    v.extract    s7, v21, #1
    v.insert     v9, s6, #5
    v.extract    s6, v13, #1
    s.shli       s8, s9, #32
    s.or         s9, s10, s11
    v.extract    s10, v10, #0
    s.or         s11, s5, s2
    s.lshri      s2, s4, #32
    s.shli       s5, s7, #32
    s.shli       s7, s6, #32
    s.or         s6, s10, s8
    v.extract    s8, v20, #1
    s.add        s10, s9, s11
    v.extract    s9, v12, #1
    v.insert     v8, s4, #6
    v.extract    s4, v21, #2
    v.insert     v9, s2, #6
    v.extract    s2, v13, #2
    v.movi       v10, #0
    v.movi       v11, #0
    s.or         s11, s8, s5
    s.or         s5, s9, s7
    s.lshri      s7, s6, #32
    s.lshri      s8, s10, #32
    s.shli       s9, s4, #32
    s.shli       s4, s2, #32
    s.add        s2, s11, s5
    v.extract    s5, v20, #2
    v.insert     v8, s6, #7
    v.extract    s6, v12, #2
    v.insert     v9, s7, #7
    v.extract    s7, v21, #3
    v.insert     v10, s10, #0
    v.extract    s10, v13, #3
    v.insert     v11, s8, #0
    s.or         s8, s5, s9
    s.or         s5, s6, s4
    s.lshri      s4, s2, #32
    v.extract    s6, v20, #3
    s.shli       s9, s7, #32
    v.extract    s7, v12, #3
    s.shli       s11, s10, #32
    s.add        s10, s8, s5
    v.extract    s5, v21, #4
    v.insert     v10, s2, #1
    v.extract    s2, v13, #4
    v.insert     v11, s4, #1
    s.or         s4, s6, s9
    s.or         s6, s7, s11
    s.lshri      s7, s10, #32
    v.extract    s8, v20, #4
    s.shli       s9, s5, #32
    v.extract    s5, v12, #4
    s.shli       s11, s2, #32
    s.add        s2, s4, s6
    v.extract    s4, v21, #5
    v.insert     v10, s10, #2
    v.extract    s6, v13, #5
    v.insert     v11, s7, #2
    s.or         s7, s8, s9
    s.or         s8, s5, s11
    s.lshri      s5, s2, #32
    v.extract    s9, v20, #5
    s.shli       s10, s4, #32
    v.extract    s4, v12, #5
    s.shli       s11, s6, #32
    s.add        s6, s7, s8
    v.extract    s7, v21, #6
    v.insert     v10, s2, #3
    v.extract    s2, v13, #6
    v.insert     v11, s5, #3
    s.or         s5, s9, s10
    s.or         s8, s4, s11
    s.lshri      s4, s6, #32
    v.extract    s9, v20, #6
    s.shli       s10, s7, #32
    v.extract    s7, v12, #6
    s.shli       s11, s2, #32
    s.add        s2, s5, s8
    v.extract    s5, v21, #7
    v.insert     v10, s6, #4
    v.extract    s6, v13, #7
    v.insert     v11, s4, #4
    v.extract    s4, v21, #0
    s.or         s8, s9, s10
    v.extract    s9, v15, #0
    s.or         s10, s7, s11
    s.lshri      s7, s2, #32
    s.shli       s11, s5, #32
    s.shli       s5, s6, #32
    s.shli       s6, s4, #32
    s.shli       s4, s9, #32
    s.add        s9, s8, s10
    v.extract    s8, v20, #7
    v.insert     v10, s2, #5
    v.extract    s2, v12, #7
    v.insert     v11, s7, #5
    v.extract    s7, v20, #0
    s.or         s10, s8, s11
    v.extract    s8, v14, #0
    s.or         s11, s2, s5
    v.extract    s2, v21, #1
    s.or         s5, s7, s6
    v.extract    s6, v15, #1
    s.or         s7, s8, s4
    s.lshri      s4, s9, #32
    s.shli       s8, s2, #32
    s.shli       s2, s6, #32
    s.add        s6, s10, s11
    v.extract    s10, v20, #1
    s.add        s11, s5, s7
    v.extract    s5, v14, #1
    v.insert     v10, s9, #6
    v.extract    s7, v21, #2
    v.insert     v11, s4, #6
    v.extract    s4, v15, #2
    v.movi       v12, #0
    v.movi       v13, #0
    s.or         s9, s10, s8
    s.or         s8, s5, s2
    s.lshri      s2, s6, #32
    s.lshri      s5, s11, #32
    s.shli       s10, s7, #32
    s.shli       s7, s4, #32
    s.add        s4, s9, s8
    v.extract    s8, v20, #2
    v.insert     v10, s6, #7
    v.extract    s6, v14, #2
    v.insert     v11, s2, #7
    v.extract    s2, v21, #3
    v.insert     v12, s11, #0
    v.extract    s9, v15, #3
    v.insert     v13, s5, #0
    s.or         s5, s8, s10
    s.or         s8, s6, s7
    s.lshri      s6, s4, #32
    v.extract    s7, v20, #3
    s.shli       s10, s2, #32
    v.extract    s2, v14, #3
    s.shli       s11, s9, #32
    s.add        s9, s5, s8
    v.extract    s5, v21, #4
    v.insert     v12, s4, #1
    v.extract    s4, v15, #4
    v.insert     v13, s6, #1
    s.or         s6, s7, s10
    s.or         s7, s2, s11
    s.lshri      s2, s9, #32
    v.extract    s8, v20, #4
    s.shli       s10, s5, #32
    v.extract    s5, v14, #4
    s.shli       s11, s4, #32
    s.add        s4, s6, s7
    v.extract    s6, v21, #5
    v.insert     v12, s9, #2
    v.extract    s7, v15, #5
    v.insert     v13, s2, #2
    s.or         s2, s8, s10
    s.or         s8, s5, s11
    s.lshri      s5, s4, #32
    v.extract    s9, v20, #5
    s.shli       s10, s6, #32
    v.extract    s6, v14, #5
    s.shli       s11, s7, #32
    s.add        s7, s2, s8
    v.extract    s2, v21, #6
    v.insert     v12, s4, #3
    v.extract    s4, v15, #6
    v.insert     v13, s5, #3
    s.or         s5, s9, s10
    s.or         s8, s6, s11
    s.lshri      s6, s7, #32
    v.extract    s9, v20, #6
    s.shli       s10, s2, #32
    v.extract    s2, v14, #6
    s.shli       s11, s4, #32
    s.add        s4, s5, s8
    v.extract    s5, v21, #7
    v.insert     v12, s7, #4
    v.extract    s7, v15, #7
    v.insert     v13, s6, #4
    v.extract    s6, v21, #0
    s.or         s8, s9, s10
    v.extract    s9, v17, #0
    s.or         s10, s2, s11
    s.lshri      s2, s4, #32
    s.shli       s11, s5, #32
    s.shli       s5, s7, #32
    s.shli       s7, s6, #32
    s.shli       s6, s9, #32
    s.add        s9, s8, s10
    v.extract    s8, v20, #7
    v.insert     v12, s4, #5
    v.extract    s4, v14, #7
    v.insert     v13, s2, #5
    v.extract    s2, v20, #0
    s.or         s10, s8, s11
    v.extract    s8, v16, #0
    s.or         s11, s4, s5
    v.extract    s4, v21, #1
    s.or         s5, s2, s7
    v.extract    s2, v17, #1
    s.or         s7, s8, s6
    s.lshri      s6, s9, #32
    s.shli       s8, s4, #32
    s.shli       s4, s2, #32
    s.add        s2, s10, s11
    v.extract    s10, v20, #1
    s.add        s11, s5, s7
    v.extract    s5, v16, #1
    v.insert     v12, s9, #6
    v.extract    s7, v21, #2
    v.insert     v13, s6, #6
    v.extract    s6, v17, #2
    v.movi       v14, #0
    v.movi       v15, #0
    s.or         s9, s10, s8
    s.or         s8, s5, s4
    s.lshri      s4, s2, #32
    s.lshri      s5, s11, #32
    s.shli       s10, s7, #32
    s.shli       s7, s6, #32
    s.add        s6, s9, s8
    v.extract    s8, v20, #2
    v.insert     v12, s2, #7
    v.extract    s2, v16, #2
    v.insert     v13, s4, #7
    v.extract    s4, v21, #3
    v.insert     v14, s11, #0
    v.extract    s9, v17, #3
    v.insert     v15, s5, #0
    s.or         s5, s8, s10
    s.or         s8, s2, s7
    s.lshri      s2, s6, #32
    v.extract    s7, v20, #3
    s.shli       s10, s4, #32
    v.extract    s4, v16, #3
    s.shli       s11, s9, #32
    s.add        s9, s5, s8
    v.extract    s5, v21, #4
    v.insert     v14, s6, #1
    v.extract    s6, v17, #4
    v.insert     v15, s2, #1
    s.or         s2, s7, s10
    s.or         s7, s4, s11
    s.lshri      s4, s9, #32
    v.extract    s8, v20, #4
    s.shli       s10, s5, #32
    v.extract    s5, v16, #4
    s.shli       s11, s6, #32
    s.add        s6, s2, s7
    v.extract    s2, v21, #5
    v.insert     v14, s9, #2
    v.extract    s7, v17, #5
    v.insert     v15, s4, #2
    s.or         s4, s8, s10
    s.or         s8, s5, s11
    s.lshri      s5, s6, #32
    v.extract    s9, v20, #5
    s.shli       s10, s2, #32
    v.extract    s2, v16, #5
    s.shli       s11, s7, #32
    s.add        s7, s4, s8
    v.extract    s4, v21, #6
    v.insert     v14, s6, #3
    v.extract    s6, v17, #6
    v.insert     v15, s5, #3
    s.or         s5, s9, s10
    s.or         s8, s2, s11
    s.lshri      s2, s7, #32
    v.extract    s9, v20, #6
    s.shli       s10, s4, #32
    v.extract    s4, v16, #6
    s.shli       s11, s6, #32
    s.add        s6, s5, s8
    v.extract    s5, v21, #7
    v.insert     v14, s7, #4
    v.extract    s7, v17, #7
    v.insert     v15, s2, #4
    v.extract    s2, v21, #0
    s.or         s8, s9, s10
    v.extract    s9, v1, #0
    s.or         s10, s4, s11
    s.lshri      s4, s6, #32
    s.shli       s11, s5, #32
    s.shli       s5, s7, #32
    s.shli       s7, s2, #32
    s.shli       s2, s9, #32
    s.add        s9, s8, s10
    v.extract    s8, v20, #7
    v.insert     v14, s6, #5
    v.extract    s6, v16, #7
    v.insert     v15, s4, #5
    v.extract    s4, v20, #0
    s.or         s10, s8, s11
    v.extract    s8, v0, #0
    s.or         s11, s6, s5
    v.extract    s5, v21, #1
    s.or         s6, s4, s7
    v.extract    s4, v1, #1
    s.or         s7, s8, s2
    s.lshri      s2, s9, #32
    s.shli       s8, s5, #32
    s.shli       s5, s4, #32
    s.add        s4, s10, s11
    v.extract    s10, v20, #1
    s.add        s11, s6, s7
    v.extract    s6, v0, #1
    v.insert     v14, s9, #6
    v.extract    s7, v21, #2
    v.insert     v15, s2, #6
    v.extract    s2, v1, #2
    v.movi       v16, #0
    v.movi       v17, #0
    s.or         s9, s10, s8
    s.or         s8, s6, s5
    s.lshri      s5, s4, #32
    s.lshri      s6, s11, #32
    s.shli       s10, s7, #32
    s.shli       s7, s2, #32
    s.add        s2, s9, s8
    v.extract    s8, v20, #2
    v.insert     v14, s4, #7
    v.extract    s4, v0, #2
    v.insert     v15, s5, #7
    v.extract    s5, v21, #3
    v.insert     v16, s11, #0
    v.extract    s9, v1, #3
    v.insert     v17, s6, #0
    s.or         s6, s8, s10
    s.or         s8, s4, s7
    s.lshri      s4, s2, #32
    v.extract    s7, v20, #3
    s.shli       s10, s5, #32
    v.extract    s5, v0, #3
    s.shli       s11, s9, #32
    s.add        s9, s6, s8
    v.extract    s6, v21, #4
    v.insert     v16, s2, #1
    v.extract    s2, v1, #4
    v.insert     v17, s4, #1
    s.or         s4, s7, s10
    s.or         s7, s5, s11
    s.lshri      s5, s9, #32
    v.extract    s8, v20, #4
    s.shli       s10, s6, #32
    v.extract    s6, v0, #4
    s.shli       s11, s2, #32
    s.add        s2, s4, s7
    v.extract    s4, v21, #5
    v.insert     v16, s9, #2
    v.extract    s7, v1, #5
    v.insert     v17, s5, #2
    s.or         s5, s8, s10
    s.or         s8, s6, s11
    s.lshri      s6, s2, #32
    v.extract    s9, v20, #5
    s.shli       s10, s4, #32
    v.extract    s4, v0, #5
    s.shli       s11, s7, #32
    s.add        s7, s5, s8
    v.extract    s5, v21, #6
    v.insert     v16, s2, #3
    v.extract    s2, v1, #6
    v.insert     v17, s6, #3
    s.or         s6, s9, s10
    s.or         s8, s4, s11
    s.lshri      s4, s7, #32
    v.extract    s9, v20, #6
    s.shli       s10, s5, #32
    v.extract    s5, v0, #6
    s.shli       s11, s2, #32
    s.add        s2, s6, s8
    v.extract    s6, v21, #7
    v.insert     v16, s7, #4
    v.extract    s7, v1, #7
    v.insert     v17, s4, #4
    v.extract    s4, v21, #0
    s.or         s8, s9, s10
    v.extract    s9, v3, #0
    s.or         s10, s5, s11
    s.lshri      s5, s2, #32
    s.shli       s11, s6, #32
    s.shli       s6, s7, #32
    s.shli       s7, s4, #32
    s.shli       s4, s9, #32
    s.add        s9, s8, s10
    v.extract    s8, v20, #7
    v.insert     v16, s2, #5
    v.extract    s2, v0, #7
    v.insert     v17, s5, #5
    v.extract    s5, v20, #0
    s.or         s10, s8, s11
    v.extract    s8, v2, #0
    s.or         s11, s2, s6
    v.extract    s2, v21, #1
    s.or         s6, s5, s7
    v.extract    s5, v3, #1
    s.or         s7, s8, s4
    s.lshri      s4, s9, #32
    s.shli       s8, s2, #32
    s.shli       s2, s5, #32
    s.add        s5, s10, s11
    v.extract    s10, v20, #1
    s.add        s11, s6, s7
    v.extract    s6, v2, #1
    v.insert     v16, s9, #6
    v.extract    s7, v21, #2
    v.insert     v17, s4, #6
    v.extract    s4, v3, #2
    v.movi       v0, #0
    v.movi       v1, #0
    s.or         s9, s10, s8
    s.or         s8, s6, s2
    s.lshri      s2, s5, #32
    s.lshri      s6, s11, #32
    s.shli       s10, s7, #32
    s.shli       s7, s4, #32
    s.add        s4, s9, s8
    v.extract    s8, v20, #2
    v.insert     v16, s5, #7
    v.extract    s5, v2, #2
    v.insert     v17, s2, #7
    v.extract    s2, v21, #3
    v.insert     v0, s11, #0
    v.extract    s9, v3, #3
    v.insert     v1, s6, #0
    s.or         s6, s8, s10
    s.or         s8, s5, s7
    s.lshri      s5, s4, #32
    v.extract    s7, v20, #3
    s.shli       s10, s2, #32
    v.extract    s2, v2, #3
    s.shli       s11, s9, #32
    s.add        s9, s6, s8
    v.extract    s6, v21, #4
    v.insert     v0, s4, #1
    v.extract    s4, v3, #4
    v.insert     v1, s5, #1
    s.or         s5, s7, s10
    s.or         s7, s2, s11
    s.lshri      s2, s9, #32
    v.extract    s8, v20, #4
    s.shli       s10, s6, #32
    v.extract    s6, v2, #4
    s.shli       s11, s4, #32
    s.add        s4, s5, s7
    v.extract    s5, v21, #5
    v.insert     v0, s9, #2
    v.extract    s7, v3, #5
    v.insert     v1, s2, #2
    s.or         s2, s8, s10
    s.or         s8, s6, s11
    s.lshri      s6, s4, #32
    v.extract    s9, v20, #5
    s.shli       s10, s5, #32
    v.extract    s5, v2, #5
    s.shli       s11, s7, #32
    s.add        s7, s2, s8
    v.extract    s2, v21, #6
    v.insert     v0, s4, #3
    v.extract    s4, v3, #6
    v.insert     v1, s6, #3
    s.or         s6, s9, s10
    s.or         s8, s5, s11
    s.lshri      s5, s7, #32
    v.extract    s9, v20, #6
    s.shli       s10, s2, #32
    v.extract    s2, v2, #6
    s.shli       s11, s4, #32
    s.add        s4, s6, s8
    v.extract    s6, v21, #7
    v.insert     v0, s7, #4
    v.extract    s7, v3, #7
    v.insert     v1, s5, #4
    v.extract    s5, v21, #0
    s.or         s8, s9, s10
    v.extract    s9, v5, #0
    s.or         s10, s2, s11
    s.lshri      s2, s4, #32
    s.shli       s11, s6, #32
    s.shli       s6, s7, #32
    s.shli       s7, s5, #32
    s.shli       s5, s9, #32
    s.add        s9, s8, s10
    v.extract    s8, v20, #7
    v.insert     v0, s4, #5
    v.extract    s4, v2, #7
    v.insert     v1, s2, #5
    v.extract    s2, v20, #0
    s.or         s10, s8, s11
    v.extract    s8, v4, #0
    s.or         s11, s4, s6
    v.extract    s4, v21, #1
    s.or         s6, s2, s7
    v.extract    s2, v5, #1
    s.or         s7, s8, s5
    s.lshri      s5, s9, #32
    s.shli       s8, s4, #32
    s.shli       s4, s2, #32
    s.add        s2, s10, s11
    v.extract    s10, v20, #1
    s.add        s11, s6, s7
    v.extract    s6, v4, #1
    v.insert     v0, s9, #6
    v.extract    s7, v21, #2
    v.insert     v1, s5, #6
    v.extract    s5, v5, #2
    v.movi       v2, #0
    v.movi       v3, #0
    s.or         s9, s10, s8
    s.or         s8, s6, s4
    s.lshri      s4, s2, #32
    s.lshri      s6, s11, #32
    s.shli       s10, s7, #32
    s.shli       s7, s5, #32
    s.add        s5, s9, s8
    v.extract    s8, v20, #2
    v.insert     v0, s2, #7
    v.extract    s2, v4, #2
    v.insert     v1, s4, #7
    v.extract    s4, v21, #3
    v.insert     v2, s11, #0
    v.extract    s9, v5, #3
    v.insert     v3, s6, #0
    s.or         s6, s8, s10
    s.or         s8, s2, s7
    s.lshri      s2, s5, #32
    v.extract    s7, v20, #3
    s.shli       s10, s4, #32
    v.extract    s4, v4, #3
    s.shli       s11, s9, #32
    s.add        s9, s6, s8
    v.extract    s6, v21, #4
    v.insert     v2, s5, #1
    v.extract    s5, v5, #4
    v.insert     v3, s2, #1
    s.or         s2, s7, s10
    s.or         s7, s4, s11
    s.lshri      s4, s9, #32
    v.extract    s8, v20, #4
    s.shli       s10, s6, #32
    v.extract    s6, v4, #4
    s.shli       s11, s5, #32
    s.add        s5, s2, s7
    v.extract    s2, v21, #5
    v.insert     v2, s9, #2
    v.extract    s7, v5, #5
    v.insert     v3, s4, #2
    s.or         s4, s8, s10
    s.or         s8, s6, s11
    s.lshri      s6, s5, #32
    v.extract    s9, v20, #5
    s.shli       s10, s2, #32
    v.extract    s2, v4, #5
    s.shli       s11, s7, #32
    s.add        s7, s4, s8
    v.extract    s4, v21, #6
    v.insert     v2, s5, #3
    v.extract    s5, v5, #6
    v.insert     v3, s6, #3
    s.or         s6, s9, s10
    s.or         s8, s2, s11
    s.lshri      s2, s7, #32
    v.extract    s9, v20, #6
    s.shli       s10, s4, #32
    v.extract    s4, v4, #6
    s.shli       s11, s5, #32
    s.add        s5, s6, s8
    v.extract    s6, v21, #7
    v.insert     v2, s7, #4
    v.extract    s7, v5, #7
    v.insert     v3, s2, #4
    v.extract    s2, v21, #0
    s.or         s8, s9, s10
    v.extract    s9, v7, #0
    s.or         s10, s4, s11
    s.lshri      s4, s5, #32
    s.shli       s11, s6, #32
    s.shli       s6, s7, #32
    s.shli       s7, s2, #32
    s.shli       s2, s9, #32
    s.add        s9, s8, s10
    v.extract    s8, v20, #7
    v.insert     v2, s5, #5
    v.extract    s5, v4, #7
    v.insert     v3, s4, #5
    v.extract    s4, v20, #0
    s.or         s10, s8, s11
    v.extract    s8, v6, #0
    s.or         s11, s5, s6
    v.extract    s5, v21, #1
    s.or         s6, s4, s7
    v.extract    s4, v7, #1
    s.or         s7, s8, s2
    s.lshri      s2, s9, #32
    s.shli       s8, s5, #32
    s.shli       s5, s4, #32
    s.add        s4, s10, s11
    v.extract    s10, v20, #1
    s.add        s11, s6, s7
    v.extract    s6, v6, #1
    v.insert     v2, s9, #6
    v.extract    s7, v21, #2
    v.insert     v3, s2, #6
    v.extract    s2, v7, #2
    v.movi       v4, #0
    v.movi       v5, #0
    s.or         s9, s10, s8
    s.or         s8, s6, s5
    s.lshri      s5, s4, #32
    s.lshri      s6, s11, #32
    s.shli       s10, s7, #32
    s.shli       s7, s2, #32
    s.add        s2, s9, s8
    v.extract    s8, v20, #2
    v.insert     v2, s4, #7
    v.extract    s4, v6, #2
    v.insert     v3, s5, #7
    v.extract    s5, v21, #3
    v.insert     v4, s11, #0
    v.extract    s9, v7, #3
    v.insert     v5, s6, #0
    s.or         s6, s8, s10
    s.or         s8, s4, s7
    s.lshri      s4, s2, #32
    v.extract    s7, v20, #3
    s.shli       s10, s5, #32
    v.extract    s5, v6, #3
    s.shli       s11, s9, #32
    s.add        s9, s6, s8
    v.extract    s6, v21, #4
    v.insert     v4, s2, #1
    v.extract    s2, v7, #4
    v.insert     v5, s4, #1
    s.or         s4, s7, s10
    s.or         s7, s5, s11
    s.lshri      s5, s9, #32
    v.extract    s8, v20, #4
    s.shli       s10, s6, #32
    v.extract    s6, v6, #4
    s.shli       s11, s2, #32
    s.add        s2, s4, s7
    v.extract    s4, v21, #5
    v.insert     v4, s9, #2
    v.extract    s7, v7, #5
    v.insert     v5, s5, #2
    s.or         s5, s8, s10
    s.or         s8, s6, s11
    s.lshri      s6, s2, #32
    v.extract    s9, v20, #5
    s.shli       s10, s4, #32
    v.extract    s4, v6, #5
    s.shli       s11, s7, #32
    s.add        s7, s5, s8
    v.extract    s5, v21, #6
    v.insert     v4, s2, #3
    v.extract    s2, v7, #6
    v.insert     v5, s6, #3
    s.or         s6, s9, s10
    s.or         s8, s4, s11
    s.lshri      s4, s7, #32
    v.extract    s9, v20, #6
    s.shli       s10, s5, #32
    v.extract    s5, v6, #6
    s.shli       s11, s2, #32
    s.add        s2, s6, s8
    v.extract    s6, v21, #7
    v.insert     v4, s7, #4
    v.extract    s7, v7, #7
    v.insert     v5, s4, #4
    v.extract    s4, v21, #0
    s.or         s8, s9, s10
    v.extract    s9, v9, #0
    s.or         s10, s5, s11
    s.lshri      s5, s2, #32
    s.shli       s11, s6, #32
    s.shli       s6, s7, #32
    s.shli       s7, s4, #32
    s.shli       s4, s9, #32
    s.add        s9, s8, s10
    v.extract    s8, v20, #7
    v.insert     v4, s2, #5
    v.extract    s2, v6, #7
    v.insert     v5, s5, #5
    v.extract    s5, v20, #0
    s.or         s10, s8, s11
    v.extract    s8, v8, #0
    s.or         s11, s2, s6
    v.extract    s2, v21, #1
    s.or         s6, s5, s7
    v.extract    s5, v9, #1
    s.or         s7, s8, s4
    s.lshri      s4, s9, #32
    s.shli       s8, s2, #32
    s.shli       s2, s5, #32
    s.add        s5, s10, s11
    v.extract    s10, v20, #1
    s.add        s11, s6, s7
    v.extract    s6, v8, #1
    v.insert     v4, s9, #6
    v.extract    s7, v21, #2
    v.insert     v5, s4, #6
    v.extract    s4, v9, #2
    v.movi       v6, #0
    v.movi       v7, #0
    s.or         s9, s10, s8
    s.or         s8, s6, s2
    s.lshri      s2, s5, #32
    s.lshri      s6, s11, #32
    s.shli       s10, s7, #32
    s.shli       s7, s4, #32
    s.add        s4, s9, s8
    v.extract    s8, v20, #2
    v.insert     v4, s5, #7
    v.extract    s5, v8, #2
    v.insert     v5, s2, #7
    v.extract    s2, v21, #3
    v.insert     v6, s11, #0
    v.extract    s9, v9, #3
    v.insert     v7, s6, #0
    s.or         s6, s8, s10
    s.or         s8, s5, s7
    s.lshri      s5, s4, #32
    v.extract    s7, v20, #3
    s.shli       s10, s2, #32
    v.extract    s2, v8, #3
    s.shli       s11, s9, #32
    s.add        s9, s6, s8
    v.extract    s6, v21, #4
    v.insert     v6, s4, #1
    v.extract    s4, v9, #4
    v.insert     v7, s5, #1
    s.or         s5, s7, s10
    s.or         s7, s2, s11
    s.lshri      s2, s9, #32
    v.extract    s8, v20, #4
    s.shli       s10, s6, #32
    v.extract    s6, v8, #4
    s.shli       s11, s4, #32
    s.add        s4, s5, s7
    v.extract    s5, v21, #5
    v.insert     v6, s9, #2
    v.extract    s7, v9, #5
    v.insert     v7, s2, #2
    s.or         s2, s8, s10
    s.or         s8, s6, s11
    s.lshri      s6, s4, #32
    v.extract    s9, v20, #5
    s.shli       s10, s5, #32
    v.extract    s5, v8, #5
    s.shli       s11, s7, #32
    s.add        s7, s2, s8
    v.extract    s2, v21, #6
    v.insert     v6, s4, #3
    v.extract    s4, v9, #6
    v.insert     v7, s6, #3
    v.extract    s6, v10, #0
    v.movi       v18, #1
    v.splat      v19, s6
    s.or         s8, s9, s10
    v.extract    s9, v11, #0
    v.cmp.ltu    p10, v10, v19
    v.splat      v22, s9
    v.sub        v23, v10, v19
    s.or         s10, s5, s11
    s.lshri      s5, s7, #32
    s.shli       s11, s2, #32
    s.shli       s2, s4, #32
    s.add        s4, s8, s10
    v.extract    s8, v20, #6
    v.insert     v6, s7, #4
    v.movi       v10, #0
    v.extract    s7, v8, #6
    v.insert     v7, s5, #4
    @p10 v.sel        v24, v18, v10
    v.sub        v10, v11, v22
    v.movi       v11, #31
    v.extract    s5, v21, #7
    v.sub        v18, v10, v24
    v.ashr       v10, v23, v11
    v.movi       v11, #1
    v.movi       v21, #0
    s.or         s10, s8, s11
    v.extract    s8, v9, #7
    s.or         s11, s7, s2
    s.movz       s2, #8
    s.shli       s7, s5, #32
    s.shli       s5, s8, #32
    v.cmp.ne     p10, v18, v10
    v.iota       v9                              // arange(0, VLEN)
    s.add        s8, s10, s11
    s.lshri      s10, s4, #32
    @p10 v.sel        v10, v11, v21
    v.insert     v6, s4, #5
    v.extract    s4, v20, #7
    v.splat      v11, s2
    v.extract    s2, v8, #7
    v.insert     v7, s10, #5
    s.or         s10, s4, s7
    s.or         s4, s2, s5
    s.lshri      s2, s8, #32
    v.cmp.lt     p10, v9, v11
    s.add        s5, s10, s4
    @p10 v.reduce.or  s4, v10
    s.movz       s7, #0
    v.insert     v6, s8, #6
    v.insert     v7, s2, #6
    s.lshri      s2, s5, #32
    s.shli       s8, s9, #32
    s.cmp.eq     s9, s4, s7
    v.insert     v6, s5, #7
    v.insert     v7, s2, #7
    s.or         s2, s6, s8
    br.nz        s9, narrow_ok_10
    trap         #677220
narrow_ok_10:
    v.movi       v8, #1
    v.movi       v9, #0
    v.cmp.ltu    p10, v12, v19
    v.sub        v10, v12, v19
    @p10 v.sel        v11, v8, v9
    v.sub        v8, v13, v22
    v.movi       v9, #31
    v.movi       v12, #1
    v.sub        v13, v8, v11
    v.ashr       v8, v10, v9
    v.movi       v9, #0
    s.movz       s4, #8
    v.cmp.ne     p10, v13, v8
    v.iota       v8                              // arange(0, VLEN)
    v.splat      v11, s4
    @p10 v.sel        v13, v12, v9
    s.movz       s4, #0
    v.cmp.lt     p10, v8, v11
    @p10 v.reduce.or  s5, v13
    s.cmp.eq     s6, s5, s4
    br.nz        s6, narrow_ok_11
    trap         #677220
narrow_ok_11:
    v.movi       v8, #1
    v.movi       v9, #0
    v.cmp.ltu    p10, v14, v19
    v.sub        v11, v14, v19
    @p10 v.sel        v12, v8, v9
    v.sub        v8, v15, v22
    v.movi       v9, #31
    v.movi       v13, #1
    v.sub        v14, v8, v12
    v.ashr       v8, v11, v9
    v.movi       v9, #0
    s.movz       s4, #8
    v.cmp.ne     p10, v14, v8
    v.iota       v8                              // arange(0, VLEN)
    v.splat      v12, s4
    @p10 v.sel        v14, v13, v9
    s.movz       s4, #0
    v.cmp.lt     p10, v8, v12
    @p10 v.reduce.or  s5, v14
    s.cmp.eq     s6, s5, s4
    br.nz        s6, narrow_ok_12
    trap         #677220
narrow_ok_12:
    v.movi       v8, #1
    v.movi       v9, #0
    v.cmp.ltu    p10, v16, v19
    v.sub        v12, v16, v19
    @p10 v.sel        v13, v8, v9
    v.sub        v8, v17, v22
    v.movi       v9, #31
    v.movi       v14, #1
    v.sub        v15, v8, v13
    v.ashr       v8, v12, v9
    v.movi       v9, #0
    s.movz       s4, #8
    v.cmp.ne     p10, v15, v8
    v.iota       v8                              // arange(0, VLEN)
    v.splat      v13, s4
    @p10 v.sel        v15, v14, v9
    s.movz       s4, #0
    v.cmp.lt     p10, v8, v13
    @p10 v.reduce.or  s5, v15
    s.cmp.eq     s6, s5, s4
    br.nz        s6, narrow_ok_13
    trap         #677220
narrow_ok_13:
    v.movi       v8, #1
    v.movi       v9, #0
    v.cmp.ltu    p10, v0, v19
    v.sub        v13, v0, v19
    @p10 v.sel        v0, v8, v9
    v.sub        v8, v1, v22
    v.movi       v1, #31
    v.movi       v9, #1
    v.sub        v14, v8, v0
    v.ashr       v0, v13, v1
    v.movi       v1, #0
    s.movz       s4, #8
    v.cmp.ne     p10, v14, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v8, s4
    @p10 v.sel        v14, v9, v1
    s.movz       s4, #0
    v.cmp.lt     p10, v0, v8
    @p10 v.reduce.or  s5, v14
    s.cmp.eq     s6, s5, s4
    br.nz        s6, narrow_ok_14
    trap         #677220
narrow_ok_14:
    v.movi       v0, #1
    v.movi       v1, #0
    v.cmp.ltu    p10, v2, v19
    v.sub        v8, v2, v19
    @p10 v.sel        v2, v0, v1
    v.sub        v0, v3, v22
    v.movi       v1, #31
    v.movi       v3, #1
    v.sub        v9, v0, v2
    v.ashr       v0, v8, v1
    v.movi       v1, #0
    s.movz       s4, #8
    v.cmp.ne     p10, v9, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s4
    @p10 v.sel        v9, v3, v1
    s.movz       s4, #0
    v.cmp.lt     p10, v0, v2
    @p10 v.reduce.or  s5, v9
    s.cmp.eq     s6, s5, s4
    br.nz        s6, narrow_ok_15
    trap         #677220
narrow_ok_15:
    v.movi       v0, #1
    v.movi       v1, #0
    v.cmp.ltu    p10, v4, v19
    v.sub        v2, v4, v19
    @p10 v.sel        v3, v0, v1
    v.sub        v0, v5, v22
    v.movi       v1, #31
    v.movi       v4, #1
    v.sub        v5, v0, v3
    v.ashr       v0, v2, v1
    v.movi       v1, #0
    s.movz       s4, #8
    v.cmp.ne     p10, v5, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v3, s4
    @p10 v.sel        v5, v4, v1
    s.movz       s4, #0
    v.cmp.lt     p10, v0, v3
    @p10 v.reduce.or  s5, v5
    s.cmp.eq     s6, s5, s4
    br.nz        s6, narrow_ok_16
    trap         #677220
narrow_ok_16:
    v.movi       v0, #1
    v.movi       v1, #0
    v.cmp.ltu    p10, v6, v19
    v.sub        v3, v6, v19
    @p10 v.sel        v4, v0, v1
    v.sub        v0, v7, v22
    v.movi       v1, #31
    v.movi       v5, #1
    v.sub        v6, v0, v4
    v.ashr       v0, v3, v1
    v.movi       v1, #0
    s.movz       s4, #8
    v.cmp.ne     p10, v6, v0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v4, s4
    @p10 v.sel        v6, v5, v1
    s.movz       s4, #0
    v.cmp.lt     p10, v0, v4
    @p10 v.reduce.or  s5, v6
    s.cmp.eq     s6, s5, s4
    br.nz        s6, narrow_ok_17
    trap         #677220
narrow_ok_17:
    s.addi       s4, s1, #0
    v.movi       v0, #1
    v.ld.w       v1, [s4, #0]
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s4, #8
    @p1 v.sel        v6, v0, v4
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v4, s4
    v.extract    s4, v6, #0
    s.shli       s5, s2, #1
    v.splat      v6, s4
    v.cmp.lt     p1, v0, v4
    s.add        s2, s3, s5                      // a 64-bit tile origin
    v.cmp.ne     p10, v6, v5
    p.and        p11, p9, p10
    s.addi       s3, s1, #64
    p.and        p10, p1, p11
    v.movi       v0, #1
    v.movi       v4, #0
    @p10 v.st.scatter.h [s2, v23], v1
    v.movi       v1, #0
    @p2 v.sel        v5, v0, v4
    s.movz       s4, #8
    v.iota       v0                              // arange(0, VLEN)
    v.extract    s5, v5, #0
    v.splat      v4, s4
    v.splat      v5, s5
    s.addi       s4, s1, #128
    v.cmp.lt     p1, v0, v4
    v.cmp.ne     p2, v5, v1
    p.and        p10, p9, p2
    v.movi       v0, #1
    p.and        p2, p1, p10
    v.ld.w       v1, [s3, #0]
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s3, #8
    @p3 v.sel        v6, v0, v4
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v4, s3
    v.extract    s3, v6, #0
    s.addi       s5, s1, #192
    v.splat      v6, s3
    v.cmp.lt     p1, v0, v4
    v.movi       v0, #1
    v.cmp.ne     p3, v6, v5
    p.and        p10, p9, p3
    v.movi       v4, #0
    p.and        p3, p1, p10
    v.movi       v5, #0
    @p4 v.sel        v6, v0, v4
    @p2 v.st.scatter.h [s2, v10], v1
    s.movz       s3, #8
    v.extract    s6, v6, #0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s6
    v.splat      v4, s3
    s.addi       s3, s1, #256
    v.cmp.ne     p1, v1, v5
    p.and        p2, p9, p1
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    v.movi       v0, #1
    v.movi       v1, #0
    v.movi       v4, #0
    v.ld.w       v5, [s4, #0]
    @p5 v.sel        v6, v0, v1
    s.movz       s4, #8
    v.iota       v0                              // arange(0, VLEN)
    v.extract    s6, v6, #0
    v.splat      v1, s4
    v.splat      v6, s6
    s.addi       s4, s1, #320
    v.cmp.lt     p1, v0, v1
    v.cmp.ne     p2, v6, v4
    p.and        p5, p9, p2
    v.movi       v0, #1
    p.and        p2, p1, p5
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s6, #8
    @p6 v.sel        v6, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    @p3 v.st.scatter.h [s2, v11], v5
    v.extract    s7, v6, #0
    v.splat      v1, s6
    v.splat      v5, s7
    s.addi       s6, s1, #384
    v.cmp.lt     p1, v0, v1
    v.cmp.ne     p3, v5, v4
    p.and        p5, p9, p3
    p.and        p3, p1, p5
    v.ld.w       v0, [s5, #0]
    v.movi       v1, #1
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s5, #8
    @p7 v.sel        v6, v1, v4
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v4, s5
    v.extract    s5, v6, #0
    v.splat      v6, s5
    v.cmp.lt     p1, v1, v4
    v.cmp.ne     p5, v6, v5
    p.and        p6, p9, p5
    p.and        p5, p1, p6
    @p4 v.st.scatter.h [s2, v12], v0
    s.addi       s5, s1, #448
    v.ld.w       v0, [s3, #0]
    v.movi       v1, #1
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s1, #8
    @p8 v.sel        v6, v1, v4
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v4, s1
    v.extract    s1, v6, #0
    v.splat      v6, s1
    v.cmp.lt     p1, v1, v4
    v.cmp.ne     p4, v6, v5
    p.and        p6, p9, p4
    p.and        p4, p1, p6
    @p2 v.st.scatter.h [s2, v13], v0
    v.ld.w       v0, [s4, #0]
    @p3 v.st.scatter.h [s2, v8], v0
    v.ld.w       v0, [s6, #0]
    @p5 v.st.scatter.h [s2, v2], v0
    v.ld.w       v0, [s5, #0]
    @p4 v.st.scatter.h [s2, v3], v0
__rctx_next:
    exit
