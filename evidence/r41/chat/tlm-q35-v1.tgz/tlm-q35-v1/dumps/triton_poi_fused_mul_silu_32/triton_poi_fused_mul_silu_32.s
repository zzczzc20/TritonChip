    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    .li       s4, #138240
    v.splat      v2, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    v.add        v3, v1, v0
    .li       s2, #1069066811
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1060205080
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p1, v3, v2
    .li       s2, #1065353216
    v.splat      v2, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1065353216
    v.splat      v3, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s2, s3, s4                      // &in_ptr0[...]
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    @p1 v.ld.h       v4, [s2, #0]
    s.add        s2, s3, s4                      // &in_ptr1[...]
    vf.cvt.bf16.f32 v5, v4
    @p1 v.ld.h       v4, [s2, #0]
    vf.neg       v6, v5
    vf.mul       v7, v6, v0
    v.exp2.approx v8, v7                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v9, v6, v0, v7                  // the exact rounding error of x*log2(e)
    vf.cvt.bf16.f32 v0, v4
    s.ld.d       s2, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    vf.mul       v4, v9, v1
    s.add        s1, s2, s4                      // &out_ptr0[...]
    vf.fma       v1, v8, v4, v8                  // 2**t * 2**d
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v4, v1, v8
    vf.add       v1, v4, v2
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v4, v1, v2, v3
    vf.fms       v3, v2, v4, v2
    vf.neg       v4, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v3, v4, v2
    vf.mul       v2, v5, v3                      // a/y: faithful quotient
    vf.fms       v4, v2, v1, v5
    vf.fms       v1, v4, v3, v2
    vf.neg       v3, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v1, v3, v2
    vf.mul       v2, v1, v0
    vf.cvt.f32.bf16 v0, v2
    @p1 v.st.h       [s1, #0], v0
__rctx_next:
    exit
