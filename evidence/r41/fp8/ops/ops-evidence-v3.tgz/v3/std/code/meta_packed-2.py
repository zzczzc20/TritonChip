# AOT ID: ['43_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


cpp_fused_slice_sub_0 = async_compile.cpp_pybinding(['const int32_t*', 'int32_t*'], r'''
#include <torch/csrc/inductor/cpp_prefix.h>
extern "C"  void  kernel(const int32_t* in_ptr0,
                       int32_t* out_ptr0)
{
    std::atomic<int> inductor_cpu_integer_div_error{0};
    inductor_cpu_integer_div_error_flag = &inductor_cpu_integer_div_error;
    {
        {
            {
                auto tmp0 = in_ptr0[static_cast<int64_t>(1L)];
                auto tmp1 = in_ptr0[static_cast<int64_t>(0L)];
                auto tmp2 = int32_t(static_cast<std::make_unsigned_t<int32_t>>(tmp0) - static_cast<std::make_unsigned_t<int32_t>>(tmp1));
                out_ptr0[static_cast<int64_t>(0L)] = tmp2;
            }
        }
    }
    inductor_cpu_integer_div_error_flag = nullptr;
    inductor_cpu_throw_if_integer_div_error(inductor_cpu_integer_div_error);
}
''')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/zu/czufi5lrcasor45tuep2fysko6ukkrt6ltlbuyi54x5ffyohfije.py
# Topologically Sorted Source Nodes: [], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
# Graph fragment:
#   %getitem : Tensor "f32[1, 4, 256, 64][65536, 16384, 64, 1]tnca:0" = PlaceHolder[target=getitem]
#   %mul_scalar : Tensor "f32[1, 4, 256, 64][65536, 16384, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%getitem, 0.3535533905932738), kwargs = {})
#   return %expand_default
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 65536}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 786432}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 65536
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None)
    tmp1 = tl.full([1], 0.3535533905932738, tl.float32)
    tmp2 = tmp0 * tmp1
    tl.store(out_ptr0 + (x0), tmp2, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/dj/cdjnueblfqujk3qibmlufgprfexwd5vmggh5nf7oyi3dfiwom3a5.py
# Topologically Sorted Source Nodes: [], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
# Graph fragment:
#   %getitem_1 : Tensor "f32[1, 4, 256, 64][65536, 16384, 64, 1]tnca:0" = PlaceHolder[target=getitem_1]
#   %permute_default : Tensor "f32[1, 4, 64, 256][65536, 16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%getitem_1, [0, 1, 3, 2]), kwargs = {})
#   %mul_scalar_1 : Tensor "f32[1, 4, 64, 256][65536, 16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_default, 0.3535533905932738), kwargs = {})
#   return %expand_default_1
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_2 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'y': 256, 'x': 256}, tile_hint=TileHint.SQUARE,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'y': 262144, 'x': 524288}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_2(in_ptr0, out_ptr0, ynumel, xnumel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 256
    xnumel = 256
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :]
    xmask = xindex < xnumel
    x2 = xindex
    y0 = (yindex % 64)
    y1 = yindex // 64
    y3 = yindex
    tmp0 = tl.load(in_ptr0 + (y0 + 64*x2 + 16384*y1), xmask & ymask)
    tmp1 = tl.full([1, 1], 0.3535533905932738, tl.float32)
    tmp2 = tmp0 * tmp1
    tl.store(out_ptr0 + (x2 + 256*y3), tmp2, xmask & ymask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/dp/cdp5ty6lo36upprsjgzs6ckrcteilhnerkz3s2rhlqm4pybwma3x.py
# Topologically Sorted Source Nodes: [], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
# Graph fragment:
#   %expand_default : Tensor "f32[1, 4, 256, 64][65536, 16384, 64, 1]tnca:0" = PlaceHolder[target=expand_default]
#   %expand_default_1 : Tensor "f32[1, 4, 64, 256][65536, 16384, 256, 1]tnca:0" = PlaceHolder[target=expand_default_1]
#   %mul_scalar : Tensor "f32[1, 4, 256, 64][65536, 16384, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%getitem, 0.3535533905932738), kwargs = {})
#   %view_default : Tensor "f32[4, 256, 64][16384, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_default, [4, 256, 64]), kwargs = {})
#   %permute_default : Tensor "f32[1, 4, 64, 256][65536, 16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%getitem_1, [0, 1, 3, 2]), kwargs = {})
#   %mul_scalar_1 : Tensor "f32[1, 4, 64, 256][65536, 16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_default, 0.3535533905932738), kwargs = {})
#   %view_default_1 : Tensor "f32[4, 64, 256][16384, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_default_1, [4, 64, 256]), kwargs = {})
#   %bmm_default : Tensor "f32[4, 256, 256][65536, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_default, %view_default_1), kwargs = {})
#   return %bmm_default
triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_3 = async_compile.triton('triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_3', 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_3(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 256
    N = 256
    K = 64
    BATCH = 4

    stride_aq = 16384
    stride_am = 64
    stride_ak = 1

    stride_bq = 16384
    stride_bk = 256
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 256*idx_m + 65536*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/wb/cwbe6ovgrdj7kavek6irhkdplbbmv7spd2x5w6gi47pruc27hmta.py
# Topologically Sorted Source Nodes: [], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
# Graph fragment:
#   %bmm_default : Tensor "f32[4, 256, 256][65536, 256, 1]tnca:0" = PlaceHolder[target=bmm_default]
#   %amax_default : Tensor "f32[1, 4, 256, 1][1024, 256, 1, 1024]tnca:0" = PlaceHolder[target=amax_default]
#   %exp_default : Tensor "f32[1, 4, 256, 256][262144, 65536, 256, 1]tnca:0" = PlaceHolder[target=exp_default]
#   %any_dim : Tensor "b8[1, 4, 256, 1][1024, 256, 1, 1024]tnca:0" = PlaceHolder[target=any_dim]
#   %sum_dim_int_list : Tensor "f32[1, 4, 256, 1][1024, 256, 1, 1024]tnca:0" = PlaceHolder[target=sum_dim_int_list]
#   %view_default_2 : Tensor "f32[1, 4, 256, 256][262144, 65536, 256, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_default, [1, 4, 256, 256]), kwargs = {})
#   %eq_scalar : Tensor "b8[1, 4, 256, 256][262144, 65536, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%view_default_2, -inf), kwargs = {})
#   %logical_not_default : Tensor "b8[1, 4, 256, 256][262144, 65536, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq_scalar,), kwargs = {})
#   %any_dim : Tensor "b8[1, 4, 256, 1][1024, 256, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.any.dim](args = (%logical_not_default, -1, True), kwargs = {})
#   %logical_not_default_1 : Tensor "b8[1, 4, 256, 1][1024, 256, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_dim,), kwargs = {})
#   %full_default : Tensor "f32[1, 4, 256, 256][262144, 65536, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 4, 256, 256], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %amax_default : Tensor "f32[1, 4, 256, 1][1024, 256, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%view_default_2, [-1], True), kwargs = {})
#   %sub_tensor : Tensor "f32[1, 4, 256, 256][262144, 65536, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%view_default_2, %amax_default), kwargs = {})
#   %exp_default : Tensor "f32[1, 4, 256, 256][262144, 65536, 256, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub_tensor,), kwargs = {})
#   %sum_dim_int_list : Tensor "f32[1, 4, 256, 1][1024, 256, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp_default, [-1], True), kwargs = {})
#   %div_tensor : Tensor "f32[1, 4, 256, 256][262144, 65536, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp_default, %sum_dim_int_list), kwargs = {})
#   %where_self : Tensor "f32[1, 4, 256, 256][262144, 65536, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_default_1, %full_default, %div_tensor), kwargs = {})
#   return %any_dim,%amax_default,%exp_default,%sum_dim_int_list,%expand_default_2
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_4 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1024, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_4', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 2, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 3145728}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_4(in_out_ptr0, in_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1024
    XBLOCK: tl.constexpr = 1
    r0_numel = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[1024, 256], strides=[256, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp7 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp11 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp1 = tl.full([1], float("-inf"), tl.float32)
        tmp2 = tmp0 == tmp1
        tmp3 = tmp2 == 0
        tmp4 = tmp3.to(tl.int64)
        tmp5 = (tmp4 != 0)
        tmp6 = tl.broadcast_to(tmp5, [R0_BLOCK])
        tmp8 = _tmp7 | tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
        tmp10 = tl.broadcast_to(tmp0, [R0_BLOCK])
        tmp12 = tl.maximum(_tmp11, tmp10, tl.PropagateNan.ALL)
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp9 = _tmp7.to(tl.int8)
    tmp7 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp9, 0))
    tmp11 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp11, 0))
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[1024, 256], strides=[256, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp17 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp14 = tmp13 - tmp11
        tmp15 = libdevice.exp(tmp14)
        tmp16 = tl.broadcast_to(tmp15, [R0_BLOCK])
        tmp18 = _tmp17 + tmp16
        _tmp17 = tl.where(r0_mask, tmp18, _tmp17)
        tl.store(in_out_ptr0 + (r0_1 + 256*x0), tmp15, r0_mask)
    tmp17 = triton_helpers.promote_to_tensor(tl.sum(_tmp17, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[1024, 256], strides=[256, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tl.debug_barrier()
        tmp20 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp19 = tmp7 == 0
        tmp21 = (tmp20 / tmp17)
        tmp22 = tl.full([1], 0.0, tl.float32)
        tmp23 = tl.where(tmp19, tmp22, tmp21)
        tl.store(in_out_ptr0 + (r0_1 + 256*x0), tmp23, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/3n/c3nunmazkjm4v7n2uwhjjz36dirdbrgqkqwhgbt46jv4pkqhgafo.py
# Topologically Sorted Source Nodes: [], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
# Graph fragment:
#   %expand_default_2 : Tensor "f32[1, 4, 256, 256][262144, 65536, 256, 1]tnca:0" = PlaceHolder[target=expand_default_2]
#   %expand_default_3 : Tensor "f32[1, 4, 256, 64][65536, 16384, 64, 1]tnca:0" = PlaceHolder[target=expand_default_3]
#   %logical_not_default_1 : Tensor "b8[1, 4, 256, 1][1024, 256, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_dim,), kwargs = {})
#   %full_default : Tensor "f32[1, 4, 256, 256][262144, 65536, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 4, 256, 256], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %div_tensor : Tensor "f32[1, 4, 256, 256][262144, 65536, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp_default, %sum_dim_int_list), kwargs = {})
#   %where_self : Tensor "f32[1, 4, 256, 256][262144, 65536, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_default_1, %full_default, %div_tensor), kwargs = {})
#   %view_default_3 : Tensor "f32[4, 256, 256][65536, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_default_2, [4, 256, 256]), kwargs = {})
#   %view_default_4 : Tensor "f32[4, 256, 64][16384, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_default_3, [4, 256, 64]), kwargs = {})
#   %bmm_default_1 : Tensor "f32[4, 256, 64][16384, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_default_3, %view_default_4), kwargs = {})
#   return %bmm_default_1
triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_5 = async_compile.triton('triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_5', 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_5(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 256
    N = 64
    K = 256
    BATCH = 4

    stride_aq = 65536
    stride_am = 256
    stride_ak = 1

    stride_bq = 16384
    stride_bk = 64
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 64*idx_m + 16384*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/ne/cnesbfb7kz7scavbxgyuztskpcbswwmwq3nw5ntvfnrzoph7zv2p.py
# Topologically Sorted Source Nodes: [], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
# Graph fragment:
#   %bmm_default_1 : Tensor "f32[4, 256, 64][16384, 64, 1]tnca:0" = PlaceHolder[target=bmm_default_1]
#   %view_default_5 : Tensor "f32[1, 4, 256, 64][65536, 16384, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_default_1, [1, 4, 256, 64]), kwargs = {})
#   %permute_default_1 : Tensor "f32[256, 1, 4, 64][64, 65536, 16384, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_default_5, [2, 0, 1, 3]), kwargs = {})
#   %clone_default : Tensor "f32[256, 1, 4, 64][256, 256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%permute_default_1,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone_default
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 65536}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 786432}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 65536
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 64)
    x1 = ((xindex // 64) % 4)
    x2 = xindex // 256
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 64*x2 + 16384*x1), None)
    tl.store(out_ptr0 + (x3), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-fp8-ops-work/v3/std/inductor-cache/2y/c2yyrigsjzigojajdhpttg2psqbhnb34irskb4g5oja4ecfz72yd.py
# Topologically Sorted Source Nodes: [matmul_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.view]
# Source node to ATen node mapping:
#   matmul_1 => permute_default_2
# Graph fragment:
#   %clone_default : Tensor "f32[256, 1, 4, 64][256, 1, 64, 1]tnca:0" = PlaceHolder[target=clone_default]
#   %view_default_5 : Tensor "f32[1, 4, 256, 64][65536, 16384, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_default_1, [1, 4, 256, 64]), kwargs = {})
#   %permute_default_1 : Tensor "f32[256, 1, 4, 64][64, 65536, 16384, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_default_5, [2, 0, 1, 3]), kwargs = {})
#   %clone_default : Tensor "f32[256, 1, 4, 64][256, 256, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%permute_default_1,), kwargs = {memory_format: torch.contiguous_format})
#   %permute_default_2 : Tensor "f32[1, 4, 256, 64][256, 64, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%clone_default, [1, 2, 0, 3]), kwargs = {})
#   return %permute_default_2
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_view_7 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_view_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 65536}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_view_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 786432}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_view_7(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 65536
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 64)
    x1 = ((xindex // 64) % 256)
    x2 = xindex // 16384
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 64*x2 + 256*x1), None)
    tl.store(out_ptr0 + (x3), tmp0, None)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1 = args
        args.clear()
        assert_size_stride(arg0_1, (2, ), (1, ), 'input')
        buf0 = empty_strided_cpu((1, ), (1, ), torch.int32)
        cpp_fused_slice_sub_0(arg0_1, buf0)
        del arg0_1
        u0 = reinterpret_tensor(buf0, (), (), 0).item()
        buf1 = None
        if not (u0 >= 256):
            raise RuntimeError('u0 >= 256')
        buf2 = None
        if not (u0 <= 256):
            raise RuntimeError('u0 <= 256')
        buf3 = None
        if not (0 <= u0):
            raise RuntimeError('0 <= u0')
        buf4 = None
        if not (u0 == 256):
            raise RuntimeError('Eq(u0, 256)')
        buf5 = None
        u1 = reinterpret_tensor(buf0, (), (), 0).item()
        buf6 = None
        if not (u1 >= 256):
            raise RuntimeError('u1 >= 256')
        buf7 = None
        if not (u1 <= 256):
            raise RuntimeError('u1 <= 256')
        buf8 = None
        if not (0 <= u1):
            raise RuntimeError('0 <= u1')
        buf9 = None
        if not (u1 == 256):
            raise RuntimeError('Eq(u1, 256)')
        buf10 = None
        u2 = reinterpret_tensor(buf0, (), (), 0).item()
        buf11 = None
        del buf0
        if not (u2 >= 256):
            raise RuntimeError('u2 >= 256')
        buf12 = None
        if not (u2 <= 256):
            raise RuntimeError('u2 <= 256')
        buf13 = None
        if not (0 <= u2):
            raise RuntimeError('0 <= u2')
        buf14 = None
        if not (u2 == 256):
            raise RuntimeError('Eq(u2, 256)')
        buf15 = None
        assert_size_stride(arg1_1, (1, 4, 256, 64), (65536, 16384, 64, 1), 'input')
        buf16 = empty_strided((1, 4, 256, 64), (65536, 16384, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_1.run(arg1_1, buf16, 65536, stream=raw_stream0)
        del arg1_1
        assert_size_stride(arg2_1, (1, 4, 256, 64), (65536, 16384, 64, 1), 'input')
        buf17 = empty_strided((1, 4, 64, 256), (65536, 16384, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_2.run(arg2_1, buf17, 256, 256, stream=raw_stream0)
        del arg2_1
        buf18 = empty_strided((4, 256, 256), (65536, 256, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_3.run(buf16, buf17, buf18, 256, 4, 1, stream=raw_stream0)
        del buf16
        del buf17
        buf21 = empty_strided((1, 4, 256, 256), (262144, 65536, 256, 1), device='tnca', dtype=torch.float32)
        buf23 = buf21; del buf21  # reuse
        # Topologically Sorted Source Nodes: [], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_4.run(buf23, buf18, 1024, 256, stream=raw_stream0)
        del buf18
        assert_size_stride(arg3_1, (1, 4, 256, 64), (65536, 16384, 64, 1), 'input')
        buf24 = empty_strided((4, 256, 64), (16384, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_5.run(buf23, arg3_1, buf24, 64, 4, 1, stream=raw_stream0)
        del arg3_1
        del buf23
        buf25 = empty_strided((256, 1, 4, 64), (256, 1, 64, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_6.run(buf24, buf25, 65536, stream=raw_stream0)
        buf26 = reinterpret_tensor(buf24, (1, 4, 256, 64), (65536, 16384, 64, 1), 0); del buf24  # reuse
        # Topologically Sorted Source Nodes: [matmul_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.view]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_view_7.run(buf25, buf26, 65536, stream=raw_stream0)
        return (buf26, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((2, ), (1, ), device='cpu', dtype=torch.int32)
    arg1_1 = rand_strided((1, 4, 256, 64), (65536, 16384, 64, 1), device='tnca:0', dtype=torch.float32)
    arg2_1 = rand_strided((1, 4, 256, 64), (65536, 16384, 64, 1), device='tnca:0', dtype=torch.float32)
    arg3_1 = rand_strided((1, 4, 256, 64), (65536, 16384, 64, 1), device='tnca:0', dtype=torch.float32)
    return [arg0_1, arg1_1, arg2_1, arg3_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
