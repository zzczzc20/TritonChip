    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s7, [s1, #40]                   // out_ptr1: device_ptr64 at arg_base+40
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #64]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s9, #1024
    s.mul        s10, s1, s9
    s.add        s1, s8, s10                     // this context's own scratch
    s.addi       s8, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s9, #0
    s.st.d       [s8, #0], s2
    s.movz       s9, #512
    s.st.d       [s8, #8], s9
    s.movz       s9, #1024
    s.st.d       [s8, #16], s9
    s.movz       s9, #2048
    s.st.d       [s8, #48], s9
    s.movz       s9, #2
    s.st.d       [s8, #56], s9
    .li       s9, #68719476737
    s.st.d       [s8, #88], s9
    .li       s9, #8589934592
    s.st.d       [s8, #104], s9
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s8, s1, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s9, #0
    s.st.d       [s8, #0], s3
    s.movz       s9, #512
    s.st.d       [s8, #8], s9
    s.movz       s9, #1024
    s.st.d       [s8, #16], s9
    s.movz       s9, #2048
    s.st.d       [s8, #48], s9
    s.movz       s9, #2
    s.st.d       [s8, #56], s9
    .li       s9, #68719476737
    s.st.d       [s8, #88], s9
    .li       s9, #8589934592
    s.st.d       [s8, #104], s9
    fence.release.device
    td.load      d1, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s8, s1, #512                    // TensorMap 2: tl.make_tensor_descriptor (rank 2)
    s.movz       s9, #0
    s.st.d       [s8, #0], s4
    s.movz       s9, #512
    s.st.d       [s8, #8], s9
    s.movz       s9, #1024
    s.st.d       [s8, #16], s9
    s.movz       s9, #2048
    s.st.d       [s8, #48], s9
    s.movz       s9, #2
    s.st.d       [s8, #56], s9
    .li       s9, #68719476737
    s.st.d       [s8, #88], s9
    .li       s9, #8589934592
    s.st.d       [s8, #104], s9
    fence.release.device
    td.load      d2, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s8, s1, #768                    // TensorMap 3: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s8, #0], s5
    s.movz       s1, #512
    s.st.d       [s8, #8], s1
    s.movz       s1, #1024
    s.st.d       [s8, #16], s1
    s.movz       s1, #2048
    s.st.d       [s8, #48], s1
    s.movz       s1, #2
    s.st.d       [s8, #56], s1
    .li       s1, #68719476737
    s.st.d       [s8, #88], s1
    .li       s1, #8589934592
    s.st.d       [s8, #104], s1
    fence.release.device
    td.load      d3, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s8, #1024
    s.movz       s9, #16
    s.rdspecial  s10, role_id
    s.rdspecial  s11, npid.x
__rctx_program:
    v.movi       v0, #0
    v.movi       v1, #0
    v.splat      v2, s10
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s12, s1, #0
    v.mov        v1, v0
for_1:
    s.cmp.ge     s13, s12, s8
    br.nz        s13, endfor_2
    v.splat      v0, s12
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s12
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s13, #1024
    s.movz       s14, #512
    s.movz       s15, #1024
    s.movz       s16, #512
    s.muli       s17, s10, #2048
    s.muli       s18, s10, #2048
    v.add        v6, v0, v3
    v.movi       v0, #0
    v.splat      v3, s13
    v.splat      v7, s10
    v.movi       v8, #0
    v.splat      v9, s14
    v.add        v10, v4, v5
    v.movi       v4, #0
    v.splat      v5, s15
    s.muli       s13, s12, #2
    s.muli       s14, s12, #2
    v.cmp.ge     p1, v6, v0
    v.splat      v0, s10
    v.cmp.lt     p2, v6, v3
    v.movi       v3, #0
    v.splat      v6, s16
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    v.cmp.ge     p5, v10, v4
    s.add        s15, s2, s17
    p.and        p6, p1, p2
    v.cmp.lt     p1, v10, v5
    p.and        p2, p3, p4
    v.cmp.ge     p3, v0, v3
    s.add        s16, s3, s18
    p.and        p4, p5, p1
    v.cmp.lt     p1, v0, v6
    p.and        p5, p3, p1
    s.add        s17, s15, s13
    p.and        p1, p6, p2
    s.add        s13, s16, s14
    p.and        p2, p4, p5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s17, #0]
    v.splat      v3, s12
    v.movi       v4, #1024
    v.add        v5, v3, v2
    s.muli       s14, s10, #2048
    v.cmp.lt     p1, v5, v4
    v.splat      v3, s12
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s15, #1024
    s.movz       s16, #512
    v.add        v5, v3, v4
    v.movi       v3, #0
    v.splat      v4, s15
    v.splat      v6, s10
    v.movi       v7, #0
    v.splat      v8, s16
    s.muli       s15, s12, #2
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v9, [s13, #0]
    v.cmp.ge     p2, v5, v3
    v.cmp.lt     p3, v5, v4
    v.cmp.ge     p4, v6, v7
    v.cmp.lt     p5, v6, v8
    s.add        s13, s4, s14
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.muli       s14, s10, #2048
    s.add        s16, s13, s15
    p.and        p3, p6, p2
    vf.cvt.f16.f32 v3, v0
    v.splat      v0, s12
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s13, #1024
    s.movz       s15, #512
    v.add        v5, v0, v4
    v.movi       v0, #0
    v.splat      v4, s13
    v.splat      v6, s10
    v.movi       v7, #0
    v.splat      v8, s15
    s.muli       s13, s12, #2
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v10, [s16, #0]
    v.cmp.ge     p2, v5, v0
    v.cmp.lt     p3, v5, v4
    v.cmp.ge     p4, v6, v7
    v.cmp.lt     p5, v6, v8
    s.add        s15, s5, s14
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.add        s14, s15, s13
    p.and        p3, p6, p2
    vf.cvt.f16.f32 v0, v9
    v.movi       v4, #0
    s.add        s13, s12, s9
    s.movz       s15, #1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s14, #0]
    vf.cvt.f16.f32 v6, v10
    vf.add       v7, v3, v0
    vf.add       v0, v7, v6
    vf.cvt.f16.f32 v3, v5
    vf.add       v5, v0, v3
    vf.mul       v0, v5, v5
    vf.add       v3, v1, v0
    @p1 v.sel        v0, v3, v1
    v.mov        v4, v0
    v.mov        v1, v4
    s.mov        s12, s13
    br.nz        s15, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.addi       s12, s1, #0
    vf.add       v3, v0, v1
for_3:
    s.cmp.ge     s13, s12, s8
    br.nz        s13, endfor_4
    v.splat      v0, s12
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v4, s12
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s13, #1024
    s.movz       s14, #512
    s.movz       s15, #1024
    s.movz       s16, #512
    s.muli       s17, s10, #2048
    s.muli       s18, s10, #2048
    v.add        v6, v0, v1
    v.movi       v0, #0
    v.splat      v1, s13
    v.splat      v7, s10
    v.movi       v8, #0
    v.splat      v9, s14
    v.add        v10, v4, v5
    v.movi       v4, #0
    v.splat      v5, s15
    s.muli       s13, s12, #2
    s.muli       s14, s12, #2
    v.cmp.ge     p1, v6, v0
    v.splat      v0, s10
    v.cmp.lt     p2, v6, v1
    v.movi       v1, #0
    v.splat      v6, s16
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    v.cmp.ge     p5, v10, v4
    s.add        s15, s2, s17
    p.and        p6, p1, p2
    v.cmp.lt     p1, v10, v5
    p.and        p2, p3, p4
    v.cmp.ge     p3, v0, v1
    s.add        s16, s3, s18
    p.and        p4, p5, p1
    v.cmp.lt     p1, v0, v6
    p.and        p5, p3, p1
    s.add        s17, s15, s13
    p.and        p1, p6, p2
    s.add        s13, s16, s14
    p.and        p2, p4, p5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s17, #0]
    v.splat      v1, s12
    v.movi       v4, #1024
    v.add        v5, v1, v2
    s.muli       s14, s10, #2048
    v.cmp.lt     p1, v5, v4
    v.splat      v1, s12
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s15, #1024
    s.movz       s16, #512
    v.add        v6, v1, v4
    v.movi       v1, #0
    v.splat      v4, s15
    v.splat      v7, s10
    v.movi       v8, #0
    v.splat      v9, s16
    s.muli       s15, s12, #2
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v10, [s13, #0]
    v.cmp.ge     p2, v6, v1
    v.cmp.lt     p3, v6, v4
    v.cmp.ge     p4, v7, v8
    v.cmp.lt     p5, v7, v9
    s.add        s13, s4, s14
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.muli       s14, s10, #2048
    s.add        s16, s13, s15
    p.and        p3, p6, p2
    vf.cvt.f16.f32 v1, v0
    v.splat      v0, s12
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s13, #1024
    s.movz       s15, #512
    v.add        v6, v0, v4
    v.movi       v0, #0
    v.splat      v4, s13
    v.splat      v7, s10
    v.movi       v8, #0
    v.splat      v9, s15
    s.muli       s13, s12, #2
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v11, [s16, #0]
    v.cmp.ge     p2, v6, v0
    v.cmp.lt     p3, v6, v4
    v.cmp.ge     p4, v7, v8
    v.cmp.lt     p5, v7, v9
    s.add        s15, s5, s14
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.add        s14, s15, s13
    p.and        p3, p6, p2
    vf.cvt.f16.f32 v0, v10
    .li       s13, #1149239296
    v.splat      v4, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s13, #1065353216
    v.splat      v6, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s13, #925353388
    v.splat      v7, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v8, v4                          // ISA 8.8: <= 2**-22 relative
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v9, [s14, #0]
    .li       s13, #1077936128
    v.splat      v10, s13                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s13, s12, #1                    // element offset -> bytes (x2)
    vf.cvt.f16.f32 v12, v11
    s.add        s14, s6, s13                    // &in_ptr4[...]
    vf.add       v11, v1, v0
    .li       s13, #3204448256
    v.splat      v0, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s13, s10, s8
    s.add        s15, s12, s9
    s.movz       s16, #1
    vf.add       v1, v11, v12
    s.add        s17, s12, s13
    v.splat      v11, s13
    vf.cvt.f16.f32 v12, v9
    s.shli       s13, s17, #1                    // element offset -> bytes (x2)
    v.add        v9, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v5, [s14, #0]
    s.add        s14, s7, s13                    // &out_ptr1[...]
    vf.add       v9, v1, v12
    vf.fms       v1, v4, v8, v6
    vf.cvt.f16.f32 v4, v5
    vf.fms       v5, v8, v1, v8
    vf.neg       v1, v5                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v5, v1, v8
    vf.mul       v1, v3, v5                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v5, v1, v7
    v.rsqrt.approx v1, v5                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v6, v1, v1
    vf.mul       v7, v1, v0
    vf.fms       v0, v5, v6, v10
    vf.mul       v5, v7, v0                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v5, v5
    @p2 v.sel        v0, v5, v1
    v.extract    s13, v0, #0
    v.splat      v0, s13
    vf.mul       v1, v9, v0
    vf.mul       v0, v1, v4
    vf.cvt.f32.f16 v1, v0
    @p1 v.st.h       [s14, #0], v1
    s.mov        s12, s15
    br.nz        s16, for_3
endfor_4:
__rctx_next:
    s.addi       s12, s10, #2                    // the next program of this context: + 2
    s.cmp.lt     s13, s12, s11
    s.mov        s10, s12
    br.nz        s13, __rctx_program
    exit
