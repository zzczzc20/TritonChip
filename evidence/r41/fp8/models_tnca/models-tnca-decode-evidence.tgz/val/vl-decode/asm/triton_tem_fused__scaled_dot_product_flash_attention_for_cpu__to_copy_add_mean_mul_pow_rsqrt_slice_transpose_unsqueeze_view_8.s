    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #1
    s.movz       s2, #0
    s.sub        s3, s1, s4
    s.movz       s5, #0
    s.min.s      s6, s3, s1
    s.movz       s1, #0
    s.cmp.lt     s3, s6, s2
    s.movz       s2, #0
    s.cmp.lt     s7, s4, s5
    s.sub        s5, s1, s3
    s.sub        s1, s2, s7
    s.xor        s2, s6, s5
    s.movz       s3, #0
    s.movz       s7, #1
    s.xor        s8, s4, s1
    s.sub        s9, s2, s5
    s.rdspecial  s2, arg_base
    s.movz       s5, #0
    s.sub        s10, s8, s1
    s.addi       s8, s3, #0
    s.cmp.eq     s3, s9, s7
    s.ld.d       s7, [s2, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.addi       s11, s5, #0
    s.ld.d       s5, [s2, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s12, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s8, s10
    br.nz        s3, sdiv_done_1
    s.movz       s2, #0
    s.movz       s3, #31
    s.mov        s8, s2
    s.addi       s2, s3, #0
sdiv_2:
    s.lshr       s3, s10, s2
    s.shli       s13, s11, #1
    s.andi       s14, s3, #1
    s.movz       s3, #0
    s.or         s15, s13, s14
    s.movz       s13, #1
    s.cmp.geu    s14, s15, s9
    s.shl        s16, s13, s2
    s.sub        s13, s3, s14
    s.subi       s3, s2, #1
    s.and        s14, s9, s13
    s.and        s17, s16, s13
    s.sub        s13, s15, s14
    s.or         s14, s8, s17
    s.mov        s11, s13
    s.mov        s8, s14
    s.mov        s2, s3
    s.movz       s3, #0
    s.cmp.ge     s13, s2, s3
    br.nz        s13, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.movz       s3, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s6, s2
    s.movz       s2, #0
    s.cmp.lt     s13, s3, s8
    s.sub        s8, s9, s10
    s.sub        s9, s2, s13
    s.xor        s2, s6, s8
    s.xor        s6, s11, s1
    s.xor        s10, s3, s9
    s.sub        s11, s2, s8
    s.movz       s2, #0
    s.movz       s13, #1
    s.sub        s14, s6, s1
    s.sub        s1, s10, s9
    s.movz       s6, #0
    s.addi       s10, s2, #0
    s.cmp.eq     s2, s11, s13
    s.add        s13, s4, s14
    s.addi       s4, s6, #0
    s.mov        s10, s1
    br.nz        s2, sdiv_done_3
    s.movz       s2, #0
    s.movz       s6, #31
    s.mov        s10, s2
    s.addi       s2, s6, #0
sdiv_4:
    s.lshr       s6, s1, s2
    s.shli       s14, s4, #1
    s.andi       s15, s6, #1
    s.movz       s6, #0
    s.or         s16, s14, s15
    s.movz       s14, #1
    s.cmp.geu    s15, s16, s11
    s.shl        s17, s14, s2
    s.sub        s14, s6, s15
    s.subi       s6, s2, #1
    s.and        s15, s11, s14
    s.and        s18, s17, s14
    s.sub        s14, s16, s15
    s.or         s15, s10, s18
    s.mov        s4, s14
    s.mov        s10, s15
    s.mov        s2, s6
    s.movz       s6, #0
    s.cmp.ge     s14, s2, s6
    br.nz        s14, sdiv_4
sdiv_done_3:
    s.xor        s1, s9, s8
    s.movz       s2, #16
    s.xor        s4, s10, s1
    s.mul        s6, s13, s2
    s.sub        s8, s4, s1
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s1, s8, s2
    v.movi       v1, #13
    v.splat      v2, s6
    v.movi       v3, #0
    v.add        v4, v2, v0
    v.splat      v2, s13
    v.splat      v5, s3
    v.splat      v6, s8
    v.splat      v7, s3
    v.splat      v8, s1
    v.sub        v9, v3, v4
    v.sub        v10, v3, v1
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.cmp.ge     p3, v2, v5
    v.cmp.ge     p3, v6, v7
    v.add        v2, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v4
    @p2 v.sel        v4, v10, v1
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s4, #31
idiv_5:
    v.splat      v8, s4
    v.shl        v9, v7, v0
    v.lshr       v10, v5, v8
    v.cmp.lt     p2, v7, v3
    v.and        v11, v10, v0
    v.shl        v10, v0, v8
    v.or         v8, v9, v11
    s.subi       s8, s4, #1
    v.cmp.geu    p3, v8, v4
    p.or         p4, p2, p3
    v.sub        v9, v8, v4
    @p4 v.sel        v11, v10, v3
    @p4 v.sel        v10, v9, v8
    v.or         v8, v6, v11
    v.mov        v7, v10
    v.mov        v6, v8
    s.mov        s4, s8
    s.movz       s8, #0
    s.cmp.ge     s9, s4, s8
    br.nz        s9, idiv_5
    v.movi       v0, #0
    v.sub        v4, v3, v7
    v.sub        v3, v0, v2
    v.sub        v5, v0, v1
    v.cmp.lt     p2, v2, v0
    v.cmp.lt     p3, v1, v0
    @p1 v.sel        v6, v4, v7
    v.movi       v4, #1
    @p2 v.sel        v7, v3, v2
    @p3 v.sel        v2, v5, v1
    v.movi       v1, #0
    v.movi       v3, #0
    s.movz       s4, #31
idiv_6:
    v.splat      v5, s4
    v.shl        v8, v3, v4
    v.lshr       v9, v7, v5
    v.cmp.lt     p1, v3, v0
    v.and        v10, v9, v4
    v.shl        v9, v4, v5
    v.or         v5, v8, v10
    s.subi       s8, s4, #1
    v.cmp.geu    p3, v5, v2
    p.or         p4, p1, p3
    v.sub        v8, v5, v2
    @p4 v.sel        v10, v9, v0
    @p4 v.sel        v9, v8, v5
    v.or         v5, v1, v10
    v.mov        v3, v9
    v.mov        v1, v5
    s.mov        s4, s8
    s.movz       s8, #0
    s.cmp.ge     s9, s4, s8
    br.nz        s9, idiv_6
    s.rdspecial  s4, pid.z
    s.rdspecial  s8, npid.y
    s.rdspecial  s9, pid.y
    s.mul        s10, s4, s8
    s.movz       s4, #15
    s.movz       s8, #1664
    s.rdspecial  s11, role_id
    s.movz       s13, #8192
    s.add        s14, s9, s10
    s.movz       s9, #128
    s.min.s      s10, s14, s4
    s.rdspecial  s4, arg_base
    s.mul        s15, s10, s8
    s.mul        s8, s11, s13
    v.extract    s10, v6, #0
    v.extract    s11, v6, #1
    v.extract    s13, v6, #2
    v.sub        v1, v0, v3
    v.splat      v0, s10
    v.splat      v2, s9
    s.movz       s10, #0
    v.splat      v4, s11
    v.splat      v5, s13
    s.ld.d       s11, [s4, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    @p2 v.sel        v7, v1, v3
    v.extract    s4, v6, #3
    v.extract    s13, v6, #4
    v.splat      v1, s4
    v.splat      v3, s13
    v.mul        v8, v0, v2
    v.iota       v0                              // arange(0, VLEN)
    s.add        s4, s10, s15                    // the tile origin
    v.mul        v9, v4, v2
    v.mul        v4, v5, v2
    v.mul        v5, v1, v2
    v.mul        v1, v3, v2
    s.add        s10, s11, s8                    // this context's own scratch
    v.add        v3, v8, v0
    v.splat      v8, s4
    v.add        v10, v9, v0
    v.add        v9, v4, v0
    v.add        v4, v5, v0
    v.add        v5, v1, v0
    s.addi       s4, s10, #0
    v.extract    s8, v6, #5
    v.splat      v1, s3
    v.extract    s11, v6, #6
    v.add        v11, v3, v8
    v.add        v3, v10, v8
    v.add        v10, v9, v8
    v.add        v9, v4, v8
    v.add        v4, v5, v8
    v.add        v5, v1, v11
    s.addi       s13, s4, #64
    v.add        v11, v1, v3
    s.addi       s15, s4, #128
    v.add        v3, v1, v10
    s.addi       s16, s4, #192
    v.add        v10, v1, v9
    s.addi       s17, s4, #256
    v.add        v9, v1, v4
    s.addi       s18, s4, #320
    s.addi       s19, s4, #384
    v.st.w       [s4, #0], v5
    v.splat      v4, s8
    v.extract    s8, v6, #7
    v.mul        v5, v4, v2
    v.add        v4, v5, v0
    v.add        v5, v4, v8
    v.add        v4, v1, v5
    v.st.w       [s13, #0], v11
    v.extract    s13, v6, #8
    v.splat      v5, s11
    s.addi       s11, s4, #448
    v.mul        v11, v5, v2
    v.add        v5, v11, v0
    v.add        v11, v5, v8
    v.add        v5, v1, v11
    v.st.w       [s15, #0], v3
    v.extract    s15, v6, #9
    v.splat      v3, s8
    s.addi       s8, s4, #512
    v.mul        v11, v3, v2
    v.add        v3, v11, v0
    v.add        v11, v3, v8
    v.add        v3, v1, v11
    v.st.w       [s16, #0], v10
    v.extract    s16, v6, #10
    v.splat      v10, s13
    s.addi       s13, s4, #576
    v.mul        v11, v10, v2
    v.add        v10, v11, v0
    v.add        v11, v10, v8
    v.add        v10, v1, v11
    v.st.w       [s17, #0], v9
    v.extract    s17, v6, #11
    v.splat      v9, s15
    s.addi       s15, s4, #640
    v.mul        v11, v9, v2
    v.add        v9, v11, v0
    v.add        v11, v9, v8
    v.add        v9, v1, v11
    v.st.w       [s18, #0], v4
    v.extract    s18, v6, #12
    v.splat      v4, s16
    s.addi       s16, s4, #704
    v.mul        v11, v4, v2
    v.add        v4, v11, v0
    v.add        v11, v4, v8
    v.add        v4, v1, v11
    v.st.w       [s19, #0], v5
    v.extract    s19, v6, #13
    v.splat      v5, s17
    s.addi       s17, s4, #768
    v.mul        v11, v5, v2
    v.add        v5, v11, v0
    v.add        v11, v5, v8
    v.add        v5, v1, v11
    v.st.w       [s11, #0], v3
    v.extract    s11, v6, #14
    v.splat      v3, s18
    s.addi       s18, s4, #832
    v.mul        v11, v3, v2
    v.add        v3, v11, v0
    v.add        v11, v3, v8
    v.add        v3, v1, v11
    v.st.w       [s8, #0], v10
    v.extract    s8, v6, #15
    v.splat      v6, s19
    v.splat      v10, s11
    v.mul        v11, v6, v2
    v.mul        v6, v10, v2
    v.add        v10, v11, v0
    v.add        v11, v6, v0
    v.add        v6, v10, v8
    v.add        v10, v11, v8
    v.add        v11, v1, v6
    s.addi       s11, s4, #896
    v.add        v6, v1, v10
    s.addi       s19, s4, #960
    v.st.w       [s13, #0], v9
    v.splat      v9, s8
    s.addi       s4, s10, #1024
    v.mul        v10, v9, v2
    v.splat      v2, s3
    v.add        v9, v10, v0
    v.add        v10, v2, v7
    v.add        v2, v9, v8
    v.add        v9, v10, v8
    v.add        v10, v1, v2
    v.splat      v1, s3
    v.st.w       [s15, #0], v4
    s.movz       s8, #13
    v.add        v2, v1, v9
    v.splat      v4, s8
    s.addi       s13, s4, #64
    v.add        v9, v4, v7
    v.add        v4, v9, v8
    v.add        v9, v1, v4
    v.st.w       [s16, #0], v5
    s.movz       s15, #26
    s.addi       s16, s4, #128
    v.splat      v4, s15
    s.addi       s15, s4, #192
    v.add        v5, v4, v7
    v.add        v4, v5, v8
    v.add        v5, v1, v4
    v.st.w       [s17, #0], v3
    s.movz       s17, #39
    v.splat      v3, s17
    s.movz       s17, #52
    v.add        v4, v3, v7
    v.add        v3, v4, v8
    v.add        v4, v1, v3
    v.st.w       [s18, #0], v11
    s.movz       s18, #65
    v.splat      v3, s17
    s.addi       s17, s4, #256
    v.add        v11, v3, v7
    v.add        v3, v11, v8
    v.add        v11, v1, v3
    v.st.w       [s11, #0], v6
    s.movz       s11, #78
    v.splat      v3, s18
    s.addi       s18, s4, #320
    v.add        v6, v3, v7
    v.add        v3, v6, v8
    v.add        v6, v1, v3
    v.st.w       [s19, #0], v10
    v.splat      v3, s11
    s.addi       s11, s4, #384
    v.add        v10, v3, v7
    fence.acq_rel.device
    s.movz       s19, #91
    v.add        v3, v10, v8
    v.add        v10, v1, v3
    v.st.w       [s4, #0], v2
    v.splat      v2, s19
    s.movz       s19, #104
    v.add        v3, v2, v7
    v.add        v2, v3, v8
    v.add        v3, v1, v2
    v.st.w       [s13, #0], v9
    s.movz       s13, #117
    v.splat      v2, s19
    s.addi       s19, s4, #448
    v.add        v9, v2, v7
    v.add        v2, v9, v8
    v.add        v9, v1, v2
    v.st.w       [s16, #0], v5
    s.movz       s16, #130
    v.splat      v2, s13
    s.addi       s13, s4, #512
    v.add        v5, v2, v7
    v.add        v2, v5, v8
    v.add        v5, v1, v2
    v.st.w       [s15, #0], v4
    s.movz       s15, #143
    v.splat      v2, s16
    s.addi       s16, s4, #576
    v.add        v4, v2, v7
    v.add        v2, v4, v8
    v.add        v4, v1, v2
    v.st.w       [s17, #0], v11
    s.movz       s17, #156
    v.splat      v2, s15
    s.addi       s15, s4, #640
    v.add        v11, v2, v7
    v.add        v2, v11, v8
    v.add        v11, v1, v2
    v.st.w       [s18, #0], v6
    s.movz       s18, #169
    v.splat      v2, s17
    s.addi       s17, s4, #704
    v.add        v6, v2, v7
    v.add        v2, v6, v8
    v.add        v6, v1, v2
    v.st.w       [s11, #0], v10
    s.movz       s11, #182
    v.splat      v2, s18
    v.add        v10, v2, v7
    v.add        v2, v10, v8
    v.add        v10, v1, v2
    v.st.w       [s19, #0], v3
    s.movz       s19, #195
    v.splat      v2, s11
    s.addi       s11, s4, #768
    v.add        v3, v2, v7
    v.add        v2, v3, v8
    v.add        v3, v1, v2
    v.st.w       [s13, #0], v9
    v.splat      v2, s19
    s.addi       s13, s4, #832
    v.add        v9, v2, v7
    s.addi       s19, s4, #896
    v.add        v2, v9, v8
    s.addi       s20, s4, #960
    v.add        v7, v1, v2
    s.addi       s4, s3, #0
    v.st.w       [s16, #0], v5
    s.addi       s3, s10, #0
    v.st.w       [s15, #0], v4
    s.addi       s15, s10, #2048
    v.st.w       [s17, #0], v11
    s.addi       s16, s10, #64
    v.st.w       [s11, #0], v6
    s.addi       s11, s15, #64
    v.st.w       [s13, #0], v10
    s.addi       s13, s10, #128
    v.st.w       [s19, #0], v3
    s.addi       s17, s15, #128
    v.st.w       [s20, #0], v7
    fence.acq_rel.device
    s.addi       s19, s10, #192
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s15, #192
    v.st.w       [s15, #0], v1
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #256
    v.st.w       [s11, #0], v1
    s.addi       s11, s15, #256
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #320
    v.st.w       [s17, #0], v1
    s.addi       s17, s15, #320
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #384
    v.st.w       [s3, #0], v1
    s.addi       s3, s15, #384
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #448
    v.st.w       [s11, #0], v1
    s.addi       s11, s15, #448
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #512
    v.st.w       [s17, #0], v1
    s.addi       s17, s15, #512
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #576
    v.st.w       [s3, #0], v1
    s.addi       s3, s15, #576
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #640
    v.st.w       [s11, #0], v1
    s.addi       s11, s15, #640
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #704
    v.st.w       [s17, #0], v1
    s.addi       s17, s15, #704
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #768
    v.st.w       [s3, #0], v1
    s.addi       s3, s15, #768
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #832
    v.st.w       [s11, #0], v1
    s.addi       s11, s15, #832
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #896
    v.st.w       [s17, #0], v1
    s.addi       s17, s15, #896
    s.addi       s20, s15, #960
    v.ld.w       v1, [s19, #0]
    s.addi       s15, s10, #960
    v.st.w       [s3, #0], v1
    s.addi       s3, s10, #1024
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #3072
    v.st.w       [s11, #0], v1
    s.addi       s11, s10, #1088
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s16, #64
    v.st.w       [s17, #0], v1
    s.addi       s17, s10, #1152
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s16, #128
    v.st.w       [s20, #0], v1
    fence.acq_rel.device
    s.addi       s19, s10, #1216
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s16, #192
    v.st.w       [s16, #0], v1
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #1280
    v.st.w       [s13, #0], v1
    s.addi       s13, s16, #256
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s10, #1344
    v.st.w       [s15, #0], v1
    s.addi       s15, s16, #320
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #1408
    v.st.w       [s3, #0], v1
    s.addi       s3, s16, #384
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #1472
    v.st.w       [s13, #0], v1
    s.addi       s13, s16, #448
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s10, #1536
    v.st.w       [s15, #0], v1
    s.addi       s15, s16, #512
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #1600
    v.st.w       [s3, #0], v1
    s.addi       s3, s16, #576
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #1664
    v.st.w       [s13, #0], v1
    s.addi       s13, s16, #640
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s10, #1728
    v.st.w       [s15, #0], v1
    s.addi       s15, s16, #704
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #1792
    v.st.w       [s3, #0], v1
    s.addi       s3, s16, #768
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #1856
    v.st.w       [s13, #0], v1
    s.addi       s13, s16, #832
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s10, #1920
    v.st.w       [s15, #0], v1
    s.addi       s15, s16, #896
    s.addi       s20, s16, #960
    v.ld.w       v1, [s19, #0]
    s.addi       s16, s10, #1984
    v.st.w       [s3, #0], v1
    v.ld.w       v1, [s11, #0]
    v.st.w       [s13, #0], v1
    v.ld.w       v1, [s17, #0]
    v.st.w       [s15, #0], v1
    v.ld.w       v1, [s16, #0]
    v.st.w       [s20, #0], v1
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_7:
    s.cmp.ge     s3, s4, s9
    br.nz        s3, endfor_8
    s.addi       s3, s10, #2048
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s11, #0
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #2112
    s.movz       s13, #1
    s.addi       s15, s10, #2176
    s.movz       s16, #2
    s.addi       s17, s10, #2240
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s11, v2
    v.ld.w       v1, [s3, #0]
    s.movz       s3, #3
    s.addi       s11, s10, #2304
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v2
    v.ld.w       v1, [s15, #0]
    s.movz       s13, #4
    s.addi       s15, s10, #2368
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s16, #5
    s.addi       s17, s10, #2432
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s3, v2
    v.ld.w       v1, [s11, #0]
    s.movz       s3, #6
    s.addi       s11, s10, #2496
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v2
    v.ld.w       v1, [s15, #0]
    s.movz       s13, #7
    s.addi       s15, s10, #2560
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s16, #8
    s.addi       s17, s10, #2624
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s3, v2
    v.ld.w       v1, [s11, #0]
    s.movz       s3, #9
    s.addi       s11, s10, #2688
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v2
    v.ld.w       v1, [s15, #0]
    s.movz       s13, #10
    s.addi       s15, s10, #2752
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s16, #11
    s.addi       s17, s10, #2816
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s3, v2
    v.ld.w       v1, [s11, #0]
    s.movz       s3, #12
    s.addi       s11, s10, #2880
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v2
    v.ld.w       v1, [s15, #0]
    s.movz       s13, #13
    s.addi       s15, s10, #2944
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s16, #14
    s.addi       s17, s10, #3008
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s3, v2
    v.ld.w       v1, [s11, #0]
    s.movz       s3, #15
    s.addi       s11, s10, #3072
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s13, v2
    v.ld.w       v1, [s15, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s13, #0
    s.addi       s15, s10, #3136
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s16, v2
    v.ld.w       v1, [s17, #0]
    s.movz       s16, #1
    s.addi       s17, s10, #3200
    v.ld.gather.w v2, [s7, v1]                   // index is in elements (ISA sec 9.1)
    s.movz       s19, #2
    a.vwrite     a1, s3, v2
    v.ld.w       v1, [s11, #0]
    s.addi       s3, s10, #3264
    s.movz       s11, #3
    v.ld.gather.w v2, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v2
    v.ld.w       v1, [s15, #0]
    s.addi       s13, s10, #3328
    s.movz       s15, #4
    v.ld.gather.w v2, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v2
    v.ld.w       v1, [s17, #0]
    s.addi       s16, s10, #3392
    s.movz       s17, #5
    v.ld.gather.w v2, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s19, v2
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #3456
    s.movz       s19, #6
    v.ld.gather.w v2, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s11, v2
    v.ld.w       v1, [s13, #0]
    s.addi       s11, s10, #3520
    s.movz       s13, #7
    v.ld.gather.w v2, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v2
    v.ld.w       v1, [s16, #0]
    s.addi       s15, s10, #3584
    s.movz       s16, #8
    v.ld.gather.w v2, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v2
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #3648
    s.movz       s17, #9
    v.movi       v2, #0
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s19, v3
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #3712
    s.movz       s19, #10
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s13, v3
    v.ld.w       v1, [s15, #0]
    s.addi       s13, s10, #3776
    s.movz       s15, #11
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #3840
    s.movz       s16, #12
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v3
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #3904
    s.movz       s17, #13
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s19, v3
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #3968
    s.movz       s19, #14
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s15, v3
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #4032
    s.movz       s15, #15
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v3
    v.ld.w       v1, [s11, #0]
    s.movz       s11, #0
    s.movz       s16, #0
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s17, v3
    v.ld.w       v1, [s13, #0]
    s.movz       s13, #1
    s.movz       s17, #2
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s19, v3
    v.ld.w       v1, [s3, #0]
    s.movz       s3, #3
    s.movz       s19, #4
    v.ld.gather.w v3, [s5, v1]                   // index is in elements (ISA sec 9.1)
    s.movz       s20, #5
    a.vwrite     a2, s15, v3
    a.vread      v1, a1, s11
    a.vread      v3, a2, s16
    v.extract    s11, v1, #0
    v.splat      v4, s11
    v.extract    s11, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s11
    a.vread      v4, a2, s13
    v.extract    s11, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s11
    a.vread      v4, a2, s17
    v.extract    s11, v1, #3
    vf.fma       v5, v3, v4, v6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    v.extract    s3, v1, #4
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s19
    v.extract    s3, v1, #5
    vf.fma       v5, v3, v4, v6
    v.splat      v3, s3
    a.vread      v4, a2, s20
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s3, #0
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #1
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #3
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #4
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #5
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #1
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #2
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #3
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #4
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #5
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #2
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #3
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #3
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #4
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #5
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #4
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #3
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #4
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #5
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #5
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #3
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #4
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #5
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #6
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #3
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #4
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #5
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #7
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #3
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #4
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #5
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #8
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #3
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #4
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #5
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #9
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #3
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #4
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #5
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #9
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #10
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #3
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #4
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #5
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #10
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #11
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #3
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #4
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #5
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #11
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #12
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #3
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #4
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #5
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #12
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #13
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #3
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #4
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #5
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #13
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #14
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v3, s3
    a.vread      v4, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v6, v3, v4, v5
    v.splat      v3, s3
    a.vread      v4, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #3
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #4
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #4
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #5
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #6
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #6
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v3, v4, v6
    v.extract    s11, v1, #7
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #8
    vf.fma       v6, v3, v4, v5
    v.extract    s11, v1, #8
    v.splat      v3, s11
    a.vread      v4, a2, s3
    s.movz       s3, #14
    vf.fma       v5, v3, v4, v6
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #10
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #10
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #11
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #12
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #12
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #13
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #14
    vf.fma       v6, v3, v4, v5
    v.extract    s13, v1, #14
    v.splat      v3, s13
    a.vread      v4, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v3, v4, v6
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v3, a2, s11
    s.movz       s11, #15
    vf.fma       v4, v1, v3, v5
    s.movz       s13, #0
    s.movz       s15, #1
    s.movz       s16, #2
    a.vwrite     a3, s3, v4
    a.vread      v1, a1, s11
    a.vread      v3, a2, s13
    v.extract    s3, v1, #0
    v.splat      v4, s3
    v.extract    s3, v1, #1
    vf.fma       v5, v4, v3, v2
    v.splat      v2, s3
    a.vread      v3, a2, s15
    v.extract    s3, v1, #2
    vf.fma       v4, v2, v3, v5
    v.splat      v2, s3
    a.vread      v3, a2, s16
    s.movz       s3, #3
    vf.fma       v5, v2, v3, v4
    v.extract    s11, v1, #3
    v.splat      v2, s11
    a.vread      v3, a2, s3
    s.movz       s3, #4
    vf.fma       v4, v2, v3, v5
    v.extract    s11, v1, #4
    v.splat      v2, s11
    a.vread      v3, a2, s3
    s.movz       s3, #5
    vf.fma       v5, v2, v3, v4
    v.extract    s11, v1, #5
    v.splat      v2, s11
    a.vread      v3, a2, s3
    s.movz       s3, #6
    vf.fma       v4, v2, v3, v5
    v.extract    s11, v1, #6
    v.splat      v2, s11
    a.vread      v3, a2, s3
    s.movz       s3, #7
    vf.fma       v5, v2, v3, v4
    v.extract    s11, v1, #7
    v.splat      v2, s11
    a.vread      v3, a2, s3
    s.movz       s3, #8
    vf.fma       v4, v2, v3, v5
    v.extract    s11, v1, #8
    v.splat      v2, s11
    a.vread      v3, a2, s3
    s.movz       s3, #15
    vf.fma       v5, v2, v3, v4
    s.movz       s11, #9
    v.extract    s13, v1, #9
    v.splat      v2, s13
    a.vread      v3, a2, s11
    s.movz       s11, #10
    vf.fma       v4, v2, v3, v5
    v.extract    s13, v1, #10
    v.splat      v2, s13
    a.vread      v3, a2, s11
    s.movz       s11, #11
    vf.fma       v5, v2, v3, v4
    v.extract    s13, v1, #11
    v.splat      v2, s13
    a.vread      v3, a2, s11
    s.movz       s11, #12
    vf.fma       v4, v2, v3, v5
    v.extract    s13, v1, #12
    v.splat      v2, s13
    a.vread      v3, a2, s11
    s.movz       s11, #13
    vf.fma       v5, v2, v3, v4
    v.extract    s13, v1, #13
    v.splat      v2, s13
    a.vread      v3, a2, s11
    s.movz       s11, #14
    vf.fma       v4, v2, v3, v5
    v.extract    s13, v1, #14
    v.splat      v2, s13
    a.vread      v3, a2, s11
    s.movz       s11, #15
    vf.fma       v5, v2, v3, v4
    v.extract    s13, v1, #15
    v.splat      v1, s13
    a.vread      v2, a2, s11
    s.addi       s11, s10, #2048
    vf.fma       v3, v1, v2, v5
    v.splat      v1, s2
    s.addi       s13, s10, #4096
    s.addi       s15, s10, #2112
    a.vwrite     a3, s3, v3
    v.ld.w       v2, [s11, #0]
    s.addi       s3, s13, #64
    s.addi       s11, s10, #2176
    s.addi       s16, s13, #128
    s.addi       s17, s10, #2240
    s.addi       s19, s13, #192
    s.addi       s20, s10, #2304
    v.add        v3, v2, v1
    v.st.w       [s13, #0], v3
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s13, #256
    v.add        v3, v2, v1
    v.st.w       [s3, #0], v3
    s.addi       s3, s10, #2368
    v.ld.w       v2, [s11, #0]
    s.addi       s11, s13, #320
    v.add        v3, v2, v1
    v.st.w       [s16, #0], v3
    s.addi       s16, s10, #2432
    v.ld.w       v2, [s17, #0]
    s.addi       s17, s13, #384
    v.add        v3, v2, v1
    v.st.w       [s19, #0], v3
    s.addi       s19, s10, #2496
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s13, #448
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s15, s10, #2560
    v.ld.w       v2, [s3, #0]
    s.addi       s3, s13, #512
    v.add        v3, v2, v1
    v.st.w       [s11, #0], v3
    s.addi       s11, s10, #2624
    v.ld.w       v2, [s16, #0]
    s.addi       s16, s13, #576
    v.add        v3, v2, v1
    v.st.w       [s17, #0], v3
    s.addi       s17, s10, #2688
    v.ld.w       v2, [s19, #0]
    s.addi       s19, s13, #640
    v.add        v3, v2, v1
    v.st.w       [s20, #0], v3
    s.addi       s20, s10, #2752
    v.ld.w       v2, [s15, #0]
    s.addi       s15, s13, #704
    v.add        v3, v2, v1
    v.st.w       [s3, #0], v3
    s.addi       s3, s10, #2816
    v.ld.w       v2, [s11, #0]
    s.addi       s11, s13, #768
    v.add        v3, v2, v1
    v.st.w       [s16, #0], v3
    s.addi       s16, s10, #2880
    v.ld.w       v2, [s17, #0]
    s.addi       s17, s13, #832
    v.add        v3, v2, v1
    v.st.w       [s19, #0], v3
    s.addi       s19, s10, #2944
    v.ld.w       v2, [s20, #0]
    s.addi       s20, s13, #896
    s.addi       s21, s13, #960
    v.add        v3, v2, v1
    v.st.w       [s15, #0], v3
    s.addi       s13, s10, #3008
    v.ld.w       v2, [s3, #0]
    s.addi       s3, s10, #3072
    v.add        v3, v2, v1
    v.st.w       [s11, #0], v3
    s.movz       s11, #208
    v.splat      v2, s11
    s.addi       s11, s10, #5120
    v.ld.w       v3, [s16, #0]
    s.addi       s15, s10, #3136
    v.add        v4, v3, v1
    v.st.w       [s17, #0], v4
    s.addi       s16, s11, #64
    v.ld.w       v3, [s19, #0]
    s.addi       s17, s10, #3200
    v.add        v4, v3, v1
    v.st.w       [s20, #0], v4
    s.addi       s19, s11, #128
    v.ld.w       v3, [s13, #0]
    s.addi       s13, s10, #3264
    v.add        v4, v3, v1
    v.st.w       [s21, #0], v4
    fence.acq_rel.device
    s.addi       s20, s11, #192
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #3328
    v.add        v3, v1, v2
    v.st.w       [s11, #0], v3
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s11, #256
    v.add        v3, v1, v2
    v.st.w       [s16, #0], v3
    s.addi       s16, s10, #3392
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s11, #320
    v.add        v3, v1, v2
    v.st.w       [s19, #0], v3
    s.addi       s19, s10, #3456
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s11, #384
    v.add        v3, v1, v2
    v.st.w       [s20, #0], v3
    s.addi       s20, s10, #3520
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s11, #448
    v.add        v3, v1, v2
    v.st.w       [s15, #0], v3
    s.addi       s15, s10, #3584
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s11, #512
    v.add        v3, v1, v2
    v.st.w       [s17, #0], v3
    s.addi       s17, s10, #3648
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s11, #576
    v.add        v3, v1, v2
    v.st.w       [s13, #0], v3
    s.addi       s13, s10, #3712
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s11, #640
    v.add        v3, v1, v2
    v.st.w       [s3, #0], v3
    s.addi       s3, s10, #3776
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s11, #704
    v.add        v3, v1, v2
    v.st.w       [s16, #0], v3
    s.addi       s16, s10, #3840
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s11, #768
    v.add        v3, v1, v2
    v.st.w       [s19, #0], v3
    s.addi       s19, s10, #3904
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s11, #832
    v.add        v3, v1, v2
    v.st.w       [s20, #0], v3
    s.addi       s20, s10, #3968
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s11, #896
    s.addi       s21, s11, #960
    v.add        v3, v1, v2
    v.st.w       [s15, #0], v3
    s.addi       s11, s10, #4032
    v.ld.w       v1, [s16, #0]
    s.addi       s15, s10, #4096
    v.add        v3, v1, v2
    v.st.w       [s17, #0], v3
    s.addi       s16, s10, #6144
    v.ld.w       v1, [s19, #0]
    s.addi       s17, s10, #4160
    v.add        v3, v1, v2
    v.st.w       [s13, #0], v3
    s.addi       s13, s16, #64
    v.ld.w       v1, [s20, #0]
    s.addi       s19, s10, #4224
    v.add        v3, v1, v2
    v.st.w       [s3, #0], v3
    s.addi       s3, s16, #128
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #4288
    v.add        v3, v1, v2
    v.st.w       [s21, #0], v3
    fence.acq_rel.device
    s.addi       s20, s16, #192
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s10, #4352
    v.st.w       [s16, #0], v1
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s16, #256
    v.st.w       [s13, #0], v1
    s.addi       s13, s10, #4416
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s16, #320
    v.st.w       [s3, #0], v1
    s.addi       s3, s10, #4480
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s16, #384
    v.st.w       [s20, #0], v1
    s.addi       s20, s10, #4544
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s16, #448
    v.st.w       [s17, #0], v1
    s.addi       s17, s10, #4608
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s16, #512
    v.st.w       [s19, #0], v1
    s.addi       s19, s10, #4672
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s16, #576
    v.st.w       [s11, #0], v1
    s.addi       s11, s10, #4736
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s16, #640
    v.st.w       [s15, #0], v1
    s.addi       s15, s10, #4800
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s16, #704
    v.st.w       [s13, #0], v1
    s.addi       s13, s10, #4864
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s16, #768
    v.st.w       [s3, #0], v1
    s.addi       s3, s10, #4928
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s16, #832
    v.st.w       [s20, #0], v1
    s.addi       s20, s10, #4992
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s16, #896
    s.addi       s21, s16, #960
    v.st.w       [s17, #0], v1
    s.addi       s16, s10, #5056
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #5120
    v.st.w       [s19, #0], v1
    s.addi       s17, s10, #7168
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s10, #5184
    v.st.w       [s11, #0], v1
    s.addi       s11, s17, #64
    v.ld.w       v1, [s20, #0]
    s.addi       s19, s10, #5248
    v.st.w       [s15, #0], v1
    s.addi       s15, s17, #128
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s10, #5312
    v.st.w       [s21, #0], v1
    fence.acq_rel.device
    s.addi       s20, s17, #192
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #5376
    v.st.w       [s17, #0], v1
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s17, #256
    v.st.w       [s11, #0], v1
    s.addi       s11, s10, #5440
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s17, #320
    v.st.w       [s15, #0], v1
    s.addi       s15, s10, #5504
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s17, #384
    v.st.w       [s20, #0], v1
    s.addi       s20, s10, #5568
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s17, #448
    v.st.w       [s3, #0], v1
    s.addi       s3, s10, #5632
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s17, #512
    v.st.w       [s19, #0], v1
    s.addi       s19, s10, #5696
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s17, #576
    v.st.w       [s16, #0], v1
    s.addi       s16, s10, #5760
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s17, #640
    v.st.w       [s13, #0], v1
    s.addi       s13, s10, #5824
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s17, #704
    v.st.w       [s11, #0], v1
    s.addi       s11, s10, #5888
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s17, #768
    v.st.w       [s15, #0], v1
    s.addi       s15, s10, #5952
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s17, #832
    v.st.w       [s20, #0], v1
    s.addi       s20, s10, #6016
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s17, #896
    s.addi       s21, s17, #960
    v.st.w       [s3, #0], v1
    s.addi       s3, s10, #6080
    v.ld.w       v1, [s11, #0]
    s.movz       s11, #0
    v.st.w       [s19, #0], v1
    s.movz       s17, #0
    v.ld.w       v1, [s15, #0]
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s15, #0
    v.st.w       [s16, #0], v1
    s.movz       s16, #1
    v.ld.w       v1, [s20, #0]
    s.movz       s19, #1
    v.st.w       [s13, #0], v1
    s.movz       s13, #1
    v.ld.w       v1, [s3, #0]
    s.movz       s3, #2
    v.st.w       [s21, #0], v1
    fence.acq_rel.device
    a.vread      v1, a0, s11
    a.vread      v2, a3, s17
    s.movz       s11, #2
    vf.add       v3, v1, v2
    s.movz       s17, #2
    s.movz       s20, #3
    a.vwrite     a4, s15, v3
    a.vread      v1, a0, s16
    a.vread      v2, a3, s19
    s.movz       s15, #3
    vf.add       v3, v1, v2
    s.movz       s16, #3
    s.movz       s19, #4
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s3
    a.vread      v2, a3, s11
    s.movz       s3, #4
    vf.add       v3, v1, v2
    s.movz       s11, #4
    s.movz       s13, #5
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s15
    s.movz       s15, #5
    vf.add       v3, v1, v2
    s.movz       s17, #5
    s.movz       s20, #6
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s3
    s.movz       s3, #6
    vf.add       v3, v1, v2
    s.movz       s16, #6
    s.movz       s19, #7
    a.vwrite     a4, s11, v3
    a.vread      v1, a0, s13
    a.vread      v2, a3, s15
    s.movz       s11, #7
    vf.add       v3, v1, v2
    s.movz       s13, #7
    s.movz       s15, #8
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s3
    s.movz       s3, #8
    vf.add       v3, v1, v2
    s.movz       s17, #8
    s.movz       s20, #9
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s11
    s.movz       s11, #9
    vf.add       v3, v1, v2
    s.movz       s16, #9
    s.movz       s19, #10
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s3
    s.movz       s3, #10
    vf.add       v3, v1, v2
    s.movz       s13, #10
    s.movz       s15, #11
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s11
    s.movz       s11, #11
    vf.add       v3, v1, v2
    s.movz       s17, #11
    s.movz       s20, #12
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s3
    s.movz       s3, #12
    vf.add       v3, v1, v2
    s.movz       s16, #12
    s.movz       s19, #13
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s11
    s.movz       s11, #13
    vf.add       v3, v1, v2
    s.movz       s13, #13
    s.movz       s15, #14
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s3
    s.movz       s3, #14
    vf.add       v3, v1, v2
    s.movz       s17, #14
    s.movz       s20, #15
    a.vwrite     a4, s16, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s11
    s.movz       s11, #15
    vf.add       v3, v1, v2
    s.movz       s16, #15
    s.addi       s19, s10, #6144
    a.vwrite     a4, s13, v3
    a.vread      v1, a0, s15
    a.vread      v2, a3, s3
    s.addi       s3, s10, #2048
    vf.add       v3, v1, v2
    s.addi       s13, s10, #6208
    s.addi       s15, s10, #2112
    a.vwrite     a4, s17, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s11
    s.addi       s11, s10, #6272
    vf.add       v3, v1, v2
    s.addi       s17, s10, #2176
    s.addi       s20, s10, #6336
    a.vwrite     a4, s16, v3
    v.ld.w       v1, [s19, #0]
    s.addi       s16, s10, #2240
    s.addi       s19, s10, #6400
    v.st.w       [s3, #0], v1
    s.addi       s3, s10, #2304
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #6464
    v.st.w       [s15, #0], v1
    s.addi       s15, s10, #2368
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #6528
    v.st.w       [s17, #0], v1
    s.addi       s17, s10, #2432
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #6592
    v.st.w       [s16, #0], v1
    s.addi       s16, s10, #2496
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #6656
    v.st.w       [s3, #0], v1
    s.addi       s3, s10, #2560
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #6720
    v.st.w       [s15, #0], v1
    s.addi       s15, s10, #2624
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #6784
    v.st.w       [s17, #0], v1
    s.addi       s17, s10, #2688
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #6848
    v.st.w       [s16, #0], v1
    s.addi       s16, s10, #2752
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #6912
    v.st.w       [s3, #0], v1
    s.addi       s3, s10, #2816
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #6976
    v.st.w       [s15, #0], v1
    s.addi       s15, s10, #2880
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #7040
    v.st.w       [s17, #0], v1
    s.addi       s17, s10, #2944
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #7104
    v.st.w       [s16, #0], v1
    s.addi       s16, s10, #3008
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #7168
    v.st.w       [s3, #0], v1
    s.addi       s3, s10, #3072
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #7232
    v.st.w       [s15, #0], v1
    s.addi       s15, s10, #3136
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #7296
    v.st.w       [s17, #0], v1
    s.addi       s17, s10, #3200
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #7360
    v.st.w       [s16, #0], v1
    fence.acq_rel.device
    s.addi       s16, s10, #3264
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #7424
    v.st.w       [s3, #0], v1
    s.addi       s3, s10, #3328
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #7488
    v.st.w       [s15, #0], v1
    s.addi       s15, s10, #3392
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #7552
    v.st.w       [s17, #0], v1
    s.addi       s17, s10, #3456
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #7616
    v.st.w       [s16, #0], v1
    s.addi       s16, s10, #3520
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #7680
    v.st.w       [s3, #0], v1
    s.addi       s3, s10, #3584
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #7744
    v.st.w       [s15, #0], v1
    s.addi       s15, s10, #3648
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #7808
    v.st.w       [s17, #0], v1
    s.addi       s17, s10, #3712
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #7872
    v.st.w       [s16, #0], v1
    s.addi       s16, s10, #3776
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s10, #7936
    v.st.w       [s3, #0], v1
    s.addi       s3, s10, #3840
    v.ld.w       v1, [s13, #0]
    s.addi       s13, s10, #8000
    v.st.w       [s15, #0], v1
    s.addi       s15, s10, #3904
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s10, #8064
    v.st.w       [s17, #0], v1
    s.addi       s17, s10, #3968
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s10, #8128
    s.addi       s21, s10, #4032
    v.st.w       [s16, #0], v1
    s.movz       s16, #0
    v.ld.w       v1, [s19, #0]
    s.movz       s19, #0
    v.st.w       [s3, #0], v1
    s.movz       s3, #1
    v.ld.w       v1, [s13, #0]
    s.movz       s13, #1
    v.st.w       [s15, #0], v1
    s.movz       s15, #2
    v.ld.w       v1, [s11, #0]
    s.movz       s11, #2
    v.st.w       [s17, #0], v1
    s.movz       s17, #3
    v.ld.w       v1, [s20, #0]
    s.movz       s20, #3
    v.st.w       [s21, #0], v1
    fence.acq_rel.device
    a.vread      v1, a4, s16
    s.movz       s16, #4
    a.vwrite     a0, s19, v1
    a.vread      v1, a4, s3
    s.movz       s3, #4
    a.vwrite     a0, s13, v1
    a.vread      v1, a4, s15
    s.movz       s13, #5
    a.vwrite     a0, s11, v1
    a.vread      v1, a4, s17
    s.movz       s11, #5
    a.vwrite     a0, s20, v1
    a.vread      v1, a4, s16
    s.movz       s15, #6
    a.vwrite     a0, s3, v1
    a.vread      v1, a4, s13
    s.movz       s3, #6
    a.vwrite     a0, s11, v1
    a.vread      v1, a4, s15
    s.movz       s11, #7
    a.vwrite     a0, s3, v1
    s.movz       s3, #7
    a.vread      v1, a4, s11
    s.movz       s11, #8
    a.vwrite     a0, s3, v1
    s.movz       s3, #8
    a.vread      v1, a4, s11
    s.movz       s11, #9
    a.vwrite     a0, s3, v1
    s.movz       s3, #9
    a.vread      v1, a4, s11
    s.movz       s11, #10
    a.vwrite     a0, s3, v1
    s.movz       s3, #10
    a.vread      v1, a4, s11
    s.movz       s11, #11
    a.vwrite     a0, s3, v1
    s.movz       s3, #11
    a.vread      v1, a4, s11
    s.movz       s11, #12
    a.vwrite     a0, s3, v1
    s.movz       s3, #12
    a.vread      v1, a4, s11
    s.movz       s11, #13
    a.vwrite     a0, s3, v1
    s.movz       s3, #13
    a.vread      v1, a4, s11
    s.movz       s11, #14
    a.vwrite     a0, s3, v1
    s.movz       s3, #14
    a.vread      v1, a4, s11
    s.movz       s11, #15
    a.vwrite     a0, s3, v1
    s.movz       s3, #15
    a.vread      v1, a4, s11
    s.add        s11, s4, s2
    s.movz       s13, #1
    a.vwrite     a0, s3, v1
    s.mov        s4, s11
    br.nz        s13, for_7
endfor_8:
    s.movz       s3, #0
    s.mul        s4, s14, s18
    s.muli       s5, s1, #4                      // a runtime tile origin, x4
    s.movz       s7, #0
    s.add        s9, s3, s1                      // the tile origin
    s.muli       s1, s6, #52                     // a runtime tile origin, x52
    s.add        s3, s7, s6                      // the tile origin
    v.splat      v1, s9
    s.muli       s6, s4, #4                      // a runtime tile origin, x4
    v.splat      v2, s3
    v.splat      v3, s8
    v.add        v4, v0, v1
    v.splat      v0, s8
    s.addi       s4, s3, #1
    s.add        s7, s12, s5                     // the tile origin
    v.splat      v1, s14
    v.splat      v5, s2
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s4
    s.addi       s2, s3, #2
    s.add        s4, s7, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    p.and        p3, p1, p2
    v.cmp.lt     p1, v1, v5
    v.cmp.lt     p4, v0, v3
    v.splat      v0, s2
    s.addi       s2, s3, #3
    s.add        s5, s4, s6                      // the tile origin
    a.vread      v1, a0, s1
    p.and        p5, p3, p1
    s.movz       s1, #1
    p.and        p3, p4, p2
    v.splat      v2, s2
    s.addi       s2, s3, #4
    @p5 v.st.w       [s5, #0], v1
    v.cmp.lt     p4, v0, v3
    a.vread      v0, a0, s1
    s.addi       s1, s5, #52                     // row 1
    p.and        p5, p3, p1
    s.movz       s4, #2
    p.and        p3, p4, p2
    v.splat      v1, s2
    s.addi       s2, s3, #5
    s.addi       s6, s5, #104                    // row 2
    @p5 v.st.w       [s1, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s4
    p.and        p5, p3, p1
    s.movz       s1, #3
    p.and        p3, p4, p2
    v.splat      v2, s2
    s.addi       s2, s3, #6
    s.addi       s4, s5, #156                    // row 3
    p.and        p4, p3, p1
    @p5 v.st.w       [s6, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s1
    s.movz       s1, #4
    p.and        p5, p3, p2
    v.splat      v1, s2
    s.addi       s2, s3, #7
    s.addi       s6, s5, #208                    // row 4
    p.and        p3, p5, p1
    s.movz       s7, #5
    @p4 v.st.w       [s4, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s1
    p.and        p5, p4, p2
    v.splat      v2, s2
    s.addi       s1, s3, #8
    s.addi       s2, s5, #260                    // row 5
    p.and        p4, p5, p1
    s.movz       s4, #6
    v.splat      v4, s1
    @p3 v.st.w       [s6, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s7
    p.and        p5, p3, p2
    s.addi       s1, s3, #9
    s.addi       s6, s5, #312                    // row 6
    p.and        p3, p5, p1
    s.movz       s7, #7
    v.splat      v1, s1
    s.addi       s1, s3, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v2, v3
    a.vread      v0, a0, s4
    p.and        p5, p4, p2
    s.addi       s2, s5, #364                    // row 7
    p.and        p4, p5, p1
    s.movz       s4, #8
    v.splat      v2, s1
    s.addi       s1, s3, #11
    s.addi       s8, s5, #416                    // row 8
    @p3 v.st.w       [s6, #0], v0
    v.cmp.lt     p3, v4, v3
    a.vread      v0, a0, s7
    p.and        p5, p3, p2
    s.movz       s6, #9
    p.and        p3, p5, p1
    v.splat      v4, s1
    s.addi       s1, s3, #12
    s.addi       s7, s5, #468                    // row 9
    s.movz       s9, #10
    @p4 v.st.w       [s2, #0], v0
    v.cmp.lt     p4, v1, v3
    a.vread      v0, a0, s4
    p.and        p5, p4, p2
    v.splat      v1, s1
    p.and        p4, p5, p1
    s.addi       s1, s3, #13
    s.addi       s2, s5, #520                    // row 10
    s.movz       s4, #11
    v.splat      v5, s1
    @p3 v.st.w       [s8, #0], v0
    v.cmp.lt     p3, v2, v3
    a.vread      v0, a0, s6
    p.and        p5, p3, p2
    s.addi       s1, s3, #14
    p.and        p3, p5, p1
    s.addi       s6, s5, #572                    // row 11
    s.movz       s8, #12
    v.splat      v2, s1
    s.addi       s1, s5, #624                    // row 12
    @p4 v.st.w       [s7, #0], v0
    v.cmp.lt     p4, v4, v3
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    s.addi       s7, s3, #15
    p.and        p4, p5, p1
    s.movz       s3, #13
    v.splat      v4, s7
    s.addi       s7, s5, #676                    // row 13
    s.movz       s9, #14
    @p3 v.st.w       [s2, #0], v0
    v.cmp.lt     p3, v1, v3
    a.vread      v0, a0, s4
    p.and        p5, p3, p2
    s.addi       s2, s5, #728                    // row 14
    p.and        p3, p5, p1
    s.movz       s4, #15
    s.addi       s10, s5, #780                   // row 15
    @p4 v.st.w       [s6, #0], v0
    v.cmp.lt     p4, v5, v3
    a.vread      v0, a0, s8
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s1, #0], v0
    v.cmp.lt     p3, v2, v3
    a.vread      v0, a0, s3
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    @p4 v.st.w       [s7, #0], v0
    v.cmp.lt     p4, v4, v3
    a.vread      v0, a0, s9
    p.and        p5, p4, p2
    p.and        p2, p5, p1
    @p3 v.st.w       [s2, #0], v0
    a.vread      v0, a0, s4
    @p2 v.st.w       [s10, #0], v0
__rctx_next:
    exit
