#!/usr/bin/env bash
set -eu
route=$1
export OMP_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES=
export TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip"
export TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg"
export TNCA_TLM_OUT="$HOME/r41_code_cache_${route}_tlm"
if [[ $route == age64 ]]; then export TNCA_CODE_CACHE_POLICY=lfu-sqrt; fi
cd "$HOME/r41_chat_cache_age64_20261031"
exec "$HOME/flux-venv/bin/python" -u tools/r41/chat_speed/bench_code_cache_dp.py --trace /tmp/r41_vl_launches_20261031.json.gz --artifacts "$HOME/r41_vl_reason_dp/whole-triton" --out "$HOME/r41_code_cache_${route}" --rounds 12
