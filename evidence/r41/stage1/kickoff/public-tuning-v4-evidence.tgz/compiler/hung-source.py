import subprocess,time
from pathlib import Path
p=subprocess.Popen(["sleep","60"])
Path('/home/zhongchun/r41-stage1/runs/public-tuning-v4/compiler/descendant.pid').write_text(str(p.pid))
time.sleep(60)
