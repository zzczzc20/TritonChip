# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41_k32_descriptor_v6_113_20261031/runs/op.rope__small__fp16-b1-h4-s64-d32/inductor_cache/qm/cqmjvassxxfbmkcqiarly2w6bztlgevg34wabbm2n7jb4wko23ue.py
# Topologically Sorted Source Nodes: [chunk, neg], Original ATen: [aten.split, aten.neg]
# Source node to ATen node mapping:
#   chunk => split
#   neg => neg
# Graph fragment:
#   %arg0_1 : Tensor "f16[1, 4, 64, 32][8192, 2048, 32, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%arg0_1, 16, -1), kwargs = {})
#   %neg : Tensor "f16[1, 4, 64, 16][4096, 1024, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_1,), kwargs = {})
#   return %neg
triton_poi_fused_neg_split_0 = async_compile.triton('triton_poi_fused_neg_split_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 4096}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_neg_split_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 24576}, 'backend_hash': '28ADB27D450F7DF27718246EA7BFE03CA6F19F076D5C1000FC5B3913D0F86B5A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_neg_split_0(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 4096
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 16)
    x1 = xindex // 16
    tmp0 = tl.load(in_ptr0 + (16 + x0 + 32*x1), None).to(tl.float32)
    tmp1 = -tmp0
    tl.store(out_ptr0 + (x0 + 32*x1), tmp1, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_k32_descriptor_v6_113_20261031/runs/op.rope__small__fp16-b1-h4-s64-d32/inductor_cache/p2/cp2emsgwagw5axwmkuhidxrj4icraxvqwpcoqoqhlz4xfywhhiyg.py
# Topologically Sorted Source Nodes: [chunk, neg, cat], Original ATen: [aten.split, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   cat => cat
#   chunk => split
#   neg => neg
# Graph fragment:
#   %arg0_1 : Tensor "f16[1, 4, 64, 32][8192, 2048, 32, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%arg0_1, 16, -1), kwargs = {})
#   %neg : Tensor "f16[1, 4, 64, 16][4096, 1024, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_1,), kwargs = {})
#   %cat : Tensor "f16[1, 4, 64, 32][8192, 2048, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %getitem], -1), kwargs = {})
#   return %buf1
triton_poi_fused_cat_neg_split_1 = async_compile.triton('triton_poi_fused_cat_neg_split_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 4096}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_cat_neg_split_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 24576}, 'backend_hash': '28ADB27D450F7DF27718246EA7BFE03CA6F19F076D5C1000FC5B3913D0F86B5A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_neg_split_1(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 4096
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 16)
    x1 = xindex // 16
    tmp0 = tl.load(in_ptr0 + (x0 + 32*x1), None).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 32*x1), tmp0, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41_k32_descriptor_v6_113_20261031/runs/op.rope__small__fp16-b1-h4-s64-d32/inductor_cache/ln/clnkd24z74xcobtuj6wajsnc4luzglq65e6dncy4a6gybfd5ch2w.py
# Topologically Sorted Source Nodes: [mul, mul_1, add], Original ATen: [aten.mul, aten.add]
# Source node to ATen node mapping:
#   add => add
#   mul => mul
#   mul_1 => mul_1
# Graph fragment:
#   %arg0_1 : Tensor "f16[1, 4, 64, 32][8192, 2048, 32, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "f16[64, 32][32, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %cat : Tensor "f16[1, 4, 64, 32][8192, 2048, 32, 1]tnca:0" = PlaceHolder[target=cat]
#   %arg2_1 : Tensor "f16[64, 32][32, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %mul : Tensor "f16[1, 4, 64, 32][8192, 2048, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg0_1, %arg1_1), kwargs = {})
#   %mul_1 : Tensor "f16[1, 4, 64, 32][8192, 2048, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %arg2_1), kwargs = {})
#   %add : Tensor "f16[1, 4, 64, 32][8192, 2048, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul, %mul_1), kwargs = {})
#   return %add
triton_poi_fused_add_mul_2 = async_compile.triton('triton_poi_fused_add_mul_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_mul_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 73728}, 'backend_hash': '28ADB27D450F7DF27718246EA7BFE03CA6F19F076D5C1000FC5B3913D0F86B5A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_mul_2(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex
    x0 = (xindex % 2048)
    tmp0 = tl.load(in_ptr0 + (x2), None).to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x2), None).to(tl.float32)
    tmp4 = tl.load(in_ptr3 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp2 = tmp0 * tmp1
    tmp5 = tmp3 * tmp4
    tmp6 = tmp2 + tmp5
    tl.store(out_ptr0 + (x2), tmp6, None)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1 = args
        args.clear()
        assert_size_stride(arg0_1, (1, 4, 64, 32), (8192, 2048, 32, 1), 'input')
        buf2 = empty_strided((1, 4, 64, 32), (8192, 2048, 32, 1), device='tnca', dtype=torch.float16)
        buf0 = reinterpret_tensor(buf2, (1, 4, 64, 16), (8192, 2048, 32, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [chunk, neg], Original ATen: [aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_neg_split_0.run(arg0_1, buf0, 4096, stream=raw_stream0)
        buf1 = reinterpret_tensor(buf2, (1, 4, 64, 16), (8192, 2048, 32, 1), 16)  # alias
        # Topologically Sorted Source Nodes: [chunk, neg, cat], Original ATen: [aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_neg_split_1.run(arg0_1, buf1, 4096, stream=raw_stream0)
        assert_size_stride_grouped((arg1_1, arg2_1), ((64, 32), (64, 32)), ((32, 1), (32, 1)), 'input')
        buf3 = empty_strided((1, 4, 64, 32), (8192, 2048, 32, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [mul, mul_1, add], Original ATen: [aten.mul, aten.add]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_add_mul_2.run(arg0_1, arg1_1, buf2, arg2_1, buf3, 8192, stream=raw_stream0)
        del arg0_1
        del arg1_1
        del arg2_1
        return (buf3, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 4, 64, 32), (8192, 2048, 32, 1), device='tnca:0', dtype=torch.float16)
    arg1_1 = rand_strided((64, 32), (32, 1), device='tnca:0', dtype=torch.float16)
    arg2_1 = rand_strided((64, 32), (32, 1), device='tnca:0', dtype=torch.float16)
    return [arg0_1, arg1_1, arg2_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
