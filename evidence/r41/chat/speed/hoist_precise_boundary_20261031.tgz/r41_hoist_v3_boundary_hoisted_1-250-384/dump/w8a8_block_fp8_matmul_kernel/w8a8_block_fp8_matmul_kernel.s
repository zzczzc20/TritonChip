    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #40]                   // N: i32 at arg_base+40
    s.movz       s4, #0
    s.movz       s5, #128
    s.rdspecial  s6, pid.x
    s.cmp.lt     s7, s5, s4
    s.movz       s8, #8
    s.sub        s9, s4, s7
    s.rdspecial  s7, pid.y
    s.movz       s10, #1
    s.xor        s11, s5, s9
    s.addi       s12, s4, #0
    s.add        s13, s3, s2
    s.ld.d       s14, [s1, #0]                   // A: device_ptr64 at arg_base+0
    s.cmp.lt     s15, s13, s4
    s.sub        s16, s11, s9
    s.sub        s11, s4, s15
    s.addi       s15, s4, #0
    s.xor        s16, s13, s11
    s.xor        s13, s11, s9
    s.sub        s9, s16, s11
    s.lshri      s11, s9, #7
    s.xor        s16, s11, s13
    s.muli       s17, s11, #128
    s.sub        s11, s16, s13
    s.ld.d       s13, [s1, #8]                   // B: device_ptr64 at arg_base+8
    s.mul        s16, s6, s11
    s.mul        s6, s11, s8
    s.sub        s11, s9, s17
    s.add        s9, s16, s7
    s.cmp.lt     s7, s6, s4
    s.cmp.lt     s11, s9, s4
    s.sub        s16, s4, s7
    s.sub        s7, s4, s11
    s.xor        s11, s6, s16
    s.xor        s17, s9, s7
    s.sub        s18, s11, s16
    s.sub        s11, s17, s7
    s.cmp.eq     s17, s18, s10
    s.ld.d       s19, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.ld.d       s20, [s1, #24]                  // As: device_ptr64 at arg_base+24
    s.ld.d       s21, [s1, #32]                  // Bs: device_ptr64 at arg_base+32
    s.ld.sw      s22, [s1, #48]                  // K: i32 at arg_base+48
    s.ld.sw      s23, [s1, #64]                  // stride_bn: i32 at arg_base+64
    s.ld.sw      s24, [s1, #72]                  // stride_cm: i32 at arg_base+72
    s.ld.sw      s25, [s1, #88]                  // stride_bs_n: i32 at arg_base+88
    s.mov        s12, s11
    br.nz        s17, sdiv_done_1
    s.movz       s1, #0
    s.movz       s17, #31
    s.mov        s12, s1
    s.addi       s1, s17, #0
sdiv_2:
    s.lshr       s17, s11, s1
    s.shli       s26, s15, #1
    s.andi       s27, s17, #1
    s.shl        s17, s10, s1
    s.or         s28, s26, s27
    s.subi       s26, s1, #1
    s.cmp.geu    s27, s28, s18
    s.sub        s29, s4, s27
    s.and        s27, s18, s29
    s.and        s30, s17, s29
    s.sub        s17, s28, s27
    s.or         s27, s12, s30
    s.mov        s15, s17
    s.mov        s12, s27
    s.mov        s1, s26
    s.cmp.ge     s17, s1, s4
    br.nz        s17, sdiv_2
sdiv_done_1:
    s.xor        s1, s7, s16
    s.movz       s4, #0
    s.xor        s7, s12, s1
    s.cmp.lt     s11, s6, s4
    s.sub        s12, s7, s1
    s.cmp.lt     s1, s9, s4
    s.sub        s7, s4, s11
    s.mul        s11, s12, s8
    s.sub        s12, s4, s1
    s.xor        s1, s6, s7
    s.xor        s6, s9, s12
    s.sub        s9, s1, s7
    s.sub        s1, s10, s11
    s.sub        s7, s6, s12
    s.addi       s6, s4, #0
    s.cmp.eq     s15, s9, s10
    s.min.s      s16, s1, s8
    s.addi       s1, s4, #0
    s.mov        s6, s7
    br.nz        s15, sdiv_done_3
    s.movz       s8, #0
    s.movz       s15, #31
    s.mov        s6, s8
    s.addi       s8, s15, #0
sdiv_4:
    s.lshr       s15, s7, s8
    s.shli       s17, s1, #1
    s.andi       s18, s15, #1
    s.movz       s15, #1
    s.or         s26, s17, s18
    s.shl        s17, s15, s8
    s.cmp.geu    s15, s26, s9
    s.subi       s18, s8, #1
    s.sub        s27, s4, s15
    s.and        s15, s9, s27
    s.and        s28, s17, s27
    s.sub        s17, s26, s15
    s.or         s15, s6, s28
    s.mov        s1, s17
    s.mov        s6, s15
    s.mov        s8, s18
    s.cmp.ge     s15, s8, s4
    br.nz        s15, sdiv_4
sdiv_done_3:
    s.xor        s6, s1, s12
    s.cmp.lt     s1, s16, s4
    s.sub        s7, s6, s12
    s.sub        s6, s4, s1
    s.cmp.lt     s1, s7, s4
    s.xor        s8, s16, s6
    s.sub        s9, s4, s1
    s.sub        s1, s8, s6
    s.xor        s6, s7, s9
    s.movz       s8, #1
    s.sub        s12, s6, s9
    s.addi       s6, s4, #0
    s.cmp.eq     s15, s1, s8
    s.addi       s17, s4, #0
    s.mov        s6, s12
    br.nz        s15, sdiv_done_5
    s.movz       s4, #0
    s.movz       s15, #31
    s.mov        s6, s4
    s.addi       s4, s15, #0
sdiv_6:
    s.lshr       s15, s12, s4
    s.shli       s18, s17, #1
    s.andi       s26, s15, #1
    s.movz       s15, #0
    s.or         s27, s18, s26
    s.shl        s18, s8, s4
    s.cmp.geu    s26, s27, s1
    s.subi       s28, s4, #1
    s.sub        s29, s15, s26
    s.and        s26, s1, s29
    s.and        s30, s18, s29
    s.sub        s18, s27, s26
    s.or         s26, s6, s30
    s.mov        s17, s18
    s.mov        s6, s26
    s.mov        s4, s28
    s.cmp.ge     s18, s4, s15
    br.nz        s18, sdiv_6
sdiv_done_5:
    s.movz       s1, #0
    s.xor        s4, s17, s9
    s.cmp.lt     s6, s16, s1
    s.cmp.lt     s12, s7, s1
    s.sub        s15, s1, s6
    s.sub        s6, s1, s12
    s.xor        s12, s16, s15
    s.xor        s16, s7, s6
    s.sub        s7, s12, s15
    s.sub        s12, s4, s9
    s.sub        s4, s16, s6
    s.addi       s9, s1, #0
    s.cmp.eq     s16, s7, s8
    s.add        s8, s11, s12
    s.addi       s11, s1, #0
    s.mov        s9, s4
    br.nz        s16, sdiv_done_7
    s.movz       s12, #0
    s.movz       s16, #31
    s.mov        s9, s12
    s.addi       s12, s16, #0
sdiv_8:
    s.lshr       s16, s4, s12
    s.shli       s17, s11, #1
    s.andi       s18, s16, #1
    s.movz       s16, #1
    s.or         s26, s17, s18
    s.shl        s17, s16, s12
    s.cmp.geu    s16, s26, s7
    s.subi       s18, s12, #1
    s.sub        s27, s1, s16
    s.and        s16, s7, s27
    s.and        s28, s17, s27
    s.sub        s17, s26, s16
    s.or         s16, s9, s28
    s.mov        s11, s17
    s.mov        s9, s16
    s.mov        s12, s18
    s.cmp.ge     s16, s12, s1
    br.nz        s16, sdiv_8
sdiv_done_7:
    s.xor        s1, s6, s15
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s4, s9, s1
    v.movi       v1, #16
    s.sub        s6, s4, s1
    v.movi       v2, #32
    s.mul        s1, s6, s5
    v.movi       v3, #48
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #64
    v.movi       v6, #80
    v.splat      v7, s1
    v.movi       v8, #96
    v.iota       v9                              // arange(0, VLEN)
    v.movi       v10, #112
    v.add        v11, v7, v0
    v.splat      v12, s3
    v.movi       v13, #0
    v.add        v14, v0, v1
    v.add        v1, v0, v2
    v.add        v2, v0, v3
    v.add        v0, v4, v5
    v.add        v3, v4, v6
    v.add        v5, v4, v8
    v.add        v4, v9, v10
    v.sub        v6, v13, v11
    v.sub        v8, v13, v12
    v.cmp.lt     p1, v11, v13
    v.cmp.lt     p2, v12, v13
    v.add        v9, v7, v14
    v.add        v10, v7, v1
    v.add        v1, v7, v2
    v.add        v2, v7, v0
    v.add        v0, v7, v3
    v.add        v3, v7, v5
    v.add        v5, v7, v4
    v.movi       v4, #1
    @p1 v.sel        v7, v6, v11
    @p2 v.sel        v6, v8, v12
    v.movi       v8, #0
    v.movi       v11, #0
    s.movz       s4, #31
idiv_9:
    v.splat      v14, s4
    v.shl        v15, v11, v4
    v.cmp.lt     p2, v11, v13
    v.lshr       v16, v7, v14
    v.shl        v17, v4, v14
    s.subi       s6, s4, #1
    v.and        v14, v16, v4
    s.movz       s7, #0
    v.or         v16, v15, v14
    v.cmp.geu    p3, v16, v6
    p.or         p4, p2, p3
    v.sub        v14, v16, v6
    @p4 v.sel        v15, v17, v13
    @p4 v.sel        v17, v14, v16
    v.or         v14, v8, v15
    v.mov        v11, v17
    v.mov        v8, v14
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_9
    v.movi       v4, #0
    v.sub        v6, v13, v11
    v.movi       v7, #1
    v.sub        v8, v4, v9
    v.sub        v13, v4, v12
    v.cmp.lt     p2, v9, v4
    v.cmp.lt     p3, v12, v4
    @p1 v.sel        v14, v6, v11
    @p2 v.sel        v6, v8, v9
    @p3 v.sel        v8, v13, v12
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s4, #31
idiv_10:
    v.splat      v13, s4
    v.shl        v15, v11, v7
    v.cmp.lt     p1, v11, v4
    v.lshr       v16, v6, v13
    v.shl        v17, v7, v13
    s.subi       s6, s4, #1
    v.and        v13, v16, v7
    v.or         v16, v15, v13
    v.cmp.geu    p3, v16, v8
    p.or         p4, p1, p3
    v.sub        v13, v16, v8
    @p4 v.sel        v15, v17, v4
    @p4 v.sel        v17, v13, v16
    v.or         v13, v9, v15
    v.mov        v11, v17
    v.mov        v9, v13
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_10
    v.movi       v6, #0
    v.sub        v7, v4, v11
    v.movi       v4, #1
    v.sub        v8, v6, v10
    v.sub        v9, v6, v12
    v.cmp.lt     p1, v10, v6
    v.cmp.lt     p3, v12, v6
    @p2 v.sel        v13, v7, v11
    @p1 v.sel        v7, v8, v10
    @p3 v.sel        v8, v9, v12
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s4, #31
idiv_11:
    v.splat      v11, s4
    v.shl        v15, v10, v4
    v.cmp.lt     p2, v10, v6
    v.lshr       v16, v7, v11
    v.shl        v17, v4, v11
    s.subi       s6, s4, #1
    v.and        v11, v16, v4
    s.movz       s7, #0
    v.or         v16, v15, v11
    v.cmp.geu    p3, v16, v8
    p.or         p4, p2, p3
    v.sub        v11, v16, v8
    @p4 v.sel        v15, v17, v6
    @p4 v.sel        v17, v11, v16
    v.or         v11, v9, v15
    v.mov        v10, v17
    v.mov        v9, v11
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_11
    v.movi       v4, #0
    v.sub        v7, v6, v10
    v.movi       v6, #1
    v.sub        v8, v4, v1
    v.sub        v9, v4, v12
    v.cmp.lt     p2, v1, v4
    v.cmp.lt     p3, v12, v4
    @p1 v.sel        v11, v7, v10
    @p2 v.sel        v7, v8, v1
    @p3 v.sel        v1, v9, v12
    v.movi       v8, #0
    v.movi       v9, #0
    s.movz       s4, #31
idiv_12:
    v.splat      v10, s4
    v.shl        v15, v9, v6
    v.cmp.lt     p1, v9, v4
    v.lshr       v16, v7, v10
    v.shl        v17, v6, v10
    s.subi       s6, s4, #1
    v.and        v10, v16, v6
    v.or         v16, v15, v10
    v.cmp.geu    p3, v16, v1
    p.or         p4, p1, p3
    v.sub        v10, v16, v1
    @p4 v.sel        v15, v17, v4
    @p4 v.sel        v17, v10, v16
    v.or         v10, v8, v15
    v.mov        v9, v17
    v.mov        v8, v10
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_12
    v.movi       v1, #0
    v.sub        v6, v4, v9
    v.movi       v4, #1
    v.sub        v7, v1, v2
    v.sub        v8, v1, v12
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p3, v12, v1
    @p2 v.sel        v10, v6, v9
    @p1 v.sel        v6, v7, v2
    @p3 v.sel        v2, v8, v12
    v.movi       v7, #0
    v.movi       v8, #0
    s.movz       s4, #31
idiv_13:
    v.splat      v9, s4
    v.shl        v15, v8, v4
    v.cmp.lt     p2, v8, v1
    v.lshr       v16, v6, v9
    v.shl        v17, v4, v9
    s.subi       s6, s4, #1
    v.and        v9, v16, v4
    s.movz       s7, #0
    v.or         v16, v15, v9
    v.cmp.geu    p3, v16, v2
    p.or         p4, p2, p3
    v.sub        v9, v16, v2
    @p4 v.sel        v15, v17, v1
    @p4 v.sel        v17, v9, v16
    v.or         v9, v7, v15
    v.mov        v8, v17
    v.mov        v7, v9
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_13
    v.movi       v2, #0
    v.sub        v4, v1, v8
    v.movi       v1, #1
    v.sub        v6, v2, v0
    v.sub        v7, v2, v12
    v.cmp.lt     p2, v0, v2
    v.cmp.lt     p3, v12, v2
    @p1 v.sel        v9, v4, v8
    @p2 v.sel        v4, v6, v0
    @p3 v.sel        v0, v7, v12
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s4, #31
idiv_14:
    v.splat      v8, s4
    v.shl        v15, v7, v1
    v.cmp.lt     p1, v7, v2
    v.lshr       v16, v4, v8
    v.shl        v17, v1, v8
    s.subi       s6, s4, #1
    v.and        v8, v16, v1
    v.or         v16, v15, v8
    v.cmp.geu    p3, v16, v0
    p.or         p4, p1, p3
    v.sub        v8, v16, v0
    @p4 v.sel        v15, v17, v2
    @p4 v.sel        v17, v8, v16
    v.or         v8, v6, v15
    v.mov        v7, v17
    v.mov        v6, v8
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_14
    v.movi       v0, #0
    v.sub        v1, v2, v7
    v.movi       v2, #1
    v.sub        v4, v0, v3
    v.sub        v6, v0, v12
    v.cmp.lt     p1, v3, v0
    v.cmp.lt     p3, v12, v0
    @p2 v.sel        v8, v1, v7
    @p1 v.sel        v1, v4, v3
    @p3 v.sel        v3, v6, v12
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s4, #31
idiv_15:
    v.splat      v7, s4
    v.shl        v15, v6, v2
    v.cmp.lt     p2, v6, v0
    v.lshr       v16, v1, v7
    v.shl        v17, v2, v7
    s.subi       s6, s4, #1
    v.and        v7, v16, v2
    s.movz       s7, #0
    v.or         v16, v15, v7
    v.cmp.geu    p3, v16, v3
    p.or         p4, p2, p3
    v.sub        v7, v16, v3
    @p4 v.sel        v15, v17, v0
    @p4 v.sel        v17, v7, v16
    v.or         v7, v4, v15
    v.mov        v6, v17
    v.mov        v4, v7
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_15
    v.movi       v1, #0
    v.sub        v2, v0, v6
    v.movi       v0, #1
    v.sub        v3, v1, v5
    v.sub        v4, v1, v12
    v.cmp.lt     p2, v5, v1
    v.cmp.lt     p3, v12, v1
    @p1 v.sel        v7, v2, v6
    @p2 v.sel        v2, v3, v5
    @p3 v.sel        v3, v4, v12
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s4, #31
idiv_16:
    v.splat      v6, s4
    v.shl        v12, v5, v0
    v.cmp.lt     p1, v5, v1
    v.lshr       v15, v2, v6
    v.shl        v16, v0, v6
    s.subi       s6, s4, #1
    v.and        v6, v15, v0
    v.or         v15, v12, v6
    v.cmp.geu    p3, v15, v3
    p.or         p4, p1, p3
    v.sub        v6, v15, v3
    @p4 v.sel        v12, v16, v1
    @p4 v.sel        v16, v6, v15
    v.or         v6, v4, v12
    v.mov        v5, v16
    v.mov        v4, v6
    s.mov        s4, s6
    s.cmp.ge     s6, s4, s7
    br.nz        s6, idiv_16
    v.sub        v0, v1, v5
    v.movi       v1, #0
    v.movi       v2, #0
    @p2 v.sel        v3, v0, v5
    v.movi       v0, #0
    v.movi       v4, #0
    v.sub        v5, v1, v14
    v.sub        v6, v2, v13
    v.sub        v12, v0, v11
    v.cmp.lt     p1, v14, v1
    v.cmp.lt     p2, v13, v2
    v.cmp.lt     p3, v11, v0
    @p1 v.sel        v15, v5, v14
    v.movi       v5, #7
    @p2 v.sel        v16, v6, v13
    v.movi       v6, #7
    @p3 v.sel        v17, v12, v11
    v.movi       v12, #7
    v.lshr       v18, v15, v5
    v.lshr       v5, v16, v6
    v.lshr       v6, v17, v12
    v.movi       v12, #128
    v.sub        v15, v1, v18
    v.movi       v16, #128
    v.sub        v17, v2, v5
    v.movi       v19, #128
    v.sub        v20, v0, v6
    v.movi       v21, #128
    v.sub        v22, v1, v12
    @p1 v.sel        v23, v15, v18
    v.sub        v15, v2, v16
    @p2 v.sel        v18, v17, v5
    v.sub        v5, v0, v19
    @p3 v.sel        v17, v20, v6
    v.cmp.lt     p1, v12, v1
    v.cmp.lt     p2, v16, v2
    v.cmp.lt     p3, v19, v0
    s.movz       s4, #16
    s.movz       s6, #32
    s.movz       s7, #48
    s.movz       s9, #64
    v.sub        v0, v4, v10
    s.movz       s11, #80
    s.movz       s12, #96
    v.sub        v1, v4, v21
    s.movz       s15, #112
    v.movi       v2, #7
    v.movi       v6, #1
    v.movi       v6, #0
    @p1 v.sel        v20, v22, v12
    v.cmp.lt     p1, v10, v4
    v.sub        v12, v6, v9
    @p1 v.sel        v20, v0, v10
    v.movi       v0, #7
    v.movi       v22, #1
    v.lshr       v22, v20, v2
    v.movi       v2, #0
    @p2 v.sel        v20, v15, v16
    v.cmp.lt     p2, v9, v6
    v.sub        v15, v2, v8
    @p2 v.sel        v16, v12, v9
    v.movi       v12, #7
    v.movi       v20, #1
    v.lshr       v20, v16, v0
    v.movi       v0, #0
    @p3 v.sel        v16, v5, v19
    v.cmp.lt     p3, v8, v2
    v.sub        v5, v0, v7
    @p3 v.sel        v16, v15, v8
    v.movi       v15, #7
    v.movi       v19, #1
    v.lshr       v19, v16, v12
    v.sub        v12, v4, v22
    v.movi       v16, #1
    v.movi       v16, #1
    @p1 v.sel        v16, v12, v22
    v.cmp.lt     p1, v7, v0
    @p1 v.sel        v12, v5, v7
    v.movi       v5, #128
    v.movi       v22, #1
    v.lshr       v22, v12, v15
    v.sub        v12, v6, v20
    @p2 v.sel        v15, v12, v20
    v.movi       v12, #128
    v.cmp.lt     p2, v21, v4
    v.movi       v4, #0
    @p2 v.sel        v20, v1, v21
    v.movi       v1, #7
    v.sub        v20, v4, v3
    v.cmp.lt     p2, v3, v4
    v.movi       v21, #1
    @p2 v.sel        v21, v20, v3
    v.lshr       v20, v21, v1
    v.sub        v1, v2, v19
    @p3 v.sel        v21, v1, v19
    v.movi       v1, #128
    v.cmp.lt     p3, v5, v6
    v.sub        v19, v6, v5
    @p3 v.sel        v6, v19, v5
    s.add        s16, s22, s2
    s.movz       s2, #0
    v.sub        v5, v0, v22
    s.cmp.lt     s17, s16, s2
    v.movi       v6, #128
    s.sub        s18, s2, s17
    @p1 v.sel        v19, v5, v22
    v.sub        v5, v4, v20
    v.cmp.lt     p1, v12, v2
    s.xor        s17, s16, s18
    s.cmp.lt     s16, s5, s2
    v.sub        v22, v2, v12
    s.sub        s26, s17, s18
    s.sub        s17, s2, s16
    @p2 v.sel        v2, v5, v20
    v.sub        v5, v0, v1
    v.cmp.lt     p2, v1, v0
    v.sub        v0, v4, v6
    v.cmp.lt     p3, v6, v4
    v.splat      v4, s25
    @p1 v.sel        v20, v22, v12
    s.lshri      s16, s26, #7
    s.xor        s25, s18, s17
    s.muli       s18, s16, #128
    s.xor        s27, s5, s17
    s.xor        s28, s16, s25
    @p2 v.sel        v12, v5, v1
    @p3 v.sel        v1, v0, v6
    v.mul        v0, v23, v4
    v.mul        v1, v18, v4
    v.mul        v5, v17, v4
    v.mul        v6, v16, v4
    v.mul        v12, v15, v4
    v.mul        v15, v21, v4
    v.mul        v16, v19, v4
    v.mul        v17, v2, v4
    s.sub        s16, s27, s17
    s.sub        s16, s26, s18
    s.sub        s16, s28, s25
    s.addi       s17, s2, #0
    s.addi       s18, s2, #0
    s.addi       s25, s2, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_17:
    s.cmp.ge     s26, s17, s16
    br.nz        s26, endfor_18
    s.mul        s26, s17, s5
    s.sub        s27, s22, s26
    s.add        s26, s14, s18
    v.iota       v2                              // arange(0, VLEN)
    s.add        s28, s2, s27                    // the tile origin
    v.splat      v4, s28
    v.cmp.lt     p1, v2, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v4, [s26, #0]
    s.rdspecial  s26, arg_base
    s.ld.d       s29, [s26, #96]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s26, s29, #0
    v.st.w       [s26, #0], v4
    fence.acq_rel.device
    s.addi       s26, s18, #16
    s.add        s30, s14, s26
    s.add        s26, s2, s4                     // the tile origin
    v.splat      v4, s26
    v.add        v18, v2, v4
    v.splat      v4, s28
    v.cmp.lt     p1, v18, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v4, [s30, #0]
    s.addi       s26, s29, #64
    v.st.w       [s26, #0], v4
    fence.acq_rel.device
    s.addi       s26, s18, #32
    s.add        s28, s14, s26
    s.movz       s26, #0
    s.add        s30, s26, s6                    // the tile origin
    v.splat      v4, s30
    v.add        v18, v2, v4
    s.add        s30, s26, s27                   // the tile origin
    v.splat      v4, s30
    v.cmp.lt     p1, v18, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v4, [s28, #0]
    s.addi       s28, s29, #128
    v.st.w       [s28, #0], v4
    fence.acq_rel.device
    s.addi       s28, s18, #48
    s.add        s31, s14, s28
    s.add        s28, s26, s7                    // the tile origin
    v.splat      v4, s28
    v.add        v18, v2, v4
    v.splat      v4, s30
    v.cmp.lt     p1, v18, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v4, [s31, #0]
    s.addi       s28, s29, #192
    v.st.w       [s28, #0], v4
    fence.acq_rel.device
    s.addi       s28, s18, #64
    s.add        s31, s14, s28
    s.add        s28, s26, s9                    // the tile origin
    v.splat      v4, s28
    v.add        v18, v2, v4
    v.splat      v4, s30
    v.cmp.lt     p1, v18, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v4, [s31, #0]
    s.addi       s28, s29, #256
    v.st.w       [s28, #0], v4
    fence.acq_rel.device
    s.addi       s28, s18, #80
    s.add        s31, s14, s28
    s.add        s28, s26, s11                   // the tile origin
    v.splat      v4, s28
    v.add        v18, v2, v4
    v.splat      v4, s30
    v.cmp.lt     p1, v18, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v4, [s31, #0]
    s.addi       s28, s29, #320
    v.st.w       [s28, #0], v4
    fence.acq_rel.device
    s.addi       s28, s18, #96
    s.add        s31, s14, s28
    s.add        s28, s26, s12                   // the tile origin
    v.splat      v4, s28
    v.add        v18, v2, v4
    v.splat      v4, s30
    v.cmp.lt     p1, v18, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v4, [s31, #0]
    s.addi       s26, s29, #384
    v.st.w       [s26, #0], v4
    fence.acq_rel.device
    s.addi       s26, s18, #112
    s.add        s28, s14, s26
    s.movz       s26, #0
    s.add        s30, s26, s15                   // the tile origin
    v.splat      v4, s30
    v.add        v18, v2, v4
    s.add        s30, s26, s27                   // the tile origin
    v.splat      v2, s30
    v.cmp.lt     p1, v18, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s28, #0]
    s.addi       s26, s29, #448
    v.st.w       [s26, #0], v2
    fence.acq_rel.device
    v.splat      v2, s23
    v.mul        v4, v14, v2
    v.mul        v18, v13, v2
    v.mul        v19, v11, v2
    v.mul        v20, v10, v2
    v.mul        v21, v9, v2
    v.splat      v2, s23
    v.mul        v22, v8, v2
    v.mul        v23, v7, v2
    v.mul        v24, v3, v2
    v.splat      v2, s17
    s.shli       s26, s17, #2                    // element offset -> bytes (x4)
    s.add        s28, s20, s26                   // &As[...]
    s.ld.w       s30, [s28, #0]                  // one element, broadcast to every lane
    v.splat      v2, s30
    v.splat      v25, s17
    v.splat      v25, s17
    v.splat      v25, s17
    v.splat      v25, s17
    v.splat      v25, s17
    v.splat      v25, s17
    v.splat      v25, s17
    v.splat      v25, s17
    s.add        s28, s21, s26                   // &Bs[...]
    v.ld.gather.w v25, [s28, v0]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v26, [s28, v1]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v27, [s28, v5]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v28, [s28, v6]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v29, [s28, v12]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v30, [s28, v15]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v31, [s28, v16]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v32, [s28, v17]                // index is in elements (ISA sec 9.1)
    s.add        s26, s2, s27
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.addi       s27, s29, #512
    v.st.w       [s27, #0], v4
    s.addi       s27, s29, #576
    v.st.w       [s27, #0], v18
    s.addi       s27, s29, #640
    v.st.w       [s27, #0], v19
    s.addi       s27, s29, #704
    v.st.w       [s27, #0], v20
    s.addi       s27, s29, #768
    v.st.w       [s27, #0], v21
    s.addi       s27, s29, #832
    v.st.w       [s27, #0], v22
    s.addi       s27, s29, #896
    v.st.w       [s27, #0], v23
    s.addi       s27, s29, #960
    v.st.w       [s27, #0], v24
    fence.acq_rel.device
    v.movi       v4, #0
    v.movi       v18, #0
    v.iota       v19                             // arange(0, VLEN)
    s.movz       s27, #0
    s.cmp.ge     s28, s26, s27
    v.extract    s30, v14, #0
    v.splat      v20, s30
    v.add        v21, v20, v19
    v.sub        v20, v14, v21
    v.reduce.or  s31, v20
    s.cmp.eq     s32, s31, s27
    s.cmp.ge     s31, s30, s27
    s.and        s33, s32, s31
    s.and        s31, s33, s28
    v.insert     v4, s31, #0
    v.insert     v18, s30, #0
    v.extract    s30, v13, #0
    v.splat      v20, s30
    v.add        v21, v20, v19
    v.sub        v20, v13, v21
    v.reduce.or  s31, v20
    s.cmp.eq     s32, s31, s27
    s.cmp.ge     s31, s30, s27
    s.and        s33, s32, s31
    s.and        s31, s33, s28
    v.insert     v4, s31, #1
    v.insert     v18, s30, #1
    v.extract    s30, v11, #0
    v.splat      v20, s30
    v.add        v21, v20, v19
    v.sub        v20, v11, v21
    v.reduce.or  s31, v20
    s.cmp.eq     s32, s31, s27
    s.cmp.ge     s31, s30, s27
    s.and        s33, s32, s31
    s.and        s31, s33, s28
    v.insert     v4, s31, #2
    v.insert     v18, s30, #2
    v.extract    s30, v10, #0
    v.splat      v20, s30
    v.add        v21, v20, v19
    v.sub        v20, v10, v21
    v.reduce.or  s31, v20
    s.cmp.eq     s32, s31, s27
    s.cmp.ge     s31, s30, s27
    s.and        s33, s32, s31
    s.and        s31, s33, s28
    v.insert     v4, s31, #3
    v.insert     v18, s30, #3
    v.extract    s30, v9, #0
    v.splat      v20, s30
    v.add        v21, v20, v19
    v.sub        v20, v9, v21
    v.reduce.or  s31, v20
    s.cmp.eq     s32, s31, s27
    s.cmp.ge     s31, s30, s27
    s.and        s27, s32, s31
    s.and        s31, s27, s28
    v.insert     v4, s31, #4
    v.insert     v18, s30, #4
    v.extract    s27, v8, #0
    v.splat      v20, s27
    v.add        v21, v20, v19
    v.sub        v20, v8, v21
    v.reduce.or  s30, v20
    s.movz       s31, #0
    s.cmp.eq     s32, s30, s31
    s.cmp.ge     s30, s27, s31
    s.and        s33, s32, s30
    s.and        s30, s33, s28
    v.insert     v4, s30, #5
    v.insert     v18, s27, #5
    v.extract    s27, v7, #0
    v.splat      v20, s27
    v.add        v21, v20, v19
    v.sub        v20, v7, v21
    v.reduce.or  s30, v20
    s.cmp.eq     s32, s30, s31
    s.cmp.ge     s30, s27, s31
    s.and        s33, s32, s30
    s.and        s30, s33, s28
    v.insert     v4, s30, #6
    v.insert     v18, s27, #6
    v.extract    s27, v3, #0
    v.splat      v20, s27
    v.add        v21, v20, v19
    v.sub        v19, v3, v21
    v.reduce.or  s30, v19
    s.cmp.eq     s32, s30, s31
    s.cmp.ge     s30, s27, s31
    s.and        s31, s32, s30
    s.and        s30, s31, s28
    v.insert     v4, s30, #7
    v.insert     v18, s27, #7
    s.add        s27, s13, s25
    s.addi       s28, s29, #1024                 // TensorMap 0: W's rows for a transposed FP8 B
    s.st.d       [s28, #0], s27
    .li       s27, #2147483647
    s.st.d       [s28, #8], s27
    s.st.d       [s28, #16], s26
    s.st.d       [s28, #48], s23
    s.movz       s27, #1
    s.st.d       [s28, #56], s27
    .li       s30, #137438953488
    s.st.d       [s28, #88], s30
    .li       s30, #7705171329024
    s.st.d       [s28, #104], s30
    fence.release.device
    td.load      d0, [s28]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s28, s29, #1280
    s.addi       s31, s29, #2304                 // TensorMap 1: the gathered fallback B tile
    s.st.d       [s31, #0], s28
    s.movz       s32, #32
    s.st.d       [s31, #8], s32
    s.movz       s33, #16
    s.st.d       [s31, #16], s33
    s.st.d       [s31, #48], s33
    s.st.d       [s31, #56], s27
    .li       s34, #68719476768
    s.st.d       [s31, #88], s34
    s.st.d       [s31, #104], s30
    fence.release.device
    td.load      d1, [s31]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s31, s29, #1792
    s.addi       s35, s29, #2560                 // TensorMap 2: the gathered fallback B tile
    s.movz       s36, #0
    s.st.d       [s35, #0], s31
    s.st.d       [s35, #8], s32
    s.st.d       [s35, #16], s33
    s.st.d       [s35, #48], s33
    s.st.d       [s35, #56], s27
    s.st.d       [s35, #88], s34
    s.st.d       [s35, #104], s30
    fence.release.device
    td.load      d2, [s35]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s27, v4, #0
    br.nz        s27, x8dot_done_19
    s.addi       s30, s29, #512
    s.addi       s31, s36, #0
    v.ld.w       v19, [s30, #0]
    s.add        s30, s13, s25
x8dot_row_20:
    s.addi       s33, s26, #0
    v.movi       v20, #0
    s.sub        s34, s33, s31
    s.add        s33, s30, s31
    v.splat      v21, s34
    s.shli       s34, s31, #4
    s.addi       s35, s31, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s33, v19]            // index is in elements (ISA sec 9.1)
    s.add        s33, s28, s34
    v.st.b       [s33, #0], v20
    fence.acq_rel.device
    s.mov        s31, s35
    s.cmp.lt     s33, s31, s32
    br.nz        s33, x8dot_row_20
x8dot_done_19:
    v.splat      v19, s27
    v.movi       v20, #0
    mb.arm       s27, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s28, v18, #0
    v.extract    s30, v4, #1
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s31, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s31, s27            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s31, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s31, s27          // predicated off still completes once (ISA sec 9A.3)
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s30, x8dot_done_21
    s.movz       s28, #0
    s.addi       s31, s29, #576
    s.addi       s32, s28, #0
    v.ld.w       v19, [s31, #0]
    s.add        s28, s13, s25
    s.addi       s31, s29, #1792
x8dot_row_22:
    s.addi       s33, s26, #0
    v.movi       v20, #0
    s.sub        s34, s33, s32
    s.add        s33, s28, s32
    v.splat      v21, s34
    s.shli       s34, s32, #4
    s.addi       s35, s32, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s33, v19]            // index is in elements (ISA sec 9.1)
    s.add        s33, s31, s34
    s.movz       s34, #32
    v.st.b       [s33, #0], v20
    fence.acq_rel.device
    s.mov        s32, s35
    s.cmp.lt     s33, s32, s34
    br.nz        s33, x8dot_row_22
x8dot_done_21:
    v.splat      v19, s30
    v.movi       v20, #0
    mb.arm       s28, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s30, #0
    v.extract    s31, v18, #1
    // X8 A staging: proven equal rows share a packed register
    s.addi       s32, s29, #0
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s33, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s28          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v19, [s32, #0]
    s.addi       s31, s29, #2816                 // 512 bytes of repack scratch
    s.addi       s33, s29, #64
    s.addi       s34, s31, #0
    s.addi       s35, s31, #32
    s.addi       s36, s31, #16
    s.addi       s37, s31, #48
    v.st.b       [s34, #0], v19
    v.extract    s34, v4, #2
    v.ld.w       v19, [s32, #0]
    v.st.b       [s35, #0], v19
    v.ld.w       v19, [s33, #0]
    v.st.b       [s36, #0], v19
    v.ld.w       v19, [s33, #0]
    v.st.b       [s37, #0], v19
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.ld.w       v19, [s31, #0]
    v.mov        v56, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v57, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v58, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v59, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v60, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v61, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v62, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v63, v19                        // hand off through the shared window (sec 7.3)
    mb.wait      s27
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s31
    mb.wait      s31
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s34, x8dot_done_23
    s.addi       s32, s29, #640
    s.addi       s33, s30, #0
    v.ld.w       v19, [s32, #0]
    s.add        s30, s13, s25
    s.addi       s32, s29, #1280
x8dot_row_24:
    s.addi       s35, s26, #0
    v.movi       v20, #0
    s.sub        s36, s35, s33
    s.add        s35, s30, s33
    v.splat      v21, s36
    s.shli       s36, s33, #4
    s.addi       s37, s33, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s35, v19]            // index is in elements (ISA sec 9.1)
    s.add        s35, s32, s36
    s.movz       s36, #32
    v.st.b       [s35, #0], v20
    fence.acq_rel.device
    s.mov        s33, s37
    s.cmp.lt     s35, s33, s36
    br.nz        s35, x8dot_row_24
x8dot_done_23:
    v.splat      v19, s34
    v.movi       v20, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    v.extract    s33, v18, #2
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s34, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s34, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s34, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s33, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v4, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s33
    mb.wait      s33
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s34, x8dot_done_25
    s.addi       s35, s29, #704
    s.addi       s36, s32, #0
    v.ld.w       v19, [s35, #0]
    s.add        s35, s13, s25
    s.addi       s37, s29, #1792
x8dot_row_26:
    s.addi       s38, s26, #0
    v.movi       v20, #0
    s.sub        s39, s38, s36
    s.add        s38, s35, s36
    v.splat      v21, s39
    s.shli       s39, s36, #4
    s.addi       s40, s36, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s38, v19]            // index is in elements (ISA sec 9.1)
    s.add        s38, s37, s39
    s.movz       s39, #32
    v.st.b       [s38, #0], v20
    fence.acq_rel.device
    s.mov        s36, s40
    s.cmp.lt     s38, s36, s39
    br.nz        s38, x8dot_row_26
x8dot_done_25:
    v.splat      v19, s34
    v.movi       v20, #0
    mb.arm       s34, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s35, v18, #3
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s36, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v4, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s35
    mb.wait      s35
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s36, x8dot_done_27
    s.addi       s37, s29, #768
    s.addi       s38, s32, #0
    v.ld.w       v19, [s37, #0]
    s.add        s32, s13, s25
    s.addi       s37, s29, #1280
x8dot_row_28:
    s.addi       s39, s26, #0
    v.movi       v20, #0
    s.sub        s40, s39, s38
    s.add        s39, s32, s38
    v.splat      v21, s40
    s.shli       s40, s38, #4
    s.addi       s41, s38, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s39, v19]            // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.movz       s40, #32
    v.st.b       [s39, #0], v20
    fence.acq_rel.device
    s.mov        s38, s41
    s.cmp.lt     s39, s38, s40
    br.nz        s39, x8dot_row_28
x8dot_done_27:
    v.splat      v19, s36
    v.movi       v20, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    v.extract    s37, v18, #4
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s38, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s38, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s38, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s37, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v4, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s37
    mb.wait      s37
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s38, x8dot_done_29
    s.addi       s39, s29, #832
    s.addi       s40, s36, #0
    v.ld.w       v19, [s39, #0]
    s.add        s39, s13, s25
    s.addi       s41, s29, #1792
x8dot_row_30:
    s.addi       s42, s26, #0
    v.movi       v20, #0
    s.sub        s43, s42, s40
    s.add        s42, s39, s40
    v.splat      v21, s43
    s.shli       s43, s40, #4
    s.addi       s44, s40, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s42, v19]            // index is in elements (ISA sec 9.1)
    s.add        s42, s41, s43
    s.movz       s43, #32
    v.st.b       [s42, #0], v20
    fence.acq_rel.device
    s.mov        s40, s44
    s.cmp.lt     s42, s40, s43
    br.nz        s42, x8dot_row_30
x8dot_done_29:
    v.splat      v19, s38
    v.movi       v20, #0
    mb.arm       s38, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s39, v18, #5
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s40, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s40, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v4, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s39
    mb.wait      s39
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s40, x8dot_done_31
    s.addi       s41, s29, #896
    s.addi       s42, s36, #0
    v.ld.w       v19, [s41, #0]
    s.add        s36, s13, s25
    s.addi       s41, s29, #1280
x8dot_row_32:
    s.addi       s43, s26, #0
    v.movi       v20, #0
    s.sub        s44, s43, s42
    s.add        s43, s36, s42
    v.splat      v21, s44
    s.shli       s44, s42, #4
    s.addi       s45, s42, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s43, v19]            // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.movz       s44, #32
    v.st.b       [s43, #0], v20
    fence.acq_rel.device
    s.mov        s42, s45
    s.cmp.lt     s43, s42, s44
    br.nz        s43, x8dot_row_32
x8dot_done_31:
    v.splat      v19, s40
    v.movi       v20, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.extract    s41, v18, #6
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s42, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s42, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s41, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v4, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s41
    mb.wait      s41
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s42, x8dot_done_33
    s.addi       s43, s29, #960
    s.addi       s44, s40, #0
    v.ld.w       v19, [s43, #0]
    s.add        s43, s13, s25
    s.addi       s45, s29, #1792
x8dot_row_34:
    s.addi       s46, s26, #0
    v.movi       v20, #0
    s.sub        s47, s46, s44
    s.add        s46, s43, s44
    v.splat      v21, s47
    s.shli       s47, s44, #4
    s.addi       s48, s44, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s46, v19]            // index is in elements (ISA sec 9.1)
    s.add        s46, s45, s47
    s.movz       s47, #32
    v.st.b       [s46, #0], v20
    fence.acq_rel.device
    s.mov        s44, s48
    s.cmp.lt     s46, s44, s47
    br.nz        s46, x8dot_row_34
x8dot_done_33:
    v.splat      v19, s42
    v.movi       v20, #0
    mb.arm       s42, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s43, v18, #7
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s44, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v4, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s43
    mb.wait      s43
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s44, x8dot_done_35
    s.addi       s45, s29, #512
    s.add        s46, s13, s25
    s.addi       s47, s40, #0
    v.ld.w       v19, [s45, #0]
    s.addi       s40, s46, #32
    s.addi       s45, s29, #1280
x8dot_row_36:
    s.addi       s46, s26, #-32
    v.movi       v20, #0
    s.sub        s48, s46, s47
    s.add        s46, s40, s47
    v.splat      v21, s48
    s.shli       s48, s47, #4
    s.addi       s49, s47, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s46, v19]            // index is in elements (ISA sec 9.1)
    s.add        s46, s45, s48
    s.movz       s48, #32
    v.st.b       [s46, #0], v20
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s46, s47, s48
    br.nz        s46, x8dot_row_36
x8dot_done_35:
    v.splat      v19, s44
    v.movi       v20, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    v.extract    s45, v18, #0
    s.movz       s46, #32
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s47, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s47, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s47, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s45, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v4, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s45
    mb.wait      s45
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s47, x8dot_done_37
    s.addi       s48, s29, #576
    s.add        s49, s13, s25
    s.addi       s50, s44, #0
    v.ld.w       v19, [s48, #0]
    s.addi       s48, s49, #32
    s.addi       s49, s29, #1792
x8dot_row_38:
    s.addi       s51, s26, #-32
    v.movi       v20, #0
    s.sub        s52, s51, s50
    s.add        s51, s48, s50
    v.splat      v21, s52
    s.shli       s52, s50, #4
    s.addi       s53, s50, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s51, v19]            // index is in elements (ISA sec 9.1)
    s.add        s51, s49, s52
    v.st.b       [s51, #0], v20
    fence.acq_rel.device
    s.mov        s50, s53
    s.cmp.lt     s51, s50, s46
    br.nz        s51, x8dot_row_38
x8dot_done_37:
    v.splat      v19, s47
    v.movi       v20, #0
    mb.arm       s47, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s48, v18, #1
    // X8 A staging: proven equal rows share a packed register
    s.addi       s49, s29, #128
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s50, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s50, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s47          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v19, [s49, #0]
    s.addi       s44, s29, #3328                 // 512 bytes of repack scratch
    s.addi       s46, s29, #192
    s.addi       s48, s44, #0
    s.addi       s50, s44, #32
    s.addi       s51, s44, #16
    s.addi       s52, s44, #48
    v.st.b       [s48, #0], v19
    v.extract    s48, v4, #2
    v.ld.w       v19, [s49, #0]
    v.st.b       [s50, #0], v19
    v.ld.w       v19, [s46, #0]
    v.st.b       [s51, #0], v19
    v.ld.w       v19, [s46, #0]
    v.st.b       [s52, #0], v19
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.ld.w       v19, [s44, #0]
    v.mov        v56, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v57, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v58, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v59, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v60, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v61, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v62, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v63, v19                        // hand off through the shared window (sec 7.3)
    mb.wait      s40
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s44
    mb.wait      s44
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s48, x8dot_done_39
    s.movz       s46, #0
    s.addi       s49, s29, #640
    s.add        s50, s13, s25
    s.addi       s51, s46, #0
    v.ld.w       v19, [s49, #0]
    s.addi       s46, s50, #32
    s.addi       s49, s29, #1280
x8dot_row_40:
    s.addi       s50, s26, #-32
    v.movi       v20, #0
    s.sub        s52, s50, s51
    s.add        s50, s46, s51
    v.splat      v21, s52
    s.shli       s52, s51, #4
    s.addi       s53, s51, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s50, v19]            // index is in elements (ISA sec 9.1)
    s.add        s50, s49, s52
    s.movz       s52, #32
    v.st.b       [s50, #0], v20
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s50, s51, s52
    br.nz        s50, x8dot_row_40
x8dot_done_39:
    v.splat      v19, s48
    v.movi       v20, #0
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s48, #0
    v.extract    s49, v18, #2
    s.movz       s50, #32
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s51, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s51, s46            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s51, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s49, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s51, v4, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s49
    mb.wait      s49
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s51, x8dot_done_41
    s.addi       s52, s29, #704
    s.add        s53, s13, s25
    s.addi       s54, s48, #0
    v.ld.w       v19, [s52, #0]
    s.addi       s52, s53, #32
    s.addi       s53, s29, #1792
x8dot_row_42:
    s.addi       s55, s26, #-32
    v.movi       v20, #0
    s.sub        s56, s55, s54
    s.add        s55, s52, s54
    v.splat      v21, s56
    s.shli       s56, s54, #4
    s.addi       s57, s54, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s55, v19]            // index is in elements (ISA sec 9.1)
    s.add        s55, s53, s56
    v.st.b       [s55, #0], v20
    fence.acq_rel.device
    s.mov        s54, s57
    s.cmp.lt     s55, s54, s50
    br.nz        s55, x8dot_row_42
x8dot_done_41:
    v.splat      v19, s51
    v.movi       v20, #0
    mb.arm       s51, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s52, v18, #3
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s53, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s53, s51            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v4, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s50
    mb.wait      s50
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s52, x8dot_done_43
    s.addi       s53, s29, #768
    s.add        s54, s13, s25
    s.addi       s55, s48, #0
    v.ld.w       v19, [s53, #0]
    s.addi       s48, s54, #32
    s.addi       s53, s29, #1280
x8dot_row_44:
    s.addi       s54, s26, #-32
    v.movi       v20, #0
    s.sub        s56, s54, s55
    s.add        s54, s48, s55
    v.splat      v21, s56
    s.shli       s56, s55, #4
    s.addi       s57, s55, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s54, v19]            // index is in elements (ISA sec 9.1)
    s.add        s54, s53, s56
    s.movz       s56, #32
    v.st.b       [s54, #0], v20
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s54, s55, s56
    br.nz        s54, x8dot_row_44
x8dot_done_43:
    v.splat      v19, s52
    v.movi       v20, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    v.extract    s53, v18, #4
    s.movz       s54, #32
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s55, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s55, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s55, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s53, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v4, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s53
    mb.wait      s53
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s55, x8dot_done_45
    s.addi       s56, s29, #832
    s.add        s57, s13, s25
    s.addi       s58, s52, #0
    v.ld.w       v19, [s56, #0]
    s.addi       s56, s57, #32
    s.addi       s57, s29, #1792
x8dot_row_46:
    s.addi       s59, s26, #-32
    v.movi       v20, #0
    s.sub        s60, s59, s58
    s.add        s59, s56, s58
    v.splat      v21, s60
    s.shli       s60, s58, #4
    s.addi       s27, s58, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s59, v19]            // index is in elements (ISA sec 9.1)
    s.add        s28, s57, s60
    v.st.b       [s28, #0], v20
    fence.acq_rel.device
    s.mov        s58, s27
    s.cmp.lt     s27, s58, s54
    br.nz        s27, x8dot_row_46
x8dot_done_45:
    v.splat      v19, s55
    v.movi       v20, #0
    mb.arm       s27, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s28, v18, #5
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s30, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s30, s27            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s30, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s30, s27          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s28, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s30, v4, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s28
    mb.wait      s28
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s30, x8dot_done_47
    s.addi       s31, s29, #896
    s.add        s32, s13, s25
    s.addi       s33, s52, #0
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s32, #32
    s.addi       s32, s29, #1280
x8dot_row_48:
    s.addi       s34, s26, #-32
    v.movi       v20, #0
    s.sub        s35, s34, s33
    s.add        s34, s31, s33
    v.splat      v21, s35
    s.shli       s35, s33, #4
    s.addi       s36, s33, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s34, v19]            // index is in elements (ISA sec 9.1)
    s.add        s34, s32, s35
    s.movz       s35, #32
    v.st.b       [s34, #0], v20
    fence.acq_rel.device
    s.mov        s33, s36
    s.cmp.lt     s34, s33, s35
    br.nz        s34, x8dot_row_48
x8dot_done_47:
    v.splat      v19, s30
    v.movi       v20, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s31, #0
    v.extract    s32, v18, #6
    s.movz       s33, #32
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s34, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s34, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s34, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s27
    mb.arm       s32, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v4, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s32
    mb.wait      s32
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s34, x8dot_done_49
    s.addi       s35, s29, #960
    s.add        s36, s13, s25
    s.addi       s37, s31, #0
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s36, #32
    s.addi       s36, s29, #1792
x8dot_row_50:
    s.addi       s38, s26, #-32
    v.movi       v20, #0
    s.sub        s39, s38, s37
    s.add        s38, s35, s37
    v.splat      v21, s39
    s.shli       s39, s37, #4
    s.addi       s40, s37, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s38, v19]            // index is in elements (ISA sec 9.1)
    s.add        s38, s36, s39
    v.st.b       [s38, #0], v20
    fence.acq_rel.device
    s.mov        s37, s40
    s.cmp.lt     s38, s37, s33
    br.nz        s38, x8dot_row_50
x8dot_done_49:
    v.splat      v19, s34
    v.movi       v20, #0
    mb.arm       s34, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s35, v18, #7
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s36, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v4, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s33
    mb.wait      s33
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s35, x8dot_done_51
    s.addi       s36, s29, #512
    s.add        s37, s13, s25
    s.addi       s38, s31, #0
    v.ld.w       v19, [s36, #0]
    s.addi       s31, s37, #64
    s.addi       s36, s29, #1280
x8dot_row_52:
    s.addi       s37, s26, #-64
    v.movi       v20, #0
    s.sub        s39, s37, s38
    s.add        s37, s31, s38
    v.splat      v21, s39
    s.shli       s39, s38, #4
    s.addi       s40, s38, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s37, v19]            // index is in elements (ISA sec 9.1)
    s.add        s37, s36, s39
    s.movz       s39, #32
    v.st.b       [s37, #0], v20
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s37, s38, s39
    br.nz        s37, x8dot_row_52
x8dot_done_51:
    v.splat      v19, s35
    v.movi       v20, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s35, #0
    v.extract    s36, v18, #0
    s.movz       s37, #64
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s38, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s38, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s38, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s36, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v4, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s36
    mb.wait      s36
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s38, x8dot_done_53
    s.addi       s39, s29, #576
    s.add        s40, s13, s25
    s.addi       s41, s35, #0
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s40, #64
    s.addi       s40, s29, #1792
x8dot_row_54:
    s.addi       s42, s26, #-64
    v.movi       v20, #0
    s.sub        s43, s42, s41
    s.add        s42, s39, s41
    v.splat      v21, s43
    s.shli       s43, s41, #4
    s.addi       s44, s41, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s42, v19]            // index is in elements (ISA sec 9.1)
    s.add        s42, s40, s43
    s.movz       s43, #32
    v.st.b       [s42, #0], v20
    fence.acq_rel.device
    s.mov        s41, s44
    s.cmp.lt     s42, s41, s43
    br.nz        s42, x8dot_row_54
x8dot_done_53:
    v.splat      v19, s38
    v.movi       v20, #0
    mb.arm       s38, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s39, v18, #1
    // X8 A staging: proven equal rows share a packed register
    s.addi       s40, s29, #256
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s41, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s41, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s38          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v19, [s40, #0]
    s.addi       s35, s29, #3840                 // 512 bytes of repack scratch
    s.addi       s37, s29, #320
    s.addi       s39, s35, #0
    s.addi       s41, s35, #32
    s.addi       s42, s35, #16
    s.addi       s43, s35, #48
    v.st.b       [s39, #0], v19
    v.extract    s39, v4, #2
    v.ld.w       v19, [s40, #0]
    v.st.b       [s41, #0], v19
    v.ld.w       v19, [s37, #0]
    v.st.b       [s42, #0], v19
    v.ld.w       v19, [s37, #0]
    v.st.b       [s43, #0], v19
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.ld.w       v19, [s35, #0]
    v.mov        v56, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v57, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v58, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v59, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v60, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v61, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v62, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v63, v19                        // hand off through the shared window (sec 7.3)
    mb.wait      s31
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s35
    mb.wait      s35
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s39, x8dot_done_55
    s.movz       s37, #0
    s.addi       s40, s29, #640
    s.add        s41, s13, s25
    s.addi       s42, s37, #0
    v.ld.w       v19, [s40, #0]
    s.addi       s37, s41, #64
    s.addi       s40, s29, #1280
x8dot_row_56:
    s.addi       s41, s26, #-64
    v.movi       v20, #0
    s.sub        s43, s41, s42
    s.add        s41, s37, s42
    v.splat      v21, s43
    s.shli       s43, s42, #4
    s.addi       s44, s42, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s41, v19]            // index is in elements (ISA sec 9.1)
    s.add        s41, s40, s43
    s.movz       s43, #32
    v.st.b       [s41, #0], v20
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s41, s42, s43
    br.nz        s41, x8dot_row_56
x8dot_done_55:
    v.splat      v19, s39
    v.movi       v20, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    v.extract    s40, v18, #2
    s.movz       s41, #64
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s42, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s42, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s42, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s40, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v4, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s40
    mb.wait      s40
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s42, x8dot_done_57
    s.addi       s43, s29, #704
    s.add        s44, s13, s25
    s.addi       s45, s39, #0
    v.ld.w       v19, [s43, #0]
    s.addi       s43, s44, #64
    s.addi       s44, s29, #1792
x8dot_row_58:
    s.addi       s46, s26, #-64
    v.movi       v20, #0
    s.sub        s47, s46, s45
    s.add        s46, s43, s45
    v.splat      v21, s47
    s.shli       s47, s45, #4
    s.addi       s49, s45, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s46, v19]            // index is in elements (ISA sec 9.1)
    s.add        s46, s44, s47
    s.movz       s47, #32
    v.st.b       [s46, #0], v20
    fence.acq_rel.device
    s.mov        s45, s49
    s.cmp.lt     s46, s45, s47
    br.nz        s46, x8dot_row_58
x8dot_done_57:
    v.splat      v19, s42
    v.movi       v20, #0
    mb.arm       s42, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s43, v18, #3
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s44, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s44, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v4, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s41
    mb.wait      s41
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s43, x8dot_done_59
    s.addi       s44, s29, #768
    s.add        s45, s13, s25
    s.addi       s46, s39, #0
    v.ld.w       v19, [s44, #0]
    s.addi       s39, s45, #64
    s.addi       s44, s29, #1280
x8dot_row_60:
    s.addi       s45, s26, #-64
    v.movi       v20, #0
    s.sub        s47, s45, s46
    s.add        s45, s39, s46
    v.splat      v21, s47
    s.shli       s47, s46, #4
    s.addi       s49, s46, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s45, v19]            // index is in elements (ISA sec 9.1)
    s.add        s45, s44, s47
    s.movz       s47, #32
    v.st.b       [s45, #0], v20
    fence.acq_rel.device
    s.mov        s46, s49
    s.cmp.lt     s45, s46, s47
    br.nz        s45, x8dot_row_60
x8dot_done_59:
    v.splat      v19, s43
    v.movi       v20, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    v.extract    s44, v18, #4
    s.movz       s45, #64
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s46, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s46, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s46, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s46, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s44, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v4, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s44
    mb.wait      s44
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s46, x8dot_done_61
    s.addi       s47, s29, #832
    s.add        s49, s13, s25
    s.addi       s50, s43, #0
    v.ld.w       v19, [s47, #0]
    s.addi       s47, s49, #64
    s.addi       s49, s29, #1792
x8dot_row_62:
    s.addi       s51, s26, #-64
    v.movi       v20, #0
    s.sub        s52, s51, s50
    s.add        s51, s47, s50
    v.splat      v21, s52
    s.shli       s52, s50, #4
    s.addi       s53, s50, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s51, v19]            // index is in elements (ISA sec 9.1)
    s.add        s51, s49, s52
    s.movz       s52, #32
    v.st.b       [s51, #0], v20
    fence.acq_rel.device
    s.mov        s50, s53
    s.cmp.lt     s51, s50, s52
    br.nz        s51, x8dot_row_62
x8dot_done_61:
    v.splat      v19, s46
    v.movi       v20, #0
    mb.arm       s46, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s47, v18, #5
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s49, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s49, s46            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v4, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s45
    mb.wait      s45
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s47, x8dot_done_63
    s.addi       s49, s29, #896
    s.add        s50, s13, s25
    s.addi       s51, s43, #0
    v.ld.w       v19, [s49, #0]
    s.addi       s43, s50, #64
    s.addi       s49, s29, #1280
x8dot_row_64:
    s.addi       s50, s26, #-64
    v.movi       v20, #0
    s.sub        s52, s50, s51
    s.add        s50, s43, s51
    v.splat      v21, s52
    s.shli       s52, s51, #4
    s.addi       s53, s51, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s50, v19]            // index is in elements (ISA sec 9.1)
    s.add        s50, s49, s52
    s.movz       s52, #32
    v.st.b       [s50, #0], v20
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s50, s51, s52
    br.nz        s50, x8dot_row_64
x8dot_done_63:
    v.splat      v19, s47
    v.movi       v20, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    v.extract    s49, v18, #6
    s.movz       s50, #64
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s51, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s51, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s49, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s51, v4, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s49
    mb.wait      s49
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s51, x8dot_done_65
    s.addi       s52, s29, #960
    s.add        s53, s13, s25
    s.addi       s54, s47, #0
    v.ld.w       v19, [s52, #0]
    s.addi       s52, s53, #64
    s.addi       s53, s29, #1792
x8dot_row_66:
    s.addi       s55, s26, #-64
    v.movi       v20, #0
    s.sub        s56, s55, s54
    s.add        s55, s52, s54
    v.splat      v21, s56
    s.shli       s56, s54, #4
    s.addi       s57, s54, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s55, v19]            // index is in elements (ISA sec 9.1)
    s.add        s55, s53, s56
    s.movz       s56, #32
    v.st.b       [s55, #0], v20
    fence.acq_rel.device
    s.mov        s54, s57
    s.cmp.lt     s55, s54, s56
    br.nz        s55, x8dot_row_66
x8dot_done_65:
    v.splat      v19, s51
    v.movi       v20, #0
    mb.arm       s51, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s52, v18, #7
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s53, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s53, s51            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s51          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v4, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s50
    mb.wait      s50
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s52, x8dot_done_67
    s.addi       s53, s29, #512
    s.add        s54, s13, s25
    s.addi       s55, s47, #0
    v.ld.w       v19, [s53, #0]
    s.addi       s47, s54, #96
    s.addi       s53, s29, #1280
x8dot_row_68:
    s.addi       s54, s26, #-96
    v.movi       v20, #0
    s.sub        s56, s54, s55
    s.add        s54, s47, s55
    v.splat      v21, s56
    s.shli       s56, s55, #4
    s.addi       s57, s55, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s54, v19]            // index is in elements (ISA sec 9.1)
    s.add        s54, s53, s56
    s.movz       s56, #32
    v.st.b       [s54, #0], v20
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s54, s55, s56
    br.nz        s54, x8dot_row_68
x8dot_done_67:
    v.splat      v19, s52
    v.movi       v20, #0
    mb.arm       s47, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s52, #0
    v.extract    s53, v18, #0
    s.movz       s54, #96
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s55, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s55, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s55, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s51
    mb.arm       s53, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v4, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s53
    mb.wait      s53
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s55, x8dot_done_69
    s.addi       s56, s29, #576
    s.add        s57, s13, s25
    s.addi       s58, s52, #0
    v.ld.w       v19, [s56, #0]
    s.addi       s56, s57, #96
    s.addi       s57, s29, #1792
x8dot_row_70:
    s.addi       s59, s26, #-96
    v.movi       v20, #0
    s.sub        s60, s59, s58
    s.add        s59, s56, s58
    v.splat      v21, s60
    s.shli       s60, s58, #4
    s.addi       s27, s58, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s59, v19]            // index is in elements (ISA sec 9.1)
    s.add        s28, s57, s60
    s.movz       s30, #32
    v.st.b       [s28, #0], v20
    fence.acq_rel.device
    s.mov        s58, s27
    s.cmp.lt     s27, s58, s30
    br.nz        s27, x8dot_row_70
x8dot_done_69:
    v.splat      v19, s55
    v.movi       v20, #0
    mb.arm       s27, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s28, v18, #1
    // X8 A staging: proven equal rows share a packed register
    s.addi       s30, s29, #384
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s31, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s31, s27            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s31, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s31, s27          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v19, [s30, #0]
    s.addi       s28, s29, #4352                 // 512 bytes of repack scratch
    s.addi       s31, s29, #448
    s.addi       s32, s28, #0
    s.addi       s33, s28, #32
    s.addi       s34, s28, #16
    s.addi       s35, s28, #48
    v.st.b       [s32, #0], v19
    v.extract    s32, v4, #2
    v.ld.w       v19, [s30, #0]
    v.st.b       [s33, #0], v19
    v.ld.w       v19, [s31, #0]
    v.st.b       [s34, #0], v19
    v.ld.w       v19, [s31, #0]
    v.st.b       [s35, #0], v19
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.ld.w       v19, [s28, #0]
    v.mov        v56, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v57, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v58, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v59, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v60, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v61, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v62, v19                        // hand off through the shared window (sec 7.3)
    v.mov        v63, v19                        // hand off through the shared window (sec 7.3)
    mb.wait      s47
    mb.arm       s28, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s28
    mb.wait      s28
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s32, x8dot_done_71
    s.movz       s30, #0
    s.addi       s31, s29, #640
    s.add        s33, s13, s25
    s.addi       s34, s30, #0
    v.ld.w       v19, [s31, #0]
    s.addi       s30, s33, #96
    s.addi       s31, s29, #1280
x8dot_row_72:
    s.addi       s33, s26, #-96
    v.movi       v20, #0
    s.sub        s35, s33, s34
    s.add        s33, s30, s34
    v.splat      v21, s35
    s.shli       s35, s34, #4
    s.addi       s36, s34, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s33, v19]            // index is in elements (ISA sec 9.1)
    s.add        s33, s31, s35
    s.movz       s35, #32
    v.st.b       [s33, #0], v20
    fence.acq_rel.device
    s.mov        s34, s36
    s.cmp.lt     s33, s34, s35
    br.nz        s33, x8dot_row_72
x8dot_done_71:
    v.splat      v19, s32
    v.movi       v20, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s31, #0
    v.extract    s32, v18, #2
    s.movz       s33, #96
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s34, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s34, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s34, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s27
    mb.arm       s32, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s34, v4, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s32
    mb.wait      s32
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s34, x8dot_done_73
    s.addi       s35, s29, #704
    s.add        s36, s13, s25
    s.addi       s37, s31, #0
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s36, #96
    s.addi       s36, s29, #1792
x8dot_row_74:
    s.addi       s38, s26, #-96
    v.movi       v20, #0
    s.sub        s39, s38, s37
    s.add        s38, s35, s37
    v.splat      v21, s39
    s.shli       s39, s37, #4
    s.addi       s40, s37, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s38, v19]            // index is in elements (ISA sec 9.1)
    s.add        s38, s36, s39
    s.movz       s39, #32
    v.st.b       [s38, #0], v20
    fence.acq_rel.device
    s.mov        s37, s40
    s.cmp.lt     s38, s37, s39
    br.nz        s38, x8dot_row_74
x8dot_done_73:
    v.splat      v19, s34
    v.movi       v20, #0
    mb.arm       s34, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s35, v18, #3
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s36, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s36, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v4, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s33
    mb.wait      s33
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s35, x8dot_done_75
    s.addi       s36, s29, #768
    s.add        s37, s13, s25
    s.addi       s38, s31, #0
    v.ld.w       v19, [s36, #0]
    s.addi       s31, s37, #96
    s.addi       s36, s29, #1280
x8dot_row_76:
    s.addi       s37, s26, #-96
    v.movi       v20, #0
    s.sub        s39, s37, s38
    s.add        s37, s31, s38
    v.splat      v21, s39
    s.shli       s39, s38, #4
    s.addi       s40, s38, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s37, v19]            // index is in elements (ISA sec 9.1)
    s.add        s37, s36, s39
    s.movz       s39, #32
    v.st.b       [s37, #0], v20
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s37, s38, s39
    br.nz        s37, x8dot_row_76
x8dot_done_75:
    v.splat      v19, s35
    v.movi       v20, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s35, #0
    v.extract    s36, v18, #4
    s.movz       s37, #96
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s38, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s38, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s38, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s36, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v4, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s36
    mb.wait      s36
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s38, x8dot_done_77
    s.addi       s39, s29, #832
    s.add        s40, s13, s25
    s.addi       s41, s35, #0
    v.ld.w       v19, [s39, #0]
    s.addi       s39, s40, #96
    s.addi       s40, s29, #1792
x8dot_row_78:
    s.addi       s42, s26, #-96
    v.movi       v20, #0
    s.sub        s43, s42, s41
    s.add        s42, s39, s41
    v.splat      v21, s43
    s.shli       s43, s41, #4
    s.addi       s44, s41, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s42, v19]            // index is in elements (ISA sec 9.1)
    s.add        s42, s40, s43
    s.movz       s43, #32
    v.st.b       [s42, #0], v20
    fence.acq_rel.device
    s.mov        s41, s44
    s.cmp.lt     s42, s41, s43
    br.nz        s42, x8dot_row_78
x8dot_done_77:
    v.splat      v19, s38
    v.movi       v20, #0
    mb.arm       s38, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s39, v18, #5
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s40, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s40, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s40, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v4, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s37
    mb.wait      s37
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s39, x8dot_done_79
    s.addi       s40, s29, #896
    s.add        s41, s13, s25
    s.addi       s42, s35, #0
    v.ld.w       v19, [s40, #0]
    s.addi       s35, s41, #96
    s.addi       s40, s29, #1280
x8dot_row_80:
    s.addi       s41, s26, #-96
    v.movi       v20, #0
    s.sub        s43, s41, s42
    s.add        s41, s35, s42
    v.splat      v21, s43
    s.shli       s43, s42, #4
    s.addi       s44, s42, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s41, v19]            // index is in elements (ISA sec 9.1)
    s.add        s41, s40, s43
    s.movz       s43, #32
    v.st.b       [s41, #0], v20
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s41, s42, s43
    br.nz        s41, x8dot_row_80
x8dot_done_79:
    v.splat      v19, s39
    v.movi       v20, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    v.extract    s40, v18, #6
    s.movz       s41, #96
    v.cmp.ne     p1, v19, v20
    v.cmp.eq     p2, v19, v20
    s.mov        s42, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s42, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s42, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s40, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v4, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s40
    mb.wait      s40
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s42, x8dot_done_81
    s.addi       s43, s29, #960
    s.add        s44, s13, s25
    s.addi       s45, s39, #0
    v.ld.w       v4, [s43, #0]
    s.addi       s43, s44, #96
    s.addi       s44, s29, #1792
x8dot_row_82:
    s.addi       s46, s26, #-96
    v.movi       v19, #0
    s.sub        s48, s46, s45
    s.add        s46, s43, s45
    v.splat      v20, s48
    s.shli       s48, s45, #4
    s.addi       s49, s45, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s46, v4]             // index is in elements (ISA sec 9.1)
    s.add        s46, s44, s48
    s.movz       s48, #32
    v.st.b       [s46, #0], v19
    fence.acq_rel.device
    s.mov        s45, s49
    s.cmp.lt     s46, s45, s48
    br.nz        s46, x8dot_row_82
x8dot_done_81:
    v.splat      v4, s42
    v.movi       v19, #0
    mb.arm       s26, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s42, v18, #7
    v.cmp.ne     p1, v4, v19
    v.cmp.eq     p2, v4, v19
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s43, s26            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s26          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s42, s29, #4864
    s.movz       s43, #1
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s41
    mb.wait      s41
    mb.wait      s26
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s45, s42, #64
    s.movz       s46, #2
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s44
    mb.wait      s44
    a.vread      v4, a8, s39
    s.addi       s39, s42, #128
    s.movz       s48, #3
    v.st.w       [s42, #0], v4
    a.vread      v4, a8, s43
    s.addi       s43, s42, #192
    s.movz       s49, #4
    s.addi       s50, s42, #256
    s.movz       s51, #5
    s.addi       s52, s42, #320
    s.movz       s53, #6
    s.addi       s54, s42, #384
    s.movz       s55, #7
    s.addi       s56, s42, #448
    s.movz       s57, #8
    s.addi       s58, s42, #512
    s.movz       s59, #9
    s.addi       s60, s42, #576
    s.movz       s26, #10
    v.st.w       [s45, #0], v4
    a.vread      v4, a8, s46
    s.addi       s27, s42, #640
    s.movz       s28, #11
    v.st.w       [s39, #0], v4
    a.vread      v4, a8, s48
    s.addi       s30, s42, #704
    s.movz       s31, #12
    v.st.w       [s43, #0], v4
    a.vread      v4, a8, s49
    s.addi       s32, s42, #768
    s.movz       s33, #13
    v.st.w       [s50, #0], v4
    a.vread      v4, a8, s51
    s.addi       s34, s42, #832
    s.movz       s35, #14
    v.st.w       [s52, #0], v4
    a.vread      v4, a8, s53
    s.addi       s36, s42, #896
    s.movz       s37, #15
    s.addi       s38, s42, #960
    v.st.w       [s54, #0], v4
    a.vread      v4, a8, s55
    s.movz       s39, #0
    s.addi       s40, s29, #5888
    v.st.w       [s56, #0], v4
    a.vread      v4, a8, s57
    s.movz       s41, #1
    s.addi       s42, s40, #64
    v.st.w       [s58, #0], v4
    a.vread      v4, a8, s59
    s.movz       s43, #2
    s.addi       s44, s40, #128
    v.st.w       [s60, #0], v4
    a.vread      v4, a8, s26
    s.movz       s26, #3
    s.addi       s45, s40, #192
    v.st.w       [s27, #0], v4
    a.vread      v4, a8, s28
    s.movz       s27, #4
    s.addi       s28, s40, #256
    v.st.w       [s30, #0], v4
    a.vread      v4, a8, s31
    s.movz       s30, #5
    s.addi       s31, s40, #320
    v.st.w       [s32, #0], v4
    a.vread      v4, a8, s33
    s.movz       s32, #6
    s.addi       s33, s40, #384
    v.st.w       [s34, #0], v4
    a.vread      v4, a8, s35
    s.movz       s34, #7
    s.addi       s35, s40, #448
    v.st.w       [s36, #0], v4
    a.vread      v4, a8, s37
    s.movz       s36, #8
    s.addi       s37, s40, #512
    v.st.w       [s38, #0], v4
    fence.acq_rel.device
    a.vread      v4, a9, s39
    s.movz       s38, #9
    s.addi       s39, s40, #576
    v.st.w       [s40, #0], v4
    a.vread      v4, a9, s41
    s.movz       s41, #10
    v.st.w       [s42, #0], v4
    a.vread      v4, a9, s43
    s.addi       s42, s40, #640
    s.movz       s43, #11
    v.st.w       [s44, #0], v4
    a.vread      v4, a9, s26
    s.addi       s26, s40, #704
    s.movz       s44, #12
    v.st.w       [s45, #0], v4
    a.vread      v4, a9, s27
    s.addi       s27, s40, #768
    s.movz       s45, #13
    v.st.w       [s28, #0], v4
    a.vread      v4, a9, s30
    s.addi       s28, s40, #832
    s.movz       s30, #14
    v.st.w       [s31, #0], v4
    a.vread      v4, a9, s32
    s.addi       s31, s40, #896
    s.movz       s32, #15
    s.addi       s46, s40, #960
    v.st.w       [s33, #0], v4
    a.vread      v4, a9, s34
    s.movz       s33, #0
    s.addi       s34, s29, #6912
    v.st.w       [s35, #0], v4
    a.vread      v4, a9, s36
    s.movz       s35, #1
    s.addi       s36, s34, #64
    v.st.w       [s37, #0], v4
    a.vread      v4, a9, s38
    s.movz       s37, #2
    s.addi       s38, s34, #128
    v.st.w       [s39, #0], v4
    a.vread      v4, a9, s41
    s.movz       s39, #3
    s.addi       s40, s34, #192
    v.st.w       [s42, #0], v4
    a.vread      v4, a9, s43
    s.movz       s41, #4
    s.addi       s42, s34, #256
    v.st.w       [s26, #0], v4
    a.vread      v4, a9, s44
    s.movz       s26, #5
    s.addi       s43, s34, #320
    v.st.w       [s27, #0], v4
    a.vread      v4, a9, s45
    s.movz       s27, #6
    s.addi       s44, s34, #384
    v.st.w       [s28, #0], v4
    a.vread      v4, a9, s30
    s.movz       s28, #7
    s.addi       s30, s34, #448
    v.st.w       [s31, #0], v4
    a.vread      v4, a9, s32
    s.movz       s31, #8
    s.addi       s32, s34, #512
    v.st.w       [s46, #0], v4
    fence.acq_rel.device
    a.vread      v4, a10, s33
    s.movz       s33, #9
    s.addi       s45, s34, #576
    v.st.w       [s34, #0], v4
    a.vread      v4, a10, s35
    s.movz       s35, #10
    v.st.w       [s36, #0], v4
    a.vread      v4, a10, s37
    s.addi       s36, s34, #640
    s.movz       s37, #11
    v.st.w       [s38, #0], v4
    a.vread      v4, a10, s39
    s.addi       s38, s34, #704
    s.movz       s39, #12
    v.st.w       [s40, #0], v4
    a.vread      v4, a10, s41
    s.addi       s40, s34, #768
    s.movz       s41, #13
    v.st.w       [s42, #0], v4
    a.vread      v4, a10, s26
    s.addi       s26, s34, #832
    s.movz       s42, #14
    v.st.w       [s43, #0], v4
    a.vread      v4, a10, s27
    s.addi       s27, s34, #896
    s.movz       s43, #15
    s.addi       s46, s34, #960
    v.st.w       [s44, #0], v4
    a.vread      v4, a10, s28
    s.movz       s28, #0
    s.addi       s34, s29, #7936
    v.st.w       [s30, #0], v4
    a.vread      v4, a10, s31
    s.movz       s30, #1
    s.addi       s31, s34, #64
    v.st.w       [s32, #0], v4
    a.vread      v4, a10, s33
    s.movz       s32, #2
    s.addi       s33, s34, #128
    v.st.w       [s45, #0], v4
    a.vread      v4, a10, s35
    s.movz       s35, #3
    s.addi       s44, s34, #192
    v.st.w       [s36, #0], v4
    a.vread      v4, a10, s37
    s.movz       s36, #4
    s.addi       s37, s34, #256
    v.st.w       [s38, #0], v4
    a.vread      v4, a10, s39
    s.movz       s38, #5
    s.addi       s39, s34, #320
    v.st.w       [s40, #0], v4
    a.vread      v4, a10, s41
    s.movz       s40, #6
    s.addi       s41, s34, #384
    v.st.w       [s26, #0], v4
    a.vread      v4, a10, s42
    s.movz       s26, #7
    s.addi       s42, s34, #448
    v.st.w       [s27, #0], v4
    a.vread      v4, a10, s43
    s.movz       s27, #8
    s.addi       s43, s34, #512
    v.st.w       [s46, #0], v4
    fence.acq_rel.device
    a.vread      v4, a11, s28
    s.movz       s28, #9
    s.addi       s45, s34, #576
    v.st.w       [s34, #0], v4
    a.vread      v4, a11, s30
    s.movz       s30, #10
    v.st.w       [s31, #0], v4
    a.vread      v4, a11, s32
    s.addi       s31, s34, #640
    s.movz       s32, #11
    v.st.w       [s33, #0], v4
    a.vread      v4, a11, s35
    s.addi       s33, s34, #704
    s.movz       s35, #12
    v.st.w       [s44, #0], v4
    a.vread      v4, a11, s36
    s.addi       s36, s34, #768
    s.movz       s44, #13
    v.st.w       [s37, #0], v4
    a.vread      v4, a11, s38
    s.addi       s37, s34, #832
    s.movz       s38, #14
    v.st.w       [s39, #0], v4
    a.vread      v4, a11, s40
    s.addi       s39, s34, #896
    s.movz       s40, #15
    s.addi       s46, s34, #960
    v.st.w       [s41, #0], v4
    a.vread      v4, a11, s26
    s.movz       s26, #0
    s.addi       s34, s29, #8960
    v.st.w       [s42, #0], v4
    a.vread      v4, a11, s27
    s.movz       s27, #1
    s.addi       s41, s34, #64
    v.st.w       [s43, #0], v4
    a.vread      v4, a11, s28
    s.movz       s28, #2
    s.addi       s42, s34, #128
    v.st.w       [s45, #0], v4
    a.vread      v4, a11, s30
    s.movz       s30, #3
    s.addi       s43, s34, #192
    v.st.w       [s31, #0], v4
    a.vread      v4, a11, s32
    s.movz       s31, #4
    s.addi       s32, s34, #256
    v.st.w       [s33, #0], v4
    a.vread      v4, a11, s35
    s.movz       s33, #5
    s.addi       s35, s34, #320
    v.st.w       [s36, #0], v4
    a.vread      v4, a11, s44
    s.movz       s36, #6
    s.addi       s44, s34, #384
    v.st.w       [s37, #0], v4
    a.vread      v4, a11, s38
    s.movz       s37, #7
    s.addi       s38, s34, #448
    v.st.w       [s39, #0], v4
    a.vread      v4, a11, s40
    s.movz       s39, #8
    s.addi       s40, s34, #512
    v.st.w       [s46, #0], v4
    fence.acq_rel.device
    a.vread      v4, a12, s26
    s.movz       s26, #9
    s.addi       s45, s34, #576
    v.st.w       [s34, #0], v4
    a.vread      v4, a12, s27
    s.movz       s27, #10
    v.st.w       [s41, #0], v4
    a.vread      v4, a12, s28
    s.addi       s28, s34, #640
    s.movz       s41, #11
    v.st.w       [s42, #0], v4
    a.vread      v4, a12, s30
    s.addi       s30, s34, #704
    s.movz       s42, #12
    v.st.w       [s43, #0], v4
    a.vread      v4, a12, s31
    s.addi       s31, s34, #768
    s.movz       s43, #13
    v.st.w       [s32, #0], v4
    a.vread      v4, a12, s33
    s.addi       s32, s34, #832
    s.movz       s33, #14
    v.st.w       [s35, #0], v4
    a.vread      v4, a12, s36
    s.addi       s35, s34, #896
    s.movz       s36, #15
    s.addi       s46, s34, #960
    v.st.w       [s44, #0], v4
    a.vread      v4, a12, s37
    s.movz       s34, #0
    s.addi       s37, s29, #9984
    v.st.w       [s38, #0], v4
    a.vread      v4, a12, s39
    s.movz       s38, #1
    s.addi       s39, s37, #64
    v.st.w       [s40, #0], v4
    a.vread      v4, a12, s26
    s.movz       s26, #2
    s.addi       s40, s37, #128
    v.st.w       [s45, #0], v4
    a.vread      v4, a12, s27
    s.movz       s27, #3
    s.addi       s44, s37, #192
    v.st.w       [s28, #0], v4
    a.vread      v4, a12, s41
    s.movz       s28, #4
    s.addi       s41, s37, #256
    v.st.w       [s30, #0], v4
    a.vread      v4, a12, s42
    s.movz       s30, #5
    s.addi       s42, s37, #320
    v.st.w       [s31, #0], v4
    a.vread      v4, a12, s43
    s.movz       s31, #6
    s.addi       s43, s37, #384
    v.st.w       [s32, #0], v4
    a.vread      v4, a12, s33
    s.movz       s32, #7
    s.addi       s33, s37, #448
    v.st.w       [s35, #0], v4
    a.vread      v4, a12, s36
    s.movz       s35, #8
    s.addi       s36, s37, #512
    v.st.w       [s46, #0], v4
    fence.acq_rel.device
    a.vread      v4, a13, s34
    s.movz       s34, #9
    s.addi       s45, s37, #576
    v.st.w       [s37, #0], v4
    a.vread      v4, a13, s38
    s.movz       s38, #10
    v.st.w       [s39, #0], v4
    a.vread      v4, a13, s26
    s.addi       s26, s37, #640
    s.movz       s39, #11
    v.st.w       [s40, #0], v4
    a.vread      v4, a13, s27
    s.addi       s27, s37, #704
    s.movz       s40, #12
    v.st.w       [s44, #0], v4
    a.vread      v4, a13, s28
    s.addi       s28, s37, #768
    s.movz       s44, #13
    v.st.w       [s41, #0], v4
    a.vread      v4, a13, s30
    s.addi       s30, s37, #832
    s.movz       s41, #14
    v.st.w       [s42, #0], v4
    a.vread      v4, a13, s31
    s.addi       s31, s37, #896
    s.movz       s42, #15
    s.addi       s46, s37, #960
    v.st.w       [s43, #0], v4
    a.vread      v4, a13, s32
    s.movz       s32, #0
    s.addi       s37, s29, #11008
    v.st.w       [s33, #0], v4
    a.vread      v4, a13, s35
    s.movz       s33, #1
    s.addi       s35, s37, #64
    v.st.w       [s36, #0], v4
    a.vread      v4, a13, s34
    s.movz       s34, #2
    s.addi       s36, s37, #128
    v.st.w       [s45, #0], v4
    a.vread      v4, a13, s38
    s.movz       s38, #3
    s.addi       s43, s37, #192
    v.st.w       [s26, #0], v4
    a.vread      v4, a13, s39
    s.movz       s26, #4
    s.addi       s39, s37, #256
    v.st.w       [s27, #0], v4
    a.vread      v4, a13, s40
    s.movz       s27, #5
    s.addi       s40, s37, #320
    v.st.w       [s28, #0], v4
    a.vread      v4, a13, s44
    s.movz       s28, #6
    s.addi       s44, s37, #384
    v.st.w       [s30, #0], v4
    a.vread      v4, a13, s41
    s.movz       s30, #7
    s.addi       s41, s37, #448
    v.st.w       [s31, #0], v4
    a.vread      v4, a13, s42
    s.movz       s31, #8
    s.addi       s42, s37, #512
    v.st.w       [s46, #0], v4
    fence.acq_rel.device
    a.vread      v4, a14, s32
    s.movz       s32, #9
    s.addi       s45, s37, #576
    v.st.w       [s37, #0], v4
    a.vread      v4, a14, s33
    s.movz       s33, #10
    v.st.w       [s35, #0], v4
    a.vread      v4, a14, s34
    s.addi       s34, s37, #640
    s.movz       s35, #11
    v.st.w       [s36, #0], v4
    a.vread      v4, a14, s38
    s.addi       s36, s37, #704
    s.movz       s38, #12
    v.st.w       [s43, #0], v4
    a.vread      v4, a14, s26
    s.addi       s26, s37, #768
    s.movz       s43, #13
    v.st.w       [s39, #0], v4
    a.vread      v4, a14, s27
    s.addi       s27, s37, #832
    s.movz       s39, #14
    v.st.w       [s40, #0], v4
    a.vread      v4, a14, s28
    s.addi       s28, s37, #896
    s.movz       s40, #15
    s.addi       s46, s37, #960
    v.st.w       [s44, #0], v4
    a.vread      v4, a14, s30
    s.movz       s30, #0
    s.addi       s37, s29, #12032
    v.st.w       [s41, #0], v4
    a.vread      v4, a14, s31
    s.movz       s31, #1
    s.addi       s41, s37, #64
    v.st.w       [s42, #0], v4
    a.vread      v4, a14, s32
    s.movz       s32, #2
    s.addi       s42, s37, #128
    v.st.w       [s45, #0], v4
    a.vread      v4, a14, s33
    s.movz       s33, #3
    s.addi       s44, s37, #192
    v.st.w       [s34, #0], v4
    a.vread      v4, a14, s35
    s.movz       s34, #4
    s.addi       s35, s37, #256
    v.st.w       [s36, #0], v4
    a.vread      v4, a14, s38
    s.movz       s36, #5
    s.addi       s38, s37, #320
    v.st.w       [s26, #0], v4
    a.vread      v4, a14, s43
    s.movz       s26, #6
    s.addi       s43, s37, #384
    v.st.w       [s27, #0], v4
    a.vread      v4, a14, s39
    s.movz       s27, #7
    s.addi       s39, s37, #448
    v.st.w       [s28, #0], v4
    a.vread      v4, a14, s40
    s.movz       s28, #8
    s.addi       s40, s37, #512
    v.st.w       [s46, #0], v4
    fence.acq_rel.device
    a.vread      v4, a15, s30
    s.movz       s30, #9
    s.addi       s45, s37, #576
    v.st.w       [s37, #0], v4
    a.vread      v4, a15, s31
    s.movz       s31, #10
    v.st.w       [s41, #0], v4
    a.vread      v4, a15, s32
    s.addi       s32, s37, #640
    s.movz       s41, #11
    v.st.w       [s42, #0], v4
    a.vread      v4, a15, s33
    s.addi       s33, s37, #704
    s.movz       s42, #12
    v.st.w       [s44, #0], v4
    a.vread      v4, a15, s34
    s.addi       s34, s37, #768
    s.movz       s44, #13
    v.st.w       [s35, #0], v4
    a.vread      v4, a15, s36
    s.addi       s35, s37, #832
    s.movz       s36, #14
    v.st.w       [s38, #0], v4
    a.vread      v4, a15, s26
    s.addi       s26, s37, #896
    s.movz       s38, #15
    s.addi       s46, s37, #960
    v.st.w       [s43, #0], v4
    a.vread      v4, a15, s27
    s.movz       s27, #0
    s.addi       s37, s29, #4864
    v.st.w       [s39, #0], v4
    a.vread      v4, a15, s28
    v.extract    s28, v2, #0
    s.addi       s39, s29, #13056
    v.splat      v18, s28
    s.movz       s28, #1
    v.st.w       [s40, #0], v4
    a.vread      v4, a15, s30
    s.addi       s30, s29, #4928
    v.extract    s40, v2, #1
    v.splat      v19, s40
    s.addi       s40, s39, #64
    v.st.w       [s45, #0], v4
    a.vread      v4, a15, s31
    s.movz       s31, #2
    s.addi       s43, s29, #4992
    v.st.w       [s32, #0], v4
    a.vread      v4, a15, s41
    v.extract    s32, v2, #2
    s.addi       s41, s39, #128
    v.splat      v20, s32
    v.st.w       [s33, #0], v4
    a.vread      v4, a15, s42
    s.addi       s32, s39, #192
    v.st.w       [s34, #0], v4
    a.vread      v4, a15, s44
    s.movz       s33, #3
    s.addi       s34, s29, #5056
    v.st.w       [s35, #0], v4
    a.vread      v4, a15, s36
    v.extract    s35, v2, #3
    v.splat      v21, s35
    v.st.w       [s26, #0], v4
    a.vread      v4, a15, s38
    s.movz       s26, #4
    s.addi       s35, s39, #256
    v.st.w       [s46, #0], v4
    fence.acq_rel.device
    a.vread      v4, a0, s27
    s.addi       s27, s29, #5120
    v.extract    s36, v2, #4
    v.splat      v22, s36
    v.ld.w       v23, [s37, #0]
    vf.mul       v24, v23, v18
    s.addi       s36, s39, #320
    vf.mul       v18, v24, v25
    s.movz       s37, #5
    vf.add       v23, v4, v18
    v.st.w       [s39, #0], v23
    a.vread      v4, a0, s28
    s.addi       s28, s29, #5184
    v.extract    s38, v2, #5
    v.splat      v18, s38
    v.ld.w       v23, [s30, #0]
    vf.mul       v24, v23, v19
    s.addi       s30, s39, #384
    vf.mul       v19, v24, v25
    s.movz       s38, #6
    vf.add       v23, v4, v19
    v.st.w       [s40, #0], v23
    a.vread      v4, a0, s31
    s.addi       s31, s29, #5248
    v.extract    s40, v2, #6
    v.splat      v19, s40
    v.ld.w       v23, [s43, #0]
    vf.mul       v24, v23, v20
    s.addi       s40, s39, #448
    vf.mul       v20, v24, v25
    s.movz       s42, #7
    vf.add       v23, v4, v20
    v.st.w       [s41, #0], v23
    a.vread      v4, a0, s33
    s.addi       s33, s29, #5312
    v.extract    s41, v2, #7
    v.splat      v20, s41
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v21
    s.addi       s34, s39, #512
    vf.mul       v21, v24, v25
    s.movz       s41, #8
    vf.add       v23, v4, v21
    v.st.w       [s32, #0], v23
    a.vread      v4, a0, s26
    s.addi       s26, s29, #5376
    v.extract    s32, v2, #8
    v.splat      v21, s32
    v.ld.w       v23, [s27, #0]
    vf.mul       v24, v23, v22
    s.addi       s27, s39, #576
    vf.mul       v22, v24, v25
    s.movz       s32, #9
    vf.add       v23, v4, v22
    v.st.w       [s35, #0], v23
    a.vread      v4, a0, s37
    s.addi       s35, s29, #5440
    v.extract    s37, v2, #9
    v.splat      v22, s37
    v.ld.w       v23, [s28, #0]
    vf.mul       v24, v23, v18
    s.addi       s28, s39, #640
    vf.mul       v18, v24, v25
    s.movz       s37, #10
    vf.add       v23, v4, v18
    v.st.w       [s36, #0], v23
    a.vread      v4, a0, s38
    s.addi       s36, s29, #5504
    v.extract    s38, v2, #10
    v.splat      v18, s38
    v.ld.w       v23, [s31, #0]
    vf.mul       v24, v23, v19
    s.addi       s31, s39, #704
    vf.mul       v19, v24, v25
    s.movz       s38, #11
    vf.add       v23, v4, v19
    v.st.w       [s30, #0], v23
    a.vread      v4, a0, s42
    s.addi       s30, s29, #5568
    v.extract    s42, v2, #11
    v.splat      v19, s42
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v20
    s.addi       s33, s39, #768
    vf.mul       v20, v24, v25
    s.movz       s42, #12
    vf.add       v23, v4, v20
    v.st.w       [s40, #0], v23
    a.vread      v4, a0, s41
    s.addi       s40, s29, #5632
    v.extract    s41, v2, #12
    v.splat      v20, s41
    v.ld.w       v23, [s26, #0]
    vf.mul       v24, v23, v21
    s.addi       s26, s39, #832
    vf.mul       v21, v24, v25
    s.movz       s41, #13
    vf.add       v23, v4, v21
    v.st.w       [s34, #0], v23
    a.vread      v4, a0, s32
    s.addi       s32, s29, #5696
    v.extract    s34, v2, #13
    v.splat      v21, s34
    v.ld.w       v23, [s35, #0]
    vf.mul       v24, v23, v22
    s.addi       s34, s39, #896
    vf.mul       v22, v24, v25
    s.movz       s35, #14
    vf.add       v23, v4, v22
    v.st.w       [s27, #0], v23
    a.vread      v4, a0, s37
    s.addi       s27, s29, #5760
    v.extract    s37, v2, #14
    v.splat      v22, s37
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v18
    s.addi       s36, s39, #960
    vf.mul       v18, v24, v25
    s.movz       s37, #15
    vf.add       v23, v4, v18
    v.st.w       [s28, #0], v23
    a.vread      v4, a0, s38
    s.addi       s28, s29, #5824
    v.extract    s38, v2, #15
    v.splat      v18, s38
    v.ld.w       v23, [s30, #0]
    vf.mul       v24, v23, v19
    vf.mul       v19, v24, v25
    s.addi       s30, s29, #14080
    vf.add       v23, v4, v19
    s.movz       s38, #0
    v.st.w       [s31, #0], v23
    a.vread      v4, a0, s42
    s.addi       s31, s29, #5888
    v.extract    s39, v2, #0
    v.splat      v19, s39
    v.ld.w       v23, [s40, #0]
    vf.mul       v24, v23, v20
    vf.mul       v20, v24, v25
    s.addi       s39, s30, #64
    vf.add       v23, v4, v20
    s.movz       s40, #1
    v.st.w       [s33, #0], v23
    a.vread      v4, a0, s41
    s.addi       s33, s29, #5952
    v.extract    s41, v2, #1
    v.splat      v20, s41
    v.ld.w       v23, [s32, #0]
    vf.mul       v24, v23, v21
    vf.mul       v21, v24, v25
    s.addi       s32, s30, #128
    vf.add       v23, v4, v21
    s.movz       s41, #2
    v.st.w       [s26, #0], v23
    a.vread      v4, a0, s35
    s.addi       s26, s29, #6016
    v.extract    s35, v2, #2
    v.splat      v21, s35
    v.ld.w       v23, [s27, #0]
    vf.mul       v24, v23, v22
    vf.mul       v22, v24, v25
    s.addi       s27, s30, #192
    vf.add       v23, v4, v22
    s.movz       s35, #3
    v.st.w       [s34, #0], v23
    a.vread      v4, a0, s37
    s.addi       s34, s29, #6080
    v.extract    s37, v2, #3
    v.splat      v22, s37
    v.ld.w       v23, [s28, #0]
    vf.mul       v24, v23, v18
    vf.mul       v18, v24, v25
    s.addi       s28, s30, #256
    vf.add       v23, v4, v18
    s.movz       s37, #4
    v.st.w       [s36, #0], v23
    fence.acq_rel.device
    a.vread      v4, a1, s38
    s.addi       s36, s29, #6144
    v.extract    s38, v2, #4
    v.splat      v18, s38
    v.ld.w       v23, [s31, #0]
    vf.mul       v24, v23, v19
    s.addi       s31, s30, #320
    vf.mul       v19, v24, v26
    s.movz       s38, #5
    vf.add       v23, v4, v19
    v.st.w       [s30, #0], v23
    a.vread      v4, a1, s40
    s.addi       s40, s29, #6208
    v.extract    s42, v2, #5
    v.splat      v19, s42
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v20
    s.addi       s33, s30, #384
    vf.mul       v20, v24, v26
    s.movz       s42, #6
    vf.add       v23, v4, v20
    v.st.w       [s39, #0], v23
    a.vread      v4, a1, s41
    s.addi       s39, s29, #6272
    v.extract    s41, v2, #6
    v.splat      v20, s41
    v.ld.w       v23, [s26, #0]
    vf.mul       v24, v23, v21
    s.addi       s26, s30, #448
    vf.mul       v21, v24, v26
    s.movz       s41, #7
    vf.add       v23, v4, v21
    v.st.w       [s32, #0], v23
    a.vread      v4, a1, s35
    s.addi       s32, s29, #6336
    v.extract    s35, v2, #7
    v.splat      v21, s35
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v22
    s.addi       s34, s30, #512
    vf.mul       v22, v24, v26
    s.movz       s35, #8
    vf.add       v23, v4, v22
    v.st.w       [s27, #0], v23
    a.vread      v4, a1, s37
    s.addi       s27, s29, #6400
    v.extract    s37, v2, #8
    v.splat      v22, s37
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v18
    s.addi       s36, s30, #576
    vf.mul       v18, v24, v26
    s.movz       s37, #9
    vf.add       v23, v4, v18
    v.st.w       [s28, #0], v23
    a.vread      v4, a1, s38
    s.addi       s28, s29, #6464
    v.extract    s38, v2, #9
    v.splat      v18, s38
    v.ld.w       v23, [s40, #0]
    vf.mul       v24, v23, v19
    s.addi       s38, s30, #640
    vf.mul       v19, v24, v26
    s.movz       s40, #10
    vf.add       v23, v4, v19
    v.st.w       [s31, #0], v23
    a.vread      v4, a1, s42
    s.addi       s31, s29, #6528
    v.extract    s42, v2, #10
    v.splat      v19, s42
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v20
    s.addi       s39, s30, #704
    vf.mul       v20, v24, v26
    s.movz       s42, #11
    vf.add       v23, v4, v20
    v.st.w       [s33, #0], v23
    a.vread      v4, a1, s41
    s.addi       s33, s29, #6592
    v.extract    s41, v2, #11
    v.splat      v20, s41
    v.ld.w       v23, [s32, #0]
    vf.mul       v24, v23, v21
    s.addi       s32, s30, #768
    vf.mul       v21, v24, v26
    s.movz       s41, #12
    vf.add       v23, v4, v21
    v.st.w       [s26, #0], v23
    a.vread      v4, a1, s35
    s.addi       s26, s29, #6656
    v.extract    s35, v2, #12
    v.splat      v21, s35
    v.ld.w       v23, [s27, #0]
    vf.mul       v24, v23, v22
    s.addi       s27, s30, #832
    vf.mul       v22, v24, v26
    s.movz       s35, #13
    vf.add       v23, v4, v22
    v.st.w       [s34, #0], v23
    a.vread      v4, a1, s37
    s.addi       s34, s29, #6720
    v.extract    s37, v2, #13
    v.splat      v22, s37
    v.ld.w       v23, [s28, #0]
    vf.mul       v24, v23, v18
    s.addi       s28, s30, #896
    vf.mul       v18, v24, v26
    s.movz       s37, #14
    vf.add       v23, v4, v18
    v.st.w       [s36, #0], v23
    a.vread      v4, a1, s40
    s.addi       s36, s29, #6784
    v.extract    s40, v2, #14
    v.splat      v18, s40
    v.ld.w       v23, [s31, #0]
    vf.mul       v24, v23, v19
    s.addi       s31, s30, #960
    vf.mul       v19, v24, v26
    s.movz       s30, #15
    vf.add       v23, v4, v19
    v.st.w       [s38, #0], v23
    a.vread      v4, a1, s42
    s.addi       s38, s29, #6848
    v.extract    s40, v2, #15
    v.splat      v19, s40
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v20
    vf.mul       v20, v24, v26
    s.addi       s33, s29, #15104
    vf.add       v23, v4, v20
    s.movz       s40, #0
    v.st.w       [s39, #0], v23
    a.vread      v4, a1, s41
    s.addi       s39, s29, #6912
    v.extract    s41, v2, #0
    v.splat      v20, s41
    v.ld.w       v23, [s26, #0]
    vf.mul       v24, v23, v21
    vf.mul       v21, v24, v26
    s.addi       s26, s33, #64
    vf.add       v23, v4, v21
    s.movz       s41, #1
    v.st.w       [s32, #0], v23
    a.vread      v4, a1, s35
    s.addi       s32, s29, #6976
    v.extract    s35, v2, #1
    v.splat      v21, s35
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v22
    vf.mul       v22, v24, v26
    s.addi       s34, s33, #128
    vf.add       v23, v4, v22
    s.movz       s35, #2
    v.st.w       [s27, #0], v23
    a.vread      v4, a1, s37
    s.addi       s27, s29, #7040
    v.extract    s37, v2, #2
    v.splat      v22, s37
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v18
    vf.mul       v18, v24, v26
    s.addi       s36, s33, #192
    vf.add       v23, v4, v18
    s.movz       s37, #3
    v.st.w       [s28, #0], v23
    a.vread      v4, a1, s30
    s.addi       s28, s29, #7104
    v.extract    s30, v2, #3
    v.splat      v18, s30
    v.ld.w       v23, [s38, #0]
    vf.mul       v24, v23, v19
    vf.mul       v19, v24, v26
    s.addi       s30, s33, #256
    vf.add       v23, v4, v19
    s.movz       s38, #4
    v.st.w       [s31, #0], v23
    fence.acq_rel.device
    a.vread      v4, a2, s40
    s.addi       s31, s29, #7168
    v.extract    s40, v2, #4
    v.splat      v19, s40
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v20
    s.addi       s39, s33, #320
    vf.mul       v20, v24, v27
    s.movz       s40, #5
    vf.add       v23, v4, v20
    v.st.w       [s33, #0], v23
    a.vread      v4, a2, s41
    s.addi       s41, s29, #7232
    v.extract    s42, v2, #5
    v.splat      v20, s42
    v.ld.w       v23, [s32, #0]
    vf.mul       v24, v23, v21
    s.addi       s32, s33, #384
    vf.mul       v21, v24, v27
    s.movz       s42, #6
    vf.add       v23, v4, v21
    v.st.w       [s26, #0], v23
    a.vread      v4, a2, s35
    s.addi       s26, s29, #7296
    v.extract    s35, v2, #6
    v.splat      v21, s35
    v.ld.w       v23, [s27, #0]
    vf.mul       v24, v23, v22
    s.addi       s27, s33, #448
    vf.mul       v22, v24, v27
    s.movz       s35, #7
    vf.add       v23, v4, v22
    v.st.w       [s34, #0], v23
    a.vread      v4, a2, s37
    s.addi       s34, s29, #7360
    v.extract    s37, v2, #7
    v.splat      v22, s37
    v.ld.w       v23, [s28, #0]
    vf.mul       v24, v23, v18
    s.addi       s28, s33, #512
    vf.mul       v18, v24, v27
    s.movz       s37, #8
    vf.add       v23, v4, v18
    v.st.w       [s36, #0], v23
    a.vread      v4, a2, s38
    s.addi       s36, s29, #7424
    v.extract    s38, v2, #8
    v.splat      v18, s38
    v.ld.w       v23, [s31, #0]
    vf.mul       v24, v23, v19
    s.addi       s31, s33, #576
    vf.mul       v19, v24, v27
    s.movz       s38, #9
    vf.add       v23, v4, v19
    v.st.w       [s30, #0], v23
    a.vread      v4, a2, s40
    s.addi       s30, s29, #7488
    v.extract    s40, v2, #9
    v.splat      v19, s40
    v.ld.w       v23, [s41, #0]
    vf.mul       v24, v23, v20
    s.addi       s40, s33, #640
    vf.mul       v20, v24, v27
    s.movz       s41, #10
    vf.add       v23, v4, v20
    v.st.w       [s39, #0], v23
    a.vread      v4, a2, s42
    s.addi       s39, s29, #7552
    v.extract    s42, v2, #10
    v.splat      v20, s42
    v.ld.w       v23, [s26, #0]
    vf.mul       v24, v23, v21
    s.addi       s26, s33, #704
    vf.mul       v21, v24, v27
    s.movz       s42, #11
    vf.add       v23, v4, v21
    v.st.w       [s32, #0], v23
    a.vread      v4, a2, s35
    s.addi       s32, s29, #7616
    v.extract    s35, v2, #11
    v.splat      v21, s35
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v22
    s.addi       s34, s33, #768
    vf.mul       v22, v24, v27
    s.movz       s35, #12
    vf.add       v23, v4, v22
    v.st.w       [s27, #0], v23
    a.vread      v4, a2, s37
    s.addi       s27, s29, #7680
    v.extract    s37, v2, #12
    v.splat      v22, s37
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v18
    s.addi       s36, s33, #832
    vf.mul       v18, v24, v27
    s.movz       s37, #13
    vf.add       v23, v4, v18
    v.st.w       [s28, #0], v23
    a.vread      v4, a2, s38
    s.addi       s28, s29, #7744
    v.extract    s38, v2, #13
    v.splat      v18, s38
    v.ld.w       v23, [s30, #0]
    vf.mul       v24, v23, v19
    s.addi       s30, s33, #896
    vf.mul       v19, v24, v27
    s.movz       s38, #14
    vf.add       v23, v4, v19
    v.st.w       [s31, #0], v23
    a.vread      v4, a2, s41
    s.addi       s31, s29, #7808
    v.extract    s41, v2, #14
    v.splat      v19, s41
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v20
    s.addi       s39, s33, #960
    vf.mul       v20, v24, v27
    s.movz       s33, #15
    vf.add       v23, v4, v20
    v.st.w       [s40, #0], v23
    a.vread      v4, a2, s42
    s.addi       s40, s29, #7872
    v.extract    s41, v2, #15
    v.splat      v20, s41
    v.ld.w       v23, [s32, #0]
    vf.mul       v24, v23, v21
    vf.mul       v21, v24, v27
    s.addi       s32, s29, #16128
    vf.add       v23, v4, v21
    s.movz       s41, #0
    v.st.w       [s26, #0], v23
    a.vread      v4, a2, s35
    s.addi       s26, s29, #7936
    v.extract    s35, v2, #0
    v.splat      v21, s35
    v.ld.w       v23, [s27, #0]
    vf.mul       v24, v23, v22
    vf.mul       v22, v24, v27
    s.addi       s27, s32, #64
    vf.add       v23, v4, v22
    s.movz       s35, #1
    v.st.w       [s34, #0], v23
    a.vread      v4, a2, s37
    s.addi       s34, s29, #8000
    v.extract    s37, v2, #1
    v.splat      v22, s37
    v.ld.w       v23, [s28, #0]
    vf.mul       v24, v23, v18
    vf.mul       v18, v24, v27
    s.addi       s28, s32, #128
    vf.add       v23, v4, v18
    s.movz       s37, #2
    v.st.w       [s36, #0], v23
    a.vread      v4, a2, s38
    s.addi       s36, s29, #8064
    v.extract    s38, v2, #2
    v.splat      v18, s38
    v.ld.w       v23, [s31, #0]
    vf.mul       v24, v23, v19
    vf.mul       v19, v24, v27
    s.addi       s31, s32, #192
    vf.add       v23, v4, v19
    s.movz       s38, #3
    v.st.w       [s30, #0], v23
    a.vread      v4, a2, s33
    s.addi       s30, s29, #8128
    v.extract    s33, v2, #3
    v.splat      v19, s33
    v.ld.w       v23, [s40, #0]
    vf.mul       v24, v23, v20
    vf.mul       v20, v24, v27
    s.addi       s33, s32, #256
    vf.add       v23, v4, v20
    s.movz       s40, #4
    v.st.w       [s39, #0], v23
    fence.acq_rel.device
    a.vread      v4, a3, s41
    s.addi       s39, s29, #8192
    v.extract    s41, v2, #4
    v.splat      v20, s41
    v.ld.w       v23, [s26, #0]
    vf.mul       v24, v23, v21
    s.addi       s26, s32, #320
    vf.mul       v21, v24, v28
    s.movz       s41, #5
    vf.add       v23, v4, v21
    v.st.w       [s32, #0], v23
    a.vread      v4, a3, s35
    s.addi       s35, s29, #8256
    v.extract    s42, v2, #5
    v.splat      v21, s42
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v22
    s.addi       s34, s32, #384
    vf.mul       v22, v24, v28
    s.movz       s42, #6
    vf.add       v23, v4, v22
    v.st.w       [s27, #0], v23
    a.vread      v4, a3, s37
    s.addi       s27, s29, #8320
    v.extract    s37, v2, #6
    v.splat      v22, s37
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v18
    s.addi       s36, s32, #448
    vf.mul       v18, v24, v28
    s.movz       s37, #7
    vf.add       v23, v4, v18
    v.st.w       [s28, #0], v23
    a.vread      v4, a3, s38
    s.addi       s28, s29, #8384
    v.extract    s38, v2, #7
    v.splat      v18, s38
    v.ld.w       v23, [s30, #0]
    vf.mul       v24, v23, v19
    s.addi       s30, s32, #512
    vf.mul       v19, v24, v28
    s.movz       s38, #8
    vf.add       v23, v4, v19
    v.st.w       [s31, #0], v23
    a.vread      v4, a3, s40
    s.addi       s31, s29, #8448
    v.extract    s40, v2, #8
    v.splat      v19, s40
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v20
    s.addi       s39, s32, #576
    vf.mul       v20, v24, v28
    s.movz       s40, #9
    vf.add       v23, v4, v20
    v.st.w       [s33, #0], v23
    a.vread      v4, a3, s41
    s.addi       s33, s29, #8512
    v.extract    s41, v2, #9
    v.splat      v20, s41
    v.ld.w       v23, [s35, #0]
    vf.mul       v24, v23, v21
    s.addi       s35, s32, #640
    vf.mul       v21, v24, v28
    s.movz       s41, #10
    vf.add       v23, v4, v21
    v.st.w       [s26, #0], v23
    a.vread      v4, a3, s42
    s.addi       s26, s29, #8576
    v.extract    s42, v2, #10
    v.splat      v21, s42
    v.ld.w       v23, [s27, #0]
    vf.mul       v24, v23, v22
    s.addi       s27, s32, #704
    vf.mul       v22, v24, v28
    s.movz       s42, #11
    vf.add       v23, v4, v22
    v.st.w       [s34, #0], v23
    a.vread      v4, a3, s37
    s.addi       s34, s29, #8640
    v.extract    s37, v2, #11
    v.splat      v22, s37
    v.ld.w       v23, [s28, #0]
    vf.mul       v24, v23, v18
    s.addi       s28, s32, #768
    vf.mul       v18, v24, v28
    s.movz       s37, #12
    vf.add       v23, v4, v18
    v.st.w       [s36, #0], v23
    a.vread      v4, a3, s38
    s.addi       s36, s29, #8704
    v.extract    s38, v2, #12
    v.splat      v18, s38
    v.ld.w       v23, [s31, #0]
    vf.mul       v24, v23, v19
    s.addi       s31, s32, #832
    vf.mul       v19, v24, v28
    s.movz       s38, #13
    vf.add       v23, v4, v19
    v.st.w       [s30, #0], v23
    a.vread      v4, a3, s40
    s.addi       s30, s29, #8768
    v.extract    s40, v2, #13
    v.splat      v19, s40
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v20
    s.addi       s33, s32, #896
    vf.mul       v20, v24, v28
    s.movz       s40, #14
    vf.add       v23, v4, v20
    v.st.w       [s39, #0], v23
    a.vread      v4, a3, s41
    s.addi       s39, s29, #8832
    v.extract    s41, v2, #14
    v.splat      v20, s41
    v.ld.w       v23, [s26, #0]
    vf.mul       v24, v23, v21
    s.addi       s26, s32, #960
    vf.mul       v21, v24, v28
    s.movz       s32, #15
    vf.add       v23, v4, v21
    v.st.w       [s35, #0], v23
    a.vread      v4, a3, s42
    s.addi       s35, s29, #8896
    v.extract    s41, v2, #15
    v.splat      v21, s41
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v22
    vf.mul       v22, v24, v28
    s.addi       s34, s29, #17152
    vf.add       v23, v4, v22
    s.movz       s41, #0
    v.st.w       [s27, #0], v23
    a.vread      v4, a3, s37
    s.addi       s27, s29, #8960
    v.extract    s37, v2, #0
    v.splat      v22, s37
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v18
    vf.mul       v18, v24, v28
    s.addi       s36, s34, #64
    vf.add       v23, v4, v18
    s.movz       s37, #1
    v.st.w       [s28, #0], v23
    a.vread      v4, a3, s38
    s.addi       s28, s29, #9024
    v.extract    s38, v2, #1
    v.splat      v18, s38
    v.ld.w       v23, [s30, #0]
    vf.mul       v24, v23, v19
    vf.mul       v19, v24, v28
    s.addi       s30, s34, #128
    vf.add       v23, v4, v19
    s.movz       s38, #2
    v.st.w       [s31, #0], v23
    a.vread      v4, a3, s40
    s.addi       s31, s29, #9088
    v.extract    s40, v2, #2
    v.splat      v19, s40
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v20
    vf.mul       v20, v24, v28
    s.addi       s39, s34, #192
    vf.add       v23, v4, v20
    s.movz       s40, #3
    v.st.w       [s33, #0], v23
    a.vread      v4, a3, s32
    s.addi       s32, s29, #9152
    v.extract    s33, v2, #3
    v.splat      v20, s33
    v.ld.w       v23, [s35, #0]
    vf.mul       v24, v23, v21
    vf.mul       v21, v24, v28
    s.addi       s33, s34, #256
    vf.add       v23, v4, v21
    s.movz       s35, #4
    v.st.w       [s26, #0], v23
    fence.acq_rel.device
    a.vread      v4, a4, s41
    s.addi       s26, s29, #9216
    v.extract    s41, v2, #4
    v.splat      v21, s41
    v.ld.w       v23, [s27, #0]
    vf.mul       v24, v23, v22
    s.addi       s27, s34, #320
    vf.mul       v22, v24, v29
    s.movz       s41, #5
    vf.add       v23, v4, v22
    v.st.w       [s34, #0], v23
    a.vread      v4, a4, s37
    s.addi       s37, s29, #9280
    v.extract    s42, v2, #5
    v.splat      v22, s42
    v.ld.w       v23, [s28, #0]
    vf.mul       v24, v23, v18
    s.addi       s28, s34, #384
    vf.mul       v18, v24, v29
    s.movz       s42, #6
    vf.add       v23, v4, v18
    v.st.w       [s36, #0], v23
    a.vread      v4, a4, s38
    s.addi       s36, s29, #9344
    v.extract    s38, v2, #6
    v.splat      v18, s38
    v.ld.w       v23, [s31, #0]
    vf.mul       v24, v23, v19
    s.addi       s31, s34, #448
    vf.mul       v19, v24, v29
    s.movz       s38, #7
    vf.add       v23, v4, v19
    v.st.w       [s30, #0], v23
    a.vread      v4, a4, s40
    s.addi       s30, s29, #9408
    v.extract    s40, v2, #7
    v.splat      v19, s40
    v.ld.w       v23, [s32, #0]
    vf.mul       v24, v23, v20
    s.addi       s32, s34, #512
    vf.mul       v20, v24, v29
    s.movz       s40, #8
    vf.add       v23, v4, v20
    v.st.w       [s39, #0], v23
    a.vread      v4, a4, s35
    s.addi       s35, s29, #9472
    v.extract    s39, v2, #8
    v.splat      v20, s39
    v.ld.w       v23, [s26, #0]
    vf.mul       v24, v23, v21
    s.addi       s26, s34, #576
    vf.mul       v21, v24, v29
    s.movz       s39, #9
    vf.add       v23, v4, v21
    v.st.w       [s33, #0], v23
    a.vread      v4, a4, s41
    s.addi       s33, s29, #9536
    v.extract    s41, v2, #9
    v.splat      v21, s41
    v.ld.w       v23, [s37, #0]
    vf.mul       v24, v23, v22
    s.addi       s37, s34, #640
    vf.mul       v22, v24, v29
    s.movz       s41, #10
    vf.add       v23, v4, v22
    v.st.w       [s27, #0], v23
    a.vread      v4, a4, s42
    s.addi       s27, s29, #9600
    v.extract    s42, v2, #10
    v.splat      v22, s42
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v18
    s.addi       s36, s34, #704
    vf.mul       v18, v24, v29
    s.movz       s42, #11
    vf.add       v23, v4, v18
    v.st.w       [s28, #0], v23
    a.vread      v4, a4, s38
    s.addi       s28, s29, #9664
    v.extract    s38, v2, #11
    v.splat      v18, s38
    v.ld.w       v23, [s30, #0]
    vf.mul       v24, v23, v19
    s.addi       s30, s34, #768
    vf.mul       v19, v24, v29
    s.movz       s38, #12
    vf.add       v23, v4, v19
    v.st.w       [s31, #0], v23
    a.vread      v4, a4, s40
    s.addi       s31, s29, #9728
    v.extract    s40, v2, #12
    v.splat      v19, s40
    v.ld.w       v23, [s35, #0]
    vf.mul       v24, v23, v20
    s.addi       s35, s34, #832
    vf.mul       v20, v24, v29
    s.movz       s40, #13
    vf.add       v23, v4, v20
    v.st.w       [s32, #0], v23
    a.vread      v4, a4, s39
    s.addi       s32, s29, #9792
    v.extract    s39, v2, #13
    v.splat      v20, s39
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v21
    s.addi       s33, s34, #896
    vf.mul       v21, v24, v29
    s.movz       s39, #14
    vf.add       v23, v4, v21
    v.st.w       [s26, #0], v23
    a.vread      v4, a4, s41
    s.addi       s26, s29, #9856
    v.extract    s41, v2, #14
    v.splat      v21, s41
    v.ld.w       v23, [s27, #0]
    vf.mul       v24, v23, v22
    s.addi       s27, s34, #960
    vf.mul       v22, v24, v29
    s.movz       s34, #15
    vf.add       v23, v4, v22
    v.st.w       [s37, #0], v23
    a.vread      v4, a4, s42
    s.addi       s37, s29, #9920
    v.extract    s41, v2, #15
    v.splat      v22, s41
    v.ld.w       v23, [s28, #0]
    vf.mul       v24, v23, v18
    vf.mul       v18, v24, v29
    s.addi       s28, s29, #18176
    vf.add       v23, v4, v18
    s.movz       s41, #0
    v.st.w       [s36, #0], v23
    a.vread      v4, a4, s38
    s.addi       s36, s29, #9984
    v.extract    s38, v2, #0
    v.splat      v18, s38
    v.ld.w       v23, [s31, #0]
    vf.mul       v24, v23, v19
    vf.mul       v19, v24, v29
    s.addi       s31, s28, #64
    vf.add       v23, v4, v19
    s.movz       s38, #1
    v.st.w       [s30, #0], v23
    a.vread      v4, a4, s40
    s.addi       s30, s29, #10048
    v.extract    s40, v2, #1
    v.splat      v19, s40
    v.ld.w       v23, [s32, #0]
    vf.mul       v24, v23, v20
    vf.mul       v20, v24, v29
    s.addi       s32, s28, #128
    vf.add       v23, v4, v20
    s.movz       s40, #2
    v.st.w       [s35, #0], v23
    a.vread      v4, a4, s39
    s.addi       s35, s29, #10112
    v.extract    s39, v2, #2
    v.splat      v20, s39
    v.ld.w       v23, [s26, #0]
    vf.mul       v24, v23, v21
    vf.mul       v21, v24, v29
    s.addi       s26, s28, #192
    vf.add       v23, v4, v21
    s.movz       s39, #3
    v.st.w       [s33, #0], v23
    a.vread      v4, a4, s34
    s.addi       s33, s29, #10176
    v.extract    s34, v2, #3
    v.splat      v21, s34
    v.ld.w       v23, [s37, #0]
    vf.mul       v24, v23, v22
    vf.mul       v22, v24, v29
    s.addi       s34, s28, #256
    vf.add       v23, v4, v22
    s.movz       s37, #4
    v.st.w       [s27, #0], v23
    fence.acq_rel.device
    a.vread      v4, a5, s41
    s.addi       s27, s29, #10240
    v.extract    s41, v2, #4
    v.splat      v22, s41
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v18
    s.addi       s36, s28, #320
    vf.mul       v18, v24, v30
    s.movz       s41, #5
    vf.add       v23, v4, v18
    v.st.w       [s28, #0], v23
    a.vread      v4, a5, s38
    s.addi       s38, s29, #10304
    v.extract    s42, v2, #5
    v.splat      v18, s42
    v.ld.w       v23, [s30, #0]
    vf.mul       v24, v23, v19
    s.addi       s30, s28, #384
    vf.mul       v19, v24, v30
    s.movz       s42, #6
    vf.add       v23, v4, v19
    v.st.w       [s31, #0], v23
    a.vread      v4, a5, s40
    s.addi       s31, s29, #10368
    v.extract    s40, v2, #6
    v.splat      v19, s40
    v.ld.w       v23, [s35, #0]
    vf.mul       v24, v23, v20
    s.addi       s35, s28, #448
    vf.mul       v20, v24, v30
    s.movz       s40, #7
    vf.add       v23, v4, v20
    v.st.w       [s32, #0], v23
    a.vread      v4, a5, s39
    s.addi       s32, s29, #10432
    v.extract    s39, v2, #7
    v.splat      v20, s39
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v21
    s.addi       s33, s28, #512
    vf.mul       v21, v24, v30
    s.movz       s39, #8
    vf.add       v23, v4, v21
    v.st.w       [s26, #0], v23
    a.vread      v4, a5, s37
    s.addi       s26, s29, #10496
    v.extract    s37, v2, #8
    v.splat      v21, s37
    v.ld.w       v23, [s27, #0]
    vf.mul       v24, v23, v22
    s.addi       s27, s28, #576
    vf.mul       v22, v24, v30
    s.movz       s37, #9
    vf.add       v23, v4, v22
    v.st.w       [s34, #0], v23
    a.vread      v4, a5, s41
    s.addi       s34, s29, #10560
    v.extract    s41, v2, #9
    v.splat      v22, s41
    v.ld.w       v23, [s38, #0]
    vf.mul       v24, v23, v18
    s.addi       s38, s28, #640
    vf.mul       v18, v24, v30
    s.movz       s41, #10
    vf.add       v23, v4, v18
    v.st.w       [s36, #0], v23
    a.vread      v4, a5, s42
    s.addi       s36, s29, #10624
    v.extract    s42, v2, #10
    v.splat      v18, s42
    v.ld.w       v23, [s31, #0]
    vf.mul       v24, v23, v19
    s.addi       s31, s28, #704
    vf.mul       v19, v24, v30
    s.movz       s42, #11
    vf.add       v23, v4, v19
    v.st.w       [s30, #0], v23
    a.vread      v4, a5, s40
    s.addi       s30, s29, #10688
    v.extract    s40, v2, #11
    v.splat      v19, s40
    v.ld.w       v23, [s32, #0]
    vf.mul       v24, v23, v20
    s.addi       s32, s28, #768
    vf.mul       v20, v24, v30
    s.movz       s40, #12
    vf.add       v23, v4, v20
    v.st.w       [s35, #0], v23
    a.vread      v4, a5, s39
    s.addi       s35, s29, #10752
    v.extract    s39, v2, #12
    v.splat      v20, s39
    v.ld.w       v23, [s26, #0]
    vf.mul       v24, v23, v21
    s.addi       s26, s28, #832
    vf.mul       v21, v24, v30
    s.movz       s39, #13
    vf.add       v23, v4, v21
    v.st.w       [s33, #0], v23
    a.vread      v4, a5, s37
    s.addi       s33, s29, #10816
    v.extract    s37, v2, #13
    v.splat      v21, s37
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v22
    s.addi       s34, s28, #896
    vf.mul       v22, v24, v30
    s.movz       s37, #14
    vf.add       v23, v4, v22
    v.st.w       [s27, #0], v23
    a.vread      v4, a5, s41
    s.addi       s27, s29, #10880
    v.extract    s41, v2, #14
    v.splat      v22, s41
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v18
    s.addi       s36, s28, #960
    vf.mul       v18, v24, v30
    s.movz       s28, #15
    vf.add       v23, v4, v18
    v.st.w       [s38, #0], v23
    a.vread      v4, a5, s42
    s.addi       s38, s29, #10944
    v.extract    s41, v2, #15
    v.splat      v18, s41
    v.ld.w       v23, [s30, #0]
    vf.mul       v24, v23, v19
    vf.mul       v19, v24, v30
    s.addi       s30, s29, #19200
    vf.add       v23, v4, v19
    s.movz       s41, #0
    v.st.w       [s31, #0], v23
    a.vread      v4, a5, s40
    s.addi       s31, s29, #11008
    v.extract    s40, v2, #0
    v.splat      v19, s40
    v.ld.w       v23, [s35, #0]
    vf.mul       v24, v23, v20
    vf.mul       v20, v24, v30
    s.addi       s35, s30, #64
    vf.add       v23, v4, v20
    s.movz       s40, #1
    v.st.w       [s32, #0], v23
    a.vread      v4, a5, s39
    s.addi       s32, s29, #11072
    v.extract    s39, v2, #1
    v.splat      v20, s39
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v21
    vf.mul       v21, v24, v30
    s.addi       s33, s30, #128
    vf.add       v23, v4, v21
    s.movz       s39, #2
    v.st.w       [s26, #0], v23
    a.vread      v4, a5, s37
    s.addi       s26, s29, #11136
    v.extract    s37, v2, #2
    v.splat      v21, s37
    v.ld.w       v23, [s27, #0]
    vf.mul       v24, v23, v22
    vf.mul       v22, v24, v30
    s.addi       s27, s30, #192
    vf.add       v23, v4, v22
    s.movz       s37, #3
    v.st.w       [s34, #0], v23
    a.vread      v4, a5, s28
    s.addi       s28, s29, #11200
    v.extract    s34, v2, #3
    v.splat      v22, s34
    v.ld.w       v23, [s38, #0]
    vf.mul       v24, v23, v18
    vf.mul       v18, v24, v30
    s.addi       s34, s30, #256
    vf.add       v23, v4, v18
    s.movz       s38, #4
    v.st.w       [s36, #0], v23
    fence.acq_rel.device
    a.vread      v4, a6, s41
    s.addi       s36, s29, #11264
    v.extract    s41, v2, #4
    v.splat      v18, s41
    v.ld.w       v23, [s31, #0]
    vf.mul       v24, v23, v19
    s.addi       s31, s30, #320
    vf.mul       v19, v24, v31
    s.movz       s41, #5
    vf.add       v23, v4, v19
    v.st.w       [s30, #0], v23
    a.vread      v4, a6, s40
    s.addi       s40, s29, #11328
    v.extract    s42, v2, #5
    v.splat      v19, s42
    v.ld.w       v23, [s32, #0]
    vf.mul       v24, v23, v20
    s.addi       s32, s30, #384
    vf.mul       v20, v24, v31
    s.movz       s42, #6
    vf.add       v23, v4, v20
    v.st.w       [s35, #0], v23
    a.vread      v4, a6, s39
    s.addi       s35, s29, #11392
    v.extract    s39, v2, #6
    v.splat      v20, s39
    v.ld.w       v23, [s26, #0]
    vf.mul       v24, v23, v21
    s.addi       s26, s30, #448
    vf.mul       v21, v24, v31
    s.movz       s39, #7
    vf.add       v23, v4, v21
    v.st.w       [s33, #0], v23
    a.vread      v4, a6, s37
    s.addi       s33, s29, #11456
    v.extract    s37, v2, #7
    v.splat      v21, s37
    v.ld.w       v23, [s28, #0]
    vf.mul       v24, v23, v22
    s.addi       s28, s30, #512
    vf.mul       v22, v24, v31
    s.movz       s37, #8
    vf.add       v23, v4, v22
    v.st.w       [s27, #0], v23
    a.vread      v4, a6, s38
    s.addi       s27, s29, #11520
    v.extract    s38, v2, #8
    v.splat      v22, s38
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v18
    s.addi       s36, s30, #576
    vf.mul       v18, v24, v31
    s.movz       s38, #9
    vf.add       v23, v4, v18
    v.st.w       [s34, #0], v23
    a.vread      v4, a6, s41
    s.addi       s34, s29, #11584
    v.extract    s41, v2, #9
    v.splat      v18, s41
    v.ld.w       v23, [s40, #0]
    vf.mul       v24, v23, v19
    s.addi       s40, s30, #640
    vf.mul       v19, v24, v31
    s.movz       s41, #10
    vf.add       v23, v4, v19
    v.st.w       [s31, #0], v23
    a.vread      v4, a6, s42
    s.addi       s31, s29, #11648
    v.extract    s42, v2, #10
    v.splat      v19, s42
    v.ld.w       v23, [s35, #0]
    vf.mul       v24, v23, v20
    s.addi       s35, s30, #704
    vf.mul       v20, v24, v31
    s.movz       s42, #11
    vf.add       v23, v4, v20
    v.st.w       [s32, #0], v23
    a.vread      v4, a6, s39
    s.addi       s32, s29, #11712
    v.extract    s39, v2, #11
    v.splat      v20, s39
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v21
    s.addi       s33, s30, #768
    vf.mul       v21, v24, v31
    s.movz       s39, #12
    vf.add       v23, v4, v21
    v.st.w       [s26, #0], v23
    a.vread      v4, a6, s37
    s.addi       s26, s29, #11776
    v.extract    s37, v2, #12
    v.splat      v21, s37
    v.ld.w       v23, [s27, #0]
    vf.mul       v24, v23, v22
    s.addi       s27, s30, #832
    vf.mul       v22, v24, v31
    s.movz       s37, #13
    vf.add       v23, v4, v22
    v.st.w       [s28, #0], v23
    a.vread      v4, a6, s38
    s.addi       s28, s29, #11840
    v.extract    s38, v2, #13
    v.splat      v22, s38
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v18
    s.addi       s34, s30, #896
    vf.mul       v18, v24, v31
    s.movz       s38, #14
    vf.add       v23, v4, v18
    v.st.w       [s36, #0], v23
    a.vread      v4, a6, s41
    s.addi       s36, s29, #11904
    v.extract    s41, v2, #14
    v.splat      v18, s41
    v.ld.w       v23, [s31, #0]
    vf.mul       v24, v23, v19
    s.addi       s31, s30, #960
    vf.mul       v19, v24, v31
    s.movz       s30, #15
    vf.add       v23, v4, v19
    v.st.w       [s40, #0], v23
    a.vread      v4, a6, s42
    s.addi       s40, s29, #11968
    v.extract    s41, v2, #15
    v.splat      v19, s41
    v.ld.w       v23, [s32, #0]
    vf.mul       v24, v23, v20
    vf.mul       v20, v24, v31
    s.addi       s32, s29, #20224
    vf.add       v23, v4, v20
    s.movz       s41, #0
    v.st.w       [s35, #0], v23
    a.vread      v4, a6, s39
    s.addi       s35, s29, #12032
    v.extract    s39, v2, #0
    v.splat      v20, s39
    v.ld.w       v23, [s26, #0]
    vf.mul       v24, v23, v21
    vf.mul       v21, v24, v31
    s.addi       s26, s32, #64
    vf.add       v23, v4, v21
    s.movz       s39, #1
    v.st.w       [s33, #0], v23
    a.vread      v4, a6, s37
    s.addi       s33, s29, #12096
    v.extract    s37, v2, #1
    v.splat      v21, s37
    v.ld.w       v23, [s28, #0]
    vf.mul       v24, v23, v22
    vf.mul       v22, v24, v31
    s.addi       s28, s32, #128
    vf.add       v23, v4, v22
    s.movz       s37, #2
    v.st.w       [s27, #0], v23
    a.vread      v4, a6, s38
    s.addi       s27, s29, #12160
    v.extract    s38, v2, #2
    v.splat      v22, s38
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v18
    vf.mul       v18, v24, v31
    s.addi       s36, s32, #192
    vf.add       v23, v4, v18
    s.movz       s38, #3
    v.st.w       [s34, #0], v23
    a.vread      v4, a6, s30
    s.addi       s30, s29, #12224
    v.extract    s34, v2, #3
    v.splat      v18, s34
    v.ld.w       v23, [s40, #0]
    vf.mul       v24, v23, v19
    vf.mul       v19, v24, v31
    s.addi       s34, s32, #256
    vf.add       v23, v4, v19
    s.movz       s40, #4
    v.st.w       [s31, #0], v23
    fence.acq_rel.device
    a.vread      v4, a7, s41
    s.addi       s31, s29, #12288
    v.extract    s41, v2, #4
    v.splat      v19, s41
    v.ld.w       v23, [s35, #0]
    vf.mul       v24, v23, v20
    s.addi       s35, s32, #320
    vf.mul       v20, v24, v32
    s.movz       s41, #5
    vf.add       v23, v4, v20
    v.st.w       [s32, #0], v23
    a.vread      v4, a7, s39
    s.addi       s39, s29, #12352
    v.extract    s42, v2, #5
    v.splat      v20, s42
    v.ld.w       v23, [s33, #0]
    vf.mul       v24, v23, v21
    s.addi       s33, s32, #384
    vf.mul       v21, v24, v32
    s.movz       s42, #6
    vf.add       v23, v4, v21
    v.st.w       [s26, #0], v23
    a.vread      v4, a7, s37
    s.addi       s26, s29, #12416
    v.extract    s37, v2, #6
    v.splat      v21, s37
    v.ld.w       v23, [s27, #0]
    vf.mul       v24, v23, v22
    s.addi       s27, s32, #448
    vf.mul       v22, v24, v32
    s.movz       s37, #7
    vf.add       v23, v4, v22
    v.st.w       [s28, #0], v23
    a.vread      v4, a7, s38
    s.addi       s28, s29, #12480
    v.extract    s38, v2, #7
    v.splat      v22, s38
    v.ld.w       v23, [s30, #0]
    vf.mul       v24, v23, v18
    s.addi       s30, s32, #512
    vf.mul       v18, v24, v32
    s.movz       s38, #8
    vf.add       v23, v4, v18
    v.st.w       [s36, #0], v23
    a.vread      v4, a7, s40
    s.addi       s36, s29, #12544
    v.extract    s40, v2, #8
    v.splat      v18, s40
    v.ld.w       v23, [s31, #0]
    vf.mul       v24, v23, v19
    s.addi       s31, s32, #576
    vf.mul       v19, v24, v32
    s.movz       s40, #9
    vf.add       v23, v4, v19
    v.st.w       [s34, #0], v23
    a.vread      v4, a7, s41
    s.addi       s34, s29, #12608
    v.extract    s41, v2, #9
    v.splat      v19, s41
    v.ld.w       v23, [s39, #0]
    vf.mul       v24, v23, v20
    s.addi       s39, s32, #640
    vf.mul       v20, v24, v32
    s.movz       s41, #10
    vf.add       v23, v4, v20
    v.st.w       [s35, #0], v23
    a.vread      v4, a7, s42
    s.addi       s35, s29, #12672
    v.extract    s42, v2, #10
    v.splat      v20, s42
    v.ld.w       v23, [s26, #0]
    vf.mul       v24, v23, v21
    s.addi       s26, s32, #704
    vf.mul       v21, v24, v32
    s.movz       s42, #11
    vf.add       v23, v4, v21
    v.st.w       [s33, #0], v23
    a.vread      v4, a7, s37
    s.addi       s33, s29, #12736
    v.extract    s37, v2, #11
    v.splat      v21, s37
    v.ld.w       v23, [s28, #0]
    vf.mul       v24, v23, v22
    s.addi       s28, s32, #768
    vf.mul       v22, v24, v32
    s.movz       s37, #12
    vf.add       v23, v4, v22
    v.st.w       [s27, #0], v23
    a.vread      v4, a7, s38
    s.addi       s27, s29, #12800
    v.extract    s38, v2, #12
    v.splat      v22, s38
    v.ld.w       v23, [s36, #0]
    vf.mul       v24, v23, v18
    s.addi       s36, s32, #832
    vf.mul       v18, v24, v32
    s.movz       s38, #13
    vf.add       v23, v4, v18
    v.st.w       [s30, #0], v23
    a.vread      v4, a7, s40
    s.addi       s30, s29, #12864
    v.extract    s40, v2, #13
    v.splat      v18, s40
    v.ld.w       v23, [s34, #0]
    vf.mul       v24, v23, v19
    s.addi       s34, s32, #896
    vf.mul       v19, v24, v32
    s.movz       s40, #14
    vf.add       v23, v4, v19
    v.st.w       [s31, #0], v23
    a.vread      v4, a7, s41
    s.addi       s31, s29, #12928
    v.extract    s41, v2, #14
    v.splat      v19, s41
    v.ld.w       v23, [s35, #0]
    vf.mul       v24, v23, v20
    s.addi       s35, s32, #960
    vf.mul       v20, v24, v32
    s.movz       s32, #15
    vf.add       v23, v4, v20
    v.st.w       [s39, #0], v23
    a.vread      v4, a7, s42
    s.addi       s39, s29, #12992
    v.extract    s41, v2, #15
    v.splat      v2, s41
    v.ld.w       v20, [s33, #0]
    vf.mul       v23, v20, v21
    vf.mul       v20, v23, v32
    s.addi       s33, s18, #128
    vf.add       v21, v4, v20
    s.addi       s41, s33, #0
    v.st.w       [s26, #0], v21
    a.vread      v4, a7, s37
    s.addi       s26, s25, #128
    s.movz       s33, #0
    s.addi       s37, s26, #0
    v.ld.w       v20, [s27, #0]
    s.addi       s26, s29, #13056
    vf.mul       v21, v20, v22
    s.movz       s27, #1
    vf.mul       v20, v21, v32
    s.addi       s42, s29, #13120
    vf.add       v21, v4, v20
    v.st.w       [s28, #0], v21
    a.vread      v4, a7, s38
    s.addi       s28, s29, #13184
    s.movz       s38, #2
    v.ld.w       v20, [s30, #0]
    s.addi       s30, s29, #13248
    s.movz       s43, #3
    vf.mul       v21, v20, v18
    vf.mul       v18, v21, v32
    s.movz       s44, #4
    vf.add       v20, v4, v18
    s.addi       s45, s29, #13312
    v.st.w       [s36, #0], v20
    a.vread      v4, a7, s40
    s.addi       s36, s29, #13376
    s.movz       s40, #5
    v.ld.w       v18, [s31, #0]
    s.addi       s31, s29, #13440
    vf.mul       v20, v18, v19
    vf.mul       v18, v20, v32
    vf.add       v19, v4, v18
    v.st.w       [s34, #0], v19
    a.vread      v4, a7, s32
    s.movz       s32, #6
    s.addi       s34, s29, #13504
    v.ld.w       v18, [s39, #0]
    s.movz       s39, #7
    vf.mul       v19, v18, v2
    vf.mul       v2, v19, v32
    vf.add       v18, v4, v2
    v.st.w       [s35, #0], v18
    fence.acq_rel.device
    s.mov        s18, s41
    s.mov        s25, s37
    s.addi       s35, s29, #13568
    s.movz       s37, #8
    s.addi       s41, s29, #13632
    s.movz       s46, #9
    s.addi       s47, s29, #13696
    v.ld.w       v2, [s26, #0]
    s.movz       s26, #10
    a.vwrite     a0, s33, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s29, #13760
    a.vwrite     a0, s27, v2
    v.ld.w       v2, [s28, #0]
    s.movz       s28, #11
    a.vwrite     a0, s38, v2
    v.ld.w       v2, [s30, #0]
    s.addi       s30, s29, #13824
    a.vwrite     a0, s43, v2
    v.ld.w       v2, [s45, #0]
    s.movz       s45, #12
    a.vwrite     a0, s44, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s29, #13888
    a.vwrite     a0, s40, v2
    v.ld.w       v2, [s31, #0]
    s.movz       s31, #13
    a.vwrite     a0, s32, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s29, #13952
    a.vwrite     a0, s39, v2
    v.ld.w       v2, [s35, #0]
    s.movz       s35, #14
    a.vwrite     a0, s37, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s29, #14016
    a.vwrite     a0, s46, v2
    v.ld.w       v2, [s47, #0]
    s.movz       s47, #15
    a.vwrite     a0, s26, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s29, #14080
    a.vwrite     a0, s28, v2
    v.ld.w       v2, [s30, #0]
    s.addi       s30, s29, #14144
    a.vwrite     a0, s45, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s29, #14208
    a.vwrite     a0, s31, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s29, #14272
    a.vwrite     a0, s35, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s29, #14336
    a.vwrite     a0, s47, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s29, #14400
    a.vwrite     a1, s33, v2
    v.ld.w       v2, [s30, #0]
    s.addi       s30, s29, #14464
    s.addi       s33, s29, #14528
    a.vwrite     a1, s27, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s27, s29, #14592
    s.addi       s36, s29, #14656
    a.vwrite     a1, s38, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s29, #14720
    s.addi       s38, s29, #14784
    a.vwrite     a1, s43, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s41, s29, #14848
    s.addi       s43, s29, #14912
    a.vwrite     a1, s44, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s42, s29, #14976
    s.addi       s44, s29, #15040
    a.vwrite     a1, s40, v2
    v.ld.w       v2, [s30, #0]
    s.addi       s30, s29, #15104
    s.movz       s40, #0
    a.vwrite     a1, s32, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s32, s29, #15168
    s.movz       s33, #1
    a.vwrite     a1, s39, v2
    v.ld.w       v2, [s27, #0]
    s.addi       s27, s29, #15232
    s.movz       s39, #2
    a.vwrite     a1, s37, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s29, #15296
    s.movz       s37, #3
    a.vwrite     a1, s46, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s29, #15360
    s.movz       s46, #4
    a.vwrite     a1, s26, v2
    v.ld.w       v2, [s38, #0]
    s.addi       s26, s29, #15424
    s.movz       s38, #5
    a.vwrite     a1, s28, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s28, s29, #15488
    s.movz       s41, #6
    a.vwrite     a1, s45, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s29, #15552
    s.movz       s45, #7
    a.vwrite     a1, s31, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s31, s29, #15616
    s.movz       s42, #8
    a.vwrite     a1, s35, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s35, s29, #15680
    s.movz       s44, #9
    a.vwrite     a1, s47, v2
    v.ld.w       v2, [s30, #0]
    s.addi       s30, s29, #15744
    s.movz       s47, #10
    a.vwrite     a2, s40, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s32, s29, #15808
    a.vwrite     a2, s33, v2
    v.ld.w       v2, [s27, #0]
    s.movz       s27, #11
    a.vwrite     a2, s39, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s29, #15872
    a.vwrite     a2, s37, v2
    v.ld.w       v2, [s34, #0]
    s.movz       s34, #12
    a.vwrite     a2, s46, v2
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s29, #15936
    a.vwrite     a2, s38, v2
    v.ld.w       v2, [s28, #0]
    s.movz       s28, #13
    a.vwrite     a2, s41, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s29, #16000
    a.vwrite     a2, s45, v2
    v.ld.w       v2, [s31, #0]
    s.movz       s31, #14
    a.vwrite     a2, s42, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s29, #16064
    a.vwrite     a2, s44, v2
    v.ld.w       v2, [s30, #0]
    s.movz       s30, #15
    a.vwrite     a2, s47, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s32, s29, #16128
    a.vwrite     a2, s27, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s29, #16192
    a.vwrite     a2, s34, v2
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s29, #16256
    a.vwrite     a2, s28, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s29, #16320
    a.vwrite     a2, s31, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s29, #16384
    a.vwrite     a2, s30, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s32, s29, #16448
    a.vwrite     a3, s40, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s29, #16512
    s.addi       s40, s29, #16576
    a.vwrite     a3, s33, v2
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s29, #16640
    s.addi       s33, s29, #16704
    a.vwrite     a3, s39, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s39, s29, #16768
    s.addi       s43, s29, #16832
    a.vwrite     a3, s37, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s29, #16896
    s.addi       s37, s29, #16960
    a.vwrite     a3, s46, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s32, s29, #17024
    s.addi       s46, s29, #17088
    a.vwrite     a3, s38, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s29, #17152
    s.movz       s38, #0
    a.vwrite     a3, s41, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s29, #17216
    s.movz       s41, #1
    a.vwrite     a3, s45, v2
    v.ld.w       v2, [s26, #0]
    s.addi       s26, s29, #17280
    s.movz       s45, #2
    a.vwrite     a3, s42, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s29, #17344
    s.movz       s42, #3
    a.vwrite     a3, s44, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s29, #17408
    s.movz       s44, #4
    a.vwrite     a3, s47, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s29, #17472
    s.movz       s47, #5
    a.vwrite     a3, s27, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s27, s29, #17536
    s.movz       s35, #6
    a.vwrite     a3, s34, v2
    v.ld.w       v2, [s37, #0]
    s.addi       s34, s29, #17600
    s.movz       s37, #7
    a.vwrite     a3, s28, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s28, s29, #17664
    s.movz       s32, #8
    a.vwrite     a3, s31, v2
    v.ld.w       v2, [s46, #0]
    s.addi       s31, s29, #17728
    s.movz       s46, #9
    a.vwrite     a3, s30, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s30, s29, #17792
    s.movz       s36, #10
    a.vwrite     a4, s38, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s29, #17856
    a.vwrite     a4, s41, v2
    v.ld.w       v2, [s26, #0]
    s.movz       s26, #11
    a.vwrite     a4, s45, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s29, #17920
    a.vwrite     a4, s42, v2
    v.ld.w       v2, [s39, #0]
    s.movz       s39, #12
    a.vwrite     a4, s44, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s29, #17984
    a.vwrite     a4, s47, v2
    v.ld.w       v2, [s27, #0]
    s.movz       s27, #13
    a.vwrite     a4, s35, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s29, #18048
    a.vwrite     a4, s37, v2
    v.ld.w       v2, [s28, #0]
    s.movz       s28, #14
    a.vwrite     a4, s32, v2
    v.ld.w       v2, [s31, #0]
    s.addi       s31, s29, #18112
    a.vwrite     a4, s46, v2
    v.ld.w       v2, [s30, #0]
    s.movz       s30, #15
    a.vwrite     a4, s36, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s29, #18176
    a.vwrite     a4, s26, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s29, #18240
    a.vwrite     a4, s39, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s43, s29, #18304
    a.vwrite     a4, s27, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s29, #18368
    a.vwrite     a4, s28, v2
    v.ld.w       v2, [s31, #0]
    s.addi       s31, s29, #18432
    a.vwrite     a4, s30, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s29, #18496
    a.vwrite     a5, s38, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s29, #18560
    s.addi       s38, s29, #18624
    a.vwrite     a5, s41, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s41, s29, #18688
    s.addi       s43, s29, #18752
    a.vwrite     a5, s45, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s29, #18816
    s.addi       s45, s29, #18880
    a.vwrite     a5, s42, v2
    v.ld.w       v2, [s31, #0]
    s.addi       s31, s29, #18944
    s.addi       s42, s29, #19008
    a.vwrite     a5, s44, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s40, s29, #19072
    s.addi       s44, s29, #19136
    a.vwrite     a5, s47, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s33, s29, #19200
    s.movz       s47, #0
    a.vwrite     a5, s35, v2
    v.ld.w       v2, [s38, #0]
    s.addi       s35, s29, #19264
    s.movz       s38, #1
    a.vwrite     a5, s37, v2
    v.ld.w       v2, [s41, #0]
    s.addi       s37, s29, #19328
    s.movz       s41, #2
    a.vwrite     a5, s32, v2
    v.ld.w       v2, [s43, #0]
    s.addi       s32, s29, #19392
    s.movz       s43, #3
    a.vwrite     a5, s46, v2
    v.ld.w       v2, [s34, #0]
    s.addi       s34, s29, #19456
    s.movz       s46, #4
    a.vwrite     a5, s36, v2
    v.ld.w       v2, [s45, #0]
    s.addi       s36, s29, #19520
    s.movz       s45, #5
    a.vwrite     a5, s26, v2
    v.ld.w       v2, [s31, #0]
    s.addi       s26, s29, #19584
    s.movz       s31, #6
    a.vwrite     a5, s39, v2
    v.ld.w       v2, [s42, #0]
    s.addi       s39, s29, #19648
    s.movz       s42, #7
    a.vwrite     a5, s27, v2
    v.ld.w       v2, [s40, #0]
    s.addi       s27, s29, #19712
    s.movz       s40, #8
    a.vwrite     a5, s28, v2
    v.ld.w       v2, [s44, #0]
    s.addi       s28, s29, #19776
    s.movz       s44, #9
    a.vwrite     a5, s30, v2
    v.ld.w       v2, [s33, #0]
    s.addi       s30, s29, #19840
    s.movz       s33, #10
    a.vwrite     a6, s47, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s29, #19904
    a.vwrite     a6, s38, v2
    v.ld.w       v2, [s37, #0]
    s.movz       s37, #11
    a.vwrite     a6, s41, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s32, s29, #19968
    a.vwrite     a6, s43, v2
    v.ld.w       v2, [s34, #0]
    s.movz       s34, #12
    a.vwrite     a6, s46, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s29, #20032
    a.vwrite     a6, s45, v2
    v.ld.w       v2, [s26, #0]
    s.movz       s26, #13
    a.vwrite     a6, s31, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s29, #20096
    a.vwrite     a6, s42, v2
    v.ld.w       v2, [s27, #0]
    s.movz       s27, #14
    a.vwrite     a6, s40, v2
    v.ld.w       v2, [s28, #0]
    s.addi       s28, s29, #20160
    a.vwrite     a6, s44, v2
    v.ld.w       v2, [s30, #0]
    s.movz       s30, #15
    a.vwrite     a6, s33, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s29, #20224
    a.vwrite     a6, s37, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s32, s29, #20288
    a.vwrite     a6, s34, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s29, #20352
    a.vwrite     a6, s26, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s29, #20416
    a.vwrite     a6, s27, v2
    v.ld.w       v2, [s28, #0]
    s.addi       s28, s29, #20480
    a.vwrite     a6, s30, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s29, #20544
    a.vwrite     a7, s47, v2
    v.ld.w       v2, [s32, #0]
    s.addi       s32, s29, #20608
    s.addi       s47, s29, #20672
    a.vwrite     a7, s38, v2
    v.ld.w       v2, [s36, #0]
    s.addi       s36, s29, #20736
    s.addi       s38, s29, #20800
    a.vwrite     a7, s41, v2
    v.ld.w       v2, [s39, #0]
    s.addi       s39, s29, #20864
    s.addi       s41, s29, #20928
    a.vwrite     a7, s43, v2
    v.ld.w       v2, [s28, #0]
    s.addi       s28, s29, #20992
    s.addi       s43, s29, #21056
    a.vwrite     a7, s46, v2
    v.ld.w       v2, [s35, #0]
    s.addi       s35, s29, #21120
    s.addi       s46, s29, #21184
    s.add        s29, s17, s10
    a.vwrite     a7, s45, v2
    v.ld.w       v2, [s32, #0]
    s.movz       s32, #1
    a.vwrite     a7, s31, v2
    v.ld.w       v2, [s47, #0]
    a.vwrite     a7, s42, v2
    v.ld.w       v2, [s36, #0]
    a.vwrite     a7, s40, v2
    v.ld.w       v2, [s38, #0]
    a.vwrite     a7, s44, v2
    v.ld.w       v2, [s39, #0]
    a.vwrite     a7, s33, v2
    v.ld.w       v2, [s41, #0]
    a.vwrite     a7, s37, v2
    v.ld.w       v2, [s28, #0]
    a.vwrite     a7, s34, v2
    v.ld.w       v2, [s43, #0]
    a.vwrite     a7, s26, v2
    v.ld.w       v2, [s35, #0]
    a.vwrite     a7, s27, v2
    v.ld.w       v2, [s46, #0]
    a.vwrite     a7, s30, v2
    s.mov        s17, s29
    br.nz        s32, for_17
endfor_18:
    s.mul        s2, s8, s4
    s.movz       s4, #0
    s.muli       s5, s1, #2
    s.add        s6, s4, s1                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s7, s2, s24
    v.splat      v1, s6
    a.vread      v2, a0, s4
    s.muli       s6, s24, #2
    s.add        s8, s4, s2                      // the tile origin
    s.muli       s9, s7, #2
    s.add        s7, s4, s3                      // the tile origin
    v.splat      v3, s8
    v.splat      v4, s10
    v.add        v5, v0, v1
    v.splat      v1, s7
    vf.cvt.f32.bf16 v6, v2
    s.add        s4, s9, s5
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.muli       s7, s6, #1
    s.add        s10, s19, s4
    p.and        p3, p1, p2
    s.movz       s4, #1
    @p3 v.st.h       [s10, #0], v6
    a.vread      v1, a0, s4
    s.addi       s4, s8, #1
    s.add        s10, s7, s9
    v.splat      v2, s4
    vf.cvt.f32.bf16 v3, v1
    s.add        s4, s10, s5
    v.cmp.lt     p1, v2, v4
    s.muli       s7, s6, #2
    s.add        s10, s19, s4
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.addi       s11, s1, #16
    s.addi       s12, s1, #32
    @p3 v.st.h       [s10, #0], v3
    a.vread      v1, a0, s4
    s.addi       s4, s1, #48
    s.addi       s10, s1, #64
    vf.cvt.f32.bf16 v2, v1
    s.addi       s13, s1, #80
    s.addi       s14, s1, #96
    s.addi       s15, s1, #112
    v.iota       v1                              // arange(0, VLEN)
    s.add        s1, s7, s9
    v.splat      v3, s2
    s.add        s2, s1, s5
    v.add        v5, v3, v1
    s.addi       s1, s8, #2
    s.muli       s7, s6, #3
    v.splat      v1, s1
    s.add        s1, s19, s2
    s.movz       s2, #3
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s16, s8, #3
    @p3 v.st.h       [s1, #0], v2
    a.vread      v1, a0, s2
    s.add        s1, s7, s9
    v.splat      v2, s16
    vf.cvt.f32.bf16 v3, v1
    s.add        s2, s1, s5
    v.cmp.lt     p1, v2, v4
    s.muli       s1, s6, #4
    s.add        s7, s19, s2
    p.and        p3, p1, p2
    s.movz       s2, #4
    s.addi       s16, s8, #4
    s.add        s17, s1, s9
    v.splat      v1, s16
    @p3 v.st.h       [s7, #0], v3
    a.vread      v2, a0, s2
    s.add        s1, s17, s5
    v.cmp.lt     p1, v1, v4
    vf.cvt.f32.bf16 v1, v2
    s.muli       s2, s6, #5
    s.add        s7, s19, s1
    p.and        p3, p1, p2
    s.movz       s1, #5
    s.addi       s16, s8, #5
    s.add        s17, s2, s9
    v.splat      v2, s16
    s.add        s2, s17, s5
    s.muli       s16, s6, #6
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v2, v4
    s.add        s1, s19, s2
    vf.cvt.f32.bf16 v2, v1
    p.and        p3, p1, p2
    s.movz       s2, #6
    s.addi       s7, s8, #6
    s.add        s17, s16, s9
    v.splat      v1, s7
    s.add        s7, s17, s5
    s.muli       s16, s6, #7
    v.cmp.lt     p1, v1, v4
    s.add        s17, s19, s7
    @p3 v.st.h       [s1, #0], v2
    a.vread      v1, a0, s2
    p.and        p3, p1, p2
    s.movz       s1, #7
    vf.cvt.f32.bf16 v2, v1
    s.addi       s2, s8, #7
    s.add        s7, s16, s9
    v.splat      v1, s2
    s.add        s2, s7, s5
    s.muli       s7, s6, #8
    v.cmp.lt     p1, v1, v4
    s.add        s16, s19, s2
    p.and        p4, p1, p2
    s.movz       s2, #8
    @p3 v.st.h       [s17, #0], v2
    a.vread      v1, a0, s1
    s.addi       s1, s8, #8
    s.add        s17, s7, s9
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s1
    s.add        s1, s17, s5
    s.muli       s7, s6, #9
    v.cmp.lt     p1, v1, v4
    s.add        s17, s19, s1
    p.and        p3, p1, p2
    s.movz       s1, #9
    s.addi       s18, s8, #9
    s.add        s20, s7, s9
    @p4 v.st.h       [s16, #0], v2
    a.vread      v1, a0, s2
    v.splat      v2, s18
    s.add        s2, s20, s5
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s7, s6, #10
    s.add        s16, s19, s2
    p.and        p4, p1, p2
    s.movz       s2, #10
    s.addi       s18, s8, #10
    s.add        s20, s7, s9
    v.splat      v1, s18
    s.add        s7, s20, s5
    @p3 v.st.h       [s17, #0], v3
    a.vread      v2, a0, s1
    v.cmp.lt     p1, v1, v4
    s.muli       s1, s6, #11
    vf.cvt.f32.bf16 v1, v2
    s.add        s17, s19, s7
    p.and        p3, p1, p2
    s.movz       s7, #11
    s.addi       s18, s8, #11
    s.add        s20, s1, s9
    v.splat      v2, s18
    s.add        s1, s20, s5
    s.muli       s18, s6, #12
    s.add        s20, s19, s1
    @p4 v.st.h       [s16, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.movz       s1, #12
    s.addi       s2, s8, #12
    s.add        s16, s18, s9
    v.splat      v1, s2
    s.add        s2, s16, s5
    s.muli       s16, s6, #13
    s.add        s18, s19, s2
    s.movz       s2, #13
    s.addi       s21, s8, #13
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a0, s7
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s7, s16, s9
    v.splat      v2, s21
    s.add        s16, s7, s5
    s.muli       s7, s6, #14
    s.add        s17, s19, s16
    s.movz       s16, #14
    s.addi       s21, s8, #14
    s.add        s22, s7, s9
    @p4 v.st.h       [s20, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s21
    s.add        s1, s22, s5
    s.muli       s7, s6, #15
    s.add        s20, s19, s1
    s.movz       s1, #15
    s.addi       s21, s8, #15
    v.splat      v3, s8
    s.add        s22, s7, s9
    v.splat      v5, s21
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a0, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.movz       s2, #0
    s.add        s7, s22, s5
    s.add        s5, s2, s11                     // the tile origin
    s.add        s18, s19, s7
    s.muli       s7, s11, #2
    v.splat      v2, s5
    s.add        s5, s2, s3                      // the tile origin
    s.muli       s11, s6, #1
    v.add        v6, v0, v2
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a0, s16
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s5
    s.add        s5, s9, s7
    v.cmp.lt     p1, v3, v4
    s.add        s16, s19, s5
    s.movz       s5, #1
    s.addi       s17, s8, #1
    s.add        s21, s11, s9
    v.splat      v3, s17
    s.add        s11, s21, s7
    @p3 v.st.h       [s20, #0], v2
    a.vread      v2, a0, s1
    v.cmp.lt     p2, v6, v1
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s1, s6, #2
    s.add        s17, s19, s11
    s.movz       s11, #2
    s.addi       s20, s8, #2
    s.muli       s21, s6, #3
    s.add        s22, s1, s9
    v.splat      v2, s20
    s.add        s1, s22, s7
    s.movz       s20, #3
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s2
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s2, s19, s1
    s.addi       s1, s8, #3
    s.add        s18, s21, s9
    v.splat      v1, s1
    s.add        s1, s18, s7
    s.muli       s18, s6, #4
    s.add        s21, s19, s1
    s.movz       s1, #4
    @p3 v.st.h       [s16, #0], v3
    a.vread      v3, a1, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s5, s8, #4
    s.add        s16, s18, s9
    v.splat      v3, s5
    s.add        s5, s16, s7
    s.muli       s16, s6, #5
    s.add        s18, s19, s5
    s.movz       s5, #5
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a1, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s11, s8, #5
    s.add        s17, s16, s9
    v.splat      v2, s11
    s.add        s11, s17, s7
    s.muli       s16, s6, #6
    s.add        s17, s19, s11
    s.movz       s11, #6
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a1, s20
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s2, s8, #6
    s.add        s20, s16, s9
    v.splat      v1, s2
    s.add        s2, s20, s7
    s.muli       s16, s6, #7
    s.add        s20, s19, s2
    s.movz       s2, #7
    @p4 v.st.h       [s21, #0], v3
    a.vread      v3, a1, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s1, s8, #7
    s.add        s21, s16, s9
    v.splat      v3, s1
    s.add        s1, s21, s7
    s.muli       s16, s6, #8
    s.add        s21, s19, s1
    s.movz       s1, #8
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a1, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s5, s8, #8
    s.add        s18, s16, s9
    v.splat      v2, s5
    s.add        s5, s18, s7
    s.muli       s16, s6, #9
    s.add        s18, s19, s5
    s.movz       s5, #9
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a1, s11
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s8, #9
    s.add        s17, s16, s9
    v.splat      v1, s11
    s.add        s11, s17, s7
    s.muli       s16, s6, #10
    s.add        s17, s19, s11
    s.movz       s11, #10
    @p3 v.st.h       [s20, #0], v3
    a.vread      v3, a1, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s2, s8, #10
    s.add        s20, s16, s9
    v.splat      v3, s2
    s.add        s2, s20, s7
    s.muli       s16, s6, #11
    s.add        s20, s19, s2
    s.movz       s2, #11
    @p4 v.st.h       [s21, #0], v2
    a.vread      v2, a1, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s1, s8, #11
    s.add        s21, s16, s9
    v.splat      v2, s1
    s.add        s1, s21, s7
    s.muli       s16, s6, #12
    s.add        s21, s19, s1
    s.movz       s1, #12
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s5, s8, #12
    s.add        s18, s16, s9
    v.splat      v1, s5
    s.add        s5, s18, s7
    s.muli       s16, s6, #13
    s.add        s18, s19, s5
    s.movz       s5, #13
    @p4 v.st.h       [s17, #0], v3
    a.vread      v3, a1, s11
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s11, s8, #13
    s.add        s17, s16, s9
    v.splat      v3, s11
    s.add        s11, s17, s7
    s.muli       s16, s6, #14
    s.add        s17, s19, s11
    s.movz       s11, #14
    @p3 v.st.h       [s20, #0], v2
    a.vread      v2, a1, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s2, s8, #14
    s.add        s20, s16, s9
    v.splat      v2, s2
    s.add        s2, s20, s7
    s.muli       s16, s6, #15
    s.add        s20, s19, s2
    s.movz       s2, #15
    @p4 v.st.h       [s21, #0], v1
    a.vread      v1, a1, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s8, #15
    s.add        s21, s16, s9
    v.splat      v1, s1
    s.movz       s1, #0
    s.add        s16, s21, s7
    s.add        s7, s1, s12                     // the tile origin
    s.add        s21, s19, s16
    s.muli       s16, s12, #2
    v.splat      v5, s7
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a1, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.add        s5, s1, s3                      // the tile origin
    v.splat      v3, s8
    v.add        v6, v0, v5
    v.splat      v5, s5
    s.add        s5, s9, s16
    s.muli       s7, s6, #1
    s.add        s12, s19, s5
    s.movz       s5, #1
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a1, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.cmp.lt     p1, v3, v4
    s.addi       s11, s8, #1
    s.add        s17, s7, s9
    v.splat      v2, s11
    s.add        s7, s17, s16
    s.muli       s11, s6, #2
    s.add        s17, s19, s7
    s.movz       s7, #2
    @p3 v.st.h       [s20, #0], v1
    a.vread      v1, a1, s2
    v.cmp.lt     p2, v6, v5
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s2, s8, #2
    s.add        s18, s11, s9
    v.splat      v1, s2
    s.add        s2, s18, s16
    s.muli       s11, s6, #3
    s.add        s18, s19, s2
    s.movz       s2, #3
    @p4 v.st.h       [s21, #0], v3
    a.vread      v3, a2, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.addi       s1, s8, #3
    s.add        s20, s11, s9
    v.splat      v3, s1
    s.add        s1, s20, s16
    s.muli       s11, s6, #4
    s.add        s20, s19, s1
    s.movz       s1, #4
    s.addi       s21, s8, #4
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a2, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s5, s11, s9
    v.splat      v2, s21
    s.add        s11, s5, s16
    s.muli       s5, s6, #5
    s.add        s12, s19, s11
    s.movz       s11, #5
    s.addi       s21, s8, #5
    s.add        s22, s5, s9
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a2, s7
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s21
    s.add        s5, s22, s16
    s.muli       s7, s6, #6
    s.add        s17, s19, s5
    s.movz       s5, #6
    s.addi       s21, s8, #6
    s.add        s22, s7, s9
    v.splat      v5, s21
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.add        s2, s22, s16
    s.muli       s7, s6, #7
    s.add        s18, s19, s2
    s.movz       s2, #7
    s.addi       s21, s8, #7
    s.add        s22, s7, s9
    v.splat      v3, s21
    s.add        s7, s22, s16
    @p4 v.st.h       [s20, #0], v2
    a.vread      v2, a2, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s1, s6, #8
    s.add        s20, s19, s7
    s.movz       s7, #8
    s.addi       s21, s8, #8
    s.add        s22, s1, s9
    v.splat      v2, s21
    s.add        s1, s22, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a2, s11
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s11, s6, #9
    s.add        s12, s19, s1
    s.movz       s1, #9
    s.addi       s21, s8, #9
    s.add        s22, s11, s9
    v.splat      v1, s21
    s.add        s11, s22, s16
    @p4 v.st.h       [s17, #0], v5
    a.vread      v5, a2, s5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s5, s6, #10
    s.add        s17, s19, s11
    s.movz       s11, #10
    s.addi       s21, s8, #10
    s.add        s22, s5, s9
    v.splat      v5, s21
    s.add        s5, s22, s16
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s2, s6, #11
    s.add        s18, s19, s5
    s.movz       s5, #11
    s.addi       s21, s8, #11
    s.add        s22, s2, s9
    v.splat      v3, s21
    s.add        s2, s22, s16
    @p4 v.st.h       [s20, #0], v2
    a.vread      v2, a2, s7
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s7, s6, #12
    s.add        s20, s19, s2
    s.movz       s2, #12
    s.addi       s21, s8, #12
    s.add        s22, s7, s9
    v.splat      v2, s21
    s.add        s7, s22, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a2, s1
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s1, s6, #13
    s.add        s12, s19, s7
    s.movz       s7, #13
    s.addi       s21, s8, #13
    s.add        s22, s1, s9
    v.splat      v1, s21
    s.add        s1, s22, s16
    @p4 v.st.h       [s17, #0], v5
    a.vread      v5, a2, s11
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s11, s6, #14
    s.add        s17, s19, s1
    s.movz       s1, #14
    s.addi       s21, s8, #14
    s.add        s22, s11, s9
    v.splat      v5, s21
    s.add        s11, s22, s16
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s5, s6, #15
    s.add        s18, s19, s11
    s.movz       s11, #15
    s.addi       s21, s8, #15
    s.add        s22, s5, s9
    v.splat      v3, s21
    s.add        s5, s22, s16
    @p4 v.st.h       [s20, #0], v2
    a.vread      v2, a2, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.movz       s2, #0
    s.add        s16, s19, s5
    s.add        s5, s2, s4                      // the tile origin
    s.muli       s20, s4, #2
    v.splat      v2, s5
    v.splat      v6, s8
    v.add        v7, v0, v2
    s.add        s4, s9, s20
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a2, s7
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s5, s2, s3                      // the tile origin
    s.muli       s7, s6, #1
    v.splat      v1, s5
    s.add        s5, s19, s4
    s.movz       s4, #1
    s.add        s12, s7, s9
    s.add        s7, s12, s20
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s1, s8, #1
    s.muli       s12, s6, #2
    v.splat      v2, s1
    s.add        s1, s19, s7
    s.movz       s7, #2
    s.add        s17, s12, s9
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a2, s11
    v.cmp.lt     p2, v7, v1
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s11, s8, #2
    s.add        s12, s17, s20
    v.splat      v3, s11
    s.muli       s11, s6, #3
    s.add        s17, s19, s12
    s.movz       s12, #3
    s.add        s18, s11, s9
    @p4 v.st.h       [s16, #0], v1
    a.vread      v1, a3, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s2, s8, #3
    s.add        s11, s18, s20
    v.splat      v1, s2
    s.muli       s2, s6, #4
    s.add        s16, s19, s11
    s.movz       s11, #4
    s.addi       s18, s8, #4
    s.add        s21, s2, s9
    @p3 v.st.h       [s5, #0], v2
    a.vread      v2, a3, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s18
    s.add        s2, s21, s20
    s.muli       s4, s6, #5
    s.add        s5, s19, s2
    s.movz       s2, #5
    s.addi       s18, s8, #5
    s.add        s21, s4, s9
    v.splat      v5, s18
    @p4 v.st.h       [s1, #0], v3
    a.vread      v3, a3, s7
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s1, s21, s20
    s.muli       s4, s6, #6
    s.add        s7, s19, s1
    s.movz       s1, #6
    s.addi       s18, s8, #6
    s.add        s21, s4, s9
    v.splat      v3, s18
    s.add        s4, s21, s20
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s12
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s12, s6, #7
    s.add        s17, s19, s4
    s.movz       s4, #7
    s.addi       s18, s8, #7
    s.add        s21, s12, s9
    v.splat      v1, s18
    s.add        s12, s21, s20
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a3, s11
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s11, s6, #8
    s.add        s16, s19, s12
    s.movz       s12, #8
    s.addi       s18, s8, #8
    s.add        s21, s11, s9
    v.splat      v2, s18
    s.add        s11, s21, s20
    @p3 v.st.h       [s5, #0], v5
    a.vread      v5, a3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s2, s6, #9
    s.add        s5, s19, s11
    s.movz       s11, #9
    s.addi       s18, s8, #9
    s.add        s21, s2, s9
    v.splat      v5, s18
    s.add        s2, s21, s20
    @p4 v.st.h       [s7, #0], v3
    a.vread      v3, a3, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s1, s6, #10
    s.add        s7, s19, s2
    s.movz       s2, #10
    s.addi       s18, s8, #10
    s.add        s21, s1, s9
    v.splat      v3, s18
    s.add        s1, s21, s20
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s4
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s4, s6, #11
    s.add        s17, s19, s1
    s.movz       s1, #11
    s.addi       s18, s8, #11
    s.add        s21, s4, s9
    v.splat      v1, s18
    s.add        s4, s21, s20
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a3, s12
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s12, s6, #12
    s.add        s16, s19, s4
    s.movz       s4, #12
    s.addi       s18, s8, #12
    s.add        s21, s12, s9
    v.splat      v2, s18
    s.add        s12, s21, s20
    @p3 v.st.h       [s5, #0], v5
    a.vread      v5, a3, s11
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s5, s6, #13
    s.add        s11, s19, s12
    s.movz       s12, #13
    s.addi       s18, s8, #13
    s.add        s21, s5, s9
    v.splat      v5, s18
    s.add        s5, s21, s20
    @p4 v.st.h       [s7, #0], v3
    a.vread      v3, a3, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s6, #14
    s.add        s7, s19, s5
    s.movz       s5, #14
    s.addi       s18, s8, #14
    s.add        s21, s2, s9
    v.splat      v3, s18
    s.add        s2, s21, s20
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s1, s6, #15
    s.add        s17, s19, s2
    s.movz       s2, #15
    s.addi       s18, s8, #15
    s.add        s21, s1, s9
    v.splat      v1, s18
    s.add        s1, s21, s20
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a3, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.movz       s4, #0
    s.add        s16, s19, s1
    s.add        s1, s4, s10                     // the tile origin
    s.muli       s18, s10, #2
    v.splat      v2, s1
    v.splat      v6, s8
    v.add        v7, v0, v2
    s.add        s1, s9, s18
    @p3 v.st.h       [s11, #0], v5
    a.vread      v2, a3, s12
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s10, s4, s3                     // the tile origin
    s.muli       s11, s6, #1
    v.splat      v2, s10
    s.add        s10, s19, s1
    s.movz       s1, #1
    s.add        s12, s11, s9
    s.add        s11, s12, s18
    @p4 v.st.h       [s7, #0], v3
    a.vread      v3, a3, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    v.cmp.lt     p1, v6, v4
    s.addi       s5, s8, #1
    s.muli       s7, s6, #2
    v.splat      v3, s5
    s.add        s5, s19, s11
    s.movz       s11, #2
    s.add        s12, s7, s9
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s2
    v.cmp.lt     p2, v7, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s2, s8, #2
    s.add        s7, s12, s18
    v.splat      v1, s2
    s.muli       s2, s6, #3
    s.add        s12, s19, s7
    s.movz       s7, #3
    s.add        s17, s2, s9
    @p4 v.st.h       [s16, #0], v2
    a.vread      v2, a4, s4
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s2, s8, #3
    s.add        s4, s17, s18
    v.splat      v2, s2
    s.muli       s2, s6, #4
    s.add        s16, s19, s4
    s.movz       s4, #4
    s.addi       s17, s8, #4
    s.add        s20, s2, s9
    @p3 v.st.h       [s10, #0], v3
    a.vread      v3, a4, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    v.splat      v3, s17
    s.add        s1, s20, s18
    s.muli       s2, s6, #5
    s.add        s10, s19, s1
    s.movz       s1, #5
    s.addi       s17, s8, #5
    s.add        s20, s2, s9
    v.splat      v5, s17
    @p4 v.st.h       [s5, #0], v1
    a.vread      v1, a4, s11
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s2, s20, s18
    s.muli       s5, s6, #6
    s.add        s11, s19, s2
    s.movz       s2, #6
    s.addi       s17, s8, #6
    s.add        s20, s5, s9
    v.splat      v1, s17
    s.add        s5, s20, s18
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a4, s7
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s7, s6, #7
    s.add        s12, s19, s5
    s.movz       s5, #7
    s.addi       s17, s8, #7
    s.add        s20, s7, s9
    v.splat      v2, s17
    s.add        s7, s20, s18
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a4, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v3
    s.muli       s4, s6, #8
    s.add        s16, s19, s7
    s.movz       s7, #8
    s.addi       s17, s8, #8
    s.add        s20, s4, s9
    v.splat      v3, s17
    s.add        s4, s20, s18
    @p3 v.st.h       [s10, #0], v5
    a.vread      v5, a4, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s1, s6, #9
    s.add        s10, s19, s4
    s.movz       s4, #9
    s.addi       s17, s8, #9
    s.add        s20, s1, s9
    v.splat      v5, s17
    s.add        s1, s20, s18
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a4, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s2, s6, #10
    s.add        s11, s19, s1
    s.movz       s1, #10
    s.addi       s17, s8, #10
    s.add        s20, s2, s9
    v.splat      v1, s17
    s.add        s2, s20, s18
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a4, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s5, s6, #11
    s.add        s12, s19, s2
    s.movz       s2, #11
    s.addi       s17, s8, #11
    s.add        s20, s5, s9
    v.splat      v2, s17
    s.add        s5, s20, s18
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a4, s7
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v3
    s.muli       s7, s6, #12
    s.add        s16, s19, s5
    s.movz       s5, #12
    s.addi       s17, s8, #12
    s.add        s20, s7, s9
    v.splat      v3, s17
    s.add        s7, s20, s18
    @p3 v.st.h       [s10, #0], v5
    a.vread      v5, a4, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s4, s6, #13
    s.add        s10, s19, s7
    s.movz       s7, #13
    s.addi       s17, s8, #13
    s.add        s20, s4, s9
    v.splat      v5, s17
    s.add        s4, s20, s18
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a4, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s1, s6, #14
    s.add        s11, s19, s4
    s.movz       s4, #14
    s.addi       s17, s8, #14
    s.add        s20, s1, s9
    v.splat      v1, s17
    s.add        s1, s20, s18
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a4, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s2, s6, #15
    s.add        s12, s19, s1
    s.movz       s1, #15
    s.addi       s17, s8, #15
    s.add        s20, s2, s9
    v.splat      v2, s17
    s.add        s2, s20, s18
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a4, s5
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v3
    s.movz       s5, #0
    s.add        s16, s19, s2
    s.add        s2, s5, s13                     // the tile origin
    s.muli       s17, s13, #2
    v.splat      v3, s2
    v.splat      v6, s8
    v.add        v7, v0, v3
    s.add        s2, s9, s17
    @p3 v.st.h       [s10, #0], v5
    a.vread      v3, a4, s7
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s7, s5, s3                      // the tile origin
    s.muli       s10, s6, #1
    v.splat      v3, s7
    s.add        s7, s19, s2
    s.movz       s2, #1
    s.add        s13, s10, s9
    s.add        s10, s13, s17
    @p4 v.st.h       [s11, #0], v1
    a.vread      v1, a4, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.cmp.lt     p1, v6, v4
    s.addi       s4, s8, #1
    s.muli       s11, s6, #2
    v.splat      v1, s4
    s.add        s4, s19, s10
    s.movz       s10, #2
    s.add        s13, s11, s9
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a4, s1
    v.cmp.lt     p2, v7, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s1, s8, #2
    s.add        s11, s13, s17
    v.splat      v2, s1
    s.muli       s1, s6, #3
    s.add        s12, s19, s11
    s.movz       s11, #3
    s.add        s13, s1, s9
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a5, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s1, s8, #3
    s.add        s5, s13, s17
    v.splat      v3, s1
    s.muli       s1, s6, #4
    s.add        s13, s19, s5
    s.movz       s5, #4
    s.addi       s16, s8, #4
    s.add        s18, s1, s9
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a5, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s16
    s.add        s1, s18, s17
    s.muli       s2, s6, #5
    s.add        s7, s19, s1
    s.movz       s1, #5
    s.addi       s16, s8, #5
    s.add        s18, s2, s9
    v.splat      v5, s16
    @p4 v.st.h       [s4, #0], v2
    a.vread      v2, a5, s10
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s2, s18, s17
    s.muli       s4, s6, #6
    s.add        s10, s19, s2
    s.movz       s2, #6
    s.addi       s16, s8, #6
    s.add        s18, s4, s9
    v.splat      v2, s16
    s.add        s4, s18, s17
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a5, s11
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s11, s6, #7
    s.add        s12, s19, s4
    s.movz       s4, #7
    s.addi       s16, s8, #7
    s.add        s18, s11, s9
    v.splat      v3, s16
    s.add        s11, s18, s17
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s5
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s5, s6, #8
    s.add        s13, s19, s11
    s.movz       s11, #8
    s.addi       s16, s8, #8
    s.add        s18, s5, s9
    v.splat      v1, s16
    s.add        s5, s18, s17
    @p3 v.st.h       [s7, #0], v5
    a.vread      v5, a5, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s1, s6, #9
    s.add        s7, s19, s5
    s.movz       s5, #9
    s.addi       s16, s8, #9
    s.add        s18, s1, s9
    v.splat      v5, s16
    s.add        s1, s18, s17
    @p4 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s2
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s2, s6, #10
    s.add        s10, s19, s1
    s.movz       s1, #10
    s.addi       s16, s8, #10
    s.add        s18, s2, s9
    v.splat      v2, s16
    s.add        s2, s18, s17
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a5, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s6, #11
    s.add        s12, s19, s2
    s.movz       s2, #11
    s.addi       s16, s8, #11
    s.add        s18, s4, s9
    v.splat      v3, s16
    s.add        s4, s18, s17
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s11
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s11, s6, #12
    s.add        s13, s19, s4
    s.movz       s4, #12
    s.addi       s16, s8, #12
    s.add        s18, s11, s9
    v.splat      v1, s16
    s.add        s11, s18, s17
    @p3 v.st.h       [s7, #0], v5
    a.vread      v5, a5, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s5, s6, #13
    s.add        s7, s19, s11
    s.movz       s11, #13
    s.addi       s16, s8, #13
    s.add        s18, s5, s9
    v.splat      v5, s16
    s.add        s5, s18, s17
    @p4 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s1, s6, #14
    s.add        s10, s19, s5
    s.movz       s5, #14
    s.addi       s16, s8, #14
    s.add        s18, s1, s9
    v.splat      v2, s16
    s.add        s1, s18, s17
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a5, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s6, #15
    s.add        s12, s19, s1
    s.movz       s1, #15
    s.addi       s16, s8, #15
    s.add        s18, s2, s9
    v.splat      v3, s16
    s.add        s2, s18, s17
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a5, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.movz       s4, #0
    s.add        s13, s19, s2
    s.add        s2, s4, s14                     // the tile origin
    s.muli       s16, s14, #2
    v.splat      v1, s2
    v.splat      v6, s8
    v.add        v7, v0, v1
    s.add        s2, s9, s16
    @p3 v.st.h       [s7, #0], v5
    a.vread      v1, a5, s11
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.add        s7, s4, s3                      // the tile origin
    s.muli       s11, s6, #1
    v.splat      v1, s7
    s.add        s7, s19, s2
    s.movz       s2, #1
    s.add        s14, s11, s9
    s.add        s11, s14, s16
    @p4 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s5, s8, #1
    s.muli       s10, s6, #2
    v.splat      v2, s5
    s.add        s5, s19, s11
    s.movz       s11, #2
    s.add        s14, s10, s9
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a5, s1
    v.cmp.lt     p2, v7, v1
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s1, s8, #2
    s.add        s10, s14, s16
    v.splat      v3, s1
    s.muli       s1, s6, #3
    s.add        s12, s19, s10
    s.movz       s10, #3
    s.add        s14, s1, s9
    @p4 v.st.h       [s13, #0], v1
    a.vread      v1, a6, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s1, s8, #3
    s.add        s4, s14, s16
    v.splat      v1, s1
    s.muli       s1, s6, #4
    s.add        s13, s19, s4
    s.movz       s4, #4
    s.addi       s14, s8, #4
    s.add        s17, s1, s9
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a6, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    v.splat      v2, s14
    s.add        s1, s17, s16
    s.muli       s2, s6, #5
    s.add        s7, s19, s1
    s.movz       s1, #5
    s.addi       s14, s8, #5
    s.add        s17, s2, s9
    v.splat      v5, s14
    @p4 v.st.h       [s5, #0], v3
    a.vread      v3, a6, s11
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s2, s17, s16
    s.muli       s5, s6, #6
    s.add        s11, s19, s2
    s.movz       s2, #6
    s.addi       s14, s8, #6
    s.add        s17, s5, s9
    v.splat      v3, s14
    s.add        s5, s17, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s10
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s10, s6, #7
    s.add        s12, s19, s5
    s.movz       s5, #7
    s.addi       s14, s8, #7
    s.add        s17, s10, s9
    v.splat      v1, s14
    s.add        s10, s17, s16
    @p4 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s4, s6, #8
    s.add        s13, s19, s10
    s.movz       s10, #8
    s.addi       s14, s8, #8
    s.add        s17, s4, s9
    v.splat      v2, s14
    s.add        s4, s17, s16
    @p3 v.st.h       [s7, #0], v5
    a.vread      v5, a6, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s1, s6, #9
    s.add        s7, s19, s4
    s.movz       s4, #9
    s.addi       s14, s8, #9
    s.add        s17, s1, s9
    v.splat      v5, s14
    s.add        s1, s17, s16
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a6, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s6, #10
    s.add        s11, s19, s1
    s.movz       s1, #10
    s.addi       s14, s8, #10
    s.add        s17, s2, s9
    v.splat      v3, s14
    s.add        s2, s17, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s5, s6, #11
    s.add        s12, s19, s2
    s.movz       s2, #11
    s.addi       s14, s8, #11
    s.add        s17, s5, s9
    v.splat      v1, s14
    s.add        s5, s17, s16
    @p4 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s10
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s10, s6, #12
    s.add        s13, s19, s5
    s.movz       s5, #12
    s.addi       s14, s8, #12
    s.add        s17, s10, s9
    v.splat      v2, s14
    s.add        s10, s17, s16
    @p3 v.st.h       [s7, #0], v5
    a.vread      v5, a6, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v5
    s.muli       s4, s6, #13
    s.add        s7, s19, s10
    s.movz       s10, #13
    s.addi       s14, s8, #13
    s.add        s17, s4, s9
    v.splat      v5, s14
    s.add        s4, s17, s16
    @p4 v.st.h       [s11, #0], v3
    a.vread      v3, a6, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s1, s6, #14
    s.add        s11, s19, s4
    s.movz       s4, #14
    s.addi       s14, s8, #14
    s.add        s17, s1, s9
    v.splat      v3, s14
    s.add        s1, s17, s16
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s2, s6, #15
    s.add        s12, s19, s1
    s.movz       s1, #15
    s.addi       s14, s8, #15
    s.add        s17, s2, s9
    v.splat      v1, s14
    s.add        s2, s17, s16
    @p4 v.st.h       [s13, #0], v2
    a.vread      v2, a6, s5
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.movz       s5, #0
    s.add        s13, s19, s2
    s.add        s2, s5, s15                     // the tile origin
    s.muli       s14, s15, #2
    v.splat      v2, s2
    v.splat      v6, s8
    v.add        v7, v0, v2
    s.add        s2, s9, s14
    @p3 v.st.h       [s7, #0], v5
    a.vread      v0, a6, s10
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.add        s7, s5, s3                      // the tile origin
    s.muli       s3, s6, #1
    v.splat      v0, s7
    s.add        s7, s19, s2
    s.movz       s2, #1
    s.add        s10, s3, s9
    s.add        s3, s10, s14
    @p4 v.st.h       [s11, #0], v2
    a.vread      v2, a6, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s4, s8, #1
    s.muli       s10, s6, #2
    v.splat      v2, s4
    s.add        s4, s19, s3
    s.movz       s3, #2
    s.add        s11, s10, s9
    @p3 v.st.h       [s12, #0], v1
    a.vread      v1, a6, s1
    v.cmp.lt     p2, v7, v0
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.addi       s1, s8, #2
    s.add        s10, s11, s14
    v.splat      v1, s1
    s.muli       s1, s6, #3
    s.add        s11, s19, s10
    s.movz       s10, #3
    s.add        s12, s1, s9
    @p4 v.st.h       [s13, #0], v0
    a.vread      v0, a7, s5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.addi       s1, s8, #3
    s.add        s5, s12, s14
    v.splat      v0, s1
    s.muli       s1, s6, #4
    s.add        s12, s19, s5
    s.movz       s5, #4
    s.addi       s13, s8, #4
    s.add        s15, s1, s9
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a7, s2
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.splat      v2, s13
    s.add        s1, s15, s14
    s.muli       s2, s6, #5
    s.add        s7, s19, s1
    s.movz       s1, #5
    s.addi       s13, s8, #5
    s.add        s15, s2, s9
    v.splat      v3, s13
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a7, s3
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.add        s2, s15, s14
    s.muli       s3, s6, #6
    s.add        s4, s19, s2
    s.movz       s2, #6
    s.addi       s13, s8, #6
    s.add        s15, s3, s9
    v.splat      v1, s13
    s.add        s3, s15, s14
    @p3 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s10
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s10, s6, #7
    s.add        s11, s19, s3
    s.movz       s3, #7
    s.addi       s13, s8, #7
    s.add        s15, s10, s9
    v.splat      v0, s13
    s.add        s10, s15, s14
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a7, s5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s5, s6, #8
    s.add        s12, s19, s10
    s.movz       s10, #8
    s.addi       s13, s8, #8
    s.add        s15, s5, s9
    v.splat      v2, s13
    s.add        s5, s15, s14
    @p3 v.st.h       [s7, #0], v3
    a.vread      v3, a7, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s1, s6, #9
    s.add        s7, s19, s5
    s.movz       s5, #9
    s.addi       s13, s8, #9
    s.add        s15, s1, s9
    v.splat      v3, s13
    s.add        s1, s15, s14
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a7, s2
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s2, s6, #10
    s.add        s4, s19, s1
    s.movz       s1, #10
    s.addi       s13, s8, #10
    s.add        s15, s2, s9
    v.splat      v1, s13
    s.add        s2, s15, s14
    @p3 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s3
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s3, s6, #11
    s.add        s11, s19, s2
    s.movz       s2, #11
    s.addi       s13, s8, #11
    s.add        s15, s3, s9
    v.splat      v0, s13
    s.add        s3, s15, s14
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a7, s10
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s10, s6, #12
    s.add        s12, s19, s3
    s.movz       s3, #12
    s.addi       s13, s8, #12
    s.add        s15, s10, s9
    v.splat      v2, s13
    s.add        s10, s15, s14
    @p3 v.st.h       [s7, #0], v3
    a.vread      v3, a7, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s5, s6, #13
    s.add        s7, s19, s10
    s.movz       s10, #13
    s.addi       s13, s8, #13
    s.add        s15, s5, s9
    v.splat      v3, s13
    s.add        s5, s15, s14
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a7, s1
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    s.muli       s1, s6, #14
    s.add        s4, s19, s5
    s.movz       s5, #14
    s.addi       s13, s8, #14
    s.add        s15, s1, s9
    v.splat      v1, s13
    s.add        s1, s15, s14
    @p3 v.st.h       [s11, #0], v0
    a.vread      v0, a7, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s2, s6, #15
    s.add        s6, s19, s1
    s.movz       s1, #15
    s.addi       s11, s8, #15
    s.add        s8, s2, s9
    v.splat      v0, s11
    s.add        s2, s8, s14
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a7, s3
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s3, s19, s2
    @p3 v.st.h       [s7, #0], v3
    a.vread      v2, a7, s10
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    @p4 v.st.h       [s4, #0], v1
    a.vread      v1, a7, s5
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    @p3 v.st.h       [s6, #0], v0
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s3, #0], v1
    exit
    exit
