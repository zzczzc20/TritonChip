    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.iota       v0                              // arange(0, VLEN)
    s.shli       s1, s4, #32
    v.movi       v1, #0
    v.extract    s2, v0, #0
    v.extract    s3, v0, #1
    s.shli       s4, s2, #32
    s.ashri      s2, s1, #32
    s.ashri      s1, s4, #32
    v.movi       v2, #0
    v.movi       v3, #0
    v.movi       v4, #0
    s.shli       s4, s3, #32
    s.rdspecial  s3, arg_base
    s.lshri      s5, s2, #32
    s.lshri      s6, s1, #32
    v.extract    s7, v0, #2
    s.ashri      s8, s4, #32
    s.ld.d       s4, [s3, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.shli       s9, s7, #32
    s.lshri      s7, s8, #32
    v.extract    s10, v0, #3
    s.ashri      s11, s9, #32
    s.shli       s9, s10, #32
    s.ashri      s10, s9, #32
    s.ld.d       s9, [s3, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.insert     v1, s2, #0
    v.insert     v2, s5, #0
    v.insert     v3, s1, #0
    v.insert     v4, s6, #0
    s.lshri      s1, s11, #32
    v.insert     v3, s8, #1
    v.insert     v4, s7, #1
    v.extract    s2, v0, #4
    v.insert     v3, s11, #2
    v.insert     v4, s1, #2
    s.shli       s1, s2, #32
    s.lshri      s2, s10, #32
    v.extract    s3, v0, #5
    s.ashri      s5, s1, #32
    v.insert     v3, s10, #3
    v.insert     v4, s2, #3
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    s.ashri      s3, s1, #32
    v.insert     v3, s5, #4
    v.insert     v4, s2, #4
    s.lshri      s1, s3, #32
    v.insert     v3, s3, #5
    s.movz       s2, #0
    v.insert     v4, s1, #5
    s.movz       s1, #2048
    v.extract    s3, v0, #6
    s.movz       s5, #16
    s.shli       s6, s3, #32
    v.extract    s3, v0, #7
    s.ashri      s7, s6, #32
    s.shli       s6, s3, #32
    s.lshri      s3, s7, #32
    v.extract    s8, v0, #8
    s.ashri      s10, s6, #32
    v.insert     v3, s7, #6
    v.insert     v4, s3, #6
    s.shli       s3, s8, #32
    s.lshri      s6, s10, #32
    v.extract    s7, v0, #9
    s.ashri      s8, s3, #32
    v.insert     v3, s10, #7
    v.insert     v4, s6, #7
    s.shli       s3, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v0, #10
    s.ashri      s10, s3, #32
    v.insert     v3, s8, #8
    v.insert     v4, s6, #8
    s.shli       s3, s7, #32
    s.lshri      s6, s10, #32
    v.extract    s7, v0, #11
    s.ashri      s8, s3, #32
    v.insert     v3, s10, #9
    v.insert     v4, s6, #9
    s.shli       s3, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v0, #12
    s.ashri      s10, s3, #32
    v.insert     v3, s8, #10
    v.insert     v4, s6, #10
    s.shli       s3, s7, #32
    s.lshri      s6, s10, #32
    v.extract    s7, v0, #13
    s.ashri      s8, s3, #32
    v.insert     v3, s10, #11
    v.insert     v4, s6, #11
    s.shli       s3, s7, #32
    s.lshri      s6, s8, #32
    v.extract    s7, v0, #14
    s.ashri      s10, s3, #32
    v.insert     v3, s8, #12
    v.insert     v4, s6, #12
    s.shli       s3, s7, #32
    s.lshri      s6, s10, #32
    v.extract    s7, v0, #15
    s.ashri      s8, s3, #32
    v.insert     v3, s10, #13
    v.insert     v4, s6, #13
    s.shli       s3, s7, #32
    s.lshri      s6, s8, #32
    s.ashri      s7, s3, #32
    v.insert     v3, s8, #14
    v.insert     v4, s6, #14
    v.movi       v0, #0
    v.movi       v5, #0
    s.lshri      s3, s7, #32
    v.insert     v3, s7, #15
    v.insert     v4, s3, #15
    s.addi       s3, s2, #0
    v.mov        v5, v0
for_1:
    s.cmp.ge     s2, s3, s1
    br.nz        s2, endfor_2
    s.shli       s2, s3, #32
    v.movi       v0, #0
    s.ashri      s6, s2, #32
    v.movi       v6, #0
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #0
    v.insert     v6, s2, #0
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #1
    v.insert     v6, s2, #1
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #2
    v.insert     v6, s2, #2
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #3
    v.insert     v6, s2, #3
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #4
    v.insert     v6, s2, #4
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #5
    v.insert     v6, s2, #5
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #6
    v.insert     v6, s2, #6
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #7
    v.insert     v6, s2, #7
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #8
    v.insert     v6, s2, #8
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #9
    v.insert     v6, s2, #9
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #10
    v.insert     v6, s2, #10
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #11
    v.insert     v6, s2, #11
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #12
    v.insert     v6, s2, #12
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #13
    v.insert     v6, s2, #13
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #14
    v.insert     v6, s2, #14
    s.lshri      s2, s6, #32
    v.insert     v0, s6, #15
    v.insert     v6, s2, #15
    v.extract    s2, v4, #0
    v.extract    s6, v0, #0
    v.extract    s7, v6, #0
    v.extract    s8, v3, #0
    s.shli       s10, s7, #32
    s.shli       s7, s2, #32
    v.extract    s2, v6, #1
    v.extract    s11, v4, #1
    s.or         s12, s6, s10
    s.or         s6, s8, s7
    v.extract    s7, v0, #1
    s.shli       s8, s2, #32
    v.extract    s2, v3, #1
    s.shli       s10, s11, #32
    s.add        s11, s12, s6
    v.extract    s6, v6, #2
    v.extract    s12, v4, #2
    v.movi       v7, #0
    v.movi       v8, #0
    s.or         s13, s7, s8
    s.or         s7, s2, s10
    s.lshri      s2, s11, #32
    v.extract    s8, v0, #2
    s.shli       s10, s6, #32
    s.shli       s6, s12, #32
    s.add        s12, s13, s7
    v.extract    s7, v3, #2
    v.insert     v7, s11, #0
    v.extract    s11, v6, #3
    v.insert     v8, s2, #0
    v.extract    s2, v4, #3
    s.or         s13, s8, s10
    s.or         s8, s7, s6
    s.lshri      s6, s12, #32
    v.extract    s7, v0, #3
    s.shli       s10, s11, #32
    s.shli       s11, s2, #32
    s.add        s2, s13, s8
    v.extract    s8, v3, #3
    v.insert     v7, s12, #1
    v.extract    s12, v6, #4
    v.insert     v8, s6, #1
    v.extract    s6, v4, #4
    s.or         s13, s7, s10
    s.or         s7, s8, s11
    s.lshri      s8, s2, #32
    v.extract    s10, v0, #4
    s.shli       s11, s12, #32
    s.shli       s12, s6, #32
    s.add        s6, s13, s7
    v.extract    s7, v3, #4
    v.insert     v7, s2, #2
    v.extract    s2, v6, #5
    v.insert     v8, s8, #2
    v.extract    s8, v4, #5
    s.or         s13, s10, s11
    s.or         s10, s7, s12
    s.lshri      s7, s6, #32
    v.extract    s11, v0, #5
    s.shli       s12, s2, #32
    s.shli       s2, s8, #32
    s.add        s8, s13, s10
    v.extract    s10, v3, #5
    v.insert     v7, s6, #3
    v.extract    s6, v6, #6
    v.insert     v8, s7, #3
    v.extract    s7, v4, #6
    s.or         s13, s11, s12
    s.or         s11, s10, s2
    s.lshri      s2, s8, #32
    v.extract    s10, v0, #6
    s.shli       s12, s6, #32
    s.shli       s6, s7, #32
    s.add        s7, s13, s11
    v.extract    s11, v3, #6
    v.insert     v7, s8, #4
    v.extract    s8, v6, #7
    v.insert     v8, s2, #4
    v.extract    s2, v4, #7
    s.or         s13, s10, s12
    s.or         s10, s11, s6
    s.lshri      s6, s7, #32
    v.extract    s11, v0, #7
    s.shli       s12, s8, #32
    s.shli       s8, s2, #32
    s.add        s2, s13, s10
    v.extract    s10, v3, #7
    v.insert     v7, s7, #5
    v.extract    s7, v6, #8
    v.insert     v8, s6, #5
    v.extract    s6, v4, #8
    s.or         s13, s11, s12
    s.or         s11, s10, s8
    s.lshri      s8, s2, #32
    v.extract    s10, v0, #8
    s.shli       s12, s7, #32
    s.shli       s7, s6, #32
    s.add        s6, s13, s11
    v.extract    s11, v3, #8
    v.insert     v7, s2, #6
    v.extract    s2, v6, #9
    v.insert     v8, s8, #6
    v.extract    s8, v4, #9
    s.or         s13, s10, s12
    s.or         s10, s11, s7
    s.lshri      s7, s6, #32
    v.extract    s11, v0, #9
    s.shli       s12, s2, #32
    s.shli       s2, s8, #32
    s.add        s8, s13, s10
    v.extract    s10, v3, #9
    v.insert     v7, s6, #7
    v.extract    s6, v6, #10
    v.insert     v8, s7, #7
    v.extract    s7, v4, #10
    s.or         s13, s11, s12
    s.or         s11, s10, s2
    s.lshri      s2, s8, #32
    v.extract    s10, v0, #10
    s.shli       s12, s6, #32
    s.shli       s6, s7, #32
    s.add        s7, s13, s11
    v.extract    s11, v3, #10
    v.insert     v7, s8, #8
    v.extract    s8, v6, #11
    v.insert     v8, s2, #8
    v.extract    s2, v4, #11
    s.or         s13, s10, s12
    s.or         s10, s11, s6
    s.lshri      s6, s7, #32
    v.extract    s11, v0, #11
    s.shli       s12, s8, #32
    s.shli       s8, s2, #32
    s.add        s2, s13, s10
    v.extract    s10, v3, #11
    v.insert     v7, s7, #9
    v.extract    s7, v6, #12
    v.insert     v8, s6, #9
    v.extract    s6, v4, #12
    s.or         s13, s11, s12
    s.or         s11, s10, s8
    s.lshri      s8, s2, #32
    v.extract    s10, v0, #12
    s.shli       s12, s7, #32
    s.shli       s7, s6, #32
    s.add        s6, s13, s11
    v.extract    s11, v3, #12
    v.insert     v7, s2, #10
    v.extract    s2, v6, #13
    v.insert     v8, s8, #10
    v.extract    s8, v4, #13
    s.or         s13, s10, s12
    s.or         s10, s11, s7
    s.lshri      s7, s6, #32
    v.extract    s11, v0, #13
    s.shli       s12, s2, #32
    s.shli       s2, s8, #32
    s.add        s8, s13, s10
    v.extract    s10, v3, #13
    v.insert     v7, s6, #11
    v.extract    s6, v6, #14
    v.insert     v8, s7, #11
    v.extract    s7, v4, #14
    s.or         s13, s11, s12
    s.or         s11, s10, s2
    s.lshri      s2, s8, #32
    v.extract    s10, v0, #14
    s.shli       s12, s6, #32
    s.shli       s6, s7, #32
    s.add        s7, s13, s11
    v.extract    s11, v3, #14
    v.insert     v7, s8, #12
    v.extract    s8, v6, #15
    v.insert     v8, s2, #12
    v.extract    s2, v4, #15
    s.or         s13, s10, s12
    s.or         s10, s11, s6
    s.lshri      s6, s7, #32
    v.extract    s11, v0, #15
    s.shli       s12, s8, #32
    s.shli       s8, s2, #32
    s.add        s2, s13, s10
    v.extract    s10, v3, #15
    v.insert     v7, s7, #13
    v.insert     v8, s6, #13
    s.or         s6, s11, s12
    s.or         s7, s10, s8
    s.lshri      s8, s2, #32
    s.add        s10, s6, s7
    v.insert     v7, s2, #14
    v.insert     v8, s8, #14
    s.lshri      s2, s10, #32
    v.insert     v7, s10, #15
    v.insert     v8, s2, #15
    s.movz       s2, #2048
    v.extract    s6, v7, #0
    v.extract    s7, v8, #0
    v.extract    s8, v8, #1
    s.shli       s10, s7, #32
    v.movi       v0, #0
    s.or         s7, s6, s10
    v.extract    s6, v7, #1
    s.shli       s10, s8, #32
    s.cmp.lt     s8, s7, s2
    v.extract    s2, v8, #2
    s.or         s7, s6, s10
    s.movz       s6, #2048
    v.insert     v0, s8, #0
    v.extract    s8, v7, #2
    s.shli       s10, s2, #32
    s.cmp.lt     s2, s7, s6
    v.extract    s6, v8, #3
    s.or         s7, s8, s10
    s.movz       s8, #2048
    v.insert     v0, s2, #1
    v.extract    s2, v7, #3
    s.shli       s10, s6, #32
    s.cmp.lt     s6, s7, s8
    v.extract    s7, v8, #4
    s.or         s8, s2, s10
    s.movz       s2, #2048
    v.insert     v0, s6, #2
    v.extract    s6, v7, #4
    s.shli       s10, s7, #32
    s.cmp.lt     s7, s8, s2
    v.extract    s2, v8, #5
    s.or         s8, s6, s10
    s.movz       s6, #2048
    v.insert     v0, s7, #3
    v.extract    s7, v7, #5
    s.shli       s10, s2, #32
    s.cmp.lt     s2, s8, s6
    v.extract    s6, v8, #6
    s.or         s8, s7, s10
    s.movz       s7, #2048
    v.insert     v0, s2, #4
    v.extract    s2, v7, #6
    s.shli       s10, s6, #32
    s.cmp.lt     s6, s8, s7
    v.extract    s7, v8, #7
    s.or         s8, s2, s10
    s.movz       s2, #2048
    v.insert     v0, s6, #5
    v.extract    s6, v7, #7
    s.shli       s10, s7, #32
    s.cmp.lt     s7, s8, s2
    v.extract    s2, v8, #8
    s.or         s8, s6, s10
    s.movz       s6, #2048
    v.insert     v0, s7, #6
    v.extract    s7, v7, #8
    s.shli       s10, s2, #32
    s.cmp.lt     s2, s8, s6
    v.extract    s6, v8, #9
    s.or         s8, s7, s10
    s.movz       s7, #2048
    v.insert     v0, s2, #7
    v.extract    s2, v7, #9
    s.shli       s10, s6, #32
    s.cmp.lt     s6, s8, s7
    v.extract    s7, v8, #10
    s.or         s8, s2, s10
    s.movz       s2, #2048
    v.insert     v0, s6, #8
    v.extract    s6, v7, #10
    s.shli       s10, s7, #32
    s.cmp.lt     s7, s8, s2
    v.extract    s2, v8, #11
    s.or         s8, s6, s10
    s.movz       s6, #2048
    v.insert     v0, s7, #9
    v.extract    s7, v7, #11
    s.shli       s10, s2, #32
    s.cmp.lt     s2, s8, s6
    v.extract    s6, v8, #12
    s.or         s8, s7, s10
    s.movz       s7, #2048
    v.insert     v0, s2, #10
    v.extract    s2, v7, #12
    s.shli       s10, s6, #32
    s.cmp.lt     s6, s8, s7
    v.extract    s7, v8, #13
    s.or         s8, s2, s10
    s.movz       s2, #2048
    v.insert     v0, s6, #11
    v.extract    s6, v7, #13
    s.shli       s10, s7, #32
    s.cmp.lt     s7, s8, s2
    v.extract    s2, v8, #14
    s.or         s8, s6, s10
    s.movz       s6, #2048
    v.extract    s10, v8, #0
    v.insert     v0, s7, #12
    v.extract    s7, v7, #14
    s.shli       s11, s2, #32
    s.cmp.lt     s2, s8, s6
    v.extract    s6, v8, #15
    v.extract    s8, v7, #0
    s.shli       s12, s10, #32
    s.or         s10, s7, s11
    s.movz       s7, #2048
    v.extract    s11, v8, #1
    v.insert     v0, s2, #13
    v.extract    s2, v7, #15
    s.shli       s13, s6, #32
    s.or         s6, s8, s12
    .li       s8, #2415902720
    s.cmp.lt     s12, s10, s7
    v.extract    s7, v7, #1
    s.shli       s10, s11, #32
    s.or         s11, s2, s13
    s.movz       s2, #2048
    s.add        s13, s6, s8
    v.extract    s6, v8, #2
    v.insert     v0, s12, #14
    v.movi       v6, #0
    v.movi       v9, #0
    s.or         s8, s7, s10
    .li       s7, #2415902720
    s.cmp.lt     s10, s11, s2
    s.lshri      s2, s13, #32
    v.extract    s11, v7, #2
    s.shli       s12, s6, #32
    s.add        s6, s8, s7
    v.extract    s7, v8, #3
    v.insert     v0, s10, #15
    v.insert     v6, s13, #0
    v.insert     v9, s2, #0
    s.or         s2, s11, s12
    .li       s8, #2415902720
    s.lshri      s10, s6, #32
    v.extract    s11, v7, #3
    s.shli       s12, s7, #32
    s.add        s7, s2, s8
    v.extract    s2, v8, #4
    v.insert     v6, s6, #1
    v.insert     v9, s10, #1
    s.or         s6, s11, s12
    .li       s8, #2415902720
    s.lshri      s10, s7, #32
    v.extract    s11, v7, #4
    s.shli       s12, s2, #32
    s.add        s2, s6, s8
    v.insert     v6, s7, #2
    v.insert     v9, s10, #2
    s.or         s6, s11, s12
    .li       s7, #2415902720
    s.lshri      s8, s2, #32
    s.add        s10, s6, s7
    v.insert     v6, s2, #3
    v.insert     v9, s8, #3
    s.lshri      s2, s10, #32
    v.insert     v6, s10, #4
    v.movi       v10, #0
    v.insert     v9, s2, #4
    v.cmp.ne     p1, v0, v10
    v.extract    s2, v8, #5
    v.extract    s6, v7, #5
    s.shli       s7, s2, #32
    v.extract    s2, v8, #6
    s.or         s8, s6, s7
    .li       s6, #2415902720
    v.extract    s7, v7, #6
    s.shli       s10, s2, #32
    s.add        s2, s8, s6
    v.extract    s6, v8, #7
    s.or         s8, s7, s10
    .li       s7, #2415902720
    s.lshri      s10, s2, #32
    v.extract    s11, v7, #7
    s.shli       s12, s6, #32
    s.add        s6, s8, s7
    v.extract    s7, v8, #8
    v.insert     v6, s2, #5
    v.insert     v9, s10, #5
    s.or         s2, s11, s12
    .li       s8, #2415902720
    s.lshri      s10, s6, #32
    v.extract    s11, v7, #8
    s.shli       s12, s7, #32
    s.add        s7, s2, s8
    v.extract    s2, v8, #9
    v.insert     v6, s6, #6
    v.insert     v9, s10, #6
    s.or         s6, s11, s12
    .li       s8, #2415902720
    s.lshri      s10, s7, #32
    v.extract    s11, v7, #9
    s.shli       s12, s2, #32
    s.add        s2, s6, s8
    v.extract    s6, v8, #10
    v.insert     v6, s7, #7
    v.insert     v9, s10, #7
    s.or         s7, s11, s12
    .li       s8, #2415902720
    s.lshri      s10, s2, #32
    v.extract    s11, v7, #10
    s.shli       s12, s6, #32
    s.add        s6, s7, s8
    v.extract    s7, v8, #11
    v.insert     v6, s2, #8
    v.insert     v9, s10, #8
    s.or         s2, s11, s12
    .li       s8, #2415902720
    s.lshri      s10, s6, #32
    v.extract    s11, v7, #11
    s.shli       s12, s7, #32
    s.add        s7, s2, s8
    v.extract    s2, v8, #12
    v.insert     v6, s6, #9
    v.insert     v9, s10, #9
    s.or         s6, s11, s12
    .li       s8, #2415902720
    s.lshri      s10, s7, #32
    v.extract    s11, v7, #12
    s.shli       s12, s2, #32
    s.add        s2, s6, s8
    v.extract    s6, v8, #13
    v.insert     v6, s7, #10
    v.insert     v9, s10, #10
    s.or         s7, s11, s12
    .li       s8, #2415902720
    s.lshri      s10, s2, #32
    v.extract    s11, v7, #13
    s.shli       s12, s6, #32
    s.add        s6, s7, s8
    v.extract    s7, v8, #14
    v.extract    s8, v2, #0
    v.insert     v6, s2, #11
    v.insert     v9, s10, #11
    s.or         s2, s11, s12
    .li       s10, #2415902720
    s.lshri      s11, s6, #32
    v.extract    s12, v7, #14
    s.shli       s13, s7, #32
    s.shli       s7, s8, #32
    s.add        s8, s2, s10
    v.extract    s2, v1, #0
    v.insert     v6, s6, #12
    v.extract    s6, v8, #15
    v.insert     v9, s11, #12
    s.or         s10, s12, s13
    .li       s11, #2415902720
    s.or         s12, s2, s7
    s.movz       s2, #2048
    s.lshri      s7, s8, #32
    s.shli       s13, s6, #32
    s.add        s6, s10, s11
    v.extract    s10, v7, #15
    s.mul        s11, s12, s2
    v.insert     v6, s8, #13
    v.insert     v9, s7, #13
    s.or         s2, s10, s13
    .li       s7, #2415902720
    s.lshri      s8, s6, #32
    s.add        s10, s2, s7
    v.insert     v6, s6, #14
    v.insert     v9, s8, #14
    v.movi       v0, #0
    v.movi       v7, #0
    s.lshri      s2, s10, #32
    s.lshri      s6, s11, #32
    v.insert     v6, s10, #15
    v.insert     v9, s2, #15
    v.insert     v0, s11, #0
    v.insert     v7, s6, #0
    v.movi       v8, #0
    v.extract    s2, v0, #0
    v.extract    s6, v7, #0
    v.extract    s7, v7, #0
    s.shli       s8, s6, #32
    v.movi       v10, #0
    s.or         s6, s2, s8
    v.extract    s2, v0, #0
    s.shli       s8, s7, #32
    s.lshri      s7, s6, #32
    v.extract    s10, v7, #0
    s.or         s11, s2, s8
    v.insert     v8, s6, #0
    v.insert     v10, s7, #0
    v.extract    s2, v0, #0
    s.shli       s6, s10, #32
    s.lshri      s7, s11, #32
    v.extract    s8, v7, #0
    s.or         s10, s2, s6
    v.insert     v8, s11, #1
    v.insert     v10, s7, #1
    v.extract    s2, v0, #0
    s.shli       s6, s8, #32
    s.lshri      s7, s10, #32
    v.extract    s8, v7, #0
    s.or         s11, s2, s6
    v.insert     v8, s10, #2
    v.insert     v10, s7, #2
    v.extract    s2, v0, #0
    s.shli       s6, s8, #32
    s.lshri      s7, s11, #32
    v.extract    s8, v7, #0
    s.or         s10, s2, s6
    v.insert     v8, s11, #3
    v.insert     v10, s7, #3
    v.extract    s2, v0, #0
    s.shli       s6, s8, #32
    s.lshri      s7, s10, #32
    v.extract    s8, v7, #0
    s.or         s11, s2, s6
    v.insert     v8, s10, #4
    v.insert     v10, s7, #4
    v.extract    s2, v0, #0
    s.shli       s6, s8, #32
    s.lshri      s7, s11, #32
    v.extract    s8, v7, #0
    s.or         s10, s2, s6
    v.insert     v8, s11, #5
    v.insert     v10, s7, #5
    v.extract    s2, v0, #0
    s.shli       s6, s8, #32
    s.lshri      s7, s10, #32
    v.extract    s8, v7, #0
    s.or         s11, s2, s6
    v.insert     v8, s10, #6
    v.insert     v10, s7, #6
    v.extract    s2, v0, #0
    s.shli       s6, s8, #32
    s.lshri      s7, s11, #32
    v.extract    s8, v7, #0
    s.or         s10, s2, s6
    v.insert     v8, s11, #7
    v.insert     v10, s7, #7
    v.extract    s2, v0, #0
    s.shli       s6, s8, #32
    s.lshri      s7, s10, #32
    v.extract    s8, v7, #0
    s.or         s11, s2, s6
    v.insert     v8, s10, #8
    v.insert     v10, s7, #8
    v.extract    s2, v0, #0
    s.shli       s6, s8, #32
    s.lshri      s7, s11, #32
    v.extract    s8, v7, #0
    s.or         s10, s2, s6
    v.insert     v8, s11, #9
    v.insert     v10, s7, #9
    v.extract    s2, v0, #0
    s.shli       s6, s8, #32
    s.lshri      s7, s10, #32
    v.extract    s8, v7, #0
    s.or         s11, s2, s6
    v.insert     v8, s10, #10
    v.insert     v10, s7, #10
    v.extract    s2, v0, #0
    s.shli       s6, s8, #32
    s.lshri      s7, s11, #32
    v.extract    s8, v7, #0
    s.or         s10, s2, s6
    v.insert     v8, s11, #11
    v.insert     v10, s7, #11
    v.extract    s2, v0, #0
    s.shli       s6, s8, #32
    s.lshri      s7, s10, #32
    v.extract    s8, v7, #0
    s.or         s11, s2, s6
    v.insert     v8, s10, #12
    v.insert     v10, s7, #12
    v.extract    s2, v0, #0
    s.shli       s6, s8, #32
    s.lshri      s7, s11, #32
    v.extract    s8, v7, #0
    s.or         s10, s2, s6
    v.insert     v8, s11, #13
    v.insert     v10, s7, #13
    v.extract    s2, v0, #0
    s.shli       s6, s8, #32
    s.lshri      s7, s10, #32
    s.or         s8, s2, s6
    v.insert     v8, s10, #14
    v.insert     v10, s7, #14
    s.lshri      s2, s8, #32
    v.insert     v8, s8, #15
    v.insert     v10, s2, #15
    v.extract    s2, v9, #0
    v.extract    s6, v6, #0
    v.extract    s7, v10, #0
    s.shli       s8, s2, #32
    v.extract    s2, v8, #0
    s.shli       s10, s7, #32
    v.extract    s7, v9, #1
    v.extract    s11, v10, #1
    s.or         s12, s6, s8
    s.or         s6, s2, s10
    v.movi       v0, #0
    v.extract    s2, v6, #1
    s.shli       s8, s7, #32
    v.extract    s7, v8, #1
    s.shli       s10, s11, #32
    s.add        s11, s12, s6
    v.extract    s6, v9, #2
    v.extract    s12, v10, #2
    s.or         s13, s2, s8
    s.or         s2, s7, s10
    v.movi       v7, #0
    v.insert     v0, s11, #0
    v.extract    s7, v6, #2
    s.shli       s8, s6, #32
    v.extract    s6, v8, #2
    s.shli       s10, s12, #32
    s.lshri      s12, s11, #32
    s.add        s11, s13, s2
    v.extract    s2, v9, #3
    s.or         s13, s7, s8
    v.extract    s7, v10, #3
    s.or         s8, s6, s10
    v.insert     v7, s12, #0
    v.insert     v0, s11, #1
    v.extract    s6, v6, #3
    s.shli       s10, s2, #32
    v.extract    s2, v8, #3
    s.shli       s12, s7, #32
    s.lshri      s7, s11, #32
    s.add        s11, s13, s8
    v.extract    s8, v9, #4
    s.or         s13, s6, s10
    v.extract    s6, v10, #4
    s.or         s10, s2, s12
    v.insert     v7, s7, #1
    v.insert     v0, s11, #2
    v.extract    s2, v6, #4
    s.shli       s7, s8, #32
    v.extract    s8, v8, #4
    s.shli       s12, s6, #32
    s.lshri      s6, s11, #32
    s.add        s11, s13, s10
    v.extract    s10, v9, #5
    s.or         s13, s2, s7
    v.extract    s2, v10, #5
    s.or         s7, s8, s12
    v.insert     v7, s6, #2
    v.insert     v0, s11, #3
    v.extract    s6, v6, #5
    s.shli       s8, s10, #32
    v.extract    s10, v8, #5
    s.shli       s12, s2, #32
    s.lshri      s2, s11, #32
    s.add        s11, s13, s7
    v.extract    s7, v9, #6
    s.or         s13, s6, s8
    v.extract    s6, v10, #6
    s.or         s8, s10, s12
    v.insert     v7, s2, #3
    v.insert     v0, s11, #4
    v.extract    s2, v6, #6
    s.shli       s10, s7, #32
    v.extract    s7, v8, #6
    s.shli       s12, s6, #32
    s.lshri      s6, s11, #32
    s.add        s11, s13, s8
    v.extract    s8, v9, #7
    s.or         s13, s2, s10
    v.extract    s2, v10, #7
    s.or         s10, s7, s12
    v.insert     v7, s6, #4
    v.insert     v0, s11, #5
    v.extract    s6, v6, #7
    s.shli       s7, s8, #32
    v.extract    s8, v8, #7
    s.shli       s12, s2, #32
    s.lshri      s2, s11, #32
    s.add        s11, s13, s10
    v.extract    s10, v9, #8
    s.or         s13, s6, s7
    v.extract    s6, v10, #8
    s.or         s7, s8, s12
    v.insert     v7, s2, #5
    v.insert     v0, s11, #6
    v.extract    s2, v6, #8
    s.shli       s8, s10, #32
    v.extract    s10, v8, #8
    s.shli       s12, s6, #32
    s.lshri      s6, s11, #32
    s.add        s11, s13, s7
    v.extract    s7, v9, #9
    s.or         s13, s2, s8
    v.extract    s2, v10, #9
    s.or         s8, s10, s12
    v.insert     v7, s6, #6
    v.insert     v0, s11, #7
    v.extract    s6, v6, #9
    s.shli       s10, s7, #32
    v.extract    s7, v8, #9
    s.shli       s12, s2, #32
    s.lshri      s2, s11, #32
    s.add        s11, s13, s8
    v.extract    s8, v9, #10
    s.or         s13, s6, s10
    v.extract    s6, v10, #10
    s.or         s10, s7, s12
    v.insert     v7, s2, #7
    v.insert     v0, s11, #8
    v.extract    s2, v6, #10
    s.shli       s7, s8, #32
    v.extract    s8, v8, #10
    s.shli       s12, s6, #32
    s.lshri      s6, s11, #32
    s.add        s11, s13, s10
    v.extract    s10, v9, #11
    s.or         s13, s2, s7
    v.extract    s2, v10, #11
    s.or         s7, s8, s12
    v.insert     v7, s6, #8
    v.insert     v0, s11, #9
    v.extract    s6, v6, #11
    s.shli       s8, s10, #32
    v.extract    s10, v8, #11
    s.shli       s12, s2, #32
    s.lshri      s2, s11, #32
    s.add        s11, s13, s7
    v.extract    s7, v9, #12
    s.or         s13, s6, s8
    v.extract    s6, v10, #12
    s.or         s8, s10, s12
    v.insert     v7, s2, #9
    v.insert     v0, s11, #10
    v.extract    s2, v6, #12
    s.shli       s10, s7, #32
    v.extract    s7, v8, #12
    s.shli       s12, s6, #32
    s.lshri      s6, s11, #32
    s.add        s11, s13, s8
    v.extract    s8, v9, #13
    s.or         s13, s2, s10
    v.extract    s2, v10, #13
    s.or         s10, s7, s12
    v.insert     v7, s6, #10
    v.insert     v0, s11, #11
    v.extract    s6, v6, #13
    s.shli       s7, s8, #32
    v.extract    s8, v8, #13
    s.shli       s12, s2, #32
    s.lshri      s2, s11, #32
    s.add        s11, s13, s10
    v.extract    s10, v9, #14
    s.or         s13, s6, s7
    v.extract    s6, v10, #14
    s.or         s7, s8, s12
    v.insert     v7, s2, #11
    v.insert     v0, s11, #12
    v.extract    s2, v6, #14
    s.shli       s8, s10, #32
    v.extract    s10, v8, #14
    s.shli       s12, s6, #32
    s.lshri      s6, s11, #32
    s.add        s11, s13, s7
    v.extract    s7, v9, #15
    s.or         s13, s2, s8
    v.extract    s2, v10, #15
    s.or         s8, s10, s12
    v.insert     v7, s6, #12
    v.insert     v0, s11, #13
    v.extract    s6, v6, #15
    s.shli       s10, s7, #32
    v.extract    s7, v8, #15
    s.shli       s12, s2, #32
    s.lshri      s2, s11, #32
    s.add        s11, s13, s8
    s.or         s8, s6, s10
    s.or         s6, s7, s12
    v.insert     v7, s2, #13
    v.insert     v0, s11, #14
    s.lshri      s2, s11, #32
    s.add        s7, s8, s6
    v.insert     v7, s2, #14
    v.insert     v0, s7, #15
    v.movi       v6, #31
    s.lshri      s2, s7, #32
    v.movi       v8, #1
    v.insert     v7, s2, #15
    v.ashr       v9, v0, v6
    v.movi       v6, #0
    s.movz       s2, #0
    v.cmp.ne     p2, v7, v9
    @p2 v.sel        v7, v8, v6
    v.reduce.or  s6, v7
    s.cmp.eq     s7, s6, s2
    br.nz        s7, narrow_ok_3
    trap         #677220
narrow_ok_3:
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v6, [s4, v0]              // index is in elements (ISA sec 9.1)
    v.movi       v0, #0
    s.add        s2, s3, s5
    s.movz       s6, #1
    vf.cvt.s32.f32 v7, v6
    vf.add       v6, v5, v7
    @p1 v.sel        v7, v6, v5
    v.mov        v0, v7
    v.mov        v5, v0
    s.mov        s3, s2
    br.nz        s6, for_1
endfor_2:
    v.movi       v0, #31
    v.movi       v3, #1
    v.movi       v4, #0
    v.ashr       v6, v1, v0
    s.movz       s1, #1
    v.iota       v0                              // arange(0, VLEN)
    v.cmp.ne     p1, v2, v6
    v.splat      v2, s1
    @p1 v.sel        v6, v3, v4
    s.movz       s1, #0
    v.cmp.lt     p1, v0, v2
    @p1 v.reduce.or  s2, v6
    vf.reduce.add.b v0, v5
    v.movi       v2, #0
    s.cmp.eq     s3, s2, s1
    vf.add       v3, v0, v2
    br.nz        s3, narrow_ok_4
    trap         #677220
narrow_ok_4:
    s.movz       s1, #1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s1
    v.cmp.lt     p1, v0, v2
    @p1 v.st.scatter.w [s9, v1], v3
__rctx_next:
    exit
