    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.shli       s4, s2, #1                      // element offset -> bytes (x2)
    .li       s5, #1027024659
    v.splat      v0, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s5, s3, s4                      // &in_ptr0[...]
    .li       s3, #1061962282
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.h       v2, [s5, #0]
    .li       s3, #3221225472
    v.splat      v3, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1069066811
    v.splat      v4, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1060205080
    v.splat      v5, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1065353216
    v.splat      v6, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1065353216
    v.splat      v7, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.f16.f32 v8, v2
    v.movi       v2, #0
    .li       s3, #1056964608
    v.splat      v9, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    vf.mul       v10, v8, v8
    vf.mul       v11, v8, v9
    s.add        s1, s3, s4                      // &out_ptr0[...]
    vf.mul       v9, v10, v8
    vf.mul       v10, v9, v0
    v.iota       v0                              // arange(0, VLEN)
    vf.add       v9, v8, v10
    v.splat      v8, s2
    v.add        v10, v8, v0
    vf.mul       v0, v9, v1
    vf.abs       v1, v0
    vf.cmp.lt    p1, v0, v2
    vf.mul       v0, v1, v3
    vf.mul       v1, v0, v4
    v.exp2.approx v2, v1                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v0, v4, v1                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v3, v5
    vf.fma       v1, v2, v0, v2                  // 2**t * 2**d
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v0, v1, v2
    vf.add       v1, v0, v6
    vf.sub       v2, v6, v0
    v.rcp.approx v0, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v1, v0, v7
    vf.fms       v1, v0, v3, v0
    vf.neg       v3, v1                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v1, v3, v0
    vf.mul       v0, v2, v1                      // a/y as a refined reciprocal (ISA has no divide)
    vf.neg       v1, v0
    @p1 v.sel        v2, v1, v0
    vf.add       v0, v2, v6
    vf.mul       v1, v11, v0
    vf.cvt.f32.f16 v0, v1
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
