    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    v.splat      v0, s4
    v.movi       v1, #96
    s.add        s3, s1, s5                      // this context's own scratch
    v.movi       v2, #0
    s.ld.d       s1, [s2, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.addi       s5, s3, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s6, #384
    s.movz       s7, #96
    s.movz       s8, #384
    s.movz       s9, #4
    .li       s10, #68719476737
    v.sub        v3, v2, v0
    v.sub        v4, v2, v1
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    s.ld.d       s11, [s2, #0]                   // in_out_ptr0: device_ptr64 at arg_base+0
    s.movz       s2, #0
    v.iota       v5                              // arange(0, VLEN)
    s.st.d       [s5, #0], s1
    v.movi       v6, #1
    @p1 v.sel        v7, v3, v0
    s.st.d       [s5, #8], s6
    .li       s2, #2207613190144
    @p2 v.sel        v0, v4, v1
    s.st.d       [s5, #16], s7
    v.movi       v1, #0
    v.movi       v3, #0
    s.st.d       [s5, #48], s8
    s.movz       s6, #31
    s.st.d       [s5, #56], s9
    s.st.d       [s5, #88], s10
    s.st.d       [s5, #104], s2
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
idiv_1:
    v.splat      v4, s6
    v.shl        v8, v3, v6
    v.lshr       v9, v7, v4
    v.cmp.lt     p2, v3, v2
    v.and        v10, v9, v6
    v.shl        v9, v6, v4
    v.or         v4, v8, v10
    s.subi       s2, s6, #1
    v.cmp.geu    p3, v4, v0
    p.or         p4, p2, p3
    v.sub        v8, v4, v0
    @p4 v.sel        v10, v9, v2
    @p4 v.sel        v9, v8, v4
    v.or         v4, v1, v10
    v.mov        v3, v9
    v.mov        v1, v4
    s.mov        s6, s2
    s.movz       s2, #0
    s.cmp.ge     s5, s6, s2
    br.nz        s5, idiv_1
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v4, v2, v3
    s.movz       s2, #0
    .li       s5, #4286578688
    v.splat      v2, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v6, #0
    v.cmp.ne     p2, v0, v1
    @p1 v.sel        v0, v4, v3
    s.movz       s5, #96
    s.movz       s6, #16
    s.addi       s7, s2, #0
    p.mov        p1, p2
    v.mov        v6, v2
for_2:
    s.cmp.ge     s8, s7, s5
    br.nz        s8, endfor_3
    v.movi       v1, #-1
    v.splat      v3, s7
    v.mul        v4, v0, v1
    v.add        v1, v3, v5
    v.extract    s8, v4, #0
    v.splat      v3, s8
    s.muli       s8, s4, #384
    v.splat      v4, s7
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s9, #96
    s.movz       s10, #384
    v.add        v8, v1, v3
    s.muli       s12, s7, #4
    v.add        v3, v4, v7
    v.movi       v4, #0
    v.splat      v7, s9
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s10
    v.extract    s9, v8, #0
    s.shli       s10, s9, #32
    v.cmp.ge     p2, v3, v4
    v.cmp.lt     p3, v3, v7
    v.cmp.ge     p4, v9, v10
    v.cmp.lt     p5, v9, v11
    v.extract    s9, v8, #1
    s.add        s13, s1, s8
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.ashri      s8, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v8, #2
    s.add        s14, s13, s12
    p.and        p3, p6, p2
    v.movi       v3, #0
    v.movi       v4, #0
    s.lshri      s12, s8, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s9, #32
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v7, [s14, #0]
    v.insert     v3, s8, #0
    v.insert     v4, s12, #0
    s.lshri      s8, s13, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s13, #1
    v.insert     v4, s8, #1
    v.insert     v3, s9, #2
    v.movi       v9, #96
    s.lshri      s8, s9, #32
    v.cmp.lt     p2, v1, v9
    v.extract    s9, v8, #3
    s.shli       s10, s9, #32
    v.extract    s9, v8, #4
    s.ashri      s12, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v8, #5
    v.insert     v4, s8, #2
    s.lshri      s8, s12, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v8, #6
    v.insert     v3, s12, #3
    v.insert     v4, s8, #3
    s.lshri      s8, s13, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s9, #32
    v.insert     v3, s13, #4
    v.insert     v4, s8, #4
    s.lshri      s8, s12, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s12, #5
    v.insert     v4, s8, #5
    v.insert     v3, s9, #6
    .li       s8, #-1
    v.extract    s8, v8, #7
    s.shli       s10, s8, #32
    v.extract    s8, v8, #8
    s.lshri      s12, s9, #32
    s.ashri      s9, s10, #32
    s.shli       s10, s8, #32
    v.extract    s8, v8, #9
    v.insert     v4, s12, #6
    s.lshri      s12, s9, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s8, #32
    v.extract    s8, v8, #10
    v.insert     v3, s9, #7
    v.insert     v4, s12, #7
    s.lshri      s9, s13, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s8, #32
    v.extract    s8, v8, #11
    v.insert     v3, s13, #8
    v.insert     v4, s9, #8
    s.lshri      s9, s12, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s8, #32
    v.extract    s8, v8, #12
    v.insert     v3, s12, #9
    v.insert     v4, s9, #9
    s.lshri      s9, s13, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s8, #32
    v.extract    s8, v8, #13
    v.insert     v3, s13, #10
    v.insert     v4, s9, #10
    s.lshri      s9, s12, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s8, #32
    v.extract    s8, v8, #14
    v.insert     v3, s12, #11
    v.insert     v4, s9, #11
    s.lshri      s9, s13, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s8, #32
    v.extract    s8, v8, #15
    v.insert     v3, s13, #12
    v.insert     v4, s9, #12
    s.lshri      s9, s12, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s8, #32
    v.insert     v3, s12, #13
    v.insert     v4, s9, #13
    s.lshri      s8, s13, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s13, #14
    v.insert     v4, s8, #14
    s.lshri      s8, s9, #32
    v.insert     v3, s9, #15
    v.insert     v4, s8, #15
    v.extract    s8, v3, #0
    v.extract    s9, v4, #0
    s.shli       s10, s9, #32
    v.extract    s9, v4, #1
    s.or         s12, s8, s10
    s.movz       s8, #0
    s.shli       s10, s9, #32
    v.extract    s9, v3, #1
    v.extract    s13, v4, #2
    v.movi       v1, #0
    s.cmp.le     s14, s12, s8
    s.or         s8, s9, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v3, #2
    v.extract    s13, v4, #3
    v.insert     v1, s14, #0
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v3, #3
    v.extract    s13, v4, #4
    v.insert     v1, s14, #1
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v3, #4
    v.extract    s13, v4, #5
    v.insert     v1, s14, #2
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v3, #5
    v.extract    s13, v4, #6
    v.insert     v1, s14, #3
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v3, #6
    v.extract    s13, v4, #7
    v.insert     v1, s14, #4
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v3, #7
    v.extract    s13, v4, #8
    v.insert     v1, s14, #5
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v3, #8
    v.extract    s13, v4, #9
    v.insert     v1, s14, #6
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v3, #9
    v.extract    s13, v4, #10
    v.insert     v1, s14, #7
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v3, #10
    v.extract    s13, v4, #11
    v.insert     v1, s14, #8
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v3, #11
    v.extract    s13, v4, #12
    v.insert     v1, s14, #9
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v3, #12
    v.extract    s13, v4, #13
    v.insert     v1, s14, #10
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v3, #13
    v.extract    s13, v4, #14
    v.insert     v1, s14, #11
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v3, #14
    v.extract    s13, v4, #15
    v.insert     v1, s14, #12
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v3, #15
    v.insert     v1, s14, #13
    s.cmp.le     s13, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    v.insert     v1, s13, #14
    s.cmp.le     s10, s8, s9
    v.movi       v3, #0
    v.insert     v1, s10, #15
    v.movi       v4, #0
    v.cmp.ne     p3, v1, v3
    @p3 v.sel        v1, v4, v2
    v.movi       v3, #1
    vf.add       v4, v7, v1
    v.movi       v1, #0
    v.movi       v7, #0
    v.movi       v8, #1
    vf.cmp.eq    p3, v4, v2
    @p3 v.sel        v9, v3, v1
    v.movi       v1, #0
    v.cmp.eq     p3, v9, v7
    @p3 v.sel        v3, v8, v1
    v.movi       v1, #1
    v.movi       v7, #0
    v.extract    s8, v3, #0
    @p3 v.sel        v3, v1, v7
    v.movi       v1, #1
    v.movi       v7, #0
    v.movi       v8, #0
    v.movi       v9, #0
    s.lshri      s9, s8, #32
    v.extract    s10, v3, #1
    @p3 v.sel        v3, v1, v7
    v.movi       v1, #1
    v.movi       v7, #0
    v.insert     v8, s8, #0
    v.insert     v9, s9, #0
    s.lshri      s8, s10, #32
    v.extract    s9, v3, #2
    @p3 v.sel        v3, v1, v7
    v.movi       v1, #1
    v.movi       v7, #0
    v.insert     v8, s10, #1
    v.insert     v9, s8, #1
    s.lshri      s8, s9, #32
    v.extract    s10, v3, #3
    @p3 v.sel        v3, v1, v7
    v.movi       v1, #1
    v.movi       v7, #0
    v.insert     v8, s9, #2
    v.insert     v9, s8, #2
    s.lshri      s8, s10, #32
    v.extract    s9, v3, #4
    @p3 v.sel        v3, v1, v7
    v.movi       v1, #1
    v.movi       v7, #0
    v.insert     v8, s10, #3
    v.insert     v9, s8, #3
    s.lshri      s8, s9, #32
    v.extract    s10, v3, #5
    @p3 v.sel        v3, v1, v7
    v.movi       v1, #1
    v.movi       v7, #0
    v.insert     v8, s9, #4
    v.insert     v9, s8, #4
    s.lshri      s8, s10, #32
    v.extract    s9, v3, #6
    @p3 v.sel        v3, v1, v7
    v.movi       v1, #1
    v.movi       v7, #0
    v.insert     v8, s10, #5
    v.insert     v9, s8, #5
    s.lshri      s8, s9, #32
    v.extract    s10, v3, #7
    @p3 v.sel        v3, v1, v7
    v.movi       v1, #1
    v.movi       v7, #0
    v.insert     v8, s9, #6
    v.insert     v9, s8, #6
    s.lshri      s8, s10, #32
    v.extract    s9, v3, #8
    @p3 v.sel        v3, v1, v7
    v.movi       v1, #1
    v.movi       v7, #0
    v.insert     v8, s10, #7
    v.insert     v9, s8, #7
    s.lshri      s8, s9, #32
    v.extract    s10, v3, #9
    @p3 v.sel        v3, v1, v7
    v.movi       v1, #1
    v.movi       v7, #0
    v.insert     v8, s9, #8
    v.insert     v9, s8, #8
    s.lshri      s8, s10, #32
    v.extract    s9, v3, #10
    @p3 v.sel        v3, v1, v7
    v.movi       v1, #1
    v.movi       v7, #0
    v.insert     v8, s10, #9
    v.insert     v9, s8, #9
    s.lshri      s8, s9, #32
    v.extract    s10, v3, #11
    @p3 v.sel        v3, v1, v7
    v.movi       v1, #1
    v.movi       v7, #0
    v.insert     v8, s9, #10
    v.insert     v9, s8, #10
    s.lshri      s8, s10, #32
    v.extract    s9, v3, #12
    @p3 v.sel        v3, v1, v7
    v.movi       v1, #1
    v.movi       v7, #0
    v.insert     v8, s10, #11
    v.insert     v9, s8, #11
    s.lshri      s8, s9, #32
    v.extract    s10, v3, #13
    @p3 v.sel        v3, v1, v7
    v.movi       v1, #1
    v.movi       v7, #0
    v.insert     v8, s9, #12
    v.insert     v9, s8, #12
    s.lshri      s8, s10, #32
    v.extract    s9, v3, #14
    @p3 v.sel        v3, v1, v7
    v.insert     v8, s10, #13
    v.insert     v9, s8, #13
    s.lshri      s8, s9, #32
    v.extract    s10, v3, #15
    v.insert     v8, s9, #14
    v.insert     v9, s8, #14
    s.lshri      s8, s10, #32
    v.insert     v8, s10, #15
    v.insert     v9, s8, #15
    v.extract    s8, v8, #0
    v.extract    s9, v9, #0
    s.shli       s10, s9, #32
    v.extract    s9, v9, #1
    s.or         s12, s8, s10
    s.movz       s8, #0
    s.shli       s10, s9, #32
    v.extract    s9, v8, #1
    v.extract    s13, v9, #2
    v.movi       v1, #0
    s.cmp.ne     s14, s12, s8
    s.or         s8, s9, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v8, #2
    v.extract    s13, v9, #3
    v.insert     v1, s14, #0
    s.cmp.ne     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v8, #3
    v.extract    s13, v9, #4
    v.insert     v1, s14, #1
    s.cmp.ne     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v8, #4
    v.extract    s13, v9, #5
    v.insert     v1, s14, #2
    s.cmp.ne     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v8, #5
    v.extract    s13, v9, #6
    v.insert     v1, s14, #3
    s.cmp.ne     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v8, #6
    v.extract    s13, v9, #7
    v.insert     v1, s14, #4
    s.cmp.ne     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v8, #7
    v.extract    s13, v9, #8
    v.insert     v1, s14, #5
    s.cmp.ne     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v8, #8
    v.extract    s13, v9, #9
    v.insert     v1, s14, #6
    s.cmp.ne     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v8, #9
    v.extract    s13, v9, #10
    v.insert     v1, s14, #7
    s.cmp.ne     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v8, #10
    v.extract    s13, v9, #11
    v.insert     v1, s14, #8
    s.cmp.ne     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v8, #11
    v.extract    s13, v9, #12
    v.insert     v1, s14, #9
    s.cmp.ne     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v8, #12
    v.extract    s13, v9, #13
    v.insert     v1, s14, #10
    s.cmp.ne     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v8, #13
    v.extract    s13, v9, #14
    v.insert     v1, s14, #11
    s.cmp.ne     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v8, #14
    v.extract    s13, v9, #15
    v.insert     v1, s14, #12
    s.cmp.ne     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v8, #15
    v.insert     v1, s14, #13
    s.cmp.ne     s13, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    v.insert     v1, s13, #14
    s.cmp.ne     s10, s8, s9
    v.movi       v3, #0
    v.insert     v1, s10, #15
    p.not        p3, p2
    v.cmp.ne     p4, v1, v3
    p.or         p5, p1, p4
    vf.max       v1, v6, v4
    p.and        p4, p2, p5
    p.and        p5, p3, p1
    v.movi       v3, #0
    p.or         p3, p4, p5
    @p2 v.sel        v4, v1, v6
    p.mov        p2, p3
    v.mov        v3, v4
    s.add        s8, s7, s6
    s.movz       s9, #1
    p.mov        p1, p2
    v.mov        v6, v3
    s.mov        s7, s8
    br.nz        s9, for_2
endfor_3:
    v.movi       v1, #1
    v.movi       v3, #0
    vf.cmp.uo    p2, v6, v6
    @p2 v.sel        v4, v1, v3
    v.movi       v1, #1
    v.movi       v3, #0
    v.reduce.or.b v7, v4
    v.movi       v4, #0
    vf.reduce.max.b v8, v6
    .li       s7, #2143289344
    v.splat      v6, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v9, v1, v3
    v.cmp.ne     p1, v7, v4
    @p1 v.sel        v1, v6, v8
    v.movi       v3, #0
    v.movi       v4, #0
    v.movi       v6, #0
    v.reduce.or  s7, v9
    v.splat      v7, s7
    vf.add       v8, v1, v3
    s.addi       s7, s2, #0
    v.mov        v6, v4
for_4:
    s.cmp.ge     s8, s7, s5
    br.nz        s8, endfor_5
    v.movi       v1, #-1
    v.splat      v9, s7
    v.mul        v10, v0, v1
    v.add        v1, v9, v5
    v.extract    s8, v10, #0
    v.splat      v9, s8
    s.muli       s8, s4, #384
    v.splat      v10, s7
    v.iota       v11                             // arange(0, VLEN)
    s.movz       s9, #96
    s.movz       s10, #384
    v.add        v12, v1, v9
    s.muli       s12, s7, #4
    v.add        v9, v10, v11
    v.movi       v10, #0
    v.splat      v11, s9
    v.splat      v13, s4
    v.movi       v14, #0
    v.splat      v15, s10
    v.extract    s9, v12, #0
    s.shli       s10, s9, #32
    v.cmp.ge     p1, v9, v10
    v.cmp.lt     p2, v9, v11
    v.cmp.ge     p3, v13, v14
    v.cmp.lt     p4, v13, v15
    v.extract    s9, v12, #1
    s.add        s13, s1, s8
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.ashri      s8, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v12, #2
    s.add        s14, s13, s12
    p.and        p2, p5, p1
    v.movi       v9, #0
    v.movi       v10, #0
    s.lshri      s12, s8, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s9, #32
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v11, [s14, #0]
    v.insert     v9, s8, #0
    v.insert     v10, s12, #0
    s.lshri      s8, s13, #32
    s.ashri      s9, s10, #32
    v.insert     v9, s13, #1
    v.insert     v10, s8, #1
    v.insert     v9, s9, #2
    v.movi       v13, #96
    s.lshri      s8, s9, #32
    v.cmp.lt     p1, v1, v13
    v.extract    s9, v12, #3
    s.shli       s10, s9, #32
    v.extract    s9, v12, #4
    s.ashri      s12, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v12, #5
    v.insert     v10, s8, #2
    s.lshri      s8, s12, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v12, #6
    v.insert     v9, s12, #3
    v.insert     v10, s8, #3
    s.lshri      s8, s13, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s9, #32
    v.insert     v9, s13, #4
    v.insert     v10, s8, #4
    s.lshri      s8, s12, #32
    s.ashri      s9, s10, #32
    v.insert     v9, s12, #5
    v.insert     v10, s8, #5
    v.insert     v9, s9, #6
    .li       s8, #-1
    v.extract    s8, v12, #7
    s.shli       s10, s8, #32
    v.extract    s8, v12, #8
    s.lshri      s12, s9, #32
    s.ashri      s9, s10, #32
    s.shli       s10, s8, #32
    v.extract    s8, v12, #9
    v.insert     v10, s12, #6
    s.lshri      s12, s9, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s8, #32
    v.extract    s8, v12, #10
    v.insert     v9, s9, #7
    v.insert     v10, s12, #7
    s.lshri      s9, s13, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s8, #32
    v.extract    s8, v12, #11
    v.insert     v9, s13, #8
    v.insert     v10, s9, #8
    s.lshri      s9, s12, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s8, #32
    v.extract    s8, v12, #12
    v.insert     v9, s12, #9
    v.insert     v10, s9, #9
    s.lshri      s9, s13, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s8, #32
    v.extract    s8, v12, #13
    v.insert     v9, s13, #10
    v.insert     v10, s9, #10
    s.lshri      s9, s12, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s8, #32
    v.extract    s8, v12, #14
    v.insert     v9, s12, #11
    v.insert     v10, s9, #11
    s.lshri      s9, s13, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s8, #32
    v.extract    s8, v12, #15
    v.insert     v9, s13, #12
    v.insert     v10, s9, #12
    s.lshri      s9, s12, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s8, #32
    v.insert     v9, s12, #13
    v.insert     v10, s9, #13
    s.lshri      s8, s13, #32
    s.ashri      s9, s10, #32
    v.insert     v9, s13, #14
    v.insert     v10, s8, #14
    s.lshri      s8, s9, #32
    v.insert     v9, s9, #15
    v.insert     v10, s8, #15
    v.extract    s8, v9, #0
    v.extract    s9, v10, #0
    s.shli       s10, s9, #32
    v.extract    s9, v10, #1
    s.or         s12, s8, s10
    s.movz       s8, #0
    s.shli       s10, s9, #32
    v.extract    s9, v9, #1
    v.extract    s13, v10, #2
    v.movi       v12, #0
    s.cmp.le     s14, s12, s8
    s.or         s8, s9, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v9, #2
    v.extract    s13, v10, #3
    v.insert     v12, s14, #0
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v9, #3
    v.extract    s13, v10, #4
    v.insert     v12, s14, #1
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v9, #4
    v.extract    s13, v10, #5
    v.insert     v12, s14, #2
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v9, #5
    v.extract    s13, v10, #6
    v.insert     v12, s14, #3
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v9, #6
    v.extract    s13, v10, #7
    v.insert     v12, s14, #4
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v9, #7
    v.extract    s13, v10, #8
    v.insert     v12, s14, #5
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v9, #8
    v.extract    s13, v10, #9
    v.insert     v12, s14, #6
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v9, #9
    v.extract    s13, v10, #10
    v.insert     v12, s14, #7
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v9, #10
    v.extract    s13, v10, #11
    v.insert     v12, s14, #8
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v9, #11
    v.extract    s13, v10, #12
    v.insert     v12, s14, #9
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v9, #12
    v.extract    s13, v10, #13
    v.insert     v12, s14, #10
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v9, #13
    v.extract    s13, v10, #14
    v.insert     v12, s14, #11
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v9, #14
    v.extract    s13, v10, #15
    v.insert     v12, s14, #12
    s.cmp.le     s14, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s12, v9, #15
    v.insert     v12, s14, #13
    s.cmp.le     s13, s8, s9
    s.or         s8, s12, s10
    s.movz       s9, #0
    v.insert     v12, s13, #14
    s.cmp.le     s10, s8, s9
    v.movi       v9, #0
    v.insert     v12, s10, #15
    v.extract    s8, v8, #0
    v.cmp.ne     p2, v12, v9
    @p2 v.sel        v9, v4, v2
    v.splat      v10, s8
    vf.add       v12, v11, v9
    .li       s8, #1069066811
    v.splat      v9, s8                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s8, #1060205080
    v.splat      v11, s8                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.mul        s8, s4, s5
    vf.sub       v13, v12, v10
    v.movi       v10, #0
    s.add        s9, s7, s6
    s.movz       s10, #1
    vf.mul       v12, v13, v9
    s.add        s12, s7, s8
    v.splat      v14, s8
    s.shli       s8, s12, #2                     // element offset -> bytes (x4)
    v.exp2.approx v15, v12                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v16, v13, v9, v12               // the exact rounding error of x*log2(e)
    s.add        s12, s11, s8                    // &in_out_ptr0[...]
    v.add        v9, v1, v14
    vf.mul       v1, v16, v11
    vf.fma       v9, v15, v1, v15                // 2**t * 2**d
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v1, v9, v15
    vf.add       v9, v6, v1
    @p1 v.st.w       [s12, #0], v1
    @p1 v.sel        v1, v9, v6
    v.mov        v10, v1
    v.mov        v6, v10
    s.mov        s7, s9
    br.nz        s10, for_4
endfor_5:
    vf.reduce.add.b v0, v6
    vf.add       v1, v0, v3
    s.addi       s1, s3, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s3, #0
    s.st.d       [s1, #0], s11
    s.movz       s3, #384
    s.st.d       [s1, #8], s3
    s.movz       s3, #96
    s.st.d       [s1, #16], s3
    s.movz       s3, #384
    s.st.d       [s1, #48], s3
    s.movz       s3, #4
    s.st.d       [s1, #56], s3
    .li       s3, #68719476737
    s.st.d       [s1, #88], s3
    .li       s3, #2207613190144
    s.st.d       [s1, #104], s3
    fence.release.device
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s1, s2, #0
for_6:
    s.cmp.ge     s2, s1, s5
    br.nz        s2, endfor_7
    v.extract    s2, v1, #0
    v.splat      v0, s2
    s.muli       s2, s4, #384
    v.rcp.approx v2, v0                          // ISA 8.8: <= 2**-22 relative
    v.splat      v3, s1
    v.iota       v6                              // arange(0, VLEN)
    s.movz       s3, #96
    s.movz       s7, #384
    s.muli       s8, s1, #4
    v.add        v8, v3, v6
    v.movi       v3, #0
    v.splat      v6, s3
    v.splat      v9, s4
    v.movi       v10, #0
    v.cmp.ge     p1, v8, v3
    v.splat      v3, s7
    v.cmp.lt     p2, v8, v6
    .li       s3, #1065353216
    v.splat      v6, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v3
    s.add        s3, s11, s2
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s2, s3, s8
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v3, [s2, #0]
    v.movi       v8, #0
    s.mul        s2, s4, s5
    v.movi       v9, #1
    vf.fms       v10, v0, v2, v6
    v.movi       v0, #0
    v.cmp.eq     p1, v7, v8
    @p1 v.sel        v6, v9, v0
    vf.fms       v0, v2, v10, v2
    v.extract    s3, v6, #0
    v.splat      v6, s1
    v.splat      v8, s3
    vf.neg       v9, v0                          // Newton step: r0*(2 - x*r0)
    v.movi       v0, #0
    v.add        v10, v6, v5
    v.movi       v6, #96
    vf.cmp.o     p1, v9, v9
    @p1 v.sel        v11, v9, v2
    s.add        s3, s1, s2
    vf.mul       v2, v3, v11                     // a/y as a refined reciprocal (ISA has no divide)
    v.cmp.ne     p1, v8, v0
    v.splat      v0, s2
    v.cmp.lt     p2, v10, v6
    s.shli       s2, s3, #2                      // element offset -> bytes (x4)
    @p1 v.sel        v3, v4, v2
    s.add        s3, s11, s2                     // &in_out_ptr0[...]
    s.add        s2, s1, s6
    s.movz       s7, #1
    v.add        v2, v10, v0
    @p2 v.st.w       [s3, #0], v3
    s.mov        s1, s2
    br.nz        s7, for_6
endfor_7:
__rctx_next:
    exit
