import subprocess,pathlib,itertools,json
out=pathlib.Path('/tmp/r40_p0b_results');out.mkdir(exist_ok=False)
results=[]
def call(args):
 p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=600)
 if p.returncode or 'FATAL' in p.stdout or '\nFAIL' in p.stdout:raise RuntimeError(str(args)+'\n'+p.stdout)
 return p.stdout
for sync,reg in ((0,0),(1,0),(0,1),(1,1)):
 for ranges,policy in itertools.product((0,1),(0,2,46,74)):
  call(['iverilog','-g2012','-I','rtl/common','-s','tb_nuca_slice',f'-Ptb_nuca_slice.SYNC_TAG_BANK={sync}',f'-Ptb_nuca_slice.REGISTER_VICTIM_OWNER={reg}',f'-Ptb_nuca_slice.EPOCH_CHURN={reg}',f'-Ptb_nuca_slice.DCO_REGISTERED_RANGES={ranges}',f'-Ptb_nuca_slice.POLICY={policy}','-Ptb_nuca_slice.MAINTENANCE=1','-o',str(out/'case.vvp'),'rtl/nuca/tnca_nuca_slice.v','tb/common/tnca_dram_model.v','tb/nuca/tb_nuca_slice.v'])
  for seed in (1,7):
   text=call(['vvp',str(out/'case.vvp'),'+nreq=20000',f'+seed={seed}','+min_wb=1']);assert 'PASS' in text.splitlines(),text
   results.append(dict(sync=sync,registered_owner=reg,ranges=ranges,policy=policy,seed=seed,output=text));print('PASS',sync,reg,ranges,policy,seed,flush=True)
   (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
