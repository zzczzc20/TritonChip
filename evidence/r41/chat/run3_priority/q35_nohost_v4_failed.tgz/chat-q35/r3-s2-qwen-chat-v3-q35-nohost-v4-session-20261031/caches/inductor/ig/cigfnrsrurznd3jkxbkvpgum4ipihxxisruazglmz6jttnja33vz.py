
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton.jit
def _triton_helper_fn_add0(arg0_0, arg1_0):
    tmp0 = arg0_0 + arg1_0
    return tmp0

@triton_heuristics.reduction(
    size_hints={'x': 32, 'r0_': 64},
    reduction_hint=ReductionHint.OUTER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*fp32', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_constant_pad_nd_cumsum_exp_mul_neg_softplus_transpose_view_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 3, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1088, 'r0_': 49152}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_constant_pad_nd_cumsum_exp_mul_neg_softplus_transpose_view_5(in_ptr0, in_ptr1, in_ptr2, out_ptr1, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 32
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), None).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = libdevice.exp(tmp1)
    tmp3 = -tmp2
    tmp33 = tl.full([1], float('nan'), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp4 = (r0_1).to(tl.int32)
        tmp5 = tl.full([1], 0, tl.int64)
        tmp6 = tmp4 >= tmp5
        tmp7 = (r0_1).to(tl.int64)
        tmp8 = (tmp7).to(tl.int64)
        tmp9 = tl.full([1], 15, tl.int64)
        tmp10 = tmp8 < tmp9
        tmp11 = tl.load(in_ptr1 + (x0 + 32*(r0_1)), r0_mask & tmp10, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tl.load(in_ptr2 + (tl.broadcast_to(x0, [R0_BLOCK])), r0_mask & tmp10, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tmp12 + tmp14
        tmp16 = tl.full([1], 20.0, tl.float32)
        tmp17 = tmp15 > tmp16
        tmp18 = libdevice.exp(tmp15)
        tmp19 = libdevice.log1p(tmp18)
        tmp20 = tl.where(tmp17, tmp15, tmp19)
        tmp21 = tmp3 * tmp20
        tmp22 = tl.full(tmp21.shape, 0.0, tmp21.dtype)
        tmp23 = tl.where(tmp10, tmp21, tmp22)
        tmp24 = tmp4 >= tmp9
        tmp25 = tl.full([1], 64, tl.int64)
        tmp26 = tmp4 < tmp25
        tmp27 = tl.full([1], 0.0, tl.float32)
        tmp28 = tl.full(tmp27.shape, 0.0, tmp27.dtype)
        tmp29 = tl.where(tmp24, tmp27, tmp28)
        tmp30 = tl.where(tmp10, tmp23, tmp29)
        tmp31 = tmp30.to(tl.float32)
        tmp32 = tl.broadcast_to(tmp31, [R0_BLOCK])
        tmp34, = tl.associative_scan((tmp32,), 0, _triton_helper_fn_add0)
        tmp35 = triton_helpers.select_one((tmp34), rbase == (RBLOCK - 1), dim=-1, keep_dims=True)
        tmp36 = tmp33 + tmp35
        tmp37 = tmp33 + tmp34
        tmp38 = tl.where(roffset > 0, tmp37, tmp34)
        tmp33 = tl.where(roffset > 0, tmp36, tmp35)
        tmp39 = libdevice.exp(tmp38)
        tl.store(out_ptr1 + (r0_1 + 64*x0), tmp38, r0_mask)
        tl.store(out_ptr2 + (r0_1 + 64*x0), tmp39, r0_mask)
        tl.store(out_ptr3 + (r0_1 + 64*x0), tmp39, r0_mask)
