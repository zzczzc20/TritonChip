    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #2
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #1
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s8, #0
    s.cmp.lt     s13, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s13
    s.sub        s11, s8, s9
    s.xor        s8, s12, s3
    s.muli       s9, s5, #2
    s.movz       s5, #0
    s.movz       s13, #1
    s.xor        s14, s4, s11
    s.sub        s15, s8, s3
    s.rdspecial  s3, arg_base
    s.xor        s8, s1, s7
    s.movz       s16, #0
    s.sub        s17, s14, s11
    s.addi       s14, s5, #0
    s.cmp.eq     s5, s15, s13
    s.ld.d       s13, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s18, s8, s7
    s.sub        s7, s2, s9
    s.addi       s2, s16, #0
    s.ld.d       s7, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s8, [s3, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s9, [s3, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s16, [s3, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s18, [s3, #40]                  // out_ptr0: device_ptr64 at arg_base+40
    s.mov        s14, s17
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s14, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s17, s3
    s.shli       s19, s2, #1
    s.andi       s20, s5, #1
    s.movz       s5, #0
    s.or         s21, s19, s20
    s.movz       s19, #1
    s.cmp.geu    s20, s21, s15
    s.shl        s22, s19, s3
    s.sub        s19, s5, s20
    s.subi       s5, s3, #1
    s.and        s20, s15, s19
    s.and        s23, s22, s19
    s.sub        s19, s21, s20
    s.or         s20, s14, s23
    s.mov        s2, s19
    s.mov        s14, s20
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s19, s3, s5
    br.nz        s19, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s14, s4, s3
    s.movz       s3, #0
    s.sub        s15, s5, s14
    s.movz       s5, #0
    s.xor        s14, s4, s15
    s.movz       s4, #0
    s.sub        s17, s14, s15
    s.cmp.lt     s14, s12, s3
    s.lshri      s3, s17, #1
    s.movz       s19, #0
    s.muli       s20, s3, #2
    s.movz       s3, #0
    s.sub        s21, s4, s14
    s.movz       s4, #0
    s.cmp.lt     s14, s1, s19
    s.sub        s19, s17, s20
    s.xor        s17, s12, s21
    s.xor        s12, s19, s15
    s.xor        s19, s2, s11
    s.sub        s2, s12, s15
    s.sub        s12, s4, s14
    s.cmp.lt     s4, s2, s5
    s.sub        s5, s17, s21
    s.sub        s14, s3, s4
    s.movz       s3, #0
    s.xor        s4, s2, s14
    s.movz       s2, #1
    s.sub        s15, s19, s11
    s.xor        s11, s1, s12
    s.sub        s17, s4, s14
    s.movz       s4, #0
    s.addi       s19, s3, #0
    s.cmp.eq     s3, s5, s2
    s.add        s2, s10, s15
    s.sub        s10, s11, s12
    s.addi       s10, s4, #0
    s.mov        s19, s17
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s19, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s17, s3
    s.shli       s11, s10, #1
    s.andi       s12, s4, #1
    s.movz       s4, #0
    s.or         s15, s11, s12
    s.movz       s11, #1
    s.cmp.geu    s12, s15, s5
    s.shl        s20, s11, s3
    s.sub        s11, s4, s12
    s.subi       s4, s3, #1
    s.and        s12, s5, s11
    s.and        s22, s20, s11
    s.sub        s11, s15, s12
    s.or         s12, s19, s22
    s.mov        s10, s11
    s.mov        s19, s12
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s11, s3, s4
    br.nz        s11, sdiv_4
sdiv_done_3:
    s.movz       s3, #16
    s.movz       s4, #8
    s.mul        s5, s2, s3
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.rdspecial  s10, arg_base
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s4
    s.ld.d       s11, [s10, #48]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.andi       s10, s5, #15
    v.cmp.lt     p1, v0, v1
    s.muli       s12, s10, #8                    // a runtime tile origin, x8
    s.rdspecial  s15, role_id
    s.movz       s17, #512
    s.xor        s20, s14, s21
    s.mul        s14, s15, s17
    s.add        s15, s13, s12                   // the tile origin
    s.xor        s12, s19, s20
    s.addi       s13, s15, #8                    // row 1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s15, #0]
    s.add        s17, s11, s14                   // this context's own scratch
    s.addi       s11, s15, #16                   // row 2
    s.addi       s14, s17, #0                    // 256 bytes of repack scratch
    s.addi       s19, s15, #24                   // row 3
    s.addi       s21, s14, #16                   // row 1
    s.sub        s22, s12, s20
    s.addi       s12, s14, #32                   // row 2
    v.splat      v2, s2
    s.addi       s2, s14, #48                    // row 3
    v.splat      v3, s22
    s.mul        s20, s22, s3
    v.st.b       [s14, #0], v1
    v.iota       v1                              // arange(0, VLEN)
    v.splat      v4, s5
    v.splat      v5, s10
    s.andi       s10, s20, #31
    v.splat      v6, s20
    v.iota       v7                              // arange(0, VLEN)
    v.splat      v8, s10
    v.add        v9, v4, v1
    v.iota       v4                              // arange(0, VLEN)
    v.add        v9, v6, v1
    v.add        v1, v5, v7
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s13, #0]
    s.movz       s13, #0
    v.add        v5, v8, v4
    v.splat      v4, s13
    v.splat      v5, s13
    v.cmp.ge     p2, v2, v4
    v.cmp.ge     p2, v3, v5
    v.st.b       [s21, #0], v1
    s.addi       s21, s15, #32                   // row 4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s11, #0]
    s.addi       s11, s14, #64                   // row 4
    v.st.b       [s12, #0], v1
    s.addi       s12, s15, #40                   // row 5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s19, #0]
    s.addi       s19, s14, #80                   // row 5
    v.st.b       [s2, #0], v1
    s.addi       s2, s15, #48                    // row 6
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s21, #0]
    s.addi       s21, s14, #96                   // row 6
    v.st.b       [s11, #0], v1
    s.addi       s11, s15, #56                   // row 7
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s12, #0]
    s.addi       s12, s14, #112                  // row 7
    v.st.b       [s19, #0], v1
    s.addi       s19, s15, #64                   // row 8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s2, #0]
    s.addi       s2, s14, #128                   // row 8
    v.st.b       [s21, #0], v1
    s.addi       s21, s15, #72                   // row 9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s11, #0]
    s.addi       s11, s14, #144                  // row 9
    s.addi       s22, s17, #256                  // 256 bytes of repack scratch
    v.st.b       [s12, #0], v1
    s.addi       s12, s15, #80                   // row 10
    s.muli       s17, s10, #8                    // a runtime tile origin, x8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s19, #0]
    s.addi       s10, s14, #160                  // row 10
    v.iota       v2                              // arange(0, VLEN)
    v.st.b       [s2, #0], v1
    s.addi       s2, s15, #88                    // row 11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s21, #0]
    s.addi       s19, s14, #176                  // row 11
    v.st.b       [s11, #0], v1
    s.addi       s11, s15, #96                   // row 12
    v.splat      v1, s13
    s.addi       s13, s14, #192                  // row 12
    v.splat      v3, s4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v4, [s12, #0]
    s.addi       s12, s15, #104                  // row 13
    v.cmp.lt     p2, v1, v3
    v.st.b       [s10, #0], v4
    s.addi       s10, s14, #208                  // row 13
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s2, #0]
    s.addi       s2, s15, #112                   // row 14
    s.addi       s21, s15, #120                  // row 15
    v.st.b       [s19, #0], v1
    s.addi       s15, s14, #224                  // row 14
    v.splat      v1, s6
    s.addi       s6, s14, #240                   // row 15
    v.cmp.lt     p3, v1, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s11, #0]
    s.addi       s11, s14, #64
    v.st.b       [s13, #0], v1
    s.addi       s13, s14, #128
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v1, [s12, #0]
    s.addi       s12, s14, #192
    v.st.b       [s10, #0], v1
    s.movz       s10, #8
    v.splat      v1, s1
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.movz       s1, #0
    v.splat      v4, s10
    s.add        s10, s1, s17                    // the tile origin
    s.addi       s1, s22, #16                    // row 1
    v.mul        v5, v2, v4
    v.splat      v2, s10
    s.addi       s17, s10, #1
    v.add        v4, v5, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s2, #0]
    v.splat      v6, s17
    s.addi       s2, s10, #2
    s.addi       s17, s22, #32                   // row 2
    v.add        v7, v5, v6
    v.splat      v6, s2
    v.add        v8, v5, v6
    v.st.b       [s15, #0], v2
    s.addi       s2, s10, #3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.b       v2, [s21, #0]
    v.cmp.lt     p1, v1, v3
    v.splat      v1, s2
    v.add        v6, v5, v1
    v.st.b       [s6, #0], v2
    w.def        w0, #60, #4                     // v60..v63
    fence.acq_rel.device
    s.movz       s2, #3
    v.splat      v1, s2
    v.ld.w       v2, [s14, #0]
    v.mov        v60, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s11, #0]
    s.addi       s2, s10, #4
    s.addi       s6, s22, #48                    // row 3
    v.mov        v61, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s13, #0]
    s.movz       s11, #4
    v.mov        v62, v2                         // hand off through the shared window (sec 7.3)
    v.ld.w       v2, [s12, #0]
    v.mov        v63, v2                         // hand off through the shared window (sec 7.3)
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v2, [s7, v4]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v3
    v.splat      v1, s2
    v.splat      v4, s11
    s.addi       s2, s10, #5
    v.add        v9, v5, v1
    s.movz       s11, #5
    s.addi       s12, s22, #64                   // row 4
    s.addi       s13, s10, #6
    s.movz       s14, #6
    s.addi       s15, s22, #80                   // row 5
    v.st.b       [s22, #0], v2
    v.splat      v1, s2
    s.addi       s2, s10, #7
    s.addi       s19, s22, #96                   // row 6
    v.add        v2, v5, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.b v1, [s7, v7]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v4, v3
    v.splat      v4, s11
    v.st.b       [s1, #0], v1
    v.splat      v1, s13
    s.movz       s1, #7
    s.addi       s11, s22, #112                  // row 7
    v.add        v7, v5, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v8]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v3
    v.splat      v4, s14
    s.addi       s13, s10, #8
    v.st.b       [s17, #0], v1
    v.splat      v1, s2
    s.addi       s2, s10, #9
    s.addi       s14, s22, #128                  // row 8
    v.add        v8, v5, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v1, [s7, v6]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v3
    v.splat      v4, s1
    v.st.b       [s6, #0], v1
    v.splat      v1, s13
    s.movz       s1, #9
    s.addi       s6, s10, #10
    v.add        v6, v5, v1
    s.addi       s13, s22, #144                  // row 9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.b v1, [s7, v9]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v4, v3
    v.splat      v4, s4
    v.st.b       [s12, #0], v1
    v.splat      v1, s2
    s.movz       s2, #10
    s.addi       s4, s10, #11
    v.add        v9, v5, v1
    s.addi       s12, s22, #160                  // row 10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v3
    v.splat      v2, s1
    v.st.b       [s15, #0], v1
    v.splat      v1, s6
    s.movz       s1, #11
    s.addi       s6, s10, #12
    v.add        v4, v5, v1
    s.addi       s15, s22, #176                  // row 11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v1, [s7, v7]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v3
    v.splat      v2, s2
    v.st.b       [s19, #0], v1
    v.splat      v1, s4
    s.movz       s2, #12
    s.addi       s4, s10, #13
    v.add        v7, v5, v1
    s.addi       s17, s22, #192                  // row 12
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.b v1, [s7, v8]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v2, v3
    v.splat      v2, s1
    v.st.b       [s11, #0], v1
    v.splat      v1, s6
    s.movz       s1, #13
    s.addi       s6, s22, #208                   // row 13
    v.add        v8, v5, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v1, [s7, v6]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v3
    v.splat      v2, s2
    s.addi       s2, s10, #14
    v.st.b       [s14, #0], v1
    v.splat      v1, s4
    s.movz       s4, #14
    s.addi       s11, s22, #224                  // row 14
    v.add        v6, v5, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v1, [s7, v9]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v3
    v.splat      v2, s1
    s.addi       s1, s10, #15
    v.st.b       [s13, #0], v1
    v.splat      v1, s2
    s.movz       s2, #15
    s.addi       s10, s22, #240                  // row 15
    v.add        v9, v5, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.b v1, [s7, v4]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p3, v2, v3
    v.splat      v2, s4
    v.st.b       [s12, #0], v1
    v.splat      v1, s1
    s.addi       s1, s22, #64
    s.addi       s4, s22, #128
    v.add        v4, v5, v1
    v.splat      v1, s2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v5, [s7, v7]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v3
    s.addi       s2, s22, #192
    v.st.b       [s15, #0], v5
    v.movi       v2, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v5, [s7, v8]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v1, v3
    s.movz       s12, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s13, #0
    v.st.b       [s17, #0], v5
    s.movz       s14, #0
    v.splat      v1, s3
    s.add        s3, s14, s5                     // the tile origin
    s.add        s14, s12, s5                    // the tile origin
    v.splat      v3, s3
    v.splat      v5, s14
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.b v7, [s7, v6]               // index is in elements (ISA sec 9.1)
    s.movz       s12, #0
    v.cmp.lt     p3, v3, v1
    s.add        s15, s12, s20                   // the tile origin
    v.st.b       [s6, #0], v7
    v.splat      v3, s15
    s.movz       s6, #32
    v.add        v6, v0, v3
    v.splat      v0, s6
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.b v3, [s7, v9]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v0
    p.and        p4, p3, p1
    s.movz       s6, #1
    v.st.b       [s11, #0], v3
    s.addi       s11, s3, #1
    s.addi       s12, s14, #1
    v.splat      v0, s11
    v.splat      v3, s12
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.b v6, [s7, v4]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p3, p2, p1
    s.movz       s7, #2
    v.st.b       [s10, #0], v6
    w.def        w1, #56, #4                     // v56..v59
    fence.acq_rel.device
    s.addi       s10, s3, #2
    s.addi       s11, s14, #2
    v.splat      v0, s11
    v.ld.w       v4, [s22, #0]
    v.splat      v6, s10
    v.mov        v56, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s1, #0]
    v.mov        v57, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s4, #0]
    s.addi       s1, s14, #3
    s.movz       s4, #3
    v.mov        v58, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s2, #0]
    s.addi       s2, s3, #3
    v.splat      v7, s1
    v.splat      v8, s2
    v.mov        v59, v4                         // hand off through the shared window (sec 7.3)
    m.zero       a0
    mb.arm       s1, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.async.k16.e4m3 a0, v60, v56, s1
    mb.wait      s1
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s8, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v1
    p.and        p4, p2, p1
    s.addi       s2, s3, #4
    s.addi       s10, s14, #4
    v.splat      v5, s2
    v.splat      v6, s10
    s.addi       s2, s3, #5
    s.addi       s10, s14, #5
    s.movz       s11, #4
    s.addi       s12, s14, #6
    s.movz       s15, #5
    s.movz       s17, #6
    a.vwrite     a1, s13, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s8, v3]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v8, v1
    p.and        p3, p2, p1
    v.splat      v3, s2
    v.splat      v8, s10
    s.addi       s2, s3, #6
    s.addi       s10, s14, #7
    s.movz       s13, #7
    a.vwrite     a1, s6, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v5, v1
    p.and        p4, p2, p1
    v.splat      v0, s2
    v.splat      v5, s12
    s.addi       s2, s3, #7
    s.addi       s6, s14, #8
    s.movz       s12, #8
    a.vwrite     a1, s7, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s8, v7]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p3, p2, p1
    v.splat      v3, s2
    v.splat      v7, s10
    s.addi       s2, s3, #8
    s.addi       s7, s14, #9
    s.movz       s10, #9
    a.vwrite     a1, s4, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s8, v6]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p2, p1
    v.splat      v0, s2
    v.splat      v6, s6
    s.addi       s2, s3, #9
    s.addi       s4, s14, #10
    s.movz       s6, #10
    a.vwrite     a1, s11, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s8, v8]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p3, p2, p1
    v.splat      v3, s2
    v.splat      v8, s7
    s.addi       s2, s3, #10
    s.addi       s7, s14, #11
    s.movz       s11, #11
    a.vwrite     a1, s15, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s8, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p2, p1
    v.splat      v0, s2
    v.splat      v5, s4
    s.addi       s2, s3, #11
    s.addi       s4, s14, #12
    s.movz       s15, #12
    a.vwrite     a1, s17, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s8, v7]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p3, p2, p1
    v.splat      v3, s2
    v.splat      v7, s7
    s.addi       s2, s3, #12
    s.addi       s7, s14, #13
    s.movz       s17, #13
    a.vwrite     a1, s13, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s8, v6]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p2, p1
    v.splat      v0, s2
    v.splat      v6, s4
    s.addi       s2, s3, #13
    s.addi       s4, s14, #14
    s.movz       s13, #14
    a.vwrite     a1, s12, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s8, v8]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p3, p2, p1
    v.splat      v3, s2
    v.splat      v8, s7
    s.addi       s2, s3, #14
    s.addi       s7, s14, #15
    s.movz       s12, #15
    a.vwrite     a1, s10, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s8, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p2, p1
    v.splat      v0, s2
    v.splat      v5, s4
    s.addi       s2, s3, #15
    s.muli       s4, s20, #4                     // a runtime tile origin, x4
    s.add        s10, s9, s4                     // the tile origin
    a.vwrite     a1, s6, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s8, v7]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p3, p2, p1
    v.splat      v3, s2
    v.splat      v7, s7
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s4, s20, #2                     // a runtime tile origin, x2
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s6, s20, #2                     // a runtime tile origin, x2
    s.muli       s7, s5, #64                     // a runtime tile origin, x64
    s.add        s5, s16, s4                     // the tile origin
    s.add        s4, s18, s6                     // the tile origin
    s.add        s6, s4, s7                      // the tile origin
    a.vwrite     a1, s11, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s8, v6]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p2, p1
    v.splat      v0, s3
    s.movz       s4, #0
    v.splat      v6, s3
    a.vwrite     a1, s15, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s8, v8]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v3, v1
    p.and        p3, p2, p1
    v.splat      v3, s3
    a.vwrite     a1, s17, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v4, [s8, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v0, v1
    p.and        p4, p2, p1
    s.addi       s7, s3, #1
    s.movz       s9, #1
    v.splat      v0, s7
    s.movz       s7, #1
    a.vwrite     a1, s13, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v4, [s8, v7]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v6, v1
    p.and        p3, p2, p1
    s.addi       s8, s3, #1
    v.splat      v5, s8
    a.vwrite     a1, s12, v4
    a.vread      v4, a0, s2
    a.vread      v6, a1, s4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s10, #0]
    vf.add       v8, v4, v2
    v.cmp.lt     p2, v3, v1
    p.and        p4, p2, p1
    s.addi       s2, s3, #1
    s.addi       s4, s3, #2
    v.splat      v3, s2
    v.splat      v4, s4
    s.addi       s2, s6, #64                     // row 1
    s.movz       s4, #2
    s.movz       s8, #2
    vf.mul       v9, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s5, #0]
    v.cmp.lt     p2, v0, v1
    p.and        p3, p2, p1
    vf.mul       v0, v8, v9
    s.addi       s11, s3, #2
    v.splat      v7, s11
    vf.cvt.bf16.f32 v8, v6
    vf.add       v6, v0, v8
    vf.cvt.f32.bf16 v0, v6
    s.addi       s11, s6, #128                   // row 2
    @p4 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s9
    a.vread      v6, a1, s7
    v.cmp.lt     p2, v5, v1
    p.and        p4, p2, p1
    vf.add       v5, v0, v2
    s.addi       s7, s3, #2
    s.movz       s9, #3
    v.splat      v0, s7
    s.movz       s7, #3
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s10, #0]
    v.cmp.lt     p2, v3, v1
    p.and        p3, p2, p1
    s.addi       s12, s3, #3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v3, [s5, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p2, v4, v1
    p.and        p4, p2, p1
    v.splat      v4, s12
    vf.mul       v6, v5, v9
    s.addi       s12, s3, #3
    vf.cvt.bf16.f32 v5, v3
    v.splat      v3, s12
    vf.add       v8, v6, v5
    vf.cvt.f32.bf16 v5, v8
    s.addi       s12, s6, #192                   // row 3
    @p3 v.st.h       [s2, #0], v5
    a.vread      v5, a0, s4
    a.vread      v6, a1, s8
    v.cmp.lt     p2, v7, v1
    p.and        p3, p2, p1
    vf.add       v7, v5, v2
    s.addi       s2, s3, #3
    s.movz       s4, #4
    v.splat      v5, s2
    s.movz       s2, #4
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s10, #0]
    v.cmp.lt     p2, v0, v1
    p.and        p4, p2, p1
    s.addi       s8, s3, #4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p2, v4, v1
    p.and        p3, p2, p1
    v.splat      v4, s8
    vf.mul       v6, v7, v9
    s.addi       s8, s3, #4
    vf.cvt.bf16.f32 v7, v0
    v.splat      v0, s8
    vf.add       v8, v6, v7
    vf.cvt.f32.bf16 v6, v8
    s.addi       s8, s6, #256                    // row 4
    @p4 v.st.h       [s11, #0], v6
    a.vread      v6, a0, s9
    a.vread      v7, a1, s7
    v.cmp.lt     p2, v3, v1
    p.and        p4, p2, p1
    vf.add       v3, v6, v2
    s.addi       s7, s3, #4
    s.movz       s9, #5
    v.splat      v6, s7
    s.movz       s7, #5
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s10, #0]
    v.cmp.lt     p2, v5, v1
    p.and        p3, p2, p1
    s.addi       s11, s3, #5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s5, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p2, v4, v1
    p.and        p4, p2, p1
    v.splat      v4, s11
    vf.mul       v7, v3, v9
    s.addi       s11, s3, #5
    vf.cvt.bf16.f32 v3, v5
    v.splat      v5, s11
    vf.add       v8, v7, v3
    vf.cvt.f32.bf16 v3, v8
    s.addi       s11, s6, #320                   // row 5
    @p3 v.st.h       [s12, #0], v3
    a.vread      v3, a0, s4
    a.vread      v7, a1, s2
    v.cmp.lt     p2, v0, v1
    p.and        p3, p2, p1
    vf.add       v0, v3, v2
    s.addi       s2, s3, #5
    s.movz       s4, #6
    v.splat      v3, s2
    s.movz       s2, #6
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s10, #0]
    v.cmp.lt     p2, v6, v1
    p.and        p4, p2, p1
    s.addi       s12, s3, #6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s5, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p2, v4, v1
    p.and        p3, p2, p1
    v.splat      v4, s12
    vf.mul       v7, v0, v9
    s.addi       s12, s3, #6
    vf.cvt.bf16.f32 v0, v6
    v.splat      v6, s12
    vf.add       v8, v7, v0
    vf.cvt.f32.bf16 v0, v8
    s.addi       s12, s6, #384                   // row 6
    @p4 v.st.h       [s8, #0], v0
    a.vread      v0, a0, s9
    a.vread      v7, a1, s7
    v.cmp.lt     p2, v5, v1
    p.and        p4, p2, p1
    vf.add       v5, v0, v2
    s.addi       s7, s3, #6
    s.movz       s8, #7
    v.splat      v0, s7
    s.movz       s7, #7
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s10, #0]
    v.cmp.lt     p2, v3, v1
    p.and        p3, p2, p1
    s.addi       s9, s3, #7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v3, [s5, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p2, v4, v1
    p.and        p4, p2, p1
    v.splat      v4, s9
    vf.mul       v7, v5, v9
    s.addi       s9, s3, #7
    vf.cvt.bf16.f32 v5, v3
    v.splat      v3, s9
    vf.add       v8, v7, v5
    vf.cvt.f32.bf16 v5, v8
    s.addi       s9, s6, #448                    // row 7
    @p3 v.st.h       [s11, #0], v5
    a.vread      v5, a0, s4
    a.vread      v7, a1, s2
    v.cmp.lt     p2, v6, v1
    p.and        p3, p2, p1
    vf.add       v6, v5, v2
    s.addi       s2, s3, #7
    s.movz       s4, #8
    v.splat      v5, s2
    s.movz       s2, #8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s10, #0]
    v.cmp.lt     p2, v0, v1
    p.and        p4, p2, p1
    s.addi       s11, s3, #8
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p2, v4, v1
    p.and        p3, p2, p1
    v.splat      v4, s11
    vf.mul       v7, v6, v9
    s.addi       s11, s3, #8
    vf.cvt.bf16.f32 v6, v0
    v.splat      v0, s11
    vf.add       v8, v7, v6
    vf.cvt.f32.bf16 v6, v8
    s.addi       s11, s6, #512                   // row 8
    @p4 v.st.h       [s12, #0], v6
    a.vread      v6, a0, s8
    a.vread      v7, a1, s7
    v.cmp.lt     p2, v3, v1
    p.and        p4, p2, p1
    vf.add       v3, v6, v2
    s.addi       s7, s3, #8
    s.movz       s8, #9
    v.splat      v6, s7
    s.movz       s7, #9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s10, #0]
    v.cmp.lt     p2, v5, v1
    p.and        p3, p2, p1
    s.addi       s12, s3, #9
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s5, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p2, v4, v1
    p.and        p4, p2, p1
    v.splat      v4, s12
    vf.mul       v7, v3, v9
    s.addi       s12, s3, #9
    vf.cvt.bf16.f32 v3, v5
    v.splat      v5, s12
    vf.add       v8, v7, v3
    vf.cvt.f32.bf16 v3, v8
    s.addi       s12, s6, #576                   // row 9
    @p3 v.st.h       [s9, #0], v3
    a.vread      v3, a0, s4
    a.vread      v7, a1, s2
    v.cmp.lt     p2, v0, v1
    p.and        p3, p2, p1
    vf.add       v0, v3, v2
    s.addi       s2, s3, #9
    s.movz       s4, #10
    v.splat      v3, s2
    s.movz       s2, #10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s10, #0]
    v.cmp.lt     p2, v6, v1
    p.and        p4, p2, p1
    s.addi       s9, s3, #10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s5, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p2, v4, v1
    p.and        p3, p2, p1
    v.splat      v4, s9
    vf.mul       v7, v0, v9
    s.addi       s9, s3, #10
    vf.cvt.bf16.f32 v0, v6
    v.splat      v6, s9
    vf.add       v8, v7, v0
    vf.cvt.f32.bf16 v0, v8
    s.addi       s9, s6, #640                    // row 10
    @p4 v.st.h       [s11, #0], v0
    a.vread      v0, a0, s8
    a.vread      v7, a1, s7
    v.cmp.lt     p2, v5, v1
    p.and        p4, p2, p1
    vf.add       v5, v0, v2
    s.addi       s7, s3, #10
    s.movz       s8, #11
    v.splat      v0, s7
    s.movz       s7, #11
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s10, #0]
    v.cmp.lt     p2, v3, v1
    p.and        p3, p2, p1
    s.addi       s11, s3, #11
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v3, [s5, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p2, v4, v1
    p.and        p4, p2, p1
    v.splat      v4, s11
    vf.mul       v7, v5, v9
    s.addi       s11, s3, #11
    vf.cvt.bf16.f32 v5, v3
    v.splat      v3, s11
    vf.add       v8, v7, v5
    vf.cvt.f32.bf16 v5, v8
    s.addi       s11, s6, #704                   // row 11
    @p3 v.st.h       [s12, #0], v5
    a.vread      v5, a0, s4
    a.vread      v7, a1, s2
    v.cmp.lt     p2, v6, v1
    p.and        p3, p2, p1
    vf.add       v6, v5, v2
    s.addi       s2, s3, #11
    s.movz       s4, #12
    v.splat      v5, s2
    s.movz       s2, #12
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s10, #0]
    v.cmp.lt     p2, v0, v1
    p.and        p4, p2, p1
    s.addi       s12, s3, #12
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p2, v4, v1
    p.and        p3, p2, p1
    v.splat      v4, s12
    vf.mul       v7, v6, v9
    s.addi       s12, s3, #12
    vf.cvt.bf16.f32 v6, v0
    v.splat      v0, s12
    vf.add       v8, v7, v6
    vf.cvt.f32.bf16 v6, v8
    s.addi       s12, s6, #768                   // row 12
    @p4 v.st.h       [s9, #0], v6
    a.vread      v6, a0, s8
    a.vread      v7, a1, s7
    v.cmp.lt     p2, v3, v1
    p.and        p4, p2, p1
    vf.add       v3, v6, v2
    s.addi       s7, s3, #12
    s.movz       s8, #13
    v.splat      v6, s7
    s.movz       s7, #13
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s10, #0]
    v.cmp.lt     p2, v5, v1
    p.and        p3, p2, p1
    s.addi       s9, s3, #13
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s5, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p2, v4, v1
    p.and        p4, p2, p1
    v.splat      v4, s9
    vf.mul       v7, v3, v9
    s.addi       s9, s3, #13
    vf.cvt.bf16.f32 v3, v5
    v.splat      v5, s9
    vf.add       v8, v7, v3
    vf.cvt.f32.bf16 v3, v8
    s.addi       s9, s6, #832                    // row 13
    @p3 v.st.h       [s11, #0], v3
    a.vread      v3, a0, s4
    a.vread      v7, a1, s2
    v.cmp.lt     p2, v0, v1
    p.and        p3, p2, p1
    vf.add       v0, v3, v2
    s.addi       s2, s3, #13
    s.movz       s4, #14
    v.splat      v3, s2
    s.movz       s2, #14
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s10, #0]
    v.cmp.lt     p2, v6, v1
    p.and        p4, p2, p1
    s.addi       s11, s3, #14
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s5, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p2, v4, v1
    p.and        p3, p2, p1
    v.splat      v4, s11
    vf.mul       v7, v0, v9
    s.addi       s11, s3, #14
    vf.cvt.bf16.f32 v0, v6
    v.splat      v6, s11
    vf.add       v8, v7, v0
    vf.cvt.f32.bf16 v0, v8
    s.addi       s11, s6, #896                   // row 14
    @p4 v.st.h       [s12, #0], v0
    a.vread      v0, a0, s8
    a.vread      v7, a1, s7
    v.cmp.lt     p2, v5, v1
    p.and        p4, p2, p1
    vf.add       v5, v0, v2
    s.addi       s7, s3, #14
    s.movz       s8, #15
    v.splat      v0, s7
    s.movz       s7, #15
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s10, #0]
    v.cmp.lt     p2, v3, v1
    p.and        p3, p2, p1
    s.addi       s12, s3, #15
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v3, [s5, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p2, v4, v1
    p.and        p4, p2, p1
    v.splat      v4, s12
    vf.mul       v7, v5, v9
    s.addi       s12, s3, #15
    vf.cvt.bf16.f32 v5, v3
    v.splat      v3, s12
    vf.add       v8, v7, v5
    vf.cvt.f32.bf16 v5, v8
    s.addi       s12, s6, #960                   // row 15
    @p3 v.st.h       [s9, #0], v5
    a.vread      v5, a0, s4
    a.vread      v7, a1, s2
    v.cmp.lt     p2, v6, v1
    p.and        p3, p2, p1
    vf.add       v6, v5, v2
    s.addi       s2, s3, #15
    v.splat      v5, s2
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s10, #0]
    v.cmp.lt     p2, v0, v1
    p.and        p4, p2, p1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s5, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p2, v4, v1
    p.and        p3, p2, p1
    vf.mul       v4, v6, v9
    vf.cvt.bf16.f32 v6, v0
    vf.add       v0, v4, v6
    vf.cvt.f32.bf16 v4, v0
    @p4 v.st.h       [s11, #0], v4
    a.vread      v0, a0, s8
    a.vread      v4, a1, s7
    v.cmp.lt     p2, v3, v1
    p.and        p4, p2, p1
    vf.add       v3, v0, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s10, #0]
    v.cmp.lt     p2, v5, v1
    p.and        p3, p2, p1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s5, #0]
    vf.mul       v2, v4, v0
    vf.mul       v0, v3, v2
    vf.cvt.bf16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    @p3 v.st.h       [s12, #0], v0
__rctx_next:
    exit
