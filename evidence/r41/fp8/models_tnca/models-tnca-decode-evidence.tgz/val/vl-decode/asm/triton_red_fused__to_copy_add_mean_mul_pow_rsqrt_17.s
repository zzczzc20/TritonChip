    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr1: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr2: device_ptr64 at arg_base+32
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #56]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s9, #512
    s.mul        s10, s1, s9
    s.add        s1, s8, s10                     // this context's own scratch
    s.addi       s8, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s9, #0
    s.st.d       [s8, #0], s2
    s.movz       s9, #13
    s.st.d       [s8, #8], s9
    s.movz       s9, #2048
    s.st.d       [s8, #16], s9
    s.movz       s9, #4096
    s.st.d       [s8, #48], s9
    s.movz       s9, #2
    s.st.d       [s8, #56], s9
    .li       s9, #68719476737
    s.st.d       [s8, #88], s9
    .li       s9, #1108101562368
    s.st.d       [s8, #104], s9
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s8, s1, #256                    // TensorMap 1: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s8, #0], s3
    s.movz       s1, #13
    s.st.d       [s8, #8], s1
    s.movz       s1, #2048
    s.st.d       [s8, #16], s1
    s.movz       s1, #4096
    s.st.d       [s8, #48], s1
    s.movz       s1, #2
    s.st.d       [s8, #56], s1
    .li       s1, #68719476737
    s.st.d       [s8, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s8, #104], s1
    fence.release.device
    td.load      d1, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s8, #2048
    s.movz       s9, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s10, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s11, s10, s8
    br.nz        s11, endfor_2
    s.muli       s11, s4, #4096
    v.splat      v1, s10
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s12, #2048
    s.movz       s13, #13
    s.muli       s14, s4, #4096
    v.splat      v4, s10
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s15, #2048
    s.movz       s16, #13
    v.add        v6, v1, v3
    v.movi       v1, #0
    v.splat      v3, s12
    s.muli       s12, s10, #2
    v.splat      v7, s4
    v.movi       v8, #0
    v.add        v9, v4, v5
    v.splat      v4, s13
    s.muli       s13, s10, #2
    v.cmp.ge     p1, v6, v1
    v.movi       v1, #0
    v.cmp.lt     p2, v6, v3
    v.splat      v3, s15
    v.splat      v5, s4
    v.cmp.ge     p3, v7, v8
    v.movi       v6, #0
    v.cmp.lt     p4, v7, v4
    v.splat      v4, s16
    v.cmp.ge     p5, v9, v1
    s.add        s15, s2, s11
    p.and        p6, p1, p2
    v.cmp.lt     p1, v9, v3
    p.and        p2, p3, p4
    v.cmp.ge     p3, v5, v6
    s.add        s11, s3, s14
    p.and        p4, p5, p1
    v.cmp.lt     p1, v5, v4
    p.and        p5, p3, p1
    s.add        s14, s15, s12
    p.and        p1, p6, p2
    s.add        s12, s11, s13
    p.and        p2, p4, p5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s14, #0]
    v.splat      v3, s10
    v.movi       v4, #2048
    v.add        v5, v3, v0
    v.cmp.lt     p1, v5, v4
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v3, [s12, #0]
    vf.cvt.bf16.f32 v4, v1
    v.movi       v1, #0
    s.add        s11, s10, s9
    s.movz       s12, #1
    vf.cvt.bf16.f32 v5, v3
    vf.add       v3, v4, v5
    vf.mul       v4, v3, v3
    vf.add       v3, v2, v4
    @p1 v.sel        v4, v3, v2
    v.mov        v1, v4
    v.mov        v2, v1
    s.mov        s10, s11
    br.nz        s12, for_1
endfor_2:
    vf.reduce.add.b v1, v2
    v.movi       v2, #0
    s.addi       s10, s1, #0
    vf.add       v3, v1, v2
for_3:
    s.cmp.ge     s1, s10, s8
    br.nz        s1, endfor_4
    s.muli       s1, s4, #4096
    v.splat      v1, s10
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s11, #2048
    s.movz       s12, #13
    s.muli       s13, s4, #4096
    v.splat      v4, s10
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s14, #2048
    v.add        v6, v1, v2
    v.movi       v1, #0
    v.splat      v2, s11
    s.movz       s11, #13
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s12
    s.muli       s12, s10, #2
    v.add        v10, v4, v5
    v.movi       v4, #0
    v.splat      v5, s14
    s.muli       s14, s10, #2
    v.cmp.ge     p1, v6, v1
    v.splat      v1, s4
    v.cmp.lt     p2, v6, v2
    v.movi       v2, #0
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    v.cmp.ge     p5, v10, v4
    s.add        s15, s2, s1
    p.and        p6, p1, p2
    v.cmp.lt     p1, v10, v5
    p.and        p2, p3, p4
    v.cmp.ge     p3, v1, v2
    s.add        s1, s3, s13
    p.and        p4, p5, p1
    s.add        s13, s15, s12
    p.and        p1, p6, p2
    s.add        s12, s1, s14
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s13, #0]
    v.splat      v4, s10
    v.splat      v5, s11
    s.shli       s1, s10, #1                     // element offset -> bytes (x2)
    v.add        v6, v4, v0
    v.cmp.lt     p1, v1, v5
    v.movi       v1, #2048
    p.and        p2, p3, p1
    s.add        s11, s5, s1                     // &in_ptr2[...]
    vf.cvt.bf16.f32 v4, v2
    v.cmp.lt     p1, v6, v1
    p.and        p3, p4, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s11, #0]
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s12, #0]
    vf.cvt.bf16.f32 v5, v1
    .li       s1, #1157627904
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v8, v1                          // ISA 8.8: <= 2**-22 relative
    .li       s1, #897988541
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1077936128
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cvt.bf16.f32 v12, v2
    s.mul        s1, s4, s8
    s.add        s11, s10, s9
    s.movz       s12, #1
    vf.add       v2, v4, v12
    s.add        s13, s10, s1
    v.splat      v4, s1
    s.shli       s1, s13, #1                     // element offset -> bytes (x2)
    v.add        v12, v6, v4
    s.add        s13, s6, s1                     // &out_ptr1[...]
    s.add        s14, s7, s1                     // &out_ptr2[...]
    vf.fms       v4, v1, v8, v7
    vf.fms       v6, v8, v4, v8
    vf.neg       v4, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v6, v4, v8
    vf.mul       v4, v3, v6                      // a/y: faithful quotient
    vf.fms       v7, v4, v1, v3
    vf.fms       v1, v7, v6, v4
    vf.neg       v6, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v6, v6
    @p2 v.sel        v1, v6, v4
    vf.add       v4, v1, v9
    v.rsqrt.approx v1, v4                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v6, v1, v1
    vf.mul       v7, v1, v11
    vf.fms       v8, v4, v6, v10
    vf.mul       v4, v7, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v4, v4
    @p2 v.sel        v6, v4, v1
    v.extract    s1, v6, #0
    v.splat      v1, s1
    vf.mul       v4, v2, v1
    vf.mul       v1, v5, v4
    vf.cvt.f32.bf16 v2, v1
    @p1 v.st.h       [s13, #0], v2
    @p1 v.st.h       [s14, #0], v2
    s.mov        s10, s11
    br.nz        s12, for_3
endfor_4:
__rctx_next:
    exit
