    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // out_ptr2: device_ptr64 at arg_base+32
    s.ld.d       s7, [s1, #40]                   // out_ptr3: device_ptr64 at arg_base+40
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #64]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s9, #256
    s.mul        s10, s1, s9
    s.add        s1, s8, s10                     // this context's own scratch
    s.addi       s8, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s8, #0], s2
    s.movz       s1, #16
    s.st.d       [s8, #8], s1
    s.movz       s1, #576
    s.st.d       [s8, #16], s1
    s.movz       s1, #2304
    s.st.d       [s8, #48], s1
    s.movz       s1, #4
    s.st.d       [s8, #56], s1
    .li       s1, #68719476737
    s.st.d       [s8, #88], s1
    .li       s1, #2207613190144
    s.st.d       [s8, #104], s1
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s8, #576
    s.movz       s9, #16
    s.rdspecial  s10, role_id
    s.rdspecial  s11, npid.x
__rctx_program:
    s.ld.d       s12, [s4, #0]                   // one element, not a vector
    v.movi       v0, #0
    v.movi       v1, #0
    v.splat      v2, s10
    v.iota       v2                              // arange(0, VLEN)
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #0
    v.insert     v1, s13, #0
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #1
    v.insert     v1, s13, #1
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #2
    v.insert     v1, s13, #2
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #3
    v.insert     v1, s13, #3
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #4
    v.insert     v1, s13, #4
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #5
    v.insert     v1, s13, #5
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #6
    v.insert     v1, s13, #6
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #7
    v.insert     v1, s13, #7
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #8
    v.insert     v1, s13, #8
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #9
    v.insert     v1, s13, #9
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #10
    v.insert     v1, s13, #10
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #11
    v.insert     v1, s13, #11
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #12
    v.insert     v1, s13, #12
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #13
    v.insert     v1, s13, #13
    s.lshri      s13, s12, #32
    v.movi       v3, #0
    v.movi       v4, #0
    v.insert     v0, s12, #14
    v.insert     v1, s13, #14
    .li       s13, #4286578688
    v.splat      v5, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v6, #0
    s.lshri      s13, s12, #32
    v.cmp.ne     p1, v3, v4
    v.insert     v0, s12, #15
    v.insert     v1, s13, #15
    s.addi       s12, s1, #0
    p.mov        p2, p1
    v.mov        v6, v5
for_1:
    s.cmp.ge     s13, s12, s8
    br.nz        s13, endfor_2
    v.splat      v3, s12
    s.shli       s13, s12, #3                    // element offset -> bytes (x8)
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v7, #1
    v.add        v8, v3, v2
    v.movi       v3, #576
    s.add        s14, s3, s13                    // &in_ptr1[...]
    v.shl        v9, v4, v7
    s.addi       s13, s14, #4
    v.cmp.lt     p1, v8, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v3, [s13, v9]              // index is in elements (ISA sec 9.1)
    v.splat      v4, s12
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s13, #576
    s.movz       s15, #16
    s.muli       s16, s10, #2304
    v.add        v8, v4, v7
    v.movi       v4, #0
    v.splat      v7, s13
    v.splat      v10, s10
    v.movi       v11, #0
    v.splat      v12, s15
    v.extract    s13, v1, #0
    s.muli       s15, s12, #4
    v.extract    s17, v0, #0
    s.shli       s18, s13, #32
    v.cmp.ge     p3, v8, v4
    v.cmp.lt     p4, v8, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s14, v9]              // index is in elements (ISA sec 9.1)
    v.extract    s13, v3, #0
    v.cmp.ge     p5, v10, v11
    s.shli       s14, s13, #32
    v.cmp.lt     p6, v10, v12
    v.extract    s13, v3, #1
    v.extract    s19, v1, #1
    s.add        s20, s2, s16
    p.and        p7, p3, p4
    p.and        p3, p5, p6
    s.or         s16, s17, s18
    v.movi       v7, #0
    s.shli       s17, s13, #32
    v.extract    s13, v0, #1
    s.shli       s18, s19, #32
    s.add        s19, s20, s15
    p.and        p4, p7, p3
    v.extract    s15, v3, #2
    s.or         s20, s13, s18
    v.extract    s13, v4, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    s.or         s18, s13, s14
    v.extract    s13, v4, #1
    s.cmp.le     s14, s18, s16
    v.extract    s16, v1, #2
    s.or         s18, s13, s17
    v.insert     v7, s14, #0
    v.extract    s13, v4, #2
    s.shli       s14, s15, #32
    v.extract    s15, v0, #2
    s.shli       s17, s16, #32
    s.cmp.le     s16, s18, s20
    v.extract    s18, v3, #3
    v.extract    s19, v1, #3
    s.or         s20, s13, s14
    s.or         s13, s15, s17
    v.insert     v7, s16, #1
    v.extract    s14, v4, #3
    s.shli       s15, s18, #32
    v.extract    s16, v0, #3
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s13
    v.extract    s13, v3, #4
    v.extract    s19, v1, #4
    s.or         s20, s14, s15
    s.or         s14, s16, s17
    v.insert     v7, s18, #2
    v.extract    s15, v4, #4
    s.shli       s16, s13, #32
    v.extract    s13, v0, #4
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s14
    v.extract    s14, v3, #5
    v.extract    s19, v1, #5
    s.or         s20, s15, s16
    s.or         s15, s13, s17
    v.insert     v7, s18, #3
    v.extract    s13, v4, #5
    s.shli       s16, s14, #32
    v.extract    s14, v0, #5
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s15
    v.extract    s15, v3, #6
    v.extract    s19, v1, #6
    s.or         s20, s13, s16
    s.or         s13, s14, s17
    v.insert     v7, s18, #4
    v.extract    s14, v4, #6
    s.shli       s16, s15, #32
    v.extract    s15, v0, #6
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s13
    v.extract    s13, v3, #7
    v.extract    s19, v1, #7
    s.or         s20, s14, s16
    s.or         s14, s15, s17
    v.insert     v7, s18, #5
    v.extract    s15, v4, #7
    s.shli       s16, s13, #32
    v.extract    s13, v0, #7
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s14
    v.extract    s14, v3, #8
    v.extract    s19, v1, #8
    s.or         s20, s15, s16
    s.or         s15, s13, s17
    v.insert     v7, s18, #6
    v.extract    s13, v4, #8
    s.shli       s16, s14, #32
    v.extract    s14, v0, #8
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s15
    v.extract    s15, v3, #9
    v.extract    s19, v1, #9
    s.or         s20, s13, s16
    s.or         s13, s14, s17
    v.insert     v7, s18, #7
    v.extract    s14, v4, #9
    s.shli       s16, s15, #32
    v.extract    s15, v0, #9
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s13
    v.extract    s13, v3, #10
    v.extract    s19, v1, #10
    s.or         s20, s14, s16
    s.or         s14, s15, s17
    v.insert     v7, s18, #8
    v.extract    s15, v4, #10
    s.shli       s16, s13, #32
    v.extract    s13, v0, #10
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s14
    v.extract    s14, v3, #11
    v.extract    s19, v1, #11
    s.or         s20, s15, s16
    s.or         s15, s13, s17
    v.insert     v7, s18, #9
    v.extract    s13, v4, #11
    s.shli       s16, s14, #32
    v.extract    s14, v0, #11
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s15
    v.extract    s15, v3, #12
    v.extract    s19, v1, #12
    s.or         s20, s13, s16
    s.or         s13, s14, s17
    v.insert     v7, s18, #10
    v.extract    s14, v4, #12
    s.shli       s16, s15, #32
    v.extract    s15, v0, #12
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s13
    v.extract    s13, v3, #13
    v.extract    s19, v1, #13
    s.or         s20, s14, s16
    s.or         s14, s15, s17
    v.insert     v7, s18, #11
    v.extract    s15, v4, #13
    s.shli       s16, s13, #32
    v.extract    s13, v0, #13
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s14
    v.extract    s14, v3, #14
    v.extract    s19, v1, #14
    s.or         s20, s15, s16
    s.or         s15, s13, s17
    v.insert     v7, s18, #12
    v.extract    s13, v4, #14
    s.shli       s16, s14, #32
    v.extract    s14, v0, #14
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s15
    v.extract    s15, v3, #15
    v.extract    s19, v1, #15
    s.or         s20, s13, s16
    s.or         s13, s14, s17
    v.insert     v7, s18, #13
    v.extract    s14, v4, #15
    s.shli       s16, s15, #32
    v.extract    s15, v0, #15
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s13
    s.or         s13, s14, s16
    s.or         s14, s15, s17
    v.insert     v7, s18, #14
    s.cmp.le     s15, s13, s14
    v.movi       v3, #0
    v.insert     v7, s15, #15
    v.movi       v4, #0
    v.movi       v9, #1
    v.cmp.ne     p3, v7, v3
    @p3 v.sel        v3, v4, v5
    v.movi       v4, #0
    v.movi       v7, #0
    vf.add       v10, v8, v3
    v.movi       v3, #1
    v.movi       v8, #0
    v.movi       v11, #1
    v.movi       v12, #0
    vf.cmp.eq    p3, v10, v5
    @p3 v.sel        v13, v9, v4
    v.movi       v4, #1
    v.movi       v9, #0
    v.cmp.eq     p3, v13, v7
    @p3 v.sel        v7, v3, v8
    @p3 v.sel        v3, v11, v12
    v.movi       v8, #0
    v.extract    s13, v7, #0
    v.movi       v7, #0
    s.lshri      s14, s13, #32
    v.extract    s15, v3, #1
    @p3 v.sel        v3, v4, v9
    v.movi       v4, #1
    v.movi       v9, #0
    v.insert     v8, s13, #0
    v.insert     v7, s14, #0
    s.lshri      s13, s15, #32
    v.extract    s14, v3, #2
    @p3 v.sel        v3, v4, v9
    v.movi       v4, #1
    v.movi       v9, #0
    v.insert     v8, s15, #1
    v.insert     v7, s13, #1
    s.lshri      s13, s14, #32
    v.extract    s15, v3, #3
    @p3 v.sel        v3, v4, v9
    v.movi       v4, #1
    v.movi       v9, #0
    v.insert     v8, s14, #2
    v.insert     v7, s13, #2
    s.lshri      s13, s15, #32
    v.extract    s14, v3, #4
    @p3 v.sel        v3, v4, v9
    v.movi       v4, #1
    v.movi       v9, #0
    v.insert     v8, s15, #3
    v.insert     v7, s13, #3
    s.lshri      s13, s14, #32
    v.extract    s15, v3, #5
    @p3 v.sel        v3, v4, v9
    v.movi       v4, #1
    v.movi       v9, #0
    v.insert     v8, s14, #4
    v.insert     v7, s13, #4
    s.lshri      s13, s15, #32
    v.extract    s14, v3, #6
    @p3 v.sel        v3, v4, v9
    v.movi       v4, #1
    v.movi       v9, #0
    v.insert     v8, s15, #5
    v.insert     v7, s13, #5
    s.lshri      s13, s14, #32
    v.extract    s15, v3, #7
    @p3 v.sel        v3, v4, v9
    v.movi       v4, #1
    v.movi       v9, #0
    v.insert     v8, s14, #6
    v.insert     v7, s13, #6
    s.lshri      s13, s15, #32
    v.extract    s14, v3, #8
    @p3 v.sel        v3, v4, v9
    v.movi       v4, #1
    v.movi       v9, #0
    v.insert     v8, s15, #7
    v.insert     v7, s13, #7
    s.lshri      s13, s14, #32
    v.extract    s15, v3, #9
    @p3 v.sel        v3, v4, v9
    v.movi       v4, #1
    v.movi       v9, #0
    v.insert     v8, s14, #8
    v.insert     v7, s13, #8
    s.lshri      s13, s15, #32
    v.extract    s14, v3, #10
    @p3 v.sel        v3, v4, v9
    v.movi       v4, #1
    v.movi       v9, #0
    v.insert     v8, s15, #9
    v.insert     v7, s13, #9
    s.lshri      s13, s14, #32
    v.extract    s15, v3, #11
    @p3 v.sel        v3, v4, v9
    v.movi       v4, #1
    v.movi       v9, #0
    v.insert     v8, s14, #10
    v.insert     v7, s13, #10
    s.lshri      s13, s15, #32
    v.extract    s14, v3, #12
    @p3 v.sel        v3, v4, v9
    v.movi       v4, #1
    v.movi       v9, #0
    v.insert     v8, s15, #11
    v.insert     v7, s13, #11
    s.lshri      s13, s14, #32
    v.extract    s15, v3, #13
    @p3 v.sel        v3, v4, v9
    v.movi       v4, #1
    v.movi       v9, #0
    v.insert     v8, s14, #12
    v.insert     v7, s13, #12
    s.lshri      s13, s15, #32
    v.extract    s14, v3, #14
    @p3 v.sel        v3, v4, v9
    v.insert     v8, s15, #13
    v.insert     v7, s13, #13
    s.lshri      s13, s14, #32
    v.extract    s15, v3, #15
    v.insert     v8, s14, #14
    v.insert     v7, s13, #14
    s.lshri      s13, s15, #32
    v.insert     v8, s15, #15
    v.insert     v7, s13, #15
    s.movz       s13, #0
    v.extract    s14, v8, #0
    v.extract    s15, v7, #0
    v.extract    s16, v7, #1
    s.shli       s17, s15, #32
    v.movi       v3, #0
    s.or         s15, s14, s17
    v.extract    s14, v8, #1
    s.shli       s17, s16, #32
    s.cmp.ne     s16, s15, s13
    v.extract    s13, v7, #2
    s.or         s15, s14, s17
    s.movz       s14, #0
    v.insert     v3, s16, #0
    v.extract    s16, v8, #2
    s.shli       s17, s13, #32
    s.cmp.ne     s13, s15, s14
    v.extract    s14, v7, #3
    s.or         s15, s16, s17
    s.movz       s16, #0
    v.insert     v3, s13, #1
    v.extract    s13, v8, #3
    s.shli       s17, s14, #32
    s.cmp.ne     s14, s15, s16
    v.extract    s15, v7, #4
    s.or         s16, s13, s17
    s.movz       s13, #0
    v.insert     v3, s14, #2
    v.extract    s14, v8, #4
    s.shli       s17, s15, #32
    s.cmp.ne     s15, s16, s13
    v.extract    s13, v7, #5
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v3, s15, #3
    v.extract    s15, v8, #5
    s.shli       s17, s13, #32
    s.cmp.ne     s13, s16, s14
    v.extract    s14, v7, #6
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v3, s13, #4
    v.extract    s13, v8, #6
    s.shli       s17, s14, #32
    s.cmp.ne     s14, s16, s15
    v.extract    s15, v7, #7
    s.or         s16, s13, s17
    s.movz       s13, #0
    v.insert     v3, s14, #5
    v.extract    s14, v8, #7
    s.shli       s17, s15, #32
    s.cmp.ne     s15, s16, s13
    v.extract    s13, v7, #8
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v3, s15, #6
    v.extract    s15, v8, #8
    s.shli       s17, s13, #32
    s.cmp.ne     s13, s16, s14
    v.extract    s14, v7, #9
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v3, s13, #7
    v.extract    s13, v8, #9
    s.shli       s17, s14, #32
    s.cmp.ne     s14, s16, s15
    v.extract    s15, v7, #10
    s.or         s16, s13, s17
    s.movz       s13, #0
    v.insert     v3, s14, #8
    v.extract    s14, v8, #10
    s.shli       s17, s15, #32
    s.cmp.ne     s15, s16, s13
    v.extract    s13, v7, #11
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v3, s15, #9
    v.extract    s15, v8, #11
    s.shli       s17, s13, #32
    s.cmp.ne     s13, s16, s14
    v.extract    s14, v7, #12
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v3, s13, #10
    v.extract    s13, v8, #12
    s.shli       s17, s14, #32
    s.cmp.ne     s14, s16, s15
    v.extract    s15, v7, #13
    s.or         s16, s13, s17
    s.movz       s13, #0
    v.insert     v3, s14, #11
    v.extract    s14, v8, #13
    s.shli       s17, s15, #32
    s.cmp.ne     s15, s16, s13
    v.extract    s13, v7, #14
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v3, s15, #12
    v.extract    s15, v8, #14
    s.shli       s17, s13, #32
    s.cmp.ne     s13, s16, s14
    v.extract    s14, v7, #15
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v3, s13, #13
    v.extract    s13, v8, #15
    s.shli       s17, s14, #32
    s.cmp.ne     s14, s16, s15
    s.or         s15, s13, s17
    s.movz       s13, #0
    v.insert     v3, s14, #14
    s.cmp.ne     s14, s15, s13
    v.movi       v4, #0
    v.insert     v3, s14, #15
    vf.max       v7, v6, v10
    p.not        p3, p1
    v.cmp.ne     p4, v3, v4
    p.or         p5, p2, p4
    p.and        p4, p3, p2
    p.and        p3, p1, p5
    @p1 v.sel        v3, v7, v6
    v.movi       v4, #0
    p.or         p1, p3, p4
    s.add        s13, s12, s9
    p.mov        p3, p1
    v.mov        v4, v3
    s.movz       s14, #1
    p.mov        p2, p3
    v.mov        v6, v4
    s.mov        s12, s13
    br.nz        s14, for_1
endfor_2:
    v.movi       v0, #1
    v.movi       v1, #0
    s.movz       s12, #1
    s.shli       s13, s10, #0                    // element offset -> bytes (x1)
    @p2 v.sel        v3, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s12
    v.reduce.or  s12, v3
    s.add        s14, s5, s13                    // &out_ptr0[...]
    v.splat      v3, s12
    v.cmp.lt     p1, v0, v1
    v.movi       v0, #0
    @p1 v.st.b       [s14, #0], v3
    v.movi       v1, #0
    v.movi       v3, #1
    v.movi       v4, #0
    vf.cmp.uo    p1, v6, v6
    v.movi       v7, #0
    @p1 v.sel        v8, v3, v4
    vf.reduce.max.b v3, v6
    .li       s12, #2143289344
    v.splat      v4, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.reduce.or.b v6, v8
    v.movi       v8, #0
    s.ld.d       s12, [s4, #0]                   // one element, not a vector
    v.cmp.ne     p1, v6, v7
    @p1 v.sel        v6, v4, v3
    vf.add       v3, v6, v8
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #0
    v.insert     v1, s13, #0
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #1
    v.insert     v1, s13, #1
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #2
    v.insert     v1, s13, #2
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #3
    v.insert     v1, s13, #3
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #4
    v.insert     v1, s13, #4
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #5
    v.insert     v1, s13, #5
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #6
    v.insert     v1, s13, #6
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #7
    v.insert     v1, s13, #7
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #8
    v.insert     v1, s13, #8
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #9
    v.insert     v1, s13, #9
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #10
    v.insert     v1, s13, #10
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #11
    v.insert     v1, s13, #11
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #12
    v.insert     v1, s13, #12
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #13
    v.insert     v1, s13, #13
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #14
    v.insert     v1, s13, #14
    v.movi       v4, #0
    v.movi       v6, #0
    s.lshri      s13, s12, #32
    v.insert     v0, s12, #15
    v.insert     v1, s13, #15
    s.addi       s12, s1, #0
    v.mov        v6, v4
for_3:
    s.cmp.ge     s13, s12, s8
    br.nz        s13, endfor_4
    v.splat      v7, s12
    s.shli       s13, s12, #3                    // element offset -> bytes (x8)
    v.iota       v9                              // arange(0, VLEN)
    v.movi       v10, #1
    v.add        v11, v7, v2
    v.movi       v7, #576
    s.add        s14, s3, s13                    // &in_ptr1[...]
    v.shl        v12, v9, v10
    s.addi       s13, s14, #4
    v.cmp.lt     p1, v11, v7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s13, v12]             // index is in elements (ISA sec 9.1)
    v.splat      v9, s12
    v.iota       v10                             // arange(0, VLEN)
    s.movz       s13, #576
    s.movz       s15, #16
    s.muli       s16, s10, #2304
    v.add        v13, v9, v10
    v.movi       v9, #0
    v.splat      v10, s13
    v.splat      v14, s10
    v.movi       v15, #0
    v.splat      v16, s15
    v.extract    s13, v1, #0
    s.muli       s15, s12, #4
    v.extract    s17, v0, #0
    s.shli       s18, s13, #32
    v.cmp.ge     p2, v13, v9
    v.cmp.lt     p3, v13, v10
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v9, [s14, v12]             // index is in elements (ISA sec 9.1)
    v.extract    s13, v7, #0
    v.cmp.ge     p4, v14, v15
    s.shli       s14, s13, #32
    v.cmp.lt     p5, v14, v16
    v.extract    s13, v7, #1
    v.extract    s19, v1, #1
    s.add        s20, s2, s16
    p.and        p6, p2, p3
    p.and        p2, p4, p5
    s.or         s16, s17, s18
    v.movi       v10, #0
    s.shli       s17, s13, #32
    v.extract    s13, v0, #1
    s.shli       s18, s19, #32
    s.add        s19, s20, s15
    p.and        p3, p6, p2
    v.extract    s15, v7, #2
    s.or         s20, s13, s18
    v.extract    s13, v9, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v12, [s19, #0]
    s.or         s18, s13, s14
    v.extract    s13, v9, #1
    s.cmp.le     s14, s18, s16
    v.extract    s16, v1, #2
    s.or         s18, s13, s17
    v.insert     v10, s14, #0
    v.extract    s13, v9, #2
    s.shli       s14, s15, #32
    v.extract    s15, v0, #2
    s.shli       s17, s16, #32
    s.cmp.le     s16, s18, s20
    v.extract    s18, v7, #3
    v.extract    s19, v1, #3
    s.or         s20, s13, s14
    s.or         s13, s15, s17
    v.insert     v10, s16, #1
    v.extract    s14, v9, #3
    s.shli       s15, s18, #32
    v.extract    s16, v0, #3
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s13
    v.extract    s13, v7, #4
    v.extract    s19, v1, #4
    s.or         s20, s14, s15
    s.or         s14, s16, s17
    v.insert     v10, s18, #2
    v.extract    s15, v9, #4
    s.shli       s16, s13, #32
    v.extract    s13, v0, #4
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s14
    v.extract    s14, v7, #5
    v.extract    s19, v1, #5
    s.or         s20, s15, s16
    s.or         s15, s13, s17
    v.insert     v10, s18, #3
    v.extract    s13, v9, #5
    s.shli       s16, s14, #32
    v.extract    s14, v0, #5
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s15
    v.extract    s15, v7, #6
    v.extract    s19, v1, #6
    s.or         s20, s13, s16
    s.or         s13, s14, s17
    v.insert     v10, s18, #4
    v.extract    s14, v9, #6
    s.shli       s16, s15, #32
    v.extract    s15, v0, #6
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s13
    v.extract    s13, v7, #7
    v.extract    s19, v1, #7
    s.or         s20, s14, s16
    s.or         s14, s15, s17
    v.insert     v10, s18, #5
    v.extract    s15, v9, #7
    s.shli       s16, s13, #32
    v.extract    s13, v0, #7
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s14
    v.extract    s14, v7, #8
    v.extract    s19, v1, #8
    s.or         s20, s15, s16
    s.or         s15, s13, s17
    v.insert     v10, s18, #6
    v.extract    s13, v9, #8
    s.shli       s16, s14, #32
    v.extract    s14, v0, #8
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s15
    v.extract    s15, v7, #9
    v.extract    s19, v1, #9
    s.or         s20, s13, s16
    s.or         s13, s14, s17
    v.insert     v10, s18, #7
    v.extract    s14, v9, #9
    s.shli       s16, s15, #32
    v.extract    s15, v0, #9
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s13
    v.extract    s13, v7, #10
    v.extract    s19, v1, #10
    s.or         s20, s14, s16
    s.or         s14, s15, s17
    v.insert     v10, s18, #8
    v.extract    s15, v9, #10
    s.shli       s16, s13, #32
    v.extract    s13, v0, #10
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s14
    v.extract    s14, v7, #11
    v.extract    s19, v1, #11
    s.or         s20, s15, s16
    s.or         s15, s13, s17
    v.insert     v10, s18, #9
    v.extract    s13, v9, #11
    s.shli       s16, s14, #32
    v.extract    s14, v0, #11
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s15
    v.extract    s15, v7, #12
    v.extract    s19, v1, #12
    s.or         s20, s13, s16
    s.or         s13, s14, s17
    v.insert     v10, s18, #10
    v.extract    s14, v9, #12
    s.shli       s16, s15, #32
    v.extract    s15, v0, #12
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s13
    v.extract    s13, v7, #13
    v.extract    s19, v1, #13
    s.or         s20, s14, s16
    s.or         s14, s15, s17
    v.insert     v10, s18, #11
    v.extract    s15, v9, #13
    s.shli       s16, s13, #32
    v.extract    s13, v0, #13
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s14
    v.extract    s14, v7, #14
    v.extract    s19, v1, #14
    s.or         s20, s15, s16
    s.or         s15, s13, s17
    v.insert     v10, s18, #12
    v.extract    s13, v9, #14
    s.shli       s16, s14, #32
    v.extract    s14, v0, #14
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s15
    v.extract    s15, v7, #15
    v.extract    s19, v1, #15
    s.or         s20, s13, s16
    s.or         s13, s14, s17
    v.insert     v10, s18, #13
    v.extract    s14, v9, #15
    s.shli       s16, s15, #32
    v.extract    s15, v0, #15
    s.shli       s17, s19, #32
    s.cmp.le     s18, s20, s13
    s.or         s13, s14, s16
    s.or         s14, s15, s17
    v.insert     v10, s18, #14
    s.cmp.le     s15, s13, s14
    v.movi       v7, #0
    v.insert     v10, s15, #15
    v.extract    s13, v3, #0
    .li       s14, #1069066811
    v.splat      v9, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p2, v10, v7
    @p2 v.sel        v7, v4, v5
    v.splat      v10, s13
    .li       s13, #1060205080
    v.splat      v13, s13                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.add       v14, v12, v7
    s.mul        s13, s10, s8
    v.movi       v7, #0
    s.add        s14, s12, s9
    s.movz       s15, #1
    vf.sub       v12, v14, v10
    s.add        s16, s12, s13
    v.splat      v10, s13
    s.shli       s13, s16, #2                    // element offset -> bytes (x4)
    vf.mul       v14, v12, v9
    s.add        s16, s6, s13                    // &out_ptr2[...]
    v.add        v15, v11, v10
    v.exp2.approx v10, v14                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v11, v12, v9, v14               // the exact rounding error of x*log2(e)
    vf.mul       v9, v11, v13
    vf.fma       v11, v10, v9, v10               // 2**t * 2**d
    vf.cmp.o     p2, v11, v11
    @p2 v.sel        v9, v11, v10
    vf.add       v10, v6, v9
    @p1 v.st.w       [s16, #0], v9
    @p1 v.sel        v9, v10, v6
    v.mov        v7, v9
    v.mov        v6, v7
    s.mov        s12, s14
    br.nz        s15, for_3
endfor_4:
    vf.reduce.add.b v0, v6
    s.movz       s12, #1
    s.shli       s13, s10, #2                    // element offset -> bytes (x4)
    vf.add       v1, v0, v8
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v2, s12
    s.add        s12, s7, s13                    // &out_ptr3[...]
    v.cmp.lt     p1, v0, v2
    @p1 v.st.w       [s12, #0], v1
__rctx_next:
    s.addi       s12, s10, #2                    // the next program of this context: + 2
    s.cmp.lt     s13, s12, s11
    s.mov        s10, s12
    br.nz        s13, __rctx_program
    exit
