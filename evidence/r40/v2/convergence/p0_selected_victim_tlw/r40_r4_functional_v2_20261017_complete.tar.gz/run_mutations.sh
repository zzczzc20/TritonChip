source ~/tc_env/env.sh
cd /home/zhongchun/r40_r4_functional_v2_20261017
python3 run_mutations.py > mutations.log 2>&1
echo $? > mutations.exit
