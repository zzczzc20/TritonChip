    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    v.movi       v0, #16
    v.movi       v1, #64
    v.movi       v2, #0
    v.movi       v3, #1024
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #32
    v.movi       v6, #48
    v.movi       v7, #80
    v.movi       v8, #96
    v.movi       v9, #112
    v.sub        v10, v2, v0
    v.sub        v11, v2, v1
    v.sub        v12, v2, v3
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (0 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
    v.add        v13, v4, v0
    v.add        v14, v4, v5
    v.add        v15, v4, v6
    v.add        v6, v4, v1
    v.add        v16, v4, v7
    v.add        v7, v4, v8
    v.add        v8, v4, v9
    @p1 v.sel        v9, v10, v0
    v.cmp.lt     p1, v3, v2
    v.movi       v0, #15
    v.movi       v9, #4
    @p2 v.sel        v10, v11, v1
    v.movi       v1, #63
    @p1 v.sel        v10, v12, v3
    v.movi       v3, #10
    v.movi       v10, #128
tiles_1:
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s9, s1, s8
    v.splat      v11, s9
    v.add        v12, v11, v4
    v.add        v17, v11, v13
    v.add        v18, v11, v14
    v.add        v19, v11, v15
    v.add        v20, v11, v6
    v.add        v21, v11, v16
    v.add        v22, v11, v7
    v.add        v23, v11, v8
    v.sub        v11, v2, v12
    v.sub        v24, v2, v17
    v.sub        v25, v2, v18
    v.sub        v26, v2, v19
    v.sub        v27, v2, v20
    v.sub        v28, v2, v21
    v.sub        v29, v2, v22
    v.sub        v30, v2, v23
    v.cmp.lt     p1, v12, v2
    v.cmp.lt     p2, v17, v2
    v.cmp.lt     p3, v18, v2
    v.cmp.lt     p4, v19, v2
    v.cmp.lt     p5, v20, v2
    v.cmp.lt     p6, v21, v2
    v.cmp.lt     p7, v22, v2
    v.cmp.lt     p8, v23, v2
    @p1 v.sel        v31, v11, v12
    @p2 v.sel        v11, v24, v17
    @p3 v.sel        v12, v25, v18
    @p4 v.sel        v17, v26, v19
    @p5 v.sel        v18, v27, v20
    @p6 v.sel        v19, v28, v21
    @p7 v.sel        v20, v29, v22
    @p8 v.sel        v21, v30, v23
    v.lshr       v22, v31, v9
    v.and        v23, v31, v0
    v.lshr       v24, v11, v9
    v.sub        v25, v2, v22
    v.and        v26, v11, v0
    v.and        v27, v12, v0
    @p1 v.sel        v28, v25, v22
    v.and        v22, v17, v0
    v.and        v25, v18, v0
    v.and        v29, v19, v0
    v.and        v30, v20, v0
    v.and        v32, v21, v0
    v.sub        v33, v2, v23
    v.sub        v34, v2, v24
    v.sub        v35, v2, v26
    v.sub        v36, v2, v27
    v.sub        v37, v2, v22
    v.sub        v38, v2, v25
    v.sub        v39, v2, v29
    v.sub        v40, v2, v30
    v.sub        v41, v2, v32
    @p1 v.sel        v42, v33, v23
    v.lshr       v23, v12, v9
    v.lshr       v33, v17, v9
    @p2 v.sel        v43, v34, v24
    v.sub        v24, v2, v23
    v.sub        v34, v2, v33
    @p2 v.sel        v44, v35, v26
    v.lshr       v26, v18, v9
    v.lshr       v35, v19, v9
    @p3 v.sel        v45, v24, v23
    v.sub        v23, v2, v26
    v.sub        v24, v2, v35
    @p4 v.sel        v46, v34, v33
    @p5 v.sel        v33, v23, v26
    @p3 v.sel        v23, v36, v27
    v.lshr       v26, v20, v9
    v.lshr       v27, v21, v9
    @p6 v.sel        v34, v24, v35
    v.sub        v24, v2, v26
    v.sub        v35, v2, v27
    @p4 v.sel        v36, v37, v22
    @p7 v.sel        v22, v24, v26
    @p8 v.sel        v24, v35, v27
    v.sub        v26, v2, v28
    v.cmp.lt     p9, v28, v2
    @p5 v.sel        v27, v38, v25
    v.sub        v25, v2, v43
    v.cmp.lt     p10, v43, v2
    @p9 v.sel        v35, v26, v28
    @p10 v.sel        v26, v25, v43
    @p6 v.sel        v25, v39, v29
    v.sub        v29, v2, v45
    v.and        v37, v35, v1
    v.and        v35, v26, v1
    @p7 v.sel        v26, v40, v30
    v.sub        v30, v2, v46
    v.sub        v38, v2, v37
    v.sub        v39, v2, v35
    @p8 v.sel        v40, v41, v32
    v.sub        v32, v2, v33
    v.sub        v41, v2, v34
    v.sub        v47, v2, v22
    v.sub        v48, v2, v24
    v.lshr       v49, v31, v3
    v.lshr       v31, v11, v3
    @p9 v.sel        v11, v38, v37
    v.cmp.lt     p9, v45, v2
    @p9 v.sel        v37, v29, v45
    v.lshr       v29, v12, v3
    v.lshr       v12, v17, v3
    v.and        v17, v37, v1
    v.sub        v37, v2, v49
    v.sub        v38, v2, v31
    v.sub        v50, v2, v29
    @p1 v.sel        v51, v37, v49
    v.cmp.lt     p1, v46, v2
    @p1 v.sel        v37, v30, v46
    v.sub        v30, v2, v12
    @p2 v.sel        v49, v38, v31
    v.cmp.lt     p2, v33, v2
    @p2 v.sel        v31, v32, v33
    v.and        v32, v37, v1
    v.sub        v37, v2, v17
    v.and        v38, v31, v1
    @p3 v.sel        v31, v50, v29
    v.cmp.lt     p3, v34, v2
    @p3 v.sel        v29, v41, v34
    v.sub        v41, v2, v32
    @p10 v.sel        v50, v39, v35
    v.cmp.lt     p10, v22, v2
    @p10 v.sel        v35, v47, v22
    v.lshr       v39, v18, v3
    v.lshr       v18, v19, v3
    v.and        v19, v29, v1
    v.and        v29, v35, v1
    v.sub        v35, v2, v39
    @p4 v.sel        v47, v30, v12
    v.cmp.lt     p4, v24, v2
    @p4 v.sel        v12, v48, v24
    v.sub        v30, v2, v18
    @p5 v.sel        v48, v35, v39
    v.and        v35, v12, v1
    v.sub        v12, v2, v38
    v.sub        v39, v2, v19
    @p9 v.sel        v52, v37, v17
    v.lshr       v17, v20, v3
    v.lshr       v20, v21, v3
    v.sub        v21, v2, v29
    v.sub        v37, v2, v17
    @p6 v.sel        v53, v30, v18
    v.sub        v18, v2, v20
    v.sub        v30, v2, v35
    @p7 v.sel        v54, v37, v17
    @p1 v.sel        v17, v41, v32
    @p8 v.sel        v32, v18, v20
    @p2 v.sel        v18, v12, v38
    @p3 v.sel        v12, v39, v19
    @p10 v.sel        v19, v21, v29
    @p4 v.sel        v20, v30, v35
    v.mul        v21, v51, v5
    v.mul        v29, v49, v5
    v.mul        v30, v31, v5
    v.mul        v31, v47, v5
    v.mul        v35, v48, v5
    v.mul        v37, v53, v5
    v.mul        v38, v54, v5
    v.mul        v39, v32, v5
    v.add        v32, v42, v21
    v.add        v21, v44, v29
    v.add        v29, v23, v30
    v.add        v30, v36, v31
    v.add        v31, v27, v35
    v.add        v35, v25, v37
    v.add        v37, v26, v38
    v.add        v38, v40, v39
    v.mul        v39, v11, v10
    v.mul        v11, v50, v10
    v.mul        v41, v52, v10
    v.mul        v47, v17, v10
    v.mul        v17, v18, v10
    v.mul        v18, v12, v10
    v.mul        v12, v19, v10
    v.mul        v19, v20, v10
    v.add        v20, v32, v39
    v.add        v32, v21, v11
    v.add        v11, v29, v41
    v.add        v21, v30, v47
    v.add        v29, v31, v17
    v.add        v17, v35, v18
    v.add        v18, v37, v12
    v.add        v12, v38, v19
    v.ld.gather.h v19, [s3, v20]                 // index is in elements (ISA sec 9.1)
    v.mul        v20, v28, v5
    v.mul        v28, v43, v5
    v.mul        v30, v45, v5
    v.mul        v31, v46, v5
    v.mul        v35, v33, v5
    v.mul        v33, v34, v5
    v.mul        v34, v22, v5
    v.mul        v22, v24, v5
    v.add        v24, v42, v20
    v.add        v20, v44, v28
    v.add        v28, v23, v30
    v.add        v23, v36, v31
    v.add        v30, v27, v35
    v.ld.gather.h v27, [s3, v32]                 // index is in elements (ISA sec 9.1)
    v.add        v31, v25, v33
    v.add        v25, v26, v34
    v.add        v26, v40, v22
    v.ld.gather.h v22, [s3, v11]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v11, [s3, v21]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v21, [s3, v29]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v29, [s3, v17]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v17, [s3, v18]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v18, [s3, v12]                 // index is in elements (ISA sec 9.1)
    v.st.scatter.h [s7, v24], v19
    v.st.scatter.h [s7, v20], v27
    v.st.scatter.h [s7, v28], v22
    v.st.scatter.h [s7, v23], v11
    v.st.scatter.h [s7, v30], v21
    v.st.scatter.h [s7, v31], v29
    v.st.scatter.h [s7, v25], v17
    v.st.scatter.h [s7, v26], v18
    s.addi       s8, s8, #128
    s.cmp.lt     s9, s8, s2
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
