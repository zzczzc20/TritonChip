    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #5
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    s.rdspecial  s1, arg_base
    .li       s2, #1132462080
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.lshr       v5, v4, v0
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v0, v2, v5
    v.movi       v4, #512
    @p1 v.sel        v6, v0, v5
    v.cmp.lt     p1, v3, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s2, v6]               // index is in elements (ISA sec 9.1)
    v.movi       v5, #0
    v.movi       v7, #31
    v.sub        v8, v5, v3
    v.cmp.lt     p2, v3, v5
    @p2 v.sel        v9, v8, v3
    v.movi       v3, #32
    v.and        v8, v9, v7
    v.mul        v7, v6, v4
    v.sub        v4, v5, v8
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.rcp.approx v9, v1                          // ISA 8.8: <= 2**-22 relative
    .li       s3, #1065353216
    v.splat      v10, s3                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p2 v.sel        v11, v4, v8
    s.ld.d       s3, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.add        v4, v11, v3
    v.add        v8, v11, v7
    v.add        v12, v4, v7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v7, [s3, v4]               // index is in elements (ISA sec 9.1)
    v.sub        v4, v5, v3
    v.sub        v13, v2, v3
    v.cmp.lt     p2, v3, v5
    v.cmp.lt     p3, v3, v2
    @p2 v.sel        v2, v4, v3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s2, v12]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v4, v7
    @p3 v.sel        v5, v13, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s2, v8]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v5, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s3, v11]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v7, v3
    vf.fms       v3, v1, v9, v10
    vf.cvt.bf16.f32 v8, v2
    s.ld.d       s2, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    vf.fms       v2, v9, v3, v9
    s.ld.d       s3, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    .li       s1, #897988541
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.neg       v10, v2                         // Newton step: r0*(2 - x*r0)
    .li       s1, #1077936128
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v14, v10, v9
    vf.add       v9, v4, v13
    vf.mul       v4, v0, v14                     // a/y: faithful quotient
    vf.add       v10, v8, v13
    v.movi       v8, #64
    vf.fms       v13, v4, v1, v0
    v.mul        v0, v6, v8
    v.add        v1, v11, v0
    vf.fms       v0, v13, v14, v4
    vf.neg       v6, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v6, v6
    @p2 v.sel        v0, v6, v4
    vf.add       v4, v0, v3
    v.rsqrt.approx v0, v4                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v0, v0
    vf.mul       v6, v0, v12
    vf.fms       v8, v4, v3, v2
    vf.mul       v2, v6, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v3, v2, v0
    vf.mul       v0, v5, v3
    vf.mul       v2, v7, v3
    vf.mul       v3, v0, v9
    vf.mul       v0, v2, v10
    vf.neg       v2, v3
    vf.cvt.f32.bf16 v3, v0
    vf.cvt.f32.bf16 v0, v2
    @p1 v.st.scatter.h [s2, v1], v0
    @p1 v.st.scatter.h [s3, v1], v3
__rctx_next:
    exit
