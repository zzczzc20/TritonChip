#!/usr/bin/env python3
"""Localize segmentation effects in CPU Qwen3.5; no device inference."""
import hashlib,json,sys,time
from pathlib import Path
import torch
home=Path.home();tree=home/'r41_q35_multiturn_diag_20261031'
sys.path[:0]=[str(tree/'tools/models'),str(tree),str(tree/'python'),str(tree/'compiler/python'),str(tree/'tools/asm')]
import chat
prompt='My name is Alice. Please remember it and reply with one short sentence.'
args=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1'])
app=chat.ChatApplication(args);chat.L.install_fp8_route('reference',dot='exact',scale_div='ieee')
inputs,text=chat.make_inputs(app.spec,app.processor,[chat.user_message(prompt)])
layers=app.model.model.language_model.layers
captures={};handles=[]
for idx,layer in enumerate(layers):
 def hook(module,args,out,i=idx):
  x=out[0] if isinstance(out,(tuple,list)) else out
  if not isinstance(x,torch.Tensor) or x.ndim != 3:raise TypeError(f'layer {i}: unexpected output {type(out)} shape={getattr(x,"shape",None)}')
  captures.setdefault(i,[]).append(x.detach().cpu().contiguous().clone())
 handles.append(layer.register_forward_hook(hook))
values={}; calls={}
try:
 for name,chunk in [('whole',0),('grouped_chunk8',8)]:
  captures.clear(); start=time.monotonic();session=chat.Session(app.model,app.spec,'cpu',256,chunk)
  with torch.no_grad(): logits,parts,reused=session.prefill_prompt(inputs,None)
  values[name]={i:torch.cat(captures[i],dim=1) for i in range(len(layers))}
  calls[name]={'seconds':time.monotonic()-start,'chunks':[x['tokens'] for x in parts]}
  del session
finally:
 for h in handles:h.remove()
rows=[]
for i,layer in enumerate(layers):
 a,b=values['whole'][i],values['grouped_chunk8'][i]
 if a.shape!=b.shape or a.dtype!=b.dtype:raise ValueError(f'layer {i}: shapes/dtypes differ')
 dtype={2:torch.int16,4:torch.int32}.get(a.element_size())
 if dtype is None:raise TypeError(f'layer {i}: dtype {a.dtype}')
 diff=a.view(dtype)!=b.view(dtype);pos=diff.any(dim=-1).reshape(-1);p=torch.nonzero(pos).flatten();af=a.float();bf=b.float();last_a=af[:,-1,:];last_b=bf[:,-1,:]
 rows.append(dict(layer=i,kind=getattr(layer,'layer_type',type(layer).__name__),first_differing_position=int(p[0]) if len(p) else None,differing_positions=int(pos.sum()),elements=a.numel(),bit_mismatches=int(diff.sum()),rel_l2=float((af-bf).norm()/af.norm().clamp_min(1e-30)),last_rel_l2=float((last_a-last_b).norm()/last_a.norm().clamp_min(1e-30)),max_abs=float((af-bf).abs().max())))
out={'schema':'r41-q35-cpu-layer-segmentation/1','scope':'full-checkpoint CPU-only exact FP8 route; no board or TLM values','prompt':prompt,'input_ids':inputs['input_ids'].tolist(),'model':app.spec.name,'revision':app.spec.revision,'chat_sha256':hashlib.sha256((tree/'tools/models/chat.py').read_bytes()).hexdigest(),'calls':calls,'layers':rows}
p=home/'r41_q35_cpu_layer_compare_20261031.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
