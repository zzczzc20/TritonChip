    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.add        v2, v1, v0
    s.shli       s4, s1, #1                      // element offset -> bytes (x2)
    s.add        s1, s2, s4                      // &in_ptr0[...]
    v.ld.h       v0, [s1, #0]
    vf.cvt.bf16.f32 v1, v0
    v.movi       v0, #0
    vf.max.prop  v2, v1, v0
    vf.cvt.f32.bf16 v0, v2
    s.add        s1, s3, s4                      // &out_ptr0[...]
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
