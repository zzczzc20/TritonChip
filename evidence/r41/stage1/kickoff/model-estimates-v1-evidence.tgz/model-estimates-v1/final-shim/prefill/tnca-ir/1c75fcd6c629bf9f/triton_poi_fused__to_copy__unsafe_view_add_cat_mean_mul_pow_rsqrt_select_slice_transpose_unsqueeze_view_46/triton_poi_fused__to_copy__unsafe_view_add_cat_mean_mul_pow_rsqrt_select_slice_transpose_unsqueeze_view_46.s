    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #192
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.movi       v3, #1
    v.splat      v4, s2
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v1, v2
    v.add        v6, v4, v0
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p1 v.sel        v0, v5, v1
    v.sub        v4, v2, v6
    v.cmp.lt     p1, v6, v2
    v.movi       v5, #0
    @p1 v.sel        v7, v4, v6
    v.movi       v4, #0
    s.movz       s3, #31
    s.ld.d       s4, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
idiv_1:
    v.splat      v8, s3
    v.shl        v9, v4, v3
    v.cmp.lt     p2, v4, v2
    v.lshr       v10, v7, v8
    v.shl        v11, v3, v8
    s.subi       s1, s3, #1
    v.and        v8, v10, v3
    s.movz       s7, #0
    v.or         v10, v9, v8
    v.cmp.geu    p3, v10, v0
    p.or         p4, p2, p3
    v.sub        v8, v10, v0
    @p4 v.sel        v9, v11, v2
    @p4 v.sel        v11, v8, v10
    v.or         v8, v5, v9
    v.mov        v4, v11
    v.mov        v5, v8
    s.mov        s3, s1
    s.cmp.ge     s1, s3, s7
    br.nz        s1, idiv_1
    v.movi       v0, #0
    v.sub        v3, v2, v4
    v.movi       v2, #1
    v.sub        v5, v0, v6
    v.sub        v7, v0, v1
    v.cmp.lt     p2, v6, v0
    v.cmp.lt     p3, v1, v0
    @p1 v.sel        v8, v3, v4
    @p2 v.sel        v3, v5, v6
    @p3 v.sel        v4, v7, v1
    v.movi       v1, #0
    v.movi       v5, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v7, s1
    v.shl        v9, v5, v2
    v.cmp.lt     p1, v5, v0
    v.lshr       v10, v3, v7
    v.shl        v11, v2, v7
    s.subi       s3, s1, #1
    v.and        v7, v10, v2
    s.movz       s7, #0
    v.or         v10, v9, v7
    v.cmp.geu    p4, v10, v4
    p.or         p5, p1, p4
    v.sub        v7, v10, v4
    @p5 v.sel        v9, v11, v0
    @p5 v.sel        v11, v7, v10
    v.or         v7, v1, v9
    v.mov        v5, v11
    v.mov        v1, v7
    s.mov        s1, s3
    s.cmp.ge     s3, s1, s7
    br.nz        s3, idiv_2
    v.sub        v2, v0, v1
    p.xor        p1, p2, p3
    v.movi       v0, #0
    @p1 v.sel        v3, v2, v1
    v.movi       v1, #1
    v.movi       v2, #2
    v.sub        v4, v0, v3
    v.cmp.lt     p1, v3, v0
    v.movi       v5, #384
    @p1 v.sel        v7, v4, v3
    v.movi       v4, #0
    v.sub        v9, v0, v2
    v.and        v10, v7, v1
    v.sub        v1, v4, v6
    v.sub        v7, v4, v5
    v.sub        v11, v0, v10
    v.cmp.lt     p2, v2, v0
    v.cmp.lt     p3, v6, v4
    v.movi       v0, #1
    @p2 v.sel        v0, v9, v2
    v.cmp.lt     p2, v5, v4
    @p1 v.sel        v0, v11, v10
    v.movi       v2, #1
    @p3 v.sel        v9, v1, v6
    @p2 v.sel        v1, v7, v5
    v.movi       v5, #0
    v.movi       v6, #0
    s.movz       s1, #31
idiv_3:
    v.splat      v7, s1
    v.shl        v10, v6, v2
    v.cmp.lt     p1, v6, v4
    v.lshr       v11, v9, v7
    v.shl        v12, v2, v7
    s.subi       s3, s1, #1
    v.and        v7, v11, v2
    s.movz       s7, #0
    v.or         v11, v10, v7
    v.cmp.geu    p4, v11, v1
    p.or         p5, p1, p4
    v.sub        v7, v11, v1
    @p5 v.sel        v10, v12, v4
    @p5 v.sel        v12, v7, v11
    v.or         v7, v5, v10
    v.mov        v6, v12
    v.mov        v5, v7
    s.mov        s1, s3
    s.cmp.ge     s3, s1, s7
    br.nz        s3, idiv_3
    .li       s1, #1132462080
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.gather.w v6, [s4, v3]                   // index is in elements (ISA sec 9.1)
    v.rcp.approx v7, v1                          // ISA 8.8: <= 2**-22 relative
    .li       s1, #897988541
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v10, #64
    v.movi       v11, #256
    .li       s1, #1077936128
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.add        v13, v8, v10
    v.mul        v10, v3, v11
    .li       s1, #3204448256
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v14, v4, v5
    v.add        v4, v13, v10
    p.xor        p1, p3, p2
    s.movz       s1, #64
    @p1 v.sel        v10, v14, v5
    .li       s1, #1065353216
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.movz       s1, #256
    v.mul        v14, v10, v11
    s.movz       s1, #32768
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.ld.gather.h v11, [s2, v4]                  // index is in elements (ISA sec 9.1)
    v.add        v4, v8, v14
    v.mul        v8, v0, v10
    s.movz       s1, #32768
    v.add        v0, v4, v8
    vf.fms       v4, v1, v7, v2
    v.ld.gather.h v1, [s5, v13]                  // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v11
    vf.fms       v8, v7, v4, v7
    vf.neg       v4, v8                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v8, v4, v7
    vf.cvt.bf16.f32 v4, v1
    vf.mul       v1, v6, v8                      // a/y as a refined reciprocal (ISA has no divide)
    vf.add       v6, v4, v5
    vf.add       v4, v1, v9
    v.rsqrt.approx v1, v4                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v5, v1, v1
    vf.mul       v7, v1, v3
    vf.fms       v3, v4, v5, v12
    vf.mul       v4, v7, v3                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v4, v4
    @p1 v.sel        v3, v4, v1
    vf.mul       v1, v2, v3
    vf.mul       v2, v1, v6
    vf.cvt.f32.bf16 v1, v2
    v.st.scatter.h [s6, v0], v1
__rctx_next:
    exit
