import json, sys
def load(p):
    d = json.load(open(p))
    return {c['case']: c for c in d['cases']}, d.get('code')
b, bc = load(sys.argv[1]); c, cc = load(sys.argv[2])
print(f"{'case':55s} {'base cyc':>12s} {'x8dot cyc':>12s} {'speedup':>8s} status")
for k in c:
    if 'matmul' not in k and 'FP8Linear' not in k and 'w8a8' not in k: continue
    if k not in b: continue
    cb = sum(l.get('device_cycles') or 0 for l in b[k].get('launches', []))
    ccy = sum(l.get('device_cycles') or 0 for l in c[k].get('launches', []))
    print(f"{k[:55]:55s} {cb:12,d} {ccy:12,d} {cb/ccy if ccy else 0:8.2f} {b[k]['status']}/{c[k]['status']}")
