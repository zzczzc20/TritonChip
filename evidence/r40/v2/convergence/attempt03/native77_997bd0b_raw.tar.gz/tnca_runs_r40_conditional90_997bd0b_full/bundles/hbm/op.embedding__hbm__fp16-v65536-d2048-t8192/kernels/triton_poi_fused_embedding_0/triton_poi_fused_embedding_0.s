    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    s.movz       s3, #0
    s.ld.d       s4, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.splat      v2, s2
    s.movz       s5, #0
    s.movz       s6, #0
    v.add        v3, v2, v0
    s.movz       s7, #0
    s.movz       s8, #0
    v.sub        v0, v1, v3
    v.cmp.lt     p1, v3, v1
    s.movz       s9, #0
    @p1 v.sel        v2, v0, v3
    s.addi       s10, s4, #4
    s.ld.d       s11, [s1, #8]                   // in_ptr1: device_ptr64 at arg_base+8
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #0
    s.movz       s17, #0
    s.movz       s18, #0
    s.movz       s19, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.ld.d       s22, [s1, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    v.movi       v0, #11
    v.movi       v4, #1
    .li       s1, #65536
    v.lshr       v5, v2, v0
    .li       s23, #65536
    .li       s24, #65536
    v.sub        v0, v1, v5
    v.movi       v2, #0
    .li       s25, #65536
    @p1 v.sel        v6, v0, v5
    .li       s26, #65536
    .li       s27, #65536
    v.shl        v0, v6, v4
    .li       s28, #65536
    .li       s29, #65536
    v.ld.gather.w v4, [s10, v0]                  // index is in elements (ISA sec 9.1)
    .li       s10, #65536
    .li       s30, #65536
    .li       s31, #65536
    .li       s32, #65536
    .li       s33, #65536
    .li       s34, #65536
    .li       s35, #65536
    .li       s36, #65536
    v.movi       v5, #0
    v.movi       v6, #2047
    v.movi       v7, #2048
    v.sub        v8, v5, v3
    v.cmp.lt     p1, v3, v5
    s.movz       s37, #0
    @p1 v.sel        v9, v8, v3
    v.sub        v3, v1, v7
    v.cmp.lt     p2, v7, v1
    v.ld.gather.w v1, [s4, v0]                   // index is in elements (ISA sec 9.1)
    v.extract    s4, v4, #0
    v.extract    s38, v4, #1
    s.shli       s39, s4, #32
    s.shli       s4, s38, #32
    v.extract    s38, v4, #2
    v.extract    s40, v4, #3
    s.shli       s41, s38, #32
    v.and        v0, v9, v6
    v.sub        v6, v5, v7
    v.cmp.lt     p3, v7, v5
    v.sub        v8, v5, v0
    v.movi       v5, #1
    s.shli       s38, s40, #32
    v.extract    s40, v4, #4
    @p2 v.sel        v5, v3, v7
    s.shli       s42, s40, #32
    v.extract    s40, v4, #5
    v.extract    s43, v1, #0
    v.movi       v3, #1
    s.or         s44, s43, s39
    v.extract    s39, v1, #1
    s.cmp.ge     s43, s44, s3
    s.or         s3, s39, s4
    v.insert     v2, s43, #0
    v.extract    s4, v1, #2
    s.cmp.ge     s39, s3, s5
    s.or         s3, s4, s41
    v.insert     v2, s39, #1
    v.extract    s4, v1, #3
    s.cmp.ge     s5, s3, s6
    s.or         s3, s4, s38
    v.insert     v2, s5, #2
    v.extract    s4, v1, #4
    s.cmp.ge     s5, s3, s7
    s.or         s3, s4, s42
    v.insert     v2, s5, #3
    v.extract    s4, v1, #5
    s.shli       s5, s40, #32
    s.cmp.ge     s6, s3, s8
    v.extract    s3, v4, #6
    s.or         s7, s4, s5
    v.insert     v2, s6, #4
    v.extract    s4, v1, #6
    s.cmp.ge     s5, s7, s9
    @p3 v.sel        v3, v6, v7
    s.shli       s6, s3, #32
    v.insert     v2, s5, #5
    s.or         s3, s4, s6
    @p1 v.sel        v3, v8, v0
    v.extract    s4, v4, #7
    v.extract    s5, v1, #7
    s.shli       s6, s4, #32
    s.cmp.ge     s4, s3, s12
    v.extract    s3, v4, #8
    s.or         s7, s5, s6
    v.insert     v2, s4, #6
    v.extract    s4, v1, #8
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s7, s13
    v.extract    s6, v4, #9
    s.or         s7, s4, s5
    v.insert     v2, s3, #7
    v.extract    s3, v1, #9
    s.shli       s4, s6, #32
    s.cmp.ge     s5, s7, s14
    v.extract    s6, v4, #10
    s.or         s7, s3, s4
    v.insert     v2, s5, #8
    v.extract    s3, v1, #10
    s.shli       s4, s6, #32
    s.cmp.ge     s5, s7, s15
    v.extract    s6, v4, #11
    s.or         s7, s3, s4
    v.insert     v2, s5, #9
    v.extract    s3, v1, #11
    s.shli       s4, s6, #32
    s.cmp.ge     s5, s7, s16
    v.extract    s6, v4, #12
    s.or         s7, s3, s4
    v.insert     v2, s5, #10
    v.extract    s3, v1, #12
    s.shli       s4, s6, #32
    s.cmp.ge     s5, s7, s17
    v.extract    s6, v4, #13
    s.or         s7, s3, s4
    v.insert     v2, s5, #11
    v.extract    s3, v1, #13
    s.shli       s4, s6, #32
    s.cmp.ge     s5, s7, s18
    v.extract    s6, v4, #14
    s.or         s7, s3, s4
    v.insert     v2, s5, #12
    v.extract    s3, v1, #14
    s.shli       s4, s6, #32
    s.cmp.ge     s5, s7, s19
    v.extract    s6, v4, #15
    v.extract    s7, v4, #0
    s.or         s8, s3, s4
    v.insert     v2, s5, #13
    v.extract    s3, v1, #15
    s.shli       s4, s6, #32
    v.extract    s5, v1, #0
    s.shli       s6, s7, #32
    s.cmp.ge     s7, s8, s20
    v.extract    s8, v4, #1
    s.or         s9, s3, s4
    s.or         s3, s5, s6
    v.insert     v2, s7, #14
    v.movi       v0, #0
    v.extract    s4, v1, #1
    s.shli       s5, s8, #32
    s.cmp.ge     s6, s9, s21
    s.cmp.lt     s7, s3, s1
    v.extract    s1, v4, #2
    s.or         s3, s4, s5
    v.insert     v2, s6, #15
    v.insert     v0, s7, #0
    v.extract    s4, v1, #2
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s3, s23
    v.extract    s3, v4, #3
    s.or         s6, s4, s5
    v.insert     v0, s1, #1
    v.extract    s1, v1, #3
    s.shli       s4, s3, #32
    s.cmp.lt     s3, s6, s24
    v.extract    s5, v4, #4
    s.or         s6, s1, s4
    v.insert     v0, s3, #2
    v.extract    s1, v1, #4
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s25
    v.extract    s5, v4, #5
    s.or         s6, s1, s3
    v.insert     v0, s4, #3
    v.extract    s1, v1, #5
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s26
    v.extract    s5, v4, #6
    s.or         s6, s1, s3
    v.insert     v0, s4, #4
    v.extract    s1, v1, #6
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s27
    v.extract    s5, v4, #7
    s.or         s6, s1, s3
    v.insert     v0, s4, #5
    v.extract    s1, v1, #7
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s28
    v.movi       v5, #0
    s.or         s5, s1, s3
    v.insert     v0, s4, #6
    v.cmp.ne     p1, v2, v5
    v.extract    s1, v4, #8
    v.extract    s3, v1, #8
    s.shli       s4, s1, #32
    s.cmp.lt     s1, s5, s29
    v.extract    s5, v4, #9
    s.or         s6, s3, s4
    v.insert     v0, s1, #7
    v.extract    s1, v1, #9
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s10
    v.extract    s5, v4, #10
    s.or         s6, s1, s3
    v.insert     v0, s4, #8
    v.extract    s1, v1, #10
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s30
    v.extract    s5, v4, #11
    s.or         s6, s1, s3
    v.insert     v0, s4, #9
    v.extract    s1, v1, #11
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s31
    v.extract    s5, v4, #12
    s.or         s6, s1, s3
    v.insert     v0, s4, #10
    v.extract    s1, v1, #12
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s32
    v.extract    s5, v4, #13
    s.or         s6, s1, s3
    v.insert     v0, s4, #11
    v.extract    s1, v1, #13
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s33
    v.extract    s5, v4, #14
    s.or         s6, s1, s3
    v.insert     v0, s4, #12
    v.extract    s1, v1, #14
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s34
    v.extract    s5, v4, #15
    s.or         s6, s1, s3
    v.insert     v0, s4, #13
    v.extract    s1, v1, #15
    s.shli       s3, s5, #32
    s.cmp.lt     s4, s6, s35
    s.or         s5, s1, s3
    v.insert     v0, s4, #14
    s.cmp.lt     s1, s5, s36
    v.movi       v2, #0
    v.insert     v0, s1, #15
    v.movi       v5, #0
    v.movi       v6, #1
    v.cmp.ne     p2, v0, v2
    p.and        p3, p1, p2
    @p3 v.sel        v0, v5, v6
    v.reduce.or  s1, v0
    s.cmp.eq     s3, s1, s37
    br.nz        s3, assert_ok_1
    trap         #677351
assert_ok_1:
    v.extract    s1, v4, #0
    v.extract    s3, v1, #0
    s.shli       s4, s1, #32
    v.extract    s1, v4, #1
    s.or         s5, s3, s4
    s.movz       s3, #2048
    v.extract    s4, v1, #1
    s.shli       s6, s1, #32
    s.mul        s1, s5, s3
    v.extract    s3, v4, #2
    s.or         s5, s4, s6
    s.movz       s4, #2048
    v.extract    s6, v1, #2
    s.shli       s7, s3, #32
    s.mul        s3, s5, s4
    v.extract    s4, v4, #3
    v.movi       v0, #0
    v.movi       v2, #0
    s.or         s5, s6, s7
    s.movz       s6, #2048
    s.lshri      s7, s1, #32
    v.extract    s8, v1, #3
    s.shli       s9, s4, #32
    s.mul        s4, s5, s6
    v.extract    s5, v4, #4
    v.insert     v0, s1, #0
    v.insert     v2, s7, #0
    s.or         s1, s8, s9
    s.movz       s6, #2048
    s.lshri      s7, s3, #32
    v.extract    s8, v1, #4
    s.shli       s9, s5, #32
    s.mul        s5, s1, s6
    v.extract    s1, v4, #5
    v.insert     v0, s3, #1
    v.insert     v2, s7, #1
    s.or         s3, s8, s9
    s.movz       s6, #2048
    s.lshri      s7, s4, #32
    v.extract    s8, v1, #5
    s.shli       s9, s1, #32
    s.mul        s1, s3, s6
    v.extract    s3, v4, #6
    v.insert     v0, s4, #2
    v.insert     v2, s7, #2
    s.or         s4, s8, s9
    s.movz       s6, #2048
    s.lshri      s7, s5, #32
    v.extract    s8, v1, #6
    s.shli       s9, s3, #32
    s.mul        s3, s4, s6
    v.extract    s4, v4, #7
    v.insert     v0, s5, #3
    v.insert     v2, s7, #3
    s.or         s5, s8, s9
    s.movz       s6, #2048
    s.lshri      s7, s1, #32
    v.extract    s8, v1, #7
    s.shli       s9, s4, #32
    s.mul        s4, s5, s6
    v.extract    s5, v4, #8
    v.insert     v0, s1, #4
    v.insert     v2, s7, #4
    s.or         s1, s8, s9
    s.movz       s6, #2048
    s.lshri      s7, s3, #32
    v.extract    s8, v1, #8
    s.shli       s9, s5, #32
    s.mul        s5, s1, s6
    v.extract    s1, v4, #9
    v.insert     v0, s3, #5
    v.insert     v2, s7, #5
    s.or         s3, s8, s9
    s.movz       s6, #2048
    s.lshri      s7, s4, #32
    v.extract    s8, v1, #9
    s.shli       s9, s1, #32
    s.mul        s1, s3, s6
    v.extract    s3, v4, #10
    v.insert     v0, s4, #6
    v.insert     v2, s7, #6
    s.or         s4, s8, s9
    s.movz       s6, #2048
    s.lshri      s7, s5, #32
    v.extract    s8, v1, #10
    s.shli       s9, s3, #32
    s.mul        s3, s4, s6
    v.extract    s4, v4, #11
    v.insert     v0, s5, #7
    v.insert     v2, s7, #7
    s.or         s5, s8, s9
    s.movz       s6, #2048
    s.lshri      s7, s1, #32
    v.extract    s8, v1, #11
    s.shli       s9, s4, #32
    s.mul        s4, s5, s6
    v.extract    s5, v4, #12
    v.insert     v0, s1, #8
    v.insert     v2, s7, #8
    s.or         s1, s8, s9
    s.movz       s6, #2048
    s.lshri      s7, s3, #32
    v.extract    s8, v1, #12
    s.shli       s9, s5, #32
    s.mul        s5, s1, s6
    v.extract    s1, v4, #13
    v.insert     v0, s3, #9
    v.insert     v2, s7, #9
    s.or         s3, s8, s9
    s.movz       s6, #2048
    s.lshri      s7, s4, #32
    v.extract    s8, v1, #13
    s.shli       s9, s1, #32
    s.mul        s1, s3, s6
    v.extract    s3, v4, #14
    v.insert     v0, s4, #10
    v.insert     v2, s7, #10
    s.or         s4, s8, s9
    s.movz       s6, #2048
    s.lshri      s7, s5, #32
    v.extract    s8, v1, #14
    s.shli       s9, s3, #32
    s.mul        s3, s4, s6
    v.extract    s4, v4, #15
    v.insert     v0, s5, #11
    v.insert     v2, s7, #11
    s.or         s5, s8, s9
    s.movz       s6, #2048
    s.lshri      s7, s1, #32
    v.extract    s8, v1, #15
    s.shli       s9, s4, #32
    s.mul        s4, s5, s6
    v.insert     v0, s1, #12
    v.insert     v2, s7, #12
    s.or         s1, s8, s9
    s.movz       s5, #2048
    s.lshri      s6, s3, #32
    v.extract    s7, v3, #0
    s.mul        s8, s1, s5
    v.insert     v0, s3, #13
    v.insert     v2, s6, #13
    s.shli       s1, s7, #32
    s.lshri      s3, s4, #32
    v.extract    s5, v3, #1
    s.ashri      s6, s1, #32
    v.insert     v0, s4, #14
    v.insert     v2, s3, #14
    v.movi       v1, #0
    v.movi       v4, #0
    s.shli       s1, s5, #32
    s.lshri      s3, s8, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v3, #2
    s.ashri      s7, s1, #32
    v.insert     v0, s8, #15
    v.insert     v2, s3, #15
    v.insert     v1, s6, #0
    v.insert     v4, s4, #0
    s.shli       s1, s5, #32
    s.lshri      s3, s7, #32
    v.extract    s4, v3, #3
    s.ashri      s5, s1, #32
    v.insert     v1, s7, #1
    v.insert     v4, s3, #1
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v3, #4
    s.ashri      s6, s1, #32
    v.insert     v1, s5, #2
    v.insert     v4, s3, #2
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #5
    s.ashri      s5, s1, #32
    v.insert     v1, s6, #3
    v.insert     v4, s3, #3
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v3, #6
    s.ashri      s6, s1, #32
    v.insert     v1, s5, #4
    v.insert     v4, s3, #4
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #7
    s.ashri      s5, s1, #32
    v.insert     v1, s6, #5
    v.insert     v4, s3, #5
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v3, #8
    s.ashri      s6, s1, #32
    v.insert     v1, s5, #6
    v.insert     v4, s3, #6
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #9
    s.ashri      s5, s1, #32
    v.insert     v1, s6, #7
    v.insert     v4, s3, #7
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v3, #10
    s.ashri      s6, s1, #32
    v.insert     v1, s5, #8
    v.insert     v4, s3, #8
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #11
    s.ashri      s5, s1, #32
    v.insert     v1, s6, #9
    v.insert     v4, s3, #9
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v3, #12
    s.ashri      s6, s1, #32
    v.insert     v1, s5, #10
    v.insert     v4, s3, #10
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #13
    s.ashri      s5, s1, #32
    v.insert     v1, s6, #11
    v.insert     v4, s3, #11
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v3, #14
    s.ashri      s6, s1, #32
    v.insert     v1, s5, #12
    v.insert     v4, s3, #12
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v3, #15
    s.ashri      s5, s1, #32
    v.insert     v1, s6, #13
    v.insert     v4, s3, #13
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #14
    v.insert     v4, s3, #14
    s.lshri      s1, s4, #32
    v.insert     v1, s4, #15
    v.insert     v4, s1, #15
    v.extract    s1, v2, #0
    v.extract    s3, v1, #0
    v.extract    s4, v4, #0
    v.extract    s5, v0, #0
    s.shli       s6, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v4, #1
    v.extract    s7, v2, #1
    s.or         s8, s3, s6
    s.or         s3, s5, s4
    v.movi       v3, #0
    v.extract    s4, v1, #1
    s.shli       s5, s1, #32
    v.extract    s1, v0, #1
    s.shli       s6, s7, #32
    s.add        s7, s8, s3
    v.extract    s3, v4, #2
    v.extract    s8, v2, #2
    s.or         s9, s4, s5
    s.or         s4, s1, s6
    v.movi       v5, #0
    v.insert     v3, s7, #0
    v.extract    s1, v1, #2
    s.shli       s5, s3, #32
    v.extract    s3, v0, #2
    s.shli       s6, s8, #32
    s.lshri      s8, s7, #32
    s.add        s7, s9, s4
    v.extract    s4, v4, #3
    s.or         s9, s1, s5
    v.extract    s1, v2, #3
    s.or         s5, s3, s6
    v.insert     v5, s8, #0
    v.insert     v3, s7, #1
    v.extract    s3, v1, #3
    s.shli       s6, s4, #32
    v.extract    s4, v0, #3
    s.shli       s8, s1, #32
    s.lshri      s1, s7, #32
    s.add        s7, s9, s5
    v.extract    s5, v4, #4
    s.or         s9, s3, s6
    v.extract    s3, v2, #4
    s.or         s6, s4, s8
    v.insert     v5, s1, #1
    v.insert     v3, s7, #2
    v.extract    s1, v1, #4
    s.shli       s4, s5, #32
    v.extract    s5, v0, #4
    s.shli       s8, s3, #32
    s.lshri      s3, s7, #32
    s.add        s7, s9, s6
    v.extract    s6, v4, #5
    s.or         s9, s1, s4
    v.extract    s1, v2, #5
    s.or         s4, s5, s8
    v.insert     v5, s3, #2
    v.insert     v3, s7, #3
    v.extract    s3, v1, #5
    s.shli       s5, s6, #32
    v.extract    s6, v0, #5
    s.shli       s8, s1, #32
    s.lshri      s1, s7, #32
    s.add        s7, s9, s4
    v.extract    s4, v4, #6
    s.or         s9, s3, s5
    v.extract    s3, v2, #6
    s.or         s5, s6, s8
    v.insert     v5, s1, #3
    v.insert     v3, s7, #4
    v.extract    s1, v1, #6
    s.shli       s6, s4, #32
    v.extract    s4, v0, #6
    s.shli       s8, s3, #32
    s.lshri      s3, s7, #32
    s.add        s7, s9, s5
    v.extract    s5, v4, #7
    s.or         s9, s1, s6
    v.extract    s1, v2, #7
    s.or         s6, s4, s8
    v.insert     v5, s3, #4
    v.insert     v3, s7, #5
    v.extract    s3, v1, #7
    s.shli       s4, s5, #32
    v.extract    s5, v0, #7
    s.shli       s8, s1, #32
    s.lshri      s1, s7, #32
    s.add        s7, s9, s6
    v.extract    s6, v4, #8
    s.or         s9, s3, s4
    v.extract    s3, v2, #8
    s.or         s4, s5, s8
    v.insert     v5, s1, #5
    v.insert     v3, s7, #6
    v.extract    s1, v1, #8
    s.shli       s5, s6, #32
    v.extract    s6, v0, #8
    s.shli       s8, s3, #32
    s.lshri      s3, s7, #32
    s.add        s7, s9, s4
    v.extract    s4, v4, #9
    s.or         s9, s1, s5
    v.extract    s1, v2, #9
    s.or         s5, s6, s8
    v.insert     v5, s3, #6
    v.insert     v3, s7, #7
    v.extract    s3, v1, #9
    s.shli       s6, s4, #32
    v.extract    s4, v0, #9
    s.shli       s8, s1, #32
    s.lshri      s1, s7, #32
    s.add        s7, s9, s5
    v.extract    s5, v4, #10
    s.or         s9, s3, s6
    v.extract    s3, v2, #10
    s.or         s6, s4, s8
    v.insert     v5, s1, #7
    v.insert     v3, s7, #8
    v.extract    s1, v1, #10
    s.shli       s4, s5, #32
    v.extract    s5, v0, #10
    s.shli       s8, s3, #32
    s.lshri      s3, s7, #32
    s.add        s7, s9, s6
    v.extract    s6, v4, #11
    s.or         s9, s1, s4
    v.extract    s1, v2, #11
    s.or         s4, s5, s8
    v.insert     v5, s3, #8
    v.insert     v3, s7, #9
    v.extract    s3, v1, #11
    s.shli       s5, s6, #32
    v.extract    s6, v0, #11
    s.shli       s8, s1, #32
    s.lshri      s1, s7, #32
    s.add        s7, s9, s4
    v.extract    s4, v4, #12
    s.or         s9, s3, s5
    v.extract    s3, v2, #12
    s.or         s5, s6, s8
    v.insert     v5, s1, #9
    v.insert     v3, s7, #10
    v.extract    s1, v1, #12
    s.shli       s6, s4, #32
    v.extract    s4, v0, #12
    s.shli       s8, s3, #32
    s.lshri      s3, s7, #32
    s.add        s7, s9, s5
    v.extract    s5, v4, #13
    s.or         s9, s1, s6
    v.extract    s1, v2, #13
    s.or         s6, s4, s8
    v.insert     v5, s3, #10
    v.insert     v3, s7, #11
    v.extract    s3, v1, #13
    s.shli       s4, s5, #32
    v.extract    s5, v0, #13
    s.shli       s8, s1, #32
    s.lshri      s1, s7, #32
    s.add        s7, s9, s6
    v.extract    s6, v4, #14
    s.or         s9, s3, s4
    v.extract    s3, v2, #14
    s.or         s4, s5, s8
    v.insert     v5, s1, #11
    v.insert     v3, s7, #12
    v.extract    s1, v1, #14
    s.shli       s5, s6, #32
    v.extract    s6, v0, #14
    s.shli       s8, s3, #32
    s.lshri      s3, s7, #32
    s.add        s7, s9, s4
    v.extract    s4, v4, #15
    s.or         s9, s1, s5
    v.extract    s1, v2, #15
    s.or         s5, s6, s8
    v.insert     v5, s3, #12
    v.insert     v3, s7, #13
    v.extract    s3, v1, #15
    s.shli       s6, s4, #32
    v.extract    s4, v0, #15
    s.shli       s8, s1, #32
    s.lshri      s1, s7, #32
    s.add        s7, s9, s5
    s.or         s5, s3, s6
    s.or         s3, s4, s8
    v.insert     v5, s1, #13
    v.insert     v3, s7, #14
    s.lshri      s1, s7, #32
    s.add        s4, s5, s3
    v.insert     v5, s1, #14
    v.insert     v3, s4, #15
    v.movi       v0, #31
    s.lshri      s1, s4, #32
    v.movi       v1, #1
    v.insert     v5, s1, #15
    v.ashr       v2, v3, v0
    v.movi       v0, #0
    s.movz       s1, #0
    v.cmp.ne     p1, v5, v2
    @p1 v.sel        v2, v1, v0
    v.reduce.or  s3, v2
    s.cmp.eq     s4, s3, s1
    br.nz        s4, narrow_ok_2
    trap         #677220
narrow_ok_2:
    v.ld.gather.h v0, [s11, v3]                  // index is in elements (ISA sec 9.1)
    s.shli       s1, s2, #1                      // element offset -> bytes (x2)
    s.add        s2, s22, s1                     // &out_ptr0[...]
    v.st.h       [s2, #0], v0
__rctx_next:
    exit
