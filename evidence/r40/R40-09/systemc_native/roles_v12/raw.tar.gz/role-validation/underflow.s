mb.arm s1, b0, #1, #0
mb.arrive b0
mb.arrive b0
exit
