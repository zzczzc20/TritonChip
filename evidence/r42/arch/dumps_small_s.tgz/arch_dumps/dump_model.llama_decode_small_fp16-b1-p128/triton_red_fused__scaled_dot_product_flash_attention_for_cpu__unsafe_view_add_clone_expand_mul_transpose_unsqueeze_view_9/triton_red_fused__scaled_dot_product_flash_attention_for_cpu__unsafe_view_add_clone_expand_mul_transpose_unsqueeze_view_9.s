    s.movz       s1, #129
    s.movz       s2, #0
    s.rdspecial  s3, arg_base
    s.cmp.lt     s4, s1, s2
    s.ld.d       s1, [s3, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.sub        s5, s2, s4
    .li       s4, #4228378656
    s.movz       s6, #32
    s.movz       s7, #16
    s.movz       s8, #1
    s.rdspecial  s9, role_id
    s.rdspecial  s10, npid.x
    s.ld.d       s11, [s3, #8]                   // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s12, [s3, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s13, [s3, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s14, [s3, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s15, [s3, #40]                  // out_ptr0: device_ptr64 at arg_base+40
__rctx_program:
    s.shli       s3, s9, #32
    v.movi       v0, #0
    s.ashri      s16, s3, #32
    v.movi       v1, #1
    s.cmp.lt     s3, s16, s2
    v.movi       v2, #4128
    s.sub        s17, s2, s3
    s.addi       s3, s2, #0
    s.xor        s18, s16, s17
    s.xor        s16, s17, s5
    s.sub        s19, s18, s17
    v.movi       v3, #2
    s.mul        s18, s19, s4
    v.movi       v4, #0
    v.movi       v5, #0
    v.sub        v6, v0, v3
    v.cmp.lt     p1, v3, v0
    s.lshri      s20, s18, #32
    v.iota       v7                              // arange(0, VLEN)
    s.sub        s18, s19, s20
    s.shli       s21, s3, #1                     // element offset -> bytes (x2)
    s.lshri      s22, s18, #1
    s.shli       s18, s3, #1                     // element offset -> bytes (x2)
    s.add        s23, s20, s22
    v.mov        v5, v4
    s.lshri      s20, s23, #7
    @p1 v.sel        v4, v6, v3
    s.xor        s22, s20, s16
    s.muli       s23, s20, #129
    s.sub        s20, s22, s16
    .li       s16, #1054295293
    v.splat      v3, s16                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v4, s20
    s.mul        s16, s20, s6
    s.sub        s20, s19, s23
    v.sub        v6, v0, v4
    v.cmp.lt     p1, v4, v0
    s.xor        s19, s20, s17
    @p1 v.sel        v8, v6, v4
    s.sub        s20, s19, s17
    s.add        s17, s3, s16
    v.lshr       v4, v8, v1
    s.mul        s19, s20, s6
    s.add        s20, s3, s16
    v.sub        v1, v0, v4
    s.shli       s16, s17, #1                    // element offset -> bytes (x2)
    s.shli       s17, s20, #1                    // element offset -> bytes (x2)
    @p1 v.sel        v0, v1, v4
    v.splat      v1, s19
    s.add        s19, s1, s16                    // &in_ptr0[...]
    v.mul        v4, v0, v2
    s.add        s16, s11, s21                   // &in_ptr1[...]
    s.add        s20, s12, s17                   // &in_ptr2[...]
    v.extract    s17, v4, #0
    s.add        s21, s13, s18                   // &in_ptr3[...]
    v.splat      v0, s17
for_1:
    v.splat      v2, s3
    v.ld.h       v4, [s19, #0]
    v.add        v6, v2, v7
    v.add        v2, v6, v1
    v.add        v6, v2, v0
    v.ld.h       v2, [s16, #0]
    vf.cvt.f16.f32 v8, v4
    v.ld.h       v4, [s20, #0]
    vf.cvt.f16.f32 v9, v2
    vf.mul       v2, v8, v9
    v.ld.h       v8, [s21, #0]
    vf.cvt.f16.f32 v9, v4
    v.ld.gather.h v4, [s14, v6]                  // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v6, v8
    vf.mul       v8, v9, v6
    vf.add       v6, v2, v8
    vf.cvt.f16.f32 v2, v4
    vf.mul       v4, v6, v3
    vf.mul       v6, v2, v3
    vf.mul       v2, v4, v6
    vf.add       v5, v5, v2
    s.addi       s19, s19, #32                   // the next iteration's address
    s.addi       s16, s16, #32                   // the next iteration's address
    s.addi       s20, s20, #32                   // the next iteration's address
    s.addi       s21, s21, #32                   // the next iteration's address
    s.add        s3, s3, s7
    s.cmp.lt     s17, s3, s6
    br.nz        s17, for_1
endfor_2:
    vf.reduce.add.b v0, v5
    v.movi       v1, #0
    s.shli       s3, s9, #2                      // element offset -> bytes (x4)
    v.iota       v2                              // arange(0, VLEN)
    vf.add       v3, v0, v1
    v.splat      v0, s8
    s.add        s16, s15, s3                    // &out_ptr0[...]
    v.cmp.lt     p1, v2, v0
    @p1 v.st.w       [s16, #0], v3
__rctx_next:
    s.addi       s3, s9, #4                      // the next program of this context: + 4
    s.cmp.lt     s16, s3, s10
    s.mov        s9, s3
    br.nz        s16, __rctx_program
    exit
