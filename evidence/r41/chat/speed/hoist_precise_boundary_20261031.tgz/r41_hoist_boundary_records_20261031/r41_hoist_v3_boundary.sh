#!/usr/bin/env bash
set -eu
route=$1
export OMP_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES= HF_HUB_OFFLINE=1 HF_HOME="$HOME/r41-fp8-kern-hf" TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip" TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg"
cd "$HOME/r41_chat_precise_hoist_v3_20261031"
for shape in 1-7-256 1-250-384 16-250-384; do IFS=- read -r m n k <<< "$shape"; export TNCA_TLM_OUT="$HOME/r41_hoist_v3_boundary_${route}_${shape}_tlm"; "$HOME/flux-venv/bin/python" -u tools/r41/chat_speed/bench_precise_hoist_diagnostic.py --route "$route" --default-div --m "$m" --n "$n" --k "$k" --v1 "$HOME/r41-fp8-kern-hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/48f42b23bb4e0122d4775c6d16753dd2efc7f580" --out "$HOME/r41_hoist_v3_boundary_${route}_${shape}"; done
