    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.movi       v0, #0
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #1024
    s.movz       s6, #16
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s7, s2, #0
    s.ld.d       s2, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    s.movz       s1, #2048
    v.splat      v0, s7
    s.mul        s8, s4, s1
    v.movi       v3, #2
    v.add        v4, v0, v2
    v.movi       v0, #1024
    v.movi       v5, #0
    v.mul        v6, v4, v3
    v.splat      v3, s8
    v.cmp.lt     p1, v4, v0
    s.add        s1, s7, s6
    v.add        v0, v6, v3
    s.movz       s8, #1
    s.movz       s9, #2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v3, [s3, v0]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v0, v3
    vf.add       v3, v1, v0
    @p1 v.sel        v0, v3, v1
    v.mov        v5, v0
    v.mov        v1, v5
    s.mov        s7, s1
    br.nz        s8, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s3, s4, #1                      // element offset -> bytes (x2)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s2, s3                      // &out_ptr0[...]
    vf.cvt.f32.f16 v3, v2
    v.cmp.lt     p1, v0, v1
    @p1 v.st.h       [s1, #0], v3
__rctx_next:
    exit
