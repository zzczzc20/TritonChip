import json,torch
from pathlib import Path
from safetensors.torch import load_file
h=Path.home();a=load_file(str(h/'r41_q35_whole_untimed_precise_20261101_diag/logits.safetensors'))['whole'];b=load_file(str(h/'r41_q35_full_precise_b32_20261101_diag/logits.safetensors'))['whole']
out=dict(scope='full-checkpoint b32 precision-cast untimed timeline-memory vs timed DP TLM',elements=a.numel(),bit_mismatches=int((a.view(torch.int16)!=b.view(torch.int16)).sum()))
(h/'r41_q35_untimed_precise_compare_20261101.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
