import json
from pathlib import Path
import torch
from safetensors.torch import load_file
h=Path.home();base=h/'r41_q35_multiturn_cpu_diag';basej=json.loads((base/'result.json').read_text());baseline=load_file(str(base/'logits.safetensors'));tlm=load_file(str(h/'r41_q35_multiturn_tlm_whole_20261031_diag/logits.safetensors'))['whole'];out={}
for variant in ('recip','fma','recip_fma'):
 d=h/f'r41_q35_cpu_{variant}_20261031_diag';j=json.loads((d/'result.json').read_text());v=load_file(str(d/'logits.safetensors'))
 for k in ('input_ids','model','revision'):
  if j[k]!=basej[k]:raise ValueError(k+' mismatch')
 paths={}
 for path in ('whole','grouped_chunk8'):
  x=baseline[path].float();y=v[path].float();z=tlm.float()
  paths[path]={'argmax_id':int(y.argmax()),'reference_argmax_id':int(x.argmax()),'top5':j['paths'][path]['logits'],'rel_l2_vs_reference':float((x-y).norm()/x.norm().clamp_min(1e-30)),'max_abs_vs_reference':float((x-y).abs().max()),'rel_l2_vs_tlm_whole':float((z-y).norm()/z.norm().clamp_min(1e-30)),'max_abs_vs_tlm_whole':float((z-y).abs().max())}
 out[variant]={'scale':j['reference_scale_div'],'fma':j['reference_fma'],'paths':paths}
p=h/'r41_q35_cpu_scale_fma_compare_20261031.json';p.write_text(json.dumps({'scope':'CPU approximations vs CPU reference and whole-prefill TLM; not board logits', 'results':out},indent=2)+'\n');print(json.dumps(out,indent=2))
