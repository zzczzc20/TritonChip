from pathlib import Path
import itertools,subprocess,json
r=Path.cwd();out=r/'results';out.mkdir(exist_ok=False);records=[]
def step(name,args,expected=0):
 p=subprocess.run(args,capture_output=True,text=True,timeout=900);s=p.stdout+p.stderr;(out/(name+'.log')).write_text(s);assert p.returncode==expected,(name,p.returncode,s[-3500:]);return s
def args_for(name,epoch,policy,source='rtl/nuca/tnca_nuca_slice.v'):
 binary=str(out/(name+'.vvp'));return binary,['iverilog','-g2012','-I','rtl/common','-s','tb_nuca_slice','-Ptb_nuca_slice.SETS=32','-Ptb_nuca_slice.SET_W=5','-Ptb_nuca_slice.WAYS=8','-Ptb_nuca_slice.WAY_W=3','-Ptb_nuca_slice.REGISTER_VICTIM_OWNER=1','-Ptb_nuca_slice.DCO_REGISTERED_RANGES=1','-Ptb_nuca_slice.AMO_TRAFFIC=1',f'-Ptb_nuca_slice.EPOCH_CHURN={epoch}',f'-Ptb_nuca_slice.POLICY={policy}','-o',binary,source,'rtl/nuca/tnca_nuca_slice_before.v','tb/common/tnca_dram_model.v','tb/nuca/tb_hit_owner.v']
def record(name,text):
 records.append(dict(name=name,stdout=text));(out/'report.json').write_text(json.dumps(records,indent=2)+'\n');print(name,flush=True)
for epoch,policy,seed in itertools.product([0,5],[46,78],[1,7]):
 name=f'epoch{epoch}_policy{policy}_seed{seed}';binary,args=args_for(name,epoch,policy);step(name+'_build',args);s=step(name,['vvp',binary,'+nreq=6000',f'+seed={seed}','+min_wb=1']);assert 'PASS' in s.splitlines() and 'FAIL' not in s and 'FATAL' not in s,s;record(name+'_pass',s)
source=(r/'rtl/nuca/tnca_nuca_slice.v').read_text();needle='owner_epoch_q == dco_owner_epoch))';assert source.count(needle)==1
mutant=out/'no_hit_epoch_guard.v';mutant.write_text(source.replace(needle,"1'b1))",1));binary,args=args_for('mutation',5,78,str(mutant));step('mutation_build',args);s=step('mutation',['vvp',binary,'+nreq=6000','+seed=7','+min_wb=1'],1);assert 'stale HIT owner snapshot emitted a TLW hint' in s,s;record('hit_epoch_guard_mutation_detected',s)
print('HIT_OWNER_CANDIDATE_FUNCTIONAL_DONE',flush=True)
