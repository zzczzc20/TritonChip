    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #81
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.sub        v3, v2, v0
    v.sub        v4, v2, v1
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    s.ld.d       s2, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #1
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    @p1 v.sel        v7, v3, v0
    @p2 v.sel        v0, v4, v1
    v.movi       v1, #0
    v.movi       v3, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v4, s1
    v.shl        v8, v3, v6
    v.lshr       v9, v7, v4
    v.cmp.lt     p2, v3, v2
    v.and        v10, v9, v6
    v.shl        v9, v6, v4
    v.or         v4, v8, v10
    s.subi       s5, s1, #1
    v.cmp.geu    p3, v4, v0
    p.or         p4, p2, p3
    v.sub        v8, v4, v0
    @p4 v.sel        v10, v9, v2
    @p4 v.sel        v9, v8, v4
    v.or         v4, v1, v10
    v.mov        v3, v9
    v.mov        v1, v4
    s.mov        s1, s5
    s.movz       s5, #0
    s.cmp.ge     s6, s1, s5
    br.nz        s6, idiv_1
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v4, v2, v3
    s.movz       s1, #0
    .li       s5, #4286578688
    v.splat      v2, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v6, #0
    v.cmp.ne     p2, v0, v1
    @p1 v.sel        v0, v4, v3
    s.movz       s5, #81
    s.movz       s6, #16
    s.addi       s7, s1, #0
    p.mov        p1, p2
    v.mov        v6, v2
for_2:
    s.cmp.ge     s8, s7, s5
    br.nz        s8, endfor_3
    v.movi       v1, #-1
    v.splat      v3, s7
    v.mul        v4, v0, v1
    v.add        v1, v3, v5
    v.extract    s8, v4, #0
    s.mul        s9, s4, s5
    v.splat      v3, s8
    v.movi       v4, #81
    v.add        v7, v1, v3
    v.movi       v3, #0
    v.extract    s8, v7, #0
    s.add        s10, s7, s9
    s.shli       s11, s8, #32
    v.extract    s8, v7, #1
    s.shli       s12, s10, #2                    // element offset -> bytes (x4)
    s.ashri      s10, s11, #32
    s.shli       s11, s8, #32
    v.extract    s8, v7, #2
    s.add        s13, s3, s12                    // &in_ptr0[...]
    v.movi       v8, #0
    s.lshri      s12, s10, #32
    s.ashri      s14, s11, #32
    s.shli       s11, s8, #32
    v.cmp.lt     p2, v1, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v4, [s13, #0]
    v.extract    s8, v7, #3
    v.insert     v3, s10, #0
    v.insert     v8, s12, #0
    s.lshri      s10, s14, #32
    s.ashri      s12, s11, #32
    s.shli       s11, s8, #32
    v.extract    s8, v7, #4
    v.insert     v3, s14, #1
    v.insert     v8, s10, #1
    s.lshri      s10, s12, #32
    s.ashri      s13, s11, #32
    s.shli       s11, s8, #32
    v.extract    s8, v7, #5
    v.insert     v3, s12, #2
    v.insert     v8, s10, #2
    s.lshri      s10, s13, #32
    s.ashri      s12, s11, #32
    s.shli       s11, s8, #32
    v.insert     v3, s13, #3
    v.insert     v8, s10, #3
    s.lshri      s8, s12, #32
    s.ashri      s10, s11, #32
    v.insert     v3, s12, #4
    v.insert     v8, s8, #4
    v.insert     v3, s10, #5
    v.splat      v9, s9
    s.lshri      s8, s10, #32
    v.add        v10, v1, v9
    v.extract    s9, v7, #6
    s.shli       s10, s9, #32
    v.insert     v8, s8, #5
    s.ashri      s8, s10, #32
    .li       s9, #-1
    v.extract    s9, v7, #7
    s.shli       s10, s9, #32
    v.extract    s9, v7, #8
    s.lshri      s11, s8, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v7, #9
    v.insert     v3, s8, #6
    v.insert     v8, s11, #6
    s.lshri      s8, s12, #32
    s.ashri      s11, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v7, #10
    v.insert     v3, s12, #7
    v.insert     v8, s8, #7
    s.lshri      s8, s11, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v7, #11
    v.insert     v3, s11, #8
    v.insert     v8, s8, #8
    s.lshri      s8, s12, #32
    s.ashri      s11, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v7, #12
    v.insert     v3, s12, #9
    v.insert     v8, s8, #9
    s.lshri      s8, s11, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v7, #13
    v.insert     v3, s11, #10
    v.insert     v8, s8, #10
    s.lshri      s8, s12, #32
    s.ashri      s11, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v7, #14
    v.insert     v3, s12, #11
    v.insert     v8, s8, #11
    s.lshri      s8, s11, #32
    s.ashri      s12, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v7, #15
    v.insert     v3, s11, #12
    v.insert     v8, s8, #12
    s.lshri      s8, s12, #32
    s.ashri      s11, s10, #32
    s.shli       s10, s9, #32
    v.insert     v3, s12, #13
    v.insert     v8, s8, #13
    s.lshri      s8, s11, #32
    s.ashri      s9, s10, #32
    v.insert     v3, s11, #14
    v.insert     v8, s8, #14
    s.lshri      s8, s9, #32
    v.insert     v3, s9, #15
    v.insert     v8, s8, #15
    v.extract    s8, v3, #0
    v.extract    s9, v8, #0
    s.shli       s10, s9, #32
    v.extract    s9, v8, #1
    s.or         s11, s8, s10
    s.movz       s8, #0
    s.shli       s10, s9, #32
    v.extract    s9, v3, #1
    v.extract    s12, v8, #2
    v.movi       v1, #0
    s.cmp.le     s13, s11, s8
    s.or         s8, s9, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v3, #2
    v.extract    s12, v8, #3
    v.insert     v1, s13, #0
    s.cmp.le     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v3, #3
    v.extract    s12, v8, #4
    v.insert     v1, s13, #1
    s.cmp.le     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v3, #4
    v.extract    s12, v8, #5
    v.insert     v1, s13, #2
    s.cmp.le     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v3, #5
    v.extract    s12, v8, #6
    v.insert     v1, s13, #3
    s.cmp.le     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v3, #6
    v.extract    s12, v8, #7
    v.insert     v1, s13, #4
    s.cmp.le     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v3, #7
    v.extract    s12, v8, #8
    v.insert     v1, s13, #5
    s.cmp.le     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v3, #8
    v.extract    s12, v8, #9
    v.insert     v1, s13, #6
    s.cmp.le     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v3, #9
    v.extract    s12, v8, #10
    v.insert     v1, s13, #7
    s.cmp.le     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v3, #10
    v.extract    s12, v8, #11
    v.insert     v1, s13, #8
    s.cmp.le     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v3, #11
    v.extract    s12, v8, #12
    v.insert     v1, s13, #9
    s.cmp.le     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v3, #12
    v.extract    s12, v8, #13
    v.insert     v1, s13, #10
    s.cmp.le     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v3, #13
    v.extract    s12, v8, #14
    v.insert     v1, s13, #11
    s.cmp.le     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v3, #14
    v.extract    s12, v8, #15
    v.insert     v1, s13, #12
    s.cmp.le     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v3, #15
    v.insert     v1, s13, #13
    s.cmp.le     s12, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    v.insert     v1, s12, #14
    s.cmp.le     s10, s8, s9
    v.movi       v3, #0
    v.insert     v1, s10, #15
    v.movi       v7, #0
    v.cmp.ne     p3, v1, v3
    @p3 v.sel        v1, v7, v2
    v.movi       v3, #1
    vf.add       v7, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    v.movi       v8, #1
    vf.cmp.eq    p3, v7, v2
    @p3 v.sel        v9, v3, v1
    v.movi       v1, #0
    v.cmp.eq     p3, v9, v4
    @p3 v.sel        v3, v8, v1
    v.movi       v1, #1
    v.movi       v4, #0
    v.extract    s8, v3, #0
    @p3 v.sel        v3, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.movi       v8, #0
    v.movi       v9, #0
    s.lshri      s9, s8, #32
    v.extract    s10, v3, #1
    @p3 v.sel        v3, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v8, s8, #0
    v.insert     v9, s9, #0
    s.lshri      s8, s10, #32
    v.extract    s9, v3, #2
    @p3 v.sel        v3, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v8, s10, #1
    v.insert     v9, s8, #1
    s.lshri      s8, s9, #32
    v.extract    s10, v3, #3
    @p3 v.sel        v3, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v8, s9, #2
    v.insert     v9, s8, #2
    s.lshri      s8, s10, #32
    v.extract    s9, v3, #4
    @p3 v.sel        v3, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v8, s10, #3
    v.insert     v9, s8, #3
    s.lshri      s8, s9, #32
    v.extract    s10, v3, #5
    @p3 v.sel        v3, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v8, s9, #4
    v.insert     v9, s8, #4
    s.lshri      s8, s10, #32
    v.extract    s9, v3, #6
    @p3 v.sel        v3, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v8, s10, #5
    v.insert     v9, s8, #5
    s.lshri      s8, s9, #32
    v.extract    s10, v3, #7
    @p3 v.sel        v3, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v8, s9, #6
    v.insert     v9, s8, #6
    s.lshri      s8, s10, #32
    v.extract    s9, v3, #8
    @p3 v.sel        v3, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v8, s10, #7
    v.insert     v9, s8, #7
    s.lshri      s8, s9, #32
    v.extract    s10, v3, #9
    @p3 v.sel        v3, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v8, s9, #8
    v.insert     v9, s8, #8
    s.lshri      s8, s10, #32
    v.extract    s9, v3, #10
    @p3 v.sel        v3, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v8, s10, #9
    v.insert     v9, s8, #9
    s.lshri      s8, s9, #32
    v.extract    s10, v3, #11
    @p3 v.sel        v3, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v8, s9, #10
    v.insert     v9, s8, #10
    s.lshri      s8, s10, #32
    v.extract    s9, v3, #12
    @p3 v.sel        v3, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v8, s10, #11
    v.insert     v9, s8, #11
    s.lshri      s8, s9, #32
    v.extract    s10, v3, #13
    @p3 v.sel        v3, v1, v4
    v.movi       v1, #1
    v.movi       v4, #0
    v.insert     v8, s9, #12
    v.insert     v9, s8, #12
    s.lshri      s8, s10, #32
    v.extract    s9, v3, #14
    @p3 v.sel        v3, v1, v4
    v.insert     v8, s10, #13
    v.insert     v9, s8, #13
    s.lshri      s8, s9, #32
    v.extract    s10, v3, #15
    v.insert     v8, s9, #14
    v.insert     v9, s8, #14
    s.lshri      s8, s10, #32
    v.insert     v8, s10, #15
    v.insert     v9, s8, #15
    v.extract    s8, v8, #0
    v.extract    s9, v9, #0
    s.shli       s10, s9, #32
    v.extract    s9, v9, #1
    s.or         s11, s8, s10
    s.movz       s8, #0
    s.shli       s10, s9, #32
    v.extract    s9, v8, #1
    v.extract    s12, v9, #2
    v.movi       v1, #0
    s.cmp.ne     s13, s11, s8
    s.or         s8, s9, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v8, #2
    v.extract    s12, v9, #3
    v.insert     v1, s13, #0
    s.cmp.ne     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v8, #3
    v.extract    s12, v9, #4
    v.insert     v1, s13, #1
    s.cmp.ne     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v8, #4
    v.extract    s12, v9, #5
    v.insert     v1, s13, #2
    s.cmp.ne     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v8, #5
    v.extract    s12, v9, #6
    v.insert     v1, s13, #3
    s.cmp.ne     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v8, #6
    v.extract    s12, v9, #7
    v.insert     v1, s13, #4
    s.cmp.ne     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v8, #7
    v.extract    s12, v9, #8
    v.insert     v1, s13, #5
    s.cmp.ne     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v8, #8
    v.extract    s12, v9, #9
    v.insert     v1, s13, #6
    s.cmp.ne     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v8, #9
    v.extract    s12, v9, #10
    v.insert     v1, s13, #7
    s.cmp.ne     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v8, #10
    v.extract    s12, v9, #11
    v.insert     v1, s13, #8
    s.cmp.ne     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v8, #11
    v.extract    s12, v9, #12
    v.insert     v1, s13, #9
    s.cmp.ne     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v8, #12
    v.extract    s12, v9, #13
    v.insert     v1, s13, #10
    s.cmp.ne     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v8, #13
    v.extract    s12, v9, #14
    v.insert     v1, s13, #11
    s.cmp.ne     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v8, #14
    v.extract    s12, v9, #15
    v.insert     v1, s13, #12
    s.cmp.ne     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s12, #32
    v.extract    s11, v8, #15
    v.insert     v1, s13, #13
    s.cmp.ne     s12, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    v.insert     v1, s12, #14
    s.cmp.ne     s10, s8, s9
    v.movi       v3, #0
    v.insert     v1, s10, #15
    p.not        p3, p2
    v.cmp.ne     p4, v1, v3
    p.or         p5, p1, p4
    vf.max.prop  v1, v6, v7
    p.and        p4, p2, p5
    p.and        p5, p3, p1
    v.movi       v3, #0
    p.or         p3, p4, p5
    @p2 v.sel        v4, v1, v6
    p.mov        p2, p3
    v.mov        v3, v4
    s.add        s8, s7, s6
    s.movz       s9, #1
    p.mov        p1, p2
    v.mov        v6, v3
    s.mov        s7, s8
    br.nz        s9, for_2
endfor_3:
    v.movi       v1, #1
    v.movi       v3, #0
    vf.cmp.uo    p2, v6, v6
    @p2 v.sel        v4, v1, v3
    v.movi       v1, #1
    v.movi       v3, #0
    v.reduce.or.b v7, v4
    v.movi       v4, #0
    vf.reduce.max.b v8, v6
    .li       s7, #2143289344
    v.splat      v6, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v9, v1, v3
    v.cmp.ne     p1, v7, v4
    @p1 v.sel        v1, v6, v8
    v.movi       v3, #0
    v.movi       v4, #0
    v.movi       v6, #0
    v.reduce.or  s7, v9
    v.splat      v7, s7
    vf.add       v8, v1, v3
    s.addi       s7, s1, #0
    v.mov        v6, v4
for_4:
    s.cmp.ge     s8, s7, s5
    br.nz        s8, endfor_5
    v.movi       v1, #-1
    v.splat      v9, s7
    v.mul        v10, v0, v1
    v.add        v1, v9, v5
    v.extract    s8, v10, #0
    s.mul        s9, s4, s5
    v.splat      v9, s8
    v.movi       v10, #81
    v.add        v11, v1, v9
    v.movi       v9, #0
    v.extract    s8, v11, #0
    s.add        s10, s7, s9
    s.shli       s11, s8, #32
    v.extract    s8, v11, #1
    s.shli       s12, s10, #2                    // element offset -> bytes (x4)
    s.ashri      s10, s11, #32
    s.shli       s11, s8, #32
    v.extract    s8, v11, #2
    s.add        s13, s3, s12                    // &in_ptr0[...]
    v.movi       v12, #0
    s.lshri      s14, s10, #32
    s.ashri      s15, s11, #32
    s.shli       s11, s8, #32
    v.cmp.lt     p1, v1, v10
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s13, #0]
    v.extract    s8, v11, #3
    v.insert     v9, s10, #0
    v.insert     v12, s14, #0
    s.lshri      s10, s15, #32
    s.ashri      s13, s11, #32
    s.shli       s11, s8, #32
    v.extract    s8, v11, #4
    v.insert     v9, s15, #1
    v.insert     v12, s10, #1
    s.lshri      s10, s13, #32
    s.ashri      s14, s11, #32
    s.shli       s11, s8, #32
    v.extract    s8, v11, #5
    v.insert     v9, s13, #2
    v.insert     v12, s10, #2
    s.lshri      s10, s14, #32
    s.ashri      s13, s11, #32
    s.shli       s11, s8, #32
    v.insert     v9, s14, #3
    v.insert     v12, s10, #3
    s.lshri      s8, s13, #32
    s.ashri      s10, s11, #32
    v.insert     v9, s13, #4
    v.insert     v12, s8, #4
    v.insert     v9, s10, #5
    v.splat      v13, s9
    s.lshri      s8, s10, #32
    v.add        v14, v1, v13
    v.extract    s9, v11, #6
    s.shli       s10, s9, #32
    v.insert     v12, s8, #5
    s.ashri      s8, s10, #32
    .li       s9, #-1
    v.extract    s9, v11, #7
    s.shli       s10, s9, #32
    v.extract    s9, v11, #8
    s.lshri      s11, s8, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v11, #9
    v.insert     v9, s8, #6
    v.insert     v12, s11, #6
    s.lshri      s8, s13, #32
    s.ashri      s11, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v11, #10
    v.insert     v9, s13, #7
    v.insert     v12, s8, #7
    s.lshri      s8, s11, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v11, #11
    v.insert     v9, s11, #8
    v.insert     v12, s8, #8
    s.lshri      s8, s13, #32
    s.ashri      s11, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v11, #12
    v.insert     v9, s13, #9
    v.insert     v12, s8, #9
    s.lshri      s8, s11, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v11, #13
    v.insert     v9, s11, #10
    v.insert     v12, s8, #10
    s.lshri      s8, s13, #32
    s.ashri      s11, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v11, #14
    v.insert     v9, s13, #11
    v.insert     v12, s8, #11
    s.lshri      s8, s11, #32
    s.ashri      s13, s10, #32
    s.shli       s10, s9, #32
    v.extract    s9, v11, #15
    v.insert     v9, s11, #12
    v.insert     v12, s8, #12
    s.lshri      s8, s13, #32
    s.ashri      s11, s10, #32
    s.shli       s10, s9, #32
    v.insert     v9, s13, #13
    v.insert     v12, s8, #13
    s.lshri      s8, s11, #32
    s.ashri      s9, s10, #32
    v.insert     v9, s11, #14
    v.insert     v12, s8, #14
    s.lshri      s8, s9, #32
    v.insert     v9, s9, #15
    v.insert     v12, s8, #15
    v.extract    s8, v9, #0
    v.extract    s9, v12, #0
    s.shli       s10, s9, #32
    v.extract    s9, v12, #1
    s.or         s11, s8, s10
    s.movz       s8, #0
    s.shli       s10, s9, #32
    v.extract    s9, v9, #1
    v.extract    s13, v12, #2
    v.movi       v1, #0
    s.cmp.le     s14, s11, s8
    s.or         s8, s9, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s11, v9, #2
    v.extract    s13, v12, #3
    v.insert     v1, s14, #0
    s.cmp.le     s14, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s11, v9, #3
    v.extract    s13, v12, #4
    v.insert     v1, s14, #1
    s.cmp.le     s14, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s11, v9, #4
    v.extract    s13, v12, #5
    v.insert     v1, s14, #2
    s.cmp.le     s14, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s11, v9, #5
    v.extract    s13, v12, #6
    v.insert     v1, s14, #3
    s.cmp.le     s14, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s11, v9, #6
    v.extract    s13, v12, #7
    v.insert     v1, s14, #4
    s.cmp.le     s14, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s11, v9, #7
    v.extract    s13, v12, #8
    v.insert     v1, s14, #5
    s.cmp.le     s14, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s11, v9, #8
    v.extract    s13, v12, #9
    v.insert     v1, s14, #6
    s.cmp.le     s14, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s11, v9, #9
    v.extract    s13, v12, #10
    v.insert     v1, s14, #7
    s.cmp.le     s14, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s11, v9, #10
    v.extract    s13, v12, #11
    v.insert     v1, s14, #8
    s.cmp.le     s14, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s11, v9, #11
    v.extract    s13, v12, #12
    v.insert     v1, s14, #9
    s.cmp.le     s14, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s11, v9, #12
    v.extract    s13, v12, #13
    v.insert     v1, s14, #10
    s.cmp.le     s14, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s11, v9, #13
    v.extract    s13, v12, #14
    v.insert     v1, s14, #11
    s.cmp.le     s14, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s11, v9, #14
    v.extract    s13, v12, #15
    v.insert     v1, s14, #12
    s.cmp.le     s14, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    s.shli       s10, s13, #32
    v.extract    s11, v9, #15
    v.insert     v1, s14, #13
    s.cmp.le     s13, s8, s9
    s.or         s8, s11, s10
    s.movz       s9, #0
    v.insert     v1, s13, #14
    s.cmp.le     s10, s8, s9
    v.movi       v9, #0
    v.insert     v1, s10, #15
    v.extract    s8, v8, #0
    v.cmp.ne     p2, v1, v9
    @p2 v.sel        v1, v4, v2
    v.splat      v9, s8
    vf.add       v11, v10, v1
    .li       s8, #1069066811
    v.splat      v1, s8                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s8, #1060205080
    v.splat      v10, s8                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s8, s2, s12                     // &in_out_ptr0[...]
    vf.sub       v12, v11, v9
    v.movi       v9, #0
    s.add        s9, s7, s6
    s.movz       s10, #1
    vf.mul       v11, v12, v1
    v.exp2.approx v13, v11                       // ISA 8.8: <= 2**-22 relative
    vf.fms       v14, v12, v1, v11               // the exact rounding error of x*log2(e)
    vf.mul       v1, v14, v10
    vf.fma       v10, v13, v1, v13               // 2**t * 2**d
    vf.cmp.o     p2, v10, v10
    @p2 v.sel        v1, v10, v13
    vf.add       v10, v6, v1
    @p1 v.st.w       [s8, #0], v1
    @p1 v.sel        v1, v10, v6
    v.mov        v9, v1
    v.mov        v6, v9
    s.mov        s7, s9
    br.nz        s10, for_4
endfor_5:
    vf.reduce.add.b v0, v6
    s.addi       s3, s1, #0
    vf.add       v1, v0, v3
for_6:
    s.cmp.ge     s1, s3, s5
    br.nz        s1, endfor_7
    v.extract    s1, v1, #0
    v.splat      v0, s1
    s.mul        s1, s4, s5
    v.rcp.approx v2, v0                          // ISA 8.8: <= 2**-22 relative
    .li       s7, #1065353216
    v.splat      v3, s7                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v6, s3
    v.movi       v8, #81
    s.add        s7, s3, s1
    v.add        v9, v6, v5
    s.shli       s8, s7, #2                      // element offset -> bytes (x4)
    v.cmp.lt     p1, v9, v8
    s.add        s7, s2, s8                      // &in_out_ptr0[...]
    fence.acq_rel.device
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s7, #0]
    v.movi       v8, #0
    v.movi       v10, #1
    v.cmp.eq     p2, v7, v8
    v.movi       v8, #0
    v.movi       v11, #0
    @p2 v.sel        v12, v10, v8
    v.splat      v8, s1
    v.extract    s1, v12, #0
    v.splat      v10, s1
    s.add        s1, s2, s8                      // &in_out_ptr0[...]
    v.cmp.ne     p2, v10, v11
    s.add        s7, s3, s6
    s.movz       s8, #1
    v.add        v10, v9, v8
    vf.fms       v8, v0, v2, v3
    vf.fms       v3, v2, v8, v2
    vf.neg       v8, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p3, v8, v8
    @p3 v.sel        v3, v8, v2
    vf.mul       v2, v6, v3                      // a/y: faithful quotient
    vf.fms       v8, v2, v0, v6
    vf.fms       v0, v8, v3, v2
    vf.neg       v3, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p3, v3, v3
    @p3 v.sel        v0, v3, v2
    @p2 v.sel        v2, v4, v0
    @p1 v.st.w       [s1, #0], v2
    s.mov        s3, s7
    br.nz        s8, for_6
endfor_7:
__rctx_next:
    exit
