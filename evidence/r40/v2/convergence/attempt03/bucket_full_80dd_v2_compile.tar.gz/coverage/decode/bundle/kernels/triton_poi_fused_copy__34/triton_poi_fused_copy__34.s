    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, role_id
    s.rdspecial  s5, npid.x
    s.ld.d       s6, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s7, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s8, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s9, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s10, [s1, #40]                  // out_ptr1: device_ptr64 at arg_base+40
__rctx_program:
    s.mul        s1, s4, s2
    v.iota       v0                              // arange(0, VLEN)
    .li       s11, #147456
    v.splat      v1, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v2, #0
    v.movi       v3, #1
    v.splat      v4, s1
    v.sub        v5, v2, v1
    v.cmp.lt     p1, v1, v2
    v.add        v6, v4, v0
    @p1 v.sel        v0, v5, v1
    v.movi       v4, #0
    v.sub        v5, v2, v6
    v.cmp.lt     p2, v6, v2
    v.movi       v7, #0
    @p2 v.sel        v8, v5, v6
    s.movz       s11, #31
idiv_1:
    v.splat      v5, s11
    v.shl        v9, v7, v3
    v.cmp.lt     p3, v7, v2
    v.lshr       v10, v8, v5
    v.shl        v11, v3, v5
    s.subi       s12, s11, #1
    v.and        v5, v10, v3
    s.movz       s13, #0
    v.or         v10, v9, v5
    v.cmp.geu    p4, v10, v0
    p.or         p5, p3, p4
    v.sub        v5, v10, v0
    @p5 v.sel        v9, v11, v2
    @p5 v.sel        v11, v5, v10
    v.or         v5, v4, v9
    v.mov        v7, v11
    v.mov        v4, v5
    s.mov        s11, s12
    s.cmp.ge     s12, s11, s13
    br.nz        s12, idiv_1
    v.movi       v0, #0
    v.sub        v3, v2, v4
    p.xor        p3, p2, p1
    v.sub        v2, v0, v6
    v.sub        v5, v0, v1
    v.cmp.lt     p1, v6, v0
    v.cmp.lt     p2, v1, v0
    @p3 v.sel        v7, v3, v4
    v.movi       v3, #1
    @p1 v.sel        v4, v2, v6
    @p2 v.sel        v2, v5, v1
    v.movi       v1, #0
    v.movi       v5, #0
    s.movz       s11, #31
idiv_2:
    v.splat      v6, s11
    v.shl        v8, v5, v3
    v.cmp.lt     p2, v5, v0
    v.lshr       v9, v4, v6
    v.shl        v10, v3, v6
    s.subi       s12, s11, #1
    v.and        v6, v9, v3
    s.movz       s13, #0
    v.or         v9, v8, v6
    v.cmp.geu    p3, v9, v2
    p.or         p4, p2, p3
    v.sub        v6, v9, v2
    @p4 v.sel        v8, v10, v0
    @p4 v.sel        v10, v6, v9
    v.or         v6, v1, v8
    v.mov        v5, v10
    v.mov        v1, v6
    s.mov        s11, s12
    s.cmp.ge     s12, s11, s13
    br.nz        s12, idiv_2
    v.sub        v1, v0, v5
    s.shli       s11, s1, #1                     // element offset -> bytes (x2)
    v.movi       v0, #0
    @p1 v.sel        v2, v1, v5
    s.add        s1, s9, s11                     // &in_ptr4[...]
    v.movi       v1, #1
    v.ld.gather.h v3, [s8, v2]                   // index is in elements (ISA sec 9.1)
    v.cmp.eq     p1, v7, v0
    v.movi       v0, #2
    v.cmp.eq     p2, v7, v1
    v.movi       v1, #3
    v.cmp.eq     p3, v7, v0
    s.add        s12, s10, s11                   // &out_ptr1[...]
    v.cmp.eq     p4, v7, v1
    v.ld.h       v0, [s1, #0]
    vf.cvt.f16.f32 v1, v3
    v.ld.gather.h v3, [s7, v2]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v4, v0
    @p1 v.sel        v0, v1, v4
    v.ld.gather.h v1, [s6, v2]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v4, v3
    @p2 v.sel        v3, v4, v0
    v.ld.gather.h v0, [s3, v2]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v2, v1
    @p3 v.sel        v1, v2, v3
    vf.cvt.f16.f32 v2, v0
    @p4 v.sel        v0, v2, v1
    vf.cvt.f32.f16 v1, v0
    v.st.h       [s12, #0], v1
__rctx_next:
    s.addi       s1, s4, #4                      // the next program of this context: + 4
    s.cmp.lt     s11, s1, s5
    s.mov        s4, s1
    br.nz        s11, __rctx_program
    exit
