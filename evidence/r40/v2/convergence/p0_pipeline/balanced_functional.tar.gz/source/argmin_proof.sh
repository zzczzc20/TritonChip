source ~/tc_env/env.sh
cd /tmp/r40_balanced_source
python3 argmin_proof.py > /tmp/r40_argmin_proof.log 2>&1
echo $? > /tmp/r40_argmin_proof.exit
