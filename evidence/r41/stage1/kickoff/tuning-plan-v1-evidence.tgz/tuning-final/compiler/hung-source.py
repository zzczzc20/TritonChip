import subprocess,time
from pathlib import Path
p=subprocess.Popen(["sleep","60"])
Path('/home/zhongchun/r41s1-work/tuning-final/compiler/descendant.pid').write_text(str(p.pid))
time.sleep(60)
