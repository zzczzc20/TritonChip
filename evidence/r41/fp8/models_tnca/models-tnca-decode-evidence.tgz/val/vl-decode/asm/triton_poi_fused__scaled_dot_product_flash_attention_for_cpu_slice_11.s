    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #1664
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.movi       v3, #26624
    v.splat      v4, s2
    v.sub        v5, v2, v1
    v.add        v6, v4, v0
    v.cmp.lt     p1, v1, v2
    v.sub        v0, v2, v6
    v.cmp.lt     p2, v6, v2
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.cmp.lt     p3, v6, v3
    v.movi       v3, #1
    s.ld.d       s4, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    @p2 v.sel        v4, v0, v6
    @p1 v.sel        v0, v5, v1
    v.movi       v1, #0
    v.movi       v5, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v7, s1
    v.shl        v8, v5, v3
    v.lshr       v9, v4, v7
    v.cmp.lt     p1, v5, v2
    v.and        v10, v9, v3
    v.shl        v9, v3, v7
    v.or         v7, v8, v10
    s.subi       s5, s1, #1
    v.cmp.geu    p4, v7, v0
    p.or         p5, p1, p4
    v.sub        v8, v7, v0
    @p5 v.sel        v10, v9, v2
    @p5 v.sel        v9, v8, v7
    v.or         v7, v1, v10
    v.mov        v5, v9
    v.mov        v1, v7
    s.mov        s1, s5
    s.movz       s5, #0
    s.cmp.ge     s6, s1, s5
    br.nz        s6, idiv_1
    v.movi       v0, #3328
    v.movi       v1, #0
    v.sub        v3, v2, v5
    v.sub        v2, v1, v6
    v.sub        v4, v1, v0
    v.cmp.lt     p1, v6, v1
    v.cmp.lt     p4, v0, v1
    @p2 v.sel        v7, v3, v5
    v.movi       v3, #1
    @p1 v.sel        v5, v2, v6
    @p4 v.sel        v2, v4, v0
    v.movi       v0, #0
    v.movi       v4, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v6, s1
    v.shl        v8, v4, v3
    v.lshr       v9, v5, v6
    v.cmp.lt     p2, v4, v1
    v.and        v10, v9, v3
    v.shl        v9, v3, v6
    v.or         v6, v8, v10
    s.subi       s5, s1, #1
    v.cmp.geu    p5, v6, v2
    p.or         p6, p2, p5
    v.sub        v8, v6, v2
    @p6 v.sel        v10, v9, v1
    @p6 v.sel        v9, v8, v6
    v.or         v6, v0, v10
    v.mov        v4, v9
    v.mov        v0, v6
    s.mov        s1, s5
    s.movz       s5, #0
    s.cmp.ge     s6, s1, s5
    br.nz        s6, idiv_2
    p.xor        p2, p1, p4
    v.sub        v2, v1, v0
    v.movi       v1, #4096
    @p2 v.sel        v3, v2, v0
    s.shli       s1, s2, #2                      // element offset -> bytes (x4)
    v.mul        v0, v3, v1
    s.add        s2, s4, s1                      // &out_ptr0[...]
    v.add        v1, v7, v0
    s.movz       s1, #4096
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v0, [s3, v1]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v1, v0
    @p3 v.st.w       [s2, #0], v1
__rctx_next:
    exit
