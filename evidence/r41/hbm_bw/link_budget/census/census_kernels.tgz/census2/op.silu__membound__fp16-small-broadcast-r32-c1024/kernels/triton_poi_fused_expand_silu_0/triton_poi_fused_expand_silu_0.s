    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    s.rdspecial  s2, arg_base
    v.add        v3, v1, v0
    v.movi       v0, #1023
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    .li       s4, #1069066811
    v.splat      v4, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v5, v1, v3
    .li       s4, #1060205080
    v.splat      v1, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s4, #1065353216
    v.splat      v3, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v6, v5, v0
    .li       s4, #1065353216
    v.splat      v0, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v5, #1024
    v.sub        v7, v2, v6
    s.ld.d       s4, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    @p1 v.sel        v8, v7, v6
    v.sub        v6, v2, v5
    v.cmp.lt     p1, v5, v2
    @p1 v.sel        v2, v6, v5
    v.ld.gather.h v2, [s3, v8]                   // index is in elements (ISA sec 9.1)
    s.add        s1, s4, s2                      // &out_ptr0[...]
    vf.cvt.f16.f32 v5, v2
    vf.neg       v2, v5
    vf.mul       v6, v2, v4
    v.exp2.approx v7, v6                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v2, v4, v6                  // the exact rounding error of x*log2(e)
    vf.mul       v2, v8, v1
    vf.fma       v1, v7, v2, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v2, v1, v7
    vf.add       v1, v2, v3
    v.rcp.approx v2, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v1, v2, v0
    vf.fms       v0, v2, v3, v2
    vf.neg       v1, v0                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v2
    vf.mul       v1, v5, v0                      // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.f16 v0, v1
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
