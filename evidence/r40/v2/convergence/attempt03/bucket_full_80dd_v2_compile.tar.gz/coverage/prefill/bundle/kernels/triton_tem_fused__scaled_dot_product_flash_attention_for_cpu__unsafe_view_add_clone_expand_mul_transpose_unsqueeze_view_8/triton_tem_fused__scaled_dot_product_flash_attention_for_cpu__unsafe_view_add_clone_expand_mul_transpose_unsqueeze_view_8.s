    s.movz       s1, #32
    s.movz       s2, #0
    s.movz       s3, #0
    s.cmp.lt     s4, s1, s2
    s.rdspecial  s2, arg_base
    s.sub        s5, s3, s4
    s.ld.d       s3, [s2, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.xor        s4, s1, s5
    s.movz       s6, #0
    s.movz       s7, #0
    s.sub        s8, s4, s5
    s.movz       s4, #1
    s.movz       s8, #0
    s.movz       s9, #0
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.ld.d       s13, [s2, #8]                   // arg_B: device_ptr64 at arg_base+8
    s.movz       s14, #0
    s.movz       s15, #1
    s.rdspecial  s16, role_id
    s.rdspecial  s17, npid.x
    s.ld.d       s18, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
__rctx_program:
    s.cmp.lt     s2, s16, s7
    s.cmp.lt     s19, s16, s9
    s.sub        s20, s6, s2
    s.sub        s2, s8, s19
    s.xor        s19, s16, s20
    s.xor        s21, s20, s5
    s.sub        s22, s19, s20
    s.xor        s19, s16, s2
    s.lshri      s20, s22, #5
    s.sub        s23, s19, s2
    s.xor        s19, s20, s21
    s.muli       s24, s20, #32
    s.sub        s20, s19, s21
    s.addi       s19, s12, #0
    s.sub        s21, s1, s20
    s.addi       s25, s14, #0
    s.min.s      s26, s21, s4
    s.sub        s21, s22, s24
    s.cmp.lt     s21, s26, s11
    s.mov        s19, s23
    s.sub        s22, s10, s21
    s.xor        s21, s26, s22
    s.sub        s24, s21, s22
    s.cmp.eq     s21, s24, s15
    br.nz        s21, sdiv_done_1
    s.movz       s21, #0
    s.movz       s22, #31
    s.mov        s19, s21
    s.addi       s21, s22, #0
sdiv_2:
    s.lshr       s22, s23, s21
    s.shli       s27, s25, #1
    s.andi       s28, s22, #1
    s.movz       s22, #0
    s.or         s29, s27, s28
    s.movz       s27, #1
    s.cmp.geu    s28, s29, s24
    s.shl        s30, s27, s21
    s.sub        s27, s22, s28
    s.subi       s22, s21, #1
    s.and        s28, s24, s27
    s.and        s31, s30, s27
    s.sub        s27, s29, s28
    s.or         s28, s19, s31
    s.mov        s25, s27
    s.mov        s19, s28
    s.mov        s21, s22
    s.movz       s22, #0
    s.cmp.ge     s27, s21, s22
    br.nz        s27, sdiv_2
sdiv_done_1:
    s.movz       s19, #0
    s.movz       s21, #0
    s.cmp.lt     s22, s16, s19
    s.movz       s19, #0
    s.sub        s23, s21, s22
    s.movz       s21, #0
    s.xor        s22, s16, s23
    s.movz       s24, #0
    s.sub        s27, s22, s23
    s.cmp.lt     s22, s26, s19
    s.lshri      s19, s27, #5
    s.movz       s28, #0
    s.muli       s29, s19, #32
    s.movz       s19, #0
    s.sub        s30, s24, s22
    s.movz       s22, #0
    s.cmp.lt     s24, s1, s28
    s.sub        s28, s27, s29
    s.xor        s27, s26, s30
    s.xor        s26, s28, s23
    s.xor        s28, s25, s2
    s.sub        s25, s26, s23
    s.sub        s23, s22, s24
    s.cmp.lt     s22, s25, s21
    s.sub        s21, s27, s30
    s.sub        s24, s19, s22
    s.movz       s19, #0
    s.xor        s22, s25, s24
    s.movz       s25, #1
    s.sub        s26, s28, s2
    s.xor        s2, s1, s23
    s.sub        s27, s22, s24
    s.movz       s22, #0
    s.addi       s28, s19, #0
    s.cmp.eq     s19, s21, s25
    s.add        s25, s20, s26
    s.sub        s20, s2, s23
    s.addi       s2, s22, #0
    s.mov        s28, s27
    br.nz        s19, sdiv_done_3
    s.movz       s19, #0
    s.movz       s20, #31
    s.mov        s28, s19
    s.addi       s19, s20, #0
sdiv_4:
    s.lshr       s20, s27, s19
    s.shli       s22, s2, #1
    s.andi       s23, s20, #1
    s.movz       s20, #0
    s.or         s26, s22, s23
    s.movz       s22, #1
    s.cmp.geu    s23, s26, s21
    s.shl        s29, s22, s19
    s.sub        s22, s20, s23
    s.subi       s20, s19, #1
    s.and        s23, s21, s22
    s.and        s31, s29, s22
    s.sub        s22, s26, s23
    s.or         s23, s28, s31
    s.mov        s2, s22
    s.mov        s28, s23
    s.mov        s19, s20
    s.movz       s20, #0
    s.cmp.ge     s22, s19, s20
    br.nz        s22, sdiv_4
sdiv_done_3:
    s.movz       s2, #16
    s.rdspecial  s19, pid.z
    s.rdspecial  s20, npid.y
    s.xor        s21, s24, s30
    s.mul        s22, s25, s2
    s.mul        s23, s19, s20
    s.xor        s19, s28, s21
    s.rdspecial  s20, pid.y
    s.sub        s24, s19, s21
    s.andi       s19, s22, #511
    s.mul        s21, s24, s2
    s.add        s26, s20, s23
    s.movz       s20, #15
    s.rdspecial  s23, arg_base
    s.min.s      s27, s26, s20
    s.movz       s20, #32768
    s.ld.d       s28, [s23, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.muli       s23, s19, #64                   // a runtime tile origin, x64
    s.mul        s29, s27, s20
    s.andi       s20, s21, #511
    s.movz       s27, #0
    s.rdspecial  s30, role_id
    s.movz       s31, #6144
    s.add        s32, s27, s23                   // the tile origin
    s.mul        s23, s30, s31
    s.add        s27, s32, s29                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s27
    s.movz       s30, #0
    s.add        s31, s28, s23                   // this context's own scratch
    v.splat      v2, s25
    s.addi       s23, s31, #0
    v.splat      v3, s30
    s.addi       s25, s27, #64
    v.splat      v4, s24
    v.splat      v5, s30
    v.add        v6, v0, v1
    s.addi       s24, s23, #64
    v.cmp.ge     p1, v2, v3
    v.splat      v1, s25
    v.iota       v2                              // arange(0, VLEN)
    v.cmp.ge     p1, v4, v5
    s.addi       s25, s27, #128
    v.splat      v3, s22
    v.splat      v4, s25
    v.add        v5, v0, v1
    s.addi       s25, s23, #128
    v.add        v1, v0, v4
    v.add        v4, v3, v2
    s.addi       s28, s27, #192
    v.splat      v3, s21
    s.addi       s32, s23, #192
    s.movz       s33, #64
    v.add        v4, v3, v2
    v.splat      v2, s28
    v.splat      v3, s19
    s.addi       s19, s23, #256
    v.add        v4, v0, v2
    s.addi       s28, s30, #0
    v.st.w       [s23, #0], v6
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s30, s27, #256
    v.add        v6, v3, v2
    v.splat      v2, s30
    v.splat      v3, s20
    v.add        v6, v0, v2
    v.st.w       [s24, #0], v5
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s24, s23, #320
    v.add        v5, v3, v2
    s.addi       s30, s27, #320
    s.addi       s34, s27, #384
    v.splat      v2, s30
    s.addi       s30, s27, #448
    v.splat      v3, s34
    s.addi       s34, s27, #512
    v.add        v5, v0, v2
    v.add        v2, v0, v3
    v.st.w       [s25, #0], v1
    s.addi       s25, s27, #576
    v.splat      v1, s30
    s.addi       s30, s27, #640
    v.add        v3, v0, v1
    v.st.w       [s32, #0], v4
    s.addi       s32, s27, #704
    v.splat      v1, s34
    s.addi       s34, s27, #768
    v.add        v4, v0, v1
    v.st.w       [s19, #0], v6
    s.addi       s19, s27, #832
    v.splat      v1, s25
    s.addi       s25, s27, #896
    s.addi       s35, s27, #960
    v.add        v6, v0, v1
    v.st.w       [s24, #0], v5
    v.splat      v1, s30
    s.addi       s24, s23, #384
    s.addi       s27, s31, #1024
    v.add        v5, v0, v1
    v.st.w       [s24, #0], v2
    s.movz       s24, #0
    v.splat      v1, s32
    s.addi       s30, s23, #448
    s.add        s32, s24, s20                   // the tile origin
    v.add        v2, v0, v1
    s.add        s20, s32, s29                   // the tile origin
    s.addi       s24, s23, #512
    s.addi       s29, s23, #576
    v.st.w       [s30, #0], v3
    s.addi       s30, s20, #512
    v.splat      v1, s34
    s.addi       s32, s23, #640
    v.add        v3, v0, v1
    v.st.w       [s24, #0], v4
    s.addi       s24, s20, #1024
    v.splat      v1, s19
    s.addi       s19, s23, #704
    v.add        v4, v0, v1
    v.st.w       [s29, #0], v6
    s.addi       s29, s20, #1536
    v.splat      v1, s25
    s.addi       s25, s23, #768
    v.add        v6, v0, v1
    v.st.w       [s32, #0], v5
    s.addi       s32, s20, #2048
    v.splat      v1, s35
    s.addi       s34, s23, #832
    v.add        v5, v0, v1
    v.st.w       [s19, #0], v2
    s.addi       s19, s20, #2560
    v.splat      v1, s20
    v.add        v2, v0, v1
    v.st.w       [s25, #0], v3
    s.addi       s25, s20, #3072
    v.splat      v1, s30
    s.addi       s30, s23, #896
    s.addi       s35, s23, #960
    v.add        v3, v0, v1
    v.st.w       [s34, #0], v4
    s.addi       s23, s20, #3584
    v.splat      v1, s24
    s.addi       s24, s27, #64
    v.add        v4, v0, v1
    v.st.w       [s30, #0], v6
    s.addi       s30, s20, #4096
    v.splat      v1, s29
    s.addi       s29, s27, #128
    v.add        v6, v0, v1
    v.st.w       [s35, #0], v5
    v.splat      v1, s32
    s.addi       s32, s27, #192
    s.addi       s34, s27, #256
    v.add        v5, v0, v1
    fence.acq_rel.device
    v.st.w       [s27, #0], v2
    v.splat      v1, s19
    s.addi       s19, s20, #4608
    v.add        v2, v0, v1
    v.st.w       [s24, #0], v3
    s.addi       s24, s20, #5120
    v.splat      v1, s25
    s.addi       s25, s20, #5632
    v.add        v3, v0, v1
    v.st.w       [s29, #0], v4
    s.addi       s29, s20, #6144
    v.splat      v1, s23
    s.addi       s23, s20, #6656
    v.add        v4, v0, v1
    v.st.w       [s32, #0], v6
    s.addi       s32, s20, #7168
    v.splat      v1, s30
    s.addi       s30, s27, #320
    v.add        v6, v0, v1
    v.st.w       [s34, #0], v5
    s.addi       s34, s20, #7680
    v.splat      v1, s19
    s.addi       s19, s27, #384
    s.addi       s20, s27, #448
    v.add        v5, v0, v1
    v.st.w       [s30, #0], v2
    v.splat      v1, s24
    s.addi       s24, s27, #512
    s.addi       s30, s27, #576
    v.add        v2, v0, v1
    v.st.w       [s19, #0], v3
    v.splat      v1, s25
    s.addi       s19, s27, #640
    s.addi       s25, s27, #704
    v.add        v3, v0, v1
    v.st.w       [s20, #0], v4
    v.splat      v1, s29
    s.addi       s20, s27, #768
    s.addi       s29, s27, #832
    v.add        v4, v0, v1
    v.st.w       [s24, #0], v6
    v.splat      v1, s23
    s.addi       s23, s27, #896
    s.addi       s24, s27, #960
    v.add        v6, v0, v1
    v.st.w       [s30, #0], v5
    v.splat      v1, s32
    v.add        v5, v0, v1
    v.st.w       [s19, #0], v2
    v.splat      v1, s34
    v.add        v2, v0, v1
    v.st.w       [s25, #0], v3
    v.st.w       [s20, #0], v4
    v.st.w       [s29, #0], v6
    v.st.w       [s23, #0], v5
    v.st.w       [s24, #0], v2
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s19, s28, s33
    br.nz        s19, endfor_6
    s.addi       s19, s31, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s20, #0
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #64
    s.movz       s23, #1
    s.addi       s24, s31, #128
    s.movz       s25, #2
    s.addi       s27, s31, #192
    s.movz       s29, #3
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s20, v2
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #256
    s.movz       s20, #4
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s23, v2
    v.ld.w       v1, [s24, #0]
    s.addi       s23, s31, #320
    s.movz       s24, #5
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s25, v2
    v.ld.w       v1, [s27, #0]
    s.addi       s25, s31, #384
    s.movz       s27, #6
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s29, v2
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #448
    s.movz       s29, #7
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s20, v2
    v.ld.w       v1, [s23, #0]
    s.addi       s20, s31, #512
    s.movz       s23, #8
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s24, v2
    v.ld.w       v1, [s25, #0]
    s.addi       s24, s31, #576
    s.movz       s25, #9
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s27, v2
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #640
    s.movz       s27, #10
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s29, v2
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s31, #704
    s.movz       s29, #11
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s23, v2
    v.ld.w       v1, [s24, #0]
    s.addi       s23, s31, #768
    s.movz       s24, #12
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s25, v2
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #832
    s.movz       s25, #13
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s27, v2
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s31, #896
    s.movz       s27, #14
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s29, v2
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s31, #960
    s.movz       s29, #15
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s24, v2
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #1024
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s24, #0
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s25, v2
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s31, #1088
    s.movz       s25, #1
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s27, v2
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s31, #1152
    s.movz       s27, #2
    v.ld.gather.w v2, [s3, v1]                   // index is in elements (ISA sec 9.1)
    a.vwrite     a1, s29, v2
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #1216
    s.movz       s29, #3
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s24, v2
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s31, #1280
    s.movz       s24, #4
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s25, v2
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s31, #1344
    s.movz       s25, #5
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s27, v2
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #1408
    s.movz       s27, #6
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s29, v2
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s31, #1472
    s.movz       s29, #7
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s24, v2
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s31, #1536
    s.movz       s24, #8
    v.ld.gather.w v2, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s25, v2
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #1600
    s.movz       s25, #9
    v.movi       v2, #0
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s27, v3
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s31, #1664
    s.movz       s27, #10
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s29, v3
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s31, #1728
    s.movz       s29, #11
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s24, v3
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #1792
    s.movz       s24, #12
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s25, v3
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s31, #1856
    s.movz       s25, #13
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s27, v3
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s31, #1920
    s.movz       s27, #14
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s29, v3
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #1984
    s.movz       s29, #15
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s24, v3
    v.ld.w       v1, [s20, #0]
    s.movz       s20, #0
    s.movz       s24, #0
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s25, v3
    v.ld.w       v1, [s23, #0]
    s.movz       s23, #1
    s.movz       s25, #2
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s27, v3
    v.ld.w       v1, [s19, #0]
    s.movz       s19, #3
    s.movz       s27, #4
    v.ld.gather.w v3, [s13, v1]                  // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s29, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s24
    a.vread      v4, a2, s23
    v.extract    s20, v1, #0
    v.extract    s23, v1, #1
    v.splat      v5, s20
    v.splat      v6, s23
    v.extract    s20, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s20
    a.vread      v5, a2, s25
    v.extract    s20, v1, #3
    a.vread      v8, a2, s19
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s20
    v.extract    s19, v1, #4
    a.vread      v6, a2, s27
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s19, #0
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #1
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s19
    a.vread      v5, a2, s25
    v.extract    s19, v1, #3
    a.vread      v8, a2, s27
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    s.movz       s19, #1
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #2
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s19
    a.vread      v5, a2, s25
    v.extract    s19, v1, #3
    a.vread      v8, a2, s27
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    s.movz       s19, #2
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #3
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s19
    a.vread      v5, a2, s25
    v.extract    s19, v1, #3
    a.vread      v8, a2, s27
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    s.movz       s19, #3
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #4
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s19
    a.vread      v5, a2, s25
    v.extract    s19, v1, #3
    a.vread      v8, a2, s27
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    s.movz       s19, #4
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #5
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s19
    a.vread      v5, a2, s25
    v.extract    s19, v1, #3
    a.vread      v8, a2, s27
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    s.movz       s19, #5
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #6
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s19
    a.vread      v5, a2, s25
    v.extract    s19, v1, #3
    a.vread      v8, a2, s27
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    s.movz       s19, #6
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #7
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s19
    a.vread      v5, a2, s25
    v.extract    s19, v1, #3
    a.vread      v8, a2, s27
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    s.movz       s19, #7
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #8
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s19
    a.vread      v5, a2, s25
    v.extract    s19, v1, #3
    a.vread      v8, a2, s27
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    s.movz       s19, #8
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #9
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s19
    a.vread      v5, a2, s25
    v.extract    s19, v1, #3
    a.vread      v8, a2, s27
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    s.movz       s19, #9
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #10
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s19
    a.vread      v5, a2, s25
    v.extract    s19, v1, #3
    a.vread      v8, a2, s27
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    s.movz       s19, #10
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #11
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s19
    a.vread      v5, a2, s25
    v.extract    s19, v1, #3
    a.vread      v8, a2, s27
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    s.movz       s19, #11
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #12
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s19
    a.vread      v5, a2, s25
    v.extract    s19, v1, #3
    a.vread      v8, a2, s27
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    s.movz       s19, #12
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #13
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s19
    a.vread      v5, a2, s25
    v.extract    s19, v1, #3
    a.vread      v8, a2, s27
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    s.movz       s19, #13
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #14
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v3, s19
    a.vread      v5, a2, s25
    v.extract    s19, v1, #3
    a.vread      v8, a2, s27
    vf.fma       v9, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v10, v3, v5, v9
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v4, v8, v10
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v8, a2, s20
    vf.fma       v10, v7, v6, v9
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v9, v3, v5, v10
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v3, s19
    a.vread      v5, a2, s20
    vf.fma       v10, v4, v8, v9
    s.movz       s19, #14
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v8, v6, v7, v10
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v9, v3, v5, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v5, s20
    vf.fma       v8, v4, v6, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v9, v7, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v7, s20
    vf.fma       v8, v5, v4, v9
    a.vread      v4, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v5, s20
    vf.fma       v9, v6, v3, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v7, v4, v9
    a.vread      v4, a2, s23
    s.movz       s20, #15
    s.movz       s23, #0
    s.movz       s24, #1
    vf.fma       v7, v5, v3, v6
    s.movz       s25, #2
    s.movz       s27, #3
    s.movz       s29, #4
    vf.fma       v3, v1, v4, v7
    a.vwrite     a3, s19, v3
    a.vread      v1, a1, s20
    a.vread      v3, a2, s23
    a.vread      v4, a2, s24
    v.extract    s19, v1, #0
    v.extract    s20, v1, #1
    v.splat      v5, s19
    v.splat      v6, s20
    v.extract    s19, v1, #2
    vf.fma       v7, v5, v3, v2
    v.splat      v2, s19
    a.vread      v3, a2, s25
    v.extract    s19, v1, #3
    a.vread      v5, a2, s27
    vf.fma       v8, v6, v4, v7
    v.splat      v4, s19
    v.extract    s19, v1, #4
    a.vread      v6, a2, s29
    v.splat      v7, s19
    vf.fma       v9, v2, v3, v8
    v.extract    s19, v1, #5
    s.movz       s20, #5
    v.splat      v2, s19
    a.vread      v3, a2, s20
    vf.fma       v8, v4, v5, v9
    v.extract    s19, v1, #6
    s.movz       s20, #6
    v.splat      v4, s19
    a.vread      v5, a2, s20
    vf.fma       v9, v7, v6, v8
    v.extract    s19, v1, #7
    s.movz       s20, #7
    v.splat      v6, s19
    a.vread      v7, a2, s20
    vf.fma       v8, v2, v3, v9
    v.extract    s19, v1, #8
    s.movz       s20, #8
    v.splat      v2, s19
    a.vread      v3, a2, s20
    vf.fma       v9, v4, v5, v8
    s.movz       s19, #15
    v.extract    s20, v1, #9
    s.movz       s23, #9
    v.splat      v4, s20
    vf.fma       v5, v6, v7, v9
    a.vread      v6, a2, s23
    v.extract    s20, v1, #10
    s.movz       s23, #10
    v.splat      v7, s20
    vf.fma       v8, v2, v3, v5
    a.vread      v2, a2, s23
    v.extract    s20, v1, #11
    s.movz       s23, #11
    v.splat      v3, s20
    vf.fma       v5, v4, v6, v8
    a.vread      v4, a2, s23
    v.extract    s20, v1, #12
    s.movz       s23, #12
    v.splat      v6, s20
    vf.fma       v8, v7, v2, v5
    a.vread      v2, a2, s23
    v.extract    s20, v1, #13
    s.movz       s23, #13
    v.splat      v5, s20
    vf.fma       v7, v3, v4, v8
    a.vread      v3, a2, s23
    v.extract    s20, v1, #14
    s.movz       s23, #14
    v.splat      v4, s20
    vf.fma       v8, v6, v2, v7
    a.vread      v2, a2, s23
    v.extract    s20, v1, #15
    s.movz       s23, #15
    v.splat      v1, s20
    vf.fma       v6, v5, v3, v8
    a.vread      v3, a2, s23
    s.addi       s20, s31, #0
    v.splat      v5, s2
    s.addi       s23, s31, #2048
    vf.fma       v7, v4, v2, v6
    s.addi       s24, s31, #64
    s.addi       s25, s23, #64
    s.addi       s27, s31, #128
    s.addi       s29, s23, #128
    vf.fma       v2, v1, v3, v7
    a.vwrite     a3, s19, v2
    v.ld.w       v1, [s20, #0]
    s.addi       s19, s31, #192
    s.addi       s20, s23, #192
    v.add        v2, v1, v5
    v.st.w       [s23, #0], v2
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s31, #256
    v.add        v2, v1, v5
    v.st.w       [s25, #0], v2
    s.addi       s25, s23, #256
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #320
    v.add        v2, v1, v5
    v.st.w       [s29, #0], v2
    s.addi       s29, s23, #320
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #384
    v.add        v2, v1, v5
    v.st.w       [s20, #0], v2
    s.addi       s20, s23, #384
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s31, #448
    v.add        v2, v1, v5
    v.st.w       [s25, #0], v2
    s.addi       s25, s23, #448
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #512
    v.add        v2, v1, v5
    v.st.w       [s29, #0], v2
    s.addi       s29, s23, #512
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #576
    v.add        v2, v1, v5
    v.st.w       [s20, #0], v2
    s.addi       s20, s23, #576
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s31, #640
    v.add        v2, v1, v5
    v.st.w       [s25, #0], v2
    s.addi       s25, s23, #640
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #704
    v.add        v2, v1, v5
    v.st.w       [s29, #0], v2
    s.addi       s29, s23, #704
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #768
    v.add        v2, v1, v5
    v.st.w       [s20, #0], v2
    s.addi       s20, s23, #768
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s31, #832
    v.add        v2, v1, v5
    v.st.w       [s25, #0], v2
    s.addi       s25, s23, #832
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #896
    v.add        v2, v1, v5
    v.st.w       [s29, #0], v2
    s.addi       s29, s23, #896
    s.addi       s30, s23, #960
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #960
    v.add        v2, v1, v5
    v.st.w       [s20, #0], v2
    s.addi       s20, s31, #1024
    v.ld.w       v1, [s24, #0]
    s.movz       s23, #8192
    v.splat      v2, s23
    s.addi       s23, s31, #3072
    v.add        v3, v1, v5
    v.st.w       [s25, #0], v3
    s.addi       s24, s31, #1088
    v.ld.w       v1, [s27, #0]
    s.addi       s25, s23, #64
    v.add        v3, v1, v5
    v.st.w       [s29, #0], v3
    s.addi       s27, s31, #1152
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s23, #128
    v.add        v3, v1, v5
    v.st.w       [s30, #0], v3
    fence.acq_rel.device
    s.addi       s29, s31, #1216
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s23, #192
    v.add        v3, v1, v2
    v.st.w       [s23, #0], v3
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s31, #1280
    v.add        v3, v1, v2
    v.st.w       [s25, #0], v3
    s.addi       s25, s23, #256
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #1344
    v.add        v3, v1, v2
    v.st.w       [s19, #0], v3
    s.addi       s19, s23, #320
    v.ld.w       v1, [s29, #0]
    s.addi       s29, s31, #1408
    v.add        v3, v1, v2
    v.st.w       [s20, #0], v3
    s.addi       s20, s23, #384
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s31, #1472
    v.add        v3, v1, v2
    v.st.w       [s25, #0], v3
    s.addi       s25, s23, #448
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #1536
    v.add        v3, v1, v2
    v.st.w       [s19, #0], v3
    s.addi       s19, s23, #512
    v.ld.w       v1, [s29, #0]
    s.addi       s29, s31, #1600
    v.add        v3, v1, v2
    v.st.w       [s20, #0], v3
    s.addi       s20, s23, #576
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s31, #1664
    v.add        v3, v1, v2
    v.st.w       [s25, #0], v3
    s.addi       s25, s23, #640
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #1728
    v.add        v3, v1, v2
    v.st.w       [s19, #0], v3
    s.addi       s19, s23, #704
    v.ld.w       v1, [s29, #0]
    s.addi       s29, s31, #1792
    v.add        v3, v1, v2
    v.st.w       [s20, #0], v3
    s.addi       s20, s23, #768
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s31, #1856
    v.add        v3, v1, v2
    v.st.w       [s25, #0], v3
    s.addi       s25, s23, #832
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #1920
    v.add        v3, v1, v2
    v.st.w       [s19, #0], v3
    s.addi       s19, s23, #896
    s.addi       s30, s23, #960
    v.ld.w       v1, [s29, #0]
    s.addi       s23, s31, #1984
    v.add        v3, v1, v2
    v.st.w       [s20, #0], v3
    s.addi       s20, s31, #2048
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s31, #4096
    v.add        v3, v1, v2
    v.st.w       [s25, #0], v3
    s.addi       s25, s31, #2112
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s24, #64
    v.add        v3, v1, v2
    v.st.w       [s19, #0], v3
    s.addi       s19, s31, #2176
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s24, #128
    v.add        v3, v1, v2
    v.st.w       [s30, #0], v3
    fence.acq_rel.device
    s.addi       s29, s31, #2240
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s24, #192
    v.st.w       [s24, #0], v1
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s31, #2304
    v.st.w       [s27, #0], v1
    s.addi       s27, s24, #256
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #2368
    v.st.w       [s23, #0], v1
    s.addi       s23, s24, #320
    v.ld.w       v1, [s29, #0]
    s.addi       s29, s31, #2432
    v.st.w       [s20, #0], v1
    s.addi       s20, s24, #384
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s31, #2496
    v.st.w       [s27, #0], v1
    s.addi       s27, s24, #448
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #2560
    v.st.w       [s23, #0], v1
    s.addi       s23, s24, #512
    v.ld.w       v1, [s29, #0]
    s.addi       s29, s31, #2624
    v.st.w       [s20, #0], v1
    s.addi       s20, s24, #576
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s31, #2688
    v.st.w       [s27, #0], v1
    s.addi       s27, s24, #640
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #2752
    v.st.w       [s23, #0], v1
    s.addi       s23, s24, #704
    v.ld.w       v1, [s29, #0]
    s.addi       s29, s31, #2816
    v.st.w       [s20, #0], v1
    s.addi       s20, s24, #768
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s31, #2880
    v.st.w       [s27, #0], v1
    s.addi       s27, s24, #832
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #2944
    v.st.w       [s23, #0], v1
    s.addi       s23, s24, #896
    s.addi       s30, s24, #960
    v.ld.w       v1, [s29, #0]
    s.addi       s24, s31, #3008
    v.st.w       [s20, #0], v1
    s.addi       s20, s31, #3072
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s31, #5120
    v.st.w       [s27, #0], v1
    s.addi       s27, s31, #3136
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s25, #64
    v.st.w       [s23, #0], v1
    s.addi       s23, s31, #3200
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s25, #128
    v.st.w       [s30, #0], v1
    fence.acq_rel.device
    s.addi       s29, s31, #3264
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s25, #192
    v.st.w       [s25, #0], v1
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #3328
    v.st.w       [s19, #0], v1
    s.addi       s19, s25, #256
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s31, #3392
    v.st.w       [s24, #0], v1
    s.addi       s24, s25, #320
    v.ld.w       v1, [s29, #0]
    s.addi       s29, s31, #3456
    v.st.w       [s20, #0], v1
    s.addi       s20, s25, #384
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #3520
    v.st.w       [s19, #0], v1
    s.addi       s19, s25, #448
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s31, #3584
    v.st.w       [s24, #0], v1
    s.addi       s24, s25, #512
    v.ld.w       v1, [s29, #0]
    s.addi       s29, s31, #3648
    v.st.w       [s20, #0], v1
    s.addi       s20, s25, #576
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #3712
    v.st.w       [s19, #0], v1
    s.addi       s19, s25, #640
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s31, #3776
    v.st.w       [s24, #0], v1
    s.addi       s24, s25, #704
    v.ld.w       v1, [s29, #0]
    s.addi       s29, s31, #3840
    v.st.w       [s20, #0], v1
    s.addi       s20, s25, #768
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #3904
    v.st.w       [s19, #0], v1
    s.addi       s19, s25, #832
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s31, #3968
    v.st.w       [s24, #0], v1
    s.addi       s24, s25, #896
    s.addi       s30, s25, #960
    v.ld.w       v1, [s29, #0]
    s.addi       s25, s31, #4032
    v.st.w       [s20, #0], v1
    s.movz       s20, #0
    v.ld.w       v1, [s27, #0]
    s.movz       s27, #0
    v.st.w       [s19, #0], v1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s19, #0
    v.ld.w       v1, [s23, #0]
    s.movz       s23, #1
    v.st.w       [s24, #0], v1
    s.movz       s24, #1
    v.ld.w       v1, [s25, #0]
    s.movz       s25, #1
    v.st.w       [s30, #0], v1
    fence.acq_rel.device
    a.vread      v1, a0, s20
    a.vread      v2, a3, s27
    s.movz       s20, #2
    s.movz       s27, #2
    vf.add       v3, v1, v2
    s.movz       s29, #2
    a.vwrite     a4, s19, v3
    a.vread      v1, a0, s23
    a.vread      v2, a3, s24
    s.movz       s19, #3
    s.movz       s23, #3
    vf.add       v3, v1, v2
    s.movz       s24, #3
    a.vwrite     a4, s25, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s27
    s.movz       s20, #4
    s.movz       s25, #4
    vf.add       v3, v1, v2
    s.movz       s27, #4
    a.vwrite     a4, s29, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s23
    s.movz       s19, #5
    s.movz       s23, #5
    vf.add       v3, v1, v2
    s.movz       s29, #5
    a.vwrite     a4, s24, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s25
    s.movz       s20, #6
    s.movz       s24, #6
    vf.add       v3, v1, v2
    s.movz       s25, #6
    a.vwrite     a4, s27, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s23
    s.movz       s19, #7
    s.movz       s23, #7
    vf.add       v3, v1, v2
    s.movz       s27, #7
    a.vwrite     a4, s29, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s24
    s.movz       s20, #8
    s.movz       s24, #8
    vf.add       v3, v1, v2
    s.movz       s29, #8
    a.vwrite     a4, s25, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s23
    s.movz       s19, #9
    s.movz       s23, #9
    vf.add       v3, v1, v2
    s.movz       s25, #9
    a.vwrite     a4, s27, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s24
    s.movz       s20, #10
    s.movz       s24, #10
    vf.add       v3, v1, v2
    s.movz       s27, #10
    a.vwrite     a4, s29, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s23
    s.movz       s19, #11
    s.movz       s23, #11
    vf.add       v3, v1, v2
    s.movz       s29, #11
    a.vwrite     a4, s25, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s24
    s.movz       s20, #12
    s.movz       s24, #12
    vf.add       v3, v1, v2
    s.movz       s25, #12
    a.vwrite     a4, s27, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s23
    s.movz       s19, #13
    s.movz       s23, #13
    vf.add       v3, v1, v2
    s.movz       s27, #13
    a.vwrite     a4, s29, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s24
    s.movz       s20, #14
    s.movz       s24, #14
    vf.add       v3, v1, v2
    s.movz       s29, #14
    a.vwrite     a4, s25, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s23
    s.movz       s19, #15
    s.movz       s23, #15
    vf.add       v3, v1, v2
    s.movz       s25, #15
    a.vwrite     a4, s27, v3
    a.vread      v1, a0, s20
    a.vread      v2, a3, s24
    s.addi       s20, s31, #4096
    s.addi       s24, s31, #0
    vf.add       v3, v1, v2
    s.addi       s27, s31, #4160
    a.vwrite     a4, s29, v3
    a.vread      v1, a0, s19
    a.vread      v2, a3, s23
    s.addi       s19, s31, #64
    s.addi       s23, s31, #4224
    vf.add       v3, v1, v2
    s.addi       s29, s31, #128
    a.vwrite     a4, s25, v3
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s31, #4288
    s.addi       s25, s31, #192
    v.st.w       [s24, #0], v1
    s.addi       s24, s31, #4352
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #256
    v.st.w       [s19, #0], v1
    s.addi       s19, s31, #4416
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s31, #320
    v.st.w       [s29, #0], v1
    s.addi       s29, s31, #4480
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s31, #384
    v.st.w       [s25, #0], v1
    s.addi       s25, s31, #4544
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s31, #448
    v.st.w       [s27, #0], v1
    s.addi       s27, s31, #4608
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #512
    v.st.w       [s23, #0], v1
    s.addi       s23, s31, #4672
    v.ld.w       v1, [s29, #0]
    s.addi       s29, s31, #576
    v.st.w       [s20, #0], v1
    s.addi       s20, s31, #4736
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s31, #640
    v.st.w       [s24, #0], v1
    s.addi       s24, s31, #4800
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #704
    v.st.w       [s19, #0], v1
    s.addi       s19, s31, #4864
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s31, #768
    v.st.w       [s29, #0], v1
    s.addi       s29, s31, #4928
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s31, #832
    v.st.w       [s25, #0], v1
    s.addi       s25, s31, #4992
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s31, #896
    v.st.w       [s27, #0], v1
    s.addi       s27, s31, #5056
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #960
    v.st.w       [s23, #0], v1
    s.addi       s23, s31, #5120
    v.ld.w       v1, [s29, #0]
    s.addi       s29, s31, #1024
    v.st.w       [s20, #0], v1
    s.addi       s20, s31, #5184
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s31, #1088
    v.st.w       [s24, #0], v1
    s.addi       s24, s31, #5248
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #1152
    v.st.w       [s19, #0], v1
    fence.acq_rel.device
    s.addi       s19, s31, #5312
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s31, #1216
    v.st.w       [s29, #0], v1
    s.addi       s29, s31, #5376
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s31, #1280
    v.st.w       [s25, #0], v1
    s.addi       s25, s31, #5440
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s31, #1344
    v.st.w       [s27, #0], v1
    s.addi       s27, s31, #5504
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #1408
    v.st.w       [s23, #0], v1
    s.addi       s23, s31, #5568
    v.ld.w       v1, [s29, #0]
    s.addi       s29, s31, #1472
    v.st.w       [s20, #0], v1
    s.addi       s20, s31, #5632
    v.ld.w       v1, [s25, #0]
    s.addi       s25, s31, #1536
    v.st.w       [s24, #0], v1
    s.addi       s24, s31, #5696
    v.ld.w       v1, [s27, #0]
    s.addi       s27, s31, #1600
    v.st.w       [s19, #0], v1
    s.addi       s19, s31, #5760
    v.ld.w       v1, [s23, #0]
    s.addi       s23, s31, #1664
    v.st.w       [s29, #0], v1
    s.addi       s29, s31, #5824
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s31, #1728
    v.st.w       [s25, #0], v1
    s.addi       s25, s31, #5888
    v.ld.w       v1, [s24, #0]
    s.addi       s24, s31, #1792
    v.st.w       [s27, #0], v1
    s.addi       s27, s31, #5952
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s31, #1856
    v.st.w       [s23, #0], v1
    s.addi       s23, s31, #6016
    v.ld.w       v1, [s29, #0]
    s.addi       s29, s31, #1920
    v.st.w       [s20, #0], v1
    s.addi       s20, s31, #6080
    s.addi       s30, s31, #1984
    v.ld.w       v1, [s25, #0]
    s.movz       s25, #0
    v.st.w       [s24, #0], v1
    s.movz       s24, #0
    v.ld.w       v1, [s27, #0]
    s.movz       s27, #1
    v.st.w       [s19, #0], v1
    s.movz       s19, #1
    v.ld.w       v1, [s23, #0]
    s.movz       s23, #2
    v.st.w       [s29, #0], v1
    s.movz       s29, #2
    v.ld.w       v1, [s20, #0]
    s.movz       s20, #3
    v.st.w       [s30, #0], v1
    fence.acq_rel.device
    a.vread      v1, a4, s25
    s.movz       s25, #3
    s.movz       s30, #4
    a.vwrite     a0, s24, v1
    a.vread      v1, a4, s27
    s.movz       s24, #4
    s.movz       s27, #5
    a.vwrite     a0, s19, v1
    a.vread      v1, a4, s23
    s.movz       s19, #5
    s.movz       s23, #6
    a.vwrite     a0, s29, v1
    a.vread      v1, a4, s20
    s.movz       s20, #6
    s.movz       s29, #7
    a.vwrite     a0, s25, v1
    a.vread      v1, a4, s30
    s.movz       s25, #7
    s.movz       s30, #8
    a.vwrite     a0, s24, v1
    a.vread      v1, a4, s27
    s.movz       s24, #8
    s.movz       s27, #9
    a.vwrite     a0, s19, v1
    a.vread      v1, a4, s23
    s.movz       s19, #9
    s.movz       s23, #10
    a.vwrite     a0, s20, v1
    a.vread      v1, a4, s29
    s.movz       s20, #10
    s.movz       s29, #11
    a.vwrite     a0, s25, v1
    a.vread      v1, a4, s30
    s.movz       s25, #11
    s.movz       s30, #12
    a.vwrite     a0, s24, v1
    a.vread      v1, a4, s27
    s.movz       s24, #12
    s.movz       s27, #13
    a.vwrite     a0, s19, v1
    a.vread      v1, a4, s23
    s.movz       s19, #13
    s.movz       s23, #14
    a.vwrite     a0, s20, v1
    a.vread      v1, a4, s29
    s.movz       s20, #14
    s.movz       s29, #15
    a.vwrite     a0, s25, v1
    a.vread      v1, a4, s30
    s.movz       s25, #15
    s.add        s30, s28, s2
    a.vwrite     a0, s24, v1
    a.vread      v1, a4, s27
    s.movz       s24, #1
    a.vwrite     a0, s19, v1
    a.vread      v1, a4, s23
    a.vwrite     a0, s20, v1
    a.vread      v1, a4, s29
    a.vwrite     a0, s25, v1
    s.mov        s28, s30
    br.nz        s24, for_5
endfor_6:
    s.movz       s19, #0
    .li       s20, #262144
    s.add        s23, s19, s21                   // the tile origin
    s.mul        s19, s26, s20
    s.movz       s20, #0
    s.muli       s24, s21, #4                    // a runtime tile origin, x4
    v.splat      v1, s23
    s.add        s21, s20, s22                   // the tile origin
    s.movz       s20, #512
    s.muli       s23, s22, #2048                 // a runtime tile origin, x2048
    v.splat      v2, s21
    v.splat      v3, s20
    v.add        v4, v0, v1
    v.splat      v0, s20
    s.muli       s20, s19, #4                    // a runtime tile origin, x4
    s.addi       s19, s21, #1
    v.splat      v1, s26
    v.splat      v5, s2
    s.add        s2, s18, s24                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s22, #0
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    v.splat      v0, s19
    s.add        s19, s2, s23                    // the tile origin
    p.and        p3, p1, p2
    s.addi       s2, s21, #2
    v.cmp.lt     p1, v1, v5
    a.vread      v1, a0, s22
    s.add        s22, s19, s20                   // the tile origin
    p.and        p4, p3, p1
    s.movz       s19, #1
    v.cmp.lt     p3, v0, v3
    v.splat      v0, s2
    p.and        p5, p3, p2
    s.addi       s2, s21, #3
    @p4 v.st.w       [s22, #0], v1
    a.vread      v1, a0, s19
    s.addi       s19, s22, #2048                 // row 1
    p.and        p3, p5, p1
    s.movz       s20, #2
    v.cmp.lt     p4, v0, v3
    v.splat      v0, s2
    p.and        p5, p4, p2
    s.addi       s2, s21, #4
    s.addi       s23, s22, #4096                 // row 2
    p.and        p4, p5, p1
    s.movz       s24, #3
    v.splat      v2, s2
    s.addi       s2, s21, #5
    s.addi       s25, s22, #6144                 // row 3
    s.movz       s26, #4
    v.splat      v4, s2
    s.addi       s2, s21, #6
    @p3 v.st.w       [s19, #0], v1
    a.vread      v1, a0, s20
    v.cmp.lt     p3, v0, v3
    p.and        p5, p3, p2
    s.addi       s19, s22, #8192                 // row 4
    p.and        p3, p5, p1
    s.movz       s20, #5
    v.splat      v0, s2
    s.addi       s2, s21, #7
    v.splat      v5, s2
    s.addi       s2, s22, #10240                 // row 5
    @p4 v.st.w       [s23, #0], v1
    a.vread      v1, a0, s24
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.movz       s23, #6
    p.and        p4, p5, p1
    s.addi       s24, s21, #8
    v.splat      v2, s24
    s.addi       s24, s22, #12288                // row 6
    @p3 v.st.w       [s25, #0], v1
    a.vread      v1, a0, s26
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    s.movz       s25, #7
    p.and        p3, p5, p1
    s.addi       s26, s21, #9
    v.splat      v4, s26
    s.addi       s26, s22, #14336                // row 7
    @p4 v.st.w       [s19, #0], v1
    a.vread      v1, a0, s20
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    s.movz       s19, #8
    p.and        p4, p5, p1
    s.addi       s20, s21, #10
    v.splat      v0, s20
    s.addi       s20, s22, #16384                // row 8
    @p3 v.st.w       [s2, #0], v1
    a.vread      v1, a0, s23
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    s.movz       s2, #9
    p.and        p3, p5, p1
    s.addi       s23, s21, #11
    v.splat      v5, s23
    s.addi       s23, s22, #18432                // row 9
    @p4 v.st.w       [s24, #0], v1
    a.vread      v1, a0, s25
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.movz       s24, #10
    p.and        p4, p5, p1
    s.addi       s25, s21, #12
    v.splat      v2, s25
    s.addi       s25, s22, #20480                // row 10
    @p3 v.st.w       [s26, #0], v1
    a.vread      v1, a0, s19
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    s.movz       s19, #11
    p.and        p3, p5, p1
    s.addi       s26, s21, #13
    v.splat      v4, s26
    s.addi       s26, s22, #22528                // row 11
    @p4 v.st.w       [s20, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    s.movz       s2, #12
    p.and        p4, p5, p1
    s.addi       s20, s21, #14
    v.splat      v0, s20
    s.addi       s20, s22, #24576                // row 12
    @p3 v.st.w       [s23, #0], v1
    a.vread      v1, a0, s24
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    s.movz       s23, #13
    p.and        p3, p5, p1
    s.addi       s24, s21, #15
    s.addi       s21, s22, #26624                // row 13
    v.splat      v5, s24
    s.movz       s24, #14
    @p4 v.st.w       [s25, #0], v1
    a.vread      v1, a0, s19
    v.cmp.lt     p4, v2, v3
    p.and        p5, p4, p2
    s.addi       s19, s22, #28672                // row 14
    p.and        p4, p5, p1
    s.movz       s25, #15
    s.addi       s27, s22, #30720                // row 15
    @p3 v.st.w       [s26, #0], v1
    a.vread      v1, a0, s2
    v.cmp.lt     p3, v4, v3
    p.and        p5, p3, p2
    p.and        p3, p5, p1
    @p4 v.st.w       [s20, #0], v1
    a.vread      v1, a0, s23
    v.cmp.lt     p4, v0, v3
    p.and        p5, p4, p2
    p.and        p4, p5, p1
    @p3 v.st.w       [s21, #0], v1
    a.vread      v0, a0, s24
    v.cmp.lt     p3, v5, v3
    p.and        p5, p3, p2
    p.and        p2, p5, p1
    @p4 v.st.w       [s19, #0], v0
    a.vread      v0, a0, s25
    @p2 v.st.w       [s27, #0], v0
__rctx_next:
    s.addi       s2, s16, #2                     // the next program of this context: + 2
    s.cmp.lt     s19, s2, s17
    s.mov        s16, s2
    br.nz        s19, __rctx_program
    exit
