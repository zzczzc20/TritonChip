    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    v.movi       v0, #16
    v.movi       v1, #64
    v.movi       v2, #0
    v.movi       v3, #1024
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #32
    v.movi       v6, #48
    v.movi       v7, #80
    v.movi       v8, #96
    v.movi       v9, #112
    v.sub        v10, v2, v0
    v.sub        v11, v2, v1
    v.sub        v12, v2, v3
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (0 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
    v.add        v13, v4, v0
    v.add        v14, v4, v5
    v.add        v15, v4, v6
    v.add        v6, v4, v1
    v.add        v16, v4, v7
    v.add        v7, v4, v8
    v.add        v8, v4, v9
    @p1 v.sel        v9, v10, v0
    v.cmp.lt     p1, v3, v2
    v.movi       v9, #15
    v.movi       v10, #4
    @p2 v.sel        v17, v11, v1
    v.movi       v1, #63
    @p1 v.sel        v11, v12, v3
    v.movi       v3, #10
    v.movi       v11, #128
tiles_1:
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s9, s1, s8
    v.splat      v12, s9
    v.add        v17, v12, v4
    v.add        v18, v12, v13
    v.add        v19, v12, v14
    v.add        v20, v12, v15
    v.add        v21, v12, v6
    v.add        v22, v12, v16
    v.add        v23, v12, v7
    v.add        v24, v12, v8
    v.sub        v12, v2, v17
    v.sub        v25, v2, v18
    v.sub        v26, v2, v19
    v.sub        v27, v2, v20
    v.sub        v28, v2, v21
    v.sub        v29, v2, v22
    v.sub        v30, v2, v23
    v.sub        v31, v2, v24
    v.cmp.lt     p1, v17, v2
    v.cmp.lt     p2, v18, v2
    v.cmp.lt     p3, v19, v2
    v.cmp.lt     p4, v20, v2
    v.cmp.lt     p5, v21, v2
    v.cmp.lt     p6, v22, v2
    v.cmp.lt     p7, v23, v2
    v.cmp.lt     p8, v24, v2
    @p1 v.sel        v32, v12, v17
    @p2 v.sel        v12, v25, v18
    @p3 v.sel        v17, v26, v19
    @p4 v.sel        v18, v27, v20
    @p5 v.sel        v19, v28, v21
    @p6 v.sel        v20, v29, v22
    @p7 v.sel        v21, v30, v23
    @p8 v.sel        v22, v31, v24
    v.lshr       v23, v32, v10
    v.and        v24, v32, v9
    v.lshr       v25, v12, v10
    v.sub        v26, v2, v23
    v.and        v27, v12, v9
    v.and        v28, v17, v9
    @p1 v.sel        v29, v26, v23
    v.and        v23, v18, v9
    v.and        v26, v19, v9
    v.and        v30, v20, v9
    v.and        v31, v21, v9
    v.and        v33, v22, v9
    v.sub        v34, v2, v24
    v.sub        v35, v2, v25
    v.sub        v36, v2, v27
    v.sub        v37, v2, v28
    v.sub        v38, v2, v23
    v.sub        v39, v2, v26
    v.sub        v40, v2, v30
    v.sub        v41, v2, v31
    v.sub        v42, v2, v33
    @p1 v.sel        v43, v34, v24
    v.lshr       v24, v17, v10
    v.lshr       v34, v18, v10
    @p2 v.sel        v44, v35, v25
    v.sub        v25, v2, v24
    v.sub        v35, v2, v34
    @p2 v.sel        v45, v36, v27
    v.lshr       v27, v19, v10
    v.lshr       v36, v20, v10
    @p3 v.sel        v46, v25, v24
    v.sub        v24, v2, v27
    v.sub        v25, v2, v36
    @p4 v.sel        v47, v35, v34
    @p5 v.sel        v34, v24, v27
    @p3 v.sel        v24, v37, v28
    v.lshr       v27, v21, v10
    v.lshr       v28, v22, v10
    @p6 v.sel        v35, v25, v36
    v.sub        v25, v2, v27
    v.sub        v36, v2, v28
    @p4 v.sel        v37, v38, v23
    @p7 v.sel        v23, v25, v27
    @p8 v.sel        v25, v36, v28
    v.sub        v27, v2, v29
    v.cmp.lt     p9, v29, v2
    @p5 v.sel        v28, v39, v26
    v.sub        v26, v2, v44
    v.cmp.lt     p10, v44, v2
    @p9 v.sel        v36, v27, v29
    @p10 v.sel        v27, v26, v44
    @p6 v.sel        v26, v40, v30
    v.sub        v30, v2, v46
    v.and        v38, v36, v1
    v.and        v36, v27, v1
    @p7 v.sel        v27, v41, v31
    v.sub        v31, v2, v47
    @p8 v.sel        v39, v42, v33
    v.sub        v33, v2, v34
    v.sub        v40, v2, v35
    v.sub        v41, v2, v23
    v.sub        v42, v2, v25
    v.lshr       v48, v32, v3
    v.lshr       v32, v12, v3
    v.sub        v12, v2, v38
    v.sub        v49, v2, v48
    v.sub        v50, v2, v32
    v.sub        v51, v2, v36
    @p1 v.sel        v52, v49, v48
    v.cmp.lt     p1, v46, v2
    @p1 v.sel        v48, v30, v46
    @p9 v.sel        v30, v12, v38
    v.cmp.lt     p9, v47, v2
    @p9 v.sel        v12, v31, v47
    v.lshr       v31, v17, v3
    v.lshr       v17, v18, v3
    v.and        v18, v48, v1
    v.and        v38, v12, v1
    v.sub        v12, v2, v31
    v.sub        v48, v2, v17
    v.sub        v49, v2, v18
    v.sub        v53, v2, v38
    @p2 v.sel        v54, v50, v32
    v.cmp.lt     p2, v34, v2
    @p2 v.sel        v32, v33, v34
    @p3 v.sel        v33, v12, v31
    v.cmp.lt     p3, v35, v2
    @p3 v.sel        v12, v40, v35
    v.and        v31, v32, v1
    @p10 v.sel        v32, v51, v36
    v.cmp.lt     p10, v23, v2
    @p10 v.sel        v36, v41, v23
    v.lshr       v40, v19, v3
    v.lshr       v19, v20, v3
    v.and        v20, v12, v1
    v.and        v12, v36, v1
    v.sub        v36, v2, v40
    v.sub        v41, v2, v19
    v.sub        v50, v2, v31
    v.sub        v51, v2, v20
    v.sub        v55, v2, v12
    @p4 v.sel        v56, v48, v17
    v.cmp.lt     p4, v25, v2
    @p4 v.sel        v17, v42, v25
    @p5 v.sel        v42, v36, v40
    @p1 v.sel        v36, v49, v18
    v.lshr       v18, v21, v3
    v.lshr       v21, v22, v3
    v.and        v22, v17, v1
    v.sub        v17, v2, v18
    v.sub        v40, v2, v21
    v.sub        v48, v2, v22
    @p6 v.sel        v49, v41, v19
    @p7 v.sel        v19, v17, v18
    @p9 v.sel        v17, v53, v38
    @p8 v.sel        v18, v40, v21
    @p2 v.sel        v21, v50, v31
    @p3 v.sel        v31, v51, v20
    @p10 v.sel        v20, v55, v12
    @p4 v.sel        v12, v48, v22
    v.add        v22, v43, v0
    v.add        v38, v45, v0
    v.add        v40, v24, v0
    v.add        v41, v37, v0
    v.add        v48, v28, v0
    v.add        v50, v26, v0
    v.add        v51, v27, v0
    v.add        v53, v39, v0
    v.mul        v55, v52, v5
    v.mul        v52, v54, v5
    v.mul        v54, v33, v5
    v.mul        v33, v56, v5
    v.mul        v56, v42, v5
    v.mul        v42, v49, v5
    v.mul        v49, v19, v5
    v.mul        v19, v18, v5
    v.add        v18, v22, v55
    v.add        v22, v38, v52
    v.add        v38, v40, v54
    v.add        v40, v41, v33
    v.add        v33, v48, v56
    v.add        v41, v50, v42
    v.add        v42, v51, v49
    v.add        v48, v53, v19
    v.mul        v19, v30, v11
    v.mul        v30, v32, v11
    v.mul        v32, v36, v11
    v.mul        v36, v17, v11
    v.mul        v17, v21, v11
    v.mul        v21, v31, v11
    v.mul        v31, v20, v11
    v.mul        v20, v12, v11
    v.add        v12, v18, v19
    v.add        v18, v22, v30
    v.add        v19, v38, v32
    v.add        v22, v40, v36
    v.add        v30, v33, v17
    v.add        v17, v41, v21
    v.add        v21, v42, v31
    v.add        v31, v48, v20
    v.ld.gather.h v20, [s3, v12]                 // index is in elements (ISA sec 9.1)
    v.mul        v12, v29, v5
    v.mul        v29, v44, v5
    v.mul        v32, v46, v5
    v.mul        v33, v47, v5
    v.mul        v36, v34, v5
    v.mul        v34, v35, v5
    v.mul        v35, v23, v5
    v.mul        v23, v25, v5
    v.add        v25, v43, v12
    v.add        v12, v45, v29
    v.add        v29, v24, v32
    v.add        v24, v37, v33
    v.add        v32, v28, v36
    v.ld.gather.h v28, [s3, v18]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v18, v20
    v.add        v20, v26, v34
    v.add        v26, v27, v35
    v.add        v27, v39, v23
    vf.neg       v23, v18
    vf.cvt.f32.f16 v18, v23
    v.ld.gather.h v23, [s3, v19]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v19, v28
    vf.neg       v28, v19
    vf.cvt.f32.f16 v19, v28
    v.ld.gather.h v28, [s3, v22]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v22, v23
    vf.neg       v23, v22
    vf.cvt.f32.f16 v22, v23
    v.ld.gather.h v23, [s3, v30]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v30, v28
    vf.neg       v28, v30
    vf.cvt.f32.f16 v30, v28
    v.ld.gather.h v28, [s3, v17]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v17, v23
    vf.neg       v23, v17
    vf.cvt.f32.f16 v17, v23
    v.ld.gather.h v23, [s3, v21]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v21, v28
    vf.neg       v28, v21
    vf.cvt.f32.f16 v21, v28
    v.ld.gather.h v28, [s3, v31]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v31, v23
    vf.neg       v23, v31
    vf.cvt.f32.f16 v31, v23
    vf.cvt.f16.f32 v23, v28
    v.st.scatter.h [s7, v25], v18
    vf.neg       v18, v23
    vf.cvt.f32.f16 v23, v18
    v.st.scatter.h [s7, v12], v19
    v.st.scatter.h [s7, v29], v22
    v.st.scatter.h [s7, v24], v30
    v.st.scatter.h [s7, v32], v17
    v.st.scatter.h [s7, v20], v21
    v.st.scatter.h [s7, v26], v31
    v.st.scatter.h [s7, v27], v23
    s.addi       s8, s8, #128
    s.cmp.lt     s9, s8, s2
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
