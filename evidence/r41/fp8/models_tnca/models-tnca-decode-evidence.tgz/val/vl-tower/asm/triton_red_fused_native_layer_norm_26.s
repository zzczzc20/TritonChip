    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // out_ptr1: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s7, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s8, #256
    s.mul        s9, s1, s8
    s.add        s1, s7, s9                      // this context's own scratch
    s.addi       s7, s1, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s1, #0
    s.st.d       [s7, #0], s2
    s.movz       s1, #256
    s.st.d       [s7, #8], s1
    s.movz       s1, #1024
    s.st.d       [s7, #16], s1
    s.movz       s1, #2048
    s.st.d       [s7, #48], s1
    s.movz       s1, #2
    s.st.d       [s7, #56], s1
    .li       s1, #68719476737
    s.st.d       [s7, #88], s1
    .li       s1, #1108101562368
    s.st.d       [s7, #104], s1
    fence.release.device
    td.load      d0, [s7]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #0
    s.movz       s7, #1024
    s.movz       s8, #16
    v.splat      v0, s4
    v.iota       v0                              // arange(0, VLEN)
    s.addi       s9, s1, #0
    v.movi       v1, #0
    v.movi       v2, #0
    v.mov        v2, v1
for_1:
    s.cmp.ge     s10, s9, s7
    br.nz        s10, endfor_2
    s.muli       s10, s4, #2048
    v.splat      v3, s9
    v.iota       v4                              // arange(0, VLEN)
    s.movz       s11, #1024
    s.movz       s12, #256
    s.muli       s13, s9, #2
    v.add        v5, v3, v4
    v.movi       v3, #0
    v.splat      v4, s11
    v.splat      v6, s4
    v.movi       v7, #0
    v.splat      v8, s12
    v.cmp.ge     p1, v5, v3
    v.cmp.lt     p2, v5, v4
    v.cmp.ge     p3, v6, v7
    v.cmp.lt     p4, v6, v8
    s.add        s11, s2, s10
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s10, s11, s13
    p.and        p2, p5, p1
    v.splat      v3, s9
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s10, #0]
    v.add        v5, v3, v0
    v.movi       v3, #1024
    v.movi       v6, #0
    v.cmp.lt     p1, v5, v3
    s.add        s10, s9, s8
    vf.cvt.bf16.f32 v3, v4
    s.movz       s11, #1
    vf.add       v4, v2, v3
    @p1 v.sel        v3, v4, v2
    v.mov        v6, v3
    v.mov        v2, v6
    s.mov        s9, s10
    br.nz        s11, for_1
endfor_2:
    .li       s9, #1149239296
    v.splat      v3, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s9, #1065353216
    v.splat      v4, s9                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v5, v3                          // ISA 8.8: <= 2**-22 relative
    vf.reduce.add.b v6, v2
    v.movi       v2, #0
    v.movi       v7, #0
    vf.add       v8, v6, v2
    s.addi       s9, s1, #0
    v.mov        v7, v1
    vf.fms       v1, v3, v5, v4
    vf.fms       v6, v5, v1, v5
    vf.neg       v1, v6                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v6, v1, v5
    vf.mul       v1, v8, v6                      // a/y: faithful quotient
    vf.fms       v5, v1, v3, v8
    vf.fms       v8, v5, v6, v1
    vf.neg       v5, v8                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v5, v5
    @p1 v.sel        v6, v5, v1
for_3:
    s.cmp.ge     s10, s9, s7
    br.nz        s10, endfor_4
    s.muli       s10, s4, #2048
    v.splat      v1, s9
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s11, #1024
    s.movz       s12, #256
    s.muli       s13, s9, #2
    v.add        v8, v1, v5
    v.movi       v1, #0
    v.splat      v5, s11
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s12
    v.cmp.ge     p1, v8, v1
    v.cmp.lt     p2, v8, v5
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    s.add        s11, s2, s10
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s10, s11, s13
    p.and        p2, p5, p1
    v.extract    s11, v6, #0
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s10, #0]
    v.splat      v5, s11
    v.splat      v8, s9
    v.movi       v9, #1024
    v.add        v10, v8, v0
    v.movi       v8, #0
    vf.cvt.bf16.f32 v11, v1
    v.cmp.lt     p1, v10, v9
    s.add        s10, s9, s8
    s.movz       s11, #1
    vf.sub       v1, v11, v5
    vf.mul       v5, v1, v1
    vf.add       v1, v7, v5
    @p1 v.sel        v5, v1, v7
    v.mov        v8, v5
    v.mov        v7, v8
    s.mov        s9, s10
    br.nz        s11, for_3
endfor_4:
    vf.reduce.add.b v1, v7
    s.addi       s9, s1, #0
    vf.add       v5, v1, v2
for_5:
    s.cmp.ge     s1, s9, s7
    br.nz        s1, endfor_6
    v.rcp.approx v1, v3                          // ISA 8.8: <= 2**-22 relative
    s.muli       s1, s4, #2048
    v.splat      v2, s9
    v.iota       v7                              // arange(0, VLEN)
    s.movz       s10, #1024
    s.movz       s11, #256
    s.muli       s12, s9, #2
    v.add        v8, v2, v7
    v.movi       v2, #0
    v.splat      v7, s10
    v.splat      v9, s4
    v.movi       v10, #0
    v.splat      v11, s11
    v.cmp.ge     p1, v8, v2
    v.cmp.lt     p2, v8, v7
    v.cmp.ge     p3, v9, v10
    v.cmp.lt     p4, v9, v11
    s.add        s10, s2, s1
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s1, s10, s12
    p.and        p2, p5, p1
    v.splat      v2, s9
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v7, [s1, #0]
    s.shli       s1, s9, #1                      // element offset -> bytes (x2)
    v.add        v8, v2, v0
    .li       s10, #897988541
    v.splat      v2, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v9, v3, v1, v4
    v.movi       v10, #1024
    vf.cvt.bf16.f32 v11, v7
    s.add        s10, s3, s1                     // &in_ptr1[...]
    vf.fms       v7, v1, v9, v1
    v.cmp.lt     p1, v8, v10
    .li       s11, #1077936128
    v.splat      v9, s11                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s11, #3204448256
    v.splat      v10, s11                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.neg       v12, v7                         // Newton step: r0*(2 - x*r0)
    v.extract    s11, v6, #0
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v7, [s10, #0]
    v.splat      v13, s11
    vf.cmp.o     p2, v12, v12
    @p2 v.sel        v14, v12, v1
    s.add        s10, s5, s1                     // &in_ptr2[...]
    vf.mul       v1, v5, v14                     // a/y: faithful quotient
    vf.sub       v12, v11, v13
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v11, [s10, #0]
    vf.cvt.bf16.f32 v13, v7
    vf.fms       v7, v1, v3, v5
    s.mul        s1, s4, s7
    s.add        s10, s9, s8
    s.movz       s11, #1
    vf.fms       v15, v7, v14, v1
    vf.cvt.bf16.f32 v7, v11
    s.add        s12, s9, s1
    v.splat      v11, s1
    vf.neg       v14, v15                        // a/y: one correction to the IEEE quotient
    s.shli       s1, s12, #1                     // element offset -> bytes (x2)
    v.add        v15, v8, v11
    s.add        s12, s6, s1                     // &out_ptr1[...]
    vf.cmp.o     p2, v14, v14
    @p2 v.sel        v8, v14, v1
    vf.add       v1, v8, v2
    v.rsqrt.approx v2, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v8, v2, v2
    vf.mul       v11, v2, v10
    vf.fms       v10, v1, v8, v9
    vf.mul       v1, v11, v10                    // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v8, v1, v2
    v.extract    s1, v8, #0
    v.splat      v1, s1
    vf.mul       v2, v12, v1
    vf.mul       v1, v2, v13
    vf.add       v2, v1, v7
    vf.cvt.f32.bf16 v1, v2
    @p1 v.st.h       [s12, #0], v1
    s.mov        s9, s10
    br.nz        s11, for_5
endfor_6:
__rctx_next:
    exit
