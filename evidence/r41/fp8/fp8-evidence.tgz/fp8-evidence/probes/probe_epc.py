import os, sys
ROOT = os.path.expanduser(os.environ.get('ROOT', '~/r41-fp8-audit/cand2'))
sys.path[:0] = [ROOT, ROOT+'/python', ROOT+'/compiler/python', ROOT+'/tools/asm', ROOT+'/tools/performance_harness/systemc', ROOT+'/tools/performance_harness']
os.environ.update(TNCA_PROFILE='core-vrf-sync-v5', TNCA_TORCH_DEVICE='native', TNCA_INDEX_OPT='1')
os.environ.setdefault('TNCA_BACKEND', 'systemc-tlm-grid')
os.environ.setdefault('TNCA_TLM_BINARY', os.path.expanduser('~/r41-fp8-build/tnca-chip'))
import torch, triton, tnca, tlm_backend
tlm_backend.register()
import tnca.torch_device as D; D.register()
import torch._inductor.config as ic
from fp8_cases import w8a8_linear, compare, summary_of
ic.emulate_precision_casts = True
g = torch.Generator().manual_seed(23)
for lead, K, N in [((16,), 64, 32), ((64,), 256, 192)]:
    x = (torch.randn(*lead, K, generator=g) * 2).to(torch.bfloat16)
    w = (torch.randn(N, K, generator=g) * torch.pow(2.0, torch.randint(-2, 3, (N, K), generator=g).float())).to(torch.float8_e4m3fn)
    ws, xs = torch.tensor(0.0213), torch.tensor(0.0157)
    bias = torch.randn(N, generator=g).to(torch.bfloat16)
    torch._dynamo.reset()
    f = torch.compile(w8a8_linear, backend='inductor', fullgraph=True)
    q, y = f(x.to('tnca'), w.to('tnca'), ws.to('tnca'), xs.to('tnca'), bias.to('tnca'))
    qe, ye = w8a8_linear(x, w, ws, xs, bias)
    cq, cy = compare(q.cpu(), qe), compare(y.cpu(), ye)
    print(lead, K, N, 'emulate_precision_casts: q vs eager:', summary_of(cq), '| y vs eager:', summary_of(cy), cy.get('max_ulp_diff'))
