    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    v.movi       v2, #4
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.splat      v3, s2
    v.movi       v4, #32
    s.movz       s4, #16
    v.add        v5, v3, v0
    s.movz       s5, #16
    s.movz       s6, #16
    v.sub        v0, v1, v5
    v.cmp.lt     p1, v5, v1
    v.cmp.lt     p2, v5, v4
    @p1 v.sel        v3, v0, v5
    s.addi       s7, s3, #4
    s.ld.d       s8, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.lshr       v0, v3, v2
    s.movz       s9, #16
    s.movz       s10, #16
    v.sub        v2, v1, v0
    s.movz       s11, #16
    s.movz       s12, #16
    @p1 v.sel        v3, v2, v0
    s.movz       s13, #16
    s.movz       s14, #16
    s.movz       s15, #16
    s.ld.d       s16, [s1, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    v.movi       v0, #1
    v.movi       v2, #0
    v.movi       v4, #0
    v.shl        v6, v3, v0
    v.movi       v0, #0
    s.movz       s1, #16
    s.movz       s17, #16
    v.sub        v3, v0, v5
    v.cmp.lt     p1, v5, v0
    v.movi       v7, #15
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s7, v6]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v9, v3, v5
    s.movz       s7, #16
    s.movz       s18, #16
    v.and        v3, v9, v7
    s.movz       s19, #16
    s.movz       s20, #16
    v.sub        v5, v0, v3
    v.movi       v7, #16
    s.movz       s21, #0
    @p1 v.sel        v9, v5, v3
    v.sub        v3, v1, v7
    v.sub        v5, v0, v7
    v.cmp.lt     p1, v7, v1
    v.cmp.lt     p3, v7, v0
    v.movi       v0, #1
    @p1 v.sel        v0, v3, v7
    v.movi       v0, #1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v0, [s3, v6]               // index is in elements (ISA sec 9.1)
    v.extract    s3, v8, #0
    v.extract    s22, v8, #1
    s.shli       s23, s3, #32
    s.shli       s3, s22, #32
    v.extract    s22, v8, #2
    v.extract    s24, v8, #3
    s.shli       s25, s22, #32
    s.shli       s22, s24, #32
    v.extract    s24, v8, #4
    @p3 v.sel        v1, v5, v7
    s.shli       s26, s24, #32
    v.extract    s24, v8, #5
    s.shli       s27, s24, #32
    v.extract    s24, v0, #0
    s.or         s28, s24, s23
    v.extract    s23, v0, #1
    s.mul        s24, s28, s4
    s.or         s4, s23, s3
    v.extract    s3, v0, #2
    s.mul        s23, s4, s5
    s.or         s4, s3, s25
    s.lshri      s3, s24, #32
    v.extract    s5, v0, #3
    s.mul        s25, s4, s6
    v.insert     v2, s24, #0
    v.insert     v4, s3, #0
    s.or         s3, s5, s22
    s.lshri      s4, s23, #32
    v.extract    s5, v0, #4
    s.mul        s6, s3, s9
    v.insert     v2, s23, #1
    v.insert     v4, s4, #1
    s.or         s3, s5, s26
    s.lshri      s4, s25, #32
    v.extract    s5, v0, #5
    s.mul        s9, s3, s10
    v.extract    s3, v8, #6
    v.insert     v2, s25, #2
    v.insert     v4, s4, #2
    s.or         s4, s5, s27
    s.lshri      s5, s6, #32
    v.extract    s10, v0, #6
    s.shli       s22, s3, #32
    s.mul        s3, s4, s11
    v.extract    s4, v8, #7
    v.insert     v2, s6, #3
    v.insert     v4, s5, #3
    s.or         s5, s10, s22
    s.lshri      s6, s9, #32
    v.extract    s10, v0, #7
    s.shli       s11, s4, #32
    s.mul        s4, s5, s12
    v.extract    s5, v8, #8
    v.insert     v2, s9, #4
    v.insert     v4, s6, #4
    s.or         s6, s10, s11
    s.lshri      s9, s3, #32
    v.extract    s10, v0, #8
    s.shli       s11, s5, #32
    s.mul        s5, s6, s13
    v.extract    s6, v8, #9
    v.insert     v2, s3, #5
    v.insert     v4, s9, #5
    s.or         s3, s10, s11
    s.lshri      s9, s4, #32
    v.extract    s10, v0, #9
    s.shli       s11, s6, #32
    s.mul        s6, s3, s14
    v.extract    s3, v8, #10
    v.insert     v2, s4, #6
    v.insert     v4, s9, #6
    s.or         s4, s10, s11
    s.lshri      s9, s5, #32
    v.extract    s10, v0, #10
    s.shli       s11, s3, #32
    s.mul        s3, s4, s15
    v.extract    s4, v8, #11
    v.insert     v2, s5, #7
    v.insert     v4, s9, #7
    s.or         s5, s10, s11
    s.lshri      s9, s6, #32
    v.extract    s10, v0, #11
    s.shli       s11, s4, #32
    s.mul        s4, s5, s1
    v.extract    s1, v8, #12
    v.insert     v2, s6, #8
    v.insert     v4, s9, #8
    s.or         s5, s10, s11
    s.lshri      s6, s3, #32
    v.extract    s9, v0, #12
    s.shli       s10, s1, #32
    s.mul        s1, s5, s17
    v.extract    s5, v8, #13
    v.insert     v2, s3, #9
    v.insert     v4, s6, #9
    s.or         s3, s9, s10
    s.lshri      s6, s4, #32
    v.extract    s9, v0, #13
    s.shli       s10, s5, #32
    s.mul        s5, s3, s7
    v.extract    s3, v8, #14
    v.insert     v2, s4, #10
    v.insert     v4, s6, #10
    s.or         s4, s9, s10
    s.lshri      s6, s1, #32
    v.extract    s7, v0, #14
    s.shli       s9, s3, #32
    s.mul        s3, s4, s18
    v.extract    s4, v8, #15
    v.insert     v2, s1, #11
    v.insert     v4, s6, #11
    s.or         s1, s7, s9
    s.lshri      s6, s5, #32
    v.extract    s7, v0, #15
    s.shli       s9, s4, #32
    s.mul        s4, s1, s19
    v.insert     v2, s5, #12
    v.insert     v4, s6, #12
    s.or         s1, s7, s9
    s.lshri      s5, s3, #32
    v.extract    s6, v9, #0
    s.mul        s7, s1, s20
    v.insert     v2, s3, #13
    v.insert     v4, s5, #13
    s.shli       s1, s6, #32
    s.lshri      s3, s4, #32
    v.extract    s5, v9, #1
    s.ashri      s6, s1, #32
    v.insert     v2, s4, #14
    v.insert     v4, s3, #14
    v.movi       v0, #0
    v.movi       v1, #0
    s.shli       s1, s5, #32
    s.lshri      s3, s7, #32
    s.lshri      s4, s6, #32
    v.extract    s5, v9, #2
    s.ashri      s9, s1, #32
    v.insert     v2, s7, #15
    v.insert     v4, s3, #15
    v.insert     v0, s6, #0
    v.insert     v1, s4, #0
    s.shli       s1, s5, #32
    s.lshri      s3, s9, #32
    v.extract    s4, v9, #3
    s.ashri      s5, s1, #32
    v.insert     v0, s9, #1
    v.insert     v1, s3, #1
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v9, #4
    s.ashri      s6, s1, #32
    v.insert     v0, s5, #2
    v.insert     v1, s3, #2
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v9, #5
    s.ashri      s5, s1, #32
    v.insert     v0, s6, #3
    v.insert     v1, s3, #3
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v9, #6
    s.ashri      s6, s1, #32
    v.insert     v0, s5, #4
    v.insert     v1, s3, #4
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v9, #7
    s.ashri      s5, s1, #32
    v.insert     v0, s6, #5
    v.insert     v1, s3, #5
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v9, #8
    s.ashri      s6, s1, #32
    v.insert     v0, s5, #6
    v.insert     v1, s3, #6
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v9, #9
    s.ashri      s5, s1, #32
    v.insert     v0, s6, #7
    v.insert     v1, s3, #7
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v9, #10
    s.ashri      s6, s1, #32
    v.insert     v0, s5, #8
    v.insert     v1, s3, #8
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v9, #11
    s.ashri      s5, s1, #32
    v.insert     v0, s6, #9
    v.insert     v1, s3, #9
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v9, #12
    s.ashri      s6, s1, #32
    v.insert     v0, s5, #10
    v.insert     v1, s3, #10
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v9, #13
    s.ashri      s5, s1, #32
    v.insert     v0, s6, #11
    v.insert     v1, s3, #11
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v9, #14
    s.ashri      s6, s1, #32
    v.insert     v0, s5, #12
    v.insert     v1, s3, #12
    s.shli       s1, s4, #32
    s.lshri      s3, s6, #32
    v.extract    s4, v9, #15
    s.ashri      s5, s1, #32
    v.insert     v0, s6, #13
    v.insert     v1, s3, #13
    s.shli       s1, s4, #32
    s.lshri      s3, s5, #32
    s.ashri      s4, s1, #32
    v.insert     v0, s5, #14
    v.insert     v1, s3, #14
    s.lshri      s1, s4, #32
    v.insert     v0, s4, #15
    v.insert     v1, s1, #15
    v.extract    s1, v4, #0
    v.extract    s3, v0, #0
    v.extract    s4, v1, #0
    v.extract    s5, v2, #0
    s.shli       s6, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v1, #1
    v.extract    s7, v4, #1
    s.or         s9, s3, s6
    s.or         s3, s5, s4
    v.movi       v3, #0
    v.extract    s4, v0, #1
    s.shli       s5, s1, #32
    v.extract    s1, v2, #1
    s.shli       s6, s7, #32
    s.add        s7, s9, s3
    v.extract    s3, v1, #2
    v.extract    s9, v4, #2
    s.or         s10, s4, s5
    s.or         s4, s1, s6
    v.movi       v5, #0
    v.insert     v3, s7, #0
    v.extract    s1, v0, #2
    s.shli       s5, s3, #32
    v.extract    s3, v2, #2
    s.shli       s6, s9, #32
    s.lshri      s9, s7, #32
    s.add        s7, s10, s4
    v.extract    s4, v1, #3
    v.extract    s10, v4, #3
    s.or         s11, s1, s5
    s.or         s1, s3, s6
    v.insert     v5, s9, #0
    v.insert     v3, s7, #1
    v.extract    s3, v0, #3
    s.shli       s5, s4, #32
    v.extract    s4, v2, #3
    s.shli       s6, s10, #32
    s.lshri      s9, s7, #32
    s.add        s7, s11, s1
    v.extract    s1, v1, #4
    v.extract    s10, v4, #4
    s.or         s11, s3, s5
    s.or         s3, s4, s6
    v.insert     v5, s9, #1
    v.insert     v3, s7, #2
    v.extract    s4, v0, #4
    s.shli       s5, s1, #32
    v.extract    s1, v2, #4
    s.shli       s6, s10, #32
    s.lshri      s9, s7, #32
    s.add        s7, s11, s3
    v.extract    s3, v1, #5
    v.extract    s10, v4, #5
    s.or         s11, s4, s5
    s.or         s4, s1, s6
    v.insert     v5, s9, #2
    v.insert     v3, s7, #3
    v.extract    s1, v0, #5
    s.shli       s5, s3, #32
    v.extract    s3, v2, #5
    s.shli       s6, s10, #32
    s.lshri      s9, s7, #32
    s.add        s7, s11, s4
    v.extract    s4, v1, #6
    v.extract    s10, v4, #6
    s.or         s11, s1, s5
    s.or         s1, s3, s6
    v.insert     v5, s9, #3
    v.insert     v3, s7, #4
    v.extract    s3, v0, #6
    s.shli       s5, s4, #32
    v.extract    s4, v2, #6
    s.shli       s6, s10, #32
    s.lshri      s9, s7, #32
    s.add        s7, s11, s1
    v.extract    s1, v1, #7
    v.extract    s10, v4, #7
    s.or         s11, s3, s5
    s.or         s3, s4, s6
    v.insert     v5, s9, #4
    v.insert     v3, s7, #5
    v.extract    s4, v0, #7
    s.shli       s5, s1, #32
    v.extract    s1, v2, #7
    s.shli       s6, s10, #32
    s.lshri      s9, s7, #32
    s.add        s7, s11, s3
    v.extract    s3, v1, #8
    v.extract    s10, v4, #8
    s.or         s11, s4, s5
    s.or         s4, s1, s6
    v.insert     v5, s9, #5
    v.insert     v3, s7, #6
    v.extract    s1, v0, #8
    s.shli       s5, s3, #32
    v.extract    s3, v2, #8
    s.shli       s6, s10, #32
    s.lshri      s9, s7, #32
    s.add        s7, s11, s4
    v.extract    s4, v1, #9
    v.extract    s10, v4, #9
    s.or         s11, s1, s5
    s.or         s1, s3, s6
    v.insert     v5, s9, #6
    v.insert     v3, s7, #7
    v.extract    s3, v0, #9
    s.shli       s5, s4, #32
    v.extract    s4, v2, #9
    s.shli       s6, s10, #32
    s.lshri      s9, s7, #32
    s.add        s7, s11, s1
    v.extract    s1, v1, #10
    v.extract    s10, v4, #10
    s.or         s11, s3, s5
    s.or         s3, s4, s6
    v.insert     v5, s9, #7
    v.insert     v3, s7, #8
    v.extract    s4, v0, #10
    s.shli       s5, s1, #32
    v.extract    s1, v2, #10
    s.shli       s6, s10, #32
    s.lshri      s9, s7, #32
    s.add        s7, s11, s3
    v.extract    s3, v1, #11
    v.extract    s10, v4, #11
    s.or         s11, s4, s5
    s.or         s4, s1, s6
    v.insert     v5, s9, #8
    v.insert     v3, s7, #9
    v.extract    s1, v0, #11
    s.shli       s5, s3, #32
    v.extract    s3, v2, #11
    s.shli       s6, s10, #32
    s.lshri      s9, s7, #32
    s.add        s7, s11, s4
    v.extract    s4, v1, #12
    v.extract    s10, v4, #12
    s.or         s11, s1, s5
    s.or         s1, s3, s6
    v.insert     v5, s9, #9
    v.insert     v3, s7, #10
    v.extract    s3, v0, #12
    s.shli       s5, s4, #32
    v.extract    s4, v2, #12
    s.shli       s6, s10, #32
    s.lshri      s9, s7, #32
    s.add        s7, s11, s1
    v.extract    s1, v1, #13
    v.extract    s10, v4, #13
    s.or         s11, s3, s5
    s.or         s3, s4, s6
    v.insert     v5, s9, #10
    v.insert     v3, s7, #11
    v.extract    s4, v0, #13
    s.shli       s5, s1, #32
    v.extract    s1, v2, #13
    s.shli       s6, s10, #32
    s.lshri      s9, s7, #32
    s.add        s7, s11, s3
    v.extract    s3, v1, #14
    v.extract    s10, v4, #14
    s.or         s11, s4, s5
    s.or         s4, s1, s6
    v.insert     v5, s9, #11
    v.insert     v3, s7, #12
    v.extract    s1, v0, #14
    s.shli       s5, s3, #32
    v.extract    s3, v2, #14
    s.shli       s6, s10, #32
    s.lshri      s9, s7, #32
    s.add        s7, s11, s4
    v.extract    s4, v1, #15
    v.extract    s10, v4, #15
    s.or         s11, s1, s5
    s.or         s1, s3, s6
    v.insert     v5, s9, #12
    v.insert     v3, s7, #13
    v.extract    s3, v0, #15
    s.shli       s5, s4, #32
    v.extract    s4, v2, #15
    s.shli       s6, s10, #32
    s.lshri      s9, s7, #32
    s.add        s7, s11, s1
    s.or         s1, s3, s5
    s.or         s3, s4, s6
    v.insert     v5, s9, #13
    v.insert     v3, s7, #14
    s.lshri      s4, s7, #32
    s.add        s5, s1, s3
    v.insert     v5, s4, #14
    v.insert     v3, s5, #15
    v.movi       v0, #31
    s.lshri      s1, s5, #32
    v.movi       v1, #1
    v.insert     v5, s1, #15
    v.ashr       v2, v3, v0
    v.movi       v0, #0
    v.cmp.ne     p1, v5, v2
    @p1 v.sel        v2, v1, v0
    v.reduce.or  s1, v2
    s.cmp.eq     s3, s1, s21
    br.nz        s3, narrow_ok_1
    trap         #677220
narrow_ok_1:
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.sb v0, [s8, v3]              // index is in elements (ISA sec 9.1)
    s.shli       s1, s2, #2                      // element offset -> bytes (x4)
    s.add        s2, s16, s1                     // &out_ptr0[...]
    vf.cvt.s32.f32 v1, v0
    @p2 v.st.w       [s2, #0], v1
__rctx_next:
    exit
