

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}, {'num_warps': 2, 'num_stages': 3}, {'num_warps': 2, 'num_stages': 4}, {'num_warps': 4, 'num_stages': 2}, {'num_warps': 4, 'num_stages': 3}, {'num_warps': 4, 'num_stages': 4}, {'num_warps': 8, 'num_stages': 2}, {'num_warps': 8, 'num_stages': 3}, {'num_warps': 8, 'num_stages': 4}, {'num_warps': 16, 'num_stages': 2}, {'num_warps': 16, 'num_stages': 3}, {'num_warps': 16, 'num_stages': 4}],
    inductor_meta={'grid_type': 'PrecomputedGrid', 'precomputed_grids': [{'config': {'num_warps': 2, 'num_stages': 2}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 2, 'num_stages': 3}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 2, 'num_stages': 4}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 4, 'num_stages': 2}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 4, 'num_stages': 3}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 4, 'num_stages': 4}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 8, 'num_stages': 2}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 8, 'num_stages': 3}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 8, 'num_stages': 4}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 16, 'num_stages': 2}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 16, 'num_stages': 3}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}, {'config': {'num_warps': 16, 'num_stages': 4}, 'python': ['1', '48', '1'], 'cpp': ['1L', '48L', '1L'], 'python_slow': ['1', '48', '1']}], 'extra_launcher_args': [], 'declared_constexpr_names': ['BLOCK_SIZE_M', 'BLOCK_SIZE_N', 'BLOCK_SIZE_K', 'GROUP_SIZE_M'], 'kernel_name': 'w8a8_block_fp8_matmul_kernel_1', 'backend_hash': 'A93B31D6EDF73560C15AA73ED6DE7E8C6F4FC7BA4A2D9DB4959968968952E588', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    triton_meta={'signature': {'A': '*fp8e4nv', 'B': '*fp8e4nv', 'C': '*bf16', 'As': '*fp32', 'Bs': '*fp32', 'M': 'i32', 'N': 'i32', 'K': 'i32', 'stride_am': 'i32', 'stride_ak': 'constexpr', 'stride_bk': 'constexpr', 'stride_bn': 'i32', 'stride_cm': 'i32', 'stride_cn': 'constexpr', 'stride_as_m': 'i32', 'stride_as_k': 'constexpr', 'stride_bs_k': 'constexpr', 'stride_bs_n': 'i32', 'BLOCK_SIZE_M': 'constexpr', 'BLOCK_SIZE_N': 'constexpr', 'BLOCK_SIZE_K': 'constexpr', 'GROUP_SIZE_M': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'stride_ak': 1, 'stride_bk': 1, 'stride_cn': 1, 'stride_as_k': 1, 'stride_bs_k': 1, 'BLOCK_SIZE_M': 16, 'BLOCK_SIZE_N': 128, 'BLOCK_SIZE_K': 128, 'GROUP_SIZE_M': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (12,): [['tt.divisibility', 16]], (14,): [['tt.divisibility', 16]], (17,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def w8a8_block_fp8_matmul_kernel(
    # Pointers to inputs and output
    A,
    B,
    C,
    As,
    Bs,
    # Shape for matmul
    M,
    N,
    K,
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_as_m,
    stride_as_k,
    stride_bs_k,
    stride_bs_n,
    # Meta-parameters
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    """Block-scale FP8 GEMM kernel.

    Computes ``C = A @ B.T`` with block-wise activation/weight scales.
    Uses a 2D grid with swizzle for L2 cache locality on B tiles.
    """
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m, pid_n = tl.swizzle2d(pid_m, pid_n, num_pid_m, num_pid_n, GROUP_SIZE_M)

    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    as_ptrs = As + offs_am * stride_as_m
    offs_bsn = offs_bn // BLOCK_SIZE_N
    bs_ptrs = Bs + offs_bsn * stride_bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_remaining = K - k * BLOCK_SIZE_K
        a = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)

        a_s = tl.load(as_ptrs + k * stride_as_k)
        b_s = tl.load(bs_ptrs + k * stride_bs_k)

        accumulator += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk

    if C.dtype.element_ty == tl.bfloat16:
        c = accumulator.to(tl.bfloat16)
    elif C.dtype.element_ty == tl.float16:
        c = accumulator.to(tl.float16)
    else:
        c = accumulator.to(tl.float32)

    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)
