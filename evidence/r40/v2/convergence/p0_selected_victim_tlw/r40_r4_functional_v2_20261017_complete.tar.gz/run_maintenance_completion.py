from pathlib import Path
import subprocess,json,itertools
r=Path.cwd();out=r/'maintenance_completion';out.mkdir(exist_ok=False);records=[]
for latency,stall,full in itertools.product([1,8],[0,1],[0,1]):
 name=f'lat{latency}_stall{stall}_full{full}';binary=str(out/(name+'.vvp'))
 commands=[['iverilog','-g2012','-I','rtl/common','-s','tb_nuca_maintenance',f'-Ptb_nuca_maintenance.LATENCY={latency}',f'-Ptb_nuca_maintenance.STALL={stall}',f'-Ptb_nuca_maintenance.FULL_TAG={full}','-o',binary,'rtl/nuca/tnca_nuca_slice.v','tb/common/tnca_dram_model.v','tb/nuca/tb_nuca_maintenance.v'],['vvp',binary]]
 for phase,cmd in zip(['build','run'],commands):
  p=subprocess.run(cmd,capture_output=True,text=True,timeout=180);s=p.stdout+p.stderr;(out/(name+'_'+phase+'.log')).write_text(s);assert p.returncode==0,(name,phase,s)
 assert any(line.startswith('NUCA MAINTENANCE PASS ') for line in s.splitlines()) and 'FATAL' not in s and 'FAIL' not in s,s
 records.append(dict(name=name,status='functional-pass',stdout=s));(out/'report.json').write_text(json.dumps(records,indent=2)+'\n');print(name,'PASS',flush=True)
print('MAINTENANCE_COMPLETION_PASS',flush=True)
