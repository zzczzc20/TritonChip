from pathlib import Path
import json,subprocess,os,datetime,hashlib
home=Path.home();p=Path(__file__).parent;source=home/'tnca_src_r40_conditional_12a0340';image=home/'tnca_images/r40_attempt03_90mhz_a88ebdf5/tnca_u280.xclbin'
review=json.loads((home/'tnca_build/r40_attempt03_conditional_90mhz/preload_review.json').read_text())
assert review['decision'].startswith('approved for explicit load')
assert hashlib.sha256(image.read_bytes()).hexdigest()==review['image_sha256']
command=['bash',str(source/'flow/fpga/program.sh'),'--go',str(image)]
env=dict(os.environ,TNCA_BOARD='u280',BDF='0000:04:00.1',PATH='/opt/xilinx/xrt/bin:'+os.environ['PATH'])
state=dict(schema='tnca-attempt03-load/1',status='starting',image_sha256=review['image_sha256'],command=command,preload_review_sha256=hashlib.sha256((home/'tnca_build/r40_attempt03_conditional_90mhz/preload_review.json').read_bytes()).hexdigest(),scope='one explicitly authorized image load; no retry or reset; actual clock/workload qualification separate')
def save():
 state['observed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();f=p/'state.tmp';f.write_text(json.dumps(state,indent=2)+'\n');f.replace(p/'state.json')
save()
with (p/'program.log').open('x') as log:
 q=subprocess.Popen(command,env=env,cwd=source,stdout=log,stderr=subprocess.STDOUT)
 state.update(status='programming',loader_pid=q.pid);save()
 code=q.wait()
state.update(status='load-command-succeeded-verify-clock-next' if code==0 else 'load-failed-no-retry',exit_code=code);save()
