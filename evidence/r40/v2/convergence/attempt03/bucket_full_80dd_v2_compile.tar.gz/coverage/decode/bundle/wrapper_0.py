# AOT ID: ['1_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph

def get_raw_stream(_):
    return 0


aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /tmp/torchinductor_zhongchun/ks/ckswqisjqwaf4f4pxymhcek3lvmjwjyxman7orymvwj3ctaacdiv.py
# Topologically Sorted Source Nodes: [next_position], Original ATen: [aten.add]
# Source node to ATen node mapping:
#   next_position => add_33
# Graph fragment:
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %add_33 : Tensor "i64[1][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg4_1, 1), kwargs = {})
#   return %add_33
triton_poi_fused_add_0 = async_compile.triton('triton_poi_fused_add_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'out_ptr0': '*i64', 'xnumel': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_0(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp2 = tl.full([1], 1, tl.int64)
    tmp3 = tmp1 + tmp2
    tl.store(out_ptr0 + (tl.full([XBLOCK], 0, tl.int32).broadcast_to(XBLOCK)), tmp3, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/wg/cwgpq3auioqe66jmdt6mmkkyxoed3ksz7453geslhigktfsu6ld2.py
# Topologically Sorted Source Nodes: [x, y], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   x => embedding
#   y => add, convert_element_type, convert_element_type_1, mean, mul, mul_1, pow_1, rsqrt
# Graph fragment:
#   %arg2_1 : Tensor "i64[1, 1][512, 1]cpu" = PlaceHolder[target=arg2_1]
#   %arg7_1 : Tensor "f16[32000, 1024][1024, 1]cpu" = PlaceHolder[target=arg7_1]
#   %buf0 : Tensor "f32[1, 1, 1][1, 1, 1]cpu" = PlaceHolder[target=buf0]
#   %arg8_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg8_1]
#   %embedding : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg7_1, %arg2_1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [2], True), kwargs = {})
#   %add : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean, 9.999999747378752e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg8_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_1, torch.float16), kwargs = {})
#   return %buf0,%convert_element_type_1
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 6144}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    _tmp7 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.device_assert((0 <= tmp1) & (tmp1 < 32000), "index out of bounds: 0 <= tmp1 < 32000")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 1024*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp3.to(tl.float32)
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
    tmp7 = triton_helpers.promote_to_tensor(tl.sum(_tmp7, 0))
    tmp9 = tl.load(in_ptr0 + (0))
    tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp20 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp10) & (tmp10 < 32000), "index out of bounds: 0 <= tmp10 < 32000")
        tmp12 = tl.load(in_ptr1 + (r0_0 + 1024*tmp10), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp13 = tmp12.to(tl.float32)
        tmp14 = tl.full([1], 1024.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp16 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = libdevice.rsqrt(tmp17)
        tmp19 = tmp13 * tmp18
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp19 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp23, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/4a/c4aa3jo44kixx5at6uffg6nxiam7g7lqrqehhwyendetaiag3tbb.py
# Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_1 => mm_1, permute_2, view_5
# Graph fragment:
#   %convert_element_type_1 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=convert_element_type_1]
#   %arg10_1 : Tensor "f16[256, 1024][1024, 1]cpu" = PlaceHolder[target=arg10_1]
#   %view_5 : Tensor "f16[1, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_1, [1, 1024]), kwargs = {})
#   %permute_2 : Tensor "f16[1024, 256][1, 1024]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg10_1, [1, 0]), kwargs = {})
#   %mm_1 : Tensor "f16[1, 256][256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_5, %permute_2), kwargs = {})
#   return %mm_1
triton_tem_fused_mm_t_view_2 = async_compile.triton('triton_tem_fused_mm_t_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_2', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_2(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 256
    K = 1024
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 1024
    stride_ak = 1
    stride_bk = 1
    stride_bn = 1024

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 1024*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 256*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 1024*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 256*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/gk/cgkk35yiuztx5nfjltq5znpi5vvahe7ypb5bwsgwgcahdtejjgaw.py
# Topologically Sorted Source Nodes: [linear_1, view_3, k, chunk_1, neg_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
# Source node to ATen node mapping:
#   chunk_1 => split_1
#   k => permute_3
#   linear_1 => view_6
#   neg_1 => neg_1
#   view_3 => view_7
# Graph fragment:
#   %mm_1 : Tensor "f16[1, 256][256, 1]cpu" = PlaceHolder[target=mm_1]
#   %view_6 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 256]), kwargs = {})
#   %view_7 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_6, [1, 1, 4, 64]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_7, [0, 2, 1, 3]), kwargs = {})
#   %split_1 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_3, 32, -1), kwargs = {})
#   %neg_1 : Tensor "f16[1, 4, 1, 32][128, 32, 32, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_3,), kwargs = {})
#   return %neg_1
triton_poi_fused__unsafe_view_neg_split_transpose_view_3 = async_compile.triton('triton_poi_fused__unsafe_view_neg_split_transpose_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 128}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_neg_split_transpose_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 768}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_neg_split_transpose_view_3(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 128
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (32 + x0 + 64*x1), xmask).to(tl.float32)
    tmp1 = -tmp0
    tl.store(out_ptr0 + (x0 + 64*x1), tmp1, xmask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/u4/cu47detxewuzycvebudjjd6vekov2cawqimrnuov3y2bzpep44xq.py
# Topologically Sorted Source Nodes: [linear_1, view_3, k, chunk_1, neg_1, cat_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   cat_1 => cat_1
#   chunk_1 => split_1
#   k => permute_3
#   linear_1 => view_6
#   neg_1 => neg_1
#   view_3 => view_7
# Graph fragment:
#   %mm_1 : Tensor "f16[1, 256][256, 1]cpu" = PlaceHolder[target=mm_1]
#   %view_6 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 256]), kwargs = {})
#   %view_7 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_6, [1, 1, 4, 64]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_7, [0, 2, 1, 3]), kwargs = {})
#   %split_1 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_3, 32, -1), kwargs = {})
#   %neg_1 : Tensor "f16[1, 4, 1, 32][128, 32, 32, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_3,), kwargs = {})
#   %cat_1 : Tensor "f16[1, 4, 1, 64][256, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %getitem_2], -1), kwargs = {})
#   return %buf8
triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4 = async_compile.triton('triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 128}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 768}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 128
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (x0 + 64*x1), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 64*x1), tmp0, xmask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/bm/cbmercbpbyjbertmtj2br6kwxjseoxwxmsxlvkbj55u5odxfftmq.py
# Topologically Sorted Source Nodes: [x, y, linear], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear => mm, permute, view_2
#   x => embedding
#   y => add, convert_element_type, convert_element_type_1, mean, mul, mul_1, pow_1, rsqrt
# Graph fragment:
#   %convert_element_type_1 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=convert_element_type_1]
#   %arg9_1 : Tensor "f16[1024, 1024][1024, 1]cpu" = PlaceHolder[target=arg9_1]
#   %embedding : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg7_1, %arg2_1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [2], True), kwargs = {})
#   %add : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean, 9.999999747378752e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg8_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_1, torch.float16), kwargs = {})
#   %view_2 : Tensor "f16[1, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_1, [1, 1024]), kwargs = {})
#   %permute : Tensor "f16[1024, 1024][1, 1024]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg9_1, [1, 0]), kwargs = {})
#   %mm : Tensor "f16[1, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_2, %permute), kwargs = {})
#   return %mm
triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5 = async_compile.triton('triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 1024
    K = 1024
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 1024

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 1024*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 1024*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 1024*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 1024*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/h2/ch2kasl3po2o77n7k3ucnemmeh2eoci42rqnfeud6cbdgykvlux5.py
# Topologically Sorted Source Nodes: [linear, view_2, q, chunk, neg], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
# Source node to ATen node mapping:
#   chunk => split
#   linear => view_3
#   neg => neg
#   q => permute_1
#   view_2 => view_4
# Graph fragment:
#   %mm : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm]
#   %view_3 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 1024]), kwargs = {})
#   %view_4 : Tensor "f16[1, 1, 16, 64][1024, 1024, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_3, [1, 1, 16, 64]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 16, 1, 64][1024, 64, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_4, [0, 2, 1, 3]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_1, 32, -1), kwargs = {})
#   %neg : Tensor "f16[1, 16, 1, 32][512, 32, 32, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_1,), kwargs = {})
#   return %neg
triton_poi_fused__unsafe_view_neg_split_transpose_view_6 = async_compile.triton('triton_poi_fused__unsafe_view_neg_split_transpose_view_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_neg_split_transpose_view_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3072}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_neg_split_transpose_view_6(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (32 + x0 + 64*x1), xmask).to(tl.float32)
    tmp1 = -tmp0
    tl.store(out_ptr0 + (x0 + 64*x1), tmp1, xmask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/hb/chbbcsgb5nvczx6lc5pqoe27tq7hnxr3ke3gbgtakenecsulm4wb.py
# Topologically Sorted Source Nodes: [linear, view_2, q, chunk, neg, cat], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   cat => cat
#   chunk => split
#   linear => view_3
#   neg => neg
#   q => permute_1
#   view_2 => view_4
# Graph fragment:
#   %mm : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm]
#   %view_3 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 1024]), kwargs = {})
#   %view_4 : Tensor "f16[1, 1, 16, 64][1024, 1024, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_3, [1, 1, 16, 64]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 16, 1, 64][1024, 64, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_4, [0, 2, 1, 3]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_1, 32, -1), kwargs = {})
#   %neg : Tensor "f16[1, 16, 1, 32][512, 32, 32, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_1,), kwargs = {})
#   %cat : Tensor "f16[1, 16, 1, 64][1024, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %getitem], -1), kwargs = {})
#   return %buf5
triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_7 = async_compile.triton('triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3072}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_7(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    tmp0 = tl.load(in_ptr0 + (x0 + 64*x1), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 64*x1), tmp0, xmask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/4t/c4tbonhn47uonbjby3nfzp5wkam7zq6eavyl4sv3dkcohcqna2ex.py
# Topologically Sorted Source Nodes: [linear_1, view_3, k, cos, sin, eq, write, mul_2, mul_3, k_1, getitem_4, full_k], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.index_select, aten.eq, aten.mul, aten.add, aten.select, aten.where]
# Source node to ATen node mapping:
#   cos => index
#   eq => eq
#   full_k => where
#   getitem_4 => select
#   k => permute_3
#   k_1 => add_2
#   linear_1 => view_6
#   mul_2 => mul_4
#   mul_3 => mul_5
#   sin => index_1
#   view_3 => view_7
#   write => view
# Graph fragment:
#   %arg3_1 : Tensor "i64[576][1]cpu" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %mm_1 : Tensor "f16[1, 256][256, 1]cpu" = PlaceHolder[target=mm_1]
#   %arg5_1 : Tensor "f16[576, 64][64, 1]cpu" = PlaceHolder[target=arg5_1]
#   %cat_1 : Tensor "f16[1, 4, 1, 64][256, 64, 64, 1]cpu" = PlaceHolder[target=cat_1]
#   %arg6_1 : Tensor "f16[576, 64][64, 1]cpu" = PlaceHolder[target=arg6_1]
#   %copy_ : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu" = PlaceHolder[target=copy_]
#   %view_6 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 256]), kwargs = {})
#   %view_7 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_6, [1, 1, 4, 64]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_7, [0, 2, 1, 3]), kwargs = {})
#   %index : Tensor "f16[1, 64][64, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg5_1, [%arg4_1]), kwargs = {})
#   %index_1 : Tensor "f16[1, 64][64, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg6_1, [%arg4_1]), kwargs = {})
#   %eq : Tensor "b8[576][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%arg3_1, %arg4_1), kwargs = {})
#   %view : Tensor "b8[1, 1, 576, 1][576, 576, 1, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 1, -1, 1]), kwargs = {})
#   %mul_4 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_3, %index), kwargs = {})
#   %mul_5 : Tensor "f16[1, 4, 1, 64][256, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %index_1), kwargs = {})
#   %add_2 : Tensor "f16[1, 4, 1, 64][256, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_4, %mul_5), kwargs = {})
#   %select : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg0_1, 0, 0), kwargs = {})
#   %where : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%view, %add_2, %select), kwargs = {})
#   return %where
triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_8 = async_compile.triton('triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'in_ptr5': '*fp16', 'in_ptr6': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_8', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 890368}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_8(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 147456
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = ((xindex // 64) % 576)
    x0 = (xindex % 64)
    x2 = xindex // 36864
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last')
    tmp1 = tl.load(in_ptr1 + (0))
    tmp2 = tl.broadcast_to(tmp1, [XBLOCK])
    tmp4 = tl.load(in_ptr2 + (x0 + 64*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp12 = tl.load(in_ptr4 + (x0 + 64*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp16 = tl.load(in_ptr6 + (x4), None).to(tl.float32)
    tmp3 = tmp0 == tmp2
    tmp5 = (tl.full([XBLOCK], 576, tl.int32)).to(tl.int32)
    tmp6 = tmp2 + tmp5
    tmp7 = tmp2 < 0
    tmp8 = tl.where(tmp7, tmp6, tmp2)
    tl.device_assert((0 <= tmp8) & (tmp8 < 576), "index out of bounds: 0 <= tmp8 < 576")
    tmp10 = tl.load(in_ptr3 + (x0 + 64*tmp8), None).to(tl.float32)
    tmp11 = tmp4 * tmp10
    tmp13 = tl.load(in_ptr5 + (x0 + 64*tmp8), None).to(tl.float32)
    tmp14 = tmp12 * tmp13
    tmp15 = tmp11 + tmp14
    tmp17 = tl.where(tmp3, tmp15, tmp16)
    tl.store(out_ptr0 + (x4), tmp17, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/mg/cmgxw3rz66kyfkv4oquturgedomthbd7wta6ucoshgzak6b5sd4l.py
# Topologically Sorted Source Nodes: [linear, view_2, q, cos, mul, sin, mul_1, q_1, o, getitem_8, expand, full_k_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.index_select, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   cos => index
#   expand => expand
#   full_k_1 => clone, view_11
#   getitem_8 => unsqueeze
#   linear => view_3
#   mul => mul_2
#   mul_1 => mul_3
#   o => bmm, convert_element_type_8, convert_element_type_9, mul_6, mul_7, permute_6, view_13, view_14
#   q => permute_1
#   q_1 => add_1
#   sin => index_1
#   view_2 => view_4
# Graph fragment:
#   %mm : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm]
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %arg5_1 : Tensor "f16[576, 64][64, 1]cpu" = PlaceHolder[target=arg5_1]
#   %cat : Tensor "f16[1, 16, 1, 64][1024, 64, 64, 1]cpu" = PlaceHolder[target=cat]
#   %arg6_1 : Tensor "f16[576, 64][64, 1]cpu" = PlaceHolder[target=arg6_1]
#   %where : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu" = PlaceHolder[target=where]
#   %view_3 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 1024]), kwargs = {})
#   %view_4 : Tensor "f16[1, 1, 16, 64][1024, 1024, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_3, [1, 1, 16, 64]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 16, 1, 64][1024, 64, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_4, [0, 2, 1, 3]), kwargs = {})
#   %index : Tensor "f16[1, 64][64, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg5_1, [%arg4_1]), kwargs = {})
#   %mul_2 : Tensor "f16[1, 16, 1, 64][1024, 64, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_1, %index), kwargs = {})
#   %index_1 : Tensor "f16[1, 64][64, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg6_1, [%arg4_1]), kwargs = {})
#   %mul_3 : Tensor "f16[1, 16, 1, 64][1024, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %index_1), kwargs = {})
#   %add_1 : Tensor "f16[1, 16, 1, 64][1024, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_2, %mul_3), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[1, 16, 1, 64][1024, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_1, torch.float32), kwargs = {})
#   %mul_6 : Tensor "f32[1, 16, 1, 64][1024, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_8, 0.3535533905932738), kwargs = {})
#   %view_13 : Tensor "f32[16, 1, 64][64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_2, [16, 1, 64]), kwargs = {})
#   %unsqueeze : Tensor "f16[1, 4, 1, 576, 64][147456, 36864, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%where, 2), kwargs = {})
#   %expand : Tensor "f16[1, 4, 4, 576, 64][147456, 36864, 0, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze, [1, 4, 4, -1, 64]), kwargs = {})
#   %clone : Tensor "f16[1, 4, 4, 576, 64][589824, 147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view_11 : Tensor "f16[1, 16, 576, 64][589824, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 16, 576, 64]), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[1, 16, 576, 64][589824, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_11, torch.float32), kwargs = {})
#   %permute_6 : Tensor "f32[1, 16, 64, 576][589824, 36864, 1, 64]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_9, [0, 1, 3, 2]), kwargs = {})
#   %mul_7 : Tensor "f32[1, 16, 64, 576][589824, 36864, 1, 64]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_6, 0.3535533905932738), kwargs = {})
#   %view_14 : Tensor "f32[16, 64, 576][36864, 1, 64]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_3, [16, 64, 576]), kwargs = {})
#   %bmm : Tensor "f32[16, 1, 576][576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_13, %view_14), kwargs = {})
#   return %bmm
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_index_select_mul_transpose_unsqueeze_view_9 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_index_select_mul_transpose_unsqueeze_view_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 64},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*i64', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'in_ptr5': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_index_select_mul_transpose_unsqueeze_view_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 73728, 'r0_': 299008}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_index_select_mul_transpose_unsqueeze_view_9(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 9216
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 576
    tmp1 = tl.load(in_ptr1 + (0))
    tmp2 = tl.broadcast_to(tmp1, [R0_BLOCK])
    x0 = (xindex % 576)
    _tmp22 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_2 + 64*x1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tl.load(in_ptr3 + (r0_2 + 64*x1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp17 = tl.load(in_ptr5 + (r0_2 + 64*x0 + 36864*(x1 // 4)), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp3 = (tl.full([R0_BLOCK], 576, tl.int32)).to(tl.int32)
        tmp4 = tmp2 + tmp3
        tmp5 = tmp2 < 0
        tmp6 = tl.where(tmp5, tmp4, tmp2)
        tl.device_assert((0 <= tmp6) & (tmp6 < 576), "index out of bounds: 0 <= tmp6 < 576")
        tmp8 = tl.load(in_ptr2 + (r0_2 + 64*tmp6), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp9 = tmp0 * tmp8
        tmp11 = tl.load(in_ptr4 + (r0_2 + 64*tmp6), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp12 = tmp10 * tmp11
        tmp13 = tmp9 + tmp12
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tl.full([1], 0.3535533905932738, tl.float32)
        tmp16 = tmp14 * tmp15
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp18 * tmp15
        tmp20 = tmp16 * tmp19
        tmp21 = tl.broadcast_to(tmp20, [R0_BLOCK])
        tmp23 = _tmp22 + tmp21
        _tmp22 = tl.where(r0_mask, tmp23, _tmp22)
    tmp22 = triton_helpers.promote_to_tensor(tl.sum(_tmp22, 0))
    tl.store(out_ptr0 + (x3), tmp22, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/43/c43uxsjzu36wuyv7lt66qu2jcxm2m4niery774chg3djlpyo7w5l.py
# Topologically Sorted Source Nodes: [o, le, visible], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.le, aten.view, aten.scalar_tensor, aten.where]
# Source node to ATen node mapping:
#   le => le
#   o => add_3, amax, any_1, eq_1, exp, full_default, full_default_1, logical_not, sub, sum_1, view_15, where_2
#   visible => view_1
# Graph fragment:
#   %bmm : Tensor "f32[16, 1, 576][576, 576, 1]cpu" = PlaceHolder[target=bmm]
#   %arg3_1 : Tensor "i64[576][1]cpu" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %amax : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]cpu" = PlaceHolder[target=amax]
#   %exp : Tensor "f32[1, 16, 1, 576][9216, 576, 9216, 1]cpu" = PlaceHolder[target=exp]
#   %view_15 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 16, 1, 576]), kwargs = {})
#   %le : Tensor "b8[576][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.le.Tensor](args = (%arg3_1, %arg4_1), kwargs = {})
#   %view_1 : Tensor "b8[1, 1, 1, 576][576, 576, 576, 1]cpu"[num_users=4] = call_function[target=torch.ops.aten.reshape.default](args = (%le, [1, 1, 1, -1]), kwargs = {})
#   %full_default_1 : Tensor "f16[][]cpu"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], 0.0), kwargs = {dtype: torch.float16, layout: torch.strided, device: cpu, pin_memory: False})
#   %full_default : Tensor "f16[][]cpu"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], -inf), kwargs = {dtype: torch.float16, layout: torch.strided, device: cpu, pin_memory: False})
#   %where_2 : Tensor "f16[1, 1, 1, 576][576, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%view_1, %full_default_1, %full_default), kwargs = {})
#   %add_3 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%view_15, %where_2), kwargs = {})
#   %eq_1 : Tensor "b8[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%add_3, -inf), kwargs = {})
#   %logical_not : Tensor "b8[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq_1,), kwargs = {})
#   %any_1 : Tensor "b8[1, 16, 1, 1][16, 1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.any.dim](args = (%logical_not, -1, True), kwargs = {})
#   %amax : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%add_3, [-1], True), kwargs = {})
#   %sub : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%add_3, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub,), kwargs = {})
#   %sum_1 : Tensor "f32[1, 16, 1, 1][16, 1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp, [-1], True), kwargs = {})
#   return %any_1,%amax,%exp,%sum_1
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_le_scalar_tensor_view_where_10 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_le_scalar_tensor_view_where_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*i64', 'in_ptr2': '*i64', 'out_ptr0': '*i1', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_le_scalar_tensor_view_where_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 3, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 160, 'r0_': 115200}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_le_scalar_tensor_view_where_10(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 576
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 576], strides=[576, 1], block_shape=[XBLOCK, R0_BLOCK])
    tmp2 = tl.load(in_ptr2 + (0))
    tmp3 = tl.broadcast_to(tmp2, [R0_BLOCK])
    _tmp15 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp19 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp1 = tl.load(in_ptr1 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp4 = tmp1 <= tmp3
        tmp5 = tl.full([1], 0.0, tl.float32)
        tmp6 = tl.full([1], float("-inf"), tl.float32)
        tmp7 = tl.where(tmp4, tmp5, tmp6)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp0 + tmp8
        tmp10 = tmp9 == tmp6
        tmp11 = tmp10 == 0
        tmp12 = tmp11.to(tl.int64)
        tmp13 = (tmp12 != 0)
        tmp14 = tl.broadcast_to(tmp13, [R0_BLOCK])
        tmp16 = _tmp15 | tmp14
        _tmp15 = tl.where(r0_mask, tmp16, _tmp15)
        tmp18 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp20 = tl.maximum(_tmp19, tmp18, tl.PropagateNan.ALL)
        _tmp19 = tl.where(r0_mask, tmp20, _tmp19)
    tmp17 = _tmp15.to(tl.int8)
    tmp15 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp17, 0))
    tmp19 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp19, 0))
    tl.store(out_ptr0 + (x0), tmp15, None)
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[16, 576], strides=[576, 1], block_shape=[XBLOCK, R0_BLOCK])
    tmp23 = tl.load(in_ptr2 + (0))
    tmp24 = tl.broadcast_to(tmp23, [R0_BLOCK])
    _tmp34 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp21 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp22 = tl.load(in_ptr1 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp25 = tmp22 <= tmp24
        tmp26 = tl.full([1], 0.0, tl.float32)
        tmp27 = tl.full([1], float("-inf"), tl.float32)
        tmp28 = tl.where(tmp25, tmp26, tmp27)
        tmp29 = tmp28.to(tl.float32)
        tmp30 = tmp21 + tmp29
        tmp31 = tmp30 - tmp19
        tmp32 = libdevice.exp(tmp31)
        tmp33 = tl.broadcast_to(tmp32, [R0_BLOCK])
        tmp35 = _tmp34 + tmp33
        _tmp34 = tl.where(r0_mask, tmp35, _tmp34)
        tl.store(out_ptr2 + (r0_1 + 576*x0), tmp32, r0_mask)
    tmp34 = triton_helpers.promote_to_tensor(tl.sum(_tmp34, 0))
    tl.store(out_ptr3 + (x0), tmp34, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/4u/c4uuqq77cgac7kraxkbe6ihjsfwlqcp2fropaoq73vlsitk4x33c.py
# Topologically Sorted Source Nodes: [eq, write, o, linear_2, view_4, v, getitem_5, full_v, getitem_9, expand_1, full_v_1], Original ATen: [aten.eq, aten.view, aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   eq => eq
#   expand_1 => expand_1
#   full_v => where_1
#   full_v_1 => clone_1, view_12
#   getitem_5 => select_1
#   getitem_9 => unsqueeze_1
#   linear_2 => view_9
#   o => bmm_1, convert_element_type_10, div, full_default_2, logical_not_1, view_16, view_17, where_3
#   v => permute_5
#   view_4 => view_10
#   write => view
# Graph fragment:
#   %any_1 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]cpu" = PlaceHolder[target=any_1]
#   %exp : Tensor "f32[1, 16, 1, 576][9216, 576, 9216, 1]cpu" = PlaceHolder[target=exp]
#   %sum_1 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]cpu" = PlaceHolder[target=sum_1]
#   %arg3_1 : Tensor "i64[576][1]cpu" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %mm_2 : Tensor "f16[1, 256][256, 1]cpu" = PlaceHolder[target=mm_2]
#   %copy__1 : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu" = PlaceHolder[target=copy__1]
#   %eq : Tensor "b8[576][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%arg3_1, %arg4_1), kwargs = {})
#   %view : Tensor "b8[1, 1, 576, 1][576, 576, 1, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 1, -1, 1]), kwargs = {})
#   %logical_not_1 : Tensor "b8[1, 16, 1, 1][16, 1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default_2 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 1, 576], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: cpu, pin_memory: False})
#   %div : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where_3 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default_2, %div), kwargs = {})
#   %view_16 : Tensor "f32[16, 1, 576][576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_4, [16, 1, 576]), kwargs = {})
#   %view_9 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 1, 256]), kwargs = {})
#   %view_10 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_9, [1, 1, 4, 64]), kwargs = {})
#   %permute_5 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_10, [0, 2, 1, 3]), kwargs = {})
#   %select_1 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg1_1, 0, 0), kwargs = {})
#   %where_1 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%view, %permute_5, %select_1), kwargs = {})
#   %unsqueeze_1 : Tensor "f16[1, 4, 1, 576, 64][147456, 36864, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%where_1, 2), kwargs = {})
#   %expand_1 : Tensor "f16[1, 4, 4, 576, 64][147456, 36864, 0, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, 4, 4, -1, 64]), kwargs = {})
#   %clone_1 : Tensor "f16[1, 4, 4, 576, 64][589824, 147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_1,), kwargs = {memory_format: torch.contiguous_format})
#   %view_12 : Tensor "f16[1, 16, 576, 64][589824, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_1, [1, 16, 576, 64]), kwargs = {})
#   %convert_element_type_10 : Tensor "f32[1, 16, 576, 64][589824, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_12, torch.float32), kwargs = {})
#   %view_17 : Tensor "f32[16, 576, 64][36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_5, [16, 576, 64]), kwargs = {})
#   %bmm_1 : Tensor "f32[16, 1, 64][64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_16, %view_17), kwargs = {})
#   return %buf17
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_11 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 8192, 'r0_': 128},
    reduction_hint=ReductionHint.OUTER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i1', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*i64', 'in_ptr4': '*i64', 'in_ptr5': '*fp16', 'in_ptr6': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 1221120, 'r0_': 41472}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_11(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 5120
    XBLOCK: tl.constexpr = 1
    r0_numel = 116
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = ((xindex // 64) % 5)
    x2 = xindex // 320
    x0 = (xindex % 64)
    _tmp23 = tl.full([R0_BLOCK], 0, tl.float32)
    x4 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = r0_index
        tmp0 = (r0_3 + 116*x1).to(tl.int32)
        tmp1 = tl.full([1], 576, tl.int32)
        tmp2 = tmp0 < tmp1
        tmp3 = tl.load(in_ptr0 + (tl.broadcast_to(x2, [R0_BLOCK])), r0_mask & tmp2, eviction_policy='evict_last', other=0.0).to(tl.int1)
        tmp4 = tmp3 == 0
        tmp5 = tl.load(in_ptr1 + (r0_3 + 116*x1 + 576*x2), r0_mask & tmp2, eviction_policy='evict_last', other=0.0)
        tmp6 = tl.load(in_ptr2 + (tl.broadcast_to(x2, [R0_BLOCK])), r0_mask & tmp2, eviction_policy='evict_last', other=0.0)
        tmp7 = (tmp5 / tmp6)
        tmp8 = tl.full([1], 0.0, tl.float32)
        tmp9 = tl.where(tmp4, tmp8, tmp7)
        tmp10 = tl.load(in_ptr3 + (r0_3 + 116*x1), r0_mask & tmp2, eviction_policy='evict_last', other=0.0)
        tmp11 = tl.load(in_ptr4 + (0))
        tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
        tmp13 = tl.where(tmp2, tmp12, 0)
        tmp14 = tmp10 == tmp13
        tmp15 = tl.load(in_ptr5 + (tl.broadcast_to(x0 + 64*(x2 // 4), [R0_BLOCK])), r0_mask & tmp2, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp16 = tl.load(in_ptr6 + (x0 + 64*r0_3 + 7424*x1 + 36864*(x2 // 4)), r0_mask & tmp2, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp17 = tl.where(tmp14, tmp15, tmp16)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp9 * tmp18
        tmp20 = tl.full(tmp19.shape, 0, tmp19.dtype)
        tmp21 = tl.where(tmp2, tmp19, tmp20)
        tmp22 = tl.broadcast_to(tmp21, [R0_BLOCK])
        tmp24 = _tmp23 + tmp22
        _tmp23 = tl.where(r0_mask, tmp24, _tmp23)
    tmp23 = triton_helpers.promote_to_tensor(tl.sum(_tmp23, 0))
    tl.store(out_ptr0 + (x4), tmp23, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/mi/cmi34dv4mmpo6amfdvf4y4hzfk7ax2giyrbbumfazylu7jygytwk.py
# Topologically Sorted Source Nodes: [eq, write, o, linear_2, view_4, v, getitem_5, full_v, getitem_9, expand_1, full_v_1], Original ATen: [aten.eq, aten.view, aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   eq => eq
#   expand_1 => expand_1
#   full_v => where_1
#   full_v_1 => clone_1, view_12
#   getitem_5 => select_1
#   getitem_9 => unsqueeze_1
#   linear_2 => view_9
#   o => bmm_1, convert_element_type_10, convert_element_type_11, div, full_default_2, logical_not_1, view_16, view_17, view_18, where_3
#   v => permute_5
#   view_4 => view_10
#   write => view
# Graph fragment:
#   %buf17 : Tensor "f32[16, 1, 64, 5][320, 5120, 1, 64]cpu" = PlaceHolder[target=buf17]
#   %bmm_1 : Tensor "f32[16, 1, 64][64, 64, 1]cpu" = PlaceHolder[target=bmm_1]
#   %eq : Tensor "b8[576][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%arg3_1, %arg4_1), kwargs = {})
#   %view : Tensor "b8[1, 1, 576, 1][576, 576, 1, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 1, -1, 1]), kwargs = {})
#   %logical_not_1 : Tensor "b8[1, 16, 1, 1][16, 1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default_2 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 1, 576], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: cpu, pin_memory: False})
#   %div : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where_3 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default_2, %div), kwargs = {})
#   %view_16 : Tensor "f32[16, 1, 576][576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_4, [16, 1, 576]), kwargs = {})
#   %view_9 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 1, 256]), kwargs = {})
#   %view_10 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_9, [1, 1, 4, 64]), kwargs = {})
#   %permute_5 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_10, [0, 2, 1, 3]), kwargs = {})
#   %select_1 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg1_1, 0, 0), kwargs = {})
#   %where_1 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%view, %permute_5, %select_1), kwargs = {})
#   %unsqueeze_1 : Tensor "f16[1, 4, 1, 576, 64][147456, 36864, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%where_1, 2), kwargs = {})
#   %expand_1 : Tensor "f16[1, 4, 4, 576, 64][147456, 36864, 0, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, 4, 4, -1, 64]), kwargs = {})
#   %clone_1 : Tensor "f16[1, 4, 4, 576, 64][589824, 147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_1,), kwargs = {memory_format: torch.contiguous_format})
#   %view_12 : Tensor "f16[1, 16, 576, 64][589824, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_1, [1, 16, 576, 64]), kwargs = {})
#   %convert_element_type_10 : Tensor "f32[1, 16, 576, 64][589824, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_12, torch.float32), kwargs = {})
#   %view_17 : Tensor "f32[16, 576, 64][36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_5, [16, 576, 64]), kwargs = {})
#   %bmm_1 : Tensor "f32[16, 1, 64][64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_16, %view_17), kwargs = {})
#   %view_18 : Tensor "f32[1, 16, 1, 64][1024, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 16, 1, 64]), kwargs = {})
#   %convert_element_type_11 : Tensor "f16[1, 16, 1, 64][1024, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_18, torch.float16), kwargs = {})
#   return %bmm_1,%convert_element_type_11
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_12 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 1024, 'r0_': 8},
    reduction_hint=ReductionHint.OUTER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 24576, 'r0_': 0}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_12(in_ptr0, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1024
    XBLOCK: tl.constexpr = 1
    r0_numel = 5
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = (xindex % 64)
    x1 = xindex // 64
    _tmp2 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (x0 + 64*r0_2 + 320*x1), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
        tmp3 = _tmp2 + tmp1
        _tmp2 = tl.where(r0_mask, tmp3, _tmp2)
    tmp2 = triton_helpers.promote_to_tensor(tl.sum(_tmp2, 0))
    tmp4 = tmp2.to(tl.float32)
    tl.store(out_ptr1 + (x3), tmp4, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/d7/cd7tfnbufzzq2op5q5ymwnkvauwp2am3hrznhcuupravnjwwe37f.py
# Topologically Sorted Source Nodes: [x, linear_3, x_1, y_1], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   linear_3 => view_21
#   x => embedding
#   x_1 => add_4
#   y_1 => add_5, convert_element_type_15, convert_element_type_16, mean_1, mul_8, mul_9, pow_2, rsqrt_1
# Graph fragment:
#   %arg2_1 : Tensor "i64[1, 1][512, 1]cpu" = PlaceHolder[target=arg2_1]
#   %arg7_1 : Tensor "f16[32000, 1024][1024, 1]cpu" = PlaceHolder[target=arg7_1]
#   %mm_3 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_3]
#   %buf21 : Tensor "f32[1, 1, 1][1, 1, 1]cpu" = PlaceHolder[target=buf21]
#   %arg13_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg13_1]
#   %embedding : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg7_1, %arg2_1), kwargs = {})
#   %view_21 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 1024]), kwargs = {})
#   %add_4 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_21), kwargs = {})
#   %convert_element_type_15 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_4, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_15, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [2], True), kwargs = {})
#   %add_5 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_1, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_5,), kwargs = {})
#   %mul_8 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_15, %rsqrt_1), kwargs = {})
#   %mul_9 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_8, %arg13_1), kwargs = {})
#   %convert_element_type_16 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_9, torch.float16), kwargs = {})
#   return %buf21,%convert_element_type_16
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 8192}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    _tmp9 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 32000), "index out of bounds: 0 <= tmp1 < 32000")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 1024*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask, tmp10, _tmp9)
    tmp9 = triton_helpers.promote_to_tensor(tl.sum(_tmp9, 0))
    tmp11 = tl.load(in_ptr0 + (0))
    tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp24 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp12) & (tmp12 < 32000), "index out of bounds: 0 <= tmp12 < 32000")
        tmp14 = tl.load(in_ptr1 + (r0_0 + 1024*tmp12), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tmp14 + tmp15
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tl.full([1], 1024.0, tl.float32)
        tmp19 = (tmp9 / tmp18)
        tmp20 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = libdevice.rsqrt(tmp21)
        tmp23 = tmp17 * tmp22
        tmp25 = tmp24.to(tl.float32)
        tmp26 = tmp23 * tmp25
        tmp27 = tmp26.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp27, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/77/c77ztkqiedw3rydrndmyharj2fk23h36sfr76dvgsulomimnsfw2.py
# Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_4 => mm_4, permute_11, view_22
# Graph fragment:
#   %convert_element_type_16 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=convert_element_type_16]
#   %arg14_1 : Tensor "f16[2816, 1024][1024, 1]cpu" = PlaceHolder[target=arg14_1]
#   %view_22 : Tensor "f16[1, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_16, [1, 1024]), kwargs = {})
#   %permute_11 : Tensor "f16[1024, 2816][1, 1024]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg14_1, [1, 0]), kwargs = {})
#   %mm_4 : Tensor "f16[1, 2816][2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_22, %permute_11), kwargs = {})
#   return %mm_4
triton_tem_fused_mm_t_view_14 = async_compile.triton('triton_tem_fused_mm_t_view_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_14', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_14(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 2816
    K = 1024
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 1024
    stride_ak = 1
    stride_bk = 1
    stride_bn = 1024

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 1024*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 2816*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 1024*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 2816*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/px/cpxrdjcgslofjwl6y5mnpddyi52x2hx6knlqxifbi6vlzkg7gukl.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
# Source node to ATen node mapping:
#   linear_4 => view_23
#   linear_5 => mm_5, permute_12, view_24, view_25
#   mul_4 => mul_10
#   silu => add_6, convert_element_type_19, convert_element_type_20, div_1, exp_1, neg_2
# Graph fragment:
#   %convert_element_type_16 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=convert_element_type_16]
#   %arg15_1 : Tensor "f16[2816, 1024][1024, 1]cpu" = PlaceHolder[target=arg15_1]
#   %mm_4 : Tensor "f16[1, 2816][2816, 1]cpu" = PlaceHolder[target=mm_4]
#   %mm_5 : Tensor "f16[1, 2816][2816, 1]cpu" = PlaceHolder[target=mm_5]
#   %view_23 : Tensor "f16[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 1, 2816]), kwargs = {})
#   %convert_element_type_19 : Tensor "f32[1, 1, 2816][2816, 2816, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_23, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_19,), kwargs = {})
#   %exp_1 : Tensor "f32[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_6 : Tensor "f32[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_1, 1), kwargs = {})
#   %div_1 : Tensor "f32[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_19, %add_6), kwargs = {})
#   %convert_element_type_20 : Tensor "f16[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_1, torch.float16), kwargs = {})
#   %view_24 : Tensor "f16[1, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_16, [1, 1024]), kwargs = {})
#   %permute_12 : Tensor "f16[1024, 2816][1, 1024]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg15_1, [1, 0]), kwargs = {})
#   %mm_5 : Tensor "f16[1, 2816][2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_24, %permute_12), kwargs = {})
#   %view_25 : Tensor "f16[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 1, 2816]), kwargs = {})
#   %mul_10 : Tensor "f16[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %view_25), kwargs = {})
#   return %mm_5,%mul_10
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15(arg_A, arg_B, in_ptr2, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 2816
    K = 1024
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 1024
    stride_ak = 1
    stride_bk = 1
    stride_bn = 1024

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 1024*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 2816*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 1024*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 2816*idx_m
    tmp0 = acc.to(tl.float16)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.load(in_ptr2 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = -tmp3
    tmp5 = libdevice.exp(tmp4)
    tmp6 = tl.full([1], 1.0, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = (tmp3 / tmp7)
    tmp9 = tmp8.to(tl.float32)
    tmp10 = tmp9 * tmp1
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp10, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/wa/cwaqbl6fjjogsua6ehx256iwdf4u2bcgjuiicdypjxvc47vnvuob.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4, linear_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_4 => view_23
#   linear_5 => view_25
#   linear_6 => mm_6, permute_13, view_26
#   mul_4 => mul_10
#   silu => add_6, convert_element_type_19, convert_element_type_20, div_1, exp_1, neg_2
# Graph fragment:
#   %mul_10 : Tensor "f16[1, 1, 2816][2816, 2816, 1]cpu" = PlaceHolder[target=mul_10]
#   %arg16_1 : Tensor "f16[1024, 2816][2816, 1]cpu" = PlaceHolder[target=arg16_1]
#   %view_23 : Tensor "f16[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 1, 2816]), kwargs = {})
#   %convert_element_type_19 : Tensor "f32[1, 1, 2816][2816, 2816, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_23, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_19,), kwargs = {})
#   %exp_1 : Tensor "f32[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_6 : Tensor "f32[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_1, 1), kwargs = {})
#   %div_1 : Tensor "f32[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_19, %add_6), kwargs = {})
#   %convert_element_type_20 : Tensor "f16[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_1, torch.float16), kwargs = {})
#   %view_25 : Tensor "f16[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 1, 2816]), kwargs = {})
#   %mul_10 : Tensor "f16[1, 1, 2816][2816, 2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %view_25), kwargs = {})
#   %view_26 : Tensor "f16[1, 2816][2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_10, [1, 2816]), kwargs = {})
#   %permute_13 : Tensor "f16[2816, 1024][1, 2816]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg16_1, [1, 0]), kwargs = {})
#   %mm_6 : Tensor "f16[1, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_26, %permute_13), kwargs = {})
#   return %mm_6
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 1024
    K = 2816
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2816

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2816*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 1024*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2816*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 1024*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/gl/cgla3f7y5rxsq6osiq2i2sfjsweqh7nr5ss2pa53tc4vb3yjtjqw.py
# Topologically Sorted Source Nodes: [x, linear_3, x_1, linear_6, x_2, y_2], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   linear_3 => view_21
#   linear_6 => view_27
#   x => embedding
#   x_1 => add_4
#   x_2 => add_7
#   y_2 => add_8, convert_element_type_25, convert_element_type_26, mean_2, mul_11, mul_12, pow_3, rsqrt_2
# Graph fragment:
#   %arg2_1 : Tensor "i64[1, 1][512, 1]cpu" = PlaceHolder[target=arg2_1]
#   %arg7_1 : Tensor "f16[32000, 1024][1024, 1]cpu" = PlaceHolder[target=arg7_1]
#   %mm_3 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_3]
#   %mm_6 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_6]
#   %buf27 : Tensor "f32[1, 1, 1][1, 1, 1]cpu" = PlaceHolder[target=buf27]
#   %arg17_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg17_1]
#   %embedding : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg7_1, %arg2_1), kwargs = {})
#   %view_21 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 1024]), kwargs = {})
#   %add_4 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_21), kwargs = {})
#   %view_27 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 1, 1024]), kwargs = {})
#   %add_7 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4, %view_27), kwargs = {})
#   %convert_element_type_25 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_7, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_25, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [2], True), kwargs = {})
#   %add_8 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_2, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_8,), kwargs = {})
#   %mul_11 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_25, %rsqrt_2), kwargs = {})
#   %mul_12 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_11, %arg17_1), kwargs = {})
#   %convert_element_type_26 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_12, torch.float16), kwargs = {})
#   return %buf27,%convert_element_type_26
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 10240}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr3, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp6 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 32000), "index out of bounds: 0 <= tmp1 < 32000")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 1024*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp13 = tl.load(in_ptr0 + (0))
    tmp14 = tl.broadcast_to(tmp13, [R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp17 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp19 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp28 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp14) & (tmp14 < 32000), "index out of bounds: 0 <= tmp14 < 32000")
        tmp16 = tl.load(in_ptr1 + (r0_0 + 1024*tmp14), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp18 = tmp16 + tmp17
        tmp20 = tmp18 + tmp19
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tl.full([1], 1024.0, tl.float32)
        tmp23 = (tmp11 / tmp22)
        tmp24 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp25 = tmp23 + tmp24
        tmp26 = libdevice.rsqrt(tmp25)
        tmp27 = tmp21 * tmp26
        tmp29 = tmp28.to(tl.float32)
        tmp30 = tmp27 * tmp29
        tmp31 = tmp30.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp31, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/cb/ccbnxpzo3oukklc35f64b4mu2fwdpacgzvfcpcrmk7tv67qlugvs.py
# Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_7 => mm_7, permute_14, view_28
# Graph fragment:
#   %convert_element_type_26 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=convert_element_type_26]
#   %arg18_1 : Tensor "f16[1024, 1024][1024, 1]cpu" = PlaceHolder[target=arg18_1]
#   %view_28 : Tensor "f16[1, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_26, [1, 1024]), kwargs = {})
#   %permute_14 : Tensor "f16[1024, 1024][1, 1024]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg18_1, [1, 0]), kwargs = {})
#   %mm_7 : Tensor "f16[1, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_28, %permute_14), kwargs = {})
#   return %mm_7
triton_tem_fused_mm_t_view_18 = async_compile.triton('triton_tem_fused_mm_t_view_18', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_18', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_18(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 1024
    K = 1024
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 1024
    stride_ak = 1
    stride_bk = 1
    stride_bn = 1024

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 1024*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 1024*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 1024*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 1024*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/2x/c2xj6vlzhd3luicwx6ftd2mcrx7wliz7dnazhuuuojjaiyeetk23.py
# Topologically Sorted Source Nodes: [cos, sin, eq, write, linear_8, view_6, k_2, mul_7, mul_8, k_3, full_k_2], Original ATen: [aten.index_select, aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.mul, aten.add, aten.select, aten.where]
# Source node to ATen node mapping:
#   cos => index
#   eq => eq
#   full_k_2 => select_7, where_4
#   k_2 => permute_17
#   k_3 => add_10
#   linear_8 => view_32
#   mul_7 => mul_15
#   mul_8 => mul_16
#   sin => index_1
#   view_6 => view_33
#   write => view
# Graph fragment:
#   %arg3_1 : Tensor "i64[576][1]cpu" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %mm_8 : Tensor "f16[1, 256][256, 1]cpu" = PlaceHolder[target=mm_8]
#   %arg5_1 : Tensor "f16[576, 64][64, 1]cpu" = PlaceHolder[target=arg5_1]
#   %cat_3 : Tensor "f16[1, 4, 1, 64][256, 64, 64, 1]cpu" = PlaceHolder[target=cat_3]
#   %arg6_1 : Tensor "f16[576, 64][64, 1]cpu" = PlaceHolder[target=arg6_1]
#   %where : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu" = PlaceHolder[target=where]
#   %copy_ : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu" = PlaceHolder[target=copy_]
#   %index : Tensor "f16[1, 64][64, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg5_1, [%arg4_1]), kwargs = {})
#   %index_1 : Tensor "f16[1, 64][64, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg6_1, [%arg4_1]), kwargs = {})
#   %eq : Tensor "b8[576][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%arg3_1, %arg4_1), kwargs = {})
#   %view : Tensor "b8[1, 1, 576, 1][576, 576, 1, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 1, -1, 1]), kwargs = {})
#   %view_32 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [1, 1, 256]), kwargs = {})
#   %view_33 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_32, [1, 1, 4, 64]), kwargs = {})
#   %permute_17 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_33, [0, 2, 1, 3]), kwargs = {})
#   %select_scatter_default : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=3] = call_function[target=torch.ops.aten.select_scatter.default](args = (%arg0_1, %where, 0, 0), kwargs = {})
#   %mul_15 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_17, %index), kwargs = {})
#   %mul_16 : Tensor "f16[1, 4, 1, 64][256, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_3, %index_1), kwargs = {})
#   %add_10 : Tensor "f16[1, 4, 1, 64][256, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_15, %mul_16), kwargs = {})
#   %select_7 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 1), kwargs = {})
#   %where_4 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%view, %add_10, %select_7), kwargs = {})
#   return %where_4
triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_19 = async_compile.triton('triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_19', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'in_ptr5': '*fp16', 'in_ptr6': '*fp16', 'in_ptr7': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_19', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1185280}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_19(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, in_ptr7, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 147456
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = ((xindex // 64) % 576)
    x0 = (xindex % 64)
    x2 = xindex // 36864
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last')
    tmp1 = tl.load(in_ptr1 + (0))
    tmp2 = tl.broadcast_to(tmp1, [XBLOCK])
    tmp4 = tl.load(in_ptr2 + (x0 + 64*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp12 = tl.load(in_ptr4 + (x0 + 64*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp19 = tl.load(in_ptr6 + (x4), None).to(tl.float32)
    tmp20 = tl.load(in_ptr7 + (147456 + x4), None).to(tl.float32)
    tmp3 = tmp0 == tmp2
    tmp5 = (tl.full([XBLOCK], 576, tl.int32)).to(tl.int32)
    tmp6 = tmp2 + tmp5
    tmp7 = tmp2 < 0
    tmp8 = tl.where(tmp7, tmp6, tmp2)
    tl.device_assert((0 <= tmp8) & (tmp8 < 576), "index out of bounds: 0 <= tmp8 < 576")
    tmp10 = tl.load(in_ptr3 + (x0 + 64*tmp8), None).to(tl.float32)
    tmp11 = tmp4 * tmp10
    tmp13 = tl.load(in_ptr5 + (x0 + 64*tmp8), None).to(tl.float32)
    tmp14 = tmp12 * tmp13
    tmp15 = tmp11 + tmp14
    tmp16 = tl.full([1], 1, tl.int32)
    tmp17 = tl.full([1], 0, tl.int32)
    tmp18 = tmp16 == tmp17
    tmp21 = tl.where(tmp18, tmp19, tmp20)
    tmp22 = tl.where(tmp3, tmp15, tmp21)
    tl.store(out_ptr0 + (x4), tmp22, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/pg/cpgxnyn4vlsbzrtcehezlo5zkw5oww5h6mtjt6lwzn3jrvzez3x5.py
# Topologically Sorted Source Nodes: [eq, write, linear_2, view_4, v, getitem_5, full_v], Original ATen: [aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.select, aten.where]
# Source node to ATen node mapping:
#   eq => eq
#   full_v => where_1
#   getitem_5 => select_1
#   linear_2 => view_9
#   v => permute_5
#   view_4 => view_10
#   write => view
# Graph fragment:
#   %arg3_1 : Tensor "i64[576][1]cpu" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %mm_2 : Tensor "f16[1, 256][256, 1]cpu" = PlaceHolder[target=mm_2]
#   %copy__1 : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu" = PlaceHolder[target=copy__1]
#   %eq : Tensor "b8[576][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%arg3_1, %arg4_1), kwargs = {})
#   %view : Tensor "b8[1, 1, 576, 1][576, 576, 1, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 1, -1, 1]), kwargs = {})
#   %view_9 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 1, 256]), kwargs = {})
#   %view_10 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_9, [1, 1, 4, 64]), kwargs = {})
#   %permute_5 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_10, [0, 2, 1, 3]), kwargs = {})
#   %select_1 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg1_1, 0, 0), kwargs = {})
#   %where_1 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%view, %permute_5, %select_1), kwargs = {})
#   %select_scatter_default_1 : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=3] = call_function[target=torch.ops.aten.select_scatter.default](args = (%arg1_1, %where_1, 0, 0), kwargs = {})
#   return %select_scatter_default_1
triton_poi_fused__unsafe_view_eq_select_transpose_view_where_20 = async_compile.triton('triton_poi_fused__unsafe_view_eq_select_transpose_view_where_20', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_eq_select_transpose_view_where_20', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3838976}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_eq_select_transpose_view_where_20(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 589824
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x3 = xindex // 147456
    x1 = ((xindex // 64) % 576)
    x0 = (xindex % 64)
    x2 = ((xindex // 36864) % 4)
    x4 = (xindex % 147456)
    x5 = xindex
    tmp3 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last')
    tmp4 = tl.load(in_ptr1 + (0))
    tmp5 = tl.broadcast_to(tmp4, [XBLOCK])
    tmp7 = tl.load(in_ptr2 + (x0 + 64*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp8 = tl.load(in_ptr3 + (x4), None, eviction_policy='evict_last').to(tl.float32)
    tmp10 = tl.load(in_ptr3 + (x5), None).to(tl.float32)
    tmp0 = (x3).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp6 = tmp3 == tmp5
    tmp9 = tl.where(tmp6, tmp7, tmp8)
    tmp11 = tl.where(tmp2, tmp9, tmp10)
    tl.store(out_ptr0 + (x5), tmp11, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/rm/crmxqtutggacqd3gl7czr5u6ooxhvy77ekjn6dvff6mtlf6qho2h.py
# Topologically Sorted Source Nodes: [eq, write, o_1, linear_9, view_7, v_1, full_v_2, getitem_19, expand_3, full_v_3], Original ATen: [aten.eq, aten.view, aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   eq => eq
#   expand_3 => expand_7
#   full_v_2 => select_9, where_5
#   full_v_3 => clone_3, view_38
#   getitem_19 => unsqueeze_3
#   linear_9 => view_35
#   o_1 => bmm_3, convert_element_type_35, div_2, full_default_5, logical_not_3, view_42, view_43, where_7
#   v_1 => permute_19
#   view_7 => view_36
#   write => view
# Graph fragment:
#   %any_2 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]cpu" = PlaceHolder[target=any_2]
#   %exp_2 : Tensor "f32[1, 16, 1, 576][9216, 576, 9216, 1]cpu" = PlaceHolder[target=exp_2]
#   %sum_2 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]cpu" = PlaceHolder[target=sum_2]
#   %arg3_1 : Tensor "i64[576][1]cpu" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %mm_9 : Tensor "f16[1, 256][256, 1]cpu" = PlaceHolder[target=mm_9]
#   %select_scatter_default_1 : Tensor "f16[4, 1, 4, 576, 64][147456, 589824, 36864, 64, 1]cpu" = PlaceHolder[target=select_scatter_default_1]
#   %eq : Tensor "b8[576][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%arg3_1, %arg4_1), kwargs = {})
#   %view : Tensor "b8[1, 1, 576, 1][576, 576, 1, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 1, -1, 1]), kwargs = {})
#   %logical_not_3 : Tensor "b8[1, 16, 1, 1][16, 1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_2,), kwargs = {})
#   %full_default_5 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 1, 576], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: cpu, pin_memory: False})
#   %div_2 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp_2, %sum_2), kwargs = {})
#   %where_7 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_3, %full_default_5, %div_2), kwargs = {})
#   %view_42 : Tensor "f32[16, 1, 576][576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_10, [16, 1, 576]), kwargs = {})
#   %view_35 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_9, [1, 1, 256]), kwargs = {})
#   %view_36 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_35, [1, 1, 4, 64]), kwargs = {})
#   %permute_19 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_36, [0, 2, 1, 3]), kwargs = {})
#   %select_9 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 1), kwargs = {})
#   %where_5 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%view, %permute_19, %select_9), kwargs = {})
#   %unsqueeze_3 : Tensor "f16[1, 4, 1, 576, 64][147456, 36864, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%where_5, 2), kwargs = {})
#   %expand_7 : Tensor "f16[1, 4, 4, 576, 64][147456, 36864, 0, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [1, 4, 4, -1, 64]), kwargs = {})
#   %clone_3 : Tensor "f16[1, 4, 4, 576, 64][589824, 147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_7,), kwargs = {memory_format: torch.contiguous_format})
#   %view_38 : Tensor "f16[1, 16, 576, 64][589824, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_3, [1, 16, 576, 64]), kwargs = {})
#   %convert_element_type_35 : Tensor "f32[1, 16, 576, 64][589824, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_38, torch.float32), kwargs = {})
#   %view_43 : Tensor "f32[16, 576, 64][36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_11, [16, 576, 64]), kwargs = {})
#   %bmm_3 : Tensor "f32[16, 1, 64][64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_42, %view_43), kwargs = {})
#   return %buf45
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_21 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_21', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 8192, 'r0_': 128},
    reduction_hint=ReductionHint.OUTER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i1', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*i64', 'in_ptr4': '*i64', 'in_ptr5': '*fp16', 'in_ptr6': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_21', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 1221120, 'r0_': 41472}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_21(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 5120
    XBLOCK: tl.constexpr = 1
    r0_numel = 116
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = ((xindex // 64) % 5)
    x2 = xindex // 320
    x0 = (xindex % 64)
    _tmp23 = tl.full([R0_BLOCK], 0, tl.float32)
    x4 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = r0_index
        tmp0 = (r0_3 + 116*x1).to(tl.int32)
        tmp1 = tl.full([1], 576, tl.int32)
        tmp2 = tmp0 < tmp1
        tmp3 = tl.load(in_ptr0 + (tl.broadcast_to(x2, [R0_BLOCK])), r0_mask & tmp2, eviction_policy='evict_last', other=0.0).to(tl.int1)
        tmp4 = tmp3 == 0
        tmp5 = tl.load(in_ptr1 + (r0_3 + 116*x1 + 576*x2), r0_mask & tmp2, eviction_policy='evict_last', other=0.0)
        tmp6 = tl.load(in_ptr2 + (tl.broadcast_to(x2, [R0_BLOCK])), r0_mask & tmp2, eviction_policy='evict_last', other=0.0)
        tmp7 = (tmp5 / tmp6)
        tmp8 = tl.full([1], 0.0, tl.float32)
        tmp9 = tl.where(tmp4, tmp8, tmp7)
        tmp10 = tl.load(in_ptr3 + (r0_3 + 116*x1), r0_mask & tmp2, eviction_policy='evict_last', other=0.0)
        tmp11 = tl.load(in_ptr4 + (0))
        tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
        tmp13 = tl.where(tmp2, tmp12, 0)
        tmp14 = tmp10 == tmp13
        tmp15 = tl.load(in_ptr5 + (tl.broadcast_to(x0 + 64*(x2 // 4), [R0_BLOCK])), r0_mask & tmp2, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp16 = tl.load(in_ptr6 + (147456 + x0 + 64*r0_3 + 7424*x1 + 36864*(x2 // 4)), r0_mask & tmp2, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp17 = tl.where(tmp14, tmp15, tmp16)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp9 * tmp18
        tmp20 = tl.full(tmp19.shape, 0, tmp19.dtype)
        tmp21 = tl.where(tmp2, tmp19, tmp20)
        tmp22 = tl.broadcast_to(tmp21, [R0_BLOCK])
        tmp24 = _tmp23 + tmp22
        _tmp23 = tl.where(r0_mask, tmp24, _tmp23)
    tmp23 = triton_helpers.promote_to_tensor(tl.sum(_tmp23, 0))
    tl.store(out_ptr0 + (x4), tmp23, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/6v/c6vxpo6z7ksjenbrnywjx3khpyapj6gkewedq3ono6qknajrqtv3.py
# Topologically Sorted Source Nodes: [x, linear_3, x_1, linear_6, x_2, linear_10, x_3, y_3], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   linear_10 => view_47
#   linear_3 => view_21
#   linear_6 => view_27
#   x => embedding
#   x_1 => add_4
#   x_2 => add_7
#   x_3 => add_12
#   y_3 => add_13, convert_element_type_40, convert_element_type_41, mean_3, mul_19, mul_20, pow_4, rsqrt_3
# Graph fragment:
#   %arg2_1 : Tensor "i64[1, 1][512, 1]cpu" = PlaceHolder[target=arg2_1]
#   %arg7_1 : Tensor "f16[32000, 1024][1024, 1]cpu" = PlaceHolder[target=arg7_1]
#   %mm_3 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_3]
#   %mm_6 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_6]
#   %mm_10 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_10]
#   %add_12 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=add_12]
#   %buf50 : Tensor "f32[1, 1, 1][1, 1, 1]cpu" = PlaceHolder[target=buf50]
#   %arg22_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg22_1]
#   %embedding : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg7_1, %arg2_1), kwargs = {})
#   %view_21 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 1024]), kwargs = {})
#   %add_4 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_21), kwargs = {})
#   %view_27 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 1, 1024]), kwargs = {})
#   %add_7 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_4, %view_27), kwargs = {})
#   %view_47 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_10, [1, 1, 1024]), kwargs = {})
#   %add_12 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_7, %view_47), kwargs = {})
#   %convert_element_type_40 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_12, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_40, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [2], True), kwargs = {})
#   %add_13 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_3, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_13,), kwargs = {})
#   %mul_19 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_40, %rsqrt_3), kwargs = {})
#   %mul_20 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_19, %arg22_1), kwargs = {})
#   %convert_element_type_41 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_20, torch.float16), kwargs = {})
#   return %add_12,%buf50,%convert_element_type_41
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_22 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_22', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_22', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 16384}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_22(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr3, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    _tmp13 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp6 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 32000), "index out of bounds: 0 <= tmp1 < 32000")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 1024*tmp1), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp9 = tmp7 + tmp8
        tmp10 = tmp9.to(tl.float32)
        tmp11 = tmp10 * tmp10
        tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
        tmp14 = _tmp13 + tmp12
        _tmp13 = tl.where(r0_mask, tmp14, _tmp13)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp9, r0_mask)
    tmp13 = triton_helpers.promote_to_tensor(tl.sum(_tmp13, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_out_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp23 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tl.full([1], 1024.0, tl.float32)
        tmp18 = (tmp13 / tmp17)
        tmp19 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = libdevice.rsqrt(tmp20)
        tmp22 = tmp16 * tmp21
        tmp24 = tmp23.to(tl.float32)
        tmp25 = tmp22 * tmp24
        tmp26 = tmp25.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp26, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/ey/ceysakblqvl4vtryyneikwx5pewfovlhbpxtqiu2qi5yxc4ml3ku.py
# Topologically Sorted Source Nodes: [y_3, linear_11], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_11 => mm_11, permute_25, view_48
#   y_3 => add_13, convert_element_type_40, convert_element_type_41, mean_3, mul_19, mul_20, pow_4, rsqrt_3
# Graph fragment:
#   %convert_element_type_41 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=convert_element_type_41]
#   %arg23_1 : Tensor "f16[2816, 1024][1024, 1]cpu" = PlaceHolder[target=arg23_1]
#   %convert_element_type_40 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_12, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_40, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [2], True), kwargs = {})
#   %add_13 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_3, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_13,), kwargs = {})
#   %mul_19 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_40, %rsqrt_3), kwargs = {})
#   %mul_20 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_19, %arg22_1), kwargs = {})
#   %convert_element_type_41 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_20, torch.float16), kwargs = {})
#   %view_48 : Tensor "f16[1, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_41, [1, 1024]), kwargs = {})
#   %permute_25 : Tensor "f16[1024, 2816][1, 1024]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg23_1, [1, 0]), kwargs = {})
#   %mm_11 : Tensor "f16[1, 2816][2816, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_48, %permute_25), kwargs = {})
#   return %mm_11
triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_23 = async_compile.triton('triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_23', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_23', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_23(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 2816
    K = 1024
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 1024

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 1024*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 2816*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 1024*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 2816*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/l3/cl3rba7ncmej4j6clgimxhgvqsk3isk7h5yxdiurfoth7wmisuei.py
# Topologically Sorted Source Nodes: [linear_13, x_4, y_4], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   linear_13 => view_53
#   x_4 => add_15
#   y_4 => add_16, convert_element_type_50, convert_element_type_51, mean_4, mul_22, mul_23, pow_5, rsqrt_4
# Graph fragment:
#   %add_12 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=add_12]
#   %mm_13 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_13]
#   %buf56 : Tensor "f32[1, 1, 1][1, 1, 1]cpu" = PlaceHolder[target=buf56]
#   %arg26_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg26_1]
#   %view_53 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 1, 1024]), kwargs = {})
#   %add_15 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_12, %view_53), kwargs = {})
#   %convert_element_type_50 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_15, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_50, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [2], True), kwargs = {})
#   %add_16 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_4, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_16,), kwargs = {})
#   %mul_22 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_50, %rsqrt_4), kwargs = {})
#   %mul_23 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_22, %arg26_1), kwargs = {})
#   %convert_element_type_51 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_23, torch.float16), kwargs = {})
#   return %buf56,%convert_element_type_51
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 10240}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr1, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 1024.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp17 * tmp19
        tmp21 = tmp20.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp21, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/4j/c4j4vi4lgtxpm246zo5nvaq6szliga4xo3dbkdnlih4yjz56bimn.py
# Topologically Sorted Source Nodes: [cos, sin, eq, write, linear_15, view_9, k_4, mul_12, mul_13, k_5, full_k_4], Original ATen: [aten.index_select, aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.mul, aten.add, aten.select, aten.where]
# Source node to ATen node mapping:
#   cos => index
#   eq => eq
#   full_k_4 => select_17, where_8
#   k_4 => permute_31
#   k_5 => add_18
#   linear_15 => view_58
#   mul_12 => mul_26
#   mul_13 => mul_27
#   sin => index_1
#   view_9 => view_59
#   write => view
# Graph fragment:
#   %arg3_1 : Tensor "i64[576][1]cpu" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %mm_15 : Tensor "f16[1, 256][256, 1]cpu" = PlaceHolder[target=mm_15]
#   %arg5_1 : Tensor "f16[576, 64][64, 1]cpu" = PlaceHolder[target=arg5_1]
#   %cat_5 : Tensor "f16[1, 4, 1, 64][256, 64, 64, 1]cpu" = PlaceHolder[target=cat_5]
#   %arg6_1 : Tensor "f16[576, 64][64, 1]cpu" = PlaceHolder[target=arg6_1]
#   %where_4 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu" = PlaceHolder[target=where_4]
#   %where : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu" = PlaceHolder[target=where]
#   %copy_ : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu" = PlaceHolder[target=copy_]
#   %index : Tensor "f16[1, 64][64, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg5_1, [%arg4_1]), kwargs = {})
#   %index_1 : Tensor "f16[1, 64][64, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg6_1, [%arg4_1]), kwargs = {})
#   %eq : Tensor "b8[576][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%arg3_1, %arg4_1), kwargs = {})
#   %view : Tensor "b8[1, 1, 576, 1][576, 576, 1, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 1, -1, 1]), kwargs = {})
#   %select_scatter_default : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=3] = call_function[target=torch.ops.aten.select_scatter.default](args = (%arg0_1, %where, 0, 0), kwargs = {})
#   %view_58 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_15, [1, 1, 256]), kwargs = {})
#   %view_59 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_58, [1, 1, 4, 64]), kwargs = {})
#   %permute_31 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_59, [0, 2, 1, 3]), kwargs = {})
#   %select_scatter_default_2 : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=3] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %where_4, 0, 1), kwargs = {})
#   %mul_26 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_31, %index), kwargs = {})
#   %mul_27 : Tensor "f16[1, 4, 1, 64][256, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_5, %index_1), kwargs = {})
#   %add_18 : Tensor "f16[1, 4, 1, 64][256, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_26, %mul_27), kwargs = {})
#   %select_17 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_2, 0, 2), kwargs = {})
#   %where_8 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%view, %add_18, %select_17), kwargs = {})
#   return %where_8
triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_25 = async_compile.triton('triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_25', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'in_ptr5': '*fp16', 'in_ptr6': '*fp16', 'in_ptr7': '*fp16', 'in_ptr8': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_25', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1480192}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_25(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, in_ptr7, in_ptr8, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 147456
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = ((xindex // 64) % 576)
    x0 = (xindex % 64)
    x2 = xindex // 36864
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last')
    tmp1 = tl.load(in_ptr1 + (0))
    tmp2 = tl.broadcast_to(tmp1, [XBLOCK])
    tmp4 = tl.load(in_ptr2 + (x0 + 64*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp12 = tl.load(in_ptr4 + (x0 + 64*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp19 = tl.load(in_ptr6 + (x4), None).to(tl.float32)
    tmp22 = tl.load(in_ptr7 + (x4), None).to(tl.float32)
    tmp23 = tl.load(in_ptr8 + (294912 + x4), None).to(tl.float32)
    tmp3 = tmp0 == tmp2
    tmp5 = (tl.full([XBLOCK], 576, tl.int32)).to(tl.int32)
    tmp6 = tmp2 + tmp5
    tmp7 = tmp2 < 0
    tmp8 = tl.where(tmp7, tmp6, tmp2)
    tl.device_assert((0 <= tmp8) & (tmp8 < 576), "index out of bounds: 0 <= tmp8 < 576")
    tmp10 = tl.load(in_ptr3 + (x0 + 64*tmp8), None).to(tl.float32)
    tmp11 = tmp4 * tmp10
    tmp13 = tl.load(in_ptr5 + (x0 + 64*tmp8), None).to(tl.float32)
    tmp14 = tmp12 * tmp13
    tmp15 = tmp11 + tmp14
    tmp16 = tl.full([1], 2, tl.int32)
    tmp17 = tl.full([1], 1, tl.int32)
    tmp18 = tmp16 == tmp17
    tmp20 = tl.full([1], 0, tl.int32)
    tmp21 = tmp16 == tmp20
    tmp24 = tl.where(tmp21, tmp22, tmp23)
    tmp25 = tl.where(tmp18, tmp19, tmp24)
    tmp26 = tl.where(tmp3, tmp15, tmp25)
    tl.store(out_ptr0 + (x4), tmp26, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/od/codloqmclb5i7gkoqx76d5tykqk4owpv4lqtj5lmoas2iik7nbr5.py
# Topologically Sorted Source Nodes: [eq, write, linear_9, view_7, v_1, full_v_2], Original ATen: [aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.select, aten.where]
# Source node to ATen node mapping:
#   eq => eq
#   full_v_2 => select_9, where_5
#   linear_9 => view_35
#   v_1 => permute_19
#   view_7 => view_36
#   write => view
# Graph fragment:
#   %arg3_1 : Tensor "i64[576][1]cpu" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %mm_9 : Tensor "f16[1, 256][256, 1]cpu" = PlaceHolder[target=mm_9]
#   %select_scatter_default_1 : Tensor "f16[4, 1, 4, 576, 64][147456, 589824, 36864, 64, 1]cpu" = PlaceHolder[target=select_scatter_default_1]
#   %eq : Tensor "b8[576][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%arg3_1, %arg4_1), kwargs = {})
#   %view : Tensor "b8[1, 1, 576, 1][576, 576, 1, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 1, -1, 1]), kwargs = {})
#   %view_35 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_9, [1, 1, 256]), kwargs = {})
#   %view_36 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_35, [1, 1, 4, 64]), kwargs = {})
#   %permute_19 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_36, [0, 2, 1, 3]), kwargs = {})
#   %select_9 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 1), kwargs = {})
#   %where_5 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%view, %permute_19, %select_9), kwargs = {})
#   %select_scatter_default_3 : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=3] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %where_5, 0, 1), kwargs = {})
#   return %select_scatter_default_3
triton_poi_fused__unsafe_view_eq_select_transpose_view_where_26 = async_compile.triton('triton_poi_fused__unsafe_view_eq_select_transpose_view_where_26', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_eq_select_transpose_view_where_26', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3838976}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_eq_select_transpose_view_where_26(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 589824
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x3 = xindex // 147456
    x1 = ((xindex // 64) % 576)
    x0 = (xindex % 64)
    x2 = ((xindex // 36864) % 4)
    x4 = (xindex % 147456)
    x5 = xindex
    tmp3 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last')
    tmp4 = tl.load(in_ptr1 + (0))
    tmp5 = tl.broadcast_to(tmp4, [XBLOCK])
    tmp7 = tl.load(in_ptr2 + (x0 + 64*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp8 = tl.load(in_ptr3 + (147456 + x4), None, eviction_policy='evict_last').to(tl.float32)
    tmp10 = tl.load(in_ptr3 + (x5), None).to(tl.float32)
    tmp0 = (x3).to(tl.int32)
    tmp1 = tl.full([1], 1, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp6 = tmp3 == tmp5
    tmp9 = tl.where(tmp6, tmp7, tmp8)
    tmp11 = tl.where(tmp2, tmp9, tmp10)
    tl.store(out_ptr0 + (x5), tmp11, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/um/cumammske4mbcgwuoponvptrulsh6kmsdnhuz2ad4ax4cpotcgjv.py
# Topologically Sorted Source Nodes: [eq, write, o_2, linear_16, view_10, v_2, full_v_4, getitem_29, expand_5, full_v_5], Original ATen: [aten.eq, aten.view, aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   eq => eq
#   expand_5 => expand_13
#   full_v_4 => select_19, where_9
#   full_v_5 => clone_5, view_64
#   getitem_29 => unsqueeze_5
#   linear_16 => view_61
#   o_2 => bmm_5, convert_element_type_60, div_4, full_default_8, logical_not_5, view_68, view_69, where_11
#   v_2 => permute_33
#   view_10 => view_62
#   write => view
# Graph fragment:
#   %any_3 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]cpu" = PlaceHolder[target=any_3]
#   %exp_4 : Tensor "f32[1, 16, 1, 576][9216, 576, 9216, 1]cpu" = PlaceHolder[target=exp_4]
#   %sum_3 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]cpu" = PlaceHolder[target=sum_3]
#   %arg3_1 : Tensor "i64[576][1]cpu" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %mm_16 : Tensor "f16[1, 256][256, 1]cpu" = PlaceHolder[target=mm_16]
#   %select_scatter_default_3 : Tensor "f16[4, 1, 4, 576, 64][147456, 589824, 36864, 64, 1]cpu" = PlaceHolder[target=select_scatter_default_3]
#   %eq : Tensor "b8[576][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%arg3_1, %arg4_1), kwargs = {})
#   %view : Tensor "b8[1, 1, 576, 1][576, 576, 1, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 1, -1, 1]), kwargs = {})
#   %logical_not_5 : Tensor "b8[1, 16, 1, 1][16, 1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_3,), kwargs = {})
#   %full_default_8 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 1, 576], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: cpu, pin_memory: False})
#   %div_4 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp_4, %sum_3), kwargs = {})
#   %where_11 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_5, %full_default_8, %div_4), kwargs = {})
#   %view_68 : Tensor "f32[16, 1, 576][576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_16, [16, 1, 576]), kwargs = {})
#   %view_61 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_16, [1, 1, 256]), kwargs = {})
#   %view_62 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_61, [1, 1, 4, 64]), kwargs = {})
#   %permute_33 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_62, [0, 2, 1, 3]), kwargs = {})
#   %select_19 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_3, 0, 2), kwargs = {})
#   %where_9 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%view, %permute_33, %select_19), kwargs = {})
#   %unsqueeze_5 : Tensor "f16[1, 4, 1, 576, 64][147456, 36864, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%where_9, 2), kwargs = {})
#   %expand_13 : Tensor "f16[1, 4, 4, 576, 64][147456, 36864, 0, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_5, [1, 4, 4, -1, 64]), kwargs = {})
#   %clone_5 : Tensor "f16[1, 4, 4, 576, 64][589824, 147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_13,), kwargs = {memory_format: torch.contiguous_format})
#   %view_64 : Tensor "f16[1, 16, 576, 64][589824, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_5, [1, 16, 576, 64]), kwargs = {})
#   %convert_element_type_60 : Tensor "f32[1, 16, 576, 64][589824, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_64, torch.float32), kwargs = {})
#   %view_69 : Tensor "f32[16, 576, 64][36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_17, [16, 576, 64]), kwargs = {})
#   %bmm_5 : Tensor "f32[16, 1, 64][64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_68, %view_69), kwargs = {})
#   return %buf74
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_27 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_27', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 8192, 'r0_': 128},
    reduction_hint=ReductionHint.OUTER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i1', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*i64', 'in_ptr4': '*i64', 'in_ptr5': '*fp16', 'in_ptr6': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_27', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 1221120, 'r0_': 41472}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_27(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 5120
    XBLOCK: tl.constexpr = 1
    r0_numel = 116
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = ((xindex // 64) % 5)
    x2 = xindex // 320
    x0 = (xindex % 64)
    _tmp23 = tl.full([R0_BLOCK], 0, tl.float32)
    x4 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = r0_index
        tmp0 = (r0_3 + 116*x1).to(tl.int32)
        tmp1 = tl.full([1], 576, tl.int32)
        tmp2 = tmp0 < tmp1
        tmp3 = tl.load(in_ptr0 + (tl.broadcast_to(x2, [R0_BLOCK])), r0_mask & tmp2, eviction_policy='evict_last', other=0.0).to(tl.int1)
        tmp4 = tmp3 == 0
        tmp5 = tl.load(in_ptr1 + (r0_3 + 116*x1 + 576*x2), r0_mask & tmp2, eviction_policy='evict_last', other=0.0)
        tmp6 = tl.load(in_ptr2 + (tl.broadcast_to(x2, [R0_BLOCK])), r0_mask & tmp2, eviction_policy='evict_last', other=0.0)
        tmp7 = (tmp5 / tmp6)
        tmp8 = tl.full([1], 0.0, tl.float32)
        tmp9 = tl.where(tmp4, tmp8, tmp7)
        tmp10 = tl.load(in_ptr3 + (r0_3 + 116*x1), r0_mask & tmp2, eviction_policy='evict_last', other=0.0)
        tmp11 = tl.load(in_ptr4 + (0))
        tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
        tmp13 = tl.where(tmp2, tmp12, 0)
        tmp14 = tmp10 == tmp13
        tmp15 = tl.load(in_ptr5 + (tl.broadcast_to(x0 + 64*(x2 // 4), [R0_BLOCK])), r0_mask & tmp2, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp16 = tl.load(in_ptr6 + (294912 + x0 + 64*r0_3 + 7424*x1 + 36864*(x2 // 4)), r0_mask & tmp2, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp17 = tl.where(tmp14, tmp15, tmp16)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp9 * tmp18
        tmp20 = tl.full(tmp19.shape, 0, tmp19.dtype)
        tmp21 = tl.where(tmp2, tmp19, tmp20)
        tmp22 = tl.broadcast_to(tmp21, [R0_BLOCK])
        tmp24 = _tmp23 + tmp22
        _tmp23 = tl.where(r0_mask, tmp24, _tmp23)
    tmp23 = triton_helpers.promote_to_tensor(tl.sum(_tmp23, 0))
    tl.store(out_ptr0 + (x4), tmp23, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/ob/cobhyizoe6kph245xwyglozb5wcxmgi3csldq3rlhr7yjjrgxf6d.py
# Topologically Sorted Source Nodes: [eq, write, linear_16, view_10, v_2, full_v_4], Original ATen: [aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.select, aten.where]
# Source node to ATen node mapping:
#   eq => eq
#   full_v_4 => select_19, where_9
#   linear_16 => view_61
#   v_2 => permute_33
#   view_10 => view_62
#   write => view
# Graph fragment:
#   %arg3_1 : Tensor "i64[576][1]cpu" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %mm_16 : Tensor "f16[1, 256][256, 1]cpu" = PlaceHolder[target=mm_16]
#   %select_scatter_default_3 : Tensor "f16[4, 1, 4, 576, 64][147456, 589824, 36864, 64, 1]cpu" = PlaceHolder[target=select_scatter_default_3]
#   %eq : Tensor "b8[576][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%arg3_1, %arg4_1), kwargs = {})
#   %view : Tensor "b8[1, 1, 576, 1][576, 576, 1, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 1, -1, 1]), kwargs = {})
#   %view_61 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_16, [1, 1, 256]), kwargs = {})
#   %view_62 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_61, [1, 1, 4, 64]), kwargs = {})
#   %permute_33 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_62, [0, 2, 1, 3]), kwargs = {})
#   %select_19 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_3, 0, 2), kwargs = {})
#   %where_9 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%view, %permute_33, %select_19), kwargs = {})
#   %select_scatter_default_6 : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=3] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_3, %where_9, 0, 2), kwargs = {})
#   return %select_scatter_default_6
triton_poi_fused__unsafe_view_eq_select_transpose_view_where_28 = async_compile.triton('triton_poi_fused__unsafe_view_eq_select_transpose_view_where_28', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_eq_select_transpose_view_where_28', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3838976}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_eq_select_transpose_view_where_28(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 589824
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x3 = xindex // 147456
    x1 = ((xindex // 64) % 576)
    x0 = (xindex % 64)
    x2 = ((xindex // 36864) % 4)
    x4 = (xindex % 147456)
    x5 = xindex
    tmp3 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last')
    tmp4 = tl.load(in_ptr1 + (0))
    tmp5 = tl.broadcast_to(tmp4, [XBLOCK])
    tmp7 = tl.load(in_ptr2 + (x0 + 64*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp8 = tl.load(in_ptr3 + (294912 + x4), None, eviction_policy='evict_last').to(tl.float32)
    tmp10 = tl.load(in_ptr3 + (x5), None).to(tl.float32)
    tmp0 = (x3).to(tl.int32)
    tmp1 = tl.full([1], 2, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp6 = tmp3 == tmp5
    tmp9 = tl.where(tmp6, tmp7, tmp8)
    tmp11 = tl.where(tmp2, tmp9, tmp10)
    tl.store(out_ptr0 + (x5), tmp11, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/67/c67wcajuytjd7j2lchcvklaxkru346e6ajz54uazkzfwkgd5mntt.py
# Topologically Sorted Source Nodes: [linear_13, x_4, linear_17, x_5, y_5], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   linear_13 => view_53
#   linear_17 => view_73
#   x_4 => add_15
#   x_5 => add_20
#   y_5 => add_21, convert_element_type_65, convert_element_type_66, mean_5, mul_30, mul_31, pow_6, rsqrt_5
# Graph fragment:
#   %add_12 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=add_12]
#   %mm_13 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_13]
#   %mm_17 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_17]
#   %buf78 : Tensor "f32[1, 1, 1][1, 1, 1]cpu" = PlaceHolder[target=buf78]
#   %arg31_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg31_1]
#   %view_53 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 1, 1024]), kwargs = {})
#   %add_15 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_12, %view_53), kwargs = {})
#   %view_73 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_17, [1, 1, 1024]), kwargs = {})
#   %add_20 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_15, %view_73), kwargs = {})
#   %convert_element_type_65 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_20, torch.float32), kwargs = {})
#   %pow_6 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_65, 2), kwargs = {})
#   %mean_5 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [2], True), kwargs = {})
#   %add_21 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_5, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_5 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_21,), kwargs = {})
#   %mul_30 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_65, %rsqrt_5), kwargs = {})
#   %mul_31 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_30, %arg31_1), kwargs = {})
#   %convert_element_type_66 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_31, torch.float16), kwargs = {})
#   return %buf78,%convert_element_type_66
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_29 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_29', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_29', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 12288}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_29(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    _tmp8 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp5
        tmp7 = tl.broadcast_to(tmp6, [R0_BLOCK])
        tmp9 = _tmp8 + tmp7
        _tmp8 = tl.where(r0_mask, tmp9, _tmp8)
    tmp8 = triton_helpers.promote_to_tensor(tl.sum(_tmp8, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr1, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr2, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp10 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp11 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp12 = tmp10 + tmp11
        tmp14 = tmp12 + tmp13
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 1024.0, tl.float32)
        tmp17 = (tmp8 / tmp16)
        tmp18 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp21 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp25, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/ir/cirlvghyobk4uk7h2b2svnlzfbqzhfajhzyssgg3nlqvtqj6zqz3.py
# Topologically Sorted Source Nodes: [linear_13, x_4, linear_17, x_5, linear_20, x_6, y_6], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   linear_13 => view_53
#   linear_17 => view_73
#   linear_20 => view_79
#   x_4 => add_15
#   x_5 => add_20
#   x_6 => add_23
#   y_6 => add_24, convert_element_type_75, convert_element_type_76, mean_6, mul_33, mul_34, pow_7, rsqrt_6
# Graph fragment:
#   %add_12 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=add_12]
#   %mm_13 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_13]
#   %mm_17 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_17]
#   %mm_20 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_20]
#   %buf84 : Tensor "f32[1, 1, 1][1, 1, 1]cpu" = PlaceHolder[target=buf84]
#   %arg35_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg35_1]
#   %view_53 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 1, 1024]), kwargs = {})
#   %add_15 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_12, %view_53), kwargs = {})
#   %view_73 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_17, [1, 1, 1024]), kwargs = {})
#   %add_20 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_15, %view_73), kwargs = {})
#   %view_79 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_20, [1, 1, 1024]), kwargs = {})
#   %add_23 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_20, %view_79), kwargs = {})
#   %convert_element_type_75 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_23, torch.float32), kwargs = {})
#   %pow_7 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_75, 2), kwargs = {})
#   %mean_6 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [2], True), kwargs = {})
#   %add_24 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_6, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_6 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_24,), kwargs = {})
#   %mul_33 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_75, %rsqrt_6), kwargs = {})
#   %mul_34 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_33, %arg35_1), kwargs = {})
#   %convert_element_type_76 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_34, torch.float16), kwargs = {})
#   return %buf84,%convert_element_type_76
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 14336}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    _tmp10 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
    tmp10 = triton_helpers.promote_to_tensor(tl.sum(_tmp10, 0))
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor5 = tl.make_tensor_descriptor(in_ptr1, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor6 = tl.make_tensor_descriptor(in_ptr2, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor7 = tl.make_tensor_descriptor(in_ptr3, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp12 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp13 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor6.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp17 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor7.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp26 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp14 = tmp12 + tmp13
        tmp16 = tmp14 + tmp15
        tmp18 = tmp16 + tmp17
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tl.full([1], 1024.0, tl.float32)
        tmp21 = (tmp10 / tmp20)
        tmp22 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp23 = tmp21 + tmp22
        tmp24 = libdevice.rsqrt(tmp23)
        tmp25 = tmp19 * tmp24
        tmp27 = tmp26.to(tl.float32)
        tmp28 = tmp25 * tmp27
        tmp29 = tmp28.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp29, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/mg/cmgq5hpgllwpl76qdty6z4rhmq6pnd3cbpnaj5qmtfjnr3p7xy4w.py
# Topologically Sorted Source Nodes: [eq, write, linear_23, view_13, v_3, full_v_6], Original ATen: [aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten.copy_]
# Source node to ATen node mapping:
#   eq => eq
#   full_v_6 => select_29, where_13
#   linear_23 => view_87
#   v_3 => permute_47
#   view_13 => view_88
#   write => view
# Graph fragment:
#   %arg3_1 : Tensor "i64[576][1]cpu" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %mm_23 : Tensor "f16[1, 256][256, 1]cpu" = PlaceHolder[target=mm_23]
#   %select_scatter_default_6 : Tensor "f16[4, 1, 4, 576, 64][147456, 589824, 36864, 64, 1]cpu" = PlaceHolder[target=select_scatter_default_6]
#   %select_scatter_default_7 : Tensor "f16[4, 1, 4, 576, 64][147456, 589824, 36864, 64, 1]cpu" = PlaceHolder[target=select_scatter_default_7]
#   %copy__1 : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu" = PlaceHolder[target=copy__1]
#   %buf17 : Tensor "f32[16, 1, 64, 5][320, 5120, 1, 64]cpu" = PlaceHolder[target=buf17]
#   %select_scatter_default_1 : Tensor "f16[4, 1, 4, 576, 64][147456, 589824, 36864, 64, 1]cpu" = PlaceHolder[target=select_scatter_default_1]
#   %eq : Tensor "b8[576][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%arg3_1, %arg4_1), kwargs = {})
#   %view : Tensor "b8[1, 1, 576, 1][576, 576, 1, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 1, -1, 1]), kwargs = {})
#   %view_87 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_23, [1, 1, 256]), kwargs = {})
#   %view_88 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_87, [1, 1, 4, 64]), kwargs = {})
#   %permute_47 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_88, [0, 2, 1, 3]), kwargs = {})
#   %select_29 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_6, 0, 3), kwargs = {})
#   %where_13 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%view, %permute_47, %select_29), kwargs = {})
#   %select_scatter_default_7 : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_6, %where_13, 0, 3), kwargs = {})
#   %copy__1 : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg1_1, %select_scatter_default_7), kwargs = {})
#   return %select_scatter_default_7,%buf127
triton_poi_fused__unsafe_view_copy__eq_select_transpose_view_where_31 = async_compile.triton('triton_poi_fused__unsafe_view_copy__eq_select_transpose_view_where_31', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_copy__eq_select_transpose_view_where_31', 'mutated_arg_names': ['out_ptr1'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4723712}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_copy__eq_select_transpose_view_where_31(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 589824
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x3 = xindex // 147456
    x1 = ((xindex // 64) % 576)
    x0 = (xindex % 64)
    x2 = ((xindex // 36864) % 4)
    x5 = (xindex % 147456)
    x4 = xindex
    tmp3 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last')
    tmp4 = tl.load(in_ptr1 + (0))
    tmp5 = tl.broadcast_to(tmp4, [XBLOCK])
    tmp7 = tl.load(in_ptr2 + (x0 + 64*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp8 = tl.load(in_ptr3 + (442368 + x5), None, eviction_policy='evict_last').to(tl.float32)
    tmp10 = tl.load(in_ptr3 + (x4), None).to(tl.float32)
    tmp0 = (x3).to(tl.int32)
    tmp1 = tl.full([1], 3, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp6 = tmp3 == tmp5
    tmp9 = tl.where(tmp6, tmp7, tmp8)
    tmp11 = tl.where(tmp2, tmp9, tmp10)
    tl.store(out_ptr1 + (x4), tmp11, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/yo/cyoxzx6ou6aljwzec3rhd4rnvlbe4n53oi3w44sy47zk7qe4gngg.py
# Topologically Sorted Source Nodes: [cos, sin, eq, write, linear_22, view_12, k_6, mul_17, mul_18, k_7, full_k_6], Original ATen: [aten.index_select, aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.mul, aten.add, aten.select, aten.where]
# Source node to ATen node mapping:
#   cos => index
#   eq => eq
#   full_k_6 => select_27, where_12
#   k_6 => permute_45
#   k_7 => add_26
#   linear_22 => view_84
#   mul_17 => mul_37
#   mul_18 => mul_38
#   sin => index_1
#   view_12 => view_85
#   write => view
# Graph fragment:
#   %arg3_1 : Tensor "i64[576][1]cpu" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %mm_22 : Tensor "f16[1, 256][256, 1]cpu" = PlaceHolder[target=mm_22]
#   %arg5_1 : Tensor "f16[576, 64][64, 1]cpu" = PlaceHolder[target=arg5_1]
#   %cat_7 : Tensor "f16[1, 4, 1, 64][256, 64, 64, 1]cpu" = PlaceHolder[target=cat_7]
#   %arg6_1 : Tensor "f16[576, 64][64, 1]cpu" = PlaceHolder[target=arg6_1]
#   %where_8 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu" = PlaceHolder[target=where_8]
#   %where_4 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu" = PlaceHolder[target=where_4]
#   %where : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu" = PlaceHolder[target=where]
#   %copy_ : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu" = PlaceHolder[target=copy_]
#   %index : Tensor "f16[1, 64][64, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg5_1, [%arg4_1]), kwargs = {})
#   %index_1 : Tensor "f16[1, 64][64, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg6_1, [%arg4_1]), kwargs = {})
#   %eq : Tensor "b8[576][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%arg3_1, %arg4_1), kwargs = {})
#   %view : Tensor "b8[1, 1, 576, 1][576, 576, 1, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 1, -1, 1]), kwargs = {})
#   %select_scatter_default : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=3] = call_function[target=torch.ops.aten.select_scatter.default](args = (%arg0_1, %where, 0, 0), kwargs = {})
#   %select_scatter_default_2 : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=3] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %where_4, 0, 1), kwargs = {})
#   %view_84 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_22, [1, 1, 256]), kwargs = {})
#   %view_85 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_84, [1, 1, 4, 64]), kwargs = {})
#   %permute_45 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_85, [0, 2, 1, 3]), kwargs = {})
#   %select_scatter_default_4 : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=3] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_2, %where_8, 0, 2), kwargs = {})
#   %mul_37 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_45, %index), kwargs = {})
#   %mul_38 : Tensor "f16[1, 4, 1, 64][256, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_7, %index_1), kwargs = {})
#   %add_26 : Tensor "f16[1, 4, 1, 64][256, 64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_37, %mul_38), kwargs = {})
#   %select_27 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_4, 0, 3), kwargs = {})
#   %where_12 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%view, %add_26, %select_27), kwargs = {})
#   return %where_12
triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_32 = async_compile.triton('triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_32', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 262144}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'in_ptr5': '*fp16', 'in_ptr6': '*fp16', 'in_ptr7': '*fp16', 'in_ptr8': '*fp16', 'in_ptr9': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_32', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1775104}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_32(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, in_ptr7, in_ptr8, in_ptr9, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 147456
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = ((xindex // 64) % 576)
    x0 = (xindex % 64)
    x2 = xindex // 36864
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last')
    tmp1 = tl.load(in_ptr1 + (0))
    tmp2 = tl.broadcast_to(tmp1, [XBLOCK])
    tmp4 = tl.load(in_ptr2 + (x0 + 64*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp12 = tl.load(in_ptr4 + (x0 + 64*x2), None, eviction_policy='evict_last').to(tl.float32)
    tmp19 = tl.load(in_ptr6 + (x4), None).to(tl.float32)
    tmp22 = tl.load(in_ptr7 + (x4), None).to(tl.float32)
    tmp25 = tl.load(in_ptr8 + (x4), None).to(tl.float32)
    tmp26 = tl.load(in_ptr9 + (442368 + x4), None).to(tl.float32)
    tmp3 = tmp0 == tmp2
    tmp5 = (tl.full([XBLOCK], 576, tl.int32)).to(tl.int32)
    tmp6 = tmp2 + tmp5
    tmp7 = tmp2 < 0
    tmp8 = tl.where(tmp7, tmp6, tmp2)
    tl.device_assert((0 <= tmp8) & (tmp8 < 576), "index out of bounds: 0 <= tmp8 < 576")
    tmp10 = tl.load(in_ptr3 + (x0 + 64*tmp8), None).to(tl.float32)
    tmp11 = tmp4 * tmp10
    tmp13 = tl.load(in_ptr5 + (x0 + 64*tmp8), None).to(tl.float32)
    tmp14 = tmp12 * tmp13
    tmp15 = tmp11 + tmp14
    tmp16 = tl.full([1], 3, tl.int32)
    tmp17 = tl.full([1], 2, tl.int32)
    tmp18 = tmp16 == tmp17
    tmp20 = tl.full([1], 1, tl.int32)
    tmp21 = tmp16 == tmp20
    tmp23 = tl.full([1], 0, tl.int32)
    tmp24 = tmp16 == tmp23
    tmp27 = tl.where(tmp24, tmp25, tmp26)
    tmp28 = tl.where(tmp21, tmp22, tmp27)
    tmp29 = tl.where(tmp18, tmp19, tmp28)
    tmp30 = tl.where(tmp3, tmp15, tmp29)
    tl.store(out_ptr0 + (x4), tmp30, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/yn/cynjkppsx6qnkqfcinec7ia6w2f7i67u55anku3naysagfzamgnm.py
# Topologically Sorted Source Nodes: [eq, write, linear_23, view_13, v_3, full_v_6, o_3, getitem_39, expand_7, full_v_7], Original ATen: [aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   eq => eq
#   expand_7 => expand_19
#   full_v_6 => select_29, where_13
#   full_v_7 => clone_7, view_90
#   getitem_39 => unsqueeze_7
#   linear_23 => view_87
#   o_3 => bmm_7, convert_element_type_85, div_6, full_default_11, logical_not_7, view_94, view_95, where_15
#   v_3 => permute_47
#   view_13 => view_88
#   write => view
# Graph fragment:
#   %any_4 : Tensor "b8[1, 16, 1, 1][16, 1, 16, 16]cpu" = PlaceHolder[target=any_4]
#   %exp_6 : Tensor "f32[1, 16, 1, 576][9216, 576, 9216, 1]cpu" = PlaceHolder[target=exp_6]
#   %sum_4 : Tensor "f32[1, 16, 1, 1][16, 1, 16, 16]cpu" = PlaceHolder[target=sum_4]
#   %arg3_1 : Tensor "i64[576][1]cpu" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "i64[1][1]cpu" = PlaceHolder[target=arg4_1]
#   %mm_23 : Tensor "f16[1, 256][256, 1]cpu" = PlaceHolder[target=mm_23]
#   %select_scatter_default_6 : Tensor "f16[4, 1, 4, 576, 64][147456, 589824, 36864, 64, 1]cpu" = PlaceHolder[target=select_scatter_default_6]
#   %eq : Tensor "b8[576][1]cpu"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%arg3_1, %arg4_1), kwargs = {})
#   %view : Tensor "b8[1, 1, 576, 1][576, 576, 1, 1]cpu"[num_users=8] = call_function[target=torch.ops.aten.reshape.default](args = (%eq, [1, 1, -1, 1]), kwargs = {})
#   %view_87 : Tensor "f16[1, 1, 256][256, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_23, [1, 1, 256]), kwargs = {})
#   %view_88 : Tensor "f16[1, 1, 4, 64][256, 256, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_87, [1, 1, 4, 64]), kwargs = {})
#   %permute_47 : Tensor "f16[1, 4, 1, 64][256, 64, 256, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_88, [0, 2, 1, 3]), kwargs = {})
#   %select_29 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_6, 0, 3), kwargs = {})
#   %where_13 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.where.self](args = (%view, %permute_47, %select_29), kwargs = {})
#   %logical_not_7 : Tensor "b8[1, 16, 1, 1][16, 1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_4,), kwargs = {})
#   %full_default_11 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 16, 1, 576], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: cpu, pin_memory: False})
#   %div_6 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp_6, %sum_4), kwargs = {})
#   %where_15 : Tensor "f32[1, 16, 1, 576][9216, 576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_7, %full_default_11, %div_6), kwargs = {})
#   %view_94 : Tensor "f32[16, 1, 576][576, 576, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_22, [16, 1, 576]), kwargs = {})
#   %unsqueeze_7 : Tensor "f16[1, 4, 1, 576, 64][147456, 36864, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%where_13, 2), kwargs = {})
#   %expand_19 : Tensor "f16[1, 4, 4, 576, 64][147456, 36864, 0, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_7, [1, 4, 4, -1, 64]), kwargs = {})
#   %clone_7 : Tensor "f16[1, 4, 4, 576, 64][589824, 147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_19,), kwargs = {memory_format: torch.contiguous_format})
#   %view_90 : Tensor "f16[1, 16, 576, 64][589824, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_7, [1, 16, 576, 64]), kwargs = {})
#   %convert_element_type_85 : Tensor "f32[1, 16, 576, 64][589824, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_90, torch.float32), kwargs = {})
#   %view_95 : Tensor "f32[16, 576, 64][36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_23, [16, 576, 64]), kwargs = {})
#   %bmm_7 : Tensor "f32[16, 1, 64][64, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_94, %view_95), kwargs = {})
#   return %buf102
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_33 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_33', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 8192, 'r0_': 128},
    reduction_hint=ReductionHint.OUTER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i1', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*i64', 'in_ptr4': '*i64', 'in_ptr5': '*fp16', 'in_ptr6': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_33', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 1221120, 'r0_': 41472}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_33(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 5120
    XBLOCK: tl.constexpr = 1
    r0_numel = 116
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = ((xindex // 64) % 5)
    x2 = xindex // 320
    x0 = (xindex % 64)
    _tmp23 = tl.full([R0_BLOCK], 0, tl.float32)
    x4 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = r0_index
        tmp0 = (r0_3 + 116*x1).to(tl.int32)
        tmp1 = tl.full([1], 576, tl.int32)
        tmp2 = tmp0 < tmp1
        tmp3 = tl.load(in_ptr0 + (tl.broadcast_to(x2, [R0_BLOCK])), r0_mask & tmp2, eviction_policy='evict_last', other=0.0).to(tl.int1)
        tmp4 = tmp3 == 0
        tmp5 = tl.load(in_ptr1 + (r0_3 + 116*x1 + 576*x2), r0_mask & tmp2, eviction_policy='evict_last', other=0.0)
        tmp6 = tl.load(in_ptr2 + (tl.broadcast_to(x2, [R0_BLOCK])), r0_mask & tmp2, eviction_policy='evict_last', other=0.0)
        tmp7 = (tmp5 / tmp6)
        tmp8 = tl.full([1], 0.0, tl.float32)
        tmp9 = tl.where(tmp4, tmp8, tmp7)
        tmp10 = tl.load(in_ptr3 + (r0_3 + 116*x1), r0_mask & tmp2, eviction_policy='evict_last', other=0.0)
        tmp11 = tl.load(in_ptr4 + (0))
        tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
        tmp13 = tl.where(tmp2, tmp12, 0)
        tmp14 = tmp10 == tmp13
        tmp15 = tl.load(in_ptr5 + (tl.broadcast_to(x0 + 64*(x2 // 4), [R0_BLOCK])), r0_mask & tmp2, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp16 = tl.load(in_ptr6 + (442368 + x0 + 64*r0_3 + 7424*x1 + 36864*(x2 // 4)), r0_mask & tmp2, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp17 = tl.where(tmp14, tmp15, tmp16)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tmp9 * tmp18
        tmp20 = tl.full(tmp19.shape, 0, tmp19.dtype)
        tmp21 = tl.where(tmp2, tmp19, tmp20)
        tmp22 = tl.broadcast_to(tmp21, [R0_BLOCK])
        tmp24 = _tmp23 + tmp22
        _tmp23 = tl.where(r0_mask, tmp24, _tmp23)
    tmp23 = triton_helpers.promote_to_tensor(tl.sum(_tmp23, 0))
    tl.store(out_ptr0 + (x4), tmp23, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/rj/crjqe2vczrf7f55gkriz2xbtnj2n5uhn7j7r6ptarb3ev3zvcs5i.py
# Topologically Sorted Source Nodes: [], Original ATen: [aten.copy_]
# Source node to ATen node mapping:
# Graph fragment:
#   %where_12 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu" = PlaceHolder[target=where_12]
#   %where_8 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu" = PlaceHolder[target=where_8]
#   %where_4 : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu" = PlaceHolder[target=where_4]
#   %where : Tensor "f16[1, 4, 576, 64][147456, 36864, 64, 1]cpu" = PlaceHolder[target=where]
#   %copy_ : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu" = PlaceHolder[target=copy_]
#   %select_scatter_default_5 : Tensor "f16[4, 1, 4, 576, 64][147456, 589824, 36864, 64, 1]cpu" = PlaceHolder[target=select_scatter_default_5]
#   %select_scatter_default : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=3] = call_function[target=torch.ops.aten.select_scatter.default](args = (%arg0_1, %where, 0, 0), kwargs = {})
#   %select_scatter_default_2 : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=3] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %where_4, 0, 1), kwargs = {})
#   %select_scatter_default_4 : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=3] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_2, %where_8, 0, 2), kwargs = {})
#   %select_scatter_default_5 : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_4, %where_12, 0, 3), kwargs = {})
#   %copy_ : Tensor "f16[4, 1, 4, 576, 64][147456, 147456, 36864, 64, 1]cpu"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg0_1, %select_scatter_default_5), kwargs = {})
#   return %select_scatter_default_5,%buf122
triton_poi_fused_copy__34 = async_compile.triton('triton_poi_fused_copy__34', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1048576}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_copy__34', 'mutated_arg_names': ['in_ptr4', 'out_ptr1'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 4718592}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_copy__34(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 589824
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = xindex // 147456
    x0 = (xindex % 147456)
    x2 = xindex
    tmp3 = tl.load(in_ptr0 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp6 = tl.load(in_ptr1 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp9 = tl.load(in_ptr2 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp12 = tl.load(in_ptr3 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp13 = tl.load(in_ptr4 + (x2), None).to(tl.float32)
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 3, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp4 = tl.full([1], 2, tl.int32)
    tmp5 = tmp0 == tmp4
    tmp7 = tl.full([1], 1, tl.int32)
    tmp8 = tmp0 == tmp7
    tmp10 = tl.full([1], 0, tl.int32)
    tmp11 = tmp0 == tmp10
    tmp14 = tl.where(tmp11, tmp12, tmp13)
    tmp15 = tl.where(tmp8, tmp9, tmp14)
    tmp16 = tl.where(tmp5, tmp6, tmp15)
    tmp17 = tl.where(tmp2, tmp3, tmp16)
    tl.store(out_ptr1 + (x2), tmp17, None)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/c7/cc7q7p642twqziwheqbatbp4byrtadtvxnrwrjydu33nteotrtzy.py
# Topologically Sorted Source Nodes: [linear_13, x_4, linear_17, x_5, linear_20, x_6, linear_24, x_7, y_7], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   linear_13 => view_53
#   linear_17 => view_73
#   linear_20 => view_79
#   linear_24 => view_99
#   x_4 => add_15
#   x_5 => add_20
#   x_6 => add_23
#   x_7 => add_28
#   y_7 => add_29, convert_element_type_90, convert_element_type_91, mean_7, mul_41, mul_42, pow_8, rsqrt_7
# Graph fragment:
#   %add_12 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=add_12]
#   %mm_13 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_13]
#   %mm_17 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_17]
#   %mm_20 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_20]
#   %mm_24 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_24]
#   %add_28 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=add_28]
#   %buf107 : Tensor "f32[1, 1, 1][1, 1, 1]cpu" = PlaceHolder[target=buf107]
#   %arg40_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg40_1]
#   %view_53 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 1, 1024]), kwargs = {})
#   %add_15 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_12, %view_53), kwargs = {})
#   %view_73 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_17, [1, 1, 1024]), kwargs = {})
#   %add_20 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_15, %view_73), kwargs = {})
#   %view_79 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_20, [1, 1, 1024]), kwargs = {})
#   %add_23 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_20, %view_79), kwargs = {})
#   %view_99 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_24, [1, 1, 1024]), kwargs = {})
#   %add_28 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_23, %view_99), kwargs = {})
#   %convert_element_type_90 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_28, torch.float32), kwargs = {})
#   %pow_8 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_90, 2), kwargs = {})
#   %mean_7 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_8, [2], True), kwargs = {})
#   %add_29 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_7, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_7 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_29,), kwargs = {})
#   %mul_41 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_90, %rsqrt_7), kwargs = {})
#   %mul_42 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_41, %arg40_1), kwargs = {})
#   %convert_element_type_91 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_42, torch.float16), kwargs = {})
#   return %add_28,%buf107,%convert_element_type_91
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_35 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_35', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_35', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 20480}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_35(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr1, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr2, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor4 = tl.make_tensor_descriptor(in_ptr3, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp3 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp5 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp7 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor4.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8.to(tl.float32)
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp8, r0_mask)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    tma_descriptor5 = tl.make_tensor_descriptor(in_out_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp14 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor5.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp22 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tl.full([1], 1024.0, tl.float32)
        tmp17 = (tmp12 / tmp16)
        tmp18 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp19 = tmp17 + tmp18
        tmp20 = libdevice.rsqrt(tmp19)
        tmp21 = tmp15 * tmp20
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp21 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp25, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/3o/c3oadq5eqk5ukvwfre34tgu7ktkbgzyl6xwcw5raifa3bxohrmpi.py
# Topologically Sorted Source Nodes: [linear_27, x_8, rms_norm_8], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   linear_27 => view_105
#   rms_norm_8 => add_32, convert_element_type_100, convert_element_type_101, mean_8, mul_44, mul_45, pow_9, rsqrt_8
#   x_8 => add_31
# Graph fragment:
#   %add_28 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=add_28]
#   %mm_27 : Tensor "f16[1, 1024][1024, 1]cpu" = PlaceHolder[target=mm_27]
#   %buf113 : Tensor "f32[1, 1, 1][1, 1, 1]cpu" = PlaceHolder[target=buf113]
#   %arg44_1 : Tensor "f16[1024][1]cpu" = PlaceHolder[target=arg44_1]
#   %view_105 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_27, [1, 1, 1024]), kwargs = {})
#   %add_31 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_28, %view_105), kwargs = {})
#   %convert_element_type_100 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_31, torch.float32), kwargs = {})
#   %pow_9 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_100, 2), kwargs = {})
#   %mean_8 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_9, [2], True), kwargs = {})
#   %add_32 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_8, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_8 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_32,), kwargs = {})
#   %mul_44 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_100, %rsqrt_8), kwargs = {})
#   %mul_45 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_44, %arg44_1), kwargs = {})
#   %convert_element_type_101 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_45, torch.float16), kwargs = {})
#   return %buf113,%convert_element_type_101
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_36 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_36', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 1024},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_36', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 10240}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_36(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 1024
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[1024], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 1024.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp17 * tmp19
        tmp21 = tmp20.to(tl.float32)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp21, r0_mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/k6/ck6yjpbdxbrn54cftk6uak2skugsa6iec7qymfwisiy3obnt4yfp.py
# Topologically Sorted Source Nodes: [linear_27, x_8, rms_norm_8, logits], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_27 => view_105
#   logits => mm_28, permute_56, view_106
#   rms_norm_8 => add_32, convert_element_type_100, convert_element_type_101, mean_8, mul_44, mul_45, pow_9, rsqrt_8
#   x_8 => add_31
# Graph fragment:
#   %convert_element_type_101 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu" = PlaceHolder[target=convert_element_type_101]
#   %arg45_1 : Tensor "f16[32000, 1024][1024, 1]cpu" = PlaceHolder[target=arg45_1]
#   %view_105 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_27, [1, 1, 1024]), kwargs = {})
#   %add_31 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_28, %view_105), kwargs = {})
#   %convert_element_type_100 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_31, torch.float32), kwargs = {})
#   %pow_9 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_100, 2), kwargs = {})
#   %mean_8 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_9, [2], True), kwargs = {})
#   %add_32 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_8, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_8 : Tensor "f32[1, 1, 1][1, 1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_32,), kwargs = {})
#   %mul_44 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_100, %rsqrt_8), kwargs = {})
#   %mul_45 : Tensor "f32[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_44, %arg44_1), kwargs = {})
#   %convert_element_type_101 : Tensor "f16[1, 1, 1024][1024, 1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_45, torch.float16), kwargs = {})
#   %view_106 : Tensor "f16[1, 1024][1024, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_101, [1, 1024]), kwargs = {})
#   %permute_56 : Tensor "f16[1024, 32000][1, 1024]cpu"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg45_1, [1, 0]), kwargs = {})
#   %mm_28 : Tensor "f16[1, 32000][32000, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_106, %permute_56), kwargs = {})
#   return %mm_28
triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_37 = async_compile.triton('triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_37', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_37', 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_37(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 32000
    K = 1024
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 1024

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 1024*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 32000*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 1024*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 32000*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cpu')


# kernel path: /tmp/torchinductor_zhongchun/as/caslplyutgcqcl76g5di4gxzhaf35b2pnjzhsqxq6edrslz3wrk3.py
# Topologically Sorted Source Nodes: [logits, next_token], Original ATen: [aten._unsafe_view, aten.argmax]
# Source node to ATen node mapping:
#   logits => view_107
#   next_token => argmax
# Graph fragment:
#   %mm_28 : Tensor "f16[1, 32000][32000, 1]cpu" = PlaceHolder[target=mm_28]
#   %view_107 : Tensor "f16[1, 1, 32000][32000, 32000, 1]cpu"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_28, [1, 1, 32000]), kwargs = {})
#   %argmax : Tensor "i64[1, 1][1, 1]cpu"[num_users=1] = call_function[target=torch.ops.aten.argmax.default](args = (%view_107, -1), kwargs = {})
#   return %argmax
triton_red_fused__unsafe_view_argmax_38 = async_compile.triton('triton_red_fused__unsafe_view_argmax_38', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_cpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 32768},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*i64', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cpu', index=None, multi_processor_count=20, cc='', major=None, regs_per_multiprocessor=None, max_threads_per_multi_processor=None, max_threads_per_block=1024, warp_size=None), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_argmax_38', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 64000}, 'backend_hash': '9375275D7291D3502ABFCD4F14534ABD78818B3EE44E67CAFFA805CF48E2AE89', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__unsafe_view_argmax_38(in_ptr0, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 32000
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[32000], strides=[1], block_shape=[R0_BLOCK])
    _tmp2 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    _tmp2_index = tl.full([R0_BLOCK], 2147483647, tl.int32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
        _tmp2_next, _tmp2_index_next = triton_helpers.maximum_with_index(
            _tmp2, _tmp2_index, tmp1, rindex
        )
        _tmp2 = tl.where(r0_mask, _tmp2_next, _tmp2)
        _tmp2_index = tl.where(r0_mask, _tmp2_index_next, _tmp2_index)
    tmp2_val, tmp2_idx = triton_helpers.max_with_index(_tmp2, _tmp2_index, 0)
    tmp2 = triton_helpers.promote_to_tensor(tmp2_idx)
    tl.store(out_ptr0 + (tl.full([1], 0, tl.int32)), tmp2, None)
''', device_str='cpu')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1 = args
        args.clear()
        assert_size_stride(arg4_1, (1, ), (1, ), 'input')
        buf117 = empty_strided_cpu((1, ), (1, ), torch.int64)
        # Topologically Sorted Source Nodes: [next_position], Original ATen: [aten.add]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused_add_0.run(arg4_1, buf117, 1, stream=raw_streamNone)
        assert_size_stride_grouped((arg2_1, arg7_1, arg8_1), ((1, 1), (32000, 1024), (1024, )), ((512, 1), (1024, 1), (1, )), 'input')
        buf1 = empty_strided_cpu((1, 1, 1024), (1024, 1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [x, y], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_1.run(arg2_1, arg7_1, arg8_1, buf1, 1, 1024, stream=raw_streamNone)
        del arg8_1
        assert_size_stride(arg10_1, (256, 1024), (1024, 1), 'input')
        buf3 = empty_strided_cpu((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf1, arg10_1, buf3, 16, 1, 1, stream=raw_streamNone)
        del arg10_1
        buf9 = empty_strided_cpu((1, 4, 1, 64), (256, 64, 64, 1), torch.float16)
        buf7 = reinterpret_tensor(buf9, (1, 4, 1, 32), (256, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_3, k, chunk_1, neg_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf3, buf7, 128, stream=raw_streamNone)
        buf8 = reinterpret_tensor(buf9, (1, 4, 1, 32), (256, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_3, k, chunk_1, neg_1, cat_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf3, buf8, 128, stream=raw_streamNone)
        assert_size_stride(arg11_1, (256, 1024), (1024, 1), 'input')
        del buf7
        del buf8
        buf16 = empty_strided_cpu((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_2], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf1, arg11_1, buf16, 16, 1, 1, stream=raw_streamNone)
        del arg11_1
        assert_size_stride(arg9_1, (1024, 1024), (1024, 1), 'input')
        buf2 = empty_strided_cpu((1, 1024), (1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [x, y, linear], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf1, arg9_1, buf2, 64, 1, 1, stream=raw_streamNone)
        del arg9_1
        buf6 = reinterpret_tensor(buf1, (1, 16, 1, 64), (1024, 64, 64, 1), 0); del buf1  # reuse
        buf4 = reinterpret_tensor(buf6, (1, 16, 1, 32), (1024, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear, view_2, q, chunk, neg], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_6.run(buf2, buf4, 512, stream=raw_streamNone)
        buf5 = reinterpret_tensor(buf6, (1, 16, 1, 32), (1024, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear, view_2, q, chunk, neg, cat], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_7.run(buf2, buf5, 512, stream=raw_streamNone)
        assert_size_stride_grouped((arg3_1, arg5_1, arg6_1, arg0_1), ((576, ), (576, 64), (576, 64), (4, 1, 4, 576, 64)), ((1, ), (64, 1), (64, 1), (147456, 147456, 36864, 64, 1)), 'input')
        buf10 = empty_strided_cpu((1, 4, 576, 64), (147456, 36864, 64, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_1, view_3, k, cos, sin, eq, write, mul_2, mul_3, k_1, getitem_4, full_k], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.index_select, aten.eq, aten.mul, aten.add, aten.select, aten.where]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_8.run(arg3_1, arg4_1, buf3, arg5_1, buf9, arg6_1, arg0_1, buf10, 147456, stream=raw_streamNone)
        del buf4
        del buf5
        buf11 = empty_strided_cpu((16, 1, 576), (576, 576, 1), torch.float32)
        # Topologically Sorted Source Nodes: [linear, view_2, q, cos, mul, sin, mul_1, q_1, o, getitem_8, expand, full_k_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.index_select, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_index_select_mul_transpose_unsqueeze_view_9.run(buf2, arg4_1, arg5_1, buf6, arg6_1, buf10, buf11, 9216, 64, stream=raw_streamNone)
        buf12 = empty_strided_cpu((1, 16, 1, 1), (16, 1, 16, 16), torch.bool)
        buf14 = empty_strided_cpu((1, 16, 1, 576), (9216, 576, 9216, 1), torch.float32)
        buf15 = empty_strided_cpu((1, 16, 1, 1), (16, 1, 16, 16), torch.float32)
        # Topologically Sorted Source Nodes: [o, le, visible], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.le, aten.view, aten.scalar_tensor, aten.where]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_le_scalar_tensor_view_where_10.run(buf11, arg3_1, arg4_1, buf12, buf14, buf15, 16, 576, stream=raw_streamNone)
        assert_size_stride(arg1_1, (4, 1, 4, 576, 64), (147456, 147456, 36864, 64, 1), 'input')
        buf17 = empty_strided_cpu((16, 1, 64, 5), (320, 5120, 1, 64), torch.float32)
        # Topologically Sorted Source Nodes: [eq, write, o, linear_2, view_4, v, getitem_5, full_v, getitem_9, expand_1, full_v_1], Original ATen: [aten.eq, aten.view, aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_11.run(buf12, buf14, buf15, arg3_1, arg4_1, buf16, arg1_1, buf17, 5120, 116, stream=raw_streamNone)
        buf19 = buf6; del buf6  # reuse
        # Topologically Sorted Source Nodes: [eq, write, o, linear_2, view_4, v, getitem_5, full_v, getitem_9, expand_1, full_v_1], Original ATen: [aten.eq, aten.view, aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_12.run(buf17, buf19, 1024, 5, stream=raw_streamNone)
        assert_size_stride(arg12_1, (1024, 1024), (1024, 1), 'input')
        buf20 = buf2; del buf2  # reuse
        # Topologically Sorted Source Nodes: [o, transpose_3, reshape_2, linear_3], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf19, arg12_1, buf20, 64, 1, 1, stream=raw_streamNone)
        del arg12_1
        assert_size_stride(arg13_1, (1024, ), (1, ), 'input')
        buf22 = reinterpret_tensor(buf19, (1, 1, 1024), (1024, 1024, 1), 0); del buf19  # reuse
        # Topologically Sorted Source Nodes: [x, linear_3, x_1, y_1], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13.run(arg2_1, arg7_1, buf20, arg13_1, buf22, 1, 1024, stream=raw_streamNone)
        del arg13_1
        assert_size_stride(arg14_1, (2816, 1024), (1024, 1), 'input')
        buf23 = empty_strided_cpu((1, 2816), (2816, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_14.run(buf22, arg14_1, buf23, 176, 1, 1, stream=raw_streamNone)
        del arg14_1
        assert_size_stride(arg15_1, (2816, 1024), (1024, 1), 'input')
        buf25 = empty_strided_cpu((1, 1, 2816), (2816, 2816, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf22, arg15_1, buf23, buf25, 176, 1, 1, stream=raw_streamNone)
        del arg15_1
        assert_size_stride(arg16_1, (1024, 2816), (2816, 1), 'input')
        buf26 = reinterpret_tensor(buf22, (1, 1024), (1024, 1), 0); del buf22  # reuse
        # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4, linear_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf25, arg16_1, buf26, 64, 1, 1, stream=raw_streamNone)
        del arg16_1
        assert_size_stride(arg17_1, (1024, ), (1, ), 'input')
        buf28 = empty_strided_cpu((1, 1, 1024), (1024, 1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [x, linear_3, x_1, linear_6, x_2, y_2], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17.run(arg2_1, arg7_1, buf20, buf26, arg17_1, buf28, 1, 1024, stream=raw_streamNone)
        del arg17_1
        assert_size_stride(arg19_1, (256, 1024), (1024, 1), 'input')
        buf30 = reinterpret_tensor(buf9, (1, 256), (256, 1), 0); del buf9  # reuse
        # Topologically Sorted Source Nodes: [linear_8], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf28, arg19_1, buf30, 16, 1, 1, stream=raw_streamNone)
        del arg19_1
        buf37 = reinterpret_tensor(buf3, (1, 4, 1, 64), (256, 64, 64, 1), 0); del buf3  # reuse
        buf35 = reinterpret_tensor(buf37, (1, 4, 1, 32), (256, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_6, k_2, chunk_3, neg_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf30, buf35, 128, stream=raw_streamNone)
        buf36 = reinterpret_tensor(buf37, (1, 4, 1, 32), (256, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_6, k_2, chunk_3, neg_3, cat_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf30, buf36, 128, stream=raw_streamNone)
        assert_size_stride(arg20_1, (256, 1024), (1024, 1), 'input')
        del buf35
        del buf36
        buf44 = empty_strided_cpu((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_9], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf28, arg20_1, buf44, 16, 1, 1, stream=raw_streamNone)
        del arg20_1
        assert_size_stride(arg18_1, (1024, 1024), (1024, 1), 'input')
        buf29 = empty_strided_cpu((1, 1024), (1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_18.run(buf28, arg18_1, buf29, 64, 1, 1, stream=raw_streamNone)
        del arg18_1
        buf34 = reinterpret_tensor(buf28, (1, 16, 1, 64), (1024, 64, 64, 1), 0); del buf28  # reuse
        buf32 = reinterpret_tensor(buf34, (1, 16, 1, 32), (1024, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_7, view_5, q_2, chunk_2, neg_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_6.run(buf29, buf32, 512, stream=raw_streamNone)
        buf33 = reinterpret_tensor(buf34, (1, 16, 1, 32), (1024, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_7, view_5, q_2, chunk_2, neg_2, cat_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_7.run(buf29, buf33, 512, stream=raw_streamNone)
        buf38 = empty_strided_cpu((1, 4, 576, 64), (147456, 36864, 64, 1), torch.float16)
        # Topologically Sorted Source Nodes: [cos, sin, eq, write, linear_8, view_6, k_2, mul_7, mul_8, k_3, full_k_2], Original ATen: [aten.index_select, aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.mul, aten.add, aten.select, aten.where]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_19.run(arg3_1, arg4_1, buf30, arg5_1, buf37, arg6_1, buf10, arg0_1, buf38, 147456, stream=raw_streamNone)
        del buf32
        del buf33
        buf39 = reinterpret_tensor(buf14, (16, 1, 576), (576, 576, 1), 0); del buf14  # reuse
        # Topologically Sorted Source Nodes: [cos, sin, linear_7, view_5, q_2, mul_5, mul_6, q_3, o_1, getitem_18, expand_2, full_k_3], Original ATen: [aten.index_select, aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_index_select_mul_transpose_unsqueeze_view_9.run(buf29, arg4_1, arg5_1, buf34, arg6_1, buf38, buf39, 9216, 64, stream=raw_streamNone)
        buf40 = buf12; del buf12  # reuse
        buf42 = reinterpret_tensor(buf11, (1, 16, 1, 576), (9216, 576, 9216, 1), 0); del buf11  # reuse
        buf43 = buf15; del buf15  # reuse
        # Topologically Sorted Source Nodes: [le, visible, o_1], Original ATen: [aten.le, aten.view, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_le_scalar_tensor_view_where_10.run(buf39, arg3_1, arg4_1, buf40, buf42, buf43, 16, 576, stream=raw_streamNone)
        buf31 = empty_strided_cpu((4, 1, 4, 576, 64), (147456, 589824, 36864, 64, 1), torch.float16)
        # Topologically Sorted Source Nodes: [eq, write, linear_2, view_4, v, getitem_5, full_v], Original ATen: [aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.select, aten.where]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_eq_select_transpose_view_where_20.run(arg3_1, arg4_1, buf16, arg1_1, buf31, 589824, stream=raw_streamNone)
        buf45 = buf17; del buf17  # reuse
        # Topologically Sorted Source Nodes: [eq, write, o_1, linear_9, view_7, v_1, full_v_2, getitem_19, expand_3, full_v_3], Original ATen: [aten.eq, aten.view, aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_21.run(buf40, buf42, buf43, arg3_1, arg4_1, buf44, buf31, buf45, 5120, 116, stream=raw_streamNone)
        buf47 = buf34; del buf34  # reuse
        # Topologically Sorted Source Nodes: [eq, write, o_1, linear_9, view_7, v_1, full_v_2, getitem_19, expand_3, full_v_3], Original ATen: [aten.eq, aten.view, aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_12.run(buf45, buf47, 1024, 5, stream=raw_streamNone)
        del buf45
        assert_size_stride(arg21_1, (1024, 1024), (1024, 1), 'input')
        buf48 = buf29; del buf29  # reuse
        # Topologically Sorted Source Nodes: [o_1, transpose_7, reshape_5, linear_10], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf47, arg21_1, buf48, 64, 1, 1, stream=raw_streamNone)
        del arg21_1
        assert_size_stride(arg22_1, (1024, ), (1, ), 'input')
        buf49 = reinterpret_tensor(buf20, (1, 1, 1024), (1024, 1024, 1), 0); del buf20  # reuse
        buf51 = reinterpret_tensor(buf47, (1, 1, 1024), (1024, 1024, 1), 0); del buf47  # reuse
        # Topologically Sorted Source Nodes: [x, linear_3, x_1, linear_6, x_2, linear_10, x_3, y_3], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_22.run(buf49, arg2_1, arg7_1, buf26, buf48, arg22_1, buf51, 1, 1024, stream=raw_streamNone)
        del arg22_1
        del arg2_1
        del arg7_1
        assert_size_stride(arg23_1, (2816, 1024), (1024, 1), 'input')
        buf52 = reinterpret_tensor(buf25, (1, 2816), (2816, 1), 0); del buf25  # reuse
        # Topologically Sorted Source Nodes: [y_3, linear_11], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_23.run(buf51, arg23_1, buf52, 176, 1, 1, stream=raw_streamNone)
        del arg23_1
        assert_size_stride(arg24_1, (2816, 1024), (1024, 1), 'input')
        buf54 = reinterpret_tensor(buf23, (1, 1, 2816), (2816, 2816, 1), 0); del buf23  # reuse
        # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_9], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf51, arg24_1, buf52, buf54, 176, 1, 1, stream=raw_streamNone)
        del arg24_1
        del buf52
        assert_size_stride(arg25_1, (1024, 2816), (2816, 1), 'input')
        buf55 = reinterpret_tensor(buf51, (1, 1024), (1024, 1), 0); del buf51  # reuse
        # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_9, linear_13], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf54, arg25_1, buf55, 64, 1, 1, stream=raw_streamNone)
        del arg25_1
        del buf54
        assert_size_stride(arg26_1, (1024, ), (1, ), 'input')
        buf57 = reinterpret_tensor(buf48, (1, 1, 1024), (1024, 1024, 1), 0); del buf48  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, y_4], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_24.run(buf49, buf55, arg26_1, buf57, 1, 1024, stream=raw_streamNone)
        del arg26_1
        assert_size_stride(arg28_1, (256, 1024), (1024, 1), 'input')
        buf59 = buf16; del buf16  # reuse
        # Topologically Sorted Source Nodes: [linear_15], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf57, arg28_1, buf59, 16, 1, 1, stream=raw_streamNone)
        del arg28_1
        buf66 = buf37; del buf37  # reuse
        buf64 = reinterpret_tensor(buf66, (1, 4, 1, 32), (256, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_15, view_9, k_4, chunk_5, neg_5], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf59, buf64, 128, stream=raw_streamNone)
        buf65 = reinterpret_tensor(buf66, (1, 4, 1, 32), (256, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_15, view_9, k_4, chunk_5, neg_5, cat_5], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf59, buf65, 128, stream=raw_streamNone)
        assert_size_stride(arg29_1, (256, 1024), (1024, 1), 'input')
        del buf64
        del buf65
        buf73 = buf30; del buf30  # reuse
        # Topologically Sorted Source Nodes: [linear_16], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf57, arg29_1, buf73, 16, 1, 1, stream=raw_streamNone)
        del arg29_1
        assert_size_stride(arg27_1, (1024, 1024), (1024, 1), 'input')
        buf58 = buf26; del buf26  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, y_4, linear_14], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf57, arg27_1, buf58, 64, 1, 1, stream=raw_streamNone)
        del arg27_1
        buf63 = reinterpret_tensor(buf57, (1, 16, 1, 64), (1024, 64, 64, 1), 0); del buf57  # reuse
        buf61 = reinterpret_tensor(buf63, (1, 16, 1, 32), (1024, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_14, view_8, q_4, chunk_4, neg_4], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_6.run(buf58, buf61, 512, stream=raw_streamNone)
        buf62 = reinterpret_tensor(buf63, (1, 16, 1, 32), (1024, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_14, view_8, q_4, chunk_4, neg_4, cat_4], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_7.run(buf58, buf62, 512, stream=raw_streamNone)
        buf67 = empty_strided_cpu((1, 4, 576, 64), (147456, 36864, 64, 1), torch.float16)
        # Topologically Sorted Source Nodes: [cos, sin, eq, write, linear_15, view_9, k_4, mul_12, mul_13, k_5, full_k_4], Original ATen: [aten.index_select, aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.mul, aten.add, aten.select, aten.where]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_25.run(arg3_1, arg4_1, buf59, arg5_1, buf66, arg6_1, buf38, buf10, arg0_1, buf67, 147456, stream=raw_streamNone)
        del buf59
        del buf61
        del buf62
        del buf66
        buf68 = reinterpret_tensor(buf42, (16, 1, 576), (576, 576, 1), 0); del buf42  # reuse
        # Topologically Sorted Source Nodes: [cos, sin, linear_14, view_8, q_4, mul_10, mul_11, q_5, o_2, getitem_28, expand_4, full_k_5], Original ATen: [aten.index_select, aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_index_select_mul_transpose_unsqueeze_view_9.run(buf58, arg4_1, arg5_1, buf63, arg6_1, buf67, buf68, 9216, 64, stream=raw_streamNone)
        del buf58
        del buf63
        buf69 = buf40; del buf40  # reuse
        buf71 = reinterpret_tensor(buf39, (1, 16, 1, 576), (9216, 576, 9216, 1), 0); del buf39  # reuse
        buf72 = buf43; del buf43  # reuse
        # Topologically Sorted Source Nodes: [le, visible, o_2], Original ATen: [aten.le, aten.view, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_le_scalar_tensor_view_where_10.run(buf68, arg3_1, arg4_1, buf69, buf71, buf72, 16, 576, stream=raw_streamNone)
        del buf68
        buf60 = empty_strided_cpu((4, 1, 4, 576, 64), (147456, 589824, 36864, 64, 1), torch.float16)
        # Topologically Sorted Source Nodes: [eq, write, linear_9, view_7, v_1, full_v_2], Original ATen: [aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.select, aten.where]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_eq_select_transpose_view_where_26.run(arg3_1, arg4_1, buf44, buf31, buf60, 589824, stream=raw_streamNone)
        del buf31
        buf74 = empty_strided_cpu((16, 1, 64, 5), (320, 5120, 1, 64), torch.float32)
        # Topologically Sorted Source Nodes: [eq, write, o_2, linear_16, view_10, v_2, full_v_4, getitem_29, expand_5, full_v_5], Original ATen: [aten.eq, aten.view, aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_27.run(buf69, buf71, buf72, arg3_1, arg4_1, buf73, buf60, buf74, 5120, 116, stream=raw_streamNone)
        del buf71
        buf76 = empty_strided_cpu((1, 16, 1, 64), (1024, 64, 64, 1), torch.float16)
        # Topologically Sorted Source Nodes: [eq, write, o_2, linear_16, view_10, v_2, full_v_4, getitem_29, expand_5, full_v_5], Original ATen: [aten.eq, aten.view, aten._scaled_dot_product_flash_attention_for_cpu, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_12.run(buf74, buf76, 1024, 5, stream=raw_streamNone)
        buf92 = empty_strided_cpu((4, 1, 4, 576, 64), (147456, 589824, 36864, 64, 1), torch.float16)
        # Topologically Sorted Source Nodes: [eq, write, linear_16, view_10, v_2, full_v_4], Original ATen: [aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.select, aten.where]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_eq_select_transpose_view_where_28.run(arg3_1, arg4_1, buf73, buf60, buf92, 589824, stream=raw_streamNone)
        del buf60
        assert_size_stride(arg30_1, (1024, 1024), (1024, 1), 'input')
        buf77 = empty_strided_cpu((1, 1024), (1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [o_2, transpose_11, reshape_8, linear_17], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf76, arg30_1, buf77, 64, 1, 1, stream=raw_streamNone)
        del arg30_1
        assert_size_stride(arg31_1, (1024, ), (1, ), 'input')
        buf79 = reinterpret_tensor(buf76, (1, 1, 1024), (1024, 1024, 1), 0); del buf76  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, linear_17, x_5, y_5], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_29.run(buf49, buf55, buf77, arg31_1, buf79, 1, 1024, stream=raw_streamNone)
        del arg31_1
        assert_size_stride(arg32_1, (2816, 1024), (1024, 1), 'input')
        buf80 = empty_strided_cpu((1, 2816), (2816, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_18], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_14.run(buf79, arg32_1, buf80, 176, 1, 1, stream=raw_streamNone)
        del arg32_1
        assert_size_stride(arg33_1, (2816, 1024), (1024, 1), 'input')
        buf82 = empty_strided_cpu((1, 1, 2816), (2816, 2816, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_14], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf79, arg33_1, buf80, buf82, 176, 1, 1, stream=raw_streamNone)
        del arg33_1
        del buf80
        assert_size_stride(arg34_1, (1024, 2816), (2816, 1), 'input')
        buf83 = reinterpret_tensor(buf79, (1, 1024), (1024, 1), 0); del buf79  # reuse
        # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_14, linear_20], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf82, arg34_1, buf83, 64, 1, 1, stream=raw_streamNone)
        del arg34_1
        assert_size_stride(arg35_1, (1024, ), (1, ), 'input')
        buf85 = empty_strided_cpu((1, 1, 1024), (1024, 1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_13, x_4, linear_17, x_5, linear_20, x_6, y_6], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_30.run(buf49, buf55, buf77, buf83, arg35_1, buf85, 1, 1024, stream=raw_streamNone)
        del arg35_1
        assert_size_stride(arg37_1, (256, 1024), (1024, 1), 'input')
        buf87 = buf73; del buf73  # reuse
        # Topologically Sorted Source Nodes: [linear_22], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf85, arg37_1, buf87, 16, 1, 1, stream=raw_streamNone)
        del arg37_1
        buf90 = reinterpret_tensor(buf44, (1, 4, 1, 64), (256, 64, 64, 1), 0); del buf44  # reuse
        buf88 = reinterpret_tensor(buf90, (1, 4, 1, 32), (256, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_22, view_12, k_6, chunk_7, neg_7], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf87, buf88, 128, stream=raw_streamNone)
        buf89 = reinterpret_tensor(buf90, (1, 4, 1, 32), (256, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_22, view_12, k_6, chunk_7, neg_7, cat_7], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf87, buf89, 128, stream=raw_streamNone)
        assert_size_stride(arg38_1, (256, 1024), (1024, 1), 'input')
        del buf88
        del buf89
        buf93 = empty_strided_cpu((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_23], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_2.run(buf85, arg38_1, buf93, 16, 1, 1, stream=raw_streamNone)
        del arg38_1
        assert_size_stride(arg36_1, (1024, 1024), (1024, 1), 'input')
        buf86 = empty_strided_cpu((1, 1024), (1024, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_21], Original ATen: [aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused_mm_t_view_18.run(buf85, arg36_1, buf86, 64, 1, 1, stream=raw_streamNone)
        del arg36_1
        # Topologically Sorted Source Nodes: [eq, write, linear_23, view_13, v_3, full_v_6], Original ATen: [aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten.copy_]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_copy__eq_select_transpose_view_where_31.run(arg3_1, arg4_1, buf93, buf92, arg1_1, 589824, stream=raw_streamNone)
        del arg1_1
        buf96 = reinterpret_tensor(buf85, (1, 16, 1, 64), (1024, 64, 64, 1), 0); del buf85  # reuse
        buf94 = reinterpret_tensor(buf96, (1, 16, 1, 32), (1024, 64, 64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_21, view_11, q_6, chunk_6, neg_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_6.run(buf86, buf94, 512, stream=raw_streamNone)
        buf95 = reinterpret_tensor(buf96, (1, 16, 1, 32), (1024, 64, 64, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_21, view_11, q_6, chunk_6, neg_6, cat_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_7.run(buf86, buf95, 512, stream=raw_streamNone)
        buf91 = empty_strided_cpu((1, 4, 576, 64), (147456, 36864, 64, 1), torch.float16)
        # Topologically Sorted Source Nodes: [cos, sin, eq, write, linear_22, view_12, k_6, mul_17, mul_18, k_7, full_k_6], Original ATen: [aten.index_select, aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.mul, aten.add, aten.select, aten.where]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused__unsafe_view_add_eq_index_select_mul_select_transpose_view_where_32.run(arg3_1, arg4_1, buf87, arg5_1, buf90, arg6_1, buf67, buf38, buf10, arg0_1, buf91, 147456, stream=raw_streamNone)
        del buf87
        del buf90
        del buf94
        del buf95
        buf97 = empty_strided_cpu((16, 1, 576), (576, 576, 1), torch.float32)
        # Topologically Sorted Source Nodes: [cos, sin, linear_21, view_11, q_6, mul_15, mul_16, q_7, o_3, getitem_38, expand_6, full_k_7], Original ATen: [aten.index_select, aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_index_select_mul_transpose_unsqueeze_view_9.run(buf86, arg4_1, arg5_1, buf96, arg6_1, buf91, buf97, 9216, 64, stream=raw_streamNone)
        del arg5_1
        del arg6_1
        buf98 = buf69; del buf69  # reuse
        buf100 = empty_strided_cpu((1, 16, 1, 576), (9216, 576, 9216, 1), torch.float32)
        buf101 = buf72; del buf72  # reuse
        # Topologically Sorted Source Nodes: [le, visible, o_3], Original ATen: [aten.le, aten.view, aten._scaled_dot_product_flash_attention_for_cpu, aten.scalar_tensor, aten.where]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_le_scalar_tensor_view_where_10.run(buf97, arg3_1, arg4_1, buf98, buf100, buf101, 16, 576, stream=raw_streamNone)
        del buf97
        buf102 = buf74; del buf74  # reuse
        # Topologically Sorted Source Nodes: [eq, write, linear_23, view_13, v_3, full_v_6, o_3, getitem_39, expand_7, full_v_7], Original ATen: [aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_33.run(buf98, buf100, buf101, arg3_1, arg4_1, buf93, buf92, buf102, 5120, 116, stream=raw_streamNone)
        del arg3_1
        del arg4_1
        del buf100
        del buf101
        del buf92
        del buf93
        del buf98
        # Topologically Sorted Source Nodes: [], Original ATen: [aten.copy_]
        raw_streamNone = get_raw_stream(None)
        triton_poi_fused_copy__34.run(buf91, buf67, buf38, buf10, arg0_1, arg0_1, 589824, stream=raw_streamNone)
        del arg0_1
        del buf10
        del buf38
        del buf67
        del buf91
        buf104 = buf96; del buf96  # reuse
        # Topologically Sorted Source Nodes: [eq, write, linear_23, view_13, v_3, full_v_6, o_3, getitem_39, expand_7, full_v_7], Original ATen: [aten.eq, aten.view, aten._unsafe_view, aten.transpose, aten.select, aten.where, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_eq_expand_select_transpose_unsqueeze_view_where_12.run(buf102, buf104, 1024, 5, stream=raw_streamNone)
        del buf102
        assert_size_stride(arg39_1, (1024, 1024), (1024, 1), 'input')
        buf105 = buf86; del buf86  # reuse
        # Topologically Sorted Source Nodes: [o_3, transpose_15, reshape_11, linear_24], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_5.run(buf104, arg39_1, buf105, 64, 1, 1, stream=raw_streamNone)
        del arg39_1
        assert_size_stride(arg40_1, (1024, ), (1, ), 'input')
        buf106 = buf49; del buf49  # reuse
        buf108 = reinterpret_tensor(buf104, (1, 1, 1024), (1024, 1024, 1), 0); del buf104  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, linear_17, x_5, linear_20, x_6, linear_24, x_7, y_7], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_35.run(buf106, buf55, buf77, buf83, buf105, arg40_1, buf108, 1, 1024, stream=raw_streamNone)
        del arg40_1
        del buf105
        del buf55
        del buf77
        del buf83
        assert_size_stride(arg41_1, (2816, 1024), (1024, 1), 'input')
        buf109 = reinterpret_tensor(buf82, (1, 2816), (2816, 1), 0); del buf82  # reuse
        # Topologically Sorted Source Nodes: [y_7, linear_25], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_23.run(buf108, arg41_1, buf109, 176, 1, 1, stream=raw_streamNone)
        del arg41_1
        assert_size_stride(arg42_1, (2816, 1024), (1024, 1), 'input')
        buf111 = empty_strided_cpu((1, 1, 2816), (2816, 2816, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_19], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf108, arg42_1, buf109, buf111, 176, 1, 1, stream=raw_streamNone)
        del arg42_1
        del buf109
        assert_size_stride(arg43_1, (1024, 2816), (2816, 1), 'input')
        buf112 = reinterpret_tensor(buf108, (1, 1024), (1024, 1), 0); del buf108  # reuse
        # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_19, linear_27], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf111, arg43_1, buf112, 64, 1, 1, stream=raw_streamNone)
        del arg43_1
        del buf111
        assert_size_stride(arg44_1, (1024, ), (1, ), 'input')
        buf114 = buf106; del buf106  # reuse
        # Topologically Sorted Source Nodes: [linear_27, x_8, rms_norm_8], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_36.run(buf114, buf112, arg44_1, 1, 1024, stream=raw_streamNone)
        del arg44_1
        del buf112
        assert_size_stride(arg45_1, (32000, 1024), (1024, 1), 'input')
        buf115 = empty_strided_cpu((1, 32000), (32000, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_27, x_8, rms_norm_8, logits], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_streamNone = get_raw_stream(None)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_37.run(buf114, arg45_1, buf115, 2000, 1, 1, stream=raw_streamNone)
        del arg45_1
        del buf114
        buf116 = empty_strided_cpu((1, 1), (1, 1), torch.int64)
        # Topologically Sorted Source Nodes: [logits, next_token], Original ATen: [aten._unsafe_view, aten.argmax]
        raw_streamNone = get_raw_stream(None)
        triton_red_fused__unsafe_view_argmax_38.run(buf115, buf116, 1, 32000, stream=raw_streamNone)
        return (reinterpret_tensor(buf115, (1, 1, 32000), (32000, 32000, 1), 0), buf116, buf117, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((4, 1, 4, 576, 64), (147456, 147456, 36864, 64, 1), device='cpu', dtype=torch.float16)
    arg1_1 = rand_strided((4, 1, 4, 576, 64), (147456, 147456, 36864, 64, 1), device='cpu', dtype=torch.float16)
    arg2_1 = rand_strided((1, 1), (512, 1), device='cpu', dtype=torch.int64)
    arg3_1 = rand_strided((576, ), (1, ), device='cpu', dtype=torch.int64)
    arg4_1 = rand_strided((1, ), (1, ), device='cpu', dtype=torch.int64)
    arg5_1 = rand_strided((576, 64), (64, 1), device='cpu', dtype=torch.float16)
    arg6_1 = rand_strided((576, 64), (64, 1), device='cpu', dtype=torch.float16)
    arg7_1 = rand_strided((32000, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg8_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg9_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg10_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg11_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg12_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg13_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg14_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg15_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg16_1 = rand_strided((1024, 2816), (2816, 1), device='cpu', dtype=torch.float16)
    arg17_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg18_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg19_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg20_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg21_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg22_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg23_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg24_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg25_1 = rand_strided((1024, 2816), (2816, 1), device='cpu', dtype=torch.float16)
    arg26_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg27_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg28_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg29_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg30_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg31_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg32_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg33_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg34_1 = rand_strided((1024, 2816), (2816, 1), device='cpu', dtype=torch.float16)
    arg35_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg36_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg37_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg38_1 = rand_strided((256, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg39_1 = rand_strided((1024, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg40_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg41_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg42_1 = rand_strided((2816, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    arg43_1 = rand_strided((1024, 2816), (2816, 1), device='cpu', dtype=torch.float16)
    arg44_1 = rand_strided((1024, ), (1, ), device='cpu', dtype=torch.float16)
    arg45_1 = rand_strided((32000, 1024), (1024, 1), device='cpu', dtype=torch.float16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cpu')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
