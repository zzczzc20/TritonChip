    // R39-12: role0 on even contexts, role1 on odd ones (ROLE_ID mod 2)
    s.rdspecial  s61, role_id
    s.andi       s61, s61, #1
    br.nz        s61, __tnca_role1
    w.def        w0, #60, #4                     // v60..v63
    w.def        w1, #56, #4                     // v56..v59
    w.def        w2, #52, #4                     // v52..v55
    w.def        w3, #48, #4                     // v48..v51
    .li       s1, #196608
    td.load      d0, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    .li       s1, #196864
    td.load      d1, [s1]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    // role 0: partition P (load/transfer). 2 k step(s) over a 2-slot RF channel.
    // k step 0: slot 0, generation 1
    mb.arm       s1, b0, #0, #2                  // 0 arrival(s), 2 operation(s)
    .li       s2, #0
    .li       s3, #0
    s.mov        s4, s2                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s4, s1
    .li       s2, #0
    .li       s3, #0
    s.mov        s4, s2                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w2, d1, s4, s1
    // k step 1: slot 1, generation 1
    mb.arm       s2, b1, #0, #2                  // 0 arrival(s), 2 operation(s)
    .li       s3, #0
    .li       s4, #16
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s6, s4                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w1, d0, s5, s2
    .li       s3, #16
    .li       s4, #0
    s.mov        s5, s3                          // coordinates must be consecutive (ISA sec 9E)
    s.mov        s6, s4                          // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w3, d1, s5, s2
    exit
__tnca_role1:
    // role 1: partitions M (matrix, and the epilogue merged in because this target has 4 Role Contexts -- sec 7.6)
    m.zero       a0
    // k step 0: slot 0, generation 1
    .li       s1, #65536          // b0 generation 1 (ISA sec 9A.2)
    mb.wait      s1
    mb.arm       s2, b4, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k16.e4m3 a0, v60, v52, s2
    mb.wait      s2
    mb.arm       s3, b2, #1, #0                  // 1 arrival(s), 0 operation(s)
    mb.arrive    b2
    // k step 1: slot 1, generation 1
    .li       s4, #65537          // b1 generation 1 (ISA sec 9A.2)
    mb.wait      s4
    mb.arm       s5, b4, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k16.e4m3 a0, v56, v48, s5
    mb.wait      s5
    mb.arm       s6, b3, #1, #0                  // 1 arrival(s), 0 operation(s)
    mb.arrive    b3
    // epilogue: the accumulator leaves a row at a time
    .li       s7, #393216
    .li       s8, #0
    a.vread      v0, a0, s8
    v.st.w       [s7, #0], v0
    .li       s8, #1
    a.vread      v0, a0, s8
    s.addi       s8, s7, #64
    v.st.w       [s8, #0], v0
    .li       s8, #2
    a.vread      v0, a0, s8
    s.addi       s8, s7, #128
    v.st.w       [s8, #0], v0
    .li       s8, #3
    a.vread      v0, a0, s8
    s.addi       s8, s7, #192
    v.st.w       [s8, #0], v0
    .li       s8, #4
    a.vread      v0, a0, s8
    s.addi       s8, s7, #256
    v.st.w       [s8, #0], v0
    .li       s8, #5
    a.vread      v0, a0, s8
    s.addi       s8, s7, #320
    v.st.w       [s8, #0], v0
    .li       s8, #6
    a.vread      v0, a0, s8
    s.addi       s8, s7, #384
    v.st.w       [s8, #0], v0
    .li       s8, #7
    a.vread      v0, a0, s8
    s.addi       s8, s7, #448
    v.st.w       [s8, #0], v0
    .li       s8, #8
    a.vread      v0, a0, s8
    s.addi       s8, s7, #512
    v.st.w       [s8, #0], v0
    .li       s8, #9
    a.vread      v0, a0, s8
    s.addi       s8, s7, #576
    v.st.w       [s8, #0], v0
    .li       s8, #10
    a.vread      v0, a0, s8
    s.addi       s8, s7, #640
    v.st.w       [s8, #0], v0
    .li       s8, #11
    a.vread      v0, a0, s8
    s.addi       s8, s7, #704
    v.st.w       [s8, #0], v0
    .li       s8, #12
    a.vread      v0, a0, s8
    s.addi       s8, s7, #768
    v.st.w       [s8, #0], v0
    .li       s8, #13
    a.vread      v0, a0, s8
    s.addi       s8, s7, #832
    v.st.w       [s8, #0], v0
    .li       s8, #14
    a.vread      v0, a0, s8
    s.addi       s8, s7, #896
    v.st.w       [s8, #0], v0
    .li       s8, #15
    a.vread      v0, a0, s8
    s.addi       s8, s7, #960
    v.st.w       [s8, #0], v0
    exit
