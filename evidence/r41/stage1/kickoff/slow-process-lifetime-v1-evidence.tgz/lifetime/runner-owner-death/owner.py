from run import run
run('/home/zhongchun/r41-stage1/runs/slow-process-lifetime-v1/build/tnca-chip','/home/zhongchun/r41-stage1/runs/slow-process-lifetime-v1/lifetime/model.cfg','/home/zhongchun/r41-stage1/runs/slow-process-lifetime-v1/lifetime/infinite.commands','/home/zhongchun/r41-stage1/runs/slow-process-lifetime-v1/lifetime/runner-owner-death/model',timeout=60,mode="chip",monitor="off")
