#!/usr/bin/env bash
set -eu
export OMP_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES= HF_HUB_OFFLINE=1 HF_HOME="$HOME/r41-fp8-kern-hf" TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip" TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg"
cd "$HOME/r41_chat_astage_default_20261031"
V1="$HOME/r41-fp8-kern-hf/hub/kernels--kernels-community--finegrained-fp8/snapshots/48f42b23bb4e0122d4775c6d16753dd2efc7f580"
for shape in 16-256-256 16-1024-256 1-1024-256; do IFS=- read -r m n k <<< "$shape"; export TNCA_TLM_OUT="$HOME/r41_hoist_default_${shape}_tlm"; "$HOME/flux-venv/bin/python" -u tools/r41/chat_speed/bench_hoisted_fp8.py --route hoisted --default-div --m "$m" --n "$n" --k "$k" --v1 "$V1" --out "$HOME/r41_hoist_default_${shape}"; done
