    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    s.rdspecial  s1, arg_base
    v.add        v3, v1, v0
    v.movi       v0, #5
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    v.movi       v4, #128
    @p1 v.sel        v5, v1, v3
    v.movi       v1, #0
    v.cmp.lt     p2, v3, v4
    v.lshr       v4, v5, v0
    v.sub        v0, v1, v3
    v.cmp.lt     p3, v3, v1
    v.sub        v5, v2, v4
    @p3 v.sel        v6, v0, v3
    v.movi       v0, #31
    @p1 v.sel        v3, v5, v4
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    .li       s4, #1132462080
    v.splat      v4, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v5, v6, v0
    v.movi       v0, #32
    v.rcp.approx v6, v4                          // ISA 8.8: <= 2**-22 relative
    v.sub        v7, v1, v5
    v.movi       v8, #256
    v.sub        v9, v1, v0
    @p3 v.sel        v10, v7, v5
    v.mul        v5, v3, v8
    v.sub        v7, v2, v0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v8, [s2, v3]               // index is in elements (ISA sec 9.1)
    v.add        v11, v10, v0
    v.add        v12, v10, v5
    v.cmp.lt     p1, v0, v1
    v.add        v1, v11, v5
    v.cmp.lt     p3, v0, v2
    @p1 v.sel        v2, v9, v0
    @p3 v.sel        v2, v7, v0
    s.ld.d       s2, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    .li       s4, #1065353216
    v.splat      v0, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v2, [s3, v1]               // index is in elements (ISA sec 9.1)
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v1, [s2, v11]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v5, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v2, [s3, v12]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v7, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v1, [s2, v10]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v9, v2
    vf.cvt.bf16.f32 v2, v1
    s.ld.d       s2, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    vf.fms       v1, v4, v6, v0
    s.ld.d       s3, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    vf.fms       v0, v6, v1, v6
    .li       s1, #897988541
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1077936128
    v.splat      v11, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #3204448256
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v13, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.neg       v14, v0                         // Newton step: r0*(2 - x*r0)
    vf.add       v0, v7, v13
    vf.add       v7, v2, v13
    v.movi       v2, #64
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v13, v14, v6
    v.mul        v6, v3, v2
    vf.mul       v2, v8, v13                     // a/y: faithful quotient
    v.add        v3, v10, v6
    vf.fms       v6, v2, v4, v8
    vf.fms       v4, v6, v13, v2
    vf.neg       v6, v4                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v6, v6
    @p1 v.sel        v4, v6, v2
    vf.add       v2, v4, v1
    v.rsqrt.approx v1, v2                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v4, v1, v1
    vf.mul       v6, v1, v12
    vf.fms       v8, v2, v4, v11
    vf.mul       v2, v6, v8                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v4, v2, v1
    vf.mul       v1, v5, v4
    vf.mul       v2, v9, v4
    vf.mul       v4, v1, v0
    vf.mul       v0, v2, v7
    vf.neg       v1, v4
    vf.cvt.f32.bf16 v2, v0
    vf.cvt.f32.bf16 v0, v1
    @p2 v.st.scatter.h [s2, v3], v0
    @p2 v.st.scatter.h [s3, v3], v2
__rctx_next:
    exit
