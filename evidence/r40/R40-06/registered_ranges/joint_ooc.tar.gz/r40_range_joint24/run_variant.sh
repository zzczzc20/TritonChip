set -e
source /tools/Xilinx/Vivado/2023.2/settings64.sh
exec /tools/Xilinx/Vivado/2023.2/bin/vivado -mode batch -notrace -nojournal -log vivado.log -source "$1/input/flow/fpga/synth_r40_range_slice.tcl" -tclargs "$1/input" "$1/$2/ooc" "$3"
