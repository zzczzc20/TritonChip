    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #0
    s.movz       s2, #0
    s.cmp.lt     s3, s4, s1
    s.movz       s1, #16
    s.movz       s5, #0
    s.sub        s6, s2, s3
    s.movz       s2, #0
    s.cmp.lt     s3, s1, s5
    s.xor        s5, s4, s6
    s.sub        s7, s2, s3
    s.sub        s2, s5, s6
    s.xor        s3, s6, s7
    s.lshri      s5, s2, #4
    s.movz       s6, #1
    s.xor        s8, s5, s3
    s.movz       s9, #0
    s.sub        s10, s8, s3
    s.movz       s3, #0
    s.sub        s8, s6, s10
    s.movz       s11, #0
    s.min.s      s12, s8, s6
    s.movz       s8, #0
    s.cmp.lt     s13, s12, s9
    s.cmp.lt     s9, s4, s3
    s.sub        s3, s11, s13
    s.sub        s11, s8, s9
    s.xor        s8, s12, s3
    s.muli       s9, s5, #16
    s.movz       s5, #0
    s.movz       s13, #1
    s.xor        s14, s4, s11
    s.sub        s15, s8, s3
    s.rdspecial  s3, arg_base
    s.xor        s8, s1, s7
    s.movz       s16, #0
    s.sub        s17, s14, s11
    s.addi       s14, s5, #0
    s.cmp.eq     s5, s15, s13
    s.ld.d       s13, [s3, #0]                   // arg_A: device_ptr64 at arg_base+0
    s.sub        s18, s8, s7
    s.sub        s7, s2, s9
    s.addi       s2, s16, #0
    s.ld.d       s7, [s3, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s8, [s3, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.mov        s14, s17
    br.nz        s5, sdiv_done_1
    s.movz       s3, #0
    s.movz       s5, #31
    s.mov        s14, s3
    s.addi       s3, s5, #0
sdiv_2:
    s.lshr       s5, s17, s3
    s.shli       s9, s2, #1
    s.andi       s16, s5, #1
    s.movz       s5, #0
    s.or         s18, s9, s16
    s.movz       s9, #1
    s.cmp.geu    s16, s18, s15
    s.shl        s19, s9, s3
    s.sub        s9, s5, s16
    s.subi       s5, s3, #1
    s.and        s16, s15, s9
    s.and        s20, s19, s9
    s.sub        s9, s18, s16
    s.or         s16, s14, s20
    s.mov        s2, s9
    s.mov        s14, s16
    s.mov        s3, s5
    s.movz       s5, #0
    s.cmp.ge     s9, s3, s5
    br.nz        s9, sdiv_2
sdiv_done_1:
    s.movz       s3, #0
    s.movz       s5, #0
    s.cmp.lt     s9, s4, s3
    s.movz       s3, #0
    s.sub        s14, s5, s9
    s.movz       s5, #0
    s.xor        s9, s4, s14
    s.movz       s4, #0
    s.sub        s15, s9, s14
    s.cmp.lt     s9, s12, s3
    s.lshri      s3, s15, #4
    s.movz       s16, #0
    s.muli       s17, s3, #16
    s.movz       s3, #0
    s.sub        s18, s4, s9
    s.movz       s4, #0
    s.cmp.lt     s9, s1, s16
    s.sub        s16, s15, s17
    s.xor        s15, s12, s18
    s.xor        s12, s16, s14
    s.xor        s16, s2, s11
    s.sub        s2, s12, s14
    s.sub        s12, s4, s9
    s.cmp.lt     s4, s2, s5
    s.sub        s5, s15, s18
    s.sub        s9, s3, s4
    s.movz       s3, #0
    s.xor        s4, s2, s9
    s.movz       s2, #1
    s.sub        s14, s16, s11
    s.xor        s11, s1, s12
    s.sub        s15, s4, s9
    s.movz       s4, #0
    s.addi       s16, s3, #0
    s.cmp.eq     s3, s5, s2
    s.add        s2, s10, s14
    s.sub        s10, s11, s12
    s.addi       s10, s4, #0
    s.mov        s16, s15
    br.nz        s3, sdiv_done_3
    s.movz       s3, #0
    s.movz       s4, #31
    s.mov        s16, s3
    s.addi       s3, s4, #0
sdiv_4:
    s.lshr       s4, s15, s3
    s.shli       s11, s10, #1
    s.andi       s12, s4, #1
    s.movz       s4, #0
    s.or         s14, s11, s12
    s.movz       s11, #1
    s.cmp.geu    s12, s14, s5
    s.shl        s17, s11, s3
    s.sub        s11, s4, s12
    s.subi       s4, s3, #1
    s.and        s12, s5, s11
    s.and        s19, s17, s11
    s.sub        s11, s14, s12
    s.or         s12, s16, s19
    s.mov        s10, s11
    s.mov        s16, s12
    s.mov        s3, s4
    s.movz       s4, #0
    s.cmp.ge     s11, s3, s4
    br.nz        s11, sdiv_4
sdiv_done_3:
    s.xor        s3, s9, s18
    s.mul        s4, s2, s1
    s.xor        s5, s16, s3
    v.iota       v0                              // arange(0, VLEN)
    s.sub        s9, s5, s3
    v.movi       v1, #5
    v.splat      v2, s4
    s.mul        s3, s9, s1
    v.movi       v3, #0
    v.add        v4, v2, v0
    s.movz       s1, #0
    v.splat      v2, s2
    v.splat      v5, s1
    v.splat      v6, s9
    v.splat      v7, s1
    v.splat      v8, s3
    v.sub        v9, v3, v4
    v.cmp.lt     p1, v4, v3
    v.cmp.lt     p2, v1, v3
    v.cmp.ge     p3, v2, v5
    v.sub        v2, v3, v1
    v.cmp.ge     p3, v6, v7
    v.add        v5, v8, v0
    v.movi       v0, #1
    @p1 v.sel        v5, v9, v4
    @p2 v.sel        v4, v2, v1
    v.movi       v1, #0
    v.movi       v2, #0
    s.movz       s2, #31
idiv_5:
    v.splat      v6, s2
    v.shl        v7, v2, v0
    v.cmp.lt     p2, v2, v3
    v.lshr       v8, v5, v6
    v.shl        v9, v0, v6
    s.subi       s5, s2, #1
    v.and        v6, v8, v0
    s.movz       s9, #0
    v.or         v8, v7, v6
    v.cmp.geu    p3, v8, v4
    p.or         p4, p2, p3
    v.sub        v6, v8, v4
    @p4 v.sel        v7, v9, v3
    @p4 v.sel        v9, v6, v8
    v.or         v6, v1, v7
    v.mov        v2, v9
    v.mov        v1, v6
    s.mov        s2, s5
    s.cmp.ge     s5, s2, s9
    br.nz        s5, idiv_5
    v.sub        v0, v3, v2
    s.rdspecial  s2, pid.z
    s.rdspecial  s5, npid.y
    @p1 v.sel        v1, v0, v2
    s.mul        s9, s2, s5
    s.rdspecial  s2, pid.y
    v.extract    s5, v1, #0
    s.movz       s10, #5
    v.extract    s11, v1, #1
    v.extract    s12, v1, #2
    s.add        s14, s2, s9
    s.movz       s2, #7
    v.splat      v0, s5
    v.splat      v2, s10
    v.splat      v3, s11
    s.rdspecial  s5, arg_base
    s.min.s      s9, s14, s2
    s.movz       s11, #25
    s.ld.d       s15, [s5, #24]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.mul        v4, v0, v2
    v.mul        v0, v3, v2
    s.mul        s5, s9, s11
    v.extract    s11, v4, #0
    v.extract    s16, v0, #0
    s.rdspecial  s17, role_id
    s.movz       s18, #1024
    s.movz       s19, #0
    v.splat      v0, s11
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s16
    s.mul        s11, s17, s18
    s.add        s16, s19, s5                    // the tile origin
    v.add        v5, v0, v3
    v.splat      v0, s16
    v.add        v6, v4, v3
    s.add        s5, s15, s11                    // this context's own scratch
    v.splat      v4, s1
    v.add        v7, v5, v0
    v.add        v5, v6, v0
    s.addi       s11, s5, #0
    v.add        v6, v4, v7
    v.add        v7, v4, v5
    s.addi       s15, s11, #64
    s.addi       s16, s11, #128
    v.st.w       [s11, #0], v6
    s.andi       s17, s3, #255
    v.splat      v5, s12
    v.splat      v6, s17
    v.iota       v8                              // arange(0, VLEN)
    v.mul        v9, v5, v2
    v.add        v5, v6, v8
    v.extract    s12, v1, #3
    v.extract    s18, v1, #4
    v.extract    s19, v1, #5
    v.extract    s20, v1, #6
    v.splat      v5, s12
    v.splat      v6, s18
    v.splat      v8, s19
    v.splat      v10, s20
    v.mul        v11, v5, v2
    v.mul        v5, v6, v2
    v.mul        v6, v8, v2
    v.mul        v8, v10, v2
    v.extract    s12, v9, #0
    v.extract    s18, v11, #0
    v.extract    s19, v5, #0
    v.extract    s20, v6, #0
    v.extract    s21, v8, #0
    v.splat      v5, s12
    v.splat      v6, s18
    v.splat      v8, s19
    v.splat      v9, s20
    v.splat      v10, s21
    v.add        v11, v5, v3
    v.add        v5, v6, v3
    v.add        v6, v8, v3
    v.add        v8, v9, v3
    v.add        v9, v10, v3
    v.add        v10, v11, v0
    v.add        v11, v5, v0
    v.add        v5, v6, v0
    v.add        v6, v8, v0
    v.add        v8, v4, v10
    v.add        v10, v4, v11
    v.add        v11, v4, v5
    v.add        v5, v4, v6
    s.addi       s12, s11, #192
    s.addi       s18, s11, #256
    s.addi       s19, s11, #320
    s.addi       s20, s11, #384
    v.st.w       [s15, #0], v7
    v.extract    s15, v1, #7
    v.add        v6, v9, v0
    v.splat      v7, s15
    s.addi       s15, s11, #448
    v.add        v9, v4, v6
    v.mul        v6, v7, v2
    v.extract    s21, v6, #0
    v.splat      v6, s21
    v.add        v7, v6, v3
    v.st.w       [s16, #0], v8
    v.extract    s16, v1, #8
    v.add        v6, v7, v0
    v.splat      v7, s16
    s.addi       s16, s11, #512
    v.add        v8, v4, v6
    v.mul        v6, v7, v2
    v.extract    s21, v6, #0
    v.splat      v6, s21
    v.add        v7, v6, v3
    v.st.w       [s12, #0], v10
    v.extract    s12, v1, #9
    v.add        v6, v7, v0
    v.splat      v7, s12
    s.addi       s12, s11, #576
    v.add        v10, v4, v6
    v.mul        v6, v7, v2
    v.extract    s21, v6, #0
    v.splat      v6, s21
    v.add        v7, v6, v3
    v.st.w       [s18, #0], v11
    v.extract    s18, v1, #10
    v.add        v6, v7, v0
    v.splat      v7, s18
    s.addi       s18, s11, #640
    v.add        v11, v4, v6
    v.mul        v6, v7, v2
    v.extract    s21, v6, #0
    v.splat      v6, s21
    v.add        v7, v6, v3
    v.st.w       [s19, #0], v5
    v.extract    s19, v1, #11
    v.add        v5, v7, v0
    v.splat      v6, s19
    s.addi       s19, s11, #704
    v.add        v7, v4, v5
    v.mul        v5, v6, v2
    v.extract    s21, v5, #0
    v.splat      v5, s21
    v.add        v6, v5, v3
    v.st.w       [s20, #0], v9
    v.extract    s20, v1, #12
    v.add        v5, v6, v0
    v.splat      v6, s20
    s.addi       s20, s11, #768
    v.add        v9, v4, v5
    v.mul        v5, v6, v2
    v.extract    s21, v5, #0
    v.splat      v5, s21
    v.add        v6, v5, v3
    v.st.w       [s15, #0], v8
    v.extract    s15, v1, #13
    v.add        v5, v6, v0
    v.splat      v6, s15
    s.addi       s15, s11, #832
    v.add        v8, v4, v5
    v.mul        v5, v6, v2
    v.extract    s21, v5, #0
    v.splat      v5, s21
    v.add        v6, v5, v3
    v.st.w       [s16, #0], v10
    v.extract    s16, v1, #14
    v.add        v5, v6, v0
    v.splat      v6, s16
    s.addi       s16, s11, #896
    v.add        v10, v4, v5
    v.mul        v5, v6, v2
    v.extract    s21, v5, #0
    v.splat      v5, s21
    v.add        v6, v5, v3
    v.st.w       [s12, #0], v11
    v.extract    s12, v1, #15
    v.add        v1, v6, v0
    v.splat      v5, s12
    s.addi       s12, s11, #960
    v.add        v6, v4, v1
    v.mul        v1, v5, v2
    v.extract    s11, v1, #0
    v.splat      v1, s11
    v.add        v5, v1, v3
    v.st.w       [s18, #0], v7
    v.add        v1, v5, v0
    s.addi       s11, s5, #0
    v.splat      v0, s10
    v.add        v5, v4, v1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s18, #0
    s.movz       s21, #1280
    s.mul        s22, s9, s21
    v.st.w       [s19, #0], v9
    v.cmp.lt     p1, v3, v0
    s.addi       s9, s5, #64
    s.movz       s19, #1
    s.addi       s23, s5, #128
    s.movz       s24, #2
    v.st.w       [s20, #0], v8
    s.addi       s20, s5, #192
    s.movz       s25, #3
    s.addi       s26, s5, #256
    s.movz       s27, #4
    v.st.w       [s15, #0], v10
    s.addi       s15, s5, #320
    s.movz       s28, #5
    s.addi       s29, s5, #384
    v.st.w       [s16, #0], v6
    s.movz       s16, #6
    v.st.w       [s12, #0], v5
    fence.acq_rel.device
    s.addi       s12, s5, #448
    v.ld.w       v0, [s11, #0]
    s.movz       s11, #7
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s13, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s18, v1
    v.ld.w       v0, [s9, #0]
    s.addi       s9, s5, #512
    s.movz       s18, #8
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s13, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s19, v1
    v.ld.w       v0, [s23, #0]
    s.addi       s19, s5, #576
    s.movz       s23, #9
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s13, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s24, v1
    v.ld.w       v0, [s20, #0]
    s.addi       s20, s5, #640
    s.movz       s24, #10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s13, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s25, v1
    v.ld.w       v0, [s26, #0]
    s.addi       s25, s5, #704
    s.movz       s26, #11
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s13, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s27, v1
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s5, #768
    s.movz       s27, #12
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s13, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s28, v1
    v.ld.w       v0, [s29, #0]
    s.addi       s28, s5, #832
    s.movz       s29, #13
    s.muli       s30, s17, #4                    // a runtime tile origin, x4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s13, v0]              // index is in elements (ISA sec 9.1)
    s.add        s17, s7, s30                    // the tile origin
    s.addi       s7, s5, #896
    s.addi       s30, s5, #960
    a.vwrite     a0, s16, v1
    v.ld.w       v0, [s12, #0]
    s.movz       s5, #14
    s.muli       s12, s22, #4                    // a runtime tile origin, x4
    s.movz       s16, #15
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    v.movi       v1, #0
    s.add        s22, s17, s12                   // the tile origin
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s12, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s13, v0]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s11, v4
    v.ld.w       v0, [s9, #0]
    v.splat      v4, s1
    s.movz       s9, #0
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v4, v2
    a.vwrite     a0, s18, v5
    v.ld.w       v0, [s19, #0]
    v.movi       v4, #1
    v.movi       v5, #0
    @p2 v.sel        v6, v4, v5
    v.extract    s11, v6, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.splat      v0, s11
    a.vwrite     a0, s23, v4
    v.ld.w       v4, [s20, #0]
    v.movi       v5, #0
    v.cmp.ne     p2, v0, v5
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s13, v4]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s24, v0
    v.ld.w       v0, [s25, #0]
    v.splat      v4, s6
    s.addi       s11, s22, #1024                 // row 1
    v.cmp.lt     p3, v4, v2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.movi       v0, #1
    a.vwrite     a0, s26, v4
    v.ld.w       v4, [s15, #0]
    v.movi       v5, #0
    @p3 v.sel        v6, v0, v5
    v.extract    s15, v6, #0
    v.splat      v0, s15
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s13, v4]              // index is in elements (ISA sec 9.1)
    v.movi       v4, #0
    a.vwrite     a0, s27, v5
    v.ld.w       v5, [s28, #0]
    v.cmp.ne     p3, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s13, v5]              // index is in elements (ISA sec 9.1)
    a.vwrite     a0, s29, v0
    v.ld.w       v0, [s7, #0]
    s.movz       s7, #2
    s.addi       s15, s22, #2048                 // row 2
    v.splat      v4, s7
    v.cmp.lt     p4, v4, v2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s13, v0]              // index is in elements (ISA sec 9.1)
    v.movi       v0, #1
    a.vwrite     a0, s5, v4
    v.ld.w       v4, [s30, #0]
    v.movi       v5, #0
    @p4 v.sel        v6, v0, v5
    v.extract    s5, v6, #0
    v.splat      v0, s5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v5, [s13, v4]              // index is in elements (ISA sec 9.1)
    v.movi       v4, #0
    a.vwrite     a0, s16, v5
    a.vread      v5, a0, s9
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v6, [s22, #0]
    s.movz       s5, #3
    v.cmp.ne     p1, v0, v4
    v.splat      v0, s5
    v.extract    s9, v5, #0
    v.movi       v4, #1
    v.cmp.lt     p2, v0, v2
    s.addi       s13, s22, #3072                 // row 3
    v.splat      v0, s9
    v.movi       v7, #0
    v.movi       v8, #0
    v.extract    s9, v5, #1
    @p2 v.sel        v9, v4, v7
    s.addi       s16, s22, #4096                 // row 4
    v.splat      v4, s9
    v.extract    s9, v9, #0
    v.extract    s17, v5, #2
    v.splat      v7, s9
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v9, [s11, #0]
    vf.fma       v10, v0, v6, v1
    s.movz       s9, #4
    v.movi       v0, #1
    v.splat      v6, s9
    v.movi       v11, #0
    v.cmp.ne     p2, v7, v8
    v.cmp.lt     p3, v6, v2
    @p3 v.sel        v6, v0, v11
    v.movi       v0, #0
    v.splat      v7, s17
    v.extract    s11, v6, #0
    v.extract    s17, v5, #3
    v.splat      v6, s11
    v.splat      v8, s17
    v.extract    s11, v5, #4
    v.cmp.ne     p3, v6, v0
    v.splat      v0, s11
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s15, #0]
    vf.fma       v11, v4, v9, v10
    v.splat      v4, s10
    v.movi       v9, #1
    v.movi       v10, #0
    v.cmp.lt     p1, v4, v2
    v.movi       v4, #0
    @p1 v.sel        v12, v9, v10
    s.addi       s11, s22, #5120                 // row 5
    s.addi       s15, s22, #6144                 // row 6
    v.extract    s17, v12, #0
    v.extract    s18, v5, #5
    v.splat      v9, s17
    v.splat      v10, s18
    v.extract    s17, v5, #6
    v.cmp.ne     p1, v9, v4
    v.splat      v4, s17
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s13, #0]
    vf.fma       v12, v7, v6, v11
    s.movz       s13, #6
    v.movi       v6, #1
    v.splat      v7, s13
    s.addi       s17, s22, #7168                 // row 7
    v.extract    s18, v5, #7
    v.cmp.lt     p2, v7, v2
    v.movi       v7, #0
    @p2 v.sel        v11, v6, v7
    v.movi       v6, #0
    v.extract    s19, v11, #0
    v.splat      v7, s18
    vf.fma       v11, v8, v9, v12
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s16, #0]
    v.splat      v9, s2
    s.movz       s16, #8
    s.addi       s18, s22, #8192                 // row 8
    v.cmp.lt     p2, v9, v2
    v.movi       v9, #1
    v.extract    s20, v5, #8
    vf.fma       v12, v0, v8, v11
    v.movi       v0, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v8, [s11, #0]
    s.addi       s11, s22, #9216                 // row 9
    @p2 v.sel        v11, v9, v0
    v.splat      v0, s19
    v.extract    s19, v5, #9
    v.extract    s23, v11, #0
    v.splat      v9, s16
    v.cmp.ne     p1, v0, v6
    v.movi       v0, #1
    v.movi       v6, #0
    v.cmp.lt     p2, v9, v2
    v.splat      v9, s23
    @p2 v.sel        v11, v0, v6
    v.movi       v0, #0
    v.extract    s23, v11, #0
    v.cmp.ne     p2, v9, v0
    v.splat      v0, s23
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v6, [s15, #0]
    v.movi       v9, #0
    vf.fma       v11, v10, v8, v12
    s.movz       s15, #9
    v.movi       v8, #1
    v.splat      v10, s15
    v.cmp.ne     p1, v0, v9
    v.movi       v0, #0
    v.cmp.lt     p3, v10, v2
    v.movi       v9, #0
    @p3 v.sel        v10, v8, v0
    s.addi       s23, s22, #10240                // row 10
    v.splat      v0, s20
    v.extract    s20, v10, #0
    v.splat      v8, s19
    v.splat      v10, s20
    v.extract    s19, v5, #10
    v.cmp.ne     p3, v10, v9
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s17, #0]
    vf.fma       v10, v4, v6, v11
    s.movz       s17, #10
    v.movi       v4, #1
    v.splat      v6, s17
    v.movi       v11, #0
    v.extract    s20, v5, #11
    v.cmp.lt     p2, v6, v2
    @p2 v.sel        v6, v4, v11
    v.movi       v4, #0
    v.splat      v11, s19
    v.extract    s19, v6, #0
    v.splat      v6, s20
    vf.fma       v12, v7, v9, v10
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v7, [s18, #0]
    s.movz       s18, #11
    v.movi       v9, #1
    s.addi       s20, s22, #11264                // row 11
    v.extract    s24, v5, #12
    vf.fma       v10, v0, v7, v12
    v.splat      v0, s18
    v.movi       v7, #0
    s.movz       s25, #12
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v0, [s11, #0]
    @p1 v.sel        v12, v9, v7
    v.splat      v7, s19
    s.addi       s11, s22, #12288                // row 12
    v.extract    s19, v12, #0
    v.splat      v9, s25
    v.cmp.ne     p1, v7, v4
    v.movi       v4, #1
    v.movi       v7, #0
    v.cmp.lt     p2, v9, v2
    v.splat      v9, s19
    @p2 v.sel        v12, v4, v7
    v.movi       v4, #0
    v.extract    s19, v5, #13
    v.extract    s26, v12, #0
    v.cmp.ne     p2, v9, v4
    v.splat      v4, s26
    v.movi       v7, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s23, #0]
    vf.fma       v12, v8, v0, v10
    s.movz       s23, #13
    v.movi       v0, #1
    v.splat      v8, s23
    v.cmp.ne     p1, v4, v7
    v.movi       v4, #0
    v.cmp.lt     p3, v8, v2
    v.movi       v7, #0
    @p3 v.sel        v8, v0, v4
    s.addi       s26, s22, #13312                // row 13
    v.splat      v0, s24
    v.extract    s24, v8, #0
    v.splat      v4, s19
    v.splat      v8, s24
    v.extract    s19, v5, #14
    v.cmp.ne     p3, v8, v7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s20, #0]
    vf.fma       v8, v11, v9, v12
    s.movz       s20, #14
    v.movi       v9, #1
    v.splat      v10, s20
    v.movi       v11, #0
    s.addi       s24, s22, #14336                // row 14
    v.cmp.lt     p2, v10, v2
    @p2 v.sel        v10, v9, v11
    v.movi       v9, #0
    v.splat      v11, s19
    v.extract    s19, v10, #0
    v.extract    s27, v5, #15
    v.splat      v5, s19
    v.splat      v10, s27
    v.cmp.ne     p2, v5, v9
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s11, #0]
    vf.fma       v9, v6, v7, v8
    s.movz       s11, #15
    v.movi       v6, #1
    v.splat      v7, s11
    v.movi       v8, #0
    s.addi       s19, s22, #15360                // row 15
    v.cmp.lt     p1, v7, v2
    @p1 v.sel        v7, v6, v8
    v.movi       v6, #0
    s.movz       s27, #1
    v.extract    s28, v7, #0
    v.splat      v7, s28
    v.cmp.ne     p1, v7, v6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v6, [s26, #0]
    vf.fma       v7, v0, v5, v9
    v.splat      v0, s1
    v.movi       v5, #1
    v.movi       v8, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v9, v5, v8
    s.movz       s26, #1
    v.extract    s28, v9, #0
    v.splat      v5, s28
    v.cmp.ne     p3, v5, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s24, #0]
    vf.fma       v5, v4, v6, v7
    v.splat      v4, s6
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p2, v4, v2
    v.movi       v4, #0
    @p2 v.sel        v8, v6, v7
    s.addi       s24, s22, #1024                 // row 1
    v.extract    s28, v8, #0
    v.splat      v6, s28
    v.cmp.ne     p2, v6, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v4, [s19, #0]
    vf.fma       v6, v11, v0, v5
    v.splat      v0, s7
    v.movi       v5, #1
    v.movi       v7, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v8, v5, v7
    s.addi       s19, s22, #2048                 // row 2
    v.extract    s28, v8, #0
    v.splat      v5, s28
    v.cmp.ne     p1, v5, v0
    vf.fma       v0, v10, v4, v6
    s.addi       s28, s22, #3072                 // row 3
    a.vwrite     a1, s12, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s12, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s12
    v.splat      v7, s9
    v.extract    s12, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s12
    v.extract    s12, v0, #1
    s.addi       s26, s22, #4096                 // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s12
    v.extract    s12, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s24, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v4, #1
    v.movi       v6, #0
    v.splat      v9, s10
    v.movi       v10, #0
    @p3 v.sel        v11, v4, v6
    v.cmp.lt     p2, v9, v2
    s.addi       s24, s22, #5120                 // row 5
    v.extract    s29, v11, #0
    v.splat      v4, s12
    v.splat      v6, s29
    v.extract    s12, v0, #3
    v.extract    s29, v0, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s12
    v.splat      v9, s29
    v.extract    s12, v0, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    s.addi       s19, s22, #6144                 // row 6
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    v.movi       v5, #0
    v.extract    s29, v12, #0
    v.splat      v7, s12
    v.splat      v8, s29
    v.extract    s12, v0, #6
    v.cmp.ne     p2, v8, v5
    v.splat      v5, s12
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s28, #0]
    vf.fma       v12, v4, v10, v11
    v.movi       v4, #1
    v.movi       v10, #0
    s.addi       s12, s22, #7168                 // row 7
    v.extract    s28, v0, #7
    @p1 v.sel        v11, v4, v10
    v.splat      v4, s2
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v4, v10
    v.splat      v4, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v6, v8, v12
    v.movi       v6, #1
    v.movi       v8, #0
    s.addi       s26, s22, #8192                 // row 8
    v.extract    s28, v0, #8
    @p1 v.sel        v12, v6, v8
    v.splat      v6, s16
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v8, #0
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v9, v10, v11
    v.movi       v9, #1
    v.movi       v10, #0
    s.addi       s24, s22, #9216                 // row 9
    v.extract    s28, v0, #9
    @p1 v.sel        v11, v9, v10
    v.splat      v9, s15
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v9, v2
    v.splat      v9, s29
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.splat      v9, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v7, v8, v12
    v.movi       v7, #1
    v.movi       v8, #0
    s.addi       s19, s22, #10240                // row 10
    v.extract    s28, v0, #10
    @p1 v.sel        v12, v7, v8
    v.splat      v7, s17
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s29
    v.movi       v8, #0
    v.cmp.ne     p4, v7, v8
    v.splat      v7, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v5, v10, v11
    v.movi       v5, #1
    v.movi       v10, #0
    s.addi       s12, s22, #11264                // row 11
    v.extract    s28, v0, #11
    @p1 v.sel        v11, v5, v10
    v.splat      v5, s18
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s29
    v.movi       v10, #0
    v.cmp.ne     p3, v5, v10
    v.splat      v5, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v4, v8, v12
    v.movi       v4, #1
    v.movi       v8, #0
    s.addi       s26, s22, #12288                // row 12
    v.extract    s28, v0, #12
    @p1 v.sel        v12, v4, v8
    v.splat      v4, s25
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v8, #0
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v6, v10, v11
    v.movi       v6, #1
    v.movi       v10, #0
    s.addi       s24, s22, #13312                // row 13
    v.extract    s28, v0, #13
    @p1 v.sel        v11, v6, v10
    v.splat      v6, s23
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v6, v10
    v.splat      v6, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v9, v8, v12
    v.movi       v8, #1
    v.movi       v9, #0
    s.addi       s19, s22, #14336                // row 14
    v.extract    s28, v0, #14
    @p1 v.sel        v12, v8, v9
    v.splat      v8, s20
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s29
    v.movi       v9, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s28
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s12, #0]
    vf.fma       v12, v7, v10, v11
    v.movi       v7, #1
    v.movi       v10, #0
    s.addi       s12, s22, #15360                // row 15
    v.extract    s28, v0, #15
    @p1 v.sel        v0, v7, v10
    v.splat      v7, s11
    v.movi       v10, #0
    v.extract    s29, v0, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v0, s29
    v.splat      v7, s28
    v.cmp.ne     p2, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s26, #0]
    vf.fma       v10, v5, v9, v12
    v.movi       v5, #1
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s26, #2
    @p1 v.sel        v12, v5, v9
    s.movz       s28, #2
    v.extract    s29, v12, #0
    v.splat      v5, s29
    v.cmp.ne     p1, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s24, #0]
    vf.fma       v9, v4, v0, v10
    v.splat      v0, s1
    v.movi       v4, #1
    v.movi       v10, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v11, v4, v10
    v.extract    s24, v11, #0
    v.splat      v4, s24
    v.cmp.ne     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s19, #0]
    vf.fma       v4, v6, v5, v9
    v.splat      v5, s6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.lt     p2, v5, v2
    v.movi       v5, #0
    @p2 v.sel        v10, v6, v9
    s.addi       s19, s22, #1024                 // row 1
    v.extract    s24, v10, #0
    v.splat      v6, s24
    v.cmp.ne     p2, v6, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s12, #0]
    vf.fma       v6, v8, v0, v4
    v.splat      v0, s7
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v9, v4, v8
    s.addi       s12, s22, #2048                 // row 2
    v.extract    s24, v9, #0
    v.splat      v4, s24
    v.cmp.ne     p1, v4, v0
    vf.fma       v0, v7, v5, v6
    s.addi       s24, s22, #3072                 // row 3
    a.vwrite     a1, s27, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s26, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s26
    v.splat      v7, s9
    v.extract    s26, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s26
    v.extract    s26, v0, #1
    s.addi       s27, s22, #4096                 // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s26
    v.extract    s26, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s19, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v4, #1
    v.movi       v6, #0
    v.splat      v9, s10
    v.movi       v10, #0
    @p3 v.sel        v11, v4, v6
    v.cmp.lt     p2, v9, v2
    s.addi       s19, s22, #5120                 // row 5
    v.extract    s29, v11, #0
    v.splat      v4, s26
    v.splat      v6, s29
    v.extract    s26, v0, #3
    v.extract    s29, v0, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s26
    v.splat      v9, s29
    v.extract    s26, v0, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s12, #0]
    vf.fma       v11, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    s.addi       s12, s22, #6144                 // row 6
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    v.movi       v5, #0
    v.extract    s29, v12, #0
    v.splat      v7, s26
    v.splat      v8, s29
    v.extract    s26, v0, #6
    v.cmp.ne     p2, v8, v5
    v.splat      v5, s26
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v4, v10, v11
    v.movi       v4, #1
    v.movi       v10, #0
    s.addi       s24, s22, #7168                 // row 7
    v.extract    s26, v0, #7
    @p1 v.sel        v11, v4, v10
    v.splat      v4, s2
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v4, v10
    v.splat      v4, s26
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s27, #0]
    vf.fma       v11, v6, v8, v12
    v.movi       v6, #1
    v.movi       v8, #0
    s.addi       s26, s22, #8192                 // row 8
    v.extract    s27, v0, #8
    @p1 v.sel        v12, v6, v8
    v.splat      v6, s16
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v8, #0
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s19, #0]
    vf.fma       v12, v9, v10, v11
    v.movi       v9, #1
    v.movi       v10, #0
    s.addi       s19, s22, #9216                 // row 9
    v.extract    s27, v0, #9
    @p1 v.sel        v11, v9, v10
    v.splat      v9, s15
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v9, v2
    v.splat      v9, s29
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.splat      v9, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s12, #0]
    vf.fma       v11, v7, v8, v12
    v.movi       v7, #1
    v.movi       v8, #0
    s.addi       s12, s22, #10240                // row 10
    v.extract    s27, v0, #10
    @p1 v.sel        v12, v7, v8
    v.splat      v7, s17
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s29
    v.movi       v8, #0
    v.cmp.ne     p4, v7, v8
    v.splat      v7, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v5, v10, v11
    v.movi       v5, #1
    v.movi       v10, #0
    s.addi       s24, s22, #11264                // row 11
    v.extract    s27, v0, #11
    @p1 v.sel        v11, v5, v10
    v.splat      v5, s18
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s29
    v.movi       v10, #0
    v.cmp.ne     p3, v5, v10
    v.splat      v5, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v4, v8, v12
    v.movi       v4, #1
    v.movi       v8, #0
    s.addi       s26, s22, #12288                // row 12
    v.extract    s27, v0, #12
    @p1 v.sel        v12, v4, v8
    v.splat      v4, s25
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v8, #0
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    vf.fma       v12, v6, v10, v11
    v.movi       v6, #1
    v.movi       v10, #0
    s.addi       s19, s22, #13312                // row 13
    v.extract    s27, v0, #13
    @p1 v.sel        v11, v6, v10
    v.splat      v6, s23
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v6, v10
    v.splat      v6, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s12, #0]
    vf.fma       v11, v9, v8, v12
    v.movi       v8, #1
    v.movi       v9, #0
    s.addi       s12, s22, #14336                // row 14
    v.extract    s27, v0, #14
    @p1 v.sel        v12, v8, v9
    v.splat      v8, s20
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s29
    v.movi       v9, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s27
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s24, #0]
    vf.fma       v12, v7, v10, v11
    v.movi       v7, #1
    v.movi       v10, #0
    s.addi       s24, s22, #15360                // row 15
    v.extract    s27, v0, #15
    @p1 v.sel        v0, v7, v10
    v.splat      v7, s11
    v.movi       v10, #0
    v.extract    s29, v0, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v0, s29
    v.splat      v7, s27
    v.cmp.ne     p2, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s26, #0]
    vf.fma       v10, v5, v9, v12
    v.movi       v5, #1
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s26, #3
    @p1 v.sel        v12, v5, v9
    s.movz       s27, #3
    v.extract    s29, v12, #0
    v.splat      v5, s29
    v.cmp.ne     p1, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s19, #0]
    vf.fma       v9, v4, v0, v10
    v.splat      v0, s1
    v.movi       v4, #1
    v.movi       v10, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v11, v4, v10
    v.extract    s19, v11, #0
    v.splat      v4, s19
    v.cmp.ne     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s12, #0]
    vf.fma       v4, v6, v5, v9
    v.splat      v5, s6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.lt     p2, v5, v2
    v.movi       v5, #0
    @p2 v.sel        v10, v6, v9
    s.addi       s12, s22, #1024                 // row 1
    v.extract    s19, v10, #0
    v.splat      v6, s19
    v.cmp.ne     p2, v6, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s24, #0]
    vf.fma       v6, v8, v0, v4
    v.splat      v0, s7
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v9, v4, v8
    s.addi       s19, s22, #2048                 // row 2
    v.extract    s24, v9, #0
    v.splat      v4, s24
    v.cmp.ne     p1, v4, v0
    vf.fma       v0, v7, v5, v6
    s.addi       s24, s22, #3072                 // row 3
    a.vwrite     a1, s28, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s26, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s26
    v.splat      v7, s9
    v.extract    s26, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s26
    v.extract    s26, v0, #1
    s.addi       s28, s22, #4096                 // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s26
    v.extract    s26, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s12, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v4, #1
    v.movi       v6, #0
    v.splat      v9, s10
    v.movi       v10, #0
    @p3 v.sel        v11, v4, v6
    v.cmp.lt     p2, v9, v2
    s.addi       s12, s22, #5120                 // row 5
    v.extract    s29, v11, #0
    v.splat      v4, s26
    v.splat      v6, s29
    v.extract    s26, v0, #3
    v.extract    s29, v0, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s26
    v.splat      v9, s29
    v.extract    s26, v0, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    s.addi       s19, s22, #6144                 // row 6
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    v.movi       v5, #0
    v.extract    s29, v12, #0
    v.splat      v7, s26
    v.splat      v8, s29
    v.extract    s26, v0, #6
    v.cmp.ne     p2, v8, v5
    v.splat      v5, s26
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v4, v10, v11
    v.movi       v4, #1
    v.movi       v10, #0
    s.addi       s24, s22, #7168                 // row 7
    v.extract    s26, v0, #7
    @p1 v.sel        v11, v4, v10
    v.splat      v4, s2
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v4, v10
    v.splat      v4, s26
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s28, #0]
    vf.fma       v11, v6, v8, v12
    v.movi       v6, #1
    v.movi       v8, #0
    s.addi       s26, s22, #8192                 // row 8
    v.extract    s28, v0, #8
    @p1 v.sel        v12, v6, v8
    v.splat      v6, s16
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v8, #0
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v9, v10, v11
    v.movi       v9, #1
    v.movi       v10, #0
    s.addi       s12, s22, #9216                 // row 9
    v.extract    s28, v0, #9
    @p1 v.sel        v11, v9, v10
    v.splat      v9, s15
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v9, v2
    v.splat      v9, s29
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.splat      v9, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v7, v8, v12
    v.movi       v7, #1
    v.movi       v8, #0
    s.addi       s19, s22, #10240                // row 10
    v.extract    s28, v0, #10
    @p1 v.sel        v12, v7, v8
    v.splat      v7, s17
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s29
    v.movi       v8, #0
    v.cmp.ne     p4, v7, v8
    v.splat      v7, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v5, v10, v11
    v.movi       v5, #1
    v.movi       v10, #0
    s.addi       s24, s22, #11264                // row 11
    v.extract    s28, v0, #11
    @p1 v.sel        v11, v5, v10
    v.splat      v5, s18
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s29
    v.movi       v10, #0
    v.cmp.ne     p3, v5, v10
    v.splat      v5, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v4, v8, v12
    v.movi       v4, #1
    v.movi       v8, #0
    s.addi       s26, s22, #12288                // row 12
    v.extract    s28, v0, #12
    @p1 v.sel        v12, v4, v8
    v.splat      v4, s25
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v8, #0
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v6, v10, v11
    v.movi       v6, #1
    v.movi       v10, #0
    s.addi       s12, s22, #13312                // row 13
    v.extract    s28, v0, #13
    @p1 v.sel        v11, v6, v10
    v.splat      v6, s23
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v6, v10
    v.splat      v6, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v9, v8, v12
    v.movi       v8, #1
    v.movi       v9, #0
    s.addi       s19, s22, #14336                // row 14
    v.extract    s28, v0, #14
    @p1 v.sel        v12, v8, v9
    v.splat      v8, s20
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s29
    v.movi       v9, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s28
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s24, #0]
    vf.fma       v12, v7, v10, v11
    v.movi       v7, #1
    v.movi       v10, #0
    s.addi       s24, s22, #15360                // row 15
    v.extract    s28, v0, #15
    @p1 v.sel        v0, v7, v10
    v.splat      v7, s11
    v.movi       v10, #0
    v.extract    s29, v0, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v0, s29
    v.splat      v7, s28
    v.cmp.ne     p2, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s26, #0]
    vf.fma       v10, v5, v9, v12
    v.movi       v5, #1
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s26, #4
    @p1 v.sel        v12, v5, v9
    s.movz       s28, #4
    v.extract    s29, v12, #0
    v.splat      v5, s29
    v.cmp.ne     p1, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s12, #0]
    vf.fma       v9, v4, v0, v10
    v.splat      v0, s1
    v.movi       v4, #1
    v.movi       v10, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v11, v4, v10
    v.extract    s12, v11, #0
    v.splat      v4, s12
    v.cmp.ne     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s19, #0]
    vf.fma       v4, v6, v5, v9
    v.splat      v5, s6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.lt     p2, v5, v2
    v.movi       v5, #0
    @p2 v.sel        v10, v6, v9
    s.addi       s12, s22, #1024                 // row 1
    v.extract    s19, v10, #0
    v.splat      v6, s19
    v.cmp.ne     p2, v6, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s24, #0]
    vf.fma       v6, v8, v0, v4
    v.splat      v0, s7
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v9, v4, v8
    s.addi       s19, s22, #2048                 // row 2
    v.extract    s24, v9, #0
    v.splat      v4, s24
    v.cmp.ne     p1, v4, v0
    vf.fma       v0, v7, v5, v6
    s.addi       s24, s22, #3072                 // row 3
    a.vwrite     a1, s27, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s26, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s26
    v.splat      v7, s9
    v.extract    s26, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s26
    v.extract    s26, v0, #1
    s.addi       s27, s22, #4096                 // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s26
    v.extract    s26, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s12, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v4, #1
    v.movi       v6, #0
    v.splat      v9, s10
    v.movi       v10, #0
    @p3 v.sel        v11, v4, v6
    v.cmp.lt     p2, v9, v2
    s.addi       s12, s22, #5120                 // row 5
    v.extract    s29, v11, #0
    v.splat      v4, s26
    v.splat      v6, s29
    v.extract    s26, v0, #3
    v.extract    s29, v0, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s26
    v.splat      v9, s29
    v.extract    s26, v0, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    s.addi       s19, s22, #6144                 // row 6
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    v.movi       v5, #0
    v.extract    s29, v12, #0
    v.splat      v7, s26
    v.splat      v8, s29
    v.extract    s26, v0, #6
    v.cmp.ne     p2, v8, v5
    v.splat      v5, s26
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v4, v10, v11
    v.movi       v4, #1
    v.movi       v10, #0
    s.addi       s24, s22, #7168                 // row 7
    v.extract    s26, v0, #7
    @p1 v.sel        v11, v4, v10
    v.splat      v4, s2
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v4, v10
    v.splat      v4, s26
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s27, #0]
    vf.fma       v11, v6, v8, v12
    v.movi       v6, #1
    v.movi       v8, #0
    s.addi       s26, s22, #8192                 // row 8
    v.extract    s27, v0, #8
    @p1 v.sel        v12, v6, v8
    v.splat      v6, s16
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v8, #0
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v9, v10, v11
    v.movi       v9, #1
    v.movi       v10, #0
    s.addi       s12, s22, #9216                 // row 9
    v.extract    s27, v0, #9
    @p1 v.sel        v11, v9, v10
    v.splat      v9, s15
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v9, v2
    v.splat      v9, s29
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.splat      v9, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v7, v8, v12
    v.movi       v7, #1
    v.movi       v8, #0
    s.addi       s19, s22, #10240                // row 10
    v.extract    s27, v0, #10
    @p1 v.sel        v12, v7, v8
    v.splat      v7, s17
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s29
    v.movi       v8, #0
    v.cmp.ne     p4, v7, v8
    v.splat      v7, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v5, v10, v11
    v.movi       v5, #1
    v.movi       v10, #0
    s.addi       s24, s22, #11264                // row 11
    v.extract    s27, v0, #11
    @p1 v.sel        v11, v5, v10
    v.splat      v5, s18
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s29
    v.movi       v10, #0
    v.cmp.ne     p3, v5, v10
    v.splat      v5, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v4, v8, v12
    v.movi       v4, #1
    v.movi       v8, #0
    s.addi       s26, s22, #12288                // row 12
    v.extract    s27, v0, #12
    @p1 v.sel        v12, v4, v8
    v.splat      v4, s25
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v8, #0
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v6, v10, v11
    v.movi       v6, #1
    v.movi       v10, #0
    s.addi       s12, s22, #13312                // row 13
    v.extract    s27, v0, #13
    @p1 v.sel        v11, v6, v10
    v.splat      v6, s23
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v6, v10
    v.splat      v6, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v9, v8, v12
    v.movi       v8, #1
    v.movi       v9, #0
    s.addi       s19, s22, #14336                // row 14
    v.extract    s27, v0, #14
    @p1 v.sel        v12, v8, v9
    v.splat      v8, s20
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s29
    v.movi       v9, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s27
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s24, #0]
    vf.fma       v12, v7, v10, v11
    v.movi       v7, #1
    v.movi       v10, #0
    s.addi       s24, s22, #15360                // row 15
    v.extract    s27, v0, #15
    @p1 v.sel        v0, v7, v10
    v.splat      v7, s11
    v.movi       v10, #0
    v.extract    s29, v0, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v0, s29
    v.splat      v7, s27
    v.cmp.ne     p2, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s26, #0]
    vf.fma       v10, v5, v9, v12
    v.movi       v5, #1
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s26, #5
    @p1 v.sel        v12, v5, v9
    s.movz       s27, #5
    v.extract    s29, v12, #0
    v.splat      v5, s29
    v.cmp.ne     p1, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s12, #0]
    vf.fma       v9, v4, v0, v10
    v.splat      v0, s1
    v.movi       v4, #1
    v.movi       v10, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v11, v4, v10
    v.extract    s12, v11, #0
    v.splat      v4, s12
    v.cmp.ne     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s19, #0]
    vf.fma       v4, v6, v5, v9
    v.splat      v5, s6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.lt     p2, v5, v2
    v.movi       v5, #0
    @p2 v.sel        v10, v6, v9
    s.addi       s12, s22, #1024                 // row 1
    v.extract    s19, v10, #0
    v.splat      v6, s19
    v.cmp.ne     p2, v6, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s24, #0]
    vf.fma       v6, v8, v0, v4
    v.splat      v0, s7
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v9, v4, v8
    s.addi       s19, s22, #2048                 // row 2
    v.extract    s24, v9, #0
    v.splat      v4, s24
    v.cmp.ne     p1, v4, v0
    vf.fma       v0, v7, v5, v6
    s.addi       s24, s22, #3072                 // row 3
    a.vwrite     a1, s28, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s26, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s26
    v.splat      v7, s9
    v.extract    s26, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s26
    v.extract    s26, v0, #1
    s.addi       s28, s22, #4096                 // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s26
    v.extract    s26, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s12, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v4, #1
    v.movi       v6, #0
    v.splat      v9, s10
    v.movi       v10, #0
    @p3 v.sel        v11, v4, v6
    v.cmp.lt     p2, v9, v2
    s.addi       s12, s22, #5120                 // row 5
    v.extract    s29, v11, #0
    v.splat      v4, s26
    v.splat      v6, s29
    v.extract    s26, v0, #3
    v.extract    s29, v0, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s26
    v.splat      v9, s29
    v.extract    s26, v0, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    s.addi       s19, s22, #6144                 // row 6
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    v.movi       v5, #0
    v.extract    s29, v12, #0
    v.splat      v7, s26
    v.splat      v8, s29
    v.extract    s26, v0, #6
    v.cmp.ne     p2, v8, v5
    v.splat      v5, s26
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v4, v10, v11
    v.movi       v4, #1
    v.movi       v10, #0
    s.addi       s24, s22, #7168                 // row 7
    v.extract    s26, v0, #7
    @p1 v.sel        v11, v4, v10
    v.splat      v4, s2
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v4, v10
    v.splat      v4, s26
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s28, #0]
    vf.fma       v11, v6, v8, v12
    v.movi       v6, #1
    v.movi       v8, #0
    s.addi       s26, s22, #8192                 // row 8
    v.extract    s28, v0, #8
    @p1 v.sel        v12, v6, v8
    v.splat      v6, s16
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v8, #0
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v9, v10, v11
    v.movi       v9, #1
    v.movi       v10, #0
    s.addi       s12, s22, #9216                 // row 9
    v.extract    s28, v0, #9
    @p1 v.sel        v11, v9, v10
    v.splat      v9, s15
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v9, v2
    v.splat      v9, s29
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.splat      v9, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v7, v8, v12
    v.movi       v7, #1
    v.movi       v8, #0
    s.addi       s19, s22, #10240                // row 10
    v.extract    s28, v0, #10
    @p1 v.sel        v12, v7, v8
    v.splat      v7, s17
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s29
    v.movi       v8, #0
    v.cmp.ne     p4, v7, v8
    v.splat      v7, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v5, v10, v11
    v.movi       v5, #1
    v.movi       v10, #0
    s.addi       s24, s22, #11264                // row 11
    v.extract    s28, v0, #11
    @p1 v.sel        v11, v5, v10
    v.splat      v5, s18
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s29
    v.movi       v10, #0
    v.cmp.ne     p3, v5, v10
    v.splat      v5, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v4, v8, v12
    v.movi       v4, #1
    v.movi       v8, #0
    s.addi       s26, s22, #12288                // row 12
    v.extract    s28, v0, #12
    @p1 v.sel        v12, v4, v8
    v.splat      v4, s25
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v8, #0
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v6, v10, v11
    v.movi       v6, #1
    v.movi       v10, #0
    s.addi       s12, s22, #13312                // row 13
    v.extract    s28, v0, #13
    @p1 v.sel        v11, v6, v10
    v.splat      v6, s23
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v6, v10
    v.splat      v6, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v9, v8, v12
    v.movi       v8, #1
    v.movi       v9, #0
    s.addi       s19, s22, #14336                // row 14
    v.extract    s28, v0, #14
    @p1 v.sel        v12, v8, v9
    v.splat      v8, s20
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s29
    v.movi       v9, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s28
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s24, #0]
    vf.fma       v12, v7, v10, v11
    v.movi       v7, #1
    v.movi       v10, #0
    s.addi       s24, s22, #15360                // row 15
    v.extract    s28, v0, #15
    @p1 v.sel        v0, v7, v10
    v.splat      v7, s11
    v.movi       v10, #0
    v.extract    s29, v0, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v0, s29
    v.splat      v7, s28
    v.cmp.ne     p2, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s26, #0]
    vf.fma       v10, v5, v9, v12
    v.movi       v5, #1
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s26, #6
    @p1 v.sel        v12, v5, v9
    s.movz       s28, #6
    v.extract    s29, v12, #0
    v.splat      v5, s29
    v.cmp.ne     p1, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s12, #0]
    vf.fma       v9, v4, v0, v10
    v.splat      v0, s1
    v.movi       v4, #1
    v.movi       v10, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v11, v4, v10
    v.extract    s12, v11, #0
    v.splat      v4, s12
    v.cmp.ne     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s19, #0]
    vf.fma       v4, v6, v5, v9
    v.splat      v5, s6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.lt     p2, v5, v2
    v.movi       v5, #0
    @p2 v.sel        v10, v6, v9
    s.addi       s12, s22, #1024                 // row 1
    v.extract    s19, v10, #0
    v.splat      v6, s19
    v.cmp.ne     p2, v6, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s24, #0]
    vf.fma       v6, v8, v0, v4
    v.splat      v0, s7
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v9, v4, v8
    s.addi       s19, s22, #2048                 // row 2
    v.extract    s24, v9, #0
    v.splat      v4, s24
    v.cmp.ne     p1, v4, v0
    vf.fma       v0, v7, v5, v6
    s.addi       s24, s22, #3072                 // row 3
    a.vwrite     a1, s27, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s26, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s26
    v.splat      v7, s9
    v.extract    s26, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s26
    v.extract    s26, v0, #1
    s.addi       s27, s22, #4096                 // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s26
    v.extract    s26, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s12, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v4, #1
    v.movi       v6, #0
    v.splat      v9, s10
    v.movi       v10, #0
    @p3 v.sel        v11, v4, v6
    v.cmp.lt     p2, v9, v2
    s.addi       s12, s22, #5120                 // row 5
    v.extract    s29, v11, #0
    v.splat      v4, s26
    v.splat      v6, s29
    v.extract    s26, v0, #3
    v.extract    s29, v0, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s26
    v.splat      v9, s29
    v.extract    s26, v0, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    s.addi       s19, s22, #6144                 // row 6
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    v.movi       v5, #0
    v.extract    s29, v12, #0
    v.splat      v7, s26
    v.splat      v8, s29
    v.extract    s26, v0, #6
    v.cmp.ne     p2, v8, v5
    v.splat      v5, s26
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v4, v10, v11
    v.movi       v4, #1
    v.movi       v10, #0
    s.addi       s24, s22, #7168                 // row 7
    v.extract    s26, v0, #7
    @p1 v.sel        v11, v4, v10
    v.splat      v4, s2
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v4, v10
    v.splat      v4, s26
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s27, #0]
    vf.fma       v11, v6, v8, v12
    v.movi       v6, #1
    v.movi       v8, #0
    s.addi       s26, s22, #8192                 // row 8
    v.extract    s27, v0, #8
    @p1 v.sel        v12, v6, v8
    v.splat      v6, s16
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v8, #0
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v9, v10, v11
    v.movi       v9, #1
    v.movi       v10, #0
    s.addi       s12, s22, #9216                 // row 9
    v.extract    s27, v0, #9
    @p1 v.sel        v11, v9, v10
    v.splat      v9, s15
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v9, v2
    v.splat      v9, s29
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.splat      v9, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v7, v8, v12
    v.movi       v7, #1
    v.movi       v8, #0
    s.addi       s19, s22, #10240                // row 10
    v.extract    s27, v0, #10
    @p1 v.sel        v12, v7, v8
    v.splat      v7, s17
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s29
    v.movi       v8, #0
    v.cmp.ne     p4, v7, v8
    v.splat      v7, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v5, v10, v11
    v.movi       v5, #1
    v.movi       v10, #0
    s.addi       s24, s22, #11264                // row 11
    v.extract    s27, v0, #11
    @p1 v.sel        v11, v5, v10
    v.splat      v5, s18
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s29
    v.movi       v10, #0
    v.cmp.ne     p3, v5, v10
    v.splat      v5, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v4, v8, v12
    v.movi       v4, #1
    v.movi       v8, #0
    s.addi       s26, s22, #12288                // row 12
    v.extract    s27, v0, #12
    @p1 v.sel        v12, v4, v8
    v.splat      v4, s25
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v8, #0
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v6, v10, v11
    v.movi       v6, #1
    v.movi       v10, #0
    s.addi       s12, s22, #13312                // row 13
    v.extract    s27, v0, #13
    @p1 v.sel        v11, v6, v10
    v.splat      v6, s23
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v6, v10
    v.splat      v6, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v9, v8, v12
    v.movi       v8, #1
    v.movi       v9, #0
    s.addi       s19, s22, #14336                // row 14
    v.extract    s27, v0, #14
    @p1 v.sel        v12, v8, v9
    v.splat      v8, s20
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s29
    v.movi       v9, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s27
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s24, #0]
    vf.fma       v12, v7, v10, v11
    v.movi       v7, #1
    v.movi       v10, #0
    s.addi       s24, s22, #15360                // row 15
    v.extract    s27, v0, #15
    @p1 v.sel        v0, v7, v10
    v.splat      v7, s11
    v.movi       v10, #0
    v.extract    s29, v0, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v0, s29
    v.splat      v7, s27
    v.cmp.ne     p2, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s26, #0]
    vf.fma       v10, v5, v9, v12
    v.movi       v5, #1
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s26, #7
    @p1 v.sel        v12, v5, v9
    s.movz       s27, #7
    v.extract    s29, v12, #0
    v.splat      v5, s29
    v.cmp.ne     p1, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s12, #0]
    vf.fma       v9, v4, v0, v10
    v.splat      v0, s1
    v.movi       v4, #1
    v.movi       v10, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v11, v4, v10
    v.extract    s12, v11, #0
    v.splat      v4, s12
    v.cmp.ne     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s19, #0]
    vf.fma       v4, v6, v5, v9
    v.splat      v5, s6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.lt     p2, v5, v2
    v.movi       v5, #0
    @p2 v.sel        v10, v6, v9
    s.addi       s12, s22, #1024                 // row 1
    v.extract    s19, v10, #0
    v.splat      v6, s19
    v.cmp.ne     p2, v6, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s24, #0]
    vf.fma       v6, v8, v0, v4
    v.splat      v0, s7
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v9, v4, v8
    s.addi       s19, s22, #2048                 // row 2
    v.extract    s24, v9, #0
    v.splat      v4, s24
    v.cmp.ne     p1, v4, v0
    vf.fma       v0, v7, v5, v6
    s.addi       s24, s22, #3072                 // row 3
    a.vwrite     a1, s28, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s26, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s26
    v.splat      v7, s9
    v.extract    s26, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s26
    v.extract    s26, v0, #1
    s.addi       s28, s22, #4096                 // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s26
    v.extract    s26, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s12, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v4, #1
    v.movi       v6, #0
    v.splat      v9, s10
    v.movi       v10, #0
    @p3 v.sel        v11, v4, v6
    v.cmp.lt     p2, v9, v2
    s.addi       s12, s22, #5120                 // row 5
    v.extract    s29, v11, #0
    v.splat      v4, s26
    v.splat      v6, s29
    v.extract    s26, v0, #3
    v.extract    s29, v0, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s26
    v.splat      v9, s29
    v.extract    s26, v0, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    s.addi       s19, s22, #6144                 // row 6
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    v.movi       v5, #0
    v.extract    s29, v12, #0
    v.splat      v7, s26
    v.splat      v8, s29
    v.extract    s26, v0, #6
    v.cmp.ne     p2, v8, v5
    v.splat      v5, s26
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v4, v10, v11
    v.movi       v4, #1
    v.movi       v10, #0
    s.addi       s24, s22, #7168                 // row 7
    v.extract    s26, v0, #7
    @p1 v.sel        v11, v4, v10
    v.splat      v4, s2
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v4, v10
    v.splat      v4, s26
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s28, #0]
    vf.fma       v11, v6, v8, v12
    v.movi       v6, #1
    v.movi       v8, #0
    s.addi       s26, s22, #8192                 // row 8
    v.extract    s28, v0, #8
    @p1 v.sel        v12, v6, v8
    v.splat      v6, s16
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v8, #0
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v9, v10, v11
    v.movi       v9, #1
    v.movi       v10, #0
    s.addi       s12, s22, #9216                 // row 9
    v.extract    s28, v0, #9
    @p1 v.sel        v11, v9, v10
    v.splat      v9, s15
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v9, v2
    v.splat      v9, s29
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.splat      v9, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v7, v8, v12
    v.movi       v7, #1
    v.movi       v8, #0
    s.addi       s19, s22, #10240                // row 10
    v.extract    s28, v0, #10
    @p1 v.sel        v12, v7, v8
    v.splat      v7, s17
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s29
    v.movi       v8, #0
    v.cmp.ne     p4, v7, v8
    v.splat      v7, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v5, v10, v11
    v.movi       v5, #1
    v.movi       v10, #0
    s.addi       s24, s22, #11264                // row 11
    v.extract    s28, v0, #11
    @p1 v.sel        v11, v5, v10
    v.splat      v5, s18
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s29
    v.movi       v10, #0
    v.cmp.ne     p3, v5, v10
    v.splat      v5, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v4, v8, v12
    v.movi       v4, #1
    v.movi       v8, #0
    s.addi       s26, s22, #12288                // row 12
    v.extract    s28, v0, #12
    @p1 v.sel        v12, v4, v8
    v.splat      v4, s25
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v8, #0
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v6, v10, v11
    v.movi       v6, #1
    v.movi       v10, #0
    s.addi       s12, s22, #13312                // row 13
    v.extract    s28, v0, #13
    @p1 v.sel        v11, v6, v10
    v.splat      v6, s23
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v6, v10
    v.splat      v6, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v9, v8, v12
    v.movi       v8, #1
    v.movi       v9, #0
    s.addi       s19, s22, #14336                // row 14
    v.extract    s28, v0, #14
    @p1 v.sel        v12, v8, v9
    v.splat      v8, s20
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s29
    v.movi       v9, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s28
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s24, #0]
    vf.fma       v12, v7, v10, v11
    v.movi       v7, #1
    v.movi       v10, #0
    s.addi       s24, s22, #15360                // row 15
    v.extract    s28, v0, #15
    @p1 v.sel        v0, v7, v10
    v.splat      v7, s11
    v.movi       v10, #0
    v.extract    s29, v0, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v0, s29
    v.splat      v7, s28
    v.cmp.ne     p2, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s26, #0]
    vf.fma       v10, v5, v9, v12
    v.movi       v5, #1
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s26, #8
    @p1 v.sel        v12, v5, v9
    s.movz       s28, #8
    v.extract    s29, v12, #0
    v.splat      v5, s29
    v.cmp.ne     p1, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s12, #0]
    vf.fma       v9, v4, v0, v10
    v.splat      v0, s1
    v.movi       v4, #1
    v.movi       v10, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v11, v4, v10
    v.extract    s12, v11, #0
    v.splat      v4, s12
    v.cmp.ne     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s19, #0]
    vf.fma       v4, v6, v5, v9
    v.splat      v5, s6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.lt     p2, v5, v2
    v.movi       v5, #0
    @p2 v.sel        v10, v6, v9
    s.addi       s12, s22, #1024                 // row 1
    v.extract    s19, v10, #0
    v.splat      v6, s19
    v.cmp.ne     p2, v6, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s24, #0]
    vf.fma       v6, v8, v0, v4
    v.splat      v0, s7
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v9, v4, v8
    s.addi       s19, s22, #2048                 // row 2
    v.extract    s24, v9, #0
    v.splat      v4, s24
    v.cmp.ne     p1, v4, v0
    vf.fma       v0, v7, v5, v6
    s.addi       s24, s22, #3072                 // row 3
    a.vwrite     a1, s27, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s26, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s26
    v.splat      v7, s9
    v.extract    s26, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s26
    v.extract    s26, v0, #1
    s.addi       s27, s22, #4096                 // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s26
    v.extract    s26, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s12, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v4, #1
    v.movi       v6, #0
    v.splat      v9, s10
    v.movi       v10, #0
    @p3 v.sel        v11, v4, v6
    v.cmp.lt     p2, v9, v2
    s.addi       s12, s22, #5120                 // row 5
    v.extract    s29, v11, #0
    v.splat      v4, s26
    v.splat      v6, s29
    v.extract    s26, v0, #3
    v.extract    s29, v0, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s26
    v.splat      v9, s29
    v.extract    s26, v0, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    s.addi       s19, s22, #6144                 // row 6
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    v.movi       v5, #0
    v.extract    s29, v12, #0
    v.splat      v7, s26
    v.splat      v8, s29
    v.extract    s26, v0, #6
    v.cmp.ne     p2, v8, v5
    v.splat      v5, s26
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v4, v10, v11
    v.movi       v4, #1
    v.movi       v10, #0
    s.addi       s24, s22, #7168                 // row 7
    v.extract    s26, v0, #7
    @p1 v.sel        v11, v4, v10
    v.splat      v4, s2
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v4, v10
    v.splat      v4, s26
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s27, #0]
    vf.fma       v11, v6, v8, v12
    v.movi       v6, #1
    v.movi       v8, #0
    s.addi       s26, s22, #8192                 // row 8
    v.extract    s27, v0, #8
    @p1 v.sel        v12, v6, v8
    v.splat      v6, s16
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v8, #0
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v9, v10, v11
    v.movi       v9, #1
    v.movi       v10, #0
    s.addi       s12, s22, #9216                 // row 9
    v.extract    s27, v0, #9
    @p1 v.sel        v11, v9, v10
    v.splat      v9, s15
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v9, v2
    v.splat      v9, s29
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.splat      v9, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v7, v8, v12
    v.movi       v7, #1
    v.movi       v8, #0
    s.addi       s19, s22, #10240                // row 10
    v.extract    s27, v0, #10
    @p1 v.sel        v12, v7, v8
    v.splat      v7, s17
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s29
    v.movi       v8, #0
    v.cmp.ne     p4, v7, v8
    v.splat      v7, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v5, v10, v11
    v.movi       v5, #1
    v.movi       v10, #0
    s.addi       s24, s22, #11264                // row 11
    v.extract    s27, v0, #11
    @p1 v.sel        v11, v5, v10
    v.splat      v5, s18
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s29
    v.movi       v10, #0
    v.cmp.ne     p3, v5, v10
    v.splat      v5, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v4, v8, v12
    v.movi       v4, #1
    v.movi       v8, #0
    s.addi       s26, s22, #12288                // row 12
    v.extract    s27, v0, #12
    @p1 v.sel        v12, v4, v8
    v.splat      v4, s25
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v8, #0
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v6, v10, v11
    v.movi       v6, #1
    v.movi       v10, #0
    s.addi       s12, s22, #13312                // row 13
    v.extract    s27, v0, #13
    @p1 v.sel        v11, v6, v10
    v.splat      v6, s23
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v6, v10
    v.splat      v6, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v9, v8, v12
    v.movi       v8, #1
    v.movi       v9, #0
    s.addi       s19, s22, #14336                // row 14
    v.extract    s27, v0, #14
    @p1 v.sel        v12, v8, v9
    v.splat      v8, s20
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s29
    v.movi       v9, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s27
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s24, #0]
    vf.fma       v12, v7, v10, v11
    v.movi       v7, #1
    v.movi       v10, #0
    s.addi       s24, s22, #15360                // row 15
    v.extract    s27, v0, #15
    @p1 v.sel        v0, v7, v10
    v.splat      v7, s11
    v.movi       v10, #0
    v.extract    s29, v0, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v0, s29
    v.splat      v7, s27
    v.cmp.ne     p2, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s26, #0]
    vf.fma       v10, v5, v9, v12
    v.movi       v5, #1
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s26, #9
    @p1 v.sel        v12, v5, v9
    s.movz       s27, #9
    v.extract    s29, v12, #0
    v.splat      v5, s29
    v.cmp.ne     p1, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s12, #0]
    vf.fma       v9, v4, v0, v10
    v.splat      v0, s1
    v.movi       v4, #1
    v.movi       v10, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v11, v4, v10
    v.extract    s12, v11, #0
    v.splat      v4, s12
    v.cmp.ne     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s19, #0]
    vf.fma       v4, v6, v5, v9
    v.splat      v5, s6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.lt     p2, v5, v2
    v.movi       v5, #0
    @p2 v.sel        v10, v6, v9
    s.addi       s12, s22, #1024                 // row 1
    v.extract    s19, v10, #0
    v.splat      v6, s19
    v.cmp.ne     p2, v6, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s24, #0]
    vf.fma       v6, v8, v0, v4
    v.splat      v0, s7
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v9, v4, v8
    s.addi       s19, s22, #2048                 // row 2
    v.extract    s24, v9, #0
    v.splat      v4, s24
    v.cmp.ne     p1, v4, v0
    vf.fma       v0, v7, v5, v6
    s.addi       s24, s22, #3072                 // row 3
    a.vwrite     a1, s28, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s26, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s26
    v.splat      v7, s9
    v.extract    s26, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s26
    v.extract    s26, v0, #1
    s.addi       s28, s22, #4096                 // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s26
    v.extract    s26, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s12, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v4, #1
    v.movi       v6, #0
    v.splat      v9, s10
    v.movi       v10, #0
    @p3 v.sel        v11, v4, v6
    v.cmp.lt     p2, v9, v2
    s.addi       s12, s22, #5120                 // row 5
    v.extract    s29, v11, #0
    v.splat      v4, s26
    v.splat      v6, s29
    v.extract    s26, v0, #3
    v.extract    s29, v0, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s26
    v.splat      v9, s29
    v.extract    s26, v0, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    s.addi       s19, s22, #6144                 // row 6
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    v.movi       v5, #0
    v.extract    s29, v12, #0
    v.splat      v7, s26
    v.splat      v8, s29
    v.extract    s26, v0, #6
    v.cmp.ne     p2, v8, v5
    v.splat      v5, s26
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v4, v10, v11
    v.movi       v4, #1
    v.movi       v10, #0
    s.addi       s24, s22, #7168                 // row 7
    v.extract    s26, v0, #7
    @p1 v.sel        v11, v4, v10
    v.splat      v4, s2
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v4, v10
    v.splat      v4, s26
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s28, #0]
    vf.fma       v11, v6, v8, v12
    v.movi       v6, #1
    v.movi       v8, #0
    s.addi       s26, s22, #8192                 // row 8
    v.extract    s28, v0, #8
    @p1 v.sel        v12, v6, v8
    v.splat      v6, s16
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v8, #0
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v9, v10, v11
    v.movi       v9, #1
    v.movi       v10, #0
    s.addi       s12, s22, #9216                 // row 9
    v.extract    s28, v0, #9
    @p1 v.sel        v11, v9, v10
    v.splat      v9, s15
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v9, v2
    v.splat      v9, s29
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.splat      v9, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v7, v8, v12
    v.movi       v7, #1
    v.movi       v8, #0
    s.addi       s19, s22, #10240                // row 10
    v.extract    s28, v0, #10
    @p1 v.sel        v12, v7, v8
    v.splat      v7, s17
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s29
    v.movi       v8, #0
    v.cmp.ne     p4, v7, v8
    v.splat      v7, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v5, v10, v11
    v.movi       v5, #1
    v.movi       v10, #0
    s.addi       s24, s22, #11264                // row 11
    v.extract    s28, v0, #11
    @p1 v.sel        v11, v5, v10
    v.splat      v5, s18
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s29
    v.movi       v10, #0
    v.cmp.ne     p3, v5, v10
    v.splat      v5, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v4, v8, v12
    v.movi       v4, #1
    v.movi       v8, #0
    s.addi       s26, s22, #12288                // row 12
    v.extract    s28, v0, #12
    @p1 v.sel        v12, v4, v8
    v.splat      v4, s25
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v8, #0
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v6, v10, v11
    v.movi       v6, #1
    v.movi       v10, #0
    s.addi       s12, s22, #13312                // row 13
    v.extract    s28, v0, #13
    @p1 v.sel        v11, v6, v10
    v.splat      v6, s23
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v6, v10
    v.splat      v6, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v9, v8, v12
    v.movi       v8, #1
    v.movi       v9, #0
    s.addi       s19, s22, #14336                // row 14
    v.extract    s28, v0, #14
    @p1 v.sel        v12, v8, v9
    v.splat      v8, s20
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s29
    v.movi       v9, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s28
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s24, #0]
    vf.fma       v12, v7, v10, v11
    v.movi       v7, #1
    v.movi       v10, #0
    s.addi       s24, s22, #15360                // row 15
    v.extract    s28, v0, #15
    @p1 v.sel        v0, v7, v10
    v.splat      v7, s11
    v.movi       v10, #0
    v.extract    s29, v0, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v0, s29
    v.splat      v7, s28
    v.cmp.ne     p2, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s26, #0]
    vf.fma       v10, v5, v9, v12
    v.movi       v5, #1
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s26, #10
    @p1 v.sel        v12, v5, v9
    s.movz       s28, #10
    v.extract    s29, v12, #0
    v.splat      v5, s29
    v.cmp.ne     p1, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s12, #0]
    vf.fma       v9, v4, v0, v10
    v.splat      v0, s1
    v.movi       v4, #1
    v.movi       v10, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v11, v4, v10
    v.extract    s12, v11, #0
    v.splat      v4, s12
    v.cmp.ne     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s19, #0]
    vf.fma       v4, v6, v5, v9
    v.splat      v5, s6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.lt     p2, v5, v2
    v.movi       v5, #0
    @p2 v.sel        v10, v6, v9
    s.addi       s12, s22, #1024                 // row 1
    v.extract    s19, v10, #0
    v.splat      v6, s19
    v.cmp.ne     p2, v6, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s24, #0]
    vf.fma       v6, v8, v0, v4
    v.splat      v0, s7
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v9, v4, v8
    s.addi       s19, s22, #2048                 // row 2
    v.extract    s24, v9, #0
    v.splat      v4, s24
    v.cmp.ne     p1, v4, v0
    vf.fma       v0, v7, v5, v6
    s.addi       s24, s22, #3072                 // row 3
    a.vwrite     a1, s27, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s26, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s26
    v.splat      v7, s9
    v.extract    s26, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s26
    v.extract    s26, v0, #1
    s.addi       s27, s22, #4096                 // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s26
    v.extract    s26, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s12, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v4, #1
    v.movi       v6, #0
    v.splat      v9, s10
    v.movi       v10, #0
    @p3 v.sel        v11, v4, v6
    v.cmp.lt     p2, v9, v2
    s.addi       s12, s22, #5120                 // row 5
    v.extract    s29, v11, #0
    v.splat      v4, s26
    v.splat      v6, s29
    v.extract    s26, v0, #3
    v.extract    s29, v0, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s26
    v.splat      v9, s29
    v.extract    s26, v0, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    s.addi       s19, s22, #6144                 // row 6
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    v.movi       v5, #0
    v.extract    s29, v12, #0
    v.splat      v7, s26
    v.splat      v8, s29
    v.extract    s26, v0, #6
    v.cmp.ne     p2, v8, v5
    v.splat      v5, s26
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v4, v10, v11
    v.movi       v4, #1
    v.movi       v10, #0
    s.addi       s24, s22, #7168                 // row 7
    v.extract    s26, v0, #7
    @p1 v.sel        v11, v4, v10
    v.splat      v4, s2
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v4, v10
    v.splat      v4, s26
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s27, #0]
    vf.fma       v11, v6, v8, v12
    v.movi       v6, #1
    v.movi       v8, #0
    s.addi       s26, s22, #8192                 // row 8
    v.extract    s27, v0, #8
    @p1 v.sel        v12, v6, v8
    v.splat      v6, s16
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v8, #0
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v9, v10, v11
    v.movi       v9, #1
    v.movi       v10, #0
    s.addi       s12, s22, #9216                 // row 9
    v.extract    s27, v0, #9
    @p1 v.sel        v11, v9, v10
    v.splat      v9, s15
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v9, v2
    v.splat      v9, s29
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.splat      v9, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v7, v8, v12
    v.movi       v7, #1
    v.movi       v8, #0
    s.addi       s19, s22, #10240                // row 10
    v.extract    s27, v0, #10
    @p1 v.sel        v12, v7, v8
    v.splat      v7, s17
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s29
    v.movi       v8, #0
    v.cmp.ne     p4, v7, v8
    v.splat      v7, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v5, v10, v11
    v.movi       v5, #1
    v.movi       v10, #0
    s.addi       s24, s22, #11264                // row 11
    v.extract    s27, v0, #11
    @p1 v.sel        v11, v5, v10
    v.splat      v5, s18
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s29
    v.movi       v10, #0
    v.cmp.ne     p3, v5, v10
    v.splat      v5, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v4, v8, v12
    v.movi       v4, #1
    v.movi       v8, #0
    s.addi       s26, s22, #12288                // row 12
    v.extract    s27, v0, #12
    @p1 v.sel        v12, v4, v8
    v.splat      v4, s25
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v8, #0
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v6, v10, v11
    v.movi       v6, #1
    v.movi       v10, #0
    s.addi       s12, s22, #13312                // row 13
    v.extract    s27, v0, #13
    @p1 v.sel        v11, v6, v10
    v.splat      v6, s23
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v6, v10
    v.splat      v6, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v9, v8, v12
    v.movi       v8, #1
    v.movi       v9, #0
    s.addi       s19, s22, #14336                // row 14
    v.extract    s27, v0, #14
    @p1 v.sel        v12, v8, v9
    v.splat      v8, s20
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s29
    v.movi       v9, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s27
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s24, #0]
    vf.fma       v12, v7, v10, v11
    v.movi       v7, #1
    v.movi       v10, #0
    s.addi       s24, s22, #15360                // row 15
    v.extract    s27, v0, #15
    @p1 v.sel        v0, v7, v10
    v.splat      v7, s11
    v.movi       v10, #0
    v.extract    s29, v0, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v0, s29
    v.splat      v7, s27
    v.cmp.ne     p2, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s26, #0]
    vf.fma       v10, v5, v9, v12
    v.movi       v5, #1
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s26, #11
    @p1 v.sel        v12, v5, v9
    s.movz       s27, #11
    v.extract    s29, v12, #0
    v.splat      v5, s29
    v.cmp.ne     p1, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s12, #0]
    vf.fma       v9, v4, v0, v10
    v.splat      v0, s1
    v.movi       v4, #1
    v.movi       v10, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v11, v4, v10
    v.extract    s12, v11, #0
    v.splat      v4, s12
    v.cmp.ne     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s19, #0]
    vf.fma       v4, v6, v5, v9
    v.splat      v5, s6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.lt     p2, v5, v2
    v.movi       v5, #0
    @p2 v.sel        v10, v6, v9
    s.addi       s12, s22, #1024                 // row 1
    v.extract    s19, v10, #0
    v.splat      v6, s19
    v.cmp.ne     p2, v6, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s24, #0]
    vf.fma       v6, v8, v0, v4
    v.splat      v0, s7
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v9, v4, v8
    s.addi       s19, s22, #2048                 // row 2
    v.extract    s24, v9, #0
    v.splat      v4, s24
    v.cmp.ne     p1, v4, v0
    vf.fma       v0, v7, v5, v6
    s.addi       s24, s22, #3072                 // row 3
    a.vwrite     a1, s28, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s26, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s26
    v.splat      v7, s9
    v.extract    s26, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s26
    v.extract    s26, v0, #1
    s.addi       s28, s22, #4096                 // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s26
    v.extract    s26, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s12, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v4, #1
    v.movi       v6, #0
    v.splat      v9, s10
    v.movi       v10, #0
    @p3 v.sel        v11, v4, v6
    v.cmp.lt     p2, v9, v2
    s.addi       s12, s22, #5120                 // row 5
    v.extract    s29, v11, #0
    v.splat      v4, s26
    v.splat      v6, s29
    v.extract    s26, v0, #3
    v.extract    s29, v0, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s26
    v.splat      v9, s29
    v.extract    s26, v0, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    s.addi       s19, s22, #6144                 // row 6
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    v.movi       v5, #0
    v.extract    s29, v12, #0
    v.splat      v7, s26
    v.splat      v8, s29
    v.extract    s26, v0, #6
    v.cmp.ne     p2, v8, v5
    v.splat      v5, s26
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v4, v10, v11
    v.movi       v4, #1
    v.movi       v10, #0
    s.addi       s24, s22, #7168                 // row 7
    v.extract    s26, v0, #7
    @p1 v.sel        v11, v4, v10
    v.splat      v4, s2
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v4, v10
    v.splat      v4, s26
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s28, #0]
    vf.fma       v11, v6, v8, v12
    v.movi       v6, #1
    v.movi       v8, #0
    s.addi       s26, s22, #8192                 // row 8
    v.extract    s28, v0, #8
    @p1 v.sel        v12, v6, v8
    v.splat      v6, s16
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v8, #0
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v9, v10, v11
    v.movi       v9, #1
    v.movi       v10, #0
    s.addi       s12, s22, #9216                 // row 9
    v.extract    s28, v0, #9
    @p1 v.sel        v11, v9, v10
    v.splat      v9, s15
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v9, v2
    v.splat      v9, s29
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.splat      v9, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v7, v8, v12
    v.movi       v7, #1
    v.movi       v8, #0
    s.addi       s19, s22, #10240                // row 10
    v.extract    s28, v0, #10
    @p1 v.sel        v12, v7, v8
    v.splat      v7, s17
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s29
    v.movi       v8, #0
    v.cmp.ne     p4, v7, v8
    v.splat      v7, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v5, v10, v11
    v.movi       v5, #1
    v.movi       v10, #0
    s.addi       s24, s22, #11264                // row 11
    v.extract    s28, v0, #11
    @p1 v.sel        v11, v5, v10
    v.splat      v5, s18
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s29
    v.movi       v10, #0
    v.cmp.ne     p3, v5, v10
    v.splat      v5, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v4, v8, v12
    v.movi       v4, #1
    v.movi       v8, #0
    s.addi       s26, s22, #12288                // row 12
    v.extract    s28, v0, #12
    @p1 v.sel        v12, v4, v8
    v.splat      v4, s25
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v8, #0
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v6, v10, v11
    v.movi       v6, #1
    v.movi       v10, #0
    s.addi       s12, s22, #13312                // row 13
    v.extract    s28, v0, #13
    @p1 v.sel        v11, v6, v10
    v.splat      v6, s23
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v6, v10
    v.splat      v6, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v9, v8, v12
    v.movi       v8, #1
    v.movi       v9, #0
    s.addi       s19, s22, #14336                // row 14
    v.extract    s28, v0, #14
    @p1 v.sel        v12, v8, v9
    v.splat      v8, s20
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s29
    v.movi       v9, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s28
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s24, #0]
    vf.fma       v12, v7, v10, v11
    v.movi       v7, #1
    v.movi       v10, #0
    s.addi       s24, s22, #15360                // row 15
    v.extract    s28, v0, #15
    @p1 v.sel        v0, v7, v10
    v.splat      v7, s11
    v.movi       v10, #0
    v.extract    s29, v0, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v0, s29
    v.splat      v7, s28
    v.cmp.ne     p2, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s26, #0]
    vf.fma       v10, v5, v9, v12
    v.movi       v5, #1
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s26, #12
    @p1 v.sel        v12, v5, v9
    s.movz       s28, #12
    v.extract    s29, v12, #0
    v.splat      v5, s29
    v.cmp.ne     p1, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s12, #0]
    vf.fma       v9, v4, v0, v10
    v.splat      v0, s1
    v.movi       v4, #1
    v.movi       v10, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v11, v4, v10
    v.extract    s12, v11, #0
    v.splat      v4, s12
    v.cmp.ne     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s19, #0]
    vf.fma       v4, v6, v5, v9
    v.splat      v5, s6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.lt     p2, v5, v2
    v.movi       v5, #0
    @p2 v.sel        v10, v6, v9
    s.addi       s12, s22, #1024                 // row 1
    v.extract    s19, v10, #0
    v.splat      v6, s19
    v.cmp.ne     p2, v6, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s24, #0]
    vf.fma       v6, v8, v0, v4
    v.splat      v0, s7
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v9, v4, v8
    s.addi       s19, s22, #2048                 // row 2
    v.extract    s24, v9, #0
    v.splat      v4, s24
    v.cmp.ne     p1, v4, v0
    vf.fma       v0, v7, v5, v6
    s.addi       s24, s22, #3072                 // row 3
    a.vwrite     a1, s27, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s26, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s26
    v.splat      v7, s9
    v.extract    s26, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s26
    v.extract    s26, v0, #1
    s.addi       s27, s22, #4096                 // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s26
    v.extract    s26, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s12, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v4, #1
    v.movi       v6, #0
    v.splat      v9, s10
    v.movi       v10, #0
    @p3 v.sel        v11, v4, v6
    v.cmp.lt     p2, v9, v2
    s.addi       s12, s22, #5120                 // row 5
    v.extract    s29, v11, #0
    v.splat      v4, s26
    v.splat      v6, s29
    v.extract    s26, v0, #3
    v.extract    s29, v0, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s26
    v.splat      v9, s29
    v.extract    s26, v0, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    s.addi       s19, s22, #6144                 // row 6
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    v.movi       v5, #0
    v.extract    s29, v12, #0
    v.splat      v7, s26
    v.splat      v8, s29
    v.extract    s26, v0, #6
    v.cmp.ne     p2, v8, v5
    v.splat      v5, s26
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v4, v10, v11
    v.movi       v4, #1
    v.movi       v10, #0
    s.addi       s24, s22, #7168                 // row 7
    v.extract    s26, v0, #7
    @p1 v.sel        v11, v4, v10
    v.splat      v4, s2
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v4, v10
    v.splat      v4, s26
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s27, #0]
    vf.fma       v11, v6, v8, v12
    v.movi       v6, #1
    v.movi       v8, #0
    s.addi       s26, s22, #8192                 // row 8
    v.extract    s27, v0, #8
    @p1 v.sel        v12, v6, v8
    v.splat      v6, s16
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v8, #0
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v9, v10, v11
    v.movi       v9, #1
    v.movi       v10, #0
    s.addi       s12, s22, #9216                 // row 9
    v.extract    s27, v0, #9
    @p1 v.sel        v11, v9, v10
    v.splat      v9, s15
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v9, v2
    v.splat      v9, s29
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.splat      v9, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v7, v8, v12
    v.movi       v7, #1
    v.movi       v8, #0
    s.addi       s19, s22, #10240                // row 10
    v.extract    s27, v0, #10
    @p1 v.sel        v12, v7, v8
    v.splat      v7, s17
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s29
    v.movi       v8, #0
    v.cmp.ne     p4, v7, v8
    v.splat      v7, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v5, v10, v11
    v.movi       v5, #1
    v.movi       v10, #0
    s.addi       s24, s22, #11264                // row 11
    v.extract    s27, v0, #11
    @p1 v.sel        v11, v5, v10
    v.splat      v5, s18
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s29
    v.movi       v10, #0
    v.cmp.ne     p3, v5, v10
    v.splat      v5, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v4, v8, v12
    v.movi       v4, #1
    v.movi       v8, #0
    s.addi       s26, s22, #12288                // row 12
    v.extract    s27, v0, #12
    @p1 v.sel        v12, v4, v8
    v.splat      v4, s25
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v8, #0
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v6, v10, v11
    v.movi       v6, #1
    v.movi       v10, #0
    s.addi       s12, s22, #13312                // row 13
    v.extract    s27, v0, #13
    @p1 v.sel        v11, v6, v10
    v.splat      v6, s23
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v6, v10
    v.splat      v6, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v9, v8, v12
    v.movi       v8, #1
    v.movi       v9, #0
    s.addi       s19, s22, #14336                // row 14
    v.extract    s27, v0, #14
    @p1 v.sel        v12, v8, v9
    v.splat      v8, s20
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s29
    v.movi       v9, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s27
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s24, #0]
    vf.fma       v12, v7, v10, v11
    v.movi       v7, #1
    v.movi       v10, #0
    s.addi       s24, s22, #15360                // row 15
    v.extract    s27, v0, #15
    @p1 v.sel        v0, v7, v10
    v.splat      v7, s11
    v.movi       v10, #0
    v.extract    s29, v0, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v0, s29
    v.splat      v7, s27
    v.cmp.ne     p2, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s26, #0]
    vf.fma       v10, v5, v9, v12
    v.movi       v5, #1
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s26, #13
    @p1 v.sel        v12, v5, v9
    s.movz       s27, #13
    v.extract    s29, v12, #0
    v.splat      v5, s29
    v.cmp.ne     p1, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s12, #0]
    vf.fma       v9, v4, v0, v10
    v.splat      v0, s1
    v.movi       v4, #1
    v.movi       v10, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v11, v4, v10
    v.extract    s12, v11, #0
    v.splat      v4, s12
    v.cmp.ne     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s19, #0]
    vf.fma       v4, v6, v5, v9
    v.splat      v5, s6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.lt     p2, v5, v2
    v.movi       v5, #0
    @p2 v.sel        v10, v6, v9
    s.addi       s12, s22, #1024                 // row 1
    v.extract    s19, v10, #0
    v.splat      v6, s19
    v.cmp.ne     p2, v6, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s24, #0]
    vf.fma       v6, v8, v0, v4
    v.splat      v0, s7
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v9, v4, v8
    s.addi       s19, s22, #2048                 // row 2
    v.extract    s24, v9, #0
    v.splat      v4, s24
    v.cmp.ne     p1, v4, v0
    vf.fma       v0, v7, v5, v6
    s.addi       s24, s22, #3072                 // row 3
    a.vwrite     a1, s28, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s26, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s26
    v.splat      v7, s9
    v.extract    s26, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s26
    v.extract    s26, v0, #1
    s.addi       s28, s22, #4096                 // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s26
    v.extract    s26, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s12, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v4, #1
    v.movi       v6, #0
    v.splat      v9, s10
    v.movi       v10, #0
    @p3 v.sel        v11, v4, v6
    v.cmp.lt     p2, v9, v2
    s.addi       s12, s22, #5120                 // row 5
    v.extract    s29, v11, #0
    v.splat      v4, s26
    v.splat      v6, s29
    v.extract    s26, v0, #3
    v.extract    s29, v0, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s26
    v.splat      v9, s29
    v.extract    s26, v0, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    s.addi       s19, s22, #6144                 // row 6
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    v.movi       v5, #0
    v.extract    s29, v12, #0
    v.splat      v7, s26
    v.splat      v8, s29
    v.extract    s26, v0, #6
    v.cmp.ne     p2, v8, v5
    v.splat      v5, s26
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v4, v10, v11
    v.movi       v4, #1
    v.movi       v10, #0
    s.addi       s24, s22, #7168                 // row 7
    v.extract    s26, v0, #7
    @p1 v.sel        v11, v4, v10
    v.splat      v4, s2
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v4, v10
    v.splat      v4, s26
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s28, #0]
    vf.fma       v11, v6, v8, v12
    v.movi       v6, #1
    v.movi       v8, #0
    s.addi       s26, s22, #8192                 // row 8
    v.extract    s28, v0, #8
    @p1 v.sel        v12, v6, v8
    v.splat      v6, s16
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v8, #0
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v9, v10, v11
    v.movi       v9, #1
    v.movi       v10, #0
    s.addi       s12, s22, #9216                 // row 9
    v.extract    s28, v0, #9
    @p1 v.sel        v11, v9, v10
    v.splat      v9, s15
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v9, v2
    v.splat      v9, s29
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.splat      v9, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v7, v8, v12
    v.movi       v7, #1
    v.movi       v8, #0
    s.addi       s19, s22, #10240                // row 10
    v.extract    s28, v0, #10
    @p1 v.sel        v12, v7, v8
    v.splat      v7, s17
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s29
    v.movi       v8, #0
    v.cmp.ne     p4, v7, v8
    v.splat      v7, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v5, v10, v11
    v.movi       v5, #1
    v.movi       v10, #0
    s.addi       s24, s22, #11264                // row 11
    v.extract    s28, v0, #11
    @p1 v.sel        v11, v5, v10
    v.splat      v5, s18
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s29
    v.movi       v10, #0
    v.cmp.ne     p3, v5, v10
    v.splat      v5, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v4, v8, v12
    v.movi       v4, #1
    v.movi       v8, #0
    s.addi       s26, s22, #12288                // row 12
    v.extract    s28, v0, #12
    @p1 v.sel        v12, v4, v8
    v.splat      v4, s25
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v8, #0
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s28
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v6, v10, v11
    v.movi       v6, #1
    v.movi       v10, #0
    s.addi       s12, s22, #13312                // row 13
    v.extract    s28, v0, #13
    @p1 v.sel        v11, v6, v10
    v.splat      v6, s23
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v6, v10
    v.splat      v6, s28
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v9, v8, v12
    v.movi       v8, #1
    v.movi       v9, #0
    s.addi       s19, s22, #14336                // row 14
    v.extract    s28, v0, #14
    @p1 v.sel        v12, v8, v9
    v.splat      v8, s20
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s29
    v.movi       v9, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s28
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s24, #0]
    vf.fma       v12, v7, v10, v11
    v.movi       v7, #1
    v.movi       v10, #0
    s.addi       s24, s22, #15360                // row 15
    v.extract    s28, v0, #15
    @p1 v.sel        v0, v7, v10
    v.splat      v7, s11
    v.movi       v10, #0
    v.extract    s29, v0, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v0, s29
    v.splat      v7, s28
    v.cmp.ne     p2, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s26, #0]
    vf.fma       v10, v5, v9, v12
    v.movi       v5, #1
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s26, #14
    @p1 v.sel        v12, v5, v9
    s.movz       s28, #14
    v.extract    s29, v12, #0
    v.splat      v5, s29
    v.cmp.ne     p1, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s12, #0]
    vf.fma       v9, v4, v0, v10
    v.splat      v0, s1
    v.movi       v4, #1
    v.movi       v10, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v11, v4, v10
    v.extract    s12, v11, #0
    v.splat      v4, s12
    v.cmp.ne     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s19, #0]
    vf.fma       v4, v6, v5, v9
    v.splat      v5, s6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.lt     p2, v5, v2
    v.movi       v5, #0
    @p2 v.sel        v10, v6, v9
    s.addi       s12, s22, #1024                 // row 1
    v.extract    s19, v10, #0
    v.splat      v6, s19
    v.cmp.ne     p2, v6, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s24, #0]
    vf.fma       v6, v8, v0, v4
    v.splat      v0, s7
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v9, v4, v8
    s.addi       s19, s22, #2048                 // row 2
    v.extract    s24, v9, #0
    v.splat      v4, s24
    v.cmp.ne     p1, v4, v0
    vf.fma       v0, v7, v5, v6
    s.addi       s24, s22, #3072                 // row 3
    a.vwrite     a1, s27, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s26, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s26
    v.splat      v7, s9
    v.extract    s26, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s26
    v.extract    s26, v0, #1
    s.addi       s27, s22, #4096                 // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s26
    v.extract    s26, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s12, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v4, #1
    v.movi       v6, #0
    v.splat      v9, s10
    v.movi       v10, #0
    @p3 v.sel        v11, v4, v6
    v.cmp.lt     p2, v9, v2
    s.addi       s12, s22, #5120                 // row 5
    v.extract    s29, v11, #0
    v.splat      v4, s26
    v.splat      v6, s29
    v.extract    s26, v0, #3
    v.extract    s29, v0, #4
    v.cmp.ne     p3, v6, v10
    v.splat      v6, s26
    v.splat      v9, s29
    v.extract    s26, v0, #5
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    s.addi       s19, s22, #6144                 // row 6
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    v.movi       v5, #0
    v.extract    s29, v12, #0
    v.splat      v7, s26
    v.splat      v8, s29
    v.extract    s26, v0, #6
    v.cmp.ne     p2, v8, v5
    v.splat      v5, s26
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v4, v10, v11
    v.movi       v4, #1
    v.movi       v10, #0
    s.addi       s24, s22, #7168                 // row 7
    v.extract    s26, v0, #7
    @p1 v.sel        v11, v4, v10
    v.splat      v4, s2
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v4, v10
    v.splat      v4, s26
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s27, #0]
    vf.fma       v11, v6, v8, v12
    v.movi       v6, #1
    v.movi       v8, #0
    s.addi       s26, s22, #8192                 // row 8
    v.extract    s27, v0, #8
    @p1 v.sel        v12, v6, v8
    v.splat      v6, s16
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v8, #0
    v.cmp.ne     p3, v6, v8
    v.splat      v6, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v9, v10, v11
    v.movi       v9, #1
    v.movi       v10, #0
    s.addi       s12, s22, #9216                 // row 9
    v.extract    s27, v0, #9
    @p1 v.sel        v11, v9, v10
    v.splat      v9, s15
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v9, v2
    v.splat      v9, s29
    v.movi       v10, #0
    v.cmp.ne     p2, v9, v10
    v.splat      v9, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v7, v8, v12
    v.movi       v7, #1
    v.movi       v8, #0
    s.addi       s19, s22, #10240                // row 10
    v.extract    s27, v0, #10
    @p1 v.sel        v12, v7, v8
    v.splat      v7, s17
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v7, s29
    v.movi       v8, #0
    v.cmp.ne     p4, v7, v8
    v.splat      v7, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s24, #0]
    vf.fma       v12, v5, v10, v11
    v.movi       v5, #1
    v.movi       v10, #0
    s.addi       s24, s22, #11264                // row 11
    v.extract    s27, v0, #11
    @p1 v.sel        v11, v5, v10
    v.splat      v5, s18
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v5, v2
    v.splat      v5, s29
    v.movi       v10, #0
    v.cmp.ne     p3, v5, v10
    v.splat      v5, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p2 v.ld.w       v10, [s26, #0]
    vf.fma       v11, v4, v8, v12
    v.movi       v4, #1
    v.movi       v8, #0
    s.addi       s26, s22, #12288                // row 12
    v.extract    s27, v0, #12
    @p1 v.sel        v12, v4, v8
    v.splat      v4, s25
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v4, v2
    v.splat      v4, s29
    v.movi       v8, #0
    v.cmp.ne     p2, v4, v8
    v.splat      v4, s27
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s12, #0]
    vf.fma       v12, v6, v10, v11
    v.movi       v6, #1
    v.movi       v10, #0
    s.addi       s12, s22, #13312                // row 13
    v.extract    s27, v0, #13
    @p1 v.sel        v11, v6, v10
    v.splat      v6, s23
    v.extract    s29, v11, #0
    v.cmp.lt     p1, v6, v2
    v.splat      v6, s29
    v.movi       v10, #0
    v.cmp.ne     p4, v6, v10
    v.splat      v6, s27
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.w       v10, [s19, #0]
    vf.fma       v11, v9, v8, v12
    v.movi       v8, #1
    v.movi       v9, #0
    s.addi       s19, s22, #14336                // row 14
    v.extract    s27, v0, #14
    @p1 v.sel        v12, v8, v9
    v.splat      v8, s20
    v.extract    s29, v12, #0
    v.cmp.lt     p1, v8, v2
    v.splat      v8, s29
    v.movi       v9, #0
    v.cmp.ne     p3, v8, v9
    v.splat      v8, s27
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v9, [s24, #0]
    vf.fma       v12, v7, v10, v11
    v.movi       v7, #1
    v.movi       v10, #0
    s.addi       s24, s22, #15360                // row 15
    v.extract    s27, v0, #15
    @p1 v.sel        v0, v7, v10
    v.splat      v7, s11
    v.movi       v10, #0
    v.extract    s29, v0, #0
    v.cmp.lt     p1, v7, v2
    v.splat      v0, s29
    v.splat      v7, s27
    v.cmp.ne     p2, v0, v10
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s26, #0]
    vf.fma       v10, v5, v9, v12
    v.movi       v5, #1
    v.movi       v9, #0
    v.movi       v11, #0
    s.movz       s26, #15
    @p1 v.sel        v12, v5, v9
    s.movz       s27, #15
    v.extract    s29, v12, #0
    v.splat      v5, s29
    v.cmp.ne     p1, v5, v11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v5, [s12, #0]
    vf.fma       v9, v4, v0, v10
    v.splat      v0, s1
    v.movi       v4, #1
    v.movi       v10, #0
    v.cmp.lt     p3, v0, v2
    v.movi       v0, #0
    @p3 v.sel        v11, v4, v10
    v.extract    s1, v11, #0
    v.splat      v4, s1
    v.cmp.ne     p3, v4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s19, #0]
    vf.fma       v4, v6, v5, v9
    v.splat      v5, s6
    v.movi       v6, #1
    v.movi       v9, #0
    v.cmp.lt     p2, v5, v2
    v.movi       v5, #0
    @p2 v.sel        v10, v6, v9
    s.addi       s1, s22, #1024                  // row 1
    v.extract    s6, v10, #0
    v.splat      v6, s6
    v.cmp.ne     p2, v6, v5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s24, #0]
    vf.fma       v6, v8, v0, v4
    v.splat      v0, s7
    v.movi       v4, #1
    v.movi       v8, #0
    v.cmp.lt     p1, v0, v2
    v.movi       v0, #0
    @p1 v.sel        v9, v4, v8
    s.addi       s6, s22, #2048                  // row 2
    v.extract    s7, v9, #0
    v.splat      v4, s7
    v.cmp.ne     p1, v4, v0
    vf.fma       v0, v7, v5, v6
    s.addi       s7, s22, #3072                  // row 3
    a.vwrite     a1, s28, v0
    a.vread      v0, a0, s26
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s22, #0]
    v.splat      v5, s5
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.lt     p3, v5, v2
    v.extract    s5, v0, #0
    @p3 v.sel        v5, v6, v7
    v.splat      v6, s5
    v.splat      v7, s9
    v.extract    s5, v5, #0
    v.movi       v5, #0
    v.cmp.lt     p3, v7, v2
    v.splat      v7, s5
    v.extract    s5, v0, #1
    s.addi       s9, s22, #4096                  // row 4
    v.cmp.ne     p4, v7, v5
    v.splat      v5, s5
    v.extract    s5, v0, #2
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s1, #0]
    vf.fma       v8, v6, v4, v1
    v.movi       v1, #1
    v.movi       v4, #0
    v.splat      v6, s10
    v.movi       v9, #0
    @p3 v.sel        v10, v1, v4
    v.cmp.lt     p2, v6, v2
    s.addi       s1, s22, #5120                  // row 5
    v.extract    s10, v10, #0
    v.splat      v1, s5
    v.splat      v4, s10
    v.extract    s5, v0, #3
    v.extract    s10, v0, #4
    v.cmp.ne     p3, v4, v9
    v.splat      v4, s5
    v.splat      v6, s10
    v.extract    s5, v0, #5
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v9, [s6, #0]
    vf.fma       v10, v5, v7, v8
    v.movi       v5, #1
    v.movi       v7, #0
    v.splat      v8, s13
    v.movi       v11, #0
    @p2 v.sel        v12, v5, v7
    v.cmp.lt     p1, v8, v2
    s.addi       s6, s22, #6144                  // row 6
    v.extract    s10, v12, #0
    v.splat      v5, s5
    v.splat      v7, s10
    v.extract    s5, v0, #6
    v.cmp.ne     p2, v7, v11
    v.splat      v7, s5
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s7, #0]
    vf.fma       v11, v1, v9, v10
    v.movi       v1, #1
    v.movi       v9, #0
    v.splat      v10, s2
    s.addi       s2, s22, #7168                  // row 7
    @p1 v.sel        v12, v1, v9
    v.cmp.lt     p1, v10, v2
    v.movi       v1, #0
    v.extract    s5, v12, #0
    v.extract    s7, v0, #7
    v.splat      v9, s5
    v.splat      v10, s7
    v.cmp.ne     p4, v9, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s9, #0]
    vf.fma       v9, v4, v8, v11
    v.movi       v4, #1
    v.movi       v8, #0
    v.splat      v11, s16
    s.addi       s5, s22, #8192                  // row 8
    @p1 v.sel        v12, v4, v8
    v.cmp.lt     p1, v11, v2
    v.movi       v4, #0
    v.extract    s7, v12, #0
    v.extract    s9, v0, #8
    v.splat      v8, s7
    v.splat      v11, s9
    v.cmp.ne     p3, v8, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v4, [s1, #0]
    vf.fma       v8, v6, v1, v9
    v.movi       v1, #1
    v.movi       v6, #0
    v.splat      v9, s15
    s.addi       s1, s22, #9216                  // row 9
    @p1 v.sel        v12, v1, v6
    v.cmp.lt     p1, v9, v2
    v.movi       v1, #0
    v.extract    s7, v12, #0
    v.extract    s9, v0, #9
    v.splat      v6, s7
    v.splat      v9, s9
    v.cmp.ne     p2, v6, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s6, #0]
    vf.fma       v6, v5, v4, v8
    v.movi       v4, #1
    v.movi       v5, #0
    v.splat      v8, s17
    s.addi       s6, s22, #10240                 // row 10
    @p1 v.sel        v12, v4, v5
    v.cmp.lt     p1, v8, v2
    v.movi       v4, #0
    v.extract    s7, v12, #0
    v.extract    s9, v0, #10
    v.splat      v5, s7
    v.splat      v8, s9
    v.cmp.ne     p4, v5, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s2, #0]
    vf.fma       v5, v7, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.splat      v7, s18
    s.addi       s2, s22, #11264                 // row 11
    @p1 v.sel        v12, v1, v6
    v.cmp.lt     p1, v7, v2
    v.movi       v1, #0
    v.extract    s7, v12, #0
    v.extract    s9, v0, #11
    v.splat      v6, s7
    v.splat      v7, s9
    v.cmp.ne     p3, v6, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v1, [s5, #0]
    vf.fma       v6, v10, v4, v5
    v.movi       v4, #1
    v.movi       v5, #0
    v.splat      v10, s25
    s.addi       s5, s22, #12288                 // row 12
    @p1 v.sel        v12, v4, v5
    v.cmp.lt     p1, v10, v2
    v.movi       v4, #0
    v.extract    s7, v12, #0
    v.extract    s9, v0, #12
    v.splat      v5, s7
    v.splat      v10, s9
    v.cmp.ne     p2, v5, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v4, [s1, #0]
    vf.fma       v5, v11, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.splat      v11, s23
    s.addi       s1, s22, #13312                 // row 13
    @p1 v.sel        v12, v1, v6
    v.cmp.lt     p1, v11, v2
    v.movi       v1, #0
    v.extract    s7, v12, #0
    v.extract    s9, v0, #13
    v.splat      v6, s7
    v.splat      v11, s9
    v.cmp.ne     p4, v6, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v1, [s6, #0]
    vf.fma       v6, v9, v4, v5
    v.movi       v4, #1
    v.movi       v5, #0
    v.splat      v9, s20
    s.addi       s6, s22, #14336                 // row 14
    @p1 v.sel        v12, v4, v5
    v.cmp.lt     p1, v9, v2
    v.movi       v4, #0
    v.extract    s7, v12, #0
    v.extract    s9, v0, #14
    v.splat      v5, s7
    v.splat      v9, s9
    v.cmp.ne     p3, v5, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v4, [s2, #0]
    vf.fma       v5, v8, v1, v6
    v.movi       v1, #1
    v.movi       v6, #0
    v.splat      v8, s11
    s.addi       s2, s22, #15360                 // row 15
    @p1 v.sel        v12, v1, v6
    v.cmp.lt     p1, v8, v2
    v.movi       v1, #0
    v.extract    s7, v12, #0
    v.extract    s9, v0, #15
    v.splat      v0, s7
    v.splat      v6, s9
    v.cmp.ne     p2, v0, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v0, [s5, #0]
    vf.fma       v1, v7, v4, v5
    v.movi       v4, #1
    v.movi       v5, #0
    v.movi       v7, #0
    v.movi       v8, #0
    @p1 v.sel        v12, v4, v5
    v.splat      v4, s14
    v.extract    s5, v12, #0
    v.splat      v5, s16
    v.cmp.lt     p1, v4, v5
    v.splat      v4, s5
    v.cmp.ne     p4, v4, v7
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v4, [s1, #0]
    vf.fma       v5, v10, v0, v1
    s.movz       s1, #0
    s.mul        s5, s14, s21
    s.add        s7, s1, s4                      // the tile origin
    s.muli       s1, s3, #4                      // a runtime tile origin, x4
    v.splat      v0, s7
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s9, #0
    s.muli       s10, s4, #1024                  // a runtime tile origin, x1024
    v.cmp.lt     p3, v0, v2
    s.muli       s4, s5, #4                      // a runtime tile origin, x4
    s.add        s5, s8, s1                      // the tile origin
    s.add        s1, s5, s10                     // the tile origin
    s.add        s5, s1, s4                      // the tile origin
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v0, [s6, #0]
    vf.fma       v1, v11, v4, v5
    v.movi       v4, #1
    v.movi       v5, #0
    s.movz       s1, #0
    s.movz       s4, #256
    @p3 v.sel        v7, v4, v5
    s.add        s6, s1, s3                      // the tile origin
    v.movi       v4, #0
    v.splat      v5, s6
    v.extract    s1, v7, #0
    v.splat      v7, s4
    v.splat      v10, s1
    v.add        v11, v3, v5
    v.cmp.ne     p2, v10, v4
    v.cmp.lt     p3, v11, v7
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v3, [s2, #0]
    vf.fma       v4, v9, v0, v1
    s.addi       s1, s7, #1
    v.movi       v0, #1
    v.splat      v1, s1
    v.movi       v5, #0
    p.and        p4, p2, p3
    v.cmp.lt     p2, v1, v2
    @p2 v.sel        v1, v0, v5
    p.and        p2, p4, p1
    s.movz       s1, #1
    v.extract    s2, v1, #0
    s.addi       s3, s5, #1024                   // row 1
    vf.fma       v0, v6, v3, v4
    v.splat      v1, s2
    a.vwrite     a1, s27, v0
    a.vread      v0, a1, s9
    s.addi       s2, s7, #2
    v.movi       v3, #0
    vf.add       v4, v0, v8
    v.splat      v0, s2
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p4, v0, v2
    @p2 v.st.w       [s5, #0], v4
    a.vread      v0, a1, s1
    v.cmp.ne     p2, v1, v3
    @p4 v.sel        v1, v5, v6
    vf.add       v3, v0, v8
    p.and        p4, p2, p3
    s.addi       s1, s7, #3
    p.and        p2, p4, p1
    s.movz       s2, #2
    v.extract    s4, v1, #0
    v.splat      v0, s1
    v.splat      v1, s4
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p4, v0, v2
    s.addi       s1, s7, #4
    @p4 v.sel        v0, v5, v6
    @p2 v.st.w       [s3, #0], v3
    a.vread      v3, a1, s2
    v.cmp.ne     p2, v1, v4
    p.and        p4, p2, p3
    vf.add       v1, v3, v8
    s.addi       s2, s5, #2048                   // row 2
    p.and        p2, p4, p1
    s.movz       s3, #3
    v.extract    s4, v0, #0
    v.splat      v0, s1
    v.splat      v3, s4
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p4, v0, v2
    s.addi       s1, s7, #5
    @p4 v.sel        v0, v5, v6
    v.cmp.ne     p4, v3, v4
    @p2 v.st.w       [s2, #0], v1
    a.vread      v1, a1, s3
    p.and        p2, p4, p3
    s.addi       s2, s5, #3072                   // row 3
    vf.add       v3, v1, v8
    p.and        p4, p2, p1
    s.movz       s3, #4
    v.extract    s4, v0, #0
    v.splat      v0, s1
    v.splat      v1, s4
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p2, v0, v2
    s.addi       s1, s7, #6
    @p2 v.sel        v0, v5, v6
    v.cmp.ne     p2, v1, v4
    p.and        p5, p2, p3
    @p4 v.st.w       [s2, #0], v3
    a.vread      v1, a1, s3
    s.addi       s2, s5, #4096                   // row 4
    p.and        p2, p5, p1
    vf.add       v3, v1, v8
    s.movz       s3, #5
    v.extract    s4, v0, #0
    v.splat      v0, s1
    v.splat      v1, s4
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p4, v0, v2
    s.addi       s1, s7, #7
    @p4 v.sel        v0, v5, v6
    v.cmp.ne     p4, v1, v4
    p.and        p5, p4, p3
    s.addi       s4, s5, #5120                   // row 5
    @p2 v.st.w       [s2, #0], v3
    a.vread      v1, a1, s3
    p.and        p2, p5, p1
    s.movz       s2, #6
    vf.add       v3, v1, v8
    v.extract    s3, v0, #0
    v.splat      v0, s1
    v.splat      v1, s3
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p4, v0, v2
    s.addi       s1, s7, #8
    @p4 v.sel        v0, v5, v6
    v.cmp.ne     p4, v1, v4
    p.and        p5, p4, p3
    s.addi       s3, s5, #6144                   // row 6
    p.and        p4, p5, p1
    @p2 v.st.w       [s4, #0], v3
    a.vread      v1, a1, s2
    s.movz       s2, #7
    v.extract    s4, v0, #0
    vf.add       v0, v1, v8
    v.splat      v1, s1
    v.splat      v3, s4
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p2, v1, v2
    s.addi       s1, s7, #9
    @p2 v.sel        v1, v5, v6
    v.cmp.ne     p2, v3, v4
    p.and        p5, p2, p3
    s.addi       s4, s5, #7168                   // row 7
    p.and        p2, p5, p1
    s.movz       s6, #8
    @p4 v.st.w       [s3, #0], v0
    a.vread      v0, a1, s2
    v.extract    s2, v1, #0
    v.splat      v1, s1
    vf.add       v3, v0, v8
    v.splat      v0, s2
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p4, v1, v2
    s.addi       s1, s7, #10
    @p4 v.sel        v1, v5, v6
    v.cmp.ne     p4, v0, v4
    p.and        p5, p4, p3
    s.addi       s2, s5, #8192                   // row 8
    p.and        p4, p5, p1
    s.movz       s3, #9
    v.extract    s8, v1, #0
    @p2 v.st.w       [s4, #0], v3
    a.vread      v0, a1, s6
    v.splat      v1, s1
    v.splat      v3, s8
    vf.add       v4, v0, v8
    v.movi       v0, #0
    v.movi       v5, #1
    v.movi       v6, #0
    v.cmp.lt     p2, v1, v2
    s.addi       s1, s7, #11
    @p2 v.sel        v1, v5, v6
    v.cmp.ne     p2, v3, v0
    p.and        p5, p2, p3
    s.addi       s4, s5, #9216                   // row 9
    p.and        p2, p5, p1
    s.movz       s6, #10
    v.extract    s8, v1, #0
    v.splat      v0, s1
    @p4 v.st.w       [s2, #0], v4
    a.vread      v1, a1, s3
    v.splat      v3, s8
    v.movi       v4, #0
    vf.add       v5, v1, v8
    v.movi       v1, #1
    v.movi       v6, #0
    v.cmp.lt     p4, v0, v2
    s.addi       s1, s7, #12
    @p4 v.sel        v0, v1, v6
    v.cmp.ne     p4, v3, v4
    p.and        p5, p4, p3
    s.addi       s2, s5, #10240                  // row 10
    p.and        p4, p5, p1
    s.movz       s3, #11
    v.extract    s8, v0, #0
    v.splat      v0, s1
    v.splat      v1, s8
    @p2 v.st.w       [s4, #0], v5
    a.vread      v3, a1, s6
    v.movi       v4, #0
    v.movi       v5, #1
    vf.add       v6, v3, v8
    v.movi       v3, #0
    v.cmp.lt     p2, v0, v2
    s.addi       s1, s7, #13
    @p2 v.sel        v0, v5, v3
    v.cmp.ne     p2, v1, v4
    p.and        p5, p2, p3
    s.addi       s4, s5, #11264                  // row 11
    p.and        p2, p5, p1
    s.movz       s6, #12
    v.extract    s8, v0, #0
    v.splat      v0, s1
    v.splat      v1, s8
    v.movi       v3, #0
    @p4 v.st.w       [s2, #0], v6
    a.vread      v4, a1, s3
    v.movi       v5, #1
    v.movi       v6, #0
    vf.add       v7, v4, v8
    v.cmp.lt     p4, v0, v2
    @p4 v.sel        v0, v5, v6
    v.cmp.ne     p4, v1, v3
    p.and        p5, p4, p3
    s.addi       s1, s7, #14
    s.addi       s2, s5, #12288                  // row 12
    p.and        p4, p5, p1
    s.movz       s3, #13
    v.extract    s8, v0, #0
    v.splat      v0, s1
    v.splat      v1, s8
    v.movi       v3, #0
    v.movi       v4, #1
    @p2 v.st.w       [s4, #0], v7
    a.vread      v5, a1, s6
    v.movi       v6, #0
    v.cmp.lt     p2, v0, v2
    vf.add       v0, v5, v8
    @p2 v.sel        v5, v4, v6
    v.cmp.ne     p2, v1, v3
    p.and        p5, p2, p3
    s.addi       s1, s7, #15
    s.addi       s4, s5, #13312                  // row 13
    p.and        p2, p5, p1
    s.movz       s6, #14
    v.extract    s7, v5, #0
    v.splat      v1, s1
    v.splat      v3, s7
    v.movi       v4, #0
    v.movi       v5, #1
    v.movi       v6, #0
    @p4 v.st.w       [s2, #0], v0
    a.vread      v0, a1, s3
    v.cmp.lt     p4, v1, v2
    @p4 v.sel        v1, v5, v6
    vf.add       v2, v0, v8
    v.cmp.ne     p4, v3, v4
    p.and        p5, p4, p3
    s.addi       s1, s5, #14336                  // row 14
    p.and        p4, p5, p1
    s.movz       s2, #15
    v.extract    s3, v1, #0
    v.movi       v0, #0
    v.splat      v1, s3
    s.addi       s3, s5, #15360                  // row 15
    @p2 v.st.w       [s4, #0], v2
    a.vread      v2, a1, s6
    v.cmp.ne     p2, v1, v0
    p.and        p5, p2, p3
    vf.add       v0, v2, v8
    p.and        p2, p5, p1
    @p4 v.st.w       [s1, #0], v0
    a.vread      v0, a1, s2
    vf.add       v1, v0, v8
    @p2 v.st.w       [s3, #0], v1
__rctx_next:
    exit
