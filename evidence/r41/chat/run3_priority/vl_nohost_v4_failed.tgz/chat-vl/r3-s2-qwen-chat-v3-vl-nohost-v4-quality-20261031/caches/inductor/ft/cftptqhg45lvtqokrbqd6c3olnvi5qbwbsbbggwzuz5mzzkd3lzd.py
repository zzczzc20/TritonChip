
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': '*bf16', 'in_ptr6': '*fp32', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 33280}, 'backend_hash': '06F9C51A4A56EF2956D7783F75B6D9880DB0D286B4DCBCF11EA964EF2FA77558', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_arange_cat_index_copy_mean_mul_pow_rsqrt_select_slice_transpose_unsqueeze_view_6(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x2 = xindex // 1024
    x0 = (xindex % 128)
    x3 = xindex
    x4 = xindex // 128
    x1 = ((xindex // 128) % 8)
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp9 = tl.load(in_ptr1 + (x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp10 = tl.load(in_ptr2 + (x3), None).to(tl.float32)
    tmp12 = tl.load(in_ptr3 + (x4), None, eviction_policy='evict_last')
    tmp36 = tl.load(in_ptr4 + (64*x2 + ((x0 % 64))), None, eviction_policy='evict_last')
    tmp41 = tl.load(in_ptr5 + (x0 + 128*x2 + 1024*x1), None).to(tl.float32)
    tmp43 = tl.load(in_ptr6 + (64*x2 + ((x0 % 64))), None, eviction_policy='evict_last')
    tmp2 = (x2).to(tl.int32)
    tmp3 = tmp2 + tmp1
    tmp4 = (tl.full([XBLOCK], 256, tl.int32)).to(tl.int32)
    tmp5 = tmp3 + tmp4
    tmp6 = tmp3 < 0
    tmp7 = tl.where(tmp6, tmp5, tmp3)
    tl.device_assert((0 <= tmp7) & (tmp7 < 256), "index out of bounds: 0 <= tmp7 < 256")
    tmp11 = tmp10.to(tl.float32)
    tmp13 = tl.full([1], 128.0, tl.float32)
    tmp14 = (tmp12 / tmp13)
    tmp15 = tl.full([1], 1e-06, tl.float32)
    tmp16 = tmp14 + tmp15
    tmp17 = libdevice.rsqrt(tmp16)
    tmp18 = tmp11 * tmp17
    tmp19 = tmp18.to(tl.float32)
    tmp20 = tmp9 * tmp19
    tmp21 = tl.full([1], 0, tl.int32)
    tmp22 = tmp21 == tmp21
    tmp23 = ((x3 % 64)).to(tl.int64)
    tmp24 = (tmp23).to(tl.int64)
    tmp25 = tl.full([1], 2, tl.int64)
    tmp26 = tmp24 >= tmp25
    tmp27 = tl.full([1], 60, tl.int64)
    tmp28 = tmp24 < tmp27
    tmp29 = ((((-2) + ((x0 % 64))) % 3)).to(tl.int64)
    tmp30 = (tmp29).to(tl.int64)
    tmp31 = tl.full([1], 0, tl.int64)
    tmp32 = tmp30 == tmp31
    tmp33 = tmp26 & tmp28
    tmp34 = tmp33 & tmp32
    tmp35 = tl.load(in_ptr4 + (1026 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 64)),  3)) + 64*x2), tmp34, eviction_policy='evict_last', other=0.0)
    tmp37 = tl.where(tmp34, tmp35, tmp36)
    tmp38 = tl.where(tmp22, tmp37, tmp36)
    tmp39 = tmp38.to(tl.float32)
    tmp40 = tmp20 * tmp39
    tmp42 = tl.load(in_ptr6 + (1026 + 3*(triton_helpers.div_floor_integer((-2) + ((x0 % 64)),  3)) + 64*x2), tmp34, eviction_policy='evict_last', other=0.0)
    tmp44 = tl.where(tmp34, tmp42, tmp43)
    tmp45 = tl.where(tmp22, tmp44, tmp43)
    tmp46 = tmp45.to(tl.float32)
    tmp47 = tmp41 * tmp46
    tmp48 = tmp40 + tmp47
    tl.store(out_ptr0 + (x0 + 128*tmp7 + 32768*x1), tmp48, None)
