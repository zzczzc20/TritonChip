    s.rdspecial  s1, arg_base
    s.movz       s2, #15
    s.ld.sw      s3, [s1, #40]                   // N: i32 at arg_base+40
    s.rdspecial  s4, pid.x
    s.rdspecial  s5, pid.y
    s.movz       s6, #16
    s.ld.sw      s7, [s1, #32]                   // M: i32 at arg_base+32
    s.add        s8, s7, s2
    s.ld.d       s2, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.movz       s9, #0
    s.ld.d       s10, [s1, #8]                   // B: device_ptr64 at arg_base+8
    s.cmp.lt     s11, s8, s9
    s.ld.d       s12, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.sub        s13, s9, s11
    s.ld.d       s11, [s1, #24]                  // Bs: device_ptr64 at arg_base+24
    s.xor        s14, s8, s13
    s.cmp.lt     s8, s6, s9
    s.sub        s15, s9, s8
    s.ld.sw      s8, [s1, #48]                   // K: i32 at arg_base+48
    s.sub        s16, s14, s13
    s.ld.sw      s14, [s1, #56]                  // stride_am: i32 at arg_base+56
    s.xor        s17, s6, s15
    s.ld.sw      s18, [s1, #64]                  // stride_bn: i32 at arg_base+64
    s.sub        s19, s17, s15
    s.ld.sw      s17, [s1, #72]                  // stride_cm: i32 at arg_base+72
    s.lshri      s19, s16, #4
    s.ld.sw      s20, [s1, #80]                  // stride_bs_n: i32 at arg_base+80
    s.movz       s1, #127
    s.movz       s21, #128
    s.add        s22, s3, s1
    s.cmp.lt     s23, s21, s9
    s.cmp.lt     s24, s22, s9
    s.sub        s25, s9, s23
    s.sub        s23, s9, s24
    s.muli       s24, s19, #16
    s.xor        s26, s22, s23
    s.xor        s22, s13, s15
    s.sub        s13, s26, s23
    s.xor        s15, s19, s22
    s.lshri      s19, s13, #7
    s.xor        s26, s21, s25
    s.sub        s27, s16, s24
    s.xor        s16, s23, s25
    s.muli       s23, s19, #128
    s.sub        s24, s15, s22
    s.xor        s15, s19, s16
    s.movz       s19, #8
    s.sub        s22, s15, s16
    s.sub        s15, s26, s25
    s.mul        s15, s4, s22
    s.mul        s4, s22, s19
    s.sub        s16, s13, s23
    s.movz       s13, #1
    s.addi       s16, s9, #0
    s.add        s22, s15, s5
    s.cmp.lt     s5, s4, s9
    s.cmp.lt     s15, s22, s9
    s.sub        s23, s9, s5
    s.sub        s5, s9, s15
    s.xor        s15, s4, s23
    s.xor        s25, s22, s5
    s.sub        s26, s15, s23
    s.sub        s15, s25, s5
    s.cmp.eq     s25, s26, s13
    s.addi       s27, s9, #0
    s.mov        s16, s15
    br.nz        s25, sdiv_done_1
    s.movz       s9, #0
    s.mov        s16, s9
    s.movz       s9, #31
    s.addi       s25, s9, #0
sdiv_2:
    s.lshr       s9, s15, s25
    s.andi       s28, s9, #1
    s.shli       s9, s27, #1
    s.or         s29, s9, s28
    s.movz       s9, #0
    s.cmp.geu    s28, s29, s26
    s.sub        s30, s9, s28
    s.and        s28, s26, s30
    s.sub        s31, s29, s28
    s.mov        s27, s31
    s.shl        s28, s13, s25
    s.and        s29, s28, s30
    s.or         s28, s16, s29
    s.mov        s16, s28
    s.subi       s28, s25, #1
    s.mov        s25, s28
    s.cmp.ge     s28, s25, s9
    br.nz        s28, sdiv_2
sdiv_done_1:
    s.xor        s9, s5, s23
    s.movz       s5, #0
    s.xor        s15, s16, s9
    s.cmp.lt     s16, s4, s5
    s.sub        s23, s15, s9
    s.cmp.lt     s9, s22, s5
    s.sub        s15, s5, s16
    s.mul        s16, s23, s19
    s.sub        s23, s5, s9
    s.xor        s9, s4, s15
    s.xor        s4, s22, s23
    s.sub        s22, s9, s15
    s.sub        s9, s24, s16
    s.sub        s15, s4, s23
    s.addi       s4, s5, #0
    s.cmp.eq     s24, s22, s13
    s.min.s      s13, s9, s19
    s.addi       s9, s5, #0
    s.mov        s4, s15
    br.nz        s24, sdiv_done_3
    s.movz       s19, #0
    s.mov        s4, s19
    s.movz       s19, #31
    s.addi       s24, s19, #0
sdiv_4:
    s.lshr       s19, s15, s24
    s.andi       s25, s19, #1
    s.shli       s19, s9, #1
    s.or         s26, s19, s25
    s.cmp.geu    s19, s26, s22
    s.sub        s25, s5, s19
    s.and        s19, s22, s25
    s.sub        s27, s26, s19
    s.mov        s9, s27
    s.movz       s19, #1
    s.shl        s26, s19, s24
    s.and        s19, s26, s25
    s.or         s25, s4, s19
    s.mov        s4, s25
    s.subi       s19, s24, #1
    s.mov        s24, s19
    s.cmp.ge     s19, s24, s5
    br.nz        s19, sdiv_4
sdiv_done_3:
    s.xor        s4, s9, s23
    s.cmp.lt     s9, s13, s5
    s.sub        s15, s4, s23
    s.sub        s4, s5, s9
    s.cmp.lt     s9, s15, s5
    s.xor        s19, s13, s4
    s.sub        s22, s5, s9
    s.sub        s9, s19, s4
    s.xor        s4, s15, s22
    s.movz       s19, #1
    s.sub        s23, s4, s22
    s.addi       s4, s5, #0
    s.cmp.eq     s24, s9, s19
    s.addi       s25, s5, #0
    s.mov        s4, s23
    br.nz        s24, sdiv_done_5
    s.movz       s5, #0
    s.mov        s4, s5
    s.movz       s5, #31
    s.addi       s24, s5, #0
sdiv_6:
    s.lshr       s5, s23, s24
    s.andi       s26, s5, #1
    s.shli       s5, s25, #1
    s.or         s27, s5, s26
    s.movz       s5, #0
    s.cmp.geu    s26, s27, s9
    s.sub        s28, s5, s26
    s.and        s26, s9, s28
    s.sub        s29, s27, s26
    s.mov        s25, s29
    s.shl        s26, s19, s24
    s.and        s27, s26, s28
    s.or         s26, s4, s27
    s.mov        s4, s26
    s.subi       s26, s24, #1
    s.mov        s24, s26
    s.cmp.ge     s26, s24, s5
    br.nz        s26, sdiv_6
sdiv_done_5:
    s.movz       s4, #0
    s.xor        s5, s25, s22
    s.cmp.lt     s9, s13, s4
    s.cmp.lt     s23, s15, s4
    s.sub        s24, s4, s9
    s.sub        s9, s4, s23
    s.xor        s23, s13, s24
    s.xor        s13, s15, s9
    s.sub        s15, s23, s24
    s.sub        s23, s5, s22
    s.sub        s5, s13, s9
    s.addi       s13, s4, #0
    s.cmp.eq     s22, s15, s19
    s.add        s19, s16, s23
    s.addi       s16, s4, #0
    s.mov        s13, s5
    br.nz        s22, sdiv_done_7
    s.movz       s22, #0
    s.mov        s13, s22
    s.movz       s22, #31
    s.addi       s23, s22, #0
sdiv_8:
    s.lshr       s22, s5, s23
    s.andi       s25, s22, #1
    s.shli       s22, s16, #1
    s.or         s26, s22, s25
    s.cmp.geu    s22, s26, s15
    s.sub        s25, s4, s22
    s.and        s22, s15, s25
    s.sub        s27, s26, s22
    s.mov        s16, s27
    s.movz       s22, #1
    s.shl        s26, s22, s23
    s.and        s22, s26, s25
    s.or         s25, s13, s22
    s.mov        s13, s25
    s.subi       s22, s23, #1
    s.mov        s23, s22
    s.cmp.ge     s22, s23, s4
    br.nz        s22, sdiv_8
sdiv_done_7:
    s.mul        s4, s19, s6
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s7
    v.movi       v2, #0
    s.xor        s5, s9, s24
    v.splat      v3, s4
    v.sub        v4, v2, v1
    s.xor        s9, s13, s5
    v.add        v5, v3, v0
    v.cmp.lt     p1, v1, v2
    s.sub        s13, s9, s5
    v.sub        v0, v2, v5
    v.cmp.lt     p2, v5, v2
    v.movi       v3, #1
    @p2 v.sel        v6, v0, v5
    @p1 v.sel        v0, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s5, #31
idiv_9:
    v.splat      v5, s5
    v.shl        v7, v4, v3
    v.cmp.lt     p1, v4, v2
    v.lshr       v8, v6, v5
    v.shl        v9, v3, v5
    s.subi       s9, s5, #1
    v.and        v5, v8, v3
    v.or         v8, v7, v5
    v.cmp.geu    p3, v8, v0
    p.or         p4, p1, p3
    v.sub        v5, v8, v0
    @p4 v.sel        v7, v9, v2
    @p4 v.sel        v9, v5, v8
    v.or         v5, v1, v7
    v.mov        v4, v9
    v.mov        v1, v5
    s.mov        s5, s9
    s.movz       s9, #0
    s.cmp.ge     s15, s5, s9
    br.nz        s15, idiv_9
    s.mul        s5, s13, s21
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.movi       v3, #32
    v.movi       v5, #48
    v.iota       v6                              // arange(0, VLEN)
    v.movi       v7, #64
    v.movi       v8, #80
    v.movi       v9, #96
    v.sub        v10, v2, v4
    v.add        v2, v0, v1
    v.add        v1, v0, v3
    v.add        v3, v0, v5
    v.add        v5, v6, v7
    v.add        v7, v6, v8
    v.add        v8, v6, v9
    @p2 v.sel        v6, v10, v4
    v.splat      v4, s5
    v.iota       v9                              // arange(0, VLEN)
    v.movi       v10, #112
    v.add        v11, v4, v0
    v.splat      v0, s3
    v.movi       v12, #0
    v.add        v13, v9, v10
    v.add        v9, v4, v2
    v.sub        v2, v12, v11
    v.sub        v10, v12, v0
    v.cmp.lt     p1, v11, v12
    v.cmp.lt     p2, v0, v12
    v.add        v14, v4, v1
    v.add        v1, v4, v3
    v.add        v3, v4, v5
    v.add        v5, v4, v7
    v.add        v7, v4, v8
    v.add        v8, v4, v13
    v.movi       v4, #1
    @p1 v.sel        v13, v2, v11
    @p2 v.sel        v2, v10, v0
    v.movi       v10, #0
    v.movi       v11, #0
    s.movz       s9, #31
idiv_10:
    v.splat      v15, s9
    v.shl        v16, v11, v4
    v.cmp.lt     p2, v11, v12
    v.lshr       v17, v13, v15
    v.shl        v18, v4, v15
    s.subi       s13, s9, #1
    v.and        v15, v17, v4
    v.or         v17, v16, v15
    v.cmp.geu    p3, v17, v2
    p.or         p4, p2, p3
    v.sub        v15, v17, v2
    @p4 v.sel        v16, v18, v12
    @p4 v.sel        v18, v15, v17
    v.or         v15, v10, v16
    v.mov        v11, v18
    v.mov        v10, v15
    s.mov        s9, s13
    s.movz       s13, #0
    s.cmp.ge     s15, s9, s13
    br.nz        s15, idiv_10
    v.movi       v2, #0
    v.sub        v4, v12, v11
    v.movi       v10, #1
    v.sub        v12, v2, v9
    v.sub        v13, v2, v0
    v.cmp.lt     p2, v9, v2
    @p1 v.sel        v15, v4, v11
    v.cmp.lt     p1, v0, v2
    @p2 v.sel        v4, v12, v9
    @p1 v.sel        v9, v13, v0
    v.movi       v11, #0
    v.movi       v12, #0
    s.movz       s9, #31
idiv_11:
    v.splat      v13, s9
    v.shl        v16, v12, v10
    v.cmp.lt     p1, v12, v2
    v.lshr       v17, v4, v13
    v.shl        v18, v10, v13
    s.subi       s15, s9, #1
    v.and        v13, v17, v10
    v.or         v17, v16, v13
    v.cmp.geu    p3, v17, v9
    p.or         p4, p1, p3
    v.sub        v13, v17, v9
    @p4 v.sel        v16, v18, v2
    @p4 v.sel        v18, v13, v17
    v.or         v13, v11, v16
    v.mov        v12, v18
    v.mov        v11, v13
    s.mov        s9, s15
    s.cmp.ge     s15, s9, s13
    br.nz        s15, idiv_11
    v.movi       v4, #0
    v.sub        v9, v2, v12
    v.movi       v2, #1
    v.sub        v10, v4, v14
    v.sub        v11, v4, v0
    v.cmp.lt     p1, v14, v4
    @p2 v.sel        v13, v9, v12
    v.cmp.lt     p2, v0, v4
    @p1 v.sel        v9, v10, v14
    @p2 v.sel        v10, v11, v0
    v.movi       v11, #0
    v.movi       v12, #0
    s.movz       s9, #31
idiv_12:
    v.splat      v14, s9
    v.shl        v16, v12, v2
    v.cmp.lt     p2, v12, v4
    v.lshr       v17, v9, v14
    v.shl        v18, v2, v14
    s.subi       s13, s9, #1
    v.and        v14, v17, v2
    v.or         v17, v16, v14
    v.cmp.geu    p3, v17, v10
    p.or         p4, p2, p3
    v.sub        v14, v17, v10
    @p4 v.sel        v16, v18, v4
    @p4 v.sel        v18, v14, v17
    v.or         v14, v11, v16
    v.mov        v12, v18
    v.mov        v11, v14
    s.mov        s9, s13
    s.movz       s13, #0
    s.cmp.ge     s15, s9, s13
    br.nz        s15, idiv_12
    v.movi       v2, #0
    v.sub        v9, v4, v12
    v.movi       v4, #1
    v.sub        v10, v2, v1
    v.sub        v11, v2, v0
    v.cmp.lt     p2, v1, v2
    @p1 v.sel        v14, v9, v12
    v.cmp.lt     p1, v0, v2
    @p2 v.sel        v9, v10, v1
    @p1 v.sel        v1, v11, v0
    v.movi       v10, #0
    v.movi       v11, #0
    s.movz       s9, #31
idiv_13:
    v.splat      v12, s9
    v.shl        v16, v11, v4
    v.cmp.lt     p1, v11, v2
    v.lshr       v17, v9, v12
    v.shl        v18, v4, v12
    s.subi       s15, s9, #1
    v.and        v12, v17, v4
    v.or         v17, v16, v12
    v.cmp.geu    p3, v17, v1
    p.or         p4, p1, p3
    v.sub        v12, v17, v1
    @p4 v.sel        v16, v18, v2
    @p4 v.sel        v18, v12, v17
    v.or         v12, v10, v16
    v.mov        v11, v18
    v.mov        v10, v12
    s.mov        s9, s15
    s.cmp.ge     s15, s9, s13
    br.nz        s15, idiv_13
    v.movi       v1, #0
    v.sub        v4, v2, v11
    v.movi       v2, #1
    v.sub        v9, v1, v3
    v.sub        v10, v1, v0
    v.cmp.lt     p1, v3, v1
    @p2 v.sel        v12, v4, v11
    v.cmp.lt     p2, v0, v1
    @p1 v.sel        v4, v9, v3
    @p2 v.sel        v3, v10, v0
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s9, #31
idiv_14:
    v.splat      v11, s9
    v.shl        v16, v10, v2
    v.cmp.lt     p2, v10, v1
    v.lshr       v17, v4, v11
    v.shl        v18, v2, v11
    s.subi       s13, s9, #1
    v.and        v11, v17, v2
    v.or         v17, v16, v11
    v.cmp.geu    p3, v17, v3
    p.or         p4, p2, p3
    v.sub        v11, v17, v3
    @p4 v.sel        v16, v18, v1
    @p4 v.sel        v18, v11, v17
    v.or         v11, v9, v16
    v.mov        v10, v18
    v.mov        v9, v11
    s.mov        s9, s13
    s.movz       s13, #0
    s.cmp.ge     s15, s9, s13
    br.nz        s15, idiv_14
    v.movi       v2, #0
    v.sub        v3, v1, v10
    v.movi       v1, #1
    v.sub        v4, v2, v5
    v.sub        v9, v2, v0
    v.cmp.lt     p2, v5, v2
    @p1 v.sel        v11, v3, v10
    v.cmp.lt     p1, v0, v2
    @p2 v.sel        v3, v4, v5
    @p1 v.sel        v4, v9, v0
    v.movi       v5, #0
    v.movi       v9, #0
    s.movz       s9, #31
idiv_15:
    v.splat      v10, s9
    v.shl        v16, v9, v1
    v.cmp.lt     p1, v9, v2
    v.lshr       v17, v3, v10
    v.shl        v18, v1, v10
    s.subi       s15, s9, #1
    v.and        v10, v17, v1
    v.or         v17, v16, v10
    v.cmp.geu    p3, v17, v4
    p.or         p4, p1, p3
    v.sub        v10, v17, v4
    @p4 v.sel        v16, v18, v2
    @p4 v.sel        v18, v10, v17
    v.or         v10, v5, v16
    v.mov        v9, v18
    v.mov        v5, v10
    s.mov        s9, s15
    s.cmp.ge     s15, s9, s13
    br.nz        s15, idiv_15
    v.movi       v1, #0
    v.sub        v3, v2, v9
    v.movi       v2, #1
    v.sub        v4, v1, v7
    v.sub        v5, v1, v0
    v.cmp.lt     p1, v7, v1
    @p2 v.sel        v10, v3, v9
    v.cmp.lt     p2, v0, v1
    @p1 v.sel        v3, v4, v7
    @p2 v.sel        v4, v5, v0
    v.movi       v5, #0
    v.movi       v7, #0
    s.movz       s9, #31
idiv_16:
    v.splat      v9, s9
    v.shl        v16, v7, v2
    v.cmp.lt     p2, v7, v1
    v.lshr       v17, v3, v9
    v.shl        v18, v2, v9
    s.subi       s13, s9, #1
    v.and        v9, v17, v2
    v.or         v17, v16, v9
    v.cmp.geu    p3, v17, v4
    p.or         p4, p2, p3
    v.sub        v9, v17, v4
    @p4 v.sel        v16, v18, v1
    @p4 v.sel        v18, v9, v17
    v.or         v9, v5, v16
    v.mov        v7, v18
    v.mov        v5, v9
    s.mov        s9, s13
    s.movz       s13, #0
    s.cmp.ge     s15, s9, s13
    br.nz        s15, idiv_16
    v.movi       v2, #0
    v.sub        v3, v1, v7
    v.movi       v1, #1
    v.sub        v4, v2, v8
    v.cmp.lt     p2, v8, v2
    @p1 v.sel        v5, v3, v7
    v.sub        v3, v2, v0
    v.cmp.lt     p1, v0, v2
    @p2 v.sel        v7, v4, v8
    @p1 v.sel        v4, v3, v0
    v.movi       v0, #0
    v.movi       v3, #0
    s.movz       s9, #31
idiv_17:
    v.splat      v8, s9
    v.shl        v9, v3, v1
    v.cmp.lt     p1, v3, v2
    v.lshr       v16, v7, v8
    v.shl        v17, v1, v8
    s.subi       s15, s9, #1
    v.and        v8, v16, v1
    v.or         v16, v9, v8
    v.cmp.geu    p3, v16, v4
    p.or         p4, p1, p3
    v.sub        v8, v16, v4
    @p4 v.sel        v9, v17, v2
    @p4 v.sel        v17, v8, v16
    v.or         v8, v0, v9
    v.mov        v3, v17
    v.mov        v0, v8
    s.mov        s9, s15
    s.cmp.ge     s15, s9, s13
    br.nz        s15, idiv_17
    v.sub        v0, v2, v3
    @p2 v.sel        v1, v0, v3
    s.movz       s9, #32
    s.movz       s13, #48
    s.movz       s15, #64
    s.movz       s16, #80
    s.movz       s19, #96
    s.movz       s22, #112
    v.movi       v0, #128
    v.movi       v2, #0
    v.movi       v3, #1
    v.cmp.lt     p1, v15, v2
    v.cmp.lt     p2, v0, v2
    v.sub        v3, v2, v15
    @p1 v.sel        v4, v3, v15
    v.sub        v3, v2, v0
    @p2 v.sel        v7, v3, v0
    v.movi       v0, #7
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.movi       v0, #128
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v13, v3
    v.cmp.lt     p2, v0, v3
    v.sub        v4, v3, v13
    @p1 v.sel        v7, v4, v13
    v.sub        v4, v3, v0
    @p2 v.sel        v8, v4, v0
    v.movi       v0, #7
    v.lshr       v4, v7, v0
    v.sub        v0, v3, v4
    @p1 v.sel        v3, v0, v4
    v.movi       v0, #128
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p1, v14, v4
    v.cmp.lt     p2, v0, v4
    v.sub        v7, v4, v14
    @p1 v.sel        v8, v7, v14
    v.sub        v7, v4, v0
    @p2 v.sel        v9, v7, v0
    v.movi       v0, #7
    v.lshr       v7, v8, v0
    v.sub        v0, v4, v7
    @p1 v.sel        v4, v0, v7
    v.movi       v0, #128
    v.movi       v7, #0
    v.movi       v8, #1
    v.cmp.lt     p1, v12, v7
    v.cmp.lt     p2, v0, v7
    v.sub        v8, v7, v12
    @p1 v.sel        v9, v8, v12
    v.sub        v8, v7, v0
    @p2 v.sel        v16, v8, v0
    v.movi       v0, #7
    v.lshr       v8, v9, v0
    v.sub        v0, v7, v8
    @p1 v.sel        v7, v0, v8
    v.movi       v0, #128
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p1, v11, v8
    v.cmp.lt     p2, v0, v8
    v.sub        v9, v8, v11
    @p1 v.sel        v16, v9, v11
    v.sub        v9, v8, v0
    @p2 v.sel        v17, v9, v0
    v.movi       v0, #7
    v.lshr       v9, v16, v0
    v.sub        v0, v8, v9
    @p1 v.sel        v8, v0, v9
    v.movi       v0, #128
    v.movi       v9, #0
    v.movi       v16, #1
    v.cmp.lt     p1, v10, v9
    v.cmp.lt     p2, v0, v9
    v.sub        v16, v9, v10
    @p1 v.sel        v17, v16, v10
    v.sub        v16, v9, v0
    @p2 v.sel        v18, v16, v0
    v.movi       v0, #7
    v.lshr       v16, v17, v0
    v.sub        v0, v9, v16
    @p1 v.sel        v9, v0, v16
    v.movi       v0, #128
    v.movi       v16, #0
    v.movi       v17, #1
    v.cmp.lt     p1, v5, v16
    v.cmp.lt     p2, v0, v16
    v.sub        v17, v16, v5
    @p1 v.sel        v18, v17, v5
    v.sub        v17, v16, v0
    @p2 v.sel        v19, v17, v0
    v.movi       v0, #7
    v.lshr       v17, v18, v0
    v.sub        v0, v16, v17
    @p1 v.sel        v16, v0, v17
    v.movi       v0, #128
    v.movi       v17, #0
    v.movi       v18, #1
    v.cmp.lt     p1, v1, v17
    v.cmp.lt     p2, v0, v17
    v.sub        v18, v17, v1
    @p1 v.sel        v19, v18, v1
    v.sub        v18, v17, v0
    @p2 v.sel        v20, v18, v0
    v.movi       v0, #7
    v.lshr       v18, v19, v0
    v.sub        v0, v17, v18
    @p1 v.sel        v17, v0, v18
    v.splat      v0, s20
    v.mul        v18, v2, v0
    v.mul        v2, v3, v0
    v.mul        v3, v4, v0
    v.mul        v4, v7, v0
    v.mul        v7, v8, v0
    v.mul        v8, v9, v0
    v.mul        v9, v16, v0
    v.mul        v16, v17, v0
    s.add        s20, s8, s1
    s.movz       s1, #0
    s.cmp.lt     s23, s20, s1
    s.sub        s24, s1, s23
    s.cmp.lt     s23, s21, s1
    s.sub        s25, s1, s23
    s.xor        s23, s20, s24
    s.sub        s20, s23, s24
    s.xor        s23, s21, s25
    s.sub        s26, s23, s25
    s.lshri      s23, s20, #7
    s.muli       s26, s23, #128
    s.sub        s27, s20, s26
    s.xor        s20, s24, s25
    s.xor        s24, s23, s20
    s.sub        s23, s24, s20
    s.movz       s20, #1
    s.addi       s24, s1, #0
    s.addi       s25, s1, #0
    s.addi       s26, s1, #0
    s.addi       s27, s11, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_26:
    s.cmp.ge     s11, s24, s23
    br.nz        s11, endfor_27
    s.muli       s11, s14, #2
    s.mul        s28, s24, s21
    s.muli       s29, s25, #2
    v.iota       v0                              // arange(0, VLEN)
    s.rdspecial  s30, arg_base
    v.splat      v17, s11
    s.sub        s11, s8, s28
    s.ld.d       s28, [s30, #88]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.mul        v19, v6, v17
    s.add        s30, s1, s11                    // the tile origin
    v.extract    s31, v19, #0
    v.splat      v17, s30
    s.add        s30, s31, s29
    s.add        s31, s2, s30
    v.cmp.lt     p1, v0, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s31, #0]
    s.addi       s30, s28, #0
    v.extract    s31, v19, #1
    v.extract    s32, v19, #2
    s.add        s33, s31, s29
    s.add        s31, s32, s29
    s.add        s32, s2, s33
    s.addi       s33, s30, #64
    s.add        s34, s2, s31
    s.addi       s31, s30, #128
    vf.cvt.bf16.f32 v20, v17
    s.addi       s35, s30, #192
    v.st.w       [s30, #0], v20
    v.extract    s36, v19, #3
    s.add        s37, s36, s29
    s.add        s36, s2, s37
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s32, s30, #256
    v.st.w       [s33, #0], v20
    v.extract    s33, v19, #4
    s.add        s37, s33, s29
    s.add        s33, s2, s37
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s34, s30, #320
    v.st.w       [s31, #0], v20
    v.extract    s31, v19, #5
    s.add        s37, s31, s29
    s.add        s31, s2, s37
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s36, s30, #384
    v.st.w       [s35, #0], v20
    v.extract    s35, v19, #6
    s.add        s37, s35, s29
    s.add        s35, s2, s37
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s33, s30, #448
    v.st.w       [s32, #0], v20
    v.extract    s32, v19, #7
    s.add        s37, s32, s29
    s.add        s32, s2, s37
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s31, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s31, s30, #512
    v.st.w       [s34, #0], v20
    v.extract    s34, v19, #8
    s.add        s37, s34, s29
    s.add        s34, s2, s37
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s35, s30, #576
    v.st.w       [s36, #0], v20
    v.extract    s36, v19, #9
    s.add        s37, s36, s29
    s.add        s36, s2, s37
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s32, s30, #640
    v.st.w       [s33, #0], v20
    v.extract    s33, v19, #10
    s.add        s37, s33, s29
    s.add        s33, s2, s37
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s34, s30, #704
    v.st.w       [s31, #0], v20
    v.extract    s31, v19, #11
    s.add        s37, s31, s29
    s.add        s31, s2, s37
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s36, s30, #768
    v.st.w       [s35, #0], v20
    v.extract    s35, v19, #12
    s.add        s37, s35, s29
    s.add        s35, s2, s37
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s33, s30, #832
    v.st.w       [s32, #0], v20
    v.extract    s32, v19, #13
    s.add        s37, s32, s29
    s.add        s32, s2, s37
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s31, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s31, s30, #896
    v.st.w       [s34, #0], v20
    v.extract    s34, v19, #14
    s.add        s37, s34, s29
    s.add        s34, s2, s37
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s35, s30, #960
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #15
    s.add        s36, s30, s29
    s.add        s30, s2, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s32, v19, #0
    s.addi       s33, s28, #1024
    s.add        s36, s32, s29
    s.addi       s32, s36, #32
    s.add        s36, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    s.movz       s32, #0
    vf.cvt.bf16.f32 v20, v17
    s.add        s34, s32, s6                    // the tile origin
    v.st.w       [s31, #0], v20
    v.splat      v17, s34
    s.add        s31, s32, s11                   // the tile origin
    v.add        v20, v0, v17
    v.splat      v17, s31
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v21, [s30, #0]
    v.cmp.lt     p1, v20, v17
    vf.cvt.bf16.f32 v17, v21
    v.st.w       [s35, #0], v17
    fence.acq_rel.device
    v.extract    s30, v19, #1
    v.extract    s31, v19, #2
    s.add        s32, s30, s29
    s.add        s30, s31, s29
    s.addi       s31, s32, #32
    s.addi       s32, s30, #32
    s.add        s30, s2, s31
    s.addi       s31, s33, #64
    s.add        s34, s2, s32
    s.addi       s32, s33, #128
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s35, v19, #3
    s.addi       s36, s33, #192
    s.add        s37, s35, s29
    s.addi       s35, s37, #32
    s.add        s37, s2, s35
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s30, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #4
    s.addi       s31, s33, #256
    s.add        s35, s30, s29
    s.addi       s30, s35, #32
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #5
    s.addi       s32, s33, #320
    s.add        s34, s30, s29
    s.addi       s30, s34, #32
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #6
    s.addi       s36, s33, #384
    s.add        s37, s30, s29
    s.addi       s30, s37, #32
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #7
    s.addi       s31, s33, #448
    s.add        s35, s30, s29
    s.addi       s30, s35, #32
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #8
    s.addi       s32, s33, #512
    s.add        s34, s30, s29
    s.addi       s30, s34, #32
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #9
    s.addi       s36, s33, #576
    s.add        s37, s30, s29
    s.addi       s30, s37, #32
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #10
    s.addi       s31, s33, #640
    s.add        s35, s30, s29
    s.addi       s30, s35, #32
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #11
    s.addi       s32, s33, #704
    s.add        s34, s30, s29
    s.addi       s30, s34, #32
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #12
    s.addi       s36, s33, #768
    s.add        s37, s30, s29
    s.addi       s30, s37, #32
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #13
    s.addi       s31, s33, #832
    s.add        s35, s30, s29
    s.addi       s30, s35, #32
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #14
    s.addi       s32, s33, #896
    s.add        s34, s30, s29
    s.addi       s30, s34, #32
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #15
    s.addi       s36, s33, #960
    s.add        s33, s30, s29
    s.addi       s30, s33, #32
    s.add        s33, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #0
    s.addi       s31, s28, #2048
    s.add        s35, s30, s29
    s.addi       s30, s35, #64
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    s.add        s34, s2, s30
    vf.cvt.bf16.f32 v20, v17
    s.movz       s30, #0
    v.st.w       [s32, #0], v20
    s.add        s32, s30, s9                    // the tile origin
    s.add        s35, s30, s11                   // the tile origin
    v.splat      v17, s32
    v.splat      v20, s35
    v.add        v21, v0, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    v.cmp.lt     p1, v21, v20
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    fence.acq_rel.device
    v.extract    s30, v19, #1
    v.extract    s32, v19, #2
    s.add        s33, s30, s29
    s.add        s30, s32, s29
    s.addi       s32, s33, #64
    s.addi       s33, s30, #64
    s.add        s30, s2, s32
    s.addi       s32, s31, #64
    s.add        s35, s2, s33
    s.addi       s33, s31, #128
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s34, v19, #3
    s.addi       s36, s31, #192
    s.add        s37, s34, s29
    s.addi       s34, s37, #64
    s.add        s37, s2, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s30, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #4
    s.addi       s32, s31, #256
    s.add        s34, s30, s29
    s.addi       s30, s34, #64
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #5
    s.addi       s33, s31, #320
    s.add        s35, s30, s29
    s.addi       s30, s35, #64
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #6
    s.addi       s36, s31, #384
    s.add        s37, s30, s29
    s.addi       s30, s37, #64
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #7
    s.addi       s32, s31, #448
    s.add        s34, s30, s29
    s.addi       s30, s34, #64
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #8
    s.addi       s33, s31, #512
    s.add        s35, s30, s29
    s.addi       s30, s35, #64
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #9
    s.addi       s36, s31, #576
    s.add        s37, s30, s29
    s.addi       s30, s37, #64
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #10
    s.addi       s32, s31, #640
    s.add        s34, s30, s29
    s.addi       s30, s34, #64
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #11
    s.addi       s33, s31, #704
    s.add        s35, s30, s29
    s.addi       s30, s35, #64
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #12
    s.addi       s36, s31, #768
    s.add        s37, s30, s29
    s.addi       s30, s37, #64
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #13
    s.addi       s32, s31, #832
    s.add        s34, s30, s29
    s.addi       s30, s34, #64
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #14
    s.addi       s33, s31, #896
    s.add        s35, s30, s29
    s.addi       s30, s35, #64
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #15
    s.addi       s36, s31, #960
    s.add        s31, s30, s29
    s.addi       s30, s31, #64
    s.add        s31, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #0
    s.addi       s32, s28, #3072
    s.add        s34, s30, s29
    s.addi       s30, s34, #96
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    s.add        s34, s2, s30
    vf.cvt.bf16.f32 v20, v17
    s.movz       s30, #0
    v.st.w       [s33, #0], v20
    s.add        s33, s30, s13                   // the tile origin
    s.add        s35, s30, s11                   // the tile origin
    v.splat      v17, s33
    v.splat      v20, s35
    v.add        v21, v0, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s31, #0]
    v.cmp.lt     p1, v21, v20
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    fence.acq_rel.device
    v.extract    s30, v19, #1
    v.extract    s31, v19, #2
    s.add        s33, s30, s29
    s.add        s30, s31, s29
    s.addi       s31, s33, #96
    s.addi       s33, s30, #96
    s.add        s30, s2, s31
    s.addi       s31, s32, #64
    s.add        s35, s2, s33
    s.addi       s33, s32, #128
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s34, v19, #3
    s.addi       s36, s32, #192
    s.add        s37, s34, s29
    s.addi       s34, s37, #96
    s.add        s37, s2, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s30, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #4
    s.addi       s31, s32, #256
    s.add        s34, s30, s29
    s.addi       s30, s34, #96
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #5
    s.addi       s33, s32, #320
    s.add        s35, s30, s29
    s.addi       s30, s35, #96
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #6
    s.addi       s36, s32, #384
    s.add        s37, s30, s29
    s.addi       s30, s37, #96
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #7
    s.addi       s31, s32, #448
    s.add        s34, s30, s29
    s.addi       s30, s34, #96
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #8
    s.addi       s33, s32, #512
    s.add        s35, s30, s29
    s.addi       s30, s35, #96
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #9
    s.addi       s36, s32, #576
    s.add        s37, s30, s29
    s.addi       s30, s37, #96
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #10
    s.addi       s31, s32, #640
    s.add        s34, s30, s29
    s.addi       s30, s34, #96
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #11
    s.addi       s33, s32, #704
    s.add        s35, s30, s29
    s.addi       s30, s35, #96
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #12
    s.addi       s36, s32, #768
    s.add        s37, s30, s29
    s.addi       s30, s37, #96
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #13
    s.addi       s31, s32, #832
    s.add        s34, s30, s29
    s.addi       s30, s34, #96
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #14
    s.addi       s33, s32, #896
    s.add        s35, s30, s29
    s.addi       s30, s35, #96
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #15
    s.addi       s36, s32, #960
    s.add        s32, s30, s29
    s.addi       s30, s32, #96
    s.add        s32, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #0
    s.addi       s31, s28, #4096
    s.add        s34, s30, s29
    s.addi       s30, s34, #128
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    s.add        s34, s2, s30
    vf.cvt.bf16.f32 v20, v17
    s.movz       s30, #0
    v.st.w       [s33, #0], v20
    s.add        s33, s30, s15                   // the tile origin
    s.add        s35, s30, s11                   // the tile origin
    v.splat      v17, s33
    v.splat      v20, s35
    v.add        v21, v0, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    v.cmp.lt     p1, v21, v20
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    fence.acq_rel.device
    v.extract    s30, v19, #1
    v.extract    s32, v19, #2
    s.add        s33, s30, s29
    s.add        s30, s32, s29
    s.addi       s32, s33, #128
    s.addi       s33, s30, #128
    s.add        s30, s2, s32
    s.addi       s32, s31, #64
    s.add        s35, s2, s33
    s.addi       s33, s31, #128
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s34, v19, #3
    s.addi       s36, s31, #192
    s.add        s37, s34, s29
    s.addi       s34, s37, #128
    s.add        s37, s2, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s30, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #4
    s.addi       s32, s31, #256
    s.add        s34, s30, s29
    s.addi       s30, s34, #128
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #5
    s.addi       s33, s31, #320
    s.add        s35, s30, s29
    s.addi       s30, s35, #128
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #6
    s.addi       s36, s31, #384
    s.add        s37, s30, s29
    s.addi       s30, s37, #128
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #7
    s.addi       s32, s31, #448
    s.add        s34, s30, s29
    s.addi       s30, s34, #128
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #8
    s.addi       s33, s31, #512
    s.add        s35, s30, s29
    s.addi       s30, s35, #128
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #9
    s.addi       s36, s31, #576
    s.add        s37, s30, s29
    s.addi       s30, s37, #128
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #10
    s.addi       s32, s31, #640
    s.add        s34, s30, s29
    s.addi       s30, s34, #128
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #11
    s.addi       s33, s31, #704
    s.add        s35, s30, s29
    s.addi       s30, s35, #128
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #12
    s.addi       s36, s31, #768
    s.add        s37, s30, s29
    s.addi       s30, s37, #128
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #13
    s.addi       s32, s31, #832
    s.add        s34, s30, s29
    s.addi       s30, s34, #128
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #14
    s.addi       s33, s31, #896
    s.add        s35, s30, s29
    s.addi       s30, s35, #128
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #15
    s.addi       s36, s31, #960
    s.add        s31, s30, s29
    s.addi       s30, s31, #128
    s.add        s31, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #0
    s.addi       s32, s28, #5120
    s.add        s34, s30, s29
    s.addi       s30, s34, #160
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    s.add        s34, s2, s30
    vf.cvt.bf16.f32 v20, v17
    s.movz       s30, #0
    v.st.w       [s33, #0], v20
    s.add        s33, s30, s16                   // the tile origin
    s.add        s35, s30, s11                   // the tile origin
    v.splat      v17, s33
    v.splat      v20, s35
    v.add        v21, v0, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s31, #0]
    v.cmp.lt     p1, v21, v20
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    fence.acq_rel.device
    v.extract    s30, v19, #1
    v.extract    s31, v19, #2
    s.add        s33, s30, s29
    s.add        s30, s31, s29
    s.addi       s31, s33, #160
    s.addi       s33, s30, #160
    s.add        s30, s2, s31
    s.addi       s31, s32, #64
    s.add        s35, s2, s33
    s.addi       s33, s32, #128
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s34, v19, #3
    s.addi       s36, s32, #192
    s.add        s37, s34, s29
    s.addi       s34, s37, #160
    s.add        s37, s2, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s30, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #4
    s.addi       s31, s32, #256
    s.add        s34, s30, s29
    s.addi       s30, s34, #160
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #5
    s.addi       s33, s32, #320
    s.add        s35, s30, s29
    s.addi       s30, s35, #160
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #6
    s.addi       s36, s32, #384
    s.add        s37, s30, s29
    s.addi       s30, s37, #160
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #7
    s.addi       s31, s32, #448
    s.add        s34, s30, s29
    s.addi       s30, s34, #160
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #8
    s.addi       s33, s32, #512
    s.add        s35, s30, s29
    s.addi       s30, s35, #160
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #9
    s.addi       s36, s32, #576
    s.add        s37, s30, s29
    s.addi       s30, s37, #160
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #10
    s.addi       s31, s32, #640
    s.add        s34, s30, s29
    s.addi       s30, s34, #160
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #11
    s.addi       s33, s32, #704
    s.add        s35, s30, s29
    s.addi       s30, s35, #160
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #12
    s.addi       s36, s32, #768
    s.add        s37, s30, s29
    s.addi       s30, s37, #160
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #13
    s.addi       s31, s32, #832
    s.add        s34, s30, s29
    s.addi       s30, s34, #160
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #14
    s.addi       s33, s32, #896
    s.add        s35, s30, s29
    s.addi       s30, s35, #160
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #15
    s.addi       s36, s32, #960
    s.add        s32, s30, s29
    s.addi       s30, s32, #160
    s.add        s32, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s30, v19, #0
    s.addi       s31, s28, #6144
    s.add        s34, s30, s29
    s.addi       s30, s34, #192
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    s.add        s34, s2, s30
    vf.cvt.bf16.f32 v20, v17
    s.movz       s30, #0
    v.st.w       [s33, #0], v20
    s.add        s33, s30, s19                   // the tile origin
    s.add        s35, s30, s11                   // the tile origin
    v.splat      v17, s33
    v.splat      v20, s35
    v.add        v21, v0, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    v.cmp.lt     p1, v21, v20
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    fence.acq_rel.device
    v.extract    s30, v19, #1
    v.extract    s32, v19, #2
    s.add        s33, s30, s29
    s.add        s30, s32, s29
    s.addi       s32, s33, #192
    s.addi       s33, s30, #192
    s.add        s30, s2, s32
    s.addi       s32, s31, #64
    s.add        s35, s2, s33
    s.addi       s33, s31, #128
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s31, #0], v20
    v.extract    s34, v19, #3
    s.addi       s36, s31, #192
    s.add        s37, s34, s29
    s.addi       s34, s37, #192
    s.add        s37, s2, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s30, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #4
    s.addi       s32, s31, #256
    s.add        s34, s30, s29
    s.addi       s30, s34, #192
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #5
    s.addi       s33, s31, #320
    s.add        s35, s30, s29
    s.addi       s30, s35, #192
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #6
    s.addi       s36, s31, #384
    s.add        s37, s30, s29
    s.addi       s30, s37, #192
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #7
    s.addi       s32, s31, #448
    s.add        s34, s30, s29
    s.addi       s30, s34, #192
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #8
    s.addi       s33, s31, #512
    s.add        s35, s30, s29
    s.addi       s30, s35, #192
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #9
    s.addi       s36, s31, #576
    s.add        s37, s30, s29
    s.addi       s30, s37, #192
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #10
    s.addi       s32, s31, #640
    s.add        s34, s30, s29
    s.addi       s30, s34, #192
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #11
    s.addi       s33, s31, #704
    s.add        s35, s30, s29
    s.addi       s30, s35, #192
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #12
    s.addi       s36, s31, #768
    s.add        s37, s30, s29
    s.addi       s30, s37, #192
    s.add        s37, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #13
    s.addi       s32, s31, #832
    s.add        s34, s30, s29
    s.addi       s30, s34, #192
    s.add        s34, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s33, #0], v20
    v.extract    s30, v19, #14
    s.addi       s33, s31, #896
    s.add        s35, s30, s29
    s.addi       s30, s35, #192
    s.add        s35, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s30, v19, #15
    s.addi       s36, s31, #960
    s.add        s31, s30, s29
    s.addi       s30, s31, #192
    s.add        s31, s2, s30
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s32, #0], v20
    v.extract    s30, v19, #0
    s.addi       s32, s28, #7168
    s.add        s34, s30, s29
    s.addi       s30, s34, #224
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    s.add        s34, s2, s30
    vf.cvt.bf16.f32 v20, v17
    s.movz       s30, #0
    v.st.w       [s33, #0], v20
    s.add        s33, s30, s22                   // the tile origin
    s.add        s35, s30, s11                   // the tile origin
    v.splat      v17, s33
    v.splat      v20, s35
    v.add        v21, v0, v17
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s31, #0]
    v.cmp.lt     p1, v21, v20
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s36, #0], v17
    fence.acq_rel.device
    v.extract    s30, v19, #1
    v.extract    s31, v19, #2
    s.add        s33, s30, s29
    s.add        s30, s31, s29
    s.addi       s31, s33, #224
    s.addi       s33, s30, #224
    s.add        s30, s2, s31
    s.addi       s31, s32, #64
    s.add        s35, s2, s33
    s.addi       s33, s32, #128
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s34, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s32, #0], v17
    v.extract    s34, v19, #3
    s.addi       s36, s32, #192
    s.add        s37, s34, s29
    s.addi       s34, s37, #224
    s.add        s37, s2, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s30, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s31, #0], v17
    v.extract    s30, v19, #4
    s.addi       s31, s32, #256
    s.add        s34, s30, s29
    s.addi       s30, s34, #224
    s.add        s34, s2, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s35, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s33, #0], v17
    v.extract    s30, v19, #5
    s.addi       s33, s32, #320
    s.add        s35, s30, s29
    s.addi       s30, s35, #224
    s.add        s35, s2, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s37, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s36, #0], v17
    v.extract    s30, v19, #6
    s.addi       s36, s32, #384
    s.add        s37, s30, s29
    s.addi       s30, s37, #224
    s.add        s37, s2, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s34, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s31, #0], v17
    v.extract    s30, v19, #7
    s.addi       s31, s32, #448
    s.add        s34, s30, s29
    s.addi       s30, s34, #224
    s.add        s34, s2, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s35, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s33, #0], v17
    v.extract    s30, v19, #8
    s.addi       s33, s32, #512
    s.add        s35, s30, s29
    s.addi       s30, s35, #224
    s.add        s35, s2, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s37, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s36, #0], v17
    v.extract    s30, v19, #9
    s.addi       s36, s32, #576
    s.add        s37, s30, s29
    s.addi       s30, s37, #224
    s.add        s37, s2, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s34, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s31, #0], v17
    v.extract    s30, v19, #10
    s.addi       s31, s32, #640
    s.add        s34, s30, s29
    s.addi       s30, s34, #224
    s.add        s34, s2, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s35, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s33, #0], v17
    v.extract    s30, v19, #11
    s.addi       s33, s32, #704
    s.add        s35, s30, s29
    s.addi       s30, s35, #224
    s.add        s35, s2, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s37, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s36, #0], v17
    v.extract    s30, v19, #12
    s.addi       s36, s32, #768
    s.add        s37, s30, s29
    s.addi       s30, s37, #224
    s.add        s37, s2, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s34, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s31, #0], v17
    v.extract    s30, v19, #13
    s.addi       s31, s32, #832
    s.add        s34, s30, s29
    s.addi       s30, s34, #224
    s.add        s34, s2, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s35, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s33, #0], v17
    v.extract    s30, v19, #14
    s.addi       s33, s32, #896
    s.add        s35, s30, s29
    s.addi       s30, s35, #224
    s.add        s35, s2, s30
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s37, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s36, #0], v17
    v.extract    s30, v19, #15
    s.addi       s36, s32, #960
    s.add        s32, s30, s29
    s.addi       s29, s32, #224
    s.add        s30, s2, s29
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s34, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s31, #0], v17
    s.addi       s29, s28, #0
    s.addi       s31, s28, #1024
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s35, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s33, #0], v17
    s.addi       s32, s28, #2048
    s.addi       s33, s28, #3072
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s30, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s36, #0], v17
    fence.acq_rel.device
    s.addi       s30, s28, #4096
    v.ld.w       v0, [s29, #0]
    v.ld.w       v17, [s31, #0]
    vf.abs       v19, v0
    s.addi       s29, s28, #5120
    v.ld.w       v0, [s32, #0]
    vf.abs       v20, v17
    vf.max.ieee  v17, v19, v20
    s.addi       s31, s28, #6144
    v.ld.w       v19, [s33, #0]
    vf.abs       v20, v0
    vf.max.ieee  v0, v17, v20
    s.addi       s32, s28, #7168
    v.ld.w       v17, [s30, #0]
    vf.abs       v20, v19
    vf.max.ieee  v19, v0, v20
    s.addi       s30, s28, #64
    v.ld.w       v0, [s29, #0]
    vf.abs       v20, v17
    vf.max.ieee  v17, v19, v20
    s.addi       s29, s28, #1088
    v.ld.w       v19, [s30, #0]
    vf.abs       v20, v0
    vf.max.ieee  v0, v17, v20
    s.addi       s30, s28, #2112
    v.ld.w       v17, [s29, #0]
    vf.abs       v20, v19
    vf.abs       v19, v17
    v.ld.w       v17, [s31, #0]
    vf.max.ieee  v21, v20, v19
    v.ld.w       v19, [s30, #0]
    vf.abs       v20, v17
    vf.max.ieee  v17, v0, v20
    s.addi       s29, s28, #3136
    vf.abs       v0, v19
    v.ld.w       v19, [s32, #0]
    vf.max.ieee  v20, v21, v0
    v.ld.w       v0, [s29, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v17, v21
    vf.reduce.max.b v17, v19
    s.addi       s29, s28, #4160
    s.addi       s30, s28, #5184
    s.addi       s31, s28, #6208
    s.addi       s32, s28, #7232
    v.ld.w       v19, [s29, #0]
    vf.abs       v21, v0
    vf.max.ieee  v0, v20, v21
    s.addi       s29, s28, #128
    v.ld.w       v20, [s30, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v0, v21
    s.addi       s30, s28, #1152
    v.ld.w       v0, [s29, #0]
    vf.abs       v21, v20
    vf.max.ieee  v20, v19, v21
    s.addi       s29, s28, #2176
    v.ld.w       v19, [s30, #0]
    vf.abs       v21, v0
    vf.abs       v0, v19
    v.ld.w       v19, [s31, #0]
    vf.max.ieee  v22, v21, v0
    v.ld.w       v0, [s29, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v20, v21
    s.addi       s29, s28, #3200
    vf.abs       v20, v0
    v.ld.w       v0, [s32, #0]
    vf.max.ieee  v21, v22, v20
    v.ld.w       v20, [s29, #0]
    vf.abs       v22, v0
    vf.max.ieee  v0, v19, v22
    vf.reduce.max.b v19, v0
    s.addi       s29, s28, #4224
    s.addi       s30, s28, #5248
    s.addi       s31, s28, #6272
    s.addi       s32, s28, #7296
    v.ld.w       v0, [s29, #0]
    vf.abs       v22, v20
    vf.max.ieee  v20, v21, v22
    s.addi       s29, s28, #192
    v.ld.w       v21, [s30, #0]
    vf.abs       v22, v0
    vf.max.ieee  v0, v20, v22
    s.addi       s30, s28, #1216
    v.ld.w       v20, [s29, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v0, v22
    s.addi       s29, s28, #2240
    v.ld.w       v0, [s30, #0]
    vf.abs       v22, v20
    vf.abs       v20, v0
    v.ld.w       v0, [s31, #0]
    vf.max.ieee  v23, v22, v20
    v.ld.w       v20, [s29, #0]
    vf.abs       v22, v0
    vf.max.ieee  v0, v21, v22
    s.addi       s29, s28, #3264
    vf.abs       v21, v20
    v.ld.w       v20, [s32, #0]
    vf.max.ieee  v22, v23, v21
    v.ld.w       v21, [s29, #0]
    vf.abs       v23, v20
    vf.max.ieee  v20, v0, v23
    vf.reduce.max.b v0, v20
    s.addi       s29, s28, #4288
    s.addi       s30, s28, #5312
    s.addi       s31, s28, #6336
    s.addi       s32, s28, #7360
    v.ld.w       v20, [s29, #0]
    vf.abs       v23, v21
    vf.max.ieee  v21, v22, v23
    s.addi       s29, s28, #256
    v.ld.w       v22, [s30, #0]
    vf.abs       v23, v20
    vf.max.ieee  v20, v21, v23
    s.addi       s30, s28, #1280
    v.ld.w       v21, [s29, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v20, v23
    s.addi       s29, s28, #2304
    v.ld.w       v20, [s30, #0]
    vf.abs       v23, v21
    vf.abs       v21, v20
    v.ld.w       v20, [s31, #0]
    vf.max.ieee  v24, v23, v21
    v.ld.w       v21, [s29, #0]
    vf.abs       v23, v20
    vf.max.ieee  v20, v22, v23
    s.addi       s29, s28, #3328
    vf.abs       v22, v21
    v.ld.w       v21, [s32, #0]
    vf.max.ieee  v23, v24, v22
    v.ld.w       v22, [s29, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v20, v24
    vf.reduce.max.b v20, v21
    s.addi       s29, s28, #4352
    s.addi       s30, s28, #5376
    s.addi       s31, s28, #6400
    s.addi       s32, s28, #7424
    v.ld.w       v21, [s29, #0]
    vf.abs       v24, v22
    vf.max.ieee  v22, v23, v24
    s.addi       s29, s28, #320
    v.ld.w       v23, [s30, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v22, v24
    s.addi       s30, s28, #1344
    v.ld.w       v22, [s29, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v21, v24
    s.addi       s29, s28, #2368
    v.ld.w       v21, [s30, #0]
    vf.abs       v24, v22
    vf.abs       v22, v21
    v.ld.w       v21, [s31, #0]
    vf.max.ieee  v25, v24, v22
    v.ld.w       v22, [s29, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v23, v24
    s.addi       s29, s28, #3392
    vf.abs       v23, v22
    v.ld.w       v22, [s32, #0]
    vf.max.ieee  v24, v25, v23
    v.ld.w       v23, [s29, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v21, v25
    vf.reduce.max.b v21, v22
    s.addi       s29, s28, #4416
    s.addi       s30, s28, #5440
    s.addi       s31, s28, #6464
    s.addi       s32, s28, #7488
    v.ld.w       v22, [s29, #0]
    vf.abs       v25, v23
    vf.max.ieee  v23, v24, v25
    s.addi       s29, s28, #384
    v.ld.w       v24, [s30, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v23, v25
    s.addi       s30, s28, #1408
    v.ld.w       v23, [s29, #0]
    vf.abs       v25, v24
    vf.max.ieee  v24, v22, v25
    s.addi       s29, s28, #2432
    v.ld.w       v22, [s30, #0]
    vf.abs       v25, v23
    vf.abs       v23, v22
    v.ld.w       v22, [s31, #0]
    vf.max.ieee  v26, v25, v23
    v.ld.w       v23, [s29, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v24, v25
    s.addi       s29, s28, #3456
    vf.abs       v24, v23
    v.ld.w       v23, [s32, #0]
    vf.max.ieee  v25, v26, v24
    v.ld.w       v24, [s29, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v22, v26
    vf.reduce.max.b v22, v23
    s.addi       s29, s28, #4480
    s.addi       s30, s28, #5504
    s.addi       s31, s28, #6528
    s.addi       s32, s28, #7552
    v.ld.w       v23, [s29, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v25, v26
    s.addi       s29, s28, #448
    v.ld.w       v25, [s30, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v24, v26
    s.addi       s30, s28, #1472
    v.ld.w       v24, [s29, #0]
    vf.abs       v26, v25
    vf.max.ieee  v25, v23, v26
    s.addi       s29, s28, #2496
    v.ld.w       v23, [s30, #0]
    vf.abs       v26, v24
    vf.abs       v24, v23
    v.ld.w       v23, [s31, #0]
    vf.max.ieee  v27, v26, v24
    v.ld.w       v24, [s29, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v25, v26
    s.addi       s29, s28, #3520
    vf.abs       v25, v24
    v.ld.w       v24, [s32, #0]
    vf.max.ieee  v26, v27, v25
    v.ld.w       v25, [s29, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v23, v27
    vf.reduce.max.b v23, v24
    s.addi       s29, s28, #4544
    s.addi       s30, s28, #5568
    s.addi       s31, s28, #6592
    s.addi       s32, s28, #7616
    v.ld.w       v24, [s29, #0]
    vf.abs       v27, v25
    vf.max.ieee  v25, v26, v27
    s.addi       s29, s28, #512
    v.ld.w       v26, [s30, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v25, v27
    s.addi       s30, s28, #1536
    v.ld.w       v25, [s29, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v24, v27
    s.addi       s29, s28, #2560
    v.ld.w       v24, [s30, #0]
    vf.abs       v27, v25
    vf.abs       v25, v24
    v.ld.w       v24, [s31, #0]
    vf.max.ieee  v28, v27, v25
    v.ld.w       v25, [s29, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v26, v27
    s.addi       s29, s28, #3584
    vf.abs       v26, v25
    v.ld.w       v25, [s32, #0]
    vf.max.ieee  v27, v28, v26
    v.ld.w       v26, [s29, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v24, v28
    vf.reduce.max.b v24, v25
    s.addi       s29, s28, #4608
    s.addi       s30, s28, #5632
    s.addi       s31, s28, #6656
    s.addi       s32, s28, #7680
    v.ld.w       v25, [s29, #0]
    vf.abs       v28, v26
    vf.max.ieee  v26, v27, v28
    s.addi       s29, s28, #576
    v.ld.w       v27, [s30, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v26, v28
    s.addi       s30, s28, #1600
    v.ld.w       v26, [s29, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v25, v28
    s.addi       s29, s28, #2624
    v.ld.w       v25, [s30, #0]
    vf.abs       v28, v26
    vf.abs       v26, v25
    v.ld.w       v25, [s31, #0]
    vf.max.ieee  v29, v28, v26
    v.ld.w       v26, [s29, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v27, v28
    s.addi       s29, s28, #3648
    vf.abs       v27, v26
    v.ld.w       v26, [s32, #0]
    vf.max.ieee  v28, v29, v27
    v.ld.w       v27, [s29, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v25, v29
    vf.reduce.max.b v25, v26
    s.addi       s29, s28, #4672
    s.addi       s30, s28, #5696
    s.addi       s31, s28, #6720
    s.addi       s32, s28, #7744
    v.ld.w       v26, [s29, #0]
    vf.abs       v29, v27
    vf.max.ieee  v27, v28, v29
    s.addi       s29, s28, #640
    v.ld.w       v28, [s30, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v27, v29
    s.addi       s30, s28, #1664
    v.ld.w       v27, [s29, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v26, v29
    s.addi       s29, s28, #2688
    v.ld.w       v26, [s30, #0]
    vf.abs       v29, v27
    vf.abs       v27, v26
    v.ld.w       v26, [s31, #0]
    vf.max.ieee  v30, v29, v27
    v.ld.w       v27, [s29, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v28, v29
    s.addi       s29, s28, #3712
    vf.abs       v28, v27
    v.ld.w       v27, [s32, #0]
    vf.max.ieee  v29, v30, v28
    v.ld.w       v28, [s29, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v26, v30
    vf.reduce.max.b v26, v27
    s.addi       s29, s28, #4736
    s.addi       s30, s28, #5760
    s.addi       s31, s28, #6784
    s.addi       s32, s28, #7808
    v.ld.w       v27, [s29, #0]
    vf.abs       v30, v28
    vf.max.ieee  v28, v29, v30
    s.addi       s29, s28, #704
    v.ld.w       v29, [s30, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v28, v30
    s.addi       s30, s28, #1728
    v.ld.w       v28, [s29, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v27, v30
    s.addi       s29, s28, #2752
    v.ld.w       v27, [s30, #0]
    vf.abs       v30, v28
    vf.abs       v28, v27
    v.ld.w       v27, [s31, #0]
    vf.max.ieee  v31, v30, v28
    v.ld.w       v28, [s29, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v29, v30
    s.addi       s29, s28, #3776
    vf.abs       v29, v28
    v.ld.w       v28, [s32, #0]
    vf.max.ieee  v30, v31, v29
    v.ld.w       v29, [s29, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v27, v31
    vf.reduce.max.b v27, v28
    s.addi       s29, s28, #4800
    s.addi       s30, s28, #5824
    s.addi       s31, s28, #6848
    s.addi       s32, s28, #7872
    v.ld.w       v28, [s29, #0]
    vf.abs       v31, v29
    vf.max.ieee  v29, v30, v31
    s.addi       s29, s28, #768
    v.ld.w       v30, [s30, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v29, v31
    s.addi       s30, s28, #1792
    v.ld.w       v29, [s29, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v28, v31
    s.addi       s29, s28, #2816
    v.ld.w       v28, [s30, #0]
    vf.abs       v31, v29
    vf.abs       v29, v28
    v.ld.w       v28, [s31, #0]
    vf.max.ieee  v32, v31, v29
    v.ld.w       v29, [s29, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v30, v31
    s.addi       s29, s28, #3840
    vf.abs       v30, v29
    v.ld.w       v29, [s32, #0]
    vf.max.ieee  v31, v32, v30
    v.ld.w       v30, [s29, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v28, v32
    vf.reduce.max.b v28, v29
    s.addi       s29, s28, #4864
    s.addi       s30, s28, #5888
    s.addi       s31, s28, #6912
    s.addi       s32, s28, #7936
    v.ld.w       v29, [s29, #0]
    vf.abs       v32, v30
    vf.max.ieee  v30, v31, v32
    s.addi       s29, s28, #832
    v.ld.w       v31, [s30, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v30, v32
    s.addi       s30, s28, #1856
    v.ld.w       v30, [s29, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v29, v32
    s.addi       s29, s28, #2880
    v.ld.w       v29, [s30, #0]
    vf.abs       v32, v30
    vf.abs       v30, v29
    v.ld.w       v29, [s31, #0]
    vf.max.ieee  v33, v32, v30
    v.ld.w       v30, [s29, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v31, v32
    s.addi       s29, s28, #3904
    vf.abs       v31, v30
    v.ld.w       v30, [s32, #0]
    vf.max.ieee  v32, v33, v31
    v.ld.w       v31, [s29, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v29, v33
    vf.reduce.max.b v29, v30
    s.addi       s29, s28, #4928
    s.addi       s30, s28, #5952
    s.addi       s31, s28, #6976
    s.addi       s32, s28, #8000
    v.ld.w       v30, [s29, #0]
    vf.abs       v33, v31
    vf.max.ieee  v31, v32, v33
    s.addi       s29, s28, #896
    v.ld.w       v32, [s30, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v31, v33
    s.addi       s30, s28, #1920
    v.ld.w       v31, [s29, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v30, v33
    s.addi       s29, s28, #2944
    v.ld.w       v30, [s30, #0]
    vf.abs       v33, v31
    vf.abs       v31, v30
    v.ld.w       v30, [s31, #0]
    vf.max.ieee  v34, v33, v31
    v.ld.w       v31, [s29, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v32, v33
    s.addi       s29, s28, #3968
    v.ld.w       v32, [s32, #0]
    vf.abs       v33, v31
    vf.max.ieee  v31, v34, v33
    v.ld.w       v33, [s29, #0]
    vf.abs       v34, v32
    vf.max.ieee  v32, v30, v34
    vf.reduce.max.b v30, v32
    s.addi       s29, s28, #4992
    s.addi       s30, s28, #6016
    s.addi       s31, s28, #7040
    s.addi       s32, s28, #8064
    v.ld.w       v32, [s29, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v31, v34
    s.addi       s29, s28, #960
    v.ld.w       v31, [s30, #0]
    vf.abs       v34, v32
    vf.max.ieee  v32, v33, v34
    s.addi       s30, s28, #1984
    v.ld.w       v33, [s29, #0]
    vf.abs       v34, v31
    vf.max.ieee  v31, v32, v34
    s.addi       s29, s28, #3008
    v.ld.w       v32, [s30, #0]
    vf.abs       v34, v33
    v.ld.w       v33, [s31, #0]
    vf.abs       v35, v32
    vf.max.ieee  v32, v34, v35
    v.ld.w       v34, [s29, #0]
    vf.abs       v35, v33
    vf.max.ieee  v33, v31, v35
    s.addi       s29, s28, #4032
    v.ld.w       v31, [s32, #0]
    vf.abs       v35, v34
    vf.max.ieee  v34, v32, v35
    v.ld.w       v32, [s29, #0]
    vf.abs       v35, v31
    vf.max.ieee  v31, v33, v35
    vf.reduce.max.b v33, v31
    s.addi       s29, s28, #5056
    s.addi       s30, s28, #6080
    s.addi       s31, s28, #7104
    s.addi       s32, s28, #8128
    v.ld.w       v31, [s29, #0]
    vf.abs       v35, v32
    vf.max.ieee  v32, v34, v35
    v.movi       v34, #0
    v.ld.w       v35, [s30, #0]
    vf.abs       v36, v31
    // one value per row into one vector (ISA 0x09)
    v.extract    s29, v17, #0
    vf.max.ieee  v17, v32, v36
    v.extract    s30, v19, #0
    v.ld.w       v19, [s31, #0]
    vf.abs       v31, v35
    v.extract    s31, v0, #0
    vf.max.ieee  v0, v17, v31
    v.extract    s33, v20, #0
    v.ld.w       v17, [s32, #0]
    v.insert     v34, s29, #0
    vf.abs       v20, v19
    v.extract    s29, v21, #0
    v.insert     v34, s30, #1
    v.insert     v34, s31, #2
    vf.max.ieee  v19, v0, v20
    v.extract    s30, v22, #0
    v.insert     v34, s33, #3
    v.insert     v34, s29, #4
    v.insert     v34, s30, #5
    vf.abs       v0, v17
    v.extract    s29, v23, #0
    vf.max.ieee  v17, v19, v0
    v.insert     v34, s29, #6
    vf.reduce.max.b v0, v17
    v.extract    s29, v24, #0
    v.extract    s30, v25, #0
    v.insert     v34, s29, #7
    .li       s29, #1138753536
    v.splat      v17, s29                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s29, v26, #0
    v.insert     v34, s30, #8
    v.rcp.approx v19, v17                        // ISA 8.8: <= 2**-22 relative
    v.extract    s30, v27, #0
    v.insert     v34, s29, #9
    .li       s29, #1065353216
    v.splat      v20, s29                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s29, v28, #0
    v.insert     v34, s30, #10
    v.extract    s30, v29, #0
    v.extract    s31, v30, #0
    v.insert     v34, s29, #11
    v.extract    s29, v33, #0
    v.extract    s32, v0, #0
    v.insert     v34, s30, #12
    v.insert     v34, s31, #13
    v.insert     v34, s29, #14
    .li       s29, #730643660
    v.splat      v0, s29                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.insert     v34, s32, #15
    v.splat      v21, s18
    v.mul        v22, v15, v21
    v.mul        v23, v13, v21
    v.mul        v24, v14, v21
    vf.fms       v25, v17, v19, v20
    v.mul        v26, v12, v21
    vf.fms       v27, v19, v25, v19
    v.mul        v25, v11, v21
    vf.neg       v21, v27                        // Newton step: r0*(2 - x*r0)
    v.splat      v27, s18
    vf.cmp.o     p1, v21, v21
    v.mul        v28, v10, v27
    @p1 v.sel        v29, v21, v19
    v.mul        v19, v5, v27
    vf.mul       v21, v34, v29                   // a/y: faithful quotient
    v.mul        v30, v1, v27
    vf.fms       v27, v21, v17, v34
    v.ld.gather.w v17, [s27, v18]                // index is in elements (ISA sec 9.1)
    vf.fms       v31, v27, v29, v21
    vf.neg       v27, v31                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v29, v27, v21
    s.add        s29, s1, s11
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.addi       s11, s28, #8192
    s.addi       s30, s28, #8256
    s.addi       s31, s28, #8320
    s.addi       s32, s28, #8384
    v.ld.gather.w v21, [s27, v2]                 // index is in elements (ISA sec 9.1)
    s.addi       s33, s28, #8448
    v.ld.gather.w v27, [s27, v3]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v31, [s27, v4]                 // index is in elements (ISA sec 9.1)
    s.addi       s34, s28, #8512
    v.ld.gather.w v32, [s27, v7]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v33, [s27, v8]                 // index is in elements (ISA sec 9.1)
    s.addi       s35, s28, #8576
    v.ld.gather.w v34, [s27, v9]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v35, [s27, v16]                // index is in elements (ISA sec 9.1)
    s.addi       s36, s28, #8640
    v.st.w       [s11, #0], v22
    v.movi       v22, #0
    v.st.w       [s30, #0], v23
    v.iota       v23                             // arange(0, VLEN)
    s.movz       s11, #0
    v.st.w       [s31, #0], v24
    v.extract    s30, v15, #0
    s.cmp.ge     s31, s29, s11
    v.movi       v24, #0
    v.st.w       [s32, #0], v26
    v.splat      v26, s30
    v.add        v36, v26, v23
    v.st.w       [s33, #0], v25
    v.sub        v25, v15, v36
    v.reduce.or  s32, v25
    v.st.w       [s34, #0], v28
    s.cmp.eq     s33, s32, s11
    s.cmp.ge     s32, s30, s11
    v.st.w       [s35, #0], v19
    s.and        s34, s33, s32
    s.and        s32, s34, s31
    v.st.w       [s36, #0], v30
    fence.acq_rel.device
    v.extract    s33, v13, #0
    v.extract    s34, v14, #0
    v.splat      v19, s33
    v.splat      v25, s34
    s.cmp.ge     s35, s33, s11
    v.add        v26, v19, v23
    v.add        v19, v25, v23
    v.insert     v22, s32, #0
    v.sub        v25, v13, v26
    v.sub        v26, v14, v19
    v.insert     v24, s30, #0
    v.reduce.or  s30, v25
    v.reduce.or  s32, v26
    s.cmp.eq     s36, s30, s11
    v.extract    s30, v12, #0
    s.and        s37, s36, s35
    v.splat      v19, s30
    s.cmp.eq     s35, s32, s11
    s.cmp.ge     s32, s34, s11
    s.and        s36, s37, s31
    v.add        v25, v19, v23
    s.and        s37, s35, s32
    v.insert     v22, s36, #1
    v.sub        v19, v12, v25
    s.and        s32, s37, s31
    v.insert     v24, s33, #1
    v.extract    s33, v11, #0
    v.reduce.or  s35, v19
    v.splat      v19, s33
    s.cmp.eq     s36, s35, s11
    s.cmp.ge     s35, s30, s11
    v.add        v25, v19, v23
    s.and        s37, s36, s35
    v.insert     v22, s32, #2
    v.sub        v19, v11, v25
    s.and        s32, s37, s31
    v.insert     v24, s34, #2
    v.extract    s34, v10, #0
    v.reduce.or  s35, v19
    v.splat      v19, s34
    s.cmp.eq     s36, s35, s11
    s.cmp.ge     s35, s33, s11
    v.add        v25, v19, v23
    s.and        s11, s36, s35
    v.insert     v22, s32, #3
    v.sub        v19, v10, v25
    s.and        s32, s11, s31
    v.insert     v24, s30, #3
    v.extract    s11, v5, #0
    v.reduce.or  s30, v19
    v.splat      v19, s11
    s.movz       s35, #0
    v.insert     v22, s32, #4
    v.add        v25, v19, v23
    s.cmp.eq     s32, s30, s35
    s.cmp.ge     s30, s34, s35
    v.insert     v24, s33, #4
    v.extract    s33, v1, #0
    v.sub        v19, v5, v25
    s.and        s36, s32, s30
    v.splat      v25, s33
    v.reduce.or  s30, v19
    s.cmp.ge     s32, s11, s35
    s.cmp.eq     s37, s30, s35
    s.and        s30, s36, s31
    v.add        v19, v25, v23
    s.and        s36, s37, s32
    v.insert     v22, s30, #5
    v.sub        v23, v1, v19
    s.and        s30, s36, s31
    v.insert     v24, s34, #5
    v.reduce.or  s32, v23
    s.cmp.ge     s34, s33, s35
    s.cmp.eq     s36, s32, s35
    v.insert     v22, s30, #6
    s.and        s30, s36, s34
    v.insert     v24, s11, #6
    s.and        s11, s30, s31
    s.add        s30, s10, s26
    v.insert     v22, s11, #7
    s.addi       s11, s28, #8704                 // TensorMap 0: W's rows for a transposed FP8 B
    .li       s31, #2147483647
    s.movz       s32, #1
    .li       s34, #137438953488
    .li       s35, #7705171329024
    v.insert     v24, s33, #7
    s.addi       s33, s28, #8960
    s.addi       s36, s28, #9984                 // TensorMap 1: the gathered fallback B tile
    s.st.d       [s11, #0], s30
    s.movz       s30, #32
    s.st.d       [s11, #8], s31
    s.movz       s31, #16
    s.st.d       [s11, #16], s29
    s.st.d       [s11, #48], s18
    s.st.d       [s11, #56], s32
    .li       s37, #68719476768
    s.st.d       [s11, #88], s34
    s.st.d       [s11, #104], s35
    fence.release.device
    s.addi       s34, s28, #9472
    td.load      d0, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s11, s28, #10240                // TensorMap 2: the gathered fallback B tile
    s.st.d       [s36, #0], s33
    s.st.d       [s36, #8], s30
    s.st.d       [s36, #16], s31
    s.st.d       [s36, #48], s31
    s.st.d       [s36, #56], s32
    s.st.d       [s36, #88], s37
    s.st.d       [s36, #104], s35
    fence.release.device
    td.load      d1, [s36]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s36, #0
    s.st.d       [s11, #0], s34
    s.st.d       [s11, #8], s30
    s.st.d       [s11, #16], s31
    v.extract    s34, v22, #0
    s.st.d       [s11, #48], s31
    s.st.d       [s11, #56], s32
    s.st.d       [s11, #88], s37
    s.st.d       [s11, #104], s35
    fence.release.device
    td.load      d2, [s11]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s34, x8dot_done_28
    s.addi       s11, s28, #8192
    s.addi       s31, s36, #0
    v.ld.w       v19, [s11, #0]
    s.add        s11, s10, s26
x8dot_row_29:
    s.addi       s32, s29, #0
    v.movi       v23, #0
    s.sub        s35, s32, s31
    s.add        s32, s11, s31
    v.splat      v25, s35
    s.shli       s35, s31, #4
    v.cmp.gt     p1, v25, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s32, v19]            // index is in elements (ISA sec 9.1)
    s.add        s32, s33, s35
    s.addi       s35, s31, #1
    v.st.b       [s32, #0], v23
    fence.acq_rel.device
    s.mov        s31, s35
    s.cmp.lt     s32, s31, s30
    br.nz        s32, x8dot_row_29
x8dot_done_28:
    v.splat      v19, s34
    v.movi       v23, #0
    mb.arm       s11, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s30, v24, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s31, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s31, s11            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s31, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s31, s11          // predicated off still completes once (ISA sec 9A.3)
    v.extract    s30, v22, #1
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s30, x8dot_done_30
    s.movz       s31, #0
    s.addi       s32, s28, #8256
    s.addi       s33, s31, #0
    v.ld.w       v19, [s32, #0]
    s.add        s31, s10, s26
    s.addi       s32, s28, #9472
x8dot_row_31:
    s.addi       s34, s29, #0
    v.movi       v23, #0
    s.sub        s35, s34, s33
    s.add        s34, s31, s33
    v.splat      v25, s35
    s.shli       s35, s33, #4
    v.cmp.gt     p1, v25, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s34, v19]            // index is in elements (ISA sec 9.1)
    s.add        s34, s32, s35
    s.addi       s35, s33, #1
    s.movz       s36, #32
    v.st.b       [s34, #0], v23
    fence.acq_rel.device
    s.mov        s33, s35
    s.cmp.lt     s34, s33, s36
    br.nz        s34, x8dot_row_31
x8dot_done_30:
    v.extract    s31, v29, #0
    v.splat      v19, s30
    v.splat      v23, s31
    v.movi       v25, #0
    mb.arm       s30, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    vf.max.ieee  v26, v23, v0
    s.movz       s31, #0
    v.extract    s32, v24, #1
    v.cmp.ne     p1, v19, v25
    v.cmp.eq     p2, v19, v25
    v.rcp.approx v19, v26                        // ISA 8.8: <= 2**-22 relative
    s.mov        s33, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s33, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s33, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s30          // predicated off still completes once (ISA sec 9A.3)
    s.addi       s31, s28, #0
    s.addi       s32, s28, #10496                // 512 bytes of repack scratch
    v.ld.w       v23, [s31, #0]
    v.movi       v25, #24
    v.movi       v28, #128
    vf.fms       v30, v26, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s31, s32, #0
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v23, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v26, v23
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #1
    v.splat      v19, s31
    s.addi       s31, s28, #64
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #32
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #2
    v.splat      v19, s31
    s.addi       s31, s28, #128
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #64
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #3
    v.splat      v19, s31
    s.addi       s31, s28, #192
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #96
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #4
    v.splat      v19, s31
    s.addi       s31, s28, #256
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #128
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #5
    v.splat      v19, s31
    s.addi       s31, s28, #320
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #160
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #6
    v.splat      v19, s31
    s.addi       s31, s28, #384
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #192
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #7
    v.splat      v19, s31
    s.addi       s31, s28, #448
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #224
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #8
    v.splat      v19, s31
    s.addi       s31, s28, #512
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #256
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #9
    v.splat      v19, s31
    s.addi       s31, s28, #576
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #288
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #10
    v.splat      v19, s31
    s.addi       s31, s28, #640
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #320
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #11
    v.splat      v19, s31
    s.addi       s31, s28, #704
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #352
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #12
    v.splat      v19, s31
    s.addi       s31, s28, #768
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #384
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #13
    v.splat      v19, s31
    s.addi       s31, s28, #832
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #416
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #14
    v.splat      v19, s31
    s.addi       s31, s28, #896
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #448
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #15
    v.splat      v19, s31
    s.addi       s31, s28, #960
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #480
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #0
    v.splat      v19, s31
    s.addi       s31, s28, #1024
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #16
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #1
    v.splat      v19, s31
    s.addi       s31, s28, #1088
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #48
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #2
    v.splat      v19, s31
    s.addi       s31, s28, #1152
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #80
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #3
    v.splat      v19, s31
    s.addi       s31, s28, #1216
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #112
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #4
    v.splat      v19, s31
    s.addi       s31, s28, #1280
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #144
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #5
    v.splat      v19, s31
    s.addi       s31, s28, #1344
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #176
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #6
    v.splat      v19, s31
    s.addi       s31, s28, #1408
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #208
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #7
    v.splat      v19, s31
    s.addi       s31, s28, #1472
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #240
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #8
    v.splat      v19, s31
    s.addi       s31, s28, #1536
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #272
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #9
    v.splat      v19, s31
    s.addi       s31, s28, #1600
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #304
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #10
    v.splat      v19, s31
    s.addi       s31, s28, #1664
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #336
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #11
    v.splat      v19, s31
    s.addi       s31, s28, #1728
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #368
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #12
    v.splat      v19, s31
    s.addi       s31, s28, #1792
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #400
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #13
    v.splat      v19, s31
    s.addi       s31, s28, #1856
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #432
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #14
    v.splat      v19, s31
    s.addi       s31, s28, #1920
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #464
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #15
    v.splat      v19, s31
    s.addi       s31, s28, #1984
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s31, #0]
    s.addi       s31, s32, #496
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s31, s32, #64
    v.ld.w       v19, [s32, #0]
    v.mov        v56, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s32, #128
    v.mov        v57, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s32, #192
    v.mov        v58, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s32, #256
    v.mov        v59, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s32, #320
    v.mov        v60, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s31, #0]
    s.addi       s31, s32, #384
    s.addi       s33, s32, #448
    v.mov        v61, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s31, #0]
    v.extract    s31, v22, #2
    v.mov        v62, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s33, #0]
    v.mov        v63, v19                        // hand off through the shared window (sec 7.3)
    mb.wait      s11
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s32
    mb.wait      s32
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s31, x8dot_done_32
    s.movz       s33, #0
    s.addi       s34, s28, #8320
    s.addi       s35, s33, #0
    v.ld.w       v19, [s34, #0]
    s.add        s33, s10, s26
    s.addi       s34, s28, #8960
x8dot_row_33:
    s.addi       s36, s29, #0
    v.movi       v23, #0
    s.sub        s37, s36, s35
    s.add        s36, s33, s35
    v.splat      v26, s37
    s.shli       s37, s35, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s36, v19]            // index is in elements (ISA sec 9.1)
    s.add        s36, s34, s37
    s.addi       s37, s35, #1
    s.movz       s38, #32
    v.st.b       [s36, #0], v23
    fence.acq_rel.device
    s.mov        s35, s37
    s.cmp.lt     s36, s35, s38
    br.nz        s36, x8dot_row_33
x8dot_done_32:
    v.splat      v19, s31
    v.movi       v23, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    v.extract    s34, v24, #2
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s35, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s35, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s35, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s34, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v22, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s34
    mb.wait      s34
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s35, x8dot_done_34
    s.addi       s36, s28, #8384
    s.addi       s37, s33, #0
    v.ld.w       v19, [s36, #0]
    s.add        s36, s10, s26
    s.addi       s38, s28, #9472
x8dot_row_35:
    s.addi       s39, s29, #0
    v.movi       v23, #0
    s.sub        s40, s39, s37
    s.add        s39, s36, s37
    v.splat      v26, s40
    s.shli       s40, s37, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s39, v19]            // index is in elements (ISA sec 9.1)
    s.add        s39, s38, s40
    s.addi       s40, s37, #1
    s.movz       s41, #32
    v.st.b       [s39, #0], v23
    fence.acq_rel.device
    s.mov        s37, s40
    s.cmp.lt     s39, s37, s41
    br.nz        s39, x8dot_row_35
x8dot_done_34:
    v.splat      v19, s35
    v.movi       v23, #0
    mb.arm       s35, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s36, v24, #3
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s37, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v22, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s36
    mb.wait      s36
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s37, x8dot_done_36
    s.addi       s38, s28, #8448
    s.addi       s39, s33, #0
    v.ld.w       v19, [s38, #0]
    s.add        s33, s10, s26
    s.addi       s38, s28, #8960
x8dot_row_37:
    s.addi       s40, s29, #0
    v.movi       v23, #0
    s.sub        s41, s40, s39
    s.add        s40, s33, s39
    v.splat      v26, s41
    s.shli       s41, s39, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s40, v19]            // index is in elements (ISA sec 9.1)
    s.add        s40, s38, s41
    s.addi       s41, s39, #1
    s.movz       s42, #32
    v.st.b       [s40, #0], v23
    fence.acq_rel.device
    s.mov        s39, s41
    s.cmp.lt     s40, s39, s42
    br.nz        s40, x8dot_row_37
x8dot_done_36:
    v.splat      v19, s37
    v.movi       v23, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    v.extract    s38, v24, #4
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s39, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s39, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s39, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s38, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v22, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s38
    mb.wait      s38
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s39, x8dot_done_38
    s.addi       s40, s28, #8512
    s.addi       s41, s37, #0
    v.ld.w       v19, [s40, #0]
    s.add        s40, s10, s26
    s.addi       s42, s28, #9472
x8dot_row_39:
    s.addi       s43, s29, #0
    v.movi       v23, #0
    s.sub        s44, s43, s41
    s.add        s43, s40, s41
    v.splat      v26, s44
    s.shli       s44, s41, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s43, v19]            // index is in elements (ISA sec 9.1)
    s.add        s43, s42, s44
    s.addi       s44, s41, #1
    s.movz       s45, #32
    v.st.b       [s43, #0], v23
    fence.acq_rel.device
    s.mov        s41, s44
    s.cmp.lt     s43, s41, s45
    br.nz        s43, x8dot_row_39
x8dot_done_38:
    v.splat      v19, s39
    v.movi       v23, #0
    mb.arm       s39, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s40, v24, #5
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s41, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v22, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s40
    mb.wait      s40
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s41, x8dot_done_40
    s.addi       s42, s28, #8576
    s.addi       s43, s37, #0
    v.ld.w       v19, [s42, #0]
    s.add        s37, s10, s26
    s.addi       s42, s28, #8960
x8dot_row_41:
    s.addi       s44, s29, #0
    v.movi       v23, #0
    s.sub        s45, s44, s43
    s.add        s44, s37, s43
    v.splat      v26, s45
    s.shli       s45, s43, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s44, v19]            // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.addi       s45, s43, #1
    s.movz       s46, #32
    v.st.b       [s44, #0], v23
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s44, s43, s46
    br.nz        s44, x8dot_row_41
x8dot_done_40:
    v.splat      v19, s41
    v.movi       v23, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    v.extract    s42, v24, #6
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s43, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s42, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v22, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s42
    mb.wait      s42
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s43, x8dot_done_42
    s.addi       s44, s28, #8640
    s.addi       s45, s41, #0
    v.ld.w       v19, [s44, #0]
    s.add        s44, s10, s26
    s.addi       s46, s28, #9472
x8dot_row_43:
    s.addi       s47, s29, #0
    v.movi       v23, #0
    s.sub        s48, s47, s45
    s.add        s47, s44, s45
    v.splat      v26, s48
    s.shli       s48, s45, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s47, v19]            // index is in elements (ISA sec 9.1)
    s.add        s47, s46, s48
    s.addi       s48, s45, #1
    s.movz       s49, #32
    v.st.b       [s47, #0], v23
    fence.acq_rel.device
    s.mov        s45, s48
    s.cmp.lt     s47, s45, s49
    br.nz        s47, x8dot_row_43
x8dot_done_42:
    v.splat      v19, s43
    v.movi       v23, #0
    mb.arm       s43, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s44, v24, #7
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s45, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v22, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s44
    mb.wait      s44
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s45, x8dot_done_44
    s.addi       s46, s28, #8192
    s.add        s47, s10, s26
    s.addi       s48, s41, #0
    v.ld.w       v19, [s46, #0]
    s.addi       s41, s47, #32
    s.addi       s46, s28, #8960
x8dot_row_45:
    s.addi       s47, s29, #-32
    v.movi       v23, #0
    s.sub        s49, s47, s48
    s.add        s47, s41, s48
    v.splat      v26, s49
    s.shli       s49, s48, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s47, v19]            // index is in elements (ISA sec 9.1)
    s.add        s47, s46, s49
    s.addi       s49, s48, #1
    s.movz       s50, #32
    v.st.b       [s47, #0], v23
    fence.acq_rel.device
    s.mov        s48, s49
    s.cmp.lt     s47, s48, s50
    br.nz        s47, x8dot_row_45
x8dot_done_44:
    v.splat      v19, s45
    v.movi       v23, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    v.extract    s46, v24, #0
    s.movz       s47, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s48, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s48, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s48, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s48, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s46, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v22, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s46
    mb.wait      s46
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s48, x8dot_done_46
    s.addi       s49, s28, #8256
    s.add        s50, s10, s26
    s.addi       s51, s45, #0
    v.ld.w       v19, [s49, #0]
    s.addi       s49, s50, #32
    s.addi       s50, s28, #9472
x8dot_row_47:
    s.addi       s52, s29, #-32
    v.movi       v23, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v26, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s52, v19]            // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    v.st.b       [s52, #0], v23
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s47
    br.nz        s52, x8dot_row_47
x8dot_done_46:
    v.splat      v19, s48
    v.extract    s48, v29, #0
    v.movi       v23, #0
    v.splat      v26, s48
    mb.arm       s48, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s49, v24, #1
    vf.max.ieee  v30, v26, v0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s50, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s50, s48            // predicated off still completes once (ISA sec 9A.3)
    s.addi       s45, s28, #2048
    v.rcp.approx v19, v30                        // ISA 8.8: <= 2**-22 relative
    s.mov        s50, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s48          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v23, [s45, #0]
    s.addi       s45, s28, #11008                // 512 bytes of repack scratch
    s.addi       s47, s45, #0
    vf.fms       v26, v30, v19, v20
    vf.fms       v36, v19, v26, v19
    s.addi       s49, s28, #2112
    vf.neg       v26, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v36, v26, v19
    vf.mul       v19, v23, v36                   // a/y: faithful quotient
    vf.fms       v26, v19, v30, v23
    vf.fms       v23, v26, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #1
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #32
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #2176
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #2
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #64
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #2240
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #3
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #96
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #2304
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #4
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #128
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #2368
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #5
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #160
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #2432
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #6
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #192
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #2496
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #7
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #224
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #2560
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #8
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #256
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #2624
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #9
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #288
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #2688
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #10
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #320
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #2752
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #11
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #352
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #2816
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #12
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #384
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #2880
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #13
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #416
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #2944
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #14
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #448
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3008
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #15
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #480
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3072
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #0
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #16
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3136
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #1
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #48
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3200
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #2
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #80
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3264
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #3
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #112
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3328
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #4
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #144
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3392
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #5
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #176
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3456
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #6
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #208
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3520
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #7
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #240
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3584
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #8
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #272
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3648
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #9
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #304
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3712
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #10
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #336
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3776
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #11
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #368
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3840
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #12
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #400
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3904
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #13
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #432
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #3968
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #14
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #464
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s49, s28, #4032
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    v.extract    s47, v29, #15
    v.splat      v19, s47
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s49, #0]
    s.addi       s47, s45, #496
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    s.addi       s49, s45, #64
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s47, #0], v19
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s47, s45, #128
    v.ld.w       v19, [s45, #0]
    v.mov        v56, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s49, #0]
    s.addi       s49, s45, #192
    v.mov        v57, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s47, #0]
    s.addi       s47, s45, #256
    v.mov        v58, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s49, #0]
    s.addi       s49, s45, #320
    v.mov        v59, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s47, #0]
    s.addi       s47, s45, #384
    s.addi       s50, s45, #448
    v.mov        v60, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s49, #0]
    v.extract    s45, v22, #2
    v.mov        v61, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s47, #0]
    v.mov        v62, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s50, #0]
    v.mov        v63, v19                        // hand off through the shared window (sec 7.3)
    mb.wait      s41
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s47
    mb.wait      s47
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s45, x8dot_done_48
    s.movz       s49, #0
    s.addi       s50, s28, #8320
    s.add        s51, s10, s26
    s.addi       s52, s49, #0
    v.ld.w       v19, [s50, #0]
    s.addi       s49, s51, #32
    s.addi       s50, s28, #8960
x8dot_row_49:
    s.addi       s51, s29, #-32
    v.movi       v23, #0
    s.sub        s53, s51, s52
    s.add        s51, s49, s52
    v.splat      v26, s53
    s.shli       s53, s52, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s51, v19]            // index is in elements (ISA sec 9.1)
    s.add        s51, s50, s53
    s.addi       s53, s52, #1
    s.movz       s54, #32
    v.st.b       [s51, #0], v23
    fence.acq_rel.device
    s.mov        s52, s53
    s.cmp.lt     s51, s52, s54
    br.nz        s51, x8dot_row_49
x8dot_done_48:
    v.splat      v19, s45
    v.movi       v23, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    v.extract    s50, v24, #2
    s.movz       s51, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s52, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s52, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s52, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s50, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v22, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s50
    mb.wait      s50
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s52, x8dot_done_50
    s.addi       s53, s28, #8384
    s.add        s54, s10, s26
    s.addi       s55, s49, #0
    v.ld.w       v19, [s53, #0]
    s.addi       s53, s54, #32
    s.addi       s54, s28, #9472
x8dot_row_51:
    s.addi       s56, s29, #-32
    v.movi       v23, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v26, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s56, v19]            // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    v.st.b       [s56, #0], v23
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s51
    br.nz        s56, x8dot_row_51
x8dot_done_50:
    v.splat      v19, s52
    v.movi       v23, #0
    mb.arm       s52, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s53, v24, #3
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s54, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s54, s52            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v22, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s51
    mb.wait      s51
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s53, x8dot_done_52
    s.addi       s54, s28, #8448
    s.add        s55, s10, s26
    s.addi       s56, s49, #0
    v.ld.w       v19, [s54, #0]
    s.addi       s49, s55, #32
    s.addi       s54, s28, #8960
x8dot_row_53:
    s.addi       s55, s29, #-32
    v.movi       v23, #0
    s.sub        s57, s55, s56
    s.add        s55, s49, s56
    v.splat      v26, s57
    s.shli       s57, s56, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s55, v19]            // index is in elements (ISA sec 9.1)
    s.add        s55, s54, s57
    s.addi       s57, s56, #1
    s.movz       s58, #32
    v.st.b       [s55, #0], v23
    fence.acq_rel.device
    s.mov        s56, s57
    s.cmp.lt     s55, s56, s58
    br.nz        s55, x8dot_row_53
x8dot_done_52:
    v.splat      v19, s53
    v.movi       v23, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    v.extract    s54, v24, #4
    s.movz       s55, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s56, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s56, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s56, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s54, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v22, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s54
    mb.wait      s54
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s56, x8dot_done_54
    s.addi       s57, s28, #8512
    s.add        s58, s10, s26
    s.addi       s59, s53, #0
    v.ld.w       v19, [s57, #0]
    s.addi       s57, s58, #32
    s.addi       s58, s28, #9472
x8dot_row_55:
    s.addi       s60, s29, #-32
    v.movi       v23, #0
    s.sub        s11, s60, s59
    s.add        s30, s57, s59
    v.splat      v26, s11
    s.shli       s11, s59, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s30, v19]            // index is in elements (ISA sec 9.1)
    s.add        s30, s58, s11
    s.addi       s11, s59, #1
    v.st.b       [s30, #0], v23
    fence.acq_rel.device
    s.mov        s59, s11
    s.cmp.lt     s11, s59, s55
    br.nz        s11, x8dot_row_55
x8dot_done_54:
    v.splat      v19, s56
    v.movi       v23, #0
    mb.arm       s11, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s30, v24, #5
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s31, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s31, s11            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s31, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s31, s11          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s31, v22, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s30
    mb.wait      s30
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s31, x8dot_done_56
    s.addi       s32, s28, #8576
    s.add        s33, s10, s26
    s.addi       s34, s53, #0
    v.ld.w       v19, [s32, #0]
    s.addi       s32, s33, #32
    s.addi       s33, s28, #8960
x8dot_row_57:
    s.addi       s35, s29, #-32
    v.movi       v23, #0
    s.sub        s36, s35, s34
    s.add        s35, s32, s34
    v.splat      v26, s36
    s.shli       s36, s34, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s35, v19]            // index is in elements (ISA sec 9.1)
    s.add        s35, s33, s36
    s.addi       s36, s34, #1
    s.movz       s37, #32
    v.st.b       [s35, #0], v23
    fence.acq_rel.device
    s.mov        s34, s36
    s.cmp.lt     s35, s34, s37
    br.nz        s35, x8dot_row_57
x8dot_done_56:
    v.splat      v19, s31
    v.movi       v23, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    v.extract    s33, v24, #6
    s.movz       s34, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s35, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s35, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s11
    mb.arm       s33, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v22, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s33
    mb.wait      s33
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s35, x8dot_done_58
    s.addi       s36, s28, #8640
    s.add        s37, s10, s26
    s.addi       s38, s32, #0
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s37, #32
    s.addi       s37, s28, #9472
x8dot_row_59:
    s.addi       s39, s29, #-32
    v.movi       v23, #0
    s.sub        s40, s39, s38
    s.add        s39, s36, s38
    v.splat      v26, s40
    s.shli       s40, s38, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s39, v19]            // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.addi       s40, s38, #1
    v.st.b       [s39, #0], v23
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s39, s38, s34
    br.nz        s39, x8dot_row_59
x8dot_done_58:
    v.splat      v19, s35
    v.movi       v23, #0
    mb.arm       s35, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s36, v24, #7
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s37, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v22, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s34
    mb.wait      s34
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s36, x8dot_done_60
    s.addi       s37, s28, #8192
    s.add        s38, s10, s26
    s.addi       s39, s32, #0
    v.ld.w       v19, [s37, #0]
    s.addi       s32, s38, #64
    s.addi       s37, s28, #8960
x8dot_row_61:
    s.addi       s38, s29, #-64
    v.movi       v23, #0
    s.sub        s40, s38, s39
    s.add        s38, s32, s39
    v.splat      v26, s40
    s.shli       s40, s39, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s38, v19]            // index is in elements (ISA sec 9.1)
    s.add        s38, s37, s40
    s.addi       s40, s39, #1
    s.movz       s41, #32
    v.st.b       [s38, #0], v23
    fence.acq_rel.device
    s.mov        s39, s40
    s.cmp.lt     s38, s39, s41
    br.nz        s38, x8dot_row_61
x8dot_done_60:
    v.splat      v19, s36
    v.movi       v23, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    v.extract    s37, v24, #0
    s.movz       s38, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s39, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s39, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s39, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s37, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v22, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s37
    mb.wait      s37
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s39, x8dot_done_62
    s.addi       s40, s28, #8256
    s.add        s41, s10, s26
    s.addi       s42, s36, #0
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s41, #64
    s.addi       s41, s28, #9472
x8dot_row_63:
    s.addi       s43, s29, #-64
    v.movi       v23, #0
    s.sub        s44, s43, s42
    s.add        s43, s40, s42
    v.splat      v26, s44
    s.shli       s44, s42, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s43, v19]            // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.addi       s44, s42, #1
    s.movz       s45, #32
    v.st.b       [s43, #0], v23
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s43, s42, s45
    br.nz        s43, x8dot_row_63
x8dot_done_62:
    v.splat      v19, s39
    v.extract    s39, v29, #0
    v.movi       v23, #0
    v.splat      v26, s39
    mb.arm       s39, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s40, v24, #1
    vf.max.ieee  v30, v26, v0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s41, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s41, s39            // predicated off still completes once (ISA sec 9A.3)
    s.addi       s36, s28, #4096
    v.rcp.approx v19, v30                        // ISA 8.8: <= 2**-22 relative
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s39          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v23, [s36, #0]
    s.addi       s36, s28, #11520                // 512 bytes of repack scratch
    s.addi       s38, s36, #0
    vf.fms       v26, v30, v19, v20
    vf.fms       v36, v19, v26, v19
    s.addi       s40, s28, #4160
    vf.neg       v26, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v36, v26, v19
    vf.mul       v19, v23, v36                   // a/y: faithful quotient
    vf.fms       v26, v19, v30, v23
    vf.fms       v23, v26, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #1
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #32
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #4224
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #2
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #64
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #4288
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #3
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #96
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #4352
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #4
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #128
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #4416
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #5
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #160
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #4480
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #6
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #192
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #4544
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #7
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #224
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #4608
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #8
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #256
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #4672
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #9
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #288
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #4736
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #10
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #320
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #4800
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #11
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #352
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #4864
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #12
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #384
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #4928
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #13
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #416
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #4992
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #14
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #448
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5056
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #15
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #480
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5120
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #0
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #16
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5184
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #1
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #48
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5248
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #2
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #80
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5312
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #3
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #112
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5376
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #4
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #144
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5440
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #5
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #176
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5504
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #6
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #208
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5568
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #7
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #240
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5632
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #8
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #272
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5696
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #9
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #304
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5760
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #10
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #336
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5824
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #11
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #368
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5888
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #12
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #400
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #5952
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #13
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #432
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #6016
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #14
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #464
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s40, s28, #6080
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    v.extract    s38, v29, #15
    v.splat      v19, s38
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s40, #0]
    s.addi       s38, s36, #496
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    s.addi       s40, s36, #64
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s38, #0], v19
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s38, s36, #128
    v.ld.w       v19, [s36, #0]
    v.mov        v56, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s36, #192
    v.mov        v57, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s36, #256
    v.mov        v58, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s36, #320
    v.mov        v59, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s38, #0]
    s.addi       s38, s36, #384
    s.addi       s41, s36, #448
    v.mov        v60, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s40, #0]
    v.extract    s36, v22, #2
    v.mov        v61, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s38, #0]
    v.mov        v62, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s41, #0]
    v.mov        v63, v19                        // hand off through the shared window (sec 7.3)
    mb.wait      s32
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s38
    mb.wait      s38
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s36, x8dot_done_64
    s.movz       s40, #0
    s.addi       s41, s28, #8320
    s.add        s42, s10, s26
    s.addi       s43, s40, #0
    v.ld.w       v19, [s41, #0]
    s.addi       s40, s42, #64
    s.addi       s41, s28, #8960
x8dot_row_65:
    s.addi       s42, s29, #-64
    v.movi       v23, #0
    s.sub        s44, s42, s43
    s.add        s42, s40, s43
    v.splat      v26, s44
    s.shli       s44, s43, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s42, v19]            // index is in elements (ISA sec 9.1)
    s.add        s42, s41, s44
    s.addi       s44, s43, #1
    s.movz       s45, #32
    v.st.b       [s42, #0], v23
    fence.acq_rel.device
    s.mov        s43, s44
    s.cmp.lt     s42, s43, s45
    br.nz        s42, x8dot_row_65
x8dot_done_64:
    v.splat      v19, s36
    v.movi       v23, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.extract    s41, v24, #2
    s.movz       s42, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s43, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s41, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v22, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s41
    mb.wait      s41
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s43, x8dot_done_66
    s.addi       s44, s28, #8384
    s.add        s45, s10, s26
    s.addi       s46, s40, #0
    v.ld.w       v19, [s44, #0]
    s.addi       s44, s45, #64
    s.addi       s45, s28, #9472
x8dot_row_67:
    s.addi       s47, s29, #-64
    v.movi       v23, #0
    s.sub        s48, s47, s46
    s.add        s47, s44, s46
    v.splat      v26, s48
    s.shli       s48, s46, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s47, v19]            // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s48
    s.addi       s48, s46, #1
    s.movz       s50, #32
    v.st.b       [s47, #0], v23
    fence.acq_rel.device
    s.mov        s46, s48
    s.cmp.lt     s47, s46, s50
    br.nz        s47, x8dot_row_67
x8dot_done_66:
    v.splat      v19, s43
    v.movi       v23, #0
    mb.arm       s43, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s44, v24, #3
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s45, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s45, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v22, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s42
    mb.wait      s42
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s44, x8dot_done_68
    s.addi       s45, s28, #8448
    s.add        s46, s10, s26
    s.addi       s47, s40, #0
    v.ld.w       v19, [s45, #0]
    s.addi       s40, s46, #64
    s.addi       s45, s28, #8960
x8dot_row_69:
    s.addi       s46, s29, #-64
    v.movi       v23, #0
    s.sub        s48, s46, s47
    s.add        s46, s40, s47
    v.splat      v26, s48
    s.shli       s48, s47, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s46, v19]            // index is in elements (ISA sec 9.1)
    s.add        s46, s45, s48
    s.addi       s48, s47, #1
    s.movz       s50, #32
    v.st.b       [s46, #0], v23
    fence.acq_rel.device
    s.mov        s47, s48
    s.cmp.lt     s46, s47, s50
    br.nz        s46, x8dot_row_69
x8dot_done_68:
    v.splat      v19, s44
    v.movi       v23, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    v.extract    s45, v24, #4
    s.movz       s46, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s47, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s47, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s47, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s45, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v22, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s45
    mb.wait      s45
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s47, x8dot_done_70
    s.addi       s48, s28, #8512
    s.add        s50, s10, s26
    s.addi       s51, s44, #0
    v.ld.w       v19, [s48, #0]
    s.addi       s48, s50, #64
    s.addi       s50, s28, #9472
x8dot_row_71:
    s.addi       s52, s29, #-64
    v.movi       v23, #0
    s.sub        s53, s52, s51
    s.add        s52, s48, s51
    v.splat      v26, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s52, v19]            // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    s.movz       s54, #32
    v.st.b       [s52, #0], v23
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s54
    br.nz        s52, x8dot_row_71
x8dot_done_70:
    v.splat      v19, s47
    v.movi       v23, #0
    mb.arm       s47, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s48, v24, #5
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s50, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s50, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v22, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s46
    mb.wait      s46
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s48, x8dot_done_72
    s.addi       s50, s28, #8576
    s.add        s51, s10, s26
    s.addi       s52, s44, #0
    v.ld.w       v19, [s50, #0]
    s.addi       s44, s51, #64
    s.addi       s50, s28, #8960
x8dot_row_73:
    s.addi       s51, s29, #-64
    v.movi       v23, #0
    s.sub        s53, s51, s52
    s.add        s51, s44, s52
    v.splat      v26, s53
    s.shli       s53, s52, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s51, v19]            // index is in elements (ISA sec 9.1)
    s.add        s51, s50, s53
    s.addi       s53, s52, #1
    s.movz       s54, #32
    v.st.b       [s51, #0], v23
    fence.acq_rel.device
    s.mov        s52, s53
    s.cmp.lt     s51, s52, s54
    br.nz        s51, x8dot_row_73
x8dot_done_72:
    v.splat      v19, s48
    v.movi       v23, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s48, #0
    v.extract    s50, v24, #6
    s.movz       s51, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s52, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s52, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s50, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v22, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s50
    mb.wait      s50
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s52, x8dot_done_74
    s.addi       s53, s28, #8640
    s.add        s54, s10, s26
    s.addi       s55, s48, #0
    v.ld.w       v19, [s53, #0]
    s.addi       s53, s54, #64
    s.addi       s54, s28, #9472
x8dot_row_75:
    s.addi       s56, s29, #-64
    v.movi       v23, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v26, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s56, v19]            // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    s.movz       s58, #32
    v.st.b       [s56, #0], v23
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s58
    br.nz        s56, x8dot_row_75
x8dot_done_74:
    v.splat      v19, s52
    v.movi       v23, #0
    mb.arm       s52, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s53, v24, #7
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s54, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s54, s52            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v22, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s51
    mb.wait      s51
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s53, x8dot_done_76
    s.addi       s54, s28, #8192
    s.add        s55, s10, s26
    s.addi       s56, s48, #0
    v.ld.w       v19, [s54, #0]
    s.addi       s48, s55, #96
    s.addi       s54, s28, #8960
x8dot_row_77:
    s.addi       s55, s29, #-96
    v.movi       v23, #0
    s.sub        s57, s55, s56
    s.add        s55, s48, s56
    v.splat      v26, s57
    s.shli       s57, s56, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s55, v19]            // index is in elements (ISA sec 9.1)
    s.add        s55, s54, s57
    s.addi       s57, s56, #1
    s.movz       s58, #32
    v.st.b       [s55, #0], v23
    fence.acq_rel.device
    s.mov        s56, s57
    s.cmp.lt     s55, s56, s58
    br.nz        s55, x8dot_row_77
x8dot_done_76:
    v.splat      v19, s53
    v.movi       v23, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    v.extract    s54, v24, #0
    s.movz       s55, #96
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s56, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s56, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s56, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s54, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v22, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s54
    mb.wait      s54
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s56, x8dot_done_78
    s.addi       s57, s28, #8256
    s.add        s58, s10, s26
    s.addi       s59, s53, #0
    v.ld.w       v19, [s57, #0]
    s.addi       s57, s58, #96
    s.addi       s58, s28, #9472
x8dot_row_79:
    s.addi       s60, s29, #-96
    v.movi       v23, #0
    s.sub        s11, s60, s59
    s.add        s30, s57, s59
    v.splat      v26, s11
    s.shli       s11, s59, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s30, v19]            // index is in elements (ISA sec 9.1)
    s.add        s30, s58, s11
    s.addi       s11, s59, #1
    s.movz       s31, #32
    v.st.b       [s30, #0], v23
    fence.acq_rel.device
    s.mov        s59, s11
    s.cmp.lt     s11, s59, s31
    br.nz        s11, x8dot_row_79
x8dot_done_78:
    v.splat      v19, s56
    v.extract    s11, v29, #0
    v.movi       v23, #0
    v.splat      v26, s11
    mb.arm       s11, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s30, v24, #1
    vf.max.ieee  v30, v26, v0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s31, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s31, s11            // predicated off still completes once (ISA sec 9A.3)
    s.addi       s31, s28, #6144
    v.rcp.approx v19, v30                        // ISA 8.8: <= 2**-22 relative
    s.mov        s32, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s11          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v23, [s31, #0]
    s.addi       s30, s28, #12032                // 512 bytes of repack scratch
    s.addi       s31, s30, #0
    vf.fms       v26, v30, v19, v20
    vf.fms       v36, v19, v26, v19
    s.addi       s32, s28, #6208
    vf.neg       v26, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v36, v26, v19
    vf.mul       v19, v23, v36                   // a/y: faithful quotient
    vf.fms       v26, v19, v30, v23
    vf.fms       v23, v26, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #1
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #32
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #6272
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #2
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #64
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #6336
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #3
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #96
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #6400
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #4
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #128
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #6464
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #5
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #160
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #6528
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #6
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #192
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #6592
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #7
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #224
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #6656
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #8
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #256
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #6720
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #9
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #288
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #6784
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #10
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #320
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #6848
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #11
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #352
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #6912
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #12
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #384
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #6976
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #13
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #416
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7040
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #14
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #448
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7104
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #15
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #480
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7168
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #0
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #16
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7232
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #1
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #48
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7296
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #2
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #80
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7360
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #3
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #112
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7424
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #4
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #144
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7488
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #5
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #176
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7552
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #6
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #208
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7616
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #7
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #240
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7680
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #8
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #272
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7744
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #9
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #304
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7808
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #10
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #336
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7872
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #11
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #368
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #7936
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #12
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #400
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #8000
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #13
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #432
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #8064
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #14
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s32, #0]
    s.addi       s31, s30, #464
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s32, s28, #8128
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v19
    v.extract    s31, v29, #15
    v.splat      v19, s31
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v0, v23                         // ISA 8.8: <= 2**-22 relative
    v.ld.w       v19, [s32, #0]
    s.addi       s31, s30, #496
    vf.fms       v26, v23, v0, v20
    vf.fms       v20, v0, v26, v0
    vf.neg       v26, v20                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v20, v26, v0
    vf.mul       v0, v19, v20                    // a/y: faithful quotient
    s.addi       s32, s30, #64
    vf.fms       v26, v0, v23, v19
    vf.fms       v19, v26, v20, v0
    vf.neg       v20, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v19, v20, v0
    v.lshr       v0, v19, v25
    vf.cvt.f32.e4m3 v20, v19
    v.and        v19, v0, v28
    v.or         v0, v20, v19                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s31, #0], v0
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s31, s30, #128
    v.ld.w       v0, [s30, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s32, #0]
    s.addi       s32, s30, #192
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s31, #0]
    s.addi       s31, s30, #256
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s32, #0]
    s.addi       s32, s30, #320
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s31, #0]
    s.addi       s31, s30, #384
    s.addi       s33, s30, #448
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s32, #0]
    v.extract    s30, v22, #2
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s31, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s33, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.wait      s48
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s31
    mb.wait      s31
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s30, x8dot_done_80
    s.movz       s32, #0
    s.addi       s33, s28, #8320
    s.add        s34, s10, s26
    s.addi       s35, s32, #0
    v.ld.w       v0, [s33, #0]
    s.addi       s32, s34, #96
    s.addi       s33, s28, #8960
x8dot_row_81:
    s.addi       s34, s29, #-96
    v.movi       v19, #0
    s.sub        s36, s34, s35
    s.add        s34, s32, s35
    v.splat      v20, s36
    s.shli       s36, s35, #4
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s34, v0]             // index is in elements (ISA sec 9.1)
    s.add        s34, s33, s36
    s.addi       s36, s35, #1
    s.movz       s37, #32
    v.st.b       [s34, #0], v19
    fence.acq_rel.device
    s.mov        s35, s36
    s.cmp.lt     s34, s35, s37
    br.nz        s34, x8dot_row_81
x8dot_done_80:
    v.splat      v0, s30
    v.movi       v19, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    v.extract    s33, v24, #2
    s.movz       s34, #96
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s35, s30            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s35, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s11
    mb.arm       s33, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v22, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s33
    mb.wait      s33
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s35, x8dot_done_82
    s.addi       s36, s28, #8384
    s.add        s37, s10, s26
    s.addi       s38, s32, #0
    v.ld.w       v0, [s36, #0]
    s.addi       s36, s37, #96
    s.addi       s37, s28, #9472
x8dot_row_83:
    s.addi       s39, s29, #-96
    v.movi       v19, #0
    s.sub        s40, s39, s38
    s.add        s39, s36, s38
    v.splat      v20, s40
    s.shli       s40, s38, #4
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s39, v0]             // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.addi       s40, s38, #1
    s.movz       s41, #32
    v.st.b       [s39, #0], v19
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s39, s38, s41
    br.nz        s39, x8dot_row_83
x8dot_done_82:
    v.splat      v0, s35
    v.movi       v19, #0
    mb.arm       s35, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s36, v24, #3
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s37, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v22, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s34
    mb.wait      s34
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s36, x8dot_done_84
    s.addi       s37, s28, #8448
    s.add        s38, s10, s26
    s.addi       s39, s32, #0
    v.ld.w       v0, [s37, #0]
    s.addi       s32, s38, #96
    s.addi       s37, s28, #8960
x8dot_row_85:
    s.addi       s38, s29, #-96
    v.movi       v19, #0
    s.sub        s40, s38, s39
    s.add        s38, s32, s39
    v.splat      v20, s40
    s.shli       s40, s39, #4
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s38, v0]             // index is in elements (ISA sec 9.1)
    s.add        s38, s37, s40
    s.addi       s40, s39, #1
    s.movz       s41, #32
    v.st.b       [s38, #0], v19
    fence.acq_rel.device
    s.mov        s39, s40
    s.cmp.lt     s38, s39, s41
    br.nz        s38, x8dot_row_85
x8dot_done_84:
    v.splat      v0, s36
    v.movi       v19, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    v.extract    s37, v24, #4
    s.movz       s38, #96
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s39, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s39, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s39, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s37, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v22, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s37
    mb.wait      s37
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s39, x8dot_done_86
    s.addi       s40, s28, #8512
    s.add        s41, s10, s26
    s.addi       s42, s36, #0
    v.ld.w       v0, [s40, #0]
    s.addi       s40, s41, #96
    s.addi       s41, s28, #9472
x8dot_row_87:
    s.addi       s43, s29, #-96
    v.movi       v19, #0
    s.sub        s44, s43, s42
    s.add        s43, s40, s42
    v.splat      v20, s44
    s.shli       s44, s42, #4
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s43, v0]             // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.addi       s44, s42, #1
    s.movz       s45, #32
    v.st.b       [s43, #0], v19
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s43, s42, s45
    br.nz        s43, x8dot_row_87
x8dot_done_86:
    v.splat      v0, s39
    v.movi       v19, #0
    mb.arm       s39, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s40, v24, #5
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s41, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s41, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v22, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s38
    mb.wait      s38
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s40, x8dot_done_88
    s.addi       s41, s28, #8576
    s.add        s42, s10, s26
    s.addi       s43, s36, #0
    v.ld.w       v0, [s41, #0]
    s.addi       s36, s42, #96
    s.addi       s41, s28, #8960
x8dot_row_89:
    s.addi       s42, s29, #-96
    v.movi       v19, #0
    s.sub        s44, s42, s43
    s.add        s42, s36, s43
    v.splat      v20, s44
    s.shli       s44, s43, #4
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s42, v0]             // index is in elements (ISA sec 9.1)
    s.add        s42, s41, s44
    s.addi       s44, s43, #1
    s.movz       s45, #32
    v.st.b       [s42, #0], v19
    fence.acq_rel.device
    s.mov        s43, s44
    s.cmp.lt     s42, s43, s45
    br.nz        s42, x8dot_row_89
x8dot_done_88:
    v.splat      v0, s40
    v.movi       v19, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.extract    s41, v24, #6
    s.movz       s42, #96
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s43, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s41, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v22, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s41
    mb.wait      s41
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s43, x8dot_done_90
    s.addi       s44, s28, #8640
    s.add        s45, s10, s26
    s.addi       s46, s40, #0
    v.ld.w       v0, [s44, #0]
    s.addi       s44, s45, #96
    s.addi       s45, s28, #9472
x8dot_row_91:
    s.addi       s47, s29, #-96
    v.movi       v19, #0
    s.sub        s49, s47, s46
    s.add        s47, s44, s46
    v.splat      v20, s49
    s.shli       s49, s46, #4
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s47, v0]             // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s49
    s.addi       s49, s46, #1
    s.movz       s50, #32
    v.st.b       [s47, #0], v19
    fence.acq_rel.device
    s.mov        s46, s49
    s.cmp.lt     s47, s46, s50
    br.nz        s47, x8dot_row_91
x8dot_done_90:
    mb.arm       s29, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v0, s43
    v.movi       v19, #0
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s43, s29            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s43, v24, #7
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s29          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s42
    mb.wait      s42
    mb.wait      s29
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s43
    mb.wait      s43
    s.addi       s44, s28, #12544
    a.vread      v0, a8, s40
    v.st.w       [s44, #0], v0
    s.addi       s40, s44, #64
    s.movz       s45, #1
    a.vread      v0, a8, s45
    v.st.w       [s40, #0], v0
    s.addi       s40, s44, #128
    s.movz       s45, #2
    a.vread      v0, a8, s45
    v.st.w       [s40, #0], v0
    s.addi       s40, s44, #192
    s.movz       s45, #3
    a.vread      v0, a8, s45
    v.st.w       [s40, #0], v0
    s.addi       s40, s44, #256
    s.movz       s45, #4
    a.vread      v0, a8, s45
    v.st.w       [s40, #0], v0
    s.addi       s40, s44, #320
    s.movz       s45, #5
    a.vread      v0, a8, s45
    v.st.w       [s40, #0], v0
    s.addi       s40, s44, #384
    s.movz       s45, #6
    a.vread      v0, a8, s45
    v.st.w       [s40, #0], v0
    s.addi       s40, s44, #448
    s.movz       s45, #7
    a.vread      v0, a8, s45
    v.st.w       [s40, #0], v0
    s.addi       s40, s44, #512
    s.movz       s45, #8
    a.vread      v0, a8, s45
    v.st.w       [s40, #0], v0
    s.addi       s40, s44, #576
    s.movz       s45, #9
    a.vread      v0, a8, s45
    v.st.w       [s40, #0], v0
    s.addi       s40, s44, #640
    s.movz       s45, #10
    a.vread      v0, a8, s45
    v.st.w       [s40, #0], v0
    s.addi       s40, s44, #704
    s.movz       s45, #11
    a.vread      v0, a8, s45
    v.st.w       [s40, #0], v0
    s.addi       s40, s44, #768
    s.movz       s45, #12
    a.vread      v0, a8, s45
    v.st.w       [s40, #0], v0
    s.addi       s40, s44, #832
    s.movz       s45, #13
    a.vread      v0, a8, s45
    v.st.w       [s40, #0], v0
    s.addi       s40, s44, #896
    s.movz       s45, #14
    a.vread      v0, a8, s45
    v.st.w       [s40, #0], v0
    s.addi       s40, s44, #960
    s.movz       s44, #15
    a.vread      v0, a8, s44
    v.st.w       [s40, #0], v0
    fence.acq_rel.device
    s.addi       s40, s28, #13568
    s.movz       s44, #0
    a.vread      v0, a9, s44
    v.st.w       [s40, #0], v0
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a9, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a9, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a9, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a9, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a9, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a9, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a9, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a9, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a9, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a9, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a9, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a9, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a9, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a9, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a9, s40
    v.st.w       [s44, #0], v0
    fence.acq_rel.device
    s.addi       s40, s28, #14592
    s.movz       s44, #0
    a.vread      v0, a10, s44
    v.st.w       [s40, #0], v0
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a10, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a10, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a10, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a10, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a10, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a10, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a10, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a10, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a10, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a10, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a10, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a10, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a10, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a10, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a10, s40
    v.st.w       [s44, #0], v0
    fence.acq_rel.device
    s.addi       s40, s28, #15616
    s.movz       s44, #0
    a.vread      v0, a11, s44
    v.st.w       [s40, #0], v0
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a11, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a11, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a11, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a11, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a11, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a11, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a11, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a11, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a11, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a11, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a11, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a11, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a11, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a11, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a11, s40
    v.st.w       [s44, #0], v0
    fence.acq_rel.device
    s.addi       s40, s28, #16640
    s.movz       s44, #0
    a.vread      v0, a12, s44
    v.st.w       [s40, #0], v0
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a12, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a12, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a12, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a12, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a12, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a12, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a12, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a12, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a12, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a12, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a12, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a12, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a12, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a12, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a12, s40
    v.st.w       [s44, #0], v0
    fence.acq_rel.device
    s.addi       s40, s28, #17664
    s.movz       s44, #0
    a.vread      v0, a13, s44
    v.st.w       [s40, #0], v0
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a13, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a13, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a13, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a13, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a13, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a13, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a13, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a13, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a13, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a13, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a13, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a13, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a13, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a13, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a13, s40
    v.st.w       [s44, #0], v0
    fence.acq_rel.device
    s.addi       s40, s28, #18688
    s.movz       s44, #0
    a.vread      v0, a14, s44
    v.st.w       [s40, #0], v0
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a14, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a14, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a14, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a14, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a14, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a14, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a14, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a14, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a14, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a14, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a14, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a14, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a14, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a14, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a14, s40
    v.st.w       [s44, #0], v0
    fence.acq_rel.device
    s.addi       s40, s28, #19712
    s.movz       s44, #0
    a.vread      v0, a15, s44
    v.st.w       [s40, #0], v0
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a15, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a15, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a15, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a15, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a15, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a15, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a15, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a15, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a15, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a15, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a15, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a15, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a15, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a15, s45
    v.st.w       [s44, #0], v0
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a15, s40
    v.st.w       [s44, #0], v0
    fence.acq_rel.device
    s.addi       s40, s28, #20736
    s.movz       s44, #0
    a.vread      v0, a0, s44
    s.addi       s44, s28, #12544
    v.ld.w       v19, [s44, #0]
    v.extract    s44, v29, #0
    v.splat      v20, s44
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s40, #0], v20
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a0, s45
    s.addi       s45, s28, #12608
    v.ld.w       v19, [s45, #0]
    v.extract    s45, v29, #1
    v.splat      v20, s45
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s44, #0], v20
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a0, s45
    s.addi       s45, s28, #12672
    v.ld.w       v19, [s45, #0]
    v.extract    s45, v29, #2
    v.splat      v20, s45
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s44, #0], v20
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a0, s45
    s.addi       s45, s28, #12736
    v.ld.w       v19, [s45, #0]
    v.extract    s45, v29, #3
    v.splat      v20, s45
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s44, #0], v20
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a0, s45
    s.addi       s45, s28, #12800
    v.ld.w       v19, [s45, #0]
    v.extract    s45, v29, #4
    v.splat      v20, s45
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s44, #0], v20
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a0, s45
    s.addi       s45, s28, #12864
    v.ld.w       v19, [s45, #0]
    v.extract    s45, v29, #5
    v.splat      v20, s45
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s44, #0], v20
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a0, s45
    s.addi       s45, s28, #12928
    v.ld.w       v19, [s45, #0]
    v.extract    s45, v29, #6
    v.splat      v20, s45
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s44, #0], v20
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a0, s45
    s.addi       s45, s28, #12992
    v.ld.w       v19, [s45, #0]
    v.extract    s45, v29, #7
    v.splat      v20, s45
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s44, #0], v20
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a0, s45
    s.addi       s45, s28, #13056
    v.ld.w       v19, [s45, #0]
    v.extract    s45, v29, #8
    v.splat      v20, s45
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s44, #0], v20
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a0, s45
    s.addi       s45, s28, #13120
    v.ld.w       v19, [s45, #0]
    v.extract    s45, v29, #9
    v.splat      v20, s45
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s44, #0], v20
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a0, s45
    s.addi       s45, s28, #13184
    v.ld.w       v19, [s45, #0]
    v.extract    s45, v29, #10
    v.splat      v20, s45
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s44, #0], v20
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a0, s45
    s.addi       s45, s28, #13248
    v.ld.w       v19, [s45, #0]
    v.extract    s45, v29, #11
    v.splat      v20, s45
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s44, #0], v20
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a0, s45
    s.addi       s45, s28, #13312
    v.ld.w       v19, [s45, #0]
    v.extract    s45, v29, #12
    v.splat      v20, s45
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s44, #0], v20
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a0, s45
    s.addi       s45, s28, #13376
    v.ld.w       v19, [s45, #0]
    v.extract    s45, v29, #13
    v.splat      v20, s45
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s44, #0], v20
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a0, s45
    s.addi       s45, s28, #13440
    v.ld.w       v19, [s45, #0]
    v.extract    s45, v29, #14
    v.splat      v20, s45
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s44, #0], v20
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a0, s40
    s.addi       s40, s28, #13504
    v.ld.w       v19, [s40, #0]
    v.extract    s40, v29, #15
    v.splat      v20, s40
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v17, v0, v19
    v.st.w       [s44, #0], v17
    fence.acq_rel.device
    s.addi       s40, s28, #21760
    s.movz       s44, #0
    a.vread      v0, a1, s44
    s.addi       s44, s28, #13568
    v.ld.w       v17, [s44, #0]
    v.extract    s44, v29, #0
    v.splat      v19, s44
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s40, #0], v19
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a1, s45
    s.addi       s45, s28, #13632
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #1
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a1, s45
    s.addi       s45, s28, #13696
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #2
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a1, s45
    s.addi       s45, s28, #13760
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #3
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a1, s45
    s.addi       s45, s28, #13824
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #4
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a1, s45
    s.addi       s45, s28, #13888
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #5
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a1, s45
    s.addi       s45, s28, #13952
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #6
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a1, s45
    s.addi       s45, s28, #14016
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #7
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a1, s45
    s.addi       s45, s28, #14080
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #8
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a1, s45
    s.addi       s45, s28, #14144
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #9
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a1, s45
    s.addi       s45, s28, #14208
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #10
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a1, s45
    s.addi       s45, s28, #14272
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #11
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a1, s45
    s.addi       s45, s28, #14336
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #12
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a1, s45
    s.addi       s45, s28, #14400
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #13
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a1, s45
    s.addi       s45, s28, #14464
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #14
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a1, s40
    s.addi       s40, s28, #14528
    v.ld.w       v17, [s40, #0]
    v.extract    s40, v29, #15
    v.splat      v19, s40
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    fence.acq_rel.device
    s.addi       s40, s28, #22784
    s.movz       s44, #0
    a.vread      v0, a2, s44
    s.addi       s44, s28, #14592
    v.ld.w       v17, [s44, #0]
    v.extract    s44, v29, #0
    v.splat      v19, s44
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s40, #0], v19
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a2, s45
    s.addi       s45, s28, #14656
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #1
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a2, s45
    s.addi       s45, s28, #14720
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #2
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a2, s45
    s.addi       s45, s28, #14784
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #3
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a2, s45
    s.addi       s45, s28, #14848
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #4
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a2, s45
    s.addi       s45, s28, #14912
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #5
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a2, s45
    s.addi       s45, s28, #14976
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #6
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a2, s45
    s.addi       s45, s28, #15040
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #7
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a2, s45
    s.addi       s45, s28, #15104
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #8
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a2, s45
    s.addi       s45, s28, #15168
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #9
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a2, s45
    s.addi       s45, s28, #15232
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #10
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a2, s45
    s.addi       s45, s28, #15296
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #11
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a2, s45
    s.addi       s45, s28, #15360
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #12
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a2, s45
    s.addi       s45, s28, #15424
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #13
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a2, s45
    s.addi       s45, s28, #15488
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #14
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a2, s40
    s.addi       s40, s28, #15552
    v.ld.w       v17, [s40, #0]
    v.extract    s40, v29, #15
    v.splat      v19, s40
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    fence.acq_rel.device
    s.addi       s40, s28, #23808
    s.movz       s44, #0
    a.vread      v0, a3, s44
    s.addi       s44, s28, #15616
    v.ld.w       v17, [s44, #0]
    v.extract    s44, v29, #0
    v.splat      v19, s44
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s40, #0], v19
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a3, s45
    s.addi       s45, s28, #15680
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #1
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a3, s45
    s.addi       s45, s28, #15744
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #2
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a3, s45
    s.addi       s45, s28, #15808
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #3
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a3, s45
    s.addi       s45, s28, #15872
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #4
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a3, s45
    s.addi       s45, s28, #15936
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #5
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a3, s45
    s.addi       s45, s28, #16000
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #6
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a3, s45
    s.addi       s45, s28, #16064
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #7
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a3, s45
    s.addi       s45, s28, #16128
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #8
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a3, s45
    s.addi       s45, s28, #16192
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #9
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a3, s45
    s.addi       s45, s28, #16256
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #10
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a3, s45
    s.addi       s45, s28, #16320
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #11
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a3, s45
    s.addi       s45, s28, #16384
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #12
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a3, s45
    s.addi       s45, s28, #16448
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #13
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a3, s45
    s.addi       s45, s28, #16512
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #14
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a3, s40
    s.addi       s40, s28, #16576
    v.ld.w       v17, [s40, #0]
    v.extract    s40, v29, #15
    v.splat      v19, s40
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    fence.acq_rel.device
    s.addi       s40, s28, #24832
    s.movz       s44, #0
    a.vread      v0, a4, s44
    s.addi       s44, s28, #16640
    v.ld.w       v17, [s44, #0]
    v.extract    s44, v29, #0
    v.splat      v19, s44
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s40, #0], v19
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a4, s45
    s.addi       s45, s28, #16704
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #1
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a4, s45
    s.addi       s45, s28, #16768
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #2
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a4, s45
    s.addi       s45, s28, #16832
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #3
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a4, s45
    s.addi       s45, s28, #16896
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #4
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a4, s45
    s.addi       s45, s28, #16960
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #5
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a4, s45
    s.addi       s45, s28, #17024
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #6
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a4, s45
    s.addi       s45, s28, #17088
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #7
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a4, s45
    s.addi       s45, s28, #17152
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #8
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a4, s45
    s.addi       s45, s28, #17216
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #9
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a4, s45
    s.addi       s45, s28, #17280
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #10
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a4, s45
    s.addi       s45, s28, #17344
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #11
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a4, s45
    s.addi       s45, s28, #17408
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #12
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a4, s45
    s.addi       s45, s28, #17472
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #13
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a4, s45
    s.addi       s45, s28, #17536
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #14
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a4, s40
    s.addi       s40, s28, #17600
    v.ld.w       v17, [s40, #0]
    v.extract    s40, v29, #15
    v.splat      v19, s40
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    fence.acq_rel.device
    s.addi       s40, s28, #25856
    s.movz       s44, #0
    a.vread      v0, a5, s44
    s.addi       s44, s28, #17664
    v.ld.w       v17, [s44, #0]
    v.extract    s44, v29, #0
    v.splat      v19, s44
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s40, #0], v19
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a5, s45
    s.addi       s45, s28, #17728
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #1
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a5, s45
    s.addi       s45, s28, #17792
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #2
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a5, s45
    s.addi       s45, s28, #17856
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #3
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a5, s45
    s.addi       s45, s28, #17920
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #4
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a5, s45
    s.addi       s45, s28, #17984
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #5
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a5, s45
    s.addi       s45, s28, #18048
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #6
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a5, s45
    s.addi       s45, s28, #18112
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #7
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a5, s45
    s.addi       s45, s28, #18176
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #8
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a5, s45
    s.addi       s45, s28, #18240
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #9
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a5, s45
    s.addi       s45, s28, #18304
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #10
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a5, s45
    s.addi       s45, s28, #18368
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #11
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a5, s45
    s.addi       s45, s28, #18432
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #12
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a5, s45
    s.addi       s45, s28, #18496
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #13
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a5, s45
    s.addi       s45, s28, #18560
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #14
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a5, s40
    s.addi       s40, s28, #18624
    v.ld.w       v17, [s40, #0]
    v.extract    s40, v29, #15
    v.splat      v19, s40
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    fence.acq_rel.device
    s.addi       s40, s28, #26880
    s.movz       s44, #0
    a.vread      v0, a6, s44
    s.addi       s44, s28, #18688
    v.ld.w       v17, [s44, #0]
    v.extract    s44, v29, #0
    v.splat      v19, s44
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s40, #0], v19
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a6, s45
    s.addi       s45, s28, #18752
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #1
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a6, s45
    s.addi       s45, s28, #18816
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #2
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a6, s45
    s.addi       s45, s28, #18880
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #3
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a6, s45
    s.addi       s45, s28, #18944
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #4
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a6, s45
    s.addi       s45, s28, #19008
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #5
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a6, s45
    s.addi       s45, s28, #19072
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #6
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a6, s45
    s.addi       s45, s28, #19136
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #7
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a6, s45
    s.addi       s45, s28, #19200
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #8
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a6, s45
    s.addi       s45, s28, #19264
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #9
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a6, s45
    s.addi       s45, s28, #19328
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #10
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a6, s45
    s.addi       s45, s28, #19392
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #11
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a6, s45
    s.addi       s45, s28, #19456
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #12
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a6, s45
    s.addi       s45, s28, #19520
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #13
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a6, s45
    s.addi       s45, s28, #19584
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #14
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a6, s40
    s.addi       s40, s28, #19648
    v.ld.w       v17, [s40, #0]
    v.extract    s40, v29, #15
    v.splat      v19, s40
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    fence.acq_rel.device
    s.addi       s40, s28, #27904
    s.movz       s44, #0
    a.vread      v0, a7, s44
    s.addi       s44, s28, #19712
    v.ld.w       v17, [s44, #0]
    v.extract    s44, v29, #0
    v.splat      v19, s44
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s40, #0], v19
    s.addi       s44, s40, #64
    s.movz       s45, #1
    a.vread      v0, a7, s45
    s.addi       s45, s28, #19776
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #1
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #128
    s.movz       s45, #2
    a.vread      v0, a7, s45
    s.addi       s45, s28, #19840
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #2
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #192
    s.movz       s45, #3
    a.vread      v0, a7, s45
    s.addi       s45, s28, #19904
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #3
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #256
    s.movz       s45, #4
    a.vread      v0, a7, s45
    s.addi       s45, s28, #19968
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #4
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #320
    s.movz       s45, #5
    a.vread      v0, a7, s45
    s.addi       s45, s28, #20032
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #5
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #384
    s.movz       s45, #6
    a.vread      v0, a7, s45
    s.addi       s45, s28, #20096
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #6
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #448
    s.movz       s45, #7
    a.vread      v0, a7, s45
    s.addi       s45, s28, #20160
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #7
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #512
    s.movz       s45, #8
    a.vread      v0, a7, s45
    s.addi       s45, s28, #20224
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #8
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #576
    s.movz       s45, #9
    a.vread      v0, a7, s45
    s.addi       s45, s28, #20288
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #9
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #640
    s.movz       s45, #10
    a.vread      v0, a7, s45
    s.addi       s45, s28, #20352
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #10
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #704
    s.movz       s45, #11
    a.vread      v0, a7, s45
    s.addi       s45, s28, #20416
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #11
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #768
    s.movz       s45, #12
    a.vread      v0, a7, s45
    s.addi       s45, s28, #20480
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #12
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #832
    s.movz       s45, #13
    a.vread      v0, a7, s45
    s.addi       s45, s28, #20544
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #13
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #896
    s.movz       s45, #14
    a.vread      v0, a7, s45
    s.addi       s45, s28, #20608
    v.ld.w       v17, [s45, #0]
    v.extract    s45, v29, #14
    v.splat      v19, s45
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    s.addi       s44, s40, #960
    s.movz       s40, #15
    a.vread      v0, a7, s40
    s.addi       s40, s28, #20672
    v.ld.w       v17, [s40, #0]
    v.extract    s40, v29, #15
    v.splat      v19, s40
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s44, #0], v19
    fence.acq_rel.device
    s.addi       s40, s25, #128
    s.addi       s44, s40, #0
    s.addi       s40, s26, #128
    s.addi       s45, s40, #0
    s.addi       s40, s27, #4                    // &ptr_carry_18[1] (a constant offset, x4)
    s.addi       s46, s40, #0
    s.addi       s40, s27, #4                    // &ptr_carry_19[1] (a constant offset, x4)
    s.addi       s40, s27, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    s.addi       s40, s27, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    s.addi       s40, s27, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    s.addi       s40, s27, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    s.addi       s40, s27, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    s.addi       s40, s27, #4                    // &ptr_carry_25[1] (a constant offset, x4)
    s.mov        s25, s44
    s.mov        s26, s45
    s.mov        s27, s46
    s.movz       s40, #0
    s.addi       s44, s28, #20736
    v.ld.w       v0, [s44, #0]
    a.vwrite     a0, s40, v0
    s.movz       s44, #1
    s.addi       s45, s28, #20800
    v.ld.w       v0, [s45, #0]
    a.vwrite     a0, s44, v0
    s.movz       s45, #2
    s.addi       s46, s28, #20864
    v.ld.w       v0, [s46, #0]
    a.vwrite     a0, s45, v0
    s.movz       s46, #3
    s.addi       s47, s28, #20928
    v.ld.w       v0, [s47, #0]
    a.vwrite     a0, s46, v0
    s.movz       s47, #4
    s.addi       s49, s28, #20992
    v.ld.w       v0, [s49, #0]
    a.vwrite     a0, s47, v0
    s.movz       s49, #5
    s.addi       s50, s28, #21056
    v.ld.w       v0, [s50, #0]
    a.vwrite     a0, s49, v0
    s.movz       s50, #6
    s.addi       s51, s28, #21120
    v.ld.w       v0, [s51, #0]
    a.vwrite     a0, s50, v0
    s.movz       s51, #7
    s.addi       s52, s28, #21184
    v.ld.w       v0, [s52, #0]
    a.vwrite     a0, s51, v0
    s.movz       s52, #8
    s.addi       s53, s28, #21248
    v.ld.w       v0, [s53, #0]
    a.vwrite     a0, s52, v0
    s.movz       s53, #9
    s.addi       s54, s28, #21312
    v.ld.w       v0, [s54, #0]
    a.vwrite     a0, s53, v0
    s.movz       s54, #10
    s.addi       s55, s28, #21376
    v.ld.w       v0, [s55, #0]
    a.vwrite     a0, s54, v0
    s.movz       s55, #11
    s.addi       s56, s28, #21440
    v.ld.w       v0, [s56, #0]
    a.vwrite     a0, s55, v0
    s.movz       s56, #12
    s.addi       s57, s28, #21504
    v.ld.w       v0, [s57, #0]
    a.vwrite     a0, s56, v0
    s.movz       s57, #13
    s.addi       s58, s28, #21568
    v.ld.w       v0, [s58, #0]
    a.vwrite     a0, s57, v0
    s.movz       s58, #14
    s.addi       s59, s28, #21632
    v.ld.w       v0, [s59, #0]
    a.vwrite     a0, s58, v0
    s.movz       s59, #15
    s.addi       s60, s28, #21696
    v.ld.w       v0, [s60, #0]
    a.vwrite     a0, s59, v0
    s.addi       s60, s28, #21760
    v.ld.w       v0, [s60, #0]
    a.vwrite     a1, s40, v0
    s.addi       s40, s28, #21824
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s44, v0
    s.addi       s40, s28, #21888
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s45, v0
    s.addi       s40, s28, #21952
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s46, v0
    s.addi       s40, s28, #22016
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s47, v0
    s.addi       s40, s28, #22080
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s49, v0
    s.addi       s40, s28, #22144
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s50, v0
    s.addi       s40, s28, #22208
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s51, v0
    s.addi       s40, s28, #22272
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s52, v0
    s.addi       s40, s28, #22336
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s53, v0
    s.addi       s40, s28, #22400
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s54, v0
    s.addi       s40, s28, #22464
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s55, v0
    s.addi       s40, s28, #22528
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s56, v0
    s.addi       s40, s28, #22592
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s57, v0
    s.addi       s40, s28, #22656
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s58, v0
    s.addi       s40, s28, #22720
    v.ld.w       v0, [s40, #0]
    a.vwrite     a1, s59, v0
    s.movz       s40, #0
    s.addi       s44, s28, #22784
    v.ld.w       v0, [s44, #0]
    a.vwrite     a2, s40, v0
    s.movz       s44, #1
    s.addi       s45, s28, #22848
    v.ld.w       v0, [s45, #0]
    a.vwrite     a2, s44, v0
    s.movz       s45, #2
    s.addi       s46, s28, #22912
    v.ld.w       v0, [s46, #0]
    a.vwrite     a2, s45, v0
    s.movz       s46, #3
    s.addi       s47, s28, #22976
    v.ld.w       v0, [s47, #0]
    a.vwrite     a2, s46, v0
    s.movz       s47, #4
    s.addi       s49, s28, #23040
    v.ld.w       v0, [s49, #0]
    a.vwrite     a2, s47, v0
    s.movz       s49, #5
    s.addi       s50, s28, #23104
    v.ld.w       v0, [s50, #0]
    a.vwrite     a2, s49, v0
    s.movz       s50, #6
    s.addi       s51, s28, #23168
    v.ld.w       v0, [s51, #0]
    a.vwrite     a2, s50, v0
    s.movz       s51, #7
    s.addi       s52, s28, #23232
    v.ld.w       v0, [s52, #0]
    a.vwrite     a2, s51, v0
    s.movz       s52, #8
    s.addi       s53, s28, #23296
    v.ld.w       v0, [s53, #0]
    a.vwrite     a2, s52, v0
    s.movz       s53, #9
    s.addi       s54, s28, #23360
    v.ld.w       v0, [s54, #0]
    a.vwrite     a2, s53, v0
    s.movz       s54, #10
    s.addi       s55, s28, #23424
    v.ld.w       v0, [s55, #0]
    a.vwrite     a2, s54, v0
    s.movz       s55, #11
    s.addi       s56, s28, #23488
    v.ld.w       v0, [s56, #0]
    a.vwrite     a2, s55, v0
    s.movz       s56, #12
    s.addi       s57, s28, #23552
    v.ld.w       v0, [s57, #0]
    a.vwrite     a2, s56, v0
    s.movz       s57, #13
    s.addi       s58, s28, #23616
    v.ld.w       v0, [s58, #0]
    a.vwrite     a2, s57, v0
    s.movz       s58, #14
    s.addi       s59, s28, #23680
    v.ld.w       v0, [s59, #0]
    a.vwrite     a2, s58, v0
    s.movz       s59, #15
    s.addi       s60, s28, #23744
    v.ld.w       v0, [s60, #0]
    a.vwrite     a2, s59, v0
    s.addi       s60, s28, #23808
    v.ld.w       v0, [s60, #0]
    a.vwrite     a3, s40, v0
    s.addi       s40, s28, #23872
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s44, v0
    s.addi       s40, s28, #23936
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s45, v0
    s.addi       s40, s28, #24000
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s46, v0
    s.addi       s40, s28, #24064
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s47, v0
    s.addi       s40, s28, #24128
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s49, v0
    s.addi       s40, s28, #24192
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s50, v0
    s.addi       s40, s28, #24256
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s51, v0
    s.addi       s40, s28, #24320
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s52, v0
    s.addi       s40, s28, #24384
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s53, v0
    s.addi       s40, s28, #24448
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s54, v0
    s.addi       s40, s28, #24512
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s55, v0
    s.addi       s40, s28, #24576
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s56, v0
    s.addi       s40, s28, #24640
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s57, v0
    s.addi       s40, s28, #24704
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s58, v0
    s.addi       s40, s28, #24768
    v.ld.w       v0, [s40, #0]
    a.vwrite     a3, s59, v0
    s.movz       s40, #0
    s.addi       s44, s28, #24832
    v.ld.w       v0, [s44, #0]
    a.vwrite     a4, s40, v0
    s.movz       s44, #1
    s.addi       s45, s28, #24896
    v.ld.w       v0, [s45, #0]
    a.vwrite     a4, s44, v0
    s.movz       s45, #2
    s.addi       s46, s28, #24960
    v.ld.w       v0, [s46, #0]
    a.vwrite     a4, s45, v0
    s.movz       s46, #3
    s.addi       s47, s28, #25024
    v.ld.w       v0, [s47, #0]
    a.vwrite     a4, s46, v0
    s.movz       s47, #4
    s.addi       s49, s28, #25088
    v.ld.w       v0, [s49, #0]
    a.vwrite     a4, s47, v0
    s.movz       s49, #5
    s.addi       s50, s28, #25152
    v.ld.w       v0, [s50, #0]
    a.vwrite     a4, s49, v0
    s.movz       s50, #6
    s.addi       s51, s28, #25216
    v.ld.w       v0, [s51, #0]
    a.vwrite     a4, s50, v0
    s.movz       s51, #7
    s.addi       s52, s28, #25280
    v.ld.w       v0, [s52, #0]
    a.vwrite     a4, s51, v0
    s.movz       s52, #8
    s.addi       s53, s28, #25344
    v.ld.w       v0, [s53, #0]
    a.vwrite     a4, s52, v0
    s.movz       s53, #9
    s.addi       s54, s28, #25408
    v.ld.w       v0, [s54, #0]
    a.vwrite     a4, s53, v0
    s.movz       s54, #10
    s.addi       s55, s28, #25472
    v.ld.w       v0, [s55, #0]
    a.vwrite     a4, s54, v0
    s.movz       s55, #11
    s.addi       s56, s28, #25536
    v.ld.w       v0, [s56, #0]
    a.vwrite     a4, s55, v0
    s.movz       s56, #12
    s.addi       s57, s28, #25600
    v.ld.w       v0, [s57, #0]
    a.vwrite     a4, s56, v0
    s.movz       s57, #13
    s.addi       s58, s28, #25664
    v.ld.w       v0, [s58, #0]
    a.vwrite     a4, s57, v0
    s.movz       s58, #14
    s.addi       s59, s28, #25728
    v.ld.w       v0, [s59, #0]
    a.vwrite     a4, s58, v0
    s.movz       s59, #15
    s.addi       s60, s28, #25792
    v.ld.w       v0, [s60, #0]
    a.vwrite     a4, s59, v0
    s.addi       s60, s28, #25856
    v.ld.w       v0, [s60, #0]
    a.vwrite     a5, s40, v0
    s.addi       s40, s28, #25920
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s44, v0
    s.addi       s40, s28, #25984
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s45, v0
    s.addi       s40, s28, #26048
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s46, v0
    s.addi       s40, s28, #26112
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s47, v0
    s.addi       s40, s28, #26176
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s49, v0
    s.addi       s40, s28, #26240
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s50, v0
    s.addi       s40, s28, #26304
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s51, v0
    s.addi       s40, s28, #26368
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s52, v0
    s.addi       s40, s28, #26432
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s53, v0
    s.addi       s40, s28, #26496
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s54, v0
    s.addi       s40, s28, #26560
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s55, v0
    s.addi       s40, s28, #26624
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s56, v0
    s.addi       s40, s28, #26688
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s57, v0
    s.addi       s40, s28, #26752
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s58, v0
    s.addi       s40, s28, #26816
    v.ld.w       v0, [s40, #0]
    a.vwrite     a5, s59, v0
    s.movz       s40, #0
    s.addi       s44, s28, #26880
    v.ld.w       v0, [s44, #0]
    a.vwrite     a6, s40, v0
    s.movz       s44, #1
    s.addi       s45, s28, #26944
    v.ld.w       v0, [s45, #0]
    a.vwrite     a6, s44, v0
    s.movz       s45, #2
    s.addi       s46, s28, #27008
    v.ld.w       v0, [s46, #0]
    a.vwrite     a6, s45, v0
    s.movz       s46, #3
    s.addi       s47, s28, #27072
    v.ld.w       v0, [s47, #0]
    a.vwrite     a6, s46, v0
    s.movz       s47, #4
    s.addi       s49, s28, #27136
    v.ld.w       v0, [s49, #0]
    a.vwrite     a6, s47, v0
    s.movz       s49, #5
    s.addi       s50, s28, #27200
    v.ld.w       v0, [s50, #0]
    a.vwrite     a6, s49, v0
    s.movz       s50, #6
    s.addi       s51, s28, #27264
    v.ld.w       v0, [s51, #0]
    a.vwrite     a6, s50, v0
    s.movz       s51, #7
    s.addi       s52, s28, #27328
    v.ld.w       v0, [s52, #0]
    a.vwrite     a6, s51, v0
    s.movz       s52, #8
    s.addi       s53, s28, #27392
    v.ld.w       v0, [s53, #0]
    a.vwrite     a6, s52, v0
    s.movz       s53, #9
    s.addi       s54, s28, #27456
    v.ld.w       v0, [s54, #0]
    a.vwrite     a6, s53, v0
    s.movz       s54, #10
    s.addi       s55, s28, #27520
    v.ld.w       v0, [s55, #0]
    a.vwrite     a6, s54, v0
    s.movz       s55, #11
    s.addi       s56, s28, #27584
    v.ld.w       v0, [s56, #0]
    a.vwrite     a6, s55, v0
    s.movz       s56, #12
    s.addi       s57, s28, #27648
    v.ld.w       v0, [s57, #0]
    a.vwrite     a6, s56, v0
    s.movz       s57, #13
    s.addi       s58, s28, #27712
    v.ld.w       v0, [s58, #0]
    a.vwrite     a6, s57, v0
    s.movz       s58, #14
    s.addi       s59, s28, #27776
    v.ld.w       v0, [s59, #0]
    a.vwrite     a6, s58, v0
    s.movz       s59, #15
    s.addi       s60, s28, #27840
    v.ld.w       v0, [s60, #0]
    a.vwrite     a6, s59, v0
    s.addi       s60, s28, #27904
    v.ld.w       v0, [s60, #0]
    a.vwrite     a7, s40, v0
    s.addi       s40, s28, #27968
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s44, v0
    s.addi       s40, s28, #28032
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s45, v0
    s.addi       s40, s28, #28096
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s46, v0
    s.addi       s40, s28, #28160
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s47, v0
    s.addi       s40, s28, #28224
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s49, v0
    s.addi       s40, s28, #28288
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s50, v0
    s.addi       s40, s28, #28352
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s51, v0
    s.addi       s40, s28, #28416
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s52, v0
    s.addi       s40, s28, #28480
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s53, v0
    s.addi       s40, s28, #28544
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s54, v0
    s.addi       s40, s28, #28608
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s55, v0
    s.addi       s40, s28, #28672
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s56, v0
    s.addi       s40, s28, #28736
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s57, v0
    s.addi       s40, s28, #28800
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s58, v0
    s.addi       s40, s28, #28864
    v.ld.w       v0, [s40, #0]
    a.vwrite     a7, s59, v0
    s.add        s28, s24, s20
    s.mov        s24, s28
    s.movz       s28, #1
    br.nz        s28, for_26
endfor_27:
    s.mul        s1, s4, s17
    s.movz       s2, #0
    s.muli       s6, s5, #2
    a.vread      v0, a0, s2
    s.muli       s8, s17, #2
    s.muli       s9, s1, #2
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s5, #16
    s.add        s10, s2, s4                     // the tile origin
    s.addi       s4, s5, #32
    v.splat      v0, s10
    s.add        s13, s9, s6
    s.addi       s14, s5, #48
    s.add        s15, s2, s7                     // the tile origin
    s.add        s7, s12, s13
    s.addi       s13, s5, #64
    v.splat      v2, s15
    s.addi       s15, s5, #80
    s.addi       s16, s5, #96
    s.add        s17, s2, s5                     // the tile origin
    v.cmp.lt     p1, v0, v2
    s.addi       s18, s5, #112
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v3, s17
    s.add        s5, s2, s3                      // the tile origin
    s.muli       s2, s8, #1
    v.add        v4, v0, v3
    v.splat      v3, s5
    s.movz       s5, #1
    s.addi       s17, s10, #1
    v.cmp.lt     p2, v4, v3
    p.and        p3, p1, p2
    s.add        s19, s2, s9
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s5
    v.splat      v3, s17
    s.add        s2, s19, s6
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.muli       s5, s8, #2
    s.add        s7, s12, s2
    p.and        p3, p1, p2
    s.movz       s2, #2
    s.addi       s17, s10, #2
    s.add        s19, s5, s9
    v.splat      v1, s17
    s.add        s5, s19, s6
    @p3 v.st.h       [s7, #0], v4
    a.vread      v3, a0, s2
    v.cmp.lt     p1, v1, v2
    s.muli       s2, s8, #3
    vf.cvt.f32.bf16 v1, v3
    s.add        s7, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #3
    s.addi       s17, s10, #3
    s.add        s19, s2, s9
    v.splat      v3, s17
    s.add        s2, s19, s6
    s.movz       s17, #4
    s.add        s19, s12, s2
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p1, v3, v2
    s.muli       s2, s8, #4
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s5, s10, #4
    s.add        s7, s2, s9
    v.splat      v1, s5
    s.add        s2, s7, s6
    s.movz       s5, #5
    s.add        s7, s12, s2
    @p3 v.st.h       [s19, #0], v3
    a.vread      v3, a0, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s2, s8, #5
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s10, #5
    s.add        s19, s2, s9
    v.splat      v3, s17
    s.add        s2, s19, s6
    s.movz       s17, #6
    s.add        s19, s12, s2
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p1, v3, v2
    s.muli       s2, s8, #6
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s5, s10, #6
    s.add        s7, s2, s9
    v.splat      v1, s5
    s.add        s2, s7, s6
    s.movz       s5, #7
    s.add        s7, s12, s2
    @p3 v.st.h       [s19, #0], v3
    a.vread      v3, a0, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s2, s8, #7
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s10, #7
    s.add        s19, s2, s9
    v.splat      v3, s17
    s.add        s2, s19, s6
    s.movz       s17, #8
    s.add        s19, s12, s2
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p1, v3, v2
    s.muli       s2, s8, #8
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s5, s10, #8
    s.add        s7, s2, s9
    v.splat      v1, s5
    s.add        s2, s7, s6
    s.movz       s5, #9
    s.add        s7, s12, s2
    @p3 v.st.h       [s19, #0], v3
    a.vread      v3, a0, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s2, s8, #9
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s10, #9
    s.add        s19, s2, s9
    v.splat      v3, s17
    s.add        s2, s19, s6
    s.movz       s17, #10
    s.add        s19, s12, s2
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p1, v3, v2
    s.muli       s2, s8, #10
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s5, s10, #10
    s.add        s7, s2, s9
    v.splat      v1, s5
    s.add        s2, s7, s6
    s.movz       s5, #11
    s.add        s7, s12, s2
    @p3 v.st.h       [s19, #0], v3
    a.vread      v3, a0, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s2, s8, #11
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s10, #11
    s.add        s19, s2, s9
    v.splat      v3, s17
    s.add        s2, s19, s6
    s.movz       s17, #12
    s.add        s19, s12, s2
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p1, v3, v2
    s.muli       s2, s8, #12
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s5, s10, #12
    s.add        s7, s2, s9
    v.splat      v1, s5
    s.add        s2, s7, s6
    s.movz       s5, #13
    s.add        s7, s12, s2
    @p3 v.st.h       [s19, #0], v3
    a.vread      v3, a0, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s2, s8, #13
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s10, #13
    s.add        s19, s2, s9
    v.splat      v3, s17
    s.add        s2, s19, s6
    s.movz       s17, #14
    s.add        s19, s12, s2
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p1, v3, v2
    s.muli       s2, s8, #14
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s5, s10, #14
    s.add        s7, s2, s9
    v.splat      v1, s5
    s.add        s2, s7, s6
    s.movz       s5, #15
    s.add        s7, s12, s2
    @p3 v.st.h       [s19, #0], v3
    a.vread      v3, a0, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s2, s8, #15
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s10, #15
    s.add        s19, s2, s9
    v.splat      v3, s17
    s.movz       s2, #0
    s.add        s17, s19, s6
    s.add        s6, s12, s17
    @p3 v.st.h       [s7, #0], v1
    a.vread      v1, a0, s5
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s5, s2, s1                      // the tile origin
    s.muli       s7, s1, #2
    v.splat      v1, s5
    s.add        s1, s2, s3                      // the tile origin
    v.splat      v4, s10
    v.add        v5, v0, v1
    s.add        s5, s9, s7
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s1
    @p3 v.st.h       [s6, #0], v3
    a.vread      v3, a1, s2
    v.cmp.lt     p2, v5, v1
    s.add        s1, s12, s5
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s8, #1
    p.and        p3, p1, p2
    s.movz       s5, #1
    s.addi       s6, s10, #1
    s.movz       s17, #2
    s.add        s19, s2, s9
    v.splat      v3, s6
    s.add        s2, s19, s7
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a1, s5
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s5, s12, s2
    p.and        p3, p1, p2
    s.addi       s2, s10, #2
    s.add        s6, s1, s9
    v.splat      v1, s2
    s.add        s1, s6, s7
    s.movz       s2, #3
    s.add        s6, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a1, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #3
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #3
    s.movz       s17, #4
    s.add        s19, s1, s9
    v.splat      v3, s5
    s.add        s1, s19, s7
    s.add        s5, s12, s1
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a1, s2
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #4
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #4
    s.movz       s6, #5
    s.add        s19, s1, s9
    v.splat      v1, s2
    s.add        s1, s19, s7
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a1, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #5
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #5
    s.movz       s17, #6
    s.add        s19, s1, s9
    v.splat      v3, s5
    s.add        s1, s19, s7
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a1, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #6
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #6
    s.movz       s6, #7
    s.add        s19, s1, s9
    v.splat      v1, s2
    s.add        s1, s19, s7
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a1, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #7
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #7
    s.movz       s17, #8
    s.add        s19, s1, s9
    v.splat      v3, s5
    s.add        s1, s19, s7
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a1, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #8
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #8
    s.movz       s6, #9
    s.add        s19, s1, s9
    v.splat      v1, s2
    s.add        s1, s19, s7
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a1, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #9
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #9
    s.movz       s17, #10
    s.add        s19, s1, s9
    v.splat      v3, s5
    s.add        s1, s19, s7
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a1, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #10
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #10
    s.movz       s6, #11
    s.add        s19, s1, s9
    v.splat      v1, s2
    s.add        s1, s19, s7
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a1, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #11
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #11
    s.movz       s17, #12
    s.add        s19, s1, s9
    v.splat      v3, s5
    s.add        s1, s19, s7
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a1, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #12
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #12
    s.movz       s6, #13
    s.add        s19, s1, s9
    v.splat      v1, s2
    s.add        s1, s19, s7
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a1, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #13
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #13
    s.movz       s17, #14
    s.add        s19, s1, s9
    v.splat      v3, s5
    s.add        s1, s19, s7
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a1, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #14
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #14
    s.movz       s6, #15
    s.add        s19, s1, s9
    v.splat      v1, s2
    s.add        s1, s19, s7
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a1, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #15
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #15
    s.movz       s17, #0
    s.add        s19, s1, s9
    v.splat      v3, s5
    s.add        s1, s19, s7
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a1, s6
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s17, s4                     // the tile origin
    s.muli       s2, s4, #2
    v.splat      v1, s1
    s.add        s1, s17, s3                     // the tile origin
    v.splat      v4, s10
    v.add        v5, v0, v1
    s.add        s4, s9, s2
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a2, s17
    v.cmp.lt     p2, v5, v1
    s.add        s1, s12, s4
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s8, #1
    p.and        p3, p1, p2
    s.movz       s5, #1
    s.addi       s6, s10, #1
    s.movz       s7, #2
    s.add        s17, s4, s9
    v.splat      v3, s6
    s.add        s4, s17, s2
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a2, s5
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s5, s12, s4
    p.and        p3, p1, p2
    s.addi       s4, s10, #2
    s.add        s6, s1, s9
    v.splat      v1, s4
    s.add        s1, s6, s2
    s.movz       s4, #3
    s.add        s6, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a2, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #3
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #3
    s.movz       s7, #4
    s.add        s17, s1, s9
    v.splat      v3, s5
    s.add        s1, s17, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a2, s4
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #4
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #4
    s.movz       s6, #5
    s.add        s17, s1, s9
    v.splat      v1, s4
    s.add        s1, s17, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a2, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #5
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #5
    s.movz       s7, #6
    s.add        s17, s1, s9
    v.splat      v3, s5
    s.add        s1, s17, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a2, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #6
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #6
    s.movz       s6, #7
    s.add        s17, s1, s9
    v.splat      v1, s4
    s.add        s1, s17, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a2, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #7
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #7
    s.movz       s7, #8
    s.add        s17, s1, s9
    v.splat      v3, s5
    s.add        s1, s17, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a2, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #8
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #8
    s.movz       s6, #9
    s.add        s17, s1, s9
    v.splat      v1, s4
    s.add        s1, s17, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a2, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #9
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #9
    s.movz       s7, #10
    s.add        s17, s1, s9
    v.splat      v3, s5
    s.add        s1, s17, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a2, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #10
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #10
    s.movz       s6, #11
    s.add        s17, s1, s9
    v.splat      v1, s4
    s.add        s1, s17, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a2, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #11
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #11
    s.movz       s7, #12
    s.add        s17, s1, s9
    v.splat      v3, s5
    s.add        s1, s17, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a2, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #12
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #12
    s.movz       s6, #13
    s.add        s17, s1, s9
    v.splat      v1, s4
    s.add        s1, s17, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a2, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #13
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #13
    s.movz       s7, #14
    s.add        s17, s1, s9
    v.splat      v3, s5
    s.add        s1, s17, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a2, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #14
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #14
    s.movz       s6, #15
    s.add        s17, s1, s9
    v.splat      v1, s4
    s.add        s1, s17, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a2, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #15
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #15
    s.movz       s7, #0
    s.add        s17, s1, s9
    v.splat      v3, s5
    s.add        s1, s17, s2
    s.add        s2, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a2, s6
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s7, s14                     // the tile origin
    s.muli       s4, s14, #2
    v.splat      v1, s1
    s.add        s1, s7, s3                      // the tile origin
    v.splat      v4, s10
    v.add        v5, v0, v1
    s.add        s5, s9, s4
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s1
    @p3 v.st.h       [s2, #0], v3
    a.vread      v3, a3, s7
    v.cmp.lt     p2, v5, v1
    s.add        s1, s12, s5
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s8, #1
    p.and        p3, p1, p2
    s.movz       s5, #1
    s.addi       s6, s10, #1
    s.movz       s7, #2
    s.add        s14, s2, s9
    v.splat      v3, s6
    s.add        s2, s14, s4
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a3, s5
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s5, s12, s2
    p.and        p3, p1, p2
    s.addi       s2, s10, #2
    s.add        s6, s1, s9
    v.splat      v1, s2
    s.add        s1, s6, s4
    s.movz       s2, #3
    s.add        s6, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a3, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #3
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #3
    s.movz       s7, #4
    s.add        s14, s1, s9
    v.splat      v3, s5
    s.add        s1, s14, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a3, s2
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #4
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #4
    s.movz       s6, #5
    s.add        s14, s1, s9
    v.splat      v1, s2
    s.add        s1, s14, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a3, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #5
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #5
    s.movz       s7, #6
    s.add        s14, s1, s9
    v.splat      v3, s5
    s.add        s1, s14, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a3, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #6
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #6
    s.movz       s6, #7
    s.add        s14, s1, s9
    v.splat      v1, s2
    s.add        s1, s14, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a3, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #7
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #7
    s.movz       s7, #8
    s.add        s14, s1, s9
    v.splat      v3, s5
    s.add        s1, s14, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a3, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #8
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #8
    s.movz       s6, #9
    s.add        s14, s1, s9
    v.splat      v1, s2
    s.add        s1, s14, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a3, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #9
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #9
    s.movz       s7, #10
    s.add        s14, s1, s9
    v.splat      v3, s5
    s.add        s1, s14, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a3, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #10
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #10
    s.movz       s6, #11
    s.add        s14, s1, s9
    v.splat      v1, s2
    s.add        s1, s14, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a3, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #11
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #11
    s.movz       s7, #12
    s.add        s14, s1, s9
    v.splat      v3, s5
    s.add        s1, s14, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a3, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #12
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #12
    s.movz       s6, #13
    s.add        s14, s1, s9
    v.splat      v1, s2
    s.add        s1, s14, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a3, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #13
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #13
    s.movz       s7, #14
    s.add        s14, s1, s9
    v.splat      v3, s5
    s.add        s1, s14, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a3, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #14
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #14
    s.movz       s6, #15
    s.add        s14, s1, s9
    v.splat      v1, s2
    s.add        s1, s14, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a3, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #15
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #15
    s.movz       s7, #0
    s.add        s14, s1, s9
    v.splat      v3, s5
    s.add        s1, s14, s4
    s.add        s4, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a3, s6
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s7, s13                     // the tile origin
    s.muli       s2, s13, #2
    v.splat      v1, s1
    s.add        s1, s7, s3                      // the tile origin
    v.splat      v4, s10
    v.add        v5, v0, v1
    s.add        s5, s9, s2
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s1
    @p3 v.st.h       [s4, #0], v3
    a.vread      v3, a4, s7
    v.cmp.lt     p2, v5, v1
    s.add        s1, s12, s5
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s8, #1
    p.and        p3, p1, p2
    s.movz       s5, #1
    s.addi       s6, s10, #1
    s.movz       s7, #2
    s.add        s13, s4, s9
    v.splat      v3, s6
    s.add        s4, s13, s2
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a4, s5
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s5, s12, s4
    p.and        p3, p1, p2
    s.addi       s4, s10, #2
    s.add        s6, s1, s9
    v.splat      v1, s4
    s.add        s1, s6, s2
    s.movz       s4, #3
    s.add        s6, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a4, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #3
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #3
    s.movz       s7, #4
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a4, s4
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #4
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #4
    s.movz       s6, #5
    s.add        s13, s1, s9
    v.splat      v1, s4
    s.add        s1, s13, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a4, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #5
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #5
    s.movz       s7, #6
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a4, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #6
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #6
    s.movz       s6, #7
    s.add        s13, s1, s9
    v.splat      v1, s4
    s.add        s1, s13, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a4, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #7
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #7
    s.movz       s7, #8
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a4, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #8
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #8
    s.movz       s6, #9
    s.add        s13, s1, s9
    v.splat      v1, s4
    s.add        s1, s13, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a4, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #9
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #9
    s.movz       s7, #10
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a4, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #10
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #10
    s.movz       s6, #11
    s.add        s13, s1, s9
    v.splat      v1, s4
    s.add        s1, s13, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a4, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #11
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #11
    s.movz       s7, #12
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a4, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #12
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #12
    s.movz       s6, #13
    s.add        s13, s1, s9
    v.splat      v1, s4
    s.add        s1, s13, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a4, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #13
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #13
    s.movz       s7, #14
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a4, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #14
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #14
    s.movz       s6, #15
    s.add        s13, s1, s9
    v.splat      v1, s4
    s.add        s1, s13, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a4, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #15
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #15
    s.movz       s7, #0
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s2
    s.add        s2, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a4, s6
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s7, s15                     // the tile origin
    s.muli       s4, s15, #2
    v.splat      v1, s1
    s.add        s1, s7, s3                      // the tile origin
    v.splat      v4, s10
    v.add        v5, v0, v1
    s.add        s5, s9, s4
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s1
    @p3 v.st.h       [s2, #0], v3
    a.vread      v3, a5, s7
    v.cmp.lt     p2, v5, v1
    s.add        s1, s12, s5
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s8, #1
    p.and        p3, p1, p2
    s.movz       s5, #1
    s.addi       s6, s10, #1
    s.movz       s7, #2
    s.add        s13, s2, s9
    v.splat      v3, s6
    s.add        s2, s13, s4
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a5, s5
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s5, s12, s2
    p.and        p3, p1, p2
    s.addi       s2, s10, #2
    s.add        s6, s1, s9
    v.splat      v1, s2
    s.add        s1, s6, s4
    s.movz       s2, #3
    s.add        s6, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a5, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #3
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #3
    s.movz       s7, #4
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a5, s2
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #4
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #4
    s.movz       s6, #5
    s.add        s13, s1, s9
    v.splat      v1, s2
    s.add        s1, s13, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a5, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #5
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #5
    s.movz       s7, #6
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a5, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #6
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #6
    s.movz       s6, #7
    s.add        s13, s1, s9
    v.splat      v1, s2
    s.add        s1, s13, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a5, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #7
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #7
    s.movz       s7, #8
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a5, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #8
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #8
    s.movz       s6, #9
    s.add        s13, s1, s9
    v.splat      v1, s2
    s.add        s1, s13, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a5, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #9
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #9
    s.movz       s7, #10
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a5, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #10
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #10
    s.movz       s6, #11
    s.add        s13, s1, s9
    v.splat      v1, s2
    s.add        s1, s13, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a5, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #11
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #11
    s.movz       s7, #12
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a5, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #12
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #12
    s.movz       s6, #13
    s.add        s13, s1, s9
    v.splat      v1, s2
    s.add        s1, s13, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a5, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #13
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #13
    s.movz       s7, #14
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s4
    s.add        s5, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a5, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #14
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s2, s10, #14
    s.movz       s6, #15
    s.add        s13, s1, s9
    v.splat      v1, s2
    s.add        s1, s13, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a5, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #15
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #15
    s.movz       s7, #0
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s4
    s.add        s4, s12, s1
    @p3 v.st.h       [s2, #0], v1
    a.vread      v1, a5, s6
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s7, s16                     // the tile origin
    s.muli       s2, s16, #2
    v.splat      v1, s1
    s.add        s1, s7, s3                      // the tile origin
    v.splat      v4, s10
    v.add        v5, v0, v1
    s.add        s5, s9, s2
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s1
    @p3 v.st.h       [s4, #0], v3
    a.vread      v3, a6, s7
    v.cmp.lt     p2, v5, v1
    s.add        s1, s12, s5
    vf.cvt.f32.bf16 v1, v3
    s.muli       s4, s8, #1
    p.and        p3, p1, p2
    s.movz       s5, #1
    s.addi       s6, s10, #1
    s.movz       s7, #2
    s.add        s13, s4, s9
    v.splat      v3, s6
    s.add        s4, s13, s2
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a6, s5
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s5, s12, s4
    p.and        p3, p1, p2
    s.addi       s4, s10, #2
    s.add        s6, s1, s9
    v.splat      v1, s4
    s.add        s1, s6, s2
    s.movz       s4, #3
    s.add        s6, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a6, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #3
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #3
    s.movz       s7, #4
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a6, s4
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #4
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #4
    s.movz       s6, #5
    s.add        s13, s1, s9
    v.splat      v1, s4
    s.add        s1, s13, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a6, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #5
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #5
    s.movz       s7, #6
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a6, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #6
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #6
    s.movz       s6, #7
    s.add        s13, s1, s9
    v.splat      v1, s4
    s.add        s1, s13, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a6, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #7
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #7
    s.movz       s7, #8
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a6, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #8
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #8
    s.movz       s6, #9
    s.add        s13, s1, s9
    v.splat      v1, s4
    s.add        s1, s13, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a6, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #9
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #9
    s.movz       s7, #10
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a6, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #10
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #10
    s.movz       s6, #11
    s.add        s13, s1, s9
    v.splat      v1, s4
    s.add        s1, s13, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a6, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #11
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #11
    s.movz       s7, #12
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a6, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #12
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #12
    s.movz       s6, #13
    s.add        s13, s1, s9
    v.splat      v1, s4
    s.add        s1, s13, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a6, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #13
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #13
    s.movz       s7, #14
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s2
    s.add        s5, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a6, s6
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s8, #14
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s4, s10, #14
    s.movz       s6, #15
    s.add        s13, s1, s9
    v.splat      v1, s4
    s.add        s1, s13, s2
    s.add        s4, s12, s1
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a6, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #15
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s5, s10, #15
    s.movz       s7, #0
    s.add        s13, s1, s9
    v.splat      v3, s5
    s.add        s1, s13, s2
    s.add        s2, s12, s1
    @p3 v.st.h       [s4, #0], v1
    a.vread      v1, a6, s6
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s7, s18                     // the tile origin
    s.muli       s4, s18, #2
    v.splat      v1, s1
    s.add        s1, s7, s3                      // the tile origin
    v.splat      v4, s10
    v.add        v5, v0, v1
    v.splat      v0, s1
    s.add        s1, s9, s4
    v.cmp.lt     p1, v4, v2
    @p3 v.st.h       [s2, #0], v3
    a.vread      v1, a7, s7
    v.cmp.lt     p2, v5, v0
    s.add        s2, s12, s1
    vf.cvt.f32.bf16 v0, v1
    s.muli       s1, s8, #1
    p.and        p3, p1, p2
    s.movz       s3, #1
    s.addi       s5, s10, #1
    s.movz       s6, #2
    s.add        s7, s1, s9
    v.splat      v1, s5
    s.add        s1, s7, s4
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a7, s3
    v.cmp.lt     p1, v1, v2
    s.muli       s2, s8, #2
    vf.cvt.f32.bf16 v1, v0
    s.add        s3, s12, s1
    p.and        p3, p1, p2
    s.addi       s1, s10, #2
    s.add        s5, s2, s9
    v.splat      v0, s1
    s.add        s1, s5, s4
    s.movz       s2, #3
    s.add        s5, s12, s1
    @p3 v.st.h       [s3, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s8, #3
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s3, s10, #3
    s.movz       s6, #4
    s.add        s7, s1, s9
    v.splat      v1, s3
    s.add        s1, s7, s4
    s.add        s3, s12, s1
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a7, s2
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #4
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s2, s10, #4
    s.movz       s5, #5
    s.add        s7, s1, s9
    v.splat      v0, s2
    s.add        s1, s7, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s3, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s8, #5
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s3, s10, #5
    s.movz       s6, #6
    s.add        s7, s1, s9
    v.splat      v1, s3
    s.add        s1, s7, s4
    s.add        s3, s12, s1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a7, s5
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #6
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s2, s10, #6
    s.movz       s5, #7
    s.add        s7, s1, s9
    v.splat      v0, s2
    s.add        s1, s7, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s3, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s8, #7
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s3, s10, #7
    s.movz       s6, #8
    s.add        s7, s1, s9
    v.splat      v1, s3
    s.add        s1, s7, s4
    s.add        s3, s12, s1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a7, s5
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #8
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s2, s10, #8
    s.movz       s5, #9
    s.add        s7, s1, s9
    v.splat      v0, s2
    s.add        s1, s7, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s3, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s8, #9
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s3, s10, #9
    s.movz       s6, #10
    s.add        s7, s1, s9
    v.splat      v1, s3
    s.add        s1, s7, s4
    s.add        s3, s12, s1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a7, s5
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #10
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s2, s10, #10
    s.movz       s5, #11
    s.add        s7, s1, s9
    v.splat      v0, s2
    s.add        s1, s7, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s3, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s8, #11
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s3, s10, #11
    s.movz       s6, #12
    s.add        s7, s1, s9
    v.splat      v1, s3
    s.add        s1, s7, s4
    s.add        s3, s12, s1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a7, s5
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #12
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s2, s10, #12
    s.movz       s5, #13
    s.add        s7, s1, s9
    v.splat      v0, s2
    s.add        s1, s7, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s3, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s8, #13
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s3, s10, #13
    s.movz       s6, #14
    s.add        s7, s1, s9
    v.splat      v1, s3
    s.add        s1, s7, s4
    s.add        s3, s12, s1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a7, s5
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s8, #14
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s2, s10, #14
    s.movz       s5, #15
    s.add        s7, s1, s9
    v.splat      v0, s2
    s.add        s1, s7, s4
    s.add        s2, s12, s1
    @p3 v.st.h       [s3, #0], v1
    a.vread      v1, a7, s6
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s8, #15
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s3, s10, #15
    s.add        s6, s1, s9
    v.splat      v1, s3
    s.add        s1, s6, s4
    s.add        s3, s12, s1
    @p3 v.st.h       [s2, #0], v0
    a.vread      v0, a7, s5
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s3, #0], v1
    exit
    exit
