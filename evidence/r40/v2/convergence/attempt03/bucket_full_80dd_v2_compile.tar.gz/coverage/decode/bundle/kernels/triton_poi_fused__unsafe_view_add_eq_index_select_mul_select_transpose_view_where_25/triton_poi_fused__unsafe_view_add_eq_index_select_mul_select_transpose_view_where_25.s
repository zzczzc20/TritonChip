    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, role_id
    s.rdspecial  s5, npid.x
    s.ld.d       s6, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s7, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s8, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s9, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s10, [s1, #40]                  // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s11, [s1, #64]                  // in_ptr8: device_ptr64 at arg_base+64
    s.ld.d       s12, [s1, #72]                  // out_ptr0: device_ptr64 at arg_base+72
__rctx_program:
    s.mul        s1, s4, s2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #0
    v.movi       v2, #6
    v.movi       v3, #64
    v.splat      v4, s1
    v.movi       v5, #576
    v.movi       v6, #0
    v.add        v7, v4, v0
    v.sub        v0, v1, v3
    v.sub        v4, v6, v5
    v.sub        v8, v1, v7
    v.cmp.lt     p1, v7, v1
    v.cmp.lt     p2, v3, v1
    @p1 v.sel        v9, v8, v7
    v.cmp.lt     p3, v5, v6
    v.movi       v8, #1
    v.lshr       v8, v9, v2
    @p2 v.sel        v2, v0, v3
    v.movi       v0, #1
    v.sub        v2, v1, v8
    @p3 v.sel        v1, v4, v5
    v.movi       v4, #0
    @p1 v.sel        v5, v2, v8
    v.movi       v2, #0
    s.movz       s13, #31
    v.sub        v8, v6, v5
    v.cmp.lt     p1, v5, v6
    @p1 v.sel        v9, v8, v5
idiv_1:
    v.splat      v5, s13
    v.shl        v8, v2, v0
    v.cmp.lt     p2, v2, v6
    v.lshr       v10, v9, v5
    v.shl        v11, v0, v5
    s.subi       s14, s13, #1
    v.and        v5, v10, v0
    s.movz       s15, #0
    v.or         v10, v8, v5
    v.cmp.geu    p3, v10, v1
    p.or         p4, p2, p3
    v.sub        v5, v10, v1
    @p4 v.sel        v8, v11, v6
    @p4 v.sel        v11, v5, v10
    v.or         v5, v4, v8
    v.mov        v2, v11
    v.mov        v4, v5
    s.mov        s13, s14
    s.cmp.ge     s14, s13, s15
    br.nz        s14, idiv_1
    v.movi       v0, #0
    v.movi       v1, #63
    s.movz       s13, #36864
    v.splat      v4, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v5, v0, v7
    v.cmp.lt     p2, v7, v0
    v.movi       v8, #0
    @p2 v.sel        v9, v5, v7
    v.sub        v5, v6, v2
    v.sub        v6, v0, v3
    v.and        v10, v9, v1
    v.sub        v1, v8, v7
    v.sub        v9, v8, v4
    v.sub        v11, v0, v10
    v.cmp.lt     p3, v3, v0
    @p1 v.sel        v0, v5, v2
    v.cmp.lt     p1, v7, v8
    v.movi       v2, #1
    @p3 v.sel        v2, v6, v3
    v.cmp.lt     p3, v4, v8
    @p2 v.sel        v2, v11, v10
    v.movi       v5, #1
    @p1 v.sel        v6, v1, v7
    @p3 v.sel        v1, v9, v4
    v.movi       v4, #0
    v.movi       v9, #0
    s.movz       s13, #31
idiv_2:
    v.splat      v10, s13
    v.shl        v11, v9, v5
    v.cmp.lt     p2, v9, v8
    v.lshr       v12, v6, v10
    v.shl        v13, v5, v10
    s.subi       s14, s13, #1
    v.and        v10, v12, v5
    s.movz       s15, #0
    v.or         v12, v11, v10
    v.cmp.geu    p4, v12, v1
    p.or         p5, p2, p4
    v.sub        v10, v12, v1
    @p5 v.sel        v11, v13, v8
    @p5 v.sel        v13, v10, v12
    v.or         v10, v4, v11
    v.mov        v9, v13
    v.mov        v4, v10
    s.mov        s13, s14
    s.cmp.ge     s14, s13, s15
    br.nz        s14, idiv_2
    s.ld.d       s13, [s6, #0]                   // one element, not a vector
    v.movi       v1, #1
    v.movi       v5, #0
    v.movi       v6, #0
    v.shl        v9, v0, v1
    s.addi       s14, s3, #4
    v.sub        v0, v8, v4
    p.xor        p2, p1, p3
    @p2 v.sel        v1, v0, v4
    s.lshri      s15, s13, #32
    v.ld.gather.w v0, [s3, v9]                   // index is in elements (ISA sec 9.1)
    s.lshri      s16, s13, #32
    s.lshri      s17, s13, #32
    s.lshri      s18, s13, #32
    s.lshri      s19, s13, #32
    s.lshri      s20, s13, #32
    v.ld.gather.w v4, [s14, v9]                  // index is in elements (ISA sec 9.1)
    v.insert     v5, s13, #0
    v.insert     v6, s15, #0
    s.lshri      s14, s13, #32
    v.insert     v5, s13, #1
    v.insert     v6, s16, #1
    s.lshri      s15, s13, #32
    v.insert     v5, s13, #2
    v.insert     v6, s17, #2
    s.lshri      s16, s13, #32
    v.insert     v5, s13, #3
    v.insert     v6, s18, #3
    s.lshri      s17, s13, #32
    v.insert     v5, s13, #4
    v.insert     v6, s19, #4
    s.lshri      s18, s13, #32
    v.insert     v5, s13, #5
    v.insert     v6, s20, #5
    s.lshri      s19, s13, #32
    v.insert     v5, s13, #6
    v.insert     v6, s14, #6
    s.lshri      s14, s13, #32
    v.insert     v5, s13, #7
    v.insert     v6, s15, #7
    s.lshri      s15, s13, #32
    v.insert     v5, s13, #8
    v.insert     v6, s16, #8
    s.lshri      s16, s13, #32
    v.insert     v5, s13, #9
    v.insert     v6, s17, #9
    s.lshri      s17, s13, #32
    v.insert     v5, s13, #10
    v.insert     v6, s18, #10
    v.extract    s18, v4, #0
    v.insert     v5, s13, #11
    v.insert     v6, s19, #11
    v.mul        v8, v1, v3
    v.insert     v5, s13, #12
    v.insert     v6, s14, #12
    .li       s14, #294912
    v.splat      v1, s14                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.insert     v5, s13, #13
    v.insert     v6, s15, #13
    v.extract    s14, v0, #0
    v.insert     v5, s13, #14
    v.insert     v6, s16, #14
    s.shli       s15, s18, #32
    v.insert     v5, s13, #15
    v.insert     v6, s17, #15
    v.extract    s13, v4, #1
    v.extract    s16, v5, #0
    v.extract    s17, v6, #0
    v.extract    s18, v6, #1
    s.shli       s19, s17, #32
    s.or         s17, s14, s15
    s.or         s14, s16, s19
    v.add        v3, v2, v8
    v.add        v8, v7, v1
    v.movi       v1, #0
    v.extract    s15, v0, #1
    s.shli       s16, s13, #32
    v.extract    s13, v5, #1
    s.shli       s19, s18, #32
    s.cmp.eq     s18, s17, s14
    v.extract    s14, v4, #2
    v.extract    s17, v6, #2
    s.or         s20, s15, s16
    s.or         s15, s13, s19
    v.ld.gather.h v7, [s7, v3]                   // index is in elements (ISA sec 9.1)
    v.extract    s13, v0, #2
    s.shli       s16, s14, #32
    v.extract    s14, v5, #2
    s.shli       s19, s17, #32
    s.cmp.eq     s17, s20, s15
    v.extract    s15, v4, #3
    s.or         s20, s13, s16
    s.or         s13, s14, s19
    v.extract    s14, v0, #3
    s.shli       s16, s15, #32
    v.extract    s15, v5, #3
    s.cmp.eq     s19, s20, s13
    s.or         s13, s14, s16
    v.ld.gather.h v9, [s9, v3]                   // index is in elements (ISA sec 9.1)
    s.movz       s14, #64
    v.extract    s14, v6, #3
    vf.cvt.f16.f32 v3, v7
    s.shli       s16, s14, #32
    v.extract    s14, v0, #4
    s.or         s20, s15, s16
    .li       s15, #294912
    s.cmp.eq     s15, s13, s20
    v.ld.gather.h v7, [s11, v8]                  // index is in elements (ISA sec 9.1)
    v.insert     v1, s18, #0
    vf.cvt.f16.f32 v8, v9
    v.extract    s13, v4, #4
    v.insert     v1, s17, #1
    v.extract    s16, v6, #4
    s.shli       s17, s13, #32
    v.insert     v1, s19, #2
    v.extract    s13, v5, #4
    s.or         s18, s14, s17
    v.insert     v1, s15, #3
    vf.cvt.f16.f32 v9, v7
    s.shli       s14, s16, #32
    v.extract    s15, v4, #5
    v.extract    s16, v6, #5
    s.or         s17, s13, s14
    v.extract    s13, v0, #5
    s.shli       s14, s15, #32
    v.extract    s15, v5, #5
    s.shli       s19, s16, #32
    s.cmp.eq     s16, s18, s17
    v.extract    s17, v4, #6
    v.extract    s18, v6, #6
    s.or         s20, s13, s14
    s.or         s13, s15, s19
    v.insert     v1, s16, #4
    v.extract    s14, v0, #6
    s.shli       s15, s17, #32
    v.extract    s16, v5, #6
    s.shli       s17, s18, #32
    s.cmp.eq     s18, s20, s13
    v.extract    s13, v4, #7
    v.extract    s19, v6, #7
    s.or         s20, s14, s15
    s.or         s14, s16, s17
    v.insert     v1, s18, #5
    v.extract    s15, v0, #7
    s.shli       s16, s13, #32
    v.extract    s13, v5, #7
    s.shli       s17, s19, #32
    s.cmp.eq     s18, s20, s14
    v.extract    s14, v4, #8
    v.extract    s19, v6, #8
    s.or         s20, s15, s16
    s.or         s15, s13, s17
    v.insert     v1, s18, #6
    v.extract    s13, v0, #8
    s.shli       s16, s14, #32
    v.extract    s14, v5, #8
    s.shli       s17, s19, #32
    s.cmp.eq     s18, s20, s15
    v.extract    s15, v4, #9
    v.extract    s19, v6, #9
    s.or         s20, s13, s16
    s.or         s13, s14, s17
    v.insert     v1, s18, #7
    v.extract    s14, v0, #9
    s.shli       s16, s15, #32
    v.extract    s15, v5, #9
    s.shli       s17, s19, #32
    s.cmp.eq     s18, s20, s13
    v.extract    s13, v4, #10
    v.extract    s19, v6, #10
    s.or         s20, s14, s16
    s.or         s14, s15, s17
    v.insert     v1, s18, #8
    v.extract    s15, v0, #10
    s.shli       s16, s13, #32
    v.extract    s13, v5, #10
    s.shli       s17, s19, #32
    s.cmp.eq     s18, s20, s14
    v.extract    s14, v4, #11
    v.extract    s19, v6, #11
    s.or         s20, s15, s16
    s.or         s15, s13, s17
    v.insert     v1, s18, #9
    v.extract    s13, v0, #11
    s.shli       s16, s14, #32
    v.extract    s14, v5, #11
    s.shli       s17, s19, #32
    s.cmp.eq     s18, s20, s15
    v.extract    s15, v4, #12
    v.extract    s19, v6, #12
    s.or         s20, s13, s16
    s.or         s13, s14, s17
    v.insert     v1, s18, #10
    v.extract    s14, v0, #12
    s.shli       s16, s15, #32
    v.extract    s15, v5, #12
    s.shli       s17, s19, #32
    s.cmp.eq     s18, s20, s13
    v.extract    s13, v4, #13
    v.extract    s19, v6, #13
    s.or         s20, s14, s16
    s.or         s14, s15, s17
    v.insert     v1, s18, #11
    v.extract    s15, v0, #13
    s.shli       s16, s13, #32
    v.extract    s13, v5, #13
    s.shli       s17, s19, #32
    s.cmp.eq     s18, s20, s14
    v.extract    s14, v4, #14
    v.extract    s19, v6, #14
    s.or         s20, s15, s16
    s.or         s15, s13, s17
    v.extract    s13, v6, #0
    v.insert     v1, s18, #12
    v.extract    s16, v0, #14
    s.shli       s17, s14, #32
    v.extract    s14, v5, #14
    s.shli       s18, s19, #32
    s.cmp.eq     s19, s20, s15
    v.extract    s15, v4, #15
    v.extract    s20, v6, #15
    s.shli       s21, s13, #32
    s.or         s13, s16, s17
    v.extract    s16, v5, #0
    s.or         s17, s14, s18
    v.extract    s14, v6, #1
    v.insert     v1, s19, #13
    v.extract    s18, v0, #15
    s.shli       s19, s15, #32
    s.shli       s15, s20, #32
    s.or         s20, s16, s21
    v.extract    s16, v5, #15
    s.cmp.eq     s21, s13, s17
    s.movz       s13, #576
    s.shli       s17, s14, #32
    s.or         s14, s18, s19
    v.extract    s18, v5, #1
    s.or         s19, s16, s15
    s.add        s15, s20, s13
    v.extract    s13, v6, #2
    v.insert     v1, s21, #14
    v.movi       v0, #0
    v.movi       v4, #0
    s.or         s16, s18, s17
    s.movz       s17, #576
    s.cmp.eq     s18, s14, s19
    s.lshri      s14, s15, #32
    v.extract    s19, v5, #2
    s.shli       s20, s13, #32
    s.add        s13, s16, s17
    v.extract    s16, v6, #3
    v.insert     v1, s18, #15
    v.insert     v0, s15, #0
    v.insert     v4, s14, #0
    s.or         s14, s19, s20
    s.movz       s15, #576
    s.lshri      s17, s13, #32
    v.extract    s18, v5, #3
    s.shli       s19, s16, #32
    s.add        s16, s14, s15
    v.extract    s14, v6, #4
    v.insert     v0, s13, #1
    v.insert     v4, s17, #1
    s.or         s13, s18, s19
    s.movz       s15, #576
    s.lshri      s17, s16, #32
    v.extract    s18, v5, #4
    s.shli       s19, s14, #32
    s.add        s14, s13, s15
    v.insert     v0, s16, #2
    v.insert     v4, s17, #2
    s.or         s13, s18, s19
    s.movz       s15, #576
    s.lshri      s16, s14, #32
    s.add        s17, s13, s15
    v.insert     v0, s14, #3
    v.insert     v4, s16, #3
    s.lshri      s13, s17, #32
    v.insert     v0, s17, #4
    v.movi       v7, #0
    v.insert     v4, s13, #4
    v.cmp.ne     p1, v1, v7
    v.extract    s13, v6, #5
    v.extract    s14, v5, #5
    s.shli       s15, s13, #32
    v.extract    s13, v6, #6
    s.or         s16, s14, s15
    s.movz       s14, #576
    v.extract    s15, v5, #6
    s.shli       s17, s13, #32
    s.add        s13, s16, s14
    v.extract    s14, v6, #7
    s.or         s16, s15, s17
    s.movz       s15, #576
    s.lshri      s17, s13, #32
    v.extract    s18, v5, #7
    s.shli       s19, s14, #32
    s.add        s14, s16, s15
    v.extract    s15, v6, #8
    v.insert     v0, s13, #5
    v.insert     v4, s17, #5
    s.or         s13, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s14, #32
    v.extract    s18, v5, #8
    s.shli       s19, s15, #32
    s.add        s15, s13, s16
    v.extract    s13, v6, #9
    v.insert     v0, s14, #6
    v.insert     v4, s17, #6
    s.or         s14, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s15, #32
    v.extract    s18, v5, #9
    s.shli       s19, s13, #32
    s.add        s13, s14, s16
    v.extract    s14, v6, #10
    v.insert     v0, s15, #7
    v.insert     v4, s17, #7
    s.or         s15, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s13, #32
    v.extract    s18, v5, #10
    s.shli       s19, s14, #32
    s.add        s14, s15, s16
    v.extract    s15, v6, #11
    v.insert     v0, s13, #8
    v.insert     v4, s17, #8
    s.or         s13, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s14, #32
    v.extract    s18, v5, #11
    s.shli       s19, s15, #32
    s.add        s15, s13, s16
    v.extract    s13, v6, #12
    v.insert     v0, s14, #9
    v.insert     v4, s17, #9
    s.or         s14, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s15, #32
    v.extract    s18, v5, #12
    s.shli       s19, s13, #32
    s.add        s13, s14, s16
    v.extract    s14, v6, #13
    v.insert     v0, s15, #10
    v.insert     v4, s17, #10
    s.or         s15, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s13, #32
    v.extract    s18, v5, #13
    s.shli       s19, s14, #32
    s.add        s14, s15, s16
    v.extract    s15, v6, #14
    v.insert     v0, s13, #11
    v.insert     v4, s17, #11
    s.or         s13, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s14, #32
    v.extract    s18, v5, #14
    s.shli       s19, s15, #32
    s.add        s15, s13, s16
    v.extract    s13, v6, #15
    v.insert     v0, s14, #12
    v.insert     v4, s17, #12
    s.or         s14, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s15, #32
    v.extract    s18, v5, #15
    s.shli       s19, s13, #32
    v.extract    s13, v6, #0
    s.add        s20, s14, s16
    v.insert     v0, s15, #13
    v.insert     v4, s17, #13
    s.or         s14, s18, s19
    s.movz       s15, #576
    v.extract    s16, v5, #0
    s.shli       s17, s13, #32
    s.lshri      s13, s20, #32
    v.extract    s18, v6, #1
    s.add        s19, s14, s15
    s.or         s14, s16, s17
    s.movz       s15, #0
    v.insert     v0, s20, #14
    v.insert     v4, s13, #14
    v.movi       v1, #0
    v.extract    s13, v5, #1
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    s.cmp.lt     s18, s14, s15
    v.extract    s14, v6, #2
    s.or         s15, s13, s16
    s.movz       s13, #0
    v.insert     v0, s19, #15
    v.insert     v4, s17, #15
    v.insert     v1, s18, #0
    v.extract    s16, v5, #2
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s15, s13
    v.extract    s13, v6, #3
    s.or         s15, s16, s17
    s.movz       s16, #0
    v.insert     v1, s14, #1
    v.extract    s14, v5, #3
    s.shli       s17, s13, #32
    s.cmp.lt     s13, s15, s16
    v.extract    s15, v6, #4
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v1, s13, #2
    v.extract    s13, v5, #4
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s16, s14
    v.extract    s14, v6, #5
    s.or         s16, s13, s17
    s.movz       s13, #0
    v.insert     v1, s15, #3
    v.extract    s15, v5, #5
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s16, s13
    v.extract    s13, v6, #6
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v1, s14, #4
    v.extract    s14, v5, #6
    s.shli       s17, s13, #32
    s.cmp.lt     s13, s16, s15
    v.extract    s15, v6, #7
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v1, s13, #5
    v.extract    s13, v5, #7
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s16, s14
    v.extract    s14, v6, #8
    s.or         s16, s13, s17
    s.movz       s13, #0
    v.insert     v1, s15, #6
    v.extract    s15, v5, #8
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s16, s13
    v.extract    s13, v6, #9
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v1, s14, #7
    v.extract    s14, v5, #9
    s.shli       s17, s13, #32
    s.cmp.lt     s13, s16, s15
    v.extract    s15, v6, #10
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v1, s13, #8
    v.extract    s13, v5, #10
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s16, s14
    v.extract    s14, v6, #11
    s.or         s16, s13, s17
    s.movz       s13, #0
    v.insert     v1, s15, #9
    v.extract    s15, v5, #11
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s16, s13
    v.extract    s13, v6, #12
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v1, s14, #10
    v.extract    s14, v5, #12
    s.shli       s17, s13, #32
    s.cmp.lt     s13, s16, s15
    v.extract    s15, v6, #13
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v1, s13, #11
    v.extract    s13, v5, #13
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s16, s14
    v.extract    s14, v6, #14
    s.or         s16, s13, s17
    s.movz       s13, #0
    v.insert     v1, s15, #12
    v.extract    s15, v5, #14
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s16, s13
    v.extract    s13, v6, #15
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v1, s14, #13
    v.extract    s14, v5, #15
    s.shli       s17, s13, #32
    s.cmp.lt     s13, s16, s15
    s.or         s15, s14, s17
    s.movz       s14, #0
    v.insert     v1, s13, #14
    s.cmp.lt     s13, s15, s14
    v.movi       v7, #0
    v.insert     v1, s13, #15
    v.movi       v10, #1
    v.movi       v11, #0
    v.extract    s13, v4, #0
    v.extract    s14, v6, #0
    v.cmp.ne     p2, v1, v7
    v.extract    s15, v0, #0
    s.shli       s16, s13, #32
    v.extract    s13, v5, #0
    s.shli       s17, s14, #32
    @p2 v.sel        v1, v10, v11
    v.extract    s14, v4, #1
    v.extract    s18, v6, #1
    s.or         s19, s15, s16
    s.or         s15, s13, s17
    v.extract    s13, v0, #1
    s.shli       s16, s14, #32
    v.extract    s14, v5, #1
    s.shli       s17, s18, #32
    v.extract    s18, v1, #0
    s.sub        s20, s19, s15
    v.extract    s19, v4, #2
    s.or         s21, s13, s16
    v.extract    s13, v6, #2
    s.or         s16, s14, s17
    s.mul        s14, s18, s20
    v.extract    s17, v0, #2
    s.shli       s18, s19, #32
    v.extract    s19, v5, #2
    s.shli       s20, s13, #32
    s.sub        s13, s21, s16
    s.or         s21, s17, s18
    v.extract    s17, v1, #1
    s.or         s18, s19, s20
    s.mul        s19, s17, s13
    v.extract    s13, v1, #2
    s.sub        s17, s21, s18
    s.add        s20, s15, s14
    v.movi       v7, #0
    v.extract    s14, v0, #3
    v.movi       v10, #0
    v.extract    s15, v4, #3
    s.mul        s21, s13, s17
    v.extract    s13, v6, #3
    s.shli       s17, s15, #32
    s.shli       s15, s13, #32
    s.or         s13, s14, s17
    v.extract    s14, v5, #3
    s.add        s17, s16, s19
    s.or         s16, s14, s15
    s.lshri      s14, s20, #32
    v.extract    s15, v1, #3
    s.sub        s19, s13, s16
    v.insert     v7, s20, #0
    v.extract    s13, v0, #4
    v.insert     v10, s14, #0
    v.extract    s14, v4, #4
    s.mul        s20, s15, s19
    v.extract    s15, v6, #4
    s.shli       s19, s14, #32
    s.shli       s14, s15, #32
    s.or         s15, s13, s19
    v.extract    s13, v5, #4
    s.add        s19, s18, s21
    s.or         s18, s13, s14
    s.lshri      s13, s17, #32
    v.extract    s14, v1, #4
    s.sub        s21, s15, s18
    v.insert     v7, s17, #1
    v.extract    s15, v0, #5
    v.insert     v10, s13, #1
    v.extract    s13, v4, #5
    s.mul        s17, s14, s21
    v.extract    s14, v6, #5
    s.shli       s21, s13, #32
    s.shli       s13, s14, #32
    s.or         s14, s15, s21
    v.extract    s15, v5, #5
    s.add        s21, s16, s20
    s.or         s16, s15, s13
    s.lshri      s13, s19, #32
    v.extract    s15, v1, #5
    s.sub        s20, s14, s16
    v.insert     v7, s19, #2
    v.extract    s14, v0, #6
    v.insert     v10, s13, #2
    v.extract    s13, v4, #6
    s.mul        s19, s15, s20
    v.extract    s15, v6, #6
    s.shli       s20, s13, #32
    s.shli       s13, s15, #32
    s.or         s15, s14, s20
    v.extract    s14, v5, #6
    s.add        s20, s18, s17
    s.or         s17, s14, s13
    s.lshri      s13, s21, #32
    v.extract    s14, v1, #6
    s.sub        s18, s15, s17
    v.insert     v7, s21, #3
    v.extract    s15, v0, #7
    v.insert     v10, s13, #3
    v.extract    s13, v4, #7
    s.mul        s21, s14, s18
    v.extract    s14, v6, #7
    s.shli       s18, s13, #32
    s.shli       s13, s14, #32
    s.or         s14, s15, s18
    v.extract    s15, v5, #7
    s.add        s18, s16, s19
    s.or         s16, s15, s13
    s.lshri      s13, s20, #32
    v.extract    s15, v1, #7
    s.sub        s19, s14, s16
    v.insert     v7, s20, #4
    v.extract    s14, v0, #8
    v.insert     v10, s13, #4
    v.extract    s13, v4, #8
    s.mul        s20, s15, s19
    v.extract    s15, v6, #8
    s.shli       s19, s13, #32
    s.shli       s13, s15, #32
    s.or         s15, s14, s19
    v.extract    s14, v5, #8
    s.add        s19, s17, s21
    s.or         s17, s14, s13
    s.lshri      s13, s18, #32
    v.extract    s14, v1, #8
    s.sub        s21, s15, s17
    v.insert     v7, s18, #5
    v.extract    s15, v0, #9
    v.insert     v10, s13, #5
    v.extract    s13, v4, #9
    s.mul        s18, s14, s21
    v.extract    s14, v6, #9
    s.shli       s21, s13, #32
    s.shli       s13, s14, #32
    s.or         s14, s15, s21
    v.extract    s15, v5, #9
    s.add        s21, s16, s20
    s.or         s16, s15, s13
    s.lshri      s13, s19, #32
    v.extract    s15, v1, #9
    s.sub        s20, s14, s16
    v.insert     v7, s19, #6
    v.extract    s14, v0, #10
    v.insert     v10, s13, #6
    v.extract    s13, v4, #10
    s.mul        s19, s15, s20
    v.extract    s15, v6, #10
    s.shli       s20, s13, #32
    s.shli       s13, s15, #32
    s.or         s15, s14, s20
    v.extract    s14, v5, #10
    s.add        s20, s17, s18
    s.or         s17, s14, s13
    s.lshri      s13, s21, #32
    v.extract    s14, v1, #10
    s.sub        s18, s15, s17
    v.insert     v7, s21, #7
    v.extract    s15, v0, #11
    v.insert     v10, s13, #7
    v.extract    s13, v4, #11
    s.mul        s21, s14, s18
    v.extract    s14, v6, #11
    s.shli       s18, s13, #32
    s.shli       s13, s14, #32
    s.or         s14, s15, s18
    v.extract    s15, v5, #11
    s.add        s18, s16, s19
    s.or         s16, s15, s13
    s.lshri      s13, s20, #32
    v.extract    s15, v1, #11
    s.sub        s19, s14, s16
    v.insert     v7, s20, #8
    v.extract    s14, v0, #12
    v.insert     v10, s13, #8
    v.extract    s13, v4, #12
    s.mul        s20, s15, s19
    v.extract    s15, v6, #12
    s.shli       s19, s13, #32
    s.shli       s13, s15, #32
    s.or         s15, s14, s19
    v.extract    s14, v5, #12
    s.add        s19, s17, s21
    s.or         s17, s14, s13
    s.lshri      s13, s18, #32
    v.extract    s14, v1, #12
    s.sub        s21, s15, s17
    v.insert     v7, s18, #9
    v.extract    s15, v0, #13
    v.insert     v10, s13, #9
    v.extract    s13, v4, #13
    s.mul        s18, s14, s21
    v.extract    s14, v6, #13
    s.shli       s21, s13, #32
    s.shli       s13, s14, #32
    s.or         s14, s15, s21
    v.extract    s15, v5, #13
    s.add        s21, s16, s20
    s.or         s16, s15, s13
    s.lshri      s13, s19, #32
    v.extract    s15, v1, #13
    s.sub        s20, s14, s16
    v.insert     v7, s19, #10
    v.extract    s14, v0, #14
    v.insert     v10, s13, #10
    v.extract    s13, v4, #14
    s.mul        s19, s15, s20
    v.extract    s15, v6, #14
    s.shli       s20, s13, #32
    s.shli       s13, s15, #32
    s.or         s15, s14, s20
    v.extract    s14, v5, #14
    s.add        s20, s17, s18
    s.or         s17, s14, s13
    s.lshri      s13, s21, #32
    v.extract    s14, v1, #14
    s.sub        s18, s15, s17
    v.insert     v7, s21, #11
    v.extract    s15, v0, #15
    v.insert     v10, s13, #11
    v.extract    s13, v4, #15
    s.mul        s21, s14, s18
    v.extract    s14, v6, #15
    s.shli       s18, s13, #32
    s.shli       s13, s14, #32
    s.or         s14, s15, s18
    v.extract    s15, v5, #15
    s.add        s18, s16, s19
    s.or         s16, s15, s13
    s.lshri      s13, s20, #32
    v.extract    s15, v1, #15
    s.sub        s19, s14, s16
    v.insert     v7, s20, #12
    v.insert     v10, s13, #12
    s.mul        s13, s15, s19
    s.lshri      s14, s18, #32
    s.add        s15, s17, s21
    v.insert     v7, s18, #13
    v.insert     v10, s14, #13
    s.lshri      s14, s15, #32
    s.add        s17, s16, s13
    v.insert     v7, s15, #14
    v.insert     v10, s14, #14
    s.lshri      s13, s17, #32
    v.insert     v7, s17, #15
    v.insert     v10, s13, #15
    s.movz       s13, #0
    v.extract    s14, v7, #0
    v.extract    s15, v10, #0
    v.extract    s16, v10, #1
    s.shli       s17, s15, #32
    v.movi       v0, #0
    s.or         s15, s14, s17
    v.extract    s14, v7, #1
    s.shli       s17, s16, #32
    s.cmp.ge     s16, s15, s13
    v.extract    s13, v10, #2
    s.or         s15, s14, s17
    s.movz       s14, #0
    v.insert     v0, s16, #0
    v.extract    s16, v7, #2
    s.shli       s17, s13, #32
    s.cmp.ge     s13, s15, s14
    v.extract    s14, v10, #3
    s.or         s15, s16, s17
    s.movz       s16, #0
    v.insert     v0, s13, #1
    v.extract    s13, v7, #3
    s.shli       s17, s14, #32
    s.cmp.ge     s14, s15, s16
    v.extract    s15, v10, #4
    s.or         s16, s13, s17
    s.movz       s13, #0
    v.insert     v0, s14, #2
    v.extract    s14, v7, #4
    s.shli       s17, s15, #32
    s.cmp.ge     s15, s16, s13
    v.extract    s13, v10, #5
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v0, s15, #3
    v.extract    s15, v7, #5
    s.shli       s17, s13, #32
    s.cmp.ge     s13, s16, s14
    v.extract    s14, v10, #6
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v0, s13, #4
    v.extract    s13, v7, #6
    s.shli       s17, s14, #32
    s.cmp.ge     s14, s16, s15
    v.extract    s15, v10, #7
    s.or         s16, s13, s17
    s.movz       s13, #0
    v.insert     v0, s14, #5
    v.extract    s14, v7, #7
    s.shli       s17, s15, #32
    s.cmp.ge     s15, s16, s13
    v.extract    s13, v10, #8
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v0, s15, #6
    v.extract    s15, v7, #8
    s.shli       s17, s13, #32
    s.cmp.ge     s13, s16, s14
    v.extract    s14, v10, #9
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v0, s13, #7
    v.extract    s13, v7, #9
    s.shli       s17, s14, #32
    s.cmp.ge     s14, s16, s15
    v.extract    s15, v10, #10
    s.or         s16, s13, s17
    s.movz       s13, #0
    v.insert     v0, s14, #8
    v.extract    s14, v7, #10
    s.shli       s17, s15, #32
    s.cmp.ge     s15, s16, s13
    v.extract    s13, v10, #11
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v0, s15, #9
    v.extract    s15, v7, #11
    s.shli       s17, s13, #32
    s.cmp.ge     s13, s16, s14
    v.extract    s14, v10, #12
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v0, s13, #10
    v.extract    s13, v7, #12
    s.shli       s17, s14, #32
    s.cmp.ge     s14, s16, s15
    v.extract    s15, v10, #13
    s.or         s16, s13, s17
    s.movz       s13, #0
    v.insert     v0, s14, #11
    v.extract    s14, v7, #13
    s.shli       s17, s15, #32
    s.cmp.ge     s15, s16, s13
    v.extract    s13, v10, #14
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v0, s15, #12
    v.extract    s15, v7, #14
    s.shli       s17, s13, #32
    s.cmp.ge     s13, s16, s14
    v.extract    s14, v10, #15
    v.extract    s16, v10, #0
    s.or         s18, s15, s17
    s.movz       s15, #0
    v.insert     v0, s13, #13
    v.extract    s13, v7, #15
    s.shli       s17, s14, #32
    v.extract    s14, v7, #0
    s.shli       s19, s16, #32
    s.cmp.ge     s16, s18, s15
    v.extract    s15, v10, #1
    s.or         s18, s13, s17
    s.movz       s13, #0
    s.or         s17, s14, s19
    s.movz       s14, #576
    v.insert     v0, s16, #14
    v.movi       v1, #0
    v.extract    s16, v7, #1
    s.shli       s19, s15, #32
    s.cmp.ge     s15, s18, s13
    s.cmp.lt     s13, s17, s14
    v.extract    s14, v10, #2
    s.or         s17, s16, s19
    s.movz       s16, #576
    v.insert     v0, s15, #15
    v.insert     v1, s13, #0
    v.extract    s13, v7, #2
    s.shli       s15, s14, #32
    s.cmp.lt     s14, s17, s16
    v.extract    s16, v10, #3
    s.or         s17, s13, s15
    s.movz       s13, #576
    v.insert     v1, s14, #1
    v.extract    s14, v7, #3
    s.shli       s15, s16, #32
    s.cmp.lt     s16, s17, s13
    v.extract    s13, v10, #4
    s.or         s17, s14, s15
    s.movz       s14, #576
    v.insert     v1, s16, #2
    v.extract    s15, v7, #4
    s.shli       s16, s13, #32
    s.cmp.lt     s13, s17, s14
    v.extract    s14, v10, #5
    s.or         s17, s15, s16
    s.movz       s15, #576
    v.insert     v1, s13, #3
    v.extract    s13, v7, #5
    s.shli       s16, s14, #32
    s.cmp.lt     s14, s17, s15
    v.extract    s15, v10, #6
    s.or         s17, s13, s16
    s.movz       s13, #576
    v.insert     v1, s14, #4
    v.extract    s14, v7, #6
    s.shli       s16, s15, #32
    s.cmp.lt     s15, s17, s13
    v.movi       v4, #0
    s.or         s13, s14, s16
    v.insert     v1, s15, #5
    v.cmp.ne     p2, v0, v4
    v.extract    s14, v10, #7
    s.movz       s15, #576
    v.extract    s16, v7, #7
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s13, s15
    v.extract    s13, v10, #8
    s.or         s15, s16, s17
    s.movz       s16, #576
    v.insert     v1, s14, #6
    v.extract    s14, v7, #8
    s.shli       s17, s13, #32
    s.cmp.lt     s13, s15, s16
    v.extract    s15, v10, #9
    s.or         s16, s14, s17
    s.movz       s14, #576
    v.insert     v1, s13, #7
    v.extract    s13, v7, #9
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s16, s14
    v.extract    s14, v10, #10
    s.or         s16, s13, s17
    s.movz       s13, #576
    v.insert     v1, s15, #8
    v.extract    s15, v7, #10
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s16, s13
    v.extract    s13, v10, #11
    s.or         s16, s15, s17
    s.movz       s15, #576
    v.insert     v1, s14, #9
    v.extract    s14, v7, #11
    s.shli       s17, s13, #32
    s.cmp.lt     s13, s16, s15
    v.extract    s15, v10, #12
    s.or         s16, s14, s17
    s.movz       s14, #576
    v.insert     v1, s13, #10
    v.extract    s13, v7, #12
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s16, s14
    v.extract    s14, v10, #13
    s.or         s16, s13, s17
    s.movz       s13, #576
    v.insert     v1, s15, #11
    v.extract    s15, v7, #13
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s16, s13
    v.extract    s13, v10, #14
    s.or         s16, s15, s17
    s.movz       s15, #576
    v.insert     v1, s14, #12
    v.extract    s14, v7, #14
    s.shli       s17, s13, #32
    s.cmp.lt     s13, s16, s15
    v.extract    s15, v10, #15
    s.or         s16, s14, s17
    s.movz       s14, #576
    v.insert     v1, s13, #13
    v.extract    s13, v7, #15
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s16, s14
    s.or         s14, s13, s17
    s.movz       s13, #576
    v.insert     v1, s15, #14
    s.cmp.lt     s15, s14, s13
    v.movi       v0, #0
    v.insert     v1, s15, #15
    v.movi       v4, #0
    v.movi       v5, #1
    v.cmp.ne     p3, v1, v0
    p.and        p4, p2, p3
    s.movz       s13, #0
    @p4 v.sel        v0, v4, v5
    v.reduce.or  s14, v0
    s.cmp.eq     s15, s14, s13
    br.nz        s15, assert_ok_3
    trap         #677351
assert_ok_3:
    v.extract    s13, v10, #0
    v.extract    s14, v7, #0
    s.shli       s15, s13, #32
    v.extract    s13, v10, #1
    s.or         s16, s14, s15
    s.movz       s14, #64
    v.extract    s15, v7, #1
    s.shli       s17, s13, #32
    s.mul        s13, s16, s14
    v.extract    s14, v10, #2
    s.or         s16, s15, s17
    s.movz       s15, #64
    v.extract    s17, v7, #2
    s.shli       s18, s14, #32
    s.mul        s14, s16, s15
    v.extract    s15, v10, #3
    v.movi       v0, #0
    v.movi       v1, #0
    s.or         s16, s17, s18
    s.movz       s17, #64
    s.lshri      s18, s13, #32
    v.extract    s19, v7, #3
    s.shli       s20, s15, #32
    s.mul        s15, s16, s17
    v.extract    s16, v10, #4
    v.insert     v0, s13, #0
    v.insert     v1, s18, #0
    s.or         s13, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s14, #32
    v.extract    s19, v7, #4
    s.shli       s20, s16, #32
    s.mul        s16, s13, s17
    v.extract    s13, v10, #5
    v.insert     v0, s14, #1
    v.insert     v1, s18, #1
    s.or         s14, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s15, #32
    v.extract    s19, v7, #5
    s.shli       s20, s13, #32
    s.mul        s13, s14, s17
    v.extract    s14, v10, #6
    v.insert     v0, s15, #2
    v.insert     v1, s18, #2
    s.or         s15, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s16, #32
    v.extract    s19, v7, #6
    s.shli       s20, s14, #32
    s.mul        s14, s15, s17
    v.extract    s15, v10, #7
    v.insert     v0, s16, #3
    v.insert     v1, s18, #3
    s.or         s16, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s13, #32
    v.extract    s19, v7, #7
    s.shli       s20, s15, #32
    s.mul        s15, s16, s17
    v.extract    s16, v10, #8
    v.insert     v0, s13, #4
    v.insert     v1, s18, #4
    s.or         s13, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s14, #32
    v.extract    s19, v7, #8
    s.shli       s20, s16, #32
    s.mul        s16, s13, s17
    v.extract    s13, v10, #9
    v.insert     v0, s14, #5
    v.insert     v1, s18, #5
    s.or         s14, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s15, #32
    v.extract    s19, v7, #9
    s.shli       s20, s13, #32
    s.mul        s13, s14, s17
    v.extract    s14, v10, #10
    v.insert     v0, s15, #6
    v.insert     v1, s18, #6
    s.or         s15, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s16, #32
    v.extract    s19, v7, #10
    s.shli       s20, s14, #32
    s.mul        s14, s15, s17
    v.extract    s15, v10, #11
    v.insert     v0, s16, #7
    v.insert     v1, s18, #7
    s.or         s16, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s13, #32
    v.extract    s19, v7, #11
    s.shli       s20, s15, #32
    s.mul        s15, s16, s17
    v.extract    s16, v10, #12
    v.insert     v0, s13, #8
    v.insert     v1, s18, #8
    s.or         s13, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s14, #32
    v.extract    s19, v7, #12
    s.shli       s20, s16, #32
    s.mul        s16, s13, s17
    v.extract    s13, v10, #13
    v.insert     v0, s14, #9
    v.insert     v1, s18, #9
    s.or         s14, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s15, #32
    v.extract    s19, v7, #13
    s.shli       s20, s13, #32
    s.mul        s13, s14, s17
    v.extract    s14, v10, #14
    v.insert     v0, s15, #10
    v.insert     v1, s18, #10
    s.or         s15, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s16, #32
    v.extract    s19, v7, #14
    s.shli       s20, s14, #32
    s.mul        s14, s15, s17
    v.extract    s15, v10, #15
    v.insert     v0, s16, #11
    v.insert     v1, s18, #11
    s.or         s16, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s13, #32
    v.extract    s19, v7, #15
    s.shli       s20, s15, #32
    s.mul        s15, s16, s17
    v.insert     v0, s13, #12
    v.insert     v1, s18, #12
    s.or         s13, s19, s20
    s.movz       s16, #64
    s.lshri      s17, s14, #32
    v.extract    s18, v2, #0
    s.mul        s19, s13, s16
    v.insert     v0, s14, #13
    v.insert     v1, s17, #13
    s.shli       s13, s18, #32
    s.lshri      s14, s15, #32
    v.extract    s16, v2, #1
    s.ashri      s17, s13, #32
    v.insert     v0, s15, #14
    v.insert     v1, s14, #14
    v.movi       v4, #0
    v.movi       v5, #0
    s.shli       s13, s16, #32
    s.lshri      s14, s19, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v2, #2
    s.ashri      s18, s13, #32
    v.insert     v0, s19, #15
    v.insert     v1, s14, #15
    v.insert     v4, s17, #0
    v.insert     v5, s15, #0
    s.shli       s13, s16, #32
    s.lshri      s14, s18, #32
    v.extract    s15, v2, #3
    s.ashri      s16, s13, #32
    v.insert     v4, s18, #1
    v.insert     v5, s14, #1
    s.shli       s13, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v2, #4
    s.ashri      s17, s13, #32
    v.insert     v4, s16, #2
    v.insert     v5, s14, #2
    s.shli       s13, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v2, #5
    s.ashri      s16, s13, #32
    v.insert     v4, s17, #3
    v.insert     v5, s14, #3
    s.shli       s13, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v2, #6
    s.ashri      s17, s13, #32
    v.insert     v4, s16, #4
    v.insert     v5, s14, #4
    s.shli       s13, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v2, #7
    s.ashri      s16, s13, #32
    v.insert     v4, s17, #5
    v.insert     v5, s14, #5
    s.shli       s13, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v2, #8
    s.ashri      s17, s13, #32
    v.insert     v4, s16, #6
    v.insert     v5, s14, #6
    s.shli       s13, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v2, #9
    s.ashri      s16, s13, #32
    v.insert     v4, s17, #7
    v.insert     v5, s14, #7
    s.shli       s13, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v2, #10
    s.ashri      s17, s13, #32
    v.insert     v4, s16, #8
    v.insert     v5, s14, #8
    s.shli       s13, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v2, #11
    s.ashri      s16, s13, #32
    v.insert     v4, s17, #9
    v.insert     v5, s14, #9
    s.shli       s13, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v2, #12
    s.ashri      s17, s13, #32
    v.insert     v4, s16, #10
    v.insert     v5, s14, #10
    s.shli       s13, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v2, #13
    s.ashri      s16, s13, #32
    v.insert     v4, s17, #11
    v.insert     v5, s14, #11
    s.shli       s13, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v2, #14
    s.ashri      s17, s13, #32
    v.insert     v4, s16, #12
    v.insert     v5, s14, #12
    s.shli       s13, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v2, #15
    s.ashri      s16, s13, #32
    v.insert     v4, s17, #13
    v.insert     v5, s14, #13
    s.shli       s13, s15, #32
    s.lshri      s14, s16, #32
    s.ashri      s15, s13, #32
    v.insert     v4, s16, #14
    v.insert     v5, s14, #14
    s.lshri      s13, s15, #32
    v.insert     v4, s15, #15
    v.insert     v5, s13, #15
    v.extract    s13, v1, #0
    v.extract    s14, v4, #0
    v.extract    s15, v5, #0
    v.extract    s16, v0, #0
    s.shli       s17, s15, #32
    s.shli       s15, s13, #32
    v.extract    s13, v5, #1
    v.extract    s18, v1, #1
    s.or         s19, s14, s17
    s.or         s14, s16, s15
    v.movi       v2, #0
    v.extract    s15, v4, #1
    s.shli       s16, s13, #32
    v.extract    s13, v0, #1
    s.shli       s17, s18, #32
    s.add        s18, s19, s14
    v.extract    s14, v5, #2
    v.extract    s19, v1, #2
    s.or         s20, s15, s16
    s.or         s15, s13, s17
    v.movi       v6, #0
    v.insert     v2, s18, #0
    v.extract    s13, v4, #2
    s.shli       s16, s14, #32
    v.extract    s14, v0, #2
    s.shli       s17, s19, #32
    s.lshri      s19, s18, #32
    s.add        s18, s20, s15
    v.extract    s15, v5, #3
    s.or         s20, s13, s16
    v.extract    s13, v1, #3
    s.or         s16, s14, s17
    v.insert     v6, s19, #0
    v.insert     v2, s18, #1
    v.extract    s14, v4, #3
    s.shli       s17, s15, #32
    v.extract    s15, v0, #3
    s.shli       s19, s13, #32
    s.lshri      s13, s18, #32
    s.add        s18, s20, s16
    v.extract    s16, v5, #4
    s.or         s20, s14, s17
    v.extract    s14, v1, #4
    s.or         s17, s15, s19
    v.insert     v6, s13, #1
    v.insert     v2, s18, #2
    v.extract    s13, v4, #4
    s.shli       s15, s16, #32
    v.extract    s16, v0, #4
    s.shli       s19, s14, #32
    s.lshri      s14, s18, #32
    s.add        s18, s20, s17
    v.extract    s17, v5, #5
    s.or         s20, s13, s15
    v.extract    s13, v1, #5
    s.or         s15, s16, s19
    v.insert     v6, s14, #2
    v.insert     v2, s18, #3
    v.extract    s14, v4, #5
    s.shli       s16, s17, #32
    v.extract    s17, v0, #5
    s.shli       s19, s13, #32
    s.lshri      s13, s18, #32
    s.add        s18, s20, s15
    v.extract    s15, v5, #6
    s.or         s20, s14, s16
    v.extract    s14, v1, #6
    s.or         s16, s17, s19
    v.insert     v6, s13, #3
    v.insert     v2, s18, #4
    v.extract    s13, v4, #6
    s.shli       s17, s15, #32
    v.extract    s15, v0, #6
    s.shli       s19, s14, #32
    s.lshri      s14, s18, #32
    s.add        s18, s20, s16
    v.extract    s16, v5, #7
    s.or         s20, s13, s17
    v.extract    s13, v1, #7
    s.or         s17, s15, s19
    v.insert     v6, s14, #4
    v.insert     v2, s18, #5
    v.extract    s14, v4, #7
    s.shli       s15, s16, #32
    v.extract    s16, v0, #7
    s.shli       s19, s13, #32
    s.lshri      s13, s18, #32
    s.add        s18, s20, s17
    v.extract    s17, v5, #8
    s.or         s20, s14, s15
    v.extract    s14, v1, #8
    s.or         s15, s16, s19
    v.insert     v6, s13, #5
    v.insert     v2, s18, #6
    v.extract    s13, v4, #8
    s.shli       s16, s17, #32
    v.extract    s17, v0, #8
    s.shli       s19, s14, #32
    s.lshri      s14, s18, #32
    s.add        s18, s20, s15
    v.extract    s15, v5, #9
    s.or         s20, s13, s16
    v.extract    s13, v1, #9
    s.or         s16, s17, s19
    v.insert     v6, s14, #6
    v.insert     v2, s18, #7
    v.extract    s14, v4, #9
    s.shli       s17, s15, #32
    v.extract    s15, v0, #9
    s.shli       s19, s13, #32
    s.lshri      s13, s18, #32
    s.add        s18, s20, s16
    v.extract    s16, v5, #10
    s.or         s20, s14, s17
    v.extract    s14, v1, #10
    s.or         s17, s15, s19
    v.insert     v6, s13, #7
    v.insert     v2, s18, #8
    v.extract    s13, v4, #10
    s.shli       s15, s16, #32
    v.extract    s16, v0, #10
    s.shli       s19, s14, #32
    s.lshri      s14, s18, #32
    s.add        s18, s20, s17
    v.extract    s17, v5, #11
    s.or         s20, s13, s15
    v.extract    s13, v1, #11
    s.or         s15, s16, s19
    v.insert     v6, s14, #8
    v.insert     v2, s18, #9
    v.extract    s14, v4, #11
    s.shli       s16, s17, #32
    v.extract    s17, v0, #11
    s.shli       s19, s13, #32
    s.lshri      s13, s18, #32
    s.add        s18, s20, s15
    v.extract    s15, v5, #12
    s.or         s20, s14, s16
    v.extract    s14, v1, #12
    s.or         s16, s17, s19
    v.insert     v6, s13, #9
    v.insert     v2, s18, #10
    v.extract    s13, v4, #12
    s.shli       s17, s15, #32
    v.extract    s15, v0, #12
    s.shli       s19, s14, #32
    s.lshri      s14, s18, #32
    s.add        s18, s20, s16
    v.extract    s16, v5, #13
    s.or         s20, s13, s17
    v.extract    s13, v1, #13
    s.or         s17, s15, s19
    v.insert     v6, s14, #10
    v.insert     v2, s18, #11
    v.extract    s14, v4, #13
    s.shli       s15, s16, #32
    v.extract    s16, v0, #13
    s.shli       s19, s13, #32
    s.lshri      s13, s18, #32
    s.add        s18, s20, s17
    v.extract    s17, v5, #14
    s.or         s20, s14, s15
    v.extract    s14, v1, #14
    s.or         s15, s16, s19
    v.insert     v6, s13, #11
    v.insert     v2, s18, #12
    v.extract    s13, v4, #14
    s.shli       s16, s17, #32
    v.extract    s17, v0, #14
    s.shli       s19, s14, #32
    s.lshri      s14, s18, #32
    s.add        s18, s20, s15
    v.extract    s15, v5, #15
    s.or         s20, s13, s16
    v.extract    s13, v1, #15
    s.or         s16, s17, s19
    v.insert     v6, s14, #12
    v.insert     v2, s18, #13
    v.extract    s14, v4, #15
    s.shli       s17, s15, #32
    v.extract    s15, v0, #15
    s.shli       s19, s13, #32
    s.lshri      s13, s18, #32
    s.add        s18, s20, s16
    s.or         s16, s14, s17
    s.or         s14, s15, s19
    v.insert     v6, s13, #13
    v.insert     v2, s18, #14
    s.lshri      s13, s18, #32
    s.add        s15, s16, s14
    v.insert     v6, s13, #14
    v.insert     v2, s15, #15
    v.movi       v0, #31
    s.lshri      s13, s15, #32
    v.movi       v1, #1
    v.insert     v6, s13, #15
    v.ashr       v4, v2, v0
    v.movi       v0, #0
    s.movz       s13, #0
    v.cmp.ne     p2, v6, v4
    @p2 v.sel        v4, v1, v0
    v.reduce.or  s14, v4
    s.cmp.eq     s15, s14, s13
    br.nz        s15, narrow_ok_4
    trap         #677220
narrow_ok_4:
    v.ld.gather.h v0, [s8, v2]                   // index is in elements (ISA sec 9.1)
    v.movi       v1, #31
    v.movi       v4, #1
    v.movi       v5, #0
    v.ashr       v7, v2, v1
    s.movz       s13, #0
    v.cmp.ne     p2, v6, v7
    @p2 v.sel        v1, v4, v5
    v.reduce.or  s14, v1
    s.cmp.eq     s15, s14, s13
    vf.cvt.f16.f32 v1, v0
    vf.mul       v0, v3, v1
    br.nz        s15, narrow_ok_5
    trap         #677220
narrow_ok_5:
    v.ld.gather.h v1, [s10, v2]                  // index is in elements (ISA sec 9.1)
    s.shli       s13, s1, #1                     // element offset -> bytes (x2)
    s.add        s1, s12, s13                    // &out_ptr0[...]
    vf.cvt.f16.f32 v2, v1
    vf.mul       v1, v8, v2
    vf.add       v2, v0, v1
    @p1 v.sel        v0, v2, v9
    vf.cvt.f32.f16 v1, v0
    v.st.h       [s1, #0], v1
__rctx_next:
    s.addi       s1, s4, #4                      // the next program of this context: + 4
    s.cmp.lt     s13, s1, s5
    s.mov        s4, s1
    br.nz        s13, __rctx_program
    exit
