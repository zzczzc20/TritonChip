    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #0
    v.add        v4, v1, v0
    v.movi       v0, #4
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v3, v4
    v.cmp.lt     p2, v4, v3
    v.movi       v7, #0
    @p2 v.sel        v8, v6, v4
    v.sub        v6, v1, v4
    v.cmp.lt     p3, v4, v1
    v.lshr       v9, v8, v0
    @p3 v.sel        v0, v6, v4
    v.movi       v6, #15
    v.sub        v8, v3, v9
    v.movi       v10, #15
    v.and        v11, v0, v6
    @p2 v.sel        v0, v8, v9
    s.rdspecial  s2, arg_base
    @p1 v.sel        v6, v5, v4
    v.sub        v5, v7, v0
    v.cmp.lt     p2, v0, v7
    v.movi       v8, #16
    @p2 v.sel        v9, v5, v0
    v.sub        v0, v1, v11
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.and        v5, v9, v10
    @p3 v.sel        v9, v0, v11
    v.movi       v0, #1024
    v.sub        v10, v7, v5
    v.cmp.lt     p3, v8, v1
    v.cmp.lt     p4, v4, v0
    @p2 v.sel        v0, v10, v5
    v.movi       v4, #256
    v.sub        v5, v1, v8
    v.sub        v1, v3, v8
    s.ld.d       s4, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v10, #8
    v.cmp.lt     p2, v8, v3
    v.movi       v3, #0
    v.lshr       v11, v6, v10
    v.movi       v6, #1
    @p3 v.sel        v10, v5, v8
    v.sub        v5, v2, v11
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    v.cmp.lt     p3, v8, v7
    @p1 v.sel        v10, v5, v11
    v.movi       v5, #32
    v.sub        v11, v7, v8
    v.cmp.lt     p1, v10, v3
    v.mul        v7, v0, v5
    v.sub        v0, v3, v10
    @p2 v.sel        v5, v1, v8
    v.movi       v1, #2
    @p1 v.sel        v5, v0, v10
    v.sub        v0, v2, v4
    s.add        s1, s4, s2                      // &out_ptr0[...]
    v.lshr       v10, v5, v6
    v.sub        v5, v3, v1
    v.cmp.lt     p2, v4, v2
    v.sub        v2, v3, v10
    @p3 v.sel        v6, v11, v8
    v.cmp.lt     p3, v1, v3
    @p1 v.sel        v3, v2, v10
    @p2 v.sel        v2, v0, v4
    @p3 v.sel        v0, v5, v1
    v.mul        v0, v3, v8
    v.add        v1, v9, v0
    v.add        v0, v1, v7
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v1, [s3, v0]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v0, v1
    @p4 v.st.w       [s1, #0], v0
__rctx_next:
    exit
