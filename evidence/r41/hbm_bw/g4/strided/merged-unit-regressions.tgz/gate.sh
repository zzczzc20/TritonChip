#!/bin/bash
set -u
source ~/tc_env/env.sh
cd "$HOME/r41-codex-t9b-merged" || exit 1
out="$HOME/r41-codex-t9b-merged-results"
run() { name=$1; shift; { date -u; printf 'COMMAND:'; printf ' %q' "$@"; printf '\n'; "$@"; rc=$?; echo "exit=$rc"; date -u; } > "$out/$name.log" 2>&1; }
case "$1" in
 compiler)
  run compiler-build cmake -S compiler -B compiler/build -G Ninja -DMLIR_DIR="$HOME/tc_env/root/usr/lib/llvm-20/lib/cmake/mlir" -DLLVM_DIR="$HOME/tc_env/root/usr/lib/llvm-20/lib/cmake/llvm" -DCMAKE_BUILD_TYPE=Release
  run compiler-ninja ninja -j1 -C compiler/build
  run compiler-core make sim/build/tb_core.vvp PYTHON="$HOME/tc_env/torchenv/bin/python"
  run compiler env PYTHONPATH="$PWD/python:$PWD/compiler/python" R1_STRICT=1 TNCA_LLVM="$HOME/tc_env/root/usr/lib/llvm-20" make compiler PYTHON="$HOME/tc_env/torchenv/bin/python" ;;
 hybrid) run hybrid python3 tools/r41/lsu_hybrid_tests.py ;;
 line_noc) run line python3 tools/r41/lsu_line_tests.py; run noc python3 tools/r41/wide_noc_tests.py ;;
 home) run home python3 tools/r41/g4_home_pipe_tests.py ;;
 clone|add) run "$1" "$HOME/tc_env/torchenv/bin/python" tools/r41/link_budget_rtl.py --image evidence/r41/hbm_bw/g4/strided/images/s4.tcl --profile core-vrf-sync-v5-x8-g2 --point "op.$1/membound/fp16-small-strided-r32-c1024" --out "$out/$1.jsonl" ;;
esac
