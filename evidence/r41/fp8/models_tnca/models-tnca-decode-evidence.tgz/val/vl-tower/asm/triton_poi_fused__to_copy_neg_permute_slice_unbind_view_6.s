    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #5
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.lshr       v5, v4, v0
    v.movi       v0, #0
    v.sub        v4, v2, v5
    v.sub        v6, v1, v3
    @p1 v.sel        v7, v4, v5
    v.movi       v4, #0
    v.sub        v5, v0, v7
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p2, v7, v0
    @p1 v.sel        v8, v6, v3
    v.movi       v6, #31
    @p2 v.sel        v9, v5, v7
    v.movi       v5, #15
    v.sub        v10, v4, v3
    v.cmp.lt     p3, v3, v4
    v.and        v11, v8, v6
    v.and        v6, v9, v5
    @p3 v.sel        v5, v10, v3
    v.sub        v3, v1, v11
    v.sub        v8, v0, v6
    v.movi       v9, #32
    @p1 v.sel        v10, v3, v11
    @p2 v.sel        v3, v8, v6
    s.rdspecial  s1, arg_base
    v.movi       v6, #16
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v8, #512
    v.sub        v11, v1, v9
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.cmp.lt     p1, v9, v1
    v.movi       v1, #9
    v.cmp.lt     p2, v9, v2
    v.lshr       v12, v5, v1
    v.movi       v1, #64
    v.sub        v5, v2, v9
    v.mul        v2, v3, v1
    @p1 v.sel        v3, v11, v9
    v.sub        v3, v4, v12
    v.mul        v11, v7, v1
    @p3 v.sel        v1, v3, v12
    v.add        v3, v10, v9
    v.movi       v7, #3072
    v.add        v12, v3, v2
    v.mul        v2, v1, v7
    v.sub        v1, v0, v6
    v.add        v3, v12, v2
    v.sub        v2, v4, v8
    v.ld.gather.h v7, [s2, v3]                   // index is in elements (ISA sec 9.1)
    v.add        v3, v10, v11
    v.cmp.lt     p1, v6, v0
    v.cmp.lt     p3, v8, v4
    @p2 v.sel        v0, v5, v9
    @p1 v.sel        v0, v1, v6
    vf.cvt.bf16.f32 v0, v7
    @p3 v.sel        v1, v2, v8
    vf.neg       v1, v0
    v.st.scatter.w [s3, v3], v1
__rctx_next:
    exit
