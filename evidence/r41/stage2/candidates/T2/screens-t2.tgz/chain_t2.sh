#!/bin/bash
# chain_t2.sh NAME : kernel synthesis of ~/r41s2t2/NAME/src with the Stage 2 image parameters, then tile 1 (SLR1) and tile 0 (SLR0) screens.
set -u
N=$1; R=$HOME/r41s2t2; SRC=$R/$N/src; SL=$HOME/r41s2int/slot.sh; O=$R/$N
V="vivado -mode batch -nojournal -nolog"
cd $O
echo "$(date -u +%FT%TZ) chain start" >> chain.log
$SL --min-gb 10 $O/kernel_synth.log -- $V -source $HOME/r41s2int/synth6.tcl -tclargs $SRC $SRC/evidence/r41/stage2/integration/image.tcl $O/kernel_synth
echo "$(date -u +%FT%TZ) kernel synth exit $?" >> chain.log
[ -f $O/kernel_synth/synth.dcp ] || { echo "$(date -u +%FT%TZ) no kernel synth.dcp" >> chain.log; exit 1; }
$SL --min-gb 8 $O/tile1_screen.log -- $V -source $R/screen_t2.tcl -tclargs $O/kernel_synth/synth.dcp 1 1 $O/tile1_screen &
sleep 120
$SL --min-gb 8 $O/tile0_screen.log -- $V -source $R/screen_t2.tcl -tclargs $O/kernel_synth/synth.dcp 0 0 $O/tile0_screen &
wait
echo "$(date -u +%FT%TZ) CHAIN-DONE" >> chain.log
