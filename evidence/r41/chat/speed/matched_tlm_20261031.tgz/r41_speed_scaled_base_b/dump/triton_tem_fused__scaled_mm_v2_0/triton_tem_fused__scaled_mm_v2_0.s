    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // arg_SA: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // arg_SB: device_ptr64 at arg_base+24
    s.ld.d       s6, [s1, #32]                   // out_ptr1: device_ptr64 at arg_base+32
    s.rdspecial  s1, pid.x
    s.movz       s7, #2
    s.movz       s8, #0
    s.cmp.lt     s9, s1, s8
    s.sub        s10, s8, s9
    s.cmp.lt     s9, s7, s8
    s.sub        s11, s8, s9
    s.xor        s8, s1, s10
    s.sub        s1, s8, s10
    s.xor        s8, s7, s11
    s.sub        s9, s8, s11
    s.lshri      s8, s1, #1
    s.muli       s9, s8, #2
    s.sub        s12, s1, s9
    s.xor        s1, s10, s11
    s.xor        s9, s8, s1
    s.sub        s8, s9, s1
    s.xor        s1, s12, s10
    s.sub        s9, s1, s10
    s.movz       s1, #16
    s.mul        s10, s8, s1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s10
    v.add        v2, v1, v0
    s.movz       s8, #128
    s.mul        s11, s9, s8
    v.movi       v1, #16
    v.add        v3, v0, v1
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v4, #32
    v.add        v5, v1, v4
    v.movi       v4, #48
    v.add        v6, v1, v4
    v.movi       v4, #64
    v.add        v7, v1, v4
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v4, #80
    v.add        v8, v1, v4
    v.movi       v4, #96
    v.add        v9, v1, v4
    v.movi       v4, #112
    v.add        v10, v1, v4
    v.splat      v1, s11
    v.add        v4, v1, v0
    v.add        v0, v1, v3
    v.add        v3, v1, v5
    v.add        v5, v1, v6
    v.add        v6, v1, v7
    v.add        v7, v1, v8
    v.add        v8, v1, v9
    v.add        v9, v1, v10
    v.movi       v1, #64
    v.movi       v10, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v2, v10
    v.cmp.lt     p2, v1, v10
    v.sub        v11, v10, v2
    @p1 v.sel        v12, v11, v2
    v.sub        v2, v10, v1
    @p2 v.sel        v11, v2, v1
    v.movi       v1, #63
    v.and        v2, v12, v1
    v.sub        v1, v10, v2
    @p1 v.sel        v10, v1, v2
    v.movi       v1, #256
    v.movi       v2, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v4, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v11, v2, v4
    @p1 v.sel        v12, v11, v4
    v.sub        v4, v2, v1
    @p2 v.sel        v11, v4, v1
    v.movi       v1, #255
    v.and        v4, v12, v1
    v.sub        v1, v2, v4
    @p1 v.sel        v2, v1, v4
    v.movi       v1, #256
    v.movi       v4, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v0, v4
    v.cmp.lt     p2, v1, v4
    v.sub        v11, v4, v0
    @p1 v.sel        v12, v11, v0
    v.sub        v0, v4, v1
    @p2 v.sel        v11, v0, v1
    v.movi       v0, #255
    v.and        v1, v12, v0
    v.sub        v0, v4, v1
    @p1 v.sel        v4, v0, v1
    v.movi       v0, #256
    v.movi       v1, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p2, v0, v1
    v.sub        v11, v1, v3
    @p1 v.sel        v12, v11, v3
    v.sub        v3, v1, v0
    @p2 v.sel        v11, v3, v0
    v.movi       v0, #255
    v.and        v3, v12, v0
    v.sub        v0, v1, v3
    @p1 v.sel        v1, v0, v3
    v.movi       v0, #256
    v.movi       v3, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v5, v3
    v.cmp.lt     p2, v0, v3
    v.sub        v11, v3, v5
    @p1 v.sel        v12, v11, v5
    v.sub        v5, v3, v0
    @p2 v.sel        v11, v5, v0
    v.movi       v0, #255
    v.and        v5, v12, v0
    v.sub        v0, v3, v5
    @p1 v.sel        v3, v0, v5
    v.movi       v0, #256
    v.movi       v5, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v6, v5
    v.cmp.lt     p2, v0, v5
    v.sub        v11, v5, v6
    @p1 v.sel        v12, v11, v6
    v.sub        v6, v5, v0
    @p2 v.sel        v11, v6, v0
    v.movi       v0, #255
    v.and        v6, v12, v0
    v.sub        v0, v5, v6
    @p1 v.sel        v5, v0, v6
    v.movi       v0, #256
    v.movi       v6, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v7, v6
    v.cmp.lt     p2, v0, v6
    v.sub        v11, v6, v7
    @p1 v.sel        v12, v11, v7
    v.sub        v7, v6, v0
    @p2 v.sel        v11, v7, v0
    v.movi       v0, #255
    v.and        v7, v12, v0
    v.sub        v0, v6, v7
    @p1 v.sel        v6, v0, v7
    v.movi       v0, #256
    v.movi       v7, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v8, v7
    v.cmp.lt     p2, v0, v7
    v.sub        v11, v7, v8
    @p1 v.sel        v12, v11, v8
    v.sub        v8, v7, v0
    @p2 v.sel        v11, v8, v0
    v.movi       v0, #255
    v.and        v8, v12, v0
    v.sub        v0, v7, v8
    @p1 v.sel        v7, v0, v8
    v.movi       v0, #256
    v.movi       v8, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v9, v8
    v.cmp.lt     p2, v0, v8
    v.sub        v11, v8, v9
    @p1 v.sel        v12, v11, v9
    v.sub        v9, v8, v0
    @p2 v.sel        v11, v9, v0
    v.movi       v0, #255
    v.and        v9, v12, v0
    v.sub        v0, v8, v9
    @p1 v.sel        v8, v0, v9
    s.movz       s9, #32
    s.movz       s12, #48
    s.movz       s13, #64
    s.movz       s14, #80
    s.movz       s15, #96
    s.movz       s16, #112
    v.movi       v0, #128
    v.movi       v9, #0
    v.movi       v11, #1
    v.cmp.lt     p1, v2, v9
    v.cmp.lt     p2, v0, v9
    v.sub        v11, v9, v2
    @p1 v.sel        v12, v11, v2
    v.sub        v11, v9, v0
    @p2 v.sel        v13, v11, v0
    v.movi       v0, #7
    v.lshr       v11, v12, v0
    v.sub        v0, v9, v11
    @p1 v.sel        v9, v0, v11
    v.movi       v0, #128
    v.movi       v11, #0
    v.movi       v12, #1
    v.cmp.lt     p1, v4, v11
    v.cmp.lt     p2, v0, v11
    v.sub        v12, v11, v4
    @p1 v.sel        v13, v12, v4
    v.sub        v12, v11, v0
    @p2 v.sel        v14, v12, v0
    v.movi       v0, #7
    v.lshr       v12, v13, v0
    v.sub        v0, v11, v12
    @p1 v.sel        v11, v0, v12
    v.movi       v0, #128
    v.movi       v12, #0
    v.movi       v13, #1
    v.cmp.lt     p1, v1, v12
    v.cmp.lt     p2, v0, v12
    v.sub        v13, v12, v1
    @p1 v.sel        v14, v13, v1
    v.sub        v13, v12, v0
    @p2 v.sel        v15, v13, v0
    v.movi       v0, #7
    v.lshr       v13, v14, v0
    v.sub        v0, v12, v13
    @p1 v.sel        v12, v0, v13
    v.movi       v0, #128
    v.movi       v13, #0
    v.movi       v14, #1
    v.cmp.lt     p1, v3, v13
    v.cmp.lt     p2, v0, v13
    v.sub        v14, v13, v3
    @p1 v.sel        v15, v14, v3
    v.sub        v14, v13, v0
    @p2 v.sel        v16, v14, v0
    v.movi       v0, #7
    v.lshr       v14, v15, v0
    v.sub        v0, v13, v14
    @p1 v.sel        v13, v0, v14
    v.movi       v0, #128
    v.movi       v14, #0
    v.movi       v15, #1
    v.cmp.lt     p1, v5, v14
    v.cmp.lt     p2, v0, v14
    v.sub        v15, v14, v5
    @p1 v.sel        v16, v15, v5
    v.sub        v15, v14, v0
    @p2 v.sel        v17, v15, v0
    v.movi       v0, #7
    v.lshr       v15, v16, v0
    v.sub        v0, v14, v15
    @p1 v.sel        v14, v0, v15
    v.movi       v0, #128
    v.movi       v15, #0
    v.movi       v16, #1
    v.cmp.lt     p1, v6, v15
    v.cmp.lt     p2, v0, v15
    v.sub        v16, v15, v6
    @p1 v.sel        v17, v16, v6
    v.sub        v16, v15, v0
    @p2 v.sel        v18, v16, v0
    v.movi       v0, #7
    v.lshr       v16, v17, v0
    v.sub        v0, v15, v16
    @p1 v.sel        v15, v0, v16
    v.movi       v0, #128
    v.movi       v16, #0
    v.movi       v17, #1
    v.cmp.lt     p1, v7, v16
    v.cmp.lt     p2, v0, v16
    v.sub        v17, v16, v7
    @p1 v.sel        v18, v17, v7
    v.sub        v17, v16, v0
    @p2 v.sel        v19, v17, v0
    v.movi       v0, #7
    v.lshr       v17, v18, v0
    v.sub        v0, v16, v17
    @p1 v.sel        v16, v0, v17
    v.movi       v0, #128
    v.movi       v17, #0
    v.movi       v18, #1
    v.cmp.lt     p1, v8, v17
    v.cmp.lt     p2, v0, v17
    v.sub        v18, v17, v8
    @p1 v.sel        v19, v18, v8
    v.sub        v18, v17, v0
    @p2 v.sel        v20, v18, v0
    v.movi       v0, #7
    v.lshr       v18, v19, v0
    v.sub        v0, v17, v18
    @p1 v.sel        v17, v0, v18
    s.movz       s17, #4
    v.movi       v0, #4
    v.mul        v18, v9, v0
    v.mul        v9, v11, v0
    v.mul        v11, v12, v0
    v.mul        v12, v13, v0
    v.mul        v13, v14, v0
    v.movi       v0, #4
    v.mul        v14, v15, v0
    v.mul        v15, v16, v0
    v.mul        v16, v17, v0
    s.movz       s17, #0
    s.movz       s18, #1
    s.addi       s19, s17, #0
    s.addi       s20, s17, #0
    s.addi       s21, s17, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_1:
    s.cmp.ge     s22, s19, s7
    br.nz        s22, endfor_2
    s.mul        s22, s19, s8
    s.movz       s23, #256
    s.sub        s24, s23, s22
    s.mul        s22, s19, s13
    v.splat      v0, s22
    s.shli       s25, s22, #2                    // element offset -> bytes (x4)
    s.add        s22, s4, s25                    // &arg_SA[...]
    v.ld.gather.w v0, [s22, v10]                 // index is in elements (ISA sec 9.1)
    v.splat      v17, s19
    v.splat      v17, s19
    v.splat      v17, s19
    v.splat      v17, s19
    v.splat      v17, s19
    v.splat      v17, s19
    v.splat      v17, s19
    v.splat      v17, s19
    s.shli       s22, s19, #2                    // element offset -> bytes (x4)
    s.add        s25, s5, s22                    // &arg_SB[...]
    v.ld.gather.w v17, [s25, v18]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v19, [s25, v9]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v20, [s25, v11]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v21, [s25, v12]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v22, [s25, v13]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v23, [s25, v14]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v24, [s25, v15]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v25, [s25, v16]                // index is in elements (ISA sec 9.1)
    v.splat      v26, s23
    v.mul        v27, v2, v26
    v.mul        v28, v4, v26
    v.mul        v29, v1, v26
    v.splat      v26, s23
    v.mul        v30, v3, v26
    v.mul        v31, v5, v26
    v.mul        v32, v6, v26
    v.splat      v26, s23
    v.mul        v33, v7, v26
    v.mul        v34, v8, v26
    s.add        s22, s17, s24
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s23, arg_base
    s.ld.d       s25, [s23, #40]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.movi       v26, #0
    v.movi       v35, #0
    v.iota       v36                             // arange(0, VLEN)
    s.movz       s23, #0
    s.cmp.ge     s26, s22, s23
    v.extract    s27, v2, #0
    v.splat      v37, s27
    v.add        v38, v37, v36
    v.sub        v37, v2, v38
    v.reduce.or  s28, v37
    s.cmp.eq     s29, s28, s23
    s.cmp.ge     s28, s27, s23
    s.and        s30, s29, s28
    s.and        s28, s30, s26
    v.insert     v26, s28, #0
    v.insert     v35, s27, #0
    v.extract    s27, v4, #0
    v.splat      v37, s27
    v.add        v38, v37, v36
    v.sub        v37, v4, v38
    v.reduce.or  s28, v37
    s.cmp.eq     s29, s28, s23
    s.cmp.ge     s28, s27, s23
    s.and        s30, s29, s28
    s.and        s28, s30, s26
    v.insert     v26, s28, #1
    v.insert     v35, s27, #1
    v.extract    s27, v1, #0
    v.splat      v37, s27
    v.add        v38, v37, v36
    v.sub        v37, v1, v38
    v.reduce.or  s28, v37
    s.cmp.eq     s29, s28, s23
    s.cmp.ge     s28, s27, s23
    s.and        s30, s29, s28
    s.and        s28, s30, s26
    v.insert     v26, s28, #2
    v.insert     v35, s27, #2
    v.extract    s27, v3, #0
    v.splat      v37, s27
    v.add        v38, v37, v36
    v.sub        v37, v3, v38
    v.reduce.or  s28, v37
    s.cmp.eq     s29, s28, s23
    s.cmp.ge     s28, s27, s23
    s.and        s30, s29, s28
    s.and        s28, s30, s26
    v.insert     v26, s28, #3
    v.insert     v35, s27, #3
    v.extract    s27, v5, #0
    v.splat      v37, s27
    v.add        v38, v37, v36
    v.sub        v37, v5, v38
    v.reduce.or  s28, v37
    s.cmp.eq     s29, s28, s23
    s.cmp.ge     s28, s27, s23
    s.and        s23, s29, s28
    s.and        s28, s23, s26
    v.insert     v26, s28, #4
    v.insert     v35, s27, #4
    v.extract    s23, v6, #0
    v.splat      v37, s23
    v.add        v38, v37, v36
    v.sub        v37, v6, v38
    v.reduce.or  s27, v37
    s.movz       s28, #0
    s.cmp.eq     s29, s27, s28
    s.cmp.ge     s27, s23, s28
    s.and        s30, s29, s27
    s.and        s27, s30, s26
    v.insert     v26, s27, #5
    v.insert     v35, s23, #5
    v.extract    s23, v7, #0
    v.splat      v37, s23
    v.add        v38, v37, v36
    v.sub        v37, v7, v38
    v.reduce.or  s27, v37
    s.cmp.eq     s29, s27, s28
    s.cmp.ge     s27, s23, s28
    s.and        s30, s29, s27
    s.and        s27, s30, s26
    v.insert     v26, s27, #6
    v.insert     v35, s23, #6
    v.extract    s23, v8, #0
    v.splat      v37, s23
    v.add        v38, v37, v36
    v.sub        v36, v8, v38
    v.reduce.or  s27, v36
    s.cmp.eq     s29, s27, s28
    s.cmp.ge     s27, s23, s28
    s.and        s28, s29, s27
    s.and        s27, s28, s26
    v.insert     v26, s27, #7
    v.insert     v35, s23, #7
    s.add        s23, s3, s21
    s.addi       s26, s25, #0                    // TensorMap 0: W's rows for a transposed FP8 B
    s.st.d       [s26, #0], s23
    .li       s23, #2147483647
    s.st.d       [s26, #8], s23
    s.st.d       [s26, #16], s22
    s.movz       s23, #256
    s.st.d       [s26, #48], s23
    s.movz       s23, #1
    s.st.d       [s26, #56], s23
    .li       s27, #137438953488
    s.st.d       [s26, #88], s27
    .li       s27, #7705171329024
    s.st.d       [s26, #104], s27
    fence.release.device
    td.load      d0, [s26]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s26, s25, #256
    s.addi       s28, s25, #768                  // TensorMap 1: the gathered fallback B tile
    s.st.d       [s28, #0], s26
    s.movz       s29, #32
    s.st.d       [s28, #8], s29
    s.movz       s30, #16
    s.st.d       [s28, #16], s30
    s.st.d       [s28, #48], s30
    s.st.d       [s28, #56], s23
    .li       s23, #68719476768
    s.st.d       [s28, #88], s23
    s.st.d       [s28, #104], s27
    fence.release.device
    td.load      d1, [s28]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s23, v26, #0
    br.nz        s23, x8dot_done_3
    s.movz       s27, #0
    s.addi       s28, s27, #0
    s.add        s27, s3, s21
x8dot_row_4:
    s.add        s30, s27, s28
    s.addi       s31, s22, #0
    s.sub        s32, s31, s28
    v.splat      v36, s32
    v.movi       v37, #0
    v.cmp.gt     p1, v36, v37
    v.movi       v36, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v36, [s30, v27]            // index is in elements (ISA sec 9.1)
    s.shli       s30, s28, #4
    s.add        s31, s26, s30
    v.st.b       [s31, #0], v36
    fence.acq_rel.device
    s.addi       s30, s28, #1
    s.mov        s28, s30
    s.cmp.lt     s30, s28, s29
    br.nz        s30, x8dot_row_4
x8dot_done_3:
    mb.arm       s26, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v36, s23
    v.movi       v37, #0
    v.cmp.ne     p1, v36, v37
    v.cmp.eq     p2, v36, v37
    s.movz       s23, #0
    s.mov        s27, s23                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s23                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s27, s26            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s27, v35, #0
    s.mov        s28, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s23                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s28, s26          // predicated off still completes once (ISA sec 9A.3)
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s27, v26, #1
    br.nz        s27, x8dot_done_5
    s.addi       s28, s23, #0
    s.add        s29, s3, s21
    s.addi       s30, s25, #256
x8dot_row_6:
    s.add        s31, s29, s28
    s.addi       s32, s22, #0
    s.sub        s33, s32, s28
    v.splat      v36, s33
    v.movi       v37, #0
    v.cmp.gt     p1, v36, v37
    v.movi       v36, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v36, [s31, v28]            // index is in elements (ISA sec 9.1)
    s.shli       s31, s28, #4
    s.add        s32, s30, s31
    v.st.b       [s32, #0], v36
    fence.acq_rel.device
    s.addi       s31, s28, #1
    s.mov        s28, s31
    s.movz       s31, #32
    s.cmp.lt     s32, s28, s31
    br.nz        s32, x8dot_row_6
x8dot_done_5:
    mb.arm       s28, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v36, s27
    v.movi       v37, #0
    v.cmp.ne     p1, v36, v37
    v.cmp.eq     p2, v36, v37
    s.mov        s29, s23                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s23                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s29, s28            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s27, v35, #1
    s.mov        s29, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s23                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s29, s28          // predicated off still completes once (ISA sec 9A.3)
    s.addi       s27, s25, #1024                 // 512 bytes of repack scratch
    s.movz       s29, #256
    v.splat      v36, s29
    v.mul        v37, v10, v36
    v.extract    s29, v37, #0
    s.add        s30, s29, s20
    s.add        s29, s2, s30
    v.iota       v36                             // arange(0, VLEN)
    s.add        s30, s23, s24                   // the tile origin
    v.splat      v38, s30
    v.cmp.lt     p1, v36, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #0
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #1
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #32
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #2
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #64
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #3
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #96
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #4
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #128
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #5
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #160
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #6
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #192
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #7
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #224
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #8
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #256
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #9
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #288
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #10
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #320
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #11
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #352
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #12
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #384
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #13
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #416
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #14
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #448
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #15
    s.add        s29, s23, s20
    s.add        s23, s2, s29
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s23, #0]
    s.addi       s23, s27, #480
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #0
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    s.movz       s23, #0
    s.add        s30, s23, s1                    // the tile origin
    v.splat      v38, s30
    v.add        v39, v36, v38
    s.add        s30, s23, s24                   // the tile origin
    v.splat      v38, s30
    v.cmp.lt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #16
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #1
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #48
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #2
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #80
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #3
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #112
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #4
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #144
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #5
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #176
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #6
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #208
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #7
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #240
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #8
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #272
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #9
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #304
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #10
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #336
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #11
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #368
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #12
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #400
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #13
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #432
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #14
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #464
    v.st.b       [s23, #0], v38
    v.extract    s23, v37, #15
    s.add        s29, s23, s20
    s.addi       s23, s29, #16
    s.add        s29, s2, s23
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s29, #0]
    s.addi       s23, s27, #496
    v.st.b       [s23, #0], v38
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.ld.w       v38, [s27, #0]
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s23, s27, #64
    v.ld.w       v38, [s23, #0]
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s23, s27, #128
    v.ld.w       v38, [s23, #0]
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s23, s27, #192
    v.ld.w       v38, [s23, #0]
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s23, s27, #256
    v.ld.w       v38, [s23, #0]
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s23, s27, #320
    v.ld.w       v38, [s23, #0]
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s23, s27, #384
    v.ld.w       v38, [s23, #0]
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s23, s27, #448
    v.ld.w       v38, [s23, #0]
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.wait      s26
    mb.arm       s23, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s23
    mb.wait      s23
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s27, v26, #2
    br.nz        s27, x8dot_done_7
    s.movz       s29, #0
    s.addi       s30, s29, #0
    s.add        s29, s3, s21
    s.addi       s31, s25, #256
x8dot_row_8:
    s.add        s32, s29, s30
    s.addi       s33, s22, #0
    s.sub        s34, s33, s30
    v.splat      v38, s34
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s32, v29]            // index is in elements (ISA sec 9.1)
    s.shli       s32, s30, #4
    s.add        s33, s31, s32
    v.st.b       [s33, #0], v38
    fence.acq_rel.device
    s.addi       s32, s30, #1
    s.mov        s30, s32
    s.movz       s32, #32
    s.cmp.lt     s33, s30, s32
    br.nz        s33, x8dot_row_8
x8dot_done_7:
    mb.arm       s29, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s27
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.movz       s27, #0
    s.mov        s30, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s30, s29            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s30, v35, #2
    s.mov        s31, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s31, s29          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s30, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s30
    mb.wait      s30
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s31, v26, #3
    br.nz        s31, x8dot_done_9
    s.addi       s32, s27, #0
    s.add        s33, s3, s21
    s.addi       s34, s25, #256
x8dot_row_10:
    s.add        s35, s33, s32
    s.addi       s36, s22, #0
    s.sub        s37, s36, s32
    v.splat      v38, s37
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s35, v30]            // index is in elements (ISA sec 9.1)
    s.shli       s35, s32, #4
    s.add        s36, s34, s35
    v.st.b       [s36, #0], v38
    fence.acq_rel.device
    s.addi       s35, s32, #1
    s.mov        s32, s35
    s.movz       s35, #32
    s.cmp.lt     s36, s32, s35
    br.nz        s36, x8dot_row_10
x8dot_done_9:
    mb.arm       s32, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s31
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.mov        s33, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s33, s32            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s31, v35, #3
    s.mov        s33, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s29
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s31
    mb.wait      s31
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s33, v26, #4
    br.nz        s33, x8dot_done_11
    s.addi       s34, s27, #0
    s.add        s27, s3, s21
    s.addi       s35, s25, #256
x8dot_row_12:
    s.add        s36, s27, s34
    s.addi       s37, s22, #0
    s.sub        s38, s37, s34
    v.splat      v38, s38
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s36, v31]            // index is in elements (ISA sec 9.1)
    s.shli       s36, s34, #4
    s.add        s37, s35, s36
    v.st.b       [s37, #0], v38
    fence.acq_rel.device
    s.addi       s36, s34, #1
    s.mov        s34, s36
    s.movz       s36, #32
    s.cmp.lt     s37, s34, s36
    br.nz        s37, x8dot_row_12
x8dot_done_11:
    mb.arm       s27, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s33
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.movz       s33, #0
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s34, s27            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s34, v35, #4
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s35, s27          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s34, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s34
    mb.wait      s34
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s35, v26, #5
    br.nz        s35, x8dot_done_13
    s.addi       s36, s33, #0
    s.add        s37, s3, s21
    s.addi       s38, s25, #256
x8dot_row_14:
    s.add        s39, s37, s36
    s.addi       s40, s22, #0
    s.sub        s41, s40, s36
    v.splat      v38, s41
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s39, v32]            // index is in elements (ISA sec 9.1)
    s.shli       s39, s36, #4
    s.add        s40, s38, s39
    v.st.b       [s40, #0], v38
    fence.acq_rel.device
    s.addi       s39, s36, #1
    s.mov        s36, s39
    s.movz       s39, #32
    s.cmp.lt     s40, s36, s39
    br.nz        s40, x8dot_row_14
x8dot_done_13:
    mb.arm       s36, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s35
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s36            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s35, v35, #5
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s27
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s35
    mb.wait      s35
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s37, v26, #6
    br.nz        s37, x8dot_done_15
    s.addi       s38, s33, #0
    s.add        s33, s3, s21
    s.addi       s39, s25, #256
x8dot_row_16:
    s.add        s40, s33, s38
    s.addi       s41, s22, #0
    s.sub        s42, s41, s38
    v.splat      v38, s42
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s40, v33]            // index is in elements (ISA sec 9.1)
    s.shli       s40, s38, #4
    s.add        s41, s39, s40
    v.st.b       [s41, #0], v38
    fence.acq_rel.device
    s.addi       s40, s38, #1
    s.mov        s38, s40
    s.movz       s40, #32
    s.cmp.lt     s41, s38, s40
    br.nz        s41, x8dot_row_16
x8dot_done_15:
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s37
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.movz       s37, #0
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s38, s33            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s38, v35, #6
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s39, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s38, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s38
    mb.wait      s38
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s39, v26, #7
    br.nz        s39, x8dot_done_17
    s.addi       s40, s37, #0
    s.add        s41, s3, s21
    s.addi       s42, s25, #256
x8dot_row_18:
    s.add        s43, s41, s40
    s.addi       s44, s22, #0
    s.sub        s45, s44, s40
    v.splat      v38, s45
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s43, v34]            // index is in elements (ISA sec 9.1)
    s.shli       s43, s40, #4
    s.add        s44, s42, s43
    v.st.b       [s44, #0], v38
    fence.acq_rel.device
    s.addi       s43, s40, #1
    s.mov        s40, s43
    s.movz       s43, #32
    s.cmp.lt     s44, s40, s43
    br.nz        s44, x8dot_row_18
x8dot_done_17:
    mb.arm       s40, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s39
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s40            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s39, v35, #7
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s39
    mb.wait      s39
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s41, v26, #0
    br.nz        s41, x8dot_done_19
    s.addi       s42, s37, #0
    s.add        s37, s3, s21
    s.addi       s43, s37, #32
    s.addi       s37, s25, #256
x8dot_row_20:
    s.add        s44, s43, s42
    s.addi       s45, s22, #-32
    s.sub        s46, s45, s42
    v.splat      v38, s46
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s44, v27]            // index is in elements (ISA sec 9.1)
    s.shli       s44, s42, #4
    s.add        s45, s37, s44
    v.st.b       [s45, #0], v38
    fence.acq_rel.device
    s.addi       s44, s42, #1
    s.mov        s42, s44
    s.movz       s44, #32
    s.cmp.lt     s45, s42, s44
    br.nz        s45, x8dot_row_20
x8dot_done_19:
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s41
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.movz       s41, #0
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s42, s37            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s42, v35, #0
    s.movz       s43, #32
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s44, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s42, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s42
    mb.wait      s42
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s44, v26, #1
    br.nz        s44, x8dot_done_21
    s.addi       s45, s41, #0
    s.add        s46, s3, s21
    s.addi       s47, s46, #32
    s.addi       s46, s25, #256
x8dot_row_22:
    s.add        s48, s47, s45
    s.addi       s49, s22, #-32
    s.sub        s50, s49, s45
    v.splat      v38, s50
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s48, v28]            // index is in elements (ISA sec 9.1)
    s.shli       s48, s45, #4
    s.add        s49, s46, s48
    v.st.b       [s49, #0], v38
    fence.acq_rel.device
    s.addi       s48, s45, #1
    s.mov        s45, s48
    s.cmp.lt     s48, s45, s43
    br.nz        s48, x8dot_row_22
x8dot_done_21:
    mb.arm       s45, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s44
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.mov        s46, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s46, s45            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s44, v35, #1
    s.mov        s46, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s45          // predicated off still completes once (ISA sec 9A.3)
    s.addi       s43, s25, #1536                 // 512 bytes of repack scratch
    v.extract    s44, v37, #0
    s.add        s46, s44, s20
    s.addi       s44, s46, #32
    s.add        s46, s2, s44
    s.add        s44, s41, s9                    // the tile origin
    v.splat      v38, s44
    v.add        v39, v36, v38
    s.add        s44, s41, s24                   // the tile origin
    v.splat      v38, s44
    v.cmp.lt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s46, #0]
    s.addi       s41, s43, #0
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #1
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #32
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #2
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #64
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #3
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #96
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #4
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #128
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #5
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #160
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #6
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #192
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #7
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #224
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #8
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #256
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #9
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #288
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #10
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #320
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #11
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #352
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #12
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #384
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #13
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #416
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #14
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #448
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #15
    s.add        s44, s41, s20
    s.addi       s41, s44, #32
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #480
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #0
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    s.movz       s41, #0
    s.add        s46, s41, s12                   // the tile origin
    v.splat      v38, s46
    v.add        v39, v36, v38
    s.add        s46, s41, s24                   // the tile origin
    v.splat      v38, s46
    v.cmp.lt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #16
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #1
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #48
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #2
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #80
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #3
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #112
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #4
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #144
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #5
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #176
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #6
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #208
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #7
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #240
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #8
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #272
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #9
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #304
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #10
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #336
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #11
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #368
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #12
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #400
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #13
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #432
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #14
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #464
    v.st.b       [s41, #0], v38
    v.extract    s41, v37, #15
    s.add        s44, s41, s20
    s.addi       s41, s44, #48
    s.add        s44, s2, s41
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s44, #0]
    s.addi       s41, s43, #496
    v.st.b       [s41, #0], v38
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.ld.w       v38, [s43, #0]
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s43, #64
    v.ld.w       v38, [s41, #0]
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s43, #128
    v.ld.w       v38, [s41, #0]
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s43, #192
    v.ld.w       v38, [s41, #0]
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s43, #256
    v.ld.w       v38, [s41, #0]
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s43, #320
    v.ld.w       v38, [s41, #0]
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s43, #384
    v.ld.w       v38, [s41, #0]
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s41, s43, #448
    v.ld.w       v38, [s41, #0]
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.wait      s37
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s41
    mb.wait      s41
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s43, v26, #2
    br.nz        s43, x8dot_done_23
    s.movz       s44, #0
    s.addi       s46, s44, #0
    s.add        s44, s3, s21
    s.addi       s47, s44, #32
    s.addi       s44, s25, #256
x8dot_row_24:
    s.add        s48, s47, s46
    s.addi       s49, s22, #-32
    s.sub        s50, s49, s46
    v.splat      v38, s50
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s48, v29]            // index is in elements (ISA sec 9.1)
    s.shli       s48, s46, #4
    s.add        s49, s44, s48
    v.st.b       [s49, #0], v38
    fence.acq_rel.device
    s.addi       s48, s46, #1
    s.mov        s46, s48
    s.movz       s48, #32
    s.cmp.lt     s49, s46, s48
    br.nz        s49, x8dot_row_24
x8dot_done_23:
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s43
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.movz       s43, #0
    s.mov        s46, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s46, s44            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s46, v35, #2
    s.movz       s47, #32
    s.mov        s48, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s48, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s46, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s46
    mb.wait      s46
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s48, v26, #3
    br.nz        s48, x8dot_done_25
    s.addi       s49, s43, #0
    s.add        s50, s3, s21
    s.addi       s51, s50, #32
    s.addi       s50, s25, #256
x8dot_row_26:
    s.add        s52, s51, s49
    s.addi       s53, s22, #-32
    s.sub        s54, s53, s49
    v.splat      v38, s54
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s52, v30]            // index is in elements (ISA sec 9.1)
    s.shli       s52, s49, #4
    s.add        s53, s50, s52
    v.st.b       [s53, #0], v38
    fence.acq_rel.device
    s.addi       s52, s49, #1
    s.mov        s49, s52
    s.cmp.lt     s52, s49, s47
    br.nz        s52, x8dot_row_26
x8dot_done_25:
    mb.arm       s49, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s48
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.mov        s50, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s50, s49            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s48, v35, #3
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s47
    mb.wait      s47
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s48, v26, #4
    br.nz        s48, x8dot_done_27
    s.addi       s50, s43, #0
    s.add        s43, s3, s21
    s.addi       s51, s43, #32
    s.addi       s43, s25, #256
x8dot_row_28:
    s.add        s52, s51, s50
    s.addi       s53, s22, #-32
    s.sub        s54, s53, s50
    v.splat      v38, s54
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s52, v31]            // index is in elements (ISA sec 9.1)
    s.shli       s52, s50, #4
    s.add        s53, s43, s52
    v.st.b       [s53, #0], v38
    fence.acq_rel.device
    s.addi       s52, s50, #1
    s.mov        s50, s52
    s.movz       s52, #32
    s.cmp.lt     s53, s50, s52
    br.nz        s53, x8dot_row_28
x8dot_done_27:
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s48
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.movz       s48, #0
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s50, s43            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s50, v35, #4
    s.movz       s51, #32
    s.mov        s52, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s52, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s50, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s50
    mb.wait      s50
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s52, v26, #5
    br.nz        s52, x8dot_done_29
    s.addi       s53, s48, #0
    s.add        s54, s3, s21
    s.addi       s55, s54, #32
    s.addi       s54, s25, #256
x8dot_row_30:
    s.add        s56, s55, s53
    s.addi       s57, s22, #-32
    s.sub        s58, s57, s53
    v.splat      v38, s58
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s56, v32]            // index is in elements (ISA sec 9.1)
    s.shli       s56, s53, #4
    s.add        s57, s54, s56
    v.st.b       [s57, #0], v38
    fence.acq_rel.device
    s.addi       s56, s53, #1
    s.mov        s53, s56
    s.cmp.lt     s56, s53, s51
    br.nz        s56, x8dot_row_30
x8dot_done_29:
    mb.arm       s53, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s52
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.mov        s54, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s54, s53            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s52, v35, #5
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s51
    mb.wait      s51
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s52, v26, #6
    br.nz        s52, x8dot_done_31
    s.addi       s54, s48, #0
    s.add        s48, s3, s21
    s.addi       s55, s48, #32
    s.addi       s48, s25, #256
x8dot_row_32:
    s.add        s56, s55, s54
    s.addi       s57, s22, #-32
    s.sub        s58, s57, s54
    v.splat      v38, s58
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s56, v33]            // index is in elements (ISA sec 9.1)
    s.shli       s56, s54, #4
    s.add        s57, s48, s56
    v.st.b       [s57, #0], v38
    fence.acq_rel.device
    s.addi       s56, s54, #1
    s.mov        s54, s56
    s.movz       s56, #32
    s.cmp.lt     s57, s54, s56
    br.nz        s57, x8dot_row_32
x8dot_done_31:
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s52
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.movz       s52, #0
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s54, s48            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s54, v35, #6
    s.movz       s55, #32
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s56, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s54, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s54
    mb.wait      s54
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s56, v26, #7
    br.nz        s56, x8dot_done_33
    s.addi       s57, s52, #0
    s.add        s58, s3, s21
    s.addi       s59, s58, #32
    s.addi       s58, s25, #256
x8dot_row_34:
    s.add        s60, s59, s57
    s.addi       s23, s22, #-32
    s.sub        s26, s23, s57
    v.splat      v38, s26
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s60, v34]            // index is in elements (ISA sec 9.1)
    s.shli       s23, s57, #4
    s.add        s26, s58, s23
    v.st.b       [s26, #0], v38
    fence.acq_rel.device
    s.addi       s23, s57, #1
    s.mov        s57, s23
    s.cmp.lt     s23, s57, s55
    br.nz        s23, x8dot_row_34
x8dot_done_33:
    mb.arm       s23, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s56
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.mov        s26, s52                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s27, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s26, s23            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s26, v35, #7
    s.mov        s27, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s28, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s27, s23          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s26, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s26
    mb.wait      s26
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s27, v26, #0
    br.nz        s27, x8dot_done_35
    s.addi       s28, s52, #0
    s.add        s29, s3, s21
    s.addi       s30, s29, #64
    s.addi       s29, s25, #256
x8dot_row_36:
    s.add        s31, s30, s28
    s.addi       s32, s22, #-64
    s.sub        s33, s32, s28
    v.splat      v38, s33
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s31, v27]            // index is in elements (ISA sec 9.1)
    s.shli       s31, s28, #4
    s.add        s32, s29, s31
    v.st.b       [s32, #0], v38
    fence.acq_rel.device
    s.addi       s31, s28, #1
    s.mov        s28, s31
    s.movz       s31, #32
    s.cmp.lt     s32, s28, s31
    br.nz        s32, x8dot_row_36
x8dot_done_35:
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s27
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.movz       s27, #0
    s.mov        s29, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s30, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s29, s28            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s29, v35, #0
    s.movz       s30, #64
    s.mov        s31, s29                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s31, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s23
    mb.arm       s29, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s29
    mb.wait      s29
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s31, v26, #1
    br.nz        s31, x8dot_done_37
    s.addi       s32, s27, #0
    s.add        s33, s3, s21
    s.addi       s34, s33, #64
    s.addi       s33, s25, #256
x8dot_row_38:
    s.add        s35, s34, s32
    s.addi       s36, s22, #-64
    s.sub        s37, s36, s32
    v.splat      v38, s37
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s35, v28]            // index is in elements (ISA sec 9.1)
    s.shli       s35, s32, #4
    s.add        s36, s33, s35
    v.st.b       [s36, #0], v38
    fence.acq_rel.device
    s.addi       s35, s32, #1
    s.mov        s32, s35
    s.movz       s35, #32
    s.cmp.lt     s36, s32, s35
    br.nz        s36, x8dot_row_38
x8dot_done_37:
    mb.arm       s32, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s31
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.mov        s33, s27                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s27                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s33, s32            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s31, v35, #1
    s.mov        s33, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s33, s32          // predicated off still completes once (ISA sec 9A.3)
    s.addi       s30, s25, #2048                 // 512 bytes of repack scratch
    v.extract    s31, v37, #0
    s.add        s33, s31, s20
    s.addi       s31, s33, #64
    s.add        s33, s2, s31
    s.add        s31, s27, s13                   // the tile origin
    v.splat      v38, s31
    v.add        v39, v36, v38
    s.add        s31, s27, s24                   // the tile origin
    v.splat      v38, s31
    v.cmp.lt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s33, #0]
    s.addi       s27, s30, #0
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #1
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #32
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #2
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #64
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #3
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #96
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #4
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #128
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #5
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #160
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #6
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #192
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #7
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #224
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #8
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #256
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #9
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #288
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #10
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #320
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #11
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #352
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #12
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #384
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #13
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #416
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #14
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #448
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #15
    s.add        s31, s27, s20
    s.addi       s27, s31, #64
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #480
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #0
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    s.movz       s27, #0
    s.add        s33, s27, s14                   // the tile origin
    v.splat      v38, s33
    v.add        v39, v36, v38
    s.add        s33, s27, s24                   // the tile origin
    v.splat      v38, s33
    v.cmp.lt     p1, v39, v38
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #16
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #1
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #48
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #2
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #80
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #3
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #112
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #4
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #144
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #5
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #176
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #6
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #208
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #7
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #240
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #8
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #272
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #9
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #304
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #10
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #336
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #11
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #368
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #12
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #400
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #13
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #432
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #14
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #464
    v.st.b       [s27, #0], v38
    v.extract    s27, v37, #15
    s.add        s31, s27, s20
    s.addi       s27, s31, #80
    s.add        s31, s2, s27
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v38, [s31, #0]
    s.addi       s27, s30, #496
    v.st.b       [s27, #0], v38
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.ld.w       v38, [s30, #0]
    v.mov        v56, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s27, s30, #64
    v.ld.w       v38, [s27, #0]
    v.mov        v57, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s27, s30, #128
    v.ld.w       v38, [s27, #0]
    v.mov        v58, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s27, s30, #192
    v.ld.w       v38, [s27, #0]
    v.mov        v59, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s27, s30, #256
    v.ld.w       v38, [s27, #0]
    v.mov        v60, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s27, s30, #320
    v.ld.w       v38, [s27, #0]
    v.mov        v61, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s27, s30, #384
    v.ld.w       v38, [s27, #0]
    v.mov        v62, v38                        // hand off through the shared window (sec 7.3)
    s.addi       s27, s30, #448
    v.ld.w       v38, [s27, #0]
    v.mov        v63, v38                        // hand off through the shared window (sec 7.3)
    mb.wait      s28
    mb.arm       s27, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s27
    mb.wait      s27
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s30, v26, #2
    br.nz        s30, x8dot_done_39
    s.movz       s31, #0
    s.addi       s33, s31, #0
    s.add        s31, s3, s21
    s.addi       s34, s31, #64
    s.addi       s31, s25, #256
x8dot_row_40:
    s.add        s35, s34, s33
    s.addi       s36, s22, #-64
    s.sub        s37, s36, s33
    v.splat      v38, s37
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s35, v29]            // index is in elements (ISA sec 9.1)
    s.shli       s35, s33, #4
    s.add        s36, s31, s35
    v.st.b       [s36, #0], v38
    fence.acq_rel.device
    s.addi       s35, s33, #1
    s.mov        s33, s35
    s.movz       s35, #32
    s.cmp.lt     s36, s33, s35
    br.nz        s36, x8dot_row_40
x8dot_done_39:
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s30
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.movz       s30, #0
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s33, s31            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s33, v35, #2
    s.movz       s34, #64
    s.mov        s35, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s35, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s33, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s33
    mb.wait      s33
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s35, v26, #3
    br.nz        s35, x8dot_done_41
    s.addi       s36, s30, #0
    s.add        s37, s3, s21
    s.addi       s38, s37, #64
    s.addi       s37, s25, #256
x8dot_row_42:
    s.add        s39, s38, s36
    s.addi       s40, s22, #-64
    s.sub        s41, s40, s36
    v.splat      v38, s41
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s39, v30]            // index is in elements (ISA sec 9.1)
    s.shli       s39, s36, #4
    s.add        s40, s37, s39
    v.st.b       [s40, #0], v38
    fence.acq_rel.device
    s.addi       s39, s36, #1
    s.mov        s36, s39
    s.movz       s39, #32
    s.cmp.lt     s40, s36, s39
    br.nz        s40, x8dot_row_42
x8dot_done_41:
    mb.arm       s36, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s35
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.mov        s37, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s37, s36            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s35, v35, #3
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s34
    mb.wait      s34
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s35, v26, #4
    br.nz        s35, x8dot_done_43
    s.addi       s37, s30, #0
    s.add        s30, s3, s21
    s.addi       s38, s30, #64
    s.addi       s30, s25, #256
x8dot_row_44:
    s.add        s39, s38, s37
    s.addi       s40, s22, #-64
    s.sub        s41, s40, s37
    v.splat      v38, s41
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s39, v31]            // index is in elements (ISA sec 9.1)
    s.shli       s39, s37, #4
    s.add        s40, s30, s39
    v.st.b       [s40, #0], v38
    fence.acq_rel.device
    s.addi       s39, s37, #1
    s.mov        s37, s39
    s.movz       s39, #32
    s.cmp.lt     s40, s37, s39
    br.nz        s40, x8dot_row_44
x8dot_done_43:
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s35
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.movz       s35, #0
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s37, s30            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s37, v35, #4
    s.movz       s38, #64
    s.mov        s39, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s39, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s37, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s37
    mb.wait      s37
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s39, v26, #5
    br.nz        s39, x8dot_done_45
    s.addi       s40, s35, #0
    s.add        s41, s3, s21
    s.addi       s42, s41, #64
    s.addi       s41, s25, #256
x8dot_row_46:
    s.add        s43, s42, s40
    s.addi       s44, s22, #-64
    s.sub        s45, s44, s40
    v.splat      v38, s45
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s43, v32]            // index is in elements (ISA sec 9.1)
    s.shli       s43, s40, #4
    s.add        s44, s41, s43
    v.st.b       [s44, #0], v38
    fence.acq_rel.device
    s.addi       s43, s40, #1
    s.mov        s40, s43
    s.movz       s43, #32
    s.cmp.lt     s44, s40, s43
    br.nz        s44, x8dot_row_46
x8dot_done_45:
    mb.arm       s40, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s39
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.mov        s41, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s41, s40            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s39, v35, #5
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s38
    mb.wait      s38
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s39, v26, #6
    br.nz        s39, x8dot_done_47
    s.addi       s41, s35, #0
    s.add        s35, s3, s21
    s.addi       s42, s35, #64
    s.addi       s35, s25, #256
x8dot_row_48:
    s.add        s43, s42, s41
    s.addi       s44, s22, #-64
    s.sub        s45, s44, s41
    v.splat      v38, s45
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s43, v33]            // index is in elements (ISA sec 9.1)
    s.shli       s43, s41, #4
    s.add        s44, s35, s43
    v.st.b       [s44, #0], v38
    fence.acq_rel.device
    s.addi       s43, s41, #1
    s.mov        s41, s43
    s.movz       s43, #32
    s.cmp.lt     s44, s41, s43
    br.nz        s44, x8dot_row_48
x8dot_done_47:
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s39
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.movz       s39, #0
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s41, s35            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s41, v35, #6
    s.movz       s42, #64
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s41, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s41
    mb.wait      s41
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s43, v26, #7
    br.nz        s43, x8dot_done_49
    s.addi       s44, s39, #0
    s.add        s45, s3, s21
    s.addi       s46, s45, #64
    s.addi       s45, s25, #256
x8dot_row_50:
    s.add        s47, s46, s44
    s.addi       s49, s22, #-64
    s.sub        s50, s49, s44
    v.splat      v38, s50
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s47, v34]            // index is in elements (ISA sec 9.1)
    s.shli       s47, s44, #4
    s.add        s49, s45, s47
    v.st.b       [s49, #0], v38
    fence.acq_rel.device
    s.addi       s47, s44, #1
    s.mov        s44, s47
    s.movz       s47, #32
    s.cmp.lt     s49, s44, s47
    br.nz        s49, x8dot_row_50
x8dot_done_49:
    mb.arm       s44, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v38, s43
    v.movi       v39, #0
    v.cmp.ne     p1, v38, v39
    v.cmp.eq     p2, v38, v39
    s.mov        s45, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s45, s44            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s43, v35, #7
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s42
    mb.wait      s42
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s43, v26, #0
    br.nz        s43, x8dot_done_51
    s.addi       s45, s39, #0
    s.add        s39, s3, s21
    s.addi       s46, s39, #96
    s.addi       s39, s25, #256
x8dot_row_52:
    s.add        s47, s46, s45
    s.addi       s49, s22, #-96
    s.sub        s50, s49, s45
    v.splat      v38, s50
    v.movi       v39, #0
    v.cmp.gt     p1, v38, v39
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v38, [s47, v27]            // index is in elements (ISA sec 9.1)
    s.shli       s47, s45, #4
    s.add        s49, s39, s47
    v.st.b       [s49, #0], v38
    fence.acq_rel.device
    s.addi       s47, s45, #1
    s.mov        s45, s47
    s.movz       s47, #32
    s.cmp.lt     s49, s45, s47
    br.nz        s49, x8dot_row_52
x8dot_done_51:
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v27, s43
    v.movi       v38, #0
    v.cmp.ne     p1, v27, v38
    v.cmp.eq     p2, v27, v38
    s.movz       s43, #0
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s45, s39            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s45, v35, #0
    s.movz       s46, #96
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s49, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s45, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s45
    mb.wait      s45
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s47, v26, #1
    br.nz        s47, x8dot_done_53
    s.addi       s49, s43, #0
    s.add        s50, s3, s21
    s.addi       s51, s50, #96
    s.addi       s50, s25, #256
x8dot_row_54:
    s.add        s52, s51, s49
    s.addi       s53, s22, #-96
    s.sub        s54, s53, s49
    v.splat      v27, s54
    v.movi       v38, #0
    v.cmp.gt     p1, v27, v38
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v27, [s52, v28]            // index is in elements (ISA sec 9.1)
    s.shli       s52, s49, #4
    s.add        s53, s50, s52
    v.st.b       [s53, #0], v27
    fence.acq_rel.device
    s.addi       s52, s49, #1
    s.mov        s49, s52
    s.movz       s52, #32
    s.cmp.lt     s53, s49, s52
    br.nz        s53, x8dot_row_54
x8dot_done_53:
    mb.arm       s49, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v27, s47
    v.movi       v28, #0
    v.cmp.ne     p1, v27, v28
    v.cmp.eq     p2, v27, v28
    s.mov        s50, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s50, s49            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s47, v35, #1
    s.mov        s50, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s49          // predicated off still completes once (ISA sec 9A.3)
    s.addi       s46, s25, #2560                 // 512 bytes of repack scratch
    v.extract    s47, v37, #0
    s.add        s50, s47, s20
    s.addi       s47, s50, #96
    s.add        s50, s2, s47
    s.add        s47, s43, s15                   // the tile origin
    v.splat      v27, s47
    v.add        v28, v36, v27
    s.add        s47, s43, s24                   // the tile origin
    v.splat      v27, s47
    v.cmp.lt     p1, v28, v27
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s50, #0]
    s.addi       s43, s46, #0
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #1
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #32
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #2
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #64
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #3
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #96
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #4
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #128
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #5
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #160
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #6
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #192
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #7
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #224
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #8
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #256
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #9
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #288
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #10
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #320
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #11
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #352
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #12
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #384
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #13
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #416
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #14
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #448
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #15
    s.add        s47, s43, s20
    s.addi       s43, s47, #96
    s.add        s47, s2, s43
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s43, s46, #480
    v.st.b       [s43, #0], v27
    v.extract    s43, v37, #0
    s.add        s47, s43, s20
    s.addi       s43, s47, #112
    s.add        s47, s2, s43
    s.movz       s43, #0
    s.add        s50, s43, s16                   // the tile origin
    v.splat      v27, s50
    v.add        v28, v36, v27
    s.add        s50, s43, s24                   // the tile origin
    v.splat      v27, s50
    v.cmp.lt     p1, v28, v27
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s47, #0]
    s.addi       s24, s46, #16
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #1
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #48
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #2
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #80
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #3
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #112
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #4
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #144
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #5
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #176
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #6
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #208
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #7
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #240
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #8
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #272
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #9
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #304
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #10
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #336
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #11
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #368
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #12
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #400
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #13
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #432
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #14
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #464
    v.st.b       [s24, #0], v27
    v.extract    s24, v37, #15
    s.add        s43, s24, s20
    s.addi       s24, s43, #112
    s.add        s43, s2, s24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.b       v27, [s43, #0]
    s.addi       s24, s46, #496
    v.st.b       [s24, #0], v27
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.ld.w       v27, [s46, #0]
    v.mov        v56, v27                        // hand off through the shared window (sec 7.3)
    s.addi       s24, s46, #64
    v.ld.w       v27, [s24, #0]
    v.mov        v57, v27                        // hand off through the shared window (sec 7.3)
    s.addi       s24, s46, #128
    v.ld.w       v27, [s24, #0]
    v.mov        v58, v27                        // hand off through the shared window (sec 7.3)
    s.addi       s24, s46, #192
    v.ld.w       v27, [s24, #0]
    v.mov        v59, v27                        // hand off through the shared window (sec 7.3)
    s.addi       s24, s46, #256
    v.ld.w       v27, [s24, #0]
    v.mov        v60, v27                        // hand off through the shared window (sec 7.3)
    s.addi       s24, s46, #320
    v.ld.w       v27, [s24, #0]
    v.mov        v61, v27                        // hand off through the shared window (sec 7.3)
    s.addi       s24, s46, #384
    v.ld.w       v27, [s24, #0]
    v.mov        v62, v27                        // hand off through the shared window (sec 7.3)
    s.addi       s24, s46, #448
    v.ld.w       v27, [s24, #0]
    v.mov        v63, v27                        // hand off through the shared window (sec 7.3)
    mb.wait      s39
    mb.arm       s24, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s24
    mb.wait      s24
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s43, v26, #2
    br.nz        s43, x8dot_done_55
    s.movz       s46, #0
    s.addi       s47, s46, #0
    s.add        s46, s3, s21
    s.addi       s50, s46, #96
    s.addi       s46, s25, #256
x8dot_row_56:
    s.add        s51, s50, s47
    s.addi       s52, s22, #-96
    s.sub        s53, s52, s47
    v.splat      v27, s53
    v.movi       v28, #0
    v.cmp.gt     p1, v27, v28
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v27, [s51, v29]            // index is in elements (ISA sec 9.1)
    s.shli       s51, s47, #4
    s.add        s52, s46, s51
    v.st.b       [s52, #0], v27
    fence.acq_rel.device
    s.addi       s51, s47, #1
    s.mov        s47, s51
    s.movz       s51, #32
    s.cmp.lt     s52, s47, s51
    br.nz        s52, x8dot_row_56
x8dot_done_55:
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v27, s43
    v.movi       v28, #0
    v.cmp.ne     p1, v27, v28
    v.cmp.eq     p2, v27, v28
    s.movz       s43, #0
    s.mov        s50, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s50, s46            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s47, v35, #2
    s.movz       s50, #96
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s51, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s47, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s47
    mb.wait      s47
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s51, v26, #3
    br.nz        s51, x8dot_done_57
    s.addi       s52, s43, #0
    s.add        s53, s3, s21
    s.addi       s54, s53, #96
    s.addi       s53, s25, #256
x8dot_row_58:
    s.add        s55, s54, s52
    s.addi       s56, s22, #-96
    s.sub        s57, s56, s52
    v.splat      v27, s57
    v.movi       v28, #0
    v.cmp.gt     p1, v27, v28
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v27, [s55, v30]            // index is in elements (ISA sec 9.1)
    s.shli       s55, s52, #4
    s.add        s56, s53, s55
    v.st.b       [s56, #0], v27
    fence.acq_rel.device
    s.addi       s55, s52, #1
    s.mov        s52, s55
    s.movz       s55, #32
    s.cmp.lt     s56, s52, s55
    br.nz        s56, x8dot_row_58
x8dot_done_57:
    mb.arm       s52, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v27, s51
    v.movi       v28, #0
    v.cmp.ne     p1, v27, v28
    v.cmp.eq     p2, v27, v28
    s.mov        s53, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s53, s52            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s51, v35, #3
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s53, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s50
    mb.wait      s50
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s51, v26, #4
    br.nz        s51, x8dot_done_59
    s.addi       s53, s43, #0
    s.add        s43, s3, s21
    s.addi       s54, s43, #96
    s.addi       s43, s25, #256
x8dot_row_60:
    s.add        s55, s54, s53
    s.addi       s56, s22, #-96
    s.sub        s57, s56, s53
    v.splat      v27, s57
    v.movi       v28, #0
    v.cmp.gt     p1, v27, v28
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v27, [s55, v31]            // index is in elements (ISA sec 9.1)
    s.shli       s55, s53, #4
    s.add        s56, s43, s55
    v.st.b       [s56, #0], v27
    fence.acq_rel.device
    s.addi       s55, s53, #1
    s.mov        s53, s55
    s.movz       s55, #32
    s.cmp.lt     s56, s53, s55
    br.nz        s56, x8dot_row_60
x8dot_done_59:
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v27, s51
    v.movi       v28, #0
    v.cmp.ne     p1, v27, v28
    v.cmp.eq     p2, v27, v28
    s.movz       s51, #0
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s53, s43            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s53, v35, #4
    s.movz       s54, #96
    s.mov        s55, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s55, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s53, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s53
    mb.wait      s53
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s55, v26, #5
    br.nz        s55, x8dot_done_61
    s.addi       s56, s51, #0
    s.add        s57, s3, s21
    s.addi       s58, s57, #96
    s.addi       s57, s25, #256
x8dot_row_62:
    s.add        s59, s58, s56
    s.addi       s60, s22, #-96
    s.sub        s23, s60, s56
    v.splat      v27, s23
    v.movi       v28, #0
    v.cmp.gt     p1, v27, v28
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v27, [s59, v32]            // index is in elements (ISA sec 9.1)
    s.shli       s23, s56, #4
    s.add        s24, s57, s23
    v.st.b       [s24, #0], v27
    fence.acq_rel.device
    s.addi       s23, s56, #1
    s.mov        s56, s23
    s.movz       s23, #32
    s.cmp.lt     s24, s56, s23
    br.nz        s24, x8dot_row_62
x8dot_done_61:
    mb.arm       s23, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v27, s55
    v.movi       v28, #0
    v.cmp.ne     p1, v27, v28
    v.cmp.eq     p2, v27, v28
    s.mov        s26, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s27, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s26, s23            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s24, v35, #5
    s.mov        s26, s24                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s27, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s26, s23          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s24, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s24
    mb.wait      s24
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s26, v26, #6
    br.nz        s26, x8dot_done_63
    s.addi       s27, s51, #0
    s.add        s28, s3, s21
    s.addi       s29, s28, #96
    s.addi       s28, s25, #256
x8dot_row_64:
    s.add        s30, s29, s27
    s.addi       s31, s22, #-96
    s.sub        s32, s31, s27
    v.splat      v27, s32
    v.movi       v28, #0
    v.cmp.gt     p1, v27, v28
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v27, [s30, v33]            // index is in elements (ISA sec 9.1)
    s.shli       s30, s27, #4
    s.add        s31, s28, s30
    v.st.b       [s31, #0], v27
    fence.acq_rel.device
    s.addi       s30, s27, #1
    s.mov        s27, s30
    s.movz       s30, #32
    s.cmp.lt     s31, s27, s30
    br.nz        s31, x8dot_row_64
x8dot_done_63:
    mb.arm       s27, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v27, s26
    v.movi       v28, #0
    v.cmp.ne     p1, v27, v28
    v.cmp.eq     p2, v27, v28
    s.movz       s26, #0
    s.mov        s28, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s29, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s28, s27            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s28, v35, #6
    s.movz       s29, #96
    s.mov        s30, s28                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s30, s27          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s23
    mb.arm       s28, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s28
    mb.wait      s28
    w.def        w1, #48, #8                     // v48..v55
    v.extract    s30, v26, #7
    br.nz        s30, x8dot_done_65
    s.addi       s31, s26, #0
    s.add        s32, s3, s21
    s.addi       s33, s32, #96
    s.addi       s32, s25, #256
x8dot_row_66:
    s.add        s34, s33, s31
    s.addi       s35, s22, #-96
    s.sub        s36, s35, s31
    v.splat      v26, s36
    v.movi       v27, #0
    v.cmp.gt     p1, v26, v27
    v.movi       v26, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v26, [s34, v34]            // index is in elements (ISA sec 9.1)
    s.shli       s34, s31, #4
    s.add        s35, s32, s34
    v.st.b       [s35, #0], v26
    fence.acq_rel.device
    s.addi       s34, s31, #1
    s.mov        s31, s34
    s.movz       s34, #32
    s.cmp.lt     s35, s31, s34
    br.nz        s35, x8dot_row_66
x8dot_done_65:
    mb.arm       s22, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v26, s30
    v.movi       v27, #0
    v.cmp.ne     p1, v26, v27
    v.cmp.eq     p2, v26, v27
    s.mov        s30, s26                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s31, s26                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s30, s22            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s30, v35, #7
    s.mov        s31, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s29                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s31, s22          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s27
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s29
    mb.wait      s29
    mb.wait      s22
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s30
    mb.wait      s30
    s.addi       s31, s25, #3072
    a.vread      v26, a8, s26
    v.st.w       [s31, #0], v26
    s.addi       s26, s31, #64
    s.movz       s32, #1
    a.vread      v26, a8, s32
    v.st.w       [s26, #0], v26
    s.addi       s26, s31, #128
    s.movz       s32, #2
    a.vread      v26, a8, s32
    v.st.w       [s26, #0], v26
    s.addi       s26, s31, #192
    s.movz       s32, #3
    a.vread      v26, a8, s32
    v.st.w       [s26, #0], v26
    s.addi       s26, s31, #256
    s.movz       s32, #4
    a.vread      v26, a8, s32
    v.st.w       [s26, #0], v26
    s.addi       s26, s31, #320
    s.movz       s32, #5
    a.vread      v26, a8, s32
    v.st.w       [s26, #0], v26
    s.addi       s26, s31, #384
    s.movz       s32, #6
    a.vread      v26, a8, s32
    v.st.w       [s26, #0], v26
    s.addi       s26, s31, #448
    s.movz       s32, #7
    a.vread      v26, a8, s32
    v.st.w       [s26, #0], v26
    s.addi       s26, s31, #512
    s.movz       s32, #8
    a.vread      v26, a8, s32
    v.st.w       [s26, #0], v26
    s.addi       s26, s31, #576
    s.movz       s32, #9
    a.vread      v26, a8, s32
    v.st.w       [s26, #0], v26
    s.addi       s26, s31, #640
    s.movz       s32, #10
    a.vread      v26, a8, s32
    v.st.w       [s26, #0], v26
    s.addi       s26, s31, #704
    s.movz       s32, #11
    a.vread      v26, a8, s32
    v.st.w       [s26, #0], v26
    s.addi       s26, s31, #768
    s.movz       s32, #12
    a.vread      v26, a8, s32
    v.st.w       [s26, #0], v26
    s.addi       s26, s31, #832
    s.movz       s32, #13
    a.vread      v26, a8, s32
    v.st.w       [s26, #0], v26
    s.addi       s26, s31, #896
    s.movz       s32, #14
    a.vread      v26, a8, s32
    v.st.w       [s26, #0], v26
    s.addi       s26, s31, #960
    s.movz       s31, #15
    a.vread      v26, a8, s31
    v.st.w       [s26, #0], v26
    fence.acq_rel.device
    s.addi       s26, s25, #4096
    s.movz       s31, #0
    a.vread      v26, a9, s31
    v.st.w       [s26, #0], v26
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v26, a9, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v26, a9, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v26, a9, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v26, a9, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v26, a9, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v26, a9, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v26, a9, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v26, a9, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v26, a9, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v26, a9, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v26, a9, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v26, a9, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v26, a9, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v26, a9, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v26, a9, s26
    v.st.w       [s31, #0], v26
    fence.acq_rel.device
    s.addi       s26, s25, #5120
    s.movz       s31, #0
    a.vread      v26, a10, s31
    v.st.w       [s26, #0], v26
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v26, a10, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v26, a10, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v26, a10, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v26, a10, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v26, a10, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v26, a10, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v26, a10, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v26, a10, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v26, a10, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v26, a10, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v26, a10, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v26, a10, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v26, a10, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v26, a10, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v26, a10, s26
    v.st.w       [s31, #0], v26
    fence.acq_rel.device
    s.addi       s26, s25, #6144
    s.movz       s31, #0
    a.vread      v26, a11, s31
    v.st.w       [s26, #0], v26
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v26, a11, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v26, a11, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v26, a11, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v26, a11, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v26, a11, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v26, a11, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v26, a11, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v26, a11, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v26, a11, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v26, a11, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v26, a11, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v26, a11, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v26, a11, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v26, a11, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v26, a11, s26
    v.st.w       [s31, #0], v26
    fence.acq_rel.device
    s.addi       s26, s25, #7168
    s.movz       s31, #0
    a.vread      v26, a12, s31
    v.st.w       [s26, #0], v26
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v26, a12, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v26, a12, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v26, a12, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v26, a12, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v26, a12, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v26, a12, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v26, a12, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v26, a12, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v26, a12, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v26, a12, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v26, a12, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v26, a12, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v26, a12, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v26, a12, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v26, a12, s26
    v.st.w       [s31, #0], v26
    fence.acq_rel.device
    s.addi       s26, s25, #8192
    s.movz       s31, #0
    a.vread      v26, a13, s31
    v.st.w       [s26, #0], v26
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v26, a13, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v26, a13, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v26, a13, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v26, a13, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v26, a13, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v26, a13, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v26, a13, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v26, a13, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v26, a13, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v26, a13, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v26, a13, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v26, a13, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v26, a13, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v26, a13, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v26, a13, s26
    v.st.w       [s31, #0], v26
    fence.acq_rel.device
    s.addi       s26, s25, #9216
    s.movz       s31, #0
    a.vread      v26, a14, s31
    v.st.w       [s26, #0], v26
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v26, a14, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v26, a14, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v26, a14, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v26, a14, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v26, a14, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v26, a14, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v26, a14, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v26, a14, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v26, a14, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v26, a14, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v26, a14, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v26, a14, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v26, a14, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v26, a14, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v26, a14, s26
    v.st.w       [s31, #0], v26
    fence.acq_rel.device
    s.addi       s26, s25, #10240
    s.movz       s31, #0
    a.vread      v26, a15, s31
    v.st.w       [s26, #0], v26
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v26, a15, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v26, a15, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v26, a15, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v26, a15, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v26, a15, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v26, a15, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v26, a15, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v26, a15, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v26, a15, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v26, a15, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v26, a15, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v26, a15, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v26, a15, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v26, a15, s32
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v26, a15, s26
    v.st.w       [s31, #0], v26
    fence.acq_rel.device
    s.addi       s26, s25, #11264
    s.movz       s31, #0
    a.vread      v26, a0, s31
    s.addi       s31, s25, #3072
    v.ld.w       v27, [s31, #0]
    v.extract    s31, v0, #0
    v.splat      v28, s31
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s26, #0], v28
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v26, a0, s32
    s.addi       s32, s25, #3136
    v.ld.w       v27, [s32, #0]
    v.extract    s32, v0, #1
    v.splat      v28, s32
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s31, #0], v28
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v26, a0, s32
    s.addi       s32, s25, #3200
    v.ld.w       v27, [s32, #0]
    v.extract    s32, v0, #2
    v.splat      v28, s32
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s31, #0], v28
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v26, a0, s32
    s.addi       s32, s25, #3264
    v.ld.w       v27, [s32, #0]
    v.extract    s32, v0, #3
    v.splat      v28, s32
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s31, #0], v28
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v26, a0, s32
    s.addi       s32, s25, #3328
    v.ld.w       v27, [s32, #0]
    v.extract    s32, v0, #4
    v.splat      v28, s32
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s31, #0], v28
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v26, a0, s32
    s.addi       s32, s25, #3392
    v.ld.w       v27, [s32, #0]
    v.extract    s32, v0, #5
    v.splat      v28, s32
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s31, #0], v28
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v26, a0, s32
    s.addi       s32, s25, #3456
    v.ld.w       v27, [s32, #0]
    v.extract    s32, v0, #6
    v.splat      v28, s32
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s31, #0], v28
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v26, a0, s32
    s.addi       s32, s25, #3520
    v.ld.w       v27, [s32, #0]
    v.extract    s32, v0, #7
    v.splat      v28, s32
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s31, #0], v28
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v26, a0, s32
    s.addi       s32, s25, #3584
    v.ld.w       v27, [s32, #0]
    v.extract    s32, v0, #8
    v.splat      v28, s32
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s31, #0], v28
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v26, a0, s32
    s.addi       s32, s25, #3648
    v.ld.w       v27, [s32, #0]
    v.extract    s32, v0, #9
    v.splat      v28, s32
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s31, #0], v28
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v26, a0, s32
    s.addi       s32, s25, #3712
    v.ld.w       v27, [s32, #0]
    v.extract    s32, v0, #10
    v.splat      v28, s32
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s31, #0], v28
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v26, a0, s32
    s.addi       s32, s25, #3776
    v.ld.w       v27, [s32, #0]
    v.extract    s32, v0, #11
    v.splat      v28, s32
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s31, #0], v28
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v26, a0, s32
    s.addi       s32, s25, #3840
    v.ld.w       v27, [s32, #0]
    v.extract    s32, v0, #12
    v.splat      v28, s32
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s31, #0], v28
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v26, a0, s32
    s.addi       s32, s25, #3904
    v.ld.w       v27, [s32, #0]
    v.extract    s32, v0, #13
    v.splat      v28, s32
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s31, #0], v28
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v26, a0, s32
    s.addi       s32, s25, #3968
    v.ld.w       v27, [s32, #0]
    v.extract    s32, v0, #14
    v.splat      v28, s32
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v28, v26, v27
    v.st.w       [s31, #0], v28
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v26, a0, s26
    s.addi       s26, s25, #4032
    v.ld.w       v27, [s26, #0]
    v.extract    s26, v0, #15
    v.splat      v28, s26
    vf.mul       v29, v27, v28
    vf.mul       v27, v29, v17
    vf.add       v17, v26, v27
    v.st.w       [s31, #0], v17
    fence.acq_rel.device
    s.addi       s26, s25, #12288
    s.movz       s31, #0
    a.vread      v17, a1, s31
    s.addi       s31, s25, #4096
    v.ld.w       v26, [s31, #0]
    v.extract    s31, v0, #0
    v.splat      v27, s31
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s26, #0], v27
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v17, a1, s32
    s.addi       s32, s25, #4160
    v.ld.w       v26, [s32, #0]
    v.extract    s32, v0, #1
    v.splat      v27, s32
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s31, #0], v27
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v17, a1, s32
    s.addi       s32, s25, #4224
    v.ld.w       v26, [s32, #0]
    v.extract    s32, v0, #2
    v.splat      v27, s32
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s31, #0], v27
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v17, a1, s32
    s.addi       s32, s25, #4288
    v.ld.w       v26, [s32, #0]
    v.extract    s32, v0, #3
    v.splat      v27, s32
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s31, #0], v27
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v17, a1, s32
    s.addi       s32, s25, #4352
    v.ld.w       v26, [s32, #0]
    v.extract    s32, v0, #4
    v.splat      v27, s32
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s31, #0], v27
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v17, a1, s32
    s.addi       s32, s25, #4416
    v.ld.w       v26, [s32, #0]
    v.extract    s32, v0, #5
    v.splat      v27, s32
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s31, #0], v27
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v17, a1, s32
    s.addi       s32, s25, #4480
    v.ld.w       v26, [s32, #0]
    v.extract    s32, v0, #6
    v.splat      v27, s32
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s31, #0], v27
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v17, a1, s32
    s.addi       s32, s25, #4544
    v.ld.w       v26, [s32, #0]
    v.extract    s32, v0, #7
    v.splat      v27, s32
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s31, #0], v27
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v17, a1, s32
    s.addi       s32, s25, #4608
    v.ld.w       v26, [s32, #0]
    v.extract    s32, v0, #8
    v.splat      v27, s32
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s31, #0], v27
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v17, a1, s32
    s.addi       s32, s25, #4672
    v.ld.w       v26, [s32, #0]
    v.extract    s32, v0, #9
    v.splat      v27, s32
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s31, #0], v27
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v17, a1, s32
    s.addi       s32, s25, #4736
    v.ld.w       v26, [s32, #0]
    v.extract    s32, v0, #10
    v.splat      v27, s32
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s31, #0], v27
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v17, a1, s32
    s.addi       s32, s25, #4800
    v.ld.w       v26, [s32, #0]
    v.extract    s32, v0, #11
    v.splat      v27, s32
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s31, #0], v27
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v17, a1, s32
    s.addi       s32, s25, #4864
    v.ld.w       v26, [s32, #0]
    v.extract    s32, v0, #12
    v.splat      v27, s32
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s31, #0], v27
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v17, a1, s32
    s.addi       s32, s25, #4928
    v.ld.w       v26, [s32, #0]
    v.extract    s32, v0, #13
    v.splat      v27, s32
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s31, #0], v27
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v17, a1, s32
    s.addi       s32, s25, #4992
    v.ld.w       v26, [s32, #0]
    v.extract    s32, v0, #14
    v.splat      v27, s32
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v27, v17, v26
    v.st.w       [s31, #0], v27
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v17, a1, s26
    s.addi       s26, s25, #5056
    v.ld.w       v26, [s26, #0]
    v.extract    s26, v0, #15
    v.splat      v27, s26
    vf.mul       v28, v26, v27
    vf.mul       v26, v28, v19
    vf.add       v19, v17, v26
    v.st.w       [s31, #0], v19
    fence.acq_rel.device
    s.addi       s26, s25, #13312
    s.movz       s31, #0
    a.vread      v17, a2, s31
    s.addi       s31, s25, #5120
    v.ld.w       v19, [s31, #0]
    v.extract    s31, v0, #0
    v.splat      v26, s31
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s26, #0], v26
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v17, a2, s32
    s.addi       s32, s25, #5184
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #1
    v.splat      v26, s32
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v17, a2, s32
    s.addi       s32, s25, #5248
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #2
    v.splat      v26, s32
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v17, a2, s32
    s.addi       s32, s25, #5312
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #3
    v.splat      v26, s32
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v17, a2, s32
    s.addi       s32, s25, #5376
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #4
    v.splat      v26, s32
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v17, a2, s32
    s.addi       s32, s25, #5440
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #5
    v.splat      v26, s32
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v17, a2, s32
    s.addi       s32, s25, #5504
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #6
    v.splat      v26, s32
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v17, a2, s32
    s.addi       s32, s25, #5568
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #7
    v.splat      v26, s32
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v17, a2, s32
    s.addi       s32, s25, #5632
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #8
    v.splat      v26, s32
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v17, a2, s32
    s.addi       s32, s25, #5696
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #9
    v.splat      v26, s32
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v17, a2, s32
    s.addi       s32, s25, #5760
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #10
    v.splat      v26, s32
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v17, a2, s32
    s.addi       s32, s25, #5824
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #11
    v.splat      v26, s32
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v17, a2, s32
    s.addi       s32, s25, #5888
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #12
    v.splat      v26, s32
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v17, a2, s32
    s.addi       s32, s25, #5952
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #13
    v.splat      v26, s32
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v17, a2, s32
    s.addi       s32, s25, #6016
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #14
    v.splat      v26, s32
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v26, v17, v19
    v.st.w       [s31, #0], v26
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v17, a2, s26
    s.addi       s26, s25, #6080
    v.ld.w       v19, [s26, #0]
    v.extract    s26, v0, #15
    v.splat      v26, s26
    vf.mul       v27, v19, v26
    vf.mul       v19, v27, v20
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    fence.acq_rel.device
    s.addi       s26, s25, #14336
    s.movz       s31, #0
    a.vread      v17, a3, s31
    s.addi       s31, s25, #6144
    v.ld.w       v19, [s31, #0]
    v.extract    s31, v0, #0
    v.splat      v20, s31
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s26, #0], v20
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v17, a3, s32
    s.addi       s32, s25, #6208
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #1
    v.splat      v20, s32
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v17, a3, s32
    s.addi       s32, s25, #6272
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #2
    v.splat      v20, s32
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v17, a3, s32
    s.addi       s32, s25, #6336
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #3
    v.splat      v20, s32
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v17, a3, s32
    s.addi       s32, s25, #6400
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #4
    v.splat      v20, s32
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v17, a3, s32
    s.addi       s32, s25, #6464
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #5
    v.splat      v20, s32
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v17, a3, s32
    s.addi       s32, s25, #6528
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #6
    v.splat      v20, s32
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v17, a3, s32
    s.addi       s32, s25, #6592
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #7
    v.splat      v20, s32
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v17, a3, s32
    s.addi       s32, s25, #6656
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #8
    v.splat      v20, s32
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v17, a3, s32
    s.addi       s32, s25, #6720
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #9
    v.splat      v20, s32
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v17, a3, s32
    s.addi       s32, s25, #6784
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #10
    v.splat      v20, s32
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v17, a3, s32
    s.addi       s32, s25, #6848
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #11
    v.splat      v20, s32
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v17, a3, s32
    s.addi       s32, s25, #6912
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #12
    v.splat      v20, s32
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v17, a3, s32
    s.addi       s32, s25, #6976
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #13
    v.splat      v20, s32
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v17, a3, s32
    s.addi       s32, s25, #7040
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #14
    v.splat      v20, s32
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v17, a3, s26
    s.addi       s26, s25, #7104
    v.ld.w       v19, [s26, #0]
    v.extract    s26, v0, #15
    v.splat      v20, s26
    vf.mul       v26, v19, v20
    vf.mul       v19, v26, v21
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    fence.acq_rel.device
    s.addi       s26, s25, #15360
    s.movz       s31, #0
    a.vread      v17, a4, s31
    s.addi       s31, s25, #7168
    v.ld.w       v19, [s31, #0]
    v.extract    s31, v0, #0
    v.splat      v20, s31
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s26, #0], v20
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v17, a4, s32
    s.addi       s32, s25, #7232
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #1
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v17, a4, s32
    s.addi       s32, s25, #7296
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #2
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v17, a4, s32
    s.addi       s32, s25, #7360
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #3
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v17, a4, s32
    s.addi       s32, s25, #7424
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #4
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v17, a4, s32
    s.addi       s32, s25, #7488
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #5
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v17, a4, s32
    s.addi       s32, s25, #7552
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #6
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v17, a4, s32
    s.addi       s32, s25, #7616
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #7
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v17, a4, s32
    s.addi       s32, s25, #7680
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #8
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v17, a4, s32
    s.addi       s32, s25, #7744
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #9
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v17, a4, s32
    s.addi       s32, s25, #7808
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #10
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v17, a4, s32
    s.addi       s32, s25, #7872
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #11
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v17, a4, s32
    s.addi       s32, s25, #7936
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #12
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v17, a4, s32
    s.addi       s32, s25, #8000
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #13
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v17, a4, s32
    s.addi       s32, s25, #8064
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #14
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v17, a4, s26
    s.addi       s26, s25, #8128
    v.ld.w       v19, [s26, #0]
    v.extract    s26, v0, #15
    v.splat      v20, s26
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v22
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    fence.acq_rel.device
    s.addi       s26, s25, #16384
    s.movz       s31, #0
    a.vread      v17, a5, s31
    s.addi       s31, s25, #8192
    v.ld.w       v19, [s31, #0]
    v.extract    s31, v0, #0
    v.splat      v20, s31
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s26, #0], v20
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v17, a5, s32
    s.addi       s32, s25, #8256
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #1
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v17, a5, s32
    s.addi       s32, s25, #8320
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #2
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v17, a5, s32
    s.addi       s32, s25, #8384
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #3
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v17, a5, s32
    s.addi       s32, s25, #8448
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #4
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v17, a5, s32
    s.addi       s32, s25, #8512
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #5
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v17, a5, s32
    s.addi       s32, s25, #8576
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #6
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v17, a5, s32
    s.addi       s32, s25, #8640
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #7
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v17, a5, s32
    s.addi       s32, s25, #8704
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #8
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v17, a5, s32
    s.addi       s32, s25, #8768
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #9
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v17, a5, s32
    s.addi       s32, s25, #8832
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #10
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v17, a5, s32
    s.addi       s32, s25, #8896
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #11
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v17, a5, s32
    s.addi       s32, s25, #8960
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #12
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v17, a5, s32
    s.addi       s32, s25, #9024
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #13
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v17, a5, s32
    s.addi       s32, s25, #9088
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #14
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v17, a5, s26
    s.addi       s26, s25, #9152
    v.ld.w       v19, [s26, #0]
    v.extract    s26, v0, #15
    v.splat      v20, s26
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v23
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    fence.acq_rel.device
    s.addi       s26, s25, #17408
    s.movz       s31, #0
    a.vread      v17, a6, s31
    s.addi       s31, s25, #9216
    v.ld.w       v19, [s31, #0]
    v.extract    s31, v0, #0
    v.splat      v20, s31
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s26, #0], v20
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v17, a6, s32
    s.addi       s32, s25, #9280
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #1
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v17, a6, s32
    s.addi       s32, s25, #9344
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #2
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v17, a6, s32
    s.addi       s32, s25, #9408
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #3
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v17, a6, s32
    s.addi       s32, s25, #9472
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #4
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v17, a6, s32
    s.addi       s32, s25, #9536
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #5
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v17, a6, s32
    s.addi       s32, s25, #9600
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #6
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v17, a6, s32
    s.addi       s32, s25, #9664
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #7
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v17, a6, s32
    s.addi       s32, s25, #9728
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #8
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v17, a6, s32
    s.addi       s32, s25, #9792
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #9
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v17, a6, s32
    s.addi       s32, s25, #9856
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #10
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v17, a6, s32
    s.addi       s32, s25, #9920
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #11
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v17, a6, s32
    s.addi       s32, s25, #9984
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #12
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v17, a6, s32
    s.addi       s32, s25, #10048
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #13
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v17, a6, s32
    s.addi       s32, s25, #10112
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #14
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v17, a6, s26
    s.addi       s26, s25, #10176
    v.ld.w       v19, [s26, #0]
    v.extract    s26, v0, #15
    v.splat      v20, s26
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v24
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    fence.acq_rel.device
    s.addi       s26, s25, #18432
    s.movz       s31, #0
    a.vread      v17, a7, s31
    s.addi       s31, s25, #10240
    v.ld.w       v19, [s31, #0]
    v.extract    s31, v0, #0
    v.splat      v20, s31
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s26, #0], v20
    s.addi       s31, s26, #64
    s.movz       s32, #1
    a.vread      v17, a7, s32
    s.addi       s32, s25, #10304
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #1
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #128
    s.movz       s32, #2
    a.vread      v17, a7, s32
    s.addi       s32, s25, #10368
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #2
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #192
    s.movz       s32, #3
    a.vread      v17, a7, s32
    s.addi       s32, s25, #10432
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #3
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #256
    s.movz       s32, #4
    a.vread      v17, a7, s32
    s.addi       s32, s25, #10496
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #4
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #320
    s.movz       s32, #5
    a.vread      v17, a7, s32
    s.addi       s32, s25, #10560
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #5
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #384
    s.movz       s32, #6
    a.vread      v17, a7, s32
    s.addi       s32, s25, #10624
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #6
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #448
    s.movz       s32, #7
    a.vread      v17, a7, s32
    s.addi       s32, s25, #10688
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #7
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #512
    s.movz       s32, #8
    a.vread      v17, a7, s32
    s.addi       s32, s25, #10752
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #8
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #576
    s.movz       s32, #9
    a.vread      v17, a7, s32
    s.addi       s32, s25, #10816
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #9
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #640
    s.movz       s32, #10
    a.vread      v17, a7, s32
    s.addi       s32, s25, #10880
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #10
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #704
    s.movz       s32, #11
    a.vread      v17, a7, s32
    s.addi       s32, s25, #10944
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #11
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #768
    s.movz       s32, #12
    a.vread      v17, a7, s32
    s.addi       s32, s25, #11008
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #12
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #832
    s.movz       s32, #13
    a.vread      v17, a7, s32
    s.addi       s32, s25, #11072
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #13
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #896
    s.movz       s32, #14
    a.vread      v17, a7, s32
    s.addi       s32, s25, #11136
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v0, #14
    v.splat      v20, s32
    vf.mul       v21, v19, v20
    vf.mul       v19, v21, v25
    vf.add       v20, v17, v19
    v.st.w       [s31, #0], v20
    s.addi       s31, s26, #960
    s.movz       s26, #15
    a.vread      v17, a7, s26
    s.addi       s26, s25, #11200
    v.ld.w       v19, [s26, #0]
    v.extract    s26, v0, #15
    v.splat      v0, s26
    vf.mul       v20, v19, v0
    vf.mul       v0, v20, v25
    vf.add       v19, v17, v0
    v.st.w       [s31, #0], v19
    fence.acq_rel.device
    s.addi       s26, s20, #128
    s.addi       s31, s26, #0
    s.addi       s26, s21, #128
    s.addi       s32, s26, #0
    s.mov        s20, s31
    s.mov        s21, s32
    s.movz       s26, #0
    s.addi       s31, s25, #11264
    v.ld.w       v0, [s31, #0]
    a.vwrite     a0, s26, v0
    s.movz       s31, #1
    s.addi       s32, s25, #11328
    v.ld.w       v0, [s32, #0]
    a.vwrite     a0, s31, v0
    s.movz       s32, #2
    s.addi       s33, s25, #11392
    v.ld.w       v0, [s33, #0]
    a.vwrite     a0, s32, v0
    s.movz       s33, #3
    s.addi       s34, s25, #11456
    v.ld.w       v0, [s34, #0]
    a.vwrite     a0, s33, v0
    s.movz       s34, #4
    s.addi       s35, s25, #11520
    v.ld.w       v0, [s35, #0]
    a.vwrite     a0, s34, v0
    s.movz       s35, #5
    s.addi       s36, s25, #11584
    v.ld.w       v0, [s36, #0]
    a.vwrite     a0, s35, v0
    s.movz       s36, #6
    s.addi       s37, s25, #11648
    v.ld.w       v0, [s37, #0]
    a.vwrite     a0, s36, v0
    s.movz       s37, #7
    s.addi       s38, s25, #11712
    v.ld.w       v0, [s38, #0]
    a.vwrite     a0, s37, v0
    s.movz       s38, #8
    s.addi       s39, s25, #11776
    v.ld.w       v0, [s39, #0]
    a.vwrite     a0, s38, v0
    s.movz       s39, #9
    s.addi       s40, s25, #11840
    v.ld.w       v0, [s40, #0]
    a.vwrite     a0, s39, v0
    s.movz       s40, #10
    s.addi       s41, s25, #11904
    v.ld.w       v0, [s41, #0]
    a.vwrite     a0, s40, v0
    s.movz       s41, #11
    s.addi       s42, s25, #11968
    v.ld.w       v0, [s42, #0]
    a.vwrite     a0, s41, v0
    s.movz       s42, #12
    s.addi       s44, s25, #12032
    v.ld.w       v0, [s44, #0]
    a.vwrite     a0, s42, v0
    s.movz       s44, #13
    s.addi       s45, s25, #12096
    v.ld.w       v0, [s45, #0]
    a.vwrite     a0, s44, v0
    s.movz       s45, #14
    s.addi       s46, s25, #12160
    v.ld.w       v0, [s46, #0]
    a.vwrite     a0, s45, v0
    s.movz       s46, #15
    s.addi       s47, s25, #12224
    v.ld.w       v0, [s47, #0]
    a.vwrite     a0, s46, v0
    s.addi       s47, s25, #12288
    v.ld.w       v0, [s47, #0]
    a.vwrite     a1, s26, v0
    s.addi       s26, s25, #12352
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s31, v0
    s.addi       s26, s25, #12416
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s32, v0
    s.addi       s26, s25, #12480
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s33, v0
    s.addi       s26, s25, #12544
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s34, v0
    s.addi       s26, s25, #12608
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s35, v0
    s.addi       s26, s25, #12672
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s36, v0
    s.addi       s26, s25, #12736
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s37, v0
    s.addi       s26, s25, #12800
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s38, v0
    s.addi       s26, s25, #12864
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s39, v0
    s.addi       s26, s25, #12928
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s40, v0
    s.addi       s26, s25, #12992
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s41, v0
    s.addi       s26, s25, #13056
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s42, v0
    s.addi       s26, s25, #13120
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s44, v0
    s.addi       s26, s25, #13184
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s45, v0
    s.addi       s26, s25, #13248
    v.ld.w       v0, [s26, #0]
    a.vwrite     a1, s46, v0
    s.movz       s26, #0
    s.addi       s31, s25, #13312
    v.ld.w       v0, [s31, #0]
    a.vwrite     a2, s26, v0
    s.movz       s31, #1
    s.addi       s32, s25, #13376
    v.ld.w       v0, [s32, #0]
    a.vwrite     a2, s31, v0
    s.movz       s32, #2
    s.addi       s33, s25, #13440
    v.ld.w       v0, [s33, #0]
    a.vwrite     a2, s32, v0
    s.movz       s33, #3
    s.addi       s34, s25, #13504
    v.ld.w       v0, [s34, #0]
    a.vwrite     a2, s33, v0
    s.movz       s34, #4
    s.addi       s35, s25, #13568
    v.ld.w       v0, [s35, #0]
    a.vwrite     a2, s34, v0
    s.movz       s35, #5
    s.addi       s36, s25, #13632
    v.ld.w       v0, [s36, #0]
    a.vwrite     a2, s35, v0
    s.movz       s36, #6
    s.addi       s37, s25, #13696
    v.ld.w       v0, [s37, #0]
    a.vwrite     a2, s36, v0
    s.movz       s37, #7
    s.addi       s38, s25, #13760
    v.ld.w       v0, [s38, #0]
    a.vwrite     a2, s37, v0
    s.movz       s38, #8
    s.addi       s39, s25, #13824
    v.ld.w       v0, [s39, #0]
    a.vwrite     a2, s38, v0
    s.movz       s39, #9
    s.addi       s40, s25, #13888
    v.ld.w       v0, [s40, #0]
    a.vwrite     a2, s39, v0
    s.movz       s40, #10
    s.addi       s41, s25, #13952
    v.ld.w       v0, [s41, #0]
    a.vwrite     a2, s40, v0
    s.movz       s41, #11
    s.addi       s42, s25, #14016
    v.ld.w       v0, [s42, #0]
    a.vwrite     a2, s41, v0
    s.movz       s42, #12
    s.addi       s44, s25, #14080
    v.ld.w       v0, [s44, #0]
    a.vwrite     a2, s42, v0
    s.movz       s44, #13
    s.addi       s45, s25, #14144
    v.ld.w       v0, [s45, #0]
    a.vwrite     a2, s44, v0
    s.movz       s45, #14
    s.addi       s46, s25, #14208
    v.ld.w       v0, [s46, #0]
    a.vwrite     a2, s45, v0
    s.movz       s46, #15
    s.addi       s47, s25, #14272
    v.ld.w       v0, [s47, #0]
    a.vwrite     a2, s46, v0
    s.addi       s47, s25, #14336
    v.ld.w       v0, [s47, #0]
    a.vwrite     a3, s26, v0
    s.addi       s26, s25, #14400
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s31, v0
    s.addi       s26, s25, #14464
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s32, v0
    s.addi       s26, s25, #14528
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s33, v0
    s.addi       s26, s25, #14592
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s34, v0
    s.addi       s26, s25, #14656
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s35, v0
    s.addi       s26, s25, #14720
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s36, v0
    s.addi       s26, s25, #14784
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s37, v0
    s.addi       s26, s25, #14848
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s38, v0
    s.addi       s26, s25, #14912
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s39, v0
    s.addi       s26, s25, #14976
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s40, v0
    s.addi       s26, s25, #15040
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s41, v0
    s.addi       s26, s25, #15104
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s42, v0
    s.addi       s26, s25, #15168
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s44, v0
    s.addi       s26, s25, #15232
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s45, v0
    s.addi       s26, s25, #15296
    v.ld.w       v0, [s26, #0]
    a.vwrite     a3, s46, v0
    s.movz       s26, #0
    s.addi       s31, s25, #15360
    v.ld.w       v0, [s31, #0]
    a.vwrite     a4, s26, v0
    s.movz       s31, #1
    s.addi       s32, s25, #15424
    v.ld.w       v0, [s32, #0]
    a.vwrite     a4, s31, v0
    s.movz       s32, #2
    s.addi       s33, s25, #15488
    v.ld.w       v0, [s33, #0]
    a.vwrite     a4, s32, v0
    s.movz       s33, #3
    s.addi       s34, s25, #15552
    v.ld.w       v0, [s34, #0]
    a.vwrite     a4, s33, v0
    s.movz       s34, #4
    s.addi       s35, s25, #15616
    v.ld.w       v0, [s35, #0]
    a.vwrite     a4, s34, v0
    s.movz       s35, #5
    s.addi       s36, s25, #15680
    v.ld.w       v0, [s36, #0]
    a.vwrite     a4, s35, v0
    s.movz       s36, #6
    s.addi       s37, s25, #15744
    v.ld.w       v0, [s37, #0]
    a.vwrite     a4, s36, v0
    s.movz       s37, #7
    s.addi       s38, s25, #15808
    v.ld.w       v0, [s38, #0]
    a.vwrite     a4, s37, v0
    s.movz       s38, #8
    s.addi       s39, s25, #15872
    v.ld.w       v0, [s39, #0]
    a.vwrite     a4, s38, v0
    s.movz       s39, #9
    s.addi       s40, s25, #15936
    v.ld.w       v0, [s40, #0]
    a.vwrite     a4, s39, v0
    s.movz       s40, #10
    s.addi       s41, s25, #16000
    v.ld.w       v0, [s41, #0]
    a.vwrite     a4, s40, v0
    s.movz       s41, #11
    s.addi       s42, s25, #16064
    v.ld.w       v0, [s42, #0]
    a.vwrite     a4, s41, v0
    s.movz       s42, #12
    s.addi       s44, s25, #16128
    v.ld.w       v0, [s44, #0]
    a.vwrite     a4, s42, v0
    s.movz       s44, #13
    s.addi       s45, s25, #16192
    v.ld.w       v0, [s45, #0]
    a.vwrite     a4, s44, v0
    s.movz       s45, #14
    s.addi       s46, s25, #16256
    v.ld.w       v0, [s46, #0]
    a.vwrite     a4, s45, v0
    s.movz       s46, #15
    s.addi       s47, s25, #16320
    v.ld.w       v0, [s47, #0]
    a.vwrite     a4, s46, v0
    s.addi       s47, s25, #16384
    v.ld.w       v0, [s47, #0]
    a.vwrite     a5, s26, v0
    s.addi       s26, s25, #16448
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s31, v0
    s.addi       s26, s25, #16512
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s32, v0
    s.addi       s26, s25, #16576
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s33, v0
    s.addi       s26, s25, #16640
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s34, v0
    s.addi       s26, s25, #16704
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s35, v0
    s.addi       s26, s25, #16768
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s36, v0
    s.addi       s26, s25, #16832
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s37, v0
    s.addi       s26, s25, #16896
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s38, v0
    s.addi       s26, s25, #16960
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s39, v0
    s.addi       s26, s25, #17024
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s40, v0
    s.addi       s26, s25, #17088
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s41, v0
    s.addi       s26, s25, #17152
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s42, v0
    s.addi       s26, s25, #17216
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s44, v0
    s.addi       s26, s25, #17280
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s45, v0
    s.addi       s26, s25, #17344
    v.ld.w       v0, [s26, #0]
    a.vwrite     a5, s46, v0
    s.movz       s26, #0
    s.addi       s31, s25, #17408
    v.ld.w       v0, [s31, #0]
    a.vwrite     a6, s26, v0
    s.movz       s31, #1
    s.addi       s32, s25, #17472
    v.ld.w       v0, [s32, #0]
    a.vwrite     a6, s31, v0
    s.movz       s32, #2
    s.addi       s33, s25, #17536
    v.ld.w       v0, [s33, #0]
    a.vwrite     a6, s32, v0
    s.movz       s33, #3
    s.addi       s34, s25, #17600
    v.ld.w       v0, [s34, #0]
    a.vwrite     a6, s33, v0
    s.movz       s34, #4
    s.addi       s35, s25, #17664
    v.ld.w       v0, [s35, #0]
    a.vwrite     a6, s34, v0
    s.movz       s35, #5
    s.addi       s36, s25, #17728
    v.ld.w       v0, [s36, #0]
    a.vwrite     a6, s35, v0
    s.movz       s36, #6
    s.addi       s37, s25, #17792
    v.ld.w       v0, [s37, #0]
    a.vwrite     a6, s36, v0
    s.movz       s37, #7
    s.addi       s38, s25, #17856
    v.ld.w       v0, [s38, #0]
    a.vwrite     a6, s37, v0
    s.movz       s38, #8
    s.addi       s39, s25, #17920
    v.ld.w       v0, [s39, #0]
    a.vwrite     a6, s38, v0
    s.movz       s39, #9
    s.addi       s40, s25, #17984
    v.ld.w       v0, [s40, #0]
    a.vwrite     a6, s39, v0
    s.movz       s40, #10
    s.addi       s41, s25, #18048
    v.ld.w       v0, [s41, #0]
    a.vwrite     a6, s40, v0
    s.movz       s41, #11
    s.addi       s42, s25, #18112
    v.ld.w       v0, [s42, #0]
    a.vwrite     a6, s41, v0
    s.movz       s42, #12
    s.addi       s44, s25, #18176
    v.ld.w       v0, [s44, #0]
    a.vwrite     a6, s42, v0
    s.movz       s44, #13
    s.addi       s45, s25, #18240
    v.ld.w       v0, [s45, #0]
    a.vwrite     a6, s44, v0
    s.movz       s45, #14
    s.addi       s46, s25, #18304
    v.ld.w       v0, [s46, #0]
    a.vwrite     a6, s45, v0
    s.movz       s46, #15
    s.addi       s47, s25, #18368
    v.ld.w       v0, [s47, #0]
    a.vwrite     a6, s46, v0
    s.addi       s47, s25, #18432
    v.ld.w       v0, [s47, #0]
    a.vwrite     a7, s26, v0
    s.addi       s26, s25, #18496
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s31, v0
    s.addi       s26, s25, #18560
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s32, v0
    s.addi       s26, s25, #18624
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s33, v0
    s.addi       s26, s25, #18688
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s34, v0
    s.addi       s26, s25, #18752
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s35, v0
    s.addi       s26, s25, #18816
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s36, v0
    s.addi       s26, s25, #18880
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s37, v0
    s.addi       s26, s25, #18944
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s38, v0
    s.addi       s26, s25, #19008
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s39, v0
    s.addi       s26, s25, #19072
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s40, v0
    s.addi       s26, s25, #19136
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s41, v0
    s.addi       s26, s25, #19200
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s42, v0
    s.addi       s26, s25, #19264
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s44, v0
    s.addi       s26, s25, #19328
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s45, v0
    s.addi       s26, s25, #19392
    v.ld.w       v0, [s26, #0]
    a.vwrite     a7, s46, v0
    s.add        s25, s19, s18
    s.mov        s19, s25
    s.movz       s25, #1
    br.nz        s25, for_1
endfor_2:
    s.addi       s1, s11, #16
    s.addi       s2, s11, #32
    s.addi       s3, s11, #48
    s.addi       s4, s11, #64
    s.addi       s5, s11, #80
    s.addi       s7, s11, #96
    s.addi       s8, s11, #112
    s.muli       s9, s11, #2                     // a runtime tile origin, x2
    s.add        s12, s6, s9                     // the tile origin
    s.muli       s9, s10, #512                   // a runtime tile origin, x512
    s.add        s14, s12, s9                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s9, #0
    a.vread      v0, a0, s9
    vf.cvt.f32.bf16 v1, v0
    s.add        s12, s9, s10                    // the tile origin
    v.splat      v0, s12
    v.splat      v2, s13
    v.cmp.lt     p1, v0, v2
    s.add        s13, s9, s11                    // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v3, s13
    v.add        v4, v0, v3
    s.movz       s9, #256
    v.splat      v3, s9
    v.cmp.lt     p2, v4, v3
    p.and        p3, p1, p2
    @p3 v.st.h       [s14, #0], v1
    s.movz       s11, #1
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #512                  // row 1
    s.addi       s13, s12, #1
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s11, #2
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #1024                 // row 2
    s.addi       s13, s12, #2
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s11, #3
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #1536                 // row 3
    s.addi       s13, s12, #3
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s11, #4
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #2048                 // row 4
    s.addi       s13, s12, #4
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s11, #5
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #2560                 // row 5
    s.addi       s13, s12, #5
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s11, #6
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #3072                 // row 6
    s.addi       s13, s12, #6
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s11, #7
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #3584                 // row 7
    s.addi       s13, s12, #7
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s11, #8
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #4096                 // row 8
    s.addi       s13, s12, #8
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s11, #9
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #4608                 // row 9
    s.addi       s13, s12, #9
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s11, #10
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #5120                 // row 10
    s.addi       s13, s12, #10
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s11, #11
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #5632                 // row 11
    s.addi       s13, s12, #11
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s11, #12
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #6144                 // row 12
    s.addi       s13, s12, #12
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s11, #13
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #6656                 // row 13
    s.addi       s13, s12, #13
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s11, #14
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #7168                 // row 14
    s.addi       s13, s12, #14
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s11, #15
    a.vread      v1, a0, s11
    vf.cvt.f32.bf16 v3, v1
    s.addi       s11, s14, #7680                 // row 15
    s.addi       s13, s12, #15
    v.splat      v1, s13
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.muli       s11, s1, #2                     // a runtime tile origin, x2
    s.add        s13, s6, s11                    // the tile origin
    s.muli       s11, s10, #512                  // a runtime tile origin, x512
    s.add        s14, s13, s11                   // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s11, #0
    a.vread      v1, a1, s11
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    v.cmp.lt     p1, v1, v2
    s.add        s13, s11, s1                    // the tile origin
    v.splat      v1, s13
    v.add        v4, v0, v1
    v.splat      v1, s9
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s14, #0], v3
    s.movz       s1, #1
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #512                   // row 1
    s.addi       s11, s12, #1
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #2
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #1024                  // row 2
    s.addi       s11, s12, #2
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #3
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #1536                  // row 3
    s.addi       s11, s12, #3
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #4
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #2048                  // row 4
    s.addi       s11, s12, #4
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #5
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #2560                  // row 5
    s.addi       s11, s12, #5
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #6
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #3072                  // row 6
    s.addi       s11, s12, #6
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #7
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #3584                  // row 7
    s.addi       s11, s12, #7
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #8
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #4096                  // row 8
    s.addi       s11, s12, #8
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #9
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #4608                  // row 9
    s.addi       s11, s12, #9
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #10
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #5120                  // row 10
    s.addi       s11, s12, #10
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #11
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #5632                  // row 11
    s.addi       s11, s12, #11
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #12
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #6144                  // row 12
    s.addi       s11, s12, #12
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #13
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #6656                  // row 13
    s.addi       s11, s12, #13
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #14
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #7168                  // row 14
    s.addi       s11, s12, #14
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #15
    a.vread      v1, a1, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s14, #7680                  // row 15
    s.addi       s11, s12, #15
    v.splat      v1, s11
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.muli       s1, s2, #2                      // a runtime tile origin, x2
    s.add        s11, s6, s1                     // the tile origin
    s.muli       s1, s10, #512                   // a runtime tile origin, x512
    s.add        s13, s11, s1                    // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    v.cmp.lt     p1, v1, v2
    s.add        s11, s1, s2                     // the tile origin
    v.splat      v1, s11
    v.add        v4, v0, v1
    v.splat      v1, s9
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s13, #0], v3
    s.movz       s1, #1
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #512                   // row 1
    s.addi       s2, s12, #1
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #2
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #1024                  // row 2
    s.addi       s2, s12, #2
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #3
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #1536                  // row 3
    s.addi       s2, s12, #3
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #4
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #2048                  // row 4
    s.addi       s2, s12, #4
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #5
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #2560                  // row 5
    s.addi       s2, s12, #5
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #6
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #3072                  // row 6
    s.addi       s2, s12, #6
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #7
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #3584                  // row 7
    s.addi       s2, s12, #7
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #8
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #4096                  // row 8
    s.addi       s2, s12, #8
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #9
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #4608                  // row 9
    s.addi       s2, s12, #9
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #10
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #5120                  // row 10
    s.addi       s2, s12, #10
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #11
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #5632                  // row 11
    s.addi       s2, s12, #11
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #12
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #6144                  // row 12
    s.addi       s2, s12, #12
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #13
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #6656                  // row 13
    s.addi       s2, s12, #13
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #14
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #7168                  // row 14
    s.addi       s2, s12, #14
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #15
    a.vread      v1, a2, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s13, #7680                  // row 15
    s.addi       s2, s12, #15
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.muli       s1, s3, #2                      // a runtime tile origin, x2
    s.add        s2, s6, s1                      // the tile origin
    s.muli       s1, s10, #512                   // a runtime tile origin, x512
    s.add        s11, s2, s1                     // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    v.cmp.lt     p1, v1, v2
    s.add        s2, s1, s3                      // the tile origin
    v.splat      v1, s2
    v.add        v4, v0, v1
    v.splat      v1, s9
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s11, #0], v3
    s.movz       s1, #1
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #512                   // row 1
    s.addi       s2, s12, #1
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #2
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #1024                  // row 2
    s.addi       s2, s12, #2
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #3
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #1536                  // row 3
    s.addi       s2, s12, #3
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #4
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #2048                  // row 4
    s.addi       s2, s12, #4
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #5
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #2560                  // row 5
    s.addi       s2, s12, #5
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #6
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #3072                  // row 6
    s.addi       s2, s12, #6
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #7
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #3584                  // row 7
    s.addi       s2, s12, #7
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #8
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #4096                  // row 8
    s.addi       s2, s12, #8
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #9
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #4608                  // row 9
    s.addi       s2, s12, #9
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #10
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #5120                  // row 10
    s.addi       s2, s12, #10
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #11
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #5632                  // row 11
    s.addi       s2, s12, #11
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #12
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #6144                  // row 12
    s.addi       s2, s12, #12
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #13
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #6656                  // row 13
    s.addi       s2, s12, #13
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #14
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #7168                  // row 14
    s.addi       s2, s12, #14
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #15
    a.vread      v1, a3, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s11, #7680                  // row 15
    s.addi       s2, s12, #15
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.muli       s1, s4, #2                      // a runtime tile origin, x2
    s.add        s2, s6, s1                      // the tile origin
    s.muli       s1, s10, #512                   // a runtime tile origin, x512
    s.add        s3, s2, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    v.cmp.lt     p1, v1, v2
    s.add        s2, s1, s4                      // the tile origin
    v.splat      v1, s2
    v.add        v4, v0, v1
    v.splat      v1, s9
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s3, #0], v3
    s.movz       s1, #1
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #512                    // row 1
    s.addi       s2, s12, #1
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #2
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #1024                   // row 2
    s.addi       s2, s12, #2
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #3
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #1536                   // row 3
    s.addi       s2, s12, #3
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #4
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #2048                   // row 4
    s.addi       s2, s12, #4
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #5
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #2560                   // row 5
    s.addi       s2, s12, #5
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #6
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #3072                   // row 6
    s.addi       s2, s12, #6
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #7
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #3584                   // row 7
    s.addi       s2, s12, #7
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #8
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #4096                   // row 8
    s.addi       s2, s12, #8
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #9
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #4608                   // row 9
    s.addi       s2, s12, #9
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #10
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #5120                   // row 10
    s.addi       s2, s12, #10
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #11
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #5632                   // row 11
    s.addi       s2, s12, #11
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #12
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #6144                   // row 12
    s.addi       s2, s12, #12
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #13
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #6656                   // row 13
    s.addi       s2, s12, #13
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #14
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #7168                   // row 14
    s.addi       s2, s12, #14
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #15
    a.vread      v1, a4, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #7680                   // row 15
    s.addi       s2, s12, #15
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.muli       s1, s5, #2                      // a runtime tile origin, x2
    s.add        s2, s6, s1                      // the tile origin
    s.muli       s1, s10, #512                   // a runtime tile origin, x512
    s.add        s3, s2, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    v.cmp.lt     p1, v1, v2
    s.add        s2, s1, s5                      // the tile origin
    v.splat      v1, s2
    v.add        v4, v0, v1
    v.splat      v1, s9
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s3, #0], v3
    s.movz       s1, #1
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #512                    // row 1
    s.addi       s2, s12, #1
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #2
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #1024                   // row 2
    s.addi       s2, s12, #2
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #3
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #1536                   // row 3
    s.addi       s2, s12, #3
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #4
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #2048                   // row 4
    s.addi       s2, s12, #4
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #5
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #2560                   // row 5
    s.addi       s2, s12, #5
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #6
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #3072                   // row 6
    s.addi       s2, s12, #6
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #7
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #3584                   // row 7
    s.addi       s2, s12, #7
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #8
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #4096                   // row 8
    s.addi       s2, s12, #8
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #9
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #4608                   // row 9
    s.addi       s2, s12, #9
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #10
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #5120                   // row 10
    s.addi       s2, s12, #10
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #11
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #5632                   // row 11
    s.addi       s2, s12, #11
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #12
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #6144                   // row 12
    s.addi       s2, s12, #12
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #13
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #6656                   // row 13
    s.addi       s2, s12, #13
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #14
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #7168                   // row 14
    s.addi       s2, s12, #14
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #15
    a.vread      v1, a5, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #7680                   // row 15
    s.addi       s2, s12, #15
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.muli       s1, s7, #2                      // a runtime tile origin, x2
    s.add        s2, s6, s1                      // the tile origin
    s.muli       s1, s10, #512                   // a runtime tile origin, x512
    s.add        s3, s2, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    v.cmp.lt     p1, v1, v2
    s.add        s2, s1, s7                      // the tile origin
    v.splat      v1, s2
    v.add        v4, v0, v1
    v.splat      v1, s9
    v.cmp.lt     p2, v4, v1
    p.and        p3, p1, p2
    @p3 v.st.h       [s3, #0], v3
    s.movz       s1, #1
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #512                    // row 1
    s.addi       s2, s12, #1
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #2
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #1024                   // row 2
    s.addi       s2, s12, #2
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #3
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #1536                   // row 3
    s.addi       s2, s12, #3
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #4
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #2048                   // row 4
    s.addi       s2, s12, #4
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #5
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #2560                   // row 5
    s.addi       s2, s12, #5
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #6
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #3072                   // row 6
    s.addi       s2, s12, #6
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #7
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #3584                   // row 7
    s.addi       s2, s12, #7
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #8
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #4096                   // row 8
    s.addi       s2, s12, #8
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #9
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #4608                   // row 9
    s.addi       s2, s12, #9
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #10
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #5120                   // row 10
    s.addi       s2, s12, #10
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #11
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #5632                   // row 11
    s.addi       s2, s12, #11
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #12
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #6144                   // row 12
    s.addi       s2, s12, #12
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #13
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #6656                   // row 13
    s.addi       s2, s12, #13
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #14
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #7168                   // row 14
    s.addi       s2, s12, #14
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.movz       s1, #15
    a.vread      v1, a6, s1
    vf.cvt.f32.bf16 v3, v1
    s.addi       s1, s3, #7680                   // row 15
    s.addi       s2, s12, #15
    v.splat      v1, s2
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v3
    s.muli       s1, s8, #2                      // a runtime tile origin, x2
    s.add        s2, s6, s1                      // the tile origin
    s.muli       s1, s10, #512                   // a runtime tile origin, x512
    s.add        s3, s2, s1                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s1, #0
    a.vread      v1, a7, s1
    vf.cvt.f32.bf16 v3, v1
    v.splat      v1, s12
    v.cmp.lt     p1, v1, v2
    s.add        s2, s1, s8                      // the tile origin
    v.splat      v1, s2
    v.add        v4, v0, v1
    v.splat      v0, s9
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    @p3 v.st.h       [s3, #0], v3
    s.movz       s1, #1
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #512                    // row 1
    s.addi       s2, s12, #1
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #2
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #1024                   // row 2
    s.addi       s2, s12, #2
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #3
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #1536                   // row 3
    s.addi       s2, s12, #3
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #4
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #2048                   // row 4
    s.addi       s2, s12, #4
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #5
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #2560                   // row 5
    s.addi       s2, s12, #5
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #6
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #3072                   // row 6
    s.addi       s2, s12, #6
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #7
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #3584                   // row 7
    s.addi       s2, s12, #7
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #8
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #4096                   // row 8
    s.addi       s2, s12, #8
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #9
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #4608                   // row 9
    s.addi       s2, s12, #9
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #10
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #5120                   // row 10
    s.addi       s2, s12, #10
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #11
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #5632                   // row 11
    s.addi       s2, s12, #11
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #12
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #6144                   // row 12
    s.addi       s2, s12, #12
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #13
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #6656                   // row 13
    s.addi       s2, s12, #13
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #14
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #7168                   // row 14
    s.addi       s2, s12, #14
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    s.movz       s1, #15
    a.vread      v0, a7, s1
    vf.cvt.f32.bf16 v1, v0
    s.addi       s1, s3, #7680                   // row 15
    s.addi       s2, s12, #15
    v.splat      v0, s2
    v.cmp.lt     p1, v0, v2
    p.and        p3, p1, p2
    @p3 v.st.h       [s1, #0], v1
    exit
    exit
