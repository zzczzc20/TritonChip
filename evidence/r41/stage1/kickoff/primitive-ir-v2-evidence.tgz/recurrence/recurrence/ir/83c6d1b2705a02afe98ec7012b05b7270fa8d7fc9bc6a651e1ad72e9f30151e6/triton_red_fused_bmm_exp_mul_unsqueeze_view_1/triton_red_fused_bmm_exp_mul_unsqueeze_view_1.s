    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    v.movi       v0, #0
    s.ld.d       s2, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.movi       v1, #0
    s.movz       s3, #0
    s.movz       s5, #128
    s.movz       s6, #16
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s7, s3, #0
    s.ld.w       s3, [s2, #0]                    // one element, not a vector
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.splat      v3, s3
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s8, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    v.splat      v0, s7
    v.movi       v4, #128
    v.splat      v5, s4
    v.add        v6, v0, v2
    s.shli       s1, s7, #2                      // element offset -> bytes (x4)
    v.movi       v0, #0
    v.mul        v7, v6, v4
    v.cmp.lt     p1, v6, v4
    s.add        s9, s2, s1                      // &in_ptr0[...]
    v.add        v4, v5, v7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.w       v5, [s9, #0]
    s.add        s1, s7, s6
    s.movz       s9, #1
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s3, v4]               // index is in elements (ISA sec 9.1)
    vf.mul       v4, v6, v3
    vf.mul       v6, v5, v4
    vf.add       v4, v1, v6
    @p1 v.sel        v5, v4, v1
    v.mov        v0, v5
    v.mov        v1, v0
    s.mov        s7, s1
    br.nz        s9, for_1
endfor_2:
    vf.reduce.add.b v0, v1
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s8, s2                      // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
