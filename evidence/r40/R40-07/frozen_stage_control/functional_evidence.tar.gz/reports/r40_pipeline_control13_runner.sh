#!/bin/bash
source ~/tc_env/env.sh
cd /tmp/r40_pipeline_control13 || exit 2
export PYTHONPATH="$PWD/python:$PWD/compiler/python:$PWD/tools/asm"
"$HOME/tc_env/torchenv/bin/python" tools/r40/pipeline_stage_options_tests.py > /tmp/r40_pipeline_control13_options.log 2>&1
rc=$?
printf '%s
' "$rc" > /tmp/r40_pipeline_control13_options.exit
if [ "$rc" != 0 ]; then exit "$rc"; fi
TNCA_PIPELINE=1 "$HOME/tc_env/torchenv/bin/python" tools/r39/rctx_roles_tests.py --only gemm_one_step gemm_odd_steps gemm_grid_3x2 gemm_carried_pointers --json /tmp/r40_pipeline_control13_native.json > /tmp/r40_pipeline_control13_native.log 2>&1
rc=$?
printf '%s
' "$rc" > /tmp/r40_pipeline_control13_native.exit
exit "$rc"
