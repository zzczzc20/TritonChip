    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #4
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v0, v4
    @p1 v.sel        v7, v5, v4
    v.movi       v5, #0
    v.sub        v8, v1, v4
    v.lshr       v9, v7, v3
    v.cmp.lt     p2, v4, v0
    v.cmp.lt     p3, v4, v1
    v.sub        v3, v2, v9
    @p2 v.sel        v7, v6, v4
    v.movi       v6, #15
    @p1 v.sel        v10, v3, v9
    v.movi       v3, #15
    v.and        v9, v7, v6
    v.sub        v6, v5, v10
    v.cmp.lt     p1, v10, v5
    v.sub        v7, v0, v9
    @p1 v.sel        v11, v6, v10
    s.rdspecial  s2, arg_base
    @p3 v.sel        v6, v8, v4
    v.and        v8, v11, v3
    v.movi       v3, #16
    @p2 v.sel        v10, v7, v9
    v.sub        v7, v5, v8
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v9, #1024
    @p1 v.sel        v11, v7, v8
    v.movi       v7, #256
    v.cmp.lt     p1, v4, v9
    v.sub        v4, v0, v3
    v.sub        v8, v2, v3
    v.cmp.lt     p2, v3, v0
    v.sub        v0, v5, v3
    v.cmp.lt     p4, v3, v2
    v.sub        v2, v1, v7
    s.ld.d       s4, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    @p2 v.sel        v9, v4, v3
    v.movi       v4, #8
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    v.cmp.lt     p2, v3, v5
    v.lshr       v5, v6, v4
    v.movi       v4, #128
    v.movi       v6, #192
    @p4 v.sel        v9, v8, v3
    v.sub        v8, v1, v5
    v.add        v9, v10, v4
    v.mul        v4, v11, v6
    @p3 v.sel        v6, v8, v5
    s.add        s1, s4, s2                      // &out_ptr0[...]
    v.cmp.lt     p3, v7, v1
    v.mul        v1, v6, v3
    @p2 v.sel        v5, v0, v3
    @p3 v.sel        v0, v2, v7
    v.add        v0, v9, v1
    v.add        v1, v0, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v0, [s3, v1]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v1, v0
    @p1 v.st.w       [s1, #0], v1
__rctx_next:
    exit
