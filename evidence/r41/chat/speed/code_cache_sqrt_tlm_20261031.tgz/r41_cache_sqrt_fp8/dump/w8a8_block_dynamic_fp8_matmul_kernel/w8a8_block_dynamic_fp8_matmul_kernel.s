    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.addi       s4, s2, #0
    s.ld.d       s5, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.ld.d       s6, [s1, #16]                   // C: device_ptr64 at arg_base+16
    s.ld.d       s7, [s1, #24]                   // Bs: device_ptr64 at arg_base+24
    s.ld.sw      s8, [s1, #32]                   // M: i32 at arg_base+32
    s.ld.sw      s9, [s1, #40]                   // N: i32 at arg_base+40
    s.ld.sw      s10, [s1, #48]                  // K: i32 at arg_base+48
    s.ld.sw      s11, [s1, #56]                  // stride_am: i32 at arg_base+56
    s.ld.sw      s12, [s1, #64]                  // stride_bn: i32 at arg_base+64
    s.ld.sw      s13, [s1, #72]                  // stride_cm: i32 at arg_base+72
    s.ld.sw      s14, [s1, #80]                  // stride_bs_n: i32 at arg_base+80
rows_1:
    s.movz       s1, #63
    s.rdspecial  s15, pid.x
    s.add        s16, s8, s1
    s.rdspecial  s1, pid.y
    s.cmp.lt     s17, s16, s2
    s.movz       s18, #64
    s.sub        s19, s2, s17
    s.cmp.lt     s17, s18, s2
    s.xor        s20, s16, s19
    s.sub        s16, s2, s17
    s.sub        s17, s20, s19
    // rows [r0, r0 + 16) of a 64-row program (row_split)
    v.iota       v0                              // arange(0, VLEN)
    s.lshri      s20, s17, #6
    v.splat      v1, s4
    s.muli       s21, s20, #64
    s.xor        s22, s18, s16
    v.add        v2, v0, v1
    s.movz       s23, #127
    s.movz       s24, #128
    s.add        s25, s9, s23
    s.cmp.lt     s26, s24, s2
    s.cmp.lt     s27, s25, s2
    s.sub        s28, s2, s26
    s.sub        s26, s2, s27
    s.xor        s27, s19, s16
    s.xor        s19, s25, s26
    s.xor        s25, s20, s27
    s.sub        s20, s19, s26
    s.sub        s19, s22, s16
    s.lshri      s16, s20, #7
    s.xor        s19, s24, s28
    s.sub        s22, s17, s21
    s.xor        s17, s26, s28
    s.muli       s21, s16, #128
    s.sub        s22, s25, s27
    s.xor        s25, s16, s17
    s.movz       s16, #8
    s.sub        s26, s25, s17
    s.sub        s17, s19, s28
    s.mul        s17, s15, s26
    s.mul        s15, s26, s16
    s.sub        s19, s20, s21
    s.movz       s19, #0
    s.movz       s20, #1
    s.add        s21, s17, s1
    s.cmp.lt     s1, s15, s2
    s.cmp.lt     s17, s21, s2
    s.sub        s25, s2, s1
    s.sub        s1, s2, s17
    s.xor        s17, s15, s25
    s.xor        s26, s21, s1
    s.sub        s27, s17, s25
    s.sub        s17, s26, s1
    s.addi       s26, s19, #0
    s.cmp.eq     s28, s27, s20
    s.addi       s29, s19, #0
    s.mov        s26, s17
    br.nz        s28, sdiv_done_3
    s.movz       s28, #0
    s.mov        s26, s28
    s.movz       s28, #31
    s.addi       s30, s28, #0
sdiv_4:
    s.lshr       s28, s17, s30
    s.andi       s31, s28, #1
    s.shli       s28, s29, #1
    s.or         s32, s28, s31
    s.cmp.geu    s28, s32, s27
    s.sub        s31, s19, s28
    s.and        s28, s27, s31
    s.sub        s33, s32, s28
    s.mov        s29, s33
    s.shl        s28, s20, s30
    s.and        s32, s28, s31
    s.or         s28, s26, s32
    s.mov        s26, s28
    s.subi       s28, s30, #1
    s.mov        s30, s28
    s.cmp.ge     s28, s30, s19
    br.nz        s28, sdiv_4
sdiv_done_3:
    s.xor        s17, s1, s25
    s.cmp.lt     s1, s15, s19
    s.xor        s25, s26, s17
    s.sub        s26, s19, s1
    s.sub        s1, s25, s17
    s.cmp.lt     s17, s21, s19
    s.mul        s25, s1, s16
    s.sub        s1, s19, s17
    s.xor        s17, s15, s26
    s.xor        s15, s21, s1
    s.sub        s21, s17, s26
    s.sub        s17, s22, s25
    s.sub        s22, s15, s1
    s.addi       s15, s19, #0
    s.cmp.eq     s26, s21, s20
    s.min.s      s20, s17, s16
    s.addi       s16, s19, #0
    s.mov        s15, s22
    br.nz        s26, sdiv_done_5
    s.movz       s17, #0
    s.mov        s15, s17
    s.movz       s17, #31
    s.addi       s19, s17, #0
sdiv_6:
    s.lshr       s17, s22, s19
    s.andi       s26, s17, #1
    s.shli       s17, s16, #1
    s.or         s27, s17, s26
    s.movz       s17, #0
    s.cmp.geu    s26, s27, s21
    s.sub        s28, s17, s26
    s.and        s26, s21, s28
    s.sub        s29, s27, s26
    s.mov        s16, s29
    s.movz       s26, #1
    s.shl        s27, s26, s19
    s.and        s26, s27, s28
    s.or         s27, s15, s26
    s.mov        s15, s27
    s.subi       s26, s19, #1
    s.mov        s19, s26
    s.cmp.ge     s26, s19, s17
    br.nz        s26, sdiv_6
sdiv_done_5:
    s.xor        s15, s16, s1
    s.movz       s16, #0
    s.sub        s17, s15, s1
    s.cmp.lt     s1, s20, s16
    s.cmp.lt     s15, s17, s16
    s.sub        s19, s16, s1
    s.sub        s1, s16, s15
    s.xor        s15, s20, s19
    s.xor        s20, s17, s1
    s.sub        s17, s15, s19
    s.movz       s15, #1
    s.sub        s21, s20, s1
    s.addi       s22, s16, #0
    s.cmp.eq     s26, s17, s15
    s.addi       s27, s16, #0
    s.mov        s22, s21
    br.nz        s26, sdiv_done_7
    s.movz       s28, #0
    s.mov        s22, s28
    s.movz       s28, #31
    s.addi       s29, s28, #0
sdiv_8:
    s.lshr       s28, s21, s29
    s.shli       s30, s27, #1
    s.andi       s31, s28, #1
    s.shl        s28, s15, s29
    s.or         s32, s30, s31
    s.subi       s30, s29, #1
    s.cmp.geu    s31, s32, s17
    s.sub        s33, s16, s31
    s.and        s31, s28, s33
    s.and        s28, s17, s33
    s.or         s33, s22, s31
    s.sub        s31, s32, s28
    s.mov        s27, s31
    s.mov        s22, s33
    s.mov        s29, s30
    s.cmp.ge     s28, s29, s16
    br.nz        s28, sdiv_8
sdiv_done_7:
    s.xor        s15, s27, s1
    s.sub        s21, s20, s1
    s.sub        s20, s15, s1
    s.add        s15, s25, s20
    s.addi       s20, s16, #0
    s.addi       s22, s16, #0
    s.mov        s20, s21
    br.nz        s26, sdiv_done_9
    s.movz       s16, #0
    s.mov        s20, s16
    s.movz       s16, #31
    s.addi       s25, s16, #0
sdiv_10:
    s.lshr       s16, s21, s25
    s.andi       s26, s16, #1
    s.shli       s16, s22, #1
    s.or         s27, s16, s26
    s.movz       s16, #0
    s.cmp.geu    s26, s27, s17
    s.sub        s28, s16, s26
    s.and        s26, s17, s28
    s.sub        s29, s27, s26
    s.mov        s22, s29
    s.movz       s26, #1
    s.shl        s27, s26, s25
    s.and        s26, s27, s28
    s.or         s27, s20, s26
    s.mov        s20, s27
    s.subi       s26, s25, #1
    s.mov        s25, s26
    s.cmp.ge     s26, s25, s16
    br.nz        s26, sdiv_10
sdiv_done_9:
    s.mul        s16, s15, s18
    v.splat      v0, s8
    v.movi       v1, #0
    s.xor        s15, s1, s19
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s16
    v.movi       v5, #16
    s.xor        s1, s20, s15
    v.add        v6, v4, v2
    v.movi       v2, #32
    s.sub        s17, s1, s15
    v.cmp.lt     p1, v6, v1
    v.cmp.lt     p2, v0, v1
    v.add        v4, v3, v5
    v.movi       v4, #48
    v.add        v5, v3, v2
    v.sub        v2, v1, v6
    v.add        v5, v3, v4
    v.sub        v3, v1, v0
    s.add        s1, s4, s16
    v.movi       v4, #1
    @p1 v.sel        v5, v2, v6
    @p2 v.sel        v2, v3, v0
    v.movi       v0, #0
    v.movi       v3, #0
    s.movz       s15, #31
idiv_11:
    v.splat      v6, s15
    v.shl        v7, v3, v4
    v.cmp.lt     p2, v3, v1
    v.lshr       v8, v5, v6
    v.shl        v9, v4, v6
    s.subi       s16, s15, #1
    v.and        v6, v8, v4
    v.or         v8, v7, v6
    v.cmp.geu    p3, v8, v2
    p.or         p4, p2, p3
    v.sub        v6, v8, v2
    @p4 v.sel        v7, v9, v1
    @p4 v.sel        v9, v6, v8
    v.or         v6, v0, v7
    v.mov        v3, v9
    v.mov        v0, v6
    s.mov        s15, s16
    s.movz       s16, #0
    s.cmp.ge     s19, s15, s16
    br.nz        s19, idiv_11
    s.mul        s15, s17, s24
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v2, #16
    v.movi       v4, #32
    v.movi       v5, #48
    v.iota       v6                              // arange(0, VLEN)
    v.movi       v7, #64
    v.movi       v8, #80
    v.movi       v9, #96
    v.sub        v10, v1, v3
    v.add        v1, v0, v2
    v.add        v2, v0, v4
    v.add        v4, v0, v5
    v.add        v5, v6, v7
    v.add        v7, v6, v8
    v.add        v8, v6, v9
    @p1 v.sel        v6, v10, v3
    v.splat      v3, s15
    v.iota       v9                              // arange(0, VLEN)
    v.movi       v10, #112
    v.add        v11, v3, v0
    v.splat      v0, s9
    v.movi       v12, #0
    v.add        v13, v9, v10
    v.add        v9, v3, v1
    v.sub        v1, v12, v11
    v.sub        v10, v12, v0
    v.cmp.lt     p1, v11, v12
    v.cmp.lt     p2, v0, v12
    v.add        v14, v3, v2
    v.add        v2, v3, v4
    v.add        v4, v3, v5
    v.add        v5, v3, v7
    v.add        v7, v3, v8
    v.add        v8, v3, v13
    v.movi       v3, #1
    @p1 v.sel        v13, v1, v11
    @p2 v.sel        v1, v10, v0
    v.movi       v10, #0
    v.movi       v11, #0
    s.movz       s16, #31
idiv_12:
    v.splat      v15, s16
    v.shl        v16, v11, v3
    v.cmp.lt     p2, v11, v12
    v.lshr       v17, v13, v15
    v.shl        v18, v3, v15
    s.subi       s17, s16, #1
    v.and        v15, v17, v3
    v.or         v17, v16, v15
    v.cmp.geu    p3, v17, v1
    p.or         p4, p2, p3
    v.sub        v15, v17, v1
    @p4 v.sel        v16, v18, v12
    @p4 v.sel        v18, v15, v17
    v.or         v15, v10, v16
    v.mov        v11, v18
    v.mov        v10, v15
    s.mov        s16, s17
    s.movz       s17, #0
    s.cmp.ge     s19, s16, s17
    br.nz        s19, idiv_12
    v.movi       v1, #0
    v.sub        v3, v12, v11
    v.movi       v10, #1
    v.sub        v12, v1, v9
    v.sub        v13, v1, v0
    v.cmp.lt     p2, v9, v1
    @p1 v.sel        v15, v3, v11
    v.cmp.lt     p1, v0, v1
    @p2 v.sel        v3, v12, v9
    @p1 v.sel        v9, v13, v0
    v.movi       v11, #0
    v.movi       v12, #0
    s.movz       s16, #31
idiv_13:
    v.splat      v13, s16
    v.shl        v16, v12, v10
    v.cmp.lt     p1, v12, v1
    v.lshr       v17, v3, v13
    v.shl        v18, v10, v13
    s.subi       s19, s16, #1
    v.and        v13, v17, v10
    v.or         v17, v16, v13
    v.cmp.geu    p3, v17, v9
    p.or         p4, p1, p3
    v.sub        v13, v17, v9
    @p4 v.sel        v16, v18, v1
    @p4 v.sel        v18, v13, v17
    v.or         v13, v11, v16
    v.mov        v12, v18
    v.mov        v11, v13
    s.mov        s16, s19
    s.cmp.ge     s19, s16, s17
    br.nz        s19, idiv_13
    v.movi       v3, #0
    v.sub        v9, v1, v12
    v.movi       v1, #1
    v.sub        v10, v3, v14
    v.sub        v11, v3, v0
    v.cmp.lt     p1, v14, v3
    @p2 v.sel        v13, v9, v12
    v.cmp.lt     p2, v0, v3
    @p1 v.sel        v9, v10, v14
    @p2 v.sel        v10, v11, v0
    v.movi       v11, #0
    v.movi       v12, #0
    s.movz       s16, #31
idiv_14:
    v.splat      v14, s16
    v.shl        v16, v12, v1
    v.cmp.lt     p2, v12, v3
    v.lshr       v17, v9, v14
    v.shl        v18, v1, v14
    s.subi       s17, s16, #1
    v.and        v14, v17, v1
    v.or         v17, v16, v14
    v.cmp.geu    p3, v17, v10
    p.or         p4, p2, p3
    v.sub        v14, v17, v10
    @p4 v.sel        v16, v18, v3
    @p4 v.sel        v18, v14, v17
    v.or         v14, v11, v16
    v.mov        v12, v18
    v.mov        v11, v14
    s.mov        s16, s17
    s.movz       s17, #0
    s.cmp.ge     s19, s16, s17
    br.nz        s19, idiv_14
    v.movi       v1, #0
    v.sub        v9, v3, v12
    v.movi       v3, #1
    v.sub        v10, v1, v2
    v.sub        v11, v1, v0
    v.cmp.lt     p2, v2, v1
    @p1 v.sel        v14, v9, v12
    v.cmp.lt     p1, v0, v1
    @p2 v.sel        v9, v10, v2
    @p1 v.sel        v2, v11, v0
    v.movi       v10, #0
    v.movi       v11, #0
    s.movz       s16, #31
idiv_15:
    v.splat      v12, s16
    v.shl        v16, v11, v3
    v.cmp.lt     p1, v11, v1
    v.lshr       v17, v9, v12
    v.shl        v18, v3, v12
    s.subi       s19, s16, #1
    v.and        v12, v17, v3
    v.or         v17, v16, v12
    v.cmp.geu    p3, v17, v2
    p.or         p4, p1, p3
    v.sub        v12, v17, v2
    @p4 v.sel        v16, v18, v1
    @p4 v.sel        v18, v12, v17
    v.or         v12, v10, v16
    v.mov        v11, v18
    v.mov        v10, v12
    s.mov        s16, s19
    s.cmp.ge     s19, s16, s17
    br.nz        s19, idiv_15
    v.movi       v2, #0
    v.sub        v3, v1, v11
    v.movi       v1, #1
    v.sub        v9, v2, v4
    v.sub        v10, v2, v0
    v.cmp.lt     p1, v4, v2
    @p2 v.sel        v12, v3, v11
    v.cmp.lt     p2, v0, v2
    @p1 v.sel        v3, v9, v4
    @p2 v.sel        v4, v10, v0
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s16, #31
idiv_16:
    v.splat      v11, s16
    v.shl        v16, v10, v1
    v.cmp.lt     p2, v10, v2
    v.lshr       v17, v3, v11
    v.shl        v18, v1, v11
    s.subi       s17, s16, #1
    v.and        v11, v17, v1
    v.or         v17, v16, v11
    v.cmp.geu    p3, v17, v4
    p.or         p4, p2, p3
    v.sub        v11, v17, v4
    @p4 v.sel        v16, v18, v2
    @p4 v.sel        v18, v11, v17
    v.or         v11, v9, v16
    v.mov        v10, v18
    v.mov        v9, v11
    s.mov        s16, s17
    s.movz       s17, #0
    s.cmp.ge     s19, s16, s17
    br.nz        s19, idiv_16
    v.movi       v1, #0
    v.sub        v3, v2, v10
    v.movi       v2, #1
    v.sub        v4, v1, v5
    v.sub        v9, v1, v0
    v.cmp.lt     p2, v5, v1
    @p1 v.sel        v11, v3, v10
    v.cmp.lt     p1, v0, v1
    @p2 v.sel        v3, v4, v5
    @p1 v.sel        v4, v9, v0
    v.movi       v5, #0
    v.movi       v9, #0
    s.movz       s16, #31
idiv_17:
    v.splat      v10, s16
    v.shl        v16, v9, v2
    v.cmp.lt     p1, v9, v1
    v.lshr       v17, v3, v10
    v.shl        v18, v2, v10
    s.subi       s19, s16, #1
    v.and        v10, v17, v2
    v.or         v17, v16, v10
    v.cmp.geu    p3, v17, v4
    p.or         p4, p1, p3
    v.sub        v10, v17, v4
    @p4 v.sel        v16, v18, v1
    @p4 v.sel        v18, v10, v17
    v.or         v10, v5, v16
    v.mov        v9, v18
    v.mov        v5, v10
    s.mov        s16, s19
    s.cmp.ge     s19, s16, s17
    br.nz        s19, idiv_17
    v.movi       v2, #0
    v.sub        v3, v1, v9
    v.movi       v1, #1
    v.sub        v4, v2, v7
    v.sub        v5, v2, v0
    v.cmp.lt     p1, v7, v2
    @p2 v.sel        v10, v3, v9
    v.cmp.lt     p2, v0, v2
    @p1 v.sel        v3, v4, v7
    @p2 v.sel        v4, v5, v0
    v.movi       v5, #0
    v.movi       v7, #0
    s.movz       s16, #31
idiv_18:
    v.splat      v9, s16
    v.shl        v16, v7, v1
    v.cmp.lt     p2, v7, v2
    v.lshr       v17, v3, v9
    v.shl        v18, v1, v9
    s.subi       s17, s16, #1
    v.and        v9, v17, v1
    v.or         v17, v16, v9
    v.cmp.geu    p3, v17, v4
    p.or         p4, p2, p3
    v.sub        v9, v17, v4
    @p4 v.sel        v16, v18, v2
    @p4 v.sel        v18, v9, v17
    v.or         v9, v5, v16
    v.mov        v7, v18
    v.mov        v5, v9
    s.mov        s16, s17
    s.movz       s17, #0
    s.cmp.ge     s19, s16, s17
    br.nz        s19, idiv_18
    v.movi       v1, #0
    v.sub        v3, v2, v7
    v.movi       v2, #1
    v.sub        v4, v1, v8
    v.cmp.lt     p2, v8, v1
    @p1 v.sel        v5, v3, v7
    v.sub        v3, v1, v0
    v.cmp.lt     p1, v0, v1
    @p2 v.sel        v7, v4, v8
    @p1 v.sel        v4, v3, v0
    v.movi       v0, #0
    v.movi       v3, #0
    s.movz       s16, #31
idiv_19:
    v.splat      v8, s16
    v.shl        v9, v3, v2
    v.cmp.lt     p1, v3, v1
    v.lshr       v16, v7, v8
    v.shl        v17, v2, v8
    s.subi       s19, s16, #1
    v.and        v8, v16, v2
    v.or         v16, v9, v8
    v.cmp.geu    p3, v16, v4
    p.or         p4, p1, p3
    v.sub        v8, v16, v4
    @p4 v.sel        v9, v17, v1
    @p4 v.sel        v17, v8, v16
    v.or         v8, v0, v9
    v.mov        v3, v17
    v.mov        v0, v8
    s.mov        s16, s19
    s.cmp.ge     s19, s16, s17
    br.nz        s19, idiv_19
    v.sub        v0, v1, v3
    @p2 v.sel        v1, v0, v3
    s.movz       s16, #16
    s.movz       s17, #32
    s.movz       s19, #48
    s.movz       s20, #80
    s.movz       s21, #96
    s.movz       s22, #112
    v.movi       v0, #128
    v.movi       v2, #0
    v.movi       v3, #1
    v.cmp.lt     p1, v15, v2
    v.cmp.lt     p2, v0, v2
    v.sub        v3, v2, v15
    @p1 v.sel        v4, v3, v15
    v.sub        v3, v2, v0
    @p2 v.sel        v7, v3, v0
    v.movi       v0, #7
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.movi       v0, #128
    v.movi       v3, #0
    v.movi       v4, #1
    v.cmp.lt     p1, v13, v3
    v.cmp.lt     p2, v0, v3
    v.sub        v4, v3, v13
    @p1 v.sel        v7, v4, v13
    v.sub        v4, v3, v0
    @p2 v.sel        v8, v4, v0
    v.movi       v0, #7
    v.lshr       v4, v7, v0
    v.sub        v0, v3, v4
    @p1 v.sel        v3, v0, v4
    v.movi       v0, #128
    v.movi       v4, #0
    v.movi       v7, #1
    v.cmp.lt     p1, v14, v4
    v.cmp.lt     p2, v0, v4
    v.sub        v7, v4, v14
    @p1 v.sel        v8, v7, v14
    v.sub        v7, v4, v0
    @p2 v.sel        v9, v7, v0
    v.movi       v0, #7
    v.lshr       v7, v8, v0
    v.sub        v0, v4, v7
    @p1 v.sel        v4, v0, v7
    v.movi       v0, #128
    v.movi       v7, #0
    v.movi       v8, #1
    v.cmp.lt     p1, v12, v7
    v.cmp.lt     p2, v0, v7
    v.sub        v8, v7, v12
    @p1 v.sel        v9, v8, v12
    v.sub        v8, v7, v0
    @p2 v.sel        v16, v8, v0
    v.movi       v0, #7
    v.lshr       v8, v9, v0
    v.sub        v0, v7, v8
    @p1 v.sel        v7, v0, v8
    v.movi       v0, #128
    v.movi       v8, #0
    v.movi       v9, #1
    v.cmp.lt     p1, v11, v8
    v.cmp.lt     p2, v0, v8
    v.sub        v9, v8, v11
    @p1 v.sel        v16, v9, v11
    v.sub        v9, v8, v0
    @p2 v.sel        v17, v9, v0
    v.movi       v0, #7
    v.lshr       v9, v16, v0
    v.sub        v0, v8, v9
    @p1 v.sel        v8, v0, v9
    v.movi       v0, #128
    v.movi       v9, #0
    v.movi       v16, #1
    v.cmp.lt     p1, v10, v9
    v.cmp.lt     p2, v0, v9
    v.sub        v16, v9, v10
    @p1 v.sel        v17, v16, v10
    v.sub        v16, v9, v0
    @p2 v.sel        v18, v16, v0
    v.movi       v0, #7
    v.lshr       v16, v17, v0
    v.sub        v0, v9, v16
    @p1 v.sel        v9, v0, v16
    v.movi       v0, #128
    v.movi       v16, #0
    v.movi       v17, #1
    v.cmp.lt     p1, v5, v16
    v.cmp.lt     p2, v0, v16
    v.sub        v17, v16, v5
    @p1 v.sel        v18, v17, v5
    v.sub        v17, v16, v0
    @p2 v.sel        v19, v17, v0
    v.movi       v0, #7
    v.lshr       v17, v18, v0
    v.sub        v0, v16, v17
    @p1 v.sel        v16, v0, v17
    v.movi       v0, #128
    v.movi       v17, #0
    v.movi       v18, #1
    v.cmp.lt     p1, v1, v17
    v.cmp.lt     p2, v0, v17
    v.sub        v18, v17, v1
    @p1 v.sel        v19, v18, v1
    v.sub        v18, v17, v0
    @p2 v.sel        v20, v18, v0
    v.movi       v0, #7
    v.lshr       v18, v19, v0
    v.sub        v0, v17, v18
    @p1 v.sel        v17, v0, v18
    v.splat      v0, s14
    v.mul        v18, v2, v0
    v.mul        v2, v3, v0
    v.mul        v3, v4, v0
    v.mul        v4, v7, v0
    v.mul        v7, v8, v0
    v.mul        v8, v9, v0
    v.mul        v9, v16, v0
    v.mul        v16, v17, v0
    s.add        s25, s10, s23
    s.movz       s23, #0
    s.cmp.lt     s26, s25, s23
    s.sub        s27, s23, s26
    s.cmp.lt     s26, s24, s23
    s.sub        s28, s23, s26
    s.xor        s26, s25, s27
    s.sub        s25, s26, s27
    s.xor        s26, s24, s28
    s.sub        s29, s26, s28
    s.lshri      s26, s25, #7
    s.muli       s29, s26, #128
    s.sub        s30, s25, s29
    s.xor        s25, s27, s28
    s.xor        s27, s26, s25
    s.sub        s26, s27, s25
    s.movz       s25, #1
    s.addi       s27, s23, #0
    s.addi       s28, s23, #0
    s.addi       s29, s23, #0
    s.addi       s30, s7, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_28:
    s.cmp.ge     s31, s27, s26
    br.nz        s31, endfor_29
    s.muli       s31, s11, #2
    s.mul        s32, s27, s24
    s.muli       s33, s28, #2
    v.iota       v0                              // arange(0, VLEN)
    s.rdspecial  s34, arg_base
    v.splat      v17, s31
    s.sub        s31, s10, s32
    s.ld.d       s32, [s34, #88]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.mul        v19, v6, v17
    s.add        s34, s23, s31                   // the tile origin
    v.extract    s35, v19, #0
    v.splat      v17, s34
    s.add        s34, s35, s33
    s.add        s35, s3, s34
    v.cmp.lt     p1, v0, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    s.addi       s34, s32, #0
    v.extract    s35, v19, #1
    v.extract    s36, v19, #2
    s.add        s37, s35, s33
    s.add        s35, s36, s33
    s.add        s36, s3, s37
    s.addi       s37, s34, #64
    s.add        s38, s3, s35
    s.addi       s35, s34, #128
    vf.cvt.bf16.f32 v20, v17
    s.addi       s39, s34, #192
    v.st.w       [s34, #0], v20
    v.extract    s40, v19, #3
    s.add        s41, s40, s33
    s.add        s40, s3, s41
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s36, s34, #256
    v.st.w       [s37, #0], v20
    v.extract    s37, v19, #4
    s.add        s41, s37, s33
    s.add        s37, s3, s41
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s38, s34, #320
    v.st.w       [s35, #0], v20
    v.extract    s35, v19, #5
    s.add        s41, s35, s33
    s.add        s35, s3, s41
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s40, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s40, s34, #384
    v.st.w       [s39, #0], v20
    v.extract    s39, v19, #6
    s.add        s41, s39, s33
    s.add        s39, s3, s41
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s37, s34, #448
    v.st.w       [s36, #0], v20
    v.extract    s36, v19, #7
    s.add        s41, s36, s33
    s.add        s36, s3, s41
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s35, s34, #512
    v.st.w       [s38, #0], v20
    v.extract    s38, v19, #8
    s.add        s41, s38, s33
    s.add        s38, s3, s41
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s39, s34, #576
    v.st.w       [s40, #0], v20
    v.extract    s40, v19, #9
    s.add        s41, s40, s33
    s.add        s40, s3, s41
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s36, s34, #640
    v.st.w       [s37, #0], v20
    v.extract    s37, v19, #10
    s.add        s41, s37, s33
    s.add        s37, s3, s41
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s38, s34, #704
    v.st.w       [s35, #0], v20
    v.extract    s35, v19, #11
    s.add        s41, s35, s33
    s.add        s35, s3, s41
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s40, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s40, s34, #768
    v.st.w       [s39, #0], v20
    v.extract    s39, v19, #12
    s.add        s41, s39, s33
    s.add        s39, s3, s41
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s37, s34, #832
    v.st.w       [s36, #0], v20
    v.extract    s36, v19, #13
    s.add        s41, s36, s33
    s.add        s36, s3, s41
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s35, s34, #896
    v.st.w       [s38, #0], v20
    v.extract    s38, v19, #14
    s.add        s41, s38, s33
    s.add        s38, s3, s41
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    s.addi       s39, s34, #960
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #15
    s.add        s40, s34, s33
    s.add        s34, s3, s40
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s36, v19, #0
    s.addi       s37, s32, #1024
    s.add        s40, s36, s33
    s.addi       s36, s40, #32
    s.add        s40, s3, s36
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    s.movz       s36, #0
    vf.cvt.bf16.f32 v20, v17
    s.add        s38, s36, s16                   // the tile origin
    v.st.w       [s35, #0], v20
    v.splat      v17, s38
    s.add        s35, s36, s31                   // the tile origin
    v.add        v20, v0, v17
    v.splat      v17, s35
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v21, [s34, #0]
    v.cmp.lt     p1, v20, v17
    vf.cvt.bf16.f32 v17, v21
    v.st.w       [s39, #0], v17
    fence.acq_rel.device
    v.extract    s34, v19, #1
    v.extract    s35, v19, #2
    s.add        s36, s34, s33
    s.add        s34, s35, s33
    s.addi       s35, s36, #32
    s.addi       s36, s34, #32
    s.add        s34, s3, s35
    s.addi       s35, s37, #64
    s.add        s38, s3, s36
    s.addi       s36, s37, #128
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s40, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s39, v19, #3
    s.addi       s40, s37, #192
    s.add        s41, s39, s33
    s.addi       s39, s41, #32
    s.add        s41, s3, s39
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #4
    s.addi       s35, s37, #256
    s.add        s39, s34, s33
    s.addi       s34, s39, #32
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #5
    s.addi       s36, s37, #320
    s.add        s38, s34, s33
    s.addi       s34, s38, #32
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #6
    s.addi       s40, s37, #384
    s.add        s41, s34, s33
    s.addi       s34, s41, #32
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #7
    s.addi       s35, s37, #448
    s.add        s39, s34, s33
    s.addi       s34, s39, #32
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #8
    s.addi       s36, s37, #512
    s.add        s38, s34, s33
    s.addi       s34, s38, #32
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #9
    s.addi       s40, s37, #576
    s.add        s41, s34, s33
    s.addi       s34, s41, #32
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #10
    s.addi       s35, s37, #640
    s.add        s39, s34, s33
    s.addi       s34, s39, #32
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #11
    s.addi       s36, s37, #704
    s.add        s38, s34, s33
    s.addi       s34, s38, #32
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #12
    s.addi       s40, s37, #768
    s.add        s41, s34, s33
    s.addi       s34, s41, #32
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #13
    s.addi       s35, s37, #832
    s.add        s39, s34, s33
    s.addi       s34, s39, #32
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #14
    s.addi       s36, s37, #896
    s.add        s38, s34, s33
    s.addi       s34, s38, #32
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #15
    s.addi       s40, s37, #960
    s.add        s37, s34, s33
    s.addi       s34, s37, #32
    s.add        s37, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #0
    s.addi       s35, s32, #2048
    s.add        s39, s34, s33
    s.addi       s34, s39, #64
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    s.add        s38, s3, s34
    vf.cvt.bf16.f32 v20, v17
    s.movz       s34, #0
    v.st.w       [s36, #0], v20
    s.add        s36, s34, s17                   // the tile origin
    s.add        s39, s34, s31                   // the tile origin
    v.splat      v17, s36
    v.splat      v20, s39
    v.add        v21, v0, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s37, #0]
    v.cmp.lt     p1, v21, v20
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    fence.acq_rel.device
    v.extract    s34, v19, #1
    v.extract    s36, v19, #2
    s.add        s37, s34, s33
    s.add        s34, s36, s33
    s.addi       s36, s37, #64
    s.addi       s37, s34, #64
    s.add        s34, s3, s36
    s.addi       s36, s35, #64
    s.add        s39, s3, s37
    s.addi       s37, s35, #128
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s38, v19, #3
    s.addi       s40, s35, #192
    s.add        s41, s38, s33
    s.addi       s38, s41, #64
    s.add        s41, s3, s38
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #4
    s.addi       s36, s35, #256
    s.add        s38, s34, s33
    s.addi       s34, s38, #64
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #5
    s.addi       s37, s35, #320
    s.add        s39, s34, s33
    s.addi       s34, s39, #64
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #6
    s.addi       s40, s35, #384
    s.add        s41, s34, s33
    s.addi       s34, s41, #64
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #7
    s.addi       s36, s35, #448
    s.add        s38, s34, s33
    s.addi       s34, s38, #64
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #8
    s.addi       s37, s35, #512
    s.add        s39, s34, s33
    s.addi       s34, s39, #64
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #9
    s.addi       s40, s35, #576
    s.add        s41, s34, s33
    s.addi       s34, s41, #64
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #10
    s.addi       s36, s35, #640
    s.add        s38, s34, s33
    s.addi       s34, s38, #64
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #11
    s.addi       s37, s35, #704
    s.add        s39, s34, s33
    s.addi       s34, s39, #64
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #12
    s.addi       s40, s35, #768
    s.add        s41, s34, s33
    s.addi       s34, s41, #64
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #13
    s.addi       s36, s35, #832
    s.add        s38, s34, s33
    s.addi       s34, s38, #64
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #14
    s.addi       s37, s35, #896
    s.add        s39, s34, s33
    s.addi       s34, s39, #64
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #15
    s.addi       s40, s35, #960
    s.add        s35, s34, s33
    s.addi       s34, s35, #64
    s.add        s35, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #0
    s.addi       s36, s32, #3072
    s.add        s38, s34, s33
    s.addi       s34, s38, #96
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    s.add        s38, s3, s34
    vf.cvt.bf16.f32 v20, v17
    s.movz       s34, #0
    v.st.w       [s37, #0], v20
    s.add        s37, s34, s19                   // the tile origin
    s.add        s39, s34, s31                   // the tile origin
    v.splat      v17, s37
    v.splat      v20, s39
    v.add        v21, v0, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    v.cmp.lt     p1, v21, v20
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    fence.acq_rel.device
    v.extract    s34, v19, #1
    v.extract    s35, v19, #2
    s.add        s37, s34, s33
    s.add        s34, s35, s33
    s.addi       s35, s37, #96
    s.addi       s37, s34, #96
    s.add        s34, s3, s35
    s.addi       s35, s36, #64
    s.add        s39, s3, s37
    s.addi       s37, s36, #128
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s38, v19, #3
    s.addi       s40, s36, #192
    s.add        s41, s38, s33
    s.addi       s38, s41, #96
    s.add        s41, s3, s38
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #4
    s.addi       s35, s36, #256
    s.add        s38, s34, s33
    s.addi       s34, s38, #96
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #5
    s.addi       s37, s36, #320
    s.add        s39, s34, s33
    s.addi       s34, s39, #96
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #6
    s.addi       s40, s36, #384
    s.add        s41, s34, s33
    s.addi       s34, s41, #96
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #7
    s.addi       s35, s36, #448
    s.add        s38, s34, s33
    s.addi       s34, s38, #96
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #8
    s.addi       s37, s36, #512
    s.add        s39, s34, s33
    s.addi       s34, s39, #96
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #9
    s.addi       s40, s36, #576
    s.add        s41, s34, s33
    s.addi       s34, s41, #96
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #10
    s.addi       s35, s36, #640
    s.add        s38, s34, s33
    s.addi       s34, s38, #96
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #11
    s.addi       s37, s36, #704
    s.add        s39, s34, s33
    s.addi       s34, s39, #96
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #12
    s.addi       s40, s36, #768
    s.add        s41, s34, s33
    s.addi       s34, s41, #96
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #13
    s.addi       s35, s36, #832
    s.add        s38, s34, s33
    s.addi       s34, s38, #96
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #14
    s.addi       s37, s36, #896
    s.add        s39, s34, s33
    s.addi       s34, s39, #96
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #15
    s.addi       s40, s36, #960
    s.add        s36, s34, s33
    s.addi       s34, s36, #96
    s.add        s36, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #0
    s.addi       s35, s32, #4096
    s.add        s38, s34, s33
    s.addi       s34, s38, #128
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    s.add        s38, s3, s34
    vf.cvt.bf16.f32 v20, v17
    s.movz       s34, #0
    v.st.w       [s37, #0], v20
    s.add        s37, s34, s18                   // the tile origin
    s.add        s39, s34, s31                   // the tile origin
    v.splat      v17, s37
    v.splat      v20, s39
    v.add        v21, v0, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    v.cmp.lt     p1, v21, v20
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    fence.acq_rel.device
    v.extract    s34, v19, #1
    v.extract    s36, v19, #2
    s.add        s37, s34, s33
    s.add        s34, s36, s33
    s.addi       s36, s37, #128
    s.addi       s37, s34, #128
    s.add        s34, s3, s36
    s.addi       s36, s35, #64
    s.add        s39, s3, s37
    s.addi       s37, s35, #128
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s38, v19, #3
    s.addi       s40, s35, #192
    s.add        s41, s38, s33
    s.addi       s38, s41, #128
    s.add        s41, s3, s38
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #4
    s.addi       s36, s35, #256
    s.add        s38, s34, s33
    s.addi       s34, s38, #128
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #5
    s.addi       s37, s35, #320
    s.add        s39, s34, s33
    s.addi       s34, s39, #128
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #6
    s.addi       s40, s35, #384
    s.add        s41, s34, s33
    s.addi       s34, s41, #128
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #7
    s.addi       s36, s35, #448
    s.add        s38, s34, s33
    s.addi       s34, s38, #128
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #8
    s.addi       s37, s35, #512
    s.add        s39, s34, s33
    s.addi       s34, s39, #128
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #9
    s.addi       s40, s35, #576
    s.add        s41, s34, s33
    s.addi       s34, s41, #128
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #10
    s.addi       s36, s35, #640
    s.add        s38, s34, s33
    s.addi       s34, s38, #128
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #11
    s.addi       s37, s35, #704
    s.add        s39, s34, s33
    s.addi       s34, s39, #128
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #12
    s.addi       s40, s35, #768
    s.add        s41, s34, s33
    s.addi       s34, s41, #128
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #13
    s.addi       s36, s35, #832
    s.add        s38, s34, s33
    s.addi       s34, s38, #128
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #14
    s.addi       s37, s35, #896
    s.add        s39, s34, s33
    s.addi       s34, s39, #128
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #15
    s.addi       s40, s35, #960
    s.add        s35, s34, s33
    s.addi       s34, s35, #128
    s.add        s35, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #0
    s.addi       s36, s32, #5120
    s.add        s38, s34, s33
    s.addi       s34, s38, #160
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    s.add        s38, s3, s34
    vf.cvt.bf16.f32 v20, v17
    s.movz       s34, #0
    v.st.w       [s37, #0], v20
    s.add        s37, s34, s20                   // the tile origin
    s.add        s39, s34, s31                   // the tile origin
    v.splat      v17, s37
    v.splat      v20, s39
    v.add        v21, v0, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s35, #0]
    v.cmp.lt     p1, v21, v20
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    fence.acq_rel.device
    v.extract    s34, v19, #1
    v.extract    s35, v19, #2
    s.add        s37, s34, s33
    s.add        s34, s35, s33
    s.addi       s35, s37, #160
    s.addi       s37, s34, #160
    s.add        s34, s3, s35
    s.addi       s35, s36, #64
    s.add        s39, s3, s37
    s.addi       s37, s36, #128
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s38, v19, #3
    s.addi       s40, s36, #192
    s.add        s41, s38, s33
    s.addi       s38, s41, #160
    s.add        s41, s3, s38
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #4
    s.addi       s35, s36, #256
    s.add        s38, s34, s33
    s.addi       s34, s38, #160
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #5
    s.addi       s37, s36, #320
    s.add        s39, s34, s33
    s.addi       s34, s39, #160
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #6
    s.addi       s40, s36, #384
    s.add        s41, s34, s33
    s.addi       s34, s41, #160
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #7
    s.addi       s35, s36, #448
    s.add        s38, s34, s33
    s.addi       s34, s38, #160
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #8
    s.addi       s37, s36, #512
    s.add        s39, s34, s33
    s.addi       s34, s39, #160
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #9
    s.addi       s40, s36, #576
    s.add        s41, s34, s33
    s.addi       s34, s41, #160
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #10
    s.addi       s35, s36, #640
    s.add        s38, s34, s33
    s.addi       s34, s38, #160
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #11
    s.addi       s37, s36, #704
    s.add        s39, s34, s33
    s.addi       s34, s39, #160
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #12
    s.addi       s40, s36, #768
    s.add        s41, s34, s33
    s.addi       s34, s41, #160
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #13
    s.addi       s35, s36, #832
    s.add        s38, s34, s33
    s.addi       s34, s38, #160
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #14
    s.addi       s37, s36, #896
    s.add        s39, s34, s33
    s.addi       s34, s39, #160
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #15
    s.addi       s40, s36, #960
    s.add        s36, s34, s33
    s.addi       s34, s36, #160
    s.add        s36, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s34, v19, #0
    s.addi       s35, s32, #6144
    s.add        s38, s34, s33
    s.addi       s34, s38, #192
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    s.add        s38, s3, s34
    vf.cvt.bf16.f32 v20, v17
    s.movz       s34, #0
    v.st.w       [s37, #0], v20
    s.add        s37, s34, s21                   // the tile origin
    s.add        s39, s34, s31                   // the tile origin
    v.splat      v17, s37
    v.splat      v20, s39
    v.add        v21, v0, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s36, #0]
    v.cmp.lt     p1, v21, v20
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    fence.acq_rel.device
    v.extract    s34, v19, #1
    v.extract    s36, v19, #2
    s.add        s37, s34, s33
    s.add        s34, s36, s33
    s.addi       s36, s37, #192
    s.addi       s37, s34, #192
    s.add        s34, s3, s36
    s.addi       s36, s35, #64
    s.add        s39, s3, s37
    s.addi       s37, s35, #128
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s35, #0], v20
    v.extract    s38, v19, #3
    s.addi       s40, s35, #192
    s.add        s41, s38, s33
    s.addi       s38, s41, #192
    s.add        s41, s3, s38
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s34, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #4
    s.addi       s36, s35, #256
    s.add        s38, s34, s33
    s.addi       s34, s38, #192
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #5
    s.addi       s37, s35, #320
    s.add        s39, s34, s33
    s.addi       s34, s39, #192
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #6
    s.addi       s40, s35, #384
    s.add        s41, s34, s33
    s.addi       s34, s41, #192
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #7
    s.addi       s36, s35, #448
    s.add        s38, s34, s33
    s.addi       s34, s38, #192
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #8
    s.addi       s37, s35, #512
    s.add        s39, s34, s33
    s.addi       s34, s39, #192
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #9
    s.addi       s40, s35, #576
    s.add        s41, s34, s33
    s.addi       s34, s41, #192
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #10
    s.addi       s36, s35, #640
    s.add        s38, s34, s33
    s.addi       s34, s38, #192
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #11
    s.addi       s37, s35, #704
    s.add        s39, s34, s33
    s.addi       s34, s39, #192
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #12
    s.addi       s40, s35, #768
    s.add        s41, s34, s33
    s.addi       s34, s41, #192
    s.add        s41, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #13
    s.addi       s36, s35, #832
    s.add        s38, s34, s33
    s.addi       s34, s38, #192
    s.add        s38, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s37, #0], v20
    v.extract    s34, v19, #14
    s.addi       s37, s35, #896
    s.add        s39, s34, s33
    s.addi       s34, s39, #192
    s.add        s39, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s41, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s40, #0], v20
    v.extract    s34, v19, #15
    s.addi       s40, s35, #960
    s.add        s35, s34, s33
    s.addi       s34, s35, #192
    s.add        s35, s3, s34
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s38, #0]
    vf.cvt.bf16.f32 v20, v17
    v.st.w       [s36, #0], v20
    v.extract    s34, v19, #0
    s.addi       s36, s32, #7168
    s.add        s38, s34, s33
    s.addi       s34, s38, #224
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s39, #0]
    s.add        s38, s3, s34
    vf.cvt.bf16.f32 v20, v17
    s.movz       s34, #0
    v.st.w       [s37, #0], v20
    s.add        s37, s34, s22                   // the tile origin
    s.add        s39, s34, s31                   // the tile origin
    v.splat      v17, s37
    v.splat      v20, s39
    v.add        v21, v0, v17
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s35, #0]
    v.cmp.lt     p1, v21, v20
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s40, #0], v17
    fence.acq_rel.device
    v.extract    s34, v19, #1
    v.extract    s35, v19, #2
    s.add        s37, s34, s33
    s.add        s34, s35, s33
    s.addi       s35, s37, #224
    s.addi       s37, s34, #224
    s.add        s34, s3, s35
    s.addi       s35, s36, #64
    s.add        s39, s3, s37
    s.addi       s37, s36, #128
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s38, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s36, #0], v17
    v.extract    s38, v19, #3
    s.addi       s40, s36, #192
    s.add        s41, s38, s33
    s.addi       s38, s41, #224
    s.add        s41, s3, s38
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s34, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s35, #0], v17
    v.extract    s34, v19, #4
    s.addi       s35, s36, #256
    s.add        s38, s34, s33
    s.addi       s34, s38, #224
    s.add        s38, s3, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s39, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s37, #0], v17
    v.extract    s34, v19, #5
    s.addi       s37, s36, #320
    s.add        s39, s34, s33
    s.addi       s34, s39, #224
    s.add        s39, s3, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s41, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s40, #0], v17
    v.extract    s34, v19, #6
    s.addi       s40, s36, #384
    s.add        s41, s34, s33
    s.addi       s34, s41, #224
    s.add        s41, s3, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s38, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s35, #0], v17
    v.extract    s34, v19, #7
    s.addi       s35, s36, #448
    s.add        s38, s34, s33
    s.addi       s34, s38, #224
    s.add        s38, s3, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s39, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s37, #0], v17
    v.extract    s34, v19, #8
    s.addi       s37, s36, #512
    s.add        s39, s34, s33
    s.addi       s34, s39, #224
    s.add        s39, s3, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s41, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s40, #0], v17
    v.extract    s34, v19, #9
    s.addi       s40, s36, #576
    s.add        s41, s34, s33
    s.addi       s34, s41, #224
    s.add        s41, s3, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s38, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s35, #0], v17
    v.extract    s34, v19, #10
    s.addi       s35, s36, #640
    s.add        s38, s34, s33
    s.addi       s34, s38, #224
    s.add        s38, s3, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s39, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s37, #0], v17
    v.extract    s34, v19, #11
    s.addi       s37, s36, #704
    s.add        s39, s34, s33
    s.addi       s34, s39, #224
    s.add        s39, s3, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s41, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s40, #0], v17
    v.extract    s34, v19, #12
    s.addi       s40, s36, #768
    s.add        s41, s34, s33
    s.addi       s34, s41, #224
    s.add        s41, s3, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s38, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s35, #0], v17
    v.extract    s34, v19, #13
    s.addi       s35, s36, #832
    s.add        s38, s34, s33
    s.addi       s34, s38, #224
    s.add        s38, s3, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s39, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s37, #0], v17
    v.extract    s34, v19, #14
    s.addi       s37, s36, #896
    s.add        s39, s34, s33
    s.addi       s34, s39, #224
    s.add        s39, s3, s34
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s41, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s40, #0], v17
    v.extract    s34, v19, #15
    s.addi       s40, s36, #960
    s.add        s36, s34, s33
    s.addi       s33, s36, #224
    s.add        s34, s3, s33
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s38, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s35, #0], v17
    s.addi       s33, s32, #0
    s.addi       s35, s32, #1024
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s39, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s37, #0], v17
    s.addi       s36, s32, #2048
    s.addi       s37, s32, #3072
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v0, [s34, #0]
    vf.cvt.bf16.f32 v17, v0
    v.st.w       [s40, #0], v17
    fence.acq_rel.device
    s.addi       s34, s32, #4096
    v.ld.w       v0, [s33, #0]
    v.ld.w       v17, [s35, #0]
    vf.abs       v19, v0
    s.addi       s33, s32, #5120
    v.ld.w       v0, [s36, #0]
    vf.abs       v20, v17
    vf.max.ieee  v17, v19, v20
    s.addi       s35, s32, #6144
    v.ld.w       v19, [s37, #0]
    vf.abs       v20, v0
    vf.max.ieee  v0, v17, v20
    s.addi       s36, s32, #7168
    v.ld.w       v17, [s34, #0]
    vf.abs       v20, v19
    vf.max.ieee  v19, v0, v20
    s.addi       s34, s32, #64
    v.ld.w       v0, [s33, #0]
    vf.abs       v20, v17
    vf.max.ieee  v17, v19, v20
    s.addi       s33, s32, #1088
    v.ld.w       v19, [s34, #0]
    vf.abs       v20, v0
    vf.max.ieee  v0, v17, v20
    s.addi       s34, s32, #2112
    v.ld.w       v17, [s33, #0]
    vf.abs       v20, v19
    vf.abs       v19, v17
    v.ld.w       v17, [s35, #0]
    vf.max.ieee  v21, v20, v19
    v.ld.w       v19, [s34, #0]
    vf.abs       v20, v17
    vf.max.ieee  v17, v0, v20
    s.addi       s33, s32, #3136
    vf.abs       v0, v19
    v.ld.w       v19, [s36, #0]
    vf.max.ieee  v20, v21, v0
    v.ld.w       v0, [s33, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v17, v21
    vf.reduce.max.b v17, v19
    s.addi       s33, s32, #4160
    s.addi       s34, s32, #5184
    s.addi       s35, s32, #6208
    s.addi       s36, s32, #7232
    v.ld.w       v19, [s33, #0]
    vf.abs       v21, v0
    vf.max.ieee  v0, v20, v21
    s.addi       s33, s32, #128
    v.ld.w       v20, [s34, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v0, v21
    s.addi       s34, s32, #1152
    v.ld.w       v0, [s33, #0]
    vf.abs       v21, v20
    vf.max.ieee  v20, v19, v21
    s.addi       s33, s32, #2176
    v.ld.w       v19, [s34, #0]
    vf.abs       v21, v0
    vf.abs       v0, v19
    v.ld.w       v19, [s35, #0]
    vf.max.ieee  v22, v21, v0
    v.ld.w       v0, [s33, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v20, v21
    s.addi       s33, s32, #3200
    vf.abs       v20, v0
    v.ld.w       v0, [s36, #0]
    vf.max.ieee  v21, v22, v20
    v.ld.w       v20, [s33, #0]
    vf.abs       v22, v0
    vf.max.ieee  v0, v19, v22
    vf.reduce.max.b v19, v0
    s.addi       s33, s32, #4224
    s.addi       s34, s32, #5248
    s.addi       s35, s32, #6272
    s.addi       s36, s32, #7296
    v.ld.w       v0, [s33, #0]
    vf.abs       v22, v20
    vf.max.ieee  v20, v21, v22
    s.addi       s33, s32, #192
    v.ld.w       v21, [s34, #0]
    vf.abs       v22, v0
    vf.max.ieee  v0, v20, v22
    s.addi       s34, s32, #1216
    v.ld.w       v20, [s33, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v0, v22
    s.addi       s33, s32, #2240
    v.ld.w       v0, [s34, #0]
    vf.abs       v22, v20
    vf.abs       v20, v0
    v.ld.w       v0, [s35, #0]
    vf.max.ieee  v23, v22, v20
    v.ld.w       v20, [s33, #0]
    vf.abs       v22, v0
    vf.max.ieee  v0, v21, v22
    s.addi       s33, s32, #3264
    vf.abs       v21, v20
    v.ld.w       v20, [s36, #0]
    vf.max.ieee  v22, v23, v21
    v.ld.w       v21, [s33, #0]
    vf.abs       v23, v20
    vf.max.ieee  v20, v0, v23
    vf.reduce.max.b v0, v20
    s.addi       s33, s32, #4288
    s.addi       s34, s32, #5312
    s.addi       s35, s32, #6336
    s.addi       s36, s32, #7360
    v.ld.w       v20, [s33, #0]
    vf.abs       v23, v21
    vf.max.ieee  v21, v22, v23
    s.addi       s33, s32, #256
    v.ld.w       v22, [s34, #0]
    vf.abs       v23, v20
    vf.max.ieee  v20, v21, v23
    s.addi       s34, s32, #1280
    v.ld.w       v21, [s33, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v20, v23
    s.addi       s33, s32, #2304
    v.ld.w       v20, [s34, #0]
    vf.abs       v23, v21
    vf.abs       v21, v20
    v.ld.w       v20, [s35, #0]
    vf.max.ieee  v24, v23, v21
    v.ld.w       v21, [s33, #0]
    vf.abs       v23, v20
    vf.max.ieee  v20, v22, v23
    s.addi       s33, s32, #3328
    vf.abs       v22, v21
    v.ld.w       v21, [s36, #0]
    vf.max.ieee  v23, v24, v22
    v.ld.w       v22, [s33, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v20, v24
    vf.reduce.max.b v20, v21
    s.addi       s33, s32, #4352
    s.addi       s34, s32, #5376
    s.addi       s35, s32, #6400
    s.addi       s36, s32, #7424
    v.ld.w       v21, [s33, #0]
    vf.abs       v24, v22
    vf.max.ieee  v22, v23, v24
    s.addi       s33, s32, #320
    v.ld.w       v23, [s34, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v22, v24
    s.addi       s34, s32, #1344
    v.ld.w       v22, [s33, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v21, v24
    s.addi       s33, s32, #2368
    v.ld.w       v21, [s34, #0]
    vf.abs       v24, v22
    vf.abs       v22, v21
    v.ld.w       v21, [s35, #0]
    vf.max.ieee  v25, v24, v22
    v.ld.w       v22, [s33, #0]
    vf.abs       v24, v21
    vf.max.ieee  v21, v23, v24
    s.addi       s33, s32, #3392
    vf.abs       v23, v22
    v.ld.w       v22, [s36, #0]
    vf.max.ieee  v24, v25, v23
    v.ld.w       v23, [s33, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v21, v25
    vf.reduce.max.b v21, v22
    s.addi       s33, s32, #4416
    s.addi       s34, s32, #5440
    s.addi       s35, s32, #6464
    s.addi       s36, s32, #7488
    v.ld.w       v22, [s33, #0]
    vf.abs       v25, v23
    vf.max.ieee  v23, v24, v25
    s.addi       s33, s32, #384
    v.ld.w       v24, [s34, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v23, v25
    s.addi       s34, s32, #1408
    v.ld.w       v23, [s33, #0]
    vf.abs       v25, v24
    vf.max.ieee  v24, v22, v25
    s.addi       s33, s32, #2432
    v.ld.w       v22, [s34, #0]
    vf.abs       v25, v23
    vf.abs       v23, v22
    v.ld.w       v22, [s35, #0]
    vf.max.ieee  v26, v25, v23
    v.ld.w       v23, [s33, #0]
    vf.abs       v25, v22
    vf.max.ieee  v22, v24, v25
    s.addi       s33, s32, #3456
    vf.abs       v24, v23
    v.ld.w       v23, [s36, #0]
    vf.max.ieee  v25, v26, v24
    v.ld.w       v24, [s33, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v22, v26
    vf.reduce.max.b v22, v23
    s.addi       s33, s32, #4480
    s.addi       s34, s32, #5504
    s.addi       s35, s32, #6528
    s.addi       s36, s32, #7552
    v.ld.w       v23, [s33, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v25, v26
    s.addi       s33, s32, #448
    v.ld.w       v25, [s34, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v24, v26
    s.addi       s34, s32, #1472
    v.ld.w       v24, [s33, #0]
    vf.abs       v26, v25
    vf.max.ieee  v25, v23, v26
    s.addi       s33, s32, #2496
    v.ld.w       v23, [s34, #0]
    vf.abs       v26, v24
    vf.abs       v24, v23
    v.ld.w       v23, [s35, #0]
    vf.max.ieee  v27, v26, v24
    v.ld.w       v24, [s33, #0]
    vf.abs       v26, v23
    vf.max.ieee  v23, v25, v26
    s.addi       s33, s32, #3520
    vf.abs       v25, v24
    v.ld.w       v24, [s36, #0]
    vf.max.ieee  v26, v27, v25
    v.ld.w       v25, [s33, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v23, v27
    vf.reduce.max.b v23, v24
    s.addi       s33, s32, #4544
    s.addi       s34, s32, #5568
    s.addi       s35, s32, #6592
    s.addi       s36, s32, #7616
    v.ld.w       v24, [s33, #0]
    vf.abs       v27, v25
    vf.max.ieee  v25, v26, v27
    s.addi       s33, s32, #512
    v.ld.w       v26, [s34, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v25, v27
    s.addi       s34, s32, #1536
    v.ld.w       v25, [s33, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v24, v27
    s.addi       s33, s32, #2560
    v.ld.w       v24, [s34, #0]
    vf.abs       v27, v25
    vf.abs       v25, v24
    v.ld.w       v24, [s35, #0]
    vf.max.ieee  v28, v27, v25
    v.ld.w       v25, [s33, #0]
    vf.abs       v27, v24
    vf.max.ieee  v24, v26, v27
    s.addi       s33, s32, #3584
    vf.abs       v26, v25
    v.ld.w       v25, [s36, #0]
    vf.max.ieee  v27, v28, v26
    v.ld.w       v26, [s33, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v24, v28
    vf.reduce.max.b v24, v25
    s.addi       s33, s32, #4608
    s.addi       s34, s32, #5632
    s.addi       s35, s32, #6656
    s.addi       s36, s32, #7680
    v.ld.w       v25, [s33, #0]
    vf.abs       v28, v26
    vf.max.ieee  v26, v27, v28
    s.addi       s33, s32, #576
    v.ld.w       v27, [s34, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v26, v28
    s.addi       s34, s32, #1600
    v.ld.w       v26, [s33, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v25, v28
    s.addi       s33, s32, #2624
    v.ld.w       v25, [s34, #0]
    vf.abs       v28, v26
    vf.abs       v26, v25
    v.ld.w       v25, [s35, #0]
    vf.max.ieee  v29, v28, v26
    v.ld.w       v26, [s33, #0]
    vf.abs       v28, v25
    vf.max.ieee  v25, v27, v28
    s.addi       s33, s32, #3648
    vf.abs       v27, v26
    v.ld.w       v26, [s36, #0]
    vf.max.ieee  v28, v29, v27
    v.ld.w       v27, [s33, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v25, v29
    vf.reduce.max.b v25, v26
    s.addi       s33, s32, #4672
    s.addi       s34, s32, #5696
    s.addi       s35, s32, #6720
    s.addi       s36, s32, #7744
    v.ld.w       v26, [s33, #0]
    vf.abs       v29, v27
    vf.max.ieee  v27, v28, v29
    s.addi       s33, s32, #640
    v.ld.w       v28, [s34, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v27, v29
    s.addi       s34, s32, #1664
    v.ld.w       v27, [s33, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v26, v29
    s.addi       s33, s32, #2688
    v.ld.w       v26, [s34, #0]
    vf.abs       v29, v27
    vf.abs       v27, v26
    v.ld.w       v26, [s35, #0]
    vf.max.ieee  v30, v29, v27
    v.ld.w       v27, [s33, #0]
    vf.abs       v29, v26
    vf.max.ieee  v26, v28, v29
    s.addi       s33, s32, #3712
    vf.abs       v28, v27
    v.ld.w       v27, [s36, #0]
    vf.max.ieee  v29, v30, v28
    v.ld.w       v28, [s33, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v26, v30
    vf.reduce.max.b v26, v27
    s.addi       s33, s32, #4736
    s.addi       s34, s32, #5760
    s.addi       s35, s32, #6784
    s.addi       s36, s32, #7808
    v.ld.w       v27, [s33, #0]
    vf.abs       v30, v28
    vf.max.ieee  v28, v29, v30
    s.addi       s33, s32, #704
    v.ld.w       v29, [s34, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v28, v30
    s.addi       s34, s32, #1728
    v.ld.w       v28, [s33, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v27, v30
    s.addi       s33, s32, #2752
    v.ld.w       v27, [s34, #0]
    vf.abs       v30, v28
    vf.abs       v28, v27
    v.ld.w       v27, [s35, #0]
    vf.max.ieee  v31, v30, v28
    v.ld.w       v28, [s33, #0]
    vf.abs       v30, v27
    vf.max.ieee  v27, v29, v30
    s.addi       s33, s32, #3776
    vf.abs       v29, v28
    v.ld.w       v28, [s36, #0]
    vf.max.ieee  v30, v31, v29
    v.ld.w       v29, [s33, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v27, v31
    vf.reduce.max.b v27, v28
    s.addi       s33, s32, #4800
    s.addi       s34, s32, #5824
    s.addi       s35, s32, #6848
    s.addi       s36, s32, #7872
    v.ld.w       v28, [s33, #0]
    vf.abs       v31, v29
    vf.max.ieee  v29, v30, v31
    s.addi       s33, s32, #768
    v.ld.w       v30, [s34, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v29, v31
    s.addi       s34, s32, #1792
    v.ld.w       v29, [s33, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v28, v31
    s.addi       s33, s32, #2816
    v.ld.w       v28, [s34, #0]
    vf.abs       v31, v29
    vf.abs       v29, v28
    v.ld.w       v28, [s35, #0]
    vf.max.ieee  v32, v31, v29
    v.ld.w       v29, [s33, #0]
    vf.abs       v31, v28
    vf.max.ieee  v28, v30, v31
    s.addi       s33, s32, #3840
    vf.abs       v30, v29
    v.ld.w       v29, [s36, #0]
    vf.max.ieee  v31, v32, v30
    v.ld.w       v30, [s33, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v28, v32
    vf.reduce.max.b v28, v29
    s.addi       s33, s32, #4864
    s.addi       s34, s32, #5888
    s.addi       s35, s32, #6912
    s.addi       s36, s32, #7936
    v.ld.w       v29, [s33, #0]
    vf.abs       v32, v30
    vf.max.ieee  v30, v31, v32
    s.addi       s33, s32, #832
    v.ld.w       v31, [s34, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v30, v32
    s.addi       s34, s32, #1856
    v.ld.w       v30, [s33, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v29, v32
    s.addi       s33, s32, #2880
    v.ld.w       v29, [s34, #0]
    vf.abs       v32, v30
    vf.abs       v30, v29
    v.ld.w       v29, [s35, #0]
    vf.max.ieee  v33, v32, v30
    v.ld.w       v30, [s33, #0]
    vf.abs       v32, v29
    vf.max.ieee  v29, v31, v32
    s.addi       s33, s32, #3904
    vf.abs       v31, v30
    v.ld.w       v30, [s36, #0]
    vf.max.ieee  v32, v33, v31
    v.ld.w       v31, [s33, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v29, v33
    vf.reduce.max.b v29, v30
    s.addi       s33, s32, #4928
    s.addi       s34, s32, #5952
    s.addi       s35, s32, #6976
    s.addi       s36, s32, #8000
    v.ld.w       v30, [s33, #0]
    vf.abs       v33, v31
    vf.max.ieee  v31, v32, v33
    s.addi       s33, s32, #896
    v.ld.w       v32, [s34, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v31, v33
    s.addi       s34, s32, #1920
    v.ld.w       v31, [s33, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v30, v33
    s.addi       s33, s32, #2944
    v.ld.w       v30, [s34, #0]
    vf.abs       v33, v31
    vf.abs       v31, v30
    v.ld.w       v30, [s35, #0]
    vf.max.ieee  v34, v33, v31
    v.ld.w       v31, [s33, #0]
    vf.abs       v33, v30
    vf.max.ieee  v30, v32, v33
    s.addi       s33, s32, #3968
    v.ld.w       v32, [s36, #0]
    vf.abs       v33, v31
    vf.max.ieee  v31, v34, v33
    v.ld.w       v33, [s33, #0]
    vf.abs       v34, v32
    vf.max.ieee  v32, v30, v34
    vf.reduce.max.b v30, v32
    s.addi       s33, s32, #4992
    s.addi       s34, s32, #6016
    s.addi       s35, s32, #7040
    s.addi       s36, s32, #8064
    v.ld.w       v32, [s33, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v31, v34
    s.addi       s33, s32, #960
    v.ld.w       v31, [s34, #0]
    vf.abs       v34, v32
    vf.max.ieee  v32, v33, v34
    s.addi       s34, s32, #1984
    v.ld.w       v33, [s33, #0]
    vf.abs       v34, v31
    vf.max.ieee  v31, v32, v34
    s.addi       s33, s32, #3008
    v.ld.w       v32, [s34, #0]
    vf.abs       v34, v33
    v.ld.w       v33, [s35, #0]
    vf.abs       v35, v32
    vf.max.ieee  v32, v34, v35
    v.ld.w       v34, [s33, #0]
    vf.abs       v35, v33
    vf.max.ieee  v33, v31, v35
    s.addi       s33, s32, #4032
    v.ld.w       v31, [s36, #0]
    vf.abs       v35, v34
    vf.max.ieee  v34, v32, v35
    v.ld.w       v32, [s33, #0]
    vf.abs       v35, v31
    vf.max.ieee  v31, v33, v35
    vf.reduce.max.b v33, v31
    s.addi       s33, s32, #5056
    s.addi       s34, s32, #6080
    s.addi       s35, s32, #7104
    s.addi       s36, s32, #8128
    v.ld.w       v31, [s33, #0]
    vf.abs       v35, v32
    vf.max.ieee  v32, v34, v35
    v.movi       v34, #0
    v.ld.w       v35, [s34, #0]
    vf.abs       v36, v31
    // one value per row into one vector (ISA 0x09)
    v.extract    s33, v17, #0
    vf.max.ieee  v17, v32, v36
    v.extract    s34, v19, #0
    v.ld.w       v19, [s35, #0]
    vf.abs       v31, v35
    v.extract    s35, v0, #0
    vf.max.ieee  v0, v17, v31
    v.extract    s37, v20, #0
    v.ld.w       v17, [s36, #0]
    v.insert     v34, s33, #0
    vf.abs       v20, v19
    v.extract    s33, v21, #0
    v.insert     v34, s34, #1
    v.insert     v34, s35, #2
    vf.max.ieee  v19, v0, v20
    v.extract    s34, v22, #0
    v.insert     v34, s37, #3
    v.insert     v34, s33, #4
    v.insert     v34, s34, #5
    vf.abs       v0, v17
    v.extract    s33, v23, #0
    vf.max.ieee  v17, v19, v0
    v.insert     v34, s33, #6
    vf.reduce.max.b v0, v17
    v.extract    s33, v24, #0
    v.extract    s34, v25, #0
    v.insert     v34, s33, #7
    .li       s33, #1138753536
    v.splat      v17, s33                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s33, v26, #0
    v.insert     v34, s34, #8
    v.rcp.approx v19, v17                        // ISA 8.8: <= 2**-22 relative
    v.extract    s34, v27, #0
    v.insert     v34, s33, #9
    .li       s33, #1065353216
    v.splat      v20, s33                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s33, v28, #0
    v.insert     v34, s34, #10
    v.extract    s34, v29, #0
    v.extract    s35, v30, #0
    v.insert     v34, s33, #11
    v.extract    s33, v33, #0
    v.extract    s36, v0, #0
    v.insert     v34, s34, #12
    v.insert     v34, s35, #13
    v.insert     v34, s33, #14
    .li       s33, #730643660
    v.splat      v0, s33                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.insert     v34, s36, #15
    v.splat      v21, s12
    v.mul        v22, v15, v21
    v.mul        v23, v13, v21
    v.mul        v24, v14, v21
    vf.fms       v25, v17, v19, v20
    v.mul        v26, v12, v21
    vf.fms       v27, v19, v25, v19
    v.mul        v25, v11, v21
    vf.neg       v21, v27                        // Newton step: r0*(2 - x*r0)
    v.splat      v27, s12
    vf.cmp.o     p1, v21, v21
    v.mul        v28, v10, v27
    @p1 v.sel        v29, v21, v19
    v.mul        v19, v5, v27
    vf.mul       v21, v34, v29                   // a/y: faithful quotient
    v.mul        v30, v1, v27
    vf.fms       v27, v21, v17, v34
    v.ld.gather.w v17, [s30, v18]                // index is in elements (ISA sec 9.1)
    vf.fms       v31, v27, v29, v21
    vf.neg       v27, v31                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v27, v27
    @p1 v.sel        v29, v27, v21
    s.add        s33, s23, s31
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.addi       s31, s32, #8192
    s.addi       s34, s32, #8256
    s.addi       s35, s32, #8320
    s.addi       s36, s32, #8384
    v.ld.gather.w v21, [s30, v2]                 // index is in elements (ISA sec 9.1)
    s.addi       s37, s32, #8448
    v.ld.gather.w v27, [s30, v3]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v31, [s30, v4]                 // index is in elements (ISA sec 9.1)
    s.addi       s38, s32, #8512
    v.ld.gather.w v32, [s30, v7]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v33, [s30, v8]                 // index is in elements (ISA sec 9.1)
    s.addi       s39, s32, #8576
    v.ld.gather.w v34, [s30, v9]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v35, [s30, v16]                // index is in elements (ISA sec 9.1)
    s.addi       s40, s32, #8640
    v.st.w       [s31, #0], v22
    v.movi       v22, #0
    v.st.w       [s34, #0], v23
    v.iota       v23                             // arange(0, VLEN)
    s.movz       s31, #0
    v.st.w       [s35, #0], v24
    v.extract    s34, v15, #0
    s.cmp.ge     s35, s33, s31
    v.movi       v24, #0
    v.st.w       [s36, #0], v26
    v.splat      v26, s34
    v.add        v36, v26, v23
    v.st.w       [s37, #0], v25
    v.sub        v25, v15, v36
    v.reduce.or  s36, v25
    v.st.w       [s38, #0], v28
    s.cmp.eq     s37, s36, s31
    s.cmp.ge     s36, s34, s31
    v.st.w       [s39, #0], v19
    s.and        s38, s37, s36
    s.and        s36, s38, s35
    v.st.w       [s40, #0], v30
    fence.acq_rel.device
    v.extract    s37, v13, #0
    v.extract    s38, v14, #0
    v.splat      v19, s37
    v.splat      v25, s38
    s.cmp.ge     s39, s37, s31
    v.add        v26, v19, v23
    v.add        v19, v25, v23
    v.insert     v22, s36, #0
    v.sub        v25, v13, v26
    v.sub        v26, v14, v19
    v.insert     v24, s34, #0
    v.reduce.or  s34, v25
    v.reduce.or  s36, v26
    s.cmp.eq     s40, s34, s31
    v.extract    s34, v12, #0
    s.and        s41, s40, s39
    v.splat      v19, s34
    s.cmp.eq     s39, s36, s31
    s.cmp.ge     s36, s38, s31
    s.and        s40, s41, s35
    v.add        v25, v19, v23
    s.and        s41, s39, s36
    v.insert     v22, s40, #1
    v.sub        v19, v12, v25
    s.and        s36, s41, s35
    v.insert     v24, s37, #1
    v.extract    s37, v11, #0
    v.reduce.or  s39, v19
    v.splat      v19, s37
    s.cmp.eq     s40, s39, s31
    s.cmp.ge     s39, s34, s31
    v.add        v25, v19, v23
    s.and        s41, s40, s39
    v.insert     v22, s36, #2
    v.sub        v19, v11, v25
    s.and        s36, s41, s35
    v.insert     v24, s38, #2
    v.extract    s38, v10, #0
    v.reduce.or  s39, v19
    v.splat      v19, s38
    s.cmp.eq     s40, s39, s31
    s.cmp.ge     s39, s37, s31
    v.add        v25, v19, v23
    s.and        s31, s40, s39
    v.insert     v22, s36, #3
    v.sub        v19, v10, v25
    s.and        s36, s31, s35
    v.insert     v24, s34, #3
    v.extract    s31, v5, #0
    v.reduce.or  s34, v19
    v.splat      v19, s31
    s.movz       s39, #0
    v.insert     v22, s36, #4
    v.add        v25, v19, v23
    s.cmp.eq     s36, s34, s39
    s.cmp.ge     s34, s38, s39
    v.insert     v24, s37, #4
    v.extract    s37, v1, #0
    v.sub        v19, v5, v25
    s.and        s40, s36, s34
    v.splat      v25, s37
    v.reduce.or  s34, v19
    s.cmp.ge     s36, s31, s39
    s.cmp.eq     s41, s34, s39
    s.and        s34, s40, s35
    v.add        v19, v25, v23
    s.and        s40, s41, s36
    v.insert     v22, s34, #5
    v.sub        v23, v1, v19
    s.and        s34, s40, s35
    v.insert     v24, s38, #5
    v.reduce.or  s36, v23
    s.cmp.ge     s38, s37, s39
    s.cmp.eq     s40, s36, s39
    v.insert     v22, s34, #6
    s.and        s34, s40, s38
    v.insert     v24, s31, #6
    s.and        s31, s34, s35
    s.add        s34, s5, s29
    v.insert     v22, s31, #7
    s.addi       s31, s32, #8704                 // TensorMap 0: W's rows for a transposed FP8 B
    .li       s35, #2147483647
    s.movz       s36, #1
    .li       s38, #137438953488
    .li       s39, #7705171329024
    v.insert     v24, s37, #7
    s.addi       s37, s32, #8960
    s.addi       s40, s32, #9984                 // TensorMap 1: the gathered fallback B tile
    s.st.d       [s31, #0], s34
    s.movz       s34, #32
    s.st.d       [s31, #8], s35
    s.movz       s35, #16
    s.st.d       [s31, #16], s33
    s.st.d       [s31, #48], s12
    s.st.d       [s31, #56], s36
    .li       s41, #68719476768
    s.st.d       [s31, #88], s38
    s.st.d       [s31, #104], s39
    fence.release.device
    s.addi       s38, s32, #9472
    td.load      d0, [s31]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s31, s32, #10240                // TensorMap 2: the gathered fallback B tile
    s.st.d       [s40, #0], s37
    s.st.d       [s40, #8], s34
    s.st.d       [s40, #16], s35
    s.st.d       [s40, #48], s35
    s.st.d       [s40, #56], s36
    s.st.d       [s40, #88], s41
    s.st.d       [s40, #104], s39
    fence.release.device
    td.load      d1, [s40]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s40, #0
    s.st.d       [s31, #0], s38
    s.st.d       [s31, #8], s34
    s.st.d       [s31, #16], s35
    v.extract    s38, v22, #0
    s.st.d       [s31, #48], s35
    s.st.d       [s31, #56], s36
    s.st.d       [s31, #88], s41
    s.st.d       [s31, #104], s39
    fence.release.device
    td.load      d2, [s31]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s38, x8dot_done_30
    s.addi       s31, s32, #8192
    s.addi       s35, s40, #0
    v.ld.w       v19, [s31, #0]
    s.add        s31, s5, s29
x8dot_row_31:
    s.addi       s36, s33, #0
    v.movi       v23, #0
    s.sub        s39, s36, s35
    s.add        s36, s31, s35
    v.splat      v25, s39
    s.shli       s39, s35, #4
    v.cmp.gt     p1, v25, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s36, v19]            // index is in elements (ISA sec 9.1)
    s.add        s36, s37, s39
    s.addi       s39, s35, #1
    v.st.b       [s36, #0], v23
    fence.acq_rel.device
    s.mov        s35, s39
    s.cmp.lt     s36, s35, s34
    br.nz        s36, x8dot_row_31
x8dot_done_30:
    v.splat      v19, s38
    v.movi       v23, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s34, v24, #0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s35, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s35, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s35, s31          // predicated off still completes once (ISA sec 9A.3)
    v.extract    s34, v22, #1
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s34, x8dot_done_32
    s.movz       s35, #0
    s.addi       s36, s32, #8256
    s.addi       s37, s35, #0
    v.ld.w       v19, [s36, #0]
    s.add        s35, s5, s29
    s.addi       s36, s32, #9472
x8dot_row_33:
    s.addi       s38, s33, #0
    v.movi       v23, #0
    s.sub        s39, s38, s37
    s.add        s38, s35, s37
    v.splat      v25, s39
    s.shli       s39, s37, #4
    v.cmp.gt     p1, v25, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s38, v19]            // index is in elements (ISA sec 9.1)
    s.add        s38, s36, s39
    s.addi       s39, s37, #1
    s.movz       s40, #32
    v.st.b       [s38, #0], v23
    fence.acq_rel.device
    s.mov        s37, s39
    s.cmp.lt     s38, s37, s40
    br.nz        s38, x8dot_row_33
x8dot_done_32:
    v.extract    s35, v29, #0
    v.splat      v19, s34
    v.splat      v23, s35
    v.movi       v25, #0
    mb.arm       s34, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    vf.max.ieee  v26, v23, v0
    s.movz       s35, #0
    v.extract    s36, v24, #1
    v.cmp.ne     p1, v19, v25
    v.cmp.eq     p2, v19, v25
    v.rcp.approx v19, v26                        // ISA 8.8: <= 2**-22 relative
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s37, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s34          // predicated off still completes once (ISA sec 9A.3)
    s.addi       s35, s32, #0
    s.addi       s36, s32, #10496                // 512 bytes of repack scratch
    v.ld.w       v23, [s35, #0]
    v.movi       v25, #24
    v.movi       v28, #128
    vf.fms       v30, v26, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s35, s36, #0
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v23, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v26, v23
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #1
    v.splat      v19, s35
    s.addi       s35, s32, #64
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #32
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #2
    v.splat      v19, s35
    s.addi       s35, s32, #128
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #64
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #3
    v.splat      v19, s35
    s.addi       s35, s32, #192
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #96
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #4
    v.splat      v19, s35
    s.addi       s35, s32, #256
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #128
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #5
    v.splat      v19, s35
    s.addi       s35, s32, #320
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #160
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #6
    v.splat      v19, s35
    s.addi       s35, s32, #384
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #192
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #7
    v.splat      v19, s35
    s.addi       s35, s32, #448
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #224
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #8
    v.splat      v19, s35
    s.addi       s35, s32, #512
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #256
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #9
    v.splat      v19, s35
    s.addi       s35, s32, #576
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #288
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #10
    v.splat      v19, s35
    s.addi       s35, s32, #640
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #320
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #11
    v.splat      v19, s35
    s.addi       s35, s32, #704
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #352
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #12
    v.splat      v19, s35
    s.addi       s35, s32, #768
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #384
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #13
    v.splat      v19, s35
    s.addi       s35, s32, #832
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #416
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #14
    v.splat      v19, s35
    s.addi       s35, s32, #896
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #448
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #15
    v.splat      v19, s35
    s.addi       s35, s32, #960
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #480
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #0
    v.splat      v19, s35
    s.addi       s35, s32, #1024
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #16
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #1
    v.splat      v19, s35
    s.addi       s35, s32, #1088
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #48
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #2
    v.splat      v19, s35
    s.addi       s35, s32, #1152
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #80
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #3
    v.splat      v19, s35
    s.addi       s35, s32, #1216
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #112
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #4
    v.splat      v19, s35
    s.addi       s35, s32, #1280
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #144
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #5
    v.splat      v19, s35
    s.addi       s35, s32, #1344
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #176
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #6
    v.splat      v19, s35
    s.addi       s35, s32, #1408
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #208
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #7
    v.splat      v19, s35
    s.addi       s35, s32, #1472
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #240
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #8
    v.splat      v19, s35
    s.addi       s35, s32, #1536
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #272
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #9
    v.splat      v19, s35
    s.addi       s35, s32, #1600
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #304
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #10
    v.splat      v19, s35
    s.addi       s35, s32, #1664
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #336
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #11
    v.splat      v19, s35
    s.addi       s35, s32, #1728
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #368
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #12
    v.splat      v19, s35
    s.addi       s35, s32, #1792
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #400
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #13
    v.splat      v19, s35
    s.addi       s35, s32, #1856
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #432
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #14
    v.splat      v19, s35
    s.addi       s35, s32, #1920
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #464
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    v.extract    s35, v29, #15
    v.splat      v19, s35
    s.addi       s35, s32, #1984
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s35, #0]
    s.addi       s35, s36, #496
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s35, #0], v19
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s35, s36, #64
    v.ld.w       v19, [s36, #0]
    v.mov        v56, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s36, #128
    v.mov        v57, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s36, #192
    v.mov        v58, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s36, #256
    v.mov        v59, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s36, #320
    v.mov        v60, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s35, #0]
    s.addi       s35, s36, #384
    s.addi       s37, s36, #448
    v.mov        v61, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s35, #0]
    v.extract    s35, v22, #2
    v.mov        v62, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s37, #0]
    v.mov        v63, v19                        // hand off through the shared window (sec 7.3)
    mb.wait      s31
    mb.arm       s36, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s36
    mb.wait      s36
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s35, x8dot_done_34
    s.movz       s37, #0
    s.addi       s38, s32, #8320
    s.addi       s39, s37, #0
    v.ld.w       v19, [s38, #0]
    s.add        s37, s5, s29
    s.addi       s38, s32, #8960
x8dot_row_35:
    s.addi       s40, s33, #0
    v.movi       v23, #0
    s.sub        s41, s40, s39
    s.add        s40, s37, s39
    v.splat      v26, s41
    s.shli       s41, s39, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s40, v19]            // index is in elements (ISA sec 9.1)
    s.add        s40, s38, s41
    s.addi       s41, s39, #1
    s.movz       s42, #32
    v.st.b       [s40, #0], v23
    fence.acq_rel.device
    s.mov        s39, s41
    s.cmp.lt     s40, s39, s42
    br.nz        s40, x8dot_row_35
x8dot_done_34:
    v.splat      v19, s35
    v.movi       v23, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    v.extract    s38, v24, #2
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s39, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s39, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s39, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s38, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v22, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s38
    mb.wait      s38
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s39, x8dot_done_36
    s.addi       s40, s32, #8384
    s.addi       s41, s37, #0
    v.ld.w       v19, [s40, #0]
    s.add        s40, s5, s29
    s.addi       s42, s32, #9472
x8dot_row_37:
    s.addi       s43, s33, #0
    v.movi       v23, #0
    s.sub        s44, s43, s41
    s.add        s43, s40, s41
    v.splat      v26, s44
    s.shli       s44, s41, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s43, v19]            // index is in elements (ISA sec 9.1)
    s.add        s43, s42, s44
    s.addi       s44, s41, #1
    s.movz       s45, #32
    v.st.b       [s43, #0], v23
    fence.acq_rel.device
    s.mov        s41, s44
    s.cmp.lt     s43, s41, s45
    br.nz        s43, x8dot_row_37
x8dot_done_36:
    v.splat      v19, s39
    v.movi       v23, #0
    mb.arm       s39, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s40, v24, #3
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s41, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s40, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v22, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s40
    mb.wait      s40
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s41, x8dot_done_38
    s.addi       s42, s32, #8448
    s.addi       s43, s37, #0
    v.ld.w       v19, [s42, #0]
    s.add        s37, s5, s29
    s.addi       s42, s32, #8960
x8dot_row_39:
    s.addi       s44, s33, #0
    v.movi       v23, #0
    s.sub        s45, s44, s43
    s.add        s44, s37, s43
    v.splat      v26, s45
    s.shli       s45, s43, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s44, v19]            // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.addi       s45, s43, #1
    s.movz       s46, #32
    v.st.b       [s44, #0], v23
    fence.acq_rel.device
    s.mov        s43, s45
    s.cmp.lt     s44, s43, s46
    br.nz        s44, x8dot_row_39
x8dot_done_38:
    v.splat      v19, s41
    v.movi       v23, #0
    mb.arm       s37, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    v.extract    s42, v24, #4
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s43, s37            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s37          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s42, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v22, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s42
    mb.wait      s42
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s43, x8dot_done_40
    s.addi       s44, s32, #8512
    s.addi       s45, s41, #0
    v.ld.w       v19, [s44, #0]
    s.add        s44, s5, s29
    s.addi       s46, s32, #9472
x8dot_row_41:
    s.addi       s47, s33, #0
    v.movi       v23, #0
    s.sub        s48, s47, s45
    s.add        s47, s44, s45
    v.splat      v26, s48
    s.shli       s48, s45, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s47, v19]            // index is in elements (ISA sec 9.1)
    s.add        s47, s46, s48
    s.addi       s48, s45, #1
    s.movz       s49, #32
    v.st.b       [s47, #0], v23
    fence.acq_rel.device
    s.mov        s45, s48
    s.cmp.lt     s47, s45, s49
    br.nz        s47, x8dot_row_41
x8dot_done_40:
    v.splat      v19, s43
    v.movi       v23, #0
    mb.arm       s43, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s44, v24, #5
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s45, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s37
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v22, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s44
    mb.wait      s44
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s45, x8dot_done_42
    s.addi       s46, s32, #8576
    s.addi       s47, s41, #0
    v.ld.w       v19, [s46, #0]
    s.add        s41, s5, s29
    s.addi       s46, s32, #8960
x8dot_row_43:
    s.addi       s48, s33, #0
    v.movi       v23, #0
    s.sub        s49, s48, s47
    s.add        s48, s41, s47
    v.splat      v26, s49
    s.shli       s49, s47, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s48, v19]            // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s49
    s.addi       s49, s47, #1
    s.movz       s50, #32
    v.st.b       [s48, #0], v23
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s48, s47, s50
    br.nz        s48, x8dot_row_43
x8dot_done_42:
    v.splat      v19, s45
    v.movi       v23, #0
    mb.arm       s41, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    v.extract    s46, v24, #6
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s47, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s47, s41            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s47, s41          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s46, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v22, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s46
    mb.wait      s46
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s47, x8dot_done_44
    s.addi       s48, s32, #8640
    s.addi       s49, s45, #0
    v.ld.w       v19, [s48, #0]
    s.add        s48, s5, s29
    s.addi       s50, s32, #9472
x8dot_row_45:
    s.addi       s51, s33, #0
    v.movi       v23, #0
    s.sub        s52, s51, s49
    s.add        s51, s48, s49
    v.splat      v26, s52
    s.shli       s52, s49, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s51, v19]            // index is in elements (ISA sec 9.1)
    s.add        s51, s50, s52
    s.addi       s52, s49, #1
    s.movz       s53, #32
    v.st.b       [s51, #0], v23
    fence.acq_rel.device
    s.mov        s49, s52
    s.cmp.lt     s51, s49, s53
    br.nz        s51, x8dot_row_45
x8dot_done_44:
    v.splat      v19, s47
    v.movi       v23, #0
    mb.arm       s47, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s48, v24, #7
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s49, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s49, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s48, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v22, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s48
    mb.wait      s48
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s49, x8dot_done_46
    s.addi       s50, s32, #8192
    s.add        s51, s5, s29
    s.addi       s52, s45, #0
    v.ld.w       v19, [s50, #0]
    s.addi       s45, s51, #32
    s.addi       s50, s32, #8960
x8dot_row_47:
    s.addi       s51, s33, #-32
    v.movi       v23, #0
    s.sub        s53, s51, s52
    s.add        s51, s45, s52
    v.splat      v26, s53
    s.shli       s53, s52, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s51, v19]            // index is in elements (ISA sec 9.1)
    s.add        s51, s50, s53
    s.addi       s53, s52, #1
    s.movz       s54, #32
    v.st.b       [s51, #0], v23
    fence.acq_rel.device
    s.mov        s52, s53
    s.cmp.lt     s51, s52, s54
    br.nz        s51, x8dot_row_47
x8dot_done_46:
    v.splat      v19, s49
    v.movi       v23, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    v.extract    s50, v24, #0
    s.movz       s51, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s52, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s52, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s52, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s50, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v22, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s50
    mb.wait      s50
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s52, x8dot_done_48
    s.addi       s53, s32, #8256
    s.add        s54, s5, s29
    s.addi       s55, s49, #0
    v.ld.w       v19, [s53, #0]
    s.addi       s53, s54, #32
    s.addi       s54, s32, #9472
x8dot_row_49:
    s.addi       s56, s33, #-32
    v.movi       v23, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v26, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s56, v19]            // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    v.st.b       [s56, #0], v23
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s51
    br.nz        s56, x8dot_row_49
x8dot_done_48:
    v.splat      v19, s52
    v.extract    s52, v29, #0
    v.movi       v23, #0
    v.splat      v26, s52
    mb.arm       s52, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s53, v24, #1
    vf.max.ieee  v30, v26, v0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s54, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s54, s52            // predicated off still completes once (ISA sec 9A.3)
    s.addi       s49, s32, #2048
    v.rcp.approx v19, v30                        // ISA 8.8: <= 2**-22 relative
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s52          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v23, [s49, #0]
    s.addi       s49, s32, #11008                // 512 bytes of repack scratch
    s.addi       s51, s49, #0
    vf.fms       v26, v30, v19, v20
    vf.fms       v36, v19, v26, v19
    s.addi       s53, s32, #2112
    vf.neg       v26, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v36, v26, v19
    vf.mul       v19, v23, v36                   // a/y: faithful quotient
    vf.fms       v26, v19, v30, v23
    vf.fms       v23, v26, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #1
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #32
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #2176
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #2
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #64
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #2240
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #3
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #96
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #2304
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #4
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #128
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #2368
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #5
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #160
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #2432
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #6
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #192
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #2496
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #7
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #224
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #2560
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #8
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #256
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #2624
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #9
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #288
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #2688
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #10
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #320
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #2752
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #11
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #352
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #2816
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #12
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #384
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #2880
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #13
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #416
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #2944
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #14
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #448
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3008
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #15
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #480
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3072
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #0
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #16
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3136
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #1
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #48
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3200
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #2
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #80
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3264
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #3
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #112
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3328
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #4
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #144
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3392
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #5
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #176
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3456
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #6
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #208
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3520
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #7
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #240
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3584
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #8
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #272
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3648
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #9
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #304
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3712
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #10
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #336
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3776
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #11
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #368
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3840
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #12
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #400
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3904
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #13
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #432
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #3968
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #14
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #464
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s53, s32, #4032
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    v.extract    s51, v29, #15
    v.splat      v19, s51
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s53, #0]
    s.addi       s51, s49, #496
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    s.addi       s53, s49, #64
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s51, #0], v19
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s51, s49, #128
    v.ld.w       v19, [s49, #0]
    v.mov        v56, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s53, #0]
    s.addi       s53, s49, #192
    v.mov        v57, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s51, #0]
    s.addi       s51, s49, #256
    v.mov        v58, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s53, #0]
    s.addi       s53, s49, #320
    v.mov        v59, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s51, #0]
    s.addi       s51, s49, #384
    s.addi       s54, s49, #448
    v.mov        v60, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s53, #0]
    v.extract    s49, v22, #2
    v.mov        v61, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s51, #0]
    v.mov        v62, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s54, #0]
    v.mov        v63, v19                        // hand off through the shared window (sec 7.3)
    mb.wait      s45
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s51
    mb.wait      s51
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s49, x8dot_done_50
    s.movz       s53, #0
    s.addi       s54, s32, #8320
    s.add        s55, s5, s29
    s.addi       s56, s53, #0
    v.ld.w       v19, [s54, #0]
    s.addi       s53, s55, #32
    s.addi       s54, s32, #8960
x8dot_row_51:
    s.addi       s55, s33, #-32
    v.movi       v23, #0
    s.sub        s57, s55, s56
    s.add        s55, s53, s56
    v.splat      v26, s57
    s.shli       s57, s56, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s55, v19]            // index is in elements (ISA sec 9.1)
    s.add        s55, s54, s57
    s.addi       s57, s56, #1
    s.movz       s58, #32
    v.st.b       [s55, #0], v23
    fence.acq_rel.device
    s.mov        s56, s57
    s.cmp.lt     s55, s56, s58
    br.nz        s55, x8dot_row_51
x8dot_done_50:
    v.splat      v19, s49
    v.movi       v23, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    v.extract    s54, v24, #2
    s.movz       s55, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s56, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s56, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s56, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s54, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v22, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s54
    mb.wait      s54
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s56, x8dot_done_52
    s.addi       s57, s32, #8384
    s.add        s58, s5, s29
    s.addi       s59, s53, #0
    v.ld.w       v19, [s57, #0]
    s.addi       s57, s58, #32
    s.addi       s58, s32, #9472
x8dot_row_53:
    s.addi       s60, s33, #-32
    v.movi       v23, #0
    s.sub        s31, s60, s59
    s.add        s34, s57, s59
    v.splat      v26, s31
    s.shli       s31, s59, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s34, v19]            // index is in elements (ISA sec 9.1)
    s.add        s34, s58, s31
    s.addi       s31, s59, #1
    v.st.b       [s34, #0], v23
    fence.acq_rel.device
    s.mov        s59, s31
    s.cmp.lt     s31, s59, s55
    br.nz        s31, x8dot_row_53
x8dot_done_52:
    v.splat      v19, s56
    v.movi       v23, #0
    mb.arm       s31, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s34, v24, #3
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s35, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s35, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v22, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s34
    mb.wait      s34
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s35, x8dot_done_54
    s.addi       s36, s32, #8448
    s.add        s37, s5, s29
    s.addi       s38, s53, #0
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s37, #32
    s.addi       s37, s32, #8960
x8dot_row_55:
    s.addi       s39, s33, #-32
    v.movi       v23, #0
    s.sub        s40, s39, s38
    s.add        s39, s36, s38
    v.splat      v26, s40
    s.shli       s40, s38, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s39, v19]            // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.addi       s40, s38, #1
    s.movz       s41, #32
    v.st.b       [s39, #0], v23
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s39, s38, s41
    br.nz        s39, x8dot_row_55
x8dot_done_54:
    v.splat      v19, s35
    v.movi       v23, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    v.extract    s37, v24, #4
    s.movz       s38, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s39, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s39, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s39, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s37, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v22, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s37
    mb.wait      s37
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s39, x8dot_done_56
    s.addi       s40, s32, #8512
    s.add        s41, s5, s29
    s.addi       s42, s36, #0
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s41, #32
    s.addi       s41, s32, #9472
x8dot_row_57:
    s.addi       s43, s33, #-32
    v.movi       v23, #0
    s.sub        s44, s43, s42
    s.add        s43, s40, s42
    v.splat      v26, s44
    s.shli       s44, s42, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s43, v19]            // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.addi       s44, s42, #1
    v.st.b       [s43, #0], v23
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s43, s42, s38
    br.nz        s43, x8dot_row_57
x8dot_done_56:
    v.splat      v19, s39
    v.movi       v23, #0
    mb.arm       s39, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s40, v24, #5
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s41, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s41, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v22, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s38
    mb.wait      s38
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s40, x8dot_done_58
    s.addi       s41, s32, #8576
    s.add        s42, s5, s29
    s.addi       s43, s36, #0
    v.ld.w       v19, [s41, #0]
    s.addi       s36, s42, #32
    s.addi       s41, s32, #8960
x8dot_row_59:
    s.addi       s42, s33, #-32
    v.movi       v23, #0
    s.sub        s44, s42, s43
    s.add        s42, s36, s43
    v.splat      v26, s44
    s.shli       s44, s43, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s42, v19]            // index is in elements (ISA sec 9.1)
    s.add        s42, s41, s44
    s.addi       s44, s43, #1
    s.movz       s45, #32
    v.st.b       [s42, #0], v23
    fence.acq_rel.device
    s.mov        s43, s44
    s.cmp.lt     s42, s43, s45
    br.nz        s42, x8dot_row_59
x8dot_done_58:
    v.splat      v19, s40
    v.movi       v23, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.extract    s41, v24, #6
    s.movz       s42, #32
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s43, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s41, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v22, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s41
    mb.wait      s41
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s43, x8dot_done_60
    s.addi       s44, s32, #8640
    s.add        s45, s5, s29
    s.addi       s46, s40, #0
    v.ld.w       v19, [s44, #0]
    s.addi       s44, s45, #32
    s.addi       s45, s32, #9472
x8dot_row_61:
    s.addi       s47, s33, #-32
    v.movi       v23, #0
    s.sub        s48, s47, s46
    s.add        s47, s44, s46
    v.splat      v26, s48
    s.shli       s48, s46, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s47, v19]            // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s48
    s.addi       s48, s46, #1
    v.st.b       [s47, #0], v23
    fence.acq_rel.device
    s.mov        s46, s48
    s.cmp.lt     s47, s46, s42
    br.nz        s47, x8dot_row_61
x8dot_done_60:
    v.splat      v19, s43
    v.movi       v23, #0
    mb.arm       s43, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s44, v24, #7
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s45, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s45, s43            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v22, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s42
    mb.wait      s42
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s44, x8dot_done_62
    s.addi       s45, s32, #8192
    s.add        s46, s5, s29
    s.addi       s47, s40, #0
    v.ld.w       v19, [s45, #0]
    s.addi       s40, s46, #64
    s.addi       s45, s32, #8960
x8dot_row_63:
    s.addi       s46, s33, #-64
    v.movi       v23, #0
    s.sub        s48, s46, s47
    s.add        s46, s40, s47
    v.splat      v26, s48
    s.shli       s48, s47, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s46, v19]            // index is in elements (ISA sec 9.1)
    s.add        s46, s45, s48
    s.addi       s48, s47, #1
    s.movz       s50, #32
    v.st.b       [s46, #0], v23
    fence.acq_rel.device
    s.mov        s47, s48
    s.cmp.lt     s46, s47, s50
    br.nz        s46, x8dot_row_63
x8dot_done_62:
    v.splat      v19, s44
    v.movi       v23, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    v.extract    s45, v24, #0
    s.movz       s46, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s47, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s47, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s47, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s48, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s47, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s45, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v22, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s45
    mb.wait      s45
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s47, x8dot_done_64
    s.addi       s48, s32, #8256
    s.add        s50, s5, s29
    s.addi       s51, s44, #0
    v.ld.w       v19, [s48, #0]
    s.addi       s48, s50, #64
    s.addi       s50, s32, #9472
x8dot_row_65:
    s.addi       s52, s33, #-64
    v.movi       v23, #0
    s.sub        s53, s52, s51
    s.add        s52, s48, s51
    v.splat      v26, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s52, v19]            // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    s.movz       s54, #32
    v.st.b       [s52, #0], v23
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s54
    br.nz        s52, x8dot_row_65
x8dot_done_64:
    v.splat      v19, s47
    v.extract    s47, v29, #0
    v.movi       v23, #0
    v.splat      v26, s47
    mb.arm       s47, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s48, v24, #1
    vf.max.ieee  v30, v26, v0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s50, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s50, s47            // predicated off still completes once (ISA sec 9A.3)
    s.addi       s44, s32, #4096
    v.rcp.approx v19, v30                        // ISA 8.8: <= 2**-22 relative
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s47          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v23, [s44, #0]
    s.addi       s44, s32, #11520                // 512 bytes of repack scratch
    s.addi       s46, s44, #0
    vf.fms       v26, v30, v19, v20
    vf.fms       v36, v19, v26, v19
    s.addi       s48, s32, #4160
    vf.neg       v26, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v36, v26, v19
    vf.mul       v19, v23, v36                   // a/y: faithful quotient
    vf.fms       v26, v19, v30, v23
    vf.fms       v23, v26, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #1
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #32
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #4224
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #2
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #64
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #4288
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #3
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #96
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #4352
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #4
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #128
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #4416
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #5
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #160
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #4480
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #6
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #192
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #4544
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #7
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #224
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #4608
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #8
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #256
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #4672
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #9
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #288
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #4736
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #10
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #320
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #4800
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #11
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #352
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #4864
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #12
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #384
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #4928
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #13
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #416
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #4992
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #14
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #448
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5056
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #15
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #480
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5120
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #0
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #16
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5184
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #1
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #48
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5248
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #2
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #80
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5312
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #3
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #112
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5376
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #4
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #144
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5440
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #5
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #176
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5504
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #6
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #208
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5568
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #7
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #240
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5632
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #8
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #272
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5696
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #9
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #304
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5760
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #10
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #336
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5824
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #11
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #368
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5888
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #12
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #400
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #5952
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #13
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #432
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #6016
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #14
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #464
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s48, s32, #6080
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    v.extract    s46, v29, #15
    v.splat      v19, s46
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s48, #0]
    s.addi       s46, s44, #496
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    s.addi       s48, s44, #64
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v19
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s46, s44, #128
    v.ld.w       v19, [s44, #0]
    v.mov        v56, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s48, #0]
    s.addi       s48, s44, #192
    v.mov        v57, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s46, #0]
    s.addi       s46, s44, #256
    v.mov        v58, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s48, #0]
    s.addi       s48, s44, #320
    v.mov        v59, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s46, #0]
    s.addi       s46, s44, #384
    s.addi       s50, s44, #448
    v.mov        v60, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s48, #0]
    v.extract    s44, v22, #2
    v.mov        v61, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s46, #0]
    v.mov        v62, v19                        // hand off through the shared window (sec 7.3)
    v.ld.w       v19, [s50, #0]
    v.mov        v63, v19                        // hand off through the shared window (sec 7.3)
    mb.wait      s40
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s46
    mb.wait      s46
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s44, x8dot_done_66
    s.movz       s48, #0
    s.addi       s50, s32, #8320
    s.add        s51, s5, s29
    s.addi       s52, s48, #0
    v.ld.w       v19, [s50, #0]
    s.addi       s48, s51, #64
    s.addi       s50, s32, #8960
x8dot_row_67:
    s.addi       s51, s33, #-64
    v.movi       v23, #0
    s.sub        s53, s51, s52
    s.add        s51, s48, s52
    v.splat      v26, s53
    s.shli       s53, s52, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s51, v19]            // index is in elements (ISA sec 9.1)
    s.add        s51, s50, s53
    s.addi       s53, s52, #1
    s.movz       s54, #32
    v.st.b       [s51, #0], v23
    fence.acq_rel.device
    s.mov        s52, s53
    s.cmp.lt     s51, s52, s54
    br.nz        s51, x8dot_row_67
x8dot_done_66:
    v.splat      v19, s44
    v.movi       v23, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s48, #0
    v.extract    s50, v24, #2
    s.movz       s51, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s52, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s52, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s50, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v22, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s50
    mb.wait      s50
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s52, x8dot_done_68
    s.addi       s53, s32, #8384
    s.add        s54, s5, s29
    s.addi       s55, s48, #0
    v.ld.w       v19, [s53, #0]
    s.addi       s53, s54, #64
    s.addi       s54, s32, #9472
x8dot_row_69:
    s.addi       s56, s33, #-64
    v.movi       v23, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v26, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s56, v19]            // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    s.movz       s58, #32
    v.st.b       [s56, #0], v23
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s58
    br.nz        s56, x8dot_row_69
x8dot_done_68:
    v.splat      v19, s52
    v.movi       v23, #0
    mb.arm       s52, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s53, v24, #3
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s54, s48                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s54, s52            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v22, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s51
    mb.wait      s51
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s53, x8dot_done_70
    s.addi       s54, s32, #8448
    s.add        s55, s5, s29
    s.addi       s56, s48, #0
    v.ld.w       v19, [s54, #0]
    s.addi       s48, s55, #64
    s.addi       s54, s32, #8960
x8dot_row_71:
    s.addi       s55, s33, #-64
    v.movi       v23, #0
    s.sub        s57, s55, s56
    s.add        s55, s48, s56
    v.splat      v26, s57
    s.shli       s57, s56, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s55, v19]            // index is in elements (ISA sec 9.1)
    s.add        s55, s54, s57
    s.addi       s57, s56, #1
    s.movz       s58, #32
    v.st.b       [s55, #0], v23
    fence.acq_rel.device
    s.mov        s56, s57
    s.cmp.lt     s55, s56, s58
    br.nz        s55, x8dot_row_71
x8dot_done_70:
    v.splat      v19, s53
    v.movi       v23, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    v.extract    s54, v24, #4
    s.movz       s55, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s56, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s56, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s56, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s54, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v22, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s54
    mb.wait      s54
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s56, x8dot_done_72
    s.addi       s57, s32, #8512
    s.add        s58, s5, s29
    s.addi       s59, s53, #0
    v.ld.w       v19, [s57, #0]
    s.addi       s57, s58, #64
    s.addi       s58, s32, #9472
x8dot_row_73:
    s.addi       s60, s33, #-64
    v.movi       v23, #0
    s.sub        s31, s60, s59
    s.add        s34, s57, s59
    v.splat      v26, s31
    s.shli       s31, s59, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s34, v19]            // index is in elements (ISA sec 9.1)
    s.add        s34, s58, s31
    s.addi       s31, s59, #1
    s.movz       s35, #32
    v.st.b       [s34, #0], v23
    fence.acq_rel.device
    s.mov        s59, s31
    s.cmp.lt     s31, s59, s35
    br.nz        s31, x8dot_row_73
x8dot_done_72:
    v.splat      v19, s56
    v.movi       v23, #0
    mb.arm       s31, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s34, v24, #5
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s35, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s35, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s35, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v22, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s34
    mb.wait      s34
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s35, x8dot_done_74
    s.addi       s36, s32, #8576
    s.add        s37, s5, s29
    s.addi       s38, s53, #0
    v.ld.w       v19, [s36, #0]
    s.addi       s36, s37, #64
    s.addi       s37, s32, #8960
x8dot_row_75:
    s.addi       s39, s33, #-64
    v.movi       v23, #0
    s.sub        s40, s39, s38
    s.add        s39, s36, s38
    v.splat      v26, s40
    s.shli       s40, s38, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s39, v19]            // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.addi       s40, s38, #1
    s.movz       s41, #32
    v.st.b       [s39, #0], v23
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s39, s38, s41
    br.nz        s39, x8dot_row_75
x8dot_done_74:
    v.splat      v19, s35
    v.movi       v23, #0
    mb.arm       s35, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    v.extract    s37, v24, #6
    s.movz       s38, #64
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s39, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s39, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s39, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s37, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v22, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s37
    mb.wait      s37
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s39, x8dot_done_76
    s.addi       s40, s32, #8640
    s.add        s41, s5, s29
    s.addi       s42, s36, #0
    v.ld.w       v19, [s40, #0]
    s.addi       s40, s41, #64
    s.addi       s41, s32, #9472
x8dot_row_77:
    s.addi       s43, s33, #-64
    v.movi       v23, #0
    s.sub        s44, s43, s42
    s.add        s43, s40, s42
    v.splat      v26, s44
    s.shli       s44, s42, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s43, v19]            // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.addi       s44, s42, #1
    s.movz       s45, #32
    v.st.b       [s43, #0], v23
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s43, s42, s45
    br.nz        s43, x8dot_row_77
x8dot_done_76:
    v.splat      v19, s39
    v.movi       v23, #0
    mb.arm       s39, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s40, v24, #7
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s41, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s41, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v22, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s38
    mb.wait      s38
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s40, x8dot_done_78
    s.addi       s41, s32, #8192
    s.add        s42, s5, s29
    s.addi       s43, s36, #0
    v.ld.w       v19, [s41, #0]
    s.addi       s36, s42, #96
    s.addi       s41, s32, #8960
x8dot_row_79:
    s.addi       s42, s33, #-96
    v.movi       v23, #0
    s.sub        s44, s42, s43
    s.add        s42, s36, s43
    v.splat      v26, s44
    s.shli       s44, s43, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s42, v19]            // index is in elements (ISA sec 9.1)
    s.add        s42, s41, s44
    s.addi       s44, s43, #1
    s.movz       s45, #32
    v.st.b       [s42, #0], v23
    fence.acq_rel.device
    s.mov        s43, s44
    s.cmp.lt     s42, s43, s45
    br.nz        s42, x8dot_row_79
x8dot_done_78:
    v.splat      v19, s40
    v.movi       v23, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.extract    s41, v24, #0
    s.movz       s42, #96
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s43, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s41, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v22, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s41
    mb.wait      s41
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s43, x8dot_done_80
    s.addi       s44, s32, #8256
    s.add        s45, s5, s29
    s.addi       s46, s40, #0
    v.ld.w       v19, [s44, #0]
    s.addi       s44, s45, #96
    s.addi       s45, s32, #9472
x8dot_row_81:
    s.addi       s47, s33, #-96
    v.movi       v23, #0
    s.sub        s49, s47, s46
    s.add        s47, s44, s46
    v.splat      v26, s49
    s.shli       s49, s46, #4
    v.cmp.gt     p1, v26, v23
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v23, [s47, v19]            // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s49
    s.addi       s49, s46, #1
    s.movz       s50, #32
    v.st.b       [s47, #0], v23
    fence.acq_rel.device
    s.mov        s46, s49
    s.cmp.lt     s47, s46, s50
    br.nz        s47, x8dot_row_81
x8dot_done_80:
    v.splat      v19, s43
    v.extract    s43, v29, #0
    v.movi       v23, #0
    v.splat      v26, s43
    mb.arm       s43, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s44, v24, #1
    vf.max.ieee  v30, v26, v0
    v.cmp.ne     p1, v19, v23
    v.cmp.eq     p2, v19, v23
    s.mov        s45, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s45, s43            // predicated off still completes once (ISA sec 9A.3)
    s.addi       s40, s32, #6144
    v.rcp.approx v19, v30                        // ISA 8.8: <= 2**-22 relative
    s.mov        s45, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s45, s43          // predicated off still completes once (ISA sec 9A.3)
    v.ld.w       v23, [s40, #0]
    s.addi       s40, s32, #12032                // 512 bytes of repack scratch
    s.addi       s42, s40, #0
    vf.fms       v26, v30, v19, v20
    vf.fms       v36, v19, v26, v19
    s.addi       s44, s32, #6208
    vf.neg       v26, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v36, v26, v19
    vf.mul       v19, v23, v36                   // a/y: faithful quotient
    vf.fms       v26, v19, v30, v23
    vf.fms       v23, v26, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #1
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #32
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #6272
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #2
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #64
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #6336
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #3
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #96
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #6400
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #4
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #128
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #6464
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #5
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #160
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #6528
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #6
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #192
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #6592
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #7
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #224
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #6656
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #8
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #256
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #6720
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #9
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #288
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #6784
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #10
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #320
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #6848
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #11
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #352
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #6912
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #12
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #384
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #6976
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #13
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #416
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7040
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #14
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #448
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7104
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #15
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #480
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7168
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #0
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #16
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7232
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #1
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #48
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7296
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #2
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #80
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7360
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #3
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #112
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7424
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #4
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #144
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7488
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #5
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #176
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7552
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #6
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #208
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7616
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #7
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #240
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7680
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #8
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #272
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7744
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #9
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #304
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7808
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #10
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #336
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7872
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #11
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #368
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #7936
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #12
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #400
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #8000
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #13
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #432
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #8064
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #14
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v19, v23                        // ISA 8.8: <= 2**-22 relative
    v.ld.w       v26, [s44, #0]
    s.addi       s42, s40, #464
    vf.fms       v30, v23, v19, v20
    vf.fms       v36, v19, v30, v19
    s.addi       s44, s32, #8128
    vf.neg       v30, v36                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v30, v30
    @p1 v.sel        v36, v30, v19
    vf.mul       v19, v26, v36                   // a/y: faithful quotient
    vf.fms       v30, v19, v23, v26
    vf.fms       v23, v30, v36, v19
    vf.neg       v26, v23                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v23, v26, v19
    v.lshr       v19, v23, v25
    vf.cvt.f32.e4m3 v26, v23
    v.and        v23, v19, v28
    v.or         v19, v26, v23                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v19
    v.extract    s42, v29, #15
    v.splat      v19, s42
    vf.max.ieee  v23, v19, v0
    v.rcp.approx v0, v23                         // ISA 8.8: <= 2**-22 relative
    v.ld.w       v19, [s44, #0]
    s.addi       s42, s40, #496
    vf.fms       v26, v23, v0, v20
    vf.fms       v20, v0, v26, v0
    vf.neg       v26, v20                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v26, v26
    @p1 v.sel        v20, v26, v0
    vf.mul       v0, v19, v20                    // a/y: faithful quotient
    s.addi       s44, s40, #64
    vf.fms       v26, v0, v23, v19
    vf.fms       v19, v26, v20, v0
    vf.neg       v20, v19                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v19, v20, v0
    v.lshr       v0, v19, v25
    vf.cvt.f32.e4m3 v20, v19
    v.and        v19, v0, v28
    v.or         v0, v20, v19                    // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s42, #0], v0
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    s.addi       s42, s40, #128
    v.ld.w       v0, [s40, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s44, #0]
    s.addi       s44, s40, #192
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s42, #0]
    s.addi       s42, s40, #256
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s44, #0]
    s.addi       s44, s40, #320
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s42, #0]
    s.addi       s42, s40, #384
    s.addi       s45, s40, #448
    v.mov        v60, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s44, #0]
    v.extract    s40, v22, #2
    v.mov        v61, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s42, #0]
    v.mov        v62, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s45, #0]
    v.mov        v63, v0                         // hand off through the shared window (sec 7.3)
    mb.wait      s36
    mb.arm       s42, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s42
    mb.wait      s42
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s40, x8dot_done_82
    s.movz       s44, #0
    s.addi       s45, s32, #8320
    s.add        s46, s5, s29
    s.addi       s47, s44, #0
    v.ld.w       v0, [s45, #0]
    s.addi       s44, s46, #96
    s.addi       s45, s32, #8960
x8dot_row_83:
    s.addi       s46, s33, #-96
    v.movi       v19, #0
    s.sub        s49, s46, s47
    s.add        s46, s44, s47
    v.splat      v20, s49
    s.shli       s49, s47, #4
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s46, v0]             // index is in elements (ISA sec 9.1)
    s.add        s46, s45, s49
    s.addi       s49, s47, #1
    s.movz       s50, #32
    v.st.b       [s46, #0], v19
    fence.acq_rel.device
    s.mov        s47, s49
    s.cmp.lt     s46, s47, s50
    br.nz        s46, x8dot_row_83
x8dot_done_82:
    v.splat      v0, s40
    v.movi       v19, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    v.extract    s45, v24, #2
    s.movz       s46, #96
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s49, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s49, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s49, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    mb.arm       s45, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v22, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s45
    mb.wait      s45
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s47, x8dot_done_84
    s.addi       s49, s32, #8384
    s.add        s50, s5, s29
    s.addi       s51, s44, #0
    v.ld.w       v0, [s49, #0]
    s.addi       s49, s50, #96
    s.addi       s50, s32, #9472
x8dot_row_85:
    s.addi       s52, s33, #-96
    v.movi       v19, #0
    s.sub        s53, s52, s51
    s.add        s52, s49, s51
    v.splat      v20, s53
    s.shli       s53, s51, #4
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s52, v0]             // index is in elements (ISA sec 9.1)
    s.add        s52, s50, s53
    s.addi       s53, s51, #1
    s.movz       s54, #32
    v.st.b       [s52, #0], v19
    fence.acq_rel.device
    s.mov        s51, s53
    s.cmp.lt     s52, s51, s54
    br.nz        s52, x8dot_row_85
x8dot_done_84:
    v.splat      v0, s47
    v.movi       v19, #0
    mb.arm       s47, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s49, v24, #3
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s50, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s50, s47            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s47          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v22, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s46
    mb.wait      s46
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s49, x8dot_done_86
    s.addi       s50, s32, #8448
    s.add        s51, s5, s29
    s.addi       s52, s44, #0
    v.ld.w       v0, [s50, #0]
    s.addi       s44, s51, #96
    s.addi       s50, s32, #8960
x8dot_row_87:
    s.addi       s51, s33, #-96
    v.movi       v19, #0
    s.sub        s53, s51, s52
    s.add        s51, s44, s52
    v.splat      v20, s53
    s.shli       s53, s52, #4
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s51, v0]             // index is in elements (ISA sec 9.1)
    s.add        s51, s50, s53
    s.addi       s53, s52, #1
    s.movz       s54, #32
    v.st.b       [s51, #0], v19
    fence.acq_rel.device
    s.mov        s52, s53
    s.cmp.lt     s51, s52, s54
    br.nz        s51, x8dot_row_87
x8dot_done_86:
    v.splat      v0, s49
    v.movi       v19, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    v.extract    s50, v24, #4
    s.movz       s51, #96
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s52, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s52, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s52, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s52, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s47
    mb.arm       s50, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s52, v22, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s50
    mb.wait      s50
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s52, x8dot_done_88
    s.addi       s53, s32, #8512
    s.add        s54, s5, s29
    s.addi       s55, s49, #0
    v.ld.w       v0, [s53, #0]
    s.addi       s53, s54, #96
    s.addi       s54, s32, #9472
x8dot_row_89:
    s.addi       s56, s33, #-96
    v.movi       v19, #0
    s.sub        s57, s56, s55
    s.add        s56, s53, s55
    v.splat      v20, s57
    s.shli       s57, s55, #4
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s56, v0]             // index is in elements (ISA sec 9.1)
    s.add        s56, s54, s57
    s.addi       s57, s55, #1
    s.movz       s58, #32
    v.st.b       [s56, #0], v19
    fence.acq_rel.device
    s.mov        s55, s57
    s.cmp.lt     s56, s55, s58
    br.nz        s56, x8dot_row_89
x8dot_done_88:
    v.splat      v0, s52
    v.movi       v19, #0
    mb.arm       s52, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s53, v24, #5
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s54, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s54, s52            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v22, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s51
    mb.wait      s51
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s53, x8dot_done_90
    s.addi       s54, s32, #8576
    s.add        s55, s5, s29
    s.addi       s56, s49, #0
    v.ld.w       v0, [s54, #0]
    s.addi       s49, s55, #96
    s.addi       s54, s32, #8960
x8dot_row_91:
    s.addi       s55, s33, #-96
    v.movi       v19, #0
    s.sub        s57, s55, s56
    s.add        s55, s49, s56
    v.splat      v20, s57
    s.shli       s57, s56, #4
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s55, v0]             // index is in elements (ISA sec 9.1)
    s.add        s55, s54, s57
    s.addi       s57, s56, #1
    s.movz       s58, #32
    v.st.b       [s55, #0], v19
    fence.acq_rel.device
    s.mov        s56, s57
    s.cmp.lt     s55, s56, s58
    br.nz        s55, x8dot_row_91
x8dot_done_90:
    v.splat      v0, s53
    v.movi       v19, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    v.extract    s54, v24, #6
    s.movz       s55, #96
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s56, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s56, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s56, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s56, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s54, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s56, v22, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s54
    mb.wait      s54
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s56, x8dot_done_92
    s.addi       s57, s32, #8640
    s.add        s58, s5, s29
    s.addi       s59, s53, #0
    v.ld.w       v0, [s57, #0]
    s.addi       s57, s58, #96
    s.addi       s58, s32, #9472
x8dot_row_93:
    s.addi       s60, s33, #-96
    v.movi       v19, #0
    s.sub        s31, s60, s59
    s.add        s34, s57, s59
    v.splat      v20, s31
    s.shli       s31, s59, #4
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s34, v0]             // index is in elements (ISA sec 9.1)
    s.add        s34, s58, s31
    s.addi       s31, s59, #1
    s.movz       s35, #32
    v.st.b       [s34, #0], v19
    fence.acq_rel.device
    s.mov        s59, s31
    s.cmp.lt     s31, s59, s35
    br.nz        s31, x8dot_row_93
x8dot_done_92:
    mb.arm       s31, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v0, s56
    v.movi       v19, #0
    v.cmp.ne     p1, v0, v19
    v.cmp.eq     p2, v0, v19
    s.mov        s33, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s33, s31            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s33, v24, #7
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s55                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s33
    mb.wait      s33
    mb.wait      s31
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s34
    mb.wait      s34
    s.addi       s35, s32, #12544
    a.vread      v0, a8, s53
    v.st.w       [s35, #0], v0
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a8, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a8, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a8, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a8, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a8, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a8, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a8, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a8, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a8, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a8, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a8, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a8, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a8, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a8, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a8, s35
    v.st.w       [s36, #0], v0
    fence.acq_rel.device
    s.addi       s35, s32, #13568
    s.movz       s36, #0
    a.vread      v0, a9, s36
    v.st.w       [s35, #0], v0
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a9, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a9, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a9, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a9, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a9, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a9, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a9, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a9, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a9, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a9, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a9, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a9, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a9, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a9, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a9, s35
    v.st.w       [s36, #0], v0
    fence.acq_rel.device
    s.addi       s35, s32, #14592
    s.movz       s36, #0
    a.vread      v0, a10, s36
    v.st.w       [s35, #0], v0
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a10, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a10, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a10, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a10, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a10, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a10, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a10, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a10, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a10, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a10, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a10, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a10, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a10, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a10, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a10, s35
    v.st.w       [s36, #0], v0
    fence.acq_rel.device
    s.addi       s35, s32, #15616
    s.movz       s36, #0
    a.vread      v0, a11, s36
    v.st.w       [s35, #0], v0
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a11, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a11, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a11, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a11, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a11, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a11, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a11, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a11, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a11, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a11, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a11, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a11, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a11, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a11, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a11, s35
    v.st.w       [s36, #0], v0
    fence.acq_rel.device
    s.addi       s35, s32, #16640
    s.movz       s36, #0
    a.vread      v0, a12, s36
    v.st.w       [s35, #0], v0
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a12, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a12, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a12, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a12, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a12, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a12, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a12, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a12, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a12, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a12, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a12, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a12, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a12, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a12, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a12, s35
    v.st.w       [s36, #0], v0
    fence.acq_rel.device
    s.addi       s35, s32, #17664
    s.movz       s36, #0
    a.vread      v0, a13, s36
    v.st.w       [s35, #0], v0
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a13, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a13, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a13, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a13, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a13, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a13, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a13, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a13, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a13, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a13, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a13, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a13, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a13, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a13, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a13, s35
    v.st.w       [s36, #0], v0
    fence.acq_rel.device
    s.addi       s35, s32, #18688
    s.movz       s36, #0
    a.vread      v0, a14, s36
    v.st.w       [s35, #0], v0
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a14, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a14, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a14, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a14, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a14, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a14, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a14, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a14, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a14, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a14, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a14, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a14, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a14, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a14, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a14, s35
    v.st.w       [s36, #0], v0
    fence.acq_rel.device
    s.addi       s35, s32, #19712
    s.movz       s36, #0
    a.vread      v0, a15, s36
    v.st.w       [s35, #0], v0
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a15, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a15, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a15, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a15, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a15, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a15, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a15, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a15, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a15, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a15, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a15, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a15, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a15, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a15, s37
    v.st.w       [s36, #0], v0
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a15, s35
    v.st.w       [s36, #0], v0
    fence.acq_rel.device
    s.addi       s35, s32, #20736
    s.movz       s36, #0
    a.vread      v0, a0, s36
    s.addi       s36, s32, #12544
    v.ld.w       v19, [s36, #0]
    v.extract    s36, v29, #0
    v.splat      v20, s36
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s35, #0], v20
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a0, s37
    s.addi       s37, s32, #12608
    v.ld.w       v19, [s37, #0]
    v.extract    s37, v29, #1
    v.splat      v20, s37
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a0, s37
    s.addi       s37, s32, #12672
    v.ld.w       v19, [s37, #0]
    v.extract    s37, v29, #2
    v.splat      v20, s37
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a0, s37
    s.addi       s37, s32, #12736
    v.ld.w       v19, [s37, #0]
    v.extract    s37, v29, #3
    v.splat      v20, s37
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a0, s37
    s.addi       s37, s32, #12800
    v.ld.w       v19, [s37, #0]
    v.extract    s37, v29, #4
    v.splat      v20, s37
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a0, s37
    s.addi       s37, s32, #12864
    v.ld.w       v19, [s37, #0]
    v.extract    s37, v29, #5
    v.splat      v20, s37
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a0, s37
    s.addi       s37, s32, #12928
    v.ld.w       v19, [s37, #0]
    v.extract    s37, v29, #6
    v.splat      v20, s37
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a0, s37
    s.addi       s37, s32, #12992
    v.ld.w       v19, [s37, #0]
    v.extract    s37, v29, #7
    v.splat      v20, s37
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a0, s37
    s.addi       s37, s32, #13056
    v.ld.w       v19, [s37, #0]
    v.extract    s37, v29, #8
    v.splat      v20, s37
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a0, s37
    s.addi       s37, s32, #13120
    v.ld.w       v19, [s37, #0]
    v.extract    s37, v29, #9
    v.splat      v20, s37
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a0, s37
    s.addi       s37, s32, #13184
    v.ld.w       v19, [s37, #0]
    v.extract    s37, v29, #10
    v.splat      v20, s37
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a0, s37
    s.addi       s37, s32, #13248
    v.ld.w       v19, [s37, #0]
    v.extract    s37, v29, #11
    v.splat      v20, s37
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a0, s37
    s.addi       s37, s32, #13312
    v.ld.w       v19, [s37, #0]
    v.extract    s37, v29, #12
    v.splat      v20, s37
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a0, s37
    s.addi       s37, s32, #13376
    v.ld.w       v19, [s37, #0]
    v.extract    s37, v29, #13
    v.splat      v20, s37
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a0, s37
    s.addi       s37, s32, #13440
    v.ld.w       v19, [s37, #0]
    v.extract    s37, v29, #14
    v.splat      v20, s37
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v20, v0, v19
    v.st.w       [s36, #0], v20
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a0, s35
    s.addi       s35, s32, #13504
    v.ld.w       v19, [s35, #0]
    v.extract    s35, v29, #15
    v.splat      v20, s35
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v17
    vf.add       v17, v0, v19
    v.st.w       [s36, #0], v17
    fence.acq_rel.device
    s.addi       s35, s32, #21760
    s.movz       s36, #0
    a.vread      v0, a1, s36
    s.addi       s36, s32, #13568
    v.ld.w       v17, [s36, #0]
    v.extract    s36, v29, #0
    v.splat      v19, s36
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s35, #0], v19
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a1, s37
    s.addi       s37, s32, #13632
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #1
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a1, s37
    s.addi       s37, s32, #13696
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #2
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a1, s37
    s.addi       s37, s32, #13760
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #3
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a1, s37
    s.addi       s37, s32, #13824
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #4
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a1, s37
    s.addi       s37, s32, #13888
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #5
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a1, s37
    s.addi       s37, s32, #13952
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #6
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a1, s37
    s.addi       s37, s32, #14016
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #7
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a1, s37
    s.addi       s37, s32, #14080
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #8
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a1, s37
    s.addi       s37, s32, #14144
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #9
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a1, s37
    s.addi       s37, s32, #14208
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #10
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a1, s37
    s.addi       s37, s32, #14272
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #11
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a1, s37
    s.addi       s37, s32, #14336
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #12
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a1, s37
    s.addi       s37, s32, #14400
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #13
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a1, s37
    s.addi       s37, s32, #14464
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #14
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a1, s35
    s.addi       s35, s32, #14528
    v.ld.w       v17, [s35, #0]
    v.extract    s35, v29, #15
    v.splat      v19, s35
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v21
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    fence.acq_rel.device
    s.addi       s35, s32, #22784
    s.movz       s36, #0
    a.vread      v0, a2, s36
    s.addi       s36, s32, #14592
    v.ld.w       v17, [s36, #0]
    v.extract    s36, v29, #0
    v.splat      v19, s36
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s35, #0], v19
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a2, s37
    s.addi       s37, s32, #14656
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #1
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a2, s37
    s.addi       s37, s32, #14720
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #2
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a2, s37
    s.addi       s37, s32, #14784
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #3
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a2, s37
    s.addi       s37, s32, #14848
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #4
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a2, s37
    s.addi       s37, s32, #14912
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #5
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a2, s37
    s.addi       s37, s32, #14976
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #6
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a2, s37
    s.addi       s37, s32, #15040
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #7
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a2, s37
    s.addi       s37, s32, #15104
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #8
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a2, s37
    s.addi       s37, s32, #15168
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #9
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a2, s37
    s.addi       s37, s32, #15232
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #10
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a2, s37
    s.addi       s37, s32, #15296
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #11
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a2, s37
    s.addi       s37, s32, #15360
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #12
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a2, s37
    s.addi       s37, s32, #15424
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #13
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a2, s37
    s.addi       s37, s32, #15488
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #14
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a2, s35
    s.addi       s35, s32, #15552
    v.ld.w       v17, [s35, #0]
    v.extract    s35, v29, #15
    v.splat      v19, s35
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v27
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    fence.acq_rel.device
    s.addi       s35, s32, #23808
    s.movz       s36, #0
    a.vread      v0, a3, s36
    s.addi       s36, s32, #15616
    v.ld.w       v17, [s36, #0]
    v.extract    s36, v29, #0
    v.splat      v19, s36
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s35, #0], v19
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a3, s37
    s.addi       s37, s32, #15680
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #1
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a3, s37
    s.addi       s37, s32, #15744
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #2
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a3, s37
    s.addi       s37, s32, #15808
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #3
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a3, s37
    s.addi       s37, s32, #15872
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #4
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a3, s37
    s.addi       s37, s32, #15936
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #5
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a3, s37
    s.addi       s37, s32, #16000
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #6
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a3, s37
    s.addi       s37, s32, #16064
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #7
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a3, s37
    s.addi       s37, s32, #16128
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #8
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a3, s37
    s.addi       s37, s32, #16192
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #9
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a3, s37
    s.addi       s37, s32, #16256
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #10
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a3, s37
    s.addi       s37, s32, #16320
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #11
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a3, s37
    s.addi       s37, s32, #16384
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #12
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a3, s37
    s.addi       s37, s32, #16448
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #13
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a3, s37
    s.addi       s37, s32, #16512
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #14
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a3, s35
    s.addi       s35, s32, #16576
    v.ld.w       v17, [s35, #0]
    v.extract    s35, v29, #15
    v.splat      v19, s35
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v31
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    fence.acq_rel.device
    s.addi       s35, s32, #24832
    s.movz       s36, #0
    a.vread      v0, a4, s36
    s.addi       s36, s32, #16640
    v.ld.w       v17, [s36, #0]
    v.extract    s36, v29, #0
    v.splat      v19, s36
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s35, #0], v19
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a4, s37
    s.addi       s37, s32, #16704
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #1
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a4, s37
    s.addi       s37, s32, #16768
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #2
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a4, s37
    s.addi       s37, s32, #16832
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #3
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a4, s37
    s.addi       s37, s32, #16896
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #4
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a4, s37
    s.addi       s37, s32, #16960
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #5
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a4, s37
    s.addi       s37, s32, #17024
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #6
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a4, s37
    s.addi       s37, s32, #17088
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #7
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a4, s37
    s.addi       s37, s32, #17152
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #8
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a4, s37
    s.addi       s37, s32, #17216
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #9
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a4, s37
    s.addi       s37, s32, #17280
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #10
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a4, s37
    s.addi       s37, s32, #17344
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #11
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a4, s37
    s.addi       s37, s32, #17408
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #12
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a4, s37
    s.addi       s37, s32, #17472
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #13
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a4, s37
    s.addi       s37, s32, #17536
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #14
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a4, s35
    s.addi       s35, s32, #17600
    v.ld.w       v17, [s35, #0]
    v.extract    s35, v29, #15
    v.splat      v19, s35
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v32
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    fence.acq_rel.device
    s.addi       s35, s32, #25856
    s.movz       s36, #0
    a.vread      v0, a5, s36
    s.addi       s36, s32, #17664
    v.ld.w       v17, [s36, #0]
    v.extract    s36, v29, #0
    v.splat      v19, s36
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s35, #0], v19
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a5, s37
    s.addi       s37, s32, #17728
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #1
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a5, s37
    s.addi       s37, s32, #17792
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #2
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a5, s37
    s.addi       s37, s32, #17856
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #3
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a5, s37
    s.addi       s37, s32, #17920
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #4
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a5, s37
    s.addi       s37, s32, #17984
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #5
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a5, s37
    s.addi       s37, s32, #18048
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #6
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a5, s37
    s.addi       s37, s32, #18112
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #7
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a5, s37
    s.addi       s37, s32, #18176
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #8
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a5, s37
    s.addi       s37, s32, #18240
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #9
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a5, s37
    s.addi       s37, s32, #18304
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #10
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a5, s37
    s.addi       s37, s32, #18368
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #11
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a5, s37
    s.addi       s37, s32, #18432
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #12
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a5, s37
    s.addi       s37, s32, #18496
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #13
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a5, s37
    s.addi       s37, s32, #18560
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #14
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a5, s35
    s.addi       s35, s32, #18624
    v.ld.w       v17, [s35, #0]
    v.extract    s35, v29, #15
    v.splat      v19, s35
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v33
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    fence.acq_rel.device
    s.addi       s35, s32, #26880
    s.movz       s36, #0
    a.vread      v0, a6, s36
    s.addi       s36, s32, #18688
    v.ld.w       v17, [s36, #0]
    v.extract    s36, v29, #0
    v.splat      v19, s36
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s35, #0], v19
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a6, s37
    s.addi       s37, s32, #18752
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #1
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a6, s37
    s.addi       s37, s32, #18816
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #2
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a6, s37
    s.addi       s37, s32, #18880
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #3
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a6, s37
    s.addi       s37, s32, #18944
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #4
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a6, s37
    s.addi       s37, s32, #19008
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #5
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a6, s37
    s.addi       s37, s32, #19072
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #6
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a6, s37
    s.addi       s37, s32, #19136
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #7
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a6, s37
    s.addi       s37, s32, #19200
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #8
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a6, s37
    s.addi       s37, s32, #19264
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #9
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a6, s37
    s.addi       s37, s32, #19328
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #10
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a6, s37
    s.addi       s37, s32, #19392
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #11
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a6, s37
    s.addi       s37, s32, #19456
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #12
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a6, s37
    s.addi       s37, s32, #19520
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #13
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a6, s37
    s.addi       s37, s32, #19584
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #14
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a6, s35
    s.addi       s35, s32, #19648
    v.ld.w       v17, [s35, #0]
    v.extract    s35, v29, #15
    v.splat      v19, s35
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v34
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    fence.acq_rel.device
    s.addi       s35, s32, #27904
    s.movz       s36, #0
    a.vread      v0, a7, s36
    s.addi       s36, s32, #19712
    v.ld.w       v17, [s36, #0]
    v.extract    s36, v29, #0
    v.splat      v19, s36
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s35, #0], v19
    s.addi       s36, s35, #64
    s.movz       s37, #1
    a.vread      v0, a7, s37
    s.addi       s37, s32, #19776
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #1
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #128
    s.movz       s37, #2
    a.vread      v0, a7, s37
    s.addi       s37, s32, #19840
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #2
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #192
    s.movz       s37, #3
    a.vread      v0, a7, s37
    s.addi       s37, s32, #19904
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #3
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #256
    s.movz       s37, #4
    a.vread      v0, a7, s37
    s.addi       s37, s32, #19968
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #4
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #320
    s.movz       s37, #5
    a.vread      v0, a7, s37
    s.addi       s37, s32, #20032
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #5
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #384
    s.movz       s37, #6
    a.vread      v0, a7, s37
    s.addi       s37, s32, #20096
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #6
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #448
    s.movz       s37, #7
    a.vread      v0, a7, s37
    s.addi       s37, s32, #20160
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #7
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #512
    s.movz       s37, #8
    a.vread      v0, a7, s37
    s.addi       s37, s32, #20224
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #8
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #576
    s.movz       s37, #9
    a.vread      v0, a7, s37
    s.addi       s37, s32, #20288
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #9
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #640
    s.movz       s37, #10
    a.vread      v0, a7, s37
    s.addi       s37, s32, #20352
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #10
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #704
    s.movz       s37, #11
    a.vread      v0, a7, s37
    s.addi       s37, s32, #20416
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #11
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #768
    s.movz       s37, #12
    a.vread      v0, a7, s37
    s.addi       s37, s32, #20480
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #12
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #832
    s.movz       s37, #13
    a.vread      v0, a7, s37
    s.addi       s37, s32, #20544
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #13
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #896
    s.movz       s37, #14
    a.vread      v0, a7, s37
    s.addi       s37, s32, #20608
    v.ld.w       v17, [s37, #0]
    v.extract    s37, v29, #14
    v.splat      v19, s37
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    s.addi       s36, s35, #960
    s.movz       s35, #15
    a.vread      v0, a7, s35
    s.addi       s35, s32, #20672
    v.ld.w       v17, [s35, #0]
    v.extract    s35, v29, #15
    v.splat      v19, s35
    vf.mul       v20, v17, v19
    vf.mul       v17, v20, v35
    vf.add       v19, v0, v17
    v.st.w       [s36, #0], v19
    fence.acq_rel.device
    s.addi       s35, s28, #128
    s.addi       s36, s35, #0
    s.addi       s35, s29, #128
    s.addi       s37, s35, #0
    s.addi       s35, s30, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    s.addi       s38, s35, #0
    s.addi       s35, s30, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    s.addi       s35, s30, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    s.addi       s35, s30, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    s.addi       s35, s30, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    s.addi       s35, s30, #4                    // &ptr_carry_25[1] (a constant offset, x4)
    s.addi       s35, s30, #4                    // &ptr_carry_26[1] (a constant offset, x4)
    s.addi       s35, s30, #4                    // &ptr_carry_27[1] (a constant offset, x4)
    s.mov        s28, s36
    s.mov        s29, s37
    s.mov        s30, s38
    s.movz       s35, #0
    s.addi       s36, s32, #20736
    v.ld.w       v0, [s36, #0]
    a.vwrite     a0, s35, v0
    s.movz       s36, #1
    s.addi       s37, s32, #20800
    v.ld.w       v0, [s37, #0]
    a.vwrite     a0, s36, v0
    s.movz       s37, #2
    s.addi       s38, s32, #20864
    v.ld.w       v0, [s38, #0]
    a.vwrite     a0, s37, v0
    s.movz       s38, #3
    s.addi       s39, s32, #20928
    v.ld.w       v0, [s39, #0]
    a.vwrite     a0, s38, v0
    s.movz       s39, #4
    s.addi       s40, s32, #20992
    v.ld.w       v0, [s40, #0]
    a.vwrite     a0, s39, v0
    s.movz       s40, #5
    s.addi       s41, s32, #21056
    v.ld.w       v0, [s41, #0]
    a.vwrite     a0, s40, v0
    s.movz       s41, #6
    s.addi       s42, s32, #21120
    v.ld.w       v0, [s42, #0]
    a.vwrite     a0, s41, v0
    s.movz       s42, #7
    s.addi       s43, s32, #21184
    v.ld.w       v0, [s43, #0]
    a.vwrite     a0, s42, v0
    s.movz       s43, #8
    s.addi       s44, s32, #21248
    v.ld.w       v0, [s44, #0]
    a.vwrite     a0, s43, v0
    s.movz       s44, #9
    s.addi       s45, s32, #21312
    v.ld.w       v0, [s45, #0]
    a.vwrite     a0, s44, v0
    s.movz       s45, #10
    s.addi       s46, s32, #21376
    v.ld.w       v0, [s46, #0]
    a.vwrite     a0, s45, v0
    s.movz       s46, #11
    s.addi       s47, s32, #21440
    v.ld.w       v0, [s47, #0]
    a.vwrite     a0, s46, v0
    s.movz       s47, #12
    s.addi       s48, s32, #21504
    v.ld.w       v0, [s48, #0]
    a.vwrite     a0, s47, v0
    s.movz       s48, #13
    s.addi       s50, s32, #21568
    v.ld.w       v0, [s50, #0]
    a.vwrite     a0, s48, v0
    s.movz       s50, #14
    s.addi       s51, s32, #21632
    v.ld.w       v0, [s51, #0]
    a.vwrite     a0, s50, v0
    s.movz       s51, #15
    s.addi       s52, s32, #21696
    v.ld.w       v0, [s52, #0]
    a.vwrite     a0, s51, v0
    s.addi       s52, s32, #21760
    v.ld.w       v0, [s52, #0]
    a.vwrite     a1, s35, v0
    s.addi       s35, s32, #21824
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s36, v0
    s.addi       s35, s32, #21888
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s37, v0
    s.addi       s35, s32, #21952
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s38, v0
    s.addi       s35, s32, #22016
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s39, v0
    s.addi       s35, s32, #22080
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s40, v0
    s.addi       s35, s32, #22144
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s41, v0
    s.addi       s35, s32, #22208
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s42, v0
    s.addi       s35, s32, #22272
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s43, v0
    s.addi       s35, s32, #22336
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s44, v0
    s.addi       s35, s32, #22400
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s45, v0
    s.addi       s35, s32, #22464
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s46, v0
    s.addi       s35, s32, #22528
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s47, v0
    s.addi       s35, s32, #22592
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s48, v0
    s.addi       s35, s32, #22656
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s50, v0
    s.addi       s35, s32, #22720
    v.ld.w       v0, [s35, #0]
    a.vwrite     a1, s51, v0
    s.movz       s35, #0
    s.addi       s36, s32, #22784
    v.ld.w       v0, [s36, #0]
    a.vwrite     a2, s35, v0
    s.movz       s36, #1
    s.addi       s37, s32, #22848
    v.ld.w       v0, [s37, #0]
    a.vwrite     a2, s36, v0
    s.movz       s37, #2
    s.addi       s38, s32, #22912
    v.ld.w       v0, [s38, #0]
    a.vwrite     a2, s37, v0
    s.movz       s38, #3
    s.addi       s39, s32, #22976
    v.ld.w       v0, [s39, #0]
    a.vwrite     a2, s38, v0
    s.movz       s39, #4
    s.addi       s40, s32, #23040
    v.ld.w       v0, [s40, #0]
    a.vwrite     a2, s39, v0
    s.movz       s40, #5
    s.addi       s41, s32, #23104
    v.ld.w       v0, [s41, #0]
    a.vwrite     a2, s40, v0
    s.movz       s41, #6
    s.addi       s42, s32, #23168
    v.ld.w       v0, [s42, #0]
    a.vwrite     a2, s41, v0
    s.movz       s42, #7
    s.addi       s43, s32, #23232
    v.ld.w       v0, [s43, #0]
    a.vwrite     a2, s42, v0
    s.movz       s43, #8
    s.addi       s44, s32, #23296
    v.ld.w       v0, [s44, #0]
    a.vwrite     a2, s43, v0
    s.movz       s44, #9
    s.addi       s45, s32, #23360
    v.ld.w       v0, [s45, #0]
    a.vwrite     a2, s44, v0
    s.movz       s45, #10
    s.addi       s46, s32, #23424
    v.ld.w       v0, [s46, #0]
    a.vwrite     a2, s45, v0
    s.movz       s46, #11
    s.addi       s47, s32, #23488
    v.ld.w       v0, [s47, #0]
    a.vwrite     a2, s46, v0
    s.movz       s47, #12
    s.addi       s48, s32, #23552
    v.ld.w       v0, [s48, #0]
    a.vwrite     a2, s47, v0
    s.movz       s48, #13
    s.addi       s50, s32, #23616
    v.ld.w       v0, [s50, #0]
    a.vwrite     a2, s48, v0
    s.movz       s50, #14
    s.addi       s51, s32, #23680
    v.ld.w       v0, [s51, #0]
    a.vwrite     a2, s50, v0
    s.movz       s51, #15
    s.addi       s52, s32, #23744
    v.ld.w       v0, [s52, #0]
    a.vwrite     a2, s51, v0
    s.addi       s52, s32, #23808
    v.ld.w       v0, [s52, #0]
    a.vwrite     a3, s35, v0
    s.addi       s35, s32, #23872
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s36, v0
    s.addi       s35, s32, #23936
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s37, v0
    s.addi       s35, s32, #24000
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s38, v0
    s.addi       s35, s32, #24064
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s39, v0
    s.addi       s35, s32, #24128
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s40, v0
    s.addi       s35, s32, #24192
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s41, v0
    s.addi       s35, s32, #24256
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s42, v0
    s.addi       s35, s32, #24320
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s43, v0
    s.addi       s35, s32, #24384
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s44, v0
    s.addi       s35, s32, #24448
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s45, v0
    s.addi       s35, s32, #24512
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s46, v0
    s.addi       s35, s32, #24576
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s47, v0
    s.addi       s35, s32, #24640
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s48, v0
    s.addi       s35, s32, #24704
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s50, v0
    s.addi       s35, s32, #24768
    v.ld.w       v0, [s35, #0]
    a.vwrite     a3, s51, v0
    s.movz       s35, #0
    s.addi       s36, s32, #24832
    v.ld.w       v0, [s36, #0]
    a.vwrite     a4, s35, v0
    s.movz       s36, #1
    s.addi       s37, s32, #24896
    v.ld.w       v0, [s37, #0]
    a.vwrite     a4, s36, v0
    s.movz       s37, #2
    s.addi       s38, s32, #24960
    v.ld.w       v0, [s38, #0]
    a.vwrite     a4, s37, v0
    s.movz       s38, #3
    s.addi       s39, s32, #25024
    v.ld.w       v0, [s39, #0]
    a.vwrite     a4, s38, v0
    s.movz       s39, #4
    s.addi       s40, s32, #25088
    v.ld.w       v0, [s40, #0]
    a.vwrite     a4, s39, v0
    s.movz       s40, #5
    s.addi       s41, s32, #25152
    v.ld.w       v0, [s41, #0]
    a.vwrite     a4, s40, v0
    s.movz       s41, #6
    s.addi       s42, s32, #25216
    v.ld.w       v0, [s42, #0]
    a.vwrite     a4, s41, v0
    s.movz       s42, #7
    s.addi       s43, s32, #25280
    v.ld.w       v0, [s43, #0]
    a.vwrite     a4, s42, v0
    s.movz       s43, #8
    s.addi       s44, s32, #25344
    v.ld.w       v0, [s44, #0]
    a.vwrite     a4, s43, v0
    s.movz       s44, #9
    s.addi       s45, s32, #25408
    v.ld.w       v0, [s45, #0]
    a.vwrite     a4, s44, v0
    s.movz       s45, #10
    s.addi       s46, s32, #25472
    v.ld.w       v0, [s46, #0]
    a.vwrite     a4, s45, v0
    s.movz       s46, #11
    s.addi       s47, s32, #25536
    v.ld.w       v0, [s47, #0]
    a.vwrite     a4, s46, v0
    s.movz       s47, #12
    s.addi       s48, s32, #25600
    v.ld.w       v0, [s48, #0]
    a.vwrite     a4, s47, v0
    s.movz       s48, #13
    s.addi       s50, s32, #25664
    v.ld.w       v0, [s50, #0]
    a.vwrite     a4, s48, v0
    s.movz       s50, #14
    s.addi       s51, s32, #25728
    v.ld.w       v0, [s51, #0]
    a.vwrite     a4, s50, v0
    s.movz       s51, #15
    s.addi       s52, s32, #25792
    v.ld.w       v0, [s52, #0]
    a.vwrite     a4, s51, v0
    s.addi       s52, s32, #25856
    v.ld.w       v0, [s52, #0]
    a.vwrite     a5, s35, v0
    s.addi       s35, s32, #25920
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s36, v0
    s.addi       s35, s32, #25984
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s37, v0
    s.addi       s35, s32, #26048
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s38, v0
    s.addi       s35, s32, #26112
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s39, v0
    s.addi       s35, s32, #26176
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s40, v0
    s.addi       s35, s32, #26240
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s41, v0
    s.addi       s35, s32, #26304
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s42, v0
    s.addi       s35, s32, #26368
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s43, v0
    s.addi       s35, s32, #26432
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s44, v0
    s.addi       s35, s32, #26496
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s45, v0
    s.addi       s35, s32, #26560
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s46, v0
    s.addi       s35, s32, #26624
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s47, v0
    s.addi       s35, s32, #26688
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s48, v0
    s.addi       s35, s32, #26752
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s50, v0
    s.addi       s35, s32, #26816
    v.ld.w       v0, [s35, #0]
    a.vwrite     a5, s51, v0
    s.movz       s35, #0
    s.addi       s36, s32, #26880
    v.ld.w       v0, [s36, #0]
    a.vwrite     a6, s35, v0
    s.movz       s36, #1
    s.addi       s37, s32, #26944
    v.ld.w       v0, [s37, #0]
    a.vwrite     a6, s36, v0
    s.movz       s37, #2
    s.addi       s38, s32, #27008
    v.ld.w       v0, [s38, #0]
    a.vwrite     a6, s37, v0
    s.movz       s38, #3
    s.addi       s39, s32, #27072
    v.ld.w       v0, [s39, #0]
    a.vwrite     a6, s38, v0
    s.movz       s39, #4
    s.addi       s40, s32, #27136
    v.ld.w       v0, [s40, #0]
    a.vwrite     a6, s39, v0
    s.movz       s40, #5
    s.addi       s41, s32, #27200
    v.ld.w       v0, [s41, #0]
    a.vwrite     a6, s40, v0
    s.movz       s41, #6
    s.addi       s42, s32, #27264
    v.ld.w       v0, [s42, #0]
    a.vwrite     a6, s41, v0
    s.movz       s42, #7
    s.addi       s43, s32, #27328
    v.ld.w       v0, [s43, #0]
    a.vwrite     a6, s42, v0
    s.movz       s43, #8
    s.addi       s44, s32, #27392
    v.ld.w       v0, [s44, #0]
    a.vwrite     a6, s43, v0
    s.movz       s44, #9
    s.addi       s45, s32, #27456
    v.ld.w       v0, [s45, #0]
    a.vwrite     a6, s44, v0
    s.movz       s45, #10
    s.addi       s46, s32, #27520
    v.ld.w       v0, [s46, #0]
    a.vwrite     a6, s45, v0
    s.movz       s46, #11
    s.addi       s47, s32, #27584
    v.ld.w       v0, [s47, #0]
    a.vwrite     a6, s46, v0
    s.movz       s47, #12
    s.addi       s48, s32, #27648
    v.ld.w       v0, [s48, #0]
    a.vwrite     a6, s47, v0
    s.movz       s48, #13
    s.addi       s50, s32, #27712
    v.ld.w       v0, [s50, #0]
    a.vwrite     a6, s48, v0
    s.movz       s50, #14
    s.addi       s51, s32, #27776
    v.ld.w       v0, [s51, #0]
    a.vwrite     a6, s50, v0
    s.movz       s51, #15
    s.addi       s52, s32, #27840
    v.ld.w       v0, [s52, #0]
    a.vwrite     a6, s51, v0
    s.addi       s52, s32, #27904
    v.ld.w       v0, [s52, #0]
    a.vwrite     a7, s35, v0
    s.addi       s35, s32, #27968
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s36, v0
    s.addi       s35, s32, #28032
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s37, v0
    s.addi       s35, s32, #28096
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s38, v0
    s.addi       s35, s32, #28160
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s39, v0
    s.addi       s35, s32, #28224
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s40, v0
    s.addi       s35, s32, #28288
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s41, v0
    s.addi       s35, s32, #28352
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s42, v0
    s.addi       s35, s32, #28416
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s43, v0
    s.addi       s35, s32, #28480
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s44, v0
    s.addi       s35, s32, #28544
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s45, v0
    s.addi       s35, s32, #28608
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s46, v0
    s.addi       s35, s32, #28672
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s47, v0
    s.addi       s35, s32, #28736
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s48, v0
    s.addi       s35, s32, #28800
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s50, v0
    s.addi       s35, s32, #28864
    v.ld.w       v0, [s35, #0]
    a.vwrite     a7, s51, v0
    s.add        s32, s27, s25
    s.mov        s27, s32
    s.movz       s32, #1
    br.nz        s32, for_28
endfor_29:
    s.mul        s16, s1, s13
    s.movz       s17, #0
    s.muli       s18, s15, #2
    a.vread      v0, a0, s17
    s.muli       s19, s13, #2
    s.muli       s20, s16, #2
    vf.cvt.f32.bf16 v1, v0
    s.addi       s16, s15, #16
    s.add        s21, s17, s1                    // the tile origin
    s.addi       s1, s15, #32
    v.splat      v0, s21
    s.add        s22, s20, s18
    s.addi       s23, s15, #48
    s.add        s24, s17, s8                    // the tile origin
    s.add        s25, s6, s22
    s.addi       s22, s15, #64
    v.splat      v2, s24
    s.addi       s24, s15, #80
    s.addi       s26, s15, #96
    s.add        s27, s17, s15                   // the tile origin
    v.cmp.lt     p1, v0, v2
    s.addi       s28, s15, #112
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v3, s27
    s.add        s15, s17, s9                    // the tile origin
    s.muli       s17, s19, #1
    v.add        v4, v0, v3
    v.splat      v3, s15
    s.movz       s15, #1
    s.addi       s27, s21, #1
    v.cmp.lt     p2, v4, v3
    p.and        p3, p1, p2
    s.add        s29, s17, s20
    @p3 v.st.h       [s25, #0], v1
    a.vread      v1, a0, s15
    v.splat      v3, s27
    s.add        s15, s29, s18
    vf.cvt.f32.bf16 v4, v1
    v.cmp.lt     p1, v3, v2
    s.muli       s17, s19, #2
    s.add        s25, s6, s15
    p.and        p3, p1, p2
    s.movz       s15, #2
    s.addi       s27, s21, #2
    s.add        s29, s17, s20
    v.splat      v1, s27
    s.add        s17, s29, s18
    @p3 v.st.h       [s25, #0], v4
    a.vread      v3, a0, s15
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #3
    vf.cvt.f32.bf16 v1, v3
    s.add        s25, s6, s17
    p.and        p3, p1, p2
    s.movz       s17, #3
    s.addi       s27, s21, #3
    s.add        s29, s15, s20
    v.splat      v3, s27
    s.add        s15, s29, s18
    s.movz       s27, #4
    s.add        s29, s6, s15
    @p3 v.st.h       [s25, #0], v1
    a.vread      v1, a0, s17
    v.cmp.lt     p1, v3, v2
    s.muli       s15, s19, #4
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s17, s21, #4
    s.add        s25, s15, s20
    v.splat      v1, s17
    s.add        s15, s25, s18
    s.movz       s17, #5
    s.add        s25, s6, s15
    @p3 v.st.h       [s29, #0], v3
    a.vread      v3, a0, s27
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #5
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s27, s21, #5
    s.add        s29, s15, s20
    v.splat      v3, s27
    s.add        s15, s29, s18
    s.movz       s27, #6
    s.add        s29, s6, s15
    @p3 v.st.h       [s25, #0], v1
    a.vread      v1, a0, s17
    v.cmp.lt     p1, v3, v2
    s.muli       s15, s19, #6
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s17, s21, #6
    s.add        s25, s15, s20
    v.splat      v1, s17
    s.add        s15, s25, s18
    s.movz       s17, #7
    s.add        s25, s6, s15
    @p3 v.st.h       [s29, #0], v3
    a.vread      v3, a0, s27
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #7
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s27, s21, #7
    s.add        s29, s15, s20
    v.splat      v3, s27
    s.add        s15, s29, s18
    s.movz       s27, #8
    s.add        s29, s6, s15
    @p3 v.st.h       [s25, #0], v1
    a.vread      v1, a0, s17
    v.cmp.lt     p1, v3, v2
    s.muli       s15, s19, #8
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s17, s21, #8
    s.add        s25, s15, s20
    v.splat      v1, s17
    s.add        s15, s25, s18
    s.movz       s17, #9
    s.add        s25, s6, s15
    @p3 v.st.h       [s29, #0], v3
    a.vread      v3, a0, s27
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #9
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s27, s21, #9
    s.add        s29, s15, s20
    v.splat      v3, s27
    s.add        s15, s29, s18
    s.movz       s27, #10
    s.add        s29, s6, s15
    @p3 v.st.h       [s25, #0], v1
    a.vread      v1, a0, s17
    v.cmp.lt     p1, v3, v2
    s.muli       s15, s19, #10
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s17, s21, #10
    s.add        s25, s15, s20
    v.splat      v1, s17
    s.add        s15, s25, s18
    s.movz       s17, #11
    s.add        s25, s6, s15
    @p3 v.st.h       [s29, #0], v3
    a.vread      v3, a0, s27
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #11
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s27, s21, #11
    s.add        s29, s15, s20
    v.splat      v3, s27
    s.add        s15, s29, s18
    s.movz       s27, #12
    s.add        s29, s6, s15
    @p3 v.st.h       [s25, #0], v1
    a.vread      v1, a0, s17
    v.cmp.lt     p1, v3, v2
    s.muli       s15, s19, #12
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s17, s21, #12
    s.add        s25, s15, s20
    v.splat      v1, s17
    s.add        s15, s25, s18
    s.movz       s17, #13
    s.add        s25, s6, s15
    @p3 v.st.h       [s29, #0], v3
    a.vread      v3, a0, s27
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #13
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s27, s21, #13
    s.add        s29, s15, s20
    v.splat      v3, s27
    s.add        s15, s29, s18
    s.movz       s27, #14
    s.add        s29, s6, s15
    @p3 v.st.h       [s25, #0], v1
    a.vread      v1, a0, s17
    v.cmp.lt     p1, v3, v2
    s.muli       s15, s19, #14
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s17, s21, #14
    s.add        s25, s15, s20
    v.splat      v1, s17
    s.add        s15, s25, s18
    s.movz       s17, #15
    s.add        s25, s6, s15
    @p3 v.st.h       [s29, #0], v3
    a.vread      v3, a0, s27
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #15
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s27, s21, #15
    s.add        s29, s15, s20
    v.splat      v3, s27
    s.movz       s15, #0
    s.add        s27, s29, s18
    s.add        s18, s6, s27
    @p3 v.st.h       [s25, #0], v1
    a.vread      v1, a0, s17
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s17, s15, s16                   // the tile origin
    s.muli       s25, s16, #2
    v.splat      v1, s17
    s.add        s16, s15, s9                    // the tile origin
    v.splat      v4, s21
    v.add        v5, v0, v1
    s.add        s17, s20, s25
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s16
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a1, s15
    v.cmp.lt     p2, v5, v1
    s.add        s15, s6, s17
    vf.cvt.f32.bf16 v1, v3
    s.muli       s16, s19, #1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    s.movz       s27, #2
    s.add        s29, s16, s20
    v.splat      v3, s18
    s.add        s16, s29, s25
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a1, s17
    v.cmp.lt     p1, v3, v2
    s.muli       s15, s19, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.addi       s16, s21, #2
    s.add        s18, s15, s20
    v.splat      v1, s16
    s.add        s15, s18, s25
    s.movz       s16, #3
    s.add        s18, s6, s15
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a1, s27
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #3
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #3
    s.movz       s27, #4
    s.add        s29, s15, s20
    v.splat      v3, s17
    s.add        s15, s29, s25
    s.add        s17, s6, s15
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s16
    v.cmp.lt     p1, v3, v2
    s.muli       s15, s19, #4
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #4
    s.movz       s18, #5
    s.add        s29, s15, s20
    v.splat      v1, s16
    s.add        s15, s29, s25
    s.add        s16, s6, s15
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a1, s27
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #5
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #5
    s.movz       s27, #6
    s.add        s29, s15, s20
    v.splat      v3, s17
    s.add        s15, s29, s25
    s.add        s17, s6, s15
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s15, s19, #6
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #6
    s.movz       s18, #7
    s.add        s29, s15, s20
    v.splat      v1, s16
    s.add        s15, s29, s25
    s.add        s16, s6, s15
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a1, s27
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #7
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #7
    s.movz       s27, #8
    s.add        s29, s15, s20
    v.splat      v3, s17
    s.add        s15, s29, s25
    s.add        s17, s6, s15
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s15, s19, #8
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #8
    s.movz       s18, #9
    s.add        s29, s15, s20
    v.splat      v1, s16
    s.add        s15, s29, s25
    s.add        s16, s6, s15
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a1, s27
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #9
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #9
    s.movz       s27, #10
    s.add        s29, s15, s20
    v.splat      v3, s17
    s.add        s15, s29, s25
    s.add        s17, s6, s15
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s15, s19, #10
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #10
    s.movz       s18, #11
    s.add        s29, s15, s20
    v.splat      v1, s16
    s.add        s15, s29, s25
    s.add        s16, s6, s15
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a1, s27
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #11
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #11
    s.movz       s27, #12
    s.add        s29, s15, s20
    v.splat      v3, s17
    s.add        s15, s29, s25
    s.add        s17, s6, s15
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s15, s19, #12
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #12
    s.movz       s18, #13
    s.add        s29, s15, s20
    v.splat      v1, s16
    s.add        s15, s29, s25
    s.add        s16, s6, s15
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a1, s27
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #13
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #13
    s.movz       s27, #14
    s.add        s29, s15, s20
    v.splat      v3, s17
    s.add        s15, s29, s25
    s.add        s17, s6, s15
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s15, s19, #14
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #14
    s.movz       s18, #15
    s.add        s29, s15, s20
    v.splat      v1, s16
    s.add        s15, s29, s25
    s.add        s16, s6, s15
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a1, s27
    v.cmp.lt     p1, v1, v2
    s.muli       s15, s19, #15
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #15
    s.movz       s27, #0
    s.add        s29, s15, s20
    v.splat      v3, s17
    s.add        s15, s29, s25
    s.add        s17, s6, s15
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a1, s18
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s15, s27, s1                    // the tile origin
    s.muli       s16, s1, #2
    v.splat      v1, s15
    s.add        s1, s27, s9                     // the tile origin
    v.splat      v4, s21
    v.add        v5, v0, v1
    s.add        s15, s20, s16
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a2, s27
    v.cmp.lt     p2, v5, v1
    s.add        s1, s6, s15
    vf.cvt.f32.bf16 v1, v3
    s.muli       s15, s19, #1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    s.movz       s25, #2
    s.add        s27, s15, s20
    v.splat      v3, s18
    s.add        s15, s27, s16
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a2, s17
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s17, s6, s15
    p.and        p3, p1, p2
    s.addi       s15, s21, #2
    s.add        s18, s1, s20
    v.splat      v1, s15
    s.add        s1, s18, s16
    s.movz       s15, #3
    s.add        s18, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a2, s25
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #3
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #3
    s.movz       s25, #4
    s.add        s27, s1, s20
    v.splat      v3, s17
    s.add        s1, s27, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s15
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #4
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #4
    s.movz       s18, #5
    s.add        s27, s1, s20
    v.splat      v1, s15
    s.add        s1, s27, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a2, s25
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #5
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #5
    s.movz       s25, #6
    s.add        s27, s1, s20
    v.splat      v3, s17
    s.add        s1, s27, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a2, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #6
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #6
    s.movz       s18, #7
    s.add        s27, s1, s20
    v.splat      v1, s15
    s.add        s1, s27, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a2, s25
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #7
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #7
    s.movz       s25, #8
    s.add        s27, s1, s20
    v.splat      v3, s17
    s.add        s1, s27, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a2, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #8
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #8
    s.movz       s18, #9
    s.add        s27, s1, s20
    v.splat      v1, s15
    s.add        s1, s27, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a2, s25
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #9
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #9
    s.movz       s25, #10
    s.add        s27, s1, s20
    v.splat      v3, s17
    s.add        s1, s27, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a2, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #10
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #10
    s.movz       s18, #11
    s.add        s27, s1, s20
    v.splat      v1, s15
    s.add        s1, s27, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a2, s25
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #11
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #11
    s.movz       s25, #12
    s.add        s27, s1, s20
    v.splat      v3, s17
    s.add        s1, s27, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a2, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #12
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #12
    s.movz       s18, #13
    s.add        s27, s1, s20
    v.splat      v1, s15
    s.add        s1, s27, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a2, s25
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #13
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #13
    s.movz       s25, #14
    s.add        s27, s1, s20
    v.splat      v3, s17
    s.add        s1, s27, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a2, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #14
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #14
    s.movz       s18, #15
    s.add        s27, s1, s20
    v.splat      v1, s15
    s.add        s1, s27, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a2, s25
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #15
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #15
    s.movz       s25, #0
    s.add        s27, s1, s20
    v.splat      v3, s17
    s.add        s1, s27, s16
    s.add        s16, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a2, s18
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s25, s23                    // the tile origin
    s.muli       s15, s23, #2
    v.splat      v1, s1
    s.add        s1, s25, s9                     // the tile origin
    v.splat      v4, s21
    v.add        v5, v0, v1
    s.add        s17, s20, s15
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s1
    @p3 v.st.h       [s16, #0], v3
    a.vread      v3, a3, s25
    v.cmp.lt     p2, v5, v1
    s.add        s1, s6, s17
    vf.cvt.f32.bf16 v1, v3
    s.muli       s16, s19, #1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    s.movz       s23, #2
    s.add        s25, s16, s20
    v.splat      v3, s18
    s.add        s16, s25, s15
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a3, s17
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.addi       s16, s21, #2
    s.add        s18, s1, s20
    v.splat      v1, s16
    s.add        s1, s18, s15
    s.movz       s16, #3
    s.add        s18, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a3, s23
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #3
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #3
    s.movz       s23, #4
    s.add        s25, s1, s20
    v.splat      v3, s17
    s.add        s1, s25, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a3, s16
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #4
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #4
    s.movz       s18, #5
    s.add        s25, s1, s20
    v.splat      v1, s16
    s.add        s1, s25, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a3, s23
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #5
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #5
    s.movz       s23, #6
    s.add        s25, s1, s20
    v.splat      v3, s17
    s.add        s1, s25, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a3, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #6
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #6
    s.movz       s18, #7
    s.add        s25, s1, s20
    v.splat      v1, s16
    s.add        s1, s25, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a3, s23
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #7
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #7
    s.movz       s23, #8
    s.add        s25, s1, s20
    v.splat      v3, s17
    s.add        s1, s25, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a3, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #8
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #8
    s.movz       s18, #9
    s.add        s25, s1, s20
    v.splat      v1, s16
    s.add        s1, s25, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a3, s23
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #9
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #9
    s.movz       s23, #10
    s.add        s25, s1, s20
    v.splat      v3, s17
    s.add        s1, s25, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a3, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #10
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #10
    s.movz       s18, #11
    s.add        s25, s1, s20
    v.splat      v1, s16
    s.add        s1, s25, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a3, s23
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #11
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #11
    s.movz       s23, #12
    s.add        s25, s1, s20
    v.splat      v3, s17
    s.add        s1, s25, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a3, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #12
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #12
    s.movz       s18, #13
    s.add        s25, s1, s20
    v.splat      v1, s16
    s.add        s1, s25, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a3, s23
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #13
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #13
    s.movz       s23, #14
    s.add        s25, s1, s20
    v.splat      v3, s17
    s.add        s1, s25, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a3, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #14
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #14
    s.movz       s18, #15
    s.add        s25, s1, s20
    v.splat      v1, s16
    s.add        s1, s25, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a3, s23
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #15
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #15
    s.movz       s23, #0
    s.add        s25, s1, s20
    v.splat      v3, s17
    s.add        s1, s25, s15
    s.add        s15, s6, s1
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a3, s18
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s23, s22                    // the tile origin
    s.muli       s16, s22, #2
    v.splat      v1, s1
    s.add        s1, s23, s9                     // the tile origin
    v.splat      v4, s21
    v.add        v5, v0, v1
    s.add        s17, s20, s16
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s1
    @p3 v.st.h       [s15, #0], v3
    a.vread      v3, a4, s23
    v.cmp.lt     p2, v5, v1
    s.add        s1, s6, s17
    vf.cvt.f32.bf16 v1, v3
    s.muli       s15, s19, #1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    s.movz       s22, #2
    s.add        s23, s15, s20
    v.splat      v3, s18
    s.add        s15, s23, s16
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a4, s17
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s17, s6, s15
    p.and        p3, p1, p2
    s.addi       s15, s21, #2
    s.add        s18, s1, s20
    v.splat      v1, s15
    s.add        s1, s18, s16
    s.movz       s15, #3
    s.add        s18, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a4, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #3
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #3
    s.movz       s22, #4
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a4, s15
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #4
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #4
    s.movz       s18, #5
    s.add        s23, s1, s20
    v.splat      v1, s15
    s.add        s1, s23, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a4, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #5
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #5
    s.movz       s22, #6
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a4, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #6
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #6
    s.movz       s18, #7
    s.add        s23, s1, s20
    v.splat      v1, s15
    s.add        s1, s23, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a4, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #7
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #7
    s.movz       s22, #8
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a4, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #8
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #8
    s.movz       s18, #9
    s.add        s23, s1, s20
    v.splat      v1, s15
    s.add        s1, s23, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a4, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #9
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #9
    s.movz       s22, #10
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a4, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #10
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #10
    s.movz       s18, #11
    s.add        s23, s1, s20
    v.splat      v1, s15
    s.add        s1, s23, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a4, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #11
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #11
    s.movz       s22, #12
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a4, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #12
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #12
    s.movz       s18, #13
    s.add        s23, s1, s20
    v.splat      v1, s15
    s.add        s1, s23, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a4, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #13
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #13
    s.movz       s22, #14
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a4, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #14
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #14
    s.movz       s18, #15
    s.add        s23, s1, s20
    v.splat      v1, s15
    s.add        s1, s23, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a4, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #15
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #15
    s.movz       s22, #0
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s16
    s.add        s16, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a4, s18
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s22, s24                    // the tile origin
    s.muli       s15, s24, #2
    v.splat      v1, s1
    s.add        s1, s22, s9                     // the tile origin
    v.splat      v4, s21
    v.add        v5, v0, v1
    s.add        s17, s20, s15
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s1
    @p3 v.st.h       [s16, #0], v3
    a.vread      v3, a5, s22
    v.cmp.lt     p2, v5, v1
    s.add        s1, s6, s17
    vf.cvt.f32.bf16 v1, v3
    s.muli       s16, s19, #1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    s.movz       s22, #2
    s.add        s23, s16, s20
    v.splat      v3, s18
    s.add        s16, s23, s15
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a5, s17
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s17, s6, s16
    p.and        p3, p1, p2
    s.addi       s16, s21, #2
    s.add        s18, s1, s20
    v.splat      v1, s16
    s.add        s1, s18, s15
    s.movz       s16, #3
    s.add        s18, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a5, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #3
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #3
    s.movz       s22, #4
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a5, s16
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #4
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #4
    s.movz       s18, #5
    s.add        s23, s1, s20
    v.splat      v1, s16
    s.add        s1, s23, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a5, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #5
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #5
    s.movz       s22, #6
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a5, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #6
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #6
    s.movz       s18, #7
    s.add        s23, s1, s20
    v.splat      v1, s16
    s.add        s1, s23, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a5, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #7
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #7
    s.movz       s22, #8
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a5, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #8
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #8
    s.movz       s18, #9
    s.add        s23, s1, s20
    v.splat      v1, s16
    s.add        s1, s23, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a5, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #9
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #9
    s.movz       s22, #10
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a5, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #10
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #10
    s.movz       s18, #11
    s.add        s23, s1, s20
    v.splat      v1, s16
    s.add        s1, s23, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a5, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #11
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #11
    s.movz       s22, #12
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a5, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #12
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #12
    s.movz       s18, #13
    s.add        s23, s1, s20
    v.splat      v1, s16
    s.add        s1, s23, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a5, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #13
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #13
    s.movz       s22, #14
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a5, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #14
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s16, s21, #14
    s.movz       s18, #15
    s.add        s23, s1, s20
    v.splat      v1, s16
    s.add        s1, s23, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a5, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #15
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #15
    s.movz       s22, #0
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s15
    s.add        s15, s6, s1
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a5, s18
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s22, s26                    // the tile origin
    s.muli       s16, s26, #2
    v.splat      v1, s1
    s.add        s1, s22, s9                     // the tile origin
    v.splat      v4, s21
    v.add        v5, v0, v1
    s.add        s17, s20, s16
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s1
    @p3 v.st.h       [s15, #0], v3
    a.vread      v3, a6, s22
    v.cmp.lt     p2, v5, v1
    s.add        s1, s6, s17
    vf.cvt.f32.bf16 v1, v3
    s.muli       s15, s19, #1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    s.movz       s22, #2
    s.add        s23, s15, s20
    v.splat      v3, s18
    s.add        s15, s23, s16
    @p3 v.st.h       [s1, #0], v1
    a.vread      v1, a6, s17
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #2
    vf.cvt.f32.bf16 v3, v1
    s.add        s17, s6, s15
    p.and        p3, p1, p2
    s.addi       s15, s21, #2
    s.add        s18, s1, s20
    v.splat      v1, s15
    s.add        s1, s18, s16
    s.movz       s15, #3
    s.add        s18, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a6, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #3
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #3
    s.movz       s22, #4
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s18, #0], v1
    a.vread      v1, a6, s15
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #4
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #4
    s.movz       s18, #5
    s.add        s23, s1, s20
    v.splat      v1, s15
    s.add        s1, s23, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a6, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #5
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #5
    s.movz       s22, #6
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a6, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #6
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #6
    s.movz       s18, #7
    s.add        s23, s1, s20
    v.splat      v1, s15
    s.add        s1, s23, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a6, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #7
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #7
    s.movz       s22, #8
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a6, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #8
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #8
    s.movz       s18, #9
    s.add        s23, s1, s20
    v.splat      v1, s15
    s.add        s1, s23, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a6, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #9
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #9
    s.movz       s22, #10
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a6, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #10
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #10
    s.movz       s18, #11
    s.add        s23, s1, s20
    v.splat      v1, s15
    s.add        s1, s23, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a6, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #11
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #11
    s.movz       s22, #12
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a6, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #12
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #12
    s.movz       s18, #13
    s.add        s23, s1, s20
    v.splat      v1, s15
    s.add        s1, s23, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a6, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #13
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #13
    s.movz       s22, #14
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s16
    s.add        s17, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a6, s18
    v.cmp.lt     p1, v3, v2
    s.muli       s1, s19, #14
    vf.cvt.f32.bf16 v3, v1
    p.and        p3, p1, p2
    s.addi       s15, s21, #14
    s.movz       s18, #15
    s.add        s23, s1, s20
    v.splat      v1, s15
    s.add        s1, s23, s16
    s.add        s15, s6, s1
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a6, s22
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #15
    vf.cvt.f32.bf16 v1, v3
    p.and        p3, p1, p2
    s.addi       s17, s21, #15
    s.movz       s22, #0
    s.add        s23, s1, s20
    v.splat      v3, s17
    s.add        s1, s23, s16
    s.add        s16, s6, s1
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a6, s18
    v.cmp.lt     p1, v3, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s22, s28                    // the tile origin
    s.muli       s15, s28, #2
    v.splat      v1, s1
    s.add        s1, s22, s9                     // the tile origin
    v.splat      v4, s21
    v.add        v5, v0, v1
    v.splat      v0, s1
    s.add        s1, s20, s15
    v.cmp.lt     p1, v4, v2
    @p3 v.st.h       [s16, #0], v3
    a.vread      v1, a7, s22
    v.cmp.lt     p2, v5, v0
    s.add        s16, s6, s1
    vf.cvt.f32.bf16 v0, v1
    s.muli       s1, s19, #1
    p.and        p3, p1, p2
    s.movz       s17, #1
    s.addi       s18, s21, #1
    s.movz       s22, #2
    s.add        s23, s1, s20
    v.splat      v1, s18
    s.add        s1, s23, s15
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a7, s17
    v.cmp.lt     p1, v1, v2
    s.muli       s16, s19, #2
    vf.cvt.f32.bf16 v1, v0
    s.add        s17, s6, s1
    p.and        p3, p1, p2
    s.addi       s1, s21, #2
    s.add        s18, s16, s20
    v.splat      v0, s1
    s.add        s1, s18, s15
    s.movz       s16, #3
    s.add        s18, s6, s1
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s22
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s19, #3
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s17, s21, #3
    s.movz       s22, #4
    s.add        s23, s1, s20
    v.splat      v1, s17
    s.add        s1, s23, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s18, #0], v0
    a.vread      v0, a7, s16
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #4
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s16, s21, #4
    s.movz       s18, #5
    s.add        s23, s1, s20
    v.splat      v0, s16
    s.add        s1, s23, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s22
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s19, #5
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s17, s21, #5
    s.movz       s22, #6
    s.add        s23, s1, s20
    v.splat      v1, s17
    s.add        s1, s23, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a7, s18
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #6
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s16, s21, #6
    s.movz       s18, #7
    s.add        s23, s1, s20
    v.splat      v0, s16
    s.add        s1, s23, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s22
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s19, #7
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s17, s21, #7
    s.movz       s22, #8
    s.add        s23, s1, s20
    v.splat      v1, s17
    s.add        s1, s23, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a7, s18
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #8
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s16, s21, #8
    s.movz       s18, #9
    s.add        s23, s1, s20
    v.splat      v0, s16
    s.add        s1, s23, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s22
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s19, #9
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s17, s21, #9
    s.movz       s22, #10
    s.add        s23, s1, s20
    v.splat      v1, s17
    s.add        s1, s23, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a7, s18
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #10
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s16, s21, #10
    s.movz       s18, #11
    s.add        s23, s1, s20
    v.splat      v0, s16
    s.add        s1, s23, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s22
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s19, #11
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s17, s21, #11
    s.movz       s22, #12
    s.add        s23, s1, s20
    v.splat      v1, s17
    s.add        s1, s23, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a7, s18
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #12
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s16, s21, #12
    s.movz       s18, #13
    s.add        s23, s1, s20
    v.splat      v0, s16
    s.add        s1, s23, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s22
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s19, #13
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s17, s21, #13
    s.movz       s22, #14
    s.add        s23, s1, s20
    v.splat      v1, s17
    s.add        s1, s23, s15
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a7, s18
    v.cmp.lt     p1, v1, v2
    s.muli       s1, s19, #14
    vf.cvt.f32.bf16 v1, v0
    p.and        p3, p1, p2
    s.addi       s16, s21, #14
    s.movz       s18, #15
    s.add        s23, s1, s20
    v.splat      v0, s16
    s.add        s1, s23, s15
    s.add        s16, s6, s1
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a7, s22
    v.cmp.lt     p1, v0, v2
    s.muli       s1, s19, #15
    vf.cvt.f32.bf16 v0, v1
    p.and        p3, p1, p2
    s.addi       s17, s21, #15
    s.addi       s19, s4, #16
    s.add        s21, s1, s20
    v.splat      v1, s17
    s.add        s1, s21, s15
    s.movz       s15, #64
    s.add        s17, s6, s1
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a7, s18
    v.cmp.lt     p1, v1, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v0
    @p3 v.st.h       [s17, #0], v1
    s.mov        s4, s19
    s.cmp.lt     s1, s4, s15
    br.nz        s1, rows_1
endrows_2:
    exit
    exit
