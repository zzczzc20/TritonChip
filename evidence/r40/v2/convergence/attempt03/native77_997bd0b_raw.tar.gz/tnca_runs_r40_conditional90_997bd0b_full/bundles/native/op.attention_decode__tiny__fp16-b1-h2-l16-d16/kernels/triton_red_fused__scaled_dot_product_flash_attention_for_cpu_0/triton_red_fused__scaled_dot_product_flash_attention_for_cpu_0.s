    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    v.movi       v2, #4
    s.rdspecial  s1, arg_base
    v.sub        v3, v1, v0
    v.cmp.lt     p1, v0, v1
    v.movi       v4, #16
    @p1 v.sel        v5, v3, v0
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.iota       v0                              // arange(0, VLEN)
    v.lshr       v3, v5, v2
    s.shli       s3, s4, #4                      // x16 as a shift
    v.movi       v2, #16
    v.sub        v5, v1, v3
    s.shli       s5, s3, #1                      // element offset -> bytes (x2)
    v.cmp.lt     p2, v0, v2
    @p1 v.sel        v2, v5, v3
    .li       s6, #1056964608
    v.splat      v3, s6                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v5, #0
    s.ld.d       s6, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.mul        v6, v2, v4
    s.add        s7, s2, s5                      // &in_ptr1[...]
    v.movi       v2, #0
    v.extract    s2, v6, #0
    s.shli       s5, s4, #2                      // element offset -> bytes (x4)
    v.splat      v6, s2
    v.iota       v7                              // arange(0, VLEN)
    v.sub        v8, v1, v4
    v.add        v9, v0, v6
    v.cmp.lt     p1, v4, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v1, [s7, #0]
    v.cmpi.lt    p3, v7, #1
    v.splat      v6, s3
    @p1 v.sel        v7, v8, v4
    v.add        v4, v0, v6
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v0, [s6, v9]               // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v4, v1
    vf.mul       v1, v4, v3
    vf.cvt.f16.f32 v4, v0
    s.ld.d       s2, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    vf.mul       v0, v4, v3
    vf.mul       v3, v0, v1
    s.add        s1, s2, s5                      // &out_ptr0[...]
    vf.add       v0, v3, v5
    @p2 v.sel        v1, v0, v5
    vf.reduce.add.b v0, v1
    vf.add       v1, v0, v2
    @p3 v.st.w       [s1, #0], v1
__rctx_next:
    exit
