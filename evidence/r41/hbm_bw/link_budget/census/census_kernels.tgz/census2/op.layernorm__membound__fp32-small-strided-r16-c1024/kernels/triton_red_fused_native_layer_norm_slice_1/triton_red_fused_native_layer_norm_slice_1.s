    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #8]                    // in_ptr0: device_ptr64 at arg_base+8
    s.movz       s5, #0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s5
    s.rdspecial  s6, role_id
    s.movz       s7, #256
    v.add        v2, v1, v0
    v.movi       v0, #0
    v.splat      v1, s4
    v.movi       v3, #0
    s.mul        s8, s6, s7
    s.ld.d       s6, [s2, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.muli       s2, s4, #32
    v.cmp.ge     p1, v2, v0
    v.cmpi.lt    p2, v2, #8
    v.cmp.ge     p3, v1, v3
    v.cmpi.lt    p4, v1, #16
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    v.iota       v0                              // arange(0, VLEN)
    s.add        s7, s3, s2
    p.and        p2, p5, p1
    s.add        s2, s6, s8                      // this context's own scratch
    v.cmpi.lt    p1, v0, #8
    s.addi       s6, s2, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s2, #16
    s.movz       s8, #8
    s.movz       s9, #32
    s.movz       s10, #4
    s.add        s11, s7, s5
    .li       s5, #34359738369
    p.and        p3, p1, p2
    s.ld.d       s7, [s1, #0]                    // in_out_ptr0: device_ptr64 at arg_base+0
    .li       s1, #1149239296
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    v.iota       v2                              // arange(0, VLEN)
    v.rcp.approx v3, v0                          // ISA 8.8: <= 2**-22 relative
    v.movi       v4, #8
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #0
    v.cmp.lt     p1, v2, v4
    v.cmpi.lt    p2, v5, #8
    s.st.d       [s6, #0], s3
    .li       s1, #2207613190144
    .li       s3, #1065353216
    v.splat      v2, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.st.d       [s6, #8], s2
    vf.fms       v4, v0, v3, v2
    s.st.d       [s6, #16], s8
    vf.fms       v0, v3, v4, v3
    vf.neg       v2, v0                          // Newton step: r0*(2 - x*r0)
    s.st.d       [s6, #48], s9
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.cmp.o     p4, v2, v2
    @p4 v.sel        v0, v2, v3
    s.st.d       [s6, #56], s10
    v.iota       v2                              // arange(0, VLEN)
    s.add        s3, s7, s2                      // &in_out_ptr0[...]
    s.st.d       [s6, #88], s5
    v.cmpi.lt    p4, v2, #1
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v2, [s11, #0]
    vf.add       v3, v2, v1
    @p1 v.sel        v2, v3, v1
    @p2 vf.reduce.add.b v1, v2
    vf.add       v2, v1, v6
    vf.mul       v1, v2, v0                      // a/y as a refined reciprocal (ISA has no divide)
    @p4 v.st.w       [s3, #0], v1
__rctx_next:
    exit
