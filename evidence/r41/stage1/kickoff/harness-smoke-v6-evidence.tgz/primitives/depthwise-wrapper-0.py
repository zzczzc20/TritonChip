# AOT ID: ['1_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-stage1/runs/harness-smoke-v6/primitives/inductor-cache/cs/ccsoiizxwlzsozcpcfgys2esa5z5aqzpt4afsma4y5r4v5vffsun.py
# Topologically Sorted Source Nodes: [conv1d], Original ATen: [aten.convolution]
# Source node to ATen node mapping:
#   conv1d => add, add_1, add_2, constant_pad_nd, convert_element_type, convert_element_type_1, convert_element_type_2, mul, mul_1, mul_2, mul_3, select, select_1, select_2, select_3, select_4, select_5, select_6, select_7, slice_1, slice_2, slice_3, slice_4, view, view_1, view_2, view_3
# Graph fragment:
#   %arg0_1 : Tensor "bf16[1, 8, 7][56, 7, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "bf16[8, 1, 4][4, 4, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %convert_element_type : Tensor "f32[1, 8, 7][56, 7, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %constant_pad_nd : Tensor "f32[1, 8, 13][104, 13, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.aten.constant_pad_nd.default](args = (%convert_element_type, [3, 3], 0.0), kwargs = {})
#   %slice_1 : Tensor "f32[1, 8, 10][104, 13, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%constant_pad_nd, 2, 0, 10), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[8, 1, 4][4, 4, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg1_1, torch.float32), kwargs = {})
#   %select : Tensor "f32[8, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_1, 1, 0), kwargs = {})
#   %select_1 : Tensor "f32[8][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select, 1, 0), kwargs = {})
#   %view : Tensor "f32[1, 8, 1][32, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_1, [1, -1, 1]), kwargs = {})
#   %mul : Tensor "f32[1, 8, 10][80, 10, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_1, %view), kwargs = {})
#   %slice_2 : Tensor "f32[1, 8, 10][104, 13, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%constant_pad_nd, 2, 1, 11), kwargs = {})
#   %select_2 : Tensor "f32[8, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_1, 1, 0), kwargs = {})
#   %select_3 : Tensor "f32[8][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_2, 1, 1), kwargs = {})
#   %view_1 : Tensor "f32[1, 8, 1][32, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_3, [1, -1, 1]), kwargs = {})
#   %mul_1 : Tensor "f32[1, 8, 10][80, 10, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_2, %view_1), kwargs = {})
#   %add : Tensor "f32[1, 8, 10][80, 10, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul, %mul_1), kwargs = {})
#   %slice_3 : Tensor "f32[1, 8, 10][104, 13, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%constant_pad_nd, 2, 2, 12), kwargs = {})
#   %select_4 : Tensor "f32[8, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_1, 1, 0), kwargs = {})
#   %select_5 : Tensor "f32[8][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_4, 1, 2), kwargs = {})
#   %view_2 : Tensor "f32[1, 8, 1][32, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_5, [1, -1, 1]), kwargs = {})
#   %mul_2 : Tensor "f32[1, 8, 10][80, 10, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_3, %view_2), kwargs = {})
#   %add_1 : Tensor "f32[1, 8, 10][80, 10, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add, %mul_2), kwargs = {})
#   %slice_4 : Tensor "f32[1, 8, 10][104, 13, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%constant_pad_nd, 2, 3, 13), kwargs = {})
#   %select_6 : Tensor "f32[8, 4][4, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%convert_element_type_1, 1, 0), kwargs = {})
#   %select_7 : Tensor "f32[8][4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_6, 1, 3), kwargs = {})
#   %view_3 : Tensor "f32[1, 8, 1][32, 4, 4]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%select_7, [1, -1, 1]), kwargs = {})
#   %mul_3 : Tensor "f32[1, 8, 10][80, 10, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_4, %view_3), kwargs = {})
#   %add_2 : Tensor "f32[1, 8, 10][80, 10, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_1, %mul_3), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 8, 10][80, 10, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_2, torch.bfloat16), kwargs = {})
#   return %convert_element_type_2
triton_poi_fused_convolution_0 = async_compile.triton('triton_poi_fused_convolution_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 128}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_convolution_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 768}, 'backend_hash': '3E8E04ED6BFC355D1139BFACB5D0C56A8D538B9745F0F37C599EC44DE4E7E5F2', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_convolution_0(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 80
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 10)
    x1 = xindex // 10
    x2 = xindex
    tmp10 = tl.load(in_ptr1 + (4*x1), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp21 = tl.load(in_ptr1 + (1 + 4*x1), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp33 = tl.load(in_ptr1 + (2 + 4*x1), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp45 = tl.load(in_ptr1 + (3 + 4*x1), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp0 = ((-3) + x0).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 7, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = tmp2 & tmp4
    tmp6 = tl.load(in_ptr0 + ((-3) + x0 + 7*x1), tmp5 & xmask, other=0.0).to(tl.float32)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tl.full(tmp7.shape, 0.0, tmp7.dtype)
    tmp9 = tl.where(tmp5, tmp7, tmp8)
    tmp11 = tmp10.to(tl.float32)
    tmp12 = tmp9 * tmp11
    tmp13 = ((-2) + x0).to(tl.int32)
    tmp14 = tmp13 >= tmp1
    tmp15 = tmp13 < tmp3
    tmp16 = tmp14 & tmp15
    tmp17 = tl.load(in_ptr0 + ((-2) + x0 + 7*x1), tmp16 & xmask, other=0.0).to(tl.float32)
    tmp18 = tmp17.to(tl.float32)
    tmp19 = tl.full(tmp18.shape, 0.0, tmp18.dtype)
    tmp20 = tl.where(tmp16, tmp18, tmp19)
    tmp22 = tmp21.to(tl.float32)
    tmp23 = tmp20 * tmp22
    tmp24 = tmp12 + tmp23
    tmp25 = ((-1) + x0).to(tl.int32)
    tmp26 = tmp25 >= tmp1
    tmp27 = tmp25 < tmp3
    tmp28 = tmp26 & tmp27
    tmp29 = tl.load(in_ptr0 + ((-1) + x0 + 7*x1), tmp28 & xmask, other=0.0).to(tl.float32)
    tmp30 = tmp29.to(tl.float32)
    tmp31 = tl.full(tmp30.shape, 0.0, tmp30.dtype)
    tmp32 = tl.where(tmp28, tmp30, tmp31)
    tmp34 = tmp33.to(tl.float32)
    tmp35 = tmp32 * tmp34
    tmp36 = tmp24 + tmp35
    tmp37 = (x0).to(tl.int32)
    tmp38 = tmp37 >= tmp1
    tmp39 = tmp37 < tmp3
    tmp40 = tmp38 & tmp39
    tmp41 = tl.load(in_ptr0 + (x0 + 7*x1), tmp40 & xmask, other=0.0).to(tl.float32)
    tmp42 = tmp41.to(tl.float32)
    tmp43 = tl.full(tmp42.shape, 0.0, tmp42.dtype)
    tmp44 = tl.where(tmp40, tmp42, tmp43)
    tmp46 = tmp45.to(tl.float32)
    tmp47 = tmp44 * tmp46
    tmp48 = tmp36 + tmp47
    tmp49 = tmp48.to(tl.float32)
    tl.store(out_ptr0 + (x2), tmp49, xmask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1), ((1, 8, 7), (8, 1, 4)), ((56, 7, 1), (4, 4, 1)), 'input')
        buf0 = empty_strided((1, 8, 10), (80, 10, 1), device='tnca', dtype=torch.bfloat16)
        # Topologically Sorted Source Nodes: [conv1d], Original ATen: [aten.convolution]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_0.run(arg0_1, arg1_1, buf0, 80, stream=raw_stream0)
        del arg0_1
        del arg1_1
        return (reinterpret_tensor(buf0, (1, 8, 7), (80, 10, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 8, 7), (56, 7, 1), device='tnca:0', dtype=torch.bfloat16)
    arg1_1 = rand_strided((8, 1, 4), (4, 4, 1), device='tnca:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
