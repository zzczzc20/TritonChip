# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /tmp/torchinductor_zzhouch/ky/ckysgh4smmxenkh7zv3w7y5ubg34aaxvzouyghyv56twlayrrdak.py
# Topologically Sorted Source Nodes: [layer_norm], Original ATen: [aten.native_layer_norm]
# Source node to ATen node mapping:
#   layer_norm => add, add_1, convert_element_type, convert_element_type_1, mul, mul_1, rsqrt, sub, var_mean
# Graph fragment:
#   %arg0_1 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %buf0 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0" = PlaceHolder[target=buf0]
#   %getitem_1 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0" = PlaceHolder[target=getitem_1]
#   %buf2 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0" = PlaceHolder[target=buf2]
#   %arg1_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg2_1]
#   %convert_element_type : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %var_mean : [num_users=2] = call_function[target=torch.ops.aten.var_mean.correction](args = (%convert_element_type, [2]), kwargs = {correction: 0, keepdim: True})
#   %sub : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%convert_element_type, %getitem_1), kwargs = {})
#   %add : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%getitem, 1e-05), kwargs = {})
#   %rsqrt : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg1_1), kwargs = {})
#   %add_1 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_1, %arg2_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_1, torch.float16), kwargs = {})
#   return %buf0,%getitem_1,%buf2,%convert_element_type_1
triton_red_fused_native_layer_norm_0 = async_compile.triton('triton_red_fused_native_layer_norm_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_native_layer_norm_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 6400}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_native_layer_norm_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    _tmp3 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 64*x0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tl.broadcast_to(tmp1, [R0_BLOCK])
        tmp4 = _tmp3 + tmp2
        _tmp3 = tl.where(r0_mask, tmp4, _tmp3)
    tmp3 = triton_helpers.promote_to_tensor(tl.sum(_tmp3, 0))
    tmp5 = tl.full([1], 64.0, tl.float32)
    tmp6 = (tmp3 / tmp5)
    _tmp12 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp7 = tl.load(in_ptr0 + (r0_1 + 64*x0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp8 - tmp6
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
    tmp12 = triton_helpers.promote_to_tensor(tl.sum(_tmp12, 0))
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp14 = tl.load(in_ptr0 + (r0_1 + 64*x0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp23 = tl.load(in_ptr1 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp26 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp15 = tmp14.to(tl.float32)
        tmp16 = tmp15 - tmp6
        tmp17 = tl.full([1], 64.0, tl.float32)
        tmp18 = (tmp12 / tmp17)
        tmp19 = tl.full([1], 1e-05, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = libdevice.rsqrt(tmp20)
        tmp22 = tmp16 * tmp21
        tmp24 = tmp23.to(tl.float32)
        tmp25 = tmp22 * tmp24
        tmp27 = tmp26.to(tl.float32)
        tmp28 = tmp25 + tmp27
        tmp29 = tmp28.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 64*x0), tmp29, r0_mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/sp/csps6ajmfd2kryjkahb5m5yd6tx22ltehpmsfgoefmy4yjzyjzmo.py
# Topologically Sorted Source Nodes: [layer_norm, linear], Original ATen: [aten.native_layer_norm, aten.view, aten.t, aten.addmm]
# Source node to ATen node mapping:
#   layer_norm => add, add_1, convert_element_type, convert_element_type_1, mul, mul_1, rsqrt, sub, var_mean
#   linear => addmm, permute, view
# Graph fragment:
#   %arg4_1 : Tensor "f16[192][1]tnca:0" = PlaceHolder[target=arg4_1]
#   %convert_element_type_1 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0" = PlaceHolder[target=convert_element_type_1]
#   %arg3_1 : Tensor "f16[192, 64][64, 1]tnca:0" = PlaceHolder[target=arg3_1]
#   %convert_element_type : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.float32), kwargs = {})
#   %var_mean : [num_users=2] = call_function[target=torch.ops.aten.var_mean.correction](args = (%convert_element_type, [2]), kwargs = {correction: 0, keepdim: True})
#   %sub : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%convert_element_type, %getitem_1), kwargs = {})
#   %add : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%getitem, 1e-05), kwargs = {})
#   %rsqrt : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg1_1), kwargs = {})
#   %add_1 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_1, %arg2_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_1, torch.float16), kwargs = {})
#   %view : Tensor "f16[16, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_1, [16, 64]), kwargs = {})
#   %permute : Tensor "f16[64, 192][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg3_1, [1, 0]), kwargs = {})
#   %addmm : Tensor "f16[16, 192][192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.addmm.default](args = (%arg4_1, %view, %permute), kwargs = {})
#   return %addmm
triton_tem_fused_addmm_native_layer_norm_t_view_1 = async_compile.triton('triton_tem_fused_addmm_native_layer_norm_t_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'in_ptr0': '*fp16', 'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_addmm_native_layer_norm_t_view_1', 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_addmm_native_layer_norm_t_view_1(in_ptr0, arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 16
    N = 192
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 64
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 192*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 192*idx_m
    tmp0 = tl.load(in_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = acc + tmp0
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp1, mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/7v/c7vccx4h76zs4stvtkt3flj6smtecz32syjliurrtifd3xv5aggu.py
# Topologically Sorted Source Nodes: [linear, split, view, q_1, scaled_dot_product_attention], Original ATen: [aten.view, aten.split, aten.transpose, aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   linear => view_1
#   q_1 => permute_1
#   scaled_dot_product_attention => convert_element_type_5, mul_2
#   split => split
#   view => view_2
# Graph fragment:
#   %addmm : Tensor "f16[16, 192][192, 1]tnca:0" = PlaceHolder[target=addmm]
#   %view_1 : Tensor "f16[1, 16, 192][3072, 192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [1, 16, 192]), kwargs = {})
#   %split : [num_users=3] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_1, 64, -1), kwargs = {})
#   %view_2 : Tensor "f16[1, 16, 4, 16][3072, 192, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_2, [1, 16, 4, 16]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 4, 16, 16][3072, 16, 192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_1, torch.float32), kwargs = {})
#   %mul_2 : Tensor "f32[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_5, 0.5), kwargs = {})
#   return %expand
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_2 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 10240}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_2(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 16)
    x1 = ((xindex // 16) % 16)
    x2 = xindex // 256
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 16*x2 + 192*x1), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.full([1], 0.5, tl.float32)
    tmp3 = tmp1 * tmp2
    tl.store(out_ptr0 + (x3), tmp3, xmask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/yy/cyy376jdwbffgwjr2b62rqfvwkf2fm2ol4bjnv4g7sbnheyec6fv.py
# Topologically Sorted Source Nodes: [linear, split, view_1, k_1, scaled_dot_product_attention], Original ATen: [aten.view, aten.split, aten.transpose, aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   k_1 => permute_2
#   linear => view_1
#   scaled_dot_product_attention => convert_element_type_6, mul_3, permute_4
#   split => split
#   view_1 => view_3
# Graph fragment:
#   %addmm : Tensor "f16[16, 192][192, 1]tnca:0" = PlaceHolder[target=addmm]
#   %view_1 : Tensor "f16[1, 16, 192][3072, 192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [1, 16, 192]), kwargs = {})
#   %split : [num_users=3] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_1, 64, -1), kwargs = {})
#   %view_3 : Tensor "f16[1, 16, 4, 16][3072, 192, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_3, [1, 16, 4, 16]), kwargs = {})
#   %permute_2 : Tensor "f16[1, 4, 16, 16][3072, 16, 192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_3, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_6 : Tensor "f32[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_2, torch.float32), kwargs = {})
#   %permute_4 : Tensor "f32[1, 4, 16, 16][1024, 16, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_6, [0, 1, 3, 2]), kwargs = {})
#   %mul_3 : Tensor "f32[1, 4, 16, 16][1024, 16, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_4, 0.5), kwargs = {})
#   return %expand_1
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_3 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'y': 64, 'x': 16}, tile_hint=TileHint.SQUARE,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'y': 2048, 'x': 8192}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'YBLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_3(in_ptr0, out_ptr0, ynumel, xnumel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 64
    xnumel = 16
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :]
    xmask = xindex < xnumel
    x1 = xindex
    y0 = yindex
    tmp0 = tl.trans(tl.make_tensor_descriptor(in_ptr0 + (64), shape=[16, 64], strides=[192, 1], block_shape=[XBLOCK, YBLOCK]).load([xoffset, yoffset]), [1, 0]).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.full([1, 1], 0.5, tl.float32)
    tmp3 = tmp1 * tmp2
    tl.store(out_ptr0 + (x1 + 16*y0), tmp3, xmask & ymask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/kn/cknet7up2esuvofx3s65fwxkoyygwnclgpmwjjwfuwaalf3wptgc.py
# Topologically Sorted Source Nodes: [linear, split, view, q_1, scaled_dot_product_attention, view_1, k_1], Original ATen: [aten.view, aten.split, aten.transpose, aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   k_1 => permute_2
#   linear => view_1
#   q_1 => permute_1
#   scaled_dot_product_attention => bmm, convert_element_type_5, convert_element_type_6, mul_2, mul_3, permute_4, view_5, view_6
#   split => split
#   view => view_2
#   view_1 => view_3
# Graph fragment:
#   %expand : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0" = PlaceHolder[target=expand]
#   %expand_1 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0" = PlaceHolder[target=expand_1]
#   %view_1 : Tensor "f16[1, 16, 192][3072, 192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [1, 16, 192]), kwargs = {})
#   %split : [num_users=3] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_1, 64, -1), kwargs = {})
#   %view_2 : Tensor "f16[1, 16, 4, 16][3072, 192, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_2, [1, 16, 4, 16]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 4, 16, 16][3072, 16, 192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_1, torch.float32), kwargs = {})
#   %mul_2 : Tensor "f32[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_5, 0.5), kwargs = {})
#   %view_5 : Tensor "f32[4, 16, 16][16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand, [4, 16, 16]), kwargs = {})
#   %view_3 : Tensor "f16[1, 16, 4, 16][3072, 192, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_3, [1, 16, 4, 16]), kwargs = {})
#   %permute_2 : Tensor "f16[1, 4, 16, 16][3072, 16, 192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_3, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_6 : Tensor "f32[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_2, torch.float32), kwargs = {})
#   %permute_4 : Tensor "f32[1, 4, 16, 16][1024, 16, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_6, [0, 1, 3, 2]), kwargs = {})
#   %mul_3 : Tensor "f32[1, 4, 16, 16][1024, 16, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_4, 0.5), kwargs = {})
#   %view_6 : Tensor "f32[4, 16, 16][16, 1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_1, [4, 16, 16]), kwargs = {})
#   %bmm : Tensor "f32[4, 16, 16][256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_5, %view_6), kwargs = {})
#   return %bmm
triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_4 = async_compile.triton('triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp32', 'arg_B': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_4', 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_4(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 16
    N = 16
    K = 16
    BATCH = 4

    stride_aq = 256
    stride_am = 16
    stride_ak = 1

    stride_bq = 256
    stride_bk = 16
    stride_bn = 1

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        ram = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        ram = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        rbn = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        rbn = rn % N

    rk = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)

    # Reconstruct batch index from grid_y/grid_z split (handles batch > 65535)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    # Clamp to valid range for safe pointer arithmetic; out-of-bounds CTAs are
    # masked off at the store below.
    idx_q_clamped = tl.minimum(idx_q, BATCH - 1)
    A = A + (ram[:, None] * stride_am + rk[None, :] * stride_ak + idx_q_clamped*stride_aq)
    B = B + (rk[:, None] * stride_bk + rbn[None, :] * stride_bn + idx_q_clamped*stride_bq)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)
    for k in range(K, 0, -BLOCK_K):
        if EVEN_K:
            a = tl.load(A)
            b = tl.load(B)
        else:
            a = tl.load(A, mask=rk[None, :] < k, other=0.)
            b = tl.load(B, mask=rk[:, None] < k, other=0.)
        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32)
        A += BLOCK_K * stride_ak
        B += BLOCK_K * stride_bk

    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_q = (tl.program_id(1) + tl.program_id(2) * tl.num_programs(1)).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N) & (idx_q < BATCH)

    # inductor generates a suffix
    xindex = idx_n + 16*idx_m + 256*idx_q
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/wd/cwd3h7kpaskrqzmyqziaab4piorksmnh52wbs7bnfa7opgb6x4zb.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => add_2, amax, any_1, div, eq, exp, full_default, full_default_1, full_default_2, full_default_3, iota, iota_1, le, logical_and, logical_not, logical_not_1, sub_1, sub_2, sum_1, unsqueeze, unsqueeze_1, view_7, where, where_1
# Graph fragment:
#   %bmm : Tensor "f32[4, 16, 16][256, 16, 1]tnca:0" = PlaceHolder[target=bmm]
#   %amax : Tensor "f32[1, 4, 16, 1][64, 16, 1, 64]tnca:0" = PlaceHolder[target=amax]
#   %exp : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0" = PlaceHolder[target=exp]
#   %any_1 : Tensor "b8[1, 4, 16, 1][64, 16, 1, 64]tnca:0" = PlaceHolder[target=any_1]
#   %sum_1 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 64]tnca:0" = PlaceHolder[target=sum_1]
#   %view_7 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 4, 16, 16]), kwargs = {})
#   %iota : Tensor "i64[16][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (16,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze : Tensor "i64[1, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota, -2), kwargs = {})
#   %iota_1 : Tensor "i64[16][1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (16,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: tnca:0, requires_grad: False})
#   %unsqueeze_1 : Tensor "i64[16, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%iota_1, -1), kwargs = {})
#   %sub_1 : Tensor "i64[16, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%unsqueeze, %unsqueeze_1), kwargs = {})
#   %le : Tensor "b8[16, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.le.Scalar](args = (%sub_1, 0), kwargs = {})
#   %full_default : Tensor "b8[16, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([16, 16], True), kwargs = {dtype: torch.bool, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %logical_and : Tensor "b8[16, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_and.default](args = (%le, %full_default), kwargs = {})
#   %full_default_2 : Tensor "f32[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], 0.0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %full_default_1 : Tensor "f32[][]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([], -inf), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %where : Tensor "f32[16, 16][16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_and, %full_default_2, %full_default_1), kwargs = {})
#   %add_2 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%view_7, %where), kwargs = {})
#   %eq : Tensor "b8[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%add_2, -inf), kwargs = {})
#   %logical_not : Tensor "b8[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq,), kwargs = {})
#   %any_1 : Tensor "b8[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.any.dim](args = (%logical_not, -1, True), kwargs = {})
#   %logical_not_1 : Tensor "b8[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default_3 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 4, 16, 16], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %amax : Tensor "f32[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%add_2, [-1], True), kwargs = {})
#   %sub_2 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%add_2, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub_2,), kwargs = {})
#   %sum_1 : Tensor "f32[1, 4, 16, 1][64, 16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp, [-1], True), kwargs = {})
#   %div : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where_1 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default_3, %div), kwargs = {})
#   return %any_1,%amax,%exp,%sum_1,%expand_2
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_5 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 16},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_5', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 2, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 12288}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_5(in_out_ptr0, in_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 64
    XBLOCK: tl.constexpr = 1
    r0_numel = 16
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x3 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr0, shape=[64, 16], strides=[16, 1], block_shape=[XBLOCK, R0_BLOCK])
    x0 = (xindex % 16)
    _tmp16 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp20 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp1 = (r0_2 + ((-1)*x0)).to(tl.int64)
        tmp2 = (tmp1).to(tl.int64)
        tmp3 = tl.full([1], 0, tl.int64)
        tmp4 = tmp2 <= tmp3
        tmp5 = tl.full([1], True, tl.int1)
        tmp6 = tmp4 & tmp5
        tmp7 = tl.full([1], 0.0, tl.float32)
        tmp8 = tl.full([1], float("-inf"), tl.float32)
        tmp9 = tl.where(tmp6, tmp7, tmp8)
        tmp10 = tmp0 + tmp9
        tmp11 = tmp10 == tmp8
        tmp12 = tmp11 == 0
        tmp13 = tmp12.to(tl.int64)
        tmp14 = (tmp13 != 0)
        tmp15 = tl.broadcast_to(tmp14, [R0_BLOCK])
        tmp17 = _tmp16 | tmp15
        _tmp16 = tl.where(r0_mask, tmp17, _tmp16)
        tmp19 = tl.broadcast_to(tmp10, [R0_BLOCK])
        tmp21 = tl.maximum(_tmp20, tmp19, tl.PropagateNan.ALL)
        _tmp20 = tl.where(r0_mask, tmp21, _tmp20)
    tmp18 = _tmp16.to(tl.int8)
    tmp16 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp18, 0))
    tmp20 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp20, 0))
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[64, 16], strides=[16, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp36 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp22 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp23 = (r0_2 + ((-1)*x0)).to(tl.int64)
        tmp24 = (tmp23).to(tl.int64)
        tmp25 = tl.full([1], 0, tl.int64)
        tmp26 = tmp24 <= tmp25
        tmp27 = tl.full([1], True, tl.int1)
        tmp28 = tmp26 & tmp27
        tmp29 = tl.full([1], 0.0, tl.float32)
        tmp30 = tl.full([1], float("-inf"), tl.float32)
        tmp31 = tl.where(tmp28, tmp29, tmp30)
        tmp32 = tmp22 + tmp31
        tmp33 = tmp32 - tmp20
        tmp34 = libdevice.exp(tmp33)
        tmp35 = tl.broadcast_to(tmp34, [R0_BLOCK])
        tmp37 = _tmp36 + tmp35
        _tmp36 = tl.where(r0_mask, tmp37, _tmp36)
        tl.store(in_out_ptr0 + (r0_2 + 16*x3), tmp34, r0_mask)
    tmp36 = triton_helpers.promote_to_tensor(tl.sum(_tmp36, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[64, 16], strides=[16, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tl.debug_barrier()
        tmp39 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK])
        tmp38 = tmp16 == 0
        tmp40 = (tmp39 / tmp36)
        tmp41 = tl.full([1], 0.0, tl.float32)
        tmp42 = tl.where(tmp38, tmp41, tmp40)
        tl.store(in_out_ptr0 + (r0_2 + 16*x3), tmp42, r0_mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/7f/c7fpwt2zzfzpvbrtkfiuis2qhdqebjos53is5spn6pul3wgdta2l.py
# Topologically Sorted Source Nodes: [linear, split, view_2, v_1, scaled_dot_product_attention], Original ATen: [aten.view, aten.split, aten.transpose, aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   linear => view_1
#   scaled_dot_product_attention => convert_element_type_7
#   split => split
#   v_1 => permute_3
#   view_2 => view_4
# Graph fragment:
#   %addmm : Tensor "f16[16, 192][192, 1]tnca:0" = PlaceHolder[target=addmm]
#   %view_1 : Tensor "f16[1, 16, 192][3072, 192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [1, 16, 192]), kwargs = {})
#   %split : [num_users=3] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_1, 64, -1), kwargs = {})
#   %view_4 : Tensor "f16[1, 16, 4, 16][3072, 192, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_4, [1, 16, 4, 16]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 4, 16, 16][3072, 16, 192, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_4, [0, 2, 1, 3]), kwargs = {})
#   %convert_element_type_7 : Tensor "f32[1, 4, 16, 16][1024, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_3, torch.float32), kwargs = {})
#   return %expand_3
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_6 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 10240}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_6(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 16)
    x1 = ((xindex // 16) % 16)
    x2 = xindex // 256
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (128 + x0 + 16*x2 + 192*x1), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp1, xmask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/ur/cur37ynwhuyddf4lxowjdyxbg3upwo6tdbxcqk5k6kcnbegtb3sq.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   scaled_dot_product_attention => clone, convert_element_type_9, permute_5, view_10
# Graph fragment:
#   %bmm_1 : Tensor "f32[4, 16, 16][256, 16, 1]tnca:0" = PlaceHolder[target=bmm_1]
#   %view_10 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 4, 16, 16]), kwargs = {})
#   %convert_element_type_9 : Tensor "f16[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float16), kwargs = {})
#   %permute_5 : Tensor "f16[16, 1, 4, 16][16, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_9, [2, 0, 1, 3]), kwargs = {})
#   %clone : Tensor "f16[16, 1, 4, 16][64, 64, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%permute_5,), kwargs = {memory_format: torch.contiguous_format})
#   return %clone
triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_7 = async_compile.triton('triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 8192}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_7(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 16)
    x1 = ((xindex // 16) % 4)
    x2 = xindex // 64
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 16*x2 + 256*x1), xmask)
    tmp1 = tmp0.to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp1, xmask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/j6/cj62i2nttmfc6p4mrz7tfqfwdiyi3zvyl4gkvoz35b3gm73swtty.py
# Topologically Sorted Source Nodes: [scaled_dot_product_attention, transpose_3, o, linear_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.addmm]
# Source node to ATen node mapping:
#   linear_1 => addmm_1, permute_8, view_12
#   o => view_11
#   scaled_dot_product_attention => clone, convert_element_type_9, permute_5, permute_6, view_10
#   transpose_3 => permute_7
# Graph fragment:
#   %arg6_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg6_1]
#   %clone : Tensor "f16[16, 1, 4, 16][64, 1, 16, 1]tnca:0" = PlaceHolder[target=clone]
#   %arg5_1 : Tensor "f16[64, 64][64, 1]tnca:0" = PlaceHolder[target=arg5_1]
#   %view_10 : Tensor "f32[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 4, 16, 16]), kwargs = {})
#   %convert_element_type_9 : Tensor "f16[1, 4, 16, 16][1024, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float16), kwargs = {})
#   %permute_5 : Tensor "f16[16, 1, 4, 16][16, 1024, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_9, [2, 0, 1, 3]), kwargs = {})
#   %clone : Tensor "f16[16, 1, 4, 16][64, 64, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%permute_5,), kwargs = {memory_format: torch.contiguous_format})
#   %permute_6 : Tensor "f16[1, 4, 16, 16][64, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%clone, [1, 2, 0, 3]), kwargs = {})
#   %permute_7 : Tensor "f16[1, 16, 4, 16][64, 64, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%permute_6, [0, 2, 1, 3]), kwargs = {})
#   %view_11 : Tensor "f16[1, 16, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%permute_7, [1, 16, 64]), kwargs = {})
#   %view_12 : Tensor "f16[16, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_11, [16, 64]), kwargs = {})
#   %permute_8 : Tensor "f16[64, 64][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg5_1, [1, 0]), kwargs = {})
#   %addmm_1 : Tensor "f16[16, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.addmm.default](args = (%arg6_1, %view_12, %permute_8), kwargs = {})
#   return %addmm_1
triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_addmm_t_transpose_view_8 = async_compile.triton('triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_addmm_t_transpose_view_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'in_ptr0': '*fp16', 'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_addmm_t_transpose_view_8', 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_addmm_t_transpose_view_8(in_ptr0, arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 16
    N = 64
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 64
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 64*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 64*idx_m
    tmp0 = tl.load(in_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = acc + tmp0
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp1, mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/34/c34j22gyqkuqyl3isaopts33ek6wgisy777kjrnl3rgwm4t7px57.py
# Topologically Sorted Source Nodes: [linear_1, x, layer_norm_1], Original ATen: [aten.view, aten.add, aten.native_layer_norm]
# Source node to ATen node mapping:
#   layer_norm_1 => add_4, add_5, convert_element_type_13, convert_element_type_14, mul_4, mul_5, rsqrt_1, sub_3, var_mean_1
#   linear_1 => view_13
#   x => add_3
# Graph fragment:
#   %arg0_1 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %addmm_1 : Tensor "f16[16, 64][64, 1]tnca:0" = PlaceHolder[target=addmm_1]
#   %buf17 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0" = PlaceHolder[target=buf17]
#   %getitem_6 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0" = PlaceHolder[target=getitem_6]
#   %buf19 : Tensor "f32[1, 16, 1][16, 1, 16]tnca:0" = PlaceHolder[target=buf19]
#   %arg7_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg7_1]
#   %arg8_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg8_1]
#   %view_13 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_1, [1, 16, 64]), kwargs = {})
#   %add_3 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg0_1, %view_13), kwargs = {})
#   %convert_element_type_13 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_3, torch.float32), kwargs = {})
#   %var_mean_1 : [num_users=2] = call_function[target=torch.ops.aten.var_mean.correction](args = (%convert_element_type_13, [2]), kwargs = {correction: 0, keepdim: True})
#   %sub_3 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%convert_element_type_13, %getitem_6), kwargs = {})
#   %add_4 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%getitem_5, 1e-05), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4,), kwargs = {})
#   %mul_4 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub_3, %rsqrt_1), kwargs = {})
#   %mul_5 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_4, %arg7_1), kwargs = {})
#   %add_5 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_5, %arg8_1), kwargs = {})
#   %convert_element_type_14 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_5, torch.float16), kwargs = {})
#   return %buf17,%getitem_6,%buf19,%convert_element_type_14
triton_red_fused_add_native_layer_norm_view_9 = async_compile.triton('triton_red_fused_add_native_layer_norm_view_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_add_native_layer_norm_view_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 8448}, 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused_add_native_layer_norm_view_9(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 16
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr1, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp5 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 64*x0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tl.reshape(tma_descriptor0.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tl.broadcast_to(tmp3, [R0_BLOCK])
        tmp6 = _tmp5 + tmp4
        _tmp5 = tl.where(r0_mask, tmp6, _tmp5)
    tmp5 = triton_helpers.promote_to_tensor(tl.sum(_tmp5, 0))
    tmp7 = tl.full([1], 64.0, tl.float32)
    tmp8 = (tmp5 / tmp7)
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr1, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    _tmp16 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr0 + (r0_1 + 64*x0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tl.reshape(tma_descriptor1.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp11 = tmp9 + tmp10
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tmp12 - tmp8
        tmp14 = tmp13 * tmp13
        tmp15 = tl.broadcast_to(tmp14, [R0_BLOCK])
        tmp17 = _tmp16 + tmp15
        _tmp16 = tl.where(r0_mask, tmp17, _tmp16)
    tmp16 = triton_helpers.promote_to_tensor(tl.sum(_tmp16, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr1, shape=[16, 64], strides=[64, 1], block_shape=[XBLOCK, R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp18 = tl.load(in_ptr0 + (r0_1 + 64*x0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp19 = tl.reshape(tma_descriptor2.load([xoffset, r0_offset]), [R0_BLOCK]).to(tl.float32)
        tmp29 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp32 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp21 - tmp8
        tmp23 = tl.full([1], 64.0, tl.float32)
        tmp24 = (tmp16 / tmp23)
        tmp25 = tl.full([1], 1e-05, tl.float32)
        tmp26 = tmp24 + tmp25
        tmp27 = libdevice.rsqrt(tmp26)
        tmp28 = tmp22 * tmp27
        tmp30 = tmp29.to(tl.float32)
        tmp31 = tmp28 * tmp30
        tmp33 = tmp32.to(tl.float32)
        tmp34 = tmp31 + tmp33
        tmp35 = tmp34.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 64*x0), tmp35, r0_mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/2u/c2unbjyh5sqxpvcoixiy4llqdhl25biolybiqsi5k3wqpzkzkonk.py
# Topologically Sorted Source Nodes: [linear_1, x, layer_norm_1, linear_2, gelu], Original ATen: [aten.view, aten.add, aten.native_layer_norm, aten.t, aten.addmm, aten.gelu]
# Source node to ATen node mapping:
#   gelu => add_6, add_7, convert_element_type_18, convert_element_type_19, mul_10, mul_11, mul_6, mul_7, mul_8, mul_9, tanh
#   layer_norm_1 => add_4, add_5, convert_element_type_13, convert_element_type_14, mul_4, mul_5, rsqrt_1, sub_3, var_mean_1
#   linear_1 => view_13
#   linear_2 => addmm_2, permute_9, view_14, view_15
#   x => add_3
# Graph fragment:
#   %arg10_1 : Tensor "f16[256][1]tnca:0" = PlaceHolder[target=arg10_1]
#   %convert_element_type_14 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0" = PlaceHolder[target=convert_element_type_14]
#   %arg9_1 : Tensor "f16[256, 64][64, 1]tnca:0" = PlaceHolder[target=arg9_1]
#   %addmm_2 : Tensor "f16[16, 256][256, 1]tnca:0" = PlaceHolder[target=addmm_2]
#   %view_13 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_1, [1, 16, 64]), kwargs = {})
#   %add_3 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg0_1, %view_13), kwargs = {})
#   %convert_element_type_13 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_3, torch.float32), kwargs = {})
#   %var_mean_1 : [num_users=2] = call_function[target=torch.ops.aten.var_mean.correction](args = (%convert_element_type_13, [2]), kwargs = {correction: 0, keepdim: True})
#   %sub_3 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%convert_element_type_13, %getitem_6), kwargs = {})
#   %add_4 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%getitem_5, 1e-05), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 16, 1][16, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4,), kwargs = {})
#   %mul_4 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub_3, %rsqrt_1), kwargs = {})
#   %mul_5 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_4, %arg7_1), kwargs = {})
#   %add_5 : Tensor "f32[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_5, %arg8_1), kwargs = {})
#   %convert_element_type_14 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_5, torch.float16), kwargs = {})
#   %view_14 : Tensor "f16[16, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_14, [16, 64]), kwargs = {})
#   %permute_9 : Tensor "f16[64, 256][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg9_1, [1, 0]), kwargs = {})
#   %addmm_2 : Tensor "f16[16, 256][256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.addmm.default](args = (%arg10_1, %view_14, %permute_9), kwargs = {})
#   %view_15 : Tensor "f16[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_2, [1, 16, 256]), kwargs = {})
#   %convert_element_type_18 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_15, torch.float32), kwargs = {})
#   %mul_10 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_18, 0.5), kwargs = {})
#   %mul_6 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_18, %convert_element_type_18), kwargs = {})
#   %mul_7 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_6, %convert_element_type_18), kwargs = {})
#   %mul_8 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_7, 0.044715), kwargs = {})
#   %add_6 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_18, %mul_8), kwargs = {})
#   %mul_9 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_6, 0.7978845608028654), kwargs = {})
#   %tanh : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.tanh.default](args = (%mul_9,), kwargs = {})
#   %add_7 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%tanh, 1), kwargs = {})
#   %mul_11 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_10, %add_7), kwargs = {})
#   %convert_element_type_19 : Tensor "f16[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_11, torch.float16), kwargs = {})
#   return %addmm_2,%convert_element_type_19
triton_tem_fused_add_addmm_gelu_native_layer_norm_t_view_10 = async_compile.triton('triton_tem_fused_add_addmm_gelu_native_layer_norm_t_view_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'in_ptr0': '*fp16', 'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr1': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_add_addmm_gelu_native_layer_norm_t_view_10', 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_add_addmm_gelu_native_layer_norm_t_view_10(in_ptr0, arg_A, arg_B, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 16
    N = 256
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 64
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 256*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 256*idx_m
    tmp0 = tl.load(in_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = acc + tmp0
    tmp2 = tmp1.to(tl.float16)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp3.to(tl.float32)
    tmp5 = tl.full([1], 0.5, tl.float32)
    tmp6 = tmp4 * tmp5
    tmp7 = tmp4 * tmp4
    tmp8 = tmp7 * tmp4
    tmp9 = tl.full([1], 0.044715, tl.float32)
    tmp10 = tmp8 * tmp9
    tmp11 = tmp4 + tmp10
    tmp12 = tl.full([1], 0.7978845608028654, tl.float32)
    tmp13 = tmp11 * tmp12
    tmp14 = libdevice.tanh(tmp13)
    tmp15 = tl.full([1], 1.0, tl.float32)
    tmp16 = tmp14 + tmp15
    tmp17 = tmp6 * tmp16
    tmp18 = tmp17.to(tl.float32)
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp18, mask)
''', device_str='tnca')


# kernel path: /tmp/torchinductor_zzhouch/vb/cvboenbx7kbi4uyp7rmraf5zur3446oc3i3fupp24g7qufg4pazj.py
# Topologically Sorted Source Nodes: [linear_1, x, linear_2, gelu, linear_3, add_1], Original ATen: [aten.view, aten.add, aten.gelu, aten.t, aten.addmm]
# Source node to ATen node mapping:
#   add_1 => add_8
#   gelu => add_6, add_7, convert_element_type_18, convert_element_type_19, mul_10, mul_11, mul_6, mul_7, mul_8, mul_9, tanh
#   linear_1 => view_13
#   linear_2 => view_15
#   linear_3 => addmm_3, permute_10, view_16, view_17
#   x => add_3
# Graph fragment:
#   %arg12_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg12_1]
#   %convert_element_type_19 : Tensor "f16[1, 16, 256][4096, 256, 1]tnca:0" = PlaceHolder[target=convert_element_type_19]
#   %arg11_1 : Tensor "f16[64, 256][256, 1]tnca:0" = PlaceHolder[target=arg11_1]
#   %arg0_1 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %addmm_1 : Tensor "f16[16, 64][64, 1]tnca:0" = PlaceHolder[target=addmm_1]
#   %addmm_3 : Tensor "f16[16, 64][64, 1]tnca:0" = PlaceHolder[target=addmm_3]
#   %view_13 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_1, [1, 16, 64]), kwargs = {})
#   %add_3 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg0_1, %view_13), kwargs = {})
#   %view_15 : Tensor "f16[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_2, [1, 16, 256]), kwargs = {})
#   %convert_element_type_18 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=4] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_15, torch.float32), kwargs = {})
#   %mul_10 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_18, 0.5), kwargs = {})
#   %mul_6 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_18, %convert_element_type_18), kwargs = {})
#   %mul_7 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_6, %convert_element_type_18), kwargs = {})
#   %mul_8 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_7, 0.044715), kwargs = {})
#   %add_6 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_18, %mul_8), kwargs = {})
#   %mul_9 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_6, 0.7978845608028654), kwargs = {})
#   %tanh : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.tanh.default](args = (%mul_9,), kwargs = {})
#   %add_7 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%tanh, 1), kwargs = {})
#   %mul_11 : Tensor "f32[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_10, %add_7), kwargs = {})
#   %convert_element_type_19 : Tensor "f16[1, 16, 256][4096, 256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_11, torch.float16), kwargs = {})
#   %view_16 : Tensor "f16[16, 256][256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_19, [16, 256]), kwargs = {})
#   %permute_10 : Tensor "f16[256, 64][1, 256]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg11_1, [1, 0]), kwargs = {})
#   %addmm_3 : Tensor "f16[16, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.addmm.default](args = (%arg12_1, %view_16, %permute_10), kwargs = {})
#   %view_17 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_3, [1, 16, 64]), kwargs = {})
#   %add_8 : Tensor "f16[1, 16, 64][1024, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_3, %view_17), kwargs = {})
#   return %addmm_3,%add_8
triton_tem_fused_add_addmm_gelu_t_view_11 = async_compile.triton('triton_tem_fused_add_addmm_gelu_t_view_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'in_ptr0': '*fp16', 'arg_A': '*fp16', 'arg_B': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(1,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_add_addmm_gelu_t_view_11', 'backend_hash': 'F3BB0CFD3BFF400F257C82FB34E88B391531A4499B109CBC7A5622A5D9A81166', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_add_addmm_gelu_t_view_11(in_ptr0, arg_A, arg_B, in_ptr3, in_ptr4, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 16
    N = 64
    K = 256
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 256
    stride_ak = 1
    stride_bk = 1
    stride_bn = 256

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 256*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 64*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 256*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 64*idx_m
    tmp0 = tl.load(in_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = acc + tmp0
    tmp2 = tmp1.to(tl.float16)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tl.load(in_ptr3 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp5 = tl.load(in_ptr4 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = tmp6 + tmp3
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp7, mask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1 = args
        args.clear()
        assert_size_stride_grouped((arg0_1, arg1_1, arg2_1), ((1, 16, 64), (64, ), (64, )), ((1024, 64, 1), (1, ), (1, )), 'input')
        buf3 = empty_strided((1, 16, 64), (1024, 64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [layer_norm], Original ATen: [aten.native_layer_norm]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_native_layer_norm_0.run(arg0_1, arg1_1, arg2_1, buf3, 16, 64, stream=raw_stream0)
        del arg1_1
        del arg2_1
        assert_size_stride_grouped((arg4_1, arg3_1), ((192, ), (192, 64)), ((1, ), (64, 1)), 'input')
        buf4 = empty_strided((16, 192), (192, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [layer_norm, linear], Original ATen: [aten.native_layer_norm, aten.view, aten.t, aten.addmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_addmm_native_layer_norm_t_view_1.run(arg4_1, buf3, arg3_1, buf4, 12, 1, 1, stream=raw_stream0)
        del arg3_1
        del arg4_1
        del buf3
        buf5 = empty_strided((1, 4, 16, 16), (1024, 256, 16, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear, split, view, q_1, scaled_dot_product_attention], Original ATen: [aten.view, aten.split, aten.transpose, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_2.run(buf4, buf5, 1024, stream=raw_stream0)
        buf6 = empty_strided((1, 4, 16, 16), (1024, 256, 16, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear, split, view_1, k_1, scaled_dot_product_attention], Original ATen: [aten.view, aten.split, aten.transpose, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_3.run(buf4, buf6, 64, 16, stream=raw_stream0)
        buf7 = empty_strided((4, 16, 16), (256, 16, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear, split, view, q_1, scaled_dot_product_attention, view_1, k_1], Original ATen: [aten.view, aten.split, aten.transpose, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_4.run(buf5, buf6, buf7, 1, 4, 1, stream=raw_stream0)
        del buf5
        buf10 = buf6; del buf6  # reuse
        buf12 = buf10; del buf10  # reuse
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_5.run(buf12, buf7, 64, 16, stream=raw_stream0)
        buf13 = reinterpret_tensor(buf7, (1, 4, 16, 16), (1024, 256, 16, 1), 0); del buf7  # reuse
        # Topologically Sorted Source Nodes: [linear, split, view_2, v_1, scaled_dot_product_attention], Original ATen: [aten.view, aten.split, aten.transpose, aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_6.run(buf4, buf13, 1024, stream=raw_stream0)
        del buf4
        buf14 = empty_strided((4, 16, 16), (256, 16, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear, split, scaled_dot_product_attention, view_2, v_1], Original ATen: [aten.view, aten.split, aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_split_transpose_view_4.run(buf12, buf13, buf14, 1, 4, 1, stream=raw_stream0)
        del buf12
        del buf13
        buf15 = empty_strided((16, 1, 4, 16), (64, 1, 16, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_flash_attention_for_cpu_7.run(buf14, buf15, 1024, stream=raw_stream0)
        del buf14
        assert_size_stride_grouped((arg6_1, arg5_1), ((64, ), (64, 64)), ((1, ), (64, 1)), 'input')
        buf16 = empty_strided((16, 64), (64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [scaled_dot_product_attention, transpose_3, o, linear_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.addmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__scaled_dot_product_flash_attention_for_cpu_addmm_t_transpose_view_8.run(arg6_1, buf15, arg5_1, buf16, 4, 1, 1, stream=raw_stream0)
        del arg5_1
        del arg6_1
        assert_size_stride_grouped((arg7_1, arg8_1), ((64, ), (64, )), ((1, ), (1, )), 'input')
        buf20 = reinterpret_tensor(buf15, (1, 16, 64), (1024, 64, 1), 0); del buf15  # reuse
        # Topologically Sorted Source Nodes: [linear_1, x, layer_norm_1], Original ATen: [aten.view, aten.add, aten.native_layer_norm]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_add_native_layer_norm_view_9.run(arg0_1, buf16, arg7_1, arg8_1, buf20, 16, 64, stream=raw_stream0)
        del arg7_1
        del arg8_1
        assert_size_stride_grouped((arg10_1, arg9_1), ((256, ), (256, 64)), ((1, ), (64, 1)), 'input')
        buf22 = empty_strided((1, 16, 256), (4096, 256, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_1, x, layer_norm_1, linear_2, gelu], Original ATen: [aten.view, aten.add, aten.native_layer_norm, aten.t, aten.addmm, aten.gelu]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_addmm_gelu_native_layer_norm_t_view_10.run(arg10_1, buf20, arg9_1, buf22, 16, 1, 1, stream=raw_stream0)
        del arg10_1
        del arg9_1
        assert_size_stride_grouped((arg12_1, arg11_1), ((64, ), (64, 256)), ((1, ), (256, 1)), 'input')
        buf24 = buf20; del buf20  # reuse
        # Topologically Sorted Source Nodes: [linear_1, x, linear_2, gelu, linear_3, add_1], Original ATen: [aten.view, aten.add, aten.gelu, aten.t, aten.addmm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_add_addmm_gelu_t_view_11.run(arg12_1, buf22, arg11_1, arg0_1, buf16, buf24, 4, 1, 1, stream=raw_stream0)
        del arg0_1
        del arg11_1
        del arg12_1
        return (buf24, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 16, 64), (1024, 64, 1), device='tnca:0', dtype=torch.float16)
    arg1_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg2_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg3_1 = rand_strided((192, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg4_1 = rand_strided((192, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg5_1 = rand_strided((64, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg6_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg7_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg8_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg9_1 = rand_strided((256, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg10_1 = rand_strided((256, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg11_1 = rand_strided((64, 256), (256, 1), device='tnca:0', dtype=torch.float16)
    arg12_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
