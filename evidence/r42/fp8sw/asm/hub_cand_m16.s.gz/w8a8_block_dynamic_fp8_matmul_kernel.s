    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #40]                   // N: i32 at arg_base+40
    s.movz       s4, #0
    s.movz       s5, #128
    s.movz       s6, #15
    s.cmp.lt     s7, s5, s4
    s.rdspecial  s8, pid.x
    s.sub        s9, s4, s7
    s.rdspecial  s7, pid.y
    s.movz       s10, #16
    s.xor        s11, s5, s9
    s.cmp.lt     s12, s10, s4
    s.add        s13, s3, s2
    s.ld.sw      s14, [s1, #32]                  // M: i32 at arg_base+32
    s.cmp.lt     s15, s13, s4
    s.sub        s16, s4, s12
    s.sub        s12, s4, s15
    s.xor        s15, s10, s16
    s.xor        s17, s13, s12
    s.xor        s13, s12, s9
    s.sub        s18, s17, s12
    s.sub        s12, s15, s16
    s.lshri      s12, s18, #7
    s.sub        s15, s11, s9
    s.xor        s9, s12, s13
    s.add        s11, s14, s6
    s.sub        s6, s9, s13
    s.cmp.lt     s9, s11, s4
    s.muli       s13, s12, #128
    s.sub        s12, s4, s9
    s.ld.d       s9, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.mul        s15, s8, s6
    s.xor        s8, s11, s12
    s.xor        s11, s12, s16
    s.sub        s16, s8, s12
    s.sub        s8, s18, s13
    s.lshri      s8, s16, #4
    s.muli       s12, s8, #16
    s.xor        s13, s8, s11
    s.ld.d       s8, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.add        s17, s15, s7
    s.sub        s7, s16, s12
    s.sub        s7, s13, s11
    s.ld.d       s11, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.movz       s12, #8
    s.ld.d       s13, [s1, #24]                  // Bs: device_ptr64 at arg_base+24
    s.mul        s15, s6, s12
    s.cmp.lt     s6, s17, s4
    s.sub        s16, s4, s6
    s.ld.sw      s6, [s1, #48]                   // K: i32 at arg_base+48
    s.cmp.lt     s18, s15, s4
    s.ld.sw      s19, [s1, #56]                  // stride_am: i32 at arg_base+56
    s.sub        s20, s4, s18
    s.ld.sw      s18, [s1, #64]                  // stride_bn: i32 at arg_base+64
    s.xor        s21, s17, s16
    s.ld.sw      s22, [s1, #72]                  // stride_cm: i32 at arg_base+72
    s.sub        s23, s21, s16
    s.ld.sw      s21, [s1, #80]                  // stride_bs_n: i32 at arg_base+80
    s.xor        s1, s15, s20
    s.movz       s24, #1
    s.sub        s25, s1, s20
    s.addi       s1, s4, #0
    s.cmp.eq     s26, s25, s24
    s.addi       s27, s4, #0
    s.mov        s1, s23
    br.nz        s26, sdiv_done_1
    s.movz       s4, #0
    s.movz       s26, #31
    s.mov        s1, s4
    s.addi       s4, s26, #0
sdiv_2:
    s.lshr       s26, s23, s4
    s.shli       s28, s27, #1
    s.andi       s29, s26, #1
    s.movz       s26, #0
    s.or         s30, s28, s29
    s.shl        s28, s24, s4
    s.cmp.geu    s29, s30, s25
    s.subi       s31, s4, #1
    s.sub        s32, s26, s29
    s.and        s29, s25, s32
    s.and        s33, s28, s32
    s.sub        s28, s30, s29
    s.or         s29, s1, s33
    s.mov        s27, s28
    s.mov        s1, s29
    s.mov        s4, s31
    s.cmp.ge     s28, s4, s26
    br.nz        s28, sdiv_2
sdiv_done_1:
    s.xor        s4, s16, s20
    s.movz       s16, #0
    s.xor        s20, s1, s4
    s.cmp.lt     s1, s15, s16
    s.sub        s23, s20, s4
    s.cmp.lt     s4, s17, s16
    s.sub        s20, s16, s1
    s.mul        s1, s23, s12
    s.sub        s23, s16, s4
    s.xor        s4, s15, s20
    s.xor        s15, s17, s23
    s.sub        s17, s4, s20
    s.sub        s4, s7, s1
    s.sub        s7, s15, s23
    s.addi       s15, s16, #0
    s.cmp.eq     s20, s17, s24
    s.min.s      s24, s4, s12
    s.addi       s4, s16, #0
    s.mov        s15, s7
    br.nz        s20, sdiv_done_3
    s.movz       s12, #0
    s.movz       s20, #31
    s.mov        s15, s12
    s.addi       s12, s20, #0
sdiv_4:
    s.lshr       s20, s7, s12
    s.shli       s25, s4, #1
    s.andi       s26, s20, #1
    s.movz       s20, #1
    s.or         s27, s25, s26
    s.shl        s25, s20, s12
    s.cmp.geu    s20, s27, s17
    s.subi       s26, s12, #1
    s.sub        s28, s16, s20
    s.and        s20, s17, s28
    s.and        s29, s25, s28
    s.sub        s25, s27, s20
    s.or         s20, s15, s29
    s.mov        s4, s25
    s.mov        s15, s20
    s.mov        s12, s26
    s.cmp.ge     s20, s12, s16
    br.nz        s20, sdiv_4
sdiv_done_3:
    s.xor        s7, s4, s23
    s.cmp.lt     s4, s24, s16
    s.sub        s12, s7, s23
    s.sub        s7, s16, s4
    s.cmp.lt     s4, s12, s16
    s.xor        s15, s24, s7
    s.sub        s17, s16, s4
    s.sub        s4, s15, s7
    s.xor        s7, s12, s17
    s.movz       s15, #1
    s.sub        s20, s7, s17
    s.addi       s7, s16, #0
    s.cmp.eq     s23, s4, s15
    s.addi       s25, s16, #0
    s.mov        s7, s20
    br.nz        s23, sdiv_done_5
    s.movz       s16, #0
    s.movz       s23, #31
    s.mov        s7, s16
    s.addi       s16, s23, #0
sdiv_6:
    s.lshr       s23, s20, s16
    s.shli       s26, s25, #1
    s.andi       s27, s23, #1
    s.movz       s23, #0
    s.or         s28, s26, s27
    s.shl        s26, s15, s16
    s.cmp.geu    s27, s28, s4
    s.subi       s29, s16, #1
    s.sub        s30, s23, s27
    s.and        s27, s4, s30
    s.and        s31, s26, s30
    s.sub        s26, s28, s27
    s.or         s27, s7, s31
    s.mov        s25, s26
    s.mov        s7, s27
    s.mov        s16, s29
    s.cmp.ge     s26, s16, s23
    br.nz        s26, sdiv_6
sdiv_done_5:
    s.movz       s4, #0
    s.xor        s7, s25, s17
    s.cmp.lt     s16, s24, s4
    s.cmp.lt     s20, s12, s4
    s.sub        s23, s4, s16
    s.sub        s16, s4, s20
    s.xor        s20, s24, s23
    s.xor        s24, s12, s16
    s.sub        s12, s20, s23
    s.sub        s20, s7, s17
    s.sub        s7, s24, s16
    s.addi       s17, s4, #0
    s.cmp.eq     s24, s12, s15
    s.add        s15, s1, s20
    s.addi       s1, s4, #0
    s.mov        s17, s7
    br.nz        s24, sdiv_done_7
    s.movz       s20, #0
    s.movz       s24, #31
    s.mov        s17, s20
    s.addi       s20, s24, #0
sdiv_8:
    s.lshr       s24, s7, s20
    s.shli       s25, s1, #1
    s.andi       s26, s24, #1
    s.movz       s24, #1
    s.or         s27, s25, s26
    s.shl        s25, s24, s20
    s.cmp.geu    s24, s27, s12
    s.subi       s26, s20, #1
    s.sub        s28, s4, s24
    s.and        s24, s12, s28
    s.and        s29, s25, s28
    s.sub        s25, s27, s24
    s.or         s24, s17, s29
    s.mov        s1, s25
    s.mov        s17, s24
    s.mov        s20, s26
    s.cmp.ge     s24, s20, s4
    br.nz        s24, sdiv_8
sdiv_done_7:
    s.mul        s1, s15, s10
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s14
    v.movi       v2, #0
    s.xor        s4, s16, s23
    v.splat      v3, s1
    v.sub        v4, v2, v1
    s.xor        s7, s17, s4
    v.add        v5, v3, v0
    v.cmp.lt     p1, v1, v2
    s.sub        s12, s7, s4
    v.sub        v0, v2, v5
    v.cmp.lt     p2, v5, v2
    v.movi       v3, #1
    @p2 v.sel        v6, v0, v5
    @p1 v.sel        v0, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s4, #31
idiv_9:
    v.splat      v5, s4
    v.shl        v7, v4, v3
    v.cmp.lt     p1, v4, v2
    v.lshr       v8, v6, v5
    v.shl        v9, v3, v5
    s.subi       s7, s4, #1
    v.and        v5, v8, v3
    s.movz       s15, #0
    v.or         v8, v7, v5
    v.cmp.geu    p3, v8, v0
    p.or         p4, p1, p3
    v.sub        v5, v8, v0
    @p4 v.sel        v7, v9, v2
    @p4 v.sel        v9, v5, v8
    v.or         v5, v1, v7
    v.mov        v4, v9
    v.mov        v1, v5
    s.mov        s4, s7
    s.cmp.ge     s7, s4, s15
    br.nz        s7, idiv_9
    s.mul        s4, s12, s5
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #16
    v.movi       v3, #32
    v.movi       v5, #48
    v.splat      v6, s4
    v.iota       v7                              // arange(0, VLEN)
    v.movi       v8, #64
    v.movi       v9, #80
    v.movi       v10, #96
    v.iota       v11                             // arange(0, VLEN)
    v.movi       v12, #112
    v.add        v13, v6, v0
    v.splat      v14, s3
    v.movi       v15, #0
    v.sub        v16, v2, v4
    v.add        v2, v0, v1
    v.add        v1, v0, v3
    v.add        v3, v0, v5
    v.add        v0, v7, v8
    v.add        v5, v7, v9
    v.add        v8, v7, v10
    v.add        v7, v11, v12
    v.sub        v9, v15, v13
    v.sub        v10, v15, v14
    v.cmp.lt     p1, v13, v15
    v.cmp.lt     p3, v14, v15
    @p2 v.sel        v11, v16, v4
    v.add        v4, v6, v2
    v.add        v2, v6, v1
    v.add        v1, v6, v3
    v.add        v3, v6, v0
    v.add        v0, v6, v5
    v.add        v5, v6, v8
    v.add        v8, v6, v7
    v.movi       v6, #1
    @p1 v.sel        v7, v9, v13
    @p3 v.sel        v9, v10, v14
    v.movi       v10, #0
    v.movi       v12, #0
    s.movz       s7, #31
idiv_10:
    v.splat      v13, s7
    v.shl        v16, v12, v6
    v.cmp.lt     p2, v12, v15
    v.lshr       v17, v7, v13
    v.shl        v18, v6, v13
    s.subi       s12, s7, #1
    v.and        v13, v17, v6
    s.movz       s15, #0
    v.or         v17, v16, v13
    v.cmp.geu    p3, v17, v9
    p.or         p4, p2, p3
    v.sub        v13, v17, v9
    @p4 v.sel        v16, v18, v15
    @p4 v.sel        v18, v13, v17
    v.or         v13, v10, v16
    v.mov        v12, v18
    v.mov        v10, v13
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_10
    v.movi       v6, #0
    v.sub        v7, v15, v12
    v.movi       v9, #1
    v.sub        v10, v6, v4
    v.sub        v13, v6, v14
    v.cmp.lt     p2, v4, v6
    v.cmp.lt     p3, v14, v6
    @p1 v.sel        v15, v7, v12
    @p2 v.sel        v7, v10, v4
    @p3 v.sel        v4, v13, v14
    v.movi       v10, #0
    v.movi       v12, #0
    s.movz       s7, #31
idiv_11:
    v.splat      v13, s7
    v.shl        v16, v12, v9
    v.cmp.lt     p1, v12, v6
    v.lshr       v17, v7, v13
    v.shl        v18, v9, v13
    s.subi       s12, s7, #1
    v.and        v13, v17, v9
    v.or         v17, v16, v13
    v.cmp.geu    p3, v17, v4
    p.or         p4, p1, p3
    v.sub        v13, v17, v4
    @p4 v.sel        v16, v18, v6
    @p4 v.sel        v18, v13, v17
    v.or         v13, v10, v16
    v.mov        v12, v18
    v.mov        v10, v13
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_11
    v.movi       v4, #0
    v.sub        v7, v6, v12
    v.movi       v6, #1
    v.sub        v9, v4, v2
    v.sub        v10, v4, v14
    v.cmp.lt     p1, v2, v4
    v.cmp.lt     p3, v14, v4
    @p2 v.sel        v13, v7, v12
    @p1 v.sel        v7, v9, v2
    @p3 v.sel        v2, v10, v14
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s7, #31
idiv_12:
    v.splat      v12, s7
    v.shl        v16, v10, v6
    v.cmp.lt     p2, v10, v4
    v.lshr       v17, v7, v12
    v.shl        v18, v6, v12
    s.subi       s12, s7, #1
    v.and        v12, v17, v6
    s.movz       s15, #0
    v.or         v17, v16, v12
    v.cmp.geu    p3, v17, v2
    p.or         p4, p2, p3
    v.sub        v12, v17, v2
    @p4 v.sel        v16, v18, v4
    @p4 v.sel        v18, v12, v17
    v.or         v12, v9, v16
    v.mov        v10, v18
    v.mov        v9, v12
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_12
    v.movi       v2, #0
    v.sub        v6, v4, v10
    v.movi       v4, #1
    v.sub        v7, v2, v1
    v.sub        v9, v2, v14
    v.cmp.lt     p2, v1, v2
    v.cmp.lt     p3, v14, v2
    @p1 v.sel        v12, v6, v10
    @p2 v.sel        v6, v7, v1
    @p3 v.sel        v1, v9, v14
    v.movi       v7, #0
    v.movi       v9, #0
    s.movz       s7, #31
idiv_13:
    v.splat      v10, s7
    v.shl        v16, v9, v4
    v.cmp.lt     p1, v9, v2
    v.lshr       v17, v6, v10
    v.shl        v18, v4, v10
    s.subi       s12, s7, #1
    v.and        v10, v17, v4
    v.or         v17, v16, v10
    v.cmp.geu    p3, v17, v1
    p.or         p4, p1, p3
    v.sub        v10, v17, v1
    @p4 v.sel        v16, v18, v2
    @p4 v.sel        v18, v10, v17
    v.or         v10, v7, v16
    v.mov        v9, v18
    v.mov        v7, v10
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_13
    v.movi       v1, #0
    v.sub        v4, v2, v9
    v.movi       v2, #1
    v.sub        v6, v1, v3
    v.sub        v7, v1, v14
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p3, v14, v1
    @p2 v.sel        v10, v4, v9
    @p1 v.sel        v4, v6, v3
    @p3 v.sel        v3, v7, v14
    v.movi       v6, #0
    v.movi       v7, #0
    s.movz       s7, #31
idiv_14:
    v.splat      v9, s7
    v.shl        v16, v7, v2
    v.cmp.lt     p2, v7, v1
    v.lshr       v17, v4, v9
    v.shl        v18, v2, v9
    s.subi       s12, s7, #1
    v.and        v9, v17, v2
    s.movz       s15, #0
    v.or         v17, v16, v9
    v.cmp.geu    p3, v17, v3
    p.or         p4, p2, p3
    v.sub        v9, v17, v3
    @p4 v.sel        v16, v18, v1
    @p4 v.sel        v18, v9, v17
    v.or         v9, v6, v16
    v.mov        v7, v18
    v.mov        v6, v9
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_14
    v.movi       v2, #0
    v.sub        v3, v1, v7
    v.movi       v1, #1
    v.sub        v4, v2, v0
    v.sub        v6, v2, v14
    v.cmp.lt     p2, v0, v2
    v.cmp.lt     p3, v14, v2
    @p1 v.sel        v9, v3, v7
    @p2 v.sel        v3, v4, v0
    @p3 v.sel        v0, v6, v14
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s7, #31
idiv_15:
    v.splat      v7, s7
    v.shl        v16, v6, v1
    v.cmp.lt     p1, v6, v2
    v.lshr       v17, v3, v7
    v.shl        v18, v1, v7
    s.subi       s12, s7, #1
    v.and        v7, v17, v1
    v.or         v17, v16, v7
    v.cmp.geu    p3, v17, v0
    p.or         p4, p1, p3
    v.sub        v7, v17, v0
    @p4 v.sel        v16, v18, v2
    @p4 v.sel        v18, v7, v17
    v.or         v7, v4, v16
    v.mov        v6, v18
    v.mov        v4, v7
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_15
    v.movi       v0, #0
    v.sub        v1, v2, v6
    v.movi       v2, #1
    v.sub        v3, v0, v5
    v.sub        v4, v0, v14
    v.cmp.lt     p1, v5, v0
    v.cmp.lt     p3, v14, v0
    @p2 v.sel        v7, v1, v6
    @p1 v.sel        v1, v3, v5
    @p3 v.sel        v3, v4, v14
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s7, #31
idiv_16:
    v.splat      v6, s7
    v.shl        v16, v5, v2
    v.cmp.lt     p2, v5, v0
    v.lshr       v17, v1, v6
    v.shl        v18, v2, v6
    s.subi       s12, s7, #1
    v.and        v6, v17, v2
    s.movz       s15, #0
    v.or         v17, v16, v6
    v.cmp.geu    p3, v17, v3
    p.or         p4, p2, p3
    v.sub        v6, v17, v3
    @p4 v.sel        v16, v18, v0
    @p4 v.sel        v18, v6, v17
    v.or         v6, v4, v16
    v.mov        v5, v18
    v.mov        v4, v6
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_16
    v.movi       v1, #0
    v.sub        v2, v0, v5
    v.movi       v0, #1
    v.sub        v3, v1, v8
    v.sub        v4, v1, v14
    v.cmp.lt     p2, v8, v1
    v.cmp.lt     p3, v14, v1
    @p1 v.sel        v6, v2, v5
    @p2 v.sel        v2, v3, v8
    @p3 v.sel        v3, v4, v14
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s7, #31
idiv_17:
    v.splat      v8, s7
    v.shl        v14, v5, v0
    v.cmp.lt     p1, v5, v1
    v.lshr       v16, v2, v8
    v.shl        v17, v0, v8
    s.subi       s12, s7, #1
    v.and        v8, v16, v0
    v.or         v16, v14, v8
    v.cmp.geu    p3, v16, v3
    p.or         p4, p1, p3
    v.sub        v8, v16, v3
    @p4 v.sel        v14, v17, v1
    @p4 v.sel        v17, v8, v16
    v.or         v8, v4, v14
    v.mov        v5, v17
    v.mov        v4, v8
    s.mov        s7, s12
    s.cmp.ge     s12, s7, s15
    br.nz        s12, idiv_17
    v.sub        v0, v1, v5
    v.movi       v1, #0
    v.movi       v2, #0
    @p2 v.sel        v3, v0, v5
    v.movi       v0, #0
    v.movi       v4, #0
    v.sub        v5, v1, v15
    v.sub        v8, v2, v13
    v.sub        v14, v0, v12
    v.cmp.lt     p1, v15, v1
    v.cmp.lt     p2, v13, v2
    v.cmp.lt     p3, v12, v0
    @p1 v.sel        v16, v5, v15
    v.movi       v5, #7
    @p2 v.sel        v17, v8, v13
    v.movi       v8, #7
    @p3 v.sel        v18, v14, v12
    v.movi       v14, #7
    v.lshr       v19, v16, v5
    v.lshr       v5, v17, v8
    v.lshr       v8, v18, v14
    v.movi       v14, #128
    v.sub        v16, v1, v19
    v.movi       v17, #128
    v.sub        v18, v2, v5
    v.movi       v20, #128
    v.sub        v21, v0, v8
    v.movi       v22, #128
    v.sub        v23, v1, v14
    @p1 v.sel        v24, v16, v19
    v.sub        v16, v2, v17
    @p2 v.sel        v19, v18, v5
    v.sub        v5, v0, v20
    @p3 v.sel        v18, v21, v8
    v.cmp.lt     p1, v14, v1
    v.cmp.lt     p2, v17, v2
    v.cmp.lt     p3, v20, v0
    s.movz       s7, #32
    s.movz       s12, #48
    s.movz       s15, #64
    v.sub        v0, v4, v10
    s.movz       s16, #80
    s.movz       s17, #96
    v.sub        v1, v4, v22
    s.movz       s20, #112
    v.movi       v2, #7
    v.movi       v8, #1
    v.movi       v8, #0
    @p1 v.sel        v21, v23, v14
    v.cmp.lt     p1, v10, v4
    v.sub        v14, v8, v9
    @p1 v.sel        v21, v0, v10
    v.movi       v0, #7
    v.movi       v23, #1
    v.lshr       v23, v21, v2
    v.movi       v2, #0
    @p2 v.sel        v21, v16, v17
    v.cmp.lt     p2, v9, v8
    v.sub        v16, v2, v7
    @p2 v.sel        v17, v14, v9
    v.movi       v14, #7
    v.movi       v21, #1
    v.lshr       v21, v17, v0
    v.movi       v0, #0
    @p3 v.sel        v17, v5, v20
    v.cmp.lt     p3, v7, v2
    v.sub        v5, v0, v6
    @p3 v.sel        v17, v16, v7
    v.movi       v16, #7
    v.movi       v20, #1
    v.lshr       v20, v17, v14
    v.sub        v14, v4, v23
    v.movi       v17, #1
    v.movi       v17, #1
    @p1 v.sel        v17, v14, v23
    v.cmp.lt     p1, v6, v0
    @p1 v.sel        v14, v5, v6
    v.movi       v5, #128
    v.movi       v23, #1
    v.lshr       v23, v14, v16
    v.sub        v14, v8, v21
    @p2 v.sel        v16, v14, v21
    v.movi       v14, #128
    v.cmp.lt     p2, v22, v4
    v.movi       v4, #0
    @p2 v.sel        v21, v1, v22
    v.movi       v1, #7
    v.sub        v21, v4, v3
    v.cmp.lt     p2, v3, v4
    v.movi       v22, #1
    @p2 v.sel        v22, v21, v3
    v.lshr       v21, v22, v1
    v.sub        v1, v2, v20
    @p3 v.sel        v22, v1, v20
    v.movi       v1, #128
    v.cmp.lt     p3, v5, v8
    v.sub        v20, v8, v5
    @p3 v.sel        v8, v20, v5
    s.add        s23, s6, s2
    s.movz       s2, #0
    v.sub        v5, v0, v23
    s.cmp.lt     s24, s23, s2
    v.movi       v8, #128
    s.sub        s25, s2, s24
    @p1 v.sel        v20, v5, v23
    v.sub        v5, v4, v21
    v.cmp.lt     p1, v14, v2
    s.xor        s24, s23, s25
    s.cmp.lt     s23, s5, s2
    v.sub        v23, v2, v14
    s.sub        s26, s24, s25
    s.sub        s24, s2, s23
    @p2 v.sel        v2, v5, v21
    v.sub        v5, v0, v1
    v.cmp.lt     p2, v1, v0
    v.sub        v0, v4, v8
    v.cmp.lt     p3, v8, v4
    v.splat      v4, s21
    @p1 v.sel        v21, v23, v14
    s.lshri      s21, s26, #7
    s.xor        s23, s25, s24
    s.muli       s25, s21, #128
    s.xor        s27, s5, s24
    s.xor        s28, s21, s23
    @p2 v.sel        v14, v5, v1
    @p3 v.sel        v1, v0, v8
    v.mul        v0, v24, v4
    v.mul        v1, v19, v4
    v.mul        v5, v18, v4
    v.mul        v8, v17, v4
    v.mul        v14, v16, v4
    v.mul        v16, v22, v4
    v.mul        v17, v20, v4
    v.mul        v18, v2, v4
    s.sub        s21, s27, s24
    s.sub        s21, s26, s25
    s.sub        s21, s28, s23
    s.movz       s23, #1
    s.addi       s24, s2, #0
    s.addi       s25, s2, #0
    s.addi       s26, s2, #0
    s.addi       s27, s13, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_26:
    s.cmp.ge     s13, s24, s21
    br.nz        s13, endfor_27
    s.muli       s13, s19, #2
    s.mul        s28, s24, s5
    s.muli       s29, s25, #2
    s.movz       s30, #0
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s13
    s.add        s13, s30, s10                   // the tile origin
    s.sub        s31, s6, s28
    v.mul        v19, v11, v4
    v.splat      v4, s13
    s.add        s13, s2, s31                    // the tile origin
    v.extract    s28, v19, #0
    s.add        s32, s30, s31                   // the tile origin
    s.add        s33, s28, s29
    v.splat      v20, s13
    s.addi       s13, s33, #32
    v.add        v21, v2, v4
    v.splat      v4, s32
    s.add        s28, s30, s7                    // the tile origin
    s.add        s34, s9, s33
    s.add        s35, s9, s13
    v.splat      v22, s28
    v.cmp.lt     p1, v2, v20
    v.cmp.lt     p2, v21, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s34, #0]
    s.addi       s13, s33, #64
    v.add        v20, v2, v22
    v.splat      v21, s32
    s.add        s28, s30, s12                   // the tile origin
    s.add        s34, s9, s13
    v.splat      v22, s28
    v.cmp.lt     p3, v20, v21
    s.addi       s13, s33, #96
    v.add        v20, v2, v22
    v.splat      v21, s32
    s.add        s28, s30, s15                   // the tile origin
    s.add        s36, s9, s13
    v.splat      v22, s28
    v.movi       v23, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v23, [s35, #0]
    v.cmp.lt     p4, v20, v21
    s.addi       s13, s33, #128
    v.add        v20, v2, v22
    v.splat      v21, s32
    s.add        s28, s9, s13
    vf.cvt.f16.f32 v22, v4
    v.extract    s13, v19, #0
    v.cmp.lt     p5, v20, v21
    vf.abs       v4, v22
    s.add        s32, s30, s16                   // the tile origin
    s.movz       s30, #0
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v20, [s34, #0]
    v.splat      v21, s32
    vf.cvt.f16.f32 v22, v23
    s.add        s32, s13, s29
    s.add        s13, s30, s31                   // the tile origin
    s.addi       s33, s32, #160
    v.add        v23, v2, v21
    v.splat      v21, s13
    s.add        s34, s9, s33
    vf.abs       v24, v22
    v.cmp.lt     p6, v23, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p4 v.ld.h       v21, [s36, #0]
    vf.cvt.f16.f32 v22, v20
    vf.max.ieee  v20, v4, v24
    s.add        s33, s30, s17                   // the tile origin
    s.addi       s35, s32, #192
    v.splat      v4, s33
    v.splat      v23, s13
    s.add        s33, s9, s35
    v.add        v24, v2, v4
    vf.abs       v4, v22
    v.cmp.lt     p7, v24, v23
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v22, [s28, #0]
    vf.cvt.f16.f32 v23, v21
    vf.max.ieee  v21, v20, v4
    s.add        s28, s30, s20                   // the tile origin
    s.addi       s30, s32, #224
    v.splat      v4, s28
    v.splat      v20, s13
    s.add        s13, s9, s30
    v.add        v24, v2, v4
    vf.abs       v2, v23
    v.cmp.lt     p8, v24, v20
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s34, #0]
    vf.cvt.f16.f32 v20, v22
    vf.max.ieee  v22, v21, v2
    v.extract    s28, v19, #1
    s.add        s30, s28, s29
    vf.abs       v2, v20
    s.addi       s28, s30, #32
    s.add        s32, s9, s30
    s.add        s34, s9, s28
    vf.max.ieee  v20, v22, v2
    s.addi       s28, s30, #64
    s.addi       s35, s30, #96
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v2, [s32, #0]
    s.add        s32, s9, s28
    s.add        s28, s9, s35
    vf.cvt.f16.f32 v21, v4
    vf.abs       v4, v21
    vf.max.ieee  v21, v20, v4
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s34, #0]
    s.addi       s34, s30, #128
    vf.cvt.f16.f32 v20, v2
    s.add        s35, s9, s34
    s.addi       s34, s30, #160
    s.add        s36, s9, s34
    vf.abs       v2, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v20, [s32, #0]
    vf.cvt.f16.f32 v22, v4
    vf.abs       v4, v22
    vf.max.ieee  v22, v2, v4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s28, #0]
    vf.cvt.f16.f32 v4, v20
    vf.abs       v20, v4
    vf.max.ieee  v4, v22, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v20, [s35, #0]
    vf.cvt.f16.f32 v22, v2
    vf.abs       v2, v22
    vf.max.ieee  v22, v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v2, [s33, #0]
    vf.cvt.f16.f32 v4, v20
    vf.abs       v20, v4
    vf.max.ieee  v4, v22, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p6 v.ld.h       v20, [s36, #0]
    vf.cvt.f16.f32 v22, v2
    vf.abs       v2, v22
    vf.max.ieee  v22, v21, v2
    s.addi       s28, s30, #192
    s.addi       s32, s30, #224
    s.add        s30, s9, s28
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v2, [s13, #0]
    s.add        s13, s9, s32
    vf.cvt.f16.f32 v21, v20
    vf.abs       v20, v21
    vf.max.ieee  v21, v4, v20
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s30, #0]
    vf.cvt.f16.f32 v20, v2
    vf.abs       v2, v20
    vf.max.ieee  v20, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v22, v4
    vf.reduce.max.b v4, v20
    v.extract    s13, v19, #2
    s.add        s28, s13, s29
    vf.abs       v20, v22
    s.addi       s13, s28, #32
    s.add        s30, s9, s28
    s.add        s32, s9, s13
    s.addi       s13, s28, #64
    s.addi       s33, s28, #96
    s.add        s34, s9, s13
    s.add        s13, s9, s33
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s30, #0]
    s.addi       s30, s28, #128
    s.addi       s33, s28, #160
    s.add        s35, s9, s30
    s.add        s30, s9, s33
    s.addi       s33, s28, #192
    vf.cvt.f16.f32 v23, v2
    s.add        s36, s9, s33
    vf.max.ieee  v2, v21, v20
    s.addi       s33, s28, #224
    s.add        s28, s9, s33
    vf.abs       v20, v23
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v21, [s32, #0]
    vf.cvt.f16.f32 v23, v22
    vf.max.ieee  v22, v2, v20
    vf.abs       v2, v23
    vf.reduce.max.b v20, v22
    v.extract    s32, v19, #3
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s37, s9, s33
    s.add        s38, s9, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s37, #0]
    vf.cvt.f16.f32 v23, v21
    vf.abs       v21, v23
    vf.max.ieee  v23, v2, v21
    s.addi       s32, s33, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s38, #0]
    vf.cvt.f16.f32 v21, v22
    vf.abs       v22, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v21, [s34, #0]
    s.add        s34, s9, s32
    vf.cvt.f16.f32 v24, v2
    vf.abs       v2, v24
    vf.max.ieee  v24, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v22, v21
    vf.abs       v21, v22
    vf.max.ieee  v22, v23, v21
    s.addi       s13, s33, #96
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v21, [s34, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v23, v2
    vf.abs       v2, v23
    vf.max.ieee  v23, v22, v2
    s.addi       s13, s33, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s32, #0]
    vf.cvt.f16.f32 v22, v21
    vf.abs       v21, v22
    vf.max.ieee  v22, v24, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v21, [s35, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v24, v2
    vf.abs       v2, v24
    vf.max.ieee  v24, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v2, [s30, #0]
    vf.cvt.f16.f32 v22, v21
    vf.abs       v21, v22
    vf.max.ieee  v22, v23, v21
    s.addi       s13, s33, #160
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v21, [s32, #0]
    s.add        s30, s9, s13
    vf.cvt.f16.f32 v23, v2
    vf.abs       v2, v23
    vf.max.ieee  v23, v22, v2
    s.addi       s13, s33, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v2, [s30, #0]
    vf.cvt.f16.f32 v22, v21
    vf.abs       v21, v22
    vf.max.ieee  v22, v24, v21
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p7 v.ld.h       v21, [s36, #0]
    s.add        s30, s9, s13
    vf.cvt.f16.f32 v24, v2
    vf.abs       v2, v24
    vf.max.ieee  v24, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v2, [s28, #0]
    vf.cvt.f16.f32 v22, v21
    vf.abs       v21, v22
    vf.max.ieee  v22, v23, v21
    s.addi       s13, s33, #224
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p7 v.ld.h       v21, [s30, #0]
    s.add        s28, s9, s13
    vf.cvt.f16.f32 v23, v2
    vf.abs       v2, v23
    vf.max.ieee  v23, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v2, [s28, #0]
    vf.cvt.f16.f32 v22, v21
    vf.reduce.max.b v21, v23
    v.extract    s13, v19, #4
    s.add        s28, s13, s29
    vf.abs       v23, v22
    s.addi       s13, s28, #32
    s.add        s30, s9, s28
    s.add        s32, s9, s13
    s.addi       s13, s28, #64
    s.addi       s33, s28, #96
    s.add        s34, s9, s13
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s30, #0]
    s.add        s13, s9, s33
    s.addi       s30, s28, #128
    s.addi       s33, s28, #160
    s.add        s35, s9, s30
    s.add        s30, s9, s33
    s.addi       s33, s28, #192
    vf.cvt.f16.f32 v25, v2
    s.add        s36, s9, s33
    vf.max.ieee  v2, v24, v23
    s.addi       s33, s28, #224
    s.add        s28, s9, s33
    vf.abs       v23, v25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v24, [s32, #0]
    vf.cvt.f16.f32 v25, v22
    vf.max.ieee  v22, v2, v23
    vf.abs       v2, v25
    vf.reduce.max.b v23, v22
    v.extract    s32, v19, #5
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s37, s9, s33
    s.add        s38, s9, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s37, #0]
    vf.cvt.f16.f32 v25, v24
    vf.abs       v24, v25
    vf.max.ieee  v25, v2, v24
    s.addi       s32, s33, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s38, #0]
    vf.cvt.f16.f32 v24, v22
    vf.abs       v22, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v24, [s34, #0]
    s.add        s34, s9, s32
    vf.cvt.f16.f32 v26, v2
    vf.abs       v2, v26
    vf.max.ieee  v26, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v22, v24
    vf.abs       v24, v22
    vf.max.ieee  v22, v25, v24
    s.addi       s13, s33, #96
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v24, [s34, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v25, v2
    vf.abs       v2, v25
    vf.max.ieee  v25, v22, v2
    s.addi       s13, s33, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s32, #0]
    vf.cvt.f16.f32 v22, v24
    vf.abs       v24, v22
    vf.max.ieee  v22, v26, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v24, [s35, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v26, v2
    vf.abs       v2, v26
    vf.max.ieee  v26, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v2, [s30, #0]
    vf.cvt.f16.f32 v22, v24
    vf.abs       v24, v22
    vf.max.ieee  v22, v25, v24
    s.addi       s13, s33, #160
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v24, [s32, #0]
    s.add        s30, s9, s13
    vf.cvt.f16.f32 v25, v2
    vf.abs       v2, v25
    vf.max.ieee  v25, v22, v2
    s.addi       s13, s33, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v2, [s30, #0]
    vf.cvt.f16.f32 v22, v24
    vf.abs       v24, v22
    vf.max.ieee  v22, v26, v24
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p7 v.ld.h       v24, [s36, #0]
    s.add        s30, s9, s13
    vf.cvt.f16.f32 v26, v2
    vf.abs       v2, v26
    vf.max.ieee  v26, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v2, [s28, #0]
    vf.cvt.f16.f32 v22, v24
    vf.abs       v24, v22
    vf.max.ieee  v22, v25, v24
    s.addi       s13, s33, #224
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p7 v.ld.h       v24, [s30, #0]
    s.add        s28, s9, s13
    vf.cvt.f16.f32 v25, v2
    vf.abs       v2, v25
    vf.max.ieee  v25, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v2, [s28, #0]
    vf.cvt.f16.f32 v22, v24
    vf.reduce.max.b v24, v25
    v.extract    s13, v19, #6
    s.add        s28, s13, s29
    vf.abs       v25, v22
    s.addi       s13, s28, #32
    s.add        s30, s9, s28
    s.add        s32, s9, s13
    s.addi       s13, s28, #64
    s.addi       s33, s28, #96
    s.add        s34, s9, s13
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s30, #0]
    s.add        s13, s9, s33
    s.addi       s30, s28, #128
    s.addi       s33, s28, #160
    s.add        s35, s9, s30
    s.add        s30, s9, s33
    s.addi       s33, s28, #192
    vf.cvt.f16.f32 v27, v2
    s.add        s36, s9, s33
    vf.max.ieee  v2, v26, v25
    s.addi       s33, s28, #224
    s.add        s28, s9, s33
    vf.abs       v25, v27
    v.movi       v26, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v26, [s32, #0]
    vf.cvt.f16.f32 v27, v22
    vf.max.ieee  v22, v2, v25
    vf.abs       v2, v27
    vf.reduce.max.b v25, v22
    v.extract    s32, v19, #7
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s37, s9, s33
    s.add        s38, s9, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s37, #0]
    vf.cvt.f16.f32 v27, v26
    vf.abs       v26, v27
    vf.max.ieee  v27, v2, v26
    s.addi       s32, s33, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s38, #0]
    vf.cvt.f16.f32 v26, v22
    vf.abs       v22, v26
    v.movi       v26, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v26, [s34, #0]
    s.add        s34, s9, s32
    vf.cvt.f16.f32 v28, v2
    vf.abs       v2, v28
    vf.max.ieee  v28, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v22, v26
    vf.abs       v26, v22
    vf.max.ieee  v22, v27, v26
    s.addi       s13, s33, #96
    v.movi       v26, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v26, [s34, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v27, v2
    vf.abs       v2, v27
    vf.max.ieee  v27, v22, v2
    s.addi       s13, s33, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s32, #0]
    vf.cvt.f16.f32 v22, v26
    vf.abs       v26, v22
    vf.max.ieee  v22, v28, v26
    v.movi       v26, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v26, [s35, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v28, v2
    vf.abs       v2, v28
    vf.max.ieee  v28, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v2, [s30, #0]
    vf.cvt.f16.f32 v22, v26
    vf.abs       v26, v22
    vf.max.ieee  v22, v27, v26
    s.addi       s13, s33, #160
    v.movi       v26, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v26, [s32, #0]
    s.add        s30, s9, s13
    vf.cvt.f16.f32 v27, v2
    vf.abs       v2, v27
    vf.max.ieee  v27, v22, v2
    s.addi       s13, s33, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v2, [s30, #0]
    vf.cvt.f16.f32 v22, v26
    vf.abs       v26, v22
    vf.max.ieee  v22, v28, v26
    v.movi       v26, #0                         // other=, materialised (sec 12)
    @p7 v.ld.h       v26, [s36, #0]
    s.add        s30, s9, s13
    vf.cvt.f16.f32 v28, v2
    vf.abs       v2, v28
    vf.max.ieee  v28, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v2, [s28, #0]
    vf.cvt.f16.f32 v22, v26
    vf.abs       v26, v22
    vf.max.ieee  v22, v27, v26
    s.addi       s13, s33, #224
    v.movi       v26, #0                         // other=, materialised (sec 12)
    @p7 v.ld.h       v26, [s30, #0]
    s.add        s28, s9, s13
    vf.cvt.f16.f32 v27, v2
    vf.abs       v2, v27
    vf.max.ieee  v27, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v2, [s28, #0]
    vf.cvt.f16.f32 v22, v26
    vf.reduce.max.b v26, v27
    v.extract    s13, v19, #8
    s.add        s28, s13, s29
    vf.abs       v27, v22
    s.addi       s13, s28, #32
    s.add        s30, s9, s28
    s.add        s32, s9, s13
    s.addi       s13, s28, #64
    s.addi       s33, s28, #96
    s.add        s34, s9, s13
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s30, #0]
    s.add        s13, s9, s33
    s.addi       s30, s28, #128
    s.addi       s33, s28, #160
    s.add        s35, s9, s30
    s.add        s30, s9, s33
    s.addi       s33, s28, #192
    vf.cvt.f16.f32 v29, v2
    s.add        s36, s9, s33
    vf.max.ieee  v2, v28, v27
    s.addi       s33, s28, #224
    s.add        s28, s9, s33
    vf.abs       v27, v29
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v28, [s32, #0]
    vf.cvt.f16.f32 v29, v22
    vf.max.ieee  v22, v2, v27
    vf.abs       v2, v29
    vf.reduce.max.b v27, v22
    v.extract    s32, v19, #9
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s37, s9, s33
    s.add        s38, s9, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s37, #0]
    vf.cvt.f16.f32 v29, v28
    vf.abs       v28, v29
    vf.max.ieee  v29, v2, v28
    s.addi       s32, s33, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s38, #0]
    vf.cvt.f16.f32 v28, v22
    vf.abs       v22, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v28, [s34, #0]
    s.add        s34, s9, s32
    vf.cvt.f16.f32 v30, v2
    vf.abs       v2, v30
    vf.max.ieee  v30, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v22, v28
    vf.abs       v28, v22
    vf.max.ieee  v22, v29, v28
    s.addi       s13, s33, #96
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v28, [s34, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v29, v2
    vf.abs       v2, v29
    vf.max.ieee  v29, v22, v2
    s.addi       s13, s33, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s32, #0]
    vf.cvt.f16.f32 v22, v28
    vf.abs       v28, v22
    vf.max.ieee  v22, v30, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v28, [s35, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v30, v2
    vf.abs       v2, v30
    vf.max.ieee  v30, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v2, [s30, #0]
    vf.cvt.f16.f32 v22, v28
    vf.abs       v28, v22
    vf.max.ieee  v22, v29, v28
    s.addi       s13, s33, #160
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v28, [s32, #0]
    s.add        s30, s9, s13
    vf.cvt.f16.f32 v29, v2
    vf.abs       v2, v29
    vf.max.ieee  v29, v22, v2
    s.addi       s13, s33, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v2, [s30, #0]
    vf.cvt.f16.f32 v22, v28
    vf.abs       v28, v22
    vf.max.ieee  v22, v30, v28
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p7 v.ld.h       v28, [s36, #0]
    s.add        s30, s9, s13
    vf.cvt.f16.f32 v30, v2
    vf.abs       v2, v30
    vf.max.ieee  v30, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v2, [s28, #0]
    vf.cvt.f16.f32 v22, v28
    vf.abs       v28, v22
    vf.max.ieee  v22, v29, v28
    s.addi       s13, s33, #224
    v.movi       v28, #0                         // other=, materialised (sec 12)
    @p7 v.ld.h       v28, [s30, #0]
    s.add        s28, s9, s13
    vf.cvt.f16.f32 v29, v2
    vf.abs       v2, v29
    vf.max.ieee  v29, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v2, [s28, #0]
    vf.cvt.f16.f32 v22, v28
    vf.reduce.max.b v28, v29
    v.extract    s13, v19, #10
    s.add        s28, s13, s29
    vf.abs       v29, v22
    s.addi       s13, s28, #32
    s.add        s30, s9, s28
    s.add        s32, s9, s13
    s.addi       s13, s28, #64
    s.addi       s33, s28, #96
    s.add        s34, s9, s13
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s30, #0]
    s.add        s13, s9, s33
    s.addi       s30, s28, #128
    s.addi       s33, s28, #160
    s.add        s35, s9, s30
    s.add        s30, s9, s33
    s.addi       s33, s28, #192
    vf.cvt.f16.f32 v31, v2
    s.add        s36, s9, s33
    vf.max.ieee  v2, v30, v29
    s.addi       s33, s28, #224
    s.add        s28, s9, s33
    vf.abs       v29, v31
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v30, [s32, #0]
    vf.cvt.f16.f32 v31, v22
    vf.max.ieee  v22, v2, v29
    vf.abs       v2, v31
    vf.reduce.max.b v29, v22
    v.extract    s32, v19, #11
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s37, s9, s33
    s.add        s38, s9, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s37, #0]
    vf.cvt.f16.f32 v31, v30
    vf.abs       v30, v31
    vf.max.ieee  v31, v2, v30
    s.addi       s32, s33, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s38, #0]
    vf.cvt.f16.f32 v30, v22
    vf.abs       v22, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v30, [s34, #0]
    s.add        s34, s9, s32
    vf.cvt.f16.f32 v32, v2
    vf.abs       v2, v32
    vf.max.ieee  v32, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v22, v30
    vf.abs       v30, v22
    vf.max.ieee  v22, v31, v30
    s.addi       s13, s33, #96
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v30, [s34, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v31, v2
    vf.abs       v2, v31
    vf.max.ieee  v31, v22, v2
    s.addi       s13, s33, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s32, #0]
    vf.cvt.f16.f32 v22, v30
    vf.abs       v30, v22
    vf.max.ieee  v22, v32, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v30, [s35, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v32, v2
    vf.abs       v2, v32
    vf.max.ieee  v32, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v2, [s30, #0]
    vf.cvt.f16.f32 v22, v30
    vf.abs       v30, v22
    vf.max.ieee  v22, v31, v30
    s.addi       s13, s33, #160
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v30, [s32, #0]
    s.add        s30, s9, s13
    vf.cvt.f16.f32 v31, v2
    vf.abs       v2, v31
    vf.max.ieee  v31, v22, v2
    s.addi       s13, s33, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v2, [s30, #0]
    vf.cvt.f16.f32 v22, v30
    vf.abs       v30, v22
    vf.max.ieee  v22, v32, v30
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p7 v.ld.h       v30, [s36, #0]
    s.add        s30, s9, s13
    vf.cvt.f16.f32 v32, v2
    vf.abs       v2, v32
    vf.max.ieee  v32, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v2, [s28, #0]
    vf.cvt.f16.f32 v22, v30
    vf.abs       v30, v22
    vf.max.ieee  v22, v31, v30
    s.addi       s13, s33, #224
    v.movi       v30, #0                         // other=, materialised (sec 12)
    @p7 v.ld.h       v30, [s30, #0]
    s.add        s28, s9, s13
    vf.cvt.f16.f32 v31, v2
    vf.abs       v2, v31
    vf.max.ieee  v31, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v2, [s28, #0]
    vf.cvt.f16.f32 v22, v30
    vf.reduce.max.b v30, v31
    v.extract    s13, v19, #12
    s.add        s28, s13, s29
    vf.abs       v31, v22
    s.addi       s13, s28, #32
    s.add        s30, s9, s28
    s.add        s32, s9, s13
    s.addi       s13, s28, #64
    s.addi       s33, s28, #96
    s.add        s34, s9, s13
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s30, #0]
    s.add        s13, s9, s33
    s.addi       s30, s28, #128
    s.addi       s33, s28, #160
    s.add        s35, s9, s30
    s.add        s30, s9, s33
    s.addi       s33, s28, #192
    vf.cvt.f16.f32 v33, v2
    s.add        s36, s9, s33
    vf.max.ieee  v2, v32, v31
    s.addi       s33, s28, #224
    s.add        s28, s9, s33
    vf.abs       v31, v33
    v.movi       v32, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v32, [s32, #0]
    vf.cvt.f16.f32 v33, v22
    vf.max.ieee  v22, v2, v31
    vf.abs       v2, v33
    vf.reduce.max.b v31, v22
    v.extract    s32, v19, #13
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s37, s9, s33
    s.add        s38, s9, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s37, #0]
    vf.cvt.f16.f32 v33, v32
    vf.abs       v32, v33
    vf.max.ieee  v33, v2, v32
    s.addi       s32, s33, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s38, #0]
    vf.cvt.f16.f32 v32, v22
    vf.abs       v22, v32
    v.movi       v32, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v32, [s34, #0]
    s.add        s34, s9, s32
    vf.cvt.f16.f32 v34, v2
    vf.abs       v2, v34
    vf.max.ieee  v34, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v22, v32
    vf.abs       v32, v22
    vf.max.ieee  v22, v33, v32
    s.addi       s13, s33, #96
    v.movi       v32, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v32, [s34, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v33, v2
    vf.abs       v2, v33
    vf.max.ieee  v33, v22, v2
    s.addi       s13, s33, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s32, #0]
    vf.cvt.f16.f32 v22, v32
    vf.abs       v32, v22
    vf.max.ieee  v22, v34, v32
    v.movi       v32, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v32, [s35, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v34, v2
    vf.abs       v2, v34
    vf.max.ieee  v34, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v2, [s30, #0]
    vf.cvt.f16.f32 v22, v32
    vf.abs       v32, v22
    vf.max.ieee  v22, v33, v32
    s.addi       s13, s33, #160
    v.movi       v32, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v32, [s32, #0]
    s.add        s30, s9, s13
    vf.cvt.f16.f32 v33, v2
    vf.abs       v2, v33
    vf.max.ieee  v33, v22, v2
    s.addi       s13, s33, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v2, [s30, #0]
    vf.cvt.f16.f32 v22, v32
    vf.abs       v32, v22
    vf.max.ieee  v22, v34, v32
    v.movi       v32, #0                         // other=, materialised (sec 12)
    @p7 v.ld.h       v32, [s36, #0]
    s.add        s30, s9, s13
    vf.cvt.f16.f32 v34, v2
    vf.abs       v2, v34
    vf.max.ieee  v34, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v2, [s28, #0]
    vf.cvt.f16.f32 v22, v32
    vf.abs       v32, v22
    vf.max.ieee  v22, v33, v32
    s.addi       s13, s33, #224
    s.add        s28, s9, s13
    v.movi       v32, #0                         // other=, materialised (sec 12)
    @p7 v.ld.h       v32, [s30, #0]
    vf.cvt.f16.f32 v33, v2
    vf.abs       v2, v33
    vf.max.ieee  v33, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v2, [s28, #0]
    vf.cvt.f16.f32 v22, v32
    vf.reduce.max.b v32, v33
    v.extract    s13, v19, #14
    s.add        s28, s13, s29
    vf.abs       v33, v22
    s.addi       s13, s28, #32
    s.add        s30, s9, s28
    s.add        s32, s9, s13
    s.addi       s13, s28, #64
    s.addi       s33, s28, #96
    s.add        s34, s9, s13
    s.add        s13, s9, s33
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s30, #0]
    s.addi       s30, s28, #128
    s.addi       s33, s28, #160
    s.add        s35, s9, s30
    s.add        s30, s9, s33
    s.addi       s33, s28, #192
    vf.cvt.f16.f32 v35, v2
    s.add        s36, s9, s33
    vf.max.ieee  v2, v34, v33
    s.addi       s33, s28, #224
    s.add        s28, s9, s33
    vf.abs       v33, v35
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p2 v.ld.h       v34, [s32, #0]
    vf.cvt.f16.f32 v35, v22
    vf.max.ieee  v22, v2, v33
    vf.abs       v2, v35
    vf.reduce.max.b v33, v22
    v.extract    s32, v19, #15
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s37, s9, s33
    s.add        s38, s9, s32
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v22, [s37, #0]
    vf.cvt.f16.f32 v35, v34
    vf.abs       v34, v35
    vf.max.ieee  v35, v2, v34
    s.addi       s32, s33, #64
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v2, [s38, #0]
    vf.cvt.f16.f32 v34, v22
    vf.abs       v22, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s34, #0]
    s.add        s34, s9, s32
    vf.cvt.f16.f32 v36, v2
    vf.abs       v2, v36
    vf.max.ieee  v36, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s13, #0]
    vf.cvt.f16.f32 v22, v34
    vf.abs       v34, v22
    vf.max.ieee  v22, v35, v34
    s.addi       s13, s33, #96
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p3 v.ld.h       v34, [s34, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v35, v2
    vf.abs       v2, v35
    vf.max.ieee  v35, v22, v2
    s.addi       s13, s33, #128
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s32, #0]
    vf.cvt.f16.f32 v22, v34
    vf.abs       v34, v22
    vf.max.ieee  v22, v36, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v34, [s35, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v36, v2
    vf.abs       v2, v36
    vf.max.ieee  v36, v22, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v2, [s30, #0]
    vf.cvt.f16.f32 v22, v34
    vf.abs       v34, v22
    vf.max.ieee  v22, v35, v34
    s.addi       s13, s33, #160
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p5 v.ld.h       v34, [s32, #0]
    s.add        s30, s9, s13
    vf.cvt.f16.f32 v35, v2
    vf.abs       v2, v35
    vf.max.ieee  v35, v22, v2
    s.addi       s13, s33, #192
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v2, [s36, #0]
    s.add        s32, s9, s13
    vf.cvt.f16.f32 v22, v34
    vf.abs       v34, v22
    vf.max.ieee  v22, v36, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p8 v.ld.h       v34, [s28, #0]
    vf.cvt.f16.f32 v36, v2
    vf.abs       v2, v36
    vf.max.ieee  v36, v35, v2
    s.addi       s13, s33, #224
    s.add        s28, s9, s13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v2, [s30, #0]
    vf.cvt.f16.f32 v35, v34
    vf.abs       v34, v35
    vf.max.ieee  v35, v36, v34
    v.movi       v34, #0                         // other=, materialised (sec 12)
    @p7 v.ld.h       v34, [s32, #0]
    vf.cvt.f16.f32 v36, v2
    vf.reduce.max.b v2, v35
    v.movi       v35, #0
    // one value per row into one vector (ISA 0x09)
    v.extract    s13, v4, #0
    v.extract    s30, v20, #0
    v.extract    s32, v21, #0
    v.extract    s33, v23, #0
    v.extract    s34, v24, #0
    v.extract    s35, v25, #0
    v.extract    s36, v26, #0
    v.extract    s37, v27, #0
    vf.abs       v4, v36
    .li       s38, #1138753536
    v.splat      v20, s38                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p8 v.ld.h       v21, [s28, #0]
    v.insert     v35, s13, #0
    vf.cvt.f16.f32 v23, v34
    v.extract    s13, v28, #0
    v.insert     v35, s30, #1
    vf.max.ieee  v24, v22, v4
    v.rcp.approx v4, v20                         // ISA 8.8: <= 2**-22 relative
    v.insert     v35, s32, #2
    vf.abs       v22, v23
    v.extract    s28, v29, #0
    v.insert     v35, s33, #3
    .li       s30, #1065353216
    v.splat      v23, s30                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s30, v30, #0
    v.insert     v35, s34, #4
    vf.cvt.f16.f32 v25, v21
    vf.max.ieee  v21, v24, v22
    v.insert     v35, s35, #5
    v.extract    s32, v31, #0
    v.extract    s33, v32, #0
    v.insert     v35, s36, #6
    vf.abs       v22, v25
    v.extract    s34, v33, #0
    v.insert     v35, s37, #7
    v.extract    s35, v2, #0
    v.insert     v35, s13, #8
    vf.max.ieee  v2, v21, v22
    v.insert     v35, s28, #9
    v.insert     v35, s30, #10
    vf.reduce.max.b v21, v2
    .li       s13, #730643660
    v.splat      v2, s13                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v22, v20, v4, v23
    v.insert     v35, s32, #11
    v.extract    s13, v21, #0
    v.splat      v21, s18
    v.insert     v35, s33, #12
    vf.fms       v24, v4, v22, v4
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    s.rdspecial  s28, arg_base
    v.insert     v35, s34, #13
    v.splat      v22, s18
    s.add        s30, s2, s31
    vf.neg       v25, v24                        // Newton step: r0*(2 - x*r0)
    v.insert     v35, s35, #14
    v.mul        v24, v15, v21
    v.mul        v26, v13, v21
    v.insert     v35, s13, #15
    vf.cmp.o     p9, v25, v25
    @p9 v.sel        v27, v25, v4
    v.iota       v4                              // arange(0, VLEN)
    s.ld.d       s13, [s28, #88]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    vf.mul       v25, v35, v27                   // a/y: faithful quotient
    s.movz       s28, #0
    v.mul        v28, v12, v21
    s.cmp.ge     s31, s30, s28
    v.mul        v29, v10, v21
    vf.fms       v30, v25, v20, v35
    v.extract    s32, v15, #0
    v.mul        v20, v9, v21
    v.mul        v21, v7, v22
    v.mul        v31, v6, v22
    vf.fms       v32, v30, v27, v25
    v.splat      v27, s32
    v.mul        v30, v3, v22
    v.movi       v22, #0
    v.ld.gather.w v33, [s27, v0]                 // index is in elements (ISA sec 9.1)
    vf.neg       v34, v32                        // a/y: one correction to the IEEE quotient
    v.add        v32, v27, v4
    v.movi       v27, #0
    vf.cmp.o     p9, v34, v34
    @p9 v.sel        v35, v34, v25
    v.sub        v25, v15, v32
    vf.max.ieee  v32, v35, v2
    v.reduce.or  s33, v25
    s.cmp.ge     s34, s32, s28
    s.cmp.eq     s35, s33, s28
    v.rcp.approx v2, v32                         // ISA 8.8: <= 2**-22 relative
    s.and        s33, s35, s34
    v.ld.gather.w v25, [s27, v1]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v34, [s27, v5]                 // index is in elements (ISA sec 9.1)
    vf.fms       v36, v32, v2, v23
    s.and        s34, s33, s31
    vf.fms       v23, v2, v36, v2
    vf.neg       v36, v23                        // Newton step: r0*(2 - x*r0)
    v.ld.gather.w v23, [s27, v8]                 // index is in elements (ISA sec 9.1)
    vf.cmp.o     p9, v36, v36
    v.extract    s33, v13, #0
    @p9 v.sel        v37, v36, v2
    v.splat      v2, s33
    v.extract    s35, v12, #0
    s.cmp.ge     s36, s33, s28
    v.add        v36, v2, v4
    v.splat      v2, s35
    v.sub        v38, v13, v36
    v.add        v36, v2, v4
    v.reduce.or  s37, v38
    v.sub        v2, v12, v36
    s.cmp.eq     s38, s37, s28
    v.ld.gather.w v36, [s27, v14]                // index is in elements (ISA sec 9.1)
    v.reduce.or  s37, v2
    s.and        s39, s38, s36
    s.cmp.eq     s36, s37, s28
    s.and        s37, s39, s31
    v.ld.gather.w v2, [s27, v16]                 // index is in elements (ISA sec 9.1)
    s.cmp.ge     s38, s35, s28
    v.ld.gather.w v38, [s27, v17]                // index is in elements (ISA sec 9.1)
    s.and        s39, s36, s38
    v.ld.gather.w v39, [s27, v18]                // index is in elements (ISA sec 9.1)
    v.extract    s36, v10, #0
    s.and        s38, s39, s31
    v.st.w       [s13, #0], v24
    v.splat      v24, s36
    v.st.w       [s13, #64], v26
    v.add        v26, v24, v4
    v.st.w       [s13, #128], v28
    v.sub        v24, v10, v26
    v.st.w       [s13, #192], v29
    v.reduce.or  s39, v24
    v.st.w       [s13, #256], v20
    s.cmp.eq     s40, s39, s28
    v.st.w       [s13, #320], v21
    s.cmp.ge     s39, s36, s28
    v.st.w       [s13, #384], v31
    s.and        s41, s40, s39
    v.st.w       [s13, #448], v30
    fence.acq_rel.device
    v.extract    s39, v9, #0
    v.extract    s40, v7, #0
    v.splat      v20, s39
    v.splat      v21, s40
    v.insert     v22, s34, #0
    v.add        v24, v20, v4
    v.add        v20, v21, v4
    v.insert     v27, s32, #0
    v.extract    s32, v6, #0
    v.sub        v21, v9, v24
    v.insert     v22, s37, #1
    v.splat      v24, s32
    v.reduce.or  s34, v21
    v.sub        v21, v7, v20
    v.insert     v27, s33, #1
    v.extract    s33, v3, #0
    v.add        v20, v24, v4
    v.insert     v22, s38, #2
    v.splat      v24, s33
    s.cmp.eq     s37, s34, s28
    s.cmp.ge     s34, s39, s28
    s.and        s28, s41, s31
    v.reduce.or  s38, v21
    s.movz       s41, #0
    v.sub        v21, v6, v20
    s.and        s42, s37, s34
    v.insert     v27, s35, #2
    v.add        v20, v24, v4
    v.insert     v22, s28, #3
    s.cmp.eq     s28, s38, s41
    s.cmp.ge     s34, s40, s41
    s.and        s35, s42, s31
    v.reduce.or  s37, v21
    v.sub        v4, v3, v20
    s.and        s38, s28, s34
    v.insert     v27, s36, #3
    v.insert     v22, s35, #4
    s.cmp.eq     s28, s37, s41
    s.cmp.ge     s34, s32, s41
    s.and        s35, s38, s31
    v.reduce.or  s36, v4
    s.and        s37, s28, s34
    v.insert     v27, s39, #4
    v.insert     v22, s35, #5
    s.cmp.eq     s28, s36, s41
    s.cmp.ge     s34, s33, s41
    s.and        s35, s37, s31
    s.and        s36, s28, s34
    v.insert     v27, s40, #5
    v.insert     v22, s35, #6
    s.and        s28, s36, s31
    v.insert     v27, s32, #6
    v.insert     v22, s28, #7
    s.add        s28, s8, s26
    s.addi       s31, s13, #512                  // TensorMap 0: W's rows for a transposed FP8 B
    .li       s32, #2147483647
    s.movz       s34, #1
    .li       s35, #137438953488
    .li       s36, #7705171329024
    s.addi       s37, s13, #768
    s.addi       s38, s13, #1792                 // TensorMap 1: the gathered fallback B tile
    s.movz       s39, #32
    s.movz       s40, #16
    .li       s41, #68719476768
    s.addi       s42, s13, #1280
    v.insert     v27, s33, #7
    s.addi       s33, s13, #2048                 // TensorMap 2: the gathered fallback B tile
    s.st.d       [s13, #512], s28
    v.extract    s28, v22, #0
    s.st.d       [s13, #520], s32
    s.movz       s32, #0
    s.st.d       [s13, #528], s30
    s.st.d       [s13, #560], s18
    s.st.d       [s13, #568], s34
    s.st.d       [s13, #600], s35
    s.st.d       [s13, #616], s36
    fence.release.device
    td.load      d0, [s31]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.st.d       [s13, #1792], s37
    s.st.d       [s13, #1800], s39
    s.st.d       [s13, #1808], s40
    s.st.d       [s13, #1840], s40
    s.st.d       [s13, #1848], s34
    s.st.d       [s13, #1880], s41
    s.st.d       [s13, #1896], s36
    fence.release.device
    td.load      d1, [s38]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.st.d       [s13, #2048], s42
    s.st.d       [s13, #2056], s39
    s.st.d       [s13, #2064], s40
    s.st.d       [s13, #2096], s40
    s.st.d       [s13, #2104], s34
    s.st.d       [s13, #2136], s41
    s.st.d       [s13, #2152], s36
    fence.release.device
    td.load      d2, [s33]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s28, x8dot_done_28
    s.addi       s31, s32, #0
    v.ld.w       v4, [s13, #0]
    s.add        s33, s8, s26
x8dot_row_29:
    s.addi       s34, s30, #0
    v.movi       v20, #0
    s.sub        s35, s34, s31
    s.add        s34, s33, s31
    v.splat      v21, s35
    s.shli       s35, s31, #4
    s.addi       s36, s31, #1
    v.cmp.gt     p9, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p9 v.ld.gather.b v20, [s34, v4]             // index is in elements (ISA sec 9.1)
    s.add        s34, s37, s35
    v.st.b       [s34, #0], v20
    fence.acq_rel.device
    s.mov        s31, s36
    s.cmp.lt     s34, s31, s39
    br.nz        s34, x8dot_row_29
x8dot_done_28:
    v.splat      v4, s28
    v.movi       v20, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s31, v27, #0
    v.extract    s33, v22, #1
    v.cmp.ne     p9, v4, v20
    v.cmp.eq     p10, v4, v20
    s.mov        s34, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p10 t.ld.async.b w0, d1, s34, s28           // predicated off still completes once (ISA sec 9A.3)
    s.mov        s34, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p9 t.ld.async.b.t w0, d0, s34, s28          // predicated off still completes once (ISA sec 9A.3)
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s33, x8dot_done_30
    s.movz       s31, #0
    v.ld.w       v4, [s13, #64]
    s.addi       s32, s31, #0
    s.add        s31, s8, s26
    s.addi       s34, s13, #1280
x8dot_row_31:
    s.addi       s35, s30, #0
    v.movi       v20, #0
    s.sub        s36, s35, s32
    s.add        s35, s31, s32
    v.splat      v21, s36
    s.shli       s36, s32, #4
    s.addi       s37, s32, #1
    v.cmp.gt     p9, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p9 v.ld.gather.b v20, [s35, v4]             // index is in elements (ISA sec 9.1)
    s.add        s35, s34, s36
    s.movz       s36, #32
    v.st.b       [s35, #0], v20
    fence.acq_rel.device
    s.mov        s32, s37
    s.cmp.lt     s35, s32, s36
    br.nz        s35, x8dot_row_31
x8dot_done_30:
    mb.arm       s31, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v4, s33
    v.movi       v20, #0
    v.cmp.ne     p9, v4, v20
    v.cmp.eq     p10, v4, v20
    s.movz       s32, #0
    s.mov        s33, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s34, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p10 t.ld.async.b w1, d2, s33, s31           // predicated off still completes once (ISA sec 9A.3)
    v.extract    s33, v27, #1
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p9 t.ld.async.b.t w1, d0, s34, s31          // predicated off still completes once (ISA sec 9A.3)
    v.extract    s32, v19, #0
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #0
    v.splat      v4, s32
    v.extract    s32, v37, #0
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2304], v20
    v.extract    s32, v19, #1
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #1
    v.splat      v4, s32
    v.extract    s32, v37, #1
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2336], v20
    v.extract    s32, v19, #2
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #2
    v.splat      v4, s32
    v.extract    s32, v37, #2
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2368], v20
    v.extract    s32, v19, #3
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #3
    v.splat      v4, s32
    v.extract    s32, v37, #3
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2400], v20
    v.extract    s32, v19, #4
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #4
    v.splat      v4, s32
    v.extract    s32, v37, #4
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2432], v20
    v.extract    s32, v19, #5
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #5
    v.splat      v4, s32
    v.extract    s32, v37, #5
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2464], v20
    v.extract    s32, v19, #6
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #6
    v.splat      v4, s32
    v.extract    s32, v37, #6
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2496], v20
    v.extract    s32, v19, #7
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #7
    v.splat      v4, s32
    v.extract    s32, v37, #7
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2528], v20
    v.extract    s32, v19, #8
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #8
    v.splat      v4, s32
    v.extract    s32, v37, #8
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2560], v20
    v.extract    s32, v19, #9
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #9
    v.splat      v4, s32
    v.extract    s32, v37, #9
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2592], v20
    v.extract    s32, v19, #10
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #10
    v.splat      v4, s32
    v.extract    s32, v37, #10
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2624], v20
    v.extract    s32, v19, #11
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #11
    v.splat      v4, s32
    v.extract    s32, v37, #11
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2656], v20
    v.extract    s32, v19, #12
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #12
    v.splat      v4, s32
    v.extract    s32, v37, #12
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2688], v20
    v.extract    s32, v19, #13
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #13
    v.splat      v4, s32
    v.extract    s32, v37, #13
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2720], v20
    v.extract    s32, v19, #14
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #14
    v.splat      v4, s32
    v.extract    s32, v37, #14
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p9, v20, v20
    @p9 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p9, v4, #0
    @p9 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2752], v20
    v.extract    s32, v19, #15
    s.add        s33, s32, s29
    s.add        s32, s9, s33
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #15
    v.splat      v4, s32
    v.extract    s32, v37, #15
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2784], v20
    v.extract    s32, v19, #0
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #0
    v.splat      v4, s32
    v.extract    s32, v37, #0
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2320], v20
    v.extract    s32, v19, #1
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #1
    v.splat      v4, s32
    v.extract    s32, v37, #1
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2352], v20
    v.extract    s32, v19, #2
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #2
    v.splat      v4, s32
    v.extract    s32, v37, #2
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2384], v20
    v.extract    s32, v19, #3
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #3
    v.splat      v4, s32
    v.extract    s32, v37, #3
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2416], v20
    v.extract    s32, v19, #4
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #4
    v.splat      v4, s32
    v.extract    s32, v37, #4
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2448], v20
    v.extract    s32, v19, #5
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #5
    v.splat      v4, s32
    v.extract    s32, v37, #5
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2480], v20
    v.extract    s32, v19, #6
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #6
    v.splat      v4, s32
    v.extract    s32, v37, #6
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2512], v20
    v.extract    s32, v19, #7
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #7
    v.splat      v4, s32
    v.extract    s32, v37, #7
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2544], v20
    v.extract    s32, v19, #8
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #8
    v.splat      v4, s32
    v.extract    s32, v37, #8
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2576], v20
    v.extract    s32, v19, #9
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #9
    v.splat      v4, s32
    v.extract    s32, v37, #9
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2608], v20
    v.extract    s32, v19, #10
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #10
    v.splat      v4, s32
    v.extract    s32, v37, #10
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2640], v20
    v.extract    s32, v19, #11
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #11
    v.splat      v4, s32
    v.extract    s32, v37, #11
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2672], v20
    v.extract    s32, v19, #12
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #12
    v.splat      v4, s32
    v.extract    s32, v37, #12
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2704], v20
    v.extract    s32, v19, #13
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #13
    v.splat      v4, s32
    v.extract    s32, v37, #13
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2736], v20
    v.extract    s32, v19, #14
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #14
    v.splat      v4, s32
    v.extract    s32, v37, #14
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2768], v20
    v.extract    s32, v19, #15
    s.add        s33, s32, s29
    s.addi       s32, s33, #32
    s.add        s33, s9, s32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v4, [s33, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s32, v32, #15
    v.splat      v4, s32
    v.extract    s32, v37, #15
    v.splat      v21, s32
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2800], v20
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.ld.w       v4, [s13, #2304]
    v.mov        v56, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #2368]
    v.mov        v57, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #2432]
    v.mov        v58, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #2496]
    v.mov        v59, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #2560]
    v.mov        v60, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #2624]
    v.mov        v61, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #2688]
    v.mov        v62, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #2752]
    v.mov        v63, v4                         // hand off through the shared window (sec 7.3)
    mb.wait      s28
    mb.arm       s32, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s32
    mb.wait      s32
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s33, v22, #2
    br.nz        s33, x8dot_done_32
    s.movz       s34, #0
    v.ld.w       v4, [s13, #128]
    s.addi       s35, s34, #0
    s.add        s34, s8, s26
    s.addi       s36, s13, #768
x8dot_row_33:
    s.addi       s37, s30, #0
    v.movi       v20, #0
    s.sub        s38, s37, s35
    s.add        s37, s34, s35
    v.splat      v21, s38
    s.shli       s38, s35, #4
    s.addi       s39, s35, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s37, v4]             // index is in elements (ISA sec 9.1)
    s.add        s37, s36, s38
    s.movz       s38, #32
    v.st.b       [s37, #0], v20
    fence.acq_rel.device
    s.mov        s35, s39
    s.cmp.lt     s37, s35, s38
    br.nz        s37, x8dot_row_33
x8dot_done_32:
    v.splat      v4, s33
    v.movi       v20, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    v.extract    s35, v27, #2
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s36, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s36, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s35, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v22, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s35
    mb.wait      s35
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s36, x8dot_done_34
    s.addi       s37, s34, #0
    v.ld.w       v4, [s13, #192]
    s.add        s38, s8, s26
    s.addi       s39, s13, #1280
x8dot_row_35:
    s.addi       s40, s30, #0
    v.movi       v20, #0
    s.sub        s41, s40, s37
    s.add        s40, s38, s37
    v.splat      v21, s41
    s.shli       s41, s37, #4
    s.addi       s42, s37, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s40, v4]             // index is in elements (ISA sec 9.1)
    s.add        s40, s39, s41
    s.movz       s41, #32
    v.st.b       [s40, #0], v20
    fence.acq_rel.device
    s.mov        s37, s42
    s.cmp.lt     s40, s37, s41
    br.nz        s40, x8dot_row_35
x8dot_done_34:
    v.splat      v4, s36
    v.movi       v20, #0
    mb.arm       s36, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s37, v27, #3
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s38, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s38, v22, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s37
    mb.wait      s37
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s38, x8dot_done_36
    s.addi       s39, s34, #0
    v.ld.w       v4, [s13, #256]
    s.add        s34, s8, s26
    s.addi       s40, s13, #768
x8dot_row_37:
    s.addi       s41, s30, #0
    v.movi       v20, #0
    s.sub        s42, s41, s39
    s.add        s41, s34, s39
    v.splat      v21, s42
    s.shli       s42, s39, #4
    s.addi       s43, s39, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s41, v4]             // index is in elements (ISA sec 9.1)
    s.add        s41, s40, s42
    s.movz       s42, #32
    v.st.b       [s41, #0], v20
    fence.acq_rel.device
    s.mov        s39, s43
    s.cmp.lt     s41, s39, s42
    br.nz        s41, x8dot_row_37
x8dot_done_36:
    v.splat      v4, s38
    v.movi       v20, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s38, #0
    v.extract    s39, v27, #4
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s40, s34            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s40, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s39, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v22, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s39
    mb.wait      s39
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s40, x8dot_done_38
    s.addi       s41, s38, #0
    v.ld.w       v4, [s13, #320]
    s.add        s42, s8, s26
    s.addi       s43, s13, #1280
x8dot_row_39:
    s.addi       s44, s30, #0
    v.movi       v20, #0
    s.sub        s45, s44, s41
    s.add        s44, s42, s41
    v.splat      v21, s45
    s.shli       s45, s41, #4
    s.addi       s46, s41, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s44, v4]             // index is in elements (ISA sec 9.1)
    s.add        s44, s43, s45
    s.movz       s45, #32
    v.st.b       [s44, #0], v20
    fence.acq_rel.device
    s.mov        s41, s46
    s.cmp.lt     s44, s41, s45
    br.nz        s44, x8dot_row_39
x8dot_done_38:
    v.splat      v4, s40
    v.movi       v20, #0
    mb.arm       s40, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s41, v27, #5
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s42, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v22, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s41
    mb.wait      s41
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s42, x8dot_done_40
    s.addi       s43, s38, #0
    v.ld.w       v4, [s13, #384]
    s.add        s38, s8, s26
    s.addi       s44, s13, #768
x8dot_row_41:
    s.addi       s45, s30, #0
    v.movi       v20, #0
    s.sub        s46, s45, s43
    s.add        s45, s38, s43
    v.splat      v21, s46
    s.shli       s46, s43, #4
    s.addi       s47, s43, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s45, v4]             // index is in elements (ISA sec 9.1)
    s.add        s45, s44, s46
    s.movz       s46, #32
    v.st.b       [s45, #0], v20
    fence.acq_rel.device
    s.mov        s43, s47
    s.cmp.lt     s45, s43, s46
    br.nz        s45, x8dot_row_41
x8dot_done_40:
    v.splat      v4, s42
    v.movi       v20, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s42, #0
    v.extract    s43, v27, #6
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s44, s38            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s44, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s43, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v22, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s43
    mb.wait      s43
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s44, x8dot_done_42
    s.addi       s45, s42, #0
    v.ld.w       v4, [s13, #448]
    s.add        s46, s8, s26
    s.addi       s47, s13, #1280
x8dot_row_43:
    s.addi       s48, s30, #0
    v.movi       v20, #0
    s.sub        s49, s48, s45
    s.add        s48, s46, s45
    v.splat      v21, s49
    s.shli       s49, s45, #4
    s.addi       s50, s45, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s48, v4]             // index is in elements (ISA sec 9.1)
    s.add        s48, s47, s49
    s.movz       s49, #32
    v.st.b       [s48, #0], v20
    fence.acq_rel.device
    s.mov        s45, s50
    s.cmp.lt     s48, s45, s49
    br.nz        s48, x8dot_row_43
x8dot_done_42:
    v.splat      v4, s44
    v.movi       v20, #0
    mb.arm       s44, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s45, v27, #7
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s46, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s46, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s46, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s46, v22, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s45
    mb.wait      s45
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s46, x8dot_done_44
    s.add        s47, s8, s26
    s.addi       s48, s42, #0
    v.ld.w       v4, [s13, #0]
    s.addi       s42, s47, #32
    s.addi       s47, s13, #768
x8dot_row_45:
    s.addi       s49, s30, #-32
    v.movi       v20, #0
    s.sub        s50, s49, s48
    s.add        s49, s42, s48
    v.splat      v21, s50
    s.shli       s50, s48, #4
    s.addi       s51, s48, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s49, v4]             // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.movz       s50, #32
    v.st.b       [s49, #0], v20
    fence.acq_rel.device
    s.mov        s48, s51
    s.cmp.lt     s49, s48, s50
    br.nz        s49, x8dot_row_45
x8dot_done_44:
    v.splat      v4, s46
    v.movi       v20, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s46, #0
    v.extract    s47, v27, #0
    s.movz       s48, #32
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s49, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s49, s42            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s49, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s50, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s49, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s47, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v22, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s47
    mb.wait      s47
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s49, x8dot_done_46
    s.add        s50, s8, s26
    s.addi       s51, s46, #0
    v.ld.w       v4, [s13, #64]
    s.addi       s52, s50, #32
    s.addi       s50, s13, #1280
x8dot_row_47:
    s.addi       s53, s30, #-32
    v.movi       v20, #0
    s.sub        s54, s53, s51
    s.add        s53, s52, s51
    v.splat      v21, s54
    s.shli       s54, s51, #4
    s.addi       s55, s51, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s53, v4]             // index is in elements (ISA sec 9.1)
    s.add        s53, s50, s54
    v.st.b       [s53, #0], v20
    fence.acq_rel.device
    s.mov        s51, s55
    s.cmp.lt     s53, s51, s48
    br.nz        s53, x8dot_row_47
x8dot_done_46:
    mb.arm       s50, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v4, s49
    v.movi       v20, #0
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s46                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s51, s50            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s46, v27, #1
    s.mov        s51, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s48                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s50          // predicated off still completes once (ISA sec 9A.3)
    v.extract    s46, v19, #0
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #0
    v.splat      v4, s46
    v.extract    s46, v37, #0
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2816], v20
    v.extract    s46, v19, #1
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #1
    v.splat      v4, s46
    v.extract    s46, v37, #1
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2848], v20
    v.extract    s46, v19, #2
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #2
    v.splat      v4, s46
    v.extract    s46, v37, #2
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2880], v20
    v.extract    s46, v19, #3
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #3
    v.splat      v4, s46
    v.extract    s46, v37, #3
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2912], v20
    v.extract    s46, v19, #4
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #4
    v.splat      v4, s46
    v.extract    s46, v37, #4
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2944], v20
    v.extract    s46, v19, #5
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #5
    v.splat      v4, s46
    v.extract    s46, v37, #5
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2976], v20
    v.extract    s46, v19, #6
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #6
    v.splat      v4, s46
    v.extract    s46, v37, #6
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3008], v20
    v.extract    s46, v19, #7
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #7
    v.splat      v4, s46
    v.extract    s46, v37, #7
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3040], v20
    v.extract    s46, v19, #8
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #8
    v.splat      v4, s46
    v.extract    s46, v37, #8
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3072], v20
    v.extract    s46, v19, #9
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #9
    v.splat      v4, s46
    v.extract    s46, v37, #9
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3104], v20
    v.extract    s46, v19, #10
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #10
    v.splat      v4, s46
    v.extract    s46, v37, #10
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3136], v20
    v.extract    s46, v19, #11
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #11
    v.splat      v4, s46
    v.extract    s46, v37, #11
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3168], v20
    v.extract    s46, v19, #12
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #12
    v.splat      v4, s46
    v.extract    s46, v37, #12
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3200], v20
    v.extract    s46, v19, #13
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #13
    v.splat      v4, s46
    v.extract    s46, v37, #13
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3232], v20
    v.extract    s46, v19, #14
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #14
    v.splat      v4, s46
    v.extract    s46, v37, #14
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3264], v20
    v.extract    s46, v19, #15
    s.add        s48, s46, s29
    s.addi       s46, s48, #64
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #15
    v.splat      v4, s46
    v.extract    s46, v37, #15
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3296], v20
    v.extract    s46, v19, #0
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #0
    v.splat      v4, s46
    v.extract    s46, v37, #0
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2832], v20
    v.extract    s46, v19, #1
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #1
    v.splat      v4, s46
    v.extract    s46, v37, #1
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2864], v20
    v.extract    s46, v19, #2
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #2
    v.splat      v4, s46
    v.extract    s46, v37, #2
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2896], v20
    v.extract    s46, v19, #3
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #3
    v.splat      v4, s46
    v.extract    s46, v37, #3
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2928], v20
    v.extract    s46, v19, #4
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #4
    v.splat      v4, s46
    v.extract    s46, v37, #4
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2960], v20
    v.extract    s46, v19, #5
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #5
    v.splat      v4, s46
    v.extract    s46, v37, #5
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #2992], v20
    v.extract    s46, v19, #6
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #6
    v.splat      v4, s46
    v.extract    s46, v37, #6
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3024], v20
    v.extract    s46, v19, #7
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #7
    v.splat      v4, s46
    v.extract    s46, v37, #7
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3056], v20
    v.extract    s46, v19, #8
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #8
    v.splat      v4, s46
    v.extract    s46, v37, #8
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3088], v20
    v.extract    s46, v19, #9
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #9
    v.splat      v4, s46
    v.extract    s46, v37, #9
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3120], v20
    v.extract    s46, v19, #10
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #10
    v.splat      v4, s46
    v.extract    s46, v37, #10
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3152], v20
    v.extract    s46, v19, #11
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #11
    v.splat      v4, s46
    v.extract    s46, v37, #11
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3184], v20
    v.extract    s46, v19, #12
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #12
    v.splat      v4, s46
    v.extract    s46, v37, #12
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3216], v20
    v.extract    s46, v19, #13
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #13
    v.splat      v4, s46
    v.extract    s46, v37, #13
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3248], v20
    v.extract    s46, v19, #14
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #14
    v.splat      v4, s46
    v.extract    s46, v37, #14
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3280], v20
    v.extract    s46, v19, #15
    s.add        s48, s46, s29
    s.addi       s46, s48, #96
    s.add        s48, s9, s46
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v4, [s48, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s46, v32, #15
    v.splat      v4, s46
    v.extract    s46, v37, #15
    v.splat      v21, s46
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3312], v20
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.ld.w       v4, [s13, #2816]
    v.mov        v56, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #2880]
    v.mov        v57, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #2944]
    v.mov        v58, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #3008]
    v.mov        v59, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #3072]
    v.mov        v60, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #3136]
    v.mov        v61, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #3200]
    v.mov        v62, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #3264]
    v.mov        v63, v4                         // hand off through the shared window (sec 7.3)
    mb.wait      s42
    mb.arm       s46, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s46
    mb.wait      s46
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s48, v22, #2
    br.nz        s48, x8dot_done_48
    s.movz       s49, #0
    s.add        s51, s8, s26
    s.addi       s52, s49, #0
    v.ld.w       v4, [s13, #128]
    s.addi       s49, s51, #32
    s.addi       s51, s13, #768
x8dot_row_49:
    s.addi       s53, s30, #-32
    v.movi       v20, #0
    s.sub        s54, s53, s52
    s.add        s53, s49, s52
    v.splat      v21, s54
    s.shli       s54, s52, #4
    s.addi       s55, s52, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s53, v4]             // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.movz       s54, #32
    v.st.b       [s53, #0], v20
    fence.acq_rel.device
    s.mov        s52, s55
    s.cmp.lt     s53, s52, s54
    br.nz        s53, x8dot_row_49
x8dot_done_48:
    v.splat      v4, s48
    v.movi       v20, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    v.extract    s51, v27, #2
    s.movz       s52, #32
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s53, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s53, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s51, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v22, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s51
    mb.wait      s51
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s53, x8dot_done_50
    s.add        s54, s8, s26
    s.addi       s55, s49, #0
    v.ld.w       v4, [s13, #192]
    s.addi       s56, s54, #32
    s.addi       s54, s13, #1280
x8dot_row_51:
    s.addi       s57, s30, #-32
    v.movi       v20, #0
    s.sub        s58, s57, s55
    s.add        s57, s56, s55
    v.splat      v21, s58
    s.shli       s58, s55, #4
    s.addi       s59, s55, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s57, v4]             // index is in elements (ISA sec 9.1)
    s.add        s57, s54, s58
    v.st.b       [s57, #0], v20
    fence.acq_rel.device
    s.mov        s55, s59
    s.cmp.lt     s57, s55, s52
    br.nz        s57, x8dot_row_51
x8dot_done_50:
    v.splat      v4, s53
    v.movi       v20, #0
    mb.arm       s53, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s54, v27, #3
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s55, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s55, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v22, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s52
    mb.wait      s52
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s54, x8dot_done_52
    s.add        s55, s8, s26
    s.addi       s56, s49, #0
    v.ld.w       v4, [s13, #256]
    s.addi       s49, s55, #32
    s.addi       s55, s13, #768
x8dot_row_53:
    s.addi       s57, s30, #-32
    v.movi       v20, #0
    s.sub        s58, s57, s56
    s.add        s57, s49, s56
    v.splat      v21, s58
    s.shli       s58, s56, #4
    s.addi       s59, s56, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s57, v4]             // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.movz       s58, #32
    v.st.b       [s57, #0], v20
    fence.acq_rel.device
    s.mov        s56, s59
    s.cmp.lt     s57, s56, s58
    br.nz        s57, x8dot_row_53
x8dot_done_52:
    v.splat      v4, s54
    v.movi       v20, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    v.extract    s55, v27, #4
    s.movz       s56, #32
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s57, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s57, s49            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s57, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s55, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s57, v22, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s55
    mb.wait      s55
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s57, x8dot_done_54
    s.add        s58, s8, s26
    s.addi       s59, s54, #0
    v.ld.w       v4, [s13, #320]
    s.addi       s60, s58, #32
    s.addi       s58, s13, #1280
x8dot_row_55:
    s.addi       s28, s30, #-32
    v.movi       v20, #0
    s.sub        s31, s28, s59
    s.add        s28, s60, s59
    v.splat      v21, s31
    s.shli       s31, s59, #4
    s.addi       s32, s59, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s28, v4]             // index is in elements (ISA sec 9.1)
    s.add        s28, s58, s31
    v.st.b       [s28, #0], v20
    fence.acq_rel.device
    s.mov        s59, s32
    s.cmp.lt     s28, s59, s56
    br.nz        s28, x8dot_row_55
x8dot_done_54:
    v.splat      v4, s57
    v.movi       v20, #0
    mb.arm       s28, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s31, v27, #5
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s32, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s32, s28            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s32, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s32, v22, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s31
    mb.wait      s31
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s32, x8dot_done_56
    s.add        s33, s8, s26
    s.addi       s34, s54, #0
    v.ld.w       v4, [s13, #384]
    s.addi       s35, s33, #32
    s.addi       s33, s13, #768
x8dot_row_57:
    s.addi       s36, s30, #-32
    v.movi       v20, #0
    s.sub        s37, s36, s34
    s.add        s36, s35, s34
    v.splat      v21, s37
    s.shli       s37, s34, #4
    s.addi       s38, s34, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s36, v4]             // index is in elements (ISA sec 9.1)
    s.add        s36, s33, s37
    s.movz       s37, #32
    v.st.b       [s36, #0], v20
    fence.acq_rel.device
    s.mov        s34, s38
    s.cmp.lt     s36, s34, s37
    br.nz        s36, x8dot_row_57
x8dot_done_56:
    v.splat      v4, s32
    v.movi       v20, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    v.extract    s34, v27, #6
    s.movz       s35, #32
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s36, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s36, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s36, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s34, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v22, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s34
    mb.wait      s34
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s36, x8dot_done_58
    s.add        s37, s8, s26
    s.addi       s38, s33, #0
    v.ld.w       v4, [s13, #448]
    s.addi       s39, s37, #32
    s.addi       s37, s13, #1280
x8dot_row_59:
    s.addi       s40, s30, #-32
    v.movi       v20, #0
    s.sub        s41, s40, s38
    s.add        s40, s39, s38
    v.splat      v21, s41
    s.shli       s41, s38, #4
    s.addi       s42, s38, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s40, v4]             // index is in elements (ISA sec 9.1)
    s.add        s40, s37, s41
    v.st.b       [s40, #0], v20
    fence.acq_rel.device
    s.mov        s38, s42
    s.cmp.lt     s40, s38, s35
    br.nz        s40, x8dot_row_59
x8dot_done_58:
    v.splat      v4, s36
    v.movi       v20, #0
    mb.arm       s36, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s37, v27, #7
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s38, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s38, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v22, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s35
    mb.wait      s35
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s37, x8dot_done_60
    s.add        s38, s8, s26
    s.addi       s39, s33, #0
    v.ld.w       v4, [s13, #0]
    s.addi       s33, s38, #64
    s.addi       s38, s13, #768
x8dot_row_61:
    s.addi       s40, s30, #-64
    v.movi       v20, #0
    s.sub        s41, s40, s39
    s.add        s40, s33, s39
    v.splat      v21, s41
    s.shli       s41, s39, #4
    s.addi       s42, s39, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s40, v4]             // index is in elements (ISA sec 9.1)
    s.add        s40, s38, s41
    s.movz       s41, #32
    v.st.b       [s40, #0], v20
    fence.acq_rel.device
    s.mov        s39, s42
    s.cmp.lt     s40, s39, s41
    br.nz        s40, x8dot_row_61
x8dot_done_60:
    v.splat      v4, s37
    v.movi       v20, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    v.extract    s38, v27, #0
    s.movz       s39, #64
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s40, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s40, s33            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s40, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s38, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v22, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s38
    mb.wait      s38
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s40, x8dot_done_62
    s.add        s41, s8, s26
    s.addi       s42, s37, #0
    v.ld.w       v4, [s13, #64]
    s.addi       s43, s41, #64
    s.addi       s41, s13, #1280
x8dot_row_63:
    s.addi       s44, s30, #-64
    v.movi       v20, #0
    s.sub        s45, s44, s42
    s.add        s44, s43, s42
    v.splat      v21, s45
    s.shli       s45, s42, #4
    s.addi       s46, s42, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s44, v4]             // index is in elements (ISA sec 9.1)
    s.add        s44, s41, s45
    s.movz       s45, #32
    v.st.b       [s44, #0], v20
    fence.acq_rel.device
    s.mov        s42, s46
    s.cmp.lt     s44, s42, s45
    br.nz        s44, x8dot_row_63
x8dot_done_62:
    mb.arm       s41, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v4, s40
    v.movi       v20, #0
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s42, s41            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s37, v27, #1
    s.mov        s42, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s41          // predicated off still completes once (ISA sec 9A.3)
    v.extract    s37, v19, #0
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #0
    v.splat      v4, s37
    v.extract    s37, v37, #0
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3328], v20
    v.extract    s37, v19, #1
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #1
    v.splat      v4, s37
    v.extract    s37, v37, #1
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3360], v20
    v.extract    s37, v19, #2
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #2
    v.splat      v4, s37
    v.extract    s37, v37, #2
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3392], v20
    v.extract    s37, v19, #3
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #3
    v.splat      v4, s37
    v.extract    s37, v37, #3
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3424], v20
    v.extract    s37, v19, #4
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #4
    v.splat      v4, s37
    v.extract    s37, v37, #4
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3456], v20
    v.extract    s37, v19, #5
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #5
    v.splat      v4, s37
    v.extract    s37, v37, #5
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3488], v20
    v.extract    s37, v19, #6
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #6
    v.splat      v4, s37
    v.extract    s37, v37, #6
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3520], v20
    v.extract    s37, v19, #7
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #7
    v.splat      v4, s37
    v.extract    s37, v37, #7
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3552], v20
    v.extract    s37, v19, #8
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #8
    v.splat      v4, s37
    v.extract    s37, v37, #8
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3584], v20
    v.extract    s37, v19, #9
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #9
    v.splat      v4, s37
    v.extract    s37, v37, #9
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3616], v20
    v.extract    s37, v19, #10
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #10
    v.splat      v4, s37
    v.extract    s37, v37, #10
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3648], v20
    v.extract    s37, v19, #11
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #11
    v.splat      v4, s37
    v.extract    s37, v37, #11
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3680], v20
    v.extract    s37, v19, #12
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #12
    v.splat      v4, s37
    v.extract    s37, v37, #12
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3712], v20
    v.extract    s37, v19, #13
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #13
    v.splat      v4, s37
    v.extract    s37, v37, #13
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3744], v20
    v.extract    s37, v19, #14
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #14
    v.splat      v4, s37
    v.extract    s37, v37, #14
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3776], v20
    v.extract    s37, v19, #15
    s.add        s39, s37, s29
    s.addi       s37, s39, #128
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #15
    v.splat      v4, s37
    v.extract    s37, v37, #15
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3808], v20
    v.extract    s37, v19, #0
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #0
    v.splat      v4, s37
    v.extract    s37, v37, #0
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3344], v20
    v.extract    s37, v19, #1
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #1
    v.splat      v4, s37
    v.extract    s37, v37, #1
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3376], v20
    v.extract    s37, v19, #2
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #2
    v.splat      v4, s37
    v.extract    s37, v37, #2
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3408], v20
    v.extract    s37, v19, #3
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #3
    v.splat      v4, s37
    v.extract    s37, v37, #3
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3440], v20
    v.extract    s37, v19, #4
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #4
    v.splat      v4, s37
    v.extract    s37, v37, #4
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3472], v20
    v.extract    s37, v19, #5
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #5
    v.splat      v4, s37
    v.extract    s37, v37, #5
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3504], v20
    v.extract    s37, v19, #6
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #6
    v.splat      v4, s37
    v.extract    s37, v37, #6
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3536], v20
    v.extract    s37, v19, #7
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #7
    v.splat      v4, s37
    v.extract    s37, v37, #7
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3568], v20
    v.extract    s37, v19, #8
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #8
    v.splat      v4, s37
    v.extract    s37, v37, #8
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3600], v20
    v.extract    s37, v19, #9
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #9
    v.splat      v4, s37
    v.extract    s37, v37, #9
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3632], v20
    v.extract    s37, v19, #10
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #10
    v.splat      v4, s37
    v.extract    s37, v37, #10
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3664], v20
    v.extract    s37, v19, #11
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #11
    v.splat      v4, s37
    v.extract    s37, v37, #11
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3696], v20
    v.extract    s37, v19, #12
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #12
    v.splat      v4, s37
    v.extract    s37, v37, #12
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3728], v20
    v.extract    s37, v19, #13
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #13
    v.splat      v4, s37
    v.extract    s37, v37, #13
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3760], v20
    v.extract    s37, v19, #14
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #14
    v.splat      v4, s37
    v.extract    s37, v37, #14
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3792], v20
    v.extract    s37, v19, #15
    s.add        s39, s37, s29
    s.addi       s37, s39, #160
    s.add        s39, s9, s37
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p6 v.ld.h       v4, [s39, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s37, v32, #15
    v.splat      v4, s37
    v.extract    s37, v37, #15
    v.splat      v21, s37
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3824], v20
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.ld.w       v4, [s13, #3328]
    v.mov        v56, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #3392]
    v.mov        v57, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #3456]
    v.mov        v58, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #3520]
    v.mov        v59, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #3584]
    v.mov        v60, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #3648]
    v.mov        v61, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #3712]
    v.mov        v62, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #3776]
    v.mov        v63, v4                         // hand off through the shared window (sec 7.3)
    mb.wait      s33
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s37
    mb.wait      s37
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s39, v22, #2
    br.nz        s39, x8dot_done_64
    s.movz       s40, #0
    s.add        s42, s8, s26
    s.addi       s43, s40, #0
    v.ld.w       v4, [s13, #128]
    s.addi       s40, s42, #64
    s.addi       s42, s13, #768
x8dot_row_65:
    s.addi       s44, s30, #-64
    v.movi       v20, #0
    s.sub        s45, s44, s43
    s.add        s44, s40, s43
    v.splat      v21, s45
    s.shli       s45, s43, #4
    s.addi       s46, s43, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s44, v4]             // index is in elements (ISA sec 9.1)
    s.add        s44, s42, s45
    s.movz       s45, #32
    v.st.b       [s44, #0], v20
    fence.acq_rel.device
    s.mov        s43, s46
    s.cmp.lt     s44, s43, s45
    br.nz        s44, x8dot_row_65
x8dot_done_64:
    v.splat      v4, s39
    v.movi       v20, #0
    mb.arm       s39, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.extract    s42, v27, #2
    s.movz       s43, #64
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s44, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s44, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s41
    mb.arm       s42, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s44, v22, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s42
    mb.wait      s42
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s44, x8dot_done_66
    s.add        s45, s8, s26
    s.addi       s46, s40, #0
    v.ld.w       v4, [s13, #192]
    s.addi       s47, s45, #64
    s.addi       s45, s13, #1280
x8dot_row_67:
    s.addi       s48, s30, #-64
    v.movi       v20, #0
    s.sub        s50, s48, s46
    s.add        s48, s47, s46
    v.splat      v21, s50
    s.shli       s50, s46, #4
    s.addi       s51, s46, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s48, v4]             // index is in elements (ISA sec 9.1)
    s.add        s48, s45, s50
    s.movz       s50, #32
    v.st.b       [s48, #0], v20
    fence.acq_rel.device
    s.mov        s46, s51
    s.cmp.lt     s48, s46, s50
    br.nz        s48, x8dot_row_67
x8dot_done_66:
    v.splat      v4, s44
    v.movi       v20, #0
    mb.arm       s44, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s45, v27, #3
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s46, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s46, s44            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s46, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v22, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s43
    mb.wait      s43
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s45, x8dot_done_68
    s.add        s46, s8, s26
    s.addi       s47, s40, #0
    v.ld.w       v4, [s13, #256]
    s.addi       s40, s46, #64
    s.addi       s46, s13, #768
x8dot_row_69:
    s.addi       s48, s30, #-64
    v.movi       v20, #0
    s.sub        s50, s48, s47
    s.add        s48, s40, s47
    v.splat      v21, s50
    s.shli       s50, s47, #4
    s.addi       s51, s47, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s48, v4]             // index is in elements (ISA sec 9.1)
    s.add        s48, s46, s50
    s.movz       s50, #32
    v.st.b       [s48, #0], v20
    fence.acq_rel.device
    s.mov        s47, s51
    s.cmp.lt     s48, s47, s50
    br.nz        s48, x8dot_row_69
x8dot_done_68:
    v.splat      v4, s45
    v.movi       v20, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    v.extract    s46, v27, #4
    s.movz       s47, #64
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s50, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s50, s40            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s50, s46                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s50, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s46, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s48, v22, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s46
    mb.wait      s46
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s48, x8dot_done_70
    s.add        s50, s8, s26
    s.addi       s51, s45, #0
    v.ld.w       v4, [s13, #320]
    s.addi       s52, s50, #64
    s.addi       s50, s13, #1280
x8dot_row_71:
    s.addi       s53, s30, #-64
    v.movi       v20, #0
    s.sub        s54, s53, s51
    s.add        s53, s52, s51
    v.splat      v21, s54
    s.shli       s54, s51, #4
    s.addi       s55, s51, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s53, v4]             // index is in elements (ISA sec 9.1)
    s.add        s53, s50, s54
    s.movz       s54, #32
    v.st.b       [s53, #0], v20
    fence.acq_rel.device
    s.mov        s51, s55
    s.cmp.lt     s53, s51, s54
    br.nz        s53, x8dot_row_71
x8dot_done_70:
    v.splat      v4, s48
    v.movi       v20, #0
    mb.arm       s48, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s50, v27, #5
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s51, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s51, s48            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s51, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s52, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s51, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s50, v22, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s47
    mb.wait      s47
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s50, x8dot_done_72
    s.add        s51, s8, s26
    s.addi       s52, s45, #0
    v.ld.w       v4, [s13, #384]
    s.addi       s45, s51, #64
    s.addi       s51, s13, #768
x8dot_row_73:
    s.addi       s53, s30, #-64
    v.movi       v20, #0
    s.sub        s54, s53, s52
    s.add        s53, s45, s52
    v.splat      v21, s54
    s.shli       s54, s52, #4
    s.addi       s55, s52, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s53, v4]             // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.movz       s54, #32
    v.st.b       [s53, #0], v20
    fence.acq_rel.device
    s.mov        s52, s55
    s.cmp.lt     s53, s52, s54
    br.nz        s53, x8dot_row_73
x8dot_done_72:
    v.splat      v4, s50
    v.movi       v20, #0
    mb.arm       s45, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    v.extract    s51, v27, #6
    s.movz       s52, #64
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s53, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s53, s45            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s54, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s53, s45          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s51, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v22, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s51
    mb.wait      s51
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s53, x8dot_done_74
    s.add        s54, s8, s26
    s.addi       s55, s50, #0
    v.ld.w       v4, [s13, #448]
    s.addi       s56, s54, #64
    s.addi       s54, s13, #1280
x8dot_row_75:
    s.addi       s57, s30, #-64
    v.movi       v20, #0
    s.sub        s58, s57, s55
    s.add        s57, s56, s55
    v.splat      v21, s58
    s.shli       s58, s55, #4
    s.addi       s59, s55, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s57, v4]             // index is in elements (ISA sec 9.1)
    s.add        s57, s54, s58
    s.movz       s58, #32
    v.st.b       [s57, #0], v20
    fence.acq_rel.device
    s.mov        s55, s59
    s.cmp.lt     s57, s55, s58
    br.nz        s57, x8dot_row_75
x8dot_done_74:
    v.splat      v4, s53
    v.movi       v20, #0
    mb.arm       s53, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s54, v27, #7
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s55, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s55, s53            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s55, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s56, s52                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s55, s53          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s45
    mb.arm       s52, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s54, v22, #0
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s52
    mb.wait      s52
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s54, x8dot_done_76
    s.add        s55, s8, s26
    s.addi       s56, s50, #0
    v.ld.w       v4, [s13, #0]
    s.addi       s50, s55, #96
    s.addi       s55, s13, #768
x8dot_row_77:
    s.addi       s57, s30, #-96
    v.movi       v20, #0
    s.sub        s58, s57, s56
    s.add        s57, s50, s56
    v.splat      v21, s58
    s.shli       s58, s56, #4
    s.addi       s59, s56, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s57, v4]             // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.movz       s58, #32
    v.st.b       [s57, #0], v20
    fence.acq_rel.device
    s.mov        s56, s59
    s.cmp.lt     s57, s56, s58
    br.nz        s57, x8dot_row_77
x8dot_done_76:
    v.splat      v4, s54
    v.movi       v20, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s54, #0
    v.extract    s55, v27, #0
    s.movz       s56, #96
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s57, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s57, s50            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s57, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s58, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s57, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s53
    mb.arm       s55, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s57, v22, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s55
    mb.wait      s55
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s57, x8dot_done_78
    s.add        s58, s8, s26
    s.addi       s59, s54, #0
    v.ld.w       v4, [s13, #64]
    s.addi       s60, s58, #96
    s.addi       s58, s13, #1280
x8dot_row_79:
    s.addi       s28, s30, #-96
    v.movi       v20, #0
    s.sub        s31, s28, s59
    s.add        s28, s60, s59
    v.splat      v21, s31
    s.shli       s31, s59, #4
    s.addi       s32, s59, #1
    v.cmp.gt     p1, v21, v20
    v.movi       v20, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v20, [s28, v4]             // index is in elements (ISA sec 9.1)
    s.add        s28, s58, s31
    s.movz       s31, #32
    v.st.b       [s28, #0], v20
    fence.acq_rel.device
    s.mov        s59, s32
    s.cmp.lt     s28, s59, s31
    br.nz        s28, x8dot_row_79
x8dot_done_78:
    mb.arm       s28, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.splat      v4, s57
    v.movi       v20, #0
    v.cmp.ne     p1, v4, v20
    v.cmp.eq     p2, v4, v20
    s.mov        s31, s54                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s32, s54                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s31, s28            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s31, v27, #1
    s.mov        s32, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s56                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s28          // predicated off still completes once (ISA sec 9A.3)
    v.extract    s31, v19, #0
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #0
    v.splat      v4, s31
    v.extract    s31, v37, #0
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3840], v20
    v.extract    s31, v19, #1
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #1
    v.splat      v4, s31
    v.extract    s31, v37, #1
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3872], v20
    v.extract    s31, v19, #2
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #2
    v.splat      v4, s31
    v.extract    s31, v37, #2
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3904], v20
    v.extract    s31, v19, #3
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #3
    v.splat      v4, s31
    v.extract    s31, v37, #3
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3936], v20
    v.extract    s31, v19, #4
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #4
    v.splat      v4, s31
    v.extract    s31, v37, #4
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3968], v20
    v.extract    s31, v19, #5
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #5
    v.splat      v4, s31
    v.extract    s31, v37, #5
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4000], v20
    v.extract    s31, v19, #6
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #6
    v.splat      v4, s31
    v.extract    s31, v37, #6
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4032], v20
    v.extract    s31, v19, #7
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #7
    v.splat      v4, s31
    v.extract    s31, v37, #7
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4064], v20
    v.extract    s31, v19, #8
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #8
    v.splat      v4, s31
    v.extract    s31, v37, #8
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4096], v20
    v.extract    s31, v19, #9
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #9
    v.splat      v4, s31
    v.extract    s31, v37, #9
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4128], v20
    v.extract    s31, v19, #10
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #10
    v.splat      v4, s31
    v.extract    s31, v37, #10
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4160], v20
    v.extract    s31, v19, #11
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #11
    v.splat      v4, s31
    v.extract    s31, v37, #11
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4192], v20
    v.extract    s31, v19, #12
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #12
    v.splat      v4, s31
    v.extract    s31, v37, #12
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4224], v20
    v.extract    s31, v19, #13
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #13
    v.splat      v4, s31
    v.extract    s31, v37, #13
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4256], v20
    v.extract    s31, v19, #14
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #14
    v.splat      v4, s31
    v.extract    s31, v37, #14
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4288], v20
    v.extract    s31, v19, #15
    s.add        s32, s31, s29
    s.addi       s31, s32, #192
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p7 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #15
    v.splat      v4, s31
    v.extract    s31, v37, #15
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4320], v20
    v.extract    s31, v19, #0
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #0
    v.splat      v4, s31
    v.extract    s31, v37, #0
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3856], v20
    v.extract    s31, v19, #1
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #1
    v.splat      v4, s31
    v.extract    s31, v37, #1
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3888], v20
    v.extract    s31, v19, #2
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #2
    v.splat      v4, s31
    v.extract    s31, v37, #2
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3920], v20
    v.extract    s31, v19, #3
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #3
    v.splat      v4, s31
    v.extract    s31, v37, #3
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3952], v20
    v.extract    s31, v19, #4
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #4
    v.splat      v4, s31
    v.extract    s31, v37, #4
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #3984], v20
    v.extract    s31, v19, #5
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #5
    v.splat      v4, s31
    v.extract    s31, v37, #5
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4016], v20
    v.extract    s31, v19, #6
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #6
    v.splat      v4, s31
    v.extract    s31, v37, #6
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4048], v20
    v.extract    s31, v19, #7
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #7
    v.splat      v4, s31
    v.extract    s31, v37, #7
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4080], v20
    v.extract    s31, v19, #8
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #8
    v.splat      v4, s31
    v.extract    s31, v37, #8
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4112], v20
    v.extract    s31, v19, #9
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #9
    v.splat      v4, s31
    v.extract    s31, v37, #9
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4144], v20
    v.extract    s31, v19, #10
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #10
    v.splat      v4, s31
    v.extract    s31, v37, #10
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4176], v20
    v.extract    s31, v19, #11
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #11
    v.splat      v4, s31
    v.extract    s31, v37, #11
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4208], v20
    v.extract    s31, v19, #12
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #12
    v.splat      v4, s31
    v.extract    s31, v37, #12
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4240], v20
    v.extract    s31, v19, #13
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #13
    v.splat      v4, s31
    v.extract    s31, v37, #13
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4272], v20
    v.extract    s31, v19, #14
    s.add        s32, s31, s29
    s.addi       s31, s32, #224
    s.add        s32, s9, s31
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s32, #0]
    vf.cvt.f16.f32 v20, v4
    v.extract    s31, v32, #14
    v.splat      v4, s31
    v.extract    s31, v37, #14
    v.splat      v21, s31
    vf.mul       v24, v20, v21                   // a/y: faithful quotient
    vf.fms       v26, v24, v4, v20
    vf.fms       v4, v26, v21, v24
    vf.neg       v20, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v20, v20
    @p1 v.sel        v4, v20, v24
    vf.cvt.f32.e4m3 v20, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v20, v20, #128              // a NaN keeps its sign
    v.st.b       [s13, #4304], v20
    v.extract    s31, v19, #15
    s.add        s32, s31, s29
    s.addi       s29, s32, #224
    s.add        s31, s9, s29
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p8 v.ld.h       v4, [s31, #0]
    vf.cvt.f16.f32 v19, v4
    v.extract    s29, v32, #15
    v.splat      v4, s29
    v.extract    s29, v37, #15
    v.splat      v20, s29
    vf.mul       v21, v19, v20                   // a/y: faithful quotient
    vf.fms       v24, v21, v4, v19
    vf.fms       v4, v24, v20, v21
    vf.neg       v19, v4                         // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v4, v19, v21
    vf.cvt.f32.e4m3 v19, v4
    v.cmpi.lt    p1, v4, #0
    @p1 v.ori        v19, v19, #128              // a NaN keeps its sign
    v.st.b       [s13, #4336], v19
    fence.acq_rel.device
    w.def        w2, #56, #8                     // v56..v63
    v.ld.w       v4, [s13, #3840]
    v.mov        v56, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #3904]
    v.mov        v57, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #3968]
    v.mov        v58, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #4032]
    v.mov        v59, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #4096]
    v.mov        v60, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #4160]
    v.mov        v61, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #4224]
    v.mov        v62, v4                         // hand off through the shared window (sec 7.3)
    v.ld.w       v4, [s13, #4288]
    v.mov        v63, v4                         // hand off through the shared window (sec 7.3)
    mb.wait      s50
    mb.arm       s29, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.dp.async.k32.e4m3 a8, v56, v40, s29
    mb.wait      s29
    w.def        w0, #40, #8                     // v40..v47
    v.extract    s31, v22, #2
    br.nz        s31, x8dot_done_80
    s.movz       s32, #0
    s.add        s33, s8, s26
    s.addi       s34, s32, #0
    v.ld.w       v4, [s13, #128]
    s.addi       s32, s33, #96
    s.addi       s33, s13, #768
x8dot_row_81:
    s.addi       s35, s30, #-96
    v.movi       v19, #0
    s.sub        s36, s35, s34
    s.add        s35, s32, s34
    v.splat      v20, s36
    s.shli       s36, s34, #4
    s.addi       s37, s34, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s35, v4]             // index is in elements (ISA sec 9.1)
    s.add        s35, s33, s36
    s.movz       s36, #32
    v.st.b       [s35, #0], v19
    fence.acq_rel.device
    s.mov        s34, s37
    s.cmp.lt     s35, s34, s36
    br.nz        s35, x8dot_row_81
x8dot_done_80:
    v.splat      v4, s31
    v.movi       v19, #0
    mb.arm       s31, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s32, #0
    v.extract    s33, v27, #2
    s.movz       s34, #96
    v.cmp.ne     p1, v4, v19
    v.cmp.eq     p2, v4, v19
    s.mov        s35, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s35, s31            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s35, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s35, s31          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s33, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v22, #3
    m.mma.dp.async.k32.e4m3 a9, v56, v48, s33
    mb.wait      s33
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s35, x8dot_done_82
    s.add        s36, s8, s26
    s.addi       s37, s32, #0
    v.ld.w       v4, [s13, #192]
    s.addi       s38, s36, #96
    s.addi       s36, s13, #1280
x8dot_row_83:
    s.addi       s39, s30, #-96
    v.movi       v19, #0
    s.sub        s40, s39, s37
    s.add        s39, s38, s37
    v.splat      v20, s40
    s.shli       s40, s37, #4
    s.addi       s41, s37, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s39, v4]             // index is in elements (ISA sec 9.1)
    s.add        s39, s36, s40
    s.movz       s40, #32
    v.st.b       [s39, #0], v19
    fence.acq_rel.device
    s.mov        s37, s41
    s.cmp.lt     s39, s37, s40
    br.nz        s39, x8dot_row_83
x8dot_done_82:
    v.splat      v4, s35
    v.movi       v19, #0
    mb.arm       s35, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s36, v27, #3
    v.cmp.ne     p1, v4, v19
    v.cmp.eq     p2, v4, v19
    s.mov        s37, s32                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s32                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s37, s35            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s37, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s38, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s37, s35          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s31
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s36, v22, #4
    m.mma.dp.async.k32.e4m3 a10, v56, v40, s34
    mb.wait      s34
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s36, x8dot_done_84
    s.add        s37, s8, s26
    s.addi       s38, s32, #0
    v.ld.w       v4, [s13, #256]
    s.addi       s32, s37, #96
    s.addi       s37, s13, #768
x8dot_row_85:
    s.addi       s39, s30, #-96
    v.movi       v19, #0
    s.sub        s40, s39, s38
    s.add        s39, s32, s38
    v.splat      v20, s40
    s.shli       s40, s38, #4
    s.addi       s41, s38, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s39, v4]             // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.movz       s40, #32
    v.st.b       [s39, #0], v19
    fence.acq_rel.device
    s.mov        s38, s41
    s.cmp.lt     s39, s38, s40
    br.nz        s39, x8dot_row_85
x8dot_done_84:
    v.splat      v4, s36
    v.movi       v19, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s36, #0
    v.extract    s37, v27, #4
    s.movz       s38, #96
    v.cmp.ne     p1, v4, v19
    v.cmp.eq     p2, v4, v19
    s.mov        s39, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s39, s32            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s39, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s40, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s39, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s35
    mb.arm       s37, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v22, #5
    m.mma.dp.async.k32.e4m3 a11, v56, v48, s37
    mb.wait      s37
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s39, x8dot_done_86
    s.add        s40, s8, s26
    s.addi       s41, s36, #0
    v.ld.w       v4, [s13, #320]
    s.addi       s42, s40, #96
    s.addi       s40, s13, #1280
x8dot_row_87:
    s.addi       s43, s30, #-96
    v.movi       v19, #0
    s.sub        s44, s43, s41
    s.add        s43, s42, s41
    v.splat      v20, s44
    s.shli       s44, s41, #4
    s.addi       s45, s41, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s43, v4]             // index is in elements (ISA sec 9.1)
    s.add        s43, s40, s44
    s.movz       s44, #32
    v.st.b       [s43, #0], v19
    fence.acq_rel.device
    s.mov        s41, s45
    s.cmp.lt     s43, s41, s44
    br.nz        s43, x8dot_row_87
x8dot_done_86:
    v.splat      v4, s39
    v.movi       v19, #0
    mb.arm       s39, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s40, v27, #5
    v.cmp.ne     p1, v4, v19
    v.cmp.eq     p2, v4, v19
    s.mov        s41, s36                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s36                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s41, s39            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s38                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s39          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s38, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s40, v22, #6
    m.mma.dp.async.k32.e4m3 a12, v56, v40, s38
    mb.wait      s38
    w.def        w0, #40, #8                     // v40..v47
    br.nz        s40, x8dot_done_88
    s.add        s41, s8, s26
    s.addi       s42, s36, #0
    v.ld.w       v4, [s13, #384]
    s.addi       s36, s41, #96
    s.addi       s41, s13, #768
x8dot_row_89:
    s.addi       s43, s30, #-96
    v.movi       v19, #0
    s.sub        s44, s43, s42
    s.add        s43, s36, s42
    v.splat      v20, s44
    s.shli       s44, s42, #4
    s.addi       s45, s42, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s43, v4]             // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.movz       s44, #32
    v.st.b       [s43, #0], v19
    fence.acq_rel.device
    s.mov        s42, s45
    s.cmp.lt     s43, s42, s44
    br.nz        s43, x8dot_row_89
x8dot_done_88:
    v.splat      v4, s40
    v.movi       v19, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    v.extract    s41, v27, #6
    s.movz       s42, #96
    v.cmp.ne     p1, v4, v19
    v.cmp.eq     p2, v4, v19
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w0, d1, s43, s36            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w0, d0, s43, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s39
    mb.arm       s41, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v22, #7
    m.mma.dp.async.k32.e4m3 a13, v56, v48, s41
    mb.wait      s41
    w.def        w1, #48, #8                     // v48..v55
    br.nz        s43, x8dot_done_90
    s.add        s44, s8, s26
    s.addi       s45, s40, #0
    v.ld.w       v4, [s13, #448]
    s.addi       s46, s44, #96
    s.addi       s44, s13, #1280
x8dot_row_91:
    s.addi       s13, s30, #-96
    v.movi       v19, #0
    s.sub        s47, s13, s45
    s.add        s13, s46, s45
    v.splat      v20, s47
    s.shli       s47, s45, #4
    s.addi       s48, s45, #1
    v.cmp.gt     p1, v20, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v19, [s13, v4]             // index is in elements (ISA sec 9.1)
    s.add        s13, s44, s47
    s.movz       s47, #32
    v.st.b       [s13, #0], v19
    fence.acq_rel.device
    s.mov        s45, s48
    s.cmp.lt     s13, s45, s47
    br.nz        s13, x8dot_row_91
x8dot_done_90:
    v.splat      v4, s43
    v.movi       v19, #0
    mb.arm       s13, b1, #0, #2                 // 0 arrival(s), 2 operation(s)
    v.extract    s30, v27, #7
    v.cmp.ne     p1, v4, v19
    v.cmp.eq     p2, v4, v19
    s.mov        s43, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s40                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d2, s43, s13            // predicated off still completes once (ISA sec 9A.3)
    s.mov        s43, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s44, s42                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s43, s13          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s42, v35, #0
    s.movz       s43, #1
    m.mma.dp.async.k32.e4m3 a14, v56, v40, s30
    mb.wait      s30
    mb.wait      s13
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.splat      v4, s42
    v.extract    s42, v35, #1
    m.mma.dp.async.k32.e4m3 a15, v56, v48, s44
    mb.wait      s44
    a.vread      v19, a0, s40
    a.vread      v20, a8, s40
    v.splat      v21, s42
    s.movz       s42, #2
    vf.mul       v22, v20, v4
    v.extract    s45, v35, #2
    s.movz       s46, #3
    v.splat      v4, s45
    v.extract    s45, v35, #3
    vf.mul       v20, v22, v33
    v.splat      v22, s45
    s.movz       s45, #4
    v.extract    s47, v35, #4
    s.movz       s48, #5
    vf.add       v24, v19, v20
    v.splat      v19, s47
    v.extract    s47, v35, #5
    v.splat      v20, s47
    a.vwrite     a0, s40, v24
    a.vread      v24, a0, s43
    a.vread      v26, a8, s43
    s.movz       s40, #6
    v.extract    s47, v35, #6
    vf.mul       v27, v26, v21
    v.splat      v21, s47
    vf.mul       v26, v27, v33
    s.movz       s47, #7
    vf.add       v27, v24, v26
    a.vwrite     a0, s43, v27
    a.vread      v24, a0, s42
    a.vread      v26, a8, s42
    v.extract    s43, v35, #7
    vf.mul       v27, v26, v4
    v.splat      v4, s43
    vf.mul       v26, v27, v33
    s.movz       s43, #8
    vf.add       v27, v24, v26
    a.vwrite     a0, s42, v27
    a.vread      v24, a0, s46
    a.vread      v26, a8, s46
    v.extract    s42, v35, #8
    vf.mul       v27, v26, v22
    v.splat      v22, s42
    vf.mul       v26, v27, v33
    s.movz       s42, #9
    vf.add       v27, v24, v26
    a.vwrite     a0, s46, v27
    a.vread      v24, a0, s45
    a.vread      v26, a8, s45
    v.extract    s46, v35, #9
    vf.mul       v27, v26, v19
    v.splat      v19, s46
    vf.mul       v26, v27, v33
    s.movz       s46, #10
    vf.add       v27, v24, v26
    a.vwrite     a0, s45, v27
    a.vread      v24, a0, s48
    a.vread      v26, a8, s48
    v.extract    s45, v35, #10
    vf.mul       v27, v26, v20
    v.splat      v20, s45
    vf.mul       v26, v27, v33
    s.movz       s45, #11
    vf.add       v27, v24, v26
    a.vwrite     a0, s48, v27
    a.vread      v24, a0, s40
    a.vread      v26, a8, s40
    v.extract    s48, v35, #11
    vf.mul       v27, v26, v21
    v.splat      v21, s48
    vf.mul       v26, v27, v33
    s.movz       s48, #12
    vf.add       v27, v24, v26
    a.vwrite     a0, s40, v27
    a.vread      v24, a0, s47
    a.vread      v26, a8, s47
    v.extract    s40, v35, #12
    vf.mul       v27, v26, v4
    v.splat      v4, s40
    vf.mul       v26, v27, v33
    s.movz       s40, #13
    vf.add       v27, v24, v26
    a.vwrite     a0, s47, v27
    a.vread      v24, a0, s43
    a.vread      v26, a8, s43
    v.extract    s47, v35, #13
    vf.mul       v27, v26, v22
    v.splat      v22, s47
    vf.mul       v26, v27, v33
    s.movz       s47, #14
    vf.add       v27, v24, v26
    a.vwrite     a0, s43, v27
    a.vread      v24, a0, s42
    a.vread      v26, a8, s42
    v.extract    s43, v35, #14
    vf.mul       v27, v26, v19
    v.splat      v19, s43
    vf.mul       v26, v27, v33
    s.movz       s43, #15
    vf.add       v27, v24, v26
    a.vwrite     a0, s42, v27
    a.vread      v24, a0, s46
    a.vread      v26, a8, s46
    v.extract    s42, v35, #15
    vf.mul       v27, v26, v20
    v.splat      v20, s42
    vf.mul       v26, v27, v33
    s.movz       s42, #0
    vf.add       v27, v24, v26
    a.vwrite     a0, s46, v27
    a.vread      v24, a0, s45
    a.vread      v26, a8, s45
    v.extract    s46, v35, #0
    vf.mul       v27, v26, v21
    v.splat      v21, s46
    vf.mul       v26, v27, v33
    s.movz       s46, #1
    vf.add       v27, v24, v26
    a.vwrite     a0, s45, v27
    a.vread      v24, a0, s48
    a.vread      v26, a8, s48
    v.extract    s45, v35, #1
    vf.mul       v27, v26, v4
    v.splat      v4, s45
    vf.mul       v26, v27, v33
    s.movz       s45, #2
    vf.add       v27, v24, v26
    a.vwrite     a0, s48, v27
    a.vread      v24, a0, s40
    a.vread      v26, a8, s40
    v.extract    s48, v35, #2
    vf.mul       v27, v26, v22
    v.splat      v22, s48
    vf.mul       v26, v27, v33
    s.movz       s48, #3
    vf.add       v27, v24, v26
    a.vwrite     a0, s40, v27
    a.vread      v24, a0, s47
    a.vread      v26, a8, s47
    v.extract    s40, v35, #3
    vf.mul       v27, v26, v19
    v.splat      v19, s40
    vf.mul       v26, v27, v33
    s.movz       s40, #4
    vf.add       v27, v24, v26
    a.vwrite     a0, s47, v27
    a.vread      v24, a0, s43
    a.vread      v26, a8, s43
    v.extract    s47, v35, #4
    vf.mul       v27, v26, v20
    v.splat      v20, s47
    vf.mul       v26, v27, v33
    s.movz       s47, #5
    vf.add       v27, v24, v26
    a.vwrite     a0, s43, v27
    a.vread      v24, a1, s42
    a.vread      v26, a9, s42
    v.extract    s43, v35, #5
    vf.mul       v27, v26, v21
    v.splat      v21, s43
    vf.mul       v26, v27, v25
    s.movz       s43, #6
    vf.add       v27, v24, v26
    a.vwrite     a1, s42, v27
    a.vread      v24, a1, s46
    a.vread      v26, a9, s46
    v.extract    s42, v35, #6
    vf.mul       v27, v26, v4
    v.splat      v4, s42
    vf.mul       v26, v27, v25
    s.movz       s42, #7
    vf.add       v27, v24, v26
    a.vwrite     a1, s46, v27
    a.vread      v24, a1, s45
    a.vread      v26, a9, s45
    v.extract    s46, v35, #7
    vf.mul       v27, v26, v22
    v.splat      v22, s46
    vf.mul       v26, v27, v25
    s.movz       s46, #8
    vf.add       v27, v24, v26
    a.vwrite     a1, s45, v27
    a.vread      v24, a1, s48
    a.vread      v26, a9, s48
    v.extract    s45, v35, #8
    vf.mul       v27, v26, v19
    v.splat      v19, s45
    vf.mul       v26, v27, v25
    s.movz       s45, #9
    vf.add       v27, v24, v26
    a.vwrite     a1, s48, v27
    a.vread      v24, a1, s40
    a.vread      v26, a9, s40
    v.extract    s48, v35, #9
    vf.mul       v27, v26, v20
    v.splat      v20, s48
    vf.mul       v26, v27, v25
    s.movz       s48, #10
    vf.add       v27, v24, v26
    a.vwrite     a1, s40, v27
    a.vread      v24, a1, s47
    a.vread      v26, a9, s47
    v.extract    s40, v35, #10
    vf.mul       v27, v26, v21
    v.splat      v21, s40
    vf.mul       v26, v27, v25
    s.movz       s40, #11
    vf.add       v27, v24, v26
    a.vwrite     a1, s47, v27
    a.vread      v24, a1, s43
    a.vread      v26, a9, s43
    v.extract    s47, v35, #11
    vf.mul       v27, v26, v4
    v.splat      v4, s47
    vf.mul       v26, v27, v25
    s.movz       s47, #12
    vf.add       v27, v24, v26
    a.vwrite     a1, s43, v27
    a.vread      v24, a1, s42
    a.vread      v26, a9, s42
    v.extract    s43, v35, #12
    vf.mul       v27, v26, v22
    v.splat      v22, s43
    vf.mul       v26, v27, v25
    s.movz       s43, #13
    vf.add       v27, v24, v26
    a.vwrite     a1, s42, v27
    a.vread      v24, a1, s46
    a.vread      v26, a9, s46
    v.extract    s42, v35, #13
    vf.mul       v27, v26, v19
    v.splat      v19, s42
    vf.mul       v26, v27, v25
    s.movz       s42, #14
    vf.add       v27, v24, v26
    a.vwrite     a1, s46, v27
    a.vread      v24, a1, s45
    a.vread      v26, a9, s45
    v.extract    s46, v35, #14
    vf.mul       v27, v26, v20
    v.splat      v20, s46
    vf.mul       v26, v27, v25
    s.movz       s46, #15
    vf.add       v27, v24, v26
    a.vwrite     a1, s45, v27
    a.vread      v24, a1, s48
    a.vread      v26, a9, s48
    v.extract    s45, v35, #15
    vf.mul       v27, v26, v21
    v.splat      v21, s45
    vf.mul       v26, v27, v25
    s.movz       s45, #0
    vf.add       v27, v24, v26
    a.vwrite     a1, s48, v27
    a.vread      v24, a1, s40
    a.vread      v26, a9, s40
    v.extract    s48, v35, #0
    vf.mul       v27, v26, v4
    v.splat      v4, s48
    vf.mul       v26, v27, v25
    s.movz       s48, #1
    vf.add       v27, v24, v26
    a.vwrite     a1, s40, v27
    a.vread      v24, a1, s47
    a.vread      v26, a9, s47
    v.extract    s40, v35, #1
    vf.mul       v27, v26, v22
    v.splat      v22, s40
    vf.mul       v26, v27, v25
    s.movz       s40, #2
    vf.add       v27, v24, v26
    a.vwrite     a1, s47, v27
    a.vread      v24, a1, s43
    a.vread      v26, a9, s43
    v.extract    s47, v35, #2
    vf.mul       v27, v26, v19
    v.splat      v19, s47
    vf.mul       v26, v27, v25
    s.movz       s47, #3
    vf.add       v27, v24, v26
    a.vwrite     a1, s43, v27
    a.vread      v24, a1, s42
    a.vread      v26, a9, s42
    v.extract    s43, v35, #3
    vf.mul       v27, v26, v20
    v.splat      v20, s43
    vf.mul       v26, v27, v25
    s.movz       s43, #4
    vf.add       v27, v24, v26
    a.vwrite     a1, s42, v27
    a.vread      v24, a1, s46
    a.vread      v26, a9, s46
    v.extract    s42, v35, #4
    vf.mul       v27, v26, v21
    v.splat      v21, s42
    vf.mul       v26, v27, v25
    s.movz       s42, #5
    vf.add       v25, v24, v26
    a.vwrite     a1, s46, v25
    a.vread      v24, a2, s45
    a.vread      v25, a10, s45
    v.extract    s46, v35, #5
    vf.mul       v26, v25, v4
    v.splat      v4, s46
    vf.mul       v25, v26, v34
    s.movz       s46, #6
    vf.add       v26, v24, v25
    a.vwrite     a2, s45, v26
    a.vread      v24, a2, s48
    a.vread      v25, a10, s48
    v.extract    s45, v35, #6
    vf.mul       v26, v25, v22
    v.splat      v22, s45
    vf.mul       v25, v26, v34
    s.movz       s45, #7
    vf.add       v26, v24, v25
    a.vwrite     a2, s48, v26
    a.vread      v24, a2, s40
    a.vread      v25, a10, s40
    v.extract    s48, v35, #7
    vf.mul       v26, v25, v19
    v.splat      v19, s48
    vf.mul       v25, v26, v34
    s.movz       s48, #8
    vf.add       v26, v24, v25
    a.vwrite     a2, s40, v26
    a.vread      v24, a2, s47
    a.vread      v25, a10, s47
    v.extract    s40, v35, #8
    vf.mul       v26, v25, v20
    v.splat      v20, s40
    vf.mul       v25, v26, v34
    s.movz       s40, #9
    vf.add       v26, v24, v25
    a.vwrite     a2, s47, v26
    a.vread      v24, a2, s43
    a.vread      v25, a10, s43
    v.extract    s47, v35, #9
    vf.mul       v26, v25, v21
    v.splat      v21, s47
    vf.mul       v25, v26, v34
    s.movz       s47, #10
    vf.add       v26, v24, v25
    a.vwrite     a2, s43, v26
    a.vread      v24, a2, s42
    a.vread      v25, a10, s42
    v.extract    s43, v35, #10
    vf.mul       v26, v25, v4
    v.splat      v4, s43
    vf.mul       v25, v26, v34
    s.movz       s43, #11
    vf.add       v26, v24, v25
    a.vwrite     a2, s42, v26
    a.vread      v24, a2, s46
    a.vread      v25, a10, s46
    v.extract    s42, v35, #11
    vf.mul       v26, v25, v22
    v.splat      v22, s42
    vf.mul       v25, v26, v34
    s.movz       s42, #12
    vf.add       v26, v24, v25
    a.vwrite     a2, s46, v26
    a.vread      v24, a2, s45
    a.vread      v25, a10, s45
    v.extract    s46, v35, #12
    vf.mul       v26, v25, v19
    v.splat      v19, s46
    vf.mul       v25, v26, v34
    s.movz       s46, #13
    vf.add       v26, v24, v25
    a.vwrite     a2, s45, v26
    a.vread      v24, a2, s48
    a.vread      v25, a10, s48
    v.extract    s45, v35, #13
    vf.mul       v26, v25, v20
    v.splat      v20, s45
    vf.mul       v25, v26, v34
    s.movz       s45, #14
    vf.add       v26, v24, v25
    a.vwrite     a2, s48, v26
    a.vread      v24, a2, s40
    a.vread      v25, a10, s40
    v.extract    s48, v35, #14
    vf.mul       v26, v25, v21
    v.splat      v21, s48
    vf.mul       v25, v26, v34
    s.movz       s48, #15
    vf.add       v26, v24, v25
    a.vwrite     a2, s40, v26
    a.vread      v24, a2, s47
    a.vread      v25, a10, s47
    v.extract    s40, v35, #15
    vf.mul       v26, v25, v4
    v.splat      v4, s40
    vf.mul       v25, v26, v34
    s.movz       s40, #0
    vf.add       v26, v24, v25
    a.vwrite     a2, s47, v26
    a.vread      v24, a2, s43
    a.vread      v25, a10, s43
    v.extract    s47, v35, #0
    vf.mul       v26, v25, v22
    v.splat      v22, s47
    vf.mul       v25, v26, v34
    s.movz       s47, #1
    vf.add       v26, v24, v25
    a.vwrite     a2, s43, v26
    a.vread      v24, a2, s42
    a.vread      v25, a10, s42
    v.extract    s43, v35, #1
    vf.mul       v26, v25, v19
    v.splat      v19, s43
    vf.mul       v25, v26, v34
    s.movz       s43, #2
    vf.add       v26, v24, v25
    a.vwrite     a2, s42, v26
    a.vread      v24, a2, s46
    a.vread      v25, a10, s46
    v.extract    s42, v35, #2
    vf.mul       v26, v25, v20
    v.splat      v20, s42
    vf.mul       v25, v26, v34
    s.movz       s42, #3
    vf.add       v26, v24, v25
    a.vwrite     a2, s46, v26
    a.vread      v24, a2, s45
    a.vread      v25, a10, s45
    v.extract    s46, v35, #3
    vf.mul       v26, v25, v21
    v.splat      v21, s46
    vf.mul       v25, v26, v34
    s.movz       s46, #4
    vf.add       v26, v24, v25
    a.vwrite     a2, s45, v26
    a.vread      v24, a2, s48
    a.vread      v25, a10, s48
    v.extract    s45, v35, #4
    vf.mul       v26, v25, v4
    v.splat      v4, s45
    vf.mul       v25, v26, v34
    s.movz       s45, #5
    vf.add       v26, v24, v25
    a.vwrite     a2, s48, v26
    a.vread      v24, a3, s40
    a.vread      v25, a11, s40
    v.extract    s48, v35, #5
    vf.mul       v26, v25, v22
    v.splat      v22, s48
    vf.mul       v25, v26, v23
    s.movz       s48, #6
    vf.add       v26, v24, v25
    a.vwrite     a3, s40, v26
    a.vread      v24, a3, s47
    a.vread      v25, a11, s47
    v.extract    s40, v35, #6
    vf.mul       v26, v25, v19
    v.splat      v19, s40
    vf.mul       v25, v26, v23
    s.movz       s40, #7
    vf.add       v26, v24, v25
    a.vwrite     a3, s47, v26
    a.vread      v24, a3, s43
    a.vread      v25, a11, s43
    v.extract    s47, v35, #7
    vf.mul       v26, v25, v20
    v.splat      v20, s47
    vf.mul       v25, v26, v23
    s.movz       s47, #8
    vf.add       v26, v24, v25
    a.vwrite     a3, s43, v26
    a.vread      v24, a3, s42
    a.vread      v25, a11, s42
    v.extract    s43, v35, #8
    vf.mul       v26, v25, v21
    v.splat      v21, s43
    vf.mul       v25, v26, v23
    s.movz       s43, #9
    vf.add       v26, v24, v25
    a.vwrite     a3, s42, v26
    a.vread      v24, a3, s46
    a.vread      v25, a11, s46
    v.extract    s42, v35, #9
    vf.mul       v26, v25, v4
    v.splat      v4, s42
    vf.mul       v25, v26, v23
    s.movz       s42, #10
    vf.add       v26, v24, v25
    a.vwrite     a3, s46, v26
    a.vread      v24, a3, s45
    a.vread      v25, a11, s45
    v.extract    s46, v35, #10
    vf.mul       v26, v25, v22
    v.splat      v22, s46
    vf.mul       v25, v26, v23
    s.movz       s46, #11
    vf.add       v26, v24, v25
    a.vwrite     a3, s45, v26
    a.vread      v24, a3, s48
    a.vread      v25, a11, s48
    v.extract    s45, v35, #11
    vf.mul       v26, v25, v19
    v.splat      v19, s45
    vf.mul       v25, v26, v23
    s.movz       s45, #12
    vf.add       v26, v24, v25
    a.vwrite     a3, s48, v26
    a.vread      v24, a3, s40
    a.vread      v25, a11, s40
    v.extract    s48, v35, #12
    vf.mul       v26, v25, v20
    v.splat      v20, s48
    vf.mul       v25, v26, v23
    s.movz       s48, #13
    vf.add       v26, v24, v25
    a.vwrite     a3, s40, v26
    a.vread      v24, a3, s47
    a.vread      v25, a11, s47
    v.extract    s40, v35, #13
    vf.mul       v26, v25, v21
    v.splat      v21, s40
    vf.mul       v25, v26, v23
    s.movz       s40, #14
    vf.add       v26, v24, v25
    a.vwrite     a3, s47, v26
    a.vread      v24, a3, s43
    a.vread      v25, a11, s43
    v.extract    s47, v35, #14
    vf.mul       v26, v25, v4
    v.splat      v4, s47
    vf.mul       v25, v26, v23
    s.movz       s47, #15
    vf.add       v26, v24, v25
    a.vwrite     a3, s43, v26
    a.vread      v24, a3, s42
    a.vread      v25, a11, s42
    v.extract    s43, v35, #15
    vf.mul       v26, v25, v22
    v.splat      v22, s43
    vf.mul       v25, v26, v23
    s.movz       s43, #0
    vf.add       v26, v24, v25
    a.vwrite     a3, s42, v26
    a.vread      v24, a3, s46
    a.vread      v25, a11, s46
    v.extract    s42, v35, #0
    vf.mul       v26, v25, v19
    v.splat      v19, s42
    vf.mul       v25, v26, v23
    s.movz       s42, #1
    vf.add       v26, v24, v25
    a.vwrite     a3, s46, v26
    a.vread      v24, a3, s45
    a.vread      v25, a11, s45
    v.extract    s46, v35, #1
    vf.mul       v26, v25, v20
    v.splat      v20, s46
    vf.mul       v25, v26, v23
    s.movz       s46, #2
    vf.add       v26, v24, v25
    a.vwrite     a3, s45, v26
    a.vread      v24, a3, s48
    a.vread      v25, a11, s48
    v.extract    s45, v35, #2
    vf.mul       v26, v25, v21
    v.splat      v21, s45
    vf.mul       v25, v26, v23
    s.movz       s45, #3
    vf.add       v26, v24, v25
    a.vwrite     a3, s48, v26
    a.vread      v24, a3, s40
    a.vread      v25, a11, s40
    v.extract    s48, v35, #3
    vf.mul       v26, v25, v4
    v.splat      v4, s48
    vf.mul       v25, v26, v23
    s.movz       s48, #4
    vf.add       v26, v24, v25
    a.vwrite     a3, s40, v26
    a.vread      v24, a3, s47
    a.vread      v25, a11, s47
    v.extract    s40, v35, #4
    vf.mul       v26, v25, v22
    v.splat      v22, s40
    vf.mul       v25, v26, v23
    s.movz       s40, #5
    vf.add       v23, v24, v25
    a.vwrite     a3, s47, v23
    a.vread      v23, a4, s43
    a.vread      v24, a12, s43
    v.extract    s47, v35, #5
    vf.mul       v25, v24, v19
    v.splat      v19, s47
    vf.mul       v24, v25, v36
    s.movz       s47, #6
    vf.add       v25, v23, v24
    a.vwrite     a4, s43, v25
    a.vread      v23, a4, s42
    a.vread      v24, a12, s42
    v.extract    s43, v35, #6
    vf.mul       v25, v24, v20
    v.splat      v20, s43
    vf.mul       v24, v25, v36
    s.movz       s43, #7
    vf.add       v25, v23, v24
    a.vwrite     a4, s42, v25
    a.vread      v23, a4, s46
    a.vread      v24, a12, s46
    v.extract    s42, v35, #7
    vf.mul       v25, v24, v21
    v.splat      v21, s42
    vf.mul       v24, v25, v36
    s.movz       s42, #8
    vf.add       v25, v23, v24
    a.vwrite     a4, s46, v25
    a.vread      v23, a4, s45
    a.vread      v24, a12, s45
    v.extract    s46, v35, #8
    vf.mul       v25, v24, v4
    v.splat      v4, s46
    vf.mul       v24, v25, v36
    s.movz       s46, #9
    vf.add       v25, v23, v24
    a.vwrite     a4, s45, v25
    a.vread      v23, a4, s48
    a.vread      v24, a12, s48
    v.extract    s45, v35, #9
    vf.mul       v25, v24, v22
    v.splat      v22, s45
    vf.mul       v24, v25, v36
    s.movz       s45, #10
    vf.add       v25, v23, v24
    a.vwrite     a4, s48, v25
    a.vread      v23, a4, s40
    a.vread      v24, a12, s40
    v.extract    s48, v35, #10
    vf.mul       v25, v24, v19
    v.splat      v19, s48
    vf.mul       v24, v25, v36
    s.movz       s48, #11
    vf.add       v25, v23, v24
    a.vwrite     a4, s40, v25
    a.vread      v23, a4, s47
    a.vread      v24, a12, s47
    v.extract    s40, v35, #11
    vf.mul       v25, v24, v20
    v.splat      v20, s40
    vf.mul       v24, v25, v36
    s.movz       s40, #12
    vf.add       v25, v23, v24
    a.vwrite     a4, s47, v25
    a.vread      v23, a4, s43
    a.vread      v24, a12, s43
    v.extract    s47, v35, #12
    vf.mul       v25, v24, v21
    v.splat      v21, s47
    vf.mul       v24, v25, v36
    s.movz       s47, #13
    vf.add       v25, v23, v24
    a.vwrite     a4, s43, v25
    a.vread      v23, a4, s42
    a.vread      v24, a12, s42
    v.extract    s43, v35, #13
    vf.mul       v25, v24, v4
    v.splat      v4, s43
    vf.mul       v24, v25, v36
    s.movz       s43, #14
    vf.add       v25, v23, v24
    a.vwrite     a4, s42, v25
    a.vread      v23, a4, s46
    a.vread      v24, a12, s46
    v.extract    s42, v35, #14
    vf.mul       v25, v24, v22
    v.splat      v22, s42
    vf.mul       v24, v25, v36
    s.movz       s42, #15
    vf.add       v25, v23, v24
    a.vwrite     a4, s46, v25
    a.vread      v23, a4, s45
    a.vread      v24, a12, s45
    v.extract    s46, v35, #15
    vf.mul       v25, v24, v19
    v.splat      v19, s46
    vf.mul       v24, v25, v36
    s.movz       s46, #0
    vf.add       v25, v23, v24
    a.vwrite     a4, s45, v25
    a.vread      v23, a4, s48
    a.vread      v24, a12, s48
    v.extract    s45, v35, #0
    vf.mul       v25, v24, v20
    v.splat      v20, s45
    vf.mul       v24, v25, v36
    s.movz       s45, #1
    vf.add       v25, v23, v24
    a.vwrite     a4, s48, v25
    a.vread      v23, a4, s40
    a.vread      v24, a12, s40
    v.extract    s48, v35, #1
    vf.mul       v25, v24, v21
    v.splat      v21, s48
    vf.mul       v24, v25, v36
    s.movz       s48, #2
    vf.add       v25, v23, v24
    a.vwrite     a4, s40, v25
    a.vread      v23, a4, s47
    a.vread      v24, a12, s47
    v.extract    s40, v35, #2
    vf.mul       v25, v24, v4
    v.splat      v4, s40
    vf.mul       v24, v25, v36
    s.movz       s40, #3
    vf.add       v25, v23, v24
    a.vwrite     a4, s47, v25
    a.vread      v23, a4, s43
    a.vread      v24, a12, s43
    v.extract    s47, v35, #3
    vf.mul       v25, v24, v22
    v.splat      v22, s47
    vf.mul       v24, v25, v36
    s.movz       s47, #4
    vf.add       v25, v23, v24
    a.vwrite     a4, s43, v25
    a.vread      v23, a4, s42
    a.vread      v24, a12, s42
    v.extract    s43, v35, #4
    vf.mul       v25, v24, v19
    v.splat      v19, s43
    vf.mul       v24, v25, v36
    s.movz       s43, #5
    vf.add       v25, v23, v24
    a.vwrite     a4, s42, v25
    a.vread      v23, a5, s46
    a.vread      v24, a13, s46
    v.extract    s42, v35, #5
    vf.mul       v25, v24, v20
    v.splat      v20, s42
    vf.mul       v24, v25, v2
    s.movz       s42, #6
    vf.add       v25, v23, v24
    a.vwrite     a5, s46, v25
    a.vread      v23, a5, s45
    a.vread      v24, a13, s45
    v.extract    s46, v35, #6
    vf.mul       v25, v24, v21
    v.splat      v21, s46
    vf.mul       v24, v25, v2
    s.movz       s46, #7
    vf.add       v25, v23, v24
    a.vwrite     a5, s45, v25
    a.vread      v23, a5, s48
    a.vread      v24, a13, s48
    v.extract    s45, v35, #7
    vf.mul       v25, v24, v4
    v.splat      v4, s45
    vf.mul       v24, v25, v2
    s.movz       s45, #8
    vf.add       v25, v23, v24
    a.vwrite     a5, s48, v25
    a.vread      v23, a5, s40
    a.vread      v24, a13, s40
    v.extract    s48, v35, #8
    vf.mul       v25, v24, v22
    v.splat      v22, s48
    vf.mul       v24, v25, v2
    s.movz       s48, #9
    vf.add       v25, v23, v24
    a.vwrite     a5, s40, v25
    a.vread      v23, a5, s47
    a.vread      v24, a13, s47
    v.extract    s40, v35, #9
    vf.mul       v25, v24, v19
    v.splat      v19, s40
    vf.mul       v24, v25, v2
    s.movz       s40, #10
    vf.add       v25, v23, v24
    a.vwrite     a5, s47, v25
    a.vread      v23, a5, s43
    a.vread      v24, a13, s43
    v.extract    s47, v35, #10
    vf.mul       v25, v24, v20
    v.splat      v20, s47
    vf.mul       v24, v25, v2
    s.movz       s47, #11
    vf.add       v25, v23, v24
    a.vwrite     a5, s43, v25
    a.vread      v23, a5, s42
    a.vread      v24, a13, s42
    v.extract    s43, v35, #11
    vf.mul       v25, v24, v21
    v.splat      v21, s43
    vf.mul       v24, v25, v2
    s.movz       s43, #12
    vf.add       v25, v23, v24
    a.vwrite     a5, s42, v25
    a.vread      v23, a5, s46
    a.vread      v24, a13, s46
    v.extract    s42, v35, #12
    vf.mul       v25, v24, v4
    v.splat      v4, s42
    vf.mul       v24, v25, v2
    s.movz       s42, #13
    vf.add       v25, v23, v24
    a.vwrite     a5, s46, v25
    a.vread      v23, a5, s45
    a.vread      v24, a13, s45
    v.extract    s46, v35, #13
    vf.mul       v25, v24, v22
    v.splat      v22, s46
    vf.mul       v24, v25, v2
    s.movz       s46, #14
    vf.add       v25, v23, v24
    a.vwrite     a5, s45, v25
    a.vread      v23, a5, s48
    a.vread      v24, a13, s48
    v.extract    s45, v35, #14
    vf.mul       v25, v24, v19
    v.splat      v19, s45
    vf.mul       v24, v25, v2
    s.movz       s45, #15
    vf.add       v25, v23, v24
    a.vwrite     a5, s48, v25
    a.vread      v23, a5, s40
    a.vread      v24, a13, s40
    v.extract    s48, v35, #15
    vf.mul       v25, v24, v20
    v.splat      v20, s48
    vf.mul       v24, v25, v2
    s.movz       s48, #0
    vf.add       v25, v23, v24
    a.vwrite     a5, s40, v25
    a.vread      v23, a5, s47
    a.vread      v24, a13, s47
    v.extract    s40, v35, #0
    vf.mul       v25, v24, v21
    v.splat      v21, s40
    vf.mul       v24, v25, v2
    s.movz       s40, #1
    vf.add       v25, v23, v24
    a.vwrite     a5, s47, v25
    a.vread      v23, a5, s43
    a.vread      v24, a13, s43
    v.extract    s47, v35, #1
    vf.mul       v25, v24, v4
    v.splat      v4, s47
    vf.mul       v24, v25, v2
    s.movz       s47, #2
    vf.add       v25, v23, v24
    a.vwrite     a5, s43, v25
    a.vread      v23, a5, s42
    a.vread      v24, a13, s42
    v.extract    s43, v35, #2
    vf.mul       v25, v24, v22
    v.splat      v22, s43
    vf.mul       v24, v25, v2
    s.movz       s43, #3
    vf.add       v25, v23, v24
    a.vwrite     a5, s42, v25
    a.vread      v23, a5, s46
    a.vread      v24, a13, s46
    v.extract    s42, v35, #3
    vf.mul       v25, v24, v19
    v.splat      v19, s42
    vf.mul       v24, v25, v2
    s.movz       s42, #4
    vf.add       v25, v23, v24
    a.vwrite     a5, s46, v25
    a.vread      v23, a5, s45
    a.vread      v24, a13, s45
    v.extract    s46, v35, #4
    vf.mul       v25, v24, v20
    v.splat      v20, s46
    vf.mul       v24, v25, v2
    s.movz       s46, #5
    vf.add       v2, v23, v24
    a.vwrite     a5, s45, v2
    a.vread      v2, a6, s48
    a.vread      v23, a14, s48
    v.extract    s45, v35, #5
    vf.mul       v24, v23, v21
    v.splat      v21, s45
    vf.mul       v23, v24, v38
    s.movz       s45, #6
    vf.add       v24, v2, v23
    a.vwrite     a6, s48, v24
    a.vread      v2, a6, s40
    a.vread      v23, a14, s40
    v.extract    s48, v35, #6
    vf.mul       v24, v23, v4
    v.splat      v4, s48
    vf.mul       v23, v24, v38
    s.movz       s48, #7
    vf.add       v24, v2, v23
    a.vwrite     a6, s40, v24
    a.vread      v2, a6, s47
    a.vread      v23, a14, s47
    v.extract    s40, v35, #7
    vf.mul       v24, v23, v22
    v.splat      v22, s40
    vf.mul       v23, v24, v38
    s.movz       s40, #8
    vf.add       v24, v2, v23
    a.vwrite     a6, s47, v24
    a.vread      v2, a6, s43
    a.vread      v23, a14, s43
    v.extract    s47, v35, #8
    vf.mul       v24, v23, v19
    v.splat      v19, s47
    vf.mul       v23, v24, v38
    s.movz       s47, #9
    vf.add       v24, v2, v23
    a.vwrite     a6, s43, v24
    a.vread      v2, a6, s42
    a.vread      v23, a14, s42
    v.extract    s43, v35, #9
    vf.mul       v24, v23, v20
    v.splat      v20, s43
    vf.mul       v23, v24, v38
    s.movz       s43, #10
    vf.add       v24, v2, v23
    a.vwrite     a6, s42, v24
    a.vread      v2, a6, s46
    a.vread      v23, a14, s46
    v.extract    s42, v35, #10
    vf.mul       v24, v23, v21
    v.splat      v21, s42
    vf.mul       v23, v24, v38
    s.movz       s42, #11
    vf.add       v24, v2, v23
    a.vwrite     a6, s46, v24
    a.vread      v2, a6, s45
    a.vread      v23, a14, s45
    v.extract    s46, v35, #11
    vf.mul       v24, v23, v4
    v.splat      v4, s46
    vf.mul       v23, v24, v38
    s.movz       s46, #12
    vf.add       v24, v2, v23
    a.vwrite     a6, s45, v24
    a.vread      v2, a6, s48
    a.vread      v23, a14, s48
    v.extract    s45, v35, #12
    vf.mul       v24, v23, v22
    v.splat      v22, s45
    vf.mul       v23, v24, v38
    s.movz       s45, #13
    vf.add       v24, v2, v23
    a.vwrite     a6, s48, v24
    a.vread      v2, a6, s40
    a.vread      v23, a14, s40
    v.extract    s48, v35, #13
    vf.mul       v24, v23, v19
    v.splat      v19, s48
    vf.mul       v23, v24, v38
    s.movz       s48, #14
    vf.add       v24, v2, v23
    a.vwrite     a6, s40, v24
    a.vread      v2, a6, s47
    a.vread      v23, a14, s47
    v.extract    s40, v35, #14
    vf.mul       v24, v23, v20
    v.splat      v20, s40
    vf.mul       v23, v24, v38
    s.movz       s40, #15
    vf.add       v24, v2, v23
    a.vwrite     a6, s47, v24
    a.vread      v2, a6, s43
    a.vread      v23, a14, s43
    v.extract    s47, v35, #15
    vf.mul       v24, v23, v21
    v.splat      v21, s47
    vf.mul       v23, v24, v38
    s.movz       s47, #0
    vf.add       v24, v2, v23
    a.vwrite     a6, s43, v24
    a.vread      v2, a6, s42
    a.vread      v23, a14, s42
    v.extract    s43, v35, #0
    vf.mul       v24, v23, v4
    v.splat      v4, s43
    vf.mul       v23, v24, v38
    s.movz       s43, #1
    vf.add       v24, v2, v23
    a.vwrite     a6, s42, v24
    a.vread      v2, a6, s46
    a.vread      v23, a14, s46
    v.extract    s42, v35, #1
    vf.mul       v24, v23, v22
    v.splat      v22, s42
    vf.mul       v23, v24, v38
    s.movz       s42, #2
    vf.add       v24, v2, v23
    a.vwrite     a6, s46, v24
    a.vread      v2, a6, s45
    a.vread      v23, a14, s45
    v.extract    s46, v35, #2
    vf.mul       v24, v23, v19
    v.splat      v19, s46
    vf.mul       v23, v24, v38
    s.movz       s46, #3
    vf.add       v24, v2, v23
    a.vwrite     a6, s45, v24
    a.vread      v2, a6, s48
    a.vread      v23, a14, s48
    v.extract    s45, v35, #3
    vf.mul       v24, v23, v20
    v.splat      v20, s45
    vf.mul       v23, v24, v38
    s.movz       s45, #4
    vf.add       v24, v2, v23
    a.vwrite     a6, s48, v24
    a.vread      v2, a6, s40
    a.vread      v23, a14, s40
    v.extract    s48, v35, #4
    vf.mul       v24, v23, v21
    v.splat      v21, s48
    vf.mul       v23, v24, v38
    s.movz       s48, #5
    vf.add       v24, v2, v23
    a.vwrite     a6, s40, v24
    a.vread      v2, a7, s47
    a.vread      v23, a15, s47
    v.extract    s40, v35, #5
    vf.mul       v24, v23, v4
    v.splat      v4, s40
    vf.mul       v23, v24, v39
    s.movz       s40, #6
    vf.add       v24, v2, v23
    a.vwrite     a7, s47, v24
    a.vread      v2, a7, s43
    a.vread      v23, a15, s43
    v.extract    s47, v35, #6
    vf.mul       v24, v23, v22
    v.splat      v22, s47
    vf.mul       v23, v24, v39
    s.movz       s47, #7
    vf.add       v24, v2, v23
    a.vwrite     a7, s43, v24
    a.vread      v2, a7, s42
    a.vread      v23, a15, s42
    v.extract    s43, v35, #7
    vf.mul       v24, v23, v19
    v.splat      v19, s43
    vf.mul       v23, v24, v39
    s.movz       s43, #8
    vf.add       v24, v2, v23
    a.vwrite     a7, s42, v24
    a.vread      v2, a7, s46
    a.vread      v23, a15, s46
    v.extract    s42, v35, #8
    vf.mul       v24, v23, v20
    v.splat      v20, s42
    vf.mul       v23, v24, v39
    s.movz       s42, #9
    vf.add       v24, v2, v23
    a.vwrite     a7, s46, v24
    a.vread      v2, a7, s45
    a.vread      v23, a15, s45
    v.extract    s46, v35, #9
    vf.mul       v24, v23, v21
    v.splat      v21, s46
    vf.mul       v23, v24, v39
    s.movz       s46, #10
    vf.add       v24, v2, v23
    a.vwrite     a7, s45, v24
    a.vread      v2, a7, s48
    a.vread      v23, a15, s48
    v.extract    s45, v35, #10
    vf.mul       v24, v23, v4
    v.splat      v4, s45
    vf.mul       v23, v24, v39
    s.movz       s45, #11
    vf.add       v24, v2, v23
    a.vwrite     a7, s48, v24
    a.vread      v2, a7, s40
    a.vread      v23, a15, s40
    v.extract    s48, v35, #11
    vf.mul       v24, v23, v22
    v.splat      v22, s48
    vf.mul       v23, v24, v39
    s.movz       s48, #12
    vf.add       v24, v2, v23
    a.vwrite     a7, s40, v24
    a.vread      v2, a7, s47
    a.vread      v23, a15, s47
    v.extract    s40, v35, #12
    vf.mul       v24, v23, v19
    v.splat      v19, s40
    vf.mul       v23, v24, v39
    s.movz       s40, #13
    vf.add       v24, v2, v23
    a.vwrite     a7, s47, v24
    a.vread      v2, a7, s43
    a.vread      v23, a15, s43
    v.extract    s47, v35, #13
    vf.mul       v24, v23, v20
    v.splat      v20, s47
    vf.mul       v23, v24, v39
    s.movz       s47, #14
    vf.add       v24, v2, v23
    a.vwrite     a7, s43, v24
    a.vread      v2, a7, s42
    a.vread      v23, a15, s42
    v.extract    s43, v35, #14
    vf.mul       v24, v23, v21
    v.splat      v21, s43
    vf.mul       v23, v24, v39
    s.movz       s43, #15
    vf.add       v24, v2, v23
    a.vwrite     a7, s42, v24
    a.vread      v2, a7, s46
    a.vread      v23, a15, s46
    v.extract    s42, v35, #15
    vf.mul       v24, v23, v4
    v.splat      v4, s42
    vf.mul       v23, v24, v39
    s.addi       s42, s25, #128
    vf.add       v24, v2, v23
    s.addi       s49, s42, #0
    a.vwrite     a7, s46, v24
    a.vread      v2, a7, s45
    a.vread      v23, a15, s45
    s.addi       s42, s26, #128
    vf.mul       v24, v23, v22
    s.addi       s46, s42, #0
    vf.mul       v22, v24, v39
    s.add        s42, s24, s23
    vf.add       v23, v2, v22
    a.vwrite     a7, s45, v23
    a.vread      v2, a7, s48
    a.vread      v22, a15, s48
    s.addi       s45, s27, #4                    // &ptr_carry_18[1] (a constant offset, x4)
    vf.mul       v23, v22, v19
    s.addi       s51, s45, #0
    vf.mul       v19, v23, v39
    vf.add       v22, v2, v19
    a.vwrite     a7, s48, v22
    a.vread      v2, a7, s40
    a.vread      v19, a15, s40
    s.movz       s45, #1
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v39
    vf.add       v20, v2, v19
    a.vwrite     a7, s40, v20
    a.vread      v2, a7, s47
    a.vread      v19, a15, s47
    vf.mul       v20, v19, v21
    vf.mul       v19, v20, v39
    vf.add       v20, v2, v19
    a.vwrite     a7, s47, v20
    a.vread      v2, a7, s43
    a.vread      v19, a15, s43
    vf.mul       v20, v19, v4
    vf.mul       v4, v20, v39
    vf.add       v19, v2, v4
    a.vwrite     a7, s43, v19
    s.mov        s25, s49
    s.mov        s26, s46
    s.mov        s27, s51
    s.mov        s24, s42
    br.nz        s45, for_26
endfor_27:
    s.mul        s2, s1, s22
    s.movz       s5, #0
    s.muli       s6, s4, #2
    s.add        s7, s5, s4                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    s.muli       s8, s2, #2
    v.splat      v1, s7
    a.vread      v2, a0, s5
    s.muli       s2, s22, #2
    s.add        s7, s5, s1                      // the tile origin
    s.add        s1, s5, s14                     // the tile origin
    s.add        s9, s5, s3                      // the tile origin
    v.splat      v3, s7
    v.splat      v4, s1
    v.add        v5, v0, v1
    v.splat      v1, s9
    vf.cvt.f32.f16 v6, v2
    s.add        s1, s8, s6
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.muli       s5, s2, #1
    s.add        s9, s11, s1
    p.and        p3, p1, p2
    s.movz       s1, #1
    @p3 v.st.h       [s9, #0], v6
    a.vread      v1, a0, s1
    s.addi       s1, s7, #1
    s.add        s9, s5, s8
    v.splat      v2, s1
    vf.cvt.f32.f16 v3, v1
    s.add        s1, s9, s6
    v.cmp.lt     p1, v2, v4
    s.muli       s5, s2, #2
    s.add        s9, s11, s1
    p.and        p3, p1, p2
    s.movz       s1, #2
    s.addi       s10, s4, #16
    s.add        s12, s5, s8
    @p3 v.st.h       [s9, #0], v3
    a.vread      v1, a0, s1
    s.add        s1, s12, s6
    s.addi       s5, s4, #32
    s.addi       s9, s7, #2
    vf.cvt.f32.f16 v2, v1
    s.add        s12, s11, s1
    s.addi       s1, s4, #48
    v.splat      v1, s9
    s.addi       s9, s4, #64
    s.addi       s14, s4, #80
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s15, s4, #96
    @p3 v.st.h       [s12, #0], v2
    s.addi       s12, s4, #112
    s.muli       s4, s2, #3
    s.movz       s16, #3
    s.addi       s17, s7, #3
    a.vread      v1, a0, s16
    v.splat      v2, s17
    s.add        s16, s4, s8
    vf.cvt.f32.f16 v3, v1
    s.add        s4, s16, s6
    v.cmp.lt     p1, v2, v4
    s.muli       s16, s2, #4
    s.add        s17, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #4
    @p3 v.st.h       [s17, #0], v3
    a.vread      v1, a0, s4
    s.addi       s4, s7, #4
    s.add        s17, s16, s8
    v.splat      v2, s4
    vf.cvt.f32.f16 v3, v1
    s.add        s4, s17, s6
    v.cmp.lt     p1, v2, v4
    s.muli       s16, s2, #5
    s.add        s17, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #5
    s.addi       s18, s7, #5
    s.add        s19, s16, s8
    @p3 v.st.h       [s17, #0], v3
    a.vread      v1, a0, s4
    v.splat      v2, s18
    s.add        s4, s19, s6
    vf.cvt.f32.f16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s16, s2, #6
    s.add        s17, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #6
    s.addi       s18, s7, #6
    s.add        s19, s16, s8
    v.splat      v1, s18
    s.add        s16, s19, s6
    @p3 v.st.h       [s17, #0], v3
    a.vread      v2, a0, s4
    v.cmp.lt     p1, v1, v4
    s.muli       s4, s2, #7
    vf.cvt.f32.f16 v1, v2
    s.add        s17, s11, s16
    p.and        p3, p1, p2
    s.movz       s16, #7
    s.addi       s18, s7, #7
    s.add        s19, s4, s8
    v.splat      v2, s18
    s.add        s4, s19, s6
    s.muli       s18, s2, #8
    v.cmp.lt     p1, v2, v4
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a0, s16
    s.add        s16, s11, s4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.movz       s4, #8
    s.addi       s17, s7, #8
    s.add        s19, s18, s8
    v.splat      v1, s17
    s.add        s17, s19, s6
    s.muli       s18, s2, #9
    v.cmp.lt     p1, v1, v4
    s.add        s19, s11, s17
    p.and        p4, p1, p2
    @p3 v.st.h       [s16, #0], v2
    a.vread      v1, a0, s4
    s.movz       s4, #9
    s.addi       s16, s7, #9
    vf.cvt.f32.f16 v2, v1
    s.add        s17, s18, s8
    v.splat      v1, s16
    s.add        s16, s17, s6
    s.muli       s17, s2, #10
    v.cmp.lt     p1, v1, v4
    s.add        s18, s11, s16
    p.and        p3, p1, p2
    s.movz       s16, #10
    s.addi       s20, s7, #10
    @p4 v.st.h       [s19, #0], v2
    a.vread      v1, a0, s4
    s.add        s4, s17, s8
    v.splat      v2, s20
    vf.cvt.f32.f16 v3, v1
    s.add        s17, s4, s6
    v.cmp.lt     p1, v2, v4
    s.muli       s4, s2, #11
    s.add        s19, s11, s17
    p.and        p4, p1, p2
    s.movz       s17, #11
    s.addi       s20, s7, #11
    s.add        s21, s4, s8
    v.splat      v1, s20
    @p3 v.st.h       [s18, #0], v3
    a.vread      v2, a0, s16
    s.add        s4, s21, s6
    v.cmp.lt     p1, v1, v4
    vf.cvt.f32.f16 v1, v2
    s.muli       s16, s2, #12
    s.add        s18, s11, s4
    p.and        p3, p1, p2
    s.movz       s4, #12
    s.addi       s20, s7, #12
    s.add        s21, s16, s8
    v.splat      v2, s20
    s.add        s16, s21, s6
    s.muli       s20, s2, #13
    @p4 v.st.h       [s19, #0], v1
    a.vread      v1, a0, s17
    v.cmp.lt     p1, v2, v4
    s.add        s17, s11, s16
    vf.cvt.f32.f16 v2, v1
    p.and        p4, p1, p2
    s.movz       s16, #13
    s.addi       s19, s7, #13
    s.add        s21, s20, s8
    v.splat      v1, s19
    s.add        s19, s21, s6
    s.muli       s20, s2, #14
    s.add        s21, s11, s19
    s.movz       s19, #14
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a0, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.addi       s4, s7, #14
    s.add        s18, s20, s8
    v.splat      v2, s4
    s.add        s4, s18, s6
    s.muli       s18, s2, #15
    s.add        s20, s11, s4
    s.movz       s4, #15
    s.addi       s22, s7, #15
    v.splat      v3, s7
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a0, s16
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.add        s16, s18, s8
    v.splat      v1, s22
    s.movz       s17, #0
    s.add        s18, s16, s6
    s.add        s6, s17, s10                    // the tile origin
    s.add        s16, s11, s18
    s.muli       s18, s10, #2
    v.splat      v5, s6
    s.add        s6, s17, s3                     // the tile origin
    @p3 v.st.h       [s21, #0], v2
    a.vread      v2, a0, s19
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v2
    v.add        v2, v0, v5
    v.splat      v5, s6
    s.add        s6, s8, s18
    v.cmp.lt     p1, v3, v4
    s.muli       s10, s2, #1
    s.add        s19, s11, s6
    s.movz       s6, #1
    s.addi       s21, s7, #1
    s.muli       s22, s2, #2
    @p4 v.st.h       [s20, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p2, v2, v5
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.add        s4, s10, s8
    v.splat      v1, s21
    s.add        s10, s4, s18
    s.movz       s4, #2
    s.add        s20, s11, s10
    s.addi       s10, s7, #2
    s.add        s21, s22, s8
    v.splat      v3, s10
    s.add        s10, s21, s18
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a1, s17
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.muli       s16, s2, #3
    s.add        s17, s11, s10
    s.movz       s10, #3
    s.addi       s21, s7, #3
    s.muli       s22, s2, #4
    s.add        s23, s16, s8
    v.splat      v2, s21
    s.add        s16, s23, s18
    s.movz       s21, #4
    @p4 v.st.h       [s19, #0], v1
    a.vread      v1, a1, s6
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v1
    s.add        s6, s11, s16
    s.addi       s16, s7, #4
    s.add        s19, s22, s8
    v.splat      v1, s16
    s.add        s16, s19, s18
    s.muli       s19, s2, #5
    s.add        s22, s11, s16
    s.movz       s16, #5
    @p3 v.st.h       [s20, #0], v3
    a.vread      v3, a1, s4
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v3
    s.addi       s4, s7, #5
    s.add        s20, s19, s8
    v.splat      v3, s4
    s.add        s4, s20, s18
    s.muli       s19, s2, #6
    s.add        s20, s11, s4
    s.movz       s4, #6
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a1, s10
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.addi       s10, s7, #6
    s.add        s17, s19, s8
    v.splat      v2, s10
    s.add        s10, s17, s18
    s.muli       s17, s2, #7
    s.add        s19, s11, s10
    s.movz       s10, #7
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a1, s21
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v1
    s.addi       s6, s7, #7
    s.add        s21, s17, s8
    v.splat      v1, s6
    s.add        s6, s21, s18
    s.muli       s17, s2, #8
    s.add        s21, s11, s6
    s.movz       s6, #8
    @p4 v.st.h       [s22, #0], v3
    a.vread      v3, a1, s16
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v3
    s.addi       s16, s7, #8
    s.add        s22, s17, s8
    v.splat      v3, s16
    s.add        s16, s22, s18
    s.muli       s17, s2, #9
    s.add        s22, s11, s16
    s.movz       s16, #9
    @p3 v.st.h       [s20, #0], v2
    a.vread      v2, a1, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.addi       s4, s7, #9
    s.add        s20, s17, s8
    v.splat      v2, s4
    s.add        s4, s20, s18
    s.muli       s17, s2, #10
    s.add        s20, s11, s4
    s.movz       s4, #10
    @p4 v.st.h       [s19, #0], v1
    a.vread      v1, a1, s10
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v1
    s.addi       s10, s7, #10
    s.add        s19, s17, s8
    v.splat      v1, s10
    s.add        s10, s19, s18
    s.muli       s17, s2, #11
    s.add        s19, s11, s10
    s.movz       s10, #11
    @p3 v.st.h       [s21, #0], v3
    a.vread      v3, a1, s6
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v3
    s.addi       s6, s7, #11
    s.add        s21, s17, s8
    v.splat      v3, s6
    s.add        s6, s21, s18
    s.muli       s17, s2, #12
    s.add        s21, s11, s6
    s.movz       s6, #12
    @p4 v.st.h       [s22, #0], v2
    a.vread      v2, a1, s16
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.addi       s16, s7, #12
    s.add        s22, s17, s8
    v.splat      v2, s16
    s.add        s16, s22, s18
    s.muli       s17, s2, #13
    s.add        s22, s11, s16
    s.movz       s16, #13
    @p3 v.st.h       [s20, #0], v1
    a.vread      v1, a1, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v1
    s.addi       s4, s7, #13
    s.add        s20, s17, s8
    v.splat      v1, s4
    s.add        s4, s20, s18
    s.muli       s17, s2, #14
    s.add        s20, s11, s4
    s.movz       s4, #14
    @p4 v.st.h       [s19, #0], v3
    a.vread      v3, a1, s10
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v3
    s.addi       s10, s7, #14
    s.add        s19, s17, s8
    v.splat      v3, s10
    s.add        s10, s19, s18
    s.muli       s17, s2, #15
    s.add        s19, s11, s10
    s.movz       s10, #15
    @p3 v.st.h       [s21, #0], v2
    a.vread      v2, a1, s6
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v2
    s.addi       s6, s7, #15
    s.add        s21, s17, s8
    v.splat      v2, s6
    s.movz       s6, #0
    s.add        s17, s21, s18
    s.add        s18, s6, s5                     // the tile origin
    s.add        s21, s11, s17
    s.muli       s17, s5, #2
    v.splat      v5, s18
    @p4 v.st.h       [s22, #0], v1
    a.vread      v1, a1, s16
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v1
    s.add        s5, s6, s3                      // the tile origin
    v.splat      v1, s7
    v.add        v6, v0, v5
    v.splat      v5, s5
    s.add        s5, s8, s17
    s.muli       s16, s2, #1
    s.add        s18, s11, s5
    s.movz       s5, #1
    @p3 v.st.h       [s20, #0], v3
    a.vread      v3, a1, s4
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v3
    v.cmp.lt     p1, v1, v4
    s.addi       s4, s7, #1
    s.add        s20, s16, s8
    v.splat      v1, s4
    s.add        s4, s20, s17
    s.muli       s16, s2, #2
    s.add        s20, s11, s4
    s.movz       s4, #2
    @p4 v.st.h       [s19, #0], v2
    a.vread      v2, a1, s10
    v.cmp.lt     p2, v6, v5
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s10, s7, #2
    s.add        s19, s16, s8
    v.splat      v2, s10
    s.add        s10, s19, s17
    s.muli       s16, s2, #3
    s.add        s19, s11, s10
    s.movz       s10, #3
    @p3 v.st.h       [s21, #0], v3
    a.vread      v3, a2, s6
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.addi       s6, s7, #3
    s.add        s21, s16, s8
    v.splat      v3, s6
    s.add        s6, s21, s17
    s.muli       s16, s2, #4
    s.add        s21, s11, s6
    s.movz       s6, #4
    s.addi       s22, s7, #4
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.add        s5, s16, s8
    v.splat      v1, s22
    s.add        s16, s5, s17
    s.muli       s5, s2, #5
    s.add        s18, s11, s16
    s.movz       s16, #5
    s.addi       s22, s7, #5
    s.add        s23, s5, s8
    @p3 v.st.h       [s20, #0], v2
    a.vread      v2, a2, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    v.splat      v2, s22
    s.add        s4, s23, s17
    s.muli       s5, s2, #6
    s.add        s20, s11, s4
    s.movz       s4, #6
    s.addi       s22, s7, #6
    s.add        s23, s5, s8
    v.splat      v5, s22
    @p4 v.st.h       [s19, #0], v3
    a.vread      v3, a2, s10
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.add        s5, s23, s17
    s.muli       s10, s2, #7
    s.add        s19, s11, s5
    s.movz       s5, #7
    s.addi       s22, s7, #7
    s.add        s23, s10, s8
    v.splat      v3, s22
    s.add        s10, s23, s17
    @p3 v.st.h       [s21, #0], v1
    a.vread      v1, a2, s6
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.muli       s6, s2, #8
    s.add        s21, s11, s10
    s.movz       s10, #8
    s.addi       s22, s7, #8
    s.add        s23, s6, s8
    v.splat      v1, s22
    s.add        s6, s23, s17
    @p4 v.st.h       [s18, #0], v2
    a.vread      v2, a2, s16
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v5, v2
    s.muli       s16, s2, #9
    s.add        s18, s11, s6
    s.movz       s6, #9
    s.addi       s22, s7, #9
    s.add        s23, s16, s8
    v.splat      v2, s22
    s.add        s16, s23, s17
    @p3 v.st.h       [s20, #0], v5
    a.vread      v5, a2, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v5
    s.muli       s4, s2, #10
    s.add        s20, s11, s16
    s.movz       s16, #10
    s.addi       s22, s7, #10
    s.add        s23, s4, s8
    v.splat      v5, s22
    s.add        s4, s23, s17
    @p4 v.st.h       [s19, #0], v3
    a.vread      v3, a2, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.muli       s5, s2, #11
    s.add        s19, s11, s4
    s.movz       s4, #11
    s.addi       s22, s7, #11
    s.add        s23, s5, s8
    v.splat      v3, s22
    s.add        s5, s23, s17
    @p3 v.st.h       [s21, #0], v1
    a.vread      v1, a2, s10
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.muli       s10, s2, #12
    s.add        s21, s11, s5
    s.movz       s5, #12
    s.addi       s22, s7, #12
    s.add        s23, s10, s8
    v.splat      v1, s22
    s.add        s10, s23, s17
    @p4 v.st.h       [s18, #0], v2
    a.vread      v2, a2, s6
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v5, v2
    s.muli       s6, s2, #13
    s.add        s18, s11, s10
    s.movz       s10, #13
    s.addi       s22, s7, #13
    s.add        s23, s6, s8
    v.splat      v2, s22
    s.add        s6, s23, s17
    @p3 v.st.h       [s20, #0], v5
    a.vread      v5, a2, s16
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v5
    s.muli       s16, s2, #14
    s.add        s20, s11, s6
    s.movz       s6, #14
    s.addi       s22, s7, #14
    s.add        s23, s16, s8
    v.splat      v5, s22
    s.add        s16, s23, s17
    @p4 v.st.h       [s19, #0], v3
    a.vread      v3, a2, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.muli       s4, s2, #15
    s.add        s19, s11, s16
    s.movz       s16, #15
    s.addi       s22, s7, #15
    s.add        s23, s4, s8
    v.splat      v3, s22
    s.add        s4, s23, s17
    @p3 v.st.h       [s21, #0], v1
    a.vread      v1, a2, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.movz       s5, #0
    s.add        s17, s11, s4
    s.add        s4, s5, s1                      // the tile origin
    s.muli       s21, s1, #2
    v.splat      v1, s4
    v.splat      v6, s7
    v.add        v7, v0, v1
    s.add        s1, s8, s21
    @p4 v.st.h       [s18, #0], v2
    a.vread      v1, a2, s10
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.add        s4, s5, s3                      // the tile origin
    s.muli       s10, s2, #1
    v.splat      v1, s4
    s.add        s4, s11, s1
    s.movz       s1, #1
    s.add        s18, s10, s8
    s.add        s10, s18, s21
    @p3 v.st.h       [s20, #0], v2
    a.vread      v2, a2, s6
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s6, s7, #1
    s.muli       s18, s2, #2
    v.splat      v2, s6
    s.add        s6, s11, s10
    s.movz       s10, #2
    s.add        s20, s18, s8
    @p4 v.st.h       [s19, #0], v3
    a.vread      v3, a2, s16
    v.cmp.lt     p2, v7, v1
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.addi       s16, s7, #2
    s.add        s18, s20, s21
    v.splat      v3, s16
    s.muli       s16, s2, #3
    s.add        s19, s11, s18
    s.movz       s18, #3
    s.add        s20, s16, s8
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s5, s7, #3
    s.add        s16, s20, s21
    v.splat      v1, s5
    s.muli       s5, s2, #4
    s.add        s17, s11, s16
    s.movz       s16, #4
    s.addi       s20, s7, #4
    s.add        s22, s5, s8
    @p4 v.st.h       [s4, #0], v2
    a.vread      v2, a3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v2
    v.splat      v2, s20
    s.add        s1, s22, s21
    s.muli       s4, s2, #5
    s.add        s5, s11, s1
    s.movz       s1, #5
    s.addi       s20, s7, #5
    s.add        s22, s4, s8
    v.splat      v5, s20
    @p3 v.st.h       [s6, #0], v3
    a.vread      v3, a3, s10
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.add        s4, s22, s21
    s.muli       s6, s2, #6
    s.add        s10, s11, s4
    s.movz       s4, #6
    s.addi       s20, s7, #6
    s.add        s22, s6, s8
    v.splat      v3, s20
    s.add        s6, s22, s21
    @p4 v.st.h       [s19, #0], v1
    a.vread      v1, a3, s18
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.muli       s18, s2, #7
    s.add        s19, s11, s6
    s.movz       s6, #7
    s.addi       s20, s7, #7
    s.add        s22, s18, s8
    v.splat      v1, s20
    s.add        s18, s22, s21
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a3, s16
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v2
    s.muli       s16, s2, #8
    s.add        s17, s11, s18
    s.movz       s18, #8
    s.addi       s20, s7, #8
    s.add        s22, s16, s8
    v.splat      v2, s20
    s.add        s16, s22, s21
    @p4 v.st.h       [s5, #0], v5
    a.vread      v5, a3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v5
    s.muli       s1, s2, #9
    s.add        s5, s11, s16
    s.movz       s16, #9
    s.addi       s20, s7, #9
    s.add        s22, s1, s8
    v.splat      v5, s20
    s.add        s1, s22, s21
    @p3 v.st.h       [s10, #0], v3
    a.vread      v3, a3, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.muli       s4, s2, #10
    s.add        s10, s11, s1
    s.movz       s1, #10
    s.addi       s20, s7, #10
    s.add        s22, s4, s8
    v.splat      v3, s20
    s.add        s4, s22, s21
    @p4 v.st.h       [s19, #0], v1
    a.vread      v1, a3, s6
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.muli       s6, s2, #11
    s.add        s19, s11, s4
    s.movz       s4, #11
    s.addi       s20, s7, #11
    s.add        s22, s6, s8
    v.splat      v1, s20
    s.add        s6, s22, s21
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a3, s18
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v2
    s.muli       s17, s2, #12
    s.add        s18, s11, s6
    s.movz       s6, #12
    s.addi       s20, s7, #12
    s.add        s22, s17, s8
    v.splat      v2, s20
    s.add        s17, s22, s21
    @p4 v.st.h       [s5, #0], v5
    a.vread      v5, a3, s16
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v5
    s.muli       s5, s2, #13
    s.add        s16, s11, s17
    s.movz       s17, #13
    s.addi       s20, s7, #13
    s.add        s22, s5, s8
    v.splat      v5, s20
    s.add        s5, s22, s21
    @p3 v.st.h       [s10, #0], v3
    a.vread      v3, a3, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.muli       s1, s2, #14
    s.add        s10, s11, s5
    s.movz       s5, #14
    s.addi       s20, s7, #14
    s.add        s22, s1, s8
    v.splat      v3, s20
    s.add        s1, s22, s21
    @p4 v.st.h       [s19, #0], v1
    a.vread      v1, a3, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.muli       s4, s2, #15
    s.add        s19, s11, s1
    s.movz       s1, #15
    s.addi       s20, s7, #15
    s.add        s22, s4, s8
    v.splat      v1, s20
    s.add        s4, s22, s21
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a3, s6
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v2
    s.movz       s6, #0
    s.add        s18, s11, s4
    s.add        s4, s6, s9                      // the tile origin
    s.muli       s20, s9, #2
    v.splat      v2, s4
    v.splat      v6, s7
    v.add        v7, v0, v2
    s.add        s4, s8, s20
    @p4 v.st.h       [s16, #0], v5
    a.vread      v2, a3, s17
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.add        s9, s6, s3                      // the tile origin
    s.muli       s16, s2, #1
    v.splat      v2, s9
    s.add        s9, s11, s4
    s.movz       s4, #1
    s.add        s17, s16, s8
    s.add        s16, s17, s20
    @p3 v.st.h       [s10, #0], v3
    a.vread      v3, a3, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    v.cmp.lt     p1, v6, v4
    s.addi       s5, s7, #1
    s.muli       s10, s2, #2
    v.splat      v3, s5
    s.add        s5, s11, s16
    s.movz       s16, #2
    s.add        s17, s10, s8
    @p4 v.st.h       [s19, #0], v1
    a.vread      v1, a3, s1
    v.cmp.lt     p2, v7, v2
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s1, s7, #2
    s.add        s10, s17, s20
    v.splat      v1, s1
    s.muli       s1, s2, #3
    s.add        s17, s11, s10
    s.movz       s10, #3
    s.add        s19, s1, s8
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a4, s6
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s1, s7, #3
    s.add        s6, s19, s20
    v.splat      v2, s1
    s.muli       s1, s2, #4
    s.add        s18, s11, s6
    s.movz       s6, #4
    s.addi       s19, s7, #4
    s.add        s21, s1, s8
    @p4 v.st.h       [s9, #0], v3
    a.vread      v3, a4, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    v.splat      v3, s19
    s.add        s1, s21, s20
    s.muli       s4, s2, #5
    s.add        s9, s11, s1
    s.movz       s1, #5
    s.addi       s19, s7, #5
    s.add        s21, s4, s8
    v.splat      v5, s19
    @p3 v.st.h       [s5, #0], v1
    a.vread      v1, a4, s16
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.add        s4, s21, s20
    s.muli       s5, s2, #6
    s.add        s16, s11, s4
    s.movz       s4, #6
    s.addi       s19, s7, #6
    s.add        s21, s5, s8
    v.splat      v1, s19
    s.add        s5, s21, s20
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s10
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.muli       s10, s2, #7
    s.add        s17, s11, s5
    s.movz       s5, #7
    s.addi       s19, s7, #7
    s.add        s21, s10, s8
    v.splat      v2, s19
    s.add        s10, s21, s20
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a4, s6
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v3
    s.muli       s6, s2, #8
    s.add        s18, s11, s10
    s.movz       s10, #8
    s.addi       s19, s7, #8
    s.add        s21, s6, s8
    v.splat      v3, s19
    s.add        s6, s21, s20
    @p4 v.st.h       [s9, #0], v5
    a.vread      v5, a4, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v5
    s.muli       s1, s2, #9
    s.add        s9, s11, s6
    s.movz       s6, #9
    s.addi       s19, s7, #9
    s.add        s21, s1, s8
    v.splat      v5, s19
    s.add        s1, s21, s20
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a4, s4
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.muli       s4, s2, #10
    s.add        s16, s11, s1
    s.movz       s1, #10
    s.addi       s19, s7, #10
    s.add        s21, s4, s8
    v.splat      v1, s19
    s.add        s4, s21, s20
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s5
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.muli       s5, s2, #11
    s.add        s17, s11, s4
    s.movz       s4, #11
    s.addi       s19, s7, #11
    s.add        s21, s5, s8
    v.splat      v2, s19
    s.add        s5, s21, s20
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a4, s10
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v3
    s.muli       s10, s2, #12
    s.add        s18, s11, s5
    s.movz       s5, #12
    s.addi       s19, s7, #12
    s.add        s21, s10, s8
    v.splat      v3, s19
    s.add        s10, s21, s20
    @p4 v.st.h       [s9, #0], v5
    a.vread      v5, a4, s6
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v5
    s.muli       s6, s2, #13
    s.add        s9, s11, s10
    s.movz       s10, #13
    s.addi       s19, s7, #13
    s.add        s21, s6, s8
    v.splat      v5, s19
    s.add        s6, s21, s20
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a4, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.muli       s1, s2, #14
    s.add        s16, s11, s6
    s.movz       s6, #14
    s.addi       s19, s7, #14
    s.add        s21, s1, s8
    v.splat      v1, s19
    s.add        s1, s21, s20
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s4
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.muli       s4, s2, #15
    s.add        s17, s11, s1
    s.movz       s1, #15
    s.addi       s19, s7, #15
    s.add        s21, s4, s8
    v.splat      v2, s19
    s.add        s4, s21, s20
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a4, s5
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v3
    s.movz       s5, #0
    s.add        s18, s11, s4
    s.add        s4, s5, s14                     // the tile origin
    s.muli       s19, s14, #2
    v.splat      v3, s4
    v.splat      v6, s7
    v.add        v7, v0, v3
    s.add        s4, s8, s19
    @p4 v.st.h       [s9, #0], v5
    a.vread      v3, a4, s10
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.add        s9, s5, s3                      // the tile origin
    s.muli       s10, s2, #1
    v.splat      v3, s9
    s.add        s9, s11, s4
    s.movz       s4, #1
    s.add        s14, s10, s8
    s.add        s10, s14, s19
    @p3 v.st.h       [s16, #0], v1
    a.vread      v1, a4, s6
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    v.cmp.lt     p1, v6, v4
    s.addi       s6, s7, #1
    s.muli       s14, s2, #2
    v.splat      v1, s6
    s.add        s6, s11, s10
    s.movz       s10, #2
    s.add        s16, s14, s8
    @p4 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s1
    v.cmp.lt     p2, v7, v3
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.addi       s1, s7, #2
    s.add        s14, s16, s19
    v.splat      v2, s1
    s.muli       s1, s2, #3
    s.add        s16, s11, s14
    s.movz       s14, #3
    s.add        s17, s1, s8
    @p3 v.st.h       [s18, #0], v3
    a.vread      v3, a5, s5
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.addi       s1, s7, #3
    s.add        s5, s17, s19
    v.splat      v3, s1
    s.muli       s1, s2, #4
    s.add        s17, s11, s5
    s.movz       s5, #4
    s.addi       s18, s7, #4
    s.add        s20, s1, s8
    @p4 v.st.h       [s9, #0], v1
    a.vread      v1, a5, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    v.splat      v1, s18
    s.add        s1, s20, s19
    s.muli       s4, s2, #5
    s.add        s9, s11, s1
    s.movz       s1, #5
    s.addi       s18, s7, #5
    s.add        s20, s4, s8
    v.splat      v5, s18
    @p3 v.st.h       [s6, #0], v2
    a.vread      v2, a5, s10
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.add        s4, s20, s19
    s.muli       s6, s2, #6
    s.add        s10, s11, s4
    s.movz       s4, #6
    s.addi       s18, s7, #6
    s.add        s20, s6, s8
    v.splat      v2, s18
    s.add        s6, s20, s19
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a5, s14
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.muli       s14, s2, #7
    s.add        s16, s11, s6
    s.movz       s6, #7
    s.addi       s18, s7, #7
    s.add        s20, s14, s8
    v.splat      v3, s18
    s.add        s14, s20, s19
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a5, s5
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v1
    s.muli       s5, s2, #8
    s.add        s17, s11, s14
    s.movz       s14, #8
    s.addi       s18, s7, #8
    s.add        s20, s5, s8
    v.splat      v1, s18
    s.add        s5, s20, s19
    @p4 v.st.h       [s9, #0], v5
    a.vread      v5, a5, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v5
    s.muli       s1, s2, #9
    s.add        s9, s11, s5
    s.movz       s5, #9
    s.addi       s18, s7, #9
    s.add        s20, s1, s8
    v.splat      v5, s18
    s.add        s1, s20, s19
    @p3 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.muli       s4, s2, #10
    s.add        s10, s11, s1
    s.movz       s1, #10
    s.addi       s18, s7, #10
    s.add        s20, s4, s8
    v.splat      v2, s18
    s.add        s4, s20, s19
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a5, s6
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.muli       s6, s2, #11
    s.add        s16, s11, s4
    s.movz       s4, #11
    s.addi       s18, s7, #11
    s.add        s20, s6, s8
    v.splat      v3, s18
    s.add        s6, s20, s19
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a5, s14
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v1
    s.muli       s14, s2, #12
    s.add        s17, s11, s6
    s.movz       s6, #12
    s.addi       s18, s7, #12
    s.add        s20, s14, s8
    v.splat      v1, s18
    s.add        s14, s20, s19
    @p4 v.st.h       [s9, #0], v5
    a.vread      v5, a5, s5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v5
    s.muli       s5, s2, #13
    s.add        s9, s11, s14
    s.movz       s14, #13
    s.addi       s18, s7, #13
    s.add        s20, s5, s8
    v.splat      v5, s18
    s.add        s5, s20, s19
    @p3 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.muli       s1, s2, #14
    s.add        s10, s11, s5
    s.movz       s5, #14
    s.addi       s18, s7, #14
    s.add        s20, s1, s8
    v.splat      v2, s18
    s.add        s1, s20, s19
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a5, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.muli       s4, s2, #15
    s.add        s16, s11, s1
    s.movz       s1, #15
    s.addi       s18, s7, #15
    s.add        s20, s4, s8
    v.splat      v3, s18
    s.add        s4, s20, s19
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a5, s6
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v1
    s.movz       s6, #0
    s.add        s17, s11, s4
    s.add        s4, s6, s15                     // the tile origin
    s.muli       s18, s15, #2
    v.splat      v1, s4
    v.splat      v6, s7
    v.add        v7, v0, v1
    s.add        s4, s8, s18
    @p4 v.st.h       [s9, #0], v5
    a.vread      v1, a5, s14
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.add        s9, s6, s3                      // the tile origin
    s.muli       s14, s2, #1
    v.splat      v1, s9
    s.add        s9, s11, s4
    s.movz       s4, #1
    s.add        s15, s14, s8
    s.add        s14, s15, s18
    @p3 v.st.h       [s10, #0], v2
    a.vread      v2, a5, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s5, s7, #1
    s.muli       s10, s2, #2
    v.splat      v2, s5
    s.add        s5, s11, s14
    s.movz       s14, #2
    s.add        s15, s10, s8
    @p4 v.st.h       [s16, #0], v3
    a.vread      v3, a5, s1
    v.cmp.lt     p2, v7, v1
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.addi       s1, s7, #2
    s.add        s10, s15, s18
    v.splat      v3, s1
    s.muli       s1, s2, #3
    s.add        s15, s11, s10
    s.movz       s10, #3
    s.add        s16, s1, s8
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a6, s6
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.addi       s1, s7, #3
    s.add        s6, s16, s18
    v.splat      v1, s1
    s.muli       s1, s2, #4
    s.add        s16, s11, s6
    s.movz       s6, #4
    s.addi       s17, s7, #4
    s.add        s19, s1, s8
    @p4 v.st.h       [s9, #0], v2
    a.vread      v2, a6, s4
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v2
    v.splat      v2, s17
    s.add        s1, s19, s18
    s.muli       s4, s2, #5
    s.add        s9, s11, s1
    s.movz       s1, #5
    s.addi       s17, s7, #5
    s.add        s19, s4, s8
    v.splat      v5, s17
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a6, s14
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.add        s4, s19, s18
    s.muli       s5, s2, #6
    s.add        s14, s11, s4
    s.movz       s4, #6
    s.addi       s17, s7, #6
    s.add        s19, s5, s8
    v.splat      v3, s17
    s.add        s5, s19, s18
    @p4 v.st.h       [s15, #0], v1
    a.vread      v1, a6, s10
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.muli       s10, s2, #7
    s.add        s15, s11, s5
    s.movz       s5, #7
    s.addi       s17, s7, #7
    s.add        s19, s10, s8
    v.splat      v1, s17
    s.add        s10, s19, s18
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a6, s6
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v2
    s.muli       s6, s2, #8
    s.add        s16, s11, s10
    s.movz       s10, #8
    s.addi       s17, s7, #8
    s.add        s19, s6, s8
    v.splat      v2, s17
    s.add        s6, s19, s18
    @p4 v.st.h       [s9, #0], v5
    a.vread      v5, a6, s1
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v5
    s.muli       s1, s2, #9
    s.add        s9, s11, s6
    s.movz       s6, #9
    s.addi       s17, s7, #9
    s.add        s19, s1, s8
    v.splat      v5, s17
    s.add        s1, s19, s18
    @p3 v.st.h       [s14, #0], v3
    a.vread      v3, a6, s4
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.muli       s4, s2, #10
    s.add        s14, s11, s1
    s.movz       s1, #10
    s.addi       s17, s7, #10
    s.add        s19, s4, s8
    v.splat      v3, s17
    s.add        s4, s19, s18
    @p4 v.st.h       [s15, #0], v1
    a.vread      v1, a6, s5
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.muli       s5, s2, #11
    s.add        s15, s11, s4
    s.movz       s4, #11
    s.addi       s17, s7, #11
    s.add        s19, s5, s8
    v.splat      v1, s17
    s.add        s5, s19, s18
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a6, s10
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v2
    s.muli       s10, s2, #12
    s.add        s16, s11, s5
    s.movz       s5, #12
    s.addi       s17, s7, #12
    s.add        s19, s10, s8
    v.splat      v2, s17
    s.add        s10, s19, s18
    @p4 v.st.h       [s9, #0], v5
    a.vread      v5, a6, s6
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v3, v5
    s.muli       s6, s2, #13
    s.add        s9, s11, s10
    s.movz       s10, #13
    s.addi       s17, s7, #13
    s.add        s19, s6, s8
    v.splat      v5, s17
    s.add        s6, s19, s18
    @p3 v.st.h       [s14, #0], v3
    a.vread      v3, a6, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.muli       s1, s2, #14
    s.add        s14, s11, s6
    s.movz       s6, #14
    s.addi       s17, s7, #14
    s.add        s19, s1, s8
    v.splat      v3, s17
    s.add        s1, s19, s18
    @p4 v.st.h       [s15, #0], v1
    a.vread      v1, a6, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v1
    s.muli       s4, s2, #15
    s.add        s15, s11, s1
    s.movz       s1, #15
    s.addi       s17, s7, #15
    s.add        s19, s4, s8
    v.splat      v1, s17
    s.add        s4, s19, s18
    @p3 v.st.h       [s16, #0], v2
    a.vread      v2, a6, s5
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v5, v2
    s.movz       s5, #0
    s.add        s16, s11, s4
    s.add        s4, s5, s12                     // the tile origin
    s.muli       s17, s12, #2
    v.splat      v2, s4
    v.splat      v6, s7
    v.add        v7, v0, v2
    s.add        s4, s8, s17
    @p4 v.st.h       [s9, #0], v5
    a.vread      v0, a6, s10
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v0
    s.add        s9, s5, s3                      // the tile origin
    s.muli       s3, s2, #1
    v.splat      v0, s9
    s.add        s9, s11, s4
    s.movz       s4, #1
    s.add        s10, s3, s8
    s.add        s3, s10, s17
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a6, s6
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v1, v2
    v.cmp.lt     p1, v6, v4
    s.addi       s6, s7, #1
    s.muli       s10, s2, #2
    v.splat      v2, s6
    s.add        s6, s11, s3
    s.movz       s3, #2
    s.add        s12, s10, s8
    @p4 v.st.h       [s15, #0], v1
    a.vread      v1, a6, s1
    v.cmp.lt     p2, v7, v0
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.addi       s1, s7, #2
    s.add        s10, s12, s17
    v.splat      v1, s1
    s.muli       s1, s2, #3
    s.add        s12, s11, s10
    s.movz       s10, #3
    s.add        s14, s1, s8
    @p3 v.st.h       [s16, #0], v0
    a.vread      v0, a7, s5
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v2, v0
    s.addi       s1, s7, #3
    s.add        s5, s14, s17
    v.splat      v0, s1
    s.muli       s1, s2, #4
    s.add        s14, s11, s5
    s.movz       s5, #4
    s.addi       s15, s7, #4
    s.add        s16, s1, s8
    @p4 v.st.h       [s9, #0], v2
    a.vread      v2, a7, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    v.splat      v2, s15
    s.add        s1, s16, s17
    s.muli       s4, s2, #5
    s.add        s9, s11, s1
    s.movz       s1, #5
    s.addi       s15, s7, #5
    s.add        s16, s4, s8
    v.splat      v3, s15
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a7, s3
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.add        s3, s16, s17
    s.muli       s4, s2, #6
    s.add        s6, s11, s3
    s.movz       s3, #6
    s.addi       s15, s7, #6
    s.add        s16, s4, s8
    v.splat      v1, s15
    s.add        s4, s16, s17
    @p4 v.st.h       [s12, #0], v0
    a.vread      v0, a7, s10
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v0
    s.muli       s10, s2, #7
    s.add        s12, s11, s4
    s.movz       s4, #7
    s.addi       s15, s7, #7
    s.add        s16, s10, s8
    v.splat      v0, s15
    s.add        s10, s16, s17
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a7, s5
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.muli       s5, s2, #8
    s.add        s14, s11, s10
    s.movz       s10, #8
    s.addi       s15, s7, #8
    s.add        s16, s5, s8
    v.splat      v2, s15
    s.add        s5, s16, s17
    @p4 v.st.h       [s9, #0], v3
    a.vread      v3, a7, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.muli       s1, s2, #9
    s.add        s9, s11, s5
    s.movz       s5, #9
    s.addi       s15, s7, #9
    s.add        s16, s1, s8
    v.splat      v3, s15
    s.add        s1, s16, s17
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a7, s3
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.muli       s3, s2, #10
    s.add        s6, s11, s1
    s.movz       s1, #10
    s.addi       s15, s7, #10
    s.add        s16, s3, s8
    v.splat      v1, s15
    s.add        s3, s16, s17
    @p4 v.st.h       [s12, #0], v0
    a.vread      v0, a7, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v0
    s.muli       s4, s2, #11
    s.add        s12, s11, s3
    s.movz       s3, #11
    s.addi       s15, s7, #11
    s.add        s16, s4, s8
    v.splat      v0, s15
    s.add        s4, s16, s17
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a7, s10
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.muli       s10, s2, #12
    s.add        s14, s11, s4
    s.movz       s4, #12
    s.addi       s15, s7, #12
    s.add        s16, s10, s8
    v.splat      v2, s15
    s.add        s10, s16, s17
    @p4 v.st.h       [s9, #0], v3
    a.vread      v3, a7, s5
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v3
    s.muli       s5, s2, #13
    s.add        s9, s11, s10
    s.movz       s10, #13
    s.addi       s15, s7, #13
    s.add        s16, s5, s8
    v.splat      v3, s15
    s.add        s5, s16, s17
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a7, s1
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    s.muli       s1, s2, #14
    s.add        s6, s11, s5
    s.movz       s5, #14
    s.addi       s15, s7, #14
    s.add        s16, s1, s8
    v.splat      v1, s15
    s.add        s1, s16, s17
    @p4 v.st.h       [s12, #0], v0
    a.vread      v0, a7, s3
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v2, v0
    s.muli       s3, s2, #15
    s.add        s2, s11, s1
    s.movz       s1, #15
    s.addi       s12, s7, #15
    s.add        s7, s3, s8
    v.splat      v0, s12
    s.add        s3, s7, s17
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a7, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v3, v2
    s.add        s4, s11, s3
    @p4 v.st.h       [s9, #0], v3
    a.vread      v2, a7, s10
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.f16 v1, v2
    @p3 v.st.h       [s6, #0], v1
    a.vread      v1, a7, s5
    v.cmp.lt     p1, v0, v4
    p.and        p3, p1, p2
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s2, #0], v0
    a.vread      v0, a7, s1
    vf.cvt.f32.f16 v1, v0
    @p3 v.st.h       [s4, #0], v1
    exit
    exit
