source ~/tc_env/env.sh
cd /tmp/r40_p0b_source
python3 run_p0b.py > /tmp/r40_p0b.log 2>&1
echo $? > /tmp/r40_p0b.exit
