    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #0
    v.add        v4, v1, v0
    v.movi       v0, #6
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.sub        v6, v3, v4
    v.cmp.lt     p1, v4, v2
    v.cmp.lt     p2, v4, v3
    @p1 v.sel        v7, v5, v4
    @p2 v.sel        v5, v6, v4
    v.sub        v6, v1, v4
    v.lshr       v8, v7, v0
    v.movi       v0, #0
    v.cmp.lt     p3, v4, v1
    v.sub        v7, v2, v8
    @p3 v.sel        v9, v6, v4
    v.movi       v4, #63
    @p1 v.sel        v6, v7, v8
    v.movi       v7, #255
    v.and        v8, v9, v4
    v.sub        v4, v0, v6
    v.cmp.lt     p1, v6, v0
    v.sub        v9, v1, v8
    @p1 v.sel        v10, v4, v6
    s.rdspecial  s2, arg_base
    @p3 v.sel        v4, v9, v8
    v.and        v6, v10, v7
    v.movi       v7, #256
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.sub        v8, v0, v6
    v.movi       v9, #16384
    v.movi       v10, #64
    @p1 v.sel        v11, v8, v6
    v.sub        v6, v0, v7
    v.cmp.lt     p1, v10, v1
    v.sub        v8, v1, v10
    v.cmp.lt     p3, v10, v2
    v.sub        v1, v2, v10
    @p1 v.sel        v2, v8, v10
    s.ld.d       s4, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v2, #14
    v.mul        v8, v4, v7
    v.cmp.lt     p1, v7, v0
    v.lshr       v0, v5, v2
    v.movi       v2, #0
    v.movi       v4, #2
    v.add        v5, v11, v8
    v.sub        v8, v3, v0
    @p3 v.sel        v11, v1, v10
    .li       s2, #1048576000
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p2 v.sel        v10, v8, v0
    v.movi       v0, #4
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    v.sub        v8, v2, v10
    v.cmp.lt     p2, v10, v2
    s.add        s1, s4, s2                      // &out_ptr0[...]
    @p2 v.sel        v11, v8, v10
    v.sub        v8, v3, v9
    v.cmp.lt     p3, v9, v3
    v.lshr       v3, v11, v4
    v.sub        v4, v2, v0
    @p1 v.sel        v10, v6, v7
    v.sub        v6, v2, v3
    v.cmp.lt     p1, v0, v2
    @p3 v.sel        v2, v8, v9
    @p2 v.sel        v2, v6, v3
    @p1 v.sel        v3, v4, v0
    v.mul        v0, v2, v9
    v.add        v2, v5, v0
    v.ld.gather.h v0, [s3, v2]                   // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v0
    vf.mul       v0, v2, v1
    v.st.w       [s1, #0], v0
__rctx_next:
    exit
