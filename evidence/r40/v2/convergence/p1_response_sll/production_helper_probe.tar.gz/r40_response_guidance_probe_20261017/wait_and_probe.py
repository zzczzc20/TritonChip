from pathlib import Path
import time,subprocess,json
r=Path.home()/'tnca_build/r40_attempt02_physical_detail_20261017'
pid=1743581
while Path('/proc',str(pid),'cmdline').exists():
 command=Path('/proc',str(pid),'cmdline').read_bytes()
 assert str(r).encode() in command,'wait PID identity changed'
 time.sleep(30)
assert (r/'runner.exit').exists(),'reader absent without terminal marker; inspect before starting another'
root=Path.cwd()
command=['bash','-c','source /tools/Xilinx/Vivado/2023.2/settings64.sh >/dev/null 2>&1; exec timeout 600 nice -n 19 vivado -mode batch -source "$1" -tclargs "$2" "$3"','r40-guidance-probe',str(root/'probe.tcl'),str(Path.home()/'tnca_build/r40_line_response_sll_20261017/case0/reports/routed.dcp'),str(root/'guidance_applied.tsv')]
with (root/'stdout.log').open('x') as stream:result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
(root/'runner.exit').write_text(str(result.returncode)+'\n')
