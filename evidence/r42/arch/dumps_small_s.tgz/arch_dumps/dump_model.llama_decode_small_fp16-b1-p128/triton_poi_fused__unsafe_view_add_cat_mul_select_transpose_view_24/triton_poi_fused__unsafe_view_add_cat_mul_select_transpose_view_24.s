    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    v.movi       v0, #4096
    v.movi       v1, #0
    v.iota       v2                              // arange(0, VLEN)
    v.movi       v3, #16
    v.movi       v4, #32
    v.movi       v5, #48
    v.movi       v6, #64
    v.movi       v7, #80
    v.movi       v8, #96
    v.movi       v9, #112
    v.sub        v10, v1, v0
    v.cmp.lt     p1, v0, v1
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (0 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
    v.add        v11, v2, v3
    v.add        v3, v2, v4
    v.add        v4, v2, v5
    v.add        v5, v2, v6
    v.add        v6, v2, v7
    v.add        v7, v2, v8
    v.add        v8, v2, v9
    @p1 v.sel        v9, v10, v0
    v.movi       v0, #4095
    v.movi       v9, #12
    v.movi       v10, #16384
    v.movi       v12, #4128
tiles_1:
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s9, s1, s8
    v.splat      v13, s9
    v.add        v14, v13, v2
    v.add        v15, v13, v11
    v.add        v16, v13, v3
    v.add        v17, v13, v4
    v.add        v18, v13, v5
    v.add        v19, v13, v6
    v.add        v20, v13, v7
    v.add        v21, v13, v8
    v.sub        v13, v1, v14
    v.sub        v22, v1, v15
    v.sub        v23, v1, v16
    v.sub        v24, v1, v17
    v.sub        v25, v1, v18
    v.sub        v26, v1, v19
    v.sub        v27, v1, v20
    v.sub        v28, v1, v21
    v.cmp.lt     p1, v14, v1
    v.cmp.lt     p2, v15, v1
    v.cmp.lt     p3, v16, v1
    v.cmp.lt     p4, v17, v1
    v.cmp.lt     p5, v18, v1
    v.cmp.lt     p6, v19, v1
    v.cmp.lt     p7, v20, v1
    v.cmp.lt     p8, v21, v1
    @p1 v.sel        v29, v13, v14
    @p2 v.sel        v13, v22, v15
    @p3 v.sel        v22, v23, v16
    @p4 v.sel        v23, v24, v17
    @p5 v.sel        v24, v25, v18
    @p6 v.sel        v25, v26, v19
    @p7 v.sel        v26, v27, v20
    @p8 v.sel        v27, v28, v21
    v.lshr       v28, v29, v9
    v.and        v30, v29, v0
    v.lshr       v29, v13, v9
    v.and        v31, v13, v0
    v.and        v13, v22, v0
    v.and        v32, v23, v0
    v.and        v33, v24, v0
    v.and        v34, v25, v0
    v.and        v35, v26, v0
    v.and        v36, v27, v0
    v.sub        v37, v1, v28
    v.sub        v38, v1, v30
    v.sub        v39, v1, v29
    v.sub        v40, v1, v31
    v.sub        v41, v1, v13
    @p1 v.sel        v42, v37, v28
    v.sub        v28, v1, v32
    @p1 v.sel        v37, v38, v30
    v.lshr       v30, v22, v9
    v.lshr       v22, v23, v9
    v.sub        v23, v1, v33
    @p2 v.sel        v38, v39, v29
    v.sub        v29, v1, v30
    @p2 v.sel        v39, v40, v31
    v.lshr       v31, v24, v9
    v.lshr       v24, v25, v9
    v.sub        v25, v1, v22
    @p3 v.sel        v40, v29, v30
    v.sub        v29, v1, v31
    @p4 v.sel        v30, v25, v22
    v.sub        v22, v1, v24
    @p5 v.sel        v25, v29, v31
    v.sub        v29, v1, v34
    @p3 v.sel        v31, v41, v13
    v.lshr       v13, v26, v9
    v.lshr       v26, v27, v9
    v.sub        v27, v1, v35
    v.sub        v41, v1, v13
    @p6 v.sel        v43, v22, v24
    v.sub        v22, v1, v26
    v.sub        v24, v1, v36
    @p7 v.sel        v44, v41, v13
    @p4 v.sel        v13, v28, v32
    v.add        v28, v14, v10
    v.add        v14, v15, v10
    v.add        v15, v16, v10
    v.add        v16, v17, v10
    v.add        v17, v18, v10
    @p8 v.sel        v18, v22, v26
    @p5 v.sel        v22, v23, v33
    v.add        v23, v19, v10
    v.add        v19, v20, v10
    v.add        v20, v21, v10
    v.ld.gather.h v21, [s3, v28]                 // index is in elements (ISA sec 9.1)
    @p6 v.sel        v26, v29, v34
    @p7 v.sel        v28, v27, v35
    @p8 v.sel        v27, v24, v36
    v.mul        v24, v42, v12
    v.mul        v29, v38, v12
    v.mul        v32, v40, v12
    v.mul        v33, v30, v12
    v.mul        v30, v25, v12
    v.mul        v25, v43, v12
    v.mul        v34, v44, v12
    v.mul        v35, v18, v12
    v.add        v18, v37, v24
    v.add        v24, v39, v29
    v.ld.gather.h v29, [s3, v14]                 // index is in elements (ISA sec 9.1)
    v.add        v14, v31, v32
    v.add        v31, v13, v33
    v.add        v13, v22, v30
    v.add        v22, v26, v25
    v.add        v25, v28, v34
    v.add        v26, v27, v35
    v.ld.gather.h v27, [s3, v15]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v15, [s3, v16]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v16, [s3, v17]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v17, [s3, v23]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v23, [s3, v19]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.h v19, [s3, v20]                 // index is in elements (ISA sec 9.1)
    v.st.scatter.h [s7, v18], v21
    v.st.scatter.h [s7, v24], v29
    v.st.scatter.h [s7, v14], v27
    v.st.scatter.h [s7, v31], v15
    v.st.scatter.h [s7, v13], v16
    v.st.scatter.h [s7, v22], v17
    v.st.scatter.h [s7, v25], v23
    v.st.scatter.h [s7, v26], v19
    s.addi       s8, s8, #128
    s.cmp.lt     s9, s8, s2
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
