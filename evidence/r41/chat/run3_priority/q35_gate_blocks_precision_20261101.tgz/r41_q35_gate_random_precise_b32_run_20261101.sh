#!/usr/bin/env bash
set -eu
export TNCA_MAX_BLOCK=32
export PYTHONPATH="$HOME/r41_q35_multiturn_diag_20261031:$HOME/r41_q35_multiturn_diag_20261031/python:$HOME/r41_q35_multiturn_diag_20261031/compiler/python:$HOME/r41_q35_multiturn_diag_20261031/tools/asm"
mode="tlm"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES= HF_HOME="$HOME/flux-hf" HF_HUB_OFFLINE=0 QWEN_FP8_VIEW_DIR="$HOME/r41-p3/snapview"
export TNCA_BACKEND=systemc-tlm-grid TNCA_PROFILE=core-vrf-sync-v5-x8-g2c4-dp TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip" TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg" TNCA_TLM_MEMORY_BYTES=0x200000000 TNCA_DRAM_PATH=fast TNCA_TLM_UNTIMED_COLD=0 TNCA_DEADLINE=40000000000 TNCA_HOST_TIMEOUT=3600
export TNCA_TLM_OUT="$HOME/r41_q35_gate_random_precise_b32_20261101_${mode}_20261031_tlm" TRITON_CACHE_DIR="$HOME/r41_q35_gate_random_precise_b32_20261101_${mode}_20261031_triton" TORCHINDUCTOR_CACHE_DIR="$HOME/r41_q35_gate_random_precise_b32_20261101_${mode}_20261031_inductor"
exec "$HOME/flux-venv/bin/python" -u "$HOME/r41_precision_cast_wrapper_v2_20261101.py" "$HOME/r41_q35_gate_random_precise_b32_20261101.py"
