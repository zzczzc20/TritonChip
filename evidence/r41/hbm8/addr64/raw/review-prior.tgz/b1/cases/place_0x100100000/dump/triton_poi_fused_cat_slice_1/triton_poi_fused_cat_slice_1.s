    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    v.movi       v2, #32
    v.movi       v3, #256
    v.add        v4, v1, v0
    s.shli       s4, s2, #2                      // element offset -> bytes (x4)
    v.add        v0, v4, v2
    v.cmp.lt     p1, v4, v3
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s3, v0]               // index is in elements (ISA sec 9.1)
    s.ld.d       s2, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.add        s1, s2, s4                      // &out_ptr0[...]
    @p1 v.st.w       [s1, #0], v1
__rctx_next:
    exit
