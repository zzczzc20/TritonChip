#!/usr/bin/env bash
set -eu
route=$1
export OMP_NUM_THREADS=1 MAX_JOBS=1 CUDA_VISIBLE_DEVICES=
export HF_HOME="$HOME/flux-hf" HF_HUB_OFFLINE=0 QWEN_FP8_VIEW_DIR="$HOME/r41-p3/snapview"
export TNCA_BACKEND=systemc-tlm-grid TNCA_PROFILE=core-vrf-sync-v5-x8-g2c4-dp
export TNCA_TLM_BINARY="$HOME/r41_vl_reason_dp/build/tnca-chip"
export TNCA_TLM_CONFIG="$HOME/r41_vl_reason_dp/src/tools/performance_harness/systemc/configs/r41-mma-dp.cfg"
export TNCA_TLM_MEMORY_BYTES=0x200000000 TNCA_DRAM_PATH=fast TNCA_TLM_UNTIMED_COLD=0 TNCA_DEADLINE=40000000000 TNCA_HOST_TIMEOUT=3600
export TNCA_TLM_OUT="$HOME/r41_profile_model_astage_${route}_tlm" TRITON_CACHE_DIR="$HOME/r41_profile_model_astage_${route}_triton" TORCHINDUCTOR_CACHE_DIR="$HOME/r41_profile_model_astage_${route}_inductor"
if [[ $route == age64 ]]; then export TNCA_CODE_CACHE_POLICY=lfu-sqrt; tree="$HOME/r41_cache_age64_final_20261031"; else tree="$HOME/r41_profile_astage_20261031"; fi
cd "$tree"
exec "$HOME/flux-venv/bin/python" -u tools/models/decode_profile.py --model vl --device tnca --tnca-tree "$PWD" --layers 1 --prompt 'Say hi.' --new-tokens 2 --bucket 64 --check-tokens 0 --out "$HOME/r41_profile_model_astage_${route}"
