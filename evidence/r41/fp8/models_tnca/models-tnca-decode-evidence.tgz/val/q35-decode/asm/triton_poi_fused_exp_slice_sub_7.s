    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #6
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    s.rdspecial  s2, arg_base
    v.lshr       v1, v4, v0
    v.movi       v0, #64
    v.sub        v4, v2, v1
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p1 v.sel        v5, v4, v1
    v.movi       v1, #63
    v.mul        v4, v5, v0
    s.shli       s4, s1, #2                      // element offset -> bytes (x4)
    v.movi       v5, #2048
    v.add        v6, v4, v1
    s.add        s1, s3, s4                      // &in_ptr0[...]
    v.cmp.lt     p1, v3, v5
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v1, [s3, v6]               // index is in elements (ISA sec 9.1)
    .li       s3, #1069066811
    v.splat      v3, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s3, #1060205080
    v.splat      v4, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.sub        v5, v2, v0
    v.cmp.lt     p2, v0, v2
    @p2 v.sel        v2, v5, v0
    @p1 v.ld.w       v0, [s1, #0]
    vf.sub       v2, v1, v0
    s.ld.d       s1, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    vf.mul       v0, v2, v3
    s.add        s2, s1, s4                      // &out_ptr0[...]
    v.exp2.approx v1, v0                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v5, v2, v3, v0                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v5, v4
    vf.fma       v2, v1, v0, v1                  // 2**t * 2**d
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v0, v2, v1
    @p1 v.st.w       [s2, #0], v0
__rctx_next:
    exit
