    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    s.rdspecial  s3, role_id
    s.movz       s6, #512
    s.add        s7, s1, s5                      // this context's own scratch
    s.ld.d       s1, [s2, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.addi       s5, s7, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s7, #2147483647
    .li       s8, #2147483647
    s.movz       s9, #128
    s.movz       s10, #2
    .li       s11, #68719476752
    .li       s12, #8589934592
    s.rdspecial  s13, arg_base
    s.mul        s14, s3, s6
    s.ld.d       s3, [s2, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.movz       s6, #4
    .li       s15, #2147483647
    s.ld.d       s16, [s2, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    s.movz       s2, #0
    s.movz       s17, #0
    s.movz       s18, #0
    s.movz       s19, #0
    s.cmp.lt     s20, s6, s18
    s.st.d       [s5, #0], s1
    s.sub        s1, s19, s20
    .li       s18, #2147483647
    s.st.d       [s5, #8], s7
    s.movz       s7, #128
    s.movz       s19, #2
    s.st.d       [s5, #16], s8
    .li       s8, #68719476752
    .li       s20, #8589934592
    s.st.d       [s5, #48], s9
    s.xor        s9, s6, s1
    s.movz       s21, #0
    s.cmp.lt     s21, s4, s2
    s.st.d       [s5, #56], s10
    s.sub        s2, s17, s21
    s.movz       s10, #1
    s.xor        s17, s4, s2
    s.st.d       [s5, #88], s11
    s.sub        s11, s17, s2
    s.movz       s17, #0
    s.st.d       [s5, #104], s12
    s.lshri      s12, s11, #2
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s5, s2, s1
    s.movz       s2, #0
    s.ld.d       s21, [s13, #24]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.cmp.lt     s13, s4, s2
    s.movz       s2, #0
    s.add        s2, s21, s14                    // this context's own scratch
    s.xor        s14, s12, s5
    s.muli       s21, s12, #4
    s.sub        s12, s14, s5
    s.movz       s5, #0
    s.addi       s14, s2, #256                   // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.sub        s2, s9, s1
    s.sub        s1, s10, s12
    s.movz       s2, #0
    s.min.s      s9, s1, s10
    s.sub        s1, s2, s13
    s.cmp.lt     s2, s9, s17
    s.movz       s13, #0
    s.sub        s17, s5, s2
    s.movz       s2, #1
    s.st.d       [s14, #0], s3
    s.xor        s3, s4, s1
    s.sub        s5, s11, s21
    s.movz       s5, #0
    s.sub        s11, s3, s1
    s.st.d       [s14, #8], s15
    s.xor        s3, s9, s17
    s.sub        s15, s3, s17
    s.st.d       [s14, #16], s18
    s.addi       s3, s13, #0
    s.addi       s13, s5, #0
    s.st.d       [s14, #48], s7
    s.cmp.eq     s5, s15, s2
    s.st.d       [s14, #56], s19
    s.st.d       [s14, #88], s8
    s.st.d       [s14, #104], s20
    fence.release.device
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s3, s11
    br.nz        s5, sdiv_done_1
    s.movz       s2, #0
    s.movz       s5, #31
    s.mov        s3, s2
    s.addi       s2, s5, #0
sdiv_2:
    s.lshr       s5, s11, s2
    s.shli       s7, s13, #1
    s.andi       s8, s5, #1
    s.movz       s5, #0
    s.or         s14, s7, s8
    s.movz       s7, #1
    s.cmp.geu    s8, s14, s15
    s.shl        s17, s7, s2
    s.sub        s7, s5, s8
    s.subi       s5, s2, #1
    s.and        s8, s15, s7
    s.and        s18, s17, s7
    s.sub        s7, s14, s8
    s.or         s8, s3, s18
    s.mov        s13, s7
    s.mov        s3, s8
    s.mov        s2, s5
    s.movz       s5, #0
    s.cmp.ge     s7, s2, s5
    br.nz        s7, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.movz       s3, #0
    s.cmp.lt     s5, s4, s2
    s.movz       s2, #0
    s.sub        s7, s3, s5
    s.movz       s3, #0
    s.xor        s5, s4, s7
    s.movz       s4, #0
    s.sub        s8, s5, s7
    s.cmp.lt     s5, s9, s2
    s.lshri      s2, s8, #2
    s.movz       s11, #0
    s.muli       s14, s2, #4
    s.movz       s2, #0
    s.sub        s15, s4, s5
    s.movz       s4, #0
    s.cmp.lt     s5, s6, s11
    s.sub        s11, s8, s14
    s.xor        s8, s9, s15
    s.xor        s9, s11, s7
    s.xor        s11, s13, s1
    s.sub        s13, s9, s7
    s.sub        s7, s4, s5
    s.cmp.lt     s4, s13, s3
    s.sub        s3, s8, s15
    s.sub        s5, s2, s4
    s.movz       s2, #0
    s.xor        s4, s13, s5
    s.movz       s8, #1
    s.sub        s9, s11, s1
    s.xor        s1, s6, s7
    s.sub        s11, s4, s5
    s.movz       s4, #0
    s.addi       s13, s2, #0
    s.cmp.eq     s2, s3, s8
    s.add        s8, s12, s9
    s.sub        s9, s1, s7
    s.addi       s1, s4, #0
    s.mov        s13, s11
    br.nz        s2, sdiv_done_3
    s.movz       s2, #0
    s.movz       s4, #31
    s.mov        s13, s2
    s.addi       s2, s4, #0
sdiv_4:
    s.lshr       s4, s11, s2
    s.shli       s7, s1, #1
    s.andi       s9, s4, #1
    s.movz       s4, #0
    s.or         s12, s7, s9
    s.movz       s7, #1
    s.cmp.geu    s9, s12, s3
    s.shl        s14, s7, s2
    s.sub        s7, s4, s9
    s.subi       s4, s2, #1
    s.and        s9, s3, s7
    s.and        s17, s14, s7
    s.sub        s7, s12, s9
    s.or         s9, s13, s17
    s.mov        s1, s7
    s.mov        s13, s9
    s.mov        s2, s4
    s.movz       s4, #0
    s.cmp.ge     s7, s2, s4
    br.nz        s7, sdiv_4
sdiv_done_3:
    s.xor        s1, s5, s15
    s.movz       s2, #16
    s.xor        s3, s13, s1
    s.mul        s4, s8, s2
    s.sub        s5, s3, s1
    s.movz       s1, #0
    s.mul        s3, s5, s2
    v.splat      v0, s8
    s.andi       s7, s4, #15
    v.splat      v1, s1
    v.splat      v2, s5
    s.andi       s5, s3, #63
    v.splat      v3, s1
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s4
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s3
    v.splat      v1, s7
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s5
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.addi       s8, s1, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s1, s8, s6
    br.nz        s1, endfor_6
    s.mul        s1, s8, s2
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s9, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.add        s11, s8, s10
    s.movz       s12, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s13, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s14, s1                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s13, s9
    mb.wait      s9
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s13, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s14, s5                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s1                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s14, s13
    mb.wait      s13
    mb.arm       s1, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s1
    mb.wait      s1
    s.mov        s8, s11
    br.nz        s12, for_5
endfor_6:
    s.movz       s5, #0
    s.muli       s6, s3, #2                      // a runtime tile origin, x2
    s.movz       s7, #0
    s.add        s8, s5, s3                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s3, #0
    s.muli       s5, s4, #128                    // a runtime tile origin, x128
    s.add        s10, s7, s4                     // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s8
    s.movz       s4, #64
    a.vread      v2, a0, s3
    v.splat      v3, s10
    v.splat      v4, s2
    v.add        v5, v0, v1
    v.splat      v0, s4
    s.add        s2, s16, s6                     // the tile origin
    vf.cvt.f32.f16 v1, v2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v0
    s.add        s3, s2, s5                      // the tile origin
    p.and        p3, p1, p2
    s.movz       s2, #1
    s.addi       s4, s10, #1
    @p3 v.st.h       [s3, #0], v1
    a.vread      v0, a0, s2
    v.splat      v1, s4
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #128                    // row 1
    p.and        p3, p1, p2
    s.movz       s4, #2
    s.addi       s5, s10, #2
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s4
    v.splat      v1, s5
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #256                    // row 2
    p.and        p3, p1, p2
    s.movz       s4, #3
    s.addi       s5, s10, #3
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s4
    v.splat      v1, s5
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #384                    // row 3
    p.and        p3, p1, p2
    s.movz       s4, #4
    s.addi       s5, s10, #4
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s4
    v.splat      v1, s5
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #512                    // row 4
    p.and        p3, p1, p2
    s.movz       s4, #5
    s.addi       s5, s10, #5
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s4
    v.splat      v1, s5
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #640                    // row 5
    p.and        p3, p1, p2
    s.movz       s4, #6
    s.addi       s5, s10, #6
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s4
    v.splat      v1, s5
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #768                    // row 6
    p.and        p3, p1, p2
    s.movz       s4, #7
    s.addi       s5, s10, #7
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s4
    v.splat      v1, s5
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #896                    // row 7
    p.and        p3, p1, p2
    s.movz       s4, #8
    s.addi       s5, s10, #8
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s4
    v.splat      v1, s5
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #1024                   // row 8
    p.and        p3, p1, p2
    s.movz       s4, #9
    s.addi       s5, s10, #9
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s4
    v.splat      v1, s5
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #1152                   // row 9
    p.and        p3, p1, p2
    s.movz       s4, #10
    s.addi       s5, s10, #10
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s4
    v.splat      v1, s5
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #1280                   // row 10
    p.and        p3, p1, p2
    s.movz       s4, #11
    s.addi       s5, s10, #11
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s4
    v.splat      v1, s5
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #1408                   // row 11
    p.and        p3, p1, p2
    s.movz       s4, #12
    s.addi       s5, s10, #12
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s4
    v.splat      v1, s5
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #1536                   // row 12
    p.and        p3, p1, p2
    s.movz       s4, #13
    s.addi       s5, s10, #13
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s4
    v.splat      v1, s5
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #1664                   // row 13
    p.and        p3, p1, p2
    s.movz       s4, #14
    s.addi       s5, s10, #14
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s4
    v.splat      v1, s5
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #1792                   // row 14
    p.and        p3, p1, p2
    s.movz       s4, #15
    s.addi       s5, s10, #15
    @p3 v.st.h       [s2, #0], v2
    a.vread      v0, a0, s4
    v.splat      v1, s5
    vf.cvt.f32.f16 v2, v0
    v.cmp.lt     p1, v1, v4
    s.addi       s2, s3, #1920                   // row 15
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v2
__rctx_next:
    exit
