    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #4
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.lshr       v5, v4, v0
    v.movi       v0, #0
    v.sub        v4, v2, v5
    v.sub        v6, v1, v3
    @p1 v.sel        v7, v4, v5
    v.cmp.lt     p1, v3, v1
    v.sub        v4, v0, v7
    v.cmp.lt     p2, v7, v0
    @p1 v.sel        v5, v6, v3
    v.movi       v6, #15
    s.rdspecial  s2, arg_base
    @p2 v.sel        v8, v4, v7
    v.and        v4, v5, v6
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.sub        v5, v1, v4
    .li       s4, #-1
    @p1 v.sel        v6, v5, v4
    s.ld.d       s5, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    .li       s6, #-1
    .li       s7, #-1
    s.ld.d       s8, [s2, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    v.movi       v4, #15
    .li       s9, #-1
    s.ld.d       s10, [s2, #24]                  // out_ptr1: device_ptr64 at arg_base+24
    v.movi       v5, #0
    v.and        v7, v8, v4
    .li       s2, #-1
    v.cmp.lt     p1, v3, v5
    v.sub        v4, v0, v7
    .li       s11, #-1
    @p2 v.sel        v8, v4, v7
    .li       s12, #-1
    v.sub        v4, v5, v3
    .li       s13, #-1
    @p1 v.sel        v7, v4, v3
    .li       s14, #-1
    .li       s15, #-1
    .li       s16, #-1
    v.movi       v4, #8
    .li       s17, #-1
    v.lshr       v9, v7, v4
    v.movi       v4, #0
    v.sub        v7, v5, v9
    v.movi       v10, #16
    @p1 v.sel        v11, v7, v9
    v.movi       v7, #256
    v.cmp.lt     p1, v11, v4
    v.cmp.lt     p2, v10, v1
    v.sub        v9, v1, v10
    v.cmp.lt     p3, v10, v2
    v.sub        v1, v2, v10
    @p2 v.sel        v2, v9, v10
    v.sub        v2, v4, v11
    v.cmp.lt     p2, v10, v0
    @p1 v.sel        v9, v2, v11
    v.movi       v2, #0
    v.sub        v11, v0, v10
    @p3 v.sel        v0, v1, v10
    v.movi       v0, #3
    v.cmp.lt     p3, v3, v2
    v.and        v1, v9, v0
    v.sub        v0, v2, v3
    @p2 v.sel        v9, v11, v10
    @p3 v.sel        v9, v0, v3
    v.movi       v0, #10
    v.sub        v3, v4, v1
    v.lshr       v10, v9, v0
    v.movi       v0, #64
    v.sub        v9, v6, v8
    @p1 v.sel        v11, v3, v1
    v.sub        v1, v2, v10
    v.mul        v3, v8, v0
    v.extract    s18, v9, #0
    @p3 v.sel        v0, v1, v10
    v.movi       v1, #1040
    v.add        v10, v6, v3
    v.mul        v3, v11, v1
    v.movi       v1, #4096
    v.add        v11, v10, v3
    v.mul        v3, v0, v1
    v.movi       v0, #0
    v.add        v1, v11, v3
    v.movi       v3, #0
    v.ld.gather.w v10, [s3, v1]                  // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v5
    s.shli       s3, s18, #32
    v.sub        v11, v5, v7
    s.ashri      s18, s3, #32
    @p1 v.sel        v5, v11, v7
    v.extract    s3, v9, #1
    s.shli       s19, s3, #32
    s.lshri      s3, s18, #32
    s.ashri      s20, s19, #32
    v.ld.gather.w v5, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.insert     v0, s18, #0
    v.insert     v3, s3, #0
    v.insert     v0, s20, #1
    v.movi       v1, #4
    v.extract    s3, v9, #2
    s.lshri      s5, s20, #32
    v.movi       v7, #1024
    v.insert     v3, s5, #1
    v.cmp.lt     p1, v1, v4
    s.shli       s5, s3, #32
    v.sub        v11, v4, v1
    s.ashri      s3, s5, #32
    v.cmp.lt     p2, v7, v2
    s.lshri      s5, s3, #32
    v.insert     v0, s3, #2
    v.sub        v4, v2, v7
    @p1 v.sel        v2, v11, v1
    v.extract    s3, v9, #3
    s.shli       s18, s3, #32
    v.extract    s3, v9, #4
    s.ashri      s19, s18, #32
    s.shli       s18, s3, #32
    v.insert     v3, s5, #2
    s.lshri      s3, s19, #32
    s.ashri      s5, s18, #32
    v.insert     v0, s19, #3
    v.insert     v3, s3, #3
    s.lshri      s3, s5, #32
    v.insert     v0, s5, #4
    @p2 v.sel        v1, v4, v7
    v.extract    s5, v9, #5
    s.shli       s18, s5, #32
    v.extract    s5, v9, #6
    s.ashri      s19, s18, #32
    s.shli       s18, s5, #32
    v.extract    s5, v9, #7
    v.insert     v3, s3, #4
    s.lshri      s3, s19, #32
    s.ashri      s20, s18, #32
    s.shli       s18, s5, #32
    v.extract    s5, v9, #8
    v.insert     v0, s19, #5
    v.insert     v3, s3, #5
    s.lshri      s3, s20, #32
    s.ashri      s19, s18, #32
    s.shli       s18, s5, #32
    v.extract    s5, v9, #9
    v.insert     v0, s20, #6
    v.insert     v3, s3, #6
    s.lshri      s3, s19, #32
    s.ashri      s20, s18, #32
    s.shli       s18, s5, #32
    v.extract    s5, v9, #10
    v.insert     v0, s19, #7
    v.insert     v3, s3, #7
    s.lshri      s3, s20, #32
    s.ashri      s19, s18, #32
    s.shli       s18, s5, #32
    v.extract    s5, v9, #11
    v.insert     v0, s20, #8
    v.insert     v3, s3, #8
    s.lshri      s3, s19, #32
    s.ashri      s20, s18, #32
    s.shli       s18, s5, #32
    v.extract    s5, v9, #12
    v.insert     v0, s19, #9
    v.insert     v3, s3, #9
    s.lshri      s3, s20, #32
    s.ashri      s19, s18, #32
    s.shli       s18, s5, #32
    v.extract    s5, v9, #13
    v.insert     v0, s20, #10
    v.insert     v3, s3, #10
    s.lshri      s3, s19, #32
    s.ashri      s20, s18, #32
    s.shli       s18, s5, #32
    v.extract    s5, v9, #14
    v.insert     v0, s19, #11
    v.insert     v3, s3, #11
    s.lshri      s3, s20, #32
    s.ashri      s19, s18, #32
    s.shli       s18, s5, #32
    v.extract    s5, v9, #15
    v.insert     v0, s20, #12
    v.insert     v3, s3, #12
    s.lshri      s3, s19, #32
    s.ashri      s20, s18, #32
    s.shli       s18, s5, #32
    v.insert     v0, s19, #13
    v.insert     v3, s3, #13
    s.lshri      s3, s20, #32
    s.ashri      s5, s18, #32
    v.insert     v0, s20, #14
    v.insert     v3, s3, #14
    s.lshri      s3, s5, #32
    v.insert     v0, s5, #15
    v.insert     v3, s3, #15
    v.extract    s3, v0, #0
    v.extract    s5, v3, #0
    s.shli       s18, s5, #32
    v.extract    s5, v3, #1
    s.or         s19, s3, s18
    s.shli       s3, s5, #32
    v.extract    s5, v0, #1
    v.extract    s18, v3, #2
    v.movi       v1, #0
    s.cmp.le     s20, s19, s4
    s.or         s19, s5, s3
    s.shli       s3, s18, #32
    v.extract    s5, v0, #2
    v.extract    s18, v3, #3
    v.insert     v1, s20, #0
    s.cmp.le     s20, s19, s4
    s.or         s19, s5, s3
    s.shli       s3, s18, #32
    v.extract    s5, v0, #3
    v.extract    s18, v3, #4
    v.insert     v1, s20, #1
    s.cmp.le     s20, s19, s4
    s.or         s19, s5, s3
    s.shli       s3, s18, #32
    v.extract    s5, v0, #4
    v.extract    s18, v3, #5
    v.insert     v1, s20, #2
    s.cmp.le     s20, s19, s4
    s.or         s19, s5, s3
    s.shli       s3, s18, #32
    v.extract    s5, v0, #5
    v.extract    s18, v3, #6
    v.insert     v1, s20, #3
    s.cmp.le     s20, s19, s4
    s.or         s4, s5, s3
    s.shli       s3, s18, #32
    v.extract    s5, v0, #6
    v.extract    s18, v3, #7
    v.insert     v1, s20, #4
    s.cmp.le     s19, s4, s6
    s.or         s4, s5, s3
    s.shli       s3, s18, #32
    v.extract    s5, v0, #7
    v.extract    s6, v3, #8
    v.insert     v1, s19, #5
    s.cmp.le     s18, s4, s7
    s.or         s4, s5, s3
    s.shli       s3, s6, #32
    v.extract    s5, v0, #8
    v.extract    s6, v3, #9
    v.insert     v1, s18, #6
    s.cmp.le     s7, s4, s9
    s.or         s4, s5, s3
    s.shli       s3, s6, #32
    v.extract    s5, v0, #9
    v.extract    s6, v3, #10
    v.insert     v1, s7, #7
    s.cmp.le     s7, s4, s2
    s.or         s2, s5, s3
    s.shli       s3, s6, #32
    v.extract    s4, v0, #10
    v.extract    s5, v3, #11
    v.insert     v1, s7, #8
    s.cmp.le     s6, s2, s11
    s.or         s2, s4, s3
    s.shli       s3, s5, #32
    v.extract    s4, v0, #11
    v.extract    s5, v3, #12
    v.insert     v1, s6, #9
    s.cmp.le     s6, s2, s12
    s.or         s2, s4, s3
    s.shli       s3, s5, #32
    v.extract    s4, v0, #12
    v.extract    s5, v3, #13
    v.insert     v1, s6, #10
    s.cmp.le     s6, s2, s13
    s.or         s2, s4, s3
    s.shli       s3, s5, #32
    v.extract    s4, v0, #13
    v.extract    s5, v3, #14
    v.insert     v1, s6, #11
    s.cmp.le     s6, s2, s14
    s.or         s2, s4, s3
    s.shli       s3, s5, #32
    v.extract    s4, v0, #14
    v.extract    s5, v3, #15
    v.insert     v1, s6, #12
    s.cmp.le     s6, s2, s15
    s.or         s2, s4, s3
    s.shli       s3, s5, #32
    v.extract    s4, v0, #15
    v.insert     v1, s6, #13
    s.cmp.le     s5, s2, s16
    s.or         s2, s4, s3
    v.insert     v1, s5, #14
    s.cmp.le     s3, s2, s17
    v.movi       v0, #255
    v.movi       v2, #255
    vf.mul       v3, v10, v5
    v.insert     v1, s3, #15
    v.movi       v4, #0
    v.and        v5, v8, v0
    v.and        v0, v6, v2
    v.movi       v2, #0
    v.movi       v6, #1
    v.movi       v7, #0
    v.cmp.ne     p1, v1, v4
    v.cmp.eq     p2, v5, v0
    @p1 v.sel        v0, v3, v2
    @p2 v.sel        v1, v6, v7
    vf.neg       v2, v0
    vf.cvt.u32.f32 v0, v1
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    s.add        s1, s8, s2                      // &out_ptr0[...]
    vf.add       v1, v0, v2
    s.add        s3, s10, s2                     // &out_ptr1[...]
    v.st.w       [s1, #0], v2
    v.st.w       [s3, #0], v1
__rctx_next:
    exit
