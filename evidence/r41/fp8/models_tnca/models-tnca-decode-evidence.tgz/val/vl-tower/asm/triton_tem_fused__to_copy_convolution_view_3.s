    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    s.rdspecial  s2, pid.y
    s.mul        s3, s4, s1
    s.mul        s4, s2, s1
    s.rdspecial  s2, role_id
    s.movz       s5, #6720
    s.rdspecial  s6, arg_base
    s.mul        s7, s2, s5
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s3
    s.ld.d       s2, [s6, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.add        v2, v1, v0
    v.movi       v1, #1536
    v.splat      v3, s4
    v.mul        v4, v2, v1
    s.add        s5, s2, s7                      // this context's own scratch
    s.movz       s2, #0
    v.add        v5, v3, v0
    v.extract    s6, v4, #0
    v.extract    s7, v4, #1
    s.addi       s8, s5, #0
    v.splat      v3, s2
    v.splat      v6, s6
    s.rdspecial  s6, arg_base
    v.splat      v7, s7
    s.addi       s7, s8, #64
    s.addi       s9, s8, #128
    s.addi       s10, s8, #192
    s.addi       s11, s8, #256
    s.addi       s12, s8, #320
    s.addi       s13, s8, #384
    s.addi       s14, s8, #448
    s.addi       s15, s8, #512
    s.addi       s16, s8, #576
    s.addi       s17, s8, #640
    s.addi       s18, s8, #704
    s.addi       s19, s8, #768
    s.addi       s20, s8, #832
    s.addi       s21, s8, #896
    s.addi       s22, s8, #960
    s.addi       s23, s5, #1024
    v.add        v8, v3, v6
    s.ld.d       s24, [s6, #0]                   // arg_X: device_ptr64 at arg_base+0
    v.add        v6, v3, v7
    s.movz       s25, #1536
    s.ld.d       s25, [s6, #8]                   // arg_W: device_ptr64 at arg_base+8
    s.movz       s26, #512
    s.movz       s27, #1
    s.ld.d       s28, [s6, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    v.extract    s6, v4, #2
    v.extract    s29, v4, #3
    v.extract    s30, v4, #4
    v.extract    s31, v4, #5
    v.extract    s32, v4, #6
    v.splat      v7, s6
    v.extract    s6, v4, #7
    v.splat      v9, s29
    v.extract    s29, v4, #8
    v.splat      v10, s30
    v.extract    s30, v4, #9
    v.add        v11, v3, v7
    v.add        v7, v3, v9
    v.add        v9, v3, v10
    v.st.w       [s8, #0], v8
    v.extract    s8, v4, #10
    v.splat      v8, s31
    v.extract    s31, v4, #11
    v.add        v10, v3, v8
    v.st.w       [s7, #0], v6
    v.extract    s7, v4, #12
    v.splat      v6, s32
    v.extract    s32, v4, #13
    v.add        v8, v3, v6
    v.st.w       [s9, #0], v11
    v.extract    s9, v4, #14
    v.splat      v6, s6
    v.extract    s6, v4, #15
    v.splat      v4, s29
    v.add        v11, v3, v6
    v.add        v6, v3, v4
    v.st.w       [s10, #0], v7
    v.splat      v4, s30
    v.mul        v7, v5, v1
    v.add        v1, v3, v4
    v.st.w       [s11, #0], v9
    v.splat      v4, s8
    s.addi       s8, s2, #0
    v.add        v9, v3, v4
    v.st.w       [s12, #0], v10
    v.splat      v4, s31
    v.add        v10, v3, v4
    v.st.w       [s13, #0], v8
    v.splat      v4, s7
    v.add        v8, v3, v4
    v.st.w       [s14, #0], v11
    v.splat      v4, s32
    v.add        v11, v3, v4
    v.st.w       [s15, #0], v6
    v.splat      v4, s9
    v.add        v6, v3, v4
    v.st.w       [s16, #0], v1
    v.splat      v1, s6
    v.add        v4, v3, v1
    v.splat      v1, s2
    v.add        v3, v1, v7
    v.st.w       [s17, #0], v9
    v.st.w       [s18, #0], v10
    v.st.w       [s19, #0], v8
    v.st.w       [s20, #0], v11
    v.st.w       [s21, #0], v6
    v.st.w       [s22, #0], v4
    fence.acq_rel.device
    v.st.w       [s23, #0], v3
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_1:
    s.cmp.ge     s6, s8, s26
    br.nz        s6, endfor_2
    s.movz       s6, #0
    s.movz       s7, #0
    s.cmp.lt     s9, s8, s6
    s.movz       s6, #0
    s.sub        s10, s7, s9
    s.movz       s7, #0
    s.cmp.lt     s9, s1, s6
    s.xor        s6, s8, s10
    s.sub        s11, s7, s9
    s.sub        s7, s6, s10
    s.xor        s6, s10, s11
    s.lshri      s9, s7, #4
    s.movz       s10, #0
    s.xor        s12, s9, s6
    s.movz       s13, #0
    s.sub        s14, s12, s6
    s.movz       s6, #0
    s.cmp.lt     s12, s14, s10
    s.movz       s10, #0
    s.sub        s15, s13, s12
    s.cmp.lt     s12, s8, s6
    s.xor        s6, s14, s15
    s.sub        s13, s10, s12
    s.sub        s10, s6, s15
    s.xor        s6, s8, s13
    s.lshri      s12, s10, #4
    s.sub        s16, s6, s13
    s.muli       s6, s12, #16
    s.lshri      s12, s16, #4
    s.movz       s17, #0
    s.muli       s18, s12, #16
    s.cmp.lt     s12, s1, s17
    s.sub        s17, s10, s6
    s.movz       s6, #0
    s.xor        s10, s17, s15
    s.sub        s17, s16, s18
    s.sub        s16, s10, s15
    s.xor        s10, s17, s13
    s.movz       s15, #0
    s.movz       s17, #0
    s.sub        s18, s10, s13
    s.movz       s10, #0
    s.cmp.lt     s13, s14, s17
    s.cmp.lt     s17, s1, s6
    s.muli       s6, s9, #16
    s.sub        s9, s15, s12
    s.sub        s12, s10, s13
    s.movz       s10, #0
    s.movz       s13, #0
    s.sub        s15, s7, s6
    s.movz       s6, #0
    s.xor        s7, s1, s9
    s.cmp.lt     s15, s1, s10
    s.sub        s10, s6, s17
    s.xor        s6, s1, s11
    s.sub        s17, s7, s9
    s.xor        s7, s14, s12
    s.sub        s9, s13, s15
    s.sub        s13, s7, s12
    s.xor        s7, s12, s9
    s.lshri      s12, s13, #4
    s.movz       s14, #256
    s.xor        s15, s12, s7
    v.splat      v1, s16
    s.sub        s17, s15, s7
    v.splat      v3, s18
    s.mul        s7, s17, s14
    v.splat      v4, s17
    s.muli       s15, s12, #16
    s.sub        s12, s6, s11
    s.mul        s6, s16, s1
    s.addi       s11, s5, #0
    v.splat      v6, s7
    v.ld.w       v7, [s11, #0]
    s.movz       s7, #0
    v.splat      v8, s6
    v.extract    s6, v6, #0
    v.extract    s11, v8, #0
    v.splat      v9, s6
    v.splat      v10, s11
    s.add        s6, s7, s18                     // the tile origin
    v.movi       v11, #512
    v.add        v12, v9, v10
    v.splat      v9, s6
    v.mul        v10, v0, v11
    v.add        v11, v12, v9
    s.addi       s6, s5, #1088
    v.add        v12, v11, v10
    s.xor        s7, s1, s10
    v.add        v11, v7, v12
    s.xor        s11, s1, s9
    s.sub        s12, s7, s10
    s.addi       s7, s5, #64
    v.st.w       [s6, #0], v11
    v.extract    s10, v6, #1
    v.extract    s12, v8, #1
    v.splat      v7, s10
    v.splat      v11, s12
    s.addi       s10, s6, #64
    v.add        v12, v7, v11
    s.addi       s12, s5, #128
    v.add        v7, v12, v9
    s.sub        s18, s11, s9
    v.ld.w       v11, [s7, #0]
    v.add        v12, v7, v10
    v.extract    s7, v6, #2
    v.extract    s9, v8, #2
    v.splat      v7, s7
    v.splat      v13, s9
    s.addi       s7, s6, #128
    s.sub        s9, s13, s15
    v.add        v14, v7, v13
    s.addi       s9, s5, #192
    v.add        v7, v11, v12
    v.add        v11, v14, v9
    v.st.w       [s10, #0], v7
    v.add        v7, v11, v10
    v.extract    s10, v6, #3
    v.extract    s11, v8, #3
    v.splat      v11, s10
    v.splat      v12, s11
    s.addi       s10, s6, #192
    v.add        v13, v11, v12
    s.addi       s11, s5, #256
    v.add        v11, v13, v9
    v.ld.w       v12, [s12, #0]
    v.add        v13, v11, v10
    v.extract    s12, v6, #4
    v.extract    s13, v8, #4
    v.splat      v11, s12
    v.splat      v14, s13
    s.addi       s12, s6, #256
    v.add        v15, v11, v14
    s.addi       s13, s5, #320
    v.add        v11, v15, v9
    v.add        v14, v12, v7
    v.add        v7, v11, v10
    v.st.w       [s7, #0], v14
    v.extract    s7, v6, #5
    v.extract    s15, v8, #5
    v.splat      v11, s7
    v.splat      v12, s15
    s.addi       s7, s6, #320
    v.add        v14, v11, v12
    s.addi       s15, s5, #384
    v.add        v11, v14, v9
    v.ld.w       v12, [s9, #0]
    v.add        v14, v11, v10
    v.extract    s9, v6, #6
    v.splat      v11, s9
    v.extract    s9, v8, #6
    v.splat      v15, s9
    s.addi       s9, s6, #384
    v.add        v16, v11, v15
    v.add        v11, v16, v9
    v.add        v15, v12, v13
    v.add        v12, v11, v10
    v.st.w       [s10, #0], v15
    s.addi       s10, s5, #448
    v.ld.w       v11, [s11, #0]
    v.extract    s11, v6, #7
    v.splat      v13, s11
    v.extract    s11, v8, #7
    v.splat      v15, s11
    s.addi       s11, s6, #448
    v.add        v16, v13, v15
    v.add        v13, v16, v9
    v.add        v15, v11, v7
    v.add        v7, v13, v10
    v.st.w       [s12, #0], v15
    s.addi       s12, s5, #512
    v.ld.w       v11, [s13, #0]
    v.extract    s13, v6, #8
    v.splat      v13, s13
    v.extract    s13, v8, #8
    v.splat      v15, s13
    s.addi       s13, s6, #512
    v.add        v16, v13, v15
    v.add        v13, v16, v9
    v.add        v15, v11, v14
    v.add        v11, v13, v10
    v.st.w       [s7, #0], v15
    s.addi       s7, s5, #576
    v.ld.w       v13, [s15, #0]
    v.extract    s15, v6, #9
    v.splat      v14, s15
    v.extract    s15, v8, #9
    v.splat      v15, s15
    s.addi       s15, s6, #576
    v.add        v16, v14, v15
    v.add        v14, v16, v9
    v.add        v15, v13, v12
    v.add        v12, v14, v10
    v.st.w       [s9, #0], v15
    s.addi       s9, s5, #640
    v.ld.w       v13, [s10, #0]
    v.extract    s10, v6, #10
    v.splat      v14, s10
    v.extract    s10, v8, #10
    v.splat      v15, s10
    s.addi       s10, s6, #640
    v.add        v16, v14, v15
    v.add        v14, v16, v9
    v.add        v15, v13, v7
    v.add        v7, v14, v10
    v.st.w       [s11, #0], v15
    s.addi       s11, s5, #704
    v.ld.w       v13, [s12, #0]
    v.extract    s12, v6, #11
    v.splat      v14, s12
    v.extract    s12, v8, #11
    v.splat      v15, s12
    s.addi       s12, s6, #704
    v.add        v16, v14, v15
    v.add        v14, v16, v9
    v.add        v15, v13, v11
    v.add        v11, v14, v10
    v.st.w       [s13, #0], v15
    s.addi       s13, s5, #768
    v.ld.w       v13, [s7, #0]
    v.extract    s7, v6, #12
    v.splat      v14, s7
    v.extract    s7, v8, #12
    v.splat      v15, s7
    s.addi       s7, s6, #768
    v.add        v16, v14, v15
    v.add        v14, v16, v9
    v.add        v15, v13, v12
    v.add        v12, v14, v10
    v.st.w       [s15, #0], v15
    s.addi       s15, s5, #832
    v.ld.w       v13, [s9, #0]
    v.extract    s9, v6, #13
    v.splat      v14, s9
    v.extract    s9, v8, #13
    v.splat      v15, s9
    s.addi       s9, s6, #832
    v.add        v16, v14, v15
    v.add        v14, v16, v9
    v.add        v15, v13, v7
    v.add        v7, v14, v10
    v.st.w       [s10, #0], v15
    s.addi       s10, s5, #896
    v.ld.w       v13, [s11, #0]
    v.extract    s11, v6, #14
    v.splat      v14, s11
    v.extract    s11, v8, #14
    v.splat      v15, s11
    s.addi       s11, s6, #896
    v.add        v16, v14, v15
    s.addi       s18, s6, #960
    v.add        v14, v16, v9
    v.add        v15, v13, v11
    v.add        v11, v14, v10
    v.st.w       [s12, #0], v15
    s.addi       s6, s5, #960
    v.movi       v13, #256
    v.ld.w       v14, [s13, #0]
    v.movi       v15, #0
    v.movi       v16, #1
    v.movi       v17, #0
    v.extract    s12, v6, #15
    v.movi       v6, #1
    v.cmp.lt     p1, v2, v13
    v.movi       v13, #0
    v.cmp.ge     p2, v4, v15
    @p1 v.sel        v18, v16, v17
    v.add        v16, v14, v12
    v.splat      v12, s12
    v.st.w       [s7, #0], v16
    v.extract    s7, v8, #15
    v.movi       v8, #2
    v.splat      v14, s7
    @p2 v.sel        v16, v6, v13
    v.movi       v6, #1
    v.cmp.lt     p1, v4, v8
    v.add        v4, v12, v14
    v.add        v8, v4, v9
    v.ld.w       v4, [s15, #0]
    v.movi       v12, #0
    v.movi       v13, #1
    @p1 v.sel        v14, v6, v12
    v.movi       v6, #0
    v.cmp.ge     p1, v1, v15
    v.movi       v12, #16
    @p1 v.sel        v17, v13, v6
    v.cmp.lt     p1, v1, v12
    v.add        v1, v8, v10
    v.add        v6, v4, v7
    v.movi       v4, #1
    v.st.w       [s9, #0], v6
    v.movi       v6, #0
    v.cmp.ge     p2, v3, v15
    @p1 v.sel        v7, v4, v6
    v.ld.w       v4, [s10, #0]
    v.movi       v6, #1
    v.movi       v8, #0
    v.movi       v13, #1
    @p2 v.sel        v15, v6, v8
    v.movi       v6, #0
    v.cmp.lt     p1, v3, v12
    @p1 v.sel        v3, v13, v6
    v.movi       v6, #3
    v.add        v8, v4, v11
    v.cmp.lt     p1, v0, v6
    v.st.w       [s11, #0], v8
    s.addi       s7, s5, #1088
    s.addi       s9, s5, #2112
    v.ld.w       v4, [s6, #0]
    v.extract    s6, v18, #0
    v.extract    s10, v16, #0
    v.splat      v6, s6
    v.movi       v8, #0
    v.splat      v11, s10
    v.movi       v12, #0
    v.cmp.ne     p2, v6, v8
    v.cmp.ne     p3, v11, v12
    v.add        v6, v4, v1
    p.and        p4, p2, p3
    v.st.w       [s18, #0], v6
    v.extract    s6, v14, #0
    fence.acq_rel.device
    v.splat      v1, s6
    v.movi       v4, #0
    v.extract    s6, v17, #0
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v7, #0
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    v.ld.w       v6, [s7, #0]
    p.and        p4, p3, p2
    v.extract    s6, v15, #0
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #0
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v4
    p.and        p3, p4, p2
    v.extract    s6, v18, #1
    p.and        p2, p3, p1
    v.extract    s7, v16, #1
    v.splat      v1, s6
    v.movi       v4, #0
    v.splat      v8, s7
    v.movi       v11, #0
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.h v12, [s24, v6]             // index is in elements (ISA sec 9.1)
    v.extract    s6, v14, #1
    v.cmp.ne     p2, v1, v4
    v.cmp.ne     p3, v8, v11
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s6, v17, #1
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    s.addi       s6, s5, #1152
    p.and        p3, p4, p2
    v.extract    s7, v7, #1
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    v.st.w       [s9, #0], v12
    p.and        p4, p3, p2
    v.extract    s7, v15, #1
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s7, v3, #1
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.ld.w       v4, [s6, #0]
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #2
    p.and        p2, p3, p1
    v.extract    s7, v16, #2
    v.splat      v1, s6
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v8, [s24, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v6
    s.addi       s6, s9, #64
    v.splat      v1, s7
    v.movi       v4, #0
    v.extract    s7, v14, #2
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s7, v17, #2
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    s.addi       s7, s5, #1216
    p.and        p3, p4, p2
    v.extract    s10, v7, #2
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s10
    v.movi       v4, #0
    v.st.w       [s6, #0], v8
    p.and        p4, p3, p2
    v.extract    s6, v15, #2
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #2
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.ld.w       v4, [s7, #0]
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #3
    p.and        p2, p3, p1
    v.extract    s7, v16, #3
    v.splat      v1, s6
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v8, [s24, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v6
    s.addi       s6, s9, #128
    v.splat      v1, s7
    v.movi       v4, #0
    v.extract    s7, v14, #3
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s7, v17, #3
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    s.addi       s7, s5, #1280
    p.and        p3, p4, p2
    v.extract    s10, v7, #3
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s10
    v.movi       v4, #0
    v.st.w       [s6, #0], v8
    p.and        p4, p3, p2
    v.extract    s6, v15, #3
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #3
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.ld.w       v4, [s7, #0]
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #4
    p.and        p2, p3, p1
    v.extract    s7, v16, #4
    v.splat      v1, s6
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v8, [s24, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v6
    s.addi       s6, s9, #192
    v.splat      v1, s7
    v.movi       v4, #0
    v.extract    s7, v14, #4
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s7, v17, #4
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    s.addi       s7, s5, #1344
    p.and        p3, p4, p2
    v.extract    s10, v7, #4
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s10
    v.movi       v4, #0
    v.st.w       [s6, #0], v8
    p.and        p4, p3, p2
    v.extract    s6, v15, #4
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #4
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.ld.w       v4, [s7, #0]
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #5
    p.and        p2, p3, p1
    v.extract    s7, v16, #5
    v.splat      v1, s6
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v8, [s24, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v6
    s.addi       s6, s9, #256
    v.splat      v1, s7
    v.movi       v4, #0
    v.extract    s7, v14, #5
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s7, v17, #5
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    s.addi       s7, s5, #1408
    p.and        p3, p4, p2
    v.extract    s10, v7, #5
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s10
    v.movi       v4, #0
    v.st.w       [s6, #0], v8
    p.and        p4, p3, p2
    v.extract    s6, v15, #5
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #5
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.ld.w       v4, [s7, #0]
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #6
    p.and        p2, p3, p1
    v.extract    s7, v16, #6
    v.splat      v1, s6
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v8, [s24, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v6
    s.addi       s6, s9, #320
    v.splat      v1, s7
    v.movi       v4, #0
    v.extract    s7, v14, #6
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s7, v17, #6
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    s.addi       s7, s5, #1472
    p.and        p3, p4, p2
    v.extract    s10, v7, #6
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s10
    v.movi       v4, #0
    v.st.w       [s6, #0], v8
    p.and        p4, p3, p2
    v.extract    s6, v15, #6
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #6
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.ld.w       v4, [s7, #0]
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #7
    p.and        p2, p3, p1
    v.extract    s7, v16, #7
    v.splat      v1, s6
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v8, [s24, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v6
    s.addi       s6, s9, #384
    v.splat      v1, s7
    v.movi       v4, #0
    v.extract    s7, v14, #7
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s7, v17, #7
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    s.addi       s7, s5, #1536
    p.and        p3, p4, p2
    v.extract    s10, v7, #7
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s10
    v.movi       v4, #0
    v.st.w       [s6, #0], v8
    p.and        p4, p3, p2
    v.extract    s6, v15, #7
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #7
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.ld.w       v4, [s7, #0]
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #8
    p.and        p2, p3, p1
    v.extract    s7, v16, #8
    v.splat      v1, s6
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v8, [s24, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v6
    s.addi       s6, s9, #448
    v.splat      v1, s7
    v.movi       v4, #0
    v.extract    s7, v14, #8
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s7, v17, #8
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    s.addi       s7, s5, #1600
    p.and        p3, p4, p2
    v.extract    s10, v7, #8
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s10
    v.movi       v4, #0
    v.st.w       [s6, #0], v8
    p.and        p4, p3, p2
    v.extract    s6, v15, #8
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #8
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.ld.w       v4, [s7, #0]
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #9
    p.and        p2, p3, p1
    v.extract    s7, v16, #9
    v.splat      v1, s6
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v8, [s24, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v6
    s.addi       s6, s9, #512
    v.splat      v1, s7
    v.movi       v4, #0
    v.extract    s7, v14, #9
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s7, v17, #9
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    s.addi       s7, s5, #1664
    p.and        p3, p4, p2
    v.extract    s10, v7, #9
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s10
    v.movi       v4, #0
    v.st.w       [s6, #0], v8
    p.and        p4, p3, p2
    v.extract    s6, v15, #9
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #9
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.ld.w       v4, [s7, #0]
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #10
    p.and        p2, p3, p1
    v.extract    s7, v16, #10
    v.splat      v1, s6
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v8, [s24, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v6
    s.addi       s6, s9, #576
    v.splat      v1, s7
    v.movi       v4, #0
    v.extract    s7, v14, #10
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s7, v17, #10
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    s.addi       s7, s5, #1728
    p.and        p3, p4, p2
    v.extract    s10, v7, #10
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s10
    v.movi       v4, #0
    v.st.w       [s6, #0], v8
    p.and        p4, p3, p2
    v.extract    s6, v15, #10
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #10
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.ld.w       v4, [s7, #0]
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #11
    p.and        p2, p3, p1
    v.extract    s7, v16, #11
    v.splat      v1, s6
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v8, [s24, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v6
    s.addi       s6, s9, #640
    v.splat      v1, s7
    v.movi       v4, #0
    v.extract    s7, v14, #11
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s7, v17, #11
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    s.addi       s7, s5, #1792
    p.and        p3, p4, p2
    v.extract    s10, v7, #11
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s10
    v.movi       v4, #0
    v.st.w       [s6, #0], v8
    p.and        p4, p3, p2
    v.extract    s6, v15, #11
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #11
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.ld.w       v4, [s7, #0]
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #12
    p.and        p2, p3, p1
    v.extract    s7, v16, #12
    v.splat      v1, s6
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v8, [s24, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v6
    s.addi       s6, s9, #704
    v.splat      v1, s7
    v.movi       v4, #0
    v.extract    s7, v14, #12
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s7, v17, #12
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    s.addi       s7, s5, #1856
    p.and        p3, p4, p2
    v.extract    s10, v7, #12
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s10
    v.movi       v4, #0
    v.st.w       [s6, #0], v8
    p.and        p4, p3, p2
    v.extract    s6, v15, #12
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #12
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.ld.w       v4, [s7, #0]
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #13
    p.and        p2, p3, p1
    v.extract    s7, v16, #13
    v.splat      v1, s6
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v8, [s24, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v6
    s.addi       s6, s9, #768
    v.splat      v1, s7
    v.movi       v4, #0
    v.extract    s7, v14, #13
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s7, v17, #13
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    s.addi       s7, s5, #1920
    p.and        p3, p4, p2
    v.extract    s10, v7, #13
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s10
    v.movi       v4, #0
    v.st.w       [s6, #0], v8
    p.and        p4, p3, p2
    v.extract    s6, v15, #13
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #13
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.ld.w       v4, [s7, #0]
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #14
    p.and        p2, p3, p1
    v.extract    s7, v16, #14
    v.splat      v1, s6
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v8, [s24, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v6
    s.addi       s6, s9, #832
    v.splat      v1, s7
    v.movi       v4, #0
    v.extract    s7, v14, #14
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s7, v17, #14
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    s.addi       s7, s5, #1984
    p.and        p3, p4, p2
    v.extract    s10, v7, #14
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s10
    v.movi       v4, #0
    v.st.w       [s6, #0], v8
    p.and        p4, p3, p2
    v.extract    s6, v15, #14
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #14
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.ld.w       v4, [s7, #0]
    v.movi       v6, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v6
    p.and        p3, p4, p2
    v.extract    s6, v18, #15
    p.and        p2, p3, p1
    v.extract    s7, v16, #15
    v.splat      v1, s6
    v.movi       v6, #0
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v8, [s24, v4]              // index is in elements (ISA sec 9.1)
    v.cmp.ne     p2, v1, v6
    s.addi       s6, s9, #896
    v.splat      v1, s7
    v.movi       v4, #0
    v.extract    s7, v14, #15
    v.cmp.ne     p3, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    p.and        p4, p2, p3
    v.extract    s7, v17, #15
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s7
    v.movi       v4, #0
    s.addi       s7, s5, #2048
    p.and        p3, p4, p2
    v.extract    s10, v7, #15
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s10
    v.movi       v4, #0
    v.st.w       [s6, #0], v8
    p.and        p4, p3, p2
    v.extract    s6, v15, #15
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.movi       v4, #0
    p.and        p3, p4, p2
    v.extract    s6, v3, #15
    v.cmp.ne     p2, v1, v4
    v.splat      v1, s6
    v.ld.w       v3, [s7, #0]
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v4
    p.and        p3, p4, p2
    s.mul        s6, s17, s14
    p.and        p2, p3, p1
    s.mul        s7, s16, s1
    s.addi       s10, s9, #960
    s.addi       s9, s5, #1024
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.h v1, [s24, v3]              // index is in elements (ISA sec 9.1)
    s.movz       s11, #0
    s.movz       s12, #0
    s.add        s13, s11, s6                    // the tile origin
    v.extract    s6, v10, #0
    v.splat      v3, s6
    v.st.w       [s10, #0], v1
    fence.acq_rel.device
    v.splat      v1, s13
    s.add        s6, s12, s7                     // the tile origin
    v.add        v4, v3, v1
    v.splat      v3, s6
    s.addi       s6, s5, #3136
    v.add        v6, v4, v3
    s.addi       s7, s5, #1024
    v.add        v4, v6, v9
    v.ld.w       v6, [s9, #0]
    v.extract    s9, v10, #1
    v.splat      v7, s9
    s.addi       s9, s6, #64
    v.add        v8, v7, v1
    s.addi       s10, s5, #1024
    v.add        v7, v8, v3
    v.extract    s11, v10, #2
    v.add        v8, v7, v9
    v.splat      v7, s11
    v.add        v11, v6, v4
    v.add        v4, v7, v1
    v.st.w       [s6, #0], v11
    v.add        v6, v4, v3
    s.addi       s11, s6, #128
    v.add        v4, v6, v9
    s.addi       s12, s5, #1024
    v.extract    s13, v10, #3
    v.splat      v6, s13
    s.addi       s13, s6, #192
    v.add        v7, v6, v1
    s.addi       s14, s5, #1024
    v.ld.w       v6, [s7, #0]
    v.add        v11, v7, v3
    v.extract    s7, v10, #4
    v.add        v7, v11, v9
    v.splat      v11, s7
    s.addi       s7, s6, #256
    v.add        v12, v11, v1
    s.addi       s15, s5, #1024
    v.add        v11, v12, v3
    v.extract    s16, v10, #5
    v.add        v12, v6, v8
    v.add        v6, v11, v9
    v.st.w       [s9, #0], v12
    v.splat      v8, s16
    s.addi       s9, s6, #320
    v.add        v11, v8, v1
    s.addi       s16, s5, #1024
    v.add        v8, v11, v3
    v.extract    s17, v10, #6
    v.add        v11, v8, v9
    v.splat      v8, s17
    s.addi       s17, s6, #384
    v.ld.w       v12, [s10, #0]
    v.add        v13, v8, v1
    s.addi       s10, s5, #1024
    v.add        v8, v13, v3
    v.extract    s18, v10, #7
    v.add        v13, v8, v9
    v.splat      v8, s18
    s.addi       s18, s6, #448
    v.add        v14, v8, v1
    v.add        v8, v12, v4
    v.add        v4, v14, v3
    v.st.w       [s11, #0], v8
    v.add        v8, v4, v9
    v.ld.w       v4, [s12, #0]
    s.addi       s11, s5, #1024
    v.extract    s12, v10, #8
    v.splat      v12, s12
    s.addi       s12, s6, #512
    v.add        v14, v12, v1
    v.add        v12, v4, v7
    v.add        v4, v14, v3
    v.st.w       [s13, #0], v12
    v.add        v7, v4, v9
    v.ld.w       v4, [s14, #0]
    s.addi       s13, s5, #1024
    v.extract    s14, v10, #9
    v.splat      v12, s14
    s.addi       s14, s6, #576
    v.add        v14, v12, v1
    v.add        v12, v4, v6
    v.add        v4, v14, v3
    v.st.w       [s7, #0], v12
    v.add        v6, v4, v9
    v.ld.w       v4, [s15, #0]
    s.addi       s7, s5, #1024
    v.extract    s15, v10, #10
    v.splat      v12, s15
    s.addi       s15, s6, #640
    v.add        v14, v12, v1
    v.add        v12, v4, v11
    v.add        v4, v14, v3
    v.st.w       [s9, #0], v12
    v.add        v11, v4, v9
    v.ld.w       v4, [s16, #0]
    s.addi       s9, s5, #1024
    v.extract    s16, v10, #11
    v.splat      v12, s16
    s.addi       s16, s6, #704
    v.add        v14, v12, v1
    v.add        v12, v4, v13
    v.add        v4, v14, v3
    v.st.w       [s17, #0], v12
    v.add        v12, v4, v9
    v.ld.w       v4, [s10, #0]
    s.addi       s10, s5, #1024
    v.extract    s17, v10, #12
    v.splat      v13, s17
    s.addi       s17, s6, #768
    v.add        v14, v13, v1
    v.add        v13, v4, v8
    v.add        v4, v14, v3
    v.st.w       [s18, #0], v13
    v.add        v8, v4, v9
    v.ld.w       v4, [s11, #0]
    s.addi       s11, s5, #1024
    v.extract    s18, v10, #13
    v.splat      v13, s18
    s.addi       s18, s6, #832
    v.add        v14, v13, v1
    v.add        v13, v4, v7
    v.add        v4, v14, v3
    v.st.w       [s12, #0], v13
    v.add        v7, v4, v9
    v.ld.w       v4, [s13, #0]
    s.addi       s12, s5, #1024
    v.extract    s13, v10, #14
    v.splat      v13, s13
    s.addi       s13, s6, #896
    v.add        v14, v13, v1
    v.add        v13, v4, v6
    v.add        v4, v14, v3
    v.st.w       [s14, #0], v13
    v.add        v6, v4, v9
    v.ld.w       v4, [s7, #0]
    s.addi       s7, s5, #1024
    v.extract    s14, v10, #15
    v.splat      v10, s14
    s.addi       s14, s6, #960
    v.add        v13, v10, v1
    v.add        v1, v4, v11
    v.add        v4, v13, v3
    v.st.w       [s15, #0], v1
    v.add        v1, v4, v9
    v.ld.w       v3, [s9, #0]
    s.addi       s6, s5, #3136
    s.movz       s9, #3
    v.splat      v4, s2
    s.addi       s15, s5, #4160
    v.add        v9, v3, v12
    v.splat      v3, s9
    v.st.w       [s16, #0], v9
    s.movz       s16, #0
    v.cmp.lt     p1, v4, v3
    s.add        s19, s16, s4                    // the tile origin
    v.ld.w       v4, [s10, #0]
    v.iota       v9                              // arange(0, VLEN)
    v.splat      v10, s19
    s.movz       s10, #1024
    v.add        v11, v9, v10
    v.splat      v9, s10
    v.cmp.lt     p2, v11, v9
    v.add        v9, v4, v8
    p.and        p3, p1, p2
    v.st.w       [s17, #0], v9
    s.addi       s10, s15, #64
    v.ld.w       v4, [s11, #0]
    s.addi       s11, s5, #3200
    v.splat      v8, s27
    v.cmp.lt     p1, v8, v3
    p.and        p4, p1, p2
    v.add        v8, v4, v7
    v.st.w       [s18, #0], v8
    s.addi       s16, s5, #3264
    s.addi       s17, s15, #128
    v.ld.w       v4, [s12, #0]
    s.movz       s12, #2
    v.splat      v7, s12
    v.cmp.lt     p1, v7, v3
    p.and        p5, p1, p2
    v.add        v7, v4, v6
    s.addi       s12, s15, #192
    v.st.w       [s13, #0], v7
    s.addi       s13, s5, #3328
    v.splat      v4, s9
    v.ld.w       v6, [s7, #0]
    s.addi       s7, s5, #3392
    s.addi       s9, s15, #256
    v.add        v7, v6, v1
    v.st.w       [s14, #0], v7
    fence.acq_rel.device
    s.movz       s14, #4
    v.splat      v1, s14
    v.ld.w       v6, [s6, #0]
    s.addi       s6, s5, #3456
    s.movz       s14, #5
    s.addi       s18, s15, #320
    v.splat      v7, s14
    s.addi       s14, s5, #3520
    s.addi       s19, s15, #384
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v8, [s25, v6]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    s.movz       s20, #6
    v.st.w       [s15, #0], v8
    v.splat      v4, s20
    v.ld.w       v6, [s11, #0]
    s.addi       s11, s5, #3584
    s.addi       s20, s15, #448
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v8, [s25, v6]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.st.w       [s10, #0], v8
    s.movz       s10, #7
    v.splat      v1, s10
    v.ld.w       v6, [s16, #0]
    s.addi       s10, s5, #3648
    s.addi       s16, s15, #512
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v8, [s25, v6]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v3
    p.and        p5, p1, p2
    v.st.w       [s17, #0], v8
    s.movz       s17, #8
    v.splat      v6, s17
    v.ld.w       v7, [s13, #0]
    s.addi       s13, s15, #576
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v8, [s25, v7]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    s.addi       s17, s5, #3712
    v.st.w       [s12, #0], v8
    s.movz       s12, #9
    v.splat      v4, s12
    v.ld.w       v7, [s7, #0]
    s.addi       s7, s15, #640
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v8, [s25, v7]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s12, s5, #3776
    v.st.w       [s9, #0], v8
    s.movz       s9, #10
    v.splat      v1, s9
    v.ld.w       v7, [s6, #0]
    s.addi       s6, s15, #704
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v8, [s25, v7]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v3
    p.and        p5, p1, p2
    s.addi       s9, s5, #3840
    v.st.w       [s18, #0], v8
    s.movz       s18, #11
    v.splat      v6, s18
    v.ld.w       v7, [s14, #0]
    s.addi       s14, s15, #768
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v8, [s25, v7]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    s.addi       s18, s5, #3904
    v.st.w       [s19, #0], v8
    s.movz       s19, #12
    v.splat      v4, s19
    v.ld.w       v7, [s11, #0]
    s.addi       s11, s15, #832
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v8, [s25, v7]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s19, s5, #3968
    v.st.w       [s20, #0], v8
    s.movz       s20, #13
    v.splat      v1, s20
    v.ld.w       v7, [s10, #0]
    s.addi       s10, s15, #896
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v8, [s25, v7]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v3
    p.and        p5, p1, p2
    s.addi       s20, s5, #4032
    v.st.w       [s16, #0], v8
    s.movz       s16, #14
    v.splat      v6, s16
    v.ld.w       v7, [s17, #0]
    s.addi       s16, s15, #960
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v8, [s25, v7]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    s.addi       s15, s5, #4096
    v.st.w       [s13, #0], v8
    s.movz       s13, #15
    v.splat      v4, s13
    v.ld.w       v7, [s12, #0]
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v8, [s25, v7]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s12, s5, #5184                  // 512 bytes of repack scratch
    v.st.w       [s7, #0], v8
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s7, s5, #2112
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s5, #2176
    s.addi       s13, s12, #32                   // row 1
    s.addi       s17, s5, #2240
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v7, [s25, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v3
    p.and        p5, p1, p2
    v.st.w       [s6, #0], v7
    s.addi       s6, s12, #64                    // row 2
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s5, #2304
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s25, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    v.st.w       [s14, #0], v6
    s.addi       s14, s12, #96                   // row 3
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s5, #2368
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.h v3, [s25, v1]              // index is in elements (ISA sec 9.1)
    v.st.w       [s11, #0], v3
    s.addi       s11, s12, #128                  // row 4
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s5, #2432
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.h v3, [s25, v1]              // index is in elements (ISA sec 9.1)
    v.st.w       [s10, #0], v3
    s.addi       s10, s12, #160                  // row 5
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s5, #2496
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v3, [s25, v1]              // index is in elements (ISA sec 9.1)
    s.addi       s21, s12, #192                  // row 6
    v.st.w       [s16, #0], v3
    fence.acq_rel.device
    s.addi       s16, s5, #2560
    v.ld.w       v1, [s7, #0]
    s.addi       s7, s12, #224                   // row 7
    v.st.h       [s12, #0], v1
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s5, #2624
    v.st.h       [s13, #0], v1
    s.addi       s13, s12, #256                  // row 8
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s5, #2688
    v.st.h       [s6, #0], v1
    s.addi       s6, s12, #288                   // row 9
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s5, #2752
    v.st.h       [s14, #0], v1
    s.addi       s14, s12, #320                  // row 10
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s5, #2816
    s.movz       s22, #0
    v.st.h       [s11, #0], v1
    s.addi       s11, s12, #352                  // row 11
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s5, #2880
    v.st.h       [s10, #0], v1
    s.addi       s10, s12, #384                  // row 12
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s5, #2944
    v.st.h       [s21, #0], v1
    s.addi       s21, s12, #416                  // row 13
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s5, #3008
    v.st.h       [s7, #0], v1
    s.addi       s7, s12, #448                   // row 14
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s5, #3072
    v.st.h       [s13, #0], v1
    s.addi       s13, s12, #480                  // row 15
    v.ld.w       v1, [s17, #0]
    s.addi       s17, s5, #5696                  // TensorMap 0: a repacked tile
    v.st.h       [s6, #0], v1
    s.movz       s6, #16
    v.ld.w       v1, [s18, #0]
    s.movz       s18, #16
    v.st.h       [s14, #0], v1
    s.movz       s14, #32
    v.ld.w       v1, [s19, #0]
    s.movz       s19, #2
    v.st.h       [s11, #0], v1
    .li       s11, #68719476752
    v.ld.w       v1, [s20, #0]
    .li       s20, #1108101562368
    v.st.h       [s10, #0], v1
    s.movz       s10, #0
    v.ld.w       v1, [s15, #0]
    // repack 16x16 bf16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s15, s5, #4160
    v.st.h       [s21, #0], v1
    s.addi       s21, s5, #5952                  // 512 bytes of repack scratch
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s5, #4224
    v.st.h       [s7, #0], v1
    s.addi       s7, s21, #32                    // row 1
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s5, #4288
    v.st.h       [s13, #0], v1
    s.addi       s13, s21, #64                   // row 2
    s.st.d       [s17, #0], s12
    s.addi       s12, s5, #4352
    s.st.d       [s17, #8], s6
    s.addi       s6, s21, #96                    // row 3
    s.st.d       [s17, #16], s18
    s.addi       s18, s5, #4416
    s.st.d       [s17, #48], s14
    s.addi       s14, s21, #128                  // row 4
    s.st.d       [s17, #56], s19
    s.addi       s19, s5, #4480
    s.st.d       [s17, #88], s11
    s.addi       s11, s21, #160                  // row 5
    s.st.d       [s17, #104], s20
    fence.release.device
    td.load      d0, [s17]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s17, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s20, s5, #4544
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s22, s10                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s23, s10                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s22, s17
    mb.wait      s17
    v.ld.w       v1, [s15, #0]
    s.addi       s10, s21, #192                  // row 6
    s.addi       s15, s5, #4608
    s.addi       s22, s21, #224                  // row 7
    v.st.h       [s21, #0], v1
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s5, #4672
    v.st.h       [s7, #0], v1
    s.addi       s7, s21, #256                   // row 8
    v.ld.w       v1, [s9, #0]
    s.addi       s9, s5, #4736
    v.st.h       [s13, #0], v1
    s.addi       s13, s21, #288                  // row 9
    v.ld.w       v1, [s12, #0]
    s.addi       s12, s5, #4800
    v.st.h       [s6, #0], v1
    s.addi       s6, s21, #320                   // row 10
    v.ld.w       v1, [s18, #0]
    s.addi       s18, s5, #4864
    s.movz       s23, #0
    v.st.h       [s14, #0], v1
    s.addi       s14, s21, #352                  // row 11
    v.ld.w       v1, [s19, #0]
    s.addi       s19, s5, #4928
    v.st.h       [s11, #0], v1
    s.addi       s11, s21, #384                  // row 12
    v.ld.w       v1, [s20, #0]
    s.addi       s20, s5, #4992
    v.st.h       [s10, #0], v1
    s.addi       s10, s21, #416                  // row 13
    v.ld.w       v1, [s15, #0]
    s.addi       s15, s5, #5056
    v.st.h       [s22, #0], v1
    s.addi       s22, s21, #448                  // row 14
    v.ld.w       v1, [s16, #0]
    s.addi       s16, s5, #5120
    s.addi       s23, s5, #6464                  // TensorMap 1: a repacked tile
    v.st.h       [s7, #0], v1
    s.addi       s7, s21, #480                   // row 15
    v.ld.w       v1, [s9, #0]
    s.movz       s9, #16
    v.st.h       [s13, #0], v1
    s.movz       s13, #16
    v.ld.w       v1, [s12, #0]
    s.movz       s12, #32
    s.add        s29, s8, s27
    v.st.h       [s6, #0], v1
    s.movz       s6, #2
    v.ld.w       v1, [s18, #0]
    .li       s18, #68719476752
    v.st.h       [s14, #0], v1
    .li       s14, #1108101562368
    v.ld.w       v1, [s19, #0]
    s.movz       s19, #0
    v.st.h       [s11, #0], v1
    s.movz       s11, #1
    v.ld.w       v1, [s20, #0]
    v.st.h       [s10, #0], v1
    v.ld.w       v1, [s15, #0]
    v.st.h       [s22, #0], v1
    v.ld.w       v1, [s16, #0]
    v.st.h       [s7, #0], v1
    s.st.d       [s23, #0], s21
    s.st.d       [s23, #8], s9
    s.st.d       [s23, #16], s13
    s.st.d       [s23, #48], s12
    s.st.d       [s23, #56], s6
    s.st.d       [s23, #88], s18
    s.st.d       [s23, #104], s14
    fence.release.device
    td.load      d1, [s23]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s6, b1, #0, #1                  // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s9, s19                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s10, s19                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s9, s6
    mb.wait      s6
    mb.arm       s7, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v56, v48, s7
    mb.wait      s7
    s.mov        s8, s29
    br.nz        s11, for_1
endfor_2:
    v.movi       v0, #256
    v.movi       v1, #1
    v.movi       v3, #0
    v.cmp.lt     p1, v2, v0
    s.muli       s1, s4, #2                      // a runtime tile origin, x2
    @p1 v.sel        v0, v1, v3
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    s.muli       s4, s3, #2048                   // a runtime tile origin, x2048
    a.vread      v1, a0, s2
    v.extract    s2, v0, #0
    v.movi       v2, #1024
    v.splat      v3, s2
    v.movi       v4, #0
    s.add        s2, s28, s1                     // the tile origin
    vf.cvt.f32.bf16 v6, v1
    v.cmp.lt     p1, v5, v2
    v.cmp.ne     p2, v3, v4
    s.add        s1, s2, s4                      // the tile origin
    p.and        p3, p2, p1
    s.movz       s2, #1
    @p3 v.st.h       [s1, #0], v6
    a.vread      v1, a0, s2
    v.extract    s2, v0, #1
    v.splat      v2, s2
    v.movi       v3, #0
    vf.cvt.f32.bf16 v4, v1
    v.cmp.ne     p2, v2, v3
    s.addi       s2, s1, #2048                   // row 1
    p.and        p3, p2, p1
    s.movz       s3, #2
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a0, s3
    v.extract    s2, v0, #2
    v.splat      v2, s2
    v.movi       v3, #0
    vf.cvt.f32.bf16 v4, v1
    v.cmp.ne     p2, v2, v3
    s.addi       s2, s1, #4096                   // row 2
    p.and        p3, p2, p1
    s.movz       s3, #3
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a0, s3
    v.extract    s2, v0, #3
    v.splat      v2, s2
    v.movi       v3, #0
    vf.cvt.f32.bf16 v4, v1
    v.cmp.ne     p2, v2, v3
    s.addi       s2, s1, #6144                   // row 3
    p.and        p3, p2, p1
    s.movz       s3, #4
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a0, s3
    v.extract    s2, v0, #4
    v.splat      v2, s2
    v.movi       v3, #0
    vf.cvt.f32.bf16 v4, v1
    v.cmp.ne     p2, v2, v3
    s.addi       s2, s1, #8192                   // row 4
    p.and        p3, p2, p1
    s.movz       s3, #5
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a0, s3
    v.extract    s2, v0, #5
    v.splat      v2, s2
    v.movi       v3, #0
    vf.cvt.f32.bf16 v4, v1
    v.cmp.ne     p2, v2, v3
    s.addi       s2, s1, #10240                  // row 5
    p.and        p3, p2, p1
    s.movz       s3, #6
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a0, s3
    v.extract    s2, v0, #6
    v.splat      v2, s2
    v.movi       v3, #0
    vf.cvt.f32.bf16 v4, v1
    v.cmp.ne     p2, v2, v3
    s.addi       s2, s1, #12288                  // row 6
    p.and        p3, p2, p1
    s.movz       s3, #7
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a0, s3
    v.extract    s2, v0, #7
    v.splat      v2, s2
    v.movi       v3, #0
    vf.cvt.f32.bf16 v4, v1
    v.cmp.ne     p2, v2, v3
    s.addi       s2, s1, #14336                  // row 7
    p.and        p3, p2, p1
    s.movz       s3, #8
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a0, s3
    v.extract    s2, v0, #8
    v.splat      v2, s2
    v.movi       v3, #0
    vf.cvt.f32.bf16 v4, v1
    v.cmp.ne     p2, v2, v3
    s.addi       s2, s1, #16384                  // row 8
    p.and        p3, p2, p1
    s.movz       s3, #9
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a0, s3
    v.extract    s2, v0, #9
    v.splat      v2, s2
    v.movi       v3, #0
    vf.cvt.f32.bf16 v4, v1
    v.cmp.ne     p2, v2, v3
    s.addi       s2, s1, #18432                  // row 9
    p.and        p3, p2, p1
    s.movz       s3, #10
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a0, s3
    v.extract    s2, v0, #10
    v.splat      v2, s2
    v.movi       v3, #0
    vf.cvt.f32.bf16 v4, v1
    v.cmp.ne     p2, v2, v3
    s.addi       s2, s1, #20480                  // row 10
    p.and        p3, p2, p1
    s.movz       s3, #11
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a0, s3
    v.extract    s2, v0, #11
    v.splat      v2, s2
    v.movi       v3, #0
    vf.cvt.f32.bf16 v4, v1
    v.cmp.ne     p2, v2, v3
    s.addi       s2, s1, #22528                  // row 11
    p.and        p3, p2, p1
    s.movz       s3, #12
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a0, s3
    v.extract    s2, v0, #12
    v.splat      v2, s2
    v.movi       v3, #0
    vf.cvt.f32.bf16 v4, v1
    v.cmp.ne     p2, v2, v3
    s.addi       s2, s1, #24576                  // row 12
    p.and        p3, p2, p1
    s.movz       s3, #13
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a0, s3
    v.extract    s2, v0, #13
    v.splat      v2, s2
    v.movi       v3, #0
    vf.cvt.f32.bf16 v4, v1
    v.cmp.ne     p2, v2, v3
    s.addi       s2, s1, #26624                  // row 13
    p.and        p3, p2, p1
    s.movz       s3, #14
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a0, s3
    v.extract    s2, v0, #14
    v.splat      v2, s2
    v.movi       v3, #0
    vf.cvt.f32.bf16 v4, v1
    v.cmp.ne     p2, v2, v3
    s.addi       s2, s1, #28672                  // row 14
    p.and        p3, p2, p1
    s.movz       s3, #15
    @p3 v.st.h       [s2, #0], v4
    a.vread      v1, a0, s3
    v.extract    s2, v0, #15
    v.splat      v0, s2
    v.movi       v2, #0
    vf.cvt.f32.bf16 v3, v1
    v.cmp.ne     p2, v0, v2
    s.addi       s2, s1, #30720                  // row 15
    p.and        p3, p2, p1
    @p3 v.st.h       [s2, #0], v3
__rctx_next:
    exit
