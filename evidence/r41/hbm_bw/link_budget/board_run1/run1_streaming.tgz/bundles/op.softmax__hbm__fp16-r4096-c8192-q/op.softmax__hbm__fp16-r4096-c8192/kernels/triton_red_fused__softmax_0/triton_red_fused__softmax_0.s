    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    .li       s3, #4286578688
    v.splat      v0, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #8192
    s.movz       s6, #16
    s.ld.d       s7, [s1, #8]                    // out_ptr1: device_ptr64 at arg_base+8
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.ld.d       s8, [s1, #16]                   // out_ptr3: device_ptr64 at arg_base+16
    s.addi       s1, s2, #0
    v.mov        v1, v0
for_1:
    s.cmp.ge     s9, s1, s5
    br.nz        s9, endfor_2
    s.mul        s9, s4, s5
    v.splat      v0, s1
    v.movi       v3, #8192
    v.add        v4, v0, v2
    v.movi       v0, #0
    s.add        s10, s1, s9
    v.cmp.lt     p1, v4, v3
    s.shli       s11, s10, #1                    // element offset -> bytes (x2)
    v.splat      v3, s9
    s.add        s9, s3, s11                     // &in_ptr0[...]
    s.add        s10, s1, s6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v5, [s9, #0]
    s.movz       s9, #1
    v.add        v6, v4, v3
    vf.cvt.f16.f32 v3, v5
    vf.max.prop  v4, v1, v3
    @p1 v.sel        v3, v4, v1
    v.mov        v0, v3
    v.mov        v1, v0
    s.mov        s1, s10
    br.nz        s9, for_1
endfor_2:
    v.movi       v0, #1
    v.movi       v3, #0
    vf.cmp.uo    p1, v1, v1
    @p1 v.sel        v4, v0, v3
    v.movi       v0, #0
    v.reduce.or.b v3, v4
    vf.reduce.max.b v4, v1
    .li       s1, #2143289344
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.ne     p1, v3, v0
    @p1 v.sel        v0, v1, v4
    v.movi       v1, #0
    v.movi       v3, #0
    v.movi       v4, #0
    vf.add       v5, v0, v1
    s.addi       s1, s2, #0
    v.mov        v4, v3
for_3:
    s.cmp.ge     s9, s1, s5
    br.nz        s9, endfor_4
    s.mul        s9, s4, s5
    v.splat      v0, s1
    v.movi       v3, #8192
    v.add        v6, v0, v2
    v.extract    s10, v5, #0
    s.add        s11, s1, s9
    v.cmp.lt     p1, v6, v3
    s.shli       s12, s11, #1                    // element offset -> bytes (x2)
    v.splat      v0, s10
    s.add        s10, s3, s12                    // &in_ptr0[...]
    .li       s12, #1069066811
    v.splat      v3, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v7, [s10, #0]
    .li       s10, #1060205080
    v.splat      v8, s10                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s10, s11, #2                    // element offset -> bytes (x4)
    v.movi       v9, #0
    s.add        s11, s7, s10                    // &out_ptr1[...]
    v.splat      v10, s9
    vf.cvt.f16.f32 v11, v7
    s.add        s9, s1, s6
    s.movz       s10, #1
    v.add        v7, v6, v10
    vf.sub       v6, v11, v0
    vf.mul       v0, v6, v3
    v.exp2.approx v7, v0                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v10, v6, v3, v0                 // the exact rounding error of x*log2(e)
    vf.mul       v0, v10, v8
    vf.fma       v3, v7, v0, v7                  // 2**t * 2**d
    vf.cmp.o     p2, v3, v3
    @p2 v.sel        v0, v3, v7
    vf.add       v3, v4, v0
    @p1 v.st.w       [s11, #0], v0
    @p1 v.sel        v0, v3, v4
    v.mov        v9, v0
    v.mov        v4, v9
    s.mov        s1, s9
    br.nz        s10, for_3
endfor_4:
    s.rdspecial  s1, role_id
    s.movz       s3, #256
    s.rdspecial  s9, arg_base
    s.mul        s10, s1, s3
    s.ld.d       s1, [s9, #40]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    vf.reduce.add.b v0, v4
    s.movz       s3, #4096
    s.movz       s9, #8192
    s.add        s11, s1, s10                    // this context's own scratch
    s.movz       s1, #32768
    s.addi       s10, s11, #0                    // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s11, #4
    .li       s12, #68719476737
    .li       s13, #2207613190144
    vf.add       v3, v0, v1
    s.movz       s14, #0
    s.st.d       [s10, #0], s7
    s.addi       s14, s2, #0
    s.st.d       [s10, #8], s3
    s.st.d       [s10, #16], s9
    s.st.d       [s10, #48], s1
    s.st.d       [s10, #56], s11
    s.st.d       [s10, #88], s12
    s.st.d       [s10, #104], s13
    fence.release.device
    td.load      d0, [s10]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
for_5:
    s.cmp.ge     s1, s14, s5
    br.nz        s1, endfor_6
    v.extract    s1, v3, #0
    v.splat      v0, s1
    s.movz       s1, #32768
    v.rcp.approx v1, v0                          // ISA 8.8: <= 2**-22 relative
    s.mul        s2, s4, s1
    v.splat      v4, s14
    v.iota       v5                              // arange(0, VLEN)
    s.movz       s1, #8192
    s.movz       s3, #4096
    s.muli       s9, s14, #4
    v.add        v6, v4, v5
    v.movi       v4, #0
    v.splat      v5, s1
    v.splat      v7, s4
    v.movi       v8, #0
    v.splat      v9, s3
    v.cmp.ge     p1, v6, v4
    .li       s1, #1065353216
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p2, v6, v5
    v.cmp.ge     p3, v7, v8
    v.cmp.lt     p4, v7, v9
    s.add        s1, s7, s2
    p.and        p5, p1, p2
    p.and        p1, p3, p4
    s.add        s2, s1, s9
    p.and        p2, p5, p1
    fence.acq_rel.device
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v5, [s2, #0]
    s.mul        s1, s4, s5
    v.splat      v6, s14
    vf.fms       v7, v0, v1, v4
    v.add        v0, v6, v2
    v.movi       v4, #8192
    s.add        s2, s14, s1
    vf.fms       v6, v1, v7, v1
    s.shli       s3, s2, #1                      // element offset -> bytes (x2)
    v.splat      v7, s1
    s.add        s1, s8, s3                      // &out_ptr3[...]
    vf.neg       v8, v6                          // Newton step: r0*(2 - x*r0)
    s.add        s2, s14, s6
    s.movz       s3, #1
    v.cmp.lt     p1, v0, v4
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v4, v8, v1
    v.add        v1, v0, v7
    vf.mul       v0, v5, v4                      // a/y as a refined reciprocal (ISA has no divide)
    vf.cvt.f32.f16 v1, v0
    @p1 v.st.h       [s1, #0], v1
    s.mov        s14, s2
    br.nz        s3, for_5
endfor_6:
__rctx_next:
    exit
