    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    s.shli       s1, s2, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #0
    v.add        v4, v1, v0
    v.movi       v0, #4
    v.movi       v1, #15
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v3, v4
    @p1 v.sel        v7, v5, v4
    v.cmp.lt     p2, v4, v3
    @p2 v.sel        v5, v6, v4
    v.lshr       v6, v7, v0
    v.movi       v0, #32
    v.and        v7, v5, v1
    v.sub        v1, v2, v6
    v.cmp.lt     p3, v4, v0
    v.sub        v4, v3, v7
    @p1 v.sel        v5, v1, v6
    v.movi       v1, #16
    @p2 v.sel        v6, v4, v7
    v.mul        v4, v5, v0
    v.sub        v0, v3, v1
    v.sub        v5, v2, v1
    v.add        v7, v6, v4
    v.cmp.lt     p1, v1, v3
    v.cmp.lt     p2, v1, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v7]               // index is in elements (ISA sec 9.1)
    @p1 v.sel        v3, v0, v1
    @p2 v.sel        v0, v5, v1
    @p3 v.st.scatter.h [s5, v7], v2
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s6, s1, s4
    s.mov        s2, s1
    br.nz        s6, __rctx_program
    exit
