#!/bin/bash
# reg.sh TAG: regression gate for a snapshot of ~/r41-sw (copied to ~/r41-sw-work/tree-TAG)
# lanes (2 cores each): A make compiler + default audit; B fp8_cases + fp8_kernels_cases; C addr64 suite
TAG=$1; W=$HOME/r41-sw-work/reg-$TAG; C=$HOME/r41-sw-work/tree-$TAG
source ~/tc_env/env.sh >/dev/null 2>&1
rm -rf $W $C; mkdir -p $W; cp -a ~/r41-sw $C; cp -a ~/r41-sw-mb/tnca-chip $W/tnca-chip
export PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES= OMP_NUM_THREADS=2 MKL_NUM_THREADS=2
P=$HOME/tc_env/torchenv/bin/python
st() { echo "$1=$2" >> $W/status; }
laneA() {
  cd $C; rm -rf compiler/build; cp -a $HOME/r41-fp8-core/compiler/build compiler/build
  PYTHONPATH=$C/python:$C/compiler/python TNCA_LLVM=$HOME/tc_env/root/usr/lib/llvm-20 taskset -c 6-7 nice make compiler PYTHON=$P > $W/make-compiler.log 2>&1; st make_compiler $?
  T=$($P -c "import sys;sys.path.insert(0,'$C');from archbench.provenance import software_tree;print(software_tree())")
  taskset -c 6-7 nice $P -u tools/performance_harness/default_change_audit.py run --source-root $C --software-tree $T --label sw-$TAG --out $W/audit --jobs 2 --torch-extensions-dir $W/ext-audit > $W/audit.log 2>&1; st audit_run $?
  $P tools/performance_harness/default_change_audit.py compare --control $HOME/r41-fp8-audit/run-ctrl/report.json --candidate $W/audit/report.json --out $W/default_change_audit.json > $W/audit-compare.log 2>&1; st audit_compare $?
}
laneB() {
  cd $C; export TORCH_EXTENSIONS_DIR=$W/ext-b TNCA_TLM_BINARY=$W/tnca-chip
  taskset -c 8-9 nice $P -u tools/performance_harness/fp8_cases.py --out $W/fp8-cases > $W/fp8-cases.log 2>&1; st fp8_cases $?
  HF_HOME=$HOME/flux-hf taskset -c 8-9 nice ~/flux-venv/bin/python -u tools/performance_harness/fp8_kernels_cases.py --out $W/fp8-kernels --v1-path $HOME/r41-fp8-kw/hub-main-0fc209e0 > $W/fp8-kernels.log 2>&1; st fp8_kernels $?
  if [ -f tools/performance_harness/std_ops_cases.py ]; then   # fp8-ops (B1-B6) suites, as ops_run.sh ran them
    export OMP_NUM_THREADS=1 PYTHONPATH=$C/python:$C/compiler/python:$C
    taskset -c 8-9 nice $P -u tools/performance_harness/std_ops_cases.py --out $W/std > $W/std.log 2>&1; st std_ops $?
    taskset -c 8-9 nice $P -u tools/performance_harness/triangular_solve_cases.py --out $W/solve > $W/solve.log 2>&1; st solve $?
  fi
}
laneC() {
  cd $C; source $HOME/r41-addr64-work/probe/env.sh $C $W/addr64 >/dev/null 2>&1
  export TNCA_TLM_BINARY=$W/tnca-chip TORCH_EXTENSIONS_DIR=$W/ext-c TNCA_TLM_CONFIG=$C/tools/performance_harness/systemc/configs/r40-board-m2.cfg
  taskset -c 10-11 nice $P -m unittest discover -s compiler/test -p test_addr64.py > $W/test_addr64.log 2>&1; st test_addr64 $?
  taskset -c 10-11 timeout 20000 nice $P -u tools/performance_harness/addr64_case.py --out $W/addr64/cases large:bf16 large:i8 large:u8 large:bf16-4g neg:abi neg:alias neg:hole neg:truncation neg:window neg:window-alloc place:0x100100000 place:0xffffc000 place:0x1fff00000 rows resize > $W/addr64-cases.log 2>&1; st addr64_cases $?
}
laneA & laneB & laneC & wait
echo DONE >> $W/status
