    s.rdspecial  s1, arg_base
    s.movz       s2, #256
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #0
    s.rdspecial  s5, role_id
    s.rdspecial  s6, npid.x
    s.ld.d       s7, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    v.movi       v0, #32
    v.movi       v1, #0
    v.movi       v2, #4
    v.movi       v3, #128
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v5, #16
    v.movi       v6, #48
    v.movi       v7, #64
    v.movi       v8, #80
    v.movi       v9, #96
    v.movi       v10, #112
    v.sub        v11, v1, v0
    v.sub        v12, v1, v2
    v.sub        v13, v1, v3
    v.cmp.lt     p1, v0, v1
    v.cmp.lt     p2, v2, v1
    // tiled element-wise program: 256 lanes as 2 tiles of 128 (1 tensor-engine transfers, one load buffer(s))
    s.mul        s1, s5, s2
    s.addi       s8, s4, #0
    v.add        v14, v4, v5
    v.add        v5, v4, v0
    v.add        v15, v4, v6
    v.add        v6, v4, v7
    v.add        v7, v4, v8
    v.add        v8, v4, v9
    v.add        v9, v4, v10
    @p1 v.sel        v10, v11, v0
    v.cmp.lt     p1, v3, v1
    v.movi       v10, #31
    v.movi       v11, #5
    @p2 v.sel        v16, v12, v2
    v.movi       v2, #3
    @p1 v.sel        v12, v13, v3
    v.movi       v3, #7
    v.movi       v12, #2048
tiles_1:
    // tile 0 of the iteration: lanes t0 + 0
    s.add        s9, s1, s8
    v.splat      v13, s9
    v.add        v16, v13, v4
    v.add        v17, v13, v14
    v.add        v18, v13, v5
    v.add        v19, v13, v15
    v.add        v20, v13, v6
    v.add        v21, v13, v7
    v.add        v22, v13, v8
    v.add        v23, v13, v9
    v.sub        v13, v1, v16
    v.sub        v24, v1, v17
    v.sub        v25, v1, v18
    v.sub        v26, v1, v19
    v.sub        v27, v1, v20
    v.sub        v28, v1, v21
    v.sub        v29, v1, v22
    v.sub        v30, v1, v23
    v.cmp.lt     p1, v16, v1
    v.cmp.lt     p2, v17, v1
    v.cmp.lt     p3, v18, v1
    v.cmp.lt     p4, v19, v1
    v.cmp.lt     p5, v20, v1
    v.cmp.lt     p6, v21, v1
    v.cmp.lt     p7, v22, v1
    v.cmp.lt     p8, v23, v1
    @p1 v.sel        v31, v13, v16
    @p2 v.sel        v13, v24, v17
    @p3 v.sel        v16, v25, v18
    @p4 v.sel        v17, v26, v19
    @p5 v.sel        v18, v27, v20
    @p6 v.sel        v19, v28, v21
    @p7 v.sel        v20, v29, v22
    @p8 v.sel        v21, v30, v23
    v.lshr       v22, v31, v11
    v.and        v23, v31, v10
    v.lshr       v24, v13, v11
    v.sub        v25, v1, v22
    v.and        v26, v13, v10
    v.and        v27, v16, v10
    @p1 v.sel        v28, v25, v22
    v.and        v22, v17, v10
    v.and        v25, v18, v10
    v.and        v29, v19, v10
    v.and        v30, v20, v10
    v.and        v32, v21, v10
    v.sub        v33, v1, v23
    v.sub        v34, v1, v24
    v.sub        v35, v1, v26
    v.sub        v36, v1, v27
    v.sub        v37, v1, v22
    v.sub        v38, v1, v25
    v.sub        v39, v1, v29
    v.sub        v40, v1, v30
    v.sub        v41, v1, v32
    @p1 v.sel        v42, v33, v23
    v.lshr       v23, v16, v11
    v.lshr       v33, v17, v11
    @p2 v.sel        v43, v34, v24
    v.sub        v24, v1, v23
    @p2 v.sel        v34, v35, v26
    v.lshr       v26, v18, v11
    @p3 v.sel        v35, v24, v23
    v.lshr       v23, v19, v11
    @p3 v.sel        v24, v36, v27
    v.lshr       v27, v20, v11
    v.lshr       v36, v21, v11
    @p4 v.sel        v44, v37, v22
    v.sub        v22, v1, v33
    v.cmp.lt     p9, v28, v1
    @p5 v.sel        v37, v38, v25
    v.sub        v25, v1, v26
    @p4 v.sel        v38, v22, v33
    v.sub        v22, v1, v23
    @p5 v.sel        v33, v25, v26
    v.sub        v25, v1, v27
    @p6 v.sel        v26, v22, v23
    v.sub        v22, v1, v36
    @p7 v.sel        v23, v25, v27
    v.sub        v25, v1, v28
    @p8 v.sel        v27, v22, v36
    v.sub        v22, v1, v43
    v.cmp.lt     p10, v43, v1
    @p9 v.sel        v36, v25, v28
    @p10 v.sel        v25, v22, v43
    @p6 v.sel        v22, v39, v29
    v.sub        v28, v1, v35
    v.and        v29, v36, v2
    v.and        v36, v25, v2
    @p7 v.sel        v25, v40, v30
    v.sub        v30, v1, v38
    v.sub        v39, v1, v29
    v.sub        v40, v1, v36
    @p8 v.sel        v43, v41, v32
    v.sub        v32, v1, v33
    v.lshr       v41, v31, v3
    v.lshr       v31, v13, v3
    @p9 v.sel        v13, v39, v29
    v.sub        v29, v1, v26
    v.cmp.lt     p9, v35, v1
    @p9 v.sel        v39, v28, v35
    v.sub        v28, v1, v23
    v.lshr       v35, v16, v3
    v.lshr       v16, v17, v3
    v.and        v17, v39, v2
    @p10 v.sel        v39, v40, v36
    v.sub        v36, v1, v27
    v.cmp.lt     p10, v38, v1
    @p10 v.sel        v40, v30, v38
    v.lshr       v30, v18, v3
    v.lshr       v18, v19, v3
    v.and        v19, v40, v2
    v.sub        v38, v1, v41
    @p1 v.sel        v40, v38, v41
    v.cmp.lt     p1, v33, v1
    @p1 v.sel        v38, v32, v33
    v.sub        v32, v1, v31
    v.sub        v33, v1, v35
    v.and        v41, v38, v2
    @p2 v.sel        v38, v32, v31
    v.cmp.lt     p2, v26, v1
    @p2 v.sel        v31, v29, v26
    v.sub        v26, v1, v16
    v.sub        v29, v1, v30
    v.and        v32, v31, v2
    @p3 v.sel        v31, v33, v35
    v.cmp.lt     p3, v23, v1
    @p3 v.sel        v33, v28, v23
    v.sub        v23, v1, v17
    v.sub        v28, v1, v18
    v.and        v35, v33, v2
    @p4 v.sel        v33, v26, v16
    v.cmp.lt     p4, v27, v1
    @p4 v.sel        v16, v36, v27
    v.sub        v26, v1, v19
    v.sub        v27, v1, v41
    v.and        v36, v16, v2
    v.sub        v16, v1, v32
    @p5 v.sel        v45, v29, v30
    v.sub        v29, v1, v35
    @p9 v.sel        v30, v23, v17
    v.lshr       v17, v20, v3
    v.lshr       v20, v21, v3
    v.sub        v21, v1, v36
    v.sub        v23, v1, v17
    v.sub        v46, v1, v20
    @p6 v.sel        v47, v28, v18
    @p7 v.sel        v18, v23, v17
    @p10 v.sel        v17, v26, v19
    @p8 v.sel        v19, v46, v20
    @p1 v.sel        v20, v27, v41
    @p2 v.sel        v23, v16, v32
    @p3 v.sel        v16, v29, v35
    @p4 v.sel        v26, v21, v36
    v.mul        v21, v40, v0
    v.mul        v27, v38, v0
    v.mul        v28, v31, v0
    v.mul        v29, v33, v0
    v.mul        v31, v45, v0
    v.mul        v32, v47, v0
    v.mul        v33, v18, v0
    v.mul        v18, v19, v0
    v.add        v19, v42, v21
    v.add        v21, v34, v27
    v.add        v27, v24, v28
    v.add        v24, v44, v29
    v.add        v28, v37, v31
    v.add        v29, v22, v32
    v.add        v22, v25, v33
    v.add        v25, v43, v18
    v.mul        v18, v13, v12
    v.mul        v13, v39, v12
    v.mul        v31, v30, v12
    v.mul        v30, v17, v12
    v.mul        v17, v20, v12
    v.mul        v20, v23, v12
    v.mul        v23, v16, v12
    v.mul        v16, v26, v12
    v.add        v26, v19, v18
    v.add        v18, v21, v13
    v.add        v13, v27, v31
    v.add        v19, v24, v30
    v.add        v21, v28, v17
    v.add        v17, v29, v20
    v.add        v20, v22, v23
    v.add        v22, v25, v16
    v.ld.gather.w v16, [s3, v26]                 // index is in elements (ISA sec 9.1)
    s.shli       s10, s9, #1
    s.add        s9, s7, s10
    v.ld.gather.w v23, [s3, v18]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f32.f16 v18, v16
    v.ld.gather.w v16, [s3, v13]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f32.f16 v13, v23
    v.ld.gather.w v23, [s3, v19]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f32.f16 v19, v16
    v.ld.gather.w v16, [s3, v21]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f32.f16 v21, v23
    v.ld.gather.w v23, [s3, v17]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f32.f16 v17, v16
    v.ld.gather.w v16, [s3, v20]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f32.f16 v20, v23
    v.ld.gather.w v23, [s3, v22]                 // index is in elements (ISA sec 9.1)
    vf.cvt.f32.f16 v22, v16
    vf.cvt.f32.f16 v16, v23
    v.st.h       [s9, #0], v18
    v.st.h       [s9, #32], v13
    v.st.h       [s9, #64], v19
    v.st.h       [s9, #96], v21
    v.st.h       [s9, #128], v17
    v.st.h       [s9, #160], v20
    v.st.h       [s9, #192], v22
    v.st.h       [s9, #224], v16
    s.addi       s8, s8, #128
    s.cmp.lt     s9, s8, s2
    br.nz        s9, tiles_1
endtiles_2:
__rctx_next:
    s.addi       s1, s5, #4                      // the next program of this context: + 4
    s.cmp.lt     s8, s1, s6
    s.mov        s5, s1
    br.nz        s8, __rctx_program
    exit
