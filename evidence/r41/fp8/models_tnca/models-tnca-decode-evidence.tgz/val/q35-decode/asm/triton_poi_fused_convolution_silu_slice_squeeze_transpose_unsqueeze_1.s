    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #13
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    v.movi       v1, #0
    v.lshr       v5, v4, v0
    v.sub        v0, v1, v3
    v.sub        v4, v2, v5
    v.cmp.lt     p2, v3, v1
    @p2 v.sel        v6, v0, v3
    v.movi       v0, #8191
    @p1 v.sel        v7, v4, v5
    v.movi       v4, #-3
    v.and        v5, v6, v0
    v.movi       v0, #4
    v.sub        v6, v1, v5
    s.rdspecial  s2, arg_base
    v.add        v8, v7, v4
    @p2 v.sel        v4, v6, v5
    v.movi       v5, #1
    v.mul        v6, v4, v0
    v.movi       v0, #2
    v.movi       v4, #3
    s.ld.d       s3, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.add        v9, v6, v5
    v.add        v5, v6, v0
    v.add        v0, v6, v4
    s.ld.d       s4, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v4, #0
    v.movi       v10, #0
    s.ld.d       s5, [s2, #16]                   // out_ptr1: device_ptr64 at arg_base+16
    v.extract    s2, v8, #0
    s.shli       s6, s2, #32
    v.ld.gather.h v11, [s3, v6]                  // index is in elements (ISA sec 9.1)
    s.ashri      s2, s6, #32
    v.movi       v6, #8192
    v.extract    s6, v8, #1
    s.shli       s7, s6, #32
    s.lshri      s6, s2, #32
    v.ld.gather.h v12, [s3, v9]                  // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v9, v11
    v.sub        v11, v2, v6
    v.sub        v13, v1, v6
    v.cmp.lt     p1, v6, v2
    s.ashri      s8, s7, #32
    v.ld.gather.h v2, [s3, v5]                   // index is in elements (ISA sec 9.1)
    s.lshri      s7, s8, #32
    vf.cvt.bf16.f32 v5, v12
    v.cmp.lt     p2, v6, v1
    @p1 v.sel        v1, v11, v6
    v.extract    s9, v8, #2
    s.shli       s10, s9, #32
    v.extract    s9, v8, #3
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.insert     v4, s2, #0
    v.insert     v10, s6, #0
    s.ashri      s2, s10, #32
    s.shli       s3, s9, #32
    v.insert     v4, s8, #1
    v.insert     v10, s7, #1
    s.lshri      s6, s2, #32
    s.ashri      s7, s3, #32
    v.insert     v4, s2, #2
    v.insert     v10, s6, #2
    s.lshri      s2, s7, #32
    v.insert     v4, s7, #3
    vf.cvt.bf16.f32 v0, v2
    vf.cvt.bf16.f32 v2, v1
    @p2 v.sel        v1, v13, v6
    v.extract    s3, v8, #4
    s.shli       s6, s3, #32
    v.extract    s3, v8, #5
    s.ashri      s7, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v8, #6
    v.insert     v10, s2, #3
    s.lshri      s2, s7, #32
    s.ashri      s8, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v8, #7
    v.insert     v4, s7, #4
    v.insert     v10, s2, #4
    s.lshri      s2, s8, #32
    s.ashri      s7, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v8, #8
    v.insert     v4, s8, #5
    v.insert     v10, s2, #5
    s.lshri      s2, s7, #32
    s.ashri      s8, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v8, #9
    v.insert     v4, s7, #6
    v.insert     v10, s2, #6
    s.lshri      s2, s8, #32
    s.ashri      s7, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v8, #10
    v.insert     v4, s8, #7
    v.insert     v10, s2, #7
    s.lshri      s2, s7, #32
    s.ashri      s8, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v8, #11
    v.insert     v4, s7, #8
    v.insert     v10, s2, #8
    s.lshri      s2, s8, #32
    s.ashri      s7, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v8, #12
    v.insert     v4, s8, #9
    v.insert     v10, s2, #9
    s.lshri      s2, s7, #32
    s.ashri      s8, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v8, #13
    v.insert     v4, s7, #10
    v.insert     v10, s2, #10
    s.lshri      s2, s8, #32
    s.ashri      s7, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v8, #14
    v.insert     v4, s8, #11
    v.insert     v10, s2, #11
    s.lshri      s2, s7, #32
    s.ashri      s8, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v8, #15
    v.insert     v4, s7, #12
    v.insert     v10, s2, #12
    s.lshri      s2, s8, #32
    s.ashri      s7, s6, #32
    s.shli       s6, s3, #32
    v.insert     v4, s8, #13
    v.insert     v10, s2, #13
    s.lshri      s2, s7, #32
    s.ashri      s3, s6, #32
    v.insert     v4, s7, #14
    v.insert     v10, s2, #14
    s.lshri      s2, s3, #32
    v.insert     v4, s3, #15
    v.insert     v10, s2, #15
    v.extract    s2, v4, #0
    v.extract    s3, v10, #0
    s.shli       s6, s3, #32
    v.extract    s3, v10, #1
    s.or         s7, s2, s6
    s.movz       s2, #0
    s.shli       s6, s3, #32
    v.extract    s3, v4, #1
    v.extract    s8, v10, #2
    v.movi       v1, #0
    s.cmp.ge     s9, s7, s2
    s.or         s7, s3, s6
    s.shli       s3, s8, #32
    v.extract    s6, v4, #2
    v.extract    s8, v10, #3
    v.insert     v1, s9, #0
    s.cmp.ge     s9, s7, s2
    s.or         s7, s6, s3
    s.shli       s3, s8, #32
    v.extract    s6, v4, #3
    v.extract    s8, v10, #4
    v.insert     v1, s9, #1
    s.cmp.ge     s9, s7, s2
    s.or         s7, s6, s3
    s.shli       s3, s8, #32
    v.extract    s6, v4, #4
    v.extract    s8, v10, #5
    v.insert     v1, s9, #2
    s.cmp.ge     s9, s7, s2
    s.or         s7, s6, s3
    s.shli       s3, s8, #32
    v.extract    s6, v4, #5
    v.extract    s8, v10, #6
    v.insert     v1, s9, #3
    s.cmp.ge     s9, s7, s2
    s.or         s2, s6, s3
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v4, #6
    v.extract    s8, v10, #7
    v.insert     v1, s9, #4
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v4, #7
    v.extract    s8, v10, #8
    v.insert     v1, s9, #5
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v4, #8
    v.extract    s8, v10, #9
    v.insert     v1, s9, #6
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v4, #9
    v.extract    s8, v10, #10
    v.insert     v1, s9, #7
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v4, #10
    v.extract    s8, v10, #11
    v.insert     v1, s9, #8
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v4, #11
    v.extract    s8, v10, #12
    v.insert     v1, s9, #9
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v4, #12
    v.extract    s8, v10, #13
    v.insert     v1, s9, #10
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v4, #13
    v.extract    s8, v10, #14
    v.insert     v1, s9, #11
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v4, #14
    v.extract    s8, v10, #15
    v.extract    s10, v10, #0
    v.insert     v1, s9, #12
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    s.shli       s7, s10, #32
    v.extract    s8, v4, #15
    v.extract    s10, v4, #0
    v.insert     v1, s9, #13
    v.extract    s9, v10, #1
    s.cmp.ge     s11, s2, s3
    s.or         s2, s8, s6
    s.movz       s3, #0
    s.or         s6, s10, s7
    s.movz       s7, #17
    s.shli       s8, s9, #32
    v.extract    s9, v4, #1
    v.insert     v1, s11, #14
    v.extract    s10, v10, #2
    s.cmp.ge     s11, s2, s3
    v.movi       v6, #0
    s.cmp.lt     s2, s6, s7
    s.or         s3, s9, s8
    s.shli       s6, s10, #32
    v.extract    s8, v4, #2
    v.extract    s9, v10, #3
    v.insert     v1, s11, #15
    v.insert     v6, s2, #0
    s.cmp.lt     s2, s3, s7
    s.or         s3, s8, s6
    s.shli       s6, s9, #32
    v.extract    s8, v4, #3
    v.extract    s9, v10, #4
    v.insert     v6, s2, #1
    s.cmp.lt     s2, s3, s7
    s.or         s3, s8, s6
    s.shli       s6, s9, #32
    v.extract    s8, v4, #4
    v.extract    s9, v10, #5
    v.insert     v6, s2, #2
    s.cmp.lt     s2, s3, s7
    s.or         s3, s8, s6
    s.shli       s6, s9, #32
    v.extract    s8, v4, #5
    v.extract    s9, v10, #6
    v.insert     v6, s2, #3
    s.cmp.lt     s2, s3, s7
    s.or         s3, s8, s6
    s.movz       s6, #17
    s.shli       s7, s9, #32
    v.extract    s8, v4, #6
    v.insert     v6, s2, #4
    s.cmp.lt     s2, s3, s6
    s.or         s3, s8, s7
    s.movz       s6, #17
    v.insert     v6, s2, #5
    s.cmp.lt     s2, s3, s6
    v.movi       v8, #0
    v.extract    s3, v4, #7
    v.insert     v6, s2, #6
    v.cmp.ne     p1, v1, v8
    v.extract    s2, v10, #7
    s.shli       s6, s2, #32
    v.extract    s2, v10, #8
    s.or         s7, s3, s6
    s.movz       s3, #17
    s.shli       s6, s2, #32
    v.extract    s2, v4, #8
    v.extract    s8, v10, #9
    s.cmp.lt     s9, s7, s3
    s.or         s3, s2, s6
    s.movz       s2, #17
    s.shli       s6, s8, #32
    v.extract    s7, v4, #9
    v.extract    s8, v10, #10
    v.insert     v6, s9, #7
    s.cmp.lt     s9, s3, s2
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v4, #10
    v.extract    s8, v10, #11
    v.insert     v6, s9, #8
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v4, #11
    v.extract    s8, v10, #12
    v.insert     v6, s9, #9
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v4, #12
    v.extract    s8, v10, #13
    v.insert     v6, s9, #10
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v4, #13
    v.extract    s8, v10, #14
    v.insert     v6, s9, #11
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v4, #14
    v.extract    s8, v10, #15
    v.insert     v6, s9, #12
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.movi       v1, #-2
    v.extract    s7, v4, #15
    v.insert     v6, s9, #13
    s.cmp.lt     s8, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    v.add        v4, v7, v1
    v.insert     v6, s8, #14
    s.cmp.lt     s6, s2, s3
    v.extract    s2, v4, #0
    s.shli       s3, s2, #32
    v.insert     v6, s6, #15
    v.movi       v1, #0
    v.extract    s2, v4, #1
    v.movi       v8, #-24576
    s.ashri      s6, s3, #32
    s.shli       s3, s2, #32
    v.cmp.ne     p2, v6, v1
    v.extract    s2, v4, #2
    p.and        p3, p1, p2
    v.add        v1, v3, v8
    v.movi       v6, #0
    v.movi       v8, #0
    s.lshri      s7, s6, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v4, #3
    v.movi       v10, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v10, [s4, v1]              // index is in elements (ISA sec 9.1)
    v.insert     v6, s6, #0
    v.insert     v8, s7, #0
    s.lshri      s6, s8, #32
    s.ashri      s7, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v4, #4
    v.insert     v6, s8, #1
    v.insert     v8, s6, #1
    s.lshri      s6, s7, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v4, #5
    v.insert     v6, s7, #2
    v.insert     v8, s6, #2
    s.lshri      s6, s8, #32
    s.ashri      s7, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v4, #6
    v.insert     v6, s8, #3
    v.insert     v8, s6, #3
    s.lshri      s6, s7, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.insert     v6, s7, #4
    v.insert     v8, s6, #4
    s.lshri      s2, s8, #32
    s.ashri      s6, s3, #32
    v.insert     v6, s8, #5
    v.insert     v8, s2, #5
    v.insert     v6, s6, #6
    vf.cvt.bf16.f32 v1, v10
    s.lshri      s2, s6, #32
    v.movi       v10, #0
    v.insert     v8, s2, #6
    @p3 v.sel        v11, v1, v10
    v.extract    s2, v4, #7
    vf.mul       v1, v11, v9
    s.shli       s3, s2, #32
    v.extract    s2, v4, #8
    s.ashri      s6, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v4, #9
    s.lshri      s7, s6, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v4, #10
    v.insert     v6, s6, #7
    v.insert     v8, s7, #7
    s.lshri      s6, s8, #32
    s.ashri      s7, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v4, #11
    v.insert     v6, s8, #8
    v.insert     v8, s6, #8
    s.lshri      s6, s7, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v4, #12
    v.insert     v6, s7, #9
    v.insert     v8, s6, #9
    s.lshri      s6, s8, #32
    s.ashri      s7, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v4, #13
    v.insert     v6, s8, #10
    v.insert     v8, s6, #10
    s.lshri      s6, s7, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v4, #14
    v.insert     v6, s7, #11
    v.insert     v8, s6, #11
    s.lshri      s6, s8, #32
    s.ashri      s7, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v4, #15
    v.insert     v6, s8, #12
    v.insert     v8, s6, #12
    s.lshri      s6, s7, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.insert     v6, s7, #13
    v.insert     v8, s6, #13
    s.lshri      s2, s8, #32
    s.ashri      s6, s3, #32
    v.insert     v6, s8, #14
    v.insert     v8, s2, #14
    s.lshri      s2, s6, #32
    v.insert     v6, s6, #15
    v.insert     v8, s2, #15
    v.extract    s2, v6, #0
    v.extract    s3, v8, #0
    s.shli       s6, s3, #32
    v.extract    s3, v8, #1
    s.or         s7, s2, s6
    s.movz       s2, #0
    s.shli       s6, s3, #32
    v.extract    s3, v6, #1
    v.extract    s8, v8, #2
    v.movi       v4, #0
    s.cmp.ge     s9, s7, s2
    s.or         s2, s3, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v6, #2
    v.extract    s8, v8, #3
    v.insert     v4, s9, #0
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v6, #3
    v.extract    s8, v8, #4
    v.insert     v4, s9, #1
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v6, #4
    v.extract    s8, v8, #5
    v.insert     v4, s9, #2
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v6, #5
    v.extract    s8, v8, #6
    v.insert     v4, s9, #3
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v6, #6
    v.extract    s8, v8, #7
    v.insert     v4, s9, #4
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v6, #7
    v.extract    s8, v8, #8
    v.insert     v4, s9, #5
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v6, #8
    v.extract    s8, v8, #9
    v.insert     v4, s9, #6
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v6, #9
    v.extract    s8, v8, #10
    v.insert     v4, s9, #7
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v6, #10
    v.extract    s8, v8, #11
    v.insert     v4, s9, #8
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v6, #11
    v.extract    s8, v8, #12
    v.insert     v4, s9, #9
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v6, #12
    v.extract    s8, v8, #13
    v.insert     v4, s9, #10
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v6, #13
    v.extract    s8, v8, #14
    v.insert     v4, s9, #11
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v6, #14
    v.extract    s8, v8, #15
    v.extract    s10, v8, #0
    v.insert     v4, s9, #12
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    s.shli       s7, s10, #32
    v.extract    s8, v6, #15
    v.extract    s10, v6, #0
    v.insert     v4, s9, #13
    v.extract    s9, v8, #1
    s.cmp.ge     s11, s2, s3
    s.or         s2, s8, s6
    s.movz       s3, #0
    s.or         s6, s10, s7
    s.movz       s7, #17
    s.shli       s8, s9, #32
    v.extract    s9, v6, #1
    v.insert     v4, s11, #14
    v.extract    s10, v8, #2
    s.cmp.ge     s11, s2, s3
    v.movi       v9, #0
    s.cmp.lt     s2, s6, s7
    s.or         s3, s9, s8
    s.movz       s6, #17
    s.shli       s7, s10, #32
    v.extract    s8, v6, #2
    v.extract    s9, v8, #3
    v.insert     v4, s11, #15
    v.insert     v9, s2, #0
    s.cmp.lt     s2, s3, s6
    s.or         s3, s8, s7
    s.movz       s6, #17
    s.shli       s7, s9, #32
    v.extract    s8, v6, #3
    v.extract    s9, v8, #4
    v.insert     v9, s2, #1
    s.cmp.lt     s2, s3, s6
    s.or         s3, s8, s7
    s.movz       s6, #17
    s.shli       s7, s9, #32
    v.extract    s8, v6, #4
    v.extract    s9, v8, #5
    v.insert     v9, s2, #2
    s.cmp.lt     s2, s3, s6
    s.or         s3, s8, s7
    s.movz       s6, #17
    s.shli       s7, s9, #32
    v.extract    s8, v6, #5
    v.extract    s9, v8, #6
    v.insert     v9, s2, #3
    s.cmp.lt     s2, s3, s6
    s.or         s3, s8, s7
    s.movz       s6, #17
    s.shli       s7, s9, #32
    v.extract    s8, v6, #6
    v.insert     v9, s2, #4
    s.cmp.lt     s2, s3, s6
    v.movi       v11, #0
    s.or         s3, s8, s7
    v.insert     v9, s2, #5
    v.cmp.ne     p1, v4, v11
    v.extract    s2, v8, #7
    s.movz       s6, #17
    s.shli       s7, s2, #32
    v.extract    s2, v6, #7
    v.extract    s8, v8, #8
    s.cmp.lt     s9, s3, s6
    s.or         s3, s2, s7
    s.movz       s2, #17
    s.shli       s6, s8, #32
    v.extract    s7, v6, #8
    v.extract    s8, v8, #9
    v.insert     v9, s9, #6
    s.cmp.lt     s9, s3, s2
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v6, #9
    v.extract    s8, v8, #10
    v.insert     v9, s9, #7
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v6, #10
    v.extract    s8, v8, #11
    v.insert     v9, s9, #8
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v6, #11
    v.extract    s8, v8, #12
    v.insert     v9, s9, #9
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v6, #12
    v.extract    s8, v8, #13
    v.insert     v9, s9, #10
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v6, #13
    v.extract    s8, v8, #14
    v.insert     v9, s9, #11
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v6, #14
    v.extract    s8, v8, #15
    v.insert     v9, s9, #12
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.movi       v4, #-1
    v.extract    s7, v6, #15
    v.insert     v9, s9, #13
    s.cmp.lt     s8, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    v.add        v6, v7, v4
    v.insert     v9, s8, #14
    s.cmp.lt     s6, s2, s3
    v.extract    s2, v6, #0
    s.shli       s3, s2, #32
    v.insert     v9, s6, #15
    v.movi       v4, #0
    v.extract    s2, v6, #1
    v.movi       v8, #-16384
    s.ashri      s6, s3, #32
    s.shli       s3, s2, #32
    v.cmp.ne     p2, v9, v4
    v.extract    s2, v6, #2
    p.and        p3, p1, p2
    v.add        v4, v3, v8
    v.movi       v8, #0
    v.movi       v9, #0
    s.lshri      s7, s6, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v6, #3
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p3 v.ld.gather.h v11, [s4, v4]              // index is in elements (ISA sec 9.1)
    v.insert     v8, s6, #0
    v.insert     v9, s7, #0
    s.lshri      s6, s8, #32
    s.ashri      s7, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v6, #4
    v.insert     v8, s8, #1
    v.insert     v9, s6, #1
    s.lshri      s6, s7, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v6, #5
    v.insert     v8, s7, #2
    v.insert     v9, s6, #2
    s.lshri      s6, s8, #32
    s.ashri      s7, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v6, #6
    v.insert     v8, s8, #3
    v.insert     v9, s6, #3
    s.lshri      s6, s7, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.insert     v8, s7, #4
    v.insert     v9, s6, #4
    s.lshri      s2, s8, #32
    s.ashri      s6, s3, #32
    v.insert     v8, s8, #5
    v.insert     v9, s2, #5
    v.insert     v8, s6, #6
    vf.cvt.bf16.f32 v4, v11
    s.lshri      s2, s6, #32
    @p3 v.sel        v11, v4, v10
    v.insert     v9, s2, #6
    vf.mul       v4, v11, v5
    v.extract    s2, v6, #7
    vf.add       v5, v1, v4
    s.shli       s3, s2, #32
    v.extract    s2, v6, #8
    s.ashri      s6, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v6, #9
    s.lshri      s7, s6, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v6, #10
    v.insert     v8, s6, #7
    v.insert     v9, s7, #7
    s.lshri      s6, s8, #32
    s.ashri      s7, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v6, #11
    v.insert     v8, s8, #8
    v.insert     v9, s6, #8
    s.lshri      s6, s7, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v6, #12
    v.insert     v8, s7, #9
    v.insert     v9, s6, #9
    s.lshri      s6, s8, #32
    s.ashri      s7, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v6, #13
    v.insert     v8, s8, #10
    v.insert     v9, s6, #10
    s.lshri      s6, s7, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v6, #14
    v.insert     v8, s7, #11
    v.insert     v9, s6, #11
    s.lshri      s6, s8, #32
    s.ashri      s7, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v6, #15
    v.insert     v8, s8, #12
    v.insert     v9, s6, #12
    s.lshri      s6, s7, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.insert     v8, s7, #13
    v.insert     v9, s6, #13
    s.lshri      s2, s8, #32
    s.ashri      s6, s3, #32
    v.insert     v8, s8, #14
    v.insert     v9, s2, #14
    s.lshri      s2, s6, #32
    v.insert     v8, s6, #15
    v.insert     v9, s2, #15
    v.extract    s2, v8, #0
    v.extract    s3, v9, #0
    s.shli       s6, s3, #32
    v.extract    s3, v9, #1
    s.or         s7, s2, s6
    s.movz       s2, #0
    s.shli       s6, s3, #32
    v.extract    s3, v8, #1
    v.extract    s8, v9, #2
    v.movi       v1, #0
    s.cmp.ge     s9, s7, s2
    s.or         s2, s3, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v8, #2
    v.extract    s8, v9, #3
    v.insert     v1, s9, #0
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v8, #3
    v.extract    s8, v9, #4
    v.insert     v1, s9, #1
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v8, #4
    v.extract    s8, v9, #5
    v.insert     v1, s9, #2
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v8, #5
    v.extract    s8, v9, #6
    v.insert     v1, s9, #3
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v8, #6
    v.extract    s8, v9, #7
    v.insert     v1, s9, #4
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v8, #7
    v.extract    s8, v9, #8
    v.insert     v1, s9, #5
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v8, #8
    v.extract    s8, v9, #9
    v.insert     v1, s9, #6
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v8, #9
    v.extract    s8, v9, #10
    v.insert     v1, s9, #7
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v8, #10
    v.extract    s8, v9, #11
    v.insert     v1, s9, #8
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v8, #11
    v.extract    s8, v9, #12
    v.insert     v1, s9, #9
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v8, #12
    v.extract    s8, v9, #13
    v.insert     v1, s9, #10
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v8, #13
    v.extract    s8, v9, #14
    v.insert     v1, s9, #11
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v8, #14
    v.extract    s8, v9, #15
    v.extract    s10, v9, #0
    v.insert     v1, s9, #12
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    s.shli       s7, s10, #32
    v.extract    s8, v8, #15
    v.extract    s10, v8, #0
    v.insert     v1, s9, #13
    v.extract    s9, v9, #1
    s.cmp.ge     s11, s2, s3
    s.or         s2, s8, s6
    s.movz       s3, #0
    s.or         s6, s10, s7
    s.movz       s7, #17
    s.shli       s8, s9, #32
    v.extract    s9, v8, #1
    v.insert     v1, s11, #14
    v.extract    s10, v9, #2
    s.cmp.ge     s11, s2, s3
    v.movi       v4, #0
    s.cmp.lt     s2, s6, s7
    s.or         s3, s9, s8
    s.movz       s6, #17
    s.shli       s7, s10, #32
    v.extract    s8, v8, #2
    v.extract    s9, v9, #3
    v.insert     v1, s11, #15
    v.insert     v4, s2, #0
    s.cmp.lt     s2, s3, s6
    s.or         s3, s8, s7
    s.movz       s6, #17
    s.shli       s7, s9, #32
    v.extract    s8, v8, #3
    v.extract    s9, v9, #4
    v.insert     v4, s2, #1
    s.cmp.lt     s2, s3, s6
    s.or         s3, s8, s7
    s.movz       s6, #17
    s.shli       s7, s9, #32
    v.extract    s8, v8, #4
    v.extract    s9, v9, #5
    v.insert     v4, s2, #2
    s.cmp.lt     s2, s3, s6
    s.or         s3, s8, s7
    s.movz       s6, #17
    s.shli       s7, s9, #32
    v.extract    s8, v8, #5
    v.extract    s9, v9, #6
    v.insert     v4, s2, #3
    s.cmp.lt     s2, s3, s6
    s.or         s3, s8, s7
    s.movz       s6, #17
    s.shli       s7, s9, #32
    v.extract    s8, v8, #6
    v.insert     v4, s2, #4
    s.cmp.lt     s2, s3, s6
    v.movi       v6, #0
    s.or         s3, s8, s7
    v.insert     v4, s2, #5
    v.cmp.ne     p1, v1, v6
    v.extract    s2, v9, #7
    s.movz       s6, #17
    s.shli       s7, s2, #32
    v.extract    s2, v8, #7
    v.extract    s8, v9, #8
    s.cmp.lt     s9, s3, s6
    s.or         s3, s2, s7
    s.movz       s2, #17
    s.shli       s6, s8, #32
    v.extract    s7, v8, #8
    v.extract    s8, v9, #9
    v.insert     v4, s9, #6
    s.cmp.lt     s9, s3, s2
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v8, #9
    v.extract    s8, v9, #10
    v.insert     v4, s9, #7
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v8, #10
    v.extract    s8, v9, #11
    v.insert     v4, s9, #8
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v8, #11
    v.extract    s8, v9, #12
    v.insert     v4, s9, #9
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v8, #12
    v.extract    s8, v9, #13
    v.insert     v4, s9, #10
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v8, #13
    v.extract    s8, v9, #14
    v.insert     v4, s9, #11
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v8, #14
    v.extract    s8, v9, #15
    v.insert     v4, s9, #12
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v8, #15
    v.insert     v4, s9, #13
    s.cmp.lt     s8, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    v.insert     v4, s8, #14
    s.cmp.lt     s6, s2, s3
    v.extract    s2, v7, #0
    s.shli       s3, s2, #32
    v.insert     v4, s6, #15
    v.movi       v1, #0
    v.extract    s2, v7, #1
    v.movi       v6, #-8192
    s.ashri      s6, s3, #32
    s.shli       s3, s2, #32
    v.cmp.ne     p2, v4, v1
    v.extract    s2, v7, #2
    p.and        p3, p1, p2
    v.add        v1, v3, v6
    v.movi       v3, #0
    v.movi       v4, #0
    s.lshri      s7, s6, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v7, #3
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v6, [s4, v1]               // index is in elements (ISA sec 9.1)
    v.insert     v3, s6, #0
    v.insert     v4, s7, #0
    s.lshri      s6, s8, #32
    s.ashri      s7, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v7, #4
    v.insert     v3, s8, #1
    v.insert     v4, s6, #1
    s.lshri      s6, s7, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v7, #5
    v.insert     v3, s7, #2
    v.insert     v4, s6, #2
    s.lshri      s6, s8, #32
    s.ashri      s7, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v7, #6
    v.insert     v3, s8, #3
    v.insert     v4, s6, #3
    s.lshri      s6, s7, #32
    s.ashri      s8, s3, #32
    s.shli       s3, s2, #32
    v.insert     v3, s7, #4
    v.insert     v4, s6, #4
    s.lshri      s2, s8, #32
    s.ashri      s6, s3, #32
    v.insert     v3, s8, #5
    v.insert     v4, s2, #5
    s.lshri      s2, s6, #32
    v.insert     v3, s6, #6
    v.insert     v4, s2, #6
    vf.cvt.bf16.f32 v1, v6
    v.extract    s2, v7, #7
    @p3 v.sel        v6, v1, v10
    s.shli       s3, s2, #32
    vf.mul       v1, v6, v0
    s.ashri      s2, s3, #32
    vf.add       v0, v5, v1
    v.extract    s3, v7, #8
    s.shli       s6, s3, #32
    v.extract    s3, v7, #9
    s.lshri      s7, s2, #32
    s.ashri      s8, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v7, #10
    v.insert     v3, s2, #7
    v.insert     v4, s7, #7
    s.lshri      s2, s8, #32
    s.ashri      s7, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v7, #11
    v.insert     v3, s8, #8
    v.insert     v4, s2, #8
    s.lshri      s2, s7, #32
    s.ashri      s8, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v7, #12
    v.insert     v3, s7, #9
    v.insert     v4, s2, #9
    s.lshri      s2, s8, #32
    s.ashri      s7, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v7, #13
    v.insert     v3, s8, #10
    v.insert     v4, s2, #10
    s.lshri      s2, s7, #32
    s.ashri      s8, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v7, #14
    v.insert     v3, s7, #11
    v.insert     v4, s2, #11
    s.lshri      s2, s8, #32
    s.ashri      s7, s6, #32
    s.shli       s6, s3, #32
    v.extract    s3, v7, #15
    v.insert     v3, s8, #12
    v.insert     v4, s2, #12
    s.lshri      s2, s7, #32
    s.ashri      s8, s6, #32
    s.shli       s6, s3, #32
    v.insert     v3, s7, #13
    v.insert     v4, s2, #13
    s.lshri      s2, s8, #32
    s.ashri      s3, s6, #32
    v.insert     v3, s8, #14
    v.insert     v4, s2, #14
    s.lshri      s2, s3, #32
    v.insert     v3, s3, #15
    v.insert     v4, s2, #15
    v.extract    s2, v3, #0
    v.extract    s3, v4, #0
    s.shli       s6, s3, #32
    v.extract    s3, v4, #1
    s.or         s7, s2, s6
    s.movz       s2, #0
    s.shli       s6, s3, #32
    v.extract    s3, v3, #1
    v.extract    s8, v4, #2
    v.movi       v1, #0
    s.cmp.ge     s9, s7, s2
    s.or         s2, s3, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v3, #2
    v.extract    s8, v4, #3
    v.insert     v1, s9, #0
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v3, #3
    v.extract    s8, v4, #4
    v.insert     v1, s9, #1
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v3, #4
    v.extract    s8, v4, #5
    v.insert     v1, s9, #2
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v3, #5
    v.extract    s8, v4, #6
    v.insert     v1, s9, #3
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v3, #6
    v.extract    s8, v4, #7
    v.insert     v1, s9, #4
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v3, #7
    v.extract    s8, v4, #8
    v.insert     v1, s9, #5
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v3, #8
    v.extract    s8, v4, #9
    v.insert     v1, s9, #6
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v3, #9
    v.extract    s8, v4, #10
    v.insert     v1, s9, #7
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v3, #10
    v.extract    s8, v4, #11
    v.insert     v1, s9, #8
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v3, #11
    v.extract    s8, v4, #12
    v.insert     v1, s9, #9
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v3, #12
    v.extract    s8, v4, #13
    v.insert     v1, s9, #10
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v3, #13
    v.extract    s8, v4, #14
    v.insert     v1, s9, #11
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    v.extract    s7, v3, #14
    v.extract    s8, v4, #15
    v.extract    s10, v4, #0
    v.insert     v1, s9, #12
    s.cmp.ge     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #0
    s.shli       s6, s8, #32
    s.shli       s7, s10, #32
    v.extract    s8, v3, #15
    v.extract    s10, v3, #0
    v.insert     v1, s9, #13
    v.extract    s9, v4, #1
    s.cmp.ge     s11, s2, s3
    s.or         s2, s8, s6
    s.movz       s3, #0
    s.or         s6, s10, s7
    s.movz       s7, #17
    s.shli       s8, s9, #32
    v.extract    s9, v3, #1
    v.insert     v1, s11, #14
    v.extract    s10, v4, #2
    s.cmp.ge     s11, s2, s3
    v.movi       v5, #0
    s.cmp.lt     s2, s6, s7
    s.or         s3, s9, s8
    s.movz       s6, #17
    s.shli       s7, s10, #32
    v.extract    s8, v3, #2
    v.extract    s9, v4, #3
    v.insert     v1, s11, #15
    v.insert     v5, s2, #0
    s.cmp.lt     s2, s3, s6
    s.or         s3, s8, s7
    s.movz       s6, #17
    s.shli       s7, s9, #32
    v.extract    s8, v3, #3
    v.extract    s9, v4, #4
    v.insert     v5, s2, #1
    s.cmp.lt     s2, s3, s6
    s.or         s3, s8, s7
    s.movz       s6, #17
    s.shli       s7, s9, #32
    v.extract    s8, v3, #4
    v.extract    s9, v4, #5
    v.insert     v5, s2, #2
    s.cmp.lt     s2, s3, s6
    s.or         s3, s8, s7
    s.movz       s6, #17
    s.shli       s7, s9, #32
    v.extract    s8, v3, #5
    v.extract    s9, v4, #6
    v.insert     v5, s2, #3
    s.cmp.lt     s2, s3, s6
    s.or         s3, s8, s7
    s.movz       s6, #17
    s.shli       s7, s9, #32
    v.extract    s8, v3, #6
    v.insert     v5, s2, #4
    s.cmp.lt     s2, s3, s6
    v.movi       v6, #0
    s.or         s3, s8, s7
    v.insert     v5, s2, #5
    v.cmp.ne     p1, v1, v6
    v.extract    s2, v4, #7
    s.movz       s6, #17
    s.shli       s7, s2, #32
    v.extract    s2, v3, #7
    v.extract    s8, v4, #8
    s.cmp.lt     s9, s3, s6
    s.or         s3, s2, s7
    s.movz       s2, #17
    s.shli       s6, s8, #32
    v.extract    s7, v3, #8
    v.extract    s8, v4, #9
    v.insert     v5, s9, #6
    s.cmp.lt     s9, s3, s2
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v3, #9
    v.extract    s8, v4, #10
    v.insert     v5, s9, #7
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v3, #10
    v.extract    s8, v4, #11
    v.insert     v5, s9, #8
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v3, #11
    v.extract    s8, v4, #12
    v.insert     v5, s9, #9
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v3, #12
    v.extract    s8, v4, #13
    v.insert     v5, s9, #10
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v3, #13
    v.extract    s8, v4, #14
    v.insert     v5, s9, #11
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v3, #14
    v.extract    s8, v4, #15
    v.insert     v5, s9, #12
    s.cmp.lt     s9, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    s.shli       s6, s8, #32
    v.extract    s7, v3, #15
    v.insert     v5, s9, #13
    s.cmp.lt     s8, s2, s3
    s.or         s2, s7, s6
    s.movz       s3, #17
    v.insert     v5, s8, #14
    s.cmp.lt     s6, s2, s3
    v.movi       v1, #0
    v.insert     v5, s6, #15
    s.shli       s2, s1, #1                      // element offset -> bytes (x2)
    v.cmp.ne     p2, v5, v1
    p.and        p3, p1, p2
    s.add        s1, s4, s2                      // &in_ptr0[...]
    .li       s3, #1069066811
    v.splat      v1, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v3, [s1, #0]
    .li       s1, #1060205080
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v6, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s1, s5, s2                      // &out_ptr1[...]
    vf.cvt.bf16.f32 v7, v3
    @p3 v.sel        v3, v7, v10
    vf.mul       v7, v3, v2
    vf.add       v2, v0, v7
    vf.neg       v0, v2
    vf.mul       v3, v0, v1
    v.exp2.approx v7, v3                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v8, v0, v1, v3                  // the exact rounding error of x*log2(e)
    vf.mul       v0, v8, v4
    vf.fma       v1, v7, v0, v7                  // 2**t * 2**d
    vf.cmp.o     p1, v1, v1
    @p1 v.sel        v0, v1, v7
    vf.add       v1, v0, v5
    v.rcp.approx v0, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v3, v1, v0, v6
    vf.fms       v4, v0, v3, v0
    vf.neg       v3, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v3, v3
    @p1 v.sel        v4, v3, v0
    vf.mul       v0, v2, v4                      // a/y: faithful quotient
    vf.fms       v3, v0, v1, v2
    vf.fms       v1, v3, v4, v0
    vf.neg       v2, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v2, v2
    @p1 v.sel        v1, v2, v0
    vf.cvt.f32.bf16 v0, v1
    v.st.h       [s1, #0], v0
__rctx_next:
    exit
