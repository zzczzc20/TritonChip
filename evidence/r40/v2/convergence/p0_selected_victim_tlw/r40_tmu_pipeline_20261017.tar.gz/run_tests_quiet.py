from pathlib import Path
import subprocess,json
root=Path.cwd();out=root/'functional_quiet';out.mkdir(exist_ok=False);records=[]
def step(name,args,expect=0):
 p=subprocess.run(args,capture_output=True,text=True,timeout=180);text=p.stdout+p.stderr;(out/(name+'.log')).write_text(text);assert p.returncode==expect,(name,p.returncode,text[-4000:]);return text
for pipe in [0,1,2]:
 for ports in [3,4]:
  name=f'pipe{pipe}_ports{ports}';binary=str(out/(name+'.vvp'));args=['iverilog','-g2012','-I','rtl/common','-s','tb_tmu_registered_ranges',f'-Ptb_tmu_registered_ranges.PORTS={ports}',f'-Ptb_tmu_registered_ranges.PIPE={pipe}','-o',binary,'rtl/nuca/tnca_tmu.v','tb/nuca/tb_tmu_pipeline_quiet.v'];step(name+'_build',args);text=step(name,['vvp',binary]);assert 'TMU REGISTERED RANGES PASS' in text;records.append(dict(name=name,status='functional-pass',stdout=text));print(text,flush=True)
s=(root/'rtl/nuca/tnca_tmu.v').read_text();needle="if (tl_pipeline_busy) mw_go = 1'b0;";assert s.count(needle)==1
mutant=out/'no_write_drain.v';mutant.write_text(s.replace(needle,"if (1'b0) mw_go = 1'b0;"));args[-2]=str(mutant);step('mutation_build',args);text=step('mutation_run',['vvp',binary],1);assert 'metadata write overtook accepted notice' in text,text;records.append(dict(name='write_drain_mutation',status='mutation-detected',stdout=text));print(text,flush=True)
(out/'report.json').write_text(json.dumps(records,indent=2)+'\n');print('TMU_PIPELINE_FUNCTIONAL_DONE',flush=True)
