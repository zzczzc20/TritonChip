


def forward(self, arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1):
    unsqueeze_4 = torch.ops.aten.unsqueeze.default(arg0_1, 0)
    expand = torch.ops.aten.expand.default(unsqueeze_4, [4, 1, -1]);  unsqueeze_4 = None
    slice_1 = torch.ops.aten.slice.Tensor(expand, 0, 1, 9223372036854775807);  expand = None
    expand_1 = torch.ops.aten.expand.default(slice_1, [3, -1, -1]);  slice_1 = None
    unsqueeze_5 = torch.ops.aten.unsqueeze.default(expand_1, 3);  expand_1 = None
    convert_element_type = torch.ops.prims.convert_element_type.default(unsqueeze_5, torch.float32);  unsqueeze_5 = None
    convert_element_type_1 = torch.ops.prims.convert_element_type.default(arg3_1, torch.float32);  arg3_1 = None
    mul = torch.ops.aten.mul.Tensor(convert_element_type, convert_element_type_1);  convert_element_type = convert_element_type_1 = None
    sin = torch.ops.aten.sin.default(mul)
    select_1 = torch.ops.aten.select.int(sin, 0, 0)
    slice_3 = torch.ops.aten.slice.Tensor(select_1, 2, 1, 33, 3);  select_1 = slice_3 = None
    select_3 = torch.ops.aten.select.int(sin, 0, 0);  select_3 = None
    select_2 = torch.ops.aten.select.int(sin, 0, 1)
    slice_2 = torch.ops.aten.slice.Tensor(select_2, 2, 1, 33, 3);  select_2 = None
    select_int = torch.ops.aten.select.int(sin, 0, 0)
    slice_scatter_default = torch.ops.aten.slice_scatter.default(select_int, slice_2, 2, 1, 33, 3);  select_int = slice_2 = None
    select_scatter_default = torch.ops.aten.select_scatter.default(sin, slice_scatter_default, 0, 0);  sin = slice_scatter_default = None
    select_8 = torch.ops.aten.select.int(select_scatter_default, 0, 0)
    slice_7 = torch.ops.aten.slice.Tensor(select_8, 2, 2, 30, 3);  select_8 = slice_7 = None
    cos = torch.ops.aten.cos.default(mul);  mul = None
    select_13 = torch.ops.aten.select.int(cos, 0, 0)
    slice_11 = torch.ops.aten.slice.Tensor(select_13, 2, 1, 33, 3);  select_13 = slice_11 = None
    select_15 = torch.ops.aten.select.int(cos, 0, 0);  select_15 = None
    select_14 = torch.ops.aten.select.int(cos, 0, 1)
    slice_10 = torch.ops.aten.slice.Tensor(select_14, 2, 1, 33, 3);  select_14 = None
    select_int_1 = torch.ops.aten.select.int(cos, 0, 0)
    slice_scatter_default_1 = torch.ops.aten.slice_scatter.default(select_int_1, slice_10, 2, 1, 33, 3);  select_int_1 = slice_10 = None
    select_scatter_default_1 = torch.ops.aten.select_scatter.default(cos, slice_scatter_default_1, 0, 0);  cos = slice_scatter_default_1 = None
    select_20 = torch.ops.aten.select.int(select_scatter_default_1, 0, 0)
    slice_15 = torch.ops.aten.slice.Tensor(select_20, 2, 2, 30, 3);  select_20 = slice_15 = None
    embedding = torch.ops.aten.embedding.default(arg2_1, arg1_1);  arg1_1 = None
    convert_element_type_4 = torch.ops.prims.convert_element_type.default(embedding, torch.float32)
    pow_1 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_4, 2)
    mean = torch.ops.aten.mean.dim(pow_1, [-1], True);  pow_1 = None
    add = torch.ops.aten.add.Tensor(mean, 1e-06);  mean = None
    rsqrt = torch.ops.aten.rsqrt.default(add);  add = None
    mul_3 = torch.ops.aten.mul.Tensor(convert_element_type_4, rsqrt);  convert_element_type_4 = rsqrt = None
    convert_element_type_5 = torch.ops.prims.convert_element_type.default(arg4_1, torch.float32);  arg4_1 = None
    add_1 = torch.ops.aten.add.Tensor(convert_element_type_5, 1.0);  convert_element_type_5 = None
    mul_4 = torch.ops.aten.mul.Tensor(mul_3, add_1);  mul_3 = add_1 = None
    convert_element_type_6 = torch.ops.prims.convert_element_type.default(mul_4, torch.bfloat16);  mul_4 = None
    view_2 = torch.ops.aten.reshape.default(convert_element_type_6, [128, 2048])
    permute = torch.ops.aten.permute.default(arg5_1, [1, 0]);  arg5_1 = None
    mm = torch.ops.aten.mm.default(view_2, permute);  view_2 = permute = None
    view_3 = torch.ops.aten.reshape.default(mm, [1, 128, 6144]);  mm = None
    permute_1 = torch.ops.aten.permute.default(view_3, [0, 2, 1]);  view_3 = None
    slice_18 = torch.ops.aten.slice.Tensor(permute_1, 2, -4, 9223372036854775807)
    copy_4 = torch.ops.aten.copy.default(arg9_1, slice_18);  slice_18 = None
    convert_element_type_15 = torch.ops.prims.convert_element_type.default(permute_1, torch.float32);  permute_1 = None
    constant_pad_nd = torch.ops.aten.constant_pad_nd.default(convert_element_type_15, [3, 3], 0.0);  convert_element_type_15 = None
    slice_19 = torch.ops.aten.slice.Tensor(constant_pad_nd, 2, 0, 131)
    squeeze = torch.ops.aten.squeeze.dim(arg10_1, 1);  arg10_1 = None
    unsqueeze_8 = torch.ops.aten.unsqueeze.default(squeeze, 1);  squeeze = None
    convert_element_type_16 = torch.ops.prims.convert_element_type.default(unsqueeze_8, torch.float32);  unsqueeze_8 = None
    select_25 = torch.ops.aten.select.int(convert_element_type_16, 1, 0)
    select_26 = torch.ops.aten.select.int(select_25, 1, 0);  select_25 = None
    view_11 = torch.ops.aten.reshape.default(select_26, [1, -1, 1]);  select_26 = None
    mul_5 = torch.ops.aten.mul.Tensor(slice_19, view_11);  slice_19 = view_11 = None
    slice_20 = torch.ops.aten.slice.Tensor(constant_pad_nd, 2, 1, 132)
    select_27 = torch.ops.aten.select.int(convert_element_type_16, 1, 0)
    select_28 = torch.ops.aten.select.int(select_27, 1, 1);  select_27 = None
    view_12 = torch.ops.aten.reshape.default(select_28, [1, -1, 1]);  select_28 = None
    mul_6 = torch.ops.aten.mul.Tensor(slice_20, view_12);  slice_20 = view_12 = None
    add_2 = torch.ops.aten.add.Tensor(mul_5, mul_6);  mul_5 = mul_6 = None
    slice_21 = torch.ops.aten.slice.Tensor(constant_pad_nd, 2, 2, 133)
    select_29 = torch.ops.aten.select.int(convert_element_type_16, 1, 0)
    select_30 = torch.ops.aten.select.int(select_29, 1, 2);  select_29 = None
    view_13 = torch.ops.aten.reshape.default(select_30, [1, -1, 1]);  select_30 = None
    mul_7 = torch.ops.aten.mul.Tensor(slice_21, view_13);  slice_21 = view_13 = None
    add_3 = torch.ops.aten.add.Tensor(add_2, mul_7);  add_2 = mul_7 = None
    slice_22 = torch.ops.aten.slice.Tensor(constant_pad_nd, 2, 3, 134);  constant_pad_nd = None
    select_31 = torch.ops.aten.select.int(convert_element_type_16, 1, 0);  convert_element_type_16 = None
    select_32 = torch.ops.aten.select.int(select_31, 1, 3);  select_31 = None
    view_14 = torch.ops.aten.reshape.default(select_32, [1, -1, 1]);  select_32 = None
    mul_8 = torch.ops.aten.mul.Tensor(slice_22, view_14);  slice_22 = view_14 = None
    add_4 = torch.ops.aten.add.Tensor(add_3, mul_8);  add_3 = mul_8 = None
    convert_element_type_17 = torch.ops.prims.convert_element_type.default(add_4, torch.bfloat16);  add_4 = None
    slice_23 = torch.ops.aten.slice.Tensor(convert_element_type_17, 2, 0, 128);  convert_element_type_17 = None
    convert_element_type_18 = torch.ops.prims.convert_element_type.default(slice_23, torch.float32);  slice_23 = None
    neg = torch.ops.aten.neg.default(convert_element_type_18)
    exp = torch.ops.aten.exp.default(neg);  neg = None
    add_5 = torch.ops.aten.add.Tensor(exp, 1);  exp = None
    div = torch.ops.aten.div.Tensor(convert_element_type_18, add_5);  convert_element_type_18 = add_5 = None
    convert_element_type_19 = torch.ops.prims.convert_element_type.default(div, torch.bfloat16);  div = None
    slice_24 = torch.ops.aten.slice.Tensor(convert_element_type_19, 2, -128, 9223372036854775807);  convert_element_type_19 = None
    permute_5 = torch.ops.aten.permute.default(slice_24, [0, 2, 1]);  slice_24 = None
    split_with_sizes = torch.ops.aten.split_with_sizes.default(permute_5, [2048, 2048, 2048], -1);  permute_5 = None
    getitem = split_with_sizes[0]
    getitem_1 = split_with_sizes[1]
    getitem_2 = split_with_sizes[2];  split_with_sizes = None
    full_2 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_1 = torch.ops.aten.exp.default(arg11_1);  arg11_1 = None
    neg_1 = torch.ops.aten.neg.default(exp_1);  exp_1 = None
    view_9 = torch.ops.aten.reshape.default(convert_element_type_6, [128, 2048])
    permute_4 = torch.ops.aten.permute.default(arg8_1, [1, 0]);  arg8_1 = None
    mm_3 = torch.ops.aten.mm.default(view_9, permute_4);  view_9 = permute_4 = None
    view_10 = torch.ops.aten.reshape.default(mm_3, [1, 128, 16]);  mm_3 = None
    convert_element_type_20 = torch.ops.prims.convert_element_type.default(view_10, torch.float32);  view_10 = None
    add_6 = torch.ops.aten.add.Tensor(convert_element_type_20, arg12_1);  convert_element_type_20 = arg12_1 = None
    gt = torch.ops.aten.gt.Scalar(add_6, 20)
    exp_2 = torch.ops.aten.exp.default(add_6)
    log1p = torch.ops.aten.log1p.default(exp_2);  exp_2 = None
    where_1 = torch.ops.aten.where.self(gt, add_6, log1p);  gt = add_6 = log1p = None
    mul_9 = torch.ops.aten.mul.Tensor(neg_1, where_1);  neg_1 = where_1 = None
    permute_10 = torch.ops.aten.permute.default(mul_9, [0, 2, 1]);  mul_9 = None
    view_22 = torch.ops.aten.reshape.default(permute_10, [1, 16, 2, 64]);  permute_10 = None
    cumsum = torch.ops.aten.cumsum.default(view_22, 3);  view_22 = None
    select_33 = torch.ops.aten.select.int(cumsum, 3, -1)
    exp_7 = torch.ops.aten.exp.default(select_33);  select_33 = None
    unsqueeze_18 = torch.ops.aten.unsqueeze.default(exp_7, 3);  exp_7 = None
    unsqueeze_19 = torch.ops.aten.unsqueeze.default(unsqueeze_18, 4);  unsqueeze_18 = None
    select_40 = torch.ops.aten.select.int(unsqueeze_19, 2, 0)
    mul_22 = torch.ops.aten.mul.Tensor(full_2, select_40);  select_40 = None
    view_16 = torch.ops.aten.reshape.default(getitem_1, [1, 128, 16, 128]);  getitem_1 = None
    permute_7 = torch.ops.aten.permute.default(view_16, [0, 2, 1, 3]);  view_16 = None
    convert_element_type_22 = torch.ops.prims.convert_element_type.default(permute_7, torch.float32);  permute_7 = None
    clone_5 = torch.ops.aten.clone.default(convert_element_type_22, memory_format = torch.contiguous_format);  convert_element_type_22 = None
    mul_12 = torch.ops.aten.mul.Tensor(clone_5, clone_5)
    sum_2 = torch.ops.aten.sum.dim_IntList(mul_12, [-1], True);  mul_12 = None
    add_8 = torch.ops.aten.add.Tensor(sum_2, 1e-06);  sum_2 = None
    rsqrt_2 = torch.ops.aten.rsqrt.default(add_8);  add_8 = None
    mul_13 = torch.ops.aten.mul.Tensor(clone_5, rsqrt_2);  clone_5 = rsqrt_2 = None
    view_19 = torch.ops.aten.reshape.default(mul_13, [1, 16, -1, 64, 128])
    slice_25 = torch.ops.aten.slice.Tensor(cumsum, 3, -1, 9223372036854775807)
    sub_2 = torch.ops.aten.sub.Tensor(slice_25, cumsum);  slice_25 = None
    exp_6 = torch.ops.aten.exp.default(sub_2);  sub_2 = None
    unsqueeze_17 = torch.ops.aten.unsqueeze.default(exp_6, -1);  exp_6 = None
    mul_21 = torch.ops.aten.mul.Tensor(view_19, unsqueeze_17);  unsqueeze_17 = None
    select_41 = torch.ops.aten.select.int(mul_21, 2, 0)
    permute_14 = torch.ops.aten.permute.default(select_41, [0, 1, 3, 2]);  select_41 = None
    expand_14 = torch.ops.aten.expand.default(permute_14, [1, 16, 128, 64]);  permute_14 = None
    view_38 = torch.ops.aten.reshape.default(expand_14, [16, 128, 64]);  expand_14 = None
    view_7 = torch.ops.aten.reshape.default(convert_element_type_6, [128, 2048])
    permute_3 = torch.ops.aten.permute.default(arg7_1, [1, 0]);  arg7_1 = None
    mm_2 = torch.ops.aten.mm.default(view_7, permute_3);  view_7 = permute_3 = None
    view_8 = torch.ops.aten.reshape.default(mm_2, [1, 128, 16]);  mm_2 = None
    sigmoid = torch.ops.aten.sigmoid.default(view_8);  view_8 = None
    permute_9 = torch.ops.aten.permute.default(sigmoid, [0, 2, 1]);  sigmoid = None
    convert_element_type_24 = torch.ops.prims.convert_element_type.default(permute_9, torch.float32);  permute_9 = None
    clone_7 = torch.ops.aten.clone.default(convert_element_type_24, memory_format = torch.contiguous_format);  convert_element_type_24 = None
    unsqueeze_10 = torch.ops.aten.unsqueeze.default(clone_7, -1)
    mul_16 = torch.ops.aten.mul.Tensor(mul_13, unsqueeze_10);  mul_13 = unsqueeze_10 = None
    view_20 = torch.ops.aten.reshape.default(mul_16, [1, 16, -1, 64, 128]);  mul_16 = None
    expand_4 = torch.ops.aten.expand.default(view_20, [1, 16, 2, 64, 128])
    view_23 = torch.ops.aten.reshape.default(expand_4, [32, 64, 128]);  expand_4 = None
    permute_11 = torch.ops.aten.permute.default(view_19, [0, 1, 2, 4, 3])
    expand_5 = torch.ops.aten.expand.default(permute_11, [1, 16, 2, 128, 64]);  permute_11 = None
    view_24 = torch.ops.aten.reshape.default(expand_5, [32, 128, 64]);  expand_5 = None
    bmm = torch.ops.aten.bmm.default(view_23, view_24);  view_23 = view_24 = None
    view_25 = torch.ops.aten.reshape.default(bmm, [1, 16, 2, 64, 64]);  bmm = None
    iota_1 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_11 = torch.ops.aten.unsqueeze.default(iota_1, -2);  iota_1 = None
    iota_2 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_12 = torch.ops.aten.unsqueeze.default(iota_2, -1);  iota_2 = None
    sub = torch.ops.aten.sub.Tensor(unsqueeze_11, unsqueeze_12);  unsqueeze_11 = unsqueeze_12 = None
    ge = torch.ops.aten.ge.Scalar(sub, 1);  sub = None
    full_default_2 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and = torch.ops.aten.logical_and.default(ge, full_default_2);  ge = full_default_2 = None
    full_default_3 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_13 = torch.ops.aten.unsqueeze.default(cumsum, 4)
    unsqueeze_14 = torch.ops.aten.unsqueeze.default(cumsum, 3)
    sub_1 = torch.ops.aten.sub.Tensor(unsqueeze_13, unsqueeze_14);  unsqueeze_13 = unsqueeze_14 = None
    where_2 = torch.ops.aten.where.self(logical_and, full_default_3, sub_1);  logical_and = full_default_3 = sub_1 = None
    exp_3 = torch.ops.aten.exp.default(where_2);  where_2 = None
    mul_17 = torch.ops.aten.mul.Tensor(view_25, exp_3);  view_25 = None
    view_17 = torch.ops.aten.reshape.default(getitem_2, [1, 128, 16, 128]);  getitem_2 = None
    permute_8 = torch.ops.aten.permute.default(view_17, [0, 2, 1, 3]);  view_17 = None
    convert_element_type_23 = torch.ops.prims.convert_element_type.default(permute_8, torch.float32);  permute_8 = None
    clone_6 = torch.ops.aten.clone.default(convert_element_type_23, memory_format = torch.contiguous_format);  convert_element_type_23 = None
    unsqueeze_9 = torch.ops.aten.unsqueeze.default(clone_7, -1);  clone_7 = None
    mul_15 = torch.ops.aten.mul.Tensor(clone_6, unsqueeze_9);  clone_6 = unsqueeze_9 = None
    view_21 = torch.ops.aten.reshape.default(mul_15, [1, 16, -1, 64, 128]);  mul_15 = None
    linalg_solve_triangular = torch.ops.aten.linalg_solve_triangular.default(mul_17, view_21, upper = False, unitriangular = True);  view_21 = None
    select_34 = torch.ops.aten.select.int(linalg_solve_triangular, 2, 0)
    exp_4 = torch.ops.aten.exp.default(cumsum)
    unsqueeze_15 = torch.ops.aten.unsqueeze.default(exp_4, -1);  exp_4 = None
    mul_19 = torch.ops.aten.mul.Tensor(view_20, unsqueeze_15);  view_20 = unsqueeze_15 = None
    linalg_solve_triangular_1 = torch.ops.aten.linalg_solve_triangular.default(mul_17, mul_19, upper = False, unitriangular = True);  mul_17 = mul_19 = None
    select_35 = torch.ops.aten.select.int(linalg_solve_triangular_1, 2, 0)
    expand_8 = torch.ops.aten.expand.default(select_35, [1, 16, 64, 128]);  select_35 = None
    view_29 = torch.ops.aten.reshape.default(expand_8, [16, 64, 128]);  expand_8 = None
    expand_9 = torch.ops.aten.expand.default(full_2, [1, 16, 128, 128])
    view_30 = torch.ops.aten.reshape.default(expand_9, [16, 128, 128]);  expand_9 = None
    bmm_2 = torch.ops.aten.bmm.default(view_29, view_30);  view_29 = view_30 = None
    view_31 = torch.ops.aten.reshape.default(bmm_2, [1, 16, 64, 128]);  bmm_2 = None
    sub_3 = torch.ops.aten.sub.Tensor(select_34, view_31);  select_34 = view_31 = None
    expand_15 = torch.ops.aten.expand.default(sub_3, [1, 16, 64, 128])
    view_39 = torch.ops.aten.reshape.default(expand_15, [16, 64, 128]);  expand_15 = None
    bmm_5 = torch.ops.aten.bmm.default(view_38, view_39);  view_38 = view_39 = None
    view_40 = torch.ops.aten.reshape.default(bmm_5, [1, 16, 128, 128]);  bmm_5 = None
    add_10 = torch.ops.aten.add.Tensor(mul_22, view_40);  mul_22 = view_40 = None
    select_49 = torch.ops.aten.select.int(unsqueeze_19, 2, 1);  unsqueeze_19 = None
    mul_23 = torch.ops.aten.mul.Tensor(add_10, select_49);  select_49 = None
    select_50 = torch.ops.aten.select.int(mul_21, 2, 1);  mul_21 = None
    permute_15 = torch.ops.aten.permute.default(select_50, [0, 1, 3, 2]);  select_50 = None
    expand_22 = torch.ops.aten.expand.default(permute_15, [1, 16, 128, 64]);  permute_15 = None
    view_50 = torch.ops.aten.reshape.default(expand_22, [16, 128, 64]);  expand_22 = None
    select_42 = torch.ops.aten.select.int(linalg_solve_triangular, 2, 1);  linalg_solve_triangular = None
    select_43 = torch.ops.aten.select.int(linalg_solve_triangular_1, 2, 1);  linalg_solve_triangular_1 = None
    expand_16 = torch.ops.aten.expand.default(select_43, [1, 16, 64, 128]);  select_43 = None
    view_41 = torch.ops.aten.reshape.default(expand_16, [16, 64, 128]);  expand_16 = None
    expand_17 = torch.ops.aten.expand.default(add_10, [1, 16, 128, 128])
    view_42 = torch.ops.aten.reshape.default(expand_17, [16, 128, 128]);  expand_17 = None
    bmm_6 = torch.ops.aten.bmm.default(view_41, view_42);  view_41 = view_42 = None
    view_43 = torch.ops.aten.reshape.default(bmm_6, [1, 16, 64, 128]);  bmm_6 = None
    sub_4 = torch.ops.aten.sub.Tensor(select_42, view_43);  select_42 = view_43 = None
    expand_23 = torch.ops.aten.expand.default(sub_4, [1, 16, 64, 128])
    view_51 = torch.ops.aten.reshape.default(expand_23, [16, 64, 128]);  expand_23 = None
    bmm_9 = torch.ops.aten.bmm.default(view_50, view_51);  view_50 = view_51 = None
    view_52 = torch.ops.aten.reshape.default(bmm_9, [1, 16, 128, 128]);  bmm_9 = None
    add_12 = torch.ops.aten.add.Tensor(mul_23, view_52);  mul_23 = view_52 = None
    full_3 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_13 = torch.ops.aten.permute.default(full_3, [0, 1, 2, 4, 3]);  full_3 = None
    select_38 = torch.ops.aten.select.int(permute_13, 2, 0)
    view_15 = torch.ops.aten.reshape.default(getitem, [1, 128, 16, 128]);  getitem = None
    permute_6 = torch.ops.aten.permute.default(view_15, [0, 2, 1, 3]);  view_15 = None
    convert_element_type_21 = torch.ops.prims.convert_element_type.default(permute_6, torch.float32);  permute_6 = None
    clone_4 = torch.ops.aten.clone.default(convert_element_type_21, memory_format = torch.contiguous_format);  convert_element_type_21 = None
    mul_10 = torch.ops.aten.mul.Tensor(clone_4, clone_4)
    sum_1 = torch.ops.aten.sum.dim_IntList(mul_10, [-1], True);  mul_10 = None
    add_7 = torch.ops.aten.add.Tensor(sum_1, 1e-06);  sum_1 = None
    rsqrt_1 = torch.ops.aten.rsqrt.default(add_7);  add_7 = None
    mul_11 = torch.ops.aten.mul.Tensor(clone_4, rsqrt_1);  clone_4 = rsqrt_1 = None
    mul_14 = torch.ops.aten.mul.Tensor(mul_11, 0.08838834764831845);  mul_11 = None
    view_18 = torch.ops.aten.reshape.default(mul_14, [1, 16, -1, 64, 128]);  mul_14 = None
    exp_5 = torch.ops.aten.exp.default(cumsum);  cumsum = None
    unsqueeze_16 = torch.ops.aten.unsqueeze.default(exp_5, -1);  exp_5 = None
    mul_20 = torch.ops.aten.mul.Tensor(view_18, unsqueeze_16);  unsqueeze_16 = None
    select_36 = torch.ops.aten.select.int(mul_20, 2, 0)
    expand_10 = torch.ops.aten.expand.default(select_36, [1, 16, 64, 128]);  select_36 = None
    view_32 = torch.ops.aten.reshape.default(expand_10, [16, 64, 128]);  expand_10 = None
    expand_11 = torch.ops.aten.expand.default(full_2, [1, 16, 128, 128]);  full_2 = None
    view_33 = torch.ops.aten.reshape.default(expand_11, [16, 128, 128]);  expand_11 = None
    bmm_3 = torch.ops.aten.bmm.default(view_32, view_33);  view_32 = view_33 = None
    view_34 = torch.ops.aten.reshape.default(bmm_3, [1, 16, 64, 128]);  bmm_3 = None
    expand_6 = torch.ops.aten.expand.default(view_18, [1, 16, 2, 64, 128]);  view_18 = None
    view_26 = torch.ops.aten.reshape.default(expand_6, [32, 64, 128]);  expand_6 = None
    permute_12 = torch.ops.aten.permute.default(view_19, [0, 1, 2, 4, 3]);  view_19 = None
    expand_7 = torch.ops.aten.expand.default(permute_12, [1, 16, 2, 128, 64]);  permute_12 = None
    view_27 = torch.ops.aten.reshape.default(expand_7, [32, 128, 64]);  expand_7 = None
    bmm_1 = torch.ops.aten.bmm.default(view_26, view_27);  view_26 = view_27 = None
    view_28 = torch.ops.aten.reshape.default(bmm_1, [1, 16, 2, 64, 64]);  bmm_1 = None
    mul_18 = torch.ops.aten.mul.Tensor(view_28, exp_3);  view_28 = exp_3 = None
    select_37 = torch.ops.aten.select.int(mul_18, 2, 0)
    expand_12 = torch.ops.aten.expand.default(select_37, [1, 16, 64, 64]);  select_37 = None
    view_35 = torch.ops.aten.reshape.default(expand_12, [16, 64, 64]);  expand_12 = None
    expand_13 = torch.ops.aten.expand.default(sub_3, [1, 16, 64, 128]);  sub_3 = None
    view_36 = torch.ops.aten.reshape.default(expand_13, [16, 64, 128]);  expand_13 = None
    bmm_4 = torch.ops.aten.bmm.default(view_35, view_36);  view_35 = view_36 = None
    view_37 = torch.ops.aten.reshape.default(bmm_4, [1, 16, 64, 128]);  bmm_4 = None
    add_9 = torch.ops.aten.add.Tensor(view_34, view_37);  view_34 = view_37 = None
    copy_5 = torch.ops.aten.copy.default(select_38, add_9);  select_38 = add_9 = None
    select_scatter_default_2 = torch.ops.aten.select_scatter.default(permute_13, copy_5, 2, 0);  permute_13 = copy_5 = None
    select_47 = torch.ops.aten.select.int(select_scatter_default_2, 2, 1)
    select_44 = torch.ops.aten.select.int(mul_20, 2, 1);  mul_20 = None
    expand_18 = torch.ops.aten.expand.default(select_44, [1, 16, 64, 128]);  select_44 = None
    view_44 = torch.ops.aten.reshape.default(expand_18, [16, 64, 128]);  expand_18 = None
    expand_19 = torch.ops.aten.expand.default(add_10, [1, 16, 128, 128]);  add_10 = None
    view_45 = torch.ops.aten.reshape.default(expand_19, [16, 128, 128]);  expand_19 = None
    bmm_7 = torch.ops.aten.bmm.default(view_44, view_45);  view_44 = view_45 = None
    view_46 = torch.ops.aten.reshape.default(bmm_7, [1, 16, 64, 128]);  bmm_7 = None
    select_45 = torch.ops.aten.select.int(mul_18, 2, 1);  mul_18 = None
    expand_20 = torch.ops.aten.expand.default(select_45, [1, 16, 64, 64]);  select_45 = None
    view_47 = torch.ops.aten.reshape.default(expand_20, [16, 64, 64]);  expand_20 = None
    expand_21 = torch.ops.aten.expand.default(sub_4, [1, 16, 64, 128]);  sub_4 = None
    view_48 = torch.ops.aten.reshape.default(expand_21, [16, 64, 128]);  expand_21 = None
    bmm_8 = torch.ops.aten.bmm.default(view_47, view_48);  view_47 = view_48 = None
    view_49 = torch.ops.aten.reshape.default(bmm_8, [1, 16, 64, 128]);  bmm_8 = None
    add_11 = torch.ops.aten.add.Tensor(view_46, view_49);  view_46 = view_49 = None
    copy_6 = torch.ops.aten.copy.default(select_47, add_11);  select_47 = add_11 = None
    select_scatter_default_3 = torch.ops.aten.select_scatter.default(select_scatter_default_2, copy_6, 2, 1);  select_scatter_default_2 = copy_6 = None
    clone_9 = torch.ops.aten.clone.default(select_scatter_default_3, memory_format = torch.contiguous_format);  select_scatter_default_3 = None
    view_53 = torch.ops.aten.reshape.default(clone_9, [1, 16, 128, 128]);  clone_9 = None
    permute_16 = torch.ops.aten.permute.default(view_53, [0, 2, 1, 3]);  view_53 = None
    convert_element_type_25 = torch.ops.prims.convert_element_type.default(permute_16, torch.bfloat16);  permute_16 = None
    clone_10 = torch.ops.aten.clone.default(convert_element_type_25, memory_format = torch.contiguous_format);  convert_element_type_25 = None
    view_54 = torch.ops.aten.reshape.default(clone_10, [-1, 128]);  clone_10 = None
    convert_element_type_26 = torch.ops.prims.convert_element_type.default(view_54, torch.float32);  view_54 = None
    pow_2 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_26, 2)
    mean_1 = torch.ops.aten.mean.dim(pow_2, [-1], True);  pow_2 = None
    add_13 = torch.ops.aten.add.Tensor(mean_1, 1e-06);  mean_1 = None
    rsqrt_3 = torch.ops.aten.rsqrt.default(add_13);  add_13 = None
    mul_24 = torch.ops.aten.mul.Tensor(convert_element_type_26, rsqrt_3);  convert_element_type_26 = rsqrt_3 = None
    convert_element_type_27 = torch.ops.prims.convert_element_type.default(mul_24, torch.bfloat16);  mul_24 = None
    mul_25 = torch.ops.aten.mul.Tensor(arg14_1, convert_element_type_27);  arg14_1 = convert_element_type_27 = None
    view_4 = torch.ops.aten.reshape.default(convert_element_type_6, [128, 2048]);  convert_element_type_6 = None
    permute_2 = torch.ops.aten.permute.default(arg6_1, [1, 0]);  arg6_1 = None
    mm_1 = torch.ops.aten.mm.default(view_4, permute_2);  view_4 = permute_2 = None
    view_5 = torch.ops.aten.reshape.default(mm_1, [1, 128, 2048]);  mm_1 = None
    view_6 = torch.ops.aten.reshape.default(view_5, [1, 128, -1, 128]);  view_5 = None
    view_55 = torch.ops.aten.reshape.default(view_6, [-1, 128]);  view_6 = None
    convert_element_type_28 = torch.ops.prims.convert_element_type.default(view_55, torch.float32);  view_55 = None
    neg_2 = torch.ops.aten.neg.default(convert_element_type_28)
    exp_8 = torch.ops.aten.exp.default(neg_2);  neg_2 = None
    add_14 = torch.ops.aten.add.Tensor(exp_8, 1);  exp_8 = None
    div_1 = torch.ops.aten.div.Tensor(convert_element_type_28, add_14);  convert_element_type_28 = add_14 = None
    mul_26 = torch.ops.aten.mul.Tensor(mul_25, div_1);  mul_25 = div_1 = None
    convert_element_type_29 = torch.ops.prims.convert_element_type.default(mul_26, torch.bfloat16);  mul_26 = None
    view_56 = torch.ops.aten.reshape.default(convert_element_type_29, [1, 128, -1]);  convert_element_type_29 = None
    view_57 = torch.ops.aten.reshape.default(view_56, [128, 2048]);  view_56 = None
    permute_17 = torch.ops.aten.permute.default(arg15_1, [1, 0]);  arg15_1 = None
    mm_4 = torch.ops.aten.mm.default(view_57, permute_17);  view_57 = permute_17 = None
    view_58 = torch.ops.aten.reshape.default(mm_4, [1, 128, 2048]);  mm_4 = None
    add_15 = torch.ops.aten.add.Tensor(embedding, view_58);  embedding = view_58 = None
    convert_element_type_32 = torch.ops.prims.convert_element_type.default(add_15, torch.float32)
    pow_3 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_32, 2)
    mean_2 = torch.ops.aten.mean.dim(pow_3, [-1], True);  pow_3 = None
    add_16 = torch.ops.aten.add.Tensor(mean_2, 1e-06);  mean_2 = None
    rsqrt_4 = torch.ops.aten.rsqrt.default(add_16);  add_16 = None
    mul_27 = torch.ops.aten.mul.Tensor(convert_element_type_32, rsqrt_4);  convert_element_type_32 = rsqrt_4 = None
    convert_element_type_33 = torch.ops.prims.convert_element_type.default(arg16_1, torch.float32);  arg16_1 = None
    add_17 = torch.ops.aten.add.Tensor(convert_element_type_33, 1.0);  convert_element_type_33 = None
    mul_28 = torch.ops.aten.mul.Tensor(mul_27, add_17);  mul_27 = add_17 = None
    convert_element_type_34 = torch.ops.prims.convert_element_type.default(mul_28, torch.bfloat16);  mul_28 = None
    view_59 = torch.ops.aten.reshape.default(convert_element_type_34, [128, 2048])
    permute_18 = torch.ops.aten.permute.default(arg17_1, [1, 0]);  arg17_1 = None
    mm_5 = torch.ops.aten.mm.default(view_59, permute_18);  view_59 = permute_18 = None
    view_60 = torch.ops.aten.reshape.default(mm_5, [1, 128, 6144]);  mm_5 = None
    convert_element_type_37 = torch.ops.prims.convert_element_type.default(view_60, torch.float32);  view_60 = None
    neg_3 = torch.ops.aten.neg.default(convert_element_type_37)
    exp_9 = torch.ops.aten.exp.default(neg_3);  neg_3 = None
    add_18 = torch.ops.aten.add.Tensor(exp_9, 1);  exp_9 = None
    div_2 = torch.ops.aten.div.Tensor(convert_element_type_37, add_18);  convert_element_type_37 = add_18 = None
    convert_element_type_38 = torch.ops.prims.convert_element_type.default(div_2, torch.bfloat16);  div_2 = None
    view_61 = torch.ops.aten.reshape.default(convert_element_type_34, [128, 2048]);  convert_element_type_34 = None
    permute_19 = torch.ops.aten.permute.default(arg18_1, [1, 0]);  arg18_1 = None
    mm_6 = torch.ops.aten.mm.default(view_61, permute_19);  view_61 = permute_19 = None
    view_62 = torch.ops.aten.reshape.default(mm_6, [1, 128, 6144]);  mm_6 = None
    mul_29 = torch.ops.aten.mul.Tensor(convert_element_type_38, view_62);  convert_element_type_38 = view_62 = None
    view_63 = torch.ops.aten.reshape.default(mul_29, [128, 6144]);  mul_29 = None
    permute_20 = torch.ops.aten.permute.default(arg19_1, [1, 0]);  arg19_1 = None
    mm_7 = torch.ops.aten.mm.default(view_63, permute_20);  view_63 = permute_20 = None
    view_64 = torch.ops.aten.reshape.default(mm_7, [1, 128, 2048]);  mm_7 = None
    add_19 = torch.ops.aten.add.Tensor(add_15, view_64);  add_15 = view_64 = None
    convert_element_type_43 = torch.ops.prims.convert_element_type.default(add_19, torch.float32)
    pow_4 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_43, 2)
    mean_3 = torch.ops.aten.mean.dim(pow_4, [-1], True);  pow_4 = None
    add_20 = torch.ops.aten.add.Tensor(mean_3, 1e-06);  mean_3 = None
    rsqrt_5 = torch.ops.aten.rsqrt.default(add_20);  add_20 = None
    mul_30 = torch.ops.aten.mul.Tensor(convert_element_type_43, rsqrt_5);  convert_element_type_43 = rsqrt_5 = None
    convert_element_type_44 = torch.ops.prims.convert_element_type.default(arg20_1, torch.float32);  arg20_1 = None
    add_21 = torch.ops.aten.add.Tensor(convert_element_type_44, 1.0);  convert_element_type_44 = None
    mul_31 = torch.ops.aten.mul.Tensor(mul_30, add_21);  mul_30 = add_21 = None
    convert_element_type_45 = torch.ops.prims.convert_element_type.default(mul_31, torch.bfloat16);  mul_31 = None
    view_65 = torch.ops.aten.reshape.default(convert_element_type_45, [128, 2048])
    permute_21 = torch.ops.aten.permute.default(arg21_1, [1, 0]);  arg21_1 = None
    mm_8 = torch.ops.aten.mm.default(view_65, permute_21);  view_65 = permute_21 = None
    view_66 = torch.ops.aten.reshape.default(mm_8, [1, 128, 6144]);  mm_8 = None
    permute_22 = torch.ops.aten.permute.default(view_66, [0, 2, 1]);  view_66 = None
    slice_26 = torch.ops.aten.slice.Tensor(permute_22, 2, -4, 9223372036854775807)
    copy_8 = torch.ops.aten.copy.default(arg25_1, slice_26);  slice_26 = None
    convert_element_type_54 = torch.ops.prims.convert_element_type.default(permute_22, torch.float32);  permute_22 = None
    constant_pad_nd_6 = torch.ops.aten.constant_pad_nd.default(convert_element_type_54, [3, 3], 0.0);  convert_element_type_54 = None
    slice_27 = torch.ops.aten.slice.Tensor(constant_pad_nd_6, 2, 0, 131)
    squeeze_1 = torch.ops.aten.squeeze.dim(arg26_1, 1);  arg26_1 = None
    unsqueeze_20 = torch.ops.aten.unsqueeze.default(squeeze_1, 1);  squeeze_1 = None
    convert_element_type_55 = torch.ops.prims.convert_element_type.default(unsqueeze_20, torch.float32);  unsqueeze_20 = None
    select_51 = torch.ops.aten.select.int(convert_element_type_55, 1, 0)
    select_52 = torch.ops.aten.select.int(select_51, 1, 0);  select_51 = None
    view_74 = torch.ops.aten.reshape.default(select_52, [1, -1, 1]);  select_52 = None
    mul_32 = torch.ops.aten.mul.Tensor(slice_27, view_74);  slice_27 = view_74 = None
    slice_28 = torch.ops.aten.slice.Tensor(constant_pad_nd_6, 2, 1, 132)
    select_53 = torch.ops.aten.select.int(convert_element_type_55, 1, 0)
    select_54 = torch.ops.aten.select.int(select_53, 1, 1);  select_53 = None
    view_75 = torch.ops.aten.reshape.default(select_54, [1, -1, 1]);  select_54 = None
    mul_33 = torch.ops.aten.mul.Tensor(slice_28, view_75);  slice_28 = view_75 = None
    add_22 = torch.ops.aten.add.Tensor(mul_32, mul_33);  mul_32 = mul_33 = None
    slice_29 = torch.ops.aten.slice.Tensor(constant_pad_nd_6, 2, 2, 133)
    select_55 = torch.ops.aten.select.int(convert_element_type_55, 1, 0)
    select_56 = torch.ops.aten.select.int(select_55, 1, 2);  select_55 = None
    view_76 = torch.ops.aten.reshape.default(select_56, [1, -1, 1]);  select_56 = None
    mul_34 = torch.ops.aten.mul.Tensor(slice_29, view_76);  slice_29 = view_76 = None
    add_23 = torch.ops.aten.add.Tensor(add_22, mul_34);  add_22 = mul_34 = None
    slice_30 = torch.ops.aten.slice.Tensor(constant_pad_nd_6, 2, 3, 134);  constant_pad_nd_6 = None
    select_57 = torch.ops.aten.select.int(convert_element_type_55, 1, 0);  convert_element_type_55 = None
    select_58 = torch.ops.aten.select.int(select_57, 1, 3);  select_57 = None
    view_77 = torch.ops.aten.reshape.default(select_58, [1, -1, 1]);  select_58 = None
    mul_35 = torch.ops.aten.mul.Tensor(slice_30, view_77);  slice_30 = view_77 = None
    add_24 = torch.ops.aten.add.Tensor(add_23, mul_35);  add_23 = mul_35 = None
    convert_element_type_56 = torch.ops.prims.convert_element_type.default(add_24, torch.bfloat16);  add_24 = None
    slice_31 = torch.ops.aten.slice.Tensor(convert_element_type_56, 2, 0, 128);  convert_element_type_56 = None
    convert_element_type_57 = torch.ops.prims.convert_element_type.default(slice_31, torch.float32);  slice_31 = None
    neg_4 = torch.ops.aten.neg.default(convert_element_type_57)
    exp_10 = torch.ops.aten.exp.default(neg_4);  neg_4 = None
    add_25 = torch.ops.aten.add.Tensor(exp_10, 1);  exp_10 = None
    div_3 = torch.ops.aten.div.Tensor(convert_element_type_57, add_25);  convert_element_type_57 = add_25 = None
    convert_element_type_58 = torch.ops.prims.convert_element_type.default(div_3, torch.bfloat16);  div_3 = None
    slice_32 = torch.ops.aten.slice.Tensor(convert_element_type_58, 2, -128, 9223372036854775807);  convert_element_type_58 = None
    permute_26 = torch.ops.aten.permute.default(slice_32, [0, 2, 1]);  slice_32 = None
    split_with_sizes_1 = torch.ops.aten.split_with_sizes.default(permute_26, [2048, 2048, 2048], -1);  permute_26 = None
    getitem_3 = split_with_sizes_1[0]
    getitem_4 = split_with_sizes_1[1]
    getitem_5 = split_with_sizes_1[2];  split_with_sizes_1 = None
    full_5 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_11 = torch.ops.aten.exp.default(arg27_1);  arg27_1 = None
    neg_5 = torch.ops.aten.neg.default(exp_11);  exp_11 = None
    view_72 = torch.ops.aten.reshape.default(convert_element_type_45, [128, 2048])
    permute_25 = torch.ops.aten.permute.default(arg24_1, [1, 0]);  arg24_1 = None
    mm_11 = torch.ops.aten.mm.default(view_72, permute_25);  view_72 = permute_25 = None
    view_73 = torch.ops.aten.reshape.default(mm_11, [1, 128, 16]);  mm_11 = None
    convert_element_type_59 = torch.ops.prims.convert_element_type.default(view_73, torch.float32);  view_73 = None
    add_26 = torch.ops.aten.add.Tensor(convert_element_type_59, arg28_1);  convert_element_type_59 = arg28_1 = None
    gt_1 = torch.ops.aten.gt.Scalar(add_26, 20)
    exp_12 = torch.ops.aten.exp.default(add_26)
    log1p_1 = torch.ops.aten.log1p.default(exp_12);  exp_12 = None
    where_3 = torch.ops.aten.where.self(gt_1, add_26, log1p_1);  gt_1 = add_26 = log1p_1 = None
    mul_36 = torch.ops.aten.mul.Tensor(neg_5, where_3);  neg_5 = where_3 = None
    permute_31 = torch.ops.aten.permute.default(mul_36, [0, 2, 1]);  mul_36 = None
    view_85 = torch.ops.aten.reshape.default(permute_31, [1, 16, 2, 64]);  permute_31 = None
    cumsum_1 = torch.ops.aten.cumsum.default(view_85, 3);  view_85 = None
    select_59 = torch.ops.aten.select.int(cumsum_1, 3, -1)
    exp_17 = torch.ops.aten.exp.default(select_59);  select_59 = None
    unsqueeze_30 = torch.ops.aten.unsqueeze.default(exp_17, 3);  exp_17 = None
    unsqueeze_31 = torch.ops.aten.unsqueeze.default(unsqueeze_30, 4);  unsqueeze_30 = None
    select_66 = torch.ops.aten.select.int(unsqueeze_31, 2, 0)
    mul_49 = torch.ops.aten.mul.Tensor(full_5, select_66);  select_66 = None
    view_79 = torch.ops.aten.reshape.default(getitem_4, [1, 128, 16, 128]);  getitem_4 = None
    permute_28 = torch.ops.aten.permute.default(view_79, [0, 2, 1, 3]);  view_79 = None
    convert_element_type_61 = torch.ops.prims.convert_element_type.default(permute_28, torch.float32);  permute_28 = None
    clone_12 = torch.ops.aten.clone.default(convert_element_type_61, memory_format = torch.contiguous_format);  convert_element_type_61 = None
    mul_39 = torch.ops.aten.mul.Tensor(clone_12, clone_12)
    sum_4 = torch.ops.aten.sum.dim_IntList(mul_39, [-1], True);  mul_39 = None
    add_28 = torch.ops.aten.add.Tensor(sum_4, 1e-06);  sum_4 = None
    rsqrt_7 = torch.ops.aten.rsqrt.default(add_28);  add_28 = None
    mul_40 = torch.ops.aten.mul.Tensor(clone_12, rsqrt_7);  clone_12 = rsqrt_7 = None
    view_82 = torch.ops.aten.reshape.default(mul_40, [1, 16, -1, 64, 128])
    slice_33 = torch.ops.aten.slice.Tensor(cumsum_1, 3, -1, 9223372036854775807)
    sub_7 = torch.ops.aten.sub.Tensor(slice_33, cumsum_1);  slice_33 = None
    exp_16 = torch.ops.aten.exp.default(sub_7);  sub_7 = None
    unsqueeze_29 = torch.ops.aten.unsqueeze.default(exp_16, -1);  exp_16 = None
    mul_48 = torch.ops.aten.mul.Tensor(view_82, unsqueeze_29);  unsqueeze_29 = None
    select_67 = torch.ops.aten.select.int(mul_48, 2, 0)
    permute_35 = torch.ops.aten.permute.default(select_67, [0, 1, 3, 2]);  select_67 = None
    expand_34 = torch.ops.aten.expand.default(permute_35, [1, 16, 128, 64]);  permute_35 = None
    view_101 = torch.ops.aten.reshape.default(expand_34, [16, 128, 64]);  expand_34 = None
    view_70 = torch.ops.aten.reshape.default(convert_element_type_45, [128, 2048])
    permute_24 = torch.ops.aten.permute.default(arg23_1, [1, 0]);  arg23_1 = None
    mm_10 = torch.ops.aten.mm.default(view_70, permute_24);  view_70 = permute_24 = None
    view_71 = torch.ops.aten.reshape.default(mm_10, [1, 128, 16]);  mm_10 = None
    sigmoid_1 = torch.ops.aten.sigmoid.default(view_71);  view_71 = None
    permute_30 = torch.ops.aten.permute.default(sigmoid_1, [0, 2, 1]);  sigmoid_1 = None
    convert_element_type_63 = torch.ops.prims.convert_element_type.default(permute_30, torch.float32);  permute_30 = None
    clone_14 = torch.ops.aten.clone.default(convert_element_type_63, memory_format = torch.contiguous_format);  convert_element_type_63 = None
    unsqueeze_22 = torch.ops.aten.unsqueeze.default(clone_14, -1)
    mul_43 = torch.ops.aten.mul.Tensor(mul_40, unsqueeze_22);  mul_40 = unsqueeze_22 = None
    view_83 = torch.ops.aten.reshape.default(mul_43, [1, 16, -1, 64, 128]);  mul_43 = None
    expand_24 = torch.ops.aten.expand.default(view_83, [1, 16, 2, 64, 128])
    view_86 = torch.ops.aten.reshape.default(expand_24, [32, 64, 128]);  expand_24 = None
    permute_32 = torch.ops.aten.permute.default(view_82, [0, 1, 2, 4, 3])
    expand_25 = torch.ops.aten.expand.default(permute_32, [1, 16, 2, 128, 64]);  permute_32 = None
    view_87 = torch.ops.aten.reshape.default(expand_25, [32, 128, 64]);  expand_25 = None
    bmm_10 = torch.ops.aten.bmm.default(view_86, view_87);  view_86 = view_87 = None
    view_88 = torch.ops.aten.reshape.default(bmm_10, [1, 16, 2, 64, 64]);  bmm_10 = None
    iota_3 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_23 = torch.ops.aten.unsqueeze.default(iota_3, -2);  iota_3 = None
    iota_4 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_24 = torch.ops.aten.unsqueeze.default(iota_4, -1);  iota_4 = None
    sub_5 = torch.ops.aten.sub.Tensor(unsqueeze_23, unsqueeze_24);  unsqueeze_23 = unsqueeze_24 = None
    ge_1 = torch.ops.aten.ge.Scalar(sub_5, 1);  sub_5 = None
    full_default_4 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_1 = torch.ops.aten.logical_and.default(ge_1, full_default_4);  ge_1 = full_default_4 = None
    full_default_5 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_25 = torch.ops.aten.unsqueeze.default(cumsum_1, 4)
    unsqueeze_26 = torch.ops.aten.unsqueeze.default(cumsum_1, 3)
    sub_6 = torch.ops.aten.sub.Tensor(unsqueeze_25, unsqueeze_26);  unsqueeze_25 = unsqueeze_26 = None
    where_4 = torch.ops.aten.where.self(logical_and_1, full_default_5, sub_6);  logical_and_1 = full_default_5 = sub_6 = None
    exp_13 = torch.ops.aten.exp.default(where_4);  where_4 = None
    mul_44 = torch.ops.aten.mul.Tensor(view_88, exp_13);  view_88 = None
    view_80 = torch.ops.aten.reshape.default(getitem_5, [1, 128, 16, 128]);  getitem_5 = None
    permute_29 = torch.ops.aten.permute.default(view_80, [0, 2, 1, 3]);  view_80 = None
    convert_element_type_62 = torch.ops.prims.convert_element_type.default(permute_29, torch.float32);  permute_29 = None
    clone_13 = torch.ops.aten.clone.default(convert_element_type_62, memory_format = torch.contiguous_format);  convert_element_type_62 = None
    unsqueeze_21 = torch.ops.aten.unsqueeze.default(clone_14, -1);  clone_14 = None
    mul_42 = torch.ops.aten.mul.Tensor(clone_13, unsqueeze_21);  clone_13 = unsqueeze_21 = None
    view_84 = torch.ops.aten.reshape.default(mul_42, [1, 16, -1, 64, 128]);  mul_42 = None
    linalg_solve_triangular_2 = torch.ops.aten.linalg_solve_triangular.default(mul_44, view_84, upper = False, unitriangular = True);  view_84 = None
    select_60 = torch.ops.aten.select.int(linalg_solve_triangular_2, 2, 0)
    exp_14 = torch.ops.aten.exp.default(cumsum_1)
    unsqueeze_27 = torch.ops.aten.unsqueeze.default(exp_14, -1);  exp_14 = None
    mul_46 = torch.ops.aten.mul.Tensor(view_83, unsqueeze_27);  view_83 = unsqueeze_27 = None
    linalg_solve_triangular_3 = torch.ops.aten.linalg_solve_triangular.default(mul_44, mul_46, upper = False, unitriangular = True);  mul_44 = mul_46 = None
    select_61 = torch.ops.aten.select.int(linalg_solve_triangular_3, 2, 0)
    expand_28 = torch.ops.aten.expand.default(select_61, [1, 16, 64, 128]);  select_61 = None
    view_92 = torch.ops.aten.reshape.default(expand_28, [16, 64, 128]);  expand_28 = None
    expand_29 = torch.ops.aten.expand.default(full_5, [1, 16, 128, 128])
    view_93 = torch.ops.aten.reshape.default(expand_29, [16, 128, 128]);  expand_29 = None
    bmm_12 = torch.ops.aten.bmm.default(view_92, view_93);  view_92 = view_93 = None
    view_94 = torch.ops.aten.reshape.default(bmm_12, [1, 16, 64, 128]);  bmm_12 = None
    sub_8 = torch.ops.aten.sub.Tensor(select_60, view_94);  select_60 = view_94 = None
    expand_35 = torch.ops.aten.expand.default(sub_8, [1, 16, 64, 128])
    view_102 = torch.ops.aten.reshape.default(expand_35, [16, 64, 128]);  expand_35 = None
    bmm_15 = torch.ops.aten.bmm.default(view_101, view_102);  view_101 = view_102 = None
    view_103 = torch.ops.aten.reshape.default(bmm_15, [1, 16, 128, 128]);  bmm_15 = None
    add_30 = torch.ops.aten.add.Tensor(mul_49, view_103);  mul_49 = view_103 = None
    select_75 = torch.ops.aten.select.int(unsqueeze_31, 2, 1);  unsqueeze_31 = None
    mul_50 = torch.ops.aten.mul.Tensor(add_30, select_75);  select_75 = None
    select_76 = torch.ops.aten.select.int(mul_48, 2, 1);  mul_48 = None
    permute_36 = torch.ops.aten.permute.default(select_76, [0, 1, 3, 2]);  select_76 = None
    expand_42 = torch.ops.aten.expand.default(permute_36, [1, 16, 128, 64]);  permute_36 = None
    view_113 = torch.ops.aten.reshape.default(expand_42, [16, 128, 64]);  expand_42 = None
    select_68 = torch.ops.aten.select.int(linalg_solve_triangular_2, 2, 1);  linalg_solve_triangular_2 = None
    select_69 = torch.ops.aten.select.int(linalg_solve_triangular_3, 2, 1);  linalg_solve_triangular_3 = None
    expand_36 = torch.ops.aten.expand.default(select_69, [1, 16, 64, 128]);  select_69 = None
    view_104 = torch.ops.aten.reshape.default(expand_36, [16, 64, 128]);  expand_36 = None
    expand_37 = torch.ops.aten.expand.default(add_30, [1, 16, 128, 128])
    view_105 = torch.ops.aten.reshape.default(expand_37, [16, 128, 128]);  expand_37 = None
    bmm_16 = torch.ops.aten.bmm.default(view_104, view_105);  view_104 = view_105 = None
    view_106 = torch.ops.aten.reshape.default(bmm_16, [1, 16, 64, 128]);  bmm_16 = None
    sub_9 = torch.ops.aten.sub.Tensor(select_68, view_106);  select_68 = view_106 = None
    expand_43 = torch.ops.aten.expand.default(sub_9, [1, 16, 64, 128])
    view_114 = torch.ops.aten.reshape.default(expand_43, [16, 64, 128]);  expand_43 = None
    bmm_19 = torch.ops.aten.bmm.default(view_113, view_114);  view_113 = view_114 = None
    view_115 = torch.ops.aten.reshape.default(bmm_19, [1, 16, 128, 128]);  bmm_19 = None
    add_32 = torch.ops.aten.add.Tensor(mul_50, view_115);  mul_50 = view_115 = None
    full_6 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_34 = torch.ops.aten.permute.default(full_6, [0, 1, 2, 4, 3]);  full_6 = None
    select_64 = torch.ops.aten.select.int(permute_34, 2, 0)
    view_78 = torch.ops.aten.reshape.default(getitem_3, [1, 128, 16, 128]);  getitem_3 = None
    permute_27 = torch.ops.aten.permute.default(view_78, [0, 2, 1, 3]);  view_78 = None
    convert_element_type_60 = torch.ops.prims.convert_element_type.default(permute_27, torch.float32);  permute_27 = None
    clone_11 = torch.ops.aten.clone.default(convert_element_type_60, memory_format = torch.contiguous_format);  convert_element_type_60 = None
    mul_37 = torch.ops.aten.mul.Tensor(clone_11, clone_11)
    sum_3 = torch.ops.aten.sum.dim_IntList(mul_37, [-1], True);  mul_37 = None
    add_27 = torch.ops.aten.add.Tensor(sum_3, 1e-06);  sum_3 = None
    rsqrt_6 = torch.ops.aten.rsqrt.default(add_27);  add_27 = None
    mul_38 = torch.ops.aten.mul.Tensor(clone_11, rsqrt_6);  clone_11 = rsqrt_6 = None
    mul_41 = torch.ops.aten.mul.Tensor(mul_38, 0.08838834764831845);  mul_38 = None
    view_81 = torch.ops.aten.reshape.default(mul_41, [1, 16, -1, 64, 128]);  mul_41 = None
    exp_15 = torch.ops.aten.exp.default(cumsum_1);  cumsum_1 = None
    unsqueeze_28 = torch.ops.aten.unsqueeze.default(exp_15, -1);  exp_15 = None
    mul_47 = torch.ops.aten.mul.Tensor(view_81, unsqueeze_28);  unsqueeze_28 = None
    select_62 = torch.ops.aten.select.int(mul_47, 2, 0)
    expand_30 = torch.ops.aten.expand.default(select_62, [1, 16, 64, 128]);  select_62 = None
    view_95 = torch.ops.aten.reshape.default(expand_30, [16, 64, 128]);  expand_30 = None
    expand_31 = torch.ops.aten.expand.default(full_5, [1, 16, 128, 128]);  full_5 = None
    view_96 = torch.ops.aten.reshape.default(expand_31, [16, 128, 128]);  expand_31 = None
    bmm_13 = torch.ops.aten.bmm.default(view_95, view_96);  view_95 = view_96 = None
    view_97 = torch.ops.aten.reshape.default(bmm_13, [1, 16, 64, 128]);  bmm_13 = None
    expand_26 = torch.ops.aten.expand.default(view_81, [1, 16, 2, 64, 128]);  view_81 = None
    view_89 = torch.ops.aten.reshape.default(expand_26, [32, 64, 128]);  expand_26 = None
    permute_33 = torch.ops.aten.permute.default(view_82, [0, 1, 2, 4, 3]);  view_82 = None
    expand_27 = torch.ops.aten.expand.default(permute_33, [1, 16, 2, 128, 64]);  permute_33 = None
    view_90 = torch.ops.aten.reshape.default(expand_27, [32, 128, 64]);  expand_27 = None
    bmm_11 = torch.ops.aten.bmm.default(view_89, view_90);  view_89 = view_90 = None
    view_91 = torch.ops.aten.reshape.default(bmm_11, [1, 16, 2, 64, 64]);  bmm_11 = None
    mul_45 = torch.ops.aten.mul.Tensor(view_91, exp_13);  view_91 = exp_13 = None
    select_63 = torch.ops.aten.select.int(mul_45, 2, 0)
    expand_32 = torch.ops.aten.expand.default(select_63, [1, 16, 64, 64]);  select_63 = None
    view_98 = torch.ops.aten.reshape.default(expand_32, [16, 64, 64]);  expand_32 = None
    expand_33 = torch.ops.aten.expand.default(sub_8, [1, 16, 64, 128]);  sub_8 = None
    view_99 = torch.ops.aten.reshape.default(expand_33, [16, 64, 128]);  expand_33 = None
    bmm_14 = torch.ops.aten.bmm.default(view_98, view_99);  view_98 = view_99 = None
    view_100 = torch.ops.aten.reshape.default(bmm_14, [1, 16, 64, 128]);  bmm_14 = None
    add_29 = torch.ops.aten.add.Tensor(view_97, view_100);  view_97 = view_100 = None
    copy_9 = torch.ops.aten.copy.default(select_64, add_29);  select_64 = add_29 = None
    select_scatter_default_4 = torch.ops.aten.select_scatter.default(permute_34, copy_9, 2, 0);  permute_34 = copy_9 = None
    select_73 = torch.ops.aten.select.int(select_scatter_default_4, 2, 1)
    select_70 = torch.ops.aten.select.int(mul_47, 2, 1);  mul_47 = None
    expand_38 = torch.ops.aten.expand.default(select_70, [1, 16, 64, 128]);  select_70 = None
    view_107 = torch.ops.aten.reshape.default(expand_38, [16, 64, 128]);  expand_38 = None
    expand_39 = torch.ops.aten.expand.default(add_30, [1, 16, 128, 128]);  add_30 = None
    view_108 = torch.ops.aten.reshape.default(expand_39, [16, 128, 128]);  expand_39 = None
    bmm_17 = torch.ops.aten.bmm.default(view_107, view_108);  view_107 = view_108 = None
    view_109 = torch.ops.aten.reshape.default(bmm_17, [1, 16, 64, 128]);  bmm_17 = None
    select_71 = torch.ops.aten.select.int(mul_45, 2, 1);  mul_45 = None
    expand_40 = torch.ops.aten.expand.default(select_71, [1, 16, 64, 64]);  select_71 = None
    view_110 = torch.ops.aten.reshape.default(expand_40, [16, 64, 64]);  expand_40 = None
    expand_41 = torch.ops.aten.expand.default(sub_9, [1, 16, 64, 128]);  sub_9 = None
    view_111 = torch.ops.aten.reshape.default(expand_41, [16, 64, 128]);  expand_41 = None
    bmm_18 = torch.ops.aten.bmm.default(view_110, view_111);  view_110 = view_111 = None
    view_112 = torch.ops.aten.reshape.default(bmm_18, [1, 16, 64, 128]);  bmm_18 = None
    add_31 = torch.ops.aten.add.Tensor(view_109, view_112);  view_109 = view_112 = None
    copy_10 = torch.ops.aten.copy.default(select_73, add_31);  select_73 = add_31 = None
    select_scatter_default_5 = torch.ops.aten.select_scatter.default(select_scatter_default_4, copy_10, 2, 1);  select_scatter_default_4 = copy_10 = None
    clone_16 = torch.ops.aten.clone.default(select_scatter_default_5, memory_format = torch.contiguous_format);  select_scatter_default_5 = None
    view_116 = torch.ops.aten.reshape.default(clone_16, [1, 16, 128, 128]);  clone_16 = None
    permute_37 = torch.ops.aten.permute.default(view_116, [0, 2, 1, 3]);  view_116 = None
    convert_element_type_64 = torch.ops.prims.convert_element_type.default(permute_37, torch.bfloat16);  permute_37 = None
    clone_17 = torch.ops.aten.clone.default(convert_element_type_64, memory_format = torch.contiguous_format);  convert_element_type_64 = None
    view_117 = torch.ops.aten.reshape.default(clone_17, [-1, 128]);  clone_17 = None
    convert_element_type_65 = torch.ops.prims.convert_element_type.default(view_117, torch.float32);  view_117 = None
    pow_5 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_65, 2)
    mean_4 = torch.ops.aten.mean.dim(pow_5, [-1], True);  pow_5 = None
    add_33 = torch.ops.aten.add.Tensor(mean_4, 1e-06);  mean_4 = None
    rsqrt_8 = torch.ops.aten.rsqrt.default(add_33);  add_33 = None
    mul_51 = torch.ops.aten.mul.Tensor(convert_element_type_65, rsqrt_8);  convert_element_type_65 = rsqrt_8 = None
    convert_element_type_66 = torch.ops.prims.convert_element_type.default(mul_51, torch.bfloat16);  mul_51 = None
    mul_52 = torch.ops.aten.mul.Tensor(arg30_1, convert_element_type_66);  arg30_1 = convert_element_type_66 = None
    view_67 = torch.ops.aten.reshape.default(convert_element_type_45, [128, 2048]);  convert_element_type_45 = None
    permute_23 = torch.ops.aten.permute.default(arg22_1, [1, 0]);  arg22_1 = None
    mm_9 = torch.ops.aten.mm.default(view_67, permute_23);  view_67 = permute_23 = None
    view_68 = torch.ops.aten.reshape.default(mm_9, [1, 128, 2048]);  mm_9 = None
    view_69 = torch.ops.aten.reshape.default(view_68, [1, 128, -1, 128]);  view_68 = None
    view_118 = torch.ops.aten.reshape.default(view_69, [-1, 128]);  view_69 = None
    convert_element_type_67 = torch.ops.prims.convert_element_type.default(view_118, torch.float32);  view_118 = None
    neg_6 = torch.ops.aten.neg.default(convert_element_type_67)
    exp_18 = torch.ops.aten.exp.default(neg_6);  neg_6 = None
    add_34 = torch.ops.aten.add.Tensor(exp_18, 1);  exp_18 = None
    div_4 = torch.ops.aten.div.Tensor(convert_element_type_67, add_34);  convert_element_type_67 = add_34 = None
    mul_53 = torch.ops.aten.mul.Tensor(mul_52, div_4);  mul_52 = div_4 = None
    convert_element_type_68 = torch.ops.prims.convert_element_type.default(mul_53, torch.bfloat16);  mul_53 = None
    view_119 = torch.ops.aten.reshape.default(convert_element_type_68, [1, 128, -1]);  convert_element_type_68 = None
    view_120 = torch.ops.aten.reshape.default(view_119, [128, 2048]);  view_119 = None
    permute_38 = torch.ops.aten.permute.default(arg31_1, [1, 0]);  arg31_1 = None
    mm_12 = torch.ops.aten.mm.default(view_120, permute_38);  view_120 = permute_38 = None
    view_121 = torch.ops.aten.reshape.default(mm_12, [1, 128, 2048]);  mm_12 = None
    add_35 = torch.ops.aten.add.Tensor(add_19, view_121);  add_19 = view_121 = None
    convert_element_type_71 = torch.ops.prims.convert_element_type.default(add_35, torch.float32)
    pow_6 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_71, 2)
    mean_5 = torch.ops.aten.mean.dim(pow_6, [-1], True);  pow_6 = None
    add_36 = torch.ops.aten.add.Tensor(mean_5, 1e-06);  mean_5 = None
    rsqrt_9 = torch.ops.aten.rsqrt.default(add_36);  add_36 = None
    mul_54 = torch.ops.aten.mul.Tensor(convert_element_type_71, rsqrt_9);  convert_element_type_71 = rsqrt_9 = None
    convert_element_type_72 = torch.ops.prims.convert_element_type.default(arg32_1, torch.float32);  arg32_1 = None
    add_37 = torch.ops.aten.add.Tensor(convert_element_type_72, 1.0);  convert_element_type_72 = None
    mul_55 = torch.ops.aten.mul.Tensor(mul_54, add_37);  mul_54 = add_37 = None
    convert_element_type_73 = torch.ops.prims.convert_element_type.default(mul_55, torch.bfloat16);  mul_55 = None
    view_122 = torch.ops.aten.reshape.default(convert_element_type_73, [128, 2048])
    permute_39 = torch.ops.aten.permute.default(arg33_1, [1, 0]);  arg33_1 = None
    mm_13 = torch.ops.aten.mm.default(view_122, permute_39);  view_122 = permute_39 = None
    view_123 = torch.ops.aten.reshape.default(mm_13, [1, 128, 6144]);  mm_13 = None
    convert_element_type_76 = torch.ops.prims.convert_element_type.default(view_123, torch.float32);  view_123 = None
    neg_7 = torch.ops.aten.neg.default(convert_element_type_76)
    exp_19 = torch.ops.aten.exp.default(neg_7);  neg_7 = None
    add_38 = torch.ops.aten.add.Tensor(exp_19, 1);  exp_19 = None
    div_5 = torch.ops.aten.div.Tensor(convert_element_type_76, add_38);  convert_element_type_76 = add_38 = None
    convert_element_type_77 = torch.ops.prims.convert_element_type.default(div_5, torch.bfloat16);  div_5 = None
    view_124 = torch.ops.aten.reshape.default(convert_element_type_73, [128, 2048]);  convert_element_type_73 = None
    permute_40 = torch.ops.aten.permute.default(arg34_1, [1, 0]);  arg34_1 = None
    mm_14 = torch.ops.aten.mm.default(view_124, permute_40);  view_124 = permute_40 = None
    view_125 = torch.ops.aten.reshape.default(mm_14, [1, 128, 6144]);  mm_14 = None
    mul_56 = torch.ops.aten.mul.Tensor(convert_element_type_77, view_125);  convert_element_type_77 = view_125 = None
    view_126 = torch.ops.aten.reshape.default(mul_56, [128, 6144]);  mul_56 = None
    permute_41 = torch.ops.aten.permute.default(arg35_1, [1, 0]);  arg35_1 = None
    mm_15 = torch.ops.aten.mm.default(view_126, permute_41);  view_126 = permute_41 = None
    view_127 = torch.ops.aten.reshape.default(mm_15, [1, 128, 2048]);  mm_15 = None
    add_39 = torch.ops.aten.add.Tensor(add_35, view_127);  add_35 = view_127 = None
    convert_element_type_82 = torch.ops.prims.convert_element_type.default(add_39, torch.float32)
    pow_7 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_82, 2)
    mean_6 = torch.ops.aten.mean.dim(pow_7, [-1], True);  pow_7 = None
    add_40 = torch.ops.aten.add.Tensor(mean_6, 1e-06);  mean_6 = None
    rsqrt_10 = torch.ops.aten.rsqrt.default(add_40);  add_40 = None
    mul_57 = torch.ops.aten.mul.Tensor(convert_element_type_82, rsqrt_10);  convert_element_type_82 = rsqrt_10 = None
    convert_element_type_83 = torch.ops.prims.convert_element_type.default(arg36_1, torch.float32);  arg36_1 = None
    add_41 = torch.ops.aten.add.Tensor(convert_element_type_83, 1.0);  convert_element_type_83 = None
    mul_58 = torch.ops.aten.mul.Tensor(mul_57, add_41);  mul_57 = add_41 = None
    convert_element_type_84 = torch.ops.prims.convert_element_type.default(mul_58, torch.bfloat16);  mul_58 = None
    view_128 = torch.ops.aten.reshape.default(convert_element_type_84, [128, 2048])
    permute_42 = torch.ops.aten.permute.default(arg37_1, [1, 0]);  arg37_1 = None
    mm_16 = torch.ops.aten.mm.default(view_128, permute_42);  view_128 = permute_42 = None
    view_129 = torch.ops.aten.reshape.default(mm_16, [1, 128, 6144]);  mm_16 = None
    permute_43 = torch.ops.aten.permute.default(view_129, [0, 2, 1]);  view_129 = None
    slice_34 = torch.ops.aten.slice.Tensor(permute_43, 2, -4, 9223372036854775807)
    copy_12 = torch.ops.aten.copy.default(arg41_1, slice_34);  slice_34 = None
    convert_element_type_93 = torch.ops.prims.convert_element_type.default(permute_43, torch.float32);  permute_43 = None
    constant_pad_nd_12 = torch.ops.aten.constant_pad_nd.default(convert_element_type_93, [3, 3], 0.0);  convert_element_type_93 = None
    slice_35 = torch.ops.aten.slice.Tensor(constant_pad_nd_12, 2, 0, 131)
    squeeze_2 = torch.ops.aten.squeeze.dim(arg42_1, 1);  arg42_1 = None
    unsqueeze_32 = torch.ops.aten.unsqueeze.default(squeeze_2, 1);  squeeze_2 = None
    convert_element_type_94 = torch.ops.prims.convert_element_type.default(unsqueeze_32, torch.float32);  unsqueeze_32 = None
    select_77 = torch.ops.aten.select.int(convert_element_type_94, 1, 0)
    select_78 = torch.ops.aten.select.int(select_77, 1, 0);  select_77 = None
    view_137 = torch.ops.aten.reshape.default(select_78, [1, -1, 1]);  select_78 = None
    mul_59 = torch.ops.aten.mul.Tensor(slice_35, view_137);  slice_35 = view_137 = None
    slice_36 = torch.ops.aten.slice.Tensor(constant_pad_nd_12, 2, 1, 132)
    select_79 = torch.ops.aten.select.int(convert_element_type_94, 1, 0)
    select_80 = torch.ops.aten.select.int(select_79, 1, 1);  select_79 = None
    view_138 = torch.ops.aten.reshape.default(select_80, [1, -1, 1]);  select_80 = None
    mul_60 = torch.ops.aten.mul.Tensor(slice_36, view_138);  slice_36 = view_138 = None
    add_42 = torch.ops.aten.add.Tensor(mul_59, mul_60);  mul_59 = mul_60 = None
    slice_37 = torch.ops.aten.slice.Tensor(constant_pad_nd_12, 2, 2, 133)
    select_81 = torch.ops.aten.select.int(convert_element_type_94, 1, 0)
    select_82 = torch.ops.aten.select.int(select_81, 1, 2);  select_81 = None
    view_139 = torch.ops.aten.reshape.default(select_82, [1, -1, 1]);  select_82 = None
    mul_61 = torch.ops.aten.mul.Tensor(slice_37, view_139);  slice_37 = view_139 = None
    add_43 = torch.ops.aten.add.Tensor(add_42, mul_61);  add_42 = mul_61 = None
    slice_38 = torch.ops.aten.slice.Tensor(constant_pad_nd_12, 2, 3, 134);  constant_pad_nd_12 = None
    select_83 = torch.ops.aten.select.int(convert_element_type_94, 1, 0);  convert_element_type_94 = None
    select_84 = torch.ops.aten.select.int(select_83, 1, 3);  select_83 = None
    view_140 = torch.ops.aten.reshape.default(select_84, [1, -1, 1]);  select_84 = None
    mul_62 = torch.ops.aten.mul.Tensor(slice_38, view_140);  slice_38 = view_140 = None
    add_44 = torch.ops.aten.add.Tensor(add_43, mul_62);  add_43 = mul_62 = None
    convert_element_type_95 = torch.ops.prims.convert_element_type.default(add_44, torch.bfloat16);  add_44 = None
    slice_39 = torch.ops.aten.slice.Tensor(convert_element_type_95, 2, 0, 128);  convert_element_type_95 = None
    convert_element_type_96 = torch.ops.prims.convert_element_type.default(slice_39, torch.float32);  slice_39 = None
    neg_8 = torch.ops.aten.neg.default(convert_element_type_96)
    exp_20 = torch.ops.aten.exp.default(neg_8);  neg_8 = None
    add_45 = torch.ops.aten.add.Tensor(exp_20, 1);  exp_20 = None
    div_6 = torch.ops.aten.div.Tensor(convert_element_type_96, add_45);  convert_element_type_96 = add_45 = None
    convert_element_type_97 = torch.ops.prims.convert_element_type.default(div_6, torch.bfloat16);  div_6 = None
    slice_40 = torch.ops.aten.slice.Tensor(convert_element_type_97, 2, -128, 9223372036854775807);  convert_element_type_97 = None
    permute_47 = torch.ops.aten.permute.default(slice_40, [0, 2, 1]);  slice_40 = None
    split_with_sizes_2 = torch.ops.aten.split_with_sizes.default(permute_47, [2048, 2048, 2048], -1);  permute_47 = None
    getitem_6 = split_with_sizes_2[0]
    getitem_7 = split_with_sizes_2[1]
    getitem_8 = split_with_sizes_2[2];  split_with_sizes_2 = None
    full_8 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_21 = torch.ops.aten.exp.default(arg43_1);  arg43_1 = None
    neg_9 = torch.ops.aten.neg.default(exp_21);  exp_21 = None
    view_135 = torch.ops.aten.reshape.default(convert_element_type_84, [128, 2048])
    permute_46 = torch.ops.aten.permute.default(arg40_1, [1, 0]);  arg40_1 = None
    mm_19 = torch.ops.aten.mm.default(view_135, permute_46);  view_135 = permute_46 = None
    view_136 = torch.ops.aten.reshape.default(mm_19, [1, 128, 16]);  mm_19 = None
    convert_element_type_98 = torch.ops.prims.convert_element_type.default(view_136, torch.float32);  view_136 = None
    add_46 = torch.ops.aten.add.Tensor(convert_element_type_98, arg44_1);  convert_element_type_98 = arg44_1 = None
    gt_2 = torch.ops.aten.gt.Scalar(add_46, 20)
    exp_22 = torch.ops.aten.exp.default(add_46)
    log1p_2 = torch.ops.aten.log1p.default(exp_22);  exp_22 = None
    where_5 = torch.ops.aten.where.self(gt_2, add_46, log1p_2);  gt_2 = add_46 = log1p_2 = None
    mul_63 = torch.ops.aten.mul.Tensor(neg_9, where_5);  neg_9 = where_5 = None
    permute_52 = torch.ops.aten.permute.default(mul_63, [0, 2, 1]);  mul_63 = None
    view_148 = torch.ops.aten.reshape.default(permute_52, [1, 16, 2, 64]);  permute_52 = None
    cumsum_2 = torch.ops.aten.cumsum.default(view_148, 3);  view_148 = None
    select_85 = torch.ops.aten.select.int(cumsum_2, 3, -1)
    exp_27 = torch.ops.aten.exp.default(select_85);  select_85 = None
    unsqueeze_42 = torch.ops.aten.unsqueeze.default(exp_27, 3);  exp_27 = None
    unsqueeze_43 = torch.ops.aten.unsqueeze.default(unsqueeze_42, 4);  unsqueeze_42 = None
    select_92 = torch.ops.aten.select.int(unsqueeze_43, 2, 0)
    mul_76 = torch.ops.aten.mul.Tensor(full_8, select_92);  select_92 = None
    view_142 = torch.ops.aten.reshape.default(getitem_7, [1, 128, 16, 128]);  getitem_7 = None
    permute_49 = torch.ops.aten.permute.default(view_142, [0, 2, 1, 3]);  view_142 = None
    convert_element_type_100 = torch.ops.prims.convert_element_type.default(permute_49, torch.float32);  permute_49 = None
    clone_19 = torch.ops.aten.clone.default(convert_element_type_100, memory_format = torch.contiguous_format);  convert_element_type_100 = None
    mul_66 = torch.ops.aten.mul.Tensor(clone_19, clone_19)
    sum_6 = torch.ops.aten.sum.dim_IntList(mul_66, [-1], True);  mul_66 = None
    add_48 = torch.ops.aten.add.Tensor(sum_6, 1e-06);  sum_6 = None
    rsqrt_12 = torch.ops.aten.rsqrt.default(add_48);  add_48 = None
    mul_67 = torch.ops.aten.mul.Tensor(clone_19, rsqrt_12);  clone_19 = rsqrt_12 = None
    view_145 = torch.ops.aten.reshape.default(mul_67, [1, 16, -1, 64, 128])
    slice_41 = torch.ops.aten.slice.Tensor(cumsum_2, 3, -1, 9223372036854775807)
    sub_12 = torch.ops.aten.sub.Tensor(slice_41, cumsum_2);  slice_41 = None
    exp_26 = torch.ops.aten.exp.default(sub_12);  sub_12 = None
    unsqueeze_41 = torch.ops.aten.unsqueeze.default(exp_26, -1);  exp_26 = None
    mul_75 = torch.ops.aten.mul.Tensor(view_145, unsqueeze_41);  unsqueeze_41 = None
    select_93 = torch.ops.aten.select.int(mul_75, 2, 0)
    permute_56 = torch.ops.aten.permute.default(select_93, [0, 1, 3, 2]);  select_93 = None
    expand_54 = torch.ops.aten.expand.default(permute_56, [1, 16, 128, 64]);  permute_56 = None
    view_164 = torch.ops.aten.reshape.default(expand_54, [16, 128, 64]);  expand_54 = None
    view_133 = torch.ops.aten.reshape.default(convert_element_type_84, [128, 2048])
    permute_45 = torch.ops.aten.permute.default(arg39_1, [1, 0]);  arg39_1 = None
    mm_18 = torch.ops.aten.mm.default(view_133, permute_45);  view_133 = permute_45 = None
    view_134 = torch.ops.aten.reshape.default(mm_18, [1, 128, 16]);  mm_18 = None
    sigmoid_2 = torch.ops.aten.sigmoid.default(view_134);  view_134 = None
    permute_51 = torch.ops.aten.permute.default(sigmoid_2, [0, 2, 1]);  sigmoid_2 = None
    convert_element_type_102 = torch.ops.prims.convert_element_type.default(permute_51, torch.float32);  permute_51 = None
    clone_21 = torch.ops.aten.clone.default(convert_element_type_102, memory_format = torch.contiguous_format);  convert_element_type_102 = None
    unsqueeze_34 = torch.ops.aten.unsqueeze.default(clone_21, -1)
    mul_70 = torch.ops.aten.mul.Tensor(mul_67, unsqueeze_34);  mul_67 = unsqueeze_34 = None
    view_146 = torch.ops.aten.reshape.default(mul_70, [1, 16, -1, 64, 128]);  mul_70 = None
    expand_44 = torch.ops.aten.expand.default(view_146, [1, 16, 2, 64, 128])
    view_149 = torch.ops.aten.reshape.default(expand_44, [32, 64, 128]);  expand_44 = None
    permute_53 = torch.ops.aten.permute.default(view_145, [0, 1, 2, 4, 3])
    expand_45 = torch.ops.aten.expand.default(permute_53, [1, 16, 2, 128, 64]);  permute_53 = None
    view_150 = torch.ops.aten.reshape.default(expand_45, [32, 128, 64]);  expand_45 = None
    bmm_20 = torch.ops.aten.bmm.default(view_149, view_150);  view_149 = view_150 = None
    view_151 = torch.ops.aten.reshape.default(bmm_20, [1, 16, 2, 64, 64]);  bmm_20 = None
    iota_5 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_35 = torch.ops.aten.unsqueeze.default(iota_5, -2);  iota_5 = None
    iota_6 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_36 = torch.ops.aten.unsqueeze.default(iota_6, -1);  iota_6 = None
    sub_10 = torch.ops.aten.sub.Tensor(unsqueeze_35, unsqueeze_36);  unsqueeze_35 = unsqueeze_36 = None
    ge_2 = torch.ops.aten.ge.Scalar(sub_10, 1);  sub_10 = None
    full_default_6 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_2 = torch.ops.aten.logical_and.default(ge_2, full_default_6);  ge_2 = full_default_6 = None
    full_default_7 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_37 = torch.ops.aten.unsqueeze.default(cumsum_2, 4)
    unsqueeze_38 = torch.ops.aten.unsqueeze.default(cumsum_2, 3)
    sub_11 = torch.ops.aten.sub.Tensor(unsqueeze_37, unsqueeze_38);  unsqueeze_37 = unsqueeze_38 = None
    where_6 = torch.ops.aten.where.self(logical_and_2, full_default_7, sub_11);  logical_and_2 = full_default_7 = sub_11 = None
    exp_23 = torch.ops.aten.exp.default(where_6);  where_6 = None
    mul_71 = torch.ops.aten.mul.Tensor(view_151, exp_23);  view_151 = None
    view_143 = torch.ops.aten.reshape.default(getitem_8, [1, 128, 16, 128]);  getitem_8 = None
    permute_50 = torch.ops.aten.permute.default(view_143, [0, 2, 1, 3]);  view_143 = None
    convert_element_type_101 = torch.ops.prims.convert_element_type.default(permute_50, torch.float32);  permute_50 = None
    clone_20 = torch.ops.aten.clone.default(convert_element_type_101, memory_format = torch.contiguous_format);  convert_element_type_101 = None
    unsqueeze_33 = torch.ops.aten.unsqueeze.default(clone_21, -1);  clone_21 = None
    mul_69 = torch.ops.aten.mul.Tensor(clone_20, unsqueeze_33);  clone_20 = unsqueeze_33 = None
    view_147 = torch.ops.aten.reshape.default(mul_69, [1, 16, -1, 64, 128]);  mul_69 = None
    linalg_solve_triangular_4 = torch.ops.aten.linalg_solve_triangular.default(mul_71, view_147, upper = False, unitriangular = True);  view_147 = None
    select_86 = torch.ops.aten.select.int(linalg_solve_triangular_4, 2, 0)
    exp_24 = torch.ops.aten.exp.default(cumsum_2)
    unsqueeze_39 = torch.ops.aten.unsqueeze.default(exp_24, -1);  exp_24 = None
    mul_73 = torch.ops.aten.mul.Tensor(view_146, unsqueeze_39);  view_146 = unsqueeze_39 = None
    linalg_solve_triangular_5 = torch.ops.aten.linalg_solve_triangular.default(mul_71, mul_73, upper = False, unitriangular = True);  mul_71 = mul_73 = None
    select_87 = torch.ops.aten.select.int(linalg_solve_triangular_5, 2, 0)
    expand_48 = torch.ops.aten.expand.default(select_87, [1, 16, 64, 128]);  select_87 = None
    view_155 = torch.ops.aten.reshape.default(expand_48, [16, 64, 128]);  expand_48 = None
    expand_49 = torch.ops.aten.expand.default(full_8, [1, 16, 128, 128])
    view_156 = torch.ops.aten.reshape.default(expand_49, [16, 128, 128]);  expand_49 = None
    bmm_22 = torch.ops.aten.bmm.default(view_155, view_156);  view_155 = view_156 = None
    view_157 = torch.ops.aten.reshape.default(bmm_22, [1, 16, 64, 128]);  bmm_22 = None
    sub_13 = torch.ops.aten.sub.Tensor(select_86, view_157);  select_86 = view_157 = None
    expand_55 = torch.ops.aten.expand.default(sub_13, [1, 16, 64, 128])
    view_165 = torch.ops.aten.reshape.default(expand_55, [16, 64, 128]);  expand_55 = None
    bmm_25 = torch.ops.aten.bmm.default(view_164, view_165);  view_164 = view_165 = None
    view_166 = torch.ops.aten.reshape.default(bmm_25, [1, 16, 128, 128]);  bmm_25 = None
    add_50 = torch.ops.aten.add.Tensor(mul_76, view_166);  mul_76 = view_166 = None
    select_101 = torch.ops.aten.select.int(unsqueeze_43, 2, 1);  unsqueeze_43 = None
    mul_77 = torch.ops.aten.mul.Tensor(add_50, select_101);  select_101 = None
    select_102 = torch.ops.aten.select.int(mul_75, 2, 1);  mul_75 = None
    permute_57 = torch.ops.aten.permute.default(select_102, [0, 1, 3, 2]);  select_102 = None
    expand_62 = torch.ops.aten.expand.default(permute_57, [1, 16, 128, 64]);  permute_57 = None
    view_176 = torch.ops.aten.reshape.default(expand_62, [16, 128, 64]);  expand_62 = None
    select_94 = torch.ops.aten.select.int(linalg_solve_triangular_4, 2, 1);  linalg_solve_triangular_4 = None
    select_95 = torch.ops.aten.select.int(linalg_solve_triangular_5, 2, 1);  linalg_solve_triangular_5 = None
    expand_56 = torch.ops.aten.expand.default(select_95, [1, 16, 64, 128]);  select_95 = None
    view_167 = torch.ops.aten.reshape.default(expand_56, [16, 64, 128]);  expand_56 = None
    expand_57 = torch.ops.aten.expand.default(add_50, [1, 16, 128, 128])
    view_168 = torch.ops.aten.reshape.default(expand_57, [16, 128, 128]);  expand_57 = None
    bmm_26 = torch.ops.aten.bmm.default(view_167, view_168);  view_167 = view_168 = None
    view_169 = torch.ops.aten.reshape.default(bmm_26, [1, 16, 64, 128]);  bmm_26 = None
    sub_14 = torch.ops.aten.sub.Tensor(select_94, view_169);  select_94 = view_169 = None
    expand_63 = torch.ops.aten.expand.default(sub_14, [1, 16, 64, 128])
    view_177 = torch.ops.aten.reshape.default(expand_63, [16, 64, 128]);  expand_63 = None
    bmm_29 = torch.ops.aten.bmm.default(view_176, view_177);  view_176 = view_177 = None
    view_178 = torch.ops.aten.reshape.default(bmm_29, [1, 16, 128, 128]);  bmm_29 = None
    add_52 = torch.ops.aten.add.Tensor(mul_77, view_178);  mul_77 = view_178 = None
    full_9 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_55 = torch.ops.aten.permute.default(full_9, [0, 1, 2, 4, 3]);  full_9 = None
    select_90 = torch.ops.aten.select.int(permute_55, 2, 0)
    view_141 = torch.ops.aten.reshape.default(getitem_6, [1, 128, 16, 128]);  getitem_6 = None
    permute_48 = torch.ops.aten.permute.default(view_141, [0, 2, 1, 3]);  view_141 = None
    convert_element_type_99 = torch.ops.prims.convert_element_type.default(permute_48, torch.float32);  permute_48 = None
    clone_18 = torch.ops.aten.clone.default(convert_element_type_99, memory_format = torch.contiguous_format);  convert_element_type_99 = None
    mul_64 = torch.ops.aten.mul.Tensor(clone_18, clone_18)
    sum_5 = torch.ops.aten.sum.dim_IntList(mul_64, [-1], True);  mul_64 = None
    add_47 = torch.ops.aten.add.Tensor(sum_5, 1e-06);  sum_5 = None
    rsqrt_11 = torch.ops.aten.rsqrt.default(add_47);  add_47 = None
    mul_65 = torch.ops.aten.mul.Tensor(clone_18, rsqrt_11);  clone_18 = rsqrt_11 = None
    mul_68 = torch.ops.aten.mul.Tensor(mul_65, 0.08838834764831845);  mul_65 = None
    view_144 = torch.ops.aten.reshape.default(mul_68, [1, 16, -1, 64, 128]);  mul_68 = None
    exp_25 = torch.ops.aten.exp.default(cumsum_2);  cumsum_2 = None
    unsqueeze_40 = torch.ops.aten.unsqueeze.default(exp_25, -1);  exp_25 = None
    mul_74 = torch.ops.aten.mul.Tensor(view_144, unsqueeze_40);  unsqueeze_40 = None
    select_88 = torch.ops.aten.select.int(mul_74, 2, 0)
    expand_50 = torch.ops.aten.expand.default(select_88, [1, 16, 64, 128]);  select_88 = None
    view_158 = torch.ops.aten.reshape.default(expand_50, [16, 64, 128]);  expand_50 = None
    expand_51 = torch.ops.aten.expand.default(full_8, [1, 16, 128, 128]);  full_8 = None
    view_159 = torch.ops.aten.reshape.default(expand_51, [16, 128, 128]);  expand_51 = None
    bmm_23 = torch.ops.aten.bmm.default(view_158, view_159);  view_158 = view_159 = None
    view_160 = torch.ops.aten.reshape.default(bmm_23, [1, 16, 64, 128]);  bmm_23 = None
    expand_46 = torch.ops.aten.expand.default(view_144, [1, 16, 2, 64, 128]);  view_144 = None
    view_152 = torch.ops.aten.reshape.default(expand_46, [32, 64, 128]);  expand_46 = None
    permute_54 = torch.ops.aten.permute.default(view_145, [0, 1, 2, 4, 3]);  view_145 = None
    expand_47 = torch.ops.aten.expand.default(permute_54, [1, 16, 2, 128, 64]);  permute_54 = None
    view_153 = torch.ops.aten.reshape.default(expand_47, [32, 128, 64]);  expand_47 = None
    bmm_21 = torch.ops.aten.bmm.default(view_152, view_153);  view_152 = view_153 = None
    view_154 = torch.ops.aten.reshape.default(bmm_21, [1, 16, 2, 64, 64]);  bmm_21 = None
    mul_72 = torch.ops.aten.mul.Tensor(view_154, exp_23);  view_154 = exp_23 = None
    select_89 = torch.ops.aten.select.int(mul_72, 2, 0)
    expand_52 = torch.ops.aten.expand.default(select_89, [1, 16, 64, 64]);  select_89 = None
    view_161 = torch.ops.aten.reshape.default(expand_52, [16, 64, 64]);  expand_52 = None
    expand_53 = torch.ops.aten.expand.default(sub_13, [1, 16, 64, 128]);  sub_13 = None
    view_162 = torch.ops.aten.reshape.default(expand_53, [16, 64, 128]);  expand_53 = None
    bmm_24 = torch.ops.aten.bmm.default(view_161, view_162);  view_161 = view_162 = None
    view_163 = torch.ops.aten.reshape.default(bmm_24, [1, 16, 64, 128]);  bmm_24 = None
    add_49 = torch.ops.aten.add.Tensor(view_160, view_163);  view_160 = view_163 = None
    copy_13 = torch.ops.aten.copy.default(select_90, add_49);  select_90 = add_49 = None
    select_scatter_default_6 = torch.ops.aten.select_scatter.default(permute_55, copy_13, 2, 0);  permute_55 = copy_13 = None
    select_99 = torch.ops.aten.select.int(select_scatter_default_6, 2, 1)
    select_96 = torch.ops.aten.select.int(mul_74, 2, 1);  mul_74 = None
    expand_58 = torch.ops.aten.expand.default(select_96, [1, 16, 64, 128]);  select_96 = None
    view_170 = torch.ops.aten.reshape.default(expand_58, [16, 64, 128]);  expand_58 = None
    expand_59 = torch.ops.aten.expand.default(add_50, [1, 16, 128, 128]);  add_50 = None
    view_171 = torch.ops.aten.reshape.default(expand_59, [16, 128, 128]);  expand_59 = None
    bmm_27 = torch.ops.aten.bmm.default(view_170, view_171);  view_170 = view_171 = None
    view_172 = torch.ops.aten.reshape.default(bmm_27, [1, 16, 64, 128]);  bmm_27 = None
    select_97 = torch.ops.aten.select.int(mul_72, 2, 1);  mul_72 = None
    expand_60 = torch.ops.aten.expand.default(select_97, [1, 16, 64, 64]);  select_97 = None
    view_173 = torch.ops.aten.reshape.default(expand_60, [16, 64, 64]);  expand_60 = None
    expand_61 = torch.ops.aten.expand.default(sub_14, [1, 16, 64, 128]);  sub_14 = None
    view_174 = torch.ops.aten.reshape.default(expand_61, [16, 64, 128]);  expand_61 = None
    bmm_28 = torch.ops.aten.bmm.default(view_173, view_174);  view_173 = view_174 = None
    view_175 = torch.ops.aten.reshape.default(bmm_28, [1, 16, 64, 128]);  bmm_28 = None
    add_51 = torch.ops.aten.add.Tensor(view_172, view_175);  view_172 = view_175 = None
    copy_14 = torch.ops.aten.copy.default(select_99, add_51);  select_99 = add_51 = None
    select_scatter_default_7 = torch.ops.aten.select_scatter.default(select_scatter_default_6, copy_14, 2, 1);  select_scatter_default_6 = copy_14 = None
    clone_23 = torch.ops.aten.clone.default(select_scatter_default_7, memory_format = torch.contiguous_format);  select_scatter_default_7 = None
    view_179 = torch.ops.aten.reshape.default(clone_23, [1, 16, 128, 128]);  clone_23 = None
    permute_58 = torch.ops.aten.permute.default(view_179, [0, 2, 1, 3]);  view_179 = None
    convert_element_type_103 = torch.ops.prims.convert_element_type.default(permute_58, torch.bfloat16);  permute_58 = None
    clone_24 = torch.ops.aten.clone.default(convert_element_type_103, memory_format = torch.contiguous_format);  convert_element_type_103 = None
    view_180 = torch.ops.aten.reshape.default(clone_24, [-1, 128]);  clone_24 = None
    convert_element_type_104 = torch.ops.prims.convert_element_type.default(view_180, torch.float32);  view_180 = None
    pow_8 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_104, 2)
    mean_7 = torch.ops.aten.mean.dim(pow_8, [-1], True);  pow_8 = None
    add_53 = torch.ops.aten.add.Tensor(mean_7, 1e-06);  mean_7 = None
    rsqrt_13 = torch.ops.aten.rsqrt.default(add_53);  add_53 = None
    mul_78 = torch.ops.aten.mul.Tensor(convert_element_type_104, rsqrt_13);  convert_element_type_104 = rsqrt_13 = None
    convert_element_type_105 = torch.ops.prims.convert_element_type.default(mul_78, torch.bfloat16);  mul_78 = None
    mul_79 = torch.ops.aten.mul.Tensor(arg46_1, convert_element_type_105);  arg46_1 = convert_element_type_105 = None
    view_130 = torch.ops.aten.reshape.default(convert_element_type_84, [128, 2048]);  convert_element_type_84 = None
    permute_44 = torch.ops.aten.permute.default(arg38_1, [1, 0]);  arg38_1 = None
    mm_17 = torch.ops.aten.mm.default(view_130, permute_44);  view_130 = permute_44 = None
    view_131 = torch.ops.aten.reshape.default(mm_17, [1, 128, 2048]);  mm_17 = None
    view_132 = torch.ops.aten.reshape.default(view_131, [1, 128, -1, 128]);  view_131 = None
    view_181 = torch.ops.aten.reshape.default(view_132, [-1, 128]);  view_132 = None
    convert_element_type_106 = torch.ops.prims.convert_element_type.default(view_181, torch.float32);  view_181 = None
    neg_10 = torch.ops.aten.neg.default(convert_element_type_106)
    exp_28 = torch.ops.aten.exp.default(neg_10);  neg_10 = None
    add_54 = torch.ops.aten.add.Tensor(exp_28, 1);  exp_28 = None
    div_7 = torch.ops.aten.div.Tensor(convert_element_type_106, add_54);  convert_element_type_106 = add_54 = None
    mul_80 = torch.ops.aten.mul.Tensor(mul_79, div_7);  mul_79 = div_7 = None
    convert_element_type_107 = torch.ops.prims.convert_element_type.default(mul_80, torch.bfloat16);  mul_80 = None
    view_182 = torch.ops.aten.reshape.default(convert_element_type_107, [1, 128, -1]);  convert_element_type_107 = None
    view_183 = torch.ops.aten.reshape.default(view_182, [128, 2048]);  view_182 = None
    permute_59 = torch.ops.aten.permute.default(arg47_1, [1, 0]);  arg47_1 = None
    mm_20 = torch.ops.aten.mm.default(view_183, permute_59);  view_183 = permute_59 = None
    view_184 = torch.ops.aten.reshape.default(mm_20, [1, 128, 2048]);  mm_20 = None
    add_55 = torch.ops.aten.add.Tensor(add_39, view_184);  add_39 = view_184 = None
    convert_element_type_110 = torch.ops.prims.convert_element_type.default(add_55, torch.float32)
    pow_9 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_110, 2)
    mean_8 = torch.ops.aten.mean.dim(pow_9, [-1], True);  pow_9 = None
    add_56 = torch.ops.aten.add.Tensor(mean_8, 1e-06);  mean_8 = None
    rsqrt_14 = torch.ops.aten.rsqrt.default(add_56);  add_56 = None
    mul_81 = torch.ops.aten.mul.Tensor(convert_element_type_110, rsqrt_14);  convert_element_type_110 = rsqrt_14 = None
    convert_element_type_111 = torch.ops.prims.convert_element_type.default(arg48_1, torch.float32);  arg48_1 = None
    add_57 = torch.ops.aten.add.Tensor(convert_element_type_111, 1.0);  convert_element_type_111 = None
    mul_82 = torch.ops.aten.mul.Tensor(mul_81, add_57);  mul_81 = add_57 = None
    convert_element_type_112 = torch.ops.prims.convert_element_type.default(mul_82, torch.bfloat16);  mul_82 = None
    view_185 = torch.ops.aten.reshape.default(convert_element_type_112, [128, 2048])
    permute_60 = torch.ops.aten.permute.default(arg49_1, [1, 0]);  arg49_1 = None
    mm_21 = torch.ops.aten.mm.default(view_185, permute_60);  view_185 = permute_60 = None
    view_186 = torch.ops.aten.reshape.default(mm_21, [1, 128, 6144]);  mm_21 = None
    convert_element_type_115 = torch.ops.prims.convert_element_type.default(view_186, torch.float32);  view_186 = None
    neg_11 = torch.ops.aten.neg.default(convert_element_type_115)
    exp_29 = torch.ops.aten.exp.default(neg_11);  neg_11 = None
    add_58 = torch.ops.aten.add.Tensor(exp_29, 1);  exp_29 = None
    div_8 = torch.ops.aten.div.Tensor(convert_element_type_115, add_58);  convert_element_type_115 = add_58 = None
    convert_element_type_116 = torch.ops.prims.convert_element_type.default(div_8, torch.bfloat16);  div_8 = None
    view_187 = torch.ops.aten.reshape.default(convert_element_type_112, [128, 2048]);  convert_element_type_112 = None
    permute_61 = torch.ops.aten.permute.default(arg50_1, [1, 0]);  arg50_1 = None
    mm_22 = torch.ops.aten.mm.default(view_187, permute_61);  view_187 = permute_61 = None
    view_188 = torch.ops.aten.reshape.default(mm_22, [1, 128, 6144]);  mm_22 = None
    mul_83 = torch.ops.aten.mul.Tensor(convert_element_type_116, view_188);  convert_element_type_116 = view_188 = None
    view_189 = torch.ops.aten.reshape.default(mul_83, [128, 6144]);  mul_83 = None
    permute_62 = torch.ops.aten.permute.default(arg51_1, [1, 0]);  arg51_1 = None
    mm_23 = torch.ops.aten.mm.default(view_189, permute_62);  view_189 = permute_62 = None
    view_190 = torch.ops.aten.reshape.default(mm_23, [1, 128, 2048]);  mm_23 = None
    add_59 = torch.ops.aten.add.Tensor(add_55, view_190);  add_55 = view_190 = None
    convert_element_type_121 = torch.ops.prims.convert_element_type.default(add_59, torch.float32)
    pow_10 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_121, 2)
    mean_9 = torch.ops.aten.mean.dim(pow_10, [-1], True);  pow_10 = None
    add_60 = torch.ops.aten.add.Tensor(mean_9, 1e-06);  mean_9 = None
    rsqrt_15 = torch.ops.aten.rsqrt.default(add_60);  add_60 = None
    mul_84 = torch.ops.aten.mul.Tensor(convert_element_type_121, rsqrt_15);  convert_element_type_121 = rsqrt_15 = None
    convert_element_type_122 = torch.ops.prims.convert_element_type.default(arg52_1, torch.float32);  arg52_1 = None
    add_61 = torch.ops.aten.add.Tensor(convert_element_type_122, 1.0);  convert_element_type_122 = None
    mul_85 = torch.ops.aten.mul.Tensor(mul_84, add_61);  mul_84 = add_61 = None
    convert_element_type_123 = torch.ops.prims.convert_element_type.default(mul_85, torch.bfloat16);  mul_85 = None
    view_191 = torch.ops.aten.reshape.default(convert_element_type_123, [128, 2048])
    permute_63 = torch.ops.aten.permute.default(arg53_1, [1, 0]);  arg53_1 = None
    mm_24 = torch.ops.aten.mm.default(view_191, permute_63);  view_191 = permute_63 = None
    view_192 = torch.ops.aten.reshape.default(mm_24, [1, 128, 4096]);  mm_24 = None
    view_193 = torch.ops.aten.reshape.default(view_192, [1, 128, -1, 512]);  view_192 = None
    split = torch.ops.aten.split.Tensor(view_193, 256, -1);  view_193 = None
    getitem_9 = split[0]
    getitem_10 = split[1];  split = None
    add_69 = torch.ops.aten.add.Tensor(arg58_1, 128)
    convert_element_type_126 = torch.ops.prims.convert_element_type.default(getitem_9, torch.float32);  getitem_9 = None
    pow_11 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_126, 2)
    mean_10 = torch.ops.aten.mean.dim(pow_11, [-1], True);  pow_11 = None
    add_62 = torch.ops.aten.add.Tensor(mean_10, 1e-06);  mean_10 = None
    rsqrt_16 = torch.ops.aten.rsqrt.default(add_62);  add_62 = None
    mul_86 = torch.ops.aten.mul.Tensor(convert_element_type_126, rsqrt_16);  convert_element_type_126 = rsqrt_16 = None
    convert_element_type_127 = torch.ops.prims.convert_element_type.default(arg54_1, torch.float32);  arg54_1 = None
    add_63 = torch.ops.aten.add.Tensor(convert_element_type_127, 1.0);  convert_element_type_127 = None
    mul_87 = torch.ops.aten.mul.Tensor(mul_86, add_63);  mul_86 = add_63 = None
    convert_element_type_128 = torch.ops.prims.convert_element_type.default(mul_87, torch.bfloat16);  mul_87 = None
    permute_64 = torch.ops.aten.permute.default(convert_element_type_128, [0, 2, 1, 3]);  convert_element_type_128 = None
    slice_42 = torch.ops.aten.slice.Tensor(permute_64, 3, 0, 64)
    select_22 = torch.ops.aten.select.int(select_scatter_default_1, 0, 0);  select_22 = None
    select_21 = torch.ops.aten.select.int(select_scatter_default_1, 0, 2)
    slice_16 = torch.ops.aten.slice.Tensor(select_21, 2, 2, 30, 3);  select_21 = None
    select_int_2 = torch.ops.aten.select.int(select_scatter_default_1, 0, 0)
    slice_scatter_default_2 = torch.ops.aten.slice_scatter.default(select_int_2, slice_16, 2, 2, 30, 3);  select_int_2 = slice_16 = None
    select_scatter_default_8 = torch.ops.aten.select_scatter.default(select_scatter_default_1, slice_scatter_default_2, 0, 0);  select_scatter_default_1 = slice_scatter_default_2 = None
    select_24 = torch.ops.aten.select.int(select_scatter_default_8, 0, 0);  select_scatter_default_8 = None
    unsqueeze_7 = torch.ops.aten.unsqueeze.default(select_24, 2);  select_24 = None
    expand_3 = torch.ops.aten.expand.default(unsqueeze_7, [1, 128, 2, 32]);  unsqueeze_7 = None
    clone_2 = torch.ops.aten.clone.default(expand_3, memory_format = torch.contiguous_format);  expand_3 = None
    view_1 = torch.ops.aten.reshape.default(clone_2, [1, 128, 64]);  clone_2 = None
    convert_element_type_2 = torch.ops.prims.convert_element_type.default(view_1, torch.bfloat16);  view_1 = None
    unsqueeze_44 = torch.ops.aten.unsqueeze.default(convert_element_type_2, 1)
    mul_90 = torch.ops.aten.mul.Tensor(slice_42, unsqueeze_44)
    slice_47 = torch.ops.aten.slice.Tensor(slice_42, 3, 32, 9223372036854775807)
    neg_12 = torch.ops.aten.neg.default(slice_47);  slice_47 = None
    slice_46 = torch.ops.aten.slice.Tensor(slice_42, 3, 0, 32);  slice_42 = None
    cat = torch.ops.aten.cat.default([neg_12, slice_46], -1);  neg_12 = slice_46 = None
    select_10 = torch.ops.aten.select.int(select_scatter_default, 0, 0);  select_10 = None
    select_9 = torch.ops.aten.select.int(select_scatter_default, 0, 2)
    slice_8 = torch.ops.aten.slice.Tensor(select_9, 2, 2, 30, 3);  select_9 = None
    select_int_3 = torch.ops.aten.select.int(select_scatter_default, 0, 0)
    slice_scatter_default_3 = torch.ops.aten.slice_scatter.default(select_int_3, slice_8, 2, 2, 30, 3);  select_int_3 = slice_8 = None
    select_scatter_default_9 = torch.ops.aten.select_scatter.default(select_scatter_default, slice_scatter_default_3, 0, 0);  select_scatter_default = slice_scatter_default_3 = None
    select_12 = torch.ops.aten.select.int(select_scatter_default_9, 0, 0);  select_scatter_default_9 = None
    unsqueeze_6 = torch.ops.aten.unsqueeze.default(select_12, 2);  select_12 = None
    expand_2 = torch.ops.aten.expand.default(unsqueeze_6, [1, 128, 2, 32]);  unsqueeze_6 = None
    clone = torch.ops.aten.clone.default(expand_2, memory_format = torch.contiguous_format);  expand_2 = None
    view = torch.ops.aten.reshape.default(clone, [1, 128, 64]);  clone = None
    convert_element_type_3 = torch.ops.prims.convert_element_type.default(view, torch.bfloat16);  view = None
    unsqueeze_45 = torch.ops.aten.unsqueeze.default(convert_element_type_3, 1)
    mul_91 = torch.ops.aten.mul.Tensor(cat, unsqueeze_45);  cat = None
    add_66 = torch.ops.aten.add.Tensor(mul_90, mul_91);  mul_90 = mul_91 = None
    slice_43 = torch.ops.aten.slice.Tensor(permute_64, 3, 64, 9223372036854775807);  permute_64 = None
    cat_2 = torch.ops.aten.cat.default([add_66, slice_43], -1);  add_66 = slice_43 = None
    expand_68 = torch.ops.aten.expand.default(cat_2, [1, 8, 128, 256]);  cat_2 = None
    view_204 = torch.ops.aten.reshape.default(expand_68, [8, 128, 256]);  expand_68 = None
    iota_7 = torch.ops.prims.iota.default(128, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    add_68 = torch.ops.aten.add.Tensor(iota_7, arg58_1);  iota_7 = None
    view_196 = torch.ops.aten.reshape.default(convert_element_type_123, [128, 2048])
    permute_65 = torch.ops.aten.permute.default(arg55_1, [1, 0]);  arg55_1 = None
    mm_25 = torch.ops.aten.mm.default(view_196, permute_65);  view_196 = permute_65 = None
    view_197 = torch.ops.aten.reshape.default(mm_25, [1, 128, 512]);  mm_25 = None
    view_198 = torch.ops.aten.reshape.default(view_197, [1, 128, -1, 256]);  view_197 = None
    convert_element_type_131 = torch.ops.prims.convert_element_type.default(view_198, torch.float32);  view_198 = None
    pow_12 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_131, 2)
    mean_11 = torch.ops.aten.mean.dim(pow_12, [-1], True);  pow_12 = None
    add_64 = torch.ops.aten.add.Tensor(mean_11, 1e-06);  mean_11 = None
    rsqrt_17 = torch.ops.aten.rsqrt.default(add_64);  add_64 = None
    mul_88 = torch.ops.aten.mul.Tensor(convert_element_type_131, rsqrt_17);  convert_element_type_131 = rsqrt_17 = None
    convert_element_type_132 = torch.ops.prims.convert_element_type.default(arg56_1, torch.float32);  arg56_1 = None
    add_65 = torch.ops.aten.add.Tensor(convert_element_type_132, 1.0);  convert_element_type_132 = None
    mul_89 = torch.ops.aten.mul.Tensor(mul_88, add_65);  mul_88 = add_65 = None
    convert_element_type_133 = torch.ops.prims.convert_element_type.default(mul_89, torch.bfloat16);  mul_89 = None
    permute_66 = torch.ops.aten.permute.default(convert_element_type_133, [0, 2, 1, 3]);  convert_element_type_133 = None
    slice_44 = torch.ops.aten.slice.Tensor(permute_66, 3, 0, 64)
    mul_92 = torch.ops.aten.mul.Tensor(slice_44, unsqueeze_44);  unsqueeze_44 = None
    slice_49 = torch.ops.aten.slice.Tensor(slice_44, 3, 32, 9223372036854775807)
    neg_13 = torch.ops.aten.neg.default(slice_49);  slice_49 = None
    slice_48 = torch.ops.aten.slice.Tensor(slice_44, 3, 0, 32);  slice_44 = None
    cat_1 = torch.ops.aten.cat.default([neg_13, slice_48], -1);  neg_13 = slice_48 = None
    mul_93 = torch.ops.aten.mul.Tensor(cat_1, unsqueeze_45);  cat_1 = unsqueeze_45 = None
    add_67 = torch.ops.aten.add.Tensor(mul_92, mul_93);  mul_92 = mul_93 = None
    slice_45 = torch.ops.aten.slice.Tensor(permute_66, 3, 64, 9223372036854775807);  permute_66 = None
    cat_3 = torch.ops.aten.cat.default([add_67, slice_45], -1);  add_67 = slice_45 = None
    index_put = torch.ops.aten.index_put_.default(arg59_1, [None, None, add_68], cat_3);  arg59_1 = cat_3 = None
    unsqueeze_48 = torch.ops.aten.unsqueeze.default(index_put, 2);  index_put = None
    expand_65 = torch.ops.aten.expand.default(unsqueeze_48, [1, 2, 4, 144, 256]);  unsqueeze_48 = None
    clone_26 = torch.ops.aten.clone.default(expand_65, memory_format = torch.contiguous_format);  expand_65 = None
    view_202 = torch.ops.aten.reshape.default(clone_26, [1, 8, 144, 256]);  clone_26 = None
    permute_69 = torch.ops.aten.permute.default(view_202, [0, 1, 3, 2]);  view_202 = None
    expand_69 = torch.ops.aten.expand.default(permute_69, [1, 8, 256, 144]);  permute_69 = None
    view_205 = torch.ops.aten.reshape.default(expand_69, [8, 256, 144]);  expand_69 = None
    bmm_30 = torch.ops.aten.bmm.default(view_204, view_205);  view_204 = view_205 = None
    view_206 = torch.ops.aten.reshape.default(bmm_30, [1, 8, 128, 144]);  bmm_30 = None
    mul_94 = torch.ops.aten.mul.Tensor(view_206, 0.0625);  view_206 = None
    iota = torch.ops.prims.iota.default(144, start = 0, step = 1, dtype = torch.int32, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze = torch.ops.aten.unsqueeze.default(iota, 0);  iota = None
    select = torch.ops.aten.select.int(arg0_1, 0, 0);  arg0_1 = None
    unsqueeze_1 = torch.ops.aten.unsqueeze.default(select, 1);  select = None
    le = torch.ops.aten.le.Tensor(unsqueeze, unsqueeze_1);  unsqueeze = unsqueeze_1 = None
    full_default_1 = torch.ops.aten.full.default([], 0.0, dtype = torch.bfloat16, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    full_default = torch.ops.aten.full.default([128, 144], -inf, dtype = torch.bfloat16, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    where = torch.ops.aten.where.self(le, full_default_1, full_default);  le = full_default_1 = full_default = None
    unsqueeze_2 = torch.ops.aten.unsqueeze.default(where, 0);  where = None
    unsqueeze_3 = torch.ops.aten.unsqueeze.default(unsqueeze_2, 1);  unsqueeze_2 = None
    add_70 = torch.ops.aten.add.Tensor(mul_94, unsqueeze_3);  mul_94 = None
    convert_element_type_138 = torch.ops.prims.convert_element_type.default(add_70, torch.float32);  add_70 = None
    amax = torch.ops.aten.amax.default(convert_element_type_138, [-1], True)
    sub_15 = torch.ops.aten.sub.Tensor(convert_element_type_138, amax);  convert_element_type_138 = amax = None
    exp_30 = torch.ops.aten.exp.default(sub_15);  sub_15 = None
    sum_7 = torch.ops.aten.sum.dim_IntList(exp_30, [-1], True)
    div_9 = torch.ops.aten.div.Tensor(exp_30, sum_7);  exp_30 = sum_7 = None
    convert_element_type_139 = torch.ops.prims.convert_element_type.default(div_9, torch.bfloat16);  div_9 = None
    expand_70 = torch.ops.aten.expand.default(convert_element_type_139, [1, 8, 128, 144]);  convert_element_type_139 = None
    view_207 = torch.ops.aten.reshape.default(expand_70, [8, 128, 144]);  expand_70 = None
    view_199 = torch.ops.aten.reshape.default(convert_element_type_123, [128, 2048]);  convert_element_type_123 = None
    permute_67 = torch.ops.aten.permute.default(arg57_1, [1, 0]);  arg57_1 = None
    mm_26 = torch.ops.aten.mm.default(view_199, permute_67);  view_199 = permute_67 = None
    view_200 = torch.ops.aten.reshape.default(mm_26, [1, 128, 512]);  mm_26 = None
    view_201 = torch.ops.aten.reshape.default(view_200, [1, 128, -1, 256]);  view_200 = None
    permute_68 = torch.ops.aten.permute.default(view_201, [0, 2, 1, 3]);  view_201 = None
    index_put_1 = torch.ops.aten.index_put_.default(arg60_1, [None, None, add_68], permute_68);  arg60_1 = add_68 = permute_68 = None
    unsqueeze_51 = torch.ops.aten.unsqueeze.default(index_put_1, 2);  index_put_1 = None
    expand_67 = torch.ops.aten.expand.default(unsqueeze_51, [1, 2, 4, 144, 256]);  unsqueeze_51 = None
    clone_27 = torch.ops.aten.clone.default(expand_67, memory_format = torch.contiguous_format);  expand_67 = None
    view_203 = torch.ops.aten.reshape.default(clone_27, [1, 8, 144, 256]);  clone_27 = None
    expand_71 = torch.ops.aten.expand.default(view_203, [1, 8, 144, 256]);  view_203 = None
    view_208 = torch.ops.aten.reshape.default(expand_71, [8, 144, 256]);  expand_71 = None
    bmm_31 = torch.ops.aten.bmm.default(view_207, view_208);  view_207 = view_208 = None
    view_209 = torch.ops.aten.reshape.default(bmm_31, [1, 8, 128, 256]);  bmm_31 = None
    permute_70 = torch.ops.aten.permute.default(view_209, [0, 2, 1, 3]);  view_209 = None
    clone_28 = torch.ops.aten.clone.default(permute_70, memory_format = torch.contiguous_format);  permute_70 = None
    view_210 = torch.ops.aten.reshape.default(clone_28, [1, 128, -1]);  clone_28 = None
    clone_25 = torch.ops.aten.clone.default(getitem_10, memory_format = torch.contiguous_format);  getitem_10 = None
    view_194 = torch.ops.aten.reshape.default(clone_25, [1, 128, 2048]);  clone_25 = None
    sigmoid_3 = torch.ops.aten.sigmoid.default(view_194);  view_194 = None
    mul_95 = torch.ops.aten.mul.Tensor(view_210, sigmoid_3);  view_210 = sigmoid_3 = None
    view_211 = torch.ops.aten.reshape.default(mul_95, [128, 2048]);  mul_95 = None
    permute_71 = torch.ops.aten.permute.default(arg61_1, [1, 0]);  arg61_1 = None
    mm_27 = torch.ops.aten.mm.default(view_211, permute_71);  view_211 = permute_71 = None
    view_212 = torch.ops.aten.reshape.default(mm_27, [1, 128, 2048]);  mm_27 = None
    add_71 = torch.ops.aten.add.Tensor(add_59, view_212);  add_59 = view_212 = None
    convert_element_type_144 = torch.ops.prims.convert_element_type.default(add_71, torch.float32)
    pow_13 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_144, 2)
    mean_12 = torch.ops.aten.mean.dim(pow_13, [-1], True);  pow_13 = None
    add_72 = torch.ops.aten.add.Tensor(mean_12, 1e-06);  mean_12 = None
    rsqrt_18 = torch.ops.aten.rsqrt.default(add_72);  add_72 = None
    mul_96 = torch.ops.aten.mul.Tensor(convert_element_type_144, rsqrt_18);  convert_element_type_144 = rsqrt_18 = None
    convert_element_type_145 = torch.ops.prims.convert_element_type.default(arg62_1, torch.float32);  arg62_1 = None
    add_73 = torch.ops.aten.add.Tensor(convert_element_type_145, 1.0);  convert_element_type_145 = None
    mul_97 = torch.ops.aten.mul.Tensor(mul_96, add_73);  mul_96 = add_73 = None
    convert_element_type_146 = torch.ops.prims.convert_element_type.default(mul_97, torch.bfloat16);  mul_97 = None
    view_213 = torch.ops.aten.reshape.default(convert_element_type_146, [128, 2048])
    permute_72 = torch.ops.aten.permute.default(arg63_1, [1, 0]);  arg63_1 = None
    mm_28 = torch.ops.aten.mm.default(view_213, permute_72);  view_213 = permute_72 = None
    view_214 = torch.ops.aten.reshape.default(mm_28, [1, 128, 6144]);  mm_28 = None
    convert_element_type_149 = torch.ops.prims.convert_element_type.default(view_214, torch.float32);  view_214 = None
    neg_14 = torch.ops.aten.neg.default(convert_element_type_149)
    exp_31 = torch.ops.aten.exp.default(neg_14);  neg_14 = None
    add_74 = torch.ops.aten.add.Tensor(exp_31, 1);  exp_31 = None
    div_10 = torch.ops.aten.div.Tensor(convert_element_type_149, add_74);  convert_element_type_149 = add_74 = None
    convert_element_type_150 = torch.ops.prims.convert_element_type.default(div_10, torch.bfloat16);  div_10 = None
    view_215 = torch.ops.aten.reshape.default(convert_element_type_146, [128, 2048]);  convert_element_type_146 = None
    permute_73 = torch.ops.aten.permute.default(arg64_1, [1, 0]);  arg64_1 = None
    mm_29 = torch.ops.aten.mm.default(view_215, permute_73);  view_215 = permute_73 = None
    view_216 = torch.ops.aten.reshape.default(mm_29, [1, 128, 6144]);  mm_29 = None
    mul_98 = torch.ops.aten.mul.Tensor(convert_element_type_150, view_216);  convert_element_type_150 = view_216 = None
    view_217 = torch.ops.aten.reshape.default(mul_98, [128, 6144]);  mul_98 = None
    permute_74 = torch.ops.aten.permute.default(arg65_1, [1, 0]);  arg65_1 = None
    mm_30 = torch.ops.aten.mm.default(view_217, permute_74);  view_217 = permute_74 = None
    view_218 = torch.ops.aten.reshape.default(mm_30, [1, 128, 2048]);  mm_30 = None
    add_75 = torch.ops.aten.add.Tensor(add_71, view_218);  add_71 = view_218 = None
    convert_element_type_155 = torch.ops.prims.convert_element_type.default(add_75, torch.float32)
    pow_14 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_155, 2)
    mean_13 = torch.ops.aten.mean.dim(pow_14, [-1], True);  pow_14 = None
    add_76 = torch.ops.aten.add.Tensor(mean_13, 1e-06);  mean_13 = None
    rsqrt_19 = torch.ops.aten.rsqrt.default(add_76);  add_76 = None
    mul_99 = torch.ops.aten.mul.Tensor(convert_element_type_155, rsqrt_19);  convert_element_type_155 = rsqrt_19 = None
    convert_element_type_156 = torch.ops.prims.convert_element_type.default(arg66_1, torch.float32);  arg66_1 = None
    add_77 = torch.ops.aten.add.Tensor(convert_element_type_156, 1.0);  convert_element_type_156 = None
    mul_100 = torch.ops.aten.mul.Tensor(mul_99, add_77);  mul_99 = add_77 = None
    convert_element_type_157 = torch.ops.prims.convert_element_type.default(mul_100, torch.bfloat16);  mul_100 = None
    view_219 = torch.ops.aten.reshape.default(convert_element_type_157, [128, 2048])
    permute_75 = torch.ops.aten.permute.default(arg67_1, [1, 0]);  arg67_1 = None
    mm_31 = torch.ops.aten.mm.default(view_219, permute_75);  view_219 = permute_75 = None
    view_220 = torch.ops.aten.reshape.default(mm_31, [1, 128, 6144]);  mm_31 = None
    permute_76 = torch.ops.aten.permute.default(view_220, [0, 2, 1]);  view_220 = None
    slice_50 = torch.ops.aten.slice.Tensor(permute_76, 2, -4, 9223372036854775807)
    copy_16 = torch.ops.aten.copy.default(arg71_1, slice_50);  slice_50 = None
    convert_element_type_166 = torch.ops.prims.convert_element_type.default(permute_76, torch.float32);  permute_76 = None
    constant_pad_nd_18 = torch.ops.aten.constant_pad_nd.default(convert_element_type_166, [3, 3], 0.0);  convert_element_type_166 = None
    slice_51 = torch.ops.aten.slice.Tensor(constant_pad_nd_18, 2, 0, 131)
    squeeze_3 = torch.ops.aten.squeeze.dim(arg72_1, 1);  arg72_1 = None
    unsqueeze_52 = torch.ops.aten.unsqueeze.default(squeeze_3, 1);  squeeze_3 = None
    convert_element_type_167 = torch.ops.prims.convert_element_type.default(unsqueeze_52, torch.float32);  unsqueeze_52 = None
    select_103 = torch.ops.aten.select.int(convert_element_type_167, 1, 0)
    select_104 = torch.ops.aten.select.int(select_103, 1, 0);  select_103 = None
    view_228 = torch.ops.aten.reshape.default(select_104, [1, -1, 1]);  select_104 = None
    mul_101 = torch.ops.aten.mul.Tensor(slice_51, view_228);  slice_51 = view_228 = None
    slice_52 = torch.ops.aten.slice.Tensor(constant_pad_nd_18, 2, 1, 132)
    select_105 = torch.ops.aten.select.int(convert_element_type_167, 1, 0)
    select_106 = torch.ops.aten.select.int(select_105, 1, 1);  select_105 = None
    view_229 = torch.ops.aten.reshape.default(select_106, [1, -1, 1]);  select_106 = None
    mul_102 = torch.ops.aten.mul.Tensor(slice_52, view_229);  slice_52 = view_229 = None
    add_78 = torch.ops.aten.add.Tensor(mul_101, mul_102);  mul_101 = mul_102 = None
    slice_53 = torch.ops.aten.slice.Tensor(constant_pad_nd_18, 2, 2, 133)
    select_107 = torch.ops.aten.select.int(convert_element_type_167, 1, 0)
    select_108 = torch.ops.aten.select.int(select_107, 1, 2);  select_107 = None
    view_230 = torch.ops.aten.reshape.default(select_108, [1, -1, 1]);  select_108 = None
    mul_103 = torch.ops.aten.mul.Tensor(slice_53, view_230);  slice_53 = view_230 = None
    add_79 = torch.ops.aten.add.Tensor(add_78, mul_103);  add_78 = mul_103 = None
    slice_54 = torch.ops.aten.slice.Tensor(constant_pad_nd_18, 2, 3, 134);  constant_pad_nd_18 = None
    select_109 = torch.ops.aten.select.int(convert_element_type_167, 1, 0);  convert_element_type_167 = None
    select_110 = torch.ops.aten.select.int(select_109, 1, 3);  select_109 = None
    view_231 = torch.ops.aten.reshape.default(select_110, [1, -1, 1]);  select_110 = None
    mul_104 = torch.ops.aten.mul.Tensor(slice_54, view_231);  slice_54 = view_231 = None
    add_80 = torch.ops.aten.add.Tensor(add_79, mul_104);  add_79 = mul_104 = None
    convert_element_type_168 = torch.ops.prims.convert_element_type.default(add_80, torch.bfloat16);  add_80 = None
    slice_55 = torch.ops.aten.slice.Tensor(convert_element_type_168, 2, 0, 128);  convert_element_type_168 = None
    convert_element_type_169 = torch.ops.prims.convert_element_type.default(slice_55, torch.float32);  slice_55 = None
    neg_15 = torch.ops.aten.neg.default(convert_element_type_169)
    exp_32 = torch.ops.aten.exp.default(neg_15);  neg_15 = None
    add_81 = torch.ops.aten.add.Tensor(exp_32, 1);  exp_32 = None
    div_11 = torch.ops.aten.div.Tensor(convert_element_type_169, add_81);  convert_element_type_169 = add_81 = None
    convert_element_type_170 = torch.ops.prims.convert_element_type.default(div_11, torch.bfloat16);  div_11 = None
    slice_56 = torch.ops.aten.slice.Tensor(convert_element_type_170, 2, -128, 9223372036854775807);  convert_element_type_170 = None
    permute_80 = torch.ops.aten.permute.default(slice_56, [0, 2, 1]);  slice_56 = None
    split_with_sizes_3 = torch.ops.aten.split_with_sizes.default(permute_80, [2048, 2048, 2048], -1);  permute_80 = None
    getitem_11 = split_with_sizes_3[0]
    getitem_12 = split_with_sizes_3[1]
    getitem_13 = split_with_sizes_3[2];  split_with_sizes_3 = None
    full_11 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_33 = torch.ops.aten.exp.default(arg73_1);  arg73_1 = None
    neg_16 = torch.ops.aten.neg.default(exp_33);  exp_33 = None
    view_226 = torch.ops.aten.reshape.default(convert_element_type_157, [128, 2048])
    permute_79 = torch.ops.aten.permute.default(arg70_1, [1, 0]);  arg70_1 = None
    mm_34 = torch.ops.aten.mm.default(view_226, permute_79);  view_226 = permute_79 = None
    view_227 = torch.ops.aten.reshape.default(mm_34, [1, 128, 16]);  mm_34 = None
    convert_element_type_171 = torch.ops.prims.convert_element_type.default(view_227, torch.float32);  view_227 = None
    add_82 = torch.ops.aten.add.Tensor(convert_element_type_171, arg74_1);  convert_element_type_171 = arg74_1 = None
    gt_3 = torch.ops.aten.gt.Scalar(add_82, 20)
    exp_34 = torch.ops.aten.exp.default(add_82)
    log1p_3 = torch.ops.aten.log1p.default(exp_34);  exp_34 = None
    where_7 = torch.ops.aten.where.self(gt_3, add_82, log1p_3);  gt_3 = add_82 = log1p_3 = None
    mul_105 = torch.ops.aten.mul.Tensor(neg_16, where_7);  neg_16 = where_7 = None
    permute_85 = torch.ops.aten.permute.default(mul_105, [0, 2, 1]);  mul_105 = None
    view_239 = torch.ops.aten.reshape.default(permute_85, [1, 16, 2, 64]);  permute_85 = None
    cumsum_3 = torch.ops.aten.cumsum.default(view_239, 3);  view_239 = None
    select_111 = torch.ops.aten.select.int(cumsum_3, 3, -1)
    exp_39 = torch.ops.aten.exp.default(select_111);  select_111 = None
    unsqueeze_62 = torch.ops.aten.unsqueeze.default(exp_39, 3);  exp_39 = None
    unsqueeze_63 = torch.ops.aten.unsqueeze.default(unsqueeze_62, 4);  unsqueeze_62 = None
    select_118 = torch.ops.aten.select.int(unsqueeze_63, 2, 0)
    mul_118 = torch.ops.aten.mul.Tensor(full_11, select_118);  select_118 = None
    view_233 = torch.ops.aten.reshape.default(getitem_12, [1, 128, 16, 128]);  getitem_12 = None
    permute_82 = torch.ops.aten.permute.default(view_233, [0, 2, 1, 3]);  view_233 = None
    convert_element_type_173 = torch.ops.prims.convert_element_type.default(permute_82, torch.float32);  permute_82 = None
    clone_30 = torch.ops.aten.clone.default(convert_element_type_173, memory_format = torch.contiguous_format);  convert_element_type_173 = None
    mul_108 = torch.ops.aten.mul.Tensor(clone_30, clone_30)
    sum_9 = torch.ops.aten.sum.dim_IntList(mul_108, [-1], True);  mul_108 = None
    add_84 = torch.ops.aten.add.Tensor(sum_9, 1e-06);  sum_9 = None
    rsqrt_21 = torch.ops.aten.rsqrt.default(add_84);  add_84 = None
    mul_109 = torch.ops.aten.mul.Tensor(clone_30, rsqrt_21);  clone_30 = rsqrt_21 = None
    view_236 = torch.ops.aten.reshape.default(mul_109, [1, 16, -1, 64, 128])
    slice_57 = torch.ops.aten.slice.Tensor(cumsum_3, 3, -1, 9223372036854775807)
    sub_18 = torch.ops.aten.sub.Tensor(slice_57, cumsum_3);  slice_57 = None
    exp_38 = torch.ops.aten.exp.default(sub_18);  sub_18 = None
    unsqueeze_61 = torch.ops.aten.unsqueeze.default(exp_38, -1);  exp_38 = None
    mul_117 = torch.ops.aten.mul.Tensor(view_236, unsqueeze_61);  unsqueeze_61 = None
    select_119 = torch.ops.aten.select.int(mul_117, 2, 0)
    permute_89 = torch.ops.aten.permute.default(select_119, [0, 1, 3, 2]);  select_119 = None
    expand_82 = torch.ops.aten.expand.default(permute_89, [1, 16, 128, 64]);  permute_89 = None
    view_255 = torch.ops.aten.reshape.default(expand_82, [16, 128, 64]);  expand_82 = None
    view_224 = torch.ops.aten.reshape.default(convert_element_type_157, [128, 2048])
    permute_78 = torch.ops.aten.permute.default(arg69_1, [1, 0]);  arg69_1 = None
    mm_33 = torch.ops.aten.mm.default(view_224, permute_78);  view_224 = permute_78 = None
    view_225 = torch.ops.aten.reshape.default(mm_33, [1, 128, 16]);  mm_33 = None
    sigmoid_4 = torch.ops.aten.sigmoid.default(view_225);  view_225 = None
    permute_84 = torch.ops.aten.permute.default(sigmoid_4, [0, 2, 1]);  sigmoid_4 = None
    convert_element_type_175 = torch.ops.prims.convert_element_type.default(permute_84, torch.float32);  permute_84 = None
    clone_32 = torch.ops.aten.clone.default(convert_element_type_175, memory_format = torch.contiguous_format);  convert_element_type_175 = None
    unsqueeze_54 = torch.ops.aten.unsqueeze.default(clone_32, -1)
    mul_112 = torch.ops.aten.mul.Tensor(mul_109, unsqueeze_54);  mul_109 = unsqueeze_54 = None
    view_237 = torch.ops.aten.reshape.default(mul_112, [1, 16, -1, 64, 128]);  mul_112 = None
    expand_72 = torch.ops.aten.expand.default(view_237, [1, 16, 2, 64, 128])
    view_240 = torch.ops.aten.reshape.default(expand_72, [32, 64, 128]);  expand_72 = None
    permute_86 = torch.ops.aten.permute.default(view_236, [0, 1, 2, 4, 3])
    expand_73 = torch.ops.aten.expand.default(permute_86, [1, 16, 2, 128, 64]);  permute_86 = None
    view_241 = torch.ops.aten.reshape.default(expand_73, [32, 128, 64]);  expand_73 = None
    bmm_32 = torch.ops.aten.bmm.default(view_240, view_241);  view_240 = view_241 = None
    view_242 = torch.ops.aten.reshape.default(bmm_32, [1, 16, 2, 64, 64]);  bmm_32 = None
    iota_8 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_55 = torch.ops.aten.unsqueeze.default(iota_8, -2);  iota_8 = None
    iota_9 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_56 = torch.ops.aten.unsqueeze.default(iota_9, -1);  iota_9 = None
    sub_16 = torch.ops.aten.sub.Tensor(unsqueeze_55, unsqueeze_56);  unsqueeze_55 = unsqueeze_56 = None
    ge_3 = torch.ops.aten.ge.Scalar(sub_16, 1);  sub_16 = None
    full_default_8 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_3 = torch.ops.aten.logical_and.default(ge_3, full_default_8);  ge_3 = full_default_8 = None
    full_default_9 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_57 = torch.ops.aten.unsqueeze.default(cumsum_3, 4)
    unsqueeze_58 = torch.ops.aten.unsqueeze.default(cumsum_3, 3)
    sub_17 = torch.ops.aten.sub.Tensor(unsqueeze_57, unsqueeze_58);  unsqueeze_57 = unsqueeze_58 = None
    where_8 = torch.ops.aten.where.self(logical_and_3, full_default_9, sub_17);  logical_and_3 = full_default_9 = sub_17 = None
    exp_35 = torch.ops.aten.exp.default(where_8);  where_8 = None
    mul_113 = torch.ops.aten.mul.Tensor(view_242, exp_35);  view_242 = None
    view_234 = torch.ops.aten.reshape.default(getitem_13, [1, 128, 16, 128]);  getitem_13 = None
    permute_83 = torch.ops.aten.permute.default(view_234, [0, 2, 1, 3]);  view_234 = None
    convert_element_type_174 = torch.ops.prims.convert_element_type.default(permute_83, torch.float32);  permute_83 = None
    clone_31 = torch.ops.aten.clone.default(convert_element_type_174, memory_format = torch.contiguous_format);  convert_element_type_174 = None
    unsqueeze_53 = torch.ops.aten.unsqueeze.default(clone_32, -1);  clone_32 = None
    mul_111 = torch.ops.aten.mul.Tensor(clone_31, unsqueeze_53);  clone_31 = unsqueeze_53 = None
    view_238 = torch.ops.aten.reshape.default(mul_111, [1, 16, -1, 64, 128]);  mul_111 = None
    linalg_solve_triangular_6 = torch.ops.aten.linalg_solve_triangular.default(mul_113, view_238, upper = False, unitriangular = True);  view_238 = None
    select_112 = torch.ops.aten.select.int(linalg_solve_triangular_6, 2, 0)
    exp_36 = torch.ops.aten.exp.default(cumsum_3)
    unsqueeze_59 = torch.ops.aten.unsqueeze.default(exp_36, -1);  exp_36 = None
    mul_115 = torch.ops.aten.mul.Tensor(view_237, unsqueeze_59);  view_237 = unsqueeze_59 = None
    linalg_solve_triangular_7 = torch.ops.aten.linalg_solve_triangular.default(mul_113, mul_115, upper = False, unitriangular = True);  mul_113 = mul_115 = None
    select_113 = torch.ops.aten.select.int(linalg_solve_triangular_7, 2, 0)
    expand_76 = torch.ops.aten.expand.default(select_113, [1, 16, 64, 128]);  select_113 = None
    view_246 = torch.ops.aten.reshape.default(expand_76, [16, 64, 128]);  expand_76 = None
    expand_77 = torch.ops.aten.expand.default(full_11, [1, 16, 128, 128])
    view_247 = torch.ops.aten.reshape.default(expand_77, [16, 128, 128]);  expand_77 = None
    bmm_34 = torch.ops.aten.bmm.default(view_246, view_247);  view_246 = view_247 = None
    view_248 = torch.ops.aten.reshape.default(bmm_34, [1, 16, 64, 128]);  bmm_34 = None
    sub_19 = torch.ops.aten.sub.Tensor(select_112, view_248);  select_112 = view_248 = None
    expand_83 = torch.ops.aten.expand.default(sub_19, [1, 16, 64, 128])
    view_256 = torch.ops.aten.reshape.default(expand_83, [16, 64, 128]);  expand_83 = None
    bmm_37 = torch.ops.aten.bmm.default(view_255, view_256);  view_255 = view_256 = None
    view_257 = torch.ops.aten.reshape.default(bmm_37, [1, 16, 128, 128]);  bmm_37 = None
    add_86 = torch.ops.aten.add.Tensor(mul_118, view_257);  mul_118 = view_257 = None
    select_127 = torch.ops.aten.select.int(unsqueeze_63, 2, 1);  unsqueeze_63 = None
    mul_119 = torch.ops.aten.mul.Tensor(add_86, select_127);  select_127 = None
    select_128 = torch.ops.aten.select.int(mul_117, 2, 1);  mul_117 = None
    permute_90 = torch.ops.aten.permute.default(select_128, [0, 1, 3, 2]);  select_128 = None
    expand_90 = torch.ops.aten.expand.default(permute_90, [1, 16, 128, 64]);  permute_90 = None
    view_267 = torch.ops.aten.reshape.default(expand_90, [16, 128, 64]);  expand_90 = None
    select_120 = torch.ops.aten.select.int(linalg_solve_triangular_6, 2, 1);  linalg_solve_triangular_6 = None
    select_121 = torch.ops.aten.select.int(linalg_solve_triangular_7, 2, 1);  linalg_solve_triangular_7 = None
    expand_84 = torch.ops.aten.expand.default(select_121, [1, 16, 64, 128]);  select_121 = None
    view_258 = torch.ops.aten.reshape.default(expand_84, [16, 64, 128]);  expand_84 = None
    expand_85 = torch.ops.aten.expand.default(add_86, [1, 16, 128, 128])
    view_259 = torch.ops.aten.reshape.default(expand_85, [16, 128, 128]);  expand_85 = None
    bmm_38 = torch.ops.aten.bmm.default(view_258, view_259);  view_258 = view_259 = None
    view_260 = torch.ops.aten.reshape.default(bmm_38, [1, 16, 64, 128]);  bmm_38 = None
    sub_20 = torch.ops.aten.sub.Tensor(select_120, view_260);  select_120 = view_260 = None
    expand_91 = torch.ops.aten.expand.default(sub_20, [1, 16, 64, 128])
    view_268 = torch.ops.aten.reshape.default(expand_91, [16, 64, 128]);  expand_91 = None
    bmm_41 = torch.ops.aten.bmm.default(view_267, view_268);  view_267 = view_268 = None
    view_269 = torch.ops.aten.reshape.default(bmm_41, [1, 16, 128, 128]);  bmm_41 = None
    add_88 = torch.ops.aten.add.Tensor(mul_119, view_269);  mul_119 = view_269 = None
    full_12 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_88 = torch.ops.aten.permute.default(full_12, [0, 1, 2, 4, 3]);  full_12 = None
    select_116 = torch.ops.aten.select.int(permute_88, 2, 0)
    view_232 = torch.ops.aten.reshape.default(getitem_11, [1, 128, 16, 128]);  getitem_11 = None
    permute_81 = torch.ops.aten.permute.default(view_232, [0, 2, 1, 3]);  view_232 = None
    convert_element_type_172 = torch.ops.prims.convert_element_type.default(permute_81, torch.float32);  permute_81 = None
    clone_29 = torch.ops.aten.clone.default(convert_element_type_172, memory_format = torch.contiguous_format);  convert_element_type_172 = None
    mul_106 = torch.ops.aten.mul.Tensor(clone_29, clone_29)
    sum_8 = torch.ops.aten.sum.dim_IntList(mul_106, [-1], True);  mul_106 = None
    add_83 = torch.ops.aten.add.Tensor(sum_8, 1e-06);  sum_8 = None
    rsqrt_20 = torch.ops.aten.rsqrt.default(add_83);  add_83 = None
    mul_107 = torch.ops.aten.mul.Tensor(clone_29, rsqrt_20);  clone_29 = rsqrt_20 = None
    mul_110 = torch.ops.aten.mul.Tensor(mul_107, 0.08838834764831845);  mul_107 = None
    view_235 = torch.ops.aten.reshape.default(mul_110, [1, 16, -1, 64, 128]);  mul_110 = None
    exp_37 = torch.ops.aten.exp.default(cumsum_3);  cumsum_3 = None
    unsqueeze_60 = torch.ops.aten.unsqueeze.default(exp_37, -1);  exp_37 = None
    mul_116 = torch.ops.aten.mul.Tensor(view_235, unsqueeze_60);  unsqueeze_60 = None
    select_114 = torch.ops.aten.select.int(mul_116, 2, 0)
    expand_78 = torch.ops.aten.expand.default(select_114, [1, 16, 64, 128]);  select_114 = None
    view_249 = torch.ops.aten.reshape.default(expand_78, [16, 64, 128]);  expand_78 = None
    expand_79 = torch.ops.aten.expand.default(full_11, [1, 16, 128, 128]);  full_11 = None
    view_250 = torch.ops.aten.reshape.default(expand_79, [16, 128, 128]);  expand_79 = None
    bmm_35 = torch.ops.aten.bmm.default(view_249, view_250);  view_249 = view_250 = None
    view_251 = torch.ops.aten.reshape.default(bmm_35, [1, 16, 64, 128]);  bmm_35 = None
    expand_74 = torch.ops.aten.expand.default(view_235, [1, 16, 2, 64, 128]);  view_235 = None
    view_243 = torch.ops.aten.reshape.default(expand_74, [32, 64, 128]);  expand_74 = None
    permute_87 = torch.ops.aten.permute.default(view_236, [0, 1, 2, 4, 3]);  view_236 = None
    expand_75 = torch.ops.aten.expand.default(permute_87, [1, 16, 2, 128, 64]);  permute_87 = None
    view_244 = torch.ops.aten.reshape.default(expand_75, [32, 128, 64]);  expand_75 = None
    bmm_33 = torch.ops.aten.bmm.default(view_243, view_244);  view_243 = view_244 = None
    view_245 = torch.ops.aten.reshape.default(bmm_33, [1, 16, 2, 64, 64]);  bmm_33 = None
    mul_114 = torch.ops.aten.mul.Tensor(view_245, exp_35);  view_245 = exp_35 = None
    select_115 = torch.ops.aten.select.int(mul_114, 2, 0)
    expand_80 = torch.ops.aten.expand.default(select_115, [1, 16, 64, 64]);  select_115 = None
    view_252 = torch.ops.aten.reshape.default(expand_80, [16, 64, 64]);  expand_80 = None
    expand_81 = torch.ops.aten.expand.default(sub_19, [1, 16, 64, 128]);  sub_19 = None
    view_253 = torch.ops.aten.reshape.default(expand_81, [16, 64, 128]);  expand_81 = None
    bmm_36 = torch.ops.aten.bmm.default(view_252, view_253);  view_252 = view_253 = None
    view_254 = torch.ops.aten.reshape.default(bmm_36, [1, 16, 64, 128]);  bmm_36 = None
    add_85 = torch.ops.aten.add.Tensor(view_251, view_254);  view_251 = view_254 = None
    copy_17 = torch.ops.aten.copy.default(select_116, add_85);  select_116 = add_85 = None
    select_scatter_default_10 = torch.ops.aten.select_scatter.default(permute_88, copy_17, 2, 0);  permute_88 = copy_17 = None
    select_125 = torch.ops.aten.select.int(select_scatter_default_10, 2, 1)
    select_122 = torch.ops.aten.select.int(mul_116, 2, 1);  mul_116 = None
    expand_86 = torch.ops.aten.expand.default(select_122, [1, 16, 64, 128]);  select_122 = None
    view_261 = torch.ops.aten.reshape.default(expand_86, [16, 64, 128]);  expand_86 = None
    expand_87 = torch.ops.aten.expand.default(add_86, [1, 16, 128, 128]);  add_86 = None
    view_262 = torch.ops.aten.reshape.default(expand_87, [16, 128, 128]);  expand_87 = None
    bmm_39 = torch.ops.aten.bmm.default(view_261, view_262);  view_261 = view_262 = None
    view_263 = torch.ops.aten.reshape.default(bmm_39, [1, 16, 64, 128]);  bmm_39 = None
    select_123 = torch.ops.aten.select.int(mul_114, 2, 1);  mul_114 = None
    expand_88 = torch.ops.aten.expand.default(select_123, [1, 16, 64, 64]);  select_123 = None
    view_264 = torch.ops.aten.reshape.default(expand_88, [16, 64, 64]);  expand_88 = None
    expand_89 = torch.ops.aten.expand.default(sub_20, [1, 16, 64, 128]);  sub_20 = None
    view_265 = torch.ops.aten.reshape.default(expand_89, [16, 64, 128]);  expand_89 = None
    bmm_40 = torch.ops.aten.bmm.default(view_264, view_265);  view_264 = view_265 = None
    view_266 = torch.ops.aten.reshape.default(bmm_40, [1, 16, 64, 128]);  bmm_40 = None
    add_87 = torch.ops.aten.add.Tensor(view_263, view_266);  view_263 = view_266 = None
    copy_18 = torch.ops.aten.copy.default(select_125, add_87);  select_125 = add_87 = None
    select_scatter_default_11 = torch.ops.aten.select_scatter.default(select_scatter_default_10, copy_18, 2, 1);  select_scatter_default_10 = copy_18 = None
    clone_34 = torch.ops.aten.clone.default(select_scatter_default_11, memory_format = torch.contiguous_format);  select_scatter_default_11 = None
    view_270 = torch.ops.aten.reshape.default(clone_34, [1, 16, 128, 128]);  clone_34 = None
    permute_91 = torch.ops.aten.permute.default(view_270, [0, 2, 1, 3]);  view_270 = None
    convert_element_type_176 = torch.ops.prims.convert_element_type.default(permute_91, torch.bfloat16);  permute_91 = None
    clone_35 = torch.ops.aten.clone.default(convert_element_type_176, memory_format = torch.contiguous_format);  convert_element_type_176 = None
    view_271 = torch.ops.aten.reshape.default(clone_35, [-1, 128]);  clone_35 = None
    convert_element_type_177 = torch.ops.prims.convert_element_type.default(view_271, torch.float32);  view_271 = None
    pow_15 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_177, 2)
    mean_14 = torch.ops.aten.mean.dim(pow_15, [-1], True);  pow_15 = None
    add_89 = torch.ops.aten.add.Tensor(mean_14, 1e-06);  mean_14 = None
    rsqrt_22 = torch.ops.aten.rsqrt.default(add_89);  add_89 = None
    mul_120 = torch.ops.aten.mul.Tensor(convert_element_type_177, rsqrt_22);  convert_element_type_177 = rsqrt_22 = None
    convert_element_type_178 = torch.ops.prims.convert_element_type.default(mul_120, torch.bfloat16);  mul_120 = None
    mul_121 = torch.ops.aten.mul.Tensor(arg76_1, convert_element_type_178);  arg76_1 = convert_element_type_178 = None
    view_221 = torch.ops.aten.reshape.default(convert_element_type_157, [128, 2048]);  convert_element_type_157 = None
    permute_77 = torch.ops.aten.permute.default(arg68_1, [1, 0]);  arg68_1 = None
    mm_32 = torch.ops.aten.mm.default(view_221, permute_77);  view_221 = permute_77 = None
    view_222 = torch.ops.aten.reshape.default(mm_32, [1, 128, 2048]);  mm_32 = None
    view_223 = torch.ops.aten.reshape.default(view_222, [1, 128, -1, 128]);  view_222 = None
    view_272 = torch.ops.aten.reshape.default(view_223, [-1, 128]);  view_223 = None
    convert_element_type_179 = torch.ops.prims.convert_element_type.default(view_272, torch.float32);  view_272 = None
    neg_17 = torch.ops.aten.neg.default(convert_element_type_179)
    exp_40 = torch.ops.aten.exp.default(neg_17);  neg_17 = None
    add_90 = torch.ops.aten.add.Tensor(exp_40, 1);  exp_40 = None
    div_12 = torch.ops.aten.div.Tensor(convert_element_type_179, add_90);  convert_element_type_179 = add_90 = None
    mul_122 = torch.ops.aten.mul.Tensor(mul_121, div_12);  mul_121 = div_12 = None
    convert_element_type_180 = torch.ops.prims.convert_element_type.default(mul_122, torch.bfloat16);  mul_122 = None
    view_273 = torch.ops.aten.reshape.default(convert_element_type_180, [1, 128, -1]);  convert_element_type_180 = None
    view_274 = torch.ops.aten.reshape.default(view_273, [128, 2048]);  view_273 = None
    permute_92 = torch.ops.aten.permute.default(arg77_1, [1, 0]);  arg77_1 = None
    mm_35 = torch.ops.aten.mm.default(view_274, permute_92);  view_274 = permute_92 = None
    view_275 = torch.ops.aten.reshape.default(mm_35, [1, 128, 2048]);  mm_35 = None
    add_91 = torch.ops.aten.add.Tensor(add_75, view_275);  add_75 = view_275 = None
    convert_element_type_183 = torch.ops.prims.convert_element_type.default(add_91, torch.float32)
    pow_16 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_183, 2)
    mean_15 = torch.ops.aten.mean.dim(pow_16, [-1], True);  pow_16 = None
    add_92 = torch.ops.aten.add.Tensor(mean_15, 1e-06);  mean_15 = None
    rsqrt_23 = torch.ops.aten.rsqrt.default(add_92);  add_92 = None
    mul_123 = torch.ops.aten.mul.Tensor(convert_element_type_183, rsqrt_23);  convert_element_type_183 = rsqrt_23 = None
    convert_element_type_184 = torch.ops.prims.convert_element_type.default(arg78_1, torch.float32);  arg78_1 = None
    add_93 = torch.ops.aten.add.Tensor(convert_element_type_184, 1.0);  convert_element_type_184 = None
    mul_124 = torch.ops.aten.mul.Tensor(mul_123, add_93);  mul_123 = add_93 = None
    convert_element_type_185 = torch.ops.prims.convert_element_type.default(mul_124, torch.bfloat16);  mul_124 = None
    view_276 = torch.ops.aten.reshape.default(convert_element_type_185, [128, 2048])
    permute_93 = torch.ops.aten.permute.default(arg79_1, [1, 0]);  arg79_1 = None
    mm_36 = torch.ops.aten.mm.default(view_276, permute_93);  view_276 = permute_93 = None
    view_277 = torch.ops.aten.reshape.default(mm_36, [1, 128, 6144]);  mm_36 = None
    convert_element_type_188 = torch.ops.prims.convert_element_type.default(view_277, torch.float32);  view_277 = None
    neg_18 = torch.ops.aten.neg.default(convert_element_type_188)
    exp_41 = torch.ops.aten.exp.default(neg_18);  neg_18 = None
    add_94 = torch.ops.aten.add.Tensor(exp_41, 1);  exp_41 = None
    div_13 = torch.ops.aten.div.Tensor(convert_element_type_188, add_94);  convert_element_type_188 = add_94 = None
    convert_element_type_189 = torch.ops.prims.convert_element_type.default(div_13, torch.bfloat16);  div_13 = None
    view_278 = torch.ops.aten.reshape.default(convert_element_type_185, [128, 2048]);  convert_element_type_185 = None
    permute_94 = torch.ops.aten.permute.default(arg80_1, [1, 0]);  arg80_1 = None
    mm_37 = torch.ops.aten.mm.default(view_278, permute_94);  view_278 = permute_94 = None
    view_279 = torch.ops.aten.reshape.default(mm_37, [1, 128, 6144]);  mm_37 = None
    mul_125 = torch.ops.aten.mul.Tensor(convert_element_type_189, view_279);  convert_element_type_189 = view_279 = None
    view_280 = torch.ops.aten.reshape.default(mul_125, [128, 6144]);  mul_125 = None
    permute_95 = torch.ops.aten.permute.default(arg81_1, [1, 0]);  arg81_1 = None
    mm_38 = torch.ops.aten.mm.default(view_280, permute_95);  view_280 = permute_95 = None
    view_281 = torch.ops.aten.reshape.default(mm_38, [1, 128, 2048]);  mm_38 = None
    add_95 = torch.ops.aten.add.Tensor(add_91, view_281);  add_91 = view_281 = None
    convert_element_type_194 = torch.ops.prims.convert_element_type.default(add_95, torch.float32)
    pow_17 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_194, 2)
    mean_16 = torch.ops.aten.mean.dim(pow_17, [-1], True);  pow_17 = None
    add_96 = torch.ops.aten.add.Tensor(mean_16, 1e-06);  mean_16 = None
    rsqrt_24 = torch.ops.aten.rsqrt.default(add_96);  add_96 = None
    mul_126 = torch.ops.aten.mul.Tensor(convert_element_type_194, rsqrt_24);  convert_element_type_194 = rsqrt_24 = None
    convert_element_type_195 = torch.ops.prims.convert_element_type.default(arg82_1, torch.float32);  arg82_1 = None
    add_97 = torch.ops.aten.add.Tensor(convert_element_type_195, 1.0);  convert_element_type_195 = None
    mul_127 = torch.ops.aten.mul.Tensor(mul_126, add_97);  mul_126 = add_97 = None
    convert_element_type_196 = torch.ops.prims.convert_element_type.default(mul_127, torch.bfloat16);  mul_127 = None
    view_282 = torch.ops.aten.reshape.default(convert_element_type_196, [128, 2048])
    permute_96 = torch.ops.aten.permute.default(arg83_1, [1, 0]);  arg83_1 = None
    mm_39 = torch.ops.aten.mm.default(view_282, permute_96);  view_282 = permute_96 = None
    view_283 = torch.ops.aten.reshape.default(mm_39, [1, 128, 6144]);  mm_39 = None
    permute_97 = torch.ops.aten.permute.default(view_283, [0, 2, 1]);  view_283 = None
    slice_58 = torch.ops.aten.slice.Tensor(permute_97, 2, -4, 9223372036854775807)
    copy_20 = torch.ops.aten.copy.default(arg87_1, slice_58);  slice_58 = None
    convert_element_type_205 = torch.ops.prims.convert_element_type.default(permute_97, torch.float32);  permute_97 = None
    constant_pad_nd_24 = torch.ops.aten.constant_pad_nd.default(convert_element_type_205, [3, 3], 0.0);  convert_element_type_205 = None
    slice_59 = torch.ops.aten.slice.Tensor(constant_pad_nd_24, 2, 0, 131)
    squeeze_4 = torch.ops.aten.squeeze.dim(arg88_1, 1);  arg88_1 = None
    unsqueeze_64 = torch.ops.aten.unsqueeze.default(squeeze_4, 1);  squeeze_4 = None
    convert_element_type_206 = torch.ops.prims.convert_element_type.default(unsqueeze_64, torch.float32);  unsqueeze_64 = None
    select_129 = torch.ops.aten.select.int(convert_element_type_206, 1, 0)
    select_130 = torch.ops.aten.select.int(select_129, 1, 0);  select_129 = None
    view_291 = torch.ops.aten.reshape.default(select_130, [1, -1, 1]);  select_130 = None
    mul_128 = torch.ops.aten.mul.Tensor(slice_59, view_291);  slice_59 = view_291 = None
    slice_60 = torch.ops.aten.slice.Tensor(constant_pad_nd_24, 2, 1, 132)
    select_131 = torch.ops.aten.select.int(convert_element_type_206, 1, 0)
    select_132 = torch.ops.aten.select.int(select_131, 1, 1);  select_131 = None
    view_292 = torch.ops.aten.reshape.default(select_132, [1, -1, 1]);  select_132 = None
    mul_129 = torch.ops.aten.mul.Tensor(slice_60, view_292);  slice_60 = view_292 = None
    add_98 = torch.ops.aten.add.Tensor(mul_128, mul_129);  mul_128 = mul_129 = None
    slice_61 = torch.ops.aten.slice.Tensor(constant_pad_nd_24, 2, 2, 133)
    select_133 = torch.ops.aten.select.int(convert_element_type_206, 1, 0)
    select_134 = torch.ops.aten.select.int(select_133, 1, 2);  select_133 = None
    view_293 = torch.ops.aten.reshape.default(select_134, [1, -1, 1]);  select_134 = None
    mul_130 = torch.ops.aten.mul.Tensor(slice_61, view_293);  slice_61 = view_293 = None
    add_99 = torch.ops.aten.add.Tensor(add_98, mul_130);  add_98 = mul_130 = None
    slice_62 = torch.ops.aten.slice.Tensor(constant_pad_nd_24, 2, 3, 134);  constant_pad_nd_24 = None
    select_135 = torch.ops.aten.select.int(convert_element_type_206, 1, 0);  convert_element_type_206 = None
    select_136 = torch.ops.aten.select.int(select_135, 1, 3);  select_135 = None
    view_294 = torch.ops.aten.reshape.default(select_136, [1, -1, 1]);  select_136 = None
    mul_131 = torch.ops.aten.mul.Tensor(slice_62, view_294);  slice_62 = view_294 = None
    add_100 = torch.ops.aten.add.Tensor(add_99, mul_131);  add_99 = mul_131 = None
    convert_element_type_207 = torch.ops.prims.convert_element_type.default(add_100, torch.bfloat16);  add_100 = None
    slice_63 = torch.ops.aten.slice.Tensor(convert_element_type_207, 2, 0, 128);  convert_element_type_207 = None
    convert_element_type_208 = torch.ops.prims.convert_element_type.default(slice_63, torch.float32);  slice_63 = None
    neg_19 = torch.ops.aten.neg.default(convert_element_type_208)
    exp_42 = torch.ops.aten.exp.default(neg_19);  neg_19 = None
    add_101 = torch.ops.aten.add.Tensor(exp_42, 1);  exp_42 = None
    div_14 = torch.ops.aten.div.Tensor(convert_element_type_208, add_101);  convert_element_type_208 = add_101 = None
    convert_element_type_209 = torch.ops.prims.convert_element_type.default(div_14, torch.bfloat16);  div_14 = None
    slice_64 = torch.ops.aten.slice.Tensor(convert_element_type_209, 2, -128, 9223372036854775807);  convert_element_type_209 = None
    permute_101 = torch.ops.aten.permute.default(slice_64, [0, 2, 1]);  slice_64 = None
    split_with_sizes_4 = torch.ops.aten.split_with_sizes.default(permute_101, [2048, 2048, 2048], -1);  permute_101 = None
    getitem_14 = split_with_sizes_4[0]
    getitem_15 = split_with_sizes_4[1]
    getitem_16 = split_with_sizes_4[2];  split_with_sizes_4 = None
    full_14 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_43 = torch.ops.aten.exp.default(arg89_1);  arg89_1 = None
    neg_20 = torch.ops.aten.neg.default(exp_43);  exp_43 = None
    view_289 = torch.ops.aten.reshape.default(convert_element_type_196, [128, 2048])
    permute_100 = torch.ops.aten.permute.default(arg86_1, [1, 0]);  arg86_1 = None
    mm_42 = torch.ops.aten.mm.default(view_289, permute_100);  view_289 = permute_100 = None
    view_290 = torch.ops.aten.reshape.default(mm_42, [1, 128, 16]);  mm_42 = None
    convert_element_type_210 = torch.ops.prims.convert_element_type.default(view_290, torch.float32);  view_290 = None
    add_102 = torch.ops.aten.add.Tensor(convert_element_type_210, arg90_1);  convert_element_type_210 = arg90_1 = None
    gt_4 = torch.ops.aten.gt.Scalar(add_102, 20)
    exp_44 = torch.ops.aten.exp.default(add_102)
    log1p_4 = torch.ops.aten.log1p.default(exp_44);  exp_44 = None
    where_9 = torch.ops.aten.where.self(gt_4, add_102, log1p_4);  gt_4 = add_102 = log1p_4 = None
    mul_132 = torch.ops.aten.mul.Tensor(neg_20, where_9);  neg_20 = where_9 = None
    permute_106 = torch.ops.aten.permute.default(mul_132, [0, 2, 1]);  mul_132 = None
    view_302 = torch.ops.aten.reshape.default(permute_106, [1, 16, 2, 64]);  permute_106 = None
    cumsum_4 = torch.ops.aten.cumsum.default(view_302, 3);  view_302 = None
    select_137 = torch.ops.aten.select.int(cumsum_4, 3, -1)
    exp_49 = torch.ops.aten.exp.default(select_137);  select_137 = None
    unsqueeze_74 = torch.ops.aten.unsqueeze.default(exp_49, 3);  exp_49 = None
    unsqueeze_75 = torch.ops.aten.unsqueeze.default(unsqueeze_74, 4);  unsqueeze_74 = None
    select_144 = torch.ops.aten.select.int(unsqueeze_75, 2, 0)
    mul_145 = torch.ops.aten.mul.Tensor(full_14, select_144);  select_144 = None
    view_296 = torch.ops.aten.reshape.default(getitem_15, [1, 128, 16, 128]);  getitem_15 = None
    permute_103 = torch.ops.aten.permute.default(view_296, [0, 2, 1, 3]);  view_296 = None
    convert_element_type_212 = torch.ops.prims.convert_element_type.default(permute_103, torch.float32);  permute_103 = None
    clone_37 = torch.ops.aten.clone.default(convert_element_type_212, memory_format = torch.contiguous_format);  convert_element_type_212 = None
    mul_135 = torch.ops.aten.mul.Tensor(clone_37, clone_37)
    sum_11 = torch.ops.aten.sum.dim_IntList(mul_135, [-1], True);  mul_135 = None
    add_104 = torch.ops.aten.add.Tensor(sum_11, 1e-06);  sum_11 = None
    rsqrt_26 = torch.ops.aten.rsqrt.default(add_104);  add_104 = None
    mul_136 = torch.ops.aten.mul.Tensor(clone_37, rsqrt_26);  clone_37 = rsqrt_26 = None
    view_299 = torch.ops.aten.reshape.default(mul_136, [1, 16, -1, 64, 128])
    slice_65 = torch.ops.aten.slice.Tensor(cumsum_4, 3, -1, 9223372036854775807)
    sub_23 = torch.ops.aten.sub.Tensor(slice_65, cumsum_4);  slice_65 = None
    exp_48 = torch.ops.aten.exp.default(sub_23);  sub_23 = None
    unsqueeze_73 = torch.ops.aten.unsqueeze.default(exp_48, -1);  exp_48 = None
    mul_144 = torch.ops.aten.mul.Tensor(view_299, unsqueeze_73);  unsqueeze_73 = None
    select_145 = torch.ops.aten.select.int(mul_144, 2, 0)
    permute_110 = torch.ops.aten.permute.default(select_145, [0, 1, 3, 2]);  select_145 = None
    expand_102 = torch.ops.aten.expand.default(permute_110, [1, 16, 128, 64]);  permute_110 = None
    view_318 = torch.ops.aten.reshape.default(expand_102, [16, 128, 64]);  expand_102 = None
    view_287 = torch.ops.aten.reshape.default(convert_element_type_196, [128, 2048])
    permute_99 = torch.ops.aten.permute.default(arg85_1, [1, 0]);  arg85_1 = None
    mm_41 = torch.ops.aten.mm.default(view_287, permute_99);  view_287 = permute_99 = None
    view_288 = torch.ops.aten.reshape.default(mm_41, [1, 128, 16]);  mm_41 = None
    sigmoid_5 = torch.ops.aten.sigmoid.default(view_288);  view_288 = None
    permute_105 = torch.ops.aten.permute.default(sigmoid_5, [0, 2, 1]);  sigmoid_5 = None
    convert_element_type_214 = torch.ops.prims.convert_element_type.default(permute_105, torch.float32);  permute_105 = None
    clone_39 = torch.ops.aten.clone.default(convert_element_type_214, memory_format = torch.contiguous_format);  convert_element_type_214 = None
    unsqueeze_66 = torch.ops.aten.unsqueeze.default(clone_39, -1)
    mul_139 = torch.ops.aten.mul.Tensor(mul_136, unsqueeze_66);  mul_136 = unsqueeze_66 = None
    view_300 = torch.ops.aten.reshape.default(mul_139, [1, 16, -1, 64, 128]);  mul_139 = None
    expand_92 = torch.ops.aten.expand.default(view_300, [1, 16, 2, 64, 128])
    view_303 = torch.ops.aten.reshape.default(expand_92, [32, 64, 128]);  expand_92 = None
    permute_107 = torch.ops.aten.permute.default(view_299, [0, 1, 2, 4, 3])
    expand_93 = torch.ops.aten.expand.default(permute_107, [1, 16, 2, 128, 64]);  permute_107 = None
    view_304 = torch.ops.aten.reshape.default(expand_93, [32, 128, 64]);  expand_93 = None
    bmm_42 = torch.ops.aten.bmm.default(view_303, view_304);  view_303 = view_304 = None
    view_305 = torch.ops.aten.reshape.default(bmm_42, [1, 16, 2, 64, 64]);  bmm_42 = None
    iota_10 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_67 = torch.ops.aten.unsqueeze.default(iota_10, -2);  iota_10 = None
    iota_11 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_68 = torch.ops.aten.unsqueeze.default(iota_11, -1);  iota_11 = None
    sub_21 = torch.ops.aten.sub.Tensor(unsqueeze_67, unsqueeze_68);  unsqueeze_67 = unsqueeze_68 = None
    ge_4 = torch.ops.aten.ge.Scalar(sub_21, 1);  sub_21 = None
    full_default_10 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_4 = torch.ops.aten.logical_and.default(ge_4, full_default_10);  ge_4 = full_default_10 = None
    full_default_11 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_69 = torch.ops.aten.unsqueeze.default(cumsum_4, 4)
    unsqueeze_70 = torch.ops.aten.unsqueeze.default(cumsum_4, 3)
    sub_22 = torch.ops.aten.sub.Tensor(unsqueeze_69, unsqueeze_70);  unsqueeze_69 = unsqueeze_70 = None
    where_10 = torch.ops.aten.where.self(logical_and_4, full_default_11, sub_22);  logical_and_4 = full_default_11 = sub_22 = None
    exp_45 = torch.ops.aten.exp.default(where_10);  where_10 = None
    mul_140 = torch.ops.aten.mul.Tensor(view_305, exp_45);  view_305 = None
    view_297 = torch.ops.aten.reshape.default(getitem_16, [1, 128, 16, 128]);  getitem_16 = None
    permute_104 = torch.ops.aten.permute.default(view_297, [0, 2, 1, 3]);  view_297 = None
    convert_element_type_213 = torch.ops.prims.convert_element_type.default(permute_104, torch.float32);  permute_104 = None
    clone_38 = torch.ops.aten.clone.default(convert_element_type_213, memory_format = torch.contiguous_format);  convert_element_type_213 = None
    unsqueeze_65 = torch.ops.aten.unsqueeze.default(clone_39, -1);  clone_39 = None
    mul_138 = torch.ops.aten.mul.Tensor(clone_38, unsqueeze_65);  clone_38 = unsqueeze_65 = None
    view_301 = torch.ops.aten.reshape.default(mul_138, [1, 16, -1, 64, 128]);  mul_138 = None
    linalg_solve_triangular_8 = torch.ops.aten.linalg_solve_triangular.default(mul_140, view_301, upper = False, unitriangular = True);  view_301 = None
    select_138 = torch.ops.aten.select.int(linalg_solve_triangular_8, 2, 0)
    exp_46 = torch.ops.aten.exp.default(cumsum_4)
    unsqueeze_71 = torch.ops.aten.unsqueeze.default(exp_46, -1);  exp_46 = None
    mul_142 = torch.ops.aten.mul.Tensor(view_300, unsqueeze_71);  view_300 = unsqueeze_71 = None
    linalg_solve_triangular_9 = torch.ops.aten.linalg_solve_triangular.default(mul_140, mul_142, upper = False, unitriangular = True);  mul_140 = mul_142 = None
    select_139 = torch.ops.aten.select.int(linalg_solve_triangular_9, 2, 0)
    expand_96 = torch.ops.aten.expand.default(select_139, [1, 16, 64, 128]);  select_139 = None
    view_309 = torch.ops.aten.reshape.default(expand_96, [16, 64, 128]);  expand_96 = None
    expand_97 = torch.ops.aten.expand.default(full_14, [1, 16, 128, 128])
    view_310 = torch.ops.aten.reshape.default(expand_97, [16, 128, 128]);  expand_97 = None
    bmm_44 = torch.ops.aten.bmm.default(view_309, view_310);  view_309 = view_310 = None
    view_311 = torch.ops.aten.reshape.default(bmm_44, [1, 16, 64, 128]);  bmm_44 = None
    sub_24 = torch.ops.aten.sub.Tensor(select_138, view_311);  select_138 = view_311 = None
    expand_103 = torch.ops.aten.expand.default(sub_24, [1, 16, 64, 128])
    view_319 = torch.ops.aten.reshape.default(expand_103, [16, 64, 128]);  expand_103 = None
    bmm_47 = torch.ops.aten.bmm.default(view_318, view_319);  view_318 = view_319 = None
    view_320 = torch.ops.aten.reshape.default(bmm_47, [1, 16, 128, 128]);  bmm_47 = None
    add_106 = torch.ops.aten.add.Tensor(mul_145, view_320);  mul_145 = view_320 = None
    select_153 = torch.ops.aten.select.int(unsqueeze_75, 2, 1);  unsqueeze_75 = None
    mul_146 = torch.ops.aten.mul.Tensor(add_106, select_153);  select_153 = None
    select_154 = torch.ops.aten.select.int(mul_144, 2, 1);  mul_144 = None
    permute_111 = torch.ops.aten.permute.default(select_154, [0, 1, 3, 2]);  select_154 = None
    expand_110 = torch.ops.aten.expand.default(permute_111, [1, 16, 128, 64]);  permute_111 = None
    view_330 = torch.ops.aten.reshape.default(expand_110, [16, 128, 64]);  expand_110 = None
    select_146 = torch.ops.aten.select.int(linalg_solve_triangular_8, 2, 1);  linalg_solve_triangular_8 = None
    select_147 = torch.ops.aten.select.int(linalg_solve_triangular_9, 2, 1);  linalg_solve_triangular_9 = None
    expand_104 = torch.ops.aten.expand.default(select_147, [1, 16, 64, 128]);  select_147 = None
    view_321 = torch.ops.aten.reshape.default(expand_104, [16, 64, 128]);  expand_104 = None
    expand_105 = torch.ops.aten.expand.default(add_106, [1, 16, 128, 128])
    view_322 = torch.ops.aten.reshape.default(expand_105, [16, 128, 128]);  expand_105 = None
    bmm_48 = torch.ops.aten.bmm.default(view_321, view_322);  view_321 = view_322 = None
    view_323 = torch.ops.aten.reshape.default(bmm_48, [1, 16, 64, 128]);  bmm_48 = None
    sub_25 = torch.ops.aten.sub.Tensor(select_146, view_323);  select_146 = view_323 = None
    expand_111 = torch.ops.aten.expand.default(sub_25, [1, 16, 64, 128])
    view_331 = torch.ops.aten.reshape.default(expand_111, [16, 64, 128]);  expand_111 = None
    bmm_51 = torch.ops.aten.bmm.default(view_330, view_331);  view_330 = view_331 = None
    view_332 = torch.ops.aten.reshape.default(bmm_51, [1, 16, 128, 128]);  bmm_51 = None
    add_108 = torch.ops.aten.add.Tensor(mul_146, view_332);  mul_146 = view_332 = None
    full_15 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_109 = torch.ops.aten.permute.default(full_15, [0, 1, 2, 4, 3]);  full_15 = None
    select_142 = torch.ops.aten.select.int(permute_109, 2, 0)
    view_295 = torch.ops.aten.reshape.default(getitem_14, [1, 128, 16, 128]);  getitem_14 = None
    permute_102 = torch.ops.aten.permute.default(view_295, [0, 2, 1, 3]);  view_295 = None
    convert_element_type_211 = torch.ops.prims.convert_element_type.default(permute_102, torch.float32);  permute_102 = None
    clone_36 = torch.ops.aten.clone.default(convert_element_type_211, memory_format = torch.contiguous_format);  convert_element_type_211 = None
    mul_133 = torch.ops.aten.mul.Tensor(clone_36, clone_36)
    sum_10 = torch.ops.aten.sum.dim_IntList(mul_133, [-1], True);  mul_133 = None
    add_103 = torch.ops.aten.add.Tensor(sum_10, 1e-06);  sum_10 = None
    rsqrt_25 = torch.ops.aten.rsqrt.default(add_103);  add_103 = None
    mul_134 = torch.ops.aten.mul.Tensor(clone_36, rsqrt_25);  clone_36 = rsqrt_25 = None
    mul_137 = torch.ops.aten.mul.Tensor(mul_134, 0.08838834764831845);  mul_134 = None
    view_298 = torch.ops.aten.reshape.default(mul_137, [1, 16, -1, 64, 128]);  mul_137 = None
    exp_47 = torch.ops.aten.exp.default(cumsum_4);  cumsum_4 = None
    unsqueeze_72 = torch.ops.aten.unsqueeze.default(exp_47, -1);  exp_47 = None
    mul_143 = torch.ops.aten.mul.Tensor(view_298, unsqueeze_72);  unsqueeze_72 = None
    select_140 = torch.ops.aten.select.int(mul_143, 2, 0)
    expand_98 = torch.ops.aten.expand.default(select_140, [1, 16, 64, 128]);  select_140 = None
    view_312 = torch.ops.aten.reshape.default(expand_98, [16, 64, 128]);  expand_98 = None
    expand_99 = torch.ops.aten.expand.default(full_14, [1, 16, 128, 128]);  full_14 = None
    view_313 = torch.ops.aten.reshape.default(expand_99, [16, 128, 128]);  expand_99 = None
    bmm_45 = torch.ops.aten.bmm.default(view_312, view_313);  view_312 = view_313 = None
    view_314 = torch.ops.aten.reshape.default(bmm_45, [1, 16, 64, 128]);  bmm_45 = None
    expand_94 = torch.ops.aten.expand.default(view_298, [1, 16, 2, 64, 128]);  view_298 = None
    view_306 = torch.ops.aten.reshape.default(expand_94, [32, 64, 128]);  expand_94 = None
    permute_108 = torch.ops.aten.permute.default(view_299, [0, 1, 2, 4, 3]);  view_299 = None
    expand_95 = torch.ops.aten.expand.default(permute_108, [1, 16, 2, 128, 64]);  permute_108 = None
    view_307 = torch.ops.aten.reshape.default(expand_95, [32, 128, 64]);  expand_95 = None
    bmm_43 = torch.ops.aten.bmm.default(view_306, view_307);  view_306 = view_307 = None
    view_308 = torch.ops.aten.reshape.default(bmm_43, [1, 16, 2, 64, 64]);  bmm_43 = None
    mul_141 = torch.ops.aten.mul.Tensor(view_308, exp_45);  view_308 = exp_45 = None
    select_141 = torch.ops.aten.select.int(mul_141, 2, 0)
    expand_100 = torch.ops.aten.expand.default(select_141, [1, 16, 64, 64]);  select_141 = None
    view_315 = torch.ops.aten.reshape.default(expand_100, [16, 64, 64]);  expand_100 = None
    expand_101 = torch.ops.aten.expand.default(sub_24, [1, 16, 64, 128]);  sub_24 = None
    view_316 = torch.ops.aten.reshape.default(expand_101, [16, 64, 128]);  expand_101 = None
    bmm_46 = torch.ops.aten.bmm.default(view_315, view_316);  view_315 = view_316 = None
    view_317 = torch.ops.aten.reshape.default(bmm_46, [1, 16, 64, 128]);  bmm_46 = None
    add_105 = torch.ops.aten.add.Tensor(view_314, view_317);  view_314 = view_317 = None
    copy_21 = torch.ops.aten.copy.default(select_142, add_105);  select_142 = add_105 = None
    select_scatter_default_12 = torch.ops.aten.select_scatter.default(permute_109, copy_21, 2, 0);  permute_109 = copy_21 = None
    select_151 = torch.ops.aten.select.int(select_scatter_default_12, 2, 1)
    select_148 = torch.ops.aten.select.int(mul_143, 2, 1);  mul_143 = None
    expand_106 = torch.ops.aten.expand.default(select_148, [1, 16, 64, 128]);  select_148 = None
    view_324 = torch.ops.aten.reshape.default(expand_106, [16, 64, 128]);  expand_106 = None
    expand_107 = torch.ops.aten.expand.default(add_106, [1, 16, 128, 128]);  add_106 = None
    view_325 = torch.ops.aten.reshape.default(expand_107, [16, 128, 128]);  expand_107 = None
    bmm_49 = torch.ops.aten.bmm.default(view_324, view_325);  view_324 = view_325 = None
    view_326 = torch.ops.aten.reshape.default(bmm_49, [1, 16, 64, 128]);  bmm_49 = None
    select_149 = torch.ops.aten.select.int(mul_141, 2, 1);  mul_141 = None
    expand_108 = torch.ops.aten.expand.default(select_149, [1, 16, 64, 64]);  select_149 = None
    view_327 = torch.ops.aten.reshape.default(expand_108, [16, 64, 64]);  expand_108 = None
    expand_109 = torch.ops.aten.expand.default(sub_25, [1, 16, 64, 128]);  sub_25 = None
    view_328 = torch.ops.aten.reshape.default(expand_109, [16, 64, 128]);  expand_109 = None
    bmm_50 = torch.ops.aten.bmm.default(view_327, view_328);  view_327 = view_328 = None
    view_329 = torch.ops.aten.reshape.default(bmm_50, [1, 16, 64, 128]);  bmm_50 = None
    add_107 = torch.ops.aten.add.Tensor(view_326, view_329);  view_326 = view_329 = None
    copy_22 = torch.ops.aten.copy.default(select_151, add_107);  select_151 = add_107 = None
    select_scatter_default_13 = torch.ops.aten.select_scatter.default(select_scatter_default_12, copy_22, 2, 1);  select_scatter_default_12 = copy_22 = None
    clone_41 = torch.ops.aten.clone.default(select_scatter_default_13, memory_format = torch.contiguous_format);  select_scatter_default_13 = None
    view_333 = torch.ops.aten.reshape.default(clone_41, [1, 16, 128, 128]);  clone_41 = None
    permute_112 = torch.ops.aten.permute.default(view_333, [0, 2, 1, 3]);  view_333 = None
    convert_element_type_215 = torch.ops.prims.convert_element_type.default(permute_112, torch.bfloat16);  permute_112 = None
    clone_42 = torch.ops.aten.clone.default(convert_element_type_215, memory_format = torch.contiguous_format);  convert_element_type_215 = None
    view_334 = torch.ops.aten.reshape.default(clone_42, [-1, 128]);  clone_42 = None
    convert_element_type_216 = torch.ops.prims.convert_element_type.default(view_334, torch.float32);  view_334 = None
    pow_18 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_216, 2)
    mean_17 = torch.ops.aten.mean.dim(pow_18, [-1], True);  pow_18 = None
    add_109 = torch.ops.aten.add.Tensor(mean_17, 1e-06);  mean_17 = None
    rsqrt_27 = torch.ops.aten.rsqrt.default(add_109);  add_109 = None
    mul_147 = torch.ops.aten.mul.Tensor(convert_element_type_216, rsqrt_27);  convert_element_type_216 = rsqrt_27 = None
    convert_element_type_217 = torch.ops.prims.convert_element_type.default(mul_147, torch.bfloat16);  mul_147 = None
    mul_148 = torch.ops.aten.mul.Tensor(arg92_1, convert_element_type_217);  arg92_1 = convert_element_type_217 = None
    view_284 = torch.ops.aten.reshape.default(convert_element_type_196, [128, 2048]);  convert_element_type_196 = None
    permute_98 = torch.ops.aten.permute.default(arg84_1, [1, 0]);  arg84_1 = None
    mm_40 = torch.ops.aten.mm.default(view_284, permute_98);  view_284 = permute_98 = None
    view_285 = torch.ops.aten.reshape.default(mm_40, [1, 128, 2048]);  mm_40 = None
    view_286 = torch.ops.aten.reshape.default(view_285, [1, 128, -1, 128]);  view_285 = None
    view_335 = torch.ops.aten.reshape.default(view_286, [-1, 128]);  view_286 = None
    convert_element_type_218 = torch.ops.prims.convert_element_type.default(view_335, torch.float32);  view_335 = None
    neg_21 = torch.ops.aten.neg.default(convert_element_type_218)
    exp_50 = torch.ops.aten.exp.default(neg_21);  neg_21 = None
    add_110 = torch.ops.aten.add.Tensor(exp_50, 1);  exp_50 = None
    div_15 = torch.ops.aten.div.Tensor(convert_element_type_218, add_110);  convert_element_type_218 = add_110 = None
    mul_149 = torch.ops.aten.mul.Tensor(mul_148, div_15);  mul_148 = div_15 = None
    convert_element_type_219 = torch.ops.prims.convert_element_type.default(mul_149, torch.bfloat16);  mul_149 = None
    view_336 = torch.ops.aten.reshape.default(convert_element_type_219, [1, 128, -1]);  convert_element_type_219 = None
    view_337 = torch.ops.aten.reshape.default(view_336, [128, 2048]);  view_336 = None
    permute_113 = torch.ops.aten.permute.default(arg93_1, [1, 0]);  arg93_1 = None
    mm_43 = torch.ops.aten.mm.default(view_337, permute_113);  view_337 = permute_113 = None
    view_338 = torch.ops.aten.reshape.default(mm_43, [1, 128, 2048]);  mm_43 = None
    add_111 = torch.ops.aten.add.Tensor(add_95, view_338);  add_95 = view_338 = None
    convert_element_type_222 = torch.ops.prims.convert_element_type.default(add_111, torch.float32)
    pow_19 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_222, 2)
    mean_18 = torch.ops.aten.mean.dim(pow_19, [-1], True);  pow_19 = None
    add_112 = torch.ops.aten.add.Tensor(mean_18, 1e-06);  mean_18 = None
    rsqrt_28 = torch.ops.aten.rsqrt.default(add_112);  add_112 = None
    mul_150 = torch.ops.aten.mul.Tensor(convert_element_type_222, rsqrt_28);  convert_element_type_222 = rsqrt_28 = None
    convert_element_type_223 = torch.ops.prims.convert_element_type.default(arg94_1, torch.float32);  arg94_1 = None
    add_113 = torch.ops.aten.add.Tensor(convert_element_type_223, 1.0);  convert_element_type_223 = None
    mul_151 = torch.ops.aten.mul.Tensor(mul_150, add_113);  mul_150 = add_113 = None
    convert_element_type_224 = torch.ops.prims.convert_element_type.default(mul_151, torch.bfloat16);  mul_151 = None
    view_339 = torch.ops.aten.reshape.default(convert_element_type_224, [128, 2048])
    permute_114 = torch.ops.aten.permute.default(arg95_1, [1, 0]);  arg95_1 = None
    mm_44 = torch.ops.aten.mm.default(view_339, permute_114);  view_339 = permute_114 = None
    view_340 = torch.ops.aten.reshape.default(mm_44, [1, 128, 6144]);  mm_44 = None
    convert_element_type_227 = torch.ops.prims.convert_element_type.default(view_340, torch.float32);  view_340 = None
    neg_22 = torch.ops.aten.neg.default(convert_element_type_227)
    exp_51 = torch.ops.aten.exp.default(neg_22);  neg_22 = None
    add_114 = torch.ops.aten.add.Tensor(exp_51, 1);  exp_51 = None
    div_16 = torch.ops.aten.div.Tensor(convert_element_type_227, add_114);  convert_element_type_227 = add_114 = None
    convert_element_type_228 = torch.ops.prims.convert_element_type.default(div_16, torch.bfloat16);  div_16 = None
    view_341 = torch.ops.aten.reshape.default(convert_element_type_224, [128, 2048]);  convert_element_type_224 = None
    permute_115 = torch.ops.aten.permute.default(arg96_1, [1, 0]);  arg96_1 = None
    mm_45 = torch.ops.aten.mm.default(view_341, permute_115);  view_341 = permute_115 = None
    view_342 = torch.ops.aten.reshape.default(mm_45, [1, 128, 6144]);  mm_45 = None
    mul_152 = torch.ops.aten.mul.Tensor(convert_element_type_228, view_342);  convert_element_type_228 = view_342 = None
    view_343 = torch.ops.aten.reshape.default(mul_152, [128, 6144]);  mul_152 = None
    permute_116 = torch.ops.aten.permute.default(arg97_1, [1, 0]);  arg97_1 = None
    mm_46 = torch.ops.aten.mm.default(view_343, permute_116);  view_343 = permute_116 = None
    view_344 = torch.ops.aten.reshape.default(mm_46, [1, 128, 2048]);  mm_46 = None
    add_115 = torch.ops.aten.add.Tensor(add_111, view_344);  add_111 = view_344 = None
    convert_element_type_233 = torch.ops.prims.convert_element_type.default(add_115, torch.float32)
    pow_20 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_233, 2)
    mean_19 = torch.ops.aten.mean.dim(pow_20, [-1], True);  pow_20 = None
    add_116 = torch.ops.aten.add.Tensor(mean_19, 1e-06);  mean_19 = None
    rsqrt_29 = torch.ops.aten.rsqrt.default(add_116);  add_116 = None
    mul_153 = torch.ops.aten.mul.Tensor(convert_element_type_233, rsqrt_29);  convert_element_type_233 = rsqrt_29 = None
    convert_element_type_234 = torch.ops.prims.convert_element_type.default(arg98_1, torch.float32);  arg98_1 = None
    add_117 = torch.ops.aten.add.Tensor(convert_element_type_234, 1.0);  convert_element_type_234 = None
    mul_154 = torch.ops.aten.mul.Tensor(mul_153, add_117);  mul_153 = add_117 = None
    convert_element_type_235 = torch.ops.prims.convert_element_type.default(mul_154, torch.bfloat16);  mul_154 = None
    view_345 = torch.ops.aten.reshape.default(convert_element_type_235, [128, 2048])
    permute_117 = torch.ops.aten.permute.default(arg99_1, [1, 0]);  arg99_1 = None
    mm_47 = torch.ops.aten.mm.default(view_345, permute_117);  view_345 = permute_117 = None
    view_346 = torch.ops.aten.reshape.default(mm_47, [1, 128, 6144]);  mm_47 = None
    permute_118 = torch.ops.aten.permute.default(view_346, [0, 2, 1]);  view_346 = None
    slice_66 = torch.ops.aten.slice.Tensor(permute_118, 2, -4, 9223372036854775807)
    copy_24 = torch.ops.aten.copy.default(arg103_1, slice_66);  slice_66 = None
    convert_element_type_244 = torch.ops.prims.convert_element_type.default(permute_118, torch.float32);  permute_118 = None
    constant_pad_nd_30 = torch.ops.aten.constant_pad_nd.default(convert_element_type_244, [3, 3], 0.0);  convert_element_type_244 = None
    slice_67 = torch.ops.aten.slice.Tensor(constant_pad_nd_30, 2, 0, 131)
    squeeze_5 = torch.ops.aten.squeeze.dim(arg104_1, 1);  arg104_1 = None
    unsqueeze_76 = torch.ops.aten.unsqueeze.default(squeeze_5, 1);  squeeze_5 = None
    convert_element_type_245 = torch.ops.prims.convert_element_type.default(unsqueeze_76, torch.float32);  unsqueeze_76 = None
    select_155 = torch.ops.aten.select.int(convert_element_type_245, 1, 0)
    select_156 = torch.ops.aten.select.int(select_155, 1, 0);  select_155 = None
    view_354 = torch.ops.aten.reshape.default(select_156, [1, -1, 1]);  select_156 = None
    mul_155 = torch.ops.aten.mul.Tensor(slice_67, view_354);  slice_67 = view_354 = None
    slice_68 = torch.ops.aten.slice.Tensor(constant_pad_nd_30, 2, 1, 132)
    select_157 = torch.ops.aten.select.int(convert_element_type_245, 1, 0)
    select_158 = torch.ops.aten.select.int(select_157, 1, 1);  select_157 = None
    view_355 = torch.ops.aten.reshape.default(select_158, [1, -1, 1]);  select_158 = None
    mul_156 = torch.ops.aten.mul.Tensor(slice_68, view_355);  slice_68 = view_355 = None
    add_118 = torch.ops.aten.add.Tensor(mul_155, mul_156);  mul_155 = mul_156 = None
    slice_69 = torch.ops.aten.slice.Tensor(constant_pad_nd_30, 2, 2, 133)
    select_159 = torch.ops.aten.select.int(convert_element_type_245, 1, 0)
    select_160 = torch.ops.aten.select.int(select_159, 1, 2);  select_159 = None
    view_356 = torch.ops.aten.reshape.default(select_160, [1, -1, 1]);  select_160 = None
    mul_157 = torch.ops.aten.mul.Tensor(slice_69, view_356);  slice_69 = view_356 = None
    add_119 = torch.ops.aten.add.Tensor(add_118, mul_157);  add_118 = mul_157 = None
    slice_70 = torch.ops.aten.slice.Tensor(constant_pad_nd_30, 2, 3, 134);  constant_pad_nd_30 = None
    select_161 = torch.ops.aten.select.int(convert_element_type_245, 1, 0);  convert_element_type_245 = None
    select_162 = torch.ops.aten.select.int(select_161, 1, 3);  select_161 = None
    view_357 = torch.ops.aten.reshape.default(select_162, [1, -1, 1]);  select_162 = None
    mul_158 = torch.ops.aten.mul.Tensor(slice_70, view_357);  slice_70 = view_357 = None
    add_120 = torch.ops.aten.add.Tensor(add_119, mul_158);  add_119 = mul_158 = None
    convert_element_type_246 = torch.ops.prims.convert_element_type.default(add_120, torch.bfloat16);  add_120 = None
    slice_71 = torch.ops.aten.slice.Tensor(convert_element_type_246, 2, 0, 128);  convert_element_type_246 = None
    convert_element_type_247 = torch.ops.prims.convert_element_type.default(slice_71, torch.float32);  slice_71 = None
    neg_23 = torch.ops.aten.neg.default(convert_element_type_247)
    exp_52 = torch.ops.aten.exp.default(neg_23);  neg_23 = None
    add_121 = torch.ops.aten.add.Tensor(exp_52, 1);  exp_52 = None
    div_17 = torch.ops.aten.div.Tensor(convert_element_type_247, add_121);  convert_element_type_247 = add_121 = None
    convert_element_type_248 = torch.ops.prims.convert_element_type.default(div_17, torch.bfloat16);  div_17 = None
    slice_72 = torch.ops.aten.slice.Tensor(convert_element_type_248, 2, -128, 9223372036854775807);  convert_element_type_248 = None
    permute_122 = torch.ops.aten.permute.default(slice_72, [0, 2, 1]);  slice_72 = None
    split_with_sizes_5 = torch.ops.aten.split_with_sizes.default(permute_122, [2048, 2048, 2048], -1);  permute_122 = None
    getitem_17 = split_with_sizes_5[0]
    getitem_18 = split_with_sizes_5[1]
    getitem_19 = split_with_sizes_5[2];  split_with_sizes_5 = None
    full_17 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_53 = torch.ops.aten.exp.default(arg105_1);  arg105_1 = None
    neg_24 = torch.ops.aten.neg.default(exp_53);  exp_53 = None
    view_352 = torch.ops.aten.reshape.default(convert_element_type_235, [128, 2048])
    permute_121 = torch.ops.aten.permute.default(arg102_1, [1, 0]);  arg102_1 = None
    mm_50 = torch.ops.aten.mm.default(view_352, permute_121);  view_352 = permute_121 = None
    view_353 = torch.ops.aten.reshape.default(mm_50, [1, 128, 16]);  mm_50 = None
    convert_element_type_249 = torch.ops.prims.convert_element_type.default(view_353, torch.float32);  view_353 = None
    add_122 = torch.ops.aten.add.Tensor(convert_element_type_249, arg106_1);  convert_element_type_249 = arg106_1 = None
    gt_5 = torch.ops.aten.gt.Scalar(add_122, 20)
    exp_54 = torch.ops.aten.exp.default(add_122)
    log1p_5 = torch.ops.aten.log1p.default(exp_54);  exp_54 = None
    where_11 = torch.ops.aten.where.self(gt_5, add_122, log1p_5);  gt_5 = add_122 = log1p_5 = None
    mul_159 = torch.ops.aten.mul.Tensor(neg_24, where_11);  neg_24 = where_11 = None
    permute_127 = torch.ops.aten.permute.default(mul_159, [0, 2, 1]);  mul_159 = None
    view_365 = torch.ops.aten.reshape.default(permute_127, [1, 16, 2, 64]);  permute_127 = None
    cumsum_5 = torch.ops.aten.cumsum.default(view_365, 3);  view_365 = None
    select_163 = torch.ops.aten.select.int(cumsum_5, 3, -1)
    exp_59 = torch.ops.aten.exp.default(select_163);  select_163 = None
    unsqueeze_86 = torch.ops.aten.unsqueeze.default(exp_59, 3);  exp_59 = None
    unsqueeze_87 = torch.ops.aten.unsqueeze.default(unsqueeze_86, 4);  unsqueeze_86 = None
    select_170 = torch.ops.aten.select.int(unsqueeze_87, 2, 0)
    mul_172 = torch.ops.aten.mul.Tensor(full_17, select_170);  select_170 = None
    view_359 = torch.ops.aten.reshape.default(getitem_18, [1, 128, 16, 128]);  getitem_18 = None
    permute_124 = torch.ops.aten.permute.default(view_359, [0, 2, 1, 3]);  view_359 = None
    convert_element_type_251 = torch.ops.prims.convert_element_type.default(permute_124, torch.float32);  permute_124 = None
    clone_44 = torch.ops.aten.clone.default(convert_element_type_251, memory_format = torch.contiguous_format);  convert_element_type_251 = None
    mul_162 = torch.ops.aten.mul.Tensor(clone_44, clone_44)
    sum_13 = torch.ops.aten.sum.dim_IntList(mul_162, [-1], True);  mul_162 = None
    add_124 = torch.ops.aten.add.Tensor(sum_13, 1e-06);  sum_13 = None
    rsqrt_31 = torch.ops.aten.rsqrt.default(add_124);  add_124 = None
    mul_163 = torch.ops.aten.mul.Tensor(clone_44, rsqrt_31);  clone_44 = rsqrt_31 = None
    view_362 = torch.ops.aten.reshape.default(mul_163, [1, 16, -1, 64, 128])
    slice_73 = torch.ops.aten.slice.Tensor(cumsum_5, 3, -1, 9223372036854775807)
    sub_28 = torch.ops.aten.sub.Tensor(slice_73, cumsum_5);  slice_73 = None
    exp_58 = torch.ops.aten.exp.default(sub_28);  sub_28 = None
    unsqueeze_85 = torch.ops.aten.unsqueeze.default(exp_58, -1);  exp_58 = None
    mul_171 = torch.ops.aten.mul.Tensor(view_362, unsqueeze_85);  unsqueeze_85 = None
    select_171 = torch.ops.aten.select.int(mul_171, 2, 0)
    permute_131 = torch.ops.aten.permute.default(select_171, [0, 1, 3, 2]);  select_171 = None
    expand_122 = torch.ops.aten.expand.default(permute_131, [1, 16, 128, 64]);  permute_131 = None
    view_381 = torch.ops.aten.reshape.default(expand_122, [16, 128, 64]);  expand_122 = None
    view_350 = torch.ops.aten.reshape.default(convert_element_type_235, [128, 2048])
    permute_120 = torch.ops.aten.permute.default(arg101_1, [1, 0]);  arg101_1 = None
    mm_49 = torch.ops.aten.mm.default(view_350, permute_120);  view_350 = permute_120 = None
    view_351 = torch.ops.aten.reshape.default(mm_49, [1, 128, 16]);  mm_49 = None
    sigmoid_6 = torch.ops.aten.sigmoid.default(view_351);  view_351 = None
    permute_126 = torch.ops.aten.permute.default(sigmoid_6, [0, 2, 1]);  sigmoid_6 = None
    convert_element_type_253 = torch.ops.prims.convert_element_type.default(permute_126, torch.float32);  permute_126 = None
    clone_46 = torch.ops.aten.clone.default(convert_element_type_253, memory_format = torch.contiguous_format);  convert_element_type_253 = None
    unsqueeze_78 = torch.ops.aten.unsqueeze.default(clone_46, -1)
    mul_166 = torch.ops.aten.mul.Tensor(mul_163, unsqueeze_78);  mul_163 = unsqueeze_78 = None
    view_363 = torch.ops.aten.reshape.default(mul_166, [1, 16, -1, 64, 128]);  mul_166 = None
    expand_112 = torch.ops.aten.expand.default(view_363, [1, 16, 2, 64, 128])
    view_366 = torch.ops.aten.reshape.default(expand_112, [32, 64, 128]);  expand_112 = None
    permute_128 = torch.ops.aten.permute.default(view_362, [0, 1, 2, 4, 3])
    expand_113 = torch.ops.aten.expand.default(permute_128, [1, 16, 2, 128, 64]);  permute_128 = None
    view_367 = torch.ops.aten.reshape.default(expand_113, [32, 128, 64]);  expand_113 = None
    bmm_52 = torch.ops.aten.bmm.default(view_366, view_367);  view_366 = view_367 = None
    view_368 = torch.ops.aten.reshape.default(bmm_52, [1, 16, 2, 64, 64]);  bmm_52 = None
    iota_12 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_79 = torch.ops.aten.unsqueeze.default(iota_12, -2);  iota_12 = None
    iota_13 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_80 = torch.ops.aten.unsqueeze.default(iota_13, -1);  iota_13 = None
    sub_26 = torch.ops.aten.sub.Tensor(unsqueeze_79, unsqueeze_80);  unsqueeze_79 = unsqueeze_80 = None
    ge_5 = torch.ops.aten.ge.Scalar(sub_26, 1);  sub_26 = None
    full_default_12 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_5 = torch.ops.aten.logical_and.default(ge_5, full_default_12);  ge_5 = full_default_12 = None
    full_default_13 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_81 = torch.ops.aten.unsqueeze.default(cumsum_5, 4)
    unsqueeze_82 = torch.ops.aten.unsqueeze.default(cumsum_5, 3)
    sub_27 = torch.ops.aten.sub.Tensor(unsqueeze_81, unsqueeze_82);  unsqueeze_81 = unsqueeze_82 = None
    where_12 = torch.ops.aten.where.self(logical_and_5, full_default_13, sub_27);  logical_and_5 = full_default_13 = sub_27 = None
    exp_55 = torch.ops.aten.exp.default(where_12);  where_12 = None
    mul_167 = torch.ops.aten.mul.Tensor(view_368, exp_55);  view_368 = None
    view_360 = torch.ops.aten.reshape.default(getitem_19, [1, 128, 16, 128]);  getitem_19 = None
    permute_125 = torch.ops.aten.permute.default(view_360, [0, 2, 1, 3]);  view_360 = None
    convert_element_type_252 = torch.ops.prims.convert_element_type.default(permute_125, torch.float32);  permute_125 = None
    clone_45 = torch.ops.aten.clone.default(convert_element_type_252, memory_format = torch.contiguous_format);  convert_element_type_252 = None
    unsqueeze_77 = torch.ops.aten.unsqueeze.default(clone_46, -1);  clone_46 = None
    mul_165 = torch.ops.aten.mul.Tensor(clone_45, unsqueeze_77);  clone_45 = unsqueeze_77 = None
    view_364 = torch.ops.aten.reshape.default(mul_165, [1, 16, -1, 64, 128]);  mul_165 = None
    linalg_solve_triangular_10 = torch.ops.aten.linalg_solve_triangular.default(mul_167, view_364, upper = False, unitriangular = True);  view_364 = None
    select_164 = torch.ops.aten.select.int(linalg_solve_triangular_10, 2, 0)
    exp_56 = torch.ops.aten.exp.default(cumsum_5)
    unsqueeze_83 = torch.ops.aten.unsqueeze.default(exp_56, -1);  exp_56 = None
    mul_169 = torch.ops.aten.mul.Tensor(view_363, unsqueeze_83);  view_363 = unsqueeze_83 = None
    linalg_solve_triangular_11 = torch.ops.aten.linalg_solve_triangular.default(mul_167, mul_169, upper = False, unitriangular = True);  mul_167 = mul_169 = None
    select_165 = torch.ops.aten.select.int(linalg_solve_triangular_11, 2, 0)
    expand_116 = torch.ops.aten.expand.default(select_165, [1, 16, 64, 128]);  select_165 = None
    view_372 = torch.ops.aten.reshape.default(expand_116, [16, 64, 128]);  expand_116 = None
    expand_117 = torch.ops.aten.expand.default(full_17, [1, 16, 128, 128])
    view_373 = torch.ops.aten.reshape.default(expand_117, [16, 128, 128]);  expand_117 = None
    bmm_54 = torch.ops.aten.bmm.default(view_372, view_373);  view_372 = view_373 = None
    view_374 = torch.ops.aten.reshape.default(bmm_54, [1, 16, 64, 128]);  bmm_54 = None
    sub_29 = torch.ops.aten.sub.Tensor(select_164, view_374);  select_164 = view_374 = None
    expand_123 = torch.ops.aten.expand.default(sub_29, [1, 16, 64, 128])
    view_382 = torch.ops.aten.reshape.default(expand_123, [16, 64, 128]);  expand_123 = None
    bmm_57 = torch.ops.aten.bmm.default(view_381, view_382);  view_381 = view_382 = None
    view_383 = torch.ops.aten.reshape.default(bmm_57, [1, 16, 128, 128]);  bmm_57 = None
    add_126 = torch.ops.aten.add.Tensor(mul_172, view_383);  mul_172 = view_383 = None
    select_179 = torch.ops.aten.select.int(unsqueeze_87, 2, 1);  unsqueeze_87 = None
    mul_173 = torch.ops.aten.mul.Tensor(add_126, select_179);  select_179 = None
    select_180 = torch.ops.aten.select.int(mul_171, 2, 1);  mul_171 = None
    permute_132 = torch.ops.aten.permute.default(select_180, [0, 1, 3, 2]);  select_180 = None
    expand_130 = torch.ops.aten.expand.default(permute_132, [1, 16, 128, 64]);  permute_132 = None
    view_393 = torch.ops.aten.reshape.default(expand_130, [16, 128, 64]);  expand_130 = None
    select_172 = torch.ops.aten.select.int(linalg_solve_triangular_10, 2, 1);  linalg_solve_triangular_10 = None
    select_173 = torch.ops.aten.select.int(linalg_solve_triangular_11, 2, 1);  linalg_solve_triangular_11 = None
    expand_124 = torch.ops.aten.expand.default(select_173, [1, 16, 64, 128]);  select_173 = None
    view_384 = torch.ops.aten.reshape.default(expand_124, [16, 64, 128]);  expand_124 = None
    expand_125 = torch.ops.aten.expand.default(add_126, [1, 16, 128, 128])
    view_385 = torch.ops.aten.reshape.default(expand_125, [16, 128, 128]);  expand_125 = None
    bmm_58 = torch.ops.aten.bmm.default(view_384, view_385);  view_384 = view_385 = None
    view_386 = torch.ops.aten.reshape.default(bmm_58, [1, 16, 64, 128]);  bmm_58 = None
    sub_30 = torch.ops.aten.sub.Tensor(select_172, view_386);  select_172 = view_386 = None
    expand_131 = torch.ops.aten.expand.default(sub_30, [1, 16, 64, 128])
    view_394 = torch.ops.aten.reshape.default(expand_131, [16, 64, 128]);  expand_131 = None
    bmm_61 = torch.ops.aten.bmm.default(view_393, view_394);  view_393 = view_394 = None
    view_395 = torch.ops.aten.reshape.default(bmm_61, [1, 16, 128, 128]);  bmm_61 = None
    add_128 = torch.ops.aten.add.Tensor(mul_173, view_395);  mul_173 = view_395 = None
    full_18 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_130 = torch.ops.aten.permute.default(full_18, [0, 1, 2, 4, 3]);  full_18 = None
    select_168 = torch.ops.aten.select.int(permute_130, 2, 0)
    view_358 = torch.ops.aten.reshape.default(getitem_17, [1, 128, 16, 128]);  getitem_17 = None
    permute_123 = torch.ops.aten.permute.default(view_358, [0, 2, 1, 3]);  view_358 = None
    convert_element_type_250 = torch.ops.prims.convert_element_type.default(permute_123, torch.float32);  permute_123 = None
    clone_43 = torch.ops.aten.clone.default(convert_element_type_250, memory_format = torch.contiguous_format);  convert_element_type_250 = None
    mul_160 = torch.ops.aten.mul.Tensor(clone_43, clone_43)
    sum_12 = torch.ops.aten.sum.dim_IntList(mul_160, [-1], True);  mul_160 = None
    add_123 = torch.ops.aten.add.Tensor(sum_12, 1e-06);  sum_12 = None
    rsqrt_30 = torch.ops.aten.rsqrt.default(add_123);  add_123 = None
    mul_161 = torch.ops.aten.mul.Tensor(clone_43, rsqrt_30);  clone_43 = rsqrt_30 = None
    mul_164 = torch.ops.aten.mul.Tensor(mul_161, 0.08838834764831845);  mul_161 = None
    view_361 = torch.ops.aten.reshape.default(mul_164, [1, 16, -1, 64, 128]);  mul_164 = None
    exp_57 = torch.ops.aten.exp.default(cumsum_5);  cumsum_5 = None
    unsqueeze_84 = torch.ops.aten.unsqueeze.default(exp_57, -1);  exp_57 = None
    mul_170 = torch.ops.aten.mul.Tensor(view_361, unsqueeze_84);  unsqueeze_84 = None
    select_166 = torch.ops.aten.select.int(mul_170, 2, 0)
    expand_118 = torch.ops.aten.expand.default(select_166, [1, 16, 64, 128]);  select_166 = None
    view_375 = torch.ops.aten.reshape.default(expand_118, [16, 64, 128]);  expand_118 = None
    expand_119 = torch.ops.aten.expand.default(full_17, [1, 16, 128, 128]);  full_17 = None
    view_376 = torch.ops.aten.reshape.default(expand_119, [16, 128, 128]);  expand_119 = None
    bmm_55 = torch.ops.aten.bmm.default(view_375, view_376);  view_375 = view_376 = None
    view_377 = torch.ops.aten.reshape.default(bmm_55, [1, 16, 64, 128]);  bmm_55 = None
    expand_114 = torch.ops.aten.expand.default(view_361, [1, 16, 2, 64, 128]);  view_361 = None
    view_369 = torch.ops.aten.reshape.default(expand_114, [32, 64, 128]);  expand_114 = None
    permute_129 = torch.ops.aten.permute.default(view_362, [0, 1, 2, 4, 3]);  view_362 = None
    expand_115 = torch.ops.aten.expand.default(permute_129, [1, 16, 2, 128, 64]);  permute_129 = None
    view_370 = torch.ops.aten.reshape.default(expand_115, [32, 128, 64]);  expand_115 = None
    bmm_53 = torch.ops.aten.bmm.default(view_369, view_370);  view_369 = view_370 = None
    view_371 = torch.ops.aten.reshape.default(bmm_53, [1, 16, 2, 64, 64]);  bmm_53 = None
    mul_168 = torch.ops.aten.mul.Tensor(view_371, exp_55);  view_371 = exp_55 = None
    select_167 = torch.ops.aten.select.int(mul_168, 2, 0)
    expand_120 = torch.ops.aten.expand.default(select_167, [1, 16, 64, 64]);  select_167 = None
    view_378 = torch.ops.aten.reshape.default(expand_120, [16, 64, 64]);  expand_120 = None
    expand_121 = torch.ops.aten.expand.default(sub_29, [1, 16, 64, 128]);  sub_29 = None
    view_379 = torch.ops.aten.reshape.default(expand_121, [16, 64, 128]);  expand_121 = None
    bmm_56 = torch.ops.aten.bmm.default(view_378, view_379);  view_378 = view_379 = None
    view_380 = torch.ops.aten.reshape.default(bmm_56, [1, 16, 64, 128]);  bmm_56 = None
    add_125 = torch.ops.aten.add.Tensor(view_377, view_380);  view_377 = view_380 = None
    copy_25 = torch.ops.aten.copy.default(select_168, add_125);  select_168 = add_125 = None
    select_scatter_default_14 = torch.ops.aten.select_scatter.default(permute_130, copy_25, 2, 0);  permute_130 = copy_25 = None
    select_177 = torch.ops.aten.select.int(select_scatter_default_14, 2, 1)
    select_174 = torch.ops.aten.select.int(mul_170, 2, 1);  mul_170 = None
    expand_126 = torch.ops.aten.expand.default(select_174, [1, 16, 64, 128]);  select_174 = None
    view_387 = torch.ops.aten.reshape.default(expand_126, [16, 64, 128]);  expand_126 = None
    expand_127 = torch.ops.aten.expand.default(add_126, [1, 16, 128, 128]);  add_126 = None
    view_388 = torch.ops.aten.reshape.default(expand_127, [16, 128, 128]);  expand_127 = None
    bmm_59 = torch.ops.aten.bmm.default(view_387, view_388);  view_387 = view_388 = None
    view_389 = torch.ops.aten.reshape.default(bmm_59, [1, 16, 64, 128]);  bmm_59 = None
    select_175 = torch.ops.aten.select.int(mul_168, 2, 1);  mul_168 = None
    expand_128 = torch.ops.aten.expand.default(select_175, [1, 16, 64, 64]);  select_175 = None
    view_390 = torch.ops.aten.reshape.default(expand_128, [16, 64, 64]);  expand_128 = None
    expand_129 = torch.ops.aten.expand.default(sub_30, [1, 16, 64, 128]);  sub_30 = None
    view_391 = torch.ops.aten.reshape.default(expand_129, [16, 64, 128]);  expand_129 = None
    bmm_60 = torch.ops.aten.bmm.default(view_390, view_391);  view_390 = view_391 = None
    view_392 = torch.ops.aten.reshape.default(bmm_60, [1, 16, 64, 128]);  bmm_60 = None
    add_127 = torch.ops.aten.add.Tensor(view_389, view_392);  view_389 = view_392 = None
    copy_26 = torch.ops.aten.copy.default(select_177, add_127);  select_177 = add_127 = None
    select_scatter_default_15 = torch.ops.aten.select_scatter.default(select_scatter_default_14, copy_26, 2, 1);  select_scatter_default_14 = copy_26 = None
    clone_48 = torch.ops.aten.clone.default(select_scatter_default_15, memory_format = torch.contiguous_format);  select_scatter_default_15 = None
    view_396 = torch.ops.aten.reshape.default(clone_48, [1, 16, 128, 128]);  clone_48 = None
    permute_133 = torch.ops.aten.permute.default(view_396, [0, 2, 1, 3]);  view_396 = None
    convert_element_type_254 = torch.ops.prims.convert_element_type.default(permute_133, torch.bfloat16);  permute_133 = None
    clone_49 = torch.ops.aten.clone.default(convert_element_type_254, memory_format = torch.contiguous_format);  convert_element_type_254 = None
    view_397 = torch.ops.aten.reshape.default(clone_49, [-1, 128]);  clone_49 = None
    convert_element_type_255 = torch.ops.prims.convert_element_type.default(view_397, torch.float32);  view_397 = None
    pow_21 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_255, 2)
    mean_20 = torch.ops.aten.mean.dim(pow_21, [-1], True);  pow_21 = None
    add_129 = torch.ops.aten.add.Tensor(mean_20, 1e-06);  mean_20 = None
    rsqrt_32 = torch.ops.aten.rsqrt.default(add_129);  add_129 = None
    mul_174 = torch.ops.aten.mul.Tensor(convert_element_type_255, rsqrt_32);  convert_element_type_255 = rsqrt_32 = None
    convert_element_type_256 = torch.ops.prims.convert_element_type.default(mul_174, torch.bfloat16);  mul_174 = None
    mul_175 = torch.ops.aten.mul.Tensor(arg108_1, convert_element_type_256);  arg108_1 = convert_element_type_256 = None
    view_347 = torch.ops.aten.reshape.default(convert_element_type_235, [128, 2048]);  convert_element_type_235 = None
    permute_119 = torch.ops.aten.permute.default(arg100_1, [1, 0]);  arg100_1 = None
    mm_48 = torch.ops.aten.mm.default(view_347, permute_119);  view_347 = permute_119 = None
    view_348 = torch.ops.aten.reshape.default(mm_48, [1, 128, 2048]);  mm_48 = None
    view_349 = torch.ops.aten.reshape.default(view_348, [1, 128, -1, 128]);  view_348 = None
    view_398 = torch.ops.aten.reshape.default(view_349, [-1, 128]);  view_349 = None
    convert_element_type_257 = torch.ops.prims.convert_element_type.default(view_398, torch.float32);  view_398 = None
    neg_25 = torch.ops.aten.neg.default(convert_element_type_257)
    exp_60 = torch.ops.aten.exp.default(neg_25);  neg_25 = None
    add_130 = torch.ops.aten.add.Tensor(exp_60, 1);  exp_60 = None
    div_18 = torch.ops.aten.div.Tensor(convert_element_type_257, add_130);  convert_element_type_257 = add_130 = None
    mul_176 = torch.ops.aten.mul.Tensor(mul_175, div_18);  mul_175 = div_18 = None
    convert_element_type_258 = torch.ops.prims.convert_element_type.default(mul_176, torch.bfloat16);  mul_176 = None
    view_399 = torch.ops.aten.reshape.default(convert_element_type_258, [1, 128, -1]);  convert_element_type_258 = None
    view_400 = torch.ops.aten.reshape.default(view_399, [128, 2048]);  view_399 = None
    permute_134 = torch.ops.aten.permute.default(arg109_1, [1, 0]);  arg109_1 = None
    mm_51 = torch.ops.aten.mm.default(view_400, permute_134);  view_400 = permute_134 = None
    view_401 = torch.ops.aten.reshape.default(mm_51, [1, 128, 2048]);  mm_51 = None
    add_131 = torch.ops.aten.add.Tensor(add_115, view_401);  add_115 = view_401 = None
    convert_element_type_261 = torch.ops.prims.convert_element_type.default(add_131, torch.float32)
    pow_22 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_261, 2)
    mean_21 = torch.ops.aten.mean.dim(pow_22, [-1], True);  pow_22 = None
    add_132 = torch.ops.aten.add.Tensor(mean_21, 1e-06);  mean_21 = None
    rsqrt_33 = torch.ops.aten.rsqrt.default(add_132);  add_132 = None
    mul_177 = torch.ops.aten.mul.Tensor(convert_element_type_261, rsqrt_33);  convert_element_type_261 = rsqrt_33 = None
    convert_element_type_262 = torch.ops.prims.convert_element_type.default(arg110_1, torch.float32);  arg110_1 = None
    add_133 = torch.ops.aten.add.Tensor(convert_element_type_262, 1.0);  convert_element_type_262 = None
    mul_178 = torch.ops.aten.mul.Tensor(mul_177, add_133);  mul_177 = add_133 = None
    convert_element_type_263 = torch.ops.prims.convert_element_type.default(mul_178, torch.bfloat16);  mul_178 = None
    view_402 = torch.ops.aten.reshape.default(convert_element_type_263, [128, 2048])
    permute_135 = torch.ops.aten.permute.default(arg111_1, [1, 0]);  arg111_1 = None
    mm_52 = torch.ops.aten.mm.default(view_402, permute_135);  view_402 = permute_135 = None
    view_403 = torch.ops.aten.reshape.default(mm_52, [1, 128, 6144]);  mm_52 = None
    convert_element_type_266 = torch.ops.prims.convert_element_type.default(view_403, torch.float32);  view_403 = None
    neg_26 = torch.ops.aten.neg.default(convert_element_type_266)
    exp_61 = torch.ops.aten.exp.default(neg_26);  neg_26 = None
    add_134 = torch.ops.aten.add.Tensor(exp_61, 1);  exp_61 = None
    div_19 = torch.ops.aten.div.Tensor(convert_element_type_266, add_134);  convert_element_type_266 = add_134 = None
    convert_element_type_267 = torch.ops.prims.convert_element_type.default(div_19, torch.bfloat16);  div_19 = None
    view_404 = torch.ops.aten.reshape.default(convert_element_type_263, [128, 2048]);  convert_element_type_263 = None
    permute_136 = torch.ops.aten.permute.default(arg112_1, [1, 0]);  arg112_1 = None
    mm_53 = torch.ops.aten.mm.default(view_404, permute_136);  view_404 = permute_136 = None
    view_405 = torch.ops.aten.reshape.default(mm_53, [1, 128, 6144]);  mm_53 = None
    mul_179 = torch.ops.aten.mul.Tensor(convert_element_type_267, view_405);  convert_element_type_267 = view_405 = None
    view_406 = torch.ops.aten.reshape.default(mul_179, [128, 6144]);  mul_179 = None
    permute_137 = torch.ops.aten.permute.default(arg113_1, [1, 0]);  arg113_1 = None
    mm_54 = torch.ops.aten.mm.default(view_406, permute_137);  view_406 = permute_137 = None
    view_407 = torch.ops.aten.reshape.default(mm_54, [1, 128, 2048]);  mm_54 = None
    add_135 = torch.ops.aten.add.Tensor(add_131, view_407);  add_131 = view_407 = None
    convert_element_type_272 = torch.ops.prims.convert_element_type.default(add_135, torch.float32)
    pow_23 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_272, 2)
    mean_22 = torch.ops.aten.mean.dim(pow_23, [-1], True);  pow_23 = None
    add_136 = torch.ops.aten.add.Tensor(mean_22, 1e-06);  mean_22 = None
    rsqrt_34 = torch.ops.aten.rsqrt.default(add_136);  add_136 = None
    mul_180 = torch.ops.aten.mul.Tensor(convert_element_type_272, rsqrt_34);  convert_element_type_272 = rsqrt_34 = None
    convert_element_type_273 = torch.ops.prims.convert_element_type.default(arg114_1, torch.float32);  arg114_1 = None
    add_137 = torch.ops.aten.add.Tensor(convert_element_type_273, 1.0);  convert_element_type_273 = None
    mul_181 = torch.ops.aten.mul.Tensor(mul_180, add_137);  mul_180 = add_137 = None
    convert_element_type_274 = torch.ops.prims.convert_element_type.default(mul_181, torch.bfloat16);  mul_181 = None
    view_408 = torch.ops.aten.reshape.default(convert_element_type_274, [128, 2048])
    permute_138 = torch.ops.aten.permute.default(arg115_1, [1, 0]);  arg115_1 = None
    mm_55 = torch.ops.aten.mm.default(view_408, permute_138);  view_408 = permute_138 = None
    view_409 = torch.ops.aten.reshape.default(mm_55, [1, 128, 4096]);  mm_55 = None
    view_410 = torch.ops.aten.reshape.default(view_409, [1, 128, -1, 512]);  view_409 = None
    split_1 = torch.ops.aten.split.Tensor(view_410, 256, -1);  view_410 = None
    getitem_20 = split_1[0]
    getitem_21 = split_1[1];  split_1 = None
    add_145 = torch.ops.aten.add.Tensor(arg120_1, 128)
    convert_element_type_277 = torch.ops.prims.convert_element_type.default(getitem_20, torch.float32);  getitem_20 = None
    pow_24 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_277, 2)
    mean_23 = torch.ops.aten.mean.dim(pow_24, [-1], True);  pow_24 = None
    add_138 = torch.ops.aten.add.Tensor(mean_23, 1e-06);  mean_23 = None
    rsqrt_35 = torch.ops.aten.rsqrt.default(add_138);  add_138 = None
    mul_182 = torch.ops.aten.mul.Tensor(convert_element_type_277, rsqrt_35);  convert_element_type_277 = rsqrt_35 = None
    convert_element_type_278 = torch.ops.prims.convert_element_type.default(arg116_1, torch.float32);  arg116_1 = None
    add_139 = torch.ops.aten.add.Tensor(convert_element_type_278, 1.0);  convert_element_type_278 = None
    mul_183 = torch.ops.aten.mul.Tensor(mul_182, add_139);  mul_182 = add_139 = None
    convert_element_type_279 = torch.ops.prims.convert_element_type.default(mul_183, torch.bfloat16);  mul_183 = None
    permute_139 = torch.ops.aten.permute.default(convert_element_type_279, [0, 2, 1, 3]);  convert_element_type_279 = None
    slice_74 = torch.ops.aten.slice.Tensor(permute_139, 3, 0, 64)
    unsqueeze_88 = torch.ops.aten.unsqueeze.default(convert_element_type_2, 1)
    mul_186 = torch.ops.aten.mul.Tensor(slice_74, unsqueeze_88)
    slice_79 = torch.ops.aten.slice.Tensor(slice_74, 3, 32, 9223372036854775807)
    neg_27 = torch.ops.aten.neg.default(slice_79);  slice_79 = None
    slice_78 = torch.ops.aten.slice.Tensor(slice_74, 3, 0, 32);  slice_74 = None
    cat_4 = torch.ops.aten.cat.default([neg_27, slice_78], -1);  neg_27 = slice_78 = None
    unsqueeze_89 = torch.ops.aten.unsqueeze.default(convert_element_type_3, 1)
    mul_187 = torch.ops.aten.mul.Tensor(cat_4, unsqueeze_89);  cat_4 = None
    add_142 = torch.ops.aten.add.Tensor(mul_186, mul_187);  mul_186 = mul_187 = None
    slice_75 = torch.ops.aten.slice.Tensor(permute_139, 3, 64, 9223372036854775807);  permute_139 = None
    cat_6 = torch.ops.aten.cat.default([add_142, slice_75], -1);  add_142 = slice_75 = None
    expand_136 = torch.ops.aten.expand.default(cat_6, [1, 8, 128, 256]);  cat_6 = None
    view_421 = torch.ops.aten.reshape.default(expand_136, [8, 128, 256]);  expand_136 = None
    iota_14 = torch.ops.prims.iota.default(128, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    add_144 = torch.ops.aten.add.Tensor(iota_14, arg120_1);  iota_14 = None
    view_413 = torch.ops.aten.reshape.default(convert_element_type_274, [128, 2048])
    permute_140 = torch.ops.aten.permute.default(arg117_1, [1, 0]);  arg117_1 = None
    mm_56 = torch.ops.aten.mm.default(view_413, permute_140);  view_413 = permute_140 = None
    view_414 = torch.ops.aten.reshape.default(mm_56, [1, 128, 512]);  mm_56 = None
    view_415 = torch.ops.aten.reshape.default(view_414, [1, 128, -1, 256]);  view_414 = None
    convert_element_type_282 = torch.ops.prims.convert_element_type.default(view_415, torch.float32);  view_415 = None
    pow_25 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_282, 2)
    mean_24 = torch.ops.aten.mean.dim(pow_25, [-1], True);  pow_25 = None
    add_140 = torch.ops.aten.add.Tensor(mean_24, 1e-06);  mean_24 = None
    rsqrt_36 = torch.ops.aten.rsqrt.default(add_140);  add_140 = None
    mul_184 = torch.ops.aten.mul.Tensor(convert_element_type_282, rsqrt_36);  convert_element_type_282 = rsqrt_36 = None
    convert_element_type_283 = torch.ops.prims.convert_element_type.default(arg118_1, torch.float32);  arg118_1 = None
    add_141 = torch.ops.aten.add.Tensor(convert_element_type_283, 1.0);  convert_element_type_283 = None
    mul_185 = torch.ops.aten.mul.Tensor(mul_184, add_141);  mul_184 = add_141 = None
    convert_element_type_284 = torch.ops.prims.convert_element_type.default(mul_185, torch.bfloat16);  mul_185 = None
    permute_141 = torch.ops.aten.permute.default(convert_element_type_284, [0, 2, 1, 3]);  convert_element_type_284 = None
    slice_76 = torch.ops.aten.slice.Tensor(permute_141, 3, 0, 64)
    mul_188 = torch.ops.aten.mul.Tensor(slice_76, unsqueeze_88);  unsqueeze_88 = None
    slice_81 = torch.ops.aten.slice.Tensor(slice_76, 3, 32, 9223372036854775807)
    neg_28 = torch.ops.aten.neg.default(slice_81);  slice_81 = None
    slice_80 = torch.ops.aten.slice.Tensor(slice_76, 3, 0, 32);  slice_76 = None
    cat_5 = torch.ops.aten.cat.default([neg_28, slice_80], -1);  neg_28 = slice_80 = None
    mul_189 = torch.ops.aten.mul.Tensor(cat_5, unsqueeze_89);  cat_5 = unsqueeze_89 = None
    add_143 = torch.ops.aten.add.Tensor(mul_188, mul_189);  mul_188 = mul_189 = None
    slice_77 = torch.ops.aten.slice.Tensor(permute_141, 3, 64, 9223372036854775807);  permute_141 = None
    cat_7 = torch.ops.aten.cat.default([add_143, slice_77], -1);  add_143 = slice_77 = None
    index_put_2 = torch.ops.aten.index_put_.default(arg121_1, [None, None, add_144], cat_7);  arg121_1 = cat_7 = None
    unsqueeze_92 = torch.ops.aten.unsqueeze.default(index_put_2, 2);  index_put_2 = None
    expand_133 = torch.ops.aten.expand.default(unsqueeze_92, [1, 2, 4, 144, 256]);  unsqueeze_92 = None
    clone_51 = torch.ops.aten.clone.default(expand_133, memory_format = torch.contiguous_format);  expand_133 = None
    view_419 = torch.ops.aten.reshape.default(clone_51, [1, 8, 144, 256]);  clone_51 = None
    permute_144 = torch.ops.aten.permute.default(view_419, [0, 1, 3, 2]);  view_419 = None
    expand_137 = torch.ops.aten.expand.default(permute_144, [1, 8, 256, 144]);  permute_144 = None
    view_422 = torch.ops.aten.reshape.default(expand_137, [8, 256, 144]);  expand_137 = None
    bmm_62 = torch.ops.aten.bmm.default(view_421, view_422);  view_421 = view_422 = None
    view_423 = torch.ops.aten.reshape.default(bmm_62, [1, 8, 128, 144]);  bmm_62 = None
    mul_190 = torch.ops.aten.mul.Tensor(view_423, 0.0625);  view_423 = None
    add_146 = torch.ops.aten.add.Tensor(mul_190, unsqueeze_3);  mul_190 = None
    convert_element_type_289 = torch.ops.prims.convert_element_type.default(add_146, torch.float32);  add_146 = None
    amax_1 = torch.ops.aten.amax.default(convert_element_type_289, [-1], True)
    sub_31 = torch.ops.aten.sub.Tensor(convert_element_type_289, amax_1);  convert_element_type_289 = amax_1 = None
    exp_62 = torch.ops.aten.exp.default(sub_31);  sub_31 = None
    sum_14 = torch.ops.aten.sum.dim_IntList(exp_62, [-1], True)
    div_20 = torch.ops.aten.div.Tensor(exp_62, sum_14);  exp_62 = sum_14 = None
    convert_element_type_290 = torch.ops.prims.convert_element_type.default(div_20, torch.bfloat16);  div_20 = None
    expand_138 = torch.ops.aten.expand.default(convert_element_type_290, [1, 8, 128, 144]);  convert_element_type_290 = None
    view_424 = torch.ops.aten.reshape.default(expand_138, [8, 128, 144]);  expand_138 = None
    view_416 = torch.ops.aten.reshape.default(convert_element_type_274, [128, 2048]);  convert_element_type_274 = None
    permute_142 = torch.ops.aten.permute.default(arg119_1, [1, 0]);  arg119_1 = None
    mm_57 = torch.ops.aten.mm.default(view_416, permute_142);  view_416 = permute_142 = None
    view_417 = torch.ops.aten.reshape.default(mm_57, [1, 128, 512]);  mm_57 = None
    view_418 = torch.ops.aten.reshape.default(view_417, [1, 128, -1, 256]);  view_417 = None
    permute_143 = torch.ops.aten.permute.default(view_418, [0, 2, 1, 3]);  view_418 = None
    index_put_3 = torch.ops.aten.index_put_.default(arg122_1, [None, None, add_144], permute_143);  arg122_1 = add_144 = permute_143 = None
    unsqueeze_95 = torch.ops.aten.unsqueeze.default(index_put_3, 2);  index_put_3 = None
    expand_135 = torch.ops.aten.expand.default(unsqueeze_95, [1, 2, 4, 144, 256]);  unsqueeze_95 = None
    clone_52 = torch.ops.aten.clone.default(expand_135, memory_format = torch.contiguous_format);  expand_135 = None
    view_420 = torch.ops.aten.reshape.default(clone_52, [1, 8, 144, 256]);  clone_52 = None
    expand_139 = torch.ops.aten.expand.default(view_420, [1, 8, 144, 256]);  view_420 = None
    view_425 = torch.ops.aten.reshape.default(expand_139, [8, 144, 256]);  expand_139 = None
    bmm_63 = torch.ops.aten.bmm.default(view_424, view_425);  view_424 = view_425 = None
    view_426 = torch.ops.aten.reshape.default(bmm_63, [1, 8, 128, 256]);  bmm_63 = None
    permute_145 = torch.ops.aten.permute.default(view_426, [0, 2, 1, 3]);  view_426 = None
    clone_53 = torch.ops.aten.clone.default(permute_145, memory_format = torch.contiguous_format);  permute_145 = None
    view_427 = torch.ops.aten.reshape.default(clone_53, [1, 128, -1]);  clone_53 = None
    clone_50 = torch.ops.aten.clone.default(getitem_21, memory_format = torch.contiguous_format);  getitem_21 = None
    view_411 = torch.ops.aten.reshape.default(clone_50, [1, 128, 2048]);  clone_50 = None
    sigmoid_7 = torch.ops.aten.sigmoid.default(view_411);  view_411 = None
    mul_191 = torch.ops.aten.mul.Tensor(view_427, sigmoid_7);  view_427 = sigmoid_7 = None
    view_428 = torch.ops.aten.reshape.default(mul_191, [128, 2048]);  mul_191 = None
    permute_146 = torch.ops.aten.permute.default(arg123_1, [1, 0]);  arg123_1 = None
    mm_58 = torch.ops.aten.mm.default(view_428, permute_146);  view_428 = permute_146 = None
    view_429 = torch.ops.aten.reshape.default(mm_58, [1, 128, 2048]);  mm_58 = None
    add_147 = torch.ops.aten.add.Tensor(add_135, view_429);  add_135 = view_429 = None
    convert_element_type_295 = torch.ops.prims.convert_element_type.default(add_147, torch.float32)
    pow_26 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_295, 2)
    mean_25 = torch.ops.aten.mean.dim(pow_26, [-1], True);  pow_26 = None
    add_148 = torch.ops.aten.add.Tensor(mean_25, 1e-06);  mean_25 = None
    rsqrt_37 = torch.ops.aten.rsqrt.default(add_148);  add_148 = None
    mul_192 = torch.ops.aten.mul.Tensor(convert_element_type_295, rsqrt_37);  convert_element_type_295 = rsqrt_37 = None
    convert_element_type_296 = torch.ops.prims.convert_element_type.default(arg124_1, torch.float32);  arg124_1 = None
    add_149 = torch.ops.aten.add.Tensor(convert_element_type_296, 1.0);  convert_element_type_296 = None
    mul_193 = torch.ops.aten.mul.Tensor(mul_192, add_149);  mul_192 = add_149 = None
    convert_element_type_297 = torch.ops.prims.convert_element_type.default(mul_193, torch.bfloat16);  mul_193 = None
    view_430 = torch.ops.aten.reshape.default(convert_element_type_297, [128, 2048])
    permute_147 = torch.ops.aten.permute.default(arg125_1, [1, 0]);  arg125_1 = None
    mm_59 = torch.ops.aten.mm.default(view_430, permute_147);  view_430 = permute_147 = None
    view_431 = torch.ops.aten.reshape.default(mm_59, [1, 128, 6144]);  mm_59 = None
    convert_element_type_300 = torch.ops.prims.convert_element_type.default(view_431, torch.float32);  view_431 = None
    neg_29 = torch.ops.aten.neg.default(convert_element_type_300)
    exp_63 = torch.ops.aten.exp.default(neg_29);  neg_29 = None
    add_150 = torch.ops.aten.add.Tensor(exp_63, 1);  exp_63 = None
    div_21 = torch.ops.aten.div.Tensor(convert_element_type_300, add_150);  convert_element_type_300 = add_150 = None
    convert_element_type_301 = torch.ops.prims.convert_element_type.default(div_21, torch.bfloat16);  div_21 = None
    view_432 = torch.ops.aten.reshape.default(convert_element_type_297, [128, 2048]);  convert_element_type_297 = None
    permute_148 = torch.ops.aten.permute.default(arg126_1, [1, 0]);  arg126_1 = None
    mm_60 = torch.ops.aten.mm.default(view_432, permute_148);  view_432 = permute_148 = None
    view_433 = torch.ops.aten.reshape.default(mm_60, [1, 128, 6144]);  mm_60 = None
    mul_194 = torch.ops.aten.mul.Tensor(convert_element_type_301, view_433);  convert_element_type_301 = view_433 = None
    view_434 = torch.ops.aten.reshape.default(mul_194, [128, 6144]);  mul_194 = None
    permute_149 = torch.ops.aten.permute.default(arg127_1, [1, 0]);  arg127_1 = None
    mm_61 = torch.ops.aten.mm.default(view_434, permute_149);  view_434 = permute_149 = None
    view_435 = torch.ops.aten.reshape.default(mm_61, [1, 128, 2048]);  mm_61 = None
    add_151 = torch.ops.aten.add.Tensor(add_147, view_435);  add_147 = view_435 = None
    convert_element_type_306 = torch.ops.prims.convert_element_type.default(add_151, torch.float32)
    pow_27 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_306, 2)
    mean_26 = torch.ops.aten.mean.dim(pow_27, [-1], True);  pow_27 = None
    add_152 = torch.ops.aten.add.Tensor(mean_26, 1e-06);  mean_26 = None
    rsqrt_38 = torch.ops.aten.rsqrt.default(add_152);  add_152 = None
    mul_195 = torch.ops.aten.mul.Tensor(convert_element_type_306, rsqrt_38);  convert_element_type_306 = rsqrt_38 = None
    convert_element_type_307 = torch.ops.prims.convert_element_type.default(arg128_1, torch.float32);  arg128_1 = None
    add_153 = torch.ops.aten.add.Tensor(convert_element_type_307, 1.0);  convert_element_type_307 = None
    mul_196 = torch.ops.aten.mul.Tensor(mul_195, add_153);  mul_195 = add_153 = None
    convert_element_type_308 = torch.ops.prims.convert_element_type.default(mul_196, torch.bfloat16);  mul_196 = None
    view_436 = torch.ops.aten.reshape.default(convert_element_type_308, [128, 2048])
    permute_150 = torch.ops.aten.permute.default(arg129_1, [1, 0]);  arg129_1 = None
    mm_62 = torch.ops.aten.mm.default(view_436, permute_150);  view_436 = permute_150 = None
    view_437 = torch.ops.aten.reshape.default(mm_62, [1, 128, 6144]);  mm_62 = None
    permute_151 = torch.ops.aten.permute.default(view_437, [0, 2, 1]);  view_437 = None
    slice_82 = torch.ops.aten.slice.Tensor(permute_151, 2, -4, 9223372036854775807)
    copy_28 = torch.ops.aten.copy.default(arg133_1, slice_82);  slice_82 = None
    convert_element_type_317 = torch.ops.prims.convert_element_type.default(permute_151, torch.float32);  permute_151 = None
    constant_pad_nd_36 = torch.ops.aten.constant_pad_nd.default(convert_element_type_317, [3, 3], 0.0);  convert_element_type_317 = None
    slice_83 = torch.ops.aten.slice.Tensor(constant_pad_nd_36, 2, 0, 131)
    squeeze_6 = torch.ops.aten.squeeze.dim(arg134_1, 1);  arg134_1 = None
    unsqueeze_96 = torch.ops.aten.unsqueeze.default(squeeze_6, 1);  squeeze_6 = None
    convert_element_type_318 = torch.ops.prims.convert_element_type.default(unsqueeze_96, torch.float32);  unsqueeze_96 = None
    select_181 = torch.ops.aten.select.int(convert_element_type_318, 1, 0)
    select_182 = torch.ops.aten.select.int(select_181, 1, 0);  select_181 = None
    view_445 = torch.ops.aten.reshape.default(select_182, [1, -1, 1]);  select_182 = None
    mul_197 = torch.ops.aten.mul.Tensor(slice_83, view_445);  slice_83 = view_445 = None
    slice_84 = torch.ops.aten.slice.Tensor(constant_pad_nd_36, 2, 1, 132)
    select_183 = torch.ops.aten.select.int(convert_element_type_318, 1, 0)
    select_184 = torch.ops.aten.select.int(select_183, 1, 1);  select_183 = None
    view_446 = torch.ops.aten.reshape.default(select_184, [1, -1, 1]);  select_184 = None
    mul_198 = torch.ops.aten.mul.Tensor(slice_84, view_446);  slice_84 = view_446 = None
    add_154 = torch.ops.aten.add.Tensor(mul_197, mul_198);  mul_197 = mul_198 = None
    slice_85 = torch.ops.aten.slice.Tensor(constant_pad_nd_36, 2, 2, 133)
    select_185 = torch.ops.aten.select.int(convert_element_type_318, 1, 0)
    select_186 = torch.ops.aten.select.int(select_185, 1, 2);  select_185 = None
    view_447 = torch.ops.aten.reshape.default(select_186, [1, -1, 1]);  select_186 = None
    mul_199 = torch.ops.aten.mul.Tensor(slice_85, view_447);  slice_85 = view_447 = None
    add_155 = torch.ops.aten.add.Tensor(add_154, mul_199);  add_154 = mul_199 = None
    slice_86 = torch.ops.aten.slice.Tensor(constant_pad_nd_36, 2, 3, 134);  constant_pad_nd_36 = None
    select_187 = torch.ops.aten.select.int(convert_element_type_318, 1, 0);  convert_element_type_318 = None
    select_188 = torch.ops.aten.select.int(select_187, 1, 3);  select_187 = None
    view_448 = torch.ops.aten.reshape.default(select_188, [1, -1, 1]);  select_188 = None
    mul_200 = torch.ops.aten.mul.Tensor(slice_86, view_448);  slice_86 = view_448 = None
    add_156 = torch.ops.aten.add.Tensor(add_155, mul_200);  add_155 = mul_200 = None
    convert_element_type_319 = torch.ops.prims.convert_element_type.default(add_156, torch.bfloat16);  add_156 = None
    slice_87 = torch.ops.aten.slice.Tensor(convert_element_type_319, 2, 0, 128);  convert_element_type_319 = None
    convert_element_type_320 = torch.ops.prims.convert_element_type.default(slice_87, torch.float32);  slice_87 = None
    neg_30 = torch.ops.aten.neg.default(convert_element_type_320)
    exp_64 = torch.ops.aten.exp.default(neg_30);  neg_30 = None
    add_157 = torch.ops.aten.add.Tensor(exp_64, 1);  exp_64 = None
    div_22 = torch.ops.aten.div.Tensor(convert_element_type_320, add_157);  convert_element_type_320 = add_157 = None
    convert_element_type_321 = torch.ops.prims.convert_element_type.default(div_22, torch.bfloat16);  div_22 = None
    slice_88 = torch.ops.aten.slice.Tensor(convert_element_type_321, 2, -128, 9223372036854775807);  convert_element_type_321 = None
    permute_155 = torch.ops.aten.permute.default(slice_88, [0, 2, 1]);  slice_88 = None
    split_with_sizes_6 = torch.ops.aten.split_with_sizes.default(permute_155, [2048, 2048, 2048], -1);  permute_155 = None
    getitem_22 = split_with_sizes_6[0]
    getitem_23 = split_with_sizes_6[1]
    getitem_24 = split_with_sizes_6[2];  split_with_sizes_6 = None
    full_20 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_65 = torch.ops.aten.exp.default(arg135_1);  arg135_1 = None
    neg_31 = torch.ops.aten.neg.default(exp_65);  exp_65 = None
    view_443 = torch.ops.aten.reshape.default(convert_element_type_308, [128, 2048])
    permute_154 = torch.ops.aten.permute.default(arg132_1, [1, 0]);  arg132_1 = None
    mm_65 = torch.ops.aten.mm.default(view_443, permute_154);  view_443 = permute_154 = None
    view_444 = torch.ops.aten.reshape.default(mm_65, [1, 128, 16]);  mm_65 = None
    convert_element_type_322 = torch.ops.prims.convert_element_type.default(view_444, torch.float32);  view_444 = None
    add_158 = torch.ops.aten.add.Tensor(convert_element_type_322, arg136_1);  convert_element_type_322 = arg136_1 = None
    gt_6 = torch.ops.aten.gt.Scalar(add_158, 20)
    exp_66 = torch.ops.aten.exp.default(add_158)
    log1p_6 = torch.ops.aten.log1p.default(exp_66);  exp_66 = None
    where_13 = torch.ops.aten.where.self(gt_6, add_158, log1p_6);  gt_6 = add_158 = log1p_6 = None
    mul_201 = torch.ops.aten.mul.Tensor(neg_31, where_13);  neg_31 = where_13 = None
    permute_160 = torch.ops.aten.permute.default(mul_201, [0, 2, 1]);  mul_201 = None
    view_456 = torch.ops.aten.reshape.default(permute_160, [1, 16, 2, 64]);  permute_160 = None
    cumsum_6 = torch.ops.aten.cumsum.default(view_456, 3);  view_456 = None
    select_189 = torch.ops.aten.select.int(cumsum_6, 3, -1)
    exp_71 = torch.ops.aten.exp.default(select_189);  select_189 = None
    unsqueeze_106 = torch.ops.aten.unsqueeze.default(exp_71, 3);  exp_71 = None
    unsqueeze_107 = torch.ops.aten.unsqueeze.default(unsqueeze_106, 4);  unsqueeze_106 = None
    select_196 = torch.ops.aten.select.int(unsqueeze_107, 2, 0)
    mul_214 = torch.ops.aten.mul.Tensor(full_20, select_196);  select_196 = None
    view_450 = torch.ops.aten.reshape.default(getitem_23, [1, 128, 16, 128]);  getitem_23 = None
    permute_157 = torch.ops.aten.permute.default(view_450, [0, 2, 1, 3]);  view_450 = None
    convert_element_type_324 = torch.ops.prims.convert_element_type.default(permute_157, torch.float32);  permute_157 = None
    clone_55 = torch.ops.aten.clone.default(convert_element_type_324, memory_format = torch.contiguous_format);  convert_element_type_324 = None
    mul_204 = torch.ops.aten.mul.Tensor(clone_55, clone_55)
    sum_16 = torch.ops.aten.sum.dim_IntList(mul_204, [-1], True);  mul_204 = None
    add_160 = torch.ops.aten.add.Tensor(sum_16, 1e-06);  sum_16 = None
    rsqrt_40 = torch.ops.aten.rsqrt.default(add_160);  add_160 = None
    mul_205 = torch.ops.aten.mul.Tensor(clone_55, rsqrt_40);  clone_55 = rsqrt_40 = None
    view_453 = torch.ops.aten.reshape.default(mul_205, [1, 16, -1, 64, 128])
    slice_89 = torch.ops.aten.slice.Tensor(cumsum_6, 3, -1, 9223372036854775807)
    sub_34 = torch.ops.aten.sub.Tensor(slice_89, cumsum_6);  slice_89 = None
    exp_70 = torch.ops.aten.exp.default(sub_34);  sub_34 = None
    unsqueeze_105 = torch.ops.aten.unsqueeze.default(exp_70, -1);  exp_70 = None
    mul_213 = torch.ops.aten.mul.Tensor(view_453, unsqueeze_105);  unsqueeze_105 = None
    select_197 = torch.ops.aten.select.int(mul_213, 2, 0)
    permute_164 = torch.ops.aten.permute.default(select_197, [0, 1, 3, 2]);  select_197 = None
    expand_150 = torch.ops.aten.expand.default(permute_164, [1, 16, 128, 64]);  permute_164 = None
    view_472 = torch.ops.aten.reshape.default(expand_150, [16, 128, 64]);  expand_150 = None
    view_441 = torch.ops.aten.reshape.default(convert_element_type_308, [128, 2048])
    permute_153 = torch.ops.aten.permute.default(arg131_1, [1, 0]);  arg131_1 = None
    mm_64 = torch.ops.aten.mm.default(view_441, permute_153);  view_441 = permute_153 = None
    view_442 = torch.ops.aten.reshape.default(mm_64, [1, 128, 16]);  mm_64 = None
    sigmoid_8 = torch.ops.aten.sigmoid.default(view_442);  view_442 = None
    permute_159 = torch.ops.aten.permute.default(sigmoid_8, [0, 2, 1]);  sigmoid_8 = None
    convert_element_type_326 = torch.ops.prims.convert_element_type.default(permute_159, torch.float32);  permute_159 = None
    clone_57 = torch.ops.aten.clone.default(convert_element_type_326, memory_format = torch.contiguous_format);  convert_element_type_326 = None
    unsqueeze_98 = torch.ops.aten.unsqueeze.default(clone_57, -1)
    mul_208 = torch.ops.aten.mul.Tensor(mul_205, unsqueeze_98);  mul_205 = unsqueeze_98 = None
    view_454 = torch.ops.aten.reshape.default(mul_208, [1, 16, -1, 64, 128]);  mul_208 = None
    expand_140 = torch.ops.aten.expand.default(view_454, [1, 16, 2, 64, 128])
    view_457 = torch.ops.aten.reshape.default(expand_140, [32, 64, 128]);  expand_140 = None
    permute_161 = torch.ops.aten.permute.default(view_453, [0, 1, 2, 4, 3])
    expand_141 = torch.ops.aten.expand.default(permute_161, [1, 16, 2, 128, 64]);  permute_161 = None
    view_458 = torch.ops.aten.reshape.default(expand_141, [32, 128, 64]);  expand_141 = None
    bmm_64 = torch.ops.aten.bmm.default(view_457, view_458);  view_457 = view_458 = None
    view_459 = torch.ops.aten.reshape.default(bmm_64, [1, 16, 2, 64, 64]);  bmm_64 = None
    iota_15 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_99 = torch.ops.aten.unsqueeze.default(iota_15, -2);  iota_15 = None
    iota_16 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_100 = torch.ops.aten.unsqueeze.default(iota_16, -1);  iota_16 = None
    sub_32 = torch.ops.aten.sub.Tensor(unsqueeze_99, unsqueeze_100);  unsqueeze_99 = unsqueeze_100 = None
    ge_6 = torch.ops.aten.ge.Scalar(sub_32, 1);  sub_32 = None
    full_default_14 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_6 = torch.ops.aten.logical_and.default(ge_6, full_default_14);  ge_6 = full_default_14 = None
    full_default_15 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_101 = torch.ops.aten.unsqueeze.default(cumsum_6, 4)
    unsqueeze_102 = torch.ops.aten.unsqueeze.default(cumsum_6, 3)
    sub_33 = torch.ops.aten.sub.Tensor(unsqueeze_101, unsqueeze_102);  unsqueeze_101 = unsqueeze_102 = None
    where_14 = torch.ops.aten.where.self(logical_and_6, full_default_15, sub_33);  logical_and_6 = full_default_15 = sub_33 = None
    exp_67 = torch.ops.aten.exp.default(where_14);  where_14 = None
    mul_209 = torch.ops.aten.mul.Tensor(view_459, exp_67);  view_459 = None
    view_451 = torch.ops.aten.reshape.default(getitem_24, [1, 128, 16, 128]);  getitem_24 = None
    permute_158 = torch.ops.aten.permute.default(view_451, [0, 2, 1, 3]);  view_451 = None
    convert_element_type_325 = torch.ops.prims.convert_element_type.default(permute_158, torch.float32);  permute_158 = None
    clone_56 = torch.ops.aten.clone.default(convert_element_type_325, memory_format = torch.contiguous_format);  convert_element_type_325 = None
    unsqueeze_97 = torch.ops.aten.unsqueeze.default(clone_57, -1);  clone_57 = None
    mul_207 = torch.ops.aten.mul.Tensor(clone_56, unsqueeze_97);  clone_56 = unsqueeze_97 = None
    view_455 = torch.ops.aten.reshape.default(mul_207, [1, 16, -1, 64, 128]);  mul_207 = None
    linalg_solve_triangular_12 = torch.ops.aten.linalg_solve_triangular.default(mul_209, view_455, upper = False, unitriangular = True);  view_455 = None
    select_190 = torch.ops.aten.select.int(linalg_solve_triangular_12, 2, 0)
    exp_68 = torch.ops.aten.exp.default(cumsum_6)
    unsqueeze_103 = torch.ops.aten.unsqueeze.default(exp_68, -1);  exp_68 = None
    mul_211 = torch.ops.aten.mul.Tensor(view_454, unsqueeze_103);  view_454 = unsqueeze_103 = None
    linalg_solve_triangular_13 = torch.ops.aten.linalg_solve_triangular.default(mul_209, mul_211, upper = False, unitriangular = True);  mul_209 = mul_211 = None
    select_191 = torch.ops.aten.select.int(linalg_solve_triangular_13, 2, 0)
    expand_144 = torch.ops.aten.expand.default(select_191, [1, 16, 64, 128]);  select_191 = None
    view_463 = torch.ops.aten.reshape.default(expand_144, [16, 64, 128]);  expand_144 = None
    expand_145 = torch.ops.aten.expand.default(full_20, [1, 16, 128, 128])
    view_464 = torch.ops.aten.reshape.default(expand_145, [16, 128, 128]);  expand_145 = None
    bmm_66 = torch.ops.aten.bmm.default(view_463, view_464);  view_463 = view_464 = None
    view_465 = torch.ops.aten.reshape.default(bmm_66, [1, 16, 64, 128]);  bmm_66 = None
    sub_35 = torch.ops.aten.sub.Tensor(select_190, view_465);  select_190 = view_465 = None
    expand_151 = torch.ops.aten.expand.default(sub_35, [1, 16, 64, 128])
    view_473 = torch.ops.aten.reshape.default(expand_151, [16, 64, 128]);  expand_151 = None
    bmm_69 = torch.ops.aten.bmm.default(view_472, view_473);  view_472 = view_473 = None
    view_474 = torch.ops.aten.reshape.default(bmm_69, [1, 16, 128, 128]);  bmm_69 = None
    add_162 = torch.ops.aten.add.Tensor(mul_214, view_474);  mul_214 = view_474 = None
    select_205 = torch.ops.aten.select.int(unsqueeze_107, 2, 1);  unsqueeze_107 = None
    mul_215 = torch.ops.aten.mul.Tensor(add_162, select_205);  select_205 = None
    select_206 = torch.ops.aten.select.int(mul_213, 2, 1);  mul_213 = None
    permute_165 = torch.ops.aten.permute.default(select_206, [0, 1, 3, 2]);  select_206 = None
    expand_158 = torch.ops.aten.expand.default(permute_165, [1, 16, 128, 64]);  permute_165 = None
    view_484 = torch.ops.aten.reshape.default(expand_158, [16, 128, 64]);  expand_158 = None
    select_198 = torch.ops.aten.select.int(linalg_solve_triangular_12, 2, 1);  linalg_solve_triangular_12 = None
    select_199 = torch.ops.aten.select.int(linalg_solve_triangular_13, 2, 1);  linalg_solve_triangular_13 = None
    expand_152 = torch.ops.aten.expand.default(select_199, [1, 16, 64, 128]);  select_199 = None
    view_475 = torch.ops.aten.reshape.default(expand_152, [16, 64, 128]);  expand_152 = None
    expand_153 = torch.ops.aten.expand.default(add_162, [1, 16, 128, 128])
    view_476 = torch.ops.aten.reshape.default(expand_153, [16, 128, 128]);  expand_153 = None
    bmm_70 = torch.ops.aten.bmm.default(view_475, view_476);  view_475 = view_476 = None
    view_477 = torch.ops.aten.reshape.default(bmm_70, [1, 16, 64, 128]);  bmm_70 = None
    sub_36 = torch.ops.aten.sub.Tensor(select_198, view_477);  select_198 = view_477 = None
    expand_159 = torch.ops.aten.expand.default(sub_36, [1, 16, 64, 128])
    view_485 = torch.ops.aten.reshape.default(expand_159, [16, 64, 128]);  expand_159 = None
    bmm_73 = torch.ops.aten.bmm.default(view_484, view_485);  view_484 = view_485 = None
    view_486 = torch.ops.aten.reshape.default(bmm_73, [1, 16, 128, 128]);  bmm_73 = None
    add_164 = torch.ops.aten.add.Tensor(mul_215, view_486);  mul_215 = view_486 = None
    full_21 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_163 = torch.ops.aten.permute.default(full_21, [0, 1, 2, 4, 3]);  full_21 = None
    select_194 = torch.ops.aten.select.int(permute_163, 2, 0)
    view_449 = torch.ops.aten.reshape.default(getitem_22, [1, 128, 16, 128]);  getitem_22 = None
    permute_156 = torch.ops.aten.permute.default(view_449, [0, 2, 1, 3]);  view_449 = None
    convert_element_type_323 = torch.ops.prims.convert_element_type.default(permute_156, torch.float32);  permute_156 = None
    clone_54 = torch.ops.aten.clone.default(convert_element_type_323, memory_format = torch.contiguous_format);  convert_element_type_323 = None
    mul_202 = torch.ops.aten.mul.Tensor(clone_54, clone_54)
    sum_15 = torch.ops.aten.sum.dim_IntList(mul_202, [-1], True);  mul_202 = None
    add_159 = torch.ops.aten.add.Tensor(sum_15, 1e-06);  sum_15 = None
    rsqrt_39 = torch.ops.aten.rsqrt.default(add_159);  add_159 = None
    mul_203 = torch.ops.aten.mul.Tensor(clone_54, rsqrt_39);  clone_54 = rsqrt_39 = None
    mul_206 = torch.ops.aten.mul.Tensor(mul_203, 0.08838834764831845);  mul_203 = None
    view_452 = torch.ops.aten.reshape.default(mul_206, [1, 16, -1, 64, 128]);  mul_206 = None
    exp_69 = torch.ops.aten.exp.default(cumsum_6);  cumsum_6 = None
    unsqueeze_104 = torch.ops.aten.unsqueeze.default(exp_69, -1);  exp_69 = None
    mul_212 = torch.ops.aten.mul.Tensor(view_452, unsqueeze_104);  unsqueeze_104 = None
    select_192 = torch.ops.aten.select.int(mul_212, 2, 0)
    expand_146 = torch.ops.aten.expand.default(select_192, [1, 16, 64, 128]);  select_192 = None
    view_466 = torch.ops.aten.reshape.default(expand_146, [16, 64, 128]);  expand_146 = None
    expand_147 = torch.ops.aten.expand.default(full_20, [1, 16, 128, 128]);  full_20 = None
    view_467 = torch.ops.aten.reshape.default(expand_147, [16, 128, 128]);  expand_147 = None
    bmm_67 = torch.ops.aten.bmm.default(view_466, view_467);  view_466 = view_467 = None
    view_468 = torch.ops.aten.reshape.default(bmm_67, [1, 16, 64, 128]);  bmm_67 = None
    expand_142 = torch.ops.aten.expand.default(view_452, [1, 16, 2, 64, 128]);  view_452 = None
    view_460 = torch.ops.aten.reshape.default(expand_142, [32, 64, 128]);  expand_142 = None
    permute_162 = torch.ops.aten.permute.default(view_453, [0, 1, 2, 4, 3]);  view_453 = None
    expand_143 = torch.ops.aten.expand.default(permute_162, [1, 16, 2, 128, 64]);  permute_162 = None
    view_461 = torch.ops.aten.reshape.default(expand_143, [32, 128, 64]);  expand_143 = None
    bmm_65 = torch.ops.aten.bmm.default(view_460, view_461);  view_460 = view_461 = None
    view_462 = torch.ops.aten.reshape.default(bmm_65, [1, 16, 2, 64, 64]);  bmm_65 = None
    mul_210 = torch.ops.aten.mul.Tensor(view_462, exp_67);  view_462 = exp_67 = None
    select_193 = torch.ops.aten.select.int(mul_210, 2, 0)
    expand_148 = torch.ops.aten.expand.default(select_193, [1, 16, 64, 64]);  select_193 = None
    view_469 = torch.ops.aten.reshape.default(expand_148, [16, 64, 64]);  expand_148 = None
    expand_149 = torch.ops.aten.expand.default(sub_35, [1, 16, 64, 128]);  sub_35 = None
    view_470 = torch.ops.aten.reshape.default(expand_149, [16, 64, 128]);  expand_149 = None
    bmm_68 = torch.ops.aten.bmm.default(view_469, view_470);  view_469 = view_470 = None
    view_471 = torch.ops.aten.reshape.default(bmm_68, [1, 16, 64, 128]);  bmm_68 = None
    add_161 = torch.ops.aten.add.Tensor(view_468, view_471);  view_468 = view_471 = None
    copy_29 = torch.ops.aten.copy.default(select_194, add_161);  select_194 = add_161 = None
    select_scatter_default_16 = torch.ops.aten.select_scatter.default(permute_163, copy_29, 2, 0);  permute_163 = copy_29 = None
    select_203 = torch.ops.aten.select.int(select_scatter_default_16, 2, 1)
    select_200 = torch.ops.aten.select.int(mul_212, 2, 1);  mul_212 = None
    expand_154 = torch.ops.aten.expand.default(select_200, [1, 16, 64, 128]);  select_200 = None
    view_478 = torch.ops.aten.reshape.default(expand_154, [16, 64, 128]);  expand_154 = None
    expand_155 = torch.ops.aten.expand.default(add_162, [1, 16, 128, 128]);  add_162 = None
    view_479 = torch.ops.aten.reshape.default(expand_155, [16, 128, 128]);  expand_155 = None
    bmm_71 = torch.ops.aten.bmm.default(view_478, view_479);  view_478 = view_479 = None
    view_480 = torch.ops.aten.reshape.default(bmm_71, [1, 16, 64, 128]);  bmm_71 = None
    select_201 = torch.ops.aten.select.int(mul_210, 2, 1);  mul_210 = None
    expand_156 = torch.ops.aten.expand.default(select_201, [1, 16, 64, 64]);  select_201 = None
    view_481 = torch.ops.aten.reshape.default(expand_156, [16, 64, 64]);  expand_156 = None
    expand_157 = torch.ops.aten.expand.default(sub_36, [1, 16, 64, 128]);  sub_36 = None
    view_482 = torch.ops.aten.reshape.default(expand_157, [16, 64, 128]);  expand_157 = None
    bmm_72 = torch.ops.aten.bmm.default(view_481, view_482);  view_481 = view_482 = None
    view_483 = torch.ops.aten.reshape.default(bmm_72, [1, 16, 64, 128]);  bmm_72 = None
    add_163 = torch.ops.aten.add.Tensor(view_480, view_483);  view_480 = view_483 = None
    copy_30 = torch.ops.aten.copy.default(select_203, add_163);  select_203 = add_163 = None
    select_scatter_default_17 = torch.ops.aten.select_scatter.default(select_scatter_default_16, copy_30, 2, 1);  select_scatter_default_16 = copy_30 = None
    clone_59 = torch.ops.aten.clone.default(select_scatter_default_17, memory_format = torch.contiguous_format);  select_scatter_default_17 = None
    view_487 = torch.ops.aten.reshape.default(clone_59, [1, 16, 128, 128]);  clone_59 = None
    permute_166 = torch.ops.aten.permute.default(view_487, [0, 2, 1, 3]);  view_487 = None
    convert_element_type_327 = torch.ops.prims.convert_element_type.default(permute_166, torch.bfloat16);  permute_166 = None
    clone_60 = torch.ops.aten.clone.default(convert_element_type_327, memory_format = torch.contiguous_format);  convert_element_type_327 = None
    view_488 = torch.ops.aten.reshape.default(clone_60, [-1, 128]);  clone_60 = None
    convert_element_type_328 = torch.ops.prims.convert_element_type.default(view_488, torch.float32);  view_488 = None
    pow_28 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_328, 2)
    mean_27 = torch.ops.aten.mean.dim(pow_28, [-1], True);  pow_28 = None
    add_165 = torch.ops.aten.add.Tensor(mean_27, 1e-06);  mean_27 = None
    rsqrt_41 = torch.ops.aten.rsqrt.default(add_165);  add_165 = None
    mul_216 = torch.ops.aten.mul.Tensor(convert_element_type_328, rsqrt_41);  convert_element_type_328 = rsqrt_41 = None
    convert_element_type_329 = torch.ops.prims.convert_element_type.default(mul_216, torch.bfloat16);  mul_216 = None
    mul_217 = torch.ops.aten.mul.Tensor(arg138_1, convert_element_type_329);  arg138_1 = convert_element_type_329 = None
    view_438 = torch.ops.aten.reshape.default(convert_element_type_308, [128, 2048]);  convert_element_type_308 = None
    permute_152 = torch.ops.aten.permute.default(arg130_1, [1, 0]);  arg130_1 = None
    mm_63 = torch.ops.aten.mm.default(view_438, permute_152);  view_438 = permute_152 = None
    view_439 = torch.ops.aten.reshape.default(mm_63, [1, 128, 2048]);  mm_63 = None
    view_440 = torch.ops.aten.reshape.default(view_439, [1, 128, -1, 128]);  view_439 = None
    view_489 = torch.ops.aten.reshape.default(view_440, [-1, 128]);  view_440 = None
    convert_element_type_330 = torch.ops.prims.convert_element_type.default(view_489, torch.float32);  view_489 = None
    neg_32 = torch.ops.aten.neg.default(convert_element_type_330)
    exp_72 = torch.ops.aten.exp.default(neg_32);  neg_32 = None
    add_166 = torch.ops.aten.add.Tensor(exp_72, 1);  exp_72 = None
    div_23 = torch.ops.aten.div.Tensor(convert_element_type_330, add_166);  convert_element_type_330 = add_166 = None
    mul_218 = torch.ops.aten.mul.Tensor(mul_217, div_23);  mul_217 = div_23 = None
    convert_element_type_331 = torch.ops.prims.convert_element_type.default(mul_218, torch.bfloat16);  mul_218 = None
    view_490 = torch.ops.aten.reshape.default(convert_element_type_331, [1, 128, -1]);  convert_element_type_331 = None
    view_491 = torch.ops.aten.reshape.default(view_490, [128, 2048]);  view_490 = None
    permute_167 = torch.ops.aten.permute.default(arg139_1, [1, 0]);  arg139_1 = None
    mm_66 = torch.ops.aten.mm.default(view_491, permute_167);  view_491 = permute_167 = None
    view_492 = torch.ops.aten.reshape.default(mm_66, [1, 128, 2048]);  mm_66 = None
    add_167 = torch.ops.aten.add.Tensor(add_151, view_492);  add_151 = view_492 = None
    convert_element_type_334 = torch.ops.prims.convert_element_type.default(add_167, torch.float32)
    pow_29 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_334, 2)
    mean_28 = torch.ops.aten.mean.dim(pow_29, [-1], True);  pow_29 = None
    add_168 = torch.ops.aten.add.Tensor(mean_28, 1e-06);  mean_28 = None
    rsqrt_42 = torch.ops.aten.rsqrt.default(add_168);  add_168 = None
    mul_219 = torch.ops.aten.mul.Tensor(convert_element_type_334, rsqrt_42);  convert_element_type_334 = rsqrt_42 = None
    convert_element_type_335 = torch.ops.prims.convert_element_type.default(arg140_1, torch.float32);  arg140_1 = None
    add_169 = torch.ops.aten.add.Tensor(convert_element_type_335, 1.0);  convert_element_type_335 = None
    mul_220 = torch.ops.aten.mul.Tensor(mul_219, add_169);  mul_219 = add_169 = None
    convert_element_type_336 = torch.ops.prims.convert_element_type.default(mul_220, torch.bfloat16);  mul_220 = None
    view_493 = torch.ops.aten.reshape.default(convert_element_type_336, [128, 2048])
    permute_168 = torch.ops.aten.permute.default(arg141_1, [1, 0]);  arg141_1 = None
    mm_67 = torch.ops.aten.mm.default(view_493, permute_168);  view_493 = permute_168 = None
    view_494 = torch.ops.aten.reshape.default(mm_67, [1, 128, 6144]);  mm_67 = None
    convert_element_type_339 = torch.ops.prims.convert_element_type.default(view_494, torch.float32);  view_494 = None
    neg_33 = torch.ops.aten.neg.default(convert_element_type_339)
    exp_73 = torch.ops.aten.exp.default(neg_33);  neg_33 = None
    add_170 = torch.ops.aten.add.Tensor(exp_73, 1);  exp_73 = None
    div_24 = torch.ops.aten.div.Tensor(convert_element_type_339, add_170);  convert_element_type_339 = add_170 = None
    convert_element_type_340 = torch.ops.prims.convert_element_type.default(div_24, torch.bfloat16);  div_24 = None
    view_495 = torch.ops.aten.reshape.default(convert_element_type_336, [128, 2048]);  convert_element_type_336 = None
    permute_169 = torch.ops.aten.permute.default(arg142_1, [1, 0]);  arg142_1 = None
    mm_68 = torch.ops.aten.mm.default(view_495, permute_169);  view_495 = permute_169 = None
    view_496 = torch.ops.aten.reshape.default(mm_68, [1, 128, 6144]);  mm_68 = None
    mul_221 = torch.ops.aten.mul.Tensor(convert_element_type_340, view_496);  convert_element_type_340 = view_496 = None
    view_497 = torch.ops.aten.reshape.default(mul_221, [128, 6144]);  mul_221 = None
    permute_170 = torch.ops.aten.permute.default(arg143_1, [1, 0]);  arg143_1 = None
    mm_69 = torch.ops.aten.mm.default(view_497, permute_170);  view_497 = permute_170 = None
    view_498 = torch.ops.aten.reshape.default(mm_69, [1, 128, 2048]);  mm_69 = None
    add_171 = torch.ops.aten.add.Tensor(add_167, view_498);  add_167 = view_498 = None
    convert_element_type_345 = torch.ops.prims.convert_element_type.default(add_171, torch.float32)
    pow_30 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_345, 2)
    mean_29 = torch.ops.aten.mean.dim(pow_30, [-1], True);  pow_30 = None
    add_172 = torch.ops.aten.add.Tensor(mean_29, 1e-06);  mean_29 = None
    rsqrt_43 = torch.ops.aten.rsqrt.default(add_172);  add_172 = None
    mul_222 = torch.ops.aten.mul.Tensor(convert_element_type_345, rsqrt_43);  convert_element_type_345 = rsqrt_43 = None
    convert_element_type_346 = torch.ops.prims.convert_element_type.default(arg144_1, torch.float32);  arg144_1 = None
    add_173 = torch.ops.aten.add.Tensor(convert_element_type_346, 1.0);  convert_element_type_346 = None
    mul_223 = torch.ops.aten.mul.Tensor(mul_222, add_173);  mul_222 = add_173 = None
    convert_element_type_347 = torch.ops.prims.convert_element_type.default(mul_223, torch.bfloat16);  mul_223 = None
    view_499 = torch.ops.aten.reshape.default(convert_element_type_347, [128, 2048])
    permute_171 = torch.ops.aten.permute.default(arg145_1, [1, 0]);  arg145_1 = None
    mm_70 = torch.ops.aten.mm.default(view_499, permute_171);  view_499 = permute_171 = None
    view_500 = torch.ops.aten.reshape.default(mm_70, [1, 128, 6144]);  mm_70 = None
    permute_172 = torch.ops.aten.permute.default(view_500, [0, 2, 1]);  view_500 = None
    slice_90 = torch.ops.aten.slice.Tensor(permute_172, 2, -4, 9223372036854775807)
    copy_32 = torch.ops.aten.copy.default(arg149_1, slice_90);  slice_90 = None
    convert_element_type_356 = torch.ops.prims.convert_element_type.default(permute_172, torch.float32);  permute_172 = None
    constant_pad_nd_42 = torch.ops.aten.constant_pad_nd.default(convert_element_type_356, [3, 3], 0.0);  convert_element_type_356 = None
    slice_91 = torch.ops.aten.slice.Tensor(constant_pad_nd_42, 2, 0, 131)
    squeeze_7 = torch.ops.aten.squeeze.dim(arg150_1, 1);  arg150_1 = None
    unsqueeze_108 = torch.ops.aten.unsqueeze.default(squeeze_7, 1);  squeeze_7 = None
    convert_element_type_357 = torch.ops.prims.convert_element_type.default(unsqueeze_108, torch.float32);  unsqueeze_108 = None
    select_207 = torch.ops.aten.select.int(convert_element_type_357, 1, 0)
    select_208 = torch.ops.aten.select.int(select_207, 1, 0);  select_207 = None
    view_508 = torch.ops.aten.reshape.default(select_208, [1, -1, 1]);  select_208 = None
    mul_224 = torch.ops.aten.mul.Tensor(slice_91, view_508);  slice_91 = view_508 = None
    slice_92 = torch.ops.aten.slice.Tensor(constant_pad_nd_42, 2, 1, 132)
    select_209 = torch.ops.aten.select.int(convert_element_type_357, 1, 0)
    select_210 = torch.ops.aten.select.int(select_209, 1, 1);  select_209 = None
    view_509 = torch.ops.aten.reshape.default(select_210, [1, -1, 1]);  select_210 = None
    mul_225 = torch.ops.aten.mul.Tensor(slice_92, view_509);  slice_92 = view_509 = None
    add_174 = torch.ops.aten.add.Tensor(mul_224, mul_225);  mul_224 = mul_225 = None
    slice_93 = torch.ops.aten.slice.Tensor(constant_pad_nd_42, 2, 2, 133)
    select_211 = torch.ops.aten.select.int(convert_element_type_357, 1, 0)
    select_212 = torch.ops.aten.select.int(select_211, 1, 2);  select_211 = None
    view_510 = torch.ops.aten.reshape.default(select_212, [1, -1, 1]);  select_212 = None
    mul_226 = torch.ops.aten.mul.Tensor(slice_93, view_510);  slice_93 = view_510 = None
    add_175 = torch.ops.aten.add.Tensor(add_174, mul_226);  add_174 = mul_226 = None
    slice_94 = torch.ops.aten.slice.Tensor(constant_pad_nd_42, 2, 3, 134);  constant_pad_nd_42 = None
    select_213 = torch.ops.aten.select.int(convert_element_type_357, 1, 0);  convert_element_type_357 = None
    select_214 = torch.ops.aten.select.int(select_213, 1, 3);  select_213 = None
    view_511 = torch.ops.aten.reshape.default(select_214, [1, -1, 1]);  select_214 = None
    mul_227 = torch.ops.aten.mul.Tensor(slice_94, view_511);  slice_94 = view_511 = None
    add_176 = torch.ops.aten.add.Tensor(add_175, mul_227);  add_175 = mul_227 = None
    convert_element_type_358 = torch.ops.prims.convert_element_type.default(add_176, torch.bfloat16);  add_176 = None
    slice_95 = torch.ops.aten.slice.Tensor(convert_element_type_358, 2, 0, 128);  convert_element_type_358 = None
    convert_element_type_359 = torch.ops.prims.convert_element_type.default(slice_95, torch.float32);  slice_95 = None
    neg_34 = torch.ops.aten.neg.default(convert_element_type_359)
    exp_74 = torch.ops.aten.exp.default(neg_34);  neg_34 = None
    add_177 = torch.ops.aten.add.Tensor(exp_74, 1);  exp_74 = None
    div_25 = torch.ops.aten.div.Tensor(convert_element_type_359, add_177);  convert_element_type_359 = add_177 = None
    convert_element_type_360 = torch.ops.prims.convert_element_type.default(div_25, torch.bfloat16);  div_25 = None
    slice_96 = torch.ops.aten.slice.Tensor(convert_element_type_360, 2, -128, 9223372036854775807);  convert_element_type_360 = None
    permute_176 = torch.ops.aten.permute.default(slice_96, [0, 2, 1]);  slice_96 = None
    split_with_sizes_7 = torch.ops.aten.split_with_sizes.default(permute_176, [2048, 2048, 2048], -1);  permute_176 = None
    getitem_25 = split_with_sizes_7[0]
    getitem_26 = split_with_sizes_7[1]
    getitem_27 = split_with_sizes_7[2];  split_with_sizes_7 = None
    full_23 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_75 = torch.ops.aten.exp.default(arg151_1);  arg151_1 = None
    neg_35 = torch.ops.aten.neg.default(exp_75);  exp_75 = None
    view_506 = torch.ops.aten.reshape.default(convert_element_type_347, [128, 2048])
    permute_175 = torch.ops.aten.permute.default(arg148_1, [1, 0]);  arg148_1 = None
    mm_73 = torch.ops.aten.mm.default(view_506, permute_175);  view_506 = permute_175 = None
    view_507 = torch.ops.aten.reshape.default(mm_73, [1, 128, 16]);  mm_73 = None
    convert_element_type_361 = torch.ops.prims.convert_element_type.default(view_507, torch.float32);  view_507 = None
    add_178 = torch.ops.aten.add.Tensor(convert_element_type_361, arg152_1);  convert_element_type_361 = arg152_1 = None
    gt_7 = torch.ops.aten.gt.Scalar(add_178, 20)
    exp_76 = torch.ops.aten.exp.default(add_178)
    log1p_7 = torch.ops.aten.log1p.default(exp_76);  exp_76 = None
    where_15 = torch.ops.aten.where.self(gt_7, add_178, log1p_7);  gt_7 = add_178 = log1p_7 = None
    mul_228 = torch.ops.aten.mul.Tensor(neg_35, where_15);  neg_35 = where_15 = None
    permute_181 = torch.ops.aten.permute.default(mul_228, [0, 2, 1]);  mul_228 = None
    view_519 = torch.ops.aten.reshape.default(permute_181, [1, 16, 2, 64]);  permute_181 = None
    cumsum_7 = torch.ops.aten.cumsum.default(view_519, 3);  view_519 = None
    select_215 = torch.ops.aten.select.int(cumsum_7, 3, -1)
    exp_81 = torch.ops.aten.exp.default(select_215);  select_215 = None
    unsqueeze_118 = torch.ops.aten.unsqueeze.default(exp_81, 3);  exp_81 = None
    unsqueeze_119 = torch.ops.aten.unsqueeze.default(unsqueeze_118, 4);  unsqueeze_118 = None
    select_222 = torch.ops.aten.select.int(unsqueeze_119, 2, 0)
    mul_241 = torch.ops.aten.mul.Tensor(full_23, select_222);  select_222 = None
    view_513 = torch.ops.aten.reshape.default(getitem_26, [1, 128, 16, 128]);  getitem_26 = None
    permute_178 = torch.ops.aten.permute.default(view_513, [0, 2, 1, 3]);  view_513 = None
    convert_element_type_363 = torch.ops.prims.convert_element_type.default(permute_178, torch.float32);  permute_178 = None
    clone_62 = torch.ops.aten.clone.default(convert_element_type_363, memory_format = torch.contiguous_format);  convert_element_type_363 = None
    mul_231 = torch.ops.aten.mul.Tensor(clone_62, clone_62)
    sum_18 = torch.ops.aten.sum.dim_IntList(mul_231, [-1], True);  mul_231 = None
    add_180 = torch.ops.aten.add.Tensor(sum_18, 1e-06);  sum_18 = None
    rsqrt_45 = torch.ops.aten.rsqrt.default(add_180);  add_180 = None
    mul_232 = torch.ops.aten.mul.Tensor(clone_62, rsqrt_45);  clone_62 = rsqrt_45 = None
    view_516 = torch.ops.aten.reshape.default(mul_232, [1, 16, -1, 64, 128])
    slice_97 = torch.ops.aten.slice.Tensor(cumsum_7, 3, -1, 9223372036854775807)
    sub_39 = torch.ops.aten.sub.Tensor(slice_97, cumsum_7);  slice_97 = None
    exp_80 = torch.ops.aten.exp.default(sub_39);  sub_39 = None
    unsqueeze_117 = torch.ops.aten.unsqueeze.default(exp_80, -1);  exp_80 = None
    mul_240 = torch.ops.aten.mul.Tensor(view_516, unsqueeze_117);  unsqueeze_117 = None
    select_223 = torch.ops.aten.select.int(mul_240, 2, 0)
    permute_185 = torch.ops.aten.permute.default(select_223, [0, 1, 3, 2]);  select_223 = None
    expand_170 = torch.ops.aten.expand.default(permute_185, [1, 16, 128, 64]);  permute_185 = None
    view_535 = torch.ops.aten.reshape.default(expand_170, [16, 128, 64]);  expand_170 = None
    view_504 = torch.ops.aten.reshape.default(convert_element_type_347, [128, 2048])
    permute_174 = torch.ops.aten.permute.default(arg147_1, [1, 0]);  arg147_1 = None
    mm_72 = torch.ops.aten.mm.default(view_504, permute_174);  view_504 = permute_174 = None
    view_505 = torch.ops.aten.reshape.default(mm_72, [1, 128, 16]);  mm_72 = None
    sigmoid_9 = torch.ops.aten.sigmoid.default(view_505);  view_505 = None
    permute_180 = torch.ops.aten.permute.default(sigmoid_9, [0, 2, 1]);  sigmoid_9 = None
    convert_element_type_365 = torch.ops.prims.convert_element_type.default(permute_180, torch.float32);  permute_180 = None
    clone_64 = torch.ops.aten.clone.default(convert_element_type_365, memory_format = torch.contiguous_format);  convert_element_type_365 = None
    unsqueeze_110 = torch.ops.aten.unsqueeze.default(clone_64, -1)
    mul_235 = torch.ops.aten.mul.Tensor(mul_232, unsqueeze_110);  mul_232 = unsqueeze_110 = None
    view_517 = torch.ops.aten.reshape.default(mul_235, [1, 16, -1, 64, 128]);  mul_235 = None
    expand_160 = torch.ops.aten.expand.default(view_517, [1, 16, 2, 64, 128])
    view_520 = torch.ops.aten.reshape.default(expand_160, [32, 64, 128]);  expand_160 = None
    permute_182 = torch.ops.aten.permute.default(view_516, [0, 1, 2, 4, 3])
    expand_161 = torch.ops.aten.expand.default(permute_182, [1, 16, 2, 128, 64]);  permute_182 = None
    view_521 = torch.ops.aten.reshape.default(expand_161, [32, 128, 64]);  expand_161 = None
    bmm_74 = torch.ops.aten.bmm.default(view_520, view_521);  view_520 = view_521 = None
    view_522 = torch.ops.aten.reshape.default(bmm_74, [1, 16, 2, 64, 64]);  bmm_74 = None
    iota_17 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_111 = torch.ops.aten.unsqueeze.default(iota_17, -2);  iota_17 = None
    iota_18 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_112 = torch.ops.aten.unsqueeze.default(iota_18, -1);  iota_18 = None
    sub_37 = torch.ops.aten.sub.Tensor(unsqueeze_111, unsqueeze_112);  unsqueeze_111 = unsqueeze_112 = None
    ge_7 = torch.ops.aten.ge.Scalar(sub_37, 1);  sub_37 = None
    full_default_16 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_7 = torch.ops.aten.logical_and.default(ge_7, full_default_16);  ge_7 = full_default_16 = None
    full_default_17 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_113 = torch.ops.aten.unsqueeze.default(cumsum_7, 4)
    unsqueeze_114 = torch.ops.aten.unsqueeze.default(cumsum_7, 3)
    sub_38 = torch.ops.aten.sub.Tensor(unsqueeze_113, unsqueeze_114);  unsqueeze_113 = unsqueeze_114 = None
    where_16 = torch.ops.aten.where.self(logical_and_7, full_default_17, sub_38);  logical_and_7 = full_default_17 = sub_38 = None
    exp_77 = torch.ops.aten.exp.default(where_16);  where_16 = None
    mul_236 = torch.ops.aten.mul.Tensor(view_522, exp_77);  view_522 = None
    view_514 = torch.ops.aten.reshape.default(getitem_27, [1, 128, 16, 128]);  getitem_27 = None
    permute_179 = torch.ops.aten.permute.default(view_514, [0, 2, 1, 3]);  view_514 = None
    convert_element_type_364 = torch.ops.prims.convert_element_type.default(permute_179, torch.float32);  permute_179 = None
    clone_63 = torch.ops.aten.clone.default(convert_element_type_364, memory_format = torch.contiguous_format);  convert_element_type_364 = None
    unsqueeze_109 = torch.ops.aten.unsqueeze.default(clone_64, -1);  clone_64 = None
    mul_234 = torch.ops.aten.mul.Tensor(clone_63, unsqueeze_109);  clone_63 = unsqueeze_109 = None
    view_518 = torch.ops.aten.reshape.default(mul_234, [1, 16, -1, 64, 128]);  mul_234 = None
    linalg_solve_triangular_14 = torch.ops.aten.linalg_solve_triangular.default(mul_236, view_518, upper = False, unitriangular = True);  view_518 = None
    select_216 = torch.ops.aten.select.int(linalg_solve_triangular_14, 2, 0)
    exp_78 = torch.ops.aten.exp.default(cumsum_7)
    unsqueeze_115 = torch.ops.aten.unsqueeze.default(exp_78, -1);  exp_78 = None
    mul_238 = torch.ops.aten.mul.Tensor(view_517, unsqueeze_115);  view_517 = unsqueeze_115 = None
    linalg_solve_triangular_15 = torch.ops.aten.linalg_solve_triangular.default(mul_236, mul_238, upper = False, unitriangular = True);  mul_236 = mul_238 = None
    select_217 = torch.ops.aten.select.int(linalg_solve_triangular_15, 2, 0)
    expand_164 = torch.ops.aten.expand.default(select_217, [1, 16, 64, 128]);  select_217 = None
    view_526 = torch.ops.aten.reshape.default(expand_164, [16, 64, 128]);  expand_164 = None
    expand_165 = torch.ops.aten.expand.default(full_23, [1, 16, 128, 128])
    view_527 = torch.ops.aten.reshape.default(expand_165, [16, 128, 128]);  expand_165 = None
    bmm_76 = torch.ops.aten.bmm.default(view_526, view_527);  view_526 = view_527 = None
    view_528 = torch.ops.aten.reshape.default(bmm_76, [1, 16, 64, 128]);  bmm_76 = None
    sub_40 = torch.ops.aten.sub.Tensor(select_216, view_528);  select_216 = view_528 = None
    expand_171 = torch.ops.aten.expand.default(sub_40, [1, 16, 64, 128])
    view_536 = torch.ops.aten.reshape.default(expand_171, [16, 64, 128]);  expand_171 = None
    bmm_79 = torch.ops.aten.bmm.default(view_535, view_536);  view_535 = view_536 = None
    view_537 = torch.ops.aten.reshape.default(bmm_79, [1, 16, 128, 128]);  bmm_79 = None
    add_182 = torch.ops.aten.add.Tensor(mul_241, view_537);  mul_241 = view_537 = None
    select_231 = torch.ops.aten.select.int(unsqueeze_119, 2, 1);  unsqueeze_119 = None
    mul_242 = torch.ops.aten.mul.Tensor(add_182, select_231);  select_231 = None
    select_232 = torch.ops.aten.select.int(mul_240, 2, 1);  mul_240 = None
    permute_186 = torch.ops.aten.permute.default(select_232, [0, 1, 3, 2]);  select_232 = None
    expand_178 = torch.ops.aten.expand.default(permute_186, [1, 16, 128, 64]);  permute_186 = None
    view_547 = torch.ops.aten.reshape.default(expand_178, [16, 128, 64]);  expand_178 = None
    select_224 = torch.ops.aten.select.int(linalg_solve_triangular_14, 2, 1);  linalg_solve_triangular_14 = None
    select_225 = torch.ops.aten.select.int(linalg_solve_triangular_15, 2, 1);  linalg_solve_triangular_15 = None
    expand_172 = torch.ops.aten.expand.default(select_225, [1, 16, 64, 128]);  select_225 = None
    view_538 = torch.ops.aten.reshape.default(expand_172, [16, 64, 128]);  expand_172 = None
    expand_173 = torch.ops.aten.expand.default(add_182, [1, 16, 128, 128])
    view_539 = torch.ops.aten.reshape.default(expand_173, [16, 128, 128]);  expand_173 = None
    bmm_80 = torch.ops.aten.bmm.default(view_538, view_539);  view_538 = view_539 = None
    view_540 = torch.ops.aten.reshape.default(bmm_80, [1, 16, 64, 128]);  bmm_80 = None
    sub_41 = torch.ops.aten.sub.Tensor(select_224, view_540);  select_224 = view_540 = None
    expand_179 = torch.ops.aten.expand.default(sub_41, [1, 16, 64, 128])
    view_548 = torch.ops.aten.reshape.default(expand_179, [16, 64, 128]);  expand_179 = None
    bmm_83 = torch.ops.aten.bmm.default(view_547, view_548);  view_547 = view_548 = None
    view_549 = torch.ops.aten.reshape.default(bmm_83, [1, 16, 128, 128]);  bmm_83 = None
    add_184 = torch.ops.aten.add.Tensor(mul_242, view_549);  mul_242 = view_549 = None
    full_24 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_184 = torch.ops.aten.permute.default(full_24, [0, 1, 2, 4, 3]);  full_24 = None
    select_220 = torch.ops.aten.select.int(permute_184, 2, 0)
    view_512 = torch.ops.aten.reshape.default(getitem_25, [1, 128, 16, 128]);  getitem_25 = None
    permute_177 = torch.ops.aten.permute.default(view_512, [0, 2, 1, 3]);  view_512 = None
    convert_element_type_362 = torch.ops.prims.convert_element_type.default(permute_177, torch.float32);  permute_177 = None
    clone_61 = torch.ops.aten.clone.default(convert_element_type_362, memory_format = torch.contiguous_format);  convert_element_type_362 = None
    mul_229 = torch.ops.aten.mul.Tensor(clone_61, clone_61)
    sum_17 = torch.ops.aten.sum.dim_IntList(mul_229, [-1], True);  mul_229 = None
    add_179 = torch.ops.aten.add.Tensor(sum_17, 1e-06);  sum_17 = None
    rsqrt_44 = torch.ops.aten.rsqrt.default(add_179);  add_179 = None
    mul_230 = torch.ops.aten.mul.Tensor(clone_61, rsqrt_44);  clone_61 = rsqrt_44 = None
    mul_233 = torch.ops.aten.mul.Tensor(mul_230, 0.08838834764831845);  mul_230 = None
    view_515 = torch.ops.aten.reshape.default(mul_233, [1, 16, -1, 64, 128]);  mul_233 = None
    exp_79 = torch.ops.aten.exp.default(cumsum_7);  cumsum_7 = None
    unsqueeze_116 = torch.ops.aten.unsqueeze.default(exp_79, -1);  exp_79 = None
    mul_239 = torch.ops.aten.mul.Tensor(view_515, unsqueeze_116);  unsqueeze_116 = None
    select_218 = torch.ops.aten.select.int(mul_239, 2, 0)
    expand_166 = torch.ops.aten.expand.default(select_218, [1, 16, 64, 128]);  select_218 = None
    view_529 = torch.ops.aten.reshape.default(expand_166, [16, 64, 128]);  expand_166 = None
    expand_167 = torch.ops.aten.expand.default(full_23, [1, 16, 128, 128]);  full_23 = None
    view_530 = torch.ops.aten.reshape.default(expand_167, [16, 128, 128]);  expand_167 = None
    bmm_77 = torch.ops.aten.bmm.default(view_529, view_530);  view_529 = view_530 = None
    view_531 = torch.ops.aten.reshape.default(bmm_77, [1, 16, 64, 128]);  bmm_77 = None
    expand_162 = torch.ops.aten.expand.default(view_515, [1, 16, 2, 64, 128]);  view_515 = None
    view_523 = torch.ops.aten.reshape.default(expand_162, [32, 64, 128]);  expand_162 = None
    permute_183 = torch.ops.aten.permute.default(view_516, [0, 1, 2, 4, 3]);  view_516 = None
    expand_163 = torch.ops.aten.expand.default(permute_183, [1, 16, 2, 128, 64]);  permute_183 = None
    view_524 = torch.ops.aten.reshape.default(expand_163, [32, 128, 64]);  expand_163 = None
    bmm_75 = torch.ops.aten.bmm.default(view_523, view_524);  view_523 = view_524 = None
    view_525 = torch.ops.aten.reshape.default(bmm_75, [1, 16, 2, 64, 64]);  bmm_75 = None
    mul_237 = torch.ops.aten.mul.Tensor(view_525, exp_77);  view_525 = exp_77 = None
    select_219 = torch.ops.aten.select.int(mul_237, 2, 0)
    expand_168 = torch.ops.aten.expand.default(select_219, [1, 16, 64, 64]);  select_219 = None
    view_532 = torch.ops.aten.reshape.default(expand_168, [16, 64, 64]);  expand_168 = None
    expand_169 = torch.ops.aten.expand.default(sub_40, [1, 16, 64, 128]);  sub_40 = None
    view_533 = torch.ops.aten.reshape.default(expand_169, [16, 64, 128]);  expand_169 = None
    bmm_78 = torch.ops.aten.bmm.default(view_532, view_533);  view_532 = view_533 = None
    view_534 = torch.ops.aten.reshape.default(bmm_78, [1, 16, 64, 128]);  bmm_78 = None
    add_181 = torch.ops.aten.add.Tensor(view_531, view_534);  view_531 = view_534 = None
    copy_33 = torch.ops.aten.copy.default(select_220, add_181);  select_220 = add_181 = None
    select_scatter_default_18 = torch.ops.aten.select_scatter.default(permute_184, copy_33, 2, 0);  permute_184 = copy_33 = None
    select_229 = torch.ops.aten.select.int(select_scatter_default_18, 2, 1)
    select_226 = torch.ops.aten.select.int(mul_239, 2, 1);  mul_239 = None
    expand_174 = torch.ops.aten.expand.default(select_226, [1, 16, 64, 128]);  select_226 = None
    view_541 = torch.ops.aten.reshape.default(expand_174, [16, 64, 128]);  expand_174 = None
    expand_175 = torch.ops.aten.expand.default(add_182, [1, 16, 128, 128]);  add_182 = None
    view_542 = torch.ops.aten.reshape.default(expand_175, [16, 128, 128]);  expand_175 = None
    bmm_81 = torch.ops.aten.bmm.default(view_541, view_542);  view_541 = view_542 = None
    view_543 = torch.ops.aten.reshape.default(bmm_81, [1, 16, 64, 128]);  bmm_81 = None
    select_227 = torch.ops.aten.select.int(mul_237, 2, 1);  mul_237 = None
    expand_176 = torch.ops.aten.expand.default(select_227, [1, 16, 64, 64]);  select_227 = None
    view_544 = torch.ops.aten.reshape.default(expand_176, [16, 64, 64]);  expand_176 = None
    expand_177 = torch.ops.aten.expand.default(sub_41, [1, 16, 64, 128]);  sub_41 = None
    view_545 = torch.ops.aten.reshape.default(expand_177, [16, 64, 128]);  expand_177 = None
    bmm_82 = torch.ops.aten.bmm.default(view_544, view_545);  view_544 = view_545 = None
    view_546 = torch.ops.aten.reshape.default(bmm_82, [1, 16, 64, 128]);  bmm_82 = None
    add_183 = torch.ops.aten.add.Tensor(view_543, view_546);  view_543 = view_546 = None
    copy_34 = torch.ops.aten.copy.default(select_229, add_183);  select_229 = add_183 = None
    select_scatter_default_19 = torch.ops.aten.select_scatter.default(select_scatter_default_18, copy_34, 2, 1);  select_scatter_default_18 = copy_34 = None
    clone_66 = torch.ops.aten.clone.default(select_scatter_default_19, memory_format = torch.contiguous_format);  select_scatter_default_19 = None
    view_550 = torch.ops.aten.reshape.default(clone_66, [1, 16, 128, 128]);  clone_66 = None
    permute_187 = torch.ops.aten.permute.default(view_550, [0, 2, 1, 3]);  view_550 = None
    convert_element_type_366 = torch.ops.prims.convert_element_type.default(permute_187, torch.bfloat16);  permute_187 = None
    clone_67 = torch.ops.aten.clone.default(convert_element_type_366, memory_format = torch.contiguous_format);  convert_element_type_366 = None
    view_551 = torch.ops.aten.reshape.default(clone_67, [-1, 128]);  clone_67 = None
    convert_element_type_367 = torch.ops.prims.convert_element_type.default(view_551, torch.float32);  view_551 = None
    pow_31 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_367, 2)
    mean_30 = torch.ops.aten.mean.dim(pow_31, [-1], True);  pow_31 = None
    add_185 = torch.ops.aten.add.Tensor(mean_30, 1e-06);  mean_30 = None
    rsqrt_46 = torch.ops.aten.rsqrt.default(add_185);  add_185 = None
    mul_243 = torch.ops.aten.mul.Tensor(convert_element_type_367, rsqrt_46);  convert_element_type_367 = rsqrt_46 = None
    convert_element_type_368 = torch.ops.prims.convert_element_type.default(mul_243, torch.bfloat16);  mul_243 = None
    mul_244 = torch.ops.aten.mul.Tensor(arg154_1, convert_element_type_368);  arg154_1 = convert_element_type_368 = None
    view_501 = torch.ops.aten.reshape.default(convert_element_type_347, [128, 2048]);  convert_element_type_347 = None
    permute_173 = torch.ops.aten.permute.default(arg146_1, [1, 0]);  arg146_1 = None
    mm_71 = torch.ops.aten.mm.default(view_501, permute_173);  view_501 = permute_173 = None
    view_502 = torch.ops.aten.reshape.default(mm_71, [1, 128, 2048]);  mm_71 = None
    view_503 = torch.ops.aten.reshape.default(view_502, [1, 128, -1, 128]);  view_502 = None
    view_552 = torch.ops.aten.reshape.default(view_503, [-1, 128]);  view_503 = None
    convert_element_type_369 = torch.ops.prims.convert_element_type.default(view_552, torch.float32);  view_552 = None
    neg_36 = torch.ops.aten.neg.default(convert_element_type_369)
    exp_82 = torch.ops.aten.exp.default(neg_36);  neg_36 = None
    add_186 = torch.ops.aten.add.Tensor(exp_82, 1);  exp_82 = None
    div_26 = torch.ops.aten.div.Tensor(convert_element_type_369, add_186);  convert_element_type_369 = add_186 = None
    mul_245 = torch.ops.aten.mul.Tensor(mul_244, div_26);  mul_244 = div_26 = None
    convert_element_type_370 = torch.ops.prims.convert_element_type.default(mul_245, torch.bfloat16);  mul_245 = None
    view_553 = torch.ops.aten.reshape.default(convert_element_type_370, [1, 128, -1]);  convert_element_type_370 = None
    view_554 = torch.ops.aten.reshape.default(view_553, [128, 2048]);  view_553 = None
    permute_188 = torch.ops.aten.permute.default(arg155_1, [1, 0]);  arg155_1 = None
    mm_74 = torch.ops.aten.mm.default(view_554, permute_188);  view_554 = permute_188 = None
    view_555 = torch.ops.aten.reshape.default(mm_74, [1, 128, 2048]);  mm_74 = None
    add_187 = torch.ops.aten.add.Tensor(add_171, view_555);  add_171 = view_555 = None
    convert_element_type_373 = torch.ops.prims.convert_element_type.default(add_187, torch.float32)
    pow_32 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_373, 2)
    mean_31 = torch.ops.aten.mean.dim(pow_32, [-1], True);  pow_32 = None
    add_188 = torch.ops.aten.add.Tensor(mean_31, 1e-06);  mean_31 = None
    rsqrt_47 = torch.ops.aten.rsqrt.default(add_188);  add_188 = None
    mul_246 = torch.ops.aten.mul.Tensor(convert_element_type_373, rsqrt_47);  convert_element_type_373 = rsqrt_47 = None
    convert_element_type_374 = torch.ops.prims.convert_element_type.default(arg156_1, torch.float32);  arg156_1 = None
    add_189 = torch.ops.aten.add.Tensor(convert_element_type_374, 1.0);  convert_element_type_374 = None
    mul_247 = torch.ops.aten.mul.Tensor(mul_246, add_189);  mul_246 = add_189 = None
    convert_element_type_375 = torch.ops.prims.convert_element_type.default(mul_247, torch.bfloat16);  mul_247 = None
    view_556 = torch.ops.aten.reshape.default(convert_element_type_375, [128, 2048])
    permute_189 = torch.ops.aten.permute.default(arg157_1, [1, 0]);  arg157_1 = None
    mm_75 = torch.ops.aten.mm.default(view_556, permute_189);  view_556 = permute_189 = None
    view_557 = torch.ops.aten.reshape.default(mm_75, [1, 128, 6144]);  mm_75 = None
    convert_element_type_378 = torch.ops.prims.convert_element_type.default(view_557, torch.float32);  view_557 = None
    neg_37 = torch.ops.aten.neg.default(convert_element_type_378)
    exp_83 = torch.ops.aten.exp.default(neg_37);  neg_37 = None
    add_190 = torch.ops.aten.add.Tensor(exp_83, 1);  exp_83 = None
    div_27 = torch.ops.aten.div.Tensor(convert_element_type_378, add_190);  convert_element_type_378 = add_190 = None
    convert_element_type_379 = torch.ops.prims.convert_element_type.default(div_27, torch.bfloat16);  div_27 = None
    view_558 = torch.ops.aten.reshape.default(convert_element_type_375, [128, 2048]);  convert_element_type_375 = None
    permute_190 = torch.ops.aten.permute.default(arg158_1, [1, 0]);  arg158_1 = None
    mm_76 = torch.ops.aten.mm.default(view_558, permute_190);  view_558 = permute_190 = None
    view_559 = torch.ops.aten.reshape.default(mm_76, [1, 128, 6144]);  mm_76 = None
    mul_248 = torch.ops.aten.mul.Tensor(convert_element_type_379, view_559);  convert_element_type_379 = view_559 = None
    view_560 = torch.ops.aten.reshape.default(mul_248, [128, 6144]);  mul_248 = None
    permute_191 = torch.ops.aten.permute.default(arg159_1, [1, 0]);  arg159_1 = None
    mm_77 = torch.ops.aten.mm.default(view_560, permute_191);  view_560 = permute_191 = None
    view_561 = torch.ops.aten.reshape.default(mm_77, [1, 128, 2048]);  mm_77 = None
    add_191 = torch.ops.aten.add.Tensor(add_187, view_561);  add_187 = view_561 = None
    convert_element_type_384 = torch.ops.prims.convert_element_type.default(add_191, torch.float32)
    pow_33 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_384, 2)
    mean_32 = torch.ops.aten.mean.dim(pow_33, [-1], True);  pow_33 = None
    add_192 = torch.ops.aten.add.Tensor(mean_32, 1e-06);  mean_32 = None
    rsqrt_48 = torch.ops.aten.rsqrt.default(add_192);  add_192 = None
    mul_249 = torch.ops.aten.mul.Tensor(convert_element_type_384, rsqrt_48);  convert_element_type_384 = rsqrt_48 = None
    convert_element_type_385 = torch.ops.prims.convert_element_type.default(arg160_1, torch.float32);  arg160_1 = None
    add_193 = torch.ops.aten.add.Tensor(convert_element_type_385, 1.0);  convert_element_type_385 = None
    mul_250 = torch.ops.aten.mul.Tensor(mul_249, add_193);  mul_249 = add_193 = None
    convert_element_type_386 = torch.ops.prims.convert_element_type.default(mul_250, torch.bfloat16);  mul_250 = None
    view_562 = torch.ops.aten.reshape.default(convert_element_type_386, [128, 2048])
    permute_192 = torch.ops.aten.permute.default(arg161_1, [1, 0]);  arg161_1 = None
    mm_78 = torch.ops.aten.mm.default(view_562, permute_192);  view_562 = permute_192 = None
    view_563 = torch.ops.aten.reshape.default(mm_78, [1, 128, 6144]);  mm_78 = None
    permute_193 = torch.ops.aten.permute.default(view_563, [0, 2, 1]);  view_563 = None
    slice_98 = torch.ops.aten.slice.Tensor(permute_193, 2, -4, 9223372036854775807)
    copy_36 = torch.ops.aten.copy.default(arg165_1, slice_98);  slice_98 = None
    convert_element_type_395 = torch.ops.prims.convert_element_type.default(permute_193, torch.float32);  permute_193 = None
    constant_pad_nd_48 = torch.ops.aten.constant_pad_nd.default(convert_element_type_395, [3, 3], 0.0);  convert_element_type_395 = None
    slice_99 = torch.ops.aten.slice.Tensor(constant_pad_nd_48, 2, 0, 131)
    squeeze_8 = torch.ops.aten.squeeze.dim(arg166_1, 1);  arg166_1 = None
    unsqueeze_120 = torch.ops.aten.unsqueeze.default(squeeze_8, 1);  squeeze_8 = None
    convert_element_type_396 = torch.ops.prims.convert_element_type.default(unsqueeze_120, torch.float32);  unsqueeze_120 = None
    select_233 = torch.ops.aten.select.int(convert_element_type_396, 1, 0)
    select_234 = torch.ops.aten.select.int(select_233, 1, 0);  select_233 = None
    view_571 = torch.ops.aten.reshape.default(select_234, [1, -1, 1]);  select_234 = None
    mul_251 = torch.ops.aten.mul.Tensor(slice_99, view_571);  slice_99 = view_571 = None
    slice_100 = torch.ops.aten.slice.Tensor(constant_pad_nd_48, 2, 1, 132)
    select_235 = torch.ops.aten.select.int(convert_element_type_396, 1, 0)
    select_236 = torch.ops.aten.select.int(select_235, 1, 1);  select_235 = None
    view_572 = torch.ops.aten.reshape.default(select_236, [1, -1, 1]);  select_236 = None
    mul_252 = torch.ops.aten.mul.Tensor(slice_100, view_572);  slice_100 = view_572 = None
    add_194 = torch.ops.aten.add.Tensor(mul_251, mul_252);  mul_251 = mul_252 = None
    slice_101 = torch.ops.aten.slice.Tensor(constant_pad_nd_48, 2, 2, 133)
    select_237 = torch.ops.aten.select.int(convert_element_type_396, 1, 0)
    select_238 = torch.ops.aten.select.int(select_237, 1, 2);  select_237 = None
    view_573 = torch.ops.aten.reshape.default(select_238, [1, -1, 1]);  select_238 = None
    mul_253 = torch.ops.aten.mul.Tensor(slice_101, view_573);  slice_101 = view_573 = None
    add_195 = torch.ops.aten.add.Tensor(add_194, mul_253);  add_194 = mul_253 = None
    slice_102 = torch.ops.aten.slice.Tensor(constant_pad_nd_48, 2, 3, 134);  constant_pad_nd_48 = None
    select_239 = torch.ops.aten.select.int(convert_element_type_396, 1, 0);  convert_element_type_396 = None
    select_240 = torch.ops.aten.select.int(select_239, 1, 3);  select_239 = None
    view_574 = torch.ops.aten.reshape.default(select_240, [1, -1, 1]);  select_240 = None
    mul_254 = torch.ops.aten.mul.Tensor(slice_102, view_574);  slice_102 = view_574 = None
    add_196 = torch.ops.aten.add.Tensor(add_195, mul_254);  add_195 = mul_254 = None
    convert_element_type_397 = torch.ops.prims.convert_element_type.default(add_196, torch.bfloat16);  add_196 = None
    slice_103 = torch.ops.aten.slice.Tensor(convert_element_type_397, 2, 0, 128);  convert_element_type_397 = None
    convert_element_type_398 = torch.ops.prims.convert_element_type.default(slice_103, torch.float32);  slice_103 = None
    neg_38 = torch.ops.aten.neg.default(convert_element_type_398)
    exp_84 = torch.ops.aten.exp.default(neg_38);  neg_38 = None
    add_197 = torch.ops.aten.add.Tensor(exp_84, 1);  exp_84 = None
    div_28 = torch.ops.aten.div.Tensor(convert_element_type_398, add_197);  convert_element_type_398 = add_197 = None
    convert_element_type_399 = torch.ops.prims.convert_element_type.default(div_28, torch.bfloat16);  div_28 = None
    slice_104 = torch.ops.aten.slice.Tensor(convert_element_type_399, 2, -128, 9223372036854775807);  convert_element_type_399 = None
    permute_197 = torch.ops.aten.permute.default(slice_104, [0, 2, 1]);  slice_104 = None
    split_with_sizes_8 = torch.ops.aten.split_with_sizes.default(permute_197, [2048, 2048, 2048], -1);  permute_197 = None
    getitem_28 = split_with_sizes_8[0]
    getitem_29 = split_with_sizes_8[1]
    getitem_30 = split_with_sizes_8[2];  split_with_sizes_8 = None
    full_26 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_85 = torch.ops.aten.exp.default(arg167_1);  arg167_1 = None
    neg_39 = torch.ops.aten.neg.default(exp_85);  exp_85 = None
    view_569 = torch.ops.aten.reshape.default(convert_element_type_386, [128, 2048])
    permute_196 = torch.ops.aten.permute.default(arg164_1, [1, 0]);  arg164_1 = None
    mm_81 = torch.ops.aten.mm.default(view_569, permute_196);  view_569 = permute_196 = None
    view_570 = torch.ops.aten.reshape.default(mm_81, [1, 128, 16]);  mm_81 = None
    convert_element_type_400 = torch.ops.prims.convert_element_type.default(view_570, torch.float32);  view_570 = None
    add_198 = torch.ops.aten.add.Tensor(convert_element_type_400, arg168_1);  convert_element_type_400 = arg168_1 = None
    gt_8 = torch.ops.aten.gt.Scalar(add_198, 20)
    exp_86 = torch.ops.aten.exp.default(add_198)
    log1p_8 = torch.ops.aten.log1p.default(exp_86);  exp_86 = None
    where_17 = torch.ops.aten.where.self(gt_8, add_198, log1p_8);  gt_8 = add_198 = log1p_8 = None
    mul_255 = torch.ops.aten.mul.Tensor(neg_39, where_17);  neg_39 = where_17 = None
    permute_202 = torch.ops.aten.permute.default(mul_255, [0, 2, 1]);  mul_255 = None
    view_582 = torch.ops.aten.reshape.default(permute_202, [1, 16, 2, 64]);  permute_202 = None
    cumsum_8 = torch.ops.aten.cumsum.default(view_582, 3);  view_582 = None
    select_241 = torch.ops.aten.select.int(cumsum_8, 3, -1)
    exp_91 = torch.ops.aten.exp.default(select_241);  select_241 = None
    unsqueeze_130 = torch.ops.aten.unsqueeze.default(exp_91, 3);  exp_91 = None
    unsqueeze_131 = torch.ops.aten.unsqueeze.default(unsqueeze_130, 4);  unsqueeze_130 = None
    select_248 = torch.ops.aten.select.int(unsqueeze_131, 2, 0)
    mul_268 = torch.ops.aten.mul.Tensor(full_26, select_248);  select_248 = None
    view_576 = torch.ops.aten.reshape.default(getitem_29, [1, 128, 16, 128]);  getitem_29 = None
    permute_199 = torch.ops.aten.permute.default(view_576, [0, 2, 1, 3]);  view_576 = None
    convert_element_type_402 = torch.ops.prims.convert_element_type.default(permute_199, torch.float32);  permute_199 = None
    clone_69 = torch.ops.aten.clone.default(convert_element_type_402, memory_format = torch.contiguous_format);  convert_element_type_402 = None
    mul_258 = torch.ops.aten.mul.Tensor(clone_69, clone_69)
    sum_20 = torch.ops.aten.sum.dim_IntList(mul_258, [-1], True);  mul_258 = None
    add_200 = torch.ops.aten.add.Tensor(sum_20, 1e-06);  sum_20 = None
    rsqrt_50 = torch.ops.aten.rsqrt.default(add_200);  add_200 = None
    mul_259 = torch.ops.aten.mul.Tensor(clone_69, rsqrt_50);  clone_69 = rsqrt_50 = None
    view_579 = torch.ops.aten.reshape.default(mul_259, [1, 16, -1, 64, 128])
    slice_105 = torch.ops.aten.slice.Tensor(cumsum_8, 3, -1, 9223372036854775807)
    sub_44 = torch.ops.aten.sub.Tensor(slice_105, cumsum_8);  slice_105 = None
    exp_90 = torch.ops.aten.exp.default(sub_44);  sub_44 = None
    unsqueeze_129 = torch.ops.aten.unsqueeze.default(exp_90, -1);  exp_90 = None
    mul_267 = torch.ops.aten.mul.Tensor(view_579, unsqueeze_129);  unsqueeze_129 = None
    select_249 = torch.ops.aten.select.int(mul_267, 2, 0)
    permute_206 = torch.ops.aten.permute.default(select_249, [0, 1, 3, 2]);  select_249 = None
    expand_190 = torch.ops.aten.expand.default(permute_206, [1, 16, 128, 64]);  permute_206 = None
    view_598 = torch.ops.aten.reshape.default(expand_190, [16, 128, 64]);  expand_190 = None
    view_567 = torch.ops.aten.reshape.default(convert_element_type_386, [128, 2048])
    permute_195 = torch.ops.aten.permute.default(arg163_1, [1, 0]);  arg163_1 = None
    mm_80 = torch.ops.aten.mm.default(view_567, permute_195);  view_567 = permute_195 = None
    view_568 = torch.ops.aten.reshape.default(mm_80, [1, 128, 16]);  mm_80 = None
    sigmoid_10 = torch.ops.aten.sigmoid.default(view_568);  view_568 = None
    permute_201 = torch.ops.aten.permute.default(sigmoid_10, [0, 2, 1]);  sigmoid_10 = None
    convert_element_type_404 = torch.ops.prims.convert_element_type.default(permute_201, torch.float32);  permute_201 = None
    clone_71 = torch.ops.aten.clone.default(convert_element_type_404, memory_format = torch.contiguous_format);  convert_element_type_404 = None
    unsqueeze_122 = torch.ops.aten.unsqueeze.default(clone_71, -1)
    mul_262 = torch.ops.aten.mul.Tensor(mul_259, unsqueeze_122);  mul_259 = unsqueeze_122 = None
    view_580 = torch.ops.aten.reshape.default(mul_262, [1, 16, -1, 64, 128]);  mul_262 = None
    expand_180 = torch.ops.aten.expand.default(view_580, [1, 16, 2, 64, 128])
    view_583 = torch.ops.aten.reshape.default(expand_180, [32, 64, 128]);  expand_180 = None
    permute_203 = torch.ops.aten.permute.default(view_579, [0, 1, 2, 4, 3])
    expand_181 = torch.ops.aten.expand.default(permute_203, [1, 16, 2, 128, 64]);  permute_203 = None
    view_584 = torch.ops.aten.reshape.default(expand_181, [32, 128, 64]);  expand_181 = None
    bmm_84 = torch.ops.aten.bmm.default(view_583, view_584);  view_583 = view_584 = None
    view_585 = torch.ops.aten.reshape.default(bmm_84, [1, 16, 2, 64, 64]);  bmm_84 = None
    iota_19 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_123 = torch.ops.aten.unsqueeze.default(iota_19, -2);  iota_19 = None
    iota_20 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_124 = torch.ops.aten.unsqueeze.default(iota_20, -1);  iota_20 = None
    sub_42 = torch.ops.aten.sub.Tensor(unsqueeze_123, unsqueeze_124);  unsqueeze_123 = unsqueeze_124 = None
    ge_8 = torch.ops.aten.ge.Scalar(sub_42, 1);  sub_42 = None
    full_default_18 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_8 = torch.ops.aten.logical_and.default(ge_8, full_default_18);  ge_8 = full_default_18 = None
    full_default_19 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_125 = torch.ops.aten.unsqueeze.default(cumsum_8, 4)
    unsqueeze_126 = torch.ops.aten.unsqueeze.default(cumsum_8, 3)
    sub_43 = torch.ops.aten.sub.Tensor(unsqueeze_125, unsqueeze_126);  unsqueeze_125 = unsqueeze_126 = None
    where_18 = torch.ops.aten.where.self(logical_and_8, full_default_19, sub_43);  logical_and_8 = full_default_19 = sub_43 = None
    exp_87 = torch.ops.aten.exp.default(where_18);  where_18 = None
    mul_263 = torch.ops.aten.mul.Tensor(view_585, exp_87);  view_585 = None
    view_577 = torch.ops.aten.reshape.default(getitem_30, [1, 128, 16, 128]);  getitem_30 = None
    permute_200 = torch.ops.aten.permute.default(view_577, [0, 2, 1, 3]);  view_577 = None
    convert_element_type_403 = torch.ops.prims.convert_element_type.default(permute_200, torch.float32);  permute_200 = None
    clone_70 = torch.ops.aten.clone.default(convert_element_type_403, memory_format = torch.contiguous_format);  convert_element_type_403 = None
    unsqueeze_121 = torch.ops.aten.unsqueeze.default(clone_71, -1);  clone_71 = None
    mul_261 = torch.ops.aten.mul.Tensor(clone_70, unsqueeze_121);  clone_70 = unsqueeze_121 = None
    view_581 = torch.ops.aten.reshape.default(mul_261, [1, 16, -1, 64, 128]);  mul_261 = None
    linalg_solve_triangular_16 = torch.ops.aten.linalg_solve_triangular.default(mul_263, view_581, upper = False, unitriangular = True);  view_581 = None
    select_242 = torch.ops.aten.select.int(linalg_solve_triangular_16, 2, 0)
    exp_88 = torch.ops.aten.exp.default(cumsum_8)
    unsqueeze_127 = torch.ops.aten.unsqueeze.default(exp_88, -1);  exp_88 = None
    mul_265 = torch.ops.aten.mul.Tensor(view_580, unsqueeze_127);  view_580 = unsqueeze_127 = None
    linalg_solve_triangular_17 = torch.ops.aten.linalg_solve_triangular.default(mul_263, mul_265, upper = False, unitriangular = True);  mul_263 = mul_265 = None
    select_243 = torch.ops.aten.select.int(linalg_solve_triangular_17, 2, 0)
    expand_184 = torch.ops.aten.expand.default(select_243, [1, 16, 64, 128]);  select_243 = None
    view_589 = torch.ops.aten.reshape.default(expand_184, [16, 64, 128]);  expand_184 = None
    expand_185 = torch.ops.aten.expand.default(full_26, [1, 16, 128, 128])
    view_590 = torch.ops.aten.reshape.default(expand_185, [16, 128, 128]);  expand_185 = None
    bmm_86 = torch.ops.aten.bmm.default(view_589, view_590);  view_589 = view_590 = None
    view_591 = torch.ops.aten.reshape.default(bmm_86, [1, 16, 64, 128]);  bmm_86 = None
    sub_45 = torch.ops.aten.sub.Tensor(select_242, view_591);  select_242 = view_591 = None
    expand_191 = torch.ops.aten.expand.default(sub_45, [1, 16, 64, 128])
    view_599 = torch.ops.aten.reshape.default(expand_191, [16, 64, 128]);  expand_191 = None
    bmm_89 = torch.ops.aten.bmm.default(view_598, view_599);  view_598 = view_599 = None
    view_600 = torch.ops.aten.reshape.default(bmm_89, [1, 16, 128, 128]);  bmm_89 = None
    add_202 = torch.ops.aten.add.Tensor(mul_268, view_600);  mul_268 = view_600 = None
    select_257 = torch.ops.aten.select.int(unsqueeze_131, 2, 1);  unsqueeze_131 = None
    mul_269 = torch.ops.aten.mul.Tensor(add_202, select_257);  select_257 = None
    select_258 = torch.ops.aten.select.int(mul_267, 2, 1);  mul_267 = None
    permute_207 = torch.ops.aten.permute.default(select_258, [0, 1, 3, 2]);  select_258 = None
    expand_198 = torch.ops.aten.expand.default(permute_207, [1, 16, 128, 64]);  permute_207 = None
    view_610 = torch.ops.aten.reshape.default(expand_198, [16, 128, 64]);  expand_198 = None
    select_250 = torch.ops.aten.select.int(linalg_solve_triangular_16, 2, 1);  linalg_solve_triangular_16 = None
    select_251 = torch.ops.aten.select.int(linalg_solve_triangular_17, 2, 1);  linalg_solve_triangular_17 = None
    expand_192 = torch.ops.aten.expand.default(select_251, [1, 16, 64, 128]);  select_251 = None
    view_601 = torch.ops.aten.reshape.default(expand_192, [16, 64, 128]);  expand_192 = None
    expand_193 = torch.ops.aten.expand.default(add_202, [1, 16, 128, 128])
    view_602 = torch.ops.aten.reshape.default(expand_193, [16, 128, 128]);  expand_193 = None
    bmm_90 = torch.ops.aten.bmm.default(view_601, view_602);  view_601 = view_602 = None
    view_603 = torch.ops.aten.reshape.default(bmm_90, [1, 16, 64, 128]);  bmm_90 = None
    sub_46 = torch.ops.aten.sub.Tensor(select_250, view_603);  select_250 = view_603 = None
    expand_199 = torch.ops.aten.expand.default(sub_46, [1, 16, 64, 128])
    view_611 = torch.ops.aten.reshape.default(expand_199, [16, 64, 128]);  expand_199 = None
    bmm_93 = torch.ops.aten.bmm.default(view_610, view_611);  view_610 = view_611 = None
    view_612 = torch.ops.aten.reshape.default(bmm_93, [1, 16, 128, 128]);  bmm_93 = None
    add_204 = torch.ops.aten.add.Tensor(mul_269, view_612);  mul_269 = view_612 = None
    full_27 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_205 = torch.ops.aten.permute.default(full_27, [0, 1, 2, 4, 3]);  full_27 = None
    select_246 = torch.ops.aten.select.int(permute_205, 2, 0)
    view_575 = torch.ops.aten.reshape.default(getitem_28, [1, 128, 16, 128]);  getitem_28 = None
    permute_198 = torch.ops.aten.permute.default(view_575, [0, 2, 1, 3]);  view_575 = None
    convert_element_type_401 = torch.ops.prims.convert_element_type.default(permute_198, torch.float32);  permute_198 = None
    clone_68 = torch.ops.aten.clone.default(convert_element_type_401, memory_format = torch.contiguous_format);  convert_element_type_401 = None
    mul_256 = torch.ops.aten.mul.Tensor(clone_68, clone_68)
    sum_19 = torch.ops.aten.sum.dim_IntList(mul_256, [-1], True);  mul_256 = None
    add_199 = torch.ops.aten.add.Tensor(sum_19, 1e-06);  sum_19 = None
    rsqrt_49 = torch.ops.aten.rsqrt.default(add_199);  add_199 = None
    mul_257 = torch.ops.aten.mul.Tensor(clone_68, rsqrt_49);  clone_68 = rsqrt_49 = None
    mul_260 = torch.ops.aten.mul.Tensor(mul_257, 0.08838834764831845);  mul_257 = None
    view_578 = torch.ops.aten.reshape.default(mul_260, [1, 16, -1, 64, 128]);  mul_260 = None
    exp_89 = torch.ops.aten.exp.default(cumsum_8);  cumsum_8 = None
    unsqueeze_128 = torch.ops.aten.unsqueeze.default(exp_89, -1);  exp_89 = None
    mul_266 = torch.ops.aten.mul.Tensor(view_578, unsqueeze_128);  unsqueeze_128 = None
    select_244 = torch.ops.aten.select.int(mul_266, 2, 0)
    expand_186 = torch.ops.aten.expand.default(select_244, [1, 16, 64, 128]);  select_244 = None
    view_592 = torch.ops.aten.reshape.default(expand_186, [16, 64, 128]);  expand_186 = None
    expand_187 = torch.ops.aten.expand.default(full_26, [1, 16, 128, 128]);  full_26 = None
    view_593 = torch.ops.aten.reshape.default(expand_187, [16, 128, 128]);  expand_187 = None
    bmm_87 = torch.ops.aten.bmm.default(view_592, view_593);  view_592 = view_593 = None
    view_594 = torch.ops.aten.reshape.default(bmm_87, [1, 16, 64, 128]);  bmm_87 = None
    expand_182 = torch.ops.aten.expand.default(view_578, [1, 16, 2, 64, 128]);  view_578 = None
    view_586 = torch.ops.aten.reshape.default(expand_182, [32, 64, 128]);  expand_182 = None
    permute_204 = torch.ops.aten.permute.default(view_579, [0, 1, 2, 4, 3]);  view_579 = None
    expand_183 = torch.ops.aten.expand.default(permute_204, [1, 16, 2, 128, 64]);  permute_204 = None
    view_587 = torch.ops.aten.reshape.default(expand_183, [32, 128, 64]);  expand_183 = None
    bmm_85 = torch.ops.aten.bmm.default(view_586, view_587);  view_586 = view_587 = None
    view_588 = torch.ops.aten.reshape.default(bmm_85, [1, 16, 2, 64, 64]);  bmm_85 = None
    mul_264 = torch.ops.aten.mul.Tensor(view_588, exp_87);  view_588 = exp_87 = None
    select_245 = torch.ops.aten.select.int(mul_264, 2, 0)
    expand_188 = torch.ops.aten.expand.default(select_245, [1, 16, 64, 64]);  select_245 = None
    view_595 = torch.ops.aten.reshape.default(expand_188, [16, 64, 64]);  expand_188 = None
    expand_189 = torch.ops.aten.expand.default(sub_45, [1, 16, 64, 128]);  sub_45 = None
    view_596 = torch.ops.aten.reshape.default(expand_189, [16, 64, 128]);  expand_189 = None
    bmm_88 = torch.ops.aten.bmm.default(view_595, view_596);  view_595 = view_596 = None
    view_597 = torch.ops.aten.reshape.default(bmm_88, [1, 16, 64, 128]);  bmm_88 = None
    add_201 = torch.ops.aten.add.Tensor(view_594, view_597);  view_594 = view_597 = None
    copy_37 = torch.ops.aten.copy.default(select_246, add_201);  select_246 = add_201 = None
    select_scatter_default_20 = torch.ops.aten.select_scatter.default(permute_205, copy_37, 2, 0);  permute_205 = copy_37 = None
    select_255 = torch.ops.aten.select.int(select_scatter_default_20, 2, 1)
    select_252 = torch.ops.aten.select.int(mul_266, 2, 1);  mul_266 = None
    expand_194 = torch.ops.aten.expand.default(select_252, [1, 16, 64, 128]);  select_252 = None
    view_604 = torch.ops.aten.reshape.default(expand_194, [16, 64, 128]);  expand_194 = None
    expand_195 = torch.ops.aten.expand.default(add_202, [1, 16, 128, 128]);  add_202 = None
    view_605 = torch.ops.aten.reshape.default(expand_195, [16, 128, 128]);  expand_195 = None
    bmm_91 = torch.ops.aten.bmm.default(view_604, view_605);  view_604 = view_605 = None
    view_606 = torch.ops.aten.reshape.default(bmm_91, [1, 16, 64, 128]);  bmm_91 = None
    select_253 = torch.ops.aten.select.int(mul_264, 2, 1);  mul_264 = None
    expand_196 = torch.ops.aten.expand.default(select_253, [1, 16, 64, 64]);  select_253 = None
    view_607 = torch.ops.aten.reshape.default(expand_196, [16, 64, 64]);  expand_196 = None
    expand_197 = torch.ops.aten.expand.default(sub_46, [1, 16, 64, 128]);  sub_46 = None
    view_608 = torch.ops.aten.reshape.default(expand_197, [16, 64, 128]);  expand_197 = None
    bmm_92 = torch.ops.aten.bmm.default(view_607, view_608);  view_607 = view_608 = None
    view_609 = torch.ops.aten.reshape.default(bmm_92, [1, 16, 64, 128]);  bmm_92 = None
    add_203 = torch.ops.aten.add.Tensor(view_606, view_609);  view_606 = view_609 = None
    copy_38 = torch.ops.aten.copy.default(select_255, add_203);  select_255 = add_203 = None
    select_scatter_default_21 = torch.ops.aten.select_scatter.default(select_scatter_default_20, copy_38, 2, 1);  select_scatter_default_20 = copy_38 = None
    clone_73 = torch.ops.aten.clone.default(select_scatter_default_21, memory_format = torch.contiguous_format);  select_scatter_default_21 = None
    view_613 = torch.ops.aten.reshape.default(clone_73, [1, 16, 128, 128]);  clone_73 = None
    permute_208 = torch.ops.aten.permute.default(view_613, [0, 2, 1, 3]);  view_613 = None
    convert_element_type_405 = torch.ops.prims.convert_element_type.default(permute_208, torch.bfloat16);  permute_208 = None
    clone_74 = torch.ops.aten.clone.default(convert_element_type_405, memory_format = torch.contiguous_format);  convert_element_type_405 = None
    view_614 = torch.ops.aten.reshape.default(clone_74, [-1, 128]);  clone_74 = None
    convert_element_type_406 = torch.ops.prims.convert_element_type.default(view_614, torch.float32);  view_614 = None
    pow_34 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_406, 2)
    mean_33 = torch.ops.aten.mean.dim(pow_34, [-1], True);  pow_34 = None
    add_205 = torch.ops.aten.add.Tensor(mean_33, 1e-06);  mean_33 = None
    rsqrt_51 = torch.ops.aten.rsqrt.default(add_205);  add_205 = None
    mul_270 = torch.ops.aten.mul.Tensor(convert_element_type_406, rsqrt_51);  convert_element_type_406 = rsqrt_51 = None
    convert_element_type_407 = torch.ops.prims.convert_element_type.default(mul_270, torch.bfloat16);  mul_270 = None
    mul_271 = torch.ops.aten.mul.Tensor(arg170_1, convert_element_type_407);  arg170_1 = convert_element_type_407 = None
    view_564 = torch.ops.aten.reshape.default(convert_element_type_386, [128, 2048]);  convert_element_type_386 = None
    permute_194 = torch.ops.aten.permute.default(arg162_1, [1, 0]);  arg162_1 = None
    mm_79 = torch.ops.aten.mm.default(view_564, permute_194);  view_564 = permute_194 = None
    view_565 = torch.ops.aten.reshape.default(mm_79, [1, 128, 2048]);  mm_79 = None
    view_566 = torch.ops.aten.reshape.default(view_565, [1, 128, -1, 128]);  view_565 = None
    view_615 = torch.ops.aten.reshape.default(view_566, [-1, 128]);  view_566 = None
    convert_element_type_408 = torch.ops.prims.convert_element_type.default(view_615, torch.float32);  view_615 = None
    neg_40 = torch.ops.aten.neg.default(convert_element_type_408)
    exp_92 = torch.ops.aten.exp.default(neg_40);  neg_40 = None
    add_206 = torch.ops.aten.add.Tensor(exp_92, 1);  exp_92 = None
    div_29 = torch.ops.aten.div.Tensor(convert_element_type_408, add_206);  convert_element_type_408 = add_206 = None
    mul_272 = torch.ops.aten.mul.Tensor(mul_271, div_29);  mul_271 = div_29 = None
    convert_element_type_409 = torch.ops.prims.convert_element_type.default(mul_272, torch.bfloat16);  mul_272 = None
    view_616 = torch.ops.aten.reshape.default(convert_element_type_409, [1, 128, -1]);  convert_element_type_409 = None
    view_617 = torch.ops.aten.reshape.default(view_616, [128, 2048]);  view_616 = None
    permute_209 = torch.ops.aten.permute.default(arg171_1, [1, 0]);  arg171_1 = None
    mm_82 = torch.ops.aten.mm.default(view_617, permute_209);  view_617 = permute_209 = None
    view_618 = torch.ops.aten.reshape.default(mm_82, [1, 128, 2048]);  mm_82 = None
    add_207 = torch.ops.aten.add.Tensor(add_191, view_618);  add_191 = view_618 = None
    convert_element_type_412 = torch.ops.prims.convert_element_type.default(add_207, torch.float32)
    pow_35 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_412, 2)
    mean_34 = torch.ops.aten.mean.dim(pow_35, [-1], True);  pow_35 = None
    add_208 = torch.ops.aten.add.Tensor(mean_34, 1e-06);  mean_34 = None
    rsqrt_52 = torch.ops.aten.rsqrt.default(add_208);  add_208 = None
    mul_273 = torch.ops.aten.mul.Tensor(convert_element_type_412, rsqrt_52);  convert_element_type_412 = rsqrt_52 = None
    convert_element_type_413 = torch.ops.prims.convert_element_type.default(arg172_1, torch.float32);  arg172_1 = None
    add_209 = torch.ops.aten.add.Tensor(convert_element_type_413, 1.0);  convert_element_type_413 = None
    mul_274 = torch.ops.aten.mul.Tensor(mul_273, add_209);  mul_273 = add_209 = None
    convert_element_type_414 = torch.ops.prims.convert_element_type.default(mul_274, torch.bfloat16);  mul_274 = None
    view_619 = torch.ops.aten.reshape.default(convert_element_type_414, [128, 2048])
    permute_210 = torch.ops.aten.permute.default(arg173_1, [1, 0]);  arg173_1 = None
    mm_83 = torch.ops.aten.mm.default(view_619, permute_210);  view_619 = permute_210 = None
    view_620 = torch.ops.aten.reshape.default(mm_83, [1, 128, 6144]);  mm_83 = None
    convert_element_type_417 = torch.ops.prims.convert_element_type.default(view_620, torch.float32);  view_620 = None
    neg_41 = torch.ops.aten.neg.default(convert_element_type_417)
    exp_93 = torch.ops.aten.exp.default(neg_41);  neg_41 = None
    add_210 = torch.ops.aten.add.Tensor(exp_93, 1);  exp_93 = None
    div_30 = torch.ops.aten.div.Tensor(convert_element_type_417, add_210);  convert_element_type_417 = add_210 = None
    convert_element_type_418 = torch.ops.prims.convert_element_type.default(div_30, torch.bfloat16);  div_30 = None
    view_621 = torch.ops.aten.reshape.default(convert_element_type_414, [128, 2048]);  convert_element_type_414 = None
    permute_211 = torch.ops.aten.permute.default(arg174_1, [1, 0]);  arg174_1 = None
    mm_84 = torch.ops.aten.mm.default(view_621, permute_211);  view_621 = permute_211 = None
    view_622 = torch.ops.aten.reshape.default(mm_84, [1, 128, 6144]);  mm_84 = None
    mul_275 = torch.ops.aten.mul.Tensor(convert_element_type_418, view_622);  convert_element_type_418 = view_622 = None
    view_623 = torch.ops.aten.reshape.default(mul_275, [128, 6144]);  mul_275 = None
    permute_212 = torch.ops.aten.permute.default(arg175_1, [1, 0]);  arg175_1 = None
    mm_85 = torch.ops.aten.mm.default(view_623, permute_212);  view_623 = permute_212 = None
    view_624 = torch.ops.aten.reshape.default(mm_85, [1, 128, 2048]);  mm_85 = None
    add_211 = torch.ops.aten.add.Tensor(add_207, view_624);  add_207 = view_624 = None
    convert_element_type_423 = torch.ops.prims.convert_element_type.default(add_211, torch.float32)
    pow_36 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_423, 2)
    mean_35 = torch.ops.aten.mean.dim(pow_36, [-1], True);  pow_36 = None
    add_212 = torch.ops.aten.add.Tensor(mean_35, 1e-06);  mean_35 = None
    rsqrt_53 = torch.ops.aten.rsqrt.default(add_212);  add_212 = None
    mul_276 = torch.ops.aten.mul.Tensor(convert_element_type_423, rsqrt_53);  convert_element_type_423 = rsqrt_53 = None
    convert_element_type_424 = torch.ops.prims.convert_element_type.default(arg176_1, torch.float32);  arg176_1 = None
    add_213 = torch.ops.aten.add.Tensor(convert_element_type_424, 1.0);  convert_element_type_424 = None
    mul_277 = torch.ops.aten.mul.Tensor(mul_276, add_213);  mul_276 = add_213 = None
    convert_element_type_425 = torch.ops.prims.convert_element_type.default(mul_277, torch.bfloat16);  mul_277 = None
    view_625 = torch.ops.aten.reshape.default(convert_element_type_425, [128, 2048])
    permute_213 = torch.ops.aten.permute.default(arg177_1, [1, 0]);  arg177_1 = None
    mm_86 = torch.ops.aten.mm.default(view_625, permute_213);  view_625 = permute_213 = None
    view_626 = torch.ops.aten.reshape.default(mm_86, [1, 128, 4096]);  mm_86 = None
    view_627 = torch.ops.aten.reshape.default(view_626, [1, 128, -1, 512]);  view_626 = None
    split_2 = torch.ops.aten.split.Tensor(view_627, 256, -1);  view_627 = None
    getitem_31 = split_2[0]
    getitem_32 = split_2[1];  split_2 = None
    add_221 = torch.ops.aten.add.Tensor(arg182_1, 128)
    convert_element_type_428 = torch.ops.prims.convert_element_type.default(getitem_31, torch.float32);  getitem_31 = None
    pow_37 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_428, 2)
    mean_36 = torch.ops.aten.mean.dim(pow_37, [-1], True);  pow_37 = None
    add_214 = torch.ops.aten.add.Tensor(mean_36, 1e-06);  mean_36 = None
    rsqrt_54 = torch.ops.aten.rsqrt.default(add_214);  add_214 = None
    mul_278 = torch.ops.aten.mul.Tensor(convert_element_type_428, rsqrt_54);  convert_element_type_428 = rsqrt_54 = None
    convert_element_type_429 = torch.ops.prims.convert_element_type.default(arg178_1, torch.float32);  arg178_1 = None
    add_215 = torch.ops.aten.add.Tensor(convert_element_type_429, 1.0);  convert_element_type_429 = None
    mul_279 = torch.ops.aten.mul.Tensor(mul_278, add_215);  mul_278 = add_215 = None
    convert_element_type_430 = torch.ops.prims.convert_element_type.default(mul_279, torch.bfloat16);  mul_279 = None
    permute_214 = torch.ops.aten.permute.default(convert_element_type_430, [0, 2, 1, 3]);  convert_element_type_430 = None
    slice_106 = torch.ops.aten.slice.Tensor(permute_214, 3, 0, 64)
    unsqueeze_132 = torch.ops.aten.unsqueeze.default(convert_element_type_2, 1)
    mul_282 = torch.ops.aten.mul.Tensor(slice_106, unsqueeze_132)
    slice_111 = torch.ops.aten.slice.Tensor(slice_106, 3, 32, 9223372036854775807)
    neg_42 = torch.ops.aten.neg.default(slice_111);  slice_111 = None
    slice_110 = torch.ops.aten.slice.Tensor(slice_106, 3, 0, 32);  slice_106 = None
    cat_8 = torch.ops.aten.cat.default([neg_42, slice_110], -1);  neg_42 = slice_110 = None
    unsqueeze_133 = torch.ops.aten.unsqueeze.default(convert_element_type_3, 1)
    mul_283 = torch.ops.aten.mul.Tensor(cat_8, unsqueeze_133);  cat_8 = None
    add_218 = torch.ops.aten.add.Tensor(mul_282, mul_283);  mul_282 = mul_283 = None
    slice_107 = torch.ops.aten.slice.Tensor(permute_214, 3, 64, 9223372036854775807);  permute_214 = None
    cat_10 = torch.ops.aten.cat.default([add_218, slice_107], -1);  add_218 = slice_107 = None
    expand_204 = torch.ops.aten.expand.default(cat_10, [1, 8, 128, 256]);  cat_10 = None
    view_638 = torch.ops.aten.reshape.default(expand_204, [8, 128, 256]);  expand_204 = None
    iota_21 = torch.ops.prims.iota.default(128, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    add_220 = torch.ops.aten.add.Tensor(iota_21, arg182_1);  iota_21 = None
    view_630 = torch.ops.aten.reshape.default(convert_element_type_425, [128, 2048])
    permute_215 = torch.ops.aten.permute.default(arg179_1, [1, 0]);  arg179_1 = None
    mm_87 = torch.ops.aten.mm.default(view_630, permute_215);  view_630 = permute_215 = None
    view_631 = torch.ops.aten.reshape.default(mm_87, [1, 128, 512]);  mm_87 = None
    view_632 = torch.ops.aten.reshape.default(view_631, [1, 128, -1, 256]);  view_631 = None
    convert_element_type_433 = torch.ops.prims.convert_element_type.default(view_632, torch.float32);  view_632 = None
    pow_38 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_433, 2)
    mean_37 = torch.ops.aten.mean.dim(pow_38, [-1], True);  pow_38 = None
    add_216 = torch.ops.aten.add.Tensor(mean_37, 1e-06);  mean_37 = None
    rsqrt_55 = torch.ops.aten.rsqrt.default(add_216);  add_216 = None
    mul_280 = torch.ops.aten.mul.Tensor(convert_element_type_433, rsqrt_55);  convert_element_type_433 = rsqrt_55 = None
    convert_element_type_434 = torch.ops.prims.convert_element_type.default(arg180_1, torch.float32);  arg180_1 = None
    add_217 = torch.ops.aten.add.Tensor(convert_element_type_434, 1.0);  convert_element_type_434 = None
    mul_281 = torch.ops.aten.mul.Tensor(mul_280, add_217);  mul_280 = add_217 = None
    convert_element_type_435 = torch.ops.prims.convert_element_type.default(mul_281, torch.bfloat16);  mul_281 = None
    permute_216 = torch.ops.aten.permute.default(convert_element_type_435, [0, 2, 1, 3]);  convert_element_type_435 = None
    slice_108 = torch.ops.aten.slice.Tensor(permute_216, 3, 0, 64)
    mul_284 = torch.ops.aten.mul.Tensor(slice_108, unsqueeze_132);  unsqueeze_132 = None
    slice_113 = torch.ops.aten.slice.Tensor(slice_108, 3, 32, 9223372036854775807)
    neg_43 = torch.ops.aten.neg.default(slice_113);  slice_113 = None
    slice_112 = torch.ops.aten.slice.Tensor(slice_108, 3, 0, 32);  slice_108 = None
    cat_9 = torch.ops.aten.cat.default([neg_43, slice_112], -1);  neg_43 = slice_112 = None
    mul_285 = torch.ops.aten.mul.Tensor(cat_9, unsqueeze_133);  cat_9 = unsqueeze_133 = None
    add_219 = torch.ops.aten.add.Tensor(mul_284, mul_285);  mul_284 = mul_285 = None
    slice_109 = torch.ops.aten.slice.Tensor(permute_216, 3, 64, 9223372036854775807);  permute_216 = None
    cat_11 = torch.ops.aten.cat.default([add_219, slice_109], -1);  add_219 = slice_109 = None
    index_put_4 = torch.ops.aten.index_put_.default(arg183_1, [None, None, add_220], cat_11);  arg183_1 = cat_11 = None
    unsqueeze_136 = torch.ops.aten.unsqueeze.default(index_put_4, 2);  index_put_4 = None
    expand_201 = torch.ops.aten.expand.default(unsqueeze_136, [1, 2, 4, 144, 256]);  unsqueeze_136 = None
    clone_76 = torch.ops.aten.clone.default(expand_201, memory_format = torch.contiguous_format);  expand_201 = None
    view_636 = torch.ops.aten.reshape.default(clone_76, [1, 8, 144, 256]);  clone_76 = None
    permute_219 = torch.ops.aten.permute.default(view_636, [0, 1, 3, 2]);  view_636 = None
    expand_205 = torch.ops.aten.expand.default(permute_219, [1, 8, 256, 144]);  permute_219 = None
    view_639 = torch.ops.aten.reshape.default(expand_205, [8, 256, 144]);  expand_205 = None
    bmm_94 = torch.ops.aten.bmm.default(view_638, view_639);  view_638 = view_639 = None
    view_640 = torch.ops.aten.reshape.default(bmm_94, [1, 8, 128, 144]);  bmm_94 = None
    mul_286 = torch.ops.aten.mul.Tensor(view_640, 0.0625);  view_640 = None
    add_222 = torch.ops.aten.add.Tensor(mul_286, unsqueeze_3);  mul_286 = None
    convert_element_type_440 = torch.ops.prims.convert_element_type.default(add_222, torch.float32);  add_222 = None
    amax_2 = torch.ops.aten.amax.default(convert_element_type_440, [-1], True)
    sub_47 = torch.ops.aten.sub.Tensor(convert_element_type_440, amax_2);  convert_element_type_440 = amax_2 = None
    exp_94 = torch.ops.aten.exp.default(sub_47);  sub_47 = None
    sum_21 = torch.ops.aten.sum.dim_IntList(exp_94, [-1], True)
    div_31 = torch.ops.aten.div.Tensor(exp_94, sum_21);  exp_94 = sum_21 = None
    convert_element_type_441 = torch.ops.prims.convert_element_type.default(div_31, torch.bfloat16);  div_31 = None
    expand_206 = torch.ops.aten.expand.default(convert_element_type_441, [1, 8, 128, 144]);  convert_element_type_441 = None
    view_641 = torch.ops.aten.reshape.default(expand_206, [8, 128, 144]);  expand_206 = None
    view_633 = torch.ops.aten.reshape.default(convert_element_type_425, [128, 2048]);  convert_element_type_425 = None
    permute_217 = torch.ops.aten.permute.default(arg181_1, [1, 0]);  arg181_1 = None
    mm_88 = torch.ops.aten.mm.default(view_633, permute_217);  view_633 = permute_217 = None
    view_634 = torch.ops.aten.reshape.default(mm_88, [1, 128, 512]);  mm_88 = None
    view_635 = torch.ops.aten.reshape.default(view_634, [1, 128, -1, 256]);  view_634 = None
    permute_218 = torch.ops.aten.permute.default(view_635, [0, 2, 1, 3]);  view_635 = None
    index_put_5 = torch.ops.aten.index_put_.default(arg184_1, [None, None, add_220], permute_218);  arg184_1 = add_220 = permute_218 = None
    unsqueeze_139 = torch.ops.aten.unsqueeze.default(index_put_5, 2);  index_put_5 = None
    expand_203 = torch.ops.aten.expand.default(unsqueeze_139, [1, 2, 4, 144, 256]);  unsqueeze_139 = None
    clone_77 = torch.ops.aten.clone.default(expand_203, memory_format = torch.contiguous_format);  expand_203 = None
    view_637 = torch.ops.aten.reshape.default(clone_77, [1, 8, 144, 256]);  clone_77 = None
    expand_207 = torch.ops.aten.expand.default(view_637, [1, 8, 144, 256]);  view_637 = None
    view_642 = torch.ops.aten.reshape.default(expand_207, [8, 144, 256]);  expand_207 = None
    bmm_95 = torch.ops.aten.bmm.default(view_641, view_642);  view_641 = view_642 = None
    view_643 = torch.ops.aten.reshape.default(bmm_95, [1, 8, 128, 256]);  bmm_95 = None
    permute_220 = torch.ops.aten.permute.default(view_643, [0, 2, 1, 3]);  view_643 = None
    clone_78 = torch.ops.aten.clone.default(permute_220, memory_format = torch.contiguous_format);  permute_220 = None
    view_644 = torch.ops.aten.reshape.default(clone_78, [1, 128, -1]);  clone_78 = None
    clone_75 = torch.ops.aten.clone.default(getitem_32, memory_format = torch.contiguous_format);  getitem_32 = None
    view_628 = torch.ops.aten.reshape.default(clone_75, [1, 128, 2048]);  clone_75 = None
    sigmoid_11 = torch.ops.aten.sigmoid.default(view_628);  view_628 = None
    mul_287 = torch.ops.aten.mul.Tensor(view_644, sigmoid_11);  view_644 = sigmoid_11 = None
    view_645 = torch.ops.aten.reshape.default(mul_287, [128, 2048]);  mul_287 = None
    permute_221 = torch.ops.aten.permute.default(arg185_1, [1, 0]);  arg185_1 = None
    mm_89 = torch.ops.aten.mm.default(view_645, permute_221);  view_645 = permute_221 = None
    view_646 = torch.ops.aten.reshape.default(mm_89, [1, 128, 2048]);  mm_89 = None
    add_223 = torch.ops.aten.add.Tensor(add_211, view_646);  add_211 = view_646 = None
    convert_element_type_446 = torch.ops.prims.convert_element_type.default(add_223, torch.float32)
    pow_39 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_446, 2)
    mean_38 = torch.ops.aten.mean.dim(pow_39, [-1], True);  pow_39 = None
    add_224 = torch.ops.aten.add.Tensor(mean_38, 1e-06);  mean_38 = None
    rsqrt_56 = torch.ops.aten.rsqrt.default(add_224);  add_224 = None
    mul_288 = torch.ops.aten.mul.Tensor(convert_element_type_446, rsqrt_56);  convert_element_type_446 = rsqrt_56 = None
    convert_element_type_447 = torch.ops.prims.convert_element_type.default(arg186_1, torch.float32);  arg186_1 = None
    add_225 = torch.ops.aten.add.Tensor(convert_element_type_447, 1.0);  convert_element_type_447 = None
    mul_289 = torch.ops.aten.mul.Tensor(mul_288, add_225);  mul_288 = add_225 = None
    convert_element_type_448 = torch.ops.prims.convert_element_type.default(mul_289, torch.bfloat16);  mul_289 = None
    view_647 = torch.ops.aten.reshape.default(convert_element_type_448, [128, 2048])
    permute_222 = torch.ops.aten.permute.default(arg187_1, [1, 0]);  arg187_1 = None
    mm_90 = torch.ops.aten.mm.default(view_647, permute_222);  view_647 = permute_222 = None
    view_648 = torch.ops.aten.reshape.default(mm_90, [1, 128, 6144]);  mm_90 = None
    convert_element_type_451 = torch.ops.prims.convert_element_type.default(view_648, torch.float32);  view_648 = None
    neg_44 = torch.ops.aten.neg.default(convert_element_type_451)
    exp_95 = torch.ops.aten.exp.default(neg_44);  neg_44 = None
    add_226 = torch.ops.aten.add.Tensor(exp_95, 1);  exp_95 = None
    div_32 = torch.ops.aten.div.Tensor(convert_element_type_451, add_226);  convert_element_type_451 = add_226 = None
    convert_element_type_452 = torch.ops.prims.convert_element_type.default(div_32, torch.bfloat16);  div_32 = None
    view_649 = torch.ops.aten.reshape.default(convert_element_type_448, [128, 2048]);  convert_element_type_448 = None
    permute_223 = torch.ops.aten.permute.default(arg188_1, [1, 0]);  arg188_1 = None
    mm_91 = torch.ops.aten.mm.default(view_649, permute_223);  view_649 = permute_223 = None
    view_650 = torch.ops.aten.reshape.default(mm_91, [1, 128, 6144]);  mm_91 = None
    mul_290 = torch.ops.aten.mul.Tensor(convert_element_type_452, view_650);  convert_element_type_452 = view_650 = None
    view_651 = torch.ops.aten.reshape.default(mul_290, [128, 6144]);  mul_290 = None
    permute_224 = torch.ops.aten.permute.default(arg189_1, [1, 0]);  arg189_1 = None
    mm_92 = torch.ops.aten.mm.default(view_651, permute_224);  view_651 = permute_224 = None
    view_652 = torch.ops.aten.reshape.default(mm_92, [1, 128, 2048]);  mm_92 = None
    add_227 = torch.ops.aten.add.Tensor(add_223, view_652);  add_223 = view_652 = None
    convert_element_type_457 = torch.ops.prims.convert_element_type.default(add_227, torch.float32)
    pow_40 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_457, 2)
    mean_39 = torch.ops.aten.mean.dim(pow_40, [-1], True);  pow_40 = None
    add_228 = torch.ops.aten.add.Tensor(mean_39, 1e-06);  mean_39 = None
    rsqrt_57 = torch.ops.aten.rsqrt.default(add_228);  add_228 = None
    mul_291 = torch.ops.aten.mul.Tensor(convert_element_type_457, rsqrt_57);  convert_element_type_457 = rsqrt_57 = None
    convert_element_type_458 = torch.ops.prims.convert_element_type.default(arg190_1, torch.float32);  arg190_1 = None
    add_229 = torch.ops.aten.add.Tensor(convert_element_type_458, 1.0);  convert_element_type_458 = None
    mul_292 = torch.ops.aten.mul.Tensor(mul_291, add_229);  mul_291 = add_229 = None
    convert_element_type_459 = torch.ops.prims.convert_element_type.default(mul_292, torch.bfloat16);  mul_292 = None
    view_653 = torch.ops.aten.reshape.default(convert_element_type_459, [128, 2048])
    permute_225 = torch.ops.aten.permute.default(arg191_1, [1, 0]);  arg191_1 = None
    mm_93 = torch.ops.aten.mm.default(view_653, permute_225);  view_653 = permute_225 = None
    view_654 = torch.ops.aten.reshape.default(mm_93, [1, 128, 6144]);  mm_93 = None
    permute_226 = torch.ops.aten.permute.default(view_654, [0, 2, 1]);  view_654 = None
    slice_114 = torch.ops.aten.slice.Tensor(permute_226, 2, -4, 9223372036854775807)
    copy_40 = torch.ops.aten.copy.default(arg195_1, slice_114);  slice_114 = None
    convert_element_type_468 = torch.ops.prims.convert_element_type.default(permute_226, torch.float32);  permute_226 = None
    constant_pad_nd_54 = torch.ops.aten.constant_pad_nd.default(convert_element_type_468, [3, 3], 0.0);  convert_element_type_468 = None
    slice_115 = torch.ops.aten.slice.Tensor(constant_pad_nd_54, 2, 0, 131)
    squeeze_9 = torch.ops.aten.squeeze.dim(arg196_1, 1);  arg196_1 = None
    unsqueeze_140 = torch.ops.aten.unsqueeze.default(squeeze_9, 1);  squeeze_9 = None
    convert_element_type_469 = torch.ops.prims.convert_element_type.default(unsqueeze_140, torch.float32);  unsqueeze_140 = None
    select_259 = torch.ops.aten.select.int(convert_element_type_469, 1, 0)
    select_260 = torch.ops.aten.select.int(select_259, 1, 0);  select_259 = None
    view_662 = torch.ops.aten.reshape.default(select_260, [1, -1, 1]);  select_260 = None
    mul_293 = torch.ops.aten.mul.Tensor(slice_115, view_662);  slice_115 = view_662 = None
    slice_116 = torch.ops.aten.slice.Tensor(constant_pad_nd_54, 2, 1, 132)
    select_261 = torch.ops.aten.select.int(convert_element_type_469, 1, 0)
    select_262 = torch.ops.aten.select.int(select_261, 1, 1);  select_261 = None
    view_663 = torch.ops.aten.reshape.default(select_262, [1, -1, 1]);  select_262 = None
    mul_294 = torch.ops.aten.mul.Tensor(slice_116, view_663);  slice_116 = view_663 = None
    add_230 = torch.ops.aten.add.Tensor(mul_293, mul_294);  mul_293 = mul_294 = None
    slice_117 = torch.ops.aten.slice.Tensor(constant_pad_nd_54, 2, 2, 133)
    select_263 = torch.ops.aten.select.int(convert_element_type_469, 1, 0)
    select_264 = torch.ops.aten.select.int(select_263, 1, 2);  select_263 = None
    view_664 = torch.ops.aten.reshape.default(select_264, [1, -1, 1]);  select_264 = None
    mul_295 = torch.ops.aten.mul.Tensor(slice_117, view_664);  slice_117 = view_664 = None
    add_231 = torch.ops.aten.add.Tensor(add_230, mul_295);  add_230 = mul_295 = None
    slice_118 = torch.ops.aten.slice.Tensor(constant_pad_nd_54, 2, 3, 134);  constant_pad_nd_54 = None
    select_265 = torch.ops.aten.select.int(convert_element_type_469, 1, 0);  convert_element_type_469 = None
    select_266 = torch.ops.aten.select.int(select_265, 1, 3);  select_265 = None
    view_665 = torch.ops.aten.reshape.default(select_266, [1, -1, 1]);  select_266 = None
    mul_296 = torch.ops.aten.mul.Tensor(slice_118, view_665);  slice_118 = view_665 = None
    add_232 = torch.ops.aten.add.Tensor(add_231, mul_296);  add_231 = mul_296 = None
    convert_element_type_470 = torch.ops.prims.convert_element_type.default(add_232, torch.bfloat16);  add_232 = None
    slice_119 = torch.ops.aten.slice.Tensor(convert_element_type_470, 2, 0, 128);  convert_element_type_470 = None
    convert_element_type_471 = torch.ops.prims.convert_element_type.default(slice_119, torch.float32);  slice_119 = None
    neg_45 = torch.ops.aten.neg.default(convert_element_type_471)
    exp_96 = torch.ops.aten.exp.default(neg_45);  neg_45 = None
    add_233 = torch.ops.aten.add.Tensor(exp_96, 1);  exp_96 = None
    div_33 = torch.ops.aten.div.Tensor(convert_element_type_471, add_233);  convert_element_type_471 = add_233 = None
    convert_element_type_472 = torch.ops.prims.convert_element_type.default(div_33, torch.bfloat16);  div_33 = None
    slice_120 = torch.ops.aten.slice.Tensor(convert_element_type_472, 2, -128, 9223372036854775807);  convert_element_type_472 = None
    permute_230 = torch.ops.aten.permute.default(slice_120, [0, 2, 1]);  slice_120 = None
    split_with_sizes_9 = torch.ops.aten.split_with_sizes.default(permute_230, [2048, 2048, 2048], -1);  permute_230 = None
    getitem_33 = split_with_sizes_9[0]
    getitem_34 = split_with_sizes_9[1]
    getitem_35 = split_with_sizes_9[2];  split_with_sizes_9 = None
    full_29 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_97 = torch.ops.aten.exp.default(arg197_1);  arg197_1 = None
    neg_46 = torch.ops.aten.neg.default(exp_97);  exp_97 = None
    view_660 = torch.ops.aten.reshape.default(convert_element_type_459, [128, 2048])
    permute_229 = torch.ops.aten.permute.default(arg194_1, [1, 0]);  arg194_1 = None
    mm_96 = torch.ops.aten.mm.default(view_660, permute_229);  view_660 = permute_229 = None
    view_661 = torch.ops.aten.reshape.default(mm_96, [1, 128, 16]);  mm_96 = None
    convert_element_type_473 = torch.ops.prims.convert_element_type.default(view_661, torch.float32);  view_661 = None
    add_234 = torch.ops.aten.add.Tensor(convert_element_type_473, arg198_1);  convert_element_type_473 = arg198_1 = None
    gt_9 = torch.ops.aten.gt.Scalar(add_234, 20)
    exp_98 = torch.ops.aten.exp.default(add_234)
    log1p_9 = torch.ops.aten.log1p.default(exp_98);  exp_98 = None
    where_19 = torch.ops.aten.where.self(gt_9, add_234, log1p_9);  gt_9 = add_234 = log1p_9 = None
    mul_297 = torch.ops.aten.mul.Tensor(neg_46, where_19);  neg_46 = where_19 = None
    permute_235 = torch.ops.aten.permute.default(mul_297, [0, 2, 1]);  mul_297 = None
    view_673 = torch.ops.aten.reshape.default(permute_235, [1, 16, 2, 64]);  permute_235 = None
    cumsum_9 = torch.ops.aten.cumsum.default(view_673, 3);  view_673 = None
    select_267 = torch.ops.aten.select.int(cumsum_9, 3, -1)
    exp_103 = torch.ops.aten.exp.default(select_267);  select_267 = None
    unsqueeze_150 = torch.ops.aten.unsqueeze.default(exp_103, 3);  exp_103 = None
    unsqueeze_151 = torch.ops.aten.unsqueeze.default(unsqueeze_150, 4);  unsqueeze_150 = None
    select_274 = torch.ops.aten.select.int(unsqueeze_151, 2, 0)
    mul_310 = torch.ops.aten.mul.Tensor(full_29, select_274);  select_274 = None
    view_667 = torch.ops.aten.reshape.default(getitem_34, [1, 128, 16, 128]);  getitem_34 = None
    permute_232 = torch.ops.aten.permute.default(view_667, [0, 2, 1, 3]);  view_667 = None
    convert_element_type_475 = torch.ops.prims.convert_element_type.default(permute_232, torch.float32);  permute_232 = None
    clone_80 = torch.ops.aten.clone.default(convert_element_type_475, memory_format = torch.contiguous_format);  convert_element_type_475 = None
    mul_300 = torch.ops.aten.mul.Tensor(clone_80, clone_80)
    sum_23 = torch.ops.aten.sum.dim_IntList(mul_300, [-1], True);  mul_300 = None
    add_236 = torch.ops.aten.add.Tensor(sum_23, 1e-06);  sum_23 = None
    rsqrt_59 = torch.ops.aten.rsqrt.default(add_236);  add_236 = None
    mul_301 = torch.ops.aten.mul.Tensor(clone_80, rsqrt_59);  clone_80 = rsqrt_59 = None
    view_670 = torch.ops.aten.reshape.default(mul_301, [1, 16, -1, 64, 128])
    slice_121 = torch.ops.aten.slice.Tensor(cumsum_9, 3, -1, 9223372036854775807)
    sub_50 = torch.ops.aten.sub.Tensor(slice_121, cumsum_9);  slice_121 = None
    exp_102 = torch.ops.aten.exp.default(sub_50);  sub_50 = None
    unsqueeze_149 = torch.ops.aten.unsqueeze.default(exp_102, -1);  exp_102 = None
    mul_309 = torch.ops.aten.mul.Tensor(view_670, unsqueeze_149);  unsqueeze_149 = None
    select_275 = torch.ops.aten.select.int(mul_309, 2, 0)
    permute_239 = torch.ops.aten.permute.default(select_275, [0, 1, 3, 2]);  select_275 = None
    expand_218 = torch.ops.aten.expand.default(permute_239, [1, 16, 128, 64]);  permute_239 = None
    view_689 = torch.ops.aten.reshape.default(expand_218, [16, 128, 64]);  expand_218 = None
    view_658 = torch.ops.aten.reshape.default(convert_element_type_459, [128, 2048])
    permute_228 = torch.ops.aten.permute.default(arg193_1, [1, 0]);  arg193_1 = None
    mm_95 = torch.ops.aten.mm.default(view_658, permute_228);  view_658 = permute_228 = None
    view_659 = torch.ops.aten.reshape.default(mm_95, [1, 128, 16]);  mm_95 = None
    sigmoid_12 = torch.ops.aten.sigmoid.default(view_659);  view_659 = None
    permute_234 = torch.ops.aten.permute.default(sigmoid_12, [0, 2, 1]);  sigmoid_12 = None
    convert_element_type_477 = torch.ops.prims.convert_element_type.default(permute_234, torch.float32);  permute_234 = None
    clone_82 = torch.ops.aten.clone.default(convert_element_type_477, memory_format = torch.contiguous_format);  convert_element_type_477 = None
    unsqueeze_142 = torch.ops.aten.unsqueeze.default(clone_82, -1)
    mul_304 = torch.ops.aten.mul.Tensor(mul_301, unsqueeze_142);  mul_301 = unsqueeze_142 = None
    view_671 = torch.ops.aten.reshape.default(mul_304, [1, 16, -1, 64, 128]);  mul_304 = None
    expand_208 = torch.ops.aten.expand.default(view_671, [1, 16, 2, 64, 128])
    view_674 = torch.ops.aten.reshape.default(expand_208, [32, 64, 128]);  expand_208 = None
    permute_236 = torch.ops.aten.permute.default(view_670, [0, 1, 2, 4, 3])
    expand_209 = torch.ops.aten.expand.default(permute_236, [1, 16, 2, 128, 64]);  permute_236 = None
    view_675 = torch.ops.aten.reshape.default(expand_209, [32, 128, 64]);  expand_209 = None
    bmm_96 = torch.ops.aten.bmm.default(view_674, view_675);  view_674 = view_675 = None
    view_676 = torch.ops.aten.reshape.default(bmm_96, [1, 16, 2, 64, 64]);  bmm_96 = None
    iota_22 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_143 = torch.ops.aten.unsqueeze.default(iota_22, -2);  iota_22 = None
    iota_23 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_144 = torch.ops.aten.unsqueeze.default(iota_23, -1);  iota_23 = None
    sub_48 = torch.ops.aten.sub.Tensor(unsqueeze_143, unsqueeze_144);  unsqueeze_143 = unsqueeze_144 = None
    ge_9 = torch.ops.aten.ge.Scalar(sub_48, 1);  sub_48 = None
    full_default_20 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_9 = torch.ops.aten.logical_and.default(ge_9, full_default_20);  ge_9 = full_default_20 = None
    full_default_21 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_145 = torch.ops.aten.unsqueeze.default(cumsum_9, 4)
    unsqueeze_146 = torch.ops.aten.unsqueeze.default(cumsum_9, 3)
    sub_49 = torch.ops.aten.sub.Tensor(unsqueeze_145, unsqueeze_146);  unsqueeze_145 = unsqueeze_146 = None
    where_20 = torch.ops.aten.where.self(logical_and_9, full_default_21, sub_49);  logical_and_9 = full_default_21 = sub_49 = None
    exp_99 = torch.ops.aten.exp.default(where_20);  where_20 = None
    mul_305 = torch.ops.aten.mul.Tensor(view_676, exp_99);  view_676 = None
    view_668 = torch.ops.aten.reshape.default(getitem_35, [1, 128, 16, 128]);  getitem_35 = None
    permute_233 = torch.ops.aten.permute.default(view_668, [0, 2, 1, 3]);  view_668 = None
    convert_element_type_476 = torch.ops.prims.convert_element_type.default(permute_233, torch.float32);  permute_233 = None
    clone_81 = torch.ops.aten.clone.default(convert_element_type_476, memory_format = torch.contiguous_format);  convert_element_type_476 = None
    unsqueeze_141 = torch.ops.aten.unsqueeze.default(clone_82, -1);  clone_82 = None
    mul_303 = torch.ops.aten.mul.Tensor(clone_81, unsqueeze_141);  clone_81 = unsqueeze_141 = None
    view_672 = torch.ops.aten.reshape.default(mul_303, [1, 16, -1, 64, 128]);  mul_303 = None
    linalg_solve_triangular_18 = torch.ops.aten.linalg_solve_triangular.default(mul_305, view_672, upper = False, unitriangular = True);  view_672 = None
    select_268 = torch.ops.aten.select.int(linalg_solve_triangular_18, 2, 0)
    exp_100 = torch.ops.aten.exp.default(cumsum_9)
    unsqueeze_147 = torch.ops.aten.unsqueeze.default(exp_100, -1);  exp_100 = None
    mul_307 = torch.ops.aten.mul.Tensor(view_671, unsqueeze_147);  view_671 = unsqueeze_147 = None
    linalg_solve_triangular_19 = torch.ops.aten.linalg_solve_triangular.default(mul_305, mul_307, upper = False, unitriangular = True);  mul_305 = mul_307 = None
    select_269 = torch.ops.aten.select.int(linalg_solve_triangular_19, 2, 0)
    expand_212 = torch.ops.aten.expand.default(select_269, [1, 16, 64, 128]);  select_269 = None
    view_680 = torch.ops.aten.reshape.default(expand_212, [16, 64, 128]);  expand_212 = None
    expand_213 = torch.ops.aten.expand.default(full_29, [1, 16, 128, 128])
    view_681 = torch.ops.aten.reshape.default(expand_213, [16, 128, 128]);  expand_213 = None
    bmm_98 = torch.ops.aten.bmm.default(view_680, view_681);  view_680 = view_681 = None
    view_682 = torch.ops.aten.reshape.default(bmm_98, [1, 16, 64, 128]);  bmm_98 = None
    sub_51 = torch.ops.aten.sub.Tensor(select_268, view_682);  select_268 = view_682 = None
    expand_219 = torch.ops.aten.expand.default(sub_51, [1, 16, 64, 128])
    view_690 = torch.ops.aten.reshape.default(expand_219, [16, 64, 128]);  expand_219 = None
    bmm_101 = torch.ops.aten.bmm.default(view_689, view_690);  view_689 = view_690 = None
    view_691 = torch.ops.aten.reshape.default(bmm_101, [1, 16, 128, 128]);  bmm_101 = None
    add_238 = torch.ops.aten.add.Tensor(mul_310, view_691);  mul_310 = view_691 = None
    select_283 = torch.ops.aten.select.int(unsqueeze_151, 2, 1);  unsqueeze_151 = None
    mul_311 = torch.ops.aten.mul.Tensor(add_238, select_283);  select_283 = None
    select_284 = torch.ops.aten.select.int(mul_309, 2, 1);  mul_309 = None
    permute_240 = torch.ops.aten.permute.default(select_284, [0, 1, 3, 2]);  select_284 = None
    expand_226 = torch.ops.aten.expand.default(permute_240, [1, 16, 128, 64]);  permute_240 = None
    view_701 = torch.ops.aten.reshape.default(expand_226, [16, 128, 64]);  expand_226 = None
    select_276 = torch.ops.aten.select.int(linalg_solve_triangular_18, 2, 1);  linalg_solve_triangular_18 = None
    select_277 = torch.ops.aten.select.int(linalg_solve_triangular_19, 2, 1);  linalg_solve_triangular_19 = None
    expand_220 = torch.ops.aten.expand.default(select_277, [1, 16, 64, 128]);  select_277 = None
    view_692 = torch.ops.aten.reshape.default(expand_220, [16, 64, 128]);  expand_220 = None
    expand_221 = torch.ops.aten.expand.default(add_238, [1, 16, 128, 128])
    view_693 = torch.ops.aten.reshape.default(expand_221, [16, 128, 128]);  expand_221 = None
    bmm_102 = torch.ops.aten.bmm.default(view_692, view_693);  view_692 = view_693 = None
    view_694 = torch.ops.aten.reshape.default(bmm_102, [1, 16, 64, 128]);  bmm_102 = None
    sub_52 = torch.ops.aten.sub.Tensor(select_276, view_694);  select_276 = view_694 = None
    expand_227 = torch.ops.aten.expand.default(sub_52, [1, 16, 64, 128])
    view_702 = torch.ops.aten.reshape.default(expand_227, [16, 64, 128]);  expand_227 = None
    bmm_105 = torch.ops.aten.bmm.default(view_701, view_702);  view_701 = view_702 = None
    view_703 = torch.ops.aten.reshape.default(bmm_105, [1, 16, 128, 128]);  bmm_105 = None
    add_240 = torch.ops.aten.add.Tensor(mul_311, view_703);  mul_311 = view_703 = None
    full_30 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_238 = torch.ops.aten.permute.default(full_30, [0, 1, 2, 4, 3]);  full_30 = None
    select_272 = torch.ops.aten.select.int(permute_238, 2, 0)
    view_666 = torch.ops.aten.reshape.default(getitem_33, [1, 128, 16, 128]);  getitem_33 = None
    permute_231 = torch.ops.aten.permute.default(view_666, [0, 2, 1, 3]);  view_666 = None
    convert_element_type_474 = torch.ops.prims.convert_element_type.default(permute_231, torch.float32);  permute_231 = None
    clone_79 = torch.ops.aten.clone.default(convert_element_type_474, memory_format = torch.contiguous_format);  convert_element_type_474 = None
    mul_298 = torch.ops.aten.mul.Tensor(clone_79, clone_79)
    sum_22 = torch.ops.aten.sum.dim_IntList(mul_298, [-1], True);  mul_298 = None
    add_235 = torch.ops.aten.add.Tensor(sum_22, 1e-06);  sum_22 = None
    rsqrt_58 = torch.ops.aten.rsqrt.default(add_235);  add_235 = None
    mul_299 = torch.ops.aten.mul.Tensor(clone_79, rsqrt_58);  clone_79 = rsqrt_58 = None
    mul_302 = torch.ops.aten.mul.Tensor(mul_299, 0.08838834764831845);  mul_299 = None
    view_669 = torch.ops.aten.reshape.default(mul_302, [1, 16, -1, 64, 128]);  mul_302 = None
    exp_101 = torch.ops.aten.exp.default(cumsum_9);  cumsum_9 = None
    unsqueeze_148 = torch.ops.aten.unsqueeze.default(exp_101, -1);  exp_101 = None
    mul_308 = torch.ops.aten.mul.Tensor(view_669, unsqueeze_148);  unsqueeze_148 = None
    select_270 = torch.ops.aten.select.int(mul_308, 2, 0)
    expand_214 = torch.ops.aten.expand.default(select_270, [1, 16, 64, 128]);  select_270 = None
    view_683 = torch.ops.aten.reshape.default(expand_214, [16, 64, 128]);  expand_214 = None
    expand_215 = torch.ops.aten.expand.default(full_29, [1, 16, 128, 128]);  full_29 = None
    view_684 = torch.ops.aten.reshape.default(expand_215, [16, 128, 128]);  expand_215 = None
    bmm_99 = torch.ops.aten.bmm.default(view_683, view_684);  view_683 = view_684 = None
    view_685 = torch.ops.aten.reshape.default(bmm_99, [1, 16, 64, 128]);  bmm_99 = None
    expand_210 = torch.ops.aten.expand.default(view_669, [1, 16, 2, 64, 128]);  view_669 = None
    view_677 = torch.ops.aten.reshape.default(expand_210, [32, 64, 128]);  expand_210 = None
    permute_237 = torch.ops.aten.permute.default(view_670, [0, 1, 2, 4, 3]);  view_670 = None
    expand_211 = torch.ops.aten.expand.default(permute_237, [1, 16, 2, 128, 64]);  permute_237 = None
    view_678 = torch.ops.aten.reshape.default(expand_211, [32, 128, 64]);  expand_211 = None
    bmm_97 = torch.ops.aten.bmm.default(view_677, view_678);  view_677 = view_678 = None
    view_679 = torch.ops.aten.reshape.default(bmm_97, [1, 16, 2, 64, 64]);  bmm_97 = None
    mul_306 = torch.ops.aten.mul.Tensor(view_679, exp_99);  view_679 = exp_99 = None
    select_271 = torch.ops.aten.select.int(mul_306, 2, 0)
    expand_216 = torch.ops.aten.expand.default(select_271, [1, 16, 64, 64]);  select_271 = None
    view_686 = torch.ops.aten.reshape.default(expand_216, [16, 64, 64]);  expand_216 = None
    expand_217 = torch.ops.aten.expand.default(sub_51, [1, 16, 64, 128]);  sub_51 = None
    view_687 = torch.ops.aten.reshape.default(expand_217, [16, 64, 128]);  expand_217 = None
    bmm_100 = torch.ops.aten.bmm.default(view_686, view_687);  view_686 = view_687 = None
    view_688 = torch.ops.aten.reshape.default(bmm_100, [1, 16, 64, 128]);  bmm_100 = None
    add_237 = torch.ops.aten.add.Tensor(view_685, view_688);  view_685 = view_688 = None
    copy_41 = torch.ops.aten.copy.default(select_272, add_237);  select_272 = add_237 = None
    select_scatter_default_22 = torch.ops.aten.select_scatter.default(permute_238, copy_41, 2, 0);  permute_238 = copy_41 = None
    select_281 = torch.ops.aten.select.int(select_scatter_default_22, 2, 1)
    select_278 = torch.ops.aten.select.int(mul_308, 2, 1);  mul_308 = None
    expand_222 = torch.ops.aten.expand.default(select_278, [1, 16, 64, 128]);  select_278 = None
    view_695 = torch.ops.aten.reshape.default(expand_222, [16, 64, 128]);  expand_222 = None
    expand_223 = torch.ops.aten.expand.default(add_238, [1, 16, 128, 128]);  add_238 = None
    view_696 = torch.ops.aten.reshape.default(expand_223, [16, 128, 128]);  expand_223 = None
    bmm_103 = torch.ops.aten.bmm.default(view_695, view_696);  view_695 = view_696 = None
    view_697 = torch.ops.aten.reshape.default(bmm_103, [1, 16, 64, 128]);  bmm_103 = None
    select_279 = torch.ops.aten.select.int(mul_306, 2, 1);  mul_306 = None
    expand_224 = torch.ops.aten.expand.default(select_279, [1, 16, 64, 64]);  select_279 = None
    view_698 = torch.ops.aten.reshape.default(expand_224, [16, 64, 64]);  expand_224 = None
    expand_225 = torch.ops.aten.expand.default(sub_52, [1, 16, 64, 128]);  sub_52 = None
    view_699 = torch.ops.aten.reshape.default(expand_225, [16, 64, 128]);  expand_225 = None
    bmm_104 = torch.ops.aten.bmm.default(view_698, view_699);  view_698 = view_699 = None
    view_700 = torch.ops.aten.reshape.default(bmm_104, [1, 16, 64, 128]);  bmm_104 = None
    add_239 = torch.ops.aten.add.Tensor(view_697, view_700);  view_697 = view_700 = None
    copy_42 = torch.ops.aten.copy.default(select_281, add_239);  select_281 = add_239 = None
    select_scatter_default_23 = torch.ops.aten.select_scatter.default(select_scatter_default_22, copy_42, 2, 1);  select_scatter_default_22 = copy_42 = None
    clone_84 = torch.ops.aten.clone.default(select_scatter_default_23, memory_format = torch.contiguous_format);  select_scatter_default_23 = None
    view_704 = torch.ops.aten.reshape.default(clone_84, [1, 16, 128, 128]);  clone_84 = None
    permute_241 = torch.ops.aten.permute.default(view_704, [0, 2, 1, 3]);  view_704 = None
    convert_element_type_478 = torch.ops.prims.convert_element_type.default(permute_241, torch.bfloat16);  permute_241 = None
    clone_85 = torch.ops.aten.clone.default(convert_element_type_478, memory_format = torch.contiguous_format);  convert_element_type_478 = None
    view_705 = torch.ops.aten.reshape.default(clone_85, [-1, 128]);  clone_85 = None
    convert_element_type_479 = torch.ops.prims.convert_element_type.default(view_705, torch.float32);  view_705 = None
    pow_41 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_479, 2)
    mean_40 = torch.ops.aten.mean.dim(pow_41, [-1], True);  pow_41 = None
    add_241 = torch.ops.aten.add.Tensor(mean_40, 1e-06);  mean_40 = None
    rsqrt_60 = torch.ops.aten.rsqrt.default(add_241);  add_241 = None
    mul_312 = torch.ops.aten.mul.Tensor(convert_element_type_479, rsqrt_60);  convert_element_type_479 = rsqrt_60 = None
    convert_element_type_480 = torch.ops.prims.convert_element_type.default(mul_312, torch.bfloat16);  mul_312 = None
    mul_313 = torch.ops.aten.mul.Tensor(arg200_1, convert_element_type_480);  arg200_1 = convert_element_type_480 = None
    view_655 = torch.ops.aten.reshape.default(convert_element_type_459, [128, 2048]);  convert_element_type_459 = None
    permute_227 = torch.ops.aten.permute.default(arg192_1, [1, 0]);  arg192_1 = None
    mm_94 = torch.ops.aten.mm.default(view_655, permute_227);  view_655 = permute_227 = None
    view_656 = torch.ops.aten.reshape.default(mm_94, [1, 128, 2048]);  mm_94 = None
    view_657 = torch.ops.aten.reshape.default(view_656, [1, 128, -1, 128]);  view_656 = None
    view_706 = torch.ops.aten.reshape.default(view_657, [-1, 128]);  view_657 = None
    convert_element_type_481 = torch.ops.prims.convert_element_type.default(view_706, torch.float32);  view_706 = None
    neg_47 = torch.ops.aten.neg.default(convert_element_type_481)
    exp_104 = torch.ops.aten.exp.default(neg_47);  neg_47 = None
    add_242 = torch.ops.aten.add.Tensor(exp_104, 1);  exp_104 = None
    div_34 = torch.ops.aten.div.Tensor(convert_element_type_481, add_242);  convert_element_type_481 = add_242 = None
    mul_314 = torch.ops.aten.mul.Tensor(mul_313, div_34);  mul_313 = div_34 = None
    convert_element_type_482 = torch.ops.prims.convert_element_type.default(mul_314, torch.bfloat16);  mul_314 = None
    view_707 = torch.ops.aten.reshape.default(convert_element_type_482, [1, 128, -1]);  convert_element_type_482 = None
    view_708 = torch.ops.aten.reshape.default(view_707, [128, 2048]);  view_707 = None
    permute_242 = torch.ops.aten.permute.default(arg201_1, [1, 0]);  arg201_1 = None
    mm_97 = torch.ops.aten.mm.default(view_708, permute_242);  view_708 = permute_242 = None
    view_709 = torch.ops.aten.reshape.default(mm_97, [1, 128, 2048]);  mm_97 = None
    add_243 = torch.ops.aten.add.Tensor(add_227, view_709);  add_227 = view_709 = None
    convert_element_type_485 = torch.ops.prims.convert_element_type.default(add_243, torch.float32)
    pow_42 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_485, 2)
    mean_41 = torch.ops.aten.mean.dim(pow_42, [-1], True);  pow_42 = None
    add_244 = torch.ops.aten.add.Tensor(mean_41, 1e-06);  mean_41 = None
    rsqrt_61 = torch.ops.aten.rsqrt.default(add_244);  add_244 = None
    mul_315 = torch.ops.aten.mul.Tensor(convert_element_type_485, rsqrt_61);  convert_element_type_485 = rsqrt_61 = None
    convert_element_type_486 = torch.ops.prims.convert_element_type.default(arg202_1, torch.float32);  arg202_1 = None
    add_245 = torch.ops.aten.add.Tensor(convert_element_type_486, 1.0);  convert_element_type_486 = None
    mul_316 = torch.ops.aten.mul.Tensor(mul_315, add_245);  mul_315 = add_245 = None
    convert_element_type_487 = torch.ops.prims.convert_element_type.default(mul_316, torch.bfloat16);  mul_316 = None
    view_710 = torch.ops.aten.reshape.default(convert_element_type_487, [128, 2048])
    permute_243 = torch.ops.aten.permute.default(arg203_1, [1, 0]);  arg203_1 = None
    mm_98 = torch.ops.aten.mm.default(view_710, permute_243);  view_710 = permute_243 = None
    view_711 = torch.ops.aten.reshape.default(mm_98, [1, 128, 6144]);  mm_98 = None
    convert_element_type_490 = torch.ops.prims.convert_element_type.default(view_711, torch.float32);  view_711 = None
    neg_48 = torch.ops.aten.neg.default(convert_element_type_490)
    exp_105 = torch.ops.aten.exp.default(neg_48);  neg_48 = None
    add_246 = torch.ops.aten.add.Tensor(exp_105, 1);  exp_105 = None
    div_35 = torch.ops.aten.div.Tensor(convert_element_type_490, add_246);  convert_element_type_490 = add_246 = None
    convert_element_type_491 = torch.ops.prims.convert_element_type.default(div_35, torch.bfloat16);  div_35 = None
    view_712 = torch.ops.aten.reshape.default(convert_element_type_487, [128, 2048]);  convert_element_type_487 = None
    permute_244 = torch.ops.aten.permute.default(arg204_1, [1, 0]);  arg204_1 = None
    mm_99 = torch.ops.aten.mm.default(view_712, permute_244);  view_712 = permute_244 = None
    view_713 = torch.ops.aten.reshape.default(mm_99, [1, 128, 6144]);  mm_99 = None
    mul_317 = torch.ops.aten.mul.Tensor(convert_element_type_491, view_713);  convert_element_type_491 = view_713 = None
    view_714 = torch.ops.aten.reshape.default(mul_317, [128, 6144]);  mul_317 = None
    permute_245 = torch.ops.aten.permute.default(arg205_1, [1, 0]);  arg205_1 = None
    mm_100 = torch.ops.aten.mm.default(view_714, permute_245);  view_714 = permute_245 = None
    view_715 = torch.ops.aten.reshape.default(mm_100, [1, 128, 2048]);  mm_100 = None
    add_247 = torch.ops.aten.add.Tensor(add_243, view_715);  add_243 = view_715 = None
    convert_element_type_496 = torch.ops.prims.convert_element_type.default(add_247, torch.float32)
    pow_43 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_496, 2)
    mean_42 = torch.ops.aten.mean.dim(pow_43, [-1], True);  pow_43 = None
    add_248 = torch.ops.aten.add.Tensor(mean_42, 1e-06);  mean_42 = None
    rsqrt_62 = torch.ops.aten.rsqrt.default(add_248);  add_248 = None
    mul_318 = torch.ops.aten.mul.Tensor(convert_element_type_496, rsqrt_62);  convert_element_type_496 = rsqrt_62 = None
    convert_element_type_497 = torch.ops.prims.convert_element_type.default(arg206_1, torch.float32);  arg206_1 = None
    add_249 = torch.ops.aten.add.Tensor(convert_element_type_497, 1.0);  convert_element_type_497 = None
    mul_319 = torch.ops.aten.mul.Tensor(mul_318, add_249);  mul_318 = add_249 = None
    convert_element_type_498 = torch.ops.prims.convert_element_type.default(mul_319, torch.bfloat16);  mul_319 = None
    view_716 = torch.ops.aten.reshape.default(convert_element_type_498, [128, 2048])
    permute_246 = torch.ops.aten.permute.default(arg207_1, [1, 0]);  arg207_1 = None
    mm_101 = torch.ops.aten.mm.default(view_716, permute_246);  view_716 = permute_246 = None
    view_717 = torch.ops.aten.reshape.default(mm_101, [1, 128, 6144]);  mm_101 = None
    permute_247 = torch.ops.aten.permute.default(view_717, [0, 2, 1]);  view_717 = None
    slice_122 = torch.ops.aten.slice.Tensor(permute_247, 2, -4, 9223372036854775807)
    copy_44 = torch.ops.aten.copy.default(arg211_1, slice_122);  slice_122 = None
    convert_element_type_507 = torch.ops.prims.convert_element_type.default(permute_247, torch.float32);  permute_247 = None
    constant_pad_nd_60 = torch.ops.aten.constant_pad_nd.default(convert_element_type_507, [3, 3], 0.0);  convert_element_type_507 = None
    slice_123 = torch.ops.aten.slice.Tensor(constant_pad_nd_60, 2, 0, 131)
    squeeze_10 = torch.ops.aten.squeeze.dim(arg212_1, 1);  arg212_1 = None
    unsqueeze_152 = torch.ops.aten.unsqueeze.default(squeeze_10, 1);  squeeze_10 = None
    convert_element_type_508 = torch.ops.prims.convert_element_type.default(unsqueeze_152, torch.float32);  unsqueeze_152 = None
    select_285 = torch.ops.aten.select.int(convert_element_type_508, 1, 0)
    select_286 = torch.ops.aten.select.int(select_285, 1, 0);  select_285 = None
    view_725 = torch.ops.aten.reshape.default(select_286, [1, -1, 1]);  select_286 = None
    mul_320 = torch.ops.aten.mul.Tensor(slice_123, view_725);  slice_123 = view_725 = None
    slice_124 = torch.ops.aten.slice.Tensor(constant_pad_nd_60, 2, 1, 132)
    select_287 = torch.ops.aten.select.int(convert_element_type_508, 1, 0)
    select_288 = torch.ops.aten.select.int(select_287, 1, 1);  select_287 = None
    view_726 = torch.ops.aten.reshape.default(select_288, [1, -1, 1]);  select_288 = None
    mul_321 = torch.ops.aten.mul.Tensor(slice_124, view_726);  slice_124 = view_726 = None
    add_250 = torch.ops.aten.add.Tensor(mul_320, mul_321);  mul_320 = mul_321 = None
    slice_125 = torch.ops.aten.slice.Tensor(constant_pad_nd_60, 2, 2, 133)
    select_289 = torch.ops.aten.select.int(convert_element_type_508, 1, 0)
    select_290 = torch.ops.aten.select.int(select_289, 1, 2);  select_289 = None
    view_727 = torch.ops.aten.reshape.default(select_290, [1, -1, 1]);  select_290 = None
    mul_322 = torch.ops.aten.mul.Tensor(slice_125, view_727);  slice_125 = view_727 = None
    add_251 = torch.ops.aten.add.Tensor(add_250, mul_322);  add_250 = mul_322 = None
    slice_126 = torch.ops.aten.slice.Tensor(constant_pad_nd_60, 2, 3, 134);  constant_pad_nd_60 = None
    select_291 = torch.ops.aten.select.int(convert_element_type_508, 1, 0);  convert_element_type_508 = None
    select_292 = torch.ops.aten.select.int(select_291, 1, 3);  select_291 = None
    view_728 = torch.ops.aten.reshape.default(select_292, [1, -1, 1]);  select_292 = None
    mul_323 = torch.ops.aten.mul.Tensor(slice_126, view_728);  slice_126 = view_728 = None
    add_252 = torch.ops.aten.add.Tensor(add_251, mul_323);  add_251 = mul_323 = None
    convert_element_type_509 = torch.ops.prims.convert_element_type.default(add_252, torch.bfloat16);  add_252 = None
    slice_127 = torch.ops.aten.slice.Tensor(convert_element_type_509, 2, 0, 128);  convert_element_type_509 = None
    convert_element_type_510 = torch.ops.prims.convert_element_type.default(slice_127, torch.float32);  slice_127 = None
    neg_49 = torch.ops.aten.neg.default(convert_element_type_510)
    exp_106 = torch.ops.aten.exp.default(neg_49);  neg_49 = None
    add_253 = torch.ops.aten.add.Tensor(exp_106, 1);  exp_106 = None
    div_36 = torch.ops.aten.div.Tensor(convert_element_type_510, add_253);  convert_element_type_510 = add_253 = None
    convert_element_type_511 = torch.ops.prims.convert_element_type.default(div_36, torch.bfloat16);  div_36 = None
    slice_128 = torch.ops.aten.slice.Tensor(convert_element_type_511, 2, -128, 9223372036854775807);  convert_element_type_511 = None
    permute_251 = torch.ops.aten.permute.default(slice_128, [0, 2, 1]);  slice_128 = None
    split_with_sizes_10 = torch.ops.aten.split_with_sizes.default(permute_251, [2048, 2048, 2048], -1);  permute_251 = None
    getitem_36 = split_with_sizes_10[0]
    getitem_37 = split_with_sizes_10[1]
    getitem_38 = split_with_sizes_10[2];  split_with_sizes_10 = None
    full_32 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_107 = torch.ops.aten.exp.default(arg213_1);  arg213_1 = None
    neg_50 = torch.ops.aten.neg.default(exp_107);  exp_107 = None
    view_723 = torch.ops.aten.reshape.default(convert_element_type_498, [128, 2048])
    permute_250 = torch.ops.aten.permute.default(arg210_1, [1, 0]);  arg210_1 = None
    mm_104 = torch.ops.aten.mm.default(view_723, permute_250);  view_723 = permute_250 = None
    view_724 = torch.ops.aten.reshape.default(mm_104, [1, 128, 16]);  mm_104 = None
    convert_element_type_512 = torch.ops.prims.convert_element_type.default(view_724, torch.float32);  view_724 = None
    add_254 = torch.ops.aten.add.Tensor(convert_element_type_512, arg214_1);  convert_element_type_512 = arg214_1 = None
    gt_10 = torch.ops.aten.gt.Scalar(add_254, 20)
    exp_108 = torch.ops.aten.exp.default(add_254)
    log1p_10 = torch.ops.aten.log1p.default(exp_108);  exp_108 = None
    where_21 = torch.ops.aten.where.self(gt_10, add_254, log1p_10);  gt_10 = add_254 = log1p_10 = None
    mul_324 = torch.ops.aten.mul.Tensor(neg_50, where_21);  neg_50 = where_21 = None
    permute_256 = torch.ops.aten.permute.default(mul_324, [0, 2, 1]);  mul_324 = None
    view_736 = torch.ops.aten.reshape.default(permute_256, [1, 16, 2, 64]);  permute_256 = None
    cumsum_10 = torch.ops.aten.cumsum.default(view_736, 3);  view_736 = None
    select_293 = torch.ops.aten.select.int(cumsum_10, 3, -1)
    exp_113 = torch.ops.aten.exp.default(select_293);  select_293 = None
    unsqueeze_162 = torch.ops.aten.unsqueeze.default(exp_113, 3);  exp_113 = None
    unsqueeze_163 = torch.ops.aten.unsqueeze.default(unsqueeze_162, 4);  unsqueeze_162 = None
    select_300 = torch.ops.aten.select.int(unsqueeze_163, 2, 0)
    mul_337 = torch.ops.aten.mul.Tensor(full_32, select_300);  select_300 = None
    view_730 = torch.ops.aten.reshape.default(getitem_37, [1, 128, 16, 128]);  getitem_37 = None
    permute_253 = torch.ops.aten.permute.default(view_730, [0, 2, 1, 3]);  view_730 = None
    convert_element_type_514 = torch.ops.prims.convert_element_type.default(permute_253, torch.float32);  permute_253 = None
    clone_87 = torch.ops.aten.clone.default(convert_element_type_514, memory_format = torch.contiguous_format);  convert_element_type_514 = None
    mul_327 = torch.ops.aten.mul.Tensor(clone_87, clone_87)
    sum_25 = torch.ops.aten.sum.dim_IntList(mul_327, [-1], True);  mul_327 = None
    add_256 = torch.ops.aten.add.Tensor(sum_25, 1e-06);  sum_25 = None
    rsqrt_64 = torch.ops.aten.rsqrt.default(add_256);  add_256 = None
    mul_328 = torch.ops.aten.mul.Tensor(clone_87, rsqrt_64);  clone_87 = rsqrt_64 = None
    view_733 = torch.ops.aten.reshape.default(mul_328, [1, 16, -1, 64, 128])
    slice_129 = torch.ops.aten.slice.Tensor(cumsum_10, 3, -1, 9223372036854775807)
    sub_55 = torch.ops.aten.sub.Tensor(slice_129, cumsum_10);  slice_129 = None
    exp_112 = torch.ops.aten.exp.default(sub_55);  sub_55 = None
    unsqueeze_161 = torch.ops.aten.unsqueeze.default(exp_112, -1);  exp_112 = None
    mul_336 = torch.ops.aten.mul.Tensor(view_733, unsqueeze_161);  unsqueeze_161 = None
    select_301 = torch.ops.aten.select.int(mul_336, 2, 0)
    permute_260 = torch.ops.aten.permute.default(select_301, [0, 1, 3, 2]);  select_301 = None
    expand_238 = torch.ops.aten.expand.default(permute_260, [1, 16, 128, 64]);  permute_260 = None
    view_752 = torch.ops.aten.reshape.default(expand_238, [16, 128, 64]);  expand_238 = None
    view_721 = torch.ops.aten.reshape.default(convert_element_type_498, [128, 2048])
    permute_249 = torch.ops.aten.permute.default(arg209_1, [1, 0]);  arg209_1 = None
    mm_103 = torch.ops.aten.mm.default(view_721, permute_249);  view_721 = permute_249 = None
    view_722 = torch.ops.aten.reshape.default(mm_103, [1, 128, 16]);  mm_103 = None
    sigmoid_13 = torch.ops.aten.sigmoid.default(view_722);  view_722 = None
    permute_255 = torch.ops.aten.permute.default(sigmoid_13, [0, 2, 1]);  sigmoid_13 = None
    convert_element_type_516 = torch.ops.prims.convert_element_type.default(permute_255, torch.float32);  permute_255 = None
    clone_89 = torch.ops.aten.clone.default(convert_element_type_516, memory_format = torch.contiguous_format);  convert_element_type_516 = None
    unsqueeze_154 = torch.ops.aten.unsqueeze.default(clone_89, -1)
    mul_331 = torch.ops.aten.mul.Tensor(mul_328, unsqueeze_154);  mul_328 = unsqueeze_154 = None
    view_734 = torch.ops.aten.reshape.default(mul_331, [1, 16, -1, 64, 128]);  mul_331 = None
    expand_228 = torch.ops.aten.expand.default(view_734, [1, 16, 2, 64, 128])
    view_737 = torch.ops.aten.reshape.default(expand_228, [32, 64, 128]);  expand_228 = None
    permute_257 = torch.ops.aten.permute.default(view_733, [0, 1, 2, 4, 3])
    expand_229 = torch.ops.aten.expand.default(permute_257, [1, 16, 2, 128, 64]);  permute_257 = None
    view_738 = torch.ops.aten.reshape.default(expand_229, [32, 128, 64]);  expand_229 = None
    bmm_106 = torch.ops.aten.bmm.default(view_737, view_738);  view_737 = view_738 = None
    view_739 = torch.ops.aten.reshape.default(bmm_106, [1, 16, 2, 64, 64]);  bmm_106 = None
    iota_24 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_155 = torch.ops.aten.unsqueeze.default(iota_24, -2);  iota_24 = None
    iota_25 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_156 = torch.ops.aten.unsqueeze.default(iota_25, -1);  iota_25 = None
    sub_53 = torch.ops.aten.sub.Tensor(unsqueeze_155, unsqueeze_156);  unsqueeze_155 = unsqueeze_156 = None
    ge_10 = torch.ops.aten.ge.Scalar(sub_53, 1);  sub_53 = None
    full_default_22 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_10 = torch.ops.aten.logical_and.default(ge_10, full_default_22);  ge_10 = full_default_22 = None
    full_default_23 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_157 = torch.ops.aten.unsqueeze.default(cumsum_10, 4)
    unsqueeze_158 = torch.ops.aten.unsqueeze.default(cumsum_10, 3)
    sub_54 = torch.ops.aten.sub.Tensor(unsqueeze_157, unsqueeze_158);  unsqueeze_157 = unsqueeze_158 = None
    where_22 = torch.ops.aten.where.self(logical_and_10, full_default_23, sub_54);  logical_and_10 = full_default_23 = sub_54 = None
    exp_109 = torch.ops.aten.exp.default(where_22);  where_22 = None
    mul_332 = torch.ops.aten.mul.Tensor(view_739, exp_109);  view_739 = None
    view_731 = torch.ops.aten.reshape.default(getitem_38, [1, 128, 16, 128]);  getitem_38 = None
    permute_254 = torch.ops.aten.permute.default(view_731, [0, 2, 1, 3]);  view_731 = None
    convert_element_type_515 = torch.ops.prims.convert_element_type.default(permute_254, torch.float32);  permute_254 = None
    clone_88 = torch.ops.aten.clone.default(convert_element_type_515, memory_format = torch.contiguous_format);  convert_element_type_515 = None
    unsqueeze_153 = torch.ops.aten.unsqueeze.default(clone_89, -1);  clone_89 = None
    mul_330 = torch.ops.aten.mul.Tensor(clone_88, unsqueeze_153);  clone_88 = unsqueeze_153 = None
    view_735 = torch.ops.aten.reshape.default(mul_330, [1, 16, -1, 64, 128]);  mul_330 = None
    linalg_solve_triangular_20 = torch.ops.aten.linalg_solve_triangular.default(mul_332, view_735, upper = False, unitriangular = True);  view_735 = None
    select_294 = torch.ops.aten.select.int(linalg_solve_triangular_20, 2, 0)
    exp_110 = torch.ops.aten.exp.default(cumsum_10)
    unsqueeze_159 = torch.ops.aten.unsqueeze.default(exp_110, -1);  exp_110 = None
    mul_334 = torch.ops.aten.mul.Tensor(view_734, unsqueeze_159);  view_734 = unsqueeze_159 = None
    linalg_solve_triangular_21 = torch.ops.aten.linalg_solve_triangular.default(mul_332, mul_334, upper = False, unitriangular = True);  mul_332 = mul_334 = None
    select_295 = torch.ops.aten.select.int(linalg_solve_triangular_21, 2, 0)
    expand_232 = torch.ops.aten.expand.default(select_295, [1, 16, 64, 128]);  select_295 = None
    view_743 = torch.ops.aten.reshape.default(expand_232, [16, 64, 128]);  expand_232 = None
    expand_233 = torch.ops.aten.expand.default(full_32, [1, 16, 128, 128])
    view_744 = torch.ops.aten.reshape.default(expand_233, [16, 128, 128]);  expand_233 = None
    bmm_108 = torch.ops.aten.bmm.default(view_743, view_744);  view_743 = view_744 = None
    view_745 = torch.ops.aten.reshape.default(bmm_108, [1, 16, 64, 128]);  bmm_108 = None
    sub_56 = torch.ops.aten.sub.Tensor(select_294, view_745);  select_294 = view_745 = None
    expand_239 = torch.ops.aten.expand.default(sub_56, [1, 16, 64, 128])
    view_753 = torch.ops.aten.reshape.default(expand_239, [16, 64, 128]);  expand_239 = None
    bmm_111 = torch.ops.aten.bmm.default(view_752, view_753);  view_752 = view_753 = None
    view_754 = torch.ops.aten.reshape.default(bmm_111, [1, 16, 128, 128]);  bmm_111 = None
    add_258 = torch.ops.aten.add.Tensor(mul_337, view_754);  mul_337 = view_754 = None
    select_309 = torch.ops.aten.select.int(unsqueeze_163, 2, 1);  unsqueeze_163 = None
    mul_338 = torch.ops.aten.mul.Tensor(add_258, select_309);  select_309 = None
    select_310 = torch.ops.aten.select.int(mul_336, 2, 1);  mul_336 = None
    permute_261 = torch.ops.aten.permute.default(select_310, [0, 1, 3, 2]);  select_310 = None
    expand_246 = torch.ops.aten.expand.default(permute_261, [1, 16, 128, 64]);  permute_261 = None
    view_764 = torch.ops.aten.reshape.default(expand_246, [16, 128, 64]);  expand_246 = None
    select_302 = torch.ops.aten.select.int(linalg_solve_triangular_20, 2, 1);  linalg_solve_triangular_20 = None
    select_303 = torch.ops.aten.select.int(linalg_solve_triangular_21, 2, 1);  linalg_solve_triangular_21 = None
    expand_240 = torch.ops.aten.expand.default(select_303, [1, 16, 64, 128]);  select_303 = None
    view_755 = torch.ops.aten.reshape.default(expand_240, [16, 64, 128]);  expand_240 = None
    expand_241 = torch.ops.aten.expand.default(add_258, [1, 16, 128, 128])
    view_756 = torch.ops.aten.reshape.default(expand_241, [16, 128, 128]);  expand_241 = None
    bmm_112 = torch.ops.aten.bmm.default(view_755, view_756);  view_755 = view_756 = None
    view_757 = torch.ops.aten.reshape.default(bmm_112, [1, 16, 64, 128]);  bmm_112 = None
    sub_57 = torch.ops.aten.sub.Tensor(select_302, view_757);  select_302 = view_757 = None
    expand_247 = torch.ops.aten.expand.default(sub_57, [1, 16, 64, 128])
    view_765 = torch.ops.aten.reshape.default(expand_247, [16, 64, 128]);  expand_247 = None
    bmm_115 = torch.ops.aten.bmm.default(view_764, view_765);  view_764 = view_765 = None
    view_766 = torch.ops.aten.reshape.default(bmm_115, [1, 16, 128, 128]);  bmm_115 = None
    add_260 = torch.ops.aten.add.Tensor(mul_338, view_766);  mul_338 = view_766 = None
    full_33 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_259 = torch.ops.aten.permute.default(full_33, [0, 1, 2, 4, 3]);  full_33 = None
    select_298 = torch.ops.aten.select.int(permute_259, 2, 0)
    view_729 = torch.ops.aten.reshape.default(getitem_36, [1, 128, 16, 128]);  getitem_36 = None
    permute_252 = torch.ops.aten.permute.default(view_729, [0, 2, 1, 3]);  view_729 = None
    convert_element_type_513 = torch.ops.prims.convert_element_type.default(permute_252, torch.float32);  permute_252 = None
    clone_86 = torch.ops.aten.clone.default(convert_element_type_513, memory_format = torch.contiguous_format);  convert_element_type_513 = None
    mul_325 = torch.ops.aten.mul.Tensor(clone_86, clone_86)
    sum_24 = torch.ops.aten.sum.dim_IntList(mul_325, [-1], True);  mul_325 = None
    add_255 = torch.ops.aten.add.Tensor(sum_24, 1e-06);  sum_24 = None
    rsqrt_63 = torch.ops.aten.rsqrt.default(add_255);  add_255 = None
    mul_326 = torch.ops.aten.mul.Tensor(clone_86, rsqrt_63);  clone_86 = rsqrt_63 = None
    mul_329 = torch.ops.aten.mul.Tensor(mul_326, 0.08838834764831845);  mul_326 = None
    view_732 = torch.ops.aten.reshape.default(mul_329, [1, 16, -1, 64, 128]);  mul_329 = None
    exp_111 = torch.ops.aten.exp.default(cumsum_10);  cumsum_10 = None
    unsqueeze_160 = torch.ops.aten.unsqueeze.default(exp_111, -1);  exp_111 = None
    mul_335 = torch.ops.aten.mul.Tensor(view_732, unsqueeze_160);  unsqueeze_160 = None
    select_296 = torch.ops.aten.select.int(mul_335, 2, 0)
    expand_234 = torch.ops.aten.expand.default(select_296, [1, 16, 64, 128]);  select_296 = None
    view_746 = torch.ops.aten.reshape.default(expand_234, [16, 64, 128]);  expand_234 = None
    expand_235 = torch.ops.aten.expand.default(full_32, [1, 16, 128, 128]);  full_32 = None
    view_747 = torch.ops.aten.reshape.default(expand_235, [16, 128, 128]);  expand_235 = None
    bmm_109 = torch.ops.aten.bmm.default(view_746, view_747);  view_746 = view_747 = None
    view_748 = torch.ops.aten.reshape.default(bmm_109, [1, 16, 64, 128]);  bmm_109 = None
    expand_230 = torch.ops.aten.expand.default(view_732, [1, 16, 2, 64, 128]);  view_732 = None
    view_740 = torch.ops.aten.reshape.default(expand_230, [32, 64, 128]);  expand_230 = None
    permute_258 = torch.ops.aten.permute.default(view_733, [0, 1, 2, 4, 3]);  view_733 = None
    expand_231 = torch.ops.aten.expand.default(permute_258, [1, 16, 2, 128, 64]);  permute_258 = None
    view_741 = torch.ops.aten.reshape.default(expand_231, [32, 128, 64]);  expand_231 = None
    bmm_107 = torch.ops.aten.bmm.default(view_740, view_741);  view_740 = view_741 = None
    view_742 = torch.ops.aten.reshape.default(bmm_107, [1, 16, 2, 64, 64]);  bmm_107 = None
    mul_333 = torch.ops.aten.mul.Tensor(view_742, exp_109);  view_742 = exp_109 = None
    select_297 = torch.ops.aten.select.int(mul_333, 2, 0)
    expand_236 = torch.ops.aten.expand.default(select_297, [1, 16, 64, 64]);  select_297 = None
    view_749 = torch.ops.aten.reshape.default(expand_236, [16, 64, 64]);  expand_236 = None
    expand_237 = torch.ops.aten.expand.default(sub_56, [1, 16, 64, 128]);  sub_56 = None
    view_750 = torch.ops.aten.reshape.default(expand_237, [16, 64, 128]);  expand_237 = None
    bmm_110 = torch.ops.aten.bmm.default(view_749, view_750);  view_749 = view_750 = None
    view_751 = torch.ops.aten.reshape.default(bmm_110, [1, 16, 64, 128]);  bmm_110 = None
    add_257 = torch.ops.aten.add.Tensor(view_748, view_751);  view_748 = view_751 = None
    copy_45 = torch.ops.aten.copy.default(select_298, add_257);  select_298 = add_257 = None
    select_scatter_default_24 = torch.ops.aten.select_scatter.default(permute_259, copy_45, 2, 0);  permute_259 = copy_45 = None
    select_307 = torch.ops.aten.select.int(select_scatter_default_24, 2, 1)
    select_304 = torch.ops.aten.select.int(mul_335, 2, 1);  mul_335 = None
    expand_242 = torch.ops.aten.expand.default(select_304, [1, 16, 64, 128]);  select_304 = None
    view_758 = torch.ops.aten.reshape.default(expand_242, [16, 64, 128]);  expand_242 = None
    expand_243 = torch.ops.aten.expand.default(add_258, [1, 16, 128, 128]);  add_258 = None
    view_759 = torch.ops.aten.reshape.default(expand_243, [16, 128, 128]);  expand_243 = None
    bmm_113 = torch.ops.aten.bmm.default(view_758, view_759);  view_758 = view_759 = None
    view_760 = torch.ops.aten.reshape.default(bmm_113, [1, 16, 64, 128]);  bmm_113 = None
    select_305 = torch.ops.aten.select.int(mul_333, 2, 1);  mul_333 = None
    expand_244 = torch.ops.aten.expand.default(select_305, [1, 16, 64, 64]);  select_305 = None
    view_761 = torch.ops.aten.reshape.default(expand_244, [16, 64, 64]);  expand_244 = None
    expand_245 = torch.ops.aten.expand.default(sub_57, [1, 16, 64, 128]);  sub_57 = None
    view_762 = torch.ops.aten.reshape.default(expand_245, [16, 64, 128]);  expand_245 = None
    bmm_114 = torch.ops.aten.bmm.default(view_761, view_762);  view_761 = view_762 = None
    view_763 = torch.ops.aten.reshape.default(bmm_114, [1, 16, 64, 128]);  bmm_114 = None
    add_259 = torch.ops.aten.add.Tensor(view_760, view_763);  view_760 = view_763 = None
    copy_46 = torch.ops.aten.copy.default(select_307, add_259);  select_307 = add_259 = None
    select_scatter_default_25 = torch.ops.aten.select_scatter.default(select_scatter_default_24, copy_46, 2, 1);  select_scatter_default_24 = copy_46 = None
    clone_91 = torch.ops.aten.clone.default(select_scatter_default_25, memory_format = torch.contiguous_format);  select_scatter_default_25 = None
    view_767 = torch.ops.aten.reshape.default(clone_91, [1, 16, 128, 128]);  clone_91 = None
    permute_262 = torch.ops.aten.permute.default(view_767, [0, 2, 1, 3]);  view_767 = None
    convert_element_type_517 = torch.ops.prims.convert_element_type.default(permute_262, torch.bfloat16);  permute_262 = None
    clone_92 = torch.ops.aten.clone.default(convert_element_type_517, memory_format = torch.contiguous_format);  convert_element_type_517 = None
    view_768 = torch.ops.aten.reshape.default(clone_92, [-1, 128]);  clone_92 = None
    convert_element_type_518 = torch.ops.prims.convert_element_type.default(view_768, torch.float32);  view_768 = None
    pow_44 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_518, 2)
    mean_43 = torch.ops.aten.mean.dim(pow_44, [-1], True);  pow_44 = None
    add_261 = torch.ops.aten.add.Tensor(mean_43, 1e-06);  mean_43 = None
    rsqrt_65 = torch.ops.aten.rsqrt.default(add_261);  add_261 = None
    mul_339 = torch.ops.aten.mul.Tensor(convert_element_type_518, rsqrt_65);  convert_element_type_518 = rsqrt_65 = None
    convert_element_type_519 = torch.ops.prims.convert_element_type.default(mul_339, torch.bfloat16);  mul_339 = None
    mul_340 = torch.ops.aten.mul.Tensor(arg216_1, convert_element_type_519);  arg216_1 = convert_element_type_519 = None
    view_718 = torch.ops.aten.reshape.default(convert_element_type_498, [128, 2048]);  convert_element_type_498 = None
    permute_248 = torch.ops.aten.permute.default(arg208_1, [1, 0]);  arg208_1 = None
    mm_102 = torch.ops.aten.mm.default(view_718, permute_248);  view_718 = permute_248 = None
    view_719 = torch.ops.aten.reshape.default(mm_102, [1, 128, 2048]);  mm_102 = None
    view_720 = torch.ops.aten.reshape.default(view_719, [1, 128, -1, 128]);  view_719 = None
    view_769 = torch.ops.aten.reshape.default(view_720, [-1, 128]);  view_720 = None
    convert_element_type_520 = torch.ops.prims.convert_element_type.default(view_769, torch.float32);  view_769 = None
    neg_51 = torch.ops.aten.neg.default(convert_element_type_520)
    exp_114 = torch.ops.aten.exp.default(neg_51);  neg_51 = None
    add_262 = torch.ops.aten.add.Tensor(exp_114, 1);  exp_114 = None
    div_37 = torch.ops.aten.div.Tensor(convert_element_type_520, add_262);  convert_element_type_520 = add_262 = None
    mul_341 = torch.ops.aten.mul.Tensor(mul_340, div_37);  mul_340 = div_37 = None
    convert_element_type_521 = torch.ops.prims.convert_element_type.default(mul_341, torch.bfloat16);  mul_341 = None
    view_770 = torch.ops.aten.reshape.default(convert_element_type_521, [1, 128, -1]);  convert_element_type_521 = None
    view_771 = torch.ops.aten.reshape.default(view_770, [128, 2048]);  view_770 = None
    permute_263 = torch.ops.aten.permute.default(arg217_1, [1, 0]);  arg217_1 = None
    mm_105 = torch.ops.aten.mm.default(view_771, permute_263);  view_771 = permute_263 = None
    view_772 = torch.ops.aten.reshape.default(mm_105, [1, 128, 2048]);  mm_105 = None
    add_263 = torch.ops.aten.add.Tensor(add_247, view_772);  add_247 = view_772 = None
    convert_element_type_524 = torch.ops.prims.convert_element_type.default(add_263, torch.float32)
    pow_45 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_524, 2)
    mean_44 = torch.ops.aten.mean.dim(pow_45, [-1], True);  pow_45 = None
    add_264 = torch.ops.aten.add.Tensor(mean_44, 1e-06);  mean_44 = None
    rsqrt_66 = torch.ops.aten.rsqrt.default(add_264);  add_264 = None
    mul_342 = torch.ops.aten.mul.Tensor(convert_element_type_524, rsqrt_66);  convert_element_type_524 = rsqrt_66 = None
    convert_element_type_525 = torch.ops.prims.convert_element_type.default(arg218_1, torch.float32);  arg218_1 = None
    add_265 = torch.ops.aten.add.Tensor(convert_element_type_525, 1.0);  convert_element_type_525 = None
    mul_343 = torch.ops.aten.mul.Tensor(mul_342, add_265);  mul_342 = add_265 = None
    convert_element_type_526 = torch.ops.prims.convert_element_type.default(mul_343, torch.bfloat16);  mul_343 = None
    view_773 = torch.ops.aten.reshape.default(convert_element_type_526, [128, 2048])
    permute_264 = torch.ops.aten.permute.default(arg219_1, [1, 0]);  arg219_1 = None
    mm_106 = torch.ops.aten.mm.default(view_773, permute_264);  view_773 = permute_264 = None
    view_774 = torch.ops.aten.reshape.default(mm_106, [1, 128, 6144]);  mm_106 = None
    convert_element_type_529 = torch.ops.prims.convert_element_type.default(view_774, torch.float32);  view_774 = None
    neg_52 = torch.ops.aten.neg.default(convert_element_type_529)
    exp_115 = torch.ops.aten.exp.default(neg_52);  neg_52 = None
    add_266 = torch.ops.aten.add.Tensor(exp_115, 1);  exp_115 = None
    div_38 = torch.ops.aten.div.Tensor(convert_element_type_529, add_266);  convert_element_type_529 = add_266 = None
    convert_element_type_530 = torch.ops.prims.convert_element_type.default(div_38, torch.bfloat16);  div_38 = None
    view_775 = torch.ops.aten.reshape.default(convert_element_type_526, [128, 2048]);  convert_element_type_526 = None
    permute_265 = torch.ops.aten.permute.default(arg220_1, [1, 0]);  arg220_1 = None
    mm_107 = torch.ops.aten.mm.default(view_775, permute_265);  view_775 = permute_265 = None
    view_776 = torch.ops.aten.reshape.default(mm_107, [1, 128, 6144]);  mm_107 = None
    mul_344 = torch.ops.aten.mul.Tensor(convert_element_type_530, view_776);  convert_element_type_530 = view_776 = None
    view_777 = torch.ops.aten.reshape.default(mul_344, [128, 6144]);  mul_344 = None
    permute_266 = torch.ops.aten.permute.default(arg221_1, [1, 0]);  arg221_1 = None
    mm_108 = torch.ops.aten.mm.default(view_777, permute_266);  view_777 = permute_266 = None
    view_778 = torch.ops.aten.reshape.default(mm_108, [1, 128, 2048]);  mm_108 = None
    add_267 = torch.ops.aten.add.Tensor(add_263, view_778);  add_263 = view_778 = None
    convert_element_type_535 = torch.ops.prims.convert_element_type.default(add_267, torch.float32)
    pow_46 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_535, 2)
    mean_45 = torch.ops.aten.mean.dim(pow_46, [-1], True);  pow_46 = None
    add_268 = torch.ops.aten.add.Tensor(mean_45, 1e-06);  mean_45 = None
    rsqrt_67 = torch.ops.aten.rsqrt.default(add_268);  add_268 = None
    mul_345 = torch.ops.aten.mul.Tensor(convert_element_type_535, rsqrt_67);  convert_element_type_535 = rsqrt_67 = None
    convert_element_type_536 = torch.ops.prims.convert_element_type.default(arg222_1, torch.float32);  arg222_1 = None
    add_269 = torch.ops.aten.add.Tensor(convert_element_type_536, 1.0);  convert_element_type_536 = None
    mul_346 = torch.ops.aten.mul.Tensor(mul_345, add_269);  mul_345 = add_269 = None
    convert_element_type_537 = torch.ops.prims.convert_element_type.default(mul_346, torch.bfloat16);  mul_346 = None
    view_779 = torch.ops.aten.reshape.default(convert_element_type_537, [128, 2048])
    permute_267 = torch.ops.aten.permute.default(arg223_1, [1, 0]);  arg223_1 = None
    mm_109 = torch.ops.aten.mm.default(view_779, permute_267);  view_779 = permute_267 = None
    view_780 = torch.ops.aten.reshape.default(mm_109, [1, 128, 6144]);  mm_109 = None
    permute_268 = torch.ops.aten.permute.default(view_780, [0, 2, 1]);  view_780 = None
    slice_130 = torch.ops.aten.slice.Tensor(permute_268, 2, -4, 9223372036854775807)
    copy_48 = torch.ops.aten.copy.default(arg227_1, slice_130);  slice_130 = None
    convert_element_type_546 = torch.ops.prims.convert_element_type.default(permute_268, torch.float32);  permute_268 = None
    constant_pad_nd_66 = torch.ops.aten.constant_pad_nd.default(convert_element_type_546, [3, 3], 0.0);  convert_element_type_546 = None
    slice_131 = torch.ops.aten.slice.Tensor(constant_pad_nd_66, 2, 0, 131)
    squeeze_11 = torch.ops.aten.squeeze.dim(arg228_1, 1);  arg228_1 = None
    unsqueeze_164 = torch.ops.aten.unsqueeze.default(squeeze_11, 1);  squeeze_11 = None
    convert_element_type_547 = torch.ops.prims.convert_element_type.default(unsqueeze_164, torch.float32);  unsqueeze_164 = None
    select_311 = torch.ops.aten.select.int(convert_element_type_547, 1, 0)
    select_312 = torch.ops.aten.select.int(select_311, 1, 0);  select_311 = None
    view_788 = torch.ops.aten.reshape.default(select_312, [1, -1, 1]);  select_312 = None
    mul_347 = torch.ops.aten.mul.Tensor(slice_131, view_788);  slice_131 = view_788 = None
    slice_132 = torch.ops.aten.slice.Tensor(constant_pad_nd_66, 2, 1, 132)
    select_313 = torch.ops.aten.select.int(convert_element_type_547, 1, 0)
    select_314 = torch.ops.aten.select.int(select_313, 1, 1);  select_313 = None
    view_789 = torch.ops.aten.reshape.default(select_314, [1, -1, 1]);  select_314 = None
    mul_348 = torch.ops.aten.mul.Tensor(slice_132, view_789);  slice_132 = view_789 = None
    add_270 = torch.ops.aten.add.Tensor(mul_347, mul_348);  mul_347 = mul_348 = None
    slice_133 = torch.ops.aten.slice.Tensor(constant_pad_nd_66, 2, 2, 133)
    select_315 = torch.ops.aten.select.int(convert_element_type_547, 1, 0)
    select_316 = torch.ops.aten.select.int(select_315, 1, 2);  select_315 = None
    view_790 = torch.ops.aten.reshape.default(select_316, [1, -1, 1]);  select_316 = None
    mul_349 = torch.ops.aten.mul.Tensor(slice_133, view_790);  slice_133 = view_790 = None
    add_271 = torch.ops.aten.add.Tensor(add_270, mul_349);  add_270 = mul_349 = None
    slice_134 = torch.ops.aten.slice.Tensor(constant_pad_nd_66, 2, 3, 134);  constant_pad_nd_66 = None
    select_317 = torch.ops.aten.select.int(convert_element_type_547, 1, 0);  convert_element_type_547 = None
    select_318 = torch.ops.aten.select.int(select_317, 1, 3);  select_317 = None
    view_791 = torch.ops.aten.reshape.default(select_318, [1, -1, 1]);  select_318 = None
    mul_350 = torch.ops.aten.mul.Tensor(slice_134, view_791);  slice_134 = view_791 = None
    add_272 = torch.ops.aten.add.Tensor(add_271, mul_350);  add_271 = mul_350 = None
    convert_element_type_548 = torch.ops.prims.convert_element_type.default(add_272, torch.bfloat16);  add_272 = None
    slice_135 = torch.ops.aten.slice.Tensor(convert_element_type_548, 2, 0, 128);  convert_element_type_548 = None
    convert_element_type_549 = torch.ops.prims.convert_element_type.default(slice_135, torch.float32);  slice_135 = None
    neg_53 = torch.ops.aten.neg.default(convert_element_type_549)
    exp_116 = torch.ops.aten.exp.default(neg_53);  neg_53 = None
    add_273 = torch.ops.aten.add.Tensor(exp_116, 1);  exp_116 = None
    div_39 = torch.ops.aten.div.Tensor(convert_element_type_549, add_273);  convert_element_type_549 = add_273 = None
    convert_element_type_550 = torch.ops.prims.convert_element_type.default(div_39, torch.bfloat16);  div_39 = None
    slice_136 = torch.ops.aten.slice.Tensor(convert_element_type_550, 2, -128, 9223372036854775807);  convert_element_type_550 = None
    permute_272 = torch.ops.aten.permute.default(slice_136, [0, 2, 1]);  slice_136 = None
    split_with_sizes_11 = torch.ops.aten.split_with_sizes.default(permute_272, [2048, 2048, 2048], -1);  permute_272 = None
    getitem_39 = split_with_sizes_11[0]
    getitem_40 = split_with_sizes_11[1]
    getitem_41 = split_with_sizes_11[2];  split_with_sizes_11 = None
    full_35 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_117 = torch.ops.aten.exp.default(arg229_1);  arg229_1 = None
    neg_54 = torch.ops.aten.neg.default(exp_117);  exp_117 = None
    view_786 = torch.ops.aten.reshape.default(convert_element_type_537, [128, 2048])
    permute_271 = torch.ops.aten.permute.default(arg226_1, [1, 0]);  arg226_1 = None
    mm_112 = torch.ops.aten.mm.default(view_786, permute_271);  view_786 = permute_271 = None
    view_787 = torch.ops.aten.reshape.default(mm_112, [1, 128, 16]);  mm_112 = None
    convert_element_type_551 = torch.ops.prims.convert_element_type.default(view_787, torch.float32);  view_787 = None
    add_274 = torch.ops.aten.add.Tensor(convert_element_type_551, arg230_1);  convert_element_type_551 = arg230_1 = None
    gt_11 = torch.ops.aten.gt.Scalar(add_274, 20)
    exp_118 = torch.ops.aten.exp.default(add_274)
    log1p_11 = torch.ops.aten.log1p.default(exp_118);  exp_118 = None
    where_23 = torch.ops.aten.where.self(gt_11, add_274, log1p_11);  gt_11 = add_274 = log1p_11 = None
    mul_351 = torch.ops.aten.mul.Tensor(neg_54, where_23);  neg_54 = where_23 = None
    permute_277 = torch.ops.aten.permute.default(mul_351, [0, 2, 1]);  mul_351 = None
    view_799 = torch.ops.aten.reshape.default(permute_277, [1, 16, 2, 64]);  permute_277 = None
    cumsum_11 = torch.ops.aten.cumsum.default(view_799, 3);  view_799 = None
    select_319 = torch.ops.aten.select.int(cumsum_11, 3, -1)
    exp_123 = torch.ops.aten.exp.default(select_319);  select_319 = None
    unsqueeze_174 = torch.ops.aten.unsqueeze.default(exp_123, 3);  exp_123 = None
    unsqueeze_175 = torch.ops.aten.unsqueeze.default(unsqueeze_174, 4);  unsqueeze_174 = None
    select_326 = torch.ops.aten.select.int(unsqueeze_175, 2, 0)
    mul_364 = torch.ops.aten.mul.Tensor(full_35, select_326);  select_326 = None
    view_793 = torch.ops.aten.reshape.default(getitem_40, [1, 128, 16, 128]);  getitem_40 = None
    permute_274 = torch.ops.aten.permute.default(view_793, [0, 2, 1, 3]);  view_793 = None
    convert_element_type_553 = torch.ops.prims.convert_element_type.default(permute_274, torch.float32);  permute_274 = None
    clone_94 = torch.ops.aten.clone.default(convert_element_type_553, memory_format = torch.contiguous_format);  convert_element_type_553 = None
    mul_354 = torch.ops.aten.mul.Tensor(clone_94, clone_94)
    sum_27 = torch.ops.aten.sum.dim_IntList(mul_354, [-1], True);  mul_354 = None
    add_276 = torch.ops.aten.add.Tensor(sum_27, 1e-06);  sum_27 = None
    rsqrt_69 = torch.ops.aten.rsqrt.default(add_276);  add_276 = None
    mul_355 = torch.ops.aten.mul.Tensor(clone_94, rsqrt_69);  clone_94 = rsqrt_69 = None
    view_796 = torch.ops.aten.reshape.default(mul_355, [1, 16, -1, 64, 128])
    slice_137 = torch.ops.aten.slice.Tensor(cumsum_11, 3, -1, 9223372036854775807)
    sub_60 = torch.ops.aten.sub.Tensor(slice_137, cumsum_11);  slice_137 = None
    exp_122 = torch.ops.aten.exp.default(sub_60);  sub_60 = None
    unsqueeze_173 = torch.ops.aten.unsqueeze.default(exp_122, -1);  exp_122 = None
    mul_363 = torch.ops.aten.mul.Tensor(view_796, unsqueeze_173);  unsqueeze_173 = None
    select_327 = torch.ops.aten.select.int(mul_363, 2, 0)
    permute_281 = torch.ops.aten.permute.default(select_327, [0, 1, 3, 2]);  select_327 = None
    expand_258 = torch.ops.aten.expand.default(permute_281, [1, 16, 128, 64]);  permute_281 = None
    view_815 = torch.ops.aten.reshape.default(expand_258, [16, 128, 64]);  expand_258 = None
    view_784 = torch.ops.aten.reshape.default(convert_element_type_537, [128, 2048])
    permute_270 = torch.ops.aten.permute.default(arg225_1, [1, 0]);  arg225_1 = None
    mm_111 = torch.ops.aten.mm.default(view_784, permute_270);  view_784 = permute_270 = None
    view_785 = torch.ops.aten.reshape.default(mm_111, [1, 128, 16]);  mm_111 = None
    sigmoid_14 = torch.ops.aten.sigmoid.default(view_785);  view_785 = None
    permute_276 = torch.ops.aten.permute.default(sigmoid_14, [0, 2, 1]);  sigmoid_14 = None
    convert_element_type_555 = torch.ops.prims.convert_element_type.default(permute_276, torch.float32);  permute_276 = None
    clone_96 = torch.ops.aten.clone.default(convert_element_type_555, memory_format = torch.contiguous_format);  convert_element_type_555 = None
    unsqueeze_166 = torch.ops.aten.unsqueeze.default(clone_96, -1)
    mul_358 = torch.ops.aten.mul.Tensor(mul_355, unsqueeze_166);  mul_355 = unsqueeze_166 = None
    view_797 = torch.ops.aten.reshape.default(mul_358, [1, 16, -1, 64, 128]);  mul_358 = None
    expand_248 = torch.ops.aten.expand.default(view_797, [1, 16, 2, 64, 128])
    view_800 = torch.ops.aten.reshape.default(expand_248, [32, 64, 128]);  expand_248 = None
    permute_278 = torch.ops.aten.permute.default(view_796, [0, 1, 2, 4, 3])
    expand_249 = torch.ops.aten.expand.default(permute_278, [1, 16, 2, 128, 64]);  permute_278 = None
    view_801 = torch.ops.aten.reshape.default(expand_249, [32, 128, 64]);  expand_249 = None
    bmm_116 = torch.ops.aten.bmm.default(view_800, view_801);  view_800 = view_801 = None
    view_802 = torch.ops.aten.reshape.default(bmm_116, [1, 16, 2, 64, 64]);  bmm_116 = None
    iota_26 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_167 = torch.ops.aten.unsqueeze.default(iota_26, -2);  iota_26 = None
    iota_27 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_168 = torch.ops.aten.unsqueeze.default(iota_27, -1);  iota_27 = None
    sub_58 = torch.ops.aten.sub.Tensor(unsqueeze_167, unsqueeze_168);  unsqueeze_167 = unsqueeze_168 = None
    ge_11 = torch.ops.aten.ge.Scalar(sub_58, 1);  sub_58 = None
    full_default_24 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_11 = torch.ops.aten.logical_and.default(ge_11, full_default_24);  ge_11 = full_default_24 = None
    full_default_25 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_169 = torch.ops.aten.unsqueeze.default(cumsum_11, 4)
    unsqueeze_170 = torch.ops.aten.unsqueeze.default(cumsum_11, 3)
    sub_59 = torch.ops.aten.sub.Tensor(unsqueeze_169, unsqueeze_170);  unsqueeze_169 = unsqueeze_170 = None
    where_24 = torch.ops.aten.where.self(logical_and_11, full_default_25, sub_59);  logical_and_11 = full_default_25 = sub_59 = None
    exp_119 = torch.ops.aten.exp.default(where_24);  where_24 = None
    mul_359 = torch.ops.aten.mul.Tensor(view_802, exp_119);  view_802 = None
    view_794 = torch.ops.aten.reshape.default(getitem_41, [1, 128, 16, 128]);  getitem_41 = None
    permute_275 = torch.ops.aten.permute.default(view_794, [0, 2, 1, 3]);  view_794 = None
    convert_element_type_554 = torch.ops.prims.convert_element_type.default(permute_275, torch.float32);  permute_275 = None
    clone_95 = torch.ops.aten.clone.default(convert_element_type_554, memory_format = torch.contiguous_format);  convert_element_type_554 = None
    unsqueeze_165 = torch.ops.aten.unsqueeze.default(clone_96, -1);  clone_96 = None
    mul_357 = torch.ops.aten.mul.Tensor(clone_95, unsqueeze_165);  clone_95 = unsqueeze_165 = None
    view_798 = torch.ops.aten.reshape.default(mul_357, [1, 16, -1, 64, 128]);  mul_357 = None
    linalg_solve_triangular_22 = torch.ops.aten.linalg_solve_triangular.default(mul_359, view_798, upper = False, unitriangular = True);  view_798 = None
    select_320 = torch.ops.aten.select.int(linalg_solve_triangular_22, 2, 0)
    exp_120 = torch.ops.aten.exp.default(cumsum_11)
    unsqueeze_171 = torch.ops.aten.unsqueeze.default(exp_120, -1);  exp_120 = None
    mul_361 = torch.ops.aten.mul.Tensor(view_797, unsqueeze_171);  view_797 = unsqueeze_171 = None
    linalg_solve_triangular_23 = torch.ops.aten.linalg_solve_triangular.default(mul_359, mul_361, upper = False, unitriangular = True);  mul_359 = mul_361 = None
    select_321 = torch.ops.aten.select.int(linalg_solve_triangular_23, 2, 0)
    expand_252 = torch.ops.aten.expand.default(select_321, [1, 16, 64, 128]);  select_321 = None
    view_806 = torch.ops.aten.reshape.default(expand_252, [16, 64, 128]);  expand_252 = None
    expand_253 = torch.ops.aten.expand.default(full_35, [1, 16, 128, 128])
    view_807 = torch.ops.aten.reshape.default(expand_253, [16, 128, 128]);  expand_253 = None
    bmm_118 = torch.ops.aten.bmm.default(view_806, view_807);  view_806 = view_807 = None
    view_808 = torch.ops.aten.reshape.default(bmm_118, [1, 16, 64, 128]);  bmm_118 = None
    sub_61 = torch.ops.aten.sub.Tensor(select_320, view_808);  select_320 = view_808 = None
    expand_259 = torch.ops.aten.expand.default(sub_61, [1, 16, 64, 128])
    view_816 = torch.ops.aten.reshape.default(expand_259, [16, 64, 128]);  expand_259 = None
    bmm_121 = torch.ops.aten.bmm.default(view_815, view_816);  view_815 = view_816 = None
    view_817 = torch.ops.aten.reshape.default(bmm_121, [1, 16, 128, 128]);  bmm_121 = None
    add_278 = torch.ops.aten.add.Tensor(mul_364, view_817);  mul_364 = view_817 = None
    select_335 = torch.ops.aten.select.int(unsqueeze_175, 2, 1);  unsqueeze_175 = None
    mul_365 = torch.ops.aten.mul.Tensor(add_278, select_335);  select_335 = None
    select_336 = torch.ops.aten.select.int(mul_363, 2, 1);  mul_363 = None
    permute_282 = torch.ops.aten.permute.default(select_336, [0, 1, 3, 2]);  select_336 = None
    expand_266 = torch.ops.aten.expand.default(permute_282, [1, 16, 128, 64]);  permute_282 = None
    view_827 = torch.ops.aten.reshape.default(expand_266, [16, 128, 64]);  expand_266 = None
    select_328 = torch.ops.aten.select.int(linalg_solve_triangular_22, 2, 1);  linalg_solve_triangular_22 = None
    select_329 = torch.ops.aten.select.int(linalg_solve_triangular_23, 2, 1);  linalg_solve_triangular_23 = None
    expand_260 = torch.ops.aten.expand.default(select_329, [1, 16, 64, 128]);  select_329 = None
    view_818 = torch.ops.aten.reshape.default(expand_260, [16, 64, 128]);  expand_260 = None
    expand_261 = torch.ops.aten.expand.default(add_278, [1, 16, 128, 128])
    view_819 = torch.ops.aten.reshape.default(expand_261, [16, 128, 128]);  expand_261 = None
    bmm_122 = torch.ops.aten.bmm.default(view_818, view_819);  view_818 = view_819 = None
    view_820 = torch.ops.aten.reshape.default(bmm_122, [1, 16, 64, 128]);  bmm_122 = None
    sub_62 = torch.ops.aten.sub.Tensor(select_328, view_820);  select_328 = view_820 = None
    expand_267 = torch.ops.aten.expand.default(sub_62, [1, 16, 64, 128])
    view_828 = torch.ops.aten.reshape.default(expand_267, [16, 64, 128]);  expand_267 = None
    bmm_125 = torch.ops.aten.bmm.default(view_827, view_828);  view_827 = view_828 = None
    view_829 = torch.ops.aten.reshape.default(bmm_125, [1, 16, 128, 128]);  bmm_125 = None
    add_280 = torch.ops.aten.add.Tensor(mul_365, view_829);  mul_365 = view_829 = None
    full_36 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_280 = torch.ops.aten.permute.default(full_36, [0, 1, 2, 4, 3]);  full_36 = None
    select_324 = torch.ops.aten.select.int(permute_280, 2, 0)
    view_792 = torch.ops.aten.reshape.default(getitem_39, [1, 128, 16, 128]);  getitem_39 = None
    permute_273 = torch.ops.aten.permute.default(view_792, [0, 2, 1, 3]);  view_792 = None
    convert_element_type_552 = torch.ops.prims.convert_element_type.default(permute_273, torch.float32);  permute_273 = None
    clone_93 = torch.ops.aten.clone.default(convert_element_type_552, memory_format = torch.contiguous_format);  convert_element_type_552 = None
    mul_352 = torch.ops.aten.mul.Tensor(clone_93, clone_93)
    sum_26 = torch.ops.aten.sum.dim_IntList(mul_352, [-1], True);  mul_352 = None
    add_275 = torch.ops.aten.add.Tensor(sum_26, 1e-06);  sum_26 = None
    rsqrt_68 = torch.ops.aten.rsqrt.default(add_275);  add_275 = None
    mul_353 = torch.ops.aten.mul.Tensor(clone_93, rsqrt_68);  clone_93 = rsqrt_68 = None
    mul_356 = torch.ops.aten.mul.Tensor(mul_353, 0.08838834764831845);  mul_353 = None
    view_795 = torch.ops.aten.reshape.default(mul_356, [1, 16, -1, 64, 128]);  mul_356 = None
    exp_121 = torch.ops.aten.exp.default(cumsum_11);  cumsum_11 = None
    unsqueeze_172 = torch.ops.aten.unsqueeze.default(exp_121, -1);  exp_121 = None
    mul_362 = torch.ops.aten.mul.Tensor(view_795, unsqueeze_172);  unsqueeze_172 = None
    select_322 = torch.ops.aten.select.int(mul_362, 2, 0)
    expand_254 = torch.ops.aten.expand.default(select_322, [1, 16, 64, 128]);  select_322 = None
    view_809 = torch.ops.aten.reshape.default(expand_254, [16, 64, 128]);  expand_254 = None
    expand_255 = torch.ops.aten.expand.default(full_35, [1, 16, 128, 128]);  full_35 = None
    view_810 = torch.ops.aten.reshape.default(expand_255, [16, 128, 128]);  expand_255 = None
    bmm_119 = torch.ops.aten.bmm.default(view_809, view_810);  view_809 = view_810 = None
    view_811 = torch.ops.aten.reshape.default(bmm_119, [1, 16, 64, 128]);  bmm_119 = None
    expand_250 = torch.ops.aten.expand.default(view_795, [1, 16, 2, 64, 128]);  view_795 = None
    view_803 = torch.ops.aten.reshape.default(expand_250, [32, 64, 128]);  expand_250 = None
    permute_279 = torch.ops.aten.permute.default(view_796, [0, 1, 2, 4, 3]);  view_796 = None
    expand_251 = torch.ops.aten.expand.default(permute_279, [1, 16, 2, 128, 64]);  permute_279 = None
    view_804 = torch.ops.aten.reshape.default(expand_251, [32, 128, 64]);  expand_251 = None
    bmm_117 = torch.ops.aten.bmm.default(view_803, view_804);  view_803 = view_804 = None
    view_805 = torch.ops.aten.reshape.default(bmm_117, [1, 16, 2, 64, 64]);  bmm_117 = None
    mul_360 = torch.ops.aten.mul.Tensor(view_805, exp_119);  view_805 = exp_119 = None
    select_323 = torch.ops.aten.select.int(mul_360, 2, 0)
    expand_256 = torch.ops.aten.expand.default(select_323, [1, 16, 64, 64]);  select_323 = None
    view_812 = torch.ops.aten.reshape.default(expand_256, [16, 64, 64]);  expand_256 = None
    expand_257 = torch.ops.aten.expand.default(sub_61, [1, 16, 64, 128]);  sub_61 = None
    view_813 = torch.ops.aten.reshape.default(expand_257, [16, 64, 128]);  expand_257 = None
    bmm_120 = torch.ops.aten.bmm.default(view_812, view_813);  view_812 = view_813 = None
    view_814 = torch.ops.aten.reshape.default(bmm_120, [1, 16, 64, 128]);  bmm_120 = None
    add_277 = torch.ops.aten.add.Tensor(view_811, view_814);  view_811 = view_814 = None
    copy_49 = torch.ops.aten.copy.default(select_324, add_277);  select_324 = add_277 = None
    select_scatter_default_26 = torch.ops.aten.select_scatter.default(permute_280, copy_49, 2, 0);  permute_280 = copy_49 = None
    select_333 = torch.ops.aten.select.int(select_scatter_default_26, 2, 1)
    select_330 = torch.ops.aten.select.int(mul_362, 2, 1);  mul_362 = None
    expand_262 = torch.ops.aten.expand.default(select_330, [1, 16, 64, 128]);  select_330 = None
    view_821 = torch.ops.aten.reshape.default(expand_262, [16, 64, 128]);  expand_262 = None
    expand_263 = torch.ops.aten.expand.default(add_278, [1, 16, 128, 128]);  add_278 = None
    view_822 = torch.ops.aten.reshape.default(expand_263, [16, 128, 128]);  expand_263 = None
    bmm_123 = torch.ops.aten.bmm.default(view_821, view_822);  view_821 = view_822 = None
    view_823 = torch.ops.aten.reshape.default(bmm_123, [1, 16, 64, 128]);  bmm_123 = None
    select_331 = torch.ops.aten.select.int(mul_360, 2, 1);  mul_360 = None
    expand_264 = torch.ops.aten.expand.default(select_331, [1, 16, 64, 64]);  select_331 = None
    view_824 = torch.ops.aten.reshape.default(expand_264, [16, 64, 64]);  expand_264 = None
    expand_265 = torch.ops.aten.expand.default(sub_62, [1, 16, 64, 128]);  sub_62 = None
    view_825 = torch.ops.aten.reshape.default(expand_265, [16, 64, 128]);  expand_265 = None
    bmm_124 = torch.ops.aten.bmm.default(view_824, view_825);  view_824 = view_825 = None
    view_826 = torch.ops.aten.reshape.default(bmm_124, [1, 16, 64, 128]);  bmm_124 = None
    add_279 = torch.ops.aten.add.Tensor(view_823, view_826);  view_823 = view_826 = None
    copy_50 = torch.ops.aten.copy.default(select_333, add_279);  select_333 = add_279 = None
    select_scatter_default_27 = torch.ops.aten.select_scatter.default(select_scatter_default_26, copy_50, 2, 1);  select_scatter_default_26 = copy_50 = None
    clone_98 = torch.ops.aten.clone.default(select_scatter_default_27, memory_format = torch.contiguous_format);  select_scatter_default_27 = None
    view_830 = torch.ops.aten.reshape.default(clone_98, [1, 16, 128, 128]);  clone_98 = None
    permute_283 = torch.ops.aten.permute.default(view_830, [0, 2, 1, 3]);  view_830 = None
    convert_element_type_556 = torch.ops.prims.convert_element_type.default(permute_283, torch.bfloat16);  permute_283 = None
    clone_99 = torch.ops.aten.clone.default(convert_element_type_556, memory_format = torch.contiguous_format);  convert_element_type_556 = None
    view_831 = torch.ops.aten.reshape.default(clone_99, [-1, 128]);  clone_99 = None
    convert_element_type_557 = torch.ops.prims.convert_element_type.default(view_831, torch.float32);  view_831 = None
    pow_47 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_557, 2)
    mean_46 = torch.ops.aten.mean.dim(pow_47, [-1], True);  pow_47 = None
    add_281 = torch.ops.aten.add.Tensor(mean_46, 1e-06);  mean_46 = None
    rsqrt_70 = torch.ops.aten.rsqrt.default(add_281);  add_281 = None
    mul_366 = torch.ops.aten.mul.Tensor(convert_element_type_557, rsqrt_70);  convert_element_type_557 = rsqrt_70 = None
    convert_element_type_558 = torch.ops.prims.convert_element_type.default(mul_366, torch.bfloat16);  mul_366 = None
    mul_367 = torch.ops.aten.mul.Tensor(arg232_1, convert_element_type_558);  arg232_1 = convert_element_type_558 = None
    view_781 = torch.ops.aten.reshape.default(convert_element_type_537, [128, 2048]);  convert_element_type_537 = None
    permute_269 = torch.ops.aten.permute.default(arg224_1, [1, 0]);  arg224_1 = None
    mm_110 = torch.ops.aten.mm.default(view_781, permute_269);  view_781 = permute_269 = None
    view_782 = torch.ops.aten.reshape.default(mm_110, [1, 128, 2048]);  mm_110 = None
    view_783 = torch.ops.aten.reshape.default(view_782, [1, 128, -1, 128]);  view_782 = None
    view_832 = torch.ops.aten.reshape.default(view_783, [-1, 128]);  view_783 = None
    convert_element_type_559 = torch.ops.prims.convert_element_type.default(view_832, torch.float32);  view_832 = None
    neg_55 = torch.ops.aten.neg.default(convert_element_type_559)
    exp_124 = torch.ops.aten.exp.default(neg_55);  neg_55 = None
    add_282 = torch.ops.aten.add.Tensor(exp_124, 1);  exp_124 = None
    div_40 = torch.ops.aten.div.Tensor(convert_element_type_559, add_282);  convert_element_type_559 = add_282 = None
    mul_368 = torch.ops.aten.mul.Tensor(mul_367, div_40);  mul_367 = div_40 = None
    convert_element_type_560 = torch.ops.prims.convert_element_type.default(mul_368, torch.bfloat16);  mul_368 = None
    view_833 = torch.ops.aten.reshape.default(convert_element_type_560, [1, 128, -1]);  convert_element_type_560 = None
    view_834 = torch.ops.aten.reshape.default(view_833, [128, 2048]);  view_833 = None
    permute_284 = torch.ops.aten.permute.default(arg233_1, [1, 0]);  arg233_1 = None
    mm_113 = torch.ops.aten.mm.default(view_834, permute_284);  view_834 = permute_284 = None
    view_835 = torch.ops.aten.reshape.default(mm_113, [1, 128, 2048]);  mm_113 = None
    add_283 = torch.ops.aten.add.Tensor(add_267, view_835);  add_267 = view_835 = None
    convert_element_type_563 = torch.ops.prims.convert_element_type.default(add_283, torch.float32)
    pow_48 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_563, 2)
    mean_47 = torch.ops.aten.mean.dim(pow_48, [-1], True);  pow_48 = None
    add_284 = torch.ops.aten.add.Tensor(mean_47, 1e-06);  mean_47 = None
    rsqrt_71 = torch.ops.aten.rsqrt.default(add_284);  add_284 = None
    mul_369 = torch.ops.aten.mul.Tensor(convert_element_type_563, rsqrt_71);  convert_element_type_563 = rsqrt_71 = None
    convert_element_type_564 = torch.ops.prims.convert_element_type.default(arg234_1, torch.float32);  arg234_1 = None
    add_285 = torch.ops.aten.add.Tensor(convert_element_type_564, 1.0);  convert_element_type_564 = None
    mul_370 = torch.ops.aten.mul.Tensor(mul_369, add_285);  mul_369 = add_285 = None
    convert_element_type_565 = torch.ops.prims.convert_element_type.default(mul_370, torch.bfloat16);  mul_370 = None
    view_836 = torch.ops.aten.reshape.default(convert_element_type_565, [128, 2048])
    permute_285 = torch.ops.aten.permute.default(arg235_1, [1, 0]);  arg235_1 = None
    mm_114 = torch.ops.aten.mm.default(view_836, permute_285);  view_836 = permute_285 = None
    view_837 = torch.ops.aten.reshape.default(mm_114, [1, 128, 6144]);  mm_114 = None
    convert_element_type_568 = torch.ops.prims.convert_element_type.default(view_837, torch.float32);  view_837 = None
    neg_56 = torch.ops.aten.neg.default(convert_element_type_568)
    exp_125 = torch.ops.aten.exp.default(neg_56);  neg_56 = None
    add_286 = torch.ops.aten.add.Tensor(exp_125, 1);  exp_125 = None
    div_41 = torch.ops.aten.div.Tensor(convert_element_type_568, add_286);  convert_element_type_568 = add_286 = None
    convert_element_type_569 = torch.ops.prims.convert_element_type.default(div_41, torch.bfloat16);  div_41 = None
    view_838 = torch.ops.aten.reshape.default(convert_element_type_565, [128, 2048]);  convert_element_type_565 = None
    permute_286 = torch.ops.aten.permute.default(arg236_1, [1, 0]);  arg236_1 = None
    mm_115 = torch.ops.aten.mm.default(view_838, permute_286);  view_838 = permute_286 = None
    view_839 = torch.ops.aten.reshape.default(mm_115, [1, 128, 6144]);  mm_115 = None
    mul_371 = torch.ops.aten.mul.Tensor(convert_element_type_569, view_839);  convert_element_type_569 = view_839 = None
    view_840 = torch.ops.aten.reshape.default(mul_371, [128, 6144]);  mul_371 = None
    permute_287 = torch.ops.aten.permute.default(arg237_1, [1, 0]);  arg237_1 = None
    mm_116 = torch.ops.aten.mm.default(view_840, permute_287);  view_840 = permute_287 = None
    view_841 = torch.ops.aten.reshape.default(mm_116, [1, 128, 2048]);  mm_116 = None
    add_287 = torch.ops.aten.add.Tensor(add_283, view_841);  add_283 = view_841 = None
    convert_element_type_574 = torch.ops.prims.convert_element_type.default(add_287, torch.float32)
    pow_49 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_574, 2)
    mean_48 = torch.ops.aten.mean.dim(pow_49, [-1], True);  pow_49 = None
    add_288 = torch.ops.aten.add.Tensor(mean_48, 1e-06);  mean_48 = None
    rsqrt_72 = torch.ops.aten.rsqrt.default(add_288);  add_288 = None
    mul_372 = torch.ops.aten.mul.Tensor(convert_element_type_574, rsqrt_72);  convert_element_type_574 = rsqrt_72 = None
    convert_element_type_575 = torch.ops.prims.convert_element_type.default(arg238_1, torch.float32);  arg238_1 = None
    add_289 = torch.ops.aten.add.Tensor(convert_element_type_575, 1.0);  convert_element_type_575 = None
    mul_373 = torch.ops.aten.mul.Tensor(mul_372, add_289);  mul_372 = add_289 = None
    convert_element_type_576 = torch.ops.prims.convert_element_type.default(mul_373, torch.bfloat16);  mul_373 = None
    view_842 = torch.ops.aten.reshape.default(convert_element_type_576, [128, 2048])
    permute_288 = torch.ops.aten.permute.default(arg239_1, [1, 0]);  arg239_1 = None
    mm_117 = torch.ops.aten.mm.default(view_842, permute_288);  view_842 = permute_288 = None
    view_843 = torch.ops.aten.reshape.default(mm_117, [1, 128, 4096]);  mm_117 = None
    view_844 = torch.ops.aten.reshape.default(view_843, [1, 128, -1, 512]);  view_843 = None
    split_3 = torch.ops.aten.split.Tensor(view_844, 256, -1);  view_844 = None
    getitem_42 = split_3[0]
    getitem_43 = split_3[1];  split_3 = None
    add_297 = torch.ops.aten.add.Tensor(arg244_1, 128)
    convert_element_type_579 = torch.ops.prims.convert_element_type.default(getitem_42, torch.float32);  getitem_42 = None
    pow_50 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_579, 2)
    mean_49 = torch.ops.aten.mean.dim(pow_50, [-1], True);  pow_50 = None
    add_290 = torch.ops.aten.add.Tensor(mean_49, 1e-06);  mean_49 = None
    rsqrt_73 = torch.ops.aten.rsqrt.default(add_290);  add_290 = None
    mul_374 = torch.ops.aten.mul.Tensor(convert_element_type_579, rsqrt_73);  convert_element_type_579 = rsqrt_73 = None
    convert_element_type_580 = torch.ops.prims.convert_element_type.default(arg240_1, torch.float32);  arg240_1 = None
    add_291 = torch.ops.aten.add.Tensor(convert_element_type_580, 1.0);  convert_element_type_580 = None
    mul_375 = torch.ops.aten.mul.Tensor(mul_374, add_291);  mul_374 = add_291 = None
    convert_element_type_581 = torch.ops.prims.convert_element_type.default(mul_375, torch.bfloat16);  mul_375 = None
    permute_289 = torch.ops.aten.permute.default(convert_element_type_581, [0, 2, 1, 3]);  convert_element_type_581 = None
    slice_138 = torch.ops.aten.slice.Tensor(permute_289, 3, 0, 64)
    unsqueeze_176 = torch.ops.aten.unsqueeze.default(convert_element_type_2, 1)
    mul_378 = torch.ops.aten.mul.Tensor(slice_138, unsqueeze_176)
    slice_143 = torch.ops.aten.slice.Tensor(slice_138, 3, 32, 9223372036854775807)
    neg_57 = torch.ops.aten.neg.default(slice_143);  slice_143 = None
    slice_142 = torch.ops.aten.slice.Tensor(slice_138, 3, 0, 32);  slice_138 = None
    cat_12 = torch.ops.aten.cat.default([neg_57, slice_142], -1);  neg_57 = slice_142 = None
    unsqueeze_177 = torch.ops.aten.unsqueeze.default(convert_element_type_3, 1)
    mul_379 = torch.ops.aten.mul.Tensor(cat_12, unsqueeze_177);  cat_12 = None
    add_294 = torch.ops.aten.add.Tensor(mul_378, mul_379);  mul_378 = mul_379 = None
    slice_139 = torch.ops.aten.slice.Tensor(permute_289, 3, 64, 9223372036854775807);  permute_289 = None
    cat_14 = torch.ops.aten.cat.default([add_294, slice_139], -1);  add_294 = slice_139 = None
    expand_272 = torch.ops.aten.expand.default(cat_14, [1, 8, 128, 256]);  cat_14 = None
    view_855 = torch.ops.aten.reshape.default(expand_272, [8, 128, 256]);  expand_272 = None
    iota_28 = torch.ops.prims.iota.default(128, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    add_296 = torch.ops.aten.add.Tensor(iota_28, arg244_1);  iota_28 = None
    view_847 = torch.ops.aten.reshape.default(convert_element_type_576, [128, 2048])
    permute_290 = torch.ops.aten.permute.default(arg241_1, [1, 0]);  arg241_1 = None
    mm_118 = torch.ops.aten.mm.default(view_847, permute_290);  view_847 = permute_290 = None
    view_848 = torch.ops.aten.reshape.default(mm_118, [1, 128, 512]);  mm_118 = None
    view_849 = torch.ops.aten.reshape.default(view_848, [1, 128, -1, 256]);  view_848 = None
    convert_element_type_584 = torch.ops.prims.convert_element_type.default(view_849, torch.float32);  view_849 = None
    pow_51 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_584, 2)
    mean_50 = torch.ops.aten.mean.dim(pow_51, [-1], True);  pow_51 = None
    add_292 = torch.ops.aten.add.Tensor(mean_50, 1e-06);  mean_50 = None
    rsqrt_74 = torch.ops.aten.rsqrt.default(add_292);  add_292 = None
    mul_376 = torch.ops.aten.mul.Tensor(convert_element_type_584, rsqrt_74);  convert_element_type_584 = rsqrt_74 = None
    convert_element_type_585 = torch.ops.prims.convert_element_type.default(arg242_1, torch.float32);  arg242_1 = None
    add_293 = torch.ops.aten.add.Tensor(convert_element_type_585, 1.0);  convert_element_type_585 = None
    mul_377 = torch.ops.aten.mul.Tensor(mul_376, add_293);  mul_376 = add_293 = None
    convert_element_type_586 = torch.ops.prims.convert_element_type.default(mul_377, torch.bfloat16);  mul_377 = None
    permute_291 = torch.ops.aten.permute.default(convert_element_type_586, [0, 2, 1, 3]);  convert_element_type_586 = None
    slice_140 = torch.ops.aten.slice.Tensor(permute_291, 3, 0, 64)
    mul_380 = torch.ops.aten.mul.Tensor(slice_140, unsqueeze_176);  unsqueeze_176 = None
    slice_145 = torch.ops.aten.slice.Tensor(slice_140, 3, 32, 9223372036854775807)
    neg_58 = torch.ops.aten.neg.default(slice_145);  slice_145 = None
    slice_144 = torch.ops.aten.slice.Tensor(slice_140, 3, 0, 32);  slice_140 = None
    cat_13 = torch.ops.aten.cat.default([neg_58, slice_144], -1);  neg_58 = slice_144 = None
    mul_381 = torch.ops.aten.mul.Tensor(cat_13, unsqueeze_177);  cat_13 = unsqueeze_177 = None
    add_295 = torch.ops.aten.add.Tensor(mul_380, mul_381);  mul_380 = mul_381 = None
    slice_141 = torch.ops.aten.slice.Tensor(permute_291, 3, 64, 9223372036854775807);  permute_291 = None
    cat_15 = torch.ops.aten.cat.default([add_295, slice_141], -1);  add_295 = slice_141 = None
    index_put_6 = torch.ops.aten.index_put_.default(arg245_1, [None, None, add_296], cat_15);  arg245_1 = cat_15 = None
    unsqueeze_180 = torch.ops.aten.unsqueeze.default(index_put_6, 2);  index_put_6 = None
    expand_269 = torch.ops.aten.expand.default(unsqueeze_180, [1, 2, 4, 144, 256]);  unsqueeze_180 = None
    clone_101 = torch.ops.aten.clone.default(expand_269, memory_format = torch.contiguous_format);  expand_269 = None
    view_853 = torch.ops.aten.reshape.default(clone_101, [1, 8, 144, 256]);  clone_101 = None
    permute_294 = torch.ops.aten.permute.default(view_853, [0, 1, 3, 2]);  view_853 = None
    expand_273 = torch.ops.aten.expand.default(permute_294, [1, 8, 256, 144]);  permute_294 = None
    view_856 = torch.ops.aten.reshape.default(expand_273, [8, 256, 144]);  expand_273 = None
    bmm_126 = torch.ops.aten.bmm.default(view_855, view_856);  view_855 = view_856 = None
    view_857 = torch.ops.aten.reshape.default(bmm_126, [1, 8, 128, 144]);  bmm_126 = None
    mul_382 = torch.ops.aten.mul.Tensor(view_857, 0.0625);  view_857 = None
    add_298 = torch.ops.aten.add.Tensor(mul_382, unsqueeze_3);  mul_382 = None
    convert_element_type_591 = torch.ops.prims.convert_element_type.default(add_298, torch.float32);  add_298 = None
    amax_3 = torch.ops.aten.amax.default(convert_element_type_591, [-1], True)
    sub_63 = torch.ops.aten.sub.Tensor(convert_element_type_591, amax_3);  convert_element_type_591 = amax_3 = None
    exp_126 = torch.ops.aten.exp.default(sub_63);  sub_63 = None
    sum_28 = torch.ops.aten.sum.dim_IntList(exp_126, [-1], True)
    div_42 = torch.ops.aten.div.Tensor(exp_126, sum_28);  exp_126 = sum_28 = None
    convert_element_type_592 = torch.ops.prims.convert_element_type.default(div_42, torch.bfloat16);  div_42 = None
    expand_274 = torch.ops.aten.expand.default(convert_element_type_592, [1, 8, 128, 144]);  convert_element_type_592 = None
    view_858 = torch.ops.aten.reshape.default(expand_274, [8, 128, 144]);  expand_274 = None
    view_850 = torch.ops.aten.reshape.default(convert_element_type_576, [128, 2048]);  convert_element_type_576 = None
    permute_292 = torch.ops.aten.permute.default(arg243_1, [1, 0]);  arg243_1 = None
    mm_119 = torch.ops.aten.mm.default(view_850, permute_292);  view_850 = permute_292 = None
    view_851 = torch.ops.aten.reshape.default(mm_119, [1, 128, 512]);  mm_119 = None
    view_852 = torch.ops.aten.reshape.default(view_851, [1, 128, -1, 256]);  view_851 = None
    permute_293 = torch.ops.aten.permute.default(view_852, [0, 2, 1, 3]);  view_852 = None
    index_put_7 = torch.ops.aten.index_put_.default(arg246_1, [None, None, add_296], permute_293);  arg246_1 = add_296 = permute_293 = None
    unsqueeze_183 = torch.ops.aten.unsqueeze.default(index_put_7, 2);  index_put_7 = None
    expand_271 = torch.ops.aten.expand.default(unsqueeze_183, [1, 2, 4, 144, 256]);  unsqueeze_183 = None
    clone_102 = torch.ops.aten.clone.default(expand_271, memory_format = torch.contiguous_format);  expand_271 = None
    view_854 = torch.ops.aten.reshape.default(clone_102, [1, 8, 144, 256]);  clone_102 = None
    expand_275 = torch.ops.aten.expand.default(view_854, [1, 8, 144, 256]);  view_854 = None
    view_859 = torch.ops.aten.reshape.default(expand_275, [8, 144, 256]);  expand_275 = None
    bmm_127 = torch.ops.aten.bmm.default(view_858, view_859);  view_858 = view_859 = None
    view_860 = torch.ops.aten.reshape.default(bmm_127, [1, 8, 128, 256]);  bmm_127 = None
    permute_295 = torch.ops.aten.permute.default(view_860, [0, 2, 1, 3]);  view_860 = None
    clone_103 = torch.ops.aten.clone.default(permute_295, memory_format = torch.contiguous_format);  permute_295 = None
    view_861 = torch.ops.aten.reshape.default(clone_103, [1, 128, -1]);  clone_103 = None
    clone_100 = torch.ops.aten.clone.default(getitem_43, memory_format = torch.contiguous_format);  getitem_43 = None
    view_845 = torch.ops.aten.reshape.default(clone_100, [1, 128, 2048]);  clone_100 = None
    sigmoid_15 = torch.ops.aten.sigmoid.default(view_845);  view_845 = None
    mul_383 = torch.ops.aten.mul.Tensor(view_861, sigmoid_15);  view_861 = sigmoid_15 = None
    view_862 = torch.ops.aten.reshape.default(mul_383, [128, 2048]);  mul_383 = None
    permute_296 = torch.ops.aten.permute.default(arg247_1, [1, 0]);  arg247_1 = None
    mm_120 = torch.ops.aten.mm.default(view_862, permute_296);  view_862 = permute_296 = None
    view_863 = torch.ops.aten.reshape.default(mm_120, [1, 128, 2048]);  mm_120 = None
    add_299 = torch.ops.aten.add.Tensor(add_287, view_863);  add_287 = view_863 = None
    convert_element_type_597 = torch.ops.prims.convert_element_type.default(add_299, torch.float32)
    pow_52 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_597, 2)
    mean_51 = torch.ops.aten.mean.dim(pow_52, [-1], True);  pow_52 = None
    add_300 = torch.ops.aten.add.Tensor(mean_51, 1e-06);  mean_51 = None
    rsqrt_75 = torch.ops.aten.rsqrt.default(add_300);  add_300 = None
    mul_384 = torch.ops.aten.mul.Tensor(convert_element_type_597, rsqrt_75);  convert_element_type_597 = rsqrt_75 = None
    convert_element_type_598 = torch.ops.prims.convert_element_type.default(arg248_1, torch.float32);  arg248_1 = None
    add_301 = torch.ops.aten.add.Tensor(convert_element_type_598, 1.0);  convert_element_type_598 = None
    mul_385 = torch.ops.aten.mul.Tensor(mul_384, add_301);  mul_384 = add_301 = None
    convert_element_type_599 = torch.ops.prims.convert_element_type.default(mul_385, torch.bfloat16);  mul_385 = None
    view_864 = torch.ops.aten.reshape.default(convert_element_type_599, [128, 2048])
    permute_297 = torch.ops.aten.permute.default(arg249_1, [1, 0]);  arg249_1 = None
    mm_121 = torch.ops.aten.mm.default(view_864, permute_297);  view_864 = permute_297 = None
    view_865 = torch.ops.aten.reshape.default(mm_121, [1, 128, 6144]);  mm_121 = None
    convert_element_type_602 = torch.ops.prims.convert_element_type.default(view_865, torch.float32);  view_865 = None
    neg_59 = torch.ops.aten.neg.default(convert_element_type_602)
    exp_127 = torch.ops.aten.exp.default(neg_59);  neg_59 = None
    add_302 = torch.ops.aten.add.Tensor(exp_127, 1);  exp_127 = None
    div_43 = torch.ops.aten.div.Tensor(convert_element_type_602, add_302);  convert_element_type_602 = add_302 = None
    convert_element_type_603 = torch.ops.prims.convert_element_type.default(div_43, torch.bfloat16);  div_43 = None
    view_866 = torch.ops.aten.reshape.default(convert_element_type_599, [128, 2048]);  convert_element_type_599 = None
    permute_298 = torch.ops.aten.permute.default(arg250_1, [1, 0]);  arg250_1 = None
    mm_122 = torch.ops.aten.mm.default(view_866, permute_298);  view_866 = permute_298 = None
    view_867 = torch.ops.aten.reshape.default(mm_122, [1, 128, 6144]);  mm_122 = None
    mul_386 = torch.ops.aten.mul.Tensor(convert_element_type_603, view_867);  convert_element_type_603 = view_867 = None
    view_868 = torch.ops.aten.reshape.default(mul_386, [128, 6144]);  mul_386 = None
    permute_299 = torch.ops.aten.permute.default(arg251_1, [1, 0]);  arg251_1 = None
    mm_123 = torch.ops.aten.mm.default(view_868, permute_299);  view_868 = permute_299 = None
    view_869 = torch.ops.aten.reshape.default(mm_123, [1, 128, 2048]);  mm_123 = None
    add_303 = torch.ops.aten.add.Tensor(add_299, view_869);  add_299 = view_869 = None
    convert_element_type_608 = torch.ops.prims.convert_element_type.default(add_303, torch.float32)
    pow_53 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_608, 2)
    mean_52 = torch.ops.aten.mean.dim(pow_53, [-1], True);  pow_53 = None
    add_304 = torch.ops.aten.add.Tensor(mean_52, 1e-06);  mean_52 = None
    rsqrt_76 = torch.ops.aten.rsqrt.default(add_304);  add_304 = None
    mul_387 = torch.ops.aten.mul.Tensor(convert_element_type_608, rsqrt_76);  convert_element_type_608 = rsqrt_76 = None
    convert_element_type_609 = torch.ops.prims.convert_element_type.default(arg252_1, torch.float32);  arg252_1 = None
    add_305 = torch.ops.aten.add.Tensor(convert_element_type_609, 1.0);  convert_element_type_609 = None
    mul_388 = torch.ops.aten.mul.Tensor(mul_387, add_305);  mul_387 = add_305 = None
    convert_element_type_610 = torch.ops.prims.convert_element_type.default(mul_388, torch.bfloat16);  mul_388 = None
    view_870 = torch.ops.aten.reshape.default(convert_element_type_610, [128, 2048])
    permute_300 = torch.ops.aten.permute.default(arg253_1, [1, 0]);  arg253_1 = None
    mm_124 = torch.ops.aten.mm.default(view_870, permute_300);  view_870 = permute_300 = None
    view_871 = torch.ops.aten.reshape.default(mm_124, [1, 128, 6144]);  mm_124 = None
    permute_301 = torch.ops.aten.permute.default(view_871, [0, 2, 1]);  view_871 = None
    slice_146 = torch.ops.aten.slice.Tensor(permute_301, 2, -4, 9223372036854775807)
    copy_52 = torch.ops.aten.copy.default(arg257_1, slice_146);  slice_146 = None
    convert_element_type_619 = torch.ops.prims.convert_element_type.default(permute_301, torch.float32);  permute_301 = None
    constant_pad_nd_72 = torch.ops.aten.constant_pad_nd.default(convert_element_type_619, [3, 3], 0.0);  convert_element_type_619 = None
    slice_147 = torch.ops.aten.slice.Tensor(constant_pad_nd_72, 2, 0, 131)
    squeeze_12 = torch.ops.aten.squeeze.dim(arg258_1, 1);  arg258_1 = None
    unsqueeze_184 = torch.ops.aten.unsqueeze.default(squeeze_12, 1);  squeeze_12 = None
    convert_element_type_620 = torch.ops.prims.convert_element_type.default(unsqueeze_184, torch.float32);  unsqueeze_184 = None
    select_337 = torch.ops.aten.select.int(convert_element_type_620, 1, 0)
    select_338 = torch.ops.aten.select.int(select_337, 1, 0);  select_337 = None
    view_879 = torch.ops.aten.reshape.default(select_338, [1, -1, 1]);  select_338 = None
    mul_389 = torch.ops.aten.mul.Tensor(slice_147, view_879);  slice_147 = view_879 = None
    slice_148 = torch.ops.aten.slice.Tensor(constant_pad_nd_72, 2, 1, 132)
    select_339 = torch.ops.aten.select.int(convert_element_type_620, 1, 0)
    select_340 = torch.ops.aten.select.int(select_339, 1, 1);  select_339 = None
    view_880 = torch.ops.aten.reshape.default(select_340, [1, -1, 1]);  select_340 = None
    mul_390 = torch.ops.aten.mul.Tensor(slice_148, view_880);  slice_148 = view_880 = None
    add_306 = torch.ops.aten.add.Tensor(mul_389, mul_390);  mul_389 = mul_390 = None
    slice_149 = torch.ops.aten.slice.Tensor(constant_pad_nd_72, 2, 2, 133)
    select_341 = torch.ops.aten.select.int(convert_element_type_620, 1, 0)
    select_342 = torch.ops.aten.select.int(select_341, 1, 2);  select_341 = None
    view_881 = torch.ops.aten.reshape.default(select_342, [1, -1, 1]);  select_342 = None
    mul_391 = torch.ops.aten.mul.Tensor(slice_149, view_881);  slice_149 = view_881 = None
    add_307 = torch.ops.aten.add.Tensor(add_306, mul_391);  add_306 = mul_391 = None
    slice_150 = torch.ops.aten.slice.Tensor(constant_pad_nd_72, 2, 3, 134);  constant_pad_nd_72 = None
    select_343 = torch.ops.aten.select.int(convert_element_type_620, 1, 0);  convert_element_type_620 = None
    select_344 = torch.ops.aten.select.int(select_343, 1, 3);  select_343 = None
    view_882 = torch.ops.aten.reshape.default(select_344, [1, -1, 1]);  select_344 = None
    mul_392 = torch.ops.aten.mul.Tensor(slice_150, view_882);  slice_150 = view_882 = None
    add_308 = torch.ops.aten.add.Tensor(add_307, mul_392);  add_307 = mul_392 = None
    convert_element_type_621 = torch.ops.prims.convert_element_type.default(add_308, torch.bfloat16);  add_308 = None
    slice_151 = torch.ops.aten.slice.Tensor(convert_element_type_621, 2, 0, 128);  convert_element_type_621 = None
    convert_element_type_622 = torch.ops.prims.convert_element_type.default(slice_151, torch.float32);  slice_151 = None
    neg_60 = torch.ops.aten.neg.default(convert_element_type_622)
    exp_128 = torch.ops.aten.exp.default(neg_60);  neg_60 = None
    add_309 = torch.ops.aten.add.Tensor(exp_128, 1);  exp_128 = None
    div_44 = torch.ops.aten.div.Tensor(convert_element_type_622, add_309);  convert_element_type_622 = add_309 = None
    convert_element_type_623 = torch.ops.prims.convert_element_type.default(div_44, torch.bfloat16);  div_44 = None
    slice_152 = torch.ops.aten.slice.Tensor(convert_element_type_623, 2, -128, 9223372036854775807);  convert_element_type_623 = None
    permute_305 = torch.ops.aten.permute.default(slice_152, [0, 2, 1]);  slice_152 = None
    split_with_sizes_12 = torch.ops.aten.split_with_sizes.default(permute_305, [2048, 2048, 2048], -1);  permute_305 = None
    getitem_44 = split_with_sizes_12[0]
    getitem_45 = split_with_sizes_12[1]
    getitem_46 = split_with_sizes_12[2];  split_with_sizes_12 = None
    full_38 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_129 = torch.ops.aten.exp.default(arg259_1);  arg259_1 = None
    neg_61 = torch.ops.aten.neg.default(exp_129);  exp_129 = None
    view_877 = torch.ops.aten.reshape.default(convert_element_type_610, [128, 2048])
    permute_304 = torch.ops.aten.permute.default(arg256_1, [1, 0]);  arg256_1 = None
    mm_127 = torch.ops.aten.mm.default(view_877, permute_304);  view_877 = permute_304 = None
    view_878 = torch.ops.aten.reshape.default(mm_127, [1, 128, 16]);  mm_127 = None
    convert_element_type_624 = torch.ops.prims.convert_element_type.default(view_878, torch.float32);  view_878 = None
    add_310 = torch.ops.aten.add.Tensor(convert_element_type_624, arg260_1);  convert_element_type_624 = arg260_1 = None
    gt_12 = torch.ops.aten.gt.Scalar(add_310, 20)
    exp_130 = torch.ops.aten.exp.default(add_310)
    log1p_12 = torch.ops.aten.log1p.default(exp_130);  exp_130 = None
    where_25 = torch.ops.aten.where.self(gt_12, add_310, log1p_12);  gt_12 = add_310 = log1p_12 = None
    mul_393 = torch.ops.aten.mul.Tensor(neg_61, where_25);  neg_61 = where_25 = None
    permute_310 = torch.ops.aten.permute.default(mul_393, [0, 2, 1]);  mul_393 = None
    view_890 = torch.ops.aten.reshape.default(permute_310, [1, 16, 2, 64]);  permute_310 = None
    cumsum_12 = torch.ops.aten.cumsum.default(view_890, 3);  view_890 = None
    select_345 = torch.ops.aten.select.int(cumsum_12, 3, -1)
    exp_135 = torch.ops.aten.exp.default(select_345);  select_345 = None
    unsqueeze_194 = torch.ops.aten.unsqueeze.default(exp_135, 3);  exp_135 = None
    unsqueeze_195 = torch.ops.aten.unsqueeze.default(unsqueeze_194, 4);  unsqueeze_194 = None
    select_352 = torch.ops.aten.select.int(unsqueeze_195, 2, 0)
    mul_406 = torch.ops.aten.mul.Tensor(full_38, select_352);  select_352 = None
    view_884 = torch.ops.aten.reshape.default(getitem_45, [1, 128, 16, 128]);  getitem_45 = None
    permute_307 = torch.ops.aten.permute.default(view_884, [0, 2, 1, 3]);  view_884 = None
    convert_element_type_626 = torch.ops.prims.convert_element_type.default(permute_307, torch.float32);  permute_307 = None
    clone_105 = torch.ops.aten.clone.default(convert_element_type_626, memory_format = torch.contiguous_format);  convert_element_type_626 = None
    mul_396 = torch.ops.aten.mul.Tensor(clone_105, clone_105)
    sum_30 = torch.ops.aten.sum.dim_IntList(mul_396, [-1], True);  mul_396 = None
    add_312 = torch.ops.aten.add.Tensor(sum_30, 1e-06);  sum_30 = None
    rsqrt_78 = torch.ops.aten.rsqrt.default(add_312);  add_312 = None
    mul_397 = torch.ops.aten.mul.Tensor(clone_105, rsqrt_78);  clone_105 = rsqrt_78 = None
    view_887 = torch.ops.aten.reshape.default(mul_397, [1, 16, -1, 64, 128])
    slice_153 = torch.ops.aten.slice.Tensor(cumsum_12, 3, -1, 9223372036854775807)
    sub_66 = torch.ops.aten.sub.Tensor(slice_153, cumsum_12);  slice_153 = None
    exp_134 = torch.ops.aten.exp.default(sub_66);  sub_66 = None
    unsqueeze_193 = torch.ops.aten.unsqueeze.default(exp_134, -1);  exp_134 = None
    mul_405 = torch.ops.aten.mul.Tensor(view_887, unsqueeze_193);  unsqueeze_193 = None
    select_353 = torch.ops.aten.select.int(mul_405, 2, 0)
    permute_314 = torch.ops.aten.permute.default(select_353, [0, 1, 3, 2]);  select_353 = None
    expand_286 = torch.ops.aten.expand.default(permute_314, [1, 16, 128, 64]);  permute_314 = None
    view_906 = torch.ops.aten.reshape.default(expand_286, [16, 128, 64]);  expand_286 = None
    view_875 = torch.ops.aten.reshape.default(convert_element_type_610, [128, 2048])
    permute_303 = torch.ops.aten.permute.default(arg255_1, [1, 0]);  arg255_1 = None
    mm_126 = torch.ops.aten.mm.default(view_875, permute_303);  view_875 = permute_303 = None
    view_876 = torch.ops.aten.reshape.default(mm_126, [1, 128, 16]);  mm_126 = None
    sigmoid_16 = torch.ops.aten.sigmoid.default(view_876);  view_876 = None
    permute_309 = torch.ops.aten.permute.default(sigmoid_16, [0, 2, 1]);  sigmoid_16 = None
    convert_element_type_628 = torch.ops.prims.convert_element_type.default(permute_309, torch.float32);  permute_309 = None
    clone_107 = torch.ops.aten.clone.default(convert_element_type_628, memory_format = torch.contiguous_format);  convert_element_type_628 = None
    unsqueeze_186 = torch.ops.aten.unsqueeze.default(clone_107, -1)
    mul_400 = torch.ops.aten.mul.Tensor(mul_397, unsqueeze_186);  mul_397 = unsqueeze_186 = None
    view_888 = torch.ops.aten.reshape.default(mul_400, [1, 16, -1, 64, 128]);  mul_400 = None
    expand_276 = torch.ops.aten.expand.default(view_888, [1, 16, 2, 64, 128])
    view_891 = torch.ops.aten.reshape.default(expand_276, [32, 64, 128]);  expand_276 = None
    permute_311 = torch.ops.aten.permute.default(view_887, [0, 1, 2, 4, 3])
    expand_277 = torch.ops.aten.expand.default(permute_311, [1, 16, 2, 128, 64]);  permute_311 = None
    view_892 = torch.ops.aten.reshape.default(expand_277, [32, 128, 64]);  expand_277 = None
    bmm_128 = torch.ops.aten.bmm.default(view_891, view_892);  view_891 = view_892 = None
    view_893 = torch.ops.aten.reshape.default(bmm_128, [1, 16, 2, 64, 64]);  bmm_128 = None
    iota_29 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_187 = torch.ops.aten.unsqueeze.default(iota_29, -2);  iota_29 = None
    iota_30 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_188 = torch.ops.aten.unsqueeze.default(iota_30, -1);  iota_30 = None
    sub_64 = torch.ops.aten.sub.Tensor(unsqueeze_187, unsqueeze_188);  unsqueeze_187 = unsqueeze_188 = None
    ge_12 = torch.ops.aten.ge.Scalar(sub_64, 1);  sub_64 = None
    full_default_26 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_12 = torch.ops.aten.logical_and.default(ge_12, full_default_26);  ge_12 = full_default_26 = None
    full_default_27 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_189 = torch.ops.aten.unsqueeze.default(cumsum_12, 4)
    unsqueeze_190 = torch.ops.aten.unsqueeze.default(cumsum_12, 3)
    sub_65 = torch.ops.aten.sub.Tensor(unsqueeze_189, unsqueeze_190);  unsqueeze_189 = unsqueeze_190 = None
    where_26 = torch.ops.aten.where.self(logical_and_12, full_default_27, sub_65);  logical_and_12 = full_default_27 = sub_65 = None
    exp_131 = torch.ops.aten.exp.default(where_26);  where_26 = None
    mul_401 = torch.ops.aten.mul.Tensor(view_893, exp_131);  view_893 = None
    view_885 = torch.ops.aten.reshape.default(getitem_46, [1, 128, 16, 128]);  getitem_46 = None
    permute_308 = torch.ops.aten.permute.default(view_885, [0, 2, 1, 3]);  view_885 = None
    convert_element_type_627 = torch.ops.prims.convert_element_type.default(permute_308, torch.float32);  permute_308 = None
    clone_106 = torch.ops.aten.clone.default(convert_element_type_627, memory_format = torch.contiguous_format);  convert_element_type_627 = None
    unsqueeze_185 = torch.ops.aten.unsqueeze.default(clone_107, -1);  clone_107 = None
    mul_399 = torch.ops.aten.mul.Tensor(clone_106, unsqueeze_185);  clone_106 = unsqueeze_185 = None
    view_889 = torch.ops.aten.reshape.default(mul_399, [1, 16, -1, 64, 128]);  mul_399 = None
    linalg_solve_triangular_24 = torch.ops.aten.linalg_solve_triangular.default(mul_401, view_889, upper = False, unitriangular = True);  view_889 = None
    select_346 = torch.ops.aten.select.int(linalg_solve_triangular_24, 2, 0)
    exp_132 = torch.ops.aten.exp.default(cumsum_12)
    unsqueeze_191 = torch.ops.aten.unsqueeze.default(exp_132, -1);  exp_132 = None
    mul_403 = torch.ops.aten.mul.Tensor(view_888, unsqueeze_191);  view_888 = unsqueeze_191 = None
    linalg_solve_triangular_25 = torch.ops.aten.linalg_solve_triangular.default(mul_401, mul_403, upper = False, unitriangular = True);  mul_401 = mul_403 = None
    select_347 = torch.ops.aten.select.int(linalg_solve_triangular_25, 2, 0)
    expand_280 = torch.ops.aten.expand.default(select_347, [1, 16, 64, 128]);  select_347 = None
    view_897 = torch.ops.aten.reshape.default(expand_280, [16, 64, 128]);  expand_280 = None
    expand_281 = torch.ops.aten.expand.default(full_38, [1, 16, 128, 128])
    view_898 = torch.ops.aten.reshape.default(expand_281, [16, 128, 128]);  expand_281 = None
    bmm_130 = torch.ops.aten.bmm.default(view_897, view_898);  view_897 = view_898 = None
    view_899 = torch.ops.aten.reshape.default(bmm_130, [1, 16, 64, 128]);  bmm_130 = None
    sub_67 = torch.ops.aten.sub.Tensor(select_346, view_899);  select_346 = view_899 = None
    expand_287 = torch.ops.aten.expand.default(sub_67, [1, 16, 64, 128])
    view_907 = torch.ops.aten.reshape.default(expand_287, [16, 64, 128]);  expand_287 = None
    bmm_133 = torch.ops.aten.bmm.default(view_906, view_907);  view_906 = view_907 = None
    view_908 = torch.ops.aten.reshape.default(bmm_133, [1, 16, 128, 128]);  bmm_133 = None
    add_314 = torch.ops.aten.add.Tensor(mul_406, view_908);  mul_406 = view_908 = None
    select_361 = torch.ops.aten.select.int(unsqueeze_195, 2, 1);  unsqueeze_195 = None
    mul_407 = torch.ops.aten.mul.Tensor(add_314, select_361);  select_361 = None
    select_362 = torch.ops.aten.select.int(mul_405, 2, 1);  mul_405 = None
    permute_315 = torch.ops.aten.permute.default(select_362, [0, 1, 3, 2]);  select_362 = None
    expand_294 = torch.ops.aten.expand.default(permute_315, [1, 16, 128, 64]);  permute_315 = None
    view_918 = torch.ops.aten.reshape.default(expand_294, [16, 128, 64]);  expand_294 = None
    select_354 = torch.ops.aten.select.int(linalg_solve_triangular_24, 2, 1);  linalg_solve_triangular_24 = None
    select_355 = torch.ops.aten.select.int(linalg_solve_triangular_25, 2, 1);  linalg_solve_triangular_25 = None
    expand_288 = torch.ops.aten.expand.default(select_355, [1, 16, 64, 128]);  select_355 = None
    view_909 = torch.ops.aten.reshape.default(expand_288, [16, 64, 128]);  expand_288 = None
    expand_289 = torch.ops.aten.expand.default(add_314, [1, 16, 128, 128])
    view_910 = torch.ops.aten.reshape.default(expand_289, [16, 128, 128]);  expand_289 = None
    bmm_134 = torch.ops.aten.bmm.default(view_909, view_910);  view_909 = view_910 = None
    view_911 = torch.ops.aten.reshape.default(bmm_134, [1, 16, 64, 128]);  bmm_134 = None
    sub_68 = torch.ops.aten.sub.Tensor(select_354, view_911);  select_354 = view_911 = None
    expand_295 = torch.ops.aten.expand.default(sub_68, [1, 16, 64, 128])
    view_919 = torch.ops.aten.reshape.default(expand_295, [16, 64, 128]);  expand_295 = None
    bmm_137 = torch.ops.aten.bmm.default(view_918, view_919);  view_918 = view_919 = None
    view_920 = torch.ops.aten.reshape.default(bmm_137, [1, 16, 128, 128]);  bmm_137 = None
    add_316 = torch.ops.aten.add.Tensor(mul_407, view_920);  mul_407 = view_920 = None
    full_39 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_313 = torch.ops.aten.permute.default(full_39, [0, 1, 2, 4, 3]);  full_39 = None
    select_350 = torch.ops.aten.select.int(permute_313, 2, 0)
    view_883 = torch.ops.aten.reshape.default(getitem_44, [1, 128, 16, 128]);  getitem_44 = None
    permute_306 = torch.ops.aten.permute.default(view_883, [0, 2, 1, 3]);  view_883 = None
    convert_element_type_625 = torch.ops.prims.convert_element_type.default(permute_306, torch.float32);  permute_306 = None
    clone_104 = torch.ops.aten.clone.default(convert_element_type_625, memory_format = torch.contiguous_format);  convert_element_type_625 = None
    mul_394 = torch.ops.aten.mul.Tensor(clone_104, clone_104)
    sum_29 = torch.ops.aten.sum.dim_IntList(mul_394, [-1], True);  mul_394 = None
    add_311 = torch.ops.aten.add.Tensor(sum_29, 1e-06);  sum_29 = None
    rsqrt_77 = torch.ops.aten.rsqrt.default(add_311);  add_311 = None
    mul_395 = torch.ops.aten.mul.Tensor(clone_104, rsqrt_77);  clone_104 = rsqrt_77 = None
    mul_398 = torch.ops.aten.mul.Tensor(mul_395, 0.08838834764831845);  mul_395 = None
    view_886 = torch.ops.aten.reshape.default(mul_398, [1, 16, -1, 64, 128]);  mul_398 = None
    exp_133 = torch.ops.aten.exp.default(cumsum_12);  cumsum_12 = None
    unsqueeze_192 = torch.ops.aten.unsqueeze.default(exp_133, -1);  exp_133 = None
    mul_404 = torch.ops.aten.mul.Tensor(view_886, unsqueeze_192);  unsqueeze_192 = None
    select_348 = torch.ops.aten.select.int(mul_404, 2, 0)
    expand_282 = torch.ops.aten.expand.default(select_348, [1, 16, 64, 128]);  select_348 = None
    view_900 = torch.ops.aten.reshape.default(expand_282, [16, 64, 128]);  expand_282 = None
    expand_283 = torch.ops.aten.expand.default(full_38, [1, 16, 128, 128]);  full_38 = None
    view_901 = torch.ops.aten.reshape.default(expand_283, [16, 128, 128]);  expand_283 = None
    bmm_131 = torch.ops.aten.bmm.default(view_900, view_901);  view_900 = view_901 = None
    view_902 = torch.ops.aten.reshape.default(bmm_131, [1, 16, 64, 128]);  bmm_131 = None
    expand_278 = torch.ops.aten.expand.default(view_886, [1, 16, 2, 64, 128]);  view_886 = None
    view_894 = torch.ops.aten.reshape.default(expand_278, [32, 64, 128]);  expand_278 = None
    permute_312 = torch.ops.aten.permute.default(view_887, [0, 1, 2, 4, 3]);  view_887 = None
    expand_279 = torch.ops.aten.expand.default(permute_312, [1, 16, 2, 128, 64]);  permute_312 = None
    view_895 = torch.ops.aten.reshape.default(expand_279, [32, 128, 64]);  expand_279 = None
    bmm_129 = torch.ops.aten.bmm.default(view_894, view_895);  view_894 = view_895 = None
    view_896 = torch.ops.aten.reshape.default(bmm_129, [1, 16, 2, 64, 64]);  bmm_129 = None
    mul_402 = torch.ops.aten.mul.Tensor(view_896, exp_131);  view_896 = exp_131 = None
    select_349 = torch.ops.aten.select.int(mul_402, 2, 0)
    expand_284 = torch.ops.aten.expand.default(select_349, [1, 16, 64, 64]);  select_349 = None
    view_903 = torch.ops.aten.reshape.default(expand_284, [16, 64, 64]);  expand_284 = None
    expand_285 = torch.ops.aten.expand.default(sub_67, [1, 16, 64, 128]);  sub_67 = None
    view_904 = torch.ops.aten.reshape.default(expand_285, [16, 64, 128]);  expand_285 = None
    bmm_132 = torch.ops.aten.bmm.default(view_903, view_904);  view_903 = view_904 = None
    view_905 = torch.ops.aten.reshape.default(bmm_132, [1, 16, 64, 128]);  bmm_132 = None
    add_313 = torch.ops.aten.add.Tensor(view_902, view_905);  view_902 = view_905 = None
    copy_53 = torch.ops.aten.copy.default(select_350, add_313);  select_350 = add_313 = None
    select_scatter_default_28 = torch.ops.aten.select_scatter.default(permute_313, copy_53, 2, 0);  permute_313 = copy_53 = None
    select_359 = torch.ops.aten.select.int(select_scatter_default_28, 2, 1)
    select_356 = torch.ops.aten.select.int(mul_404, 2, 1);  mul_404 = None
    expand_290 = torch.ops.aten.expand.default(select_356, [1, 16, 64, 128]);  select_356 = None
    view_912 = torch.ops.aten.reshape.default(expand_290, [16, 64, 128]);  expand_290 = None
    expand_291 = torch.ops.aten.expand.default(add_314, [1, 16, 128, 128]);  add_314 = None
    view_913 = torch.ops.aten.reshape.default(expand_291, [16, 128, 128]);  expand_291 = None
    bmm_135 = torch.ops.aten.bmm.default(view_912, view_913);  view_912 = view_913 = None
    view_914 = torch.ops.aten.reshape.default(bmm_135, [1, 16, 64, 128]);  bmm_135 = None
    select_357 = torch.ops.aten.select.int(mul_402, 2, 1);  mul_402 = None
    expand_292 = torch.ops.aten.expand.default(select_357, [1, 16, 64, 64]);  select_357 = None
    view_915 = torch.ops.aten.reshape.default(expand_292, [16, 64, 64]);  expand_292 = None
    expand_293 = torch.ops.aten.expand.default(sub_68, [1, 16, 64, 128]);  sub_68 = None
    view_916 = torch.ops.aten.reshape.default(expand_293, [16, 64, 128]);  expand_293 = None
    bmm_136 = torch.ops.aten.bmm.default(view_915, view_916);  view_915 = view_916 = None
    view_917 = torch.ops.aten.reshape.default(bmm_136, [1, 16, 64, 128]);  bmm_136 = None
    add_315 = torch.ops.aten.add.Tensor(view_914, view_917);  view_914 = view_917 = None
    copy_54 = torch.ops.aten.copy.default(select_359, add_315);  select_359 = add_315 = None
    select_scatter_default_29 = torch.ops.aten.select_scatter.default(select_scatter_default_28, copy_54, 2, 1);  select_scatter_default_28 = copy_54 = None
    clone_109 = torch.ops.aten.clone.default(select_scatter_default_29, memory_format = torch.contiguous_format);  select_scatter_default_29 = None
    view_921 = torch.ops.aten.reshape.default(clone_109, [1, 16, 128, 128]);  clone_109 = None
    permute_316 = torch.ops.aten.permute.default(view_921, [0, 2, 1, 3]);  view_921 = None
    convert_element_type_629 = torch.ops.prims.convert_element_type.default(permute_316, torch.bfloat16);  permute_316 = None
    clone_110 = torch.ops.aten.clone.default(convert_element_type_629, memory_format = torch.contiguous_format);  convert_element_type_629 = None
    view_922 = torch.ops.aten.reshape.default(clone_110, [-1, 128]);  clone_110 = None
    convert_element_type_630 = torch.ops.prims.convert_element_type.default(view_922, torch.float32);  view_922 = None
    pow_54 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_630, 2)
    mean_53 = torch.ops.aten.mean.dim(pow_54, [-1], True);  pow_54 = None
    add_317 = torch.ops.aten.add.Tensor(mean_53, 1e-06);  mean_53 = None
    rsqrt_79 = torch.ops.aten.rsqrt.default(add_317);  add_317 = None
    mul_408 = torch.ops.aten.mul.Tensor(convert_element_type_630, rsqrt_79);  convert_element_type_630 = rsqrt_79 = None
    convert_element_type_631 = torch.ops.prims.convert_element_type.default(mul_408, torch.bfloat16);  mul_408 = None
    mul_409 = torch.ops.aten.mul.Tensor(arg262_1, convert_element_type_631);  arg262_1 = convert_element_type_631 = None
    view_872 = torch.ops.aten.reshape.default(convert_element_type_610, [128, 2048]);  convert_element_type_610 = None
    permute_302 = torch.ops.aten.permute.default(arg254_1, [1, 0]);  arg254_1 = None
    mm_125 = torch.ops.aten.mm.default(view_872, permute_302);  view_872 = permute_302 = None
    view_873 = torch.ops.aten.reshape.default(mm_125, [1, 128, 2048]);  mm_125 = None
    view_874 = torch.ops.aten.reshape.default(view_873, [1, 128, -1, 128]);  view_873 = None
    view_923 = torch.ops.aten.reshape.default(view_874, [-1, 128]);  view_874 = None
    convert_element_type_632 = torch.ops.prims.convert_element_type.default(view_923, torch.float32);  view_923 = None
    neg_62 = torch.ops.aten.neg.default(convert_element_type_632)
    exp_136 = torch.ops.aten.exp.default(neg_62);  neg_62 = None
    add_318 = torch.ops.aten.add.Tensor(exp_136, 1);  exp_136 = None
    div_45 = torch.ops.aten.div.Tensor(convert_element_type_632, add_318);  convert_element_type_632 = add_318 = None
    mul_410 = torch.ops.aten.mul.Tensor(mul_409, div_45);  mul_409 = div_45 = None
    convert_element_type_633 = torch.ops.prims.convert_element_type.default(mul_410, torch.bfloat16);  mul_410 = None
    view_924 = torch.ops.aten.reshape.default(convert_element_type_633, [1, 128, -1]);  convert_element_type_633 = None
    view_925 = torch.ops.aten.reshape.default(view_924, [128, 2048]);  view_924 = None
    permute_317 = torch.ops.aten.permute.default(arg263_1, [1, 0]);  arg263_1 = None
    mm_128 = torch.ops.aten.mm.default(view_925, permute_317);  view_925 = permute_317 = None
    view_926 = torch.ops.aten.reshape.default(mm_128, [1, 128, 2048]);  mm_128 = None
    add_319 = torch.ops.aten.add.Tensor(add_303, view_926);  add_303 = view_926 = None
    convert_element_type_636 = torch.ops.prims.convert_element_type.default(add_319, torch.float32)
    pow_55 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_636, 2)
    mean_54 = torch.ops.aten.mean.dim(pow_55, [-1], True);  pow_55 = None
    add_320 = torch.ops.aten.add.Tensor(mean_54, 1e-06);  mean_54 = None
    rsqrt_80 = torch.ops.aten.rsqrt.default(add_320);  add_320 = None
    mul_411 = torch.ops.aten.mul.Tensor(convert_element_type_636, rsqrt_80);  convert_element_type_636 = rsqrt_80 = None
    convert_element_type_637 = torch.ops.prims.convert_element_type.default(arg264_1, torch.float32);  arg264_1 = None
    add_321 = torch.ops.aten.add.Tensor(convert_element_type_637, 1.0);  convert_element_type_637 = None
    mul_412 = torch.ops.aten.mul.Tensor(mul_411, add_321);  mul_411 = add_321 = None
    convert_element_type_638 = torch.ops.prims.convert_element_type.default(mul_412, torch.bfloat16);  mul_412 = None
    view_927 = torch.ops.aten.reshape.default(convert_element_type_638, [128, 2048])
    permute_318 = torch.ops.aten.permute.default(arg265_1, [1, 0]);  arg265_1 = None
    mm_129 = torch.ops.aten.mm.default(view_927, permute_318);  view_927 = permute_318 = None
    view_928 = torch.ops.aten.reshape.default(mm_129, [1, 128, 6144]);  mm_129 = None
    convert_element_type_641 = torch.ops.prims.convert_element_type.default(view_928, torch.float32);  view_928 = None
    neg_63 = torch.ops.aten.neg.default(convert_element_type_641)
    exp_137 = torch.ops.aten.exp.default(neg_63);  neg_63 = None
    add_322 = torch.ops.aten.add.Tensor(exp_137, 1);  exp_137 = None
    div_46 = torch.ops.aten.div.Tensor(convert_element_type_641, add_322);  convert_element_type_641 = add_322 = None
    convert_element_type_642 = torch.ops.prims.convert_element_type.default(div_46, torch.bfloat16);  div_46 = None
    view_929 = torch.ops.aten.reshape.default(convert_element_type_638, [128, 2048]);  convert_element_type_638 = None
    permute_319 = torch.ops.aten.permute.default(arg266_1, [1, 0]);  arg266_1 = None
    mm_130 = torch.ops.aten.mm.default(view_929, permute_319);  view_929 = permute_319 = None
    view_930 = torch.ops.aten.reshape.default(mm_130, [1, 128, 6144]);  mm_130 = None
    mul_413 = torch.ops.aten.mul.Tensor(convert_element_type_642, view_930);  convert_element_type_642 = view_930 = None
    view_931 = torch.ops.aten.reshape.default(mul_413, [128, 6144]);  mul_413 = None
    permute_320 = torch.ops.aten.permute.default(arg267_1, [1, 0]);  arg267_1 = None
    mm_131 = torch.ops.aten.mm.default(view_931, permute_320);  view_931 = permute_320 = None
    view_932 = torch.ops.aten.reshape.default(mm_131, [1, 128, 2048]);  mm_131 = None
    add_323 = torch.ops.aten.add.Tensor(add_319, view_932);  add_319 = view_932 = None
    convert_element_type_647 = torch.ops.prims.convert_element_type.default(add_323, torch.float32)
    pow_56 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_647, 2)
    mean_55 = torch.ops.aten.mean.dim(pow_56, [-1], True);  pow_56 = None
    add_324 = torch.ops.aten.add.Tensor(mean_55, 1e-06);  mean_55 = None
    rsqrt_81 = torch.ops.aten.rsqrt.default(add_324);  add_324 = None
    mul_414 = torch.ops.aten.mul.Tensor(convert_element_type_647, rsqrt_81);  convert_element_type_647 = rsqrt_81 = None
    convert_element_type_648 = torch.ops.prims.convert_element_type.default(arg268_1, torch.float32);  arg268_1 = None
    add_325 = torch.ops.aten.add.Tensor(convert_element_type_648, 1.0);  convert_element_type_648 = None
    mul_415 = torch.ops.aten.mul.Tensor(mul_414, add_325);  mul_414 = add_325 = None
    convert_element_type_649 = torch.ops.prims.convert_element_type.default(mul_415, torch.bfloat16);  mul_415 = None
    view_933 = torch.ops.aten.reshape.default(convert_element_type_649, [128, 2048])
    permute_321 = torch.ops.aten.permute.default(arg269_1, [1, 0]);  arg269_1 = None
    mm_132 = torch.ops.aten.mm.default(view_933, permute_321);  view_933 = permute_321 = None
    view_934 = torch.ops.aten.reshape.default(mm_132, [1, 128, 6144]);  mm_132 = None
    permute_322 = torch.ops.aten.permute.default(view_934, [0, 2, 1]);  view_934 = None
    slice_154 = torch.ops.aten.slice.Tensor(permute_322, 2, -4, 9223372036854775807)
    copy_56 = torch.ops.aten.copy.default(arg273_1, slice_154);  slice_154 = None
    convert_element_type_658 = torch.ops.prims.convert_element_type.default(permute_322, torch.float32);  permute_322 = None
    constant_pad_nd_78 = torch.ops.aten.constant_pad_nd.default(convert_element_type_658, [3, 3], 0.0);  convert_element_type_658 = None
    slice_155 = torch.ops.aten.slice.Tensor(constant_pad_nd_78, 2, 0, 131)
    squeeze_13 = torch.ops.aten.squeeze.dim(arg274_1, 1);  arg274_1 = None
    unsqueeze_196 = torch.ops.aten.unsqueeze.default(squeeze_13, 1);  squeeze_13 = None
    convert_element_type_659 = torch.ops.prims.convert_element_type.default(unsqueeze_196, torch.float32);  unsqueeze_196 = None
    select_363 = torch.ops.aten.select.int(convert_element_type_659, 1, 0)
    select_364 = torch.ops.aten.select.int(select_363, 1, 0);  select_363 = None
    view_942 = torch.ops.aten.reshape.default(select_364, [1, -1, 1]);  select_364 = None
    mul_416 = torch.ops.aten.mul.Tensor(slice_155, view_942);  slice_155 = view_942 = None
    slice_156 = torch.ops.aten.slice.Tensor(constant_pad_nd_78, 2, 1, 132)
    select_365 = torch.ops.aten.select.int(convert_element_type_659, 1, 0)
    select_366 = torch.ops.aten.select.int(select_365, 1, 1);  select_365 = None
    view_943 = torch.ops.aten.reshape.default(select_366, [1, -1, 1]);  select_366 = None
    mul_417 = torch.ops.aten.mul.Tensor(slice_156, view_943);  slice_156 = view_943 = None
    add_326 = torch.ops.aten.add.Tensor(mul_416, mul_417);  mul_416 = mul_417 = None
    slice_157 = torch.ops.aten.slice.Tensor(constant_pad_nd_78, 2, 2, 133)
    select_367 = torch.ops.aten.select.int(convert_element_type_659, 1, 0)
    select_368 = torch.ops.aten.select.int(select_367, 1, 2);  select_367 = None
    view_944 = torch.ops.aten.reshape.default(select_368, [1, -1, 1]);  select_368 = None
    mul_418 = torch.ops.aten.mul.Tensor(slice_157, view_944);  slice_157 = view_944 = None
    add_327 = torch.ops.aten.add.Tensor(add_326, mul_418);  add_326 = mul_418 = None
    slice_158 = torch.ops.aten.slice.Tensor(constant_pad_nd_78, 2, 3, 134);  constant_pad_nd_78 = None
    select_369 = torch.ops.aten.select.int(convert_element_type_659, 1, 0);  convert_element_type_659 = None
    select_370 = torch.ops.aten.select.int(select_369, 1, 3);  select_369 = None
    view_945 = torch.ops.aten.reshape.default(select_370, [1, -1, 1]);  select_370 = None
    mul_419 = torch.ops.aten.mul.Tensor(slice_158, view_945);  slice_158 = view_945 = None
    add_328 = torch.ops.aten.add.Tensor(add_327, mul_419);  add_327 = mul_419 = None
    convert_element_type_660 = torch.ops.prims.convert_element_type.default(add_328, torch.bfloat16);  add_328 = None
    slice_159 = torch.ops.aten.slice.Tensor(convert_element_type_660, 2, 0, 128);  convert_element_type_660 = None
    convert_element_type_661 = torch.ops.prims.convert_element_type.default(slice_159, torch.float32);  slice_159 = None
    neg_64 = torch.ops.aten.neg.default(convert_element_type_661)
    exp_138 = torch.ops.aten.exp.default(neg_64);  neg_64 = None
    add_329 = torch.ops.aten.add.Tensor(exp_138, 1);  exp_138 = None
    div_47 = torch.ops.aten.div.Tensor(convert_element_type_661, add_329);  convert_element_type_661 = add_329 = None
    convert_element_type_662 = torch.ops.prims.convert_element_type.default(div_47, torch.bfloat16);  div_47 = None
    slice_160 = torch.ops.aten.slice.Tensor(convert_element_type_662, 2, -128, 9223372036854775807);  convert_element_type_662 = None
    permute_326 = torch.ops.aten.permute.default(slice_160, [0, 2, 1]);  slice_160 = None
    split_with_sizes_13 = torch.ops.aten.split_with_sizes.default(permute_326, [2048, 2048, 2048], -1);  permute_326 = None
    getitem_47 = split_with_sizes_13[0]
    getitem_48 = split_with_sizes_13[1]
    getitem_49 = split_with_sizes_13[2];  split_with_sizes_13 = None
    full_41 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_139 = torch.ops.aten.exp.default(arg275_1);  arg275_1 = None
    neg_65 = torch.ops.aten.neg.default(exp_139);  exp_139 = None
    view_940 = torch.ops.aten.reshape.default(convert_element_type_649, [128, 2048])
    permute_325 = torch.ops.aten.permute.default(arg272_1, [1, 0]);  arg272_1 = None
    mm_135 = torch.ops.aten.mm.default(view_940, permute_325);  view_940 = permute_325 = None
    view_941 = torch.ops.aten.reshape.default(mm_135, [1, 128, 16]);  mm_135 = None
    convert_element_type_663 = torch.ops.prims.convert_element_type.default(view_941, torch.float32);  view_941 = None
    add_330 = torch.ops.aten.add.Tensor(convert_element_type_663, arg276_1);  convert_element_type_663 = arg276_1 = None
    gt_13 = torch.ops.aten.gt.Scalar(add_330, 20)
    exp_140 = torch.ops.aten.exp.default(add_330)
    log1p_13 = torch.ops.aten.log1p.default(exp_140);  exp_140 = None
    where_27 = torch.ops.aten.where.self(gt_13, add_330, log1p_13);  gt_13 = add_330 = log1p_13 = None
    mul_420 = torch.ops.aten.mul.Tensor(neg_65, where_27);  neg_65 = where_27 = None
    permute_331 = torch.ops.aten.permute.default(mul_420, [0, 2, 1]);  mul_420 = None
    view_953 = torch.ops.aten.reshape.default(permute_331, [1, 16, 2, 64]);  permute_331 = None
    cumsum_13 = torch.ops.aten.cumsum.default(view_953, 3);  view_953 = None
    select_371 = torch.ops.aten.select.int(cumsum_13, 3, -1)
    exp_145 = torch.ops.aten.exp.default(select_371);  select_371 = None
    unsqueeze_206 = torch.ops.aten.unsqueeze.default(exp_145, 3);  exp_145 = None
    unsqueeze_207 = torch.ops.aten.unsqueeze.default(unsqueeze_206, 4);  unsqueeze_206 = None
    select_378 = torch.ops.aten.select.int(unsqueeze_207, 2, 0)
    mul_433 = torch.ops.aten.mul.Tensor(full_41, select_378);  select_378 = None
    view_947 = torch.ops.aten.reshape.default(getitem_48, [1, 128, 16, 128]);  getitem_48 = None
    permute_328 = torch.ops.aten.permute.default(view_947, [0, 2, 1, 3]);  view_947 = None
    convert_element_type_665 = torch.ops.prims.convert_element_type.default(permute_328, torch.float32);  permute_328 = None
    clone_112 = torch.ops.aten.clone.default(convert_element_type_665, memory_format = torch.contiguous_format);  convert_element_type_665 = None
    mul_423 = torch.ops.aten.mul.Tensor(clone_112, clone_112)
    sum_32 = torch.ops.aten.sum.dim_IntList(mul_423, [-1], True);  mul_423 = None
    add_332 = torch.ops.aten.add.Tensor(sum_32, 1e-06);  sum_32 = None
    rsqrt_83 = torch.ops.aten.rsqrt.default(add_332);  add_332 = None
    mul_424 = torch.ops.aten.mul.Tensor(clone_112, rsqrt_83);  clone_112 = rsqrt_83 = None
    view_950 = torch.ops.aten.reshape.default(mul_424, [1, 16, -1, 64, 128])
    slice_161 = torch.ops.aten.slice.Tensor(cumsum_13, 3, -1, 9223372036854775807)
    sub_71 = torch.ops.aten.sub.Tensor(slice_161, cumsum_13);  slice_161 = None
    exp_144 = torch.ops.aten.exp.default(sub_71);  sub_71 = None
    unsqueeze_205 = torch.ops.aten.unsqueeze.default(exp_144, -1);  exp_144 = None
    mul_432 = torch.ops.aten.mul.Tensor(view_950, unsqueeze_205);  unsqueeze_205 = None
    select_379 = torch.ops.aten.select.int(mul_432, 2, 0)
    permute_335 = torch.ops.aten.permute.default(select_379, [0, 1, 3, 2]);  select_379 = None
    expand_306 = torch.ops.aten.expand.default(permute_335, [1, 16, 128, 64]);  permute_335 = None
    view_969 = torch.ops.aten.reshape.default(expand_306, [16, 128, 64]);  expand_306 = None
    view_938 = torch.ops.aten.reshape.default(convert_element_type_649, [128, 2048])
    permute_324 = torch.ops.aten.permute.default(arg271_1, [1, 0]);  arg271_1 = None
    mm_134 = torch.ops.aten.mm.default(view_938, permute_324);  view_938 = permute_324 = None
    view_939 = torch.ops.aten.reshape.default(mm_134, [1, 128, 16]);  mm_134 = None
    sigmoid_17 = torch.ops.aten.sigmoid.default(view_939);  view_939 = None
    permute_330 = torch.ops.aten.permute.default(sigmoid_17, [0, 2, 1]);  sigmoid_17 = None
    convert_element_type_667 = torch.ops.prims.convert_element_type.default(permute_330, torch.float32);  permute_330 = None
    clone_114 = torch.ops.aten.clone.default(convert_element_type_667, memory_format = torch.contiguous_format);  convert_element_type_667 = None
    unsqueeze_198 = torch.ops.aten.unsqueeze.default(clone_114, -1)
    mul_427 = torch.ops.aten.mul.Tensor(mul_424, unsqueeze_198);  mul_424 = unsqueeze_198 = None
    view_951 = torch.ops.aten.reshape.default(mul_427, [1, 16, -1, 64, 128]);  mul_427 = None
    expand_296 = torch.ops.aten.expand.default(view_951, [1, 16, 2, 64, 128])
    view_954 = torch.ops.aten.reshape.default(expand_296, [32, 64, 128]);  expand_296 = None
    permute_332 = torch.ops.aten.permute.default(view_950, [0, 1, 2, 4, 3])
    expand_297 = torch.ops.aten.expand.default(permute_332, [1, 16, 2, 128, 64]);  permute_332 = None
    view_955 = torch.ops.aten.reshape.default(expand_297, [32, 128, 64]);  expand_297 = None
    bmm_138 = torch.ops.aten.bmm.default(view_954, view_955);  view_954 = view_955 = None
    view_956 = torch.ops.aten.reshape.default(bmm_138, [1, 16, 2, 64, 64]);  bmm_138 = None
    iota_31 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_199 = torch.ops.aten.unsqueeze.default(iota_31, -2);  iota_31 = None
    iota_32 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_200 = torch.ops.aten.unsqueeze.default(iota_32, -1);  iota_32 = None
    sub_69 = torch.ops.aten.sub.Tensor(unsqueeze_199, unsqueeze_200);  unsqueeze_199 = unsqueeze_200 = None
    ge_13 = torch.ops.aten.ge.Scalar(sub_69, 1);  sub_69 = None
    full_default_28 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_13 = torch.ops.aten.logical_and.default(ge_13, full_default_28);  ge_13 = full_default_28 = None
    full_default_29 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_201 = torch.ops.aten.unsqueeze.default(cumsum_13, 4)
    unsqueeze_202 = torch.ops.aten.unsqueeze.default(cumsum_13, 3)
    sub_70 = torch.ops.aten.sub.Tensor(unsqueeze_201, unsqueeze_202);  unsqueeze_201 = unsqueeze_202 = None
    where_28 = torch.ops.aten.where.self(logical_and_13, full_default_29, sub_70);  logical_and_13 = full_default_29 = sub_70 = None
    exp_141 = torch.ops.aten.exp.default(where_28);  where_28 = None
    mul_428 = torch.ops.aten.mul.Tensor(view_956, exp_141);  view_956 = None
    view_948 = torch.ops.aten.reshape.default(getitem_49, [1, 128, 16, 128]);  getitem_49 = None
    permute_329 = torch.ops.aten.permute.default(view_948, [0, 2, 1, 3]);  view_948 = None
    convert_element_type_666 = torch.ops.prims.convert_element_type.default(permute_329, torch.float32);  permute_329 = None
    clone_113 = torch.ops.aten.clone.default(convert_element_type_666, memory_format = torch.contiguous_format);  convert_element_type_666 = None
    unsqueeze_197 = torch.ops.aten.unsqueeze.default(clone_114, -1);  clone_114 = None
    mul_426 = torch.ops.aten.mul.Tensor(clone_113, unsqueeze_197);  clone_113 = unsqueeze_197 = None
    view_952 = torch.ops.aten.reshape.default(mul_426, [1, 16, -1, 64, 128]);  mul_426 = None
    linalg_solve_triangular_26 = torch.ops.aten.linalg_solve_triangular.default(mul_428, view_952, upper = False, unitriangular = True);  view_952 = None
    select_372 = torch.ops.aten.select.int(linalg_solve_triangular_26, 2, 0)
    exp_142 = torch.ops.aten.exp.default(cumsum_13)
    unsqueeze_203 = torch.ops.aten.unsqueeze.default(exp_142, -1);  exp_142 = None
    mul_430 = torch.ops.aten.mul.Tensor(view_951, unsqueeze_203);  view_951 = unsqueeze_203 = None
    linalg_solve_triangular_27 = torch.ops.aten.linalg_solve_triangular.default(mul_428, mul_430, upper = False, unitriangular = True);  mul_428 = mul_430 = None
    select_373 = torch.ops.aten.select.int(linalg_solve_triangular_27, 2, 0)
    expand_300 = torch.ops.aten.expand.default(select_373, [1, 16, 64, 128]);  select_373 = None
    view_960 = torch.ops.aten.reshape.default(expand_300, [16, 64, 128]);  expand_300 = None
    expand_301 = torch.ops.aten.expand.default(full_41, [1, 16, 128, 128])
    view_961 = torch.ops.aten.reshape.default(expand_301, [16, 128, 128]);  expand_301 = None
    bmm_140 = torch.ops.aten.bmm.default(view_960, view_961);  view_960 = view_961 = None
    view_962 = torch.ops.aten.reshape.default(bmm_140, [1, 16, 64, 128]);  bmm_140 = None
    sub_72 = torch.ops.aten.sub.Tensor(select_372, view_962);  select_372 = view_962 = None
    expand_307 = torch.ops.aten.expand.default(sub_72, [1, 16, 64, 128])
    view_970 = torch.ops.aten.reshape.default(expand_307, [16, 64, 128]);  expand_307 = None
    bmm_143 = torch.ops.aten.bmm.default(view_969, view_970);  view_969 = view_970 = None
    view_971 = torch.ops.aten.reshape.default(bmm_143, [1, 16, 128, 128]);  bmm_143 = None
    add_334 = torch.ops.aten.add.Tensor(mul_433, view_971);  mul_433 = view_971 = None
    select_387 = torch.ops.aten.select.int(unsqueeze_207, 2, 1);  unsqueeze_207 = None
    mul_434 = torch.ops.aten.mul.Tensor(add_334, select_387);  select_387 = None
    select_388 = torch.ops.aten.select.int(mul_432, 2, 1);  mul_432 = None
    permute_336 = torch.ops.aten.permute.default(select_388, [0, 1, 3, 2]);  select_388 = None
    expand_314 = torch.ops.aten.expand.default(permute_336, [1, 16, 128, 64]);  permute_336 = None
    view_981 = torch.ops.aten.reshape.default(expand_314, [16, 128, 64]);  expand_314 = None
    select_380 = torch.ops.aten.select.int(linalg_solve_triangular_26, 2, 1);  linalg_solve_triangular_26 = None
    select_381 = torch.ops.aten.select.int(linalg_solve_triangular_27, 2, 1);  linalg_solve_triangular_27 = None
    expand_308 = torch.ops.aten.expand.default(select_381, [1, 16, 64, 128]);  select_381 = None
    view_972 = torch.ops.aten.reshape.default(expand_308, [16, 64, 128]);  expand_308 = None
    expand_309 = torch.ops.aten.expand.default(add_334, [1, 16, 128, 128])
    view_973 = torch.ops.aten.reshape.default(expand_309, [16, 128, 128]);  expand_309 = None
    bmm_144 = torch.ops.aten.bmm.default(view_972, view_973);  view_972 = view_973 = None
    view_974 = torch.ops.aten.reshape.default(bmm_144, [1, 16, 64, 128]);  bmm_144 = None
    sub_73 = torch.ops.aten.sub.Tensor(select_380, view_974);  select_380 = view_974 = None
    expand_315 = torch.ops.aten.expand.default(sub_73, [1, 16, 64, 128])
    view_982 = torch.ops.aten.reshape.default(expand_315, [16, 64, 128]);  expand_315 = None
    bmm_147 = torch.ops.aten.bmm.default(view_981, view_982);  view_981 = view_982 = None
    view_983 = torch.ops.aten.reshape.default(bmm_147, [1, 16, 128, 128]);  bmm_147 = None
    add_336 = torch.ops.aten.add.Tensor(mul_434, view_983);  mul_434 = view_983 = None
    full_42 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_334 = torch.ops.aten.permute.default(full_42, [0, 1, 2, 4, 3]);  full_42 = None
    select_376 = torch.ops.aten.select.int(permute_334, 2, 0)
    view_946 = torch.ops.aten.reshape.default(getitem_47, [1, 128, 16, 128]);  getitem_47 = None
    permute_327 = torch.ops.aten.permute.default(view_946, [0, 2, 1, 3]);  view_946 = None
    convert_element_type_664 = torch.ops.prims.convert_element_type.default(permute_327, torch.float32);  permute_327 = None
    clone_111 = torch.ops.aten.clone.default(convert_element_type_664, memory_format = torch.contiguous_format);  convert_element_type_664 = None
    mul_421 = torch.ops.aten.mul.Tensor(clone_111, clone_111)
    sum_31 = torch.ops.aten.sum.dim_IntList(mul_421, [-1], True);  mul_421 = None
    add_331 = torch.ops.aten.add.Tensor(sum_31, 1e-06);  sum_31 = None
    rsqrt_82 = torch.ops.aten.rsqrt.default(add_331);  add_331 = None
    mul_422 = torch.ops.aten.mul.Tensor(clone_111, rsqrt_82);  clone_111 = rsqrt_82 = None
    mul_425 = torch.ops.aten.mul.Tensor(mul_422, 0.08838834764831845);  mul_422 = None
    view_949 = torch.ops.aten.reshape.default(mul_425, [1, 16, -1, 64, 128]);  mul_425 = None
    exp_143 = torch.ops.aten.exp.default(cumsum_13);  cumsum_13 = None
    unsqueeze_204 = torch.ops.aten.unsqueeze.default(exp_143, -1);  exp_143 = None
    mul_431 = torch.ops.aten.mul.Tensor(view_949, unsqueeze_204);  unsqueeze_204 = None
    select_374 = torch.ops.aten.select.int(mul_431, 2, 0)
    expand_302 = torch.ops.aten.expand.default(select_374, [1, 16, 64, 128]);  select_374 = None
    view_963 = torch.ops.aten.reshape.default(expand_302, [16, 64, 128]);  expand_302 = None
    expand_303 = torch.ops.aten.expand.default(full_41, [1, 16, 128, 128]);  full_41 = None
    view_964 = torch.ops.aten.reshape.default(expand_303, [16, 128, 128]);  expand_303 = None
    bmm_141 = torch.ops.aten.bmm.default(view_963, view_964);  view_963 = view_964 = None
    view_965 = torch.ops.aten.reshape.default(bmm_141, [1, 16, 64, 128]);  bmm_141 = None
    expand_298 = torch.ops.aten.expand.default(view_949, [1, 16, 2, 64, 128]);  view_949 = None
    view_957 = torch.ops.aten.reshape.default(expand_298, [32, 64, 128]);  expand_298 = None
    permute_333 = torch.ops.aten.permute.default(view_950, [0, 1, 2, 4, 3]);  view_950 = None
    expand_299 = torch.ops.aten.expand.default(permute_333, [1, 16, 2, 128, 64]);  permute_333 = None
    view_958 = torch.ops.aten.reshape.default(expand_299, [32, 128, 64]);  expand_299 = None
    bmm_139 = torch.ops.aten.bmm.default(view_957, view_958);  view_957 = view_958 = None
    view_959 = torch.ops.aten.reshape.default(bmm_139, [1, 16, 2, 64, 64]);  bmm_139 = None
    mul_429 = torch.ops.aten.mul.Tensor(view_959, exp_141);  view_959 = exp_141 = None
    select_375 = torch.ops.aten.select.int(mul_429, 2, 0)
    expand_304 = torch.ops.aten.expand.default(select_375, [1, 16, 64, 64]);  select_375 = None
    view_966 = torch.ops.aten.reshape.default(expand_304, [16, 64, 64]);  expand_304 = None
    expand_305 = torch.ops.aten.expand.default(sub_72, [1, 16, 64, 128]);  sub_72 = None
    view_967 = torch.ops.aten.reshape.default(expand_305, [16, 64, 128]);  expand_305 = None
    bmm_142 = torch.ops.aten.bmm.default(view_966, view_967);  view_966 = view_967 = None
    view_968 = torch.ops.aten.reshape.default(bmm_142, [1, 16, 64, 128]);  bmm_142 = None
    add_333 = torch.ops.aten.add.Tensor(view_965, view_968);  view_965 = view_968 = None
    copy_57 = torch.ops.aten.copy.default(select_376, add_333);  select_376 = add_333 = None
    select_scatter_default_30 = torch.ops.aten.select_scatter.default(permute_334, copy_57, 2, 0);  permute_334 = copy_57 = None
    select_385 = torch.ops.aten.select.int(select_scatter_default_30, 2, 1)
    select_382 = torch.ops.aten.select.int(mul_431, 2, 1);  mul_431 = None
    expand_310 = torch.ops.aten.expand.default(select_382, [1, 16, 64, 128]);  select_382 = None
    view_975 = torch.ops.aten.reshape.default(expand_310, [16, 64, 128]);  expand_310 = None
    expand_311 = torch.ops.aten.expand.default(add_334, [1, 16, 128, 128]);  add_334 = None
    view_976 = torch.ops.aten.reshape.default(expand_311, [16, 128, 128]);  expand_311 = None
    bmm_145 = torch.ops.aten.bmm.default(view_975, view_976);  view_975 = view_976 = None
    view_977 = torch.ops.aten.reshape.default(bmm_145, [1, 16, 64, 128]);  bmm_145 = None
    select_383 = torch.ops.aten.select.int(mul_429, 2, 1);  mul_429 = None
    expand_312 = torch.ops.aten.expand.default(select_383, [1, 16, 64, 64]);  select_383 = None
    view_978 = torch.ops.aten.reshape.default(expand_312, [16, 64, 64]);  expand_312 = None
    expand_313 = torch.ops.aten.expand.default(sub_73, [1, 16, 64, 128]);  sub_73 = None
    view_979 = torch.ops.aten.reshape.default(expand_313, [16, 64, 128]);  expand_313 = None
    bmm_146 = torch.ops.aten.bmm.default(view_978, view_979);  view_978 = view_979 = None
    view_980 = torch.ops.aten.reshape.default(bmm_146, [1, 16, 64, 128]);  bmm_146 = None
    add_335 = torch.ops.aten.add.Tensor(view_977, view_980);  view_977 = view_980 = None
    copy_58 = torch.ops.aten.copy.default(select_385, add_335);  select_385 = add_335 = None
    select_scatter_default_31 = torch.ops.aten.select_scatter.default(select_scatter_default_30, copy_58, 2, 1);  select_scatter_default_30 = copy_58 = None
    clone_116 = torch.ops.aten.clone.default(select_scatter_default_31, memory_format = torch.contiguous_format);  select_scatter_default_31 = None
    view_984 = torch.ops.aten.reshape.default(clone_116, [1, 16, 128, 128]);  clone_116 = None
    permute_337 = torch.ops.aten.permute.default(view_984, [0, 2, 1, 3]);  view_984 = None
    convert_element_type_668 = torch.ops.prims.convert_element_type.default(permute_337, torch.bfloat16);  permute_337 = None
    clone_117 = torch.ops.aten.clone.default(convert_element_type_668, memory_format = torch.contiguous_format);  convert_element_type_668 = None
    view_985 = torch.ops.aten.reshape.default(clone_117, [-1, 128]);  clone_117 = None
    convert_element_type_669 = torch.ops.prims.convert_element_type.default(view_985, torch.float32);  view_985 = None
    pow_57 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_669, 2)
    mean_56 = torch.ops.aten.mean.dim(pow_57, [-1], True);  pow_57 = None
    add_337 = torch.ops.aten.add.Tensor(mean_56, 1e-06);  mean_56 = None
    rsqrt_84 = torch.ops.aten.rsqrt.default(add_337);  add_337 = None
    mul_435 = torch.ops.aten.mul.Tensor(convert_element_type_669, rsqrt_84);  convert_element_type_669 = rsqrt_84 = None
    convert_element_type_670 = torch.ops.prims.convert_element_type.default(mul_435, torch.bfloat16);  mul_435 = None
    mul_436 = torch.ops.aten.mul.Tensor(arg278_1, convert_element_type_670);  arg278_1 = convert_element_type_670 = None
    view_935 = torch.ops.aten.reshape.default(convert_element_type_649, [128, 2048]);  convert_element_type_649 = None
    permute_323 = torch.ops.aten.permute.default(arg270_1, [1, 0]);  arg270_1 = None
    mm_133 = torch.ops.aten.mm.default(view_935, permute_323);  view_935 = permute_323 = None
    view_936 = torch.ops.aten.reshape.default(mm_133, [1, 128, 2048]);  mm_133 = None
    view_937 = torch.ops.aten.reshape.default(view_936, [1, 128, -1, 128]);  view_936 = None
    view_986 = torch.ops.aten.reshape.default(view_937, [-1, 128]);  view_937 = None
    convert_element_type_671 = torch.ops.prims.convert_element_type.default(view_986, torch.float32);  view_986 = None
    neg_66 = torch.ops.aten.neg.default(convert_element_type_671)
    exp_146 = torch.ops.aten.exp.default(neg_66);  neg_66 = None
    add_338 = torch.ops.aten.add.Tensor(exp_146, 1);  exp_146 = None
    div_48 = torch.ops.aten.div.Tensor(convert_element_type_671, add_338);  convert_element_type_671 = add_338 = None
    mul_437 = torch.ops.aten.mul.Tensor(mul_436, div_48);  mul_436 = div_48 = None
    convert_element_type_672 = torch.ops.prims.convert_element_type.default(mul_437, torch.bfloat16);  mul_437 = None
    view_987 = torch.ops.aten.reshape.default(convert_element_type_672, [1, 128, -1]);  convert_element_type_672 = None
    view_988 = torch.ops.aten.reshape.default(view_987, [128, 2048]);  view_987 = None
    permute_338 = torch.ops.aten.permute.default(arg279_1, [1, 0]);  arg279_1 = None
    mm_136 = torch.ops.aten.mm.default(view_988, permute_338);  view_988 = permute_338 = None
    view_989 = torch.ops.aten.reshape.default(mm_136, [1, 128, 2048]);  mm_136 = None
    add_339 = torch.ops.aten.add.Tensor(add_323, view_989);  add_323 = view_989 = None
    convert_element_type_675 = torch.ops.prims.convert_element_type.default(add_339, torch.float32)
    pow_58 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_675, 2)
    mean_57 = torch.ops.aten.mean.dim(pow_58, [-1], True);  pow_58 = None
    add_340 = torch.ops.aten.add.Tensor(mean_57, 1e-06);  mean_57 = None
    rsqrt_85 = torch.ops.aten.rsqrt.default(add_340);  add_340 = None
    mul_438 = torch.ops.aten.mul.Tensor(convert_element_type_675, rsqrt_85);  convert_element_type_675 = rsqrt_85 = None
    convert_element_type_676 = torch.ops.prims.convert_element_type.default(arg280_1, torch.float32);  arg280_1 = None
    add_341 = torch.ops.aten.add.Tensor(convert_element_type_676, 1.0);  convert_element_type_676 = None
    mul_439 = torch.ops.aten.mul.Tensor(mul_438, add_341);  mul_438 = add_341 = None
    convert_element_type_677 = torch.ops.prims.convert_element_type.default(mul_439, torch.bfloat16);  mul_439 = None
    view_990 = torch.ops.aten.reshape.default(convert_element_type_677, [128, 2048])
    permute_339 = torch.ops.aten.permute.default(arg281_1, [1, 0]);  arg281_1 = None
    mm_137 = torch.ops.aten.mm.default(view_990, permute_339);  view_990 = permute_339 = None
    view_991 = torch.ops.aten.reshape.default(mm_137, [1, 128, 6144]);  mm_137 = None
    convert_element_type_680 = torch.ops.prims.convert_element_type.default(view_991, torch.float32);  view_991 = None
    neg_67 = torch.ops.aten.neg.default(convert_element_type_680)
    exp_147 = torch.ops.aten.exp.default(neg_67);  neg_67 = None
    add_342 = torch.ops.aten.add.Tensor(exp_147, 1);  exp_147 = None
    div_49 = torch.ops.aten.div.Tensor(convert_element_type_680, add_342);  convert_element_type_680 = add_342 = None
    convert_element_type_681 = torch.ops.prims.convert_element_type.default(div_49, torch.bfloat16);  div_49 = None
    view_992 = torch.ops.aten.reshape.default(convert_element_type_677, [128, 2048]);  convert_element_type_677 = None
    permute_340 = torch.ops.aten.permute.default(arg282_1, [1, 0]);  arg282_1 = None
    mm_138 = torch.ops.aten.mm.default(view_992, permute_340);  view_992 = permute_340 = None
    view_993 = torch.ops.aten.reshape.default(mm_138, [1, 128, 6144]);  mm_138 = None
    mul_440 = torch.ops.aten.mul.Tensor(convert_element_type_681, view_993);  convert_element_type_681 = view_993 = None
    view_994 = torch.ops.aten.reshape.default(mul_440, [128, 6144]);  mul_440 = None
    permute_341 = torch.ops.aten.permute.default(arg283_1, [1, 0]);  arg283_1 = None
    mm_139 = torch.ops.aten.mm.default(view_994, permute_341);  view_994 = permute_341 = None
    view_995 = torch.ops.aten.reshape.default(mm_139, [1, 128, 2048]);  mm_139 = None
    add_343 = torch.ops.aten.add.Tensor(add_339, view_995);  add_339 = view_995 = None
    convert_element_type_686 = torch.ops.prims.convert_element_type.default(add_343, torch.float32)
    pow_59 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_686, 2)
    mean_58 = torch.ops.aten.mean.dim(pow_59, [-1], True);  pow_59 = None
    add_344 = torch.ops.aten.add.Tensor(mean_58, 1e-06);  mean_58 = None
    rsqrt_86 = torch.ops.aten.rsqrt.default(add_344);  add_344 = None
    mul_441 = torch.ops.aten.mul.Tensor(convert_element_type_686, rsqrt_86);  convert_element_type_686 = rsqrt_86 = None
    convert_element_type_687 = torch.ops.prims.convert_element_type.default(arg284_1, torch.float32);  arg284_1 = None
    add_345 = torch.ops.aten.add.Tensor(convert_element_type_687, 1.0);  convert_element_type_687 = None
    mul_442 = torch.ops.aten.mul.Tensor(mul_441, add_345);  mul_441 = add_345 = None
    convert_element_type_688 = torch.ops.prims.convert_element_type.default(mul_442, torch.bfloat16);  mul_442 = None
    view_996 = torch.ops.aten.reshape.default(convert_element_type_688, [128, 2048])
    permute_342 = torch.ops.aten.permute.default(arg285_1, [1, 0]);  arg285_1 = None
    mm_140 = torch.ops.aten.mm.default(view_996, permute_342);  view_996 = permute_342 = None
    view_997 = torch.ops.aten.reshape.default(mm_140, [1, 128, 6144]);  mm_140 = None
    permute_343 = torch.ops.aten.permute.default(view_997, [0, 2, 1]);  view_997 = None
    slice_162 = torch.ops.aten.slice.Tensor(permute_343, 2, -4, 9223372036854775807)
    copy_60 = torch.ops.aten.copy.default(arg289_1, slice_162);  slice_162 = None
    convert_element_type_697 = torch.ops.prims.convert_element_type.default(permute_343, torch.float32);  permute_343 = None
    constant_pad_nd_84 = torch.ops.aten.constant_pad_nd.default(convert_element_type_697, [3, 3], 0.0);  convert_element_type_697 = None
    slice_163 = torch.ops.aten.slice.Tensor(constant_pad_nd_84, 2, 0, 131)
    squeeze_14 = torch.ops.aten.squeeze.dim(arg290_1, 1);  arg290_1 = None
    unsqueeze_208 = torch.ops.aten.unsqueeze.default(squeeze_14, 1);  squeeze_14 = None
    convert_element_type_698 = torch.ops.prims.convert_element_type.default(unsqueeze_208, torch.float32);  unsqueeze_208 = None
    select_389 = torch.ops.aten.select.int(convert_element_type_698, 1, 0)
    select_390 = torch.ops.aten.select.int(select_389, 1, 0);  select_389 = None
    view_1005 = torch.ops.aten.reshape.default(select_390, [1, -1, 1]);  select_390 = None
    mul_443 = torch.ops.aten.mul.Tensor(slice_163, view_1005);  slice_163 = view_1005 = None
    slice_164 = torch.ops.aten.slice.Tensor(constant_pad_nd_84, 2, 1, 132)
    select_391 = torch.ops.aten.select.int(convert_element_type_698, 1, 0)
    select_392 = torch.ops.aten.select.int(select_391, 1, 1);  select_391 = None
    view_1006 = torch.ops.aten.reshape.default(select_392, [1, -1, 1]);  select_392 = None
    mul_444 = torch.ops.aten.mul.Tensor(slice_164, view_1006);  slice_164 = view_1006 = None
    add_346 = torch.ops.aten.add.Tensor(mul_443, mul_444);  mul_443 = mul_444 = None
    slice_165 = torch.ops.aten.slice.Tensor(constant_pad_nd_84, 2, 2, 133)
    select_393 = torch.ops.aten.select.int(convert_element_type_698, 1, 0)
    select_394 = torch.ops.aten.select.int(select_393, 1, 2);  select_393 = None
    view_1007 = torch.ops.aten.reshape.default(select_394, [1, -1, 1]);  select_394 = None
    mul_445 = torch.ops.aten.mul.Tensor(slice_165, view_1007);  slice_165 = view_1007 = None
    add_347 = torch.ops.aten.add.Tensor(add_346, mul_445);  add_346 = mul_445 = None
    slice_166 = torch.ops.aten.slice.Tensor(constant_pad_nd_84, 2, 3, 134);  constant_pad_nd_84 = None
    select_395 = torch.ops.aten.select.int(convert_element_type_698, 1, 0);  convert_element_type_698 = None
    select_396 = torch.ops.aten.select.int(select_395, 1, 3);  select_395 = None
    view_1008 = torch.ops.aten.reshape.default(select_396, [1, -1, 1]);  select_396 = None
    mul_446 = torch.ops.aten.mul.Tensor(slice_166, view_1008);  slice_166 = view_1008 = None
    add_348 = torch.ops.aten.add.Tensor(add_347, mul_446);  add_347 = mul_446 = None
    convert_element_type_699 = torch.ops.prims.convert_element_type.default(add_348, torch.bfloat16);  add_348 = None
    slice_167 = torch.ops.aten.slice.Tensor(convert_element_type_699, 2, 0, 128);  convert_element_type_699 = None
    convert_element_type_700 = torch.ops.prims.convert_element_type.default(slice_167, torch.float32);  slice_167 = None
    neg_68 = torch.ops.aten.neg.default(convert_element_type_700)
    exp_148 = torch.ops.aten.exp.default(neg_68);  neg_68 = None
    add_349 = torch.ops.aten.add.Tensor(exp_148, 1);  exp_148 = None
    div_50 = torch.ops.aten.div.Tensor(convert_element_type_700, add_349);  convert_element_type_700 = add_349 = None
    convert_element_type_701 = torch.ops.prims.convert_element_type.default(div_50, torch.bfloat16);  div_50 = None
    slice_168 = torch.ops.aten.slice.Tensor(convert_element_type_701, 2, -128, 9223372036854775807);  convert_element_type_701 = None
    permute_347 = torch.ops.aten.permute.default(slice_168, [0, 2, 1]);  slice_168 = None
    split_with_sizes_14 = torch.ops.aten.split_with_sizes.default(permute_347, [2048, 2048, 2048], -1);  permute_347 = None
    getitem_50 = split_with_sizes_14[0]
    getitem_51 = split_with_sizes_14[1]
    getitem_52 = split_with_sizes_14[2];  split_with_sizes_14 = None
    full_44 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_149 = torch.ops.aten.exp.default(arg291_1);  arg291_1 = None
    neg_69 = torch.ops.aten.neg.default(exp_149);  exp_149 = None
    view_1003 = torch.ops.aten.reshape.default(convert_element_type_688, [128, 2048])
    permute_346 = torch.ops.aten.permute.default(arg288_1, [1, 0]);  arg288_1 = None
    mm_143 = torch.ops.aten.mm.default(view_1003, permute_346);  view_1003 = permute_346 = None
    view_1004 = torch.ops.aten.reshape.default(mm_143, [1, 128, 16]);  mm_143 = None
    convert_element_type_702 = torch.ops.prims.convert_element_type.default(view_1004, torch.float32);  view_1004 = None
    add_350 = torch.ops.aten.add.Tensor(convert_element_type_702, arg292_1);  convert_element_type_702 = arg292_1 = None
    gt_14 = torch.ops.aten.gt.Scalar(add_350, 20)
    exp_150 = torch.ops.aten.exp.default(add_350)
    log1p_14 = torch.ops.aten.log1p.default(exp_150);  exp_150 = None
    where_29 = torch.ops.aten.where.self(gt_14, add_350, log1p_14);  gt_14 = add_350 = log1p_14 = None
    mul_447 = torch.ops.aten.mul.Tensor(neg_69, where_29);  neg_69 = where_29 = None
    permute_352 = torch.ops.aten.permute.default(mul_447, [0, 2, 1]);  mul_447 = None
    view_1016 = torch.ops.aten.reshape.default(permute_352, [1, 16, 2, 64]);  permute_352 = None
    cumsum_14 = torch.ops.aten.cumsum.default(view_1016, 3);  view_1016 = None
    select_397 = torch.ops.aten.select.int(cumsum_14, 3, -1)
    exp_155 = torch.ops.aten.exp.default(select_397);  select_397 = None
    unsqueeze_218 = torch.ops.aten.unsqueeze.default(exp_155, 3);  exp_155 = None
    unsqueeze_219 = torch.ops.aten.unsqueeze.default(unsqueeze_218, 4);  unsqueeze_218 = None
    select_404 = torch.ops.aten.select.int(unsqueeze_219, 2, 0)
    mul_460 = torch.ops.aten.mul.Tensor(full_44, select_404);  select_404 = None
    view_1010 = torch.ops.aten.reshape.default(getitem_51, [1, 128, 16, 128]);  getitem_51 = None
    permute_349 = torch.ops.aten.permute.default(view_1010, [0, 2, 1, 3]);  view_1010 = None
    convert_element_type_704 = torch.ops.prims.convert_element_type.default(permute_349, torch.float32);  permute_349 = None
    clone_119 = torch.ops.aten.clone.default(convert_element_type_704, memory_format = torch.contiguous_format);  convert_element_type_704 = None
    mul_450 = torch.ops.aten.mul.Tensor(clone_119, clone_119)
    sum_34 = torch.ops.aten.sum.dim_IntList(mul_450, [-1], True);  mul_450 = None
    add_352 = torch.ops.aten.add.Tensor(sum_34, 1e-06);  sum_34 = None
    rsqrt_88 = torch.ops.aten.rsqrt.default(add_352);  add_352 = None
    mul_451 = torch.ops.aten.mul.Tensor(clone_119, rsqrt_88);  clone_119 = rsqrt_88 = None
    view_1013 = torch.ops.aten.reshape.default(mul_451, [1, 16, -1, 64, 128])
    slice_169 = torch.ops.aten.slice.Tensor(cumsum_14, 3, -1, 9223372036854775807)
    sub_76 = torch.ops.aten.sub.Tensor(slice_169, cumsum_14);  slice_169 = None
    exp_154 = torch.ops.aten.exp.default(sub_76);  sub_76 = None
    unsqueeze_217 = torch.ops.aten.unsqueeze.default(exp_154, -1);  exp_154 = None
    mul_459 = torch.ops.aten.mul.Tensor(view_1013, unsqueeze_217);  unsqueeze_217 = None
    select_405 = torch.ops.aten.select.int(mul_459, 2, 0)
    permute_356 = torch.ops.aten.permute.default(select_405, [0, 1, 3, 2]);  select_405 = None
    expand_326 = torch.ops.aten.expand.default(permute_356, [1, 16, 128, 64]);  permute_356 = None
    view_1032 = torch.ops.aten.reshape.default(expand_326, [16, 128, 64]);  expand_326 = None
    view_1001 = torch.ops.aten.reshape.default(convert_element_type_688, [128, 2048])
    permute_345 = torch.ops.aten.permute.default(arg287_1, [1, 0]);  arg287_1 = None
    mm_142 = torch.ops.aten.mm.default(view_1001, permute_345);  view_1001 = permute_345 = None
    view_1002 = torch.ops.aten.reshape.default(mm_142, [1, 128, 16]);  mm_142 = None
    sigmoid_18 = torch.ops.aten.sigmoid.default(view_1002);  view_1002 = None
    permute_351 = torch.ops.aten.permute.default(sigmoid_18, [0, 2, 1]);  sigmoid_18 = None
    convert_element_type_706 = torch.ops.prims.convert_element_type.default(permute_351, torch.float32);  permute_351 = None
    clone_121 = torch.ops.aten.clone.default(convert_element_type_706, memory_format = torch.contiguous_format);  convert_element_type_706 = None
    unsqueeze_210 = torch.ops.aten.unsqueeze.default(clone_121, -1)
    mul_454 = torch.ops.aten.mul.Tensor(mul_451, unsqueeze_210);  mul_451 = unsqueeze_210 = None
    view_1014 = torch.ops.aten.reshape.default(mul_454, [1, 16, -1, 64, 128]);  mul_454 = None
    expand_316 = torch.ops.aten.expand.default(view_1014, [1, 16, 2, 64, 128])
    view_1017 = torch.ops.aten.reshape.default(expand_316, [32, 64, 128]);  expand_316 = None
    permute_353 = torch.ops.aten.permute.default(view_1013, [0, 1, 2, 4, 3])
    expand_317 = torch.ops.aten.expand.default(permute_353, [1, 16, 2, 128, 64]);  permute_353 = None
    view_1018 = torch.ops.aten.reshape.default(expand_317, [32, 128, 64]);  expand_317 = None
    bmm_148 = torch.ops.aten.bmm.default(view_1017, view_1018);  view_1017 = view_1018 = None
    view_1019 = torch.ops.aten.reshape.default(bmm_148, [1, 16, 2, 64, 64]);  bmm_148 = None
    iota_33 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_211 = torch.ops.aten.unsqueeze.default(iota_33, -2);  iota_33 = None
    iota_34 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_212 = torch.ops.aten.unsqueeze.default(iota_34, -1);  iota_34 = None
    sub_74 = torch.ops.aten.sub.Tensor(unsqueeze_211, unsqueeze_212);  unsqueeze_211 = unsqueeze_212 = None
    ge_14 = torch.ops.aten.ge.Scalar(sub_74, 1);  sub_74 = None
    full_default_30 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_14 = torch.ops.aten.logical_and.default(ge_14, full_default_30);  ge_14 = full_default_30 = None
    full_default_31 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_213 = torch.ops.aten.unsqueeze.default(cumsum_14, 4)
    unsqueeze_214 = torch.ops.aten.unsqueeze.default(cumsum_14, 3)
    sub_75 = torch.ops.aten.sub.Tensor(unsqueeze_213, unsqueeze_214);  unsqueeze_213 = unsqueeze_214 = None
    where_30 = torch.ops.aten.where.self(logical_and_14, full_default_31, sub_75);  logical_and_14 = full_default_31 = sub_75 = None
    exp_151 = torch.ops.aten.exp.default(where_30);  where_30 = None
    mul_455 = torch.ops.aten.mul.Tensor(view_1019, exp_151);  view_1019 = None
    view_1011 = torch.ops.aten.reshape.default(getitem_52, [1, 128, 16, 128]);  getitem_52 = None
    permute_350 = torch.ops.aten.permute.default(view_1011, [0, 2, 1, 3]);  view_1011 = None
    convert_element_type_705 = torch.ops.prims.convert_element_type.default(permute_350, torch.float32);  permute_350 = None
    clone_120 = torch.ops.aten.clone.default(convert_element_type_705, memory_format = torch.contiguous_format);  convert_element_type_705 = None
    unsqueeze_209 = torch.ops.aten.unsqueeze.default(clone_121, -1);  clone_121 = None
    mul_453 = torch.ops.aten.mul.Tensor(clone_120, unsqueeze_209);  clone_120 = unsqueeze_209 = None
    view_1015 = torch.ops.aten.reshape.default(mul_453, [1, 16, -1, 64, 128]);  mul_453 = None
    linalg_solve_triangular_28 = torch.ops.aten.linalg_solve_triangular.default(mul_455, view_1015, upper = False, unitriangular = True);  view_1015 = None
    select_398 = torch.ops.aten.select.int(linalg_solve_triangular_28, 2, 0)
    exp_152 = torch.ops.aten.exp.default(cumsum_14)
    unsqueeze_215 = torch.ops.aten.unsqueeze.default(exp_152, -1);  exp_152 = None
    mul_457 = torch.ops.aten.mul.Tensor(view_1014, unsqueeze_215);  view_1014 = unsqueeze_215 = None
    linalg_solve_triangular_29 = torch.ops.aten.linalg_solve_triangular.default(mul_455, mul_457, upper = False, unitriangular = True);  mul_455 = mul_457 = None
    select_399 = torch.ops.aten.select.int(linalg_solve_triangular_29, 2, 0)
    expand_320 = torch.ops.aten.expand.default(select_399, [1, 16, 64, 128]);  select_399 = None
    view_1023 = torch.ops.aten.reshape.default(expand_320, [16, 64, 128]);  expand_320 = None
    expand_321 = torch.ops.aten.expand.default(full_44, [1, 16, 128, 128])
    view_1024 = torch.ops.aten.reshape.default(expand_321, [16, 128, 128]);  expand_321 = None
    bmm_150 = torch.ops.aten.bmm.default(view_1023, view_1024);  view_1023 = view_1024 = None
    view_1025 = torch.ops.aten.reshape.default(bmm_150, [1, 16, 64, 128]);  bmm_150 = None
    sub_77 = torch.ops.aten.sub.Tensor(select_398, view_1025);  select_398 = view_1025 = None
    expand_327 = torch.ops.aten.expand.default(sub_77, [1, 16, 64, 128])
    view_1033 = torch.ops.aten.reshape.default(expand_327, [16, 64, 128]);  expand_327 = None
    bmm_153 = torch.ops.aten.bmm.default(view_1032, view_1033);  view_1032 = view_1033 = None
    view_1034 = torch.ops.aten.reshape.default(bmm_153, [1, 16, 128, 128]);  bmm_153 = None
    add_354 = torch.ops.aten.add.Tensor(mul_460, view_1034);  mul_460 = view_1034 = None
    select_413 = torch.ops.aten.select.int(unsqueeze_219, 2, 1);  unsqueeze_219 = None
    mul_461 = torch.ops.aten.mul.Tensor(add_354, select_413);  select_413 = None
    select_414 = torch.ops.aten.select.int(mul_459, 2, 1);  mul_459 = None
    permute_357 = torch.ops.aten.permute.default(select_414, [0, 1, 3, 2]);  select_414 = None
    expand_334 = torch.ops.aten.expand.default(permute_357, [1, 16, 128, 64]);  permute_357 = None
    view_1044 = torch.ops.aten.reshape.default(expand_334, [16, 128, 64]);  expand_334 = None
    select_406 = torch.ops.aten.select.int(linalg_solve_triangular_28, 2, 1);  linalg_solve_triangular_28 = None
    select_407 = torch.ops.aten.select.int(linalg_solve_triangular_29, 2, 1);  linalg_solve_triangular_29 = None
    expand_328 = torch.ops.aten.expand.default(select_407, [1, 16, 64, 128]);  select_407 = None
    view_1035 = torch.ops.aten.reshape.default(expand_328, [16, 64, 128]);  expand_328 = None
    expand_329 = torch.ops.aten.expand.default(add_354, [1, 16, 128, 128])
    view_1036 = torch.ops.aten.reshape.default(expand_329, [16, 128, 128]);  expand_329 = None
    bmm_154 = torch.ops.aten.bmm.default(view_1035, view_1036);  view_1035 = view_1036 = None
    view_1037 = torch.ops.aten.reshape.default(bmm_154, [1, 16, 64, 128]);  bmm_154 = None
    sub_78 = torch.ops.aten.sub.Tensor(select_406, view_1037);  select_406 = view_1037 = None
    expand_335 = torch.ops.aten.expand.default(sub_78, [1, 16, 64, 128])
    view_1045 = torch.ops.aten.reshape.default(expand_335, [16, 64, 128]);  expand_335 = None
    bmm_157 = torch.ops.aten.bmm.default(view_1044, view_1045);  view_1044 = view_1045 = None
    view_1046 = torch.ops.aten.reshape.default(bmm_157, [1, 16, 128, 128]);  bmm_157 = None
    add_356 = torch.ops.aten.add.Tensor(mul_461, view_1046);  mul_461 = view_1046 = None
    full_45 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_355 = torch.ops.aten.permute.default(full_45, [0, 1, 2, 4, 3]);  full_45 = None
    select_402 = torch.ops.aten.select.int(permute_355, 2, 0)
    view_1009 = torch.ops.aten.reshape.default(getitem_50, [1, 128, 16, 128]);  getitem_50 = None
    permute_348 = torch.ops.aten.permute.default(view_1009, [0, 2, 1, 3]);  view_1009 = None
    convert_element_type_703 = torch.ops.prims.convert_element_type.default(permute_348, torch.float32);  permute_348 = None
    clone_118 = torch.ops.aten.clone.default(convert_element_type_703, memory_format = torch.contiguous_format);  convert_element_type_703 = None
    mul_448 = torch.ops.aten.mul.Tensor(clone_118, clone_118)
    sum_33 = torch.ops.aten.sum.dim_IntList(mul_448, [-1], True);  mul_448 = None
    add_351 = torch.ops.aten.add.Tensor(sum_33, 1e-06);  sum_33 = None
    rsqrt_87 = torch.ops.aten.rsqrt.default(add_351);  add_351 = None
    mul_449 = torch.ops.aten.mul.Tensor(clone_118, rsqrt_87);  clone_118 = rsqrt_87 = None
    mul_452 = torch.ops.aten.mul.Tensor(mul_449, 0.08838834764831845);  mul_449 = None
    view_1012 = torch.ops.aten.reshape.default(mul_452, [1, 16, -1, 64, 128]);  mul_452 = None
    exp_153 = torch.ops.aten.exp.default(cumsum_14);  cumsum_14 = None
    unsqueeze_216 = torch.ops.aten.unsqueeze.default(exp_153, -1);  exp_153 = None
    mul_458 = torch.ops.aten.mul.Tensor(view_1012, unsqueeze_216);  unsqueeze_216 = None
    select_400 = torch.ops.aten.select.int(mul_458, 2, 0)
    expand_322 = torch.ops.aten.expand.default(select_400, [1, 16, 64, 128]);  select_400 = None
    view_1026 = torch.ops.aten.reshape.default(expand_322, [16, 64, 128]);  expand_322 = None
    expand_323 = torch.ops.aten.expand.default(full_44, [1, 16, 128, 128]);  full_44 = None
    view_1027 = torch.ops.aten.reshape.default(expand_323, [16, 128, 128]);  expand_323 = None
    bmm_151 = torch.ops.aten.bmm.default(view_1026, view_1027);  view_1026 = view_1027 = None
    view_1028 = torch.ops.aten.reshape.default(bmm_151, [1, 16, 64, 128]);  bmm_151 = None
    expand_318 = torch.ops.aten.expand.default(view_1012, [1, 16, 2, 64, 128]);  view_1012 = None
    view_1020 = torch.ops.aten.reshape.default(expand_318, [32, 64, 128]);  expand_318 = None
    permute_354 = torch.ops.aten.permute.default(view_1013, [0, 1, 2, 4, 3]);  view_1013 = None
    expand_319 = torch.ops.aten.expand.default(permute_354, [1, 16, 2, 128, 64]);  permute_354 = None
    view_1021 = torch.ops.aten.reshape.default(expand_319, [32, 128, 64]);  expand_319 = None
    bmm_149 = torch.ops.aten.bmm.default(view_1020, view_1021);  view_1020 = view_1021 = None
    view_1022 = torch.ops.aten.reshape.default(bmm_149, [1, 16, 2, 64, 64]);  bmm_149 = None
    mul_456 = torch.ops.aten.mul.Tensor(view_1022, exp_151);  view_1022 = exp_151 = None
    select_401 = torch.ops.aten.select.int(mul_456, 2, 0)
    expand_324 = torch.ops.aten.expand.default(select_401, [1, 16, 64, 64]);  select_401 = None
    view_1029 = torch.ops.aten.reshape.default(expand_324, [16, 64, 64]);  expand_324 = None
    expand_325 = torch.ops.aten.expand.default(sub_77, [1, 16, 64, 128]);  sub_77 = None
    view_1030 = torch.ops.aten.reshape.default(expand_325, [16, 64, 128]);  expand_325 = None
    bmm_152 = torch.ops.aten.bmm.default(view_1029, view_1030);  view_1029 = view_1030 = None
    view_1031 = torch.ops.aten.reshape.default(bmm_152, [1, 16, 64, 128]);  bmm_152 = None
    add_353 = torch.ops.aten.add.Tensor(view_1028, view_1031);  view_1028 = view_1031 = None
    copy_61 = torch.ops.aten.copy.default(select_402, add_353);  select_402 = add_353 = None
    select_scatter_default_32 = torch.ops.aten.select_scatter.default(permute_355, copy_61, 2, 0);  permute_355 = copy_61 = None
    select_411 = torch.ops.aten.select.int(select_scatter_default_32, 2, 1)
    select_408 = torch.ops.aten.select.int(mul_458, 2, 1);  mul_458 = None
    expand_330 = torch.ops.aten.expand.default(select_408, [1, 16, 64, 128]);  select_408 = None
    view_1038 = torch.ops.aten.reshape.default(expand_330, [16, 64, 128]);  expand_330 = None
    expand_331 = torch.ops.aten.expand.default(add_354, [1, 16, 128, 128]);  add_354 = None
    view_1039 = torch.ops.aten.reshape.default(expand_331, [16, 128, 128]);  expand_331 = None
    bmm_155 = torch.ops.aten.bmm.default(view_1038, view_1039);  view_1038 = view_1039 = None
    view_1040 = torch.ops.aten.reshape.default(bmm_155, [1, 16, 64, 128]);  bmm_155 = None
    select_409 = torch.ops.aten.select.int(mul_456, 2, 1);  mul_456 = None
    expand_332 = torch.ops.aten.expand.default(select_409, [1, 16, 64, 64]);  select_409 = None
    view_1041 = torch.ops.aten.reshape.default(expand_332, [16, 64, 64]);  expand_332 = None
    expand_333 = torch.ops.aten.expand.default(sub_78, [1, 16, 64, 128]);  sub_78 = None
    view_1042 = torch.ops.aten.reshape.default(expand_333, [16, 64, 128]);  expand_333 = None
    bmm_156 = torch.ops.aten.bmm.default(view_1041, view_1042);  view_1041 = view_1042 = None
    view_1043 = torch.ops.aten.reshape.default(bmm_156, [1, 16, 64, 128]);  bmm_156 = None
    add_355 = torch.ops.aten.add.Tensor(view_1040, view_1043);  view_1040 = view_1043 = None
    copy_62 = torch.ops.aten.copy.default(select_411, add_355);  select_411 = add_355 = None
    select_scatter_default_33 = torch.ops.aten.select_scatter.default(select_scatter_default_32, copy_62, 2, 1);  select_scatter_default_32 = copy_62 = None
    clone_123 = torch.ops.aten.clone.default(select_scatter_default_33, memory_format = torch.contiguous_format);  select_scatter_default_33 = None
    view_1047 = torch.ops.aten.reshape.default(clone_123, [1, 16, 128, 128]);  clone_123 = None
    permute_358 = torch.ops.aten.permute.default(view_1047, [0, 2, 1, 3]);  view_1047 = None
    convert_element_type_707 = torch.ops.prims.convert_element_type.default(permute_358, torch.bfloat16);  permute_358 = None
    clone_124 = torch.ops.aten.clone.default(convert_element_type_707, memory_format = torch.contiguous_format);  convert_element_type_707 = None
    view_1048 = torch.ops.aten.reshape.default(clone_124, [-1, 128]);  clone_124 = None
    convert_element_type_708 = torch.ops.prims.convert_element_type.default(view_1048, torch.float32);  view_1048 = None
    pow_60 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_708, 2)
    mean_59 = torch.ops.aten.mean.dim(pow_60, [-1], True);  pow_60 = None
    add_357 = torch.ops.aten.add.Tensor(mean_59, 1e-06);  mean_59 = None
    rsqrt_89 = torch.ops.aten.rsqrt.default(add_357);  add_357 = None
    mul_462 = torch.ops.aten.mul.Tensor(convert_element_type_708, rsqrt_89);  convert_element_type_708 = rsqrt_89 = None
    convert_element_type_709 = torch.ops.prims.convert_element_type.default(mul_462, torch.bfloat16);  mul_462 = None
    mul_463 = torch.ops.aten.mul.Tensor(arg294_1, convert_element_type_709);  arg294_1 = convert_element_type_709 = None
    view_998 = torch.ops.aten.reshape.default(convert_element_type_688, [128, 2048]);  convert_element_type_688 = None
    permute_344 = torch.ops.aten.permute.default(arg286_1, [1, 0]);  arg286_1 = None
    mm_141 = torch.ops.aten.mm.default(view_998, permute_344);  view_998 = permute_344 = None
    view_999 = torch.ops.aten.reshape.default(mm_141, [1, 128, 2048]);  mm_141 = None
    view_1000 = torch.ops.aten.reshape.default(view_999, [1, 128, -1, 128]);  view_999 = None
    view_1049 = torch.ops.aten.reshape.default(view_1000, [-1, 128]);  view_1000 = None
    convert_element_type_710 = torch.ops.prims.convert_element_type.default(view_1049, torch.float32);  view_1049 = None
    neg_70 = torch.ops.aten.neg.default(convert_element_type_710)
    exp_156 = torch.ops.aten.exp.default(neg_70);  neg_70 = None
    add_358 = torch.ops.aten.add.Tensor(exp_156, 1);  exp_156 = None
    div_51 = torch.ops.aten.div.Tensor(convert_element_type_710, add_358);  convert_element_type_710 = add_358 = None
    mul_464 = torch.ops.aten.mul.Tensor(mul_463, div_51);  mul_463 = div_51 = None
    convert_element_type_711 = torch.ops.prims.convert_element_type.default(mul_464, torch.bfloat16);  mul_464 = None
    view_1050 = torch.ops.aten.reshape.default(convert_element_type_711, [1, 128, -1]);  convert_element_type_711 = None
    view_1051 = torch.ops.aten.reshape.default(view_1050, [128, 2048]);  view_1050 = None
    permute_359 = torch.ops.aten.permute.default(arg295_1, [1, 0]);  arg295_1 = None
    mm_144 = torch.ops.aten.mm.default(view_1051, permute_359);  view_1051 = permute_359 = None
    view_1052 = torch.ops.aten.reshape.default(mm_144, [1, 128, 2048]);  mm_144 = None
    add_359 = torch.ops.aten.add.Tensor(add_343, view_1052);  add_343 = view_1052 = None
    convert_element_type_714 = torch.ops.prims.convert_element_type.default(add_359, torch.float32)
    pow_61 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_714, 2)
    mean_60 = torch.ops.aten.mean.dim(pow_61, [-1], True);  pow_61 = None
    add_360 = torch.ops.aten.add.Tensor(mean_60, 1e-06);  mean_60 = None
    rsqrt_90 = torch.ops.aten.rsqrt.default(add_360);  add_360 = None
    mul_465 = torch.ops.aten.mul.Tensor(convert_element_type_714, rsqrt_90);  convert_element_type_714 = rsqrt_90 = None
    convert_element_type_715 = torch.ops.prims.convert_element_type.default(arg296_1, torch.float32);  arg296_1 = None
    add_361 = torch.ops.aten.add.Tensor(convert_element_type_715, 1.0);  convert_element_type_715 = None
    mul_466 = torch.ops.aten.mul.Tensor(mul_465, add_361);  mul_465 = add_361 = None
    convert_element_type_716 = torch.ops.prims.convert_element_type.default(mul_466, torch.bfloat16);  mul_466 = None
    view_1053 = torch.ops.aten.reshape.default(convert_element_type_716, [128, 2048])
    permute_360 = torch.ops.aten.permute.default(arg297_1, [1, 0]);  arg297_1 = None
    mm_145 = torch.ops.aten.mm.default(view_1053, permute_360);  view_1053 = permute_360 = None
    view_1054 = torch.ops.aten.reshape.default(mm_145, [1, 128, 6144]);  mm_145 = None
    convert_element_type_719 = torch.ops.prims.convert_element_type.default(view_1054, torch.float32);  view_1054 = None
    neg_71 = torch.ops.aten.neg.default(convert_element_type_719)
    exp_157 = torch.ops.aten.exp.default(neg_71);  neg_71 = None
    add_362 = torch.ops.aten.add.Tensor(exp_157, 1);  exp_157 = None
    div_52 = torch.ops.aten.div.Tensor(convert_element_type_719, add_362);  convert_element_type_719 = add_362 = None
    convert_element_type_720 = torch.ops.prims.convert_element_type.default(div_52, torch.bfloat16);  div_52 = None
    view_1055 = torch.ops.aten.reshape.default(convert_element_type_716, [128, 2048]);  convert_element_type_716 = None
    permute_361 = torch.ops.aten.permute.default(arg298_1, [1, 0]);  arg298_1 = None
    mm_146 = torch.ops.aten.mm.default(view_1055, permute_361);  view_1055 = permute_361 = None
    view_1056 = torch.ops.aten.reshape.default(mm_146, [1, 128, 6144]);  mm_146 = None
    mul_467 = torch.ops.aten.mul.Tensor(convert_element_type_720, view_1056);  convert_element_type_720 = view_1056 = None
    view_1057 = torch.ops.aten.reshape.default(mul_467, [128, 6144]);  mul_467 = None
    permute_362 = torch.ops.aten.permute.default(arg299_1, [1, 0]);  arg299_1 = None
    mm_147 = torch.ops.aten.mm.default(view_1057, permute_362);  view_1057 = permute_362 = None
    view_1058 = torch.ops.aten.reshape.default(mm_147, [1, 128, 2048]);  mm_147 = None
    add_363 = torch.ops.aten.add.Tensor(add_359, view_1058);  add_359 = view_1058 = None
    convert_element_type_725 = torch.ops.prims.convert_element_type.default(add_363, torch.float32)
    pow_62 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_725, 2)
    mean_61 = torch.ops.aten.mean.dim(pow_62, [-1], True);  pow_62 = None
    add_364 = torch.ops.aten.add.Tensor(mean_61, 1e-06);  mean_61 = None
    rsqrt_91 = torch.ops.aten.rsqrt.default(add_364);  add_364 = None
    mul_468 = torch.ops.aten.mul.Tensor(convert_element_type_725, rsqrt_91);  convert_element_type_725 = rsqrt_91 = None
    convert_element_type_726 = torch.ops.prims.convert_element_type.default(arg300_1, torch.float32);  arg300_1 = None
    add_365 = torch.ops.aten.add.Tensor(convert_element_type_726, 1.0);  convert_element_type_726 = None
    mul_469 = torch.ops.aten.mul.Tensor(mul_468, add_365);  mul_468 = add_365 = None
    convert_element_type_727 = torch.ops.prims.convert_element_type.default(mul_469, torch.bfloat16);  mul_469 = None
    view_1059 = torch.ops.aten.reshape.default(convert_element_type_727, [128, 2048])
    permute_363 = torch.ops.aten.permute.default(arg301_1, [1, 0]);  arg301_1 = None
    mm_148 = torch.ops.aten.mm.default(view_1059, permute_363);  view_1059 = permute_363 = None
    view_1060 = torch.ops.aten.reshape.default(mm_148, [1, 128, 4096]);  mm_148 = None
    view_1061 = torch.ops.aten.reshape.default(view_1060, [1, 128, -1, 512]);  view_1060 = None
    split_4 = torch.ops.aten.split.Tensor(view_1061, 256, -1);  view_1061 = None
    getitem_53 = split_4[0]
    getitem_54 = split_4[1];  split_4 = None
    add_373 = torch.ops.aten.add.Tensor(arg306_1, 128)
    convert_element_type_730 = torch.ops.prims.convert_element_type.default(getitem_53, torch.float32);  getitem_53 = None
    pow_63 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_730, 2)
    mean_62 = torch.ops.aten.mean.dim(pow_63, [-1], True);  pow_63 = None
    add_366 = torch.ops.aten.add.Tensor(mean_62, 1e-06);  mean_62 = None
    rsqrt_92 = torch.ops.aten.rsqrt.default(add_366);  add_366 = None
    mul_470 = torch.ops.aten.mul.Tensor(convert_element_type_730, rsqrt_92);  convert_element_type_730 = rsqrt_92 = None
    convert_element_type_731 = torch.ops.prims.convert_element_type.default(arg302_1, torch.float32);  arg302_1 = None
    add_367 = torch.ops.aten.add.Tensor(convert_element_type_731, 1.0);  convert_element_type_731 = None
    mul_471 = torch.ops.aten.mul.Tensor(mul_470, add_367);  mul_470 = add_367 = None
    convert_element_type_732 = torch.ops.prims.convert_element_type.default(mul_471, torch.bfloat16);  mul_471 = None
    permute_364 = torch.ops.aten.permute.default(convert_element_type_732, [0, 2, 1, 3]);  convert_element_type_732 = None
    slice_170 = torch.ops.aten.slice.Tensor(permute_364, 3, 0, 64)
    unsqueeze_220 = torch.ops.aten.unsqueeze.default(convert_element_type_2, 1)
    mul_474 = torch.ops.aten.mul.Tensor(slice_170, unsqueeze_220)
    slice_175 = torch.ops.aten.slice.Tensor(slice_170, 3, 32, 9223372036854775807)
    neg_72 = torch.ops.aten.neg.default(slice_175);  slice_175 = None
    slice_174 = torch.ops.aten.slice.Tensor(slice_170, 3, 0, 32);  slice_170 = None
    cat_16 = torch.ops.aten.cat.default([neg_72, slice_174], -1);  neg_72 = slice_174 = None
    unsqueeze_221 = torch.ops.aten.unsqueeze.default(convert_element_type_3, 1)
    mul_475 = torch.ops.aten.mul.Tensor(cat_16, unsqueeze_221);  cat_16 = None
    add_370 = torch.ops.aten.add.Tensor(mul_474, mul_475);  mul_474 = mul_475 = None
    slice_171 = torch.ops.aten.slice.Tensor(permute_364, 3, 64, 9223372036854775807);  permute_364 = None
    cat_18 = torch.ops.aten.cat.default([add_370, slice_171], -1);  add_370 = slice_171 = None
    expand_340 = torch.ops.aten.expand.default(cat_18, [1, 8, 128, 256]);  cat_18 = None
    view_1072 = torch.ops.aten.reshape.default(expand_340, [8, 128, 256]);  expand_340 = None
    iota_35 = torch.ops.prims.iota.default(128, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    add_372 = torch.ops.aten.add.Tensor(iota_35, arg306_1);  iota_35 = None
    view_1064 = torch.ops.aten.reshape.default(convert_element_type_727, [128, 2048])
    permute_365 = torch.ops.aten.permute.default(arg303_1, [1, 0]);  arg303_1 = None
    mm_149 = torch.ops.aten.mm.default(view_1064, permute_365);  view_1064 = permute_365 = None
    view_1065 = torch.ops.aten.reshape.default(mm_149, [1, 128, 512]);  mm_149 = None
    view_1066 = torch.ops.aten.reshape.default(view_1065, [1, 128, -1, 256]);  view_1065 = None
    convert_element_type_735 = torch.ops.prims.convert_element_type.default(view_1066, torch.float32);  view_1066 = None
    pow_64 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_735, 2)
    mean_63 = torch.ops.aten.mean.dim(pow_64, [-1], True);  pow_64 = None
    add_368 = torch.ops.aten.add.Tensor(mean_63, 1e-06);  mean_63 = None
    rsqrt_93 = torch.ops.aten.rsqrt.default(add_368);  add_368 = None
    mul_472 = torch.ops.aten.mul.Tensor(convert_element_type_735, rsqrt_93);  convert_element_type_735 = rsqrt_93 = None
    convert_element_type_736 = torch.ops.prims.convert_element_type.default(arg304_1, torch.float32);  arg304_1 = None
    add_369 = torch.ops.aten.add.Tensor(convert_element_type_736, 1.0);  convert_element_type_736 = None
    mul_473 = torch.ops.aten.mul.Tensor(mul_472, add_369);  mul_472 = add_369 = None
    convert_element_type_737 = torch.ops.prims.convert_element_type.default(mul_473, torch.bfloat16);  mul_473 = None
    permute_366 = torch.ops.aten.permute.default(convert_element_type_737, [0, 2, 1, 3]);  convert_element_type_737 = None
    slice_172 = torch.ops.aten.slice.Tensor(permute_366, 3, 0, 64)
    mul_476 = torch.ops.aten.mul.Tensor(slice_172, unsqueeze_220);  unsqueeze_220 = None
    slice_177 = torch.ops.aten.slice.Tensor(slice_172, 3, 32, 9223372036854775807)
    neg_73 = torch.ops.aten.neg.default(slice_177);  slice_177 = None
    slice_176 = torch.ops.aten.slice.Tensor(slice_172, 3, 0, 32);  slice_172 = None
    cat_17 = torch.ops.aten.cat.default([neg_73, slice_176], -1);  neg_73 = slice_176 = None
    mul_477 = torch.ops.aten.mul.Tensor(cat_17, unsqueeze_221);  cat_17 = unsqueeze_221 = None
    add_371 = torch.ops.aten.add.Tensor(mul_476, mul_477);  mul_476 = mul_477 = None
    slice_173 = torch.ops.aten.slice.Tensor(permute_366, 3, 64, 9223372036854775807);  permute_366 = None
    cat_19 = torch.ops.aten.cat.default([add_371, slice_173], -1);  add_371 = slice_173 = None
    index_put_8 = torch.ops.aten.index_put_.default(arg307_1, [None, None, add_372], cat_19);  arg307_1 = cat_19 = None
    unsqueeze_224 = torch.ops.aten.unsqueeze.default(index_put_8, 2);  index_put_8 = None
    expand_337 = torch.ops.aten.expand.default(unsqueeze_224, [1, 2, 4, 144, 256]);  unsqueeze_224 = None
    clone_126 = torch.ops.aten.clone.default(expand_337, memory_format = torch.contiguous_format);  expand_337 = None
    view_1070 = torch.ops.aten.reshape.default(clone_126, [1, 8, 144, 256]);  clone_126 = None
    permute_369 = torch.ops.aten.permute.default(view_1070, [0, 1, 3, 2]);  view_1070 = None
    expand_341 = torch.ops.aten.expand.default(permute_369, [1, 8, 256, 144]);  permute_369 = None
    view_1073 = torch.ops.aten.reshape.default(expand_341, [8, 256, 144]);  expand_341 = None
    bmm_158 = torch.ops.aten.bmm.default(view_1072, view_1073);  view_1072 = view_1073 = None
    view_1074 = torch.ops.aten.reshape.default(bmm_158, [1, 8, 128, 144]);  bmm_158 = None
    mul_478 = torch.ops.aten.mul.Tensor(view_1074, 0.0625);  view_1074 = None
    add_374 = torch.ops.aten.add.Tensor(mul_478, unsqueeze_3);  mul_478 = None
    convert_element_type_742 = torch.ops.prims.convert_element_type.default(add_374, torch.float32);  add_374 = None
    amax_4 = torch.ops.aten.amax.default(convert_element_type_742, [-1], True)
    sub_79 = torch.ops.aten.sub.Tensor(convert_element_type_742, amax_4);  convert_element_type_742 = amax_4 = None
    exp_158 = torch.ops.aten.exp.default(sub_79);  sub_79 = None
    sum_35 = torch.ops.aten.sum.dim_IntList(exp_158, [-1], True)
    div_53 = torch.ops.aten.div.Tensor(exp_158, sum_35);  exp_158 = sum_35 = None
    convert_element_type_743 = torch.ops.prims.convert_element_type.default(div_53, torch.bfloat16);  div_53 = None
    expand_342 = torch.ops.aten.expand.default(convert_element_type_743, [1, 8, 128, 144]);  convert_element_type_743 = None
    view_1075 = torch.ops.aten.reshape.default(expand_342, [8, 128, 144]);  expand_342 = None
    view_1067 = torch.ops.aten.reshape.default(convert_element_type_727, [128, 2048]);  convert_element_type_727 = None
    permute_367 = torch.ops.aten.permute.default(arg305_1, [1, 0]);  arg305_1 = None
    mm_150 = torch.ops.aten.mm.default(view_1067, permute_367);  view_1067 = permute_367 = None
    view_1068 = torch.ops.aten.reshape.default(mm_150, [1, 128, 512]);  mm_150 = None
    view_1069 = torch.ops.aten.reshape.default(view_1068, [1, 128, -1, 256]);  view_1068 = None
    permute_368 = torch.ops.aten.permute.default(view_1069, [0, 2, 1, 3]);  view_1069 = None
    index_put_9 = torch.ops.aten.index_put_.default(arg308_1, [None, None, add_372], permute_368);  arg308_1 = add_372 = permute_368 = None
    unsqueeze_227 = torch.ops.aten.unsqueeze.default(index_put_9, 2);  index_put_9 = None
    expand_339 = torch.ops.aten.expand.default(unsqueeze_227, [1, 2, 4, 144, 256]);  unsqueeze_227 = None
    clone_127 = torch.ops.aten.clone.default(expand_339, memory_format = torch.contiguous_format);  expand_339 = None
    view_1071 = torch.ops.aten.reshape.default(clone_127, [1, 8, 144, 256]);  clone_127 = None
    expand_343 = torch.ops.aten.expand.default(view_1071, [1, 8, 144, 256]);  view_1071 = None
    view_1076 = torch.ops.aten.reshape.default(expand_343, [8, 144, 256]);  expand_343 = None
    bmm_159 = torch.ops.aten.bmm.default(view_1075, view_1076);  view_1075 = view_1076 = None
    view_1077 = torch.ops.aten.reshape.default(bmm_159, [1, 8, 128, 256]);  bmm_159 = None
    permute_370 = torch.ops.aten.permute.default(view_1077, [0, 2, 1, 3]);  view_1077 = None
    clone_128 = torch.ops.aten.clone.default(permute_370, memory_format = torch.contiguous_format);  permute_370 = None
    view_1078 = torch.ops.aten.reshape.default(clone_128, [1, 128, -1]);  clone_128 = None
    clone_125 = torch.ops.aten.clone.default(getitem_54, memory_format = torch.contiguous_format);  getitem_54 = None
    view_1062 = torch.ops.aten.reshape.default(clone_125, [1, 128, 2048]);  clone_125 = None
    sigmoid_19 = torch.ops.aten.sigmoid.default(view_1062);  view_1062 = None
    mul_479 = torch.ops.aten.mul.Tensor(view_1078, sigmoid_19);  view_1078 = sigmoid_19 = None
    view_1079 = torch.ops.aten.reshape.default(mul_479, [128, 2048]);  mul_479 = None
    permute_371 = torch.ops.aten.permute.default(arg309_1, [1, 0]);  arg309_1 = None
    mm_151 = torch.ops.aten.mm.default(view_1079, permute_371);  view_1079 = permute_371 = None
    view_1080 = torch.ops.aten.reshape.default(mm_151, [1, 128, 2048]);  mm_151 = None
    add_375 = torch.ops.aten.add.Tensor(add_363, view_1080);  add_363 = view_1080 = None
    convert_element_type_748 = torch.ops.prims.convert_element_type.default(add_375, torch.float32)
    pow_65 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_748, 2)
    mean_64 = torch.ops.aten.mean.dim(pow_65, [-1], True);  pow_65 = None
    add_376 = torch.ops.aten.add.Tensor(mean_64, 1e-06);  mean_64 = None
    rsqrt_94 = torch.ops.aten.rsqrt.default(add_376);  add_376 = None
    mul_480 = torch.ops.aten.mul.Tensor(convert_element_type_748, rsqrt_94);  convert_element_type_748 = rsqrt_94 = None
    convert_element_type_749 = torch.ops.prims.convert_element_type.default(arg310_1, torch.float32);  arg310_1 = None
    add_377 = torch.ops.aten.add.Tensor(convert_element_type_749, 1.0);  convert_element_type_749 = None
    mul_481 = torch.ops.aten.mul.Tensor(mul_480, add_377);  mul_480 = add_377 = None
    convert_element_type_750 = torch.ops.prims.convert_element_type.default(mul_481, torch.bfloat16);  mul_481 = None
    view_1081 = torch.ops.aten.reshape.default(convert_element_type_750, [128, 2048])
    permute_372 = torch.ops.aten.permute.default(arg311_1, [1, 0]);  arg311_1 = None
    mm_152 = torch.ops.aten.mm.default(view_1081, permute_372);  view_1081 = permute_372 = None
    view_1082 = torch.ops.aten.reshape.default(mm_152, [1, 128, 6144]);  mm_152 = None
    convert_element_type_753 = torch.ops.prims.convert_element_type.default(view_1082, torch.float32);  view_1082 = None
    neg_74 = torch.ops.aten.neg.default(convert_element_type_753)
    exp_159 = torch.ops.aten.exp.default(neg_74);  neg_74 = None
    add_378 = torch.ops.aten.add.Tensor(exp_159, 1);  exp_159 = None
    div_54 = torch.ops.aten.div.Tensor(convert_element_type_753, add_378);  convert_element_type_753 = add_378 = None
    convert_element_type_754 = torch.ops.prims.convert_element_type.default(div_54, torch.bfloat16);  div_54 = None
    view_1083 = torch.ops.aten.reshape.default(convert_element_type_750, [128, 2048]);  convert_element_type_750 = None
    permute_373 = torch.ops.aten.permute.default(arg312_1, [1, 0]);  arg312_1 = None
    mm_153 = torch.ops.aten.mm.default(view_1083, permute_373);  view_1083 = permute_373 = None
    view_1084 = torch.ops.aten.reshape.default(mm_153, [1, 128, 6144]);  mm_153 = None
    mul_482 = torch.ops.aten.mul.Tensor(convert_element_type_754, view_1084);  convert_element_type_754 = view_1084 = None
    view_1085 = torch.ops.aten.reshape.default(mul_482, [128, 6144]);  mul_482 = None
    permute_374 = torch.ops.aten.permute.default(arg313_1, [1, 0]);  arg313_1 = None
    mm_154 = torch.ops.aten.mm.default(view_1085, permute_374);  view_1085 = permute_374 = None
    view_1086 = torch.ops.aten.reshape.default(mm_154, [1, 128, 2048]);  mm_154 = None
    add_379 = torch.ops.aten.add.Tensor(add_375, view_1086);  add_375 = view_1086 = None
    convert_element_type_759 = torch.ops.prims.convert_element_type.default(add_379, torch.float32)
    pow_66 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_759, 2)
    mean_65 = torch.ops.aten.mean.dim(pow_66, [-1], True);  pow_66 = None
    add_380 = torch.ops.aten.add.Tensor(mean_65, 1e-06);  mean_65 = None
    rsqrt_95 = torch.ops.aten.rsqrt.default(add_380);  add_380 = None
    mul_483 = torch.ops.aten.mul.Tensor(convert_element_type_759, rsqrt_95);  convert_element_type_759 = rsqrt_95 = None
    convert_element_type_760 = torch.ops.prims.convert_element_type.default(arg314_1, torch.float32);  arg314_1 = None
    add_381 = torch.ops.aten.add.Tensor(convert_element_type_760, 1.0);  convert_element_type_760 = None
    mul_484 = torch.ops.aten.mul.Tensor(mul_483, add_381);  mul_483 = add_381 = None
    convert_element_type_761 = torch.ops.prims.convert_element_type.default(mul_484, torch.bfloat16);  mul_484 = None
    view_1087 = torch.ops.aten.reshape.default(convert_element_type_761, [128, 2048])
    permute_375 = torch.ops.aten.permute.default(arg315_1, [1, 0]);  arg315_1 = None
    mm_155 = torch.ops.aten.mm.default(view_1087, permute_375);  view_1087 = permute_375 = None
    view_1088 = torch.ops.aten.reshape.default(mm_155, [1, 128, 6144]);  mm_155 = None
    permute_376 = torch.ops.aten.permute.default(view_1088, [0, 2, 1]);  view_1088 = None
    slice_178 = torch.ops.aten.slice.Tensor(permute_376, 2, -4, 9223372036854775807)
    copy_64 = torch.ops.aten.copy.default(arg319_1, slice_178);  slice_178 = None
    convert_element_type_770 = torch.ops.prims.convert_element_type.default(permute_376, torch.float32);  permute_376 = None
    constant_pad_nd_90 = torch.ops.aten.constant_pad_nd.default(convert_element_type_770, [3, 3], 0.0);  convert_element_type_770 = None
    slice_179 = torch.ops.aten.slice.Tensor(constant_pad_nd_90, 2, 0, 131)
    squeeze_15 = torch.ops.aten.squeeze.dim(arg320_1, 1);  arg320_1 = None
    unsqueeze_228 = torch.ops.aten.unsqueeze.default(squeeze_15, 1);  squeeze_15 = None
    convert_element_type_771 = torch.ops.prims.convert_element_type.default(unsqueeze_228, torch.float32);  unsqueeze_228 = None
    select_415 = torch.ops.aten.select.int(convert_element_type_771, 1, 0)
    select_416 = torch.ops.aten.select.int(select_415, 1, 0);  select_415 = None
    view_1096 = torch.ops.aten.reshape.default(select_416, [1, -1, 1]);  select_416 = None
    mul_485 = torch.ops.aten.mul.Tensor(slice_179, view_1096);  slice_179 = view_1096 = None
    slice_180 = torch.ops.aten.slice.Tensor(constant_pad_nd_90, 2, 1, 132)
    select_417 = torch.ops.aten.select.int(convert_element_type_771, 1, 0)
    select_418 = torch.ops.aten.select.int(select_417, 1, 1);  select_417 = None
    view_1097 = torch.ops.aten.reshape.default(select_418, [1, -1, 1]);  select_418 = None
    mul_486 = torch.ops.aten.mul.Tensor(slice_180, view_1097);  slice_180 = view_1097 = None
    add_382 = torch.ops.aten.add.Tensor(mul_485, mul_486);  mul_485 = mul_486 = None
    slice_181 = torch.ops.aten.slice.Tensor(constant_pad_nd_90, 2, 2, 133)
    select_419 = torch.ops.aten.select.int(convert_element_type_771, 1, 0)
    select_420 = torch.ops.aten.select.int(select_419, 1, 2);  select_419 = None
    view_1098 = torch.ops.aten.reshape.default(select_420, [1, -1, 1]);  select_420 = None
    mul_487 = torch.ops.aten.mul.Tensor(slice_181, view_1098);  slice_181 = view_1098 = None
    add_383 = torch.ops.aten.add.Tensor(add_382, mul_487);  add_382 = mul_487 = None
    slice_182 = torch.ops.aten.slice.Tensor(constant_pad_nd_90, 2, 3, 134);  constant_pad_nd_90 = None
    select_421 = torch.ops.aten.select.int(convert_element_type_771, 1, 0);  convert_element_type_771 = None
    select_422 = torch.ops.aten.select.int(select_421, 1, 3);  select_421 = None
    view_1099 = torch.ops.aten.reshape.default(select_422, [1, -1, 1]);  select_422 = None
    mul_488 = torch.ops.aten.mul.Tensor(slice_182, view_1099);  slice_182 = view_1099 = None
    add_384 = torch.ops.aten.add.Tensor(add_383, mul_488);  add_383 = mul_488 = None
    convert_element_type_772 = torch.ops.prims.convert_element_type.default(add_384, torch.bfloat16);  add_384 = None
    slice_183 = torch.ops.aten.slice.Tensor(convert_element_type_772, 2, 0, 128);  convert_element_type_772 = None
    convert_element_type_773 = torch.ops.prims.convert_element_type.default(slice_183, torch.float32);  slice_183 = None
    neg_75 = torch.ops.aten.neg.default(convert_element_type_773)
    exp_160 = torch.ops.aten.exp.default(neg_75);  neg_75 = None
    add_385 = torch.ops.aten.add.Tensor(exp_160, 1);  exp_160 = None
    div_55 = torch.ops.aten.div.Tensor(convert_element_type_773, add_385);  convert_element_type_773 = add_385 = None
    convert_element_type_774 = torch.ops.prims.convert_element_type.default(div_55, torch.bfloat16);  div_55 = None
    slice_184 = torch.ops.aten.slice.Tensor(convert_element_type_774, 2, -128, 9223372036854775807);  convert_element_type_774 = None
    permute_380 = torch.ops.aten.permute.default(slice_184, [0, 2, 1]);  slice_184 = None
    split_with_sizes_15 = torch.ops.aten.split_with_sizes.default(permute_380, [2048, 2048, 2048], -1);  permute_380 = None
    getitem_55 = split_with_sizes_15[0]
    getitem_56 = split_with_sizes_15[1]
    getitem_57 = split_with_sizes_15[2];  split_with_sizes_15 = None
    full_47 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_161 = torch.ops.aten.exp.default(arg321_1);  arg321_1 = None
    neg_76 = torch.ops.aten.neg.default(exp_161);  exp_161 = None
    view_1094 = torch.ops.aten.reshape.default(convert_element_type_761, [128, 2048])
    permute_379 = torch.ops.aten.permute.default(arg318_1, [1, 0]);  arg318_1 = None
    mm_158 = torch.ops.aten.mm.default(view_1094, permute_379);  view_1094 = permute_379 = None
    view_1095 = torch.ops.aten.reshape.default(mm_158, [1, 128, 16]);  mm_158 = None
    convert_element_type_775 = torch.ops.prims.convert_element_type.default(view_1095, torch.float32);  view_1095 = None
    add_386 = torch.ops.aten.add.Tensor(convert_element_type_775, arg322_1);  convert_element_type_775 = arg322_1 = None
    gt_15 = torch.ops.aten.gt.Scalar(add_386, 20)
    exp_162 = torch.ops.aten.exp.default(add_386)
    log1p_15 = torch.ops.aten.log1p.default(exp_162);  exp_162 = None
    where_31 = torch.ops.aten.where.self(gt_15, add_386, log1p_15);  gt_15 = add_386 = log1p_15 = None
    mul_489 = torch.ops.aten.mul.Tensor(neg_76, where_31);  neg_76 = where_31 = None
    permute_385 = torch.ops.aten.permute.default(mul_489, [0, 2, 1]);  mul_489 = None
    view_1107 = torch.ops.aten.reshape.default(permute_385, [1, 16, 2, 64]);  permute_385 = None
    cumsum_15 = torch.ops.aten.cumsum.default(view_1107, 3);  view_1107 = None
    select_423 = torch.ops.aten.select.int(cumsum_15, 3, -1)
    exp_167 = torch.ops.aten.exp.default(select_423);  select_423 = None
    unsqueeze_238 = torch.ops.aten.unsqueeze.default(exp_167, 3);  exp_167 = None
    unsqueeze_239 = torch.ops.aten.unsqueeze.default(unsqueeze_238, 4);  unsqueeze_238 = None
    select_430 = torch.ops.aten.select.int(unsqueeze_239, 2, 0)
    mul_502 = torch.ops.aten.mul.Tensor(full_47, select_430);  select_430 = None
    view_1101 = torch.ops.aten.reshape.default(getitem_56, [1, 128, 16, 128]);  getitem_56 = None
    permute_382 = torch.ops.aten.permute.default(view_1101, [0, 2, 1, 3]);  view_1101 = None
    convert_element_type_777 = torch.ops.prims.convert_element_type.default(permute_382, torch.float32);  permute_382 = None
    clone_130 = torch.ops.aten.clone.default(convert_element_type_777, memory_format = torch.contiguous_format);  convert_element_type_777 = None
    mul_492 = torch.ops.aten.mul.Tensor(clone_130, clone_130)
    sum_37 = torch.ops.aten.sum.dim_IntList(mul_492, [-1], True);  mul_492 = None
    add_388 = torch.ops.aten.add.Tensor(sum_37, 1e-06);  sum_37 = None
    rsqrt_97 = torch.ops.aten.rsqrt.default(add_388);  add_388 = None
    mul_493 = torch.ops.aten.mul.Tensor(clone_130, rsqrt_97);  clone_130 = rsqrt_97 = None
    view_1104 = torch.ops.aten.reshape.default(mul_493, [1, 16, -1, 64, 128])
    slice_185 = torch.ops.aten.slice.Tensor(cumsum_15, 3, -1, 9223372036854775807)
    sub_82 = torch.ops.aten.sub.Tensor(slice_185, cumsum_15);  slice_185 = None
    exp_166 = torch.ops.aten.exp.default(sub_82);  sub_82 = None
    unsqueeze_237 = torch.ops.aten.unsqueeze.default(exp_166, -1);  exp_166 = None
    mul_501 = torch.ops.aten.mul.Tensor(view_1104, unsqueeze_237);  unsqueeze_237 = None
    select_431 = torch.ops.aten.select.int(mul_501, 2, 0)
    permute_389 = torch.ops.aten.permute.default(select_431, [0, 1, 3, 2]);  select_431 = None
    expand_354 = torch.ops.aten.expand.default(permute_389, [1, 16, 128, 64]);  permute_389 = None
    view_1123 = torch.ops.aten.reshape.default(expand_354, [16, 128, 64]);  expand_354 = None
    view_1092 = torch.ops.aten.reshape.default(convert_element_type_761, [128, 2048])
    permute_378 = torch.ops.aten.permute.default(arg317_1, [1, 0]);  arg317_1 = None
    mm_157 = torch.ops.aten.mm.default(view_1092, permute_378);  view_1092 = permute_378 = None
    view_1093 = torch.ops.aten.reshape.default(mm_157, [1, 128, 16]);  mm_157 = None
    sigmoid_20 = torch.ops.aten.sigmoid.default(view_1093);  view_1093 = None
    permute_384 = torch.ops.aten.permute.default(sigmoid_20, [0, 2, 1]);  sigmoid_20 = None
    convert_element_type_779 = torch.ops.prims.convert_element_type.default(permute_384, torch.float32);  permute_384 = None
    clone_132 = torch.ops.aten.clone.default(convert_element_type_779, memory_format = torch.contiguous_format);  convert_element_type_779 = None
    unsqueeze_230 = torch.ops.aten.unsqueeze.default(clone_132, -1)
    mul_496 = torch.ops.aten.mul.Tensor(mul_493, unsqueeze_230);  mul_493 = unsqueeze_230 = None
    view_1105 = torch.ops.aten.reshape.default(mul_496, [1, 16, -1, 64, 128]);  mul_496 = None
    expand_344 = torch.ops.aten.expand.default(view_1105, [1, 16, 2, 64, 128])
    view_1108 = torch.ops.aten.reshape.default(expand_344, [32, 64, 128]);  expand_344 = None
    permute_386 = torch.ops.aten.permute.default(view_1104, [0, 1, 2, 4, 3])
    expand_345 = torch.ops.aten.expand.default(permute_386, [1, 16, 2, 128, 64]);  permute_386 = None
    view_1109 = torch.ops.aten.reshape.default(expand_345, [32, 128, 64]);  expand_345 = None
    bmm_160 = torch.ops.aten.bmm.default(view_1108, view_1109);  view_1108 = view_1109 = None
    view_1110 = torch.ops.aten.reshape.default(bmm_160, [1, 16, 2, 64, 64]);  bmm_160 = None
    iota_36 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_231 = torch.ops.aten.unsqueeze.default(iota_36, -2);  iota_36 = None
    iota_37 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_232 = torch.ops.aten.unsqueeze.default(iota_37, -1);  iota_37 = None
    sub_80 = torch.ops.aten.sub.Tensor(unsqueeze_231, unsqueeze_232);  unsqueeze_231 = unsqueeze_232 = None
    ge_15 = torch.ops.aten.ge.Scalar(sub_80, 1);  sub_80 = None
    full_default_32 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_15 = torch.ops.aten.logical_and.default(ge_15, full_default_32);  ge_15 = full_default_32 = None
    full_default_33 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_233 = torch.ops.aten.unsqueeze.default(cumsum_15, 4)
    unsqueeze_234 = torch.ops.aten.unsqueeze.default(cumsum_15, 3)
    sub_81 = torch.ops.aten.sub.Tensor(unsqueeze_233, unsqueeze_234);  unsqueeze_233 = unsqueeze_234 = None
    where_32 = torch.ops.aten.where.self(logical_and_15, full_default_33, sub_81);  logical_and_15 = full_default_33 = sub_81 = None
    exp_163 = torch.ops.aten.exp.default(where_32);  where_32 = None
    mul_497 = torch.ops.aten.mul.Tensor(view_1110, exp_163);  view_1110 = None
    view_1102 = torch.ops.aten.reshape.default(getitem_57, [1, 128, 16, 128]);  getitem_57 = None
    permute_383 = torch.ops.aten.permute.default(view_1102, [0, 2, 1, 3]);  view_1102 = None
    convert_element_type_778 = torch.ops.prims.convert_element_type.default(permute_383, torch.float32);  permute_383 = None
    clone_131 = torch.ops.aten.clone.default(convert_element_type_778, memory_format = torch.contiguous_format);  convert_element_type_778 = None
    unsqueeze_229 = torch.ops.aten.unsqueeze.default(clone_132, -1);  clone_132 = None
    mul_495 = torch.ops.aten.mul.Tensor(clone_131, unsqueeze_229);  clone_131 = unsqueeze_229 = None
    view_1106 = torch.ops.aten.reshape.default(mul_495, [1, 16, -1, 64, 128]);  mul_495 = None
    linalg_solve_triangular_30 = torch.ops.aten.linalg_solve_triangular.default(mul_497, view_1106, upper = False, unitriangular = True);  view_1106 = None
    select_424 = torch.ops.aten.select.int(linalg_solve_triangular_30, 2, 0)
    exp_164 = torch.ops.aten.exp.default(cumsum_15)
    unsqueeze_235 = torch.ops.aten.unsqueeze.default(exp_164, -1);  exp_164 = None
    mul_499 = torch.ops.aten.mul.Tensor(view_1105, unsqueeze_235);  view_1105 = unsqueeze_235 = None
    linalg_solve_triangular_31 = torch.ops.aten.linalg_solve_triangular.default(mul_497, mul_499, upper = False, unitriangular = True);  mul_497 = mul_499 = None
    select_425 = torch.ops.aten.select.int(linalg_solve_triangular_31, 2, 0)
    expand_348 = torch.ops.aten.expand.default(select_425, [1, 16, 64, 128]);  select_425 = None
    view_1114 = torch.ops.aten.reshape.default(expand_348, [16, 64, 128]);  expand_348 = None
    expand_349 = torch.ops.aten.expand.default(full_47, [1, 16, 128, 128])
    view_1115 = torch.ops.aten.reshape.default(expand_349, [16, 128, 128]);  expand_349 = None
    bmm_162 = torch.ops.aten.bmm.default(view_1114, view_1115);  view_1114 = view_1115 = None
    view_1116 = torch.ops.aten.reshape.default(bmm_162, [1, 16, 64, 128]);  bmm_162 = None
    sub_83 = torch.ops.aten.sub.Tensor(select_424, view_1116);  select_424 = view_1116 = None
    expand_355 = torch.ops.aten.expand.default(sub_83, [1, 16, 64, 128])
    view_1124 = torch.ops.aten.reshape.default(expand_355, [16, 64, 128]);  expand_355 = None
    bmm_165 = torch.ops.aten.bmm.default(view_1123, view_1124);  view_1123 = view_1124 = None
    view_1125 = torch.ops.aten.reshape.default(bmm_165, [1, 16, 128, 128]);  bmm_165 = None
    add_390 = torch.ops.aten.add.Tensor(mul_502, view_1125);  mul_502 = view_1125 = None
    select_439 = torch.ops.aten.select.int(unsqueeze_239, 2, 1);  unsqueeze_239 = None
    mul_503 = torch.ops.aten.mul.Tensor(add_390, select_439);  select_439 = None
    select_440 = torch.ops.aten.select.int(mul_501, 2, 1);  mul_501 = None
    permute_390 = torch.ops.aten.permute.default(select_440, [0, 1, 3, 2]);  select_440 = None
    expand_362 = torch.ops.aten.expand.default(permute_390, [1, 16, 128, 64]);  permute_390 = None
    view_1135 = torch.ops.aten.reshape.default(expand_362, [16, 128, 64]);  expand_362 = None
    select_432 = torch.ops.aten.select.int(linalg_solve_triangular_30, 2, 1);  linalg_solve_triangular_30 = None
    select_433 = torch.ops.aten.select.int(linalg_solve_triangular_31, 2, 1);  linalg_solve_triangular_31 = None
    expand_356 = torch.ops.aten.expand.default(select_433, [1, 16, 64, 128]);  select_433 = None
    view_1126 = torch.ops.aten.reshape.default(expand_356, [16, 64, 128]);  expand_356 = None
    expand_357 = torch.ops.aten.expand.default(add_390, [1, 16, 128, 128])
    view_1127 = torch.ops.aten.reshape.default(expand_357, [16, 128, 128]);  expand_357 = None
    bmm_166 = torch.ops.aten.bmm.default(view_1126, view_1127);  view_1126 = view_1127 = None
    view_1128 = torch.ops.aten.reshape.default(bmm_166, [1, 16, 64, 128]);  bmm_166 = None
    sub_84 = torch.ops.aten.sub.Tensor(select_432, view_1128);  select_432 = view_1128 = None
    expand_363 = torch.ops.aten.expand.default(sub_84, [1, 16, 64, 128])
    view_1136 = torch.ops.aten.reshape.default(expand_363, [16, 64, 128]);  expand_363 = None
    bmm_169 = torch.ops.aten.bmm.default(view_1135, view_1136);  view_1135 = view_1136 = None
    view_1137 = torch.ops.aten.reshape.default(bmm_169, [1, 16, 128, 128]);  bmm_169 = None
    add_392 = torch.ops.aten.add.Tensor(mul_503, view_1137);  mul_503 = view_1137 = None
    full_48 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_388 = torch.ops.aten.permute.default(full_48, [0, 1, 2, 4, 3]);  full_48 = None
    select_428 = torch.ops.aten.select.int(permute_388, 2, 0)
    view_1100 = torch.ops.aten.reshape.default(getitem_55, [1, 128, 16, 128]);  getitem_55 = None
    permute_381 = torch.ops.aten.permute.default(view_1100, [0, 2, 1, 3]);  view_1100 = None
    convert_element_type_776 = torch.ops.prims.convert_element_type.default(permute_381, torch.float32);  permute_381 = None
    clone_129 = torch.ops.aten.clone.default(convert_element_type_776, memory_format = torch.contiguous_format);  convert_element_type_776 = None
    mul_490 = torch.ops.aten.mul.Tensor(clone_129, clone_129)
    sum_36 = torch.ops.aten.sum.dim_IntList(mul_490, [-1], True);  mul_490 = None
    add_387 = torch.ops.aten.add.Tensor(sum_36, 1e-06);  sum_36 = None
    rsqrt_96 = torch.ops.aten.rsqrt.default(add_387);  add_387 = None
    mul_491 = torch.ops.aten.mul.Tensor(clone_129, rsqrt_96);  clone_129 = rsqrt_96 = None
    mul_494 = torch.ops.aten.mul.Tensor(mul_491, 0.08838834764831845);  mul_491 = None
    view_1103 = torch.ops.aten.reshape.default(mul_494, [1, 16, -1, 64, 128]);  mul_494 = None
    exp_165 = torch.ops.aten.exp.default(cumsum_15);  cumsum_15 = None
    unsqueeze_236 = torch.ops.aten.unsqueeze.default(exp_165, -1);  exp_165 = None
    mul_500 = torch.ops.aten.mul.Tensor(view_1103, unsqueeze_236);  unsqueeze_236 = None
    select_426 = torch.ops.aten.select.int(mul_500, 2, 0)
    expand_350 = torch.ops.aten.expand.default(select_426, [1, 16, 64, 128]);  select_426 = None
    view_1117 = torch.ops.aten.reshape.default(expand_350, [16, 64, 128]);  expand_350 = None
    expand_351 = torch.ops.aten.expand.default(full_47, [1, 16, 128, 128]);  full_47 = None
    view_1118 = torch.ops.aten.reshape.default(expand_351, [16, 128, 128]);  expand_351 = None
    bmm_163 = torch.ops.aten.bmm.default(view_1117, view_1118);  view_1117 = view_1118 = None
    view_1119 = torch.ops.aten.reshape.default(bmm_163, [1, 16, 64, 128]);  bmm_163 = None
    expand_346 = torch.ops.aten.expand.default(view_1103, [1, 16, 2, 64, 128]);  view_1103 = None
    view_1111 = torch.ops.aten.reshape.default(expand_346, [32, 64, 128]);  expand_346 = None
    permute_387 = torch.ops.aten.permute.default(view_1104, [0, 1, 2, 4, 3]);  view_1104 = None
    expand_347 = torch.ops.aten.expand.default(permute_387, [1, 16, 2, 128, 64]);  permute_387 = None
    view_1112 = torch.ops.aten.reshape.default(expand_347, [32, 128, 64]);  expand_347 = None
    bmm_161 = torch.ops.aten.bmm.default(view_1111, view_1112);  view_1111 = view_1112 = None
    view_1113 = torch.ops.aten.reshape.default(bmm_161, [1, 16, 2, 64, 64]);  bmm_161 = None
    mul_498 = torch.ops.aten.mul.Tensor(view_1113, exp_163);  view_1113 = exp_163 = None
    select_427 = torch.ops.aten.select.int(mul_498, 2, 0)
    expand_352 = torch.ops.aten.expand.default(select_427, [1, 16, 64, 64]);  select_427 = None
    view_1120 = torch.ops.aten.reshape.default(expand_352, [16, 64, 64]);  expand_352 = None
    expand_353 = torch.ops.aten.expand.default(sub_83, [1, 16, 64, 128]);  sub_83 = None
    view_1121 = torch.ops.aten.reshape.default(expand_353, [16, 64, 128]);  expand_353 = None
    bmm_164 = torch.ops.aten.bmm.default(view_1120, view_1121);  view_1120 = view_1121 = None
    view_1122 = torch.ops.aten.reshape.default(bmm_164, [1, 16, 64, 128]);  bmm_164 = None
    add_389 = torch.ops.aten.add.Tensor(view_1119, view_1122);  view_1119 = view_1122 = None
    copy_65 = torch.ops.aten.copy.default(select_428, add_389);  select_428 = add_389 = None
    select_scatter_default_34 = torch.ops.aten.select_scatter.default(permute_388, copy_65, 2, 0);  permute_388 = copy_65 = None
    select_437 = torch.ops.aten.select.int(select_scatter_default_34, 2, 1)
    select_434 = torch.ops.aten.select.int(mul_500, 2, 1);  mul_500 = None
    expand_358 = torch.ops.aten.expand.default(select_434, [1, 16, 64, 128]);  select_434 = None
    view_1129 = torch.ops.aten.reshape.default(expand_358, [16, 64, 128]);  expand_358 = None
    expand_359 = torch.ops.aten.expand.default(add_390, [1, 16, 128, 128]);  add_390 = None
    view_1130 = torch.ops.aten.reshape.default(expand_359, [16, 128, 128]);  expand_359 = None
    bmm_167 = torch.ops.aten.bmm.default(view_1129, view_1130);  view_1129 = view_1130 = None
    view_1131 = torch.ops.aten.reshape.default(bmm_167, [1, 16, 64, 128]);  bmm_167 = None
    select_435 = torch.ops.aten.select.int(mul_498, 2, 1);  mul_498 = None
    expand_360 = torch.ops.aten.expand.default(select_435, [1, 16, 64, 64]);  select_435 = None
    view_1132 = torch.ops.aten.reshape.default(expand_360, [16, 64, 64]);  expand_360 = None
    expand_361 = torch.ops.aten.expand.default(sub_84, [1, 16, 64, 128]);  sub_84 = None
    view_1133 = torch.ops.aten.reshape.default(expand_361, [16, 64, 128]);  expand_361 = None
    bmm_168 = torch.ops.aten.bmm.default(view_1132, view_1133);  view_1132 = view_1133 = None
    view_1134 = torch.ops.aten.reshape.default(bmm_168, [1, 16, 64, 128]);  bmm_168 = None
    add_391 = torch.ops.aten.add.Tensor(view_1131, view_1134);  view_1131 = view_1134 = None
    copy_66 = torch.ops.aten.copy.default(select_437, add_391);  select_437 = add_391 = None
    select_scatter_default_35 = torch.ops.aten.select_scatter.default(select_scatter_default_34, copy_66, 2, 1);  select_scatter_default_34 = copy_66 = None
    clone_134 = torch.ops.aten.clone.default(select_scatter_default_35, memory_format = torch.contiguous_format);  select_scatter_default_35 = None
    view_1138 = torch.ops.aten.reshape.default(clone_134, [1, 16, 128, 128]);  clone_134 = None
    permute_391 = torch.ops.aten.permute.default(view_1138, [0, 2, 1, 3]);  view_1138 = None
    convert_element_type_780 = torch.ops.prims.convert_element_type.default(permute_391, torch.bfloat16);  permute_391 = None
    clone_135 = torch.ops.aten.clone.default(convert_element_type_780, memory_format = torch.contiguous_format);  convert_element_type_780 = None
    view_1139 = torch.ops.aten.reshape.default(clone_135, [-1, 128]);  clone_135 = None
    convert_element_type_781 = torch.ops.prims.convert_element_type.default(view_1139, torch.float32);  view_1139 = None
    pow_67 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_781, 2)
    mean_66 = torch.ops.aten.mean.dim(pow_67, [-1], True);  pow_67 = None
    add_393 = torch.ops.aten.add.Tensor(mean_66, 1e-06);  mean_66 = None
    rsqrt_98 = torch.ops.aten.rsqrt.default(add_393);  add_393 = None
    mul_504 = torch.ops.aten.mul.Tensor(convert_element_type_781, rsqrt_98);  convert_element_type_781 = rsqrt_98 = None
    convert_element_type_782 = torch.ops.prims.convert_element_type.default(mul_504, torch.bfloat16);  mul_504 = None
    mul_505 = torch.ops.aten.mul.Tensor(arg324_1, convert_element_type_782);  arg324_1 = convert_element_type_782 = None
    view_1089 = torch.ops.aten.reshape.default(convert_element_type_761, [128, 2048]);  convert_element_type_761 = None
    permute_377 = torch.ops.aten.permute.default(arg316_1, [1, 0]);  arg316_1 = None
    mm_156 = torch.ops.aten.mm.default(view_1089, permute_377);  view_1089 = permute_377 = None
    view_1090 = torch.ops.aten.reshape.default(mm_156, [1, 128, 2048]);  mm_156 = None
    view_1091 = torch.ops.aten.reshape.default(view_1090, [1, 128, -1, 128]);  view_1090 = None
    view_1140 = torch.ops.aten.reshape.default(view_1091, [-1, 128]);  view_1091 = None
    convert_element_type_783 = torch.ops.prims.convert_element_type.default(view_1140, torch.float32);  view_1140 = None
    neg_77 = torch.ops.aten.neg.default(convert_element_type_783)
    exp_168 = torch.ops.aten.exp.default(neg_77);  neg_77 = None
    add_394 = torch.ops.aten.add.Tensor(exp_168, 1);  exp_168 = None
    div_56 = torch.ops.aten.div.Tensor(convert_element_type_783, add_394);  convert_element_type_783 = add_394 = None
    mul_506 = torch.ops.aten.mul.Tensor(mul_505, div_56);  mul_505 = div_56 = None
    convert_element_type_784 = torch.ops.prims.convert_element_type.default(mul_506, torch.bfloat16);  mul_506 = None
    view_1141 = torch.ops.aten.reshape.default(convert_element_type_784, [1, 128, -1]);  convert_element_type_784 = None
    view_1142 = torch.ops.aten.reshape.default(view_1141, [128, 2048]);  view_1141 = None
    permute_392 = torch.ops.aten.permute.default(arg325_1, [1, 0]);  arg325_1 = None
    mm_159 = torch.ops.aten.mm.default(view_1142, permute_392);  view_1142 = permute_392 = None
    view_1143 = torch.ops.aten.reshape.default(mm_159, [1, 128, 2048]);  mm_159 = None
    add_395 = torch.ops.aten.add.Tensor(add_379, view_1143);  add_379 = view_1143 = None
    convert_element_type_787 = torch.ops.prims.convert_element_type.default(add_395, torch.float32)
    pow_68 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_787, 2)
    mean_67 = torch.ops.aten.mean.dim(pow_68, [-1], True);  pow_68 = None
    add_396 = torch.ops.aten.add.Tensor(mean_67, 1e-06);  mean_67 = None
    rsqrt_99 = torch.ops.aten.rsqrt.default(add_396);  add_396 = None
    mul_507 = torch.ops.aten.mul.Tensor(convert_element_type_787, rsqrt_99);  convert_element_type_787 = rsqrt_99 = None
    convert_element_type_788 = torch.ops.prims.convert_element_type.default(arg326_1, torch.float32);  arg326_1 = None
    add_397 = torch.ops.aten.add.Tensor(convert_element_type_788, 1.0);  convert_element_type_788 = None
    mul_508 = torch.ops.aten.mul.Tensor(mul_507, add_397);  mul_507 = add_397 = None
    convert_element_type_789 = torch.ops.prims.convert_element_type.default(mul_508, torch.bfloat16);  mul_508 = None
    view_1144 = torch.ops.aten.reshape.default(convert_element_type_789, [128, 2048])
    permute_393 = torch.ops.aten.permute.default(arg327_1, [1, 0]);  arg327_1 = None
    mm_160 = torch.ops.aten.mm.default(view_1144, permute_393);  view_1144 = permute_393 = None
    view_1145 = torch.ops.aten.reshape.default(mm_160, [1, 128, 6144]);  mm_160 = None
    convert_element_type_792 = torch.ops.prims.convert_element_type.default(view_1145, torch.float32);  view_1145 = None
    neg_78 = torch.ops.aten.neg.default(convert_element_type_792)
    exp_169 = torch.ops.aten.exp.default(neg_78);  neg_78 = None
    add_398 = torch.ops.aten.add.Tensor(exp_169, 1);  exp_169 = None
    div_57 = torch.ops.aten.div.Tensor(convert_element_type_792, add_398);  convert_element_type_792 = add_398 = None
    convert_element_type_793 = torch.ops.prims.convert_element_type.default(div_57, torch.bfloat16);  div_57 = None
    view_1146 = torch.ops.aten.reshape.default(convert_element_type_789, [128, 2048]);  convert_element_type_789 = None
    permute_394 = torch.ops.aten.permute.default(arg328_1, [1, 0]);  arg328_1 = None
    mm_161 = torch.ops.aten.mm.default(view_1146, permute_394);  view_1146 = permute_394 = None
    view_1147 = torch.ops.aten.reshape.default(mm_161, [1, 128, 6144]);  mm_161 = None
    mul_509 = torch.ops.aten.mul.Tensor(convert_element_type_793, view_1147);  convert_element_type_793 = view_1147 = None
    view_1148 = torch.ops.aten.reshape.default(mul_509, [128, 6144]);  mul_509 = None
    permute_395 = torch.ops.aten.permute.default(arg329_1, [1, 0]);  arg329_1 = None
    mm_162 = torch.ops.aten.mm.default(view_1148, permute_395);  view_1148 = permute_395 = None
    view_1149 = torch.ops.aten.reshape.default(mm_162, [1, 128, 2048]);  mm_162 = None
    add_399 = torch.ops.aten.add.Tensor(add_395, view_1149);  add_395 = view_1149 = None
    convert_element_type_798 = torch.ops.prims.convert_element_type.default(add_399, torch.float32)
    pow_69 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_798, 2)
    mean_68 = torch.ops.aten.mean.dim(pow_69, [-1], True);  pow_69 = None
    add_400 = torch.ops.aten.add.Tensor(mean_68, 1e-06);  mean_68 = None
    rsqrt_100 = torch.ops.aten.rsqrt.default(add_400);  add_400 = None
    mul_510 = torch.ops.aten.mul.Tensor(convert_element_type_798, rsqrt_100);  convert_element_type_798 = rsqrt_100 = None
    convert_element_type_799 = torch.ops.prims.convert_element_type.default(arg330_1, torch.float32);  arg330_1 = None
    add_401 = torch.ops.aten.add.Tensor(convert_element_type_799, 1.0);  convert_element_type_799 = None
    mul_511 = torch.ops.aten.mul.Tensor(mul_510, add_401);  mul_510 = add_401 = None
    convert_element_type_800 = torch.ops.prims.convert_element_type.default(mul_511, torch.bfloat16);  mul_511 = None
    view_1150 = torch.ops.aten.reshape.default(convert_element_type_800, [128, 2048])
    permute_396 = torch.ops.aten.permute.default(arg331_1, [1, 0]);  arg331_1 = None
    mm_163 = torch.ops.aten.mm.default(view_1150, permute_396);  view_1150 = permute_396 = None
    view_1151 = torch.ops.aten.reshape.default(mm_163, [1, 128, 6144]);  mm_163 = None
    permute_397 = torch.ops.aten.permute.default(view_1151, [0, 2, 1]);  view_1151 = None
    slice_186 = torch.ops.aten.slice.Tensor(permute_397, 2, -4, 9223372036854775807)
    copy_68 = torch.ops.aten.copy.default(arg335_1, slice_186);  slice_186 = None
    convert_element_type_809 = torch.ops.prims.convert_element_type.default(permute_397, torch.float32);  permute_397 = None
    constant_pad_nd_96 = torch.ops.aten.constant_pad_nd.default(convert_element_type_809, [3, 3], 0.0);  convert_element_type_809 = None
    slice_187 = torch.ops.aten.slice.Tensor(constant_pad_nd_96, 2, 0, 131)
    squeeze_16 = torch.ops.aten.squeeze.dim(arg336_1, 1);  arg336_1 = None
    unsqueeze_240 = torch.ops.aten.unsqueeze.default(squeeze_16, 1);  squeeze_16 = None
    convert_element_type_810 = torch.ops.prims.convert_element_type.default(unsqueeze_240, torch.float32);  unsqueeze_240 = None
    select_441 = torch.ops.aten.select.int(convert_element_type_810, 1, 0)
    select_442 = torch.ops.aten.select.int(select_441, 1, 0);  select_441 = None
    view_1159 = torch.ops.aten.reshape.default(select_442, [1, -1, 1]);  select_442 = None
    mul_512 = torch.ops.aten.mul.Tensor(slice_187, view_1159);  slice_187 = view_1159 = None
    slice_188 = torch.ops.aten.slice.Tensor(constant_pad_nd_96, 2, 1, 132)
    select_443 = torch.ops.aten.select.int(convert_element_type_810, 1, 0)
    select_444 = torch.ops.aten.select.int(select_443, 1, 1);  select_443 = None
    view_1160 = torch.ops.aten.reshape.default(select_444, [1, -1, 1]);  select_444 = None
    mul_513 = torch.ops.aten.mul.Tensor(slice_188, view_1160);  slice_188 = view_1160 = None
    add_402 = torch.ops.aten.add.Tensor(mul_512, mul_513);  mul_512 = mul_513 = None
    slice_189 = torch.ops.aten.slice.Tensor(constant_pad_nd_96, 2, 2, 133)
    select_445 = torch.ops.aten.select.int(convert_element_type_810, 1, 0)
    select_446 = torch.ops.aten.select.int(select_445, 1, 2);  select_445 = None
    view_1161 = torch.ops.aten.reshape.default(select_446, [1, -1, 1]);  select_446 = None
    mul_514 = torch.ops.aten.mul.Tensor(slice_189, view_1161);  slice_189 = view_1161 = None
    add_403 = torch.ops.aten.add.Tensor(add_402, mul_514);  add_402 = mul_514 = None
    slice_190 = torch.ops.aten.slice.Tensor(constant_pad_nd_96, 2, 3, 134);  constant_pad_nd_96 = None
    select_447 = torch.ops.aten.select.int(convert_element_type_810, 1, 0);  convert_element_type_810 = None
    select_448 = torch.ops.aten.select.int(select_447, 1, 3);  select_447 = None
    view_1162 = torch.ops.aten.reshape.default(select_448, [1, -1, 1]);  select_448 = None
    mul_515 = torch.ops.aten.mul.Tensor(slice_190, view_1162);  slice_190 = view_1162 = None
    add_404 = torch.ops.aten.add.Tensor(add_403, mul_515);  add_403 = mul_515 = None
    convert_element_type_811 = torch.ops.prims.convert_element_type.default(add_404, torch.bfloat16);  add_404 = None
    slice_191 = torch.ops.aten.slice.Tensor(convert_element_type_811, 2, 0, 128);  convert_element_type_811 = None
    convert_element_type_812 = torch.ops.prims.convert_element_type.default(slice_191, torch.float32);  slice_191 = None
    neg_79 = torch.ops.aten.neg.default(convert_element_type_812)
    exp_170 = torch.ops.aten.exp.default(neg_79);  neg_79 = None
    add_405 = torch.ops.aten.add.Tensor(exp_170, 1);  exp_170 = None
    div_58 = torch.ops.aten.div.Tensor(convert_element_type_812, add_405);  convert_element_type_812 = add_405 = None
    convert_element_type_813 = torch.ops.prims.convert_element_type.default(div_58, torch.bfloat16);  div_58 = None
    slice_192 = torch.ops.aten.slice.Tensor(convert_element_type_813, 2, -128, 9223372036854775807);  convert_element_type_813 = None
    permute_401 = torch.ops.aten.permute.default(slice_192, [0, 2, 1]);  slice_192 = None
    split_with_sizes_16 = torch.ops.aten.split_with_sizes.default(permute_401, [2048, 2048, 2048], -1);  permute_401 = None
    getitem_58 = split_with_sizes_16[0]
    getitem_59 = split_with_sizes_16[1]
    getitem_60 = split_with_sizes_16[2];  split_with_sizes_16 = None
    full_50 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_171 = torch.ops.aten.exp.default(arg337_1);  arg337_1 = None
    neg_80 = torch.ops.aten.neg.default(exp_171);  exp_171 = None
    view_1157 = torch.ops.aten.reshape.default(convert_element_type_800, [128, 2048])
    permute_400 = torch.ops.aten.permute.default(arg334_1, [1, 0]);  arg334_1 = None
    mm_166 = torch.ops.aten.mm.default(view_1157, permute_400);  view_1157 = permute_400 = None
    view_1158 = torch.ops.aten.reshape.default(mm_166, [1, 128, 16]);  mm_166 = None
    convert_element_type_814 = torch.ops.prims.convert_element_type.default(view_1158, torch.float32);  view_1158 = None
    add_406 = torch.ops.aten.add.Tensor(convert_element_type_814, arg338_1);  convert_element_type_814 = arg338_1 = None
    gt_16 = torch.ops.aten.gt.Scalar(add_406, 20)
    exp_172 = torch.ops.aten.exp.default(add_406)
    log1p_16 = torch.ops.aten.log1p.default(exp_172);  exp_172 = None
    where_33 = torch.ops.aten.where.self(gt_16, add_406, log1p_16);  gt_16 = add_406 = log1p_16 = None
    mul_516 = torch.ops.aten.mul.Tensor(neg_80, where_33);  neg_80 = where_33 = None
    permute_406 = torch.ops.aten.permute.default(mul_516, [0, 2, 1]);  mul_516 = None
    view_1170 = torch.ops.aten.reshape.default(permute_406, [1, 16, 2, 64]);  permute_406 = None
    cumsum_16 = torch.ops.aten.cumsum.default(view_1170, 3);  view_1170 = None
    select_449 = torch.ops.aten.select.int(cumsum_16, 3, -1)
    exp_177 = torch.ops.aten.exp.default(select_449);  select_449 = None
    unsqueeze_250 = torch.ops.aten.unsqueeze.default(exp_177, 3);  exp_177 = None
    unsqueeze_251 = torch.ops.aten.unsqueeze.default(unsqueeze_250, 4);  unsqueeze_250 = None
    select_456 = torch.ops.aten.select.int(unsqueeze_251, 2, 0)
    mul_529 = torch.ops.aten.mul.Tensor(full_50, select_456);  select_456 = None
    view_1164 = torch.ops.aten.reshape.default(getitem_59, [1, 128, 16, 128]);  getitem_59 = None
    permute_403 = torch.ops.aten.permute.default(view_1164, [0, 2, 1, 3]);  view_1164 = None
    convert_element_type_816 = torch.ops.prims.convert_element_type.default(permute_403, torch.float32);  permute_403 = None
    clone_137 = torch.ops.aten.clone.default(convert_element_type_816, memory_format = torch.contiguous_format);  convert_element_type_816 = None
    mul_519 = torch.ops.aten.mul.Tensor(clone_137, clone_137)
    sum_39 = torch.ops.aten.sum.dim_IntList(mul_519, [-1], True);  mul_519 = None
    add_408 = torch.ops.aten.add.Tensor(sum_39, 1e-06);  sum_39 = None
    rsqrt_102 = torch.ops.aten.rsqrt.default(add_408);  add_408 = None
    mul_520 = torch.ops.aten.mul.Tensor(clone_137, rsqrt_102);  clone_137 = rsqrt_102 = None
    view_1167 = torch.ops.aten.reshape.default(mul_520, [1, 16, -1, 64, 128])
    slice_193 = torch.ops.aten.slice.Tensor(cumsum_16, 3, -1, 9223372036854775807)
    sub_87 = torch.ops.aten.sub.Tensor(slice_193, cumsum_16);  slice_193 = None
    exp_176 = torch.ops.aten.exp.default(sub_87);  sub_87 = None
    unsqueeze_249 = torch.ops.aten.unsqueeze.default(exp_176, -1);  exp_176 = None
    mul_528 = torch.ops.aten.mul.Tensor(view_1167, unsqueeze_249);  unsqueeze_249 = None
    select_457 = torch.ops.aten.select.int(mul_528, 2, 0)
    permute_410 = torch.ops.aten.permute.default(select_457, [0, 1, 3, 2]);  select_457 = None
    expand_374 = torch.ops.aten.expand.default(permute_410, [1, 16, 128, 64]);  permute_410 = None
    view_1186 = torch.ops.aten.reshape.default(expand_374, [16, 128, 64]);  expand_374 = None
    view_1155 = torch.ops.aten.reshape.default(convert_element_type_800, [128, 2048])
    permute_399 = torch.ops.aten.permute.default(arg333_1, [1, 0]);  arg333_1 = None
    mm_165 = torch.ops.aten.mm.default(view_1155, permute_399);  view_1155 = permute_399 = None
    view_1156 = torch.ops.aten.reshape.default(mm_165, [1, 128, 16]);  mm_165 = None
    sigmoid_21 = torch.ops.aten.sigmoid.default(view_1156);  view_1156 = None
    permute_405 = torch.ops.aten.permute.default(sigmoid_21, [0, 2, 1]);  sigmoid_21 = None
    convert_element_type_818 = torch.ops.prims.convert_element_type.default(permute_405, torch.float32);  permute_405 = None
    clone_139 = torch.ops.aten.clone.default(convert_element_type_818, memory_format = torch.contiguous_format);  convert_element_type_818 = None
    unsqueeze_242 = torch.ops.aten.unsqueeze.default(clone_139, -1)
    mul_523 = torch.ops.aten.mul.Tensor(mul_520, unsqueeze_242);  mul_520 = unsqueeze_242 = None
    view_1168 = torch.ops.aten.reshape.default(mul_523, [1, 16, -1, 64, 128]);  mul_523 = None
    expand_364 = torch.ops.aten.expand.default(view_1168, [1, 16, 2, 64, 128])
    view_1171 = torch.ops.aten.reshape.default(expand_364, [32, 64, 128]);  expand_364 = None
    permute_407 = torch.ops.aten.permute.default(view_1167, [0, 1, 2, 4, 3])
    expand_365 = torch.ops.aten.expand.default(permute_407, [1, 16, 2, 128, 64]);  permute_407 = None
    view_1172 = torch.ops.aten.reshape.default(expand_365, [32, 128, 64]);  expand_365 = None
    bmm_170 = torch.ops.aten.bmm.default(view_1171, view_1172);  view_1171 = view_1172 = None
    view_1173 = torch.ops.aten.reshape.default(bmm_170, [1, 16, 2, 64, 64]);  bmm_170 = None
    iota_38 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_243 = torch.ops.aten.unsqueeze.default(iota_38, -2);  iota_38 = None
    iota_39 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_244 = torch.ops.aten.unsqueeze.default(iota_39, -1);  iota_39 = None
    sub_85 = torch.ops.aten.sub.Tensor(unsqueeze_243, unsqueeze_244);  unsqueeze_243 = unsqueeze_244 = None
    ge_16 = torch.ops.aten.ge.Scalar(sub_85, 1);  sub_85 = None
    full_default_34 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_16 = torch.ops.aten.logical_and.default(ge_16, full_default_34);  ge_16 = full_default_34 = None
    full_default_35 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_245 = torch.ops.aten.unsqueeze.default(cumsum_16, 4)
    unsqueeze_246 = torch.ops.aten.unsqueeze.default(cumsum_16, 3)
    sub_86 = torch.ops.aten.sub.Tensor(unsqueeze_245, unsqueeze_246);  unsqueeze_245 = unsqueeze_246 = None
    where_34 = torch.ops.aten.where.self(logical_and_16, full_default_35, sub_86);  logical_and_16 = full_default_35 = sub_86 = None
    exp_173 = torch.ops.aten.exp.default(where_34);  where_34 = None
    mul_524 = torch.ops.aten.mul.Tensor(view_1173, exp_173);  view_1173 = None
    view_1165 = torch.ops.aten.reshape.default(getitem_60, [1, 128, 16, 128]);  getitem_60 = None
    permute_404 = torch.ops.aten.permute.default(view_1165, [0, 2, 1, 3]);  view_1165 = None
    convert_element_type_817 = torch.ops.prims.convert_element_type.default(permute_404, torch.float32);  permute_404 = None
    clone_138 = torch.ops.aten.clone.default(convert_element_type_817, memory_format = torch.contiguous_format);  convert_element_type_817 = None
    unsqueeze_241 = torch.ops.aten.unsqueeze.default(clone_139, -1);  clone_139 = None
    mul_522 = torch.ops.aten.mul.Tensor(clone_138, unsqueeze_241);  clone_138 = unsqueeze_241 = None
    view_1169 = torch.ops.aten.reshape.default(mul_522, [1, 16, -1, 64, 128]);  mul_522 = None
    linalg_solve_triangular_32 = torch.ops.aten.linalg_solve_triangular.default(mul_524, view_1169, upper = False, unitriangular = True);  view_1169 = None
    select_450 = torch.ops.aten.select.int(linalg_solve_triangular_32, 2, 0)
    exp_174 = torch.ops.aten.exp.default(cumsum_16)
    unsqueeze_247 = torch.ops.aten.unsqueeze.default(exp_174, -1);  exp_174 = None
    mul_526 = torch.ops.aten.mul.Tensor(view_1168, unsqueeze_247);  view_1168 = unsqueeze_247 = None
    linalg_solve_triangular_33 = torch.ops.aten.linalg_solve_triangular.default(mul_524, mul_526, upper = False, unitriangular = True);  mul_524 = mul_526 = None
    select_451 = torch.ops.aten.select.int(linalg_solve_triangular_33, 2, 0)
    expand_368 = torch.ops.aten.expand.default(select_451, [1, 16, 64, 128]);  select_451 = None
    view_1177 = torch.ops.aten.reshape.default(expand_368, [16, 64, 128]);  expand_368 = None
    expand_369 = torch.ops.aten.expand.default(full_50, [1, 16, 128, 128])
    view_1178 = torch.ops.aten.reshape.default(expand_369, [16, 128, 128]);  expand_369 = None
    bmm_172 = torch.ops.aten.bmm.default(view_1177, view_1178);  view_1177 = view_1178 = None
    view_1179 = torch.ops.aten.reshape.default(bmm_172, [1, 16, 64, 128]);  bmm_172 = None
    sub_88 = torch.ops.aten.sub.Tensor(select_450, view_1179);  select_450 = view_1179 = None
    expand_375 = torch.ops.aten.expand.default(sub_88, [1, 16, 64, 128])
    view_1187 = torch.ops.aten.reshape.default(expand_375, [16, 64, 128]);  expand_375 = None
    bmm_175 = torch.ops.aten.bmm.default(view_1186, view_1187);  view_1186 = view_1187 = None
    view_1188 = torch.ops.aten.reshape.default(bmm_175, [1, 16, 128, 128]);  bmm_175 = None
    add_410 = torch.ops.aten.add.Tensor(mul_529, view_1188);  mul_529 = view_1188 = None
    select_465 = torch.ops.aten.select.int(unsqueeze_251, 2, 1);  unsqueeze_251 = None
    mul_530 = torch.ops.aten.mul.Tensor(add_410, select_465);  select_465 = None
    select_466 = torch.ops.aten.select.int(mul_528, 2, 1);  mul_528 = None
    permute_411 = torch.ops.aten.permute.default(select_466, [0, 1, 3, 2]);  select_466 = None
    expand_382 = torch.ops.aten.expand.default(permute_411, [1, 16, 128, 64]);  permute_411 = None
    view_1198 = torch.ops.aten.reshape.default(expand_382, [16, 128, 64]);  expand_382 = None
    select_458 = torch.ops.aten.select.int(linalg_solve_triangular_32, 2, 1);  linalg_solve_triangular_32 = None
    select_459 = torch.ops.aten.select.int(linalg_solve_triangular_33, 2, 1);  linalg_solve_triangular_33 = None
    expand_376 = torch.ops.aten.expand.default(select_459, [1, 16, 64, 128]);  select_459 = None
    view_1189 = torch.ops.aten.reshape.default(expand_376, [16, 64, 128]);  expand_376 = None
    expand_377 = torch.ops.aten.expand.default(add_410, [1, 16, 128, 128])
    view_1190 = torch.ops.aten.reshape.default(expand_377, [16, 128, 128]);  expand_377 = None
    bmm_176 = torch.ops.aten.bmm.default(view_1189, view_1190);  view_1189 = view_1190 = None
    view_1191 = torch.ops.aten.reshape.default(bmm_176, [1, 16, 64, 128]);  bmm_176 = None
    sub_89 = torch.ops.aten.sub.Tensor(select_458, view_1191);  select_458 = view_1191 = None
    expand_383 = torch.ops.aten.expand.default(sub_89, [1, 16, 64, 128])
    view_1199 = torch.ops.aten.reshape.default(expand_383, [16, 64, 128]);  expand_383 = None
    bmm_179 = torch.ops.aten.bmm.default(view_1198, view_1199);  view_1198 = view_1199 = None
    view_1200 = torch.ops.aten.reshape.default(bmm_179, [1, 16, 128, 128]);  bmm_179 = None
    add_412 = torch.ops.aten.add.Tensor(mul_530, view_1200);  mul_530 = view_1200 = None
    full_51 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_409 = torch.ops.aten.permute.default(full_51, [0, 1, 2, 4, 3]);  full_51 = None
    select_454 = torch.ops.aten.select.int(permute_409, 2, 0)
    view_1163 = torch.ops.aten.reshape.default(getitem_58, [1, 128, 16, 128]);  getitem_58 = None
    permute_402 = torch.ops.aten.permute.default(view_1163, [0, 2, 1, 3]);  view_1163 = None
    convert_element_type_815 = torch.ops.prims.convert_element_type.default(permute_402, torch.float32);  permute_402 = None
    clone_136 = torch.ops.aten.clone.default(convert_element_type_815, memory_format = torch.contiguous_format);  convert_element_type_815 = None
    mul_517 = torch.ops.aten.mul.Tensor(clone_136, clone_136)
    sum_38 = torch.ops.aten.sum.dim_IntList(mul_517, [-1], True);  mul_517 = None
    add_407 = torch.ops.aten.add.Tensor(sum_38, 1e-06);  sum_38 = None
    rsqrt_101 = torch.ops.aten.rsqrt.default(add_407);  add_407 = None
    mul_518 = torch.ops.aten.mul.Tensor(clone_136, rsqrt_101);  clone_136 = rsqrt_101 = None
    mul_521 = torch.ops.aten.mul.Tensor(mul_518, 0.08838834764831845);  mul_518 = None
    view_1166 = torch.ops.aten.reshape.default(mul_521, [1, 16, -1, 64, 128]);  mul_521 = None
    exp_175 = torch.ops.aten.exp.default(cumsum_16);  cumsum_16 = None
    unsqueeze_248 = torch.ops.aten.unsqueeze.default(exp_175, -1);  exp_175 = None
    mul_527 = torch.ops.aten.mul.Tensor(view_1166, unsqueeze_248);  unsqueeze_248 = None
    select_452 = torch.ops.aten.select.int(mul_527, 2, 0)
    expand_370 = torch.ops.aten.expand.default(select_452, [1, 16, 64, 128]);  select_452 = None
    view_1180 = torch.ops.aten.reshape.default(expand_370, [16, 64, 128]);  expand_370 = None
    expand_371 = torch.ops.aten.expand.default(full_50, [1, 16, 128, 128]);  full_50 = None
    view_1181 = torch.ops.aten.reshape.default(expand_371, [16, 128, 128]);  expand_371 = None
    bmm_173 = torch.ops.aten.bmm.default(view_1180, view_1181);  view_1180 = view_1181 = None
    view_1182 = torch.ops.aten.reshape.default(bmm_173, [1, 16, 64, 128]);  bmm_173 = None
    expand_366 = torch.ops.aten.expand.default(view_1166, [1, 16, 2, 64, 128]);  view_1166 = None
    view_1174 = torch.ops.aten.reshape.default(expand_366, [32, 64, 128]);  expand_366 = None
    permute_408 = torch.ops.aten.permute.default(view_1167, [0, 1, 2, 4, 3]);  view_1167 = None
    expand_367 = torch.ops.aten.expand.default(permute_408, [1, 16, 2, 128, 64]);  permute_408 = None
    view_1175 = torch.ops.aten.reshape.default(expand_367, [32, 128, 64]);  expand_367 = None
    bmm_171 = torch.ops.aten.bmm.default(view_1174, view_1175);  view_1174 = view_1175 = None
    view_1176 = torch.ops.aten.reshape.default(bmm_171, [1, 16, 2, 64, 64]);  bmm_171 = None
    mul_525 = torch.ops.aten.mul.Tensor(view_1176, exp_173);  view_1176 = exp_173 = None
    select_453 = torch.ops.aten.select.int(mul_525, 2, 0)
    expand_372 = torch.ops.aten.expand.default(select_453, [1, 16, 64, 64]);  select_453 = None
    view_1183 = torch.ops.aten.reshape.default(expand_372, [16, 64, 64]);  expand_372 = None
    expand_373 = torch.ops.aten.expand.default(sub_88, [1, 16, 64, 128]);  sub_88 = None
    view_1184 = torch.ops.aten.reshape.default(expand_373, [16, 64, 128]);  expand_373 = None
    bmm_174 = torch.ops.aten.bmm.default(view_1183, view_1184);  view_1183 = view_1184 = None
    view_1185 = torch.ops.aten.reshape.default(bmm_174, [1, 16, 64, 128]);  bmm_174 = None
    add_409 = torch.ops.aten.add.Tensor(view_1182, view_1185);  view_1182 = view_1185 = None
    copy_69 = torch.ops.aten.copy.default(select_454, add_409);  select_454 = add_409 = None
    select_scatter_default_36 = torch.ops.aten.select_scatter.default(permute_409, copy_69, 2, 0);  permute_409 = copy_69 = None
    select_463 = torch.ops.aten.select.int(select_scatter_default_36, 2, 1)
    select_460 = torch.ops.aten.select.int(mul_527, 2, 1);  mul_527 = None
    expand_378 = torch.ops.aten.expand.default(select_460, [1, 16, 64, 128]);  select_460 = None
    view_1192 = torch.ops.aten.reshape.default(expand_378, [16, 64, 128]);  expand_378 = None
    expand_379 = torch.ops.aten.expand.default(add_410, [1, 16, 128, 128]);  add_410 = None
    view_1193 = torch.ops.aten.reshape.default(expand_379, [16, 128, 128]);  expand_379 = None
    bmm_177 = torch.ops.aten.bmm.default(view_1192, view_1193);  view_1192 = view_1193 = None
    view_1194 = torch.ops.aten.reshape.default(bmm_177, [1, 16, 64, 128]);  bmm_177 = None
    select_461 = torch.ops.aten.select.int(mul_525, 2, 1);  mul_525 = None
    expand_380 = torch.ops.aten.expand.default(select_461, [1, 16, 64, 64]);  select_461 = None
    view_1195 = torch.ops.aten.reshape.default(expand_380, [16, 64, 64]);  expand_380 = None
    expand_381 = torch.ops.aten.expand.default(sub_89, [1, 16, 64, 128]);  sub_89 = None
    view_1196 = torch.ops.aten.reshape.default(expand_381, [16, 64, 128]);  expand_381 = None
    bmm_178 = torch.ops.aten.bmm.default(view_1195, view_1196);  view_1195 = view_1196 = None
    view_1197 = torch.ops.aten.reshape.default(bmm_178, [1, 16, 64, 128]);  bmm_178 = None
    add_411 = torch.ops.aten.add.Tensor(view_1194, view_1197);  view_1194 = view_1197 = None
    copy_70 = torch.ops.aten.copy.default(select_463, add_411);  select_463 = add_411 = None
    select_scatter_default_37 = torch.ops.aten.select_scatter.default(select_scatter_default_36, copy_70, 2, 1);  select_scatter_default_36 = copy_70 = None
    clone_141 = torch.ops.aten.clone.default(select_scatter_default_37, memory_format = torch.contiguous_format);  select_scatter_default_37 = None
    view_1201 = torch.ops.aten.reshape.default(clone_141, [1, 16, 128, 128]);  clone_141 = None
    permute_412 = torch.ops.aten.permute.default(view_1201, [0, 2, 1, 3]);  view_1201 = None
    convert_element_type_819 = torch.ops.prims.convert_element_type.default(permute_412, torch.bfloat16);  permute_412 = None
    clone_142 = torch.ops.aten.clone.default(convert_element_type_819, memory_format = torch.contiguous_format);  convert_element_type_819 = None
    view_1202 = torch.ops.aten.reshape.default(clone_142, [-1, 128]);  clone_142 = None
    convert_element_type_820 = torch.ops.prims.convert_element_type.default(view_1202, torch.float32);  view_1202 = None
    pow_70 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_820, 2)
    mean_69 = torch.ops.aten.mean.dim(pow_70, [-1], True);  pow_70 = None
    add_413 = torch.ops.aten.add.Tensor(mean_69, 1e-06);  mean_69 = None
    rsqrt_103 = torch.ops.aten.rsqrt.default(add_413);  add_413 = None
    mul_531 = torch.ops.aten.mul.Tensor(convert_element_type_820, rsqrt_103);  convert_element_type_820 = rsqrt_103 = None
    convert_element_type_821 = torch.ops.prims.convert_element_type.default(mul_531, torch.bfloat16);  mul_531 = None
    mul_532 = torch.ops.aten.mul.Tensor(arg340_1, convert_element_type_821);  arg340_1 = convert_element_type_821 = None
    view_1152 = torch.ops.aten.reshape.default(convert_element_type_800, [128, 2048]);  convert_element_type_800 = None
    permute_398 = torch.ops.aten.permute.default(arg332_1, [1, 0]);  arg332_1 = None
    mm_164 = torch.ops.aten.mm.default(view_1152, permute_398);  view_1152 = permute_398 = None
    view_1153 = torch.ops.aten.reshape.default(mm_164, [1, 128, 2048]);  mm_164 = None
    view_1154 = torch.ops.aten.reshape.default(view_1153, [1, 128, -1, 128]);  view_1153 = None
    view_1203 = torch.ops.aten.reshape.default(view_1154, [-1, 128]);  view_1154 = None
    convert_element_type_822 = torch.ops.prims.convert_element_type.default(view_1203, torch.float32);  view_1203 = None
    neg_81 = torch.ops.aten.neg.default(convert_element_type_822)
    exp_178 = torch.ops.aten.exp.default(neg_81);  neg_81 = None
    add_414 = torch.ops.aten.add.Tensor(exp_178, 1);  exp_178 = None
    div_59 = torch.ops.aten.div.Tensor(convert_element_type_822, add_414);  convert_element_type_822 = add_414 = None
    mul_533 = torch.ops.aten.mul.Tensor(mul_532, div_59);  mul_532 = div_59 = None
    convert_element_type_823 = torch.ops.prims.convert_element_type.default(mul_533, torch.bfloat16);  mul_533 = None
    view_1204 = torch.ops.aten.reshape.default(convert_element_type_823, [1, 128, -1]);  convert_element_type_823 = None
    view_1205 = torch.ops.aten.reshape.default(view_1204, [128, 2048]);  view_1204 = None
    permute_413 = torch.ops.aten.permute.default(arg341_1, [1, 0]);  arg341_1 = None
    mm_167 = torch.ops.aten.mm.default(view_1205, permute_413);  view_1205 = permute_413 = None
    view_1206 = torch.ops.aten.reshape.default(mm_167, [1, 128, 2048]);  mm_167 = None
    add_415 = torch.ops.aten.add.Tensor(add_399, view_1206);  add_399 = view_1206 = None
    convert_element_type_826 = torch.ops.prims.convert_element_type.default(add_415, torch.float32)
    pow_71 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_826, 2)
    mean_70 = torch.ops.aten.mean.dim(pow_71, [-1], True);  pow_71 = None
    add_416 = torch.ops.aten.add.Tensor(mean_70, 1e-06);  mean_70 = None
    rsqrt_104 = torch.ops.aten.rsqrt.default(add_416);  add_416 = None
    mul_534 = torch.ops.aten.mul.Tensor(convert_element_type_826, rsqrt_104);  convert_element_type_826 = rsqrt_104 = None
    convert_element_type_827 = torch.ops.prims.convert_element_type.default(arg342_1, torch.float32);  arg342_1 = None
    add_417 = torch.ops.aten.add.Tensor(convert_element_type_827, 1.0);  convert_element_type_827 = None
    mul_535 = torch.ops.aten.mul.Tensor(mul_534, add_417);  mul_534 = add_417 = None
    convert_element_type_828 = torch.ops.prims.convert_element_type.default(mul_535, torch.bfloat16);  mul_535 = None
    view_1207 = torch.ops.aten.reshape.default(convert_element_type_828, [128, 2048])
    permute_414 = torch.ops.aten.permute.default(arg343_1, [1, 0]);  arg343_1 = None
    mm_168 = torch.ops.aten.mm.default(view_1207, permute_414);  view_1207 = permute_414 = None
    view_1208 = torch.ops.aten.reshape.default(mm_168, [1, 128, 6144]);  mm_168 = None
    convert_element_type_831 = torch.ops.prims.convert_element_type.default(view_1208, torch.float32);  view_1208 = None
    neg_82 = torch.ops.aten.neg.default(convert_element_type_831)
    exp_179 = torch.ops.aten.exp.default(neg_82);  neg_82 = None
    add_418 = torch.ops.aten.add.Tensor(exp_179, 1);  exp_179 = None
    div_60 = torch.ops.aten.div.Tensor(convert_element_type_831, add_418);  convert_element_type_831 = add_418 = None
    convert_element_type_832 = torch.ops.prims.convert_element_type.default(div_60, torch.bfloat16);  div_60 = None
    view_1209 = torch.ops.aten.reshape.default(convert_element_type_828, [128, 2048]);  convert_element_type_828 = None
    permute_415 = torch.ops.aten.permute.default(arg344_1, [1, 0]);  arg344_1 = None
    mm_169 = torch.ops.aten.mm.default(view_1209, permute_415);  view_1209 = permute_415 = None
    view_1210 = torch.ops.aten.reshape.default(mm_169, [1, 128, 6144]);  mm_169 = None
    mul_536 = torch.ops.aten.mul.Tensor(convert_element_type_832, view_1210);  convert_element_type_832 = view_1210 = None
    view_1211 = torch.ops.aten.reshape.default(mul_536, [128, 6144]);  mul_536 = None
    permute_416 = torch.ops.aten.permute.default(arg345_1, [1, 0]);  arg345_1 = None
    mm_170 = torch.ops.aten.mm.default(view_1211, permute_416);  view_1211 = permute_416 = None
    view_1212 = torch.ops.aten.reshape.default(mm_170, [1, 128, 2048]);  mm_170 = None
    add_419 = torch.ops.aten.add.Tensor(add_415, view_1212);  add_415 = view_1212 = None
    convert_element_type_837 = torch.ops.prims.convert_element_type.default(add_419, torch.float32)
    pow_72 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_837, 2)
    mean_71 = torch.ops.aten.mean.dim(pow_72, [-1], True);  pow_72 = None
    add_420 = torch.ops.aten.add.Tensor(mean_71, 1e-06);  mean_71 = None
    rsqrt_105 = torch.ops.aten.rsqrt.default(add_420);  add_420 = None
    mul_537 = torch.ops.aten.mul.Tensor(convert_element_type_837, rsqrt_105);  convert_element_type_837 = rsqrt_105 = None
    convert_element_type_838 = torch.ops.prims.convert_element_type.default(arg346_1, torch.float32);  arg346_1 = None
    add_421 = torch.ops.aten.add.Tensor(convert_element_type_838, 1.0);  convert_element_type_838 = None
    mul_538 = torch.ops.aten.mul.Tensor(mul_537, add_421);  mul_537 = add_421 = None
    convert_element_type_839 = torch.ops.prims.convert_element_type.default(mul_538, torch.bfloat16);  mul_538 = None
    view_1213 = torch.ops.aten.reshape.default(convert_element_type_839, [128, 2048])
    permute_417 = torch.ops.aten.permute.default(arg347_1, [1, 0]);  arg347_1 = None
    mm_171 = torch.ops.aten.mm.default(view_1213, permute_417);  view_1213 = permute_417 = None
    view_1214 = torch.ops.aten.reshape.default(mm_171, [1, 128, 6144]);  mm_171 = None
    permute_418 = torch.ops.aten.permute.default(view_1214, [0, 2, 1]);  view_1214 = None
    slice_194 = torch.ops.aten.slice.Tensor(permute_418, 2, -4, 9223372036854775807)
    copy_72 = torch.ops.aten.copy.default(arg351_1, slice_194);  slice_194 = None
    convert_element_type_848 = torch.ops.prims.convert_element_type.default(permute_418, torch.float32);  permute_418 = None
    constant_pad_nd_102 = torch.ops.aten.constant_pad_nd.default(convert_element_type_848, [3, 3], 0.0);  convert_element_type_848 = None
    slice_195 = torch.ops.aten.slice.Tensor(constant_pad_nd_102, 2, 0, 131)
    squeeze_17 = torch.ops.aten.squeeze.dim(arg352_1, 1);  arg352_1 = None
    unsqueeze_252 = torch.ops.aten.unsqueeze.default(squeeze_17, 1);  squeeze_17 = None
    convert_element_type_849 = torch.ops.prims.convert_element_type.default(unsqueeze_252, torch.float32);  unsqueeze_252 = None
    select_467 = torch.ops.aten.select.int(convert_element_type_849, 1, 0)
    select_468 = torch.ops.aten.select.int(select_467, 1, 0);  select_467 = None
    view_1222 = torch.ops.aten.reshape.default(select_468, [1, -1, 1]);  select_468 = None
    mul_539 = torch.ops.aten.mul.Tensor(slice_195, view_1222);  slice_195 = view_1222 = None
    slice_196 = torch.ops.aten.slice.Tensor(constant_pad_nd_102, 2, 1, 132)
    select_469 = torch.ops.aten.select.int(convert_element_type_849, 1, 0)
    select_470 = torch.ops.aten.select.int(select_469, 1, 1);  select_469 = None
    view_1223 = torch.ops.aten.reshape.default(select_470, [1, -1, 1]);  select_470 = None
    mul_540 = torch.ops.aten.mul.Tensor(slice_196, view_1223);  slice_196 = view_1223 = None
    add_422 = torch.ops.aten.add.Tensor(mul_539, mul_540);  mul_539 = mul_540 = None
    slice_197 = torch.ops.aten.slice.Tensor(constant_pad_nd_102, 2, 2, 133)
    select_471 = torch.ops.aten.select.int(convert_element_type_849, 1, 0)
    select_472 = torch.ops.aten.select.int(select_471, 1, 2);  select_471 = None
    view_1224 = torch.ops.aten.reshape.default(select_472, [1, -1, 1]);  select_472 = None
    mul_541 = torch.ops.aten.mul.Tensor(slice_197, view_1224);  slice_197 = view_1224 = None
    add_423 = torch.ops.aten.add.Tensor(add_422, mul_541);  add_422 = mul_541 = None
    slice_198 = torch.ops.aten.slice.Tensor(constant_pad_nd_102, 2, 3, 134);  constant_pad_nd_102 = None
    select_473 = torch.ops.aten.select.int(convert_element_type_849, 1, 0);  convert_element_type_849 = None
    select_474 = torch.ops.aten.select.int(select_473, 1, 3);  select_473 = None
    view_1225 = torch.ops.aten.reshape.default(select_474, [1, -1, 1]);  select_474 = None
    mul_542 = torch.ops.aten.mul.Tensor(slice_198, view_1225);  slice_198 = view_1225 = None
    add_424 = torch.ops.aten.add.Tensor(add_423, mul_542);  add_423 = mul_542 = None
    convert_element_type_850 = torch.ops.prims.convert_element_type.default(add_424, torch.bfloat16);  add_424 = None
    slice_199 = torch.ops.aten.slice.Tensor(convert_element_type_850, 2, 0, 128);  convert_element_type_850 = None
    convert_element_type_851 = torch.ops.prims.convert_element_type.default(slice_199, torch.float32);  slice_199 = None
    neg_83 = torch.ops.aten.neg.default(convert_element_type_851)
    exp_180 = torch.ops.aten.exp.default(neg_83);  neg_83 = None
    add_425 = torch.ops.aten.add.Tensor(exp_180, 1);  exp_180 = None
    div_61 = torch.ops.aten.div.Tensor(convert_element_type_851, add_425);  convert_element_type_851 = add_425 = None
    convert_element_type_852 = torch.ops.prims.convert_element_type.default(div_61, torch.bfloat16);  div_61 = None
    slice_200 = torch.ops.aten.slice.Tensor(convert_element_type_852, 2, -128, 9223372036854775807);  convert_element_type_852 = None
    permute_422 = torch.ops.aten.permute.default(slice_200, [0, 2, 1]);  slice_200 = None
    split_with_sizes_17 = torch.ops.aten.split_with_sizes.default(permute_422, [2048, 2048, 2048], -1);  permute_422 = None
    getitem_61 = split_with_sizes_17[0]
    getitem_62 = split_with_sizes_17[1]
    getitem_63 = split_with_sizes_17[2];  split_with_sizes_17 = None
    full_53 = torch.ops.aten.full.default([1, 16, 128, 128], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    exp_181 = torch.ops.aten.exp.default(arg353_1);  arg353_1 = None
    neg_84 = torch.ops.aten.neg.default(exp_181);  exp_181 = None
    view_1220 = torch.ops.aten.reshape.default(convert_element_type_839, [128, 2048])
    permute_421 = torch.ops.aten.permute.default(arg350_1, [1, 0]);  arg350_1 = None
    mm_174 = torch.ops.aten.mm.default(view_1220, permute_421);  view_1220 = permute_421 = None
    view_1221 = torch.ops.aten.reshape.default(mm_174, [1, 128, 16]);  mm_174 = None
    convert_element_type_853 = torch.ops.prims.convert_element_type.default(view_1221, torch.float32);  view_1221 = None
    add_426 = torch.ops.aten.add.Tensor(convert_element_type_853, arg354_1);  convert_element_type_853 = arg354_1 = None
    gt_17 = torch.ops.aten.gt.Scalar(add_426, 20)
    exp_182 = torch.ops.aten.exp.default(add_426)
    log1p_17 = torch.ops.aten.log1p.default(exp_182);  exp_182 = None
    where_35 = torch.ops.aten.where.self(gt_17, add_426, log1p_17);  gt_17 = add_426 = log1p_17 = None
    mul_543 = torch.ops.aten.mul.Tensor(neg_84, where_35);  neg_84 = where_35 = None
    permute_427 = torch.ops.aten.permute.default(mul_543, [0, 2, 1]);  mul_543 = None
    view_1233 = torch.ops.aten.reshape.default(permute_427, [1, 16, 2, 64]);  permute_427 = None
    cumsum_17 = torch.ops.aten.cumsum.default(view_1233, 3);  view_1233 = None
    select_475 = torch.ops.aten.select.int(cumsum_17, 3, -1)
    exp_187 = torch.ops.aten.exp.default(select_475);  select_475 = None
    unsqueeze_262 = torch.ops.aten.unsqueeze.default(exp_187, 3);  exp_187 = None
    unsqueeze_263 = torch.ops.aten.unsqueeze.default(unsqueeze_262, 4);  unsqueeze_262 = None
    select_482 = torch.ops.aten.select.int(unsqueeze_263, 2, 0)
    mul_556 = torch.ops.aten.mul.Tensor(full_53, select_482);  select_482 = None
    view_1227 = torch.ops.aten.reshape.default(getitem_62, [1, 128, 16, 128]);  getitem_62 = None
    permute_424 = torch.ops.aten.permute.default(view_1227, [0, 2, 1, 3]);  view_1227 = None
    convert_element_type_855 = torch.ops.prims.convert_element_type.default(permute_424, torch.float32);  permute_424 = None
    clone_144 = torch.ops.aten.clone.default(convert_element_type_855, memory_format = torch.contiguous_format);  convert_element_type_855 = None
    mul_546 = torch.ops.aten.mul.Tensor(clone_144, clone_144)
    sum_41 = torch.ops.aten.sum.dim_IntList(mul_546, [-1], True);  mul_546 = None
    add_428 = torch.ops.aten.add.Tensor(sum_41, 1e-06);  sum_41 = None
    rsqrt_107 = torch.ops.aten.rsqrt.default(add_428);  add_428 = None
    mul_547 = torch.ops.aten.mul.Tensor(clone_144, rsqrt_107);  clone_144 = rsqrt_107 = None
    view_1230 = torch.ops.aten.reshape.default(mul_547, [1, 16, -1, 64, 128])
    slice_201 = torch.ops.aten.slice.Tensor(cumsum_17, 3, -1, 9223372036854775807)
    sub_92 = torch.ops.aten.sub.Tensor(slice_201, cumsum_17);  slice_201 = None
    exp_186 = torch.ops.aten.exp.default(sub_92);  sub_92 = None
    unsqueeze_261 = torch.ops.aten.unsqueeze.default(exp_186, -1);  exp_186 = None
    mul_555 = torch.ops.aten.mul.Tensor(view_1230, unsqueeze_261);  unsqueeze_261 = None
    select_483 = torch.ops.aten.select.int(mul_555, 2, 0)
    permute_431 = torch.ops.aten.permute.default(select_483, [0, 1, 3, 2]);  select_483 = None
    expand_394 = torch.ops.aten.expand.default(permute_431, [1, 16, 128, 64]);  permute_431 = None
    view_1249 = torch.ops.aten.reshape.default(expand_394, [16, 128, 64]);  expand_394 = None
    view_1218 = torch.ops.aten.reshape.default(convert_element_type_839, [128, 2048])
    permute_420 = torch.ops.aten.permute.default(arg349_1, [1, 0]);  arg349_1 = None
    mm_173 = torch.ops.aten.mm.default(view_1218, permute_420);  view_1218 = permute_420 = None
    view_1219 = torch.ops.aten.reshape.default(mm_173, [1, 128, 16]);  mm_173 = None
    sigmoid_22 = torch.ops.aten.sigmoid.default(view_1219);  view_1219 = None
    permute_426 = torch.ops.aten.permute.default(sigmoid_22, [0, 2, 1]);  sigmoid_22 = None
    convert_element_type_857 = torch.ops.prims.convert_element_type.default(permute_426, torch.float32);  permute_426 = None
    clone_146 = torch.ops.aten.clone.default(convert_element_type_857, memory_format = torch.contiguous_format);  convert_element_type_857 = None
    unsqueeze_254 = torch.ops.aten.unsqueeze.default(clone_146, -1)
    mul_550 = torch.ops.aten.mul.Tensor(mul_547, unsqueeze_254);  mul_547 = unsqueeze_254 = None
    view_1231 = torch.ops.aten.reshape.default(mul_550, [1, 16, -1, 64, 128]);  mul_550 = None
    expand_384 = torch.ops.aten.expand.default(view_1231, [1, 16, 2, 64, 128])
    view_1234 = torch.ops.aten.reshape.default(expand_384, [32, 64, 128]);  expand_384 = None
    permute_428 = torch.ops.aten.permute.default(view_1230, [0, 1, 2, 4, 3])
    expand_385 = torch.ops.aten.expand.default(permute_428, [1, 16, 2, 128, 64]);  permute_428 = None
    view_1235 = torch.ops.aten.reshape.default(expand_385, [32, 128, 64]);  expand_385 = None
    bmm_180 = torch.ops.aten.bmm.default(view_1234, view_1235);  view_1234 = view_1235 = None
    view_1236 = torch.ops.aten.reshape.default(bmm_180, [1, 16, 2, 64, 64]);  bmm_180 = None
    iota_40 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_255 = torch.ops.aten.unsqueeze.default(iota_40, -2);  iota_40 = None
    iota_41 = torch.ops.prims.iota.default(64, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    unsqueeze_256 = torch.ops.aten.unsqueeze.default(iota_41, -1);  iota_41 = None
    sub_90 = torch.ops.aten.sub.Tensor(unsqueeze_255, unsqueeze_256);  unsqueeze_255 = unsqueeze_256 = None
    ge_17 = torch.ops.aten.ge.Scalar(sub_90, 1);  sub_90 = None
    full_default_36 = torch.ops.aten.full.default([64, 64], True, dtype = torch.bool, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    logical_and_17 = torch.ops.aten.logical_and.default(ge_17, full_default_36);  ge_17 = full_default_36 = None
    full_default_37 = torch.ops.aten.full.default([], -inf, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    unsqueeze_257 = torch.ops.aten.unsqueeze.default(cumsum_17, 4)
    unsqueeze_258 = torch.ops.aten.unsqueeze.default(cumsum_17, 3)
    sub_91 = torch.ops.aten.sub.Tensor(unsqueeze_257, unsqueeze_258);  unsqueeze_257 = unsqueeze_258 = None
    where_36 = torch.ops.aten.where.self(logical_and_17, full_default_37, sub_91);  logical_and_17 = full_default_37 = sub_91 = None
    exp_183 = torch.ops.aten.exp.default(where_36);  where_36 = None
    mul_551 = torch.ops.aten.mul.Tensor(view_1236, exp_183);  view_1236 = None
    view_1228 = torch.ops.aten.reshape.default(getitem_63, [1, 128, 16, 128]);  getitem_63 = None
    permute_425 = torch.ops.aten.permute.default(view_1228, [0, 2, 1, 3]);  view_1228 = None
    convert_element_type_856 = torch.ops.prims.convert_element_type.default(permute_425, torch.float32);  permute_425 = None
    clone_145 = torch.ops.aten.clone.default(convert_element_type_856, memory_format = torch.contiguous_format);  convert_element_type_856 = None
    unsqueeze_253 = torch.ops.aten.unsqueeze.default(clone_146, -1);  clone_146 = None
    mul_549 = torch.ops.aten.mul.Tensor(clone_145, unsqueeze_253);  clone_145 = unsqueeze_253 = None
    view_1232 = torch.ops.aten.reshape.default(mul_549, [1, 16, -1, 64, 128]);  mul_549 = None
    linalg_solve_triangular_34 = torch.ops.aten.linalg_solve_triangular.default(mul_551, view_1232, upper = False, unitriangular = True);  view_1232 = None
    select_476 = torch.ops.aten.select.int(linalg_solve_triangular_34, 2, 0)
    exp_184 = torch.ops.aten.exp.default(cumsum_17)
    unsqueeze_259 = torch.ops.aten.unsqueeze.default(exp_184, -1);  exp_184 = None
    mul_553 = torch.ops.aten.mul.Tensor(view_1231, unsqueeze_259);  view_1231 = unsqueeze_259 = None
    linalg_solve_triangular_35 = torch.ops.aten.linalg_solve_triangular.default(mul_551, mul_553, upper = False, unitriangular = True);  mul_551 = mul_553 = None
    select_477 = torch.ops.aten.select.int(linalg_solve_triangular_35, 2, 0)
    expand_388 = torch.ops.aten.expand.default(select_477, [1, 16, 64, 128]);  select_477 = None
    view_1240 = torch.ops.aten.reshape.default(expand_388, [16, 64, 128]);  expand_388 = None
    expand_389 = torch.ops.aten.expand.default(full_53, [1, 16, 128, 128])
    view_1241 = torch.ops.aten.reshape.default(expand_389, [16, 128, 128]);  expand_389 = None
    bmm_182 = torch.ops.aten.bmm.default(view_1240, view_1241);  view_1240 = view_1241 = None
    view_1242 = torch.ops.aten.reshape.default(bmm_182, [1, 16, 64, 128]);  bmm_182 = None
    sub_93 = torch.ops.aten.sub.Tensor(select_476, view_1242);  select_476 = view_1242 = None
    expand_395 = torch.ops.aten.expand.default(sub_93, [1, 16, 64, 128])
    view_1250 = torch.ops.aten.reshape.default(expand_395, [16, 64, 128]);  expand_395 = None
    bmm_185 = torch.ops.aten.bmm.default(view_1249, view_1250);  view_1249 = view_1250 = None
    view_1251 = torch.ops.aten.reshape.default(bmm_185, [1, 16, 128, 128]);  bmm_185 = None
    add_430 = torch.ops.aten.add.Tensor(mul_556, view_1251);  mul_556 = view_1251 = None
    select_491 = torch.ops.aten.select.int(unsqueeze_263, 2, 1);  unsqueeze_263 = None
    mul_557 = torch.ops.aten.mul.Tensor(add_430, select_491);  select_491 = None
    select_492 = torch.ops.aten.select.int(mul_555, 2, 1);  mul_555 = None
    permute_432 = torch.ops.aten.permute.default(select_492, [0, 1, 3, 2]);  select_492 = None
    expand_402 = torch.ops.aten.expand.default(permute_432, [1, 16, 128, 64]);  permute_432 = None
    view_1261 = torch.ops.aten.reshape.default(expand_402, [16, 128, 64]);  expand_402 = None
    select_484 = torch.ops.aten.select.int(linalg_solve_triangular_34, 2, 1);  linalg_solve_triangular_34 = None
    select_485 = torch.ops.aten.select.int(linalg_solve_triangular_35, 2, 1);  linalg_solve_triangular_35 = None
    expand_396 = torch.ops.aten.expand.default(select_485, [1, 16, 64, 128]);  select_485 = None
    view_1252 = torch.ops.aten.reshape.default(expand_396, [16, 64, 128]);  expand_396 = None
    expand_397 = torch.ops.aten.expand.default(add_430, [1, 16, 128, 128])
    view_1253 = torch.ops.aten.reshape.default(expand_397, [16, 128, 128]);  expand_397 = None
    bmm_186 = torch.ops.aten.bmm.default(view_1252, view_1253);  view_1252 = view_1253 = None
    view_1254 = torch.ops.aten.reshape.default(bmm_186, [1, 16, 64, 128]);  bmm_186 = None
    sub_94 = torch.ops.aten.sub.Tensor(select_484, view_1254);  select_484 = view_1254 = None
    expand_403 = torch.ops.aten.expand.default(sub_94, [1, 16, 64, 128])
    view_1262 = torch.ops.aten.reshape.default(expand_403, [16, 64, 128]);  expand_403 = None
    bmm_189 = torch.ops.aten.bmm.default(view_1261, view_1262);  view_1261 = view_1262 = None
    view_1263 = torch.ops.aten.reshape.default(bmm_189, [1, 16, 128, 128]);  bmm_189 = None
    add_432 = torch.ops.aten.add.Tensor(mul_557, view_1263);  mul_557 = view_1263 = None
    full_54 = torch.ops.aten.full.default([1, 16, 2, 128, 64], 0, dtype = torch.float32, layout = torch.strided, device = device(type='tnca', index=0), pin_memory = False)
    permute_430 = torch.ops.aten.permute.default(full_54, [0, 1, 2, 4, 3]);  full_54 = None
    select_480 = torch.ops.aten.select.int(permute_430, 2, 0)
    view_1226 = torch.ops.aten.reshape.default(getitem_61, [1, 128, 16, 128]);  getitem_61 = None
    permute_423 = torch.ops.aten.permute.default(view_1226, [0, 2, 1, 3]);  view_1226 = None
    convert_element_type_854 = torch.ops.prims.convert_element_type.default(permute_423, torch.float32);  permute_423 = None
    clone_143 = torch.ops.aten.clone.default(convert_element_type_854, memory_format = torch.contiguous_format);  convert_element_type_854 = None
    mul_544 = torch.ops.aten.mul.Tensor(clone_143, clone_143)
    sum_40 = torch.ops.aten.sum.dim_IntList(mul_544, [-1], True);  mul_544 = None
    add_427 = torch.ops.aten.add.Tensor(sum_40, 1e-06);  sum_40 = None
    rsqrt_106 = torch.ops.aten.rsqrt.default(add_427);  add_427 = None
    mul_545 = torch.ops.aten.mul.Tensor(clone_143, rsqrt_106);  clone_143 = rsqrt_106 = None
    mul_548 = torch.ops.aten.mul.Tensor(mul_545, 0.08838834764831845);  mul_545 = None
    view_1229 = torch.ops.aten.reshape.default(mul_548, [1, 16, -1, 64, 128]);  mul_548 = None
    exp_185 = torch.ops.aten.exp.default(cumsum_17);  cumsum_17 = None
    unsqueeze_260 = torch.ops.aten.unsqueeze.default(exp_185, -1);  exp_185 = None
    mul_554 = torch.ops.aten.mul.Tensor(view_1229, unsqueeze_260);  unsqueeze_260 = None
    select_478 = torch.ops.aten.select.int(mul_554, 2, 0)
    expand_390 = torch.ops.aten.expand.default(select_478, [1, 16, 64, 128]);  select_478 = None
    view_1243 = torch.ops.aten.reshape.default(expand_390, [16, 64, 128]);  expand_390 = None
    expand_391 = torch.ops.aten.expand.default(full_53, [1, 16, 128, 128]);  full_53 = None
    view_1244 = torch.ops.aten.reshape.default(expand_391, [16, 128, 128]);  expand_391 = None
    bmm_183 = torch.ops.aten.bmm.default(view_1243, view_1244);  view_1243 = view_1244 = None
    view_1245 = torch.ops.aten.reshape.default(bmm_183, [1, 16, 64, 128]);  bmm_183 = None
    expand_386 = torch.ops.aten.expand.default(view_1229, [1, 16, 2, 64, 128]);  view_1229 = None
    view_1237 = torch.ops.aten.reshape.default(expand_386, [32, 64, 128]);  expand_386 = None
    permute_429 = torch.ops.aten.permute.default(view_1230, [0, 1, 2, 4, 3]);  view_1230 = None
    expand_387 = torch.ops.aten.expand.default(permute_429, [1, 16, 2, 128, 64]);  permute_429 = None
    view_1238 = torch.ops.aten.reshape.default(expand_387, [32, 128, 64]);  expand_387 = None
    bmm_181 = torch.ops.aten.bmm.default(view_1237, view_1238);  view_1237 = view_1238 = None
    view_1239 = torch.ops.aten.reshape.default(bmm_181, [1, 16, 2, 64, 64]);  bmm_181 = None
    mul_552 = torch.ops.aten.mul.Tensor(view_1239, exp_183);  view_1239 = exp_183 = None
    select_479 = torch.ops.aten.select.int(mul_552, 2, 0)
    expand_392 = torch.ops.aten.expand.default(select_479, [1, 16, 64, 64]);  select_479 = None
    view_1246 = torch.ops.aten.reshape.default(expand_392, [16, 64, 64]);  expand_392 = None
    expand_393 = torch.ops.aten.expand.default(sub_93, [1, 16, 64, 128]);  sub_93 = None
    view_1247 = torch.ops.aten.reshape.default(expand_393, [16, 64, 128]);  expand_393 = None
    bmm_184 = torch.ops.aten.bmm.default(view_1246, view_1247);  view_1246 = view_1247 = None
    view_1248 = torch.ops.aten.reshape.default(bmm_184, [1, 16, 64, 128]);  bmm_184 = None
    add_429 = torch.ops.aten.add.Tensor(view_1245, view_1248);  view_1245 = view_1248 = None
    copy_73 = torch.ops.aten.copy.default(select_480, add_429);  select_480 = add_429 = None
    select_scatter_default_38 = torch.ops.aten.select_scatter.default(permute_430, copy_73, 2, 0);  permute_430 = copy_73 = None
    select_489 = torch.ops.aten.select.int(select_scatter_default_38, 2, 1)
    select_486 = torch.ops.aten.select.int(mul_554, 2, 1);  mul_554 = None
    expand_398 = torch.ops.aten.expand.default(select_486, [1, 16, 64, 128]);  select_486 = None
    view_1255 = torch.ops.aten.reshape.default(expand_398, [16, 64, 128]);  expand_398 = None
    expand_399 = torch.ops.aten.expand.default(add_430, [1, 16, 128, 128]);  add_430 = None
    view_1256 = torch.ops.aten.reshape.default(expand_399, [16, 128, 128]);  expand_399 = None
    bmm_187 = torch.ops.aten.bmm.default(view_1255, view_1256);  view_1255 = view_1256 = None
    view_1257 = torch.ops.aten.reshape.default(bmm_187, [1, 16, 64, 128]);  bmm_187 = None
    select_487 = torch.ops.aten.select.int(mul_552, 2, 1);  mul_552 = None
    expand_400 = torch.ops.aten.expand.default(select_487, [1, 16, 64, 64]);  select_487 = None
    view_1258 = torch.ops.aten.reshape.default(expand_400, [16, 64, 64]);  expand_400 = None
    expand_401 = torch.ops.aten.expand.default(sub_94, [1, 16, 64, 128]);  sub_94 = None
    view_1259 = torch.ops.aten.reshape.default(expand_401, [16, 64, 128]);  expand_401 = None
    bmm_188 = torch.ops.aten.bmm.default(view_1258, view_1259);  view_1258 = view_1259 = None
    view_1260 = torch.ops.aten.reshape.default(bmm_188, [1, 16, 64, 128]);  bmm_188 = None
    add_431 = torch.ops.aten.add.Tensor(view_1257, view_1260);  view_1257 = view_1260 = None
    copy_74 = torch.ops.aten.copy.default(select_489, add_431);  select_489 = add_431 = None
    select_scatter_default_39 = torch.ops.aten.select_scatter.default(select_scatter_default_38, copy_74, 2, 1);  select_scatter_default_38 = copy_74 = None
    clone_148 = torch.ops.aten.clone.default(select_scatter_default_39, memory_format = torch.contiguous_format);  select_scatter_default_39 = None
    view_1264 = torch.ops.aten.reshape.default(clone_148, [1, 16, 128, 128]);  clone_148 = None
    permute_433 = torch.ops.aten.permute.default(view_1264, [0, 2, 1, 3]);  view_1264 = None
    convert_element_type_858 = torch.ops.prims.convert_element_type.default(permute_433, torch.bfloat16);  permute_433 = None
    clone_149 = torch.ops.aten.clone.default(convert_element_type_858, memory_format = torch.contiguous_format);  convert_element_type_858 = None
    view_1265 = torch.ops.aten.reshape.default(clone_149, [-1, 128]);  clone_149 = None
    convert_element_type_859 = torch.ops.prims.convert_element_type.default(view_1265, torch.float32);  view_1265 = None
    pow_73 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_859, 2)
    mean_72 = torch.ops.aten.mean.dim(pow_73, [-1], True);  pow_73 = None
    add_433 = torch.ops.aten.add.Tensor(mean_72, 1e-06);  mean_72 = None
    rsqrt_108 = torch.ops.aten.rsqrt.default(add_433);  add_433 = None
    mul_558 = torch.ops.aten.mul.Tensor(convert_element_type_859, rsqrt_108);  convert_element_type_859 = rsqrt_108 = None
    convert_element_type_860 = torch.ops.prims.convert_element_type.default(mul_558, torch.bfloat16);  mul_558 = None
    mul_559 = torch.ops.aten.mul.Tensor(arg356_1, convert_element_type_860);  arg356_1 = convert_element_type_860 = None
    view_1215 = torch.ops.aten.reshape.default(convert_element_type_839, [128, 2048]);  convert_element_type_839 = None
    permute_419 = torch.ops.aten.permute.default(arg348_1, [1, 0]);  arg348_1 = None
    mm_172 = torch.ops.aten.mm.default(view_1215, permute_419);  view_1215 = permute_419 = None
    view_1216 = torch.ops.aten.reshape.default(mm_172, [1, 128, 2048]);  mm_172 = None
    view_1217 = torch.ops.aten.reshape.default(view_1216, [1, 128, -1, 128]);  view_1216 = None
    view_1266 = torch.ops.aten.reshape.default(view_1217, [-1, 128]);  view_1217 = None
    convert_element_type_861 = torch.ops.prims.convert_element_type.default(view_1266, torch.float32);  view_1266 = None
    neg_85 = torch.ops.aten.neg.default(convert_element_type_861)
    exp_188 = torch.ops.aten.exp.default(neg_85);  neg_85 = None
    add_434 = torch.ops.aten.add.Tensor(exp_188, 1);  exp_188 = None
    div_62 = torch.ops.aten.div.Tensor(convert_element_type_861, add_434);  convert_element_type_861 = add_434 = None
    mul_560 = torch.ops.aten.mul.Tensor(mul_559, div_62);  mul_559 = div_62 = None
    convert_element_type_862 = torch.ops.prims.convert_element_type.default(mul_560, torch.bfloat16);  mul_560 = None
    view_1267 = torch.ops.aten.reshape.default(convert_element_type_862, [1, 128, -1]);  convert_element_type_862 = None
    view_1268 = torch.ops.aten.reshape.default(view_1267, [128, 2048]);  view_1267 = None
    permute_434 = torch.ops.aten.permute.default(arg357_1, [1, 0]);  arg357_1 = None
    mm_175 = torch.ops.aten.mm.default(view_1268, permute_434);  view_1268 = permute_434 = None
    view_1269 = torch.ops.aten.reshape.default(mm_175, [1, 128, 2048]);  mm_175 = None
    add_435 = torch.ops.aten.add.Tensor(add_419, view_1269);  add_419 = view_1269 = None
    convert_element_type_865 = torch.ops.prims.convert_element_type.default(add_435, torch.float32)
    pow_74 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_865, 2)
    mean_73 = torch.ops.aten.mean.dim(pow_74, [-1], True);  pow_74 = None
    add_436 = torch.ops.aten.add.Tensor(mean_73, 1e-06);  mean_73 = None
    rsqrt_109 = torch.ops.aten.rsqrt.default(add_436);  add_436 = None
    mul_561 = torch.ops.aten.mul.Tensor(convert_element_type_865, rsqrt_109);  convert_element_type_865 = rsqrt_109 = None
    convert_element_type_866 = torch.ops.prims.convert_element_type.default(arg358_1, torch.float32);  arg358_1 = None
    add_437 = torch.ops.aten.add.Tensor(convert_element_type_866, 1.0);  convert_element_type_866 = None
    mul_562 = torch.ops.aten.mul.Tensor(mul_561, add_437);  mul_561 = add_437 = None
    convert_element_type_867 = torch.ops.prims.convert_element_type.default(mul_562, torch.bfloat16);  mul_562 = None
    view_1270 = torch.ops.aten.reshape.default(convert_element_type_867, [128, 2048])
    permute_435 = torch.ops.aten.permute.default(arg359_1, [1, 0]);  arg359_1 = None
    mm_176 = torch.ops.aten.mm.default(view_1270, permute_435);  view_1270 = permute_435 = None
    view_1271 = torch.ops.aten.reshape.default(mm_176, [1, 128, 6144]);  mm_176 = None
    convert_element_type_870 = torch.ops.prims.convert_element_type.default(view_1271, torch.float32);  view_1271 = None
    neg_86 = torch.ops.aten.neg.default(convert_element_type_870)
    exp_189 = torch.ops.aten.exp.default(neg_86);  neg_86 = None
    add_438 = torch.ops.aten.add.Tensor(exp_189, 1);  exp_189 = None
    div_63 = torch.ops.aten.div.Tensor(convert_element_type_870, add_438);  convert_element_type_870 = add_438 = None
    convert_element_type_871 = torch.ops.prims.convert_element_type.default(div_63, torch.bfloat16);  div_63 = None
    view_1272 = torch.ops.aten.reshape.default(convert_element_type_867, [128, 2048]);  convert_element_type_867 = None
    permute_436 = torch.ops.aten.permute.default(arg360_1, [1, 0]);  arg360_1 = None
    mm_177 = torch.ops.aten.mm.default(view_1272, permute_436);  view_1272 = permute_436 = None
    view_1273 = torch.ops.aten.reshape.default(mm_177, [1, 128, 6144]);  mm_177 = None
    mul_563 = torch.ops.aten.mul.Tensor(convert_element_type_871, view_1273);  convert_element_type_871 = view_1273 = None
    view_1274 = torch.ops.aten.reshape.default(mul_563, [128, 6144]);  mul_563 = None
    permute_437 = torch.ops.aten.permute.default(arg361_1, [1, 0]);  arg361_1 = None
    mm_178 = torch.ops.aten.mm.default(view_1274, permute_437);  view_1274 = permute_437 = None
    view_1275 = torch.ops.aten.reshape.default(mm_178, [1, 128, 2048]);  mm_178 = None
    add_439 = torch.ops.aten.add.Tensor(add_435, view_1275);  add_435 = view_1275 = None
    convert_element_type_876 = torch.ops.prims.convert_element_type.default(add_439, torch.float32)
    pow_75 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_876, 2)
    mean_74 = torch.ops.aten.mean.dim(pow_75, [-1], True);  pow_75 = None
    add_440 = torch.ops.aten.add.Tensor(mean_74, 1e-06);  mean_74 = None
    rsqrt_110 = torch.ops.aten.rsqrt.default(add_440);  add_440 = None
    mul_564 = torch.ops.aten.mul.Tensor(convert_element_type_876, rsqrt_110);  convert_element_type_876 = rsqrt_110 = None
    convert_element_type_877 = torch.ops.prims.convert_element_type.default(arg362_1, torch.float32);  arg362_1 = None
    add_441 = torch.ops.aten.add.Tensor(convert_element_type_877, 1.0);  convert_element_type_877 = None
    mul_565 = torch.ops.aten.mul.Tensor(mul_564, add_441);  mul_564 = add_441 = None
    convert_element_type_878 = torch.ops.prims.convert_element_type.default(mul_565, torch.bfloat16);  mul_565 = None
    view_1276 = torch.ops.aten.reshape.default(convert_element_type_878, [128, 2048])
    permute_438 = torch.ops.aten.permute.default(arg363_1, [1, 0]);  arg363_1 = None
    mm_179 = torch.ops.aten.mm.default(view_1276, permute_438);  view_1276 = permute_438 = None
    view_1277 = torch.ops.aten.reshape.default(mm_179, [1, 128, 4096]);  mm_179 = None
    view_1278 = torch.ops.aten.reshape.default(view_1277, [1, 128, -1, 512]);  view_1277 = None
    split_5 = torch.ops.aten.split.Tensor(view_1278, 256, -1);  view_1278 = None
    getitem_64 = split_5[0]
    getitem_65 = split_5[1];  split_5 = None
    add_449 = torch.ops.aten.add.Tensor(arg368_1, 128)
    convert_element_type_881 = torch.ops.prims.convert_element_type.default(getitem_64, torch.float32);  getitem_64 = None
    pow_76 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_881, 2)
    mean_75 = torch.ops.aten.mean.dim(pow_76, [-1], True);  pow_76 = None
    add_442 = torch.ops.aten.add.Tensor(mean_75, 1e-06);  mean_75 = None
    rsqrt_111 = torch.ops.aten.rsqrt.default(add_442);  add_442 = None
    mul_566 = torch.ops.aten.mul.Tensor(convert_element_type_881, rsqrt_111);  convert_element_type_881 = rsqrt_111 = None
    convert_element_type_882 = torch.ops.prims.convert_element_type.default(arg364_1, torch.float32);  arg364_1 = None
    add_443 = torch.ops.aten.add.Tensor(convert_element_type_882, 1.0);  convert_element_type_882 = None
    mul_567 = torch.ops.aten.mul.Tensor(mul_566, add_443);  mul_566 = add_443 = None
    convert_element_type_883 = torch.ops.prims.convert_element_type.default(mul_567, torch.bfloat16);  mul_567 = None
    permute_439 = torch.ops.aten.permute.default(convert_element_type_883, [0, 2, 1, 3]);  convert_element_type_883 = None
    slice_202 = torch.ops.aten.slice.Tensor(permute_439, 3, 0, 64)
    unsqueeze_264 = torch.ops.aten.unsqueeze.default(convert_element_type_2, 1);  convert_element_type_2 = None
    mul_570 = torch.ops.aten.mul.Tensor(slice_202, unsqueeze_264)
    slice_207 = torch.ops.aten.slice.Tensor(slice_202, 3, 32, 9223372036854775807)
    neg_87 = torch.ops.aten.neg.default(slice_207);  slice_207 = None
    slice_206 = torch.ops.aten.slice.Tensor(slice_202, 3, 0, 32);  slice_202 = None
    cat_20 = torch.ops.aten.cat.default([neg_87, slice_206], -1);  neg_87 = slice_206 = None
    unsqueeze_265 = torch.ops.aten.unsqueeze.default(convert_element_type_3, 1);  convert_element_type_3 = None
    mul_571 = torch.ops.aten.mul.Tensor(cat_20, unsqueeze_265);  cat_20 = None
    add_446 = torch.ops.aten.add.Tensor(mul_570, mul_571);  mul_570 = mul_571 = None
    slice_203 = torch.ops.aten.slice.Tensor(permute_439, 3, 64, 9223372036854775807);  permute_439 = None
    cat_22 = torch.ops.aten.cat.default([add_446, slice_203], -1);  add_446 = slice_203 = None
    expand_408 = torch.ops.aten.expand.default(cat_22, [1, 8, 128, 256]);  cat_22 = None
    view_1289 = torch.ops.aten.reshape.default(expand_408, [8, 128, 256]);  expand_408 = None
    iota_42 = torch.ops.prims.iota.default(128, start = 0, step = 1, dtype = torch.int64, device = device(type='tnca', index=0), requires_grad = False)
    add_448 = torch.ops.aten.add.Tensor(iota_42, arg368_1);  iota_42 = None
    view_1281 = torch.ops.aten.reshape.default(convert_element_type_878, [128, 2048])
    permute_440 = torch.ops.aten.permute.default(arg365_1, [1, 0]);  arg365_1 = None
    mm_180 = torch.ops.aten.mm.default(view_1281, permute_440);  view_1281 = permute_440 = None
    view_1282 = torch.ops.aten.reshape.default(mm_180, [1, 128, 512]);  mm_180 = None
    view_1283 = torch.ops.aten.reshape.default(view_1282, [1, 128, -1, 256]);  view_1282 = None
    convert_element_type_886 = torch.ops.prims.convert_element_type.default(view_1283, torch.float32);  view_1283 = None
    pow_77 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_886, 2)
    mean_76 = torch.ops.aten.mean.dim(pow_77, [-1], True);  pow_77 = None
    add_444 = torch.ops.aten.add.Tensor(mean_76, 1e-06);  mean_76 = None
    rsqrt_112 = torch.ops.aten.rsqrt.default(add_444);  add_444 = None
    mul_568 = torch.ops.aten.mul.Tensor(convert_element_type_886, rsqrt_112);  convert_element_type_886 = rsqrt_112 = None
    convert_element_type_887 = torch.ops.prims.convert_element_type.default(arg366_1, torch.float32);  arg366_1 = None
    add_445 = torch.ops.aten.add.Tensor(convert_element_type_887, 1.0);  convert_element_type_887 = None
    mul_569 = torch.ops.aten.mul.Tensor(mul_568, add_445);  mul_568 = add_445 = None
    convert_element_type_888 = torch.ops.prims.convert_element_type.default(mul_569, torch.bfloat16);  mul_569 = None
    permute_441 = torch.ops.aten.permute.default(convert_element_type_888, [0, 2, 1, 3]);  convert_element_type_888 = None
    slice_204 = torch.ops.aten.slice.Tensor(permute_441, 3, 0, 64)
    mul_572 = torch.ops.aten.mul.Tensor(slice_204, unsqueeze_264);  unsqueeze_264 = None
    slice_209 = torch.ops.aten.slice.Tensor(slice_204, 3, 32, 9223372036854775807)
    neg_88 = torch.ops.aten.neg.default(slice_209);  slice_209 = None
    slice_208 = torch.ops.aten.slice.Tensor(slice_204, 3, 0, 32);  slice_204 = None
    cat_21 = torch.ops.aten.cat.default([neg_88, slice_208], -1);  neg_88 = slice_208 = None
    mul_573 = torch.ops.aten.mul.Tensor(cat_21, unsqueeze_265);  cat_21 = unsqueeze_265 = None
    add_447 = torch.ops.aten.add.Tensor(mul_572, mul_573);  mul_572 = mul_573 = None
    slice_205 = torch.ops.aten.slice.Tensor(permute_441, 3, 64, 9223372036854775807);  permute_441 = None
    cat_23 = torch.ops.aten.cat.default([add_447, slice_205], -1);  add_447 = slice_205 = None
    index_put_10 = torch.ops.aten.index_put_.default(arg369_1, [None, None, add_448], cat_23);  arg369_1 = cat_23 = None
    unsqueeze_268 = torch.ops.aten.unsqueeze.default(index_put_10, 2);  index_put_10 = None
    expand_405 = torch.ops.aten.expand.default(unsqueeze_268, [1, 2, 4, 144, 256]);  unsqueeze_268 = None
    clone_151 = torch.ops.aten.clone.default(expand_405, memory_format = torch.contiguous_format);  expand_405 = None
    view_1287 = torch.ops.aten.reshape.default(clone_151, [1, 8, 144, 256]);  clone_151 = None
    permute_444 = torch.ops.aten.permute.default(view_1287, [0, 1, 3, 2]);  view_1287 = None
    expand_409 = torch.ops.aten.expand.default(permute_444, [1, 8, 256, 144]);  permute_444 = None
    view_1290 = torch.ops.aten.reshape.default(expand_409, [8, 256, 144]);  expand_409 = None
    bmm_190 = torch.ops.aten.bmm.default(view_1289, view_1290);  view_1289 = view_1290 = None
    view_1291 = torch.ops.aten.reshape.default(bmm_190, [1, 8, 128, 144]);  bmm_190 = None
    mul_574 = torch.ops.aten.mul.Tensor(view_1291, 0.0625);  view_1291 = None
    add_450 = torch.ops.aten.add.Tensor(mul_574, unsqueeze_3);  mul_574 = unsqueeze_3 = None
    convert_element_type_893 = torch.ops.prims.convert_element_type.default(add_450, torch.float32);  add_450 = None
    amax_5 = torch.ops.aten.amax.default(convert_element_type_893, [-1], True)
    sub_95 = torch.ops.aten.sub.Tensor(convert_element_type_893, amax_5);  convert_element_type_893 = amax_5 = None
    exp_190 = torch.ops.aten.exp.default(sub_95);  sub_95 = None
    sum_42 = torch.ops.aten.sum.dim_IntList(exp_190, [-1], True)
    div_64 = torch.ops.aten.div.Tensor(exp_190, sum_42);  exp_190 = sum_42 = None
    convert_element_type_894 = torch.ops.prims.convert_element_type.default(div_64, torch.bfloat16);  div_64 = None
    expand_410 = torch.ops.aten.expand.default(convert_element_type_894, [1, 8, 128, 144]);  convert_element_type_894 = None
    view_1292 = torch.ops.aten.reshape.default(expand_410, [8, 128, 144]);  expand_410 = None
    view_1284 = torch.ops.aten.reshape.default(convert_element_type_878, [128, 2048]);  convert_element_type_878 = None
    permute_442 = torch.ops.aten.permute.default(arg367_1, [1, 0]);  arg367_1 = None
    mm_181 = torch.ops.aten.mm.default(view_1284, permute_442);  view_1284 = permute_442 = None
    view_1285 = torch.ops.aten.reshape.default(mm_181, [1, 128, 512]);  mm_181 = None
    view_1286 = torch.ops.aten.reshape.default(view_1285, [1, 128, -1, 256]);  view_1285 = None
    permute_443 = torch.ops.aten.permute.default(view_1286, [0, 2, 1, 3]);  view_1286 = None
    index_put_11 = torch.ops.aten.index_put_.default(arg370_1, [None, None, add_448], permute_443);  arg370_1 = add_448 = permute_443 = None
    unsqueeze_271 = torch.ops.aten.unsqueeze.default(index_put_11, 2);  index_put_11 = None
    expand_407 = torch.ops.aten.expand.default(unsqueeze_271, [1, 2, 4, 144, 256]);  unsqueeze_271 = None
    clone_152 = torch.ops.aten.clone.default(expand_407, memory_format = torch.contiguous_format);  expand_407 = None
    view_1288 = torch.ops.aten.reshape.default(clone_152, [1, 8, 144, 256]);  clone_152 = None
    expand_411 = torch.ops.aten.expand.default(view_1288, [1, 8, 144, 256]);  view_1288 = None
    view_1293 = torch.ops.aten.reshape.default(expand_411, [8, 144, 256]);  expand_411 = None
    bmm_191 = torch.ops.aten.bmm.default(view_1292, view_1293);  view_1292 = view_1293 = None
    view_1294 = torch.ops.aten.reshape.default(bmm_191, [1, 8, 128, 256]);  bmm_191 = None
    permute_445 = torch.ops.aten.permute.default(view_1294, [0, 2, 1, 3]);  view_1294 = None
    clone_153 = torch.ops.aten.clone.default(permute_445, memory_format = torch.contiguous_format);  permute_445 = None
    view_1295 = torch.ops.aten.reshape.default(clone_153, [1, 128, -1]);  clone_153 = None
    clone_150 = torch.ops.aten.clone.default(getitem_65, memory_format = torch.contiguous_format);  getitem_65 = None
    view_1279 = torch.ops.aten.reshape.default(clone_150, [1, 128, 2048]);  clone_150 = None
    sigmoid_23 = torch.ops.aten.sigmoid.default(view_1279);  view_1279 = None
    mul_575 = torch.ops.aten.mul.Tensor(view_1295, sigmoid_23);  view_1295 = sigmoid_23 = None
    view_1296 = torch.ops.aten.reshape.default(mul_575, [128, 2048]);  mul_575 = None
    permute_446 = torch.ops.aten.permute.default(arg371_1, [1, 0]);  arg371_1 = None
    mm_182 = torch.ops.aten.mm.default(view_1296, permute_446);  view_1296 = permute_446 = None
    view_1297 = torch.ops.aten.reshape.default(mm_182, [1, 128, 2048]);  mm_182 = None
    add_451 = torch.ops.aten.add.Tensor(add_439, view_1297);  add_439 = view_1297 = None
    convert_element_type_899 = torch.ops.prims.convert_element_type.default(add_451, torch.float32)
    pow_78 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_899, 2)
    mean_77 = torch.ops.aten.mean.dim(pow_78, [-1], True);  pow_78 = None
    add_452 = torch.ops.aten.add.Tensor(mean_77, 1e-06);  mean_77 = None
    rsqrt_113 = torch.ops.aten.rsqrt.default(add_452);  add_452 = None
    mul_576 = torch.ops.aten.mul.Tensor(convert_element_type_899, rsqrt_113);  convert_element_type_899 = rsqrt_113 = None
    convert_element_type_900 = torch.ops.prims.convert_element_type.default(arg372_1, torch.float32);  arg372_1 = None
    add_453 = torch.ops.aten.add.Tensor(convert_element_type_900, 1.0);  convert_element_type_900 = None
    mul_577 = torch.ops.aten.mul.Tensor(mul_576, add_453);  mul_576 = add_453 = None
    convert_element_type_901 = torch.ops.prims.convert_element_type.default(mul_577, torch.bfloat16);  mul_577 = None
    view_1298 = torch.ops.aten.reshape.default(convert_element_type_901, [128, 2048])
    permute_447 = torch.ops.aten.permute.default(arg373_1, [1, 0]);  arg373_1 = None
    mm_183 = torch.ops.aten.mm.default(view_1298, permute_447);  view_1298 = permute_447 = None
    view_1299 = torch.ops.aten.reshape.default(mm_183, [1, 128, 6144]);  mm_183 = None
    convert_element_type_904 = torch.ops.prims.convert_element_type.default(view_1299, torch.float32);  view_1299 = None
    neg_89 = torch.ops.aten.neg.default(convert_element_type_904)
    exp_191 = torch.ops.aten.exp.default(neg_89);  neg_89 = None
    add_454 = torch.ops.aten.add.Tensor(exp_191, 1);  exp_191 = None
    div_65 = torch.ops.aten.div.Tensor(convert_element_type_904, add_454);  convert_element_type_904 = add_454 = None
    convert_element_type_905 = torch.ops.prims.convert_element_type.default(div_65, torch.bfloat16);  div_65 = None
    view_1300 = torch.ops.aten.reshape.default(convert_element_type_901, [128, 2048]);  convert_element_type_901 = None
    permute_448 = torch.ops.aten.permute.default(arg374_1, [1, 0]);  arg374_1 = None
    mm_184 = torch.ops.aten.mm.default(view_1300, permute_448);  view_1300 = permute_448 = None
    view_1301 = torch.ops.aten.reshape.default(mm_184, [1, 128, 6144]);  mm_184 = None
    mul_578 = torch.ops.aten.mul.Tensor(convert_element_type_905, view_1301);  convert_element_type_905 = view_1301 = None
    view_1302 = torch.ops.aten.reshape.default(mul_578, [128, 6144]);  mul_578 = None
    permute_449 = torch.ops.aten.permute.default(arg375_1, [1, 0]);  arg375_1 = None
    mm_185 = torch.ops.aten.mm.default(view_1302, permute_449);  view_1302 = permute_449 = None
    view_1303 = torch.ops.aten.reshape.default(mm_185, [1, 128, 2048]);  mm_185 = None
    add_455 = torch.ops.aten.add.Tensor(add_451, view_1303);  add_451 = view_1303 = None
    convert_element_type_910 = torch.ops.prims.convert_element_type.default(add_455, torch.float32);  add_455 = None
    pow_79 = torch.ops.aten.pow.Tensor_Scalar(convert_element_type_910, 2)
    mean_78 = torch.ops.aten.mean.dim(pow_79, [-1], True);  pow_79 = None
    add_456 = torch.ops.aten.add.Tensor(mean_78, 1e-06);  mean_78 = None
    rsqrt_114 = torch.ops.aten.rsqrt.default(add_456);  add_456 = None
    mul_579 = torch.ops.aten.mul.Tensor(convert_element_type_910, rsqrt_114);  convert_element_type_910 = rsqrt_114 = None
    convert_element_type_911 = torch.ops.prims.convert_element_type.default(arg376_1, torch.float32);  arg376_1 = None
    add_457 = torch.ops.aten.add.Tensor(convert_element_type_911, 1.0);  convert_element_type_911 = None
    mul_580 = torch.ops.aten.mul.Tensor(mul_579, add_457);  mul_579 = add_457 = None
    convert_element_type_912 = torch.ops.prims.convert_element_type.default(mul_580, torch.bfloat16);  mul_580 = None
    slice_210 = torch.ops.aten.slice.Tensor(convert_element_type_912, 1, -1, 9223372036854775807);  convert_element_type_912 = None
    view_1304 = torch.ops.aten.reshape.default(slice_210, [1, 2048]);  slice_210 = None
    permute_450 = torch.ops.aten.permute.default(arg2_1, [1, 0]);  arg2_1 = None
    mm_186 = torch.ops.aten.mm.default(view_1304, permute_450);  view_1304 = permute_450 = None
    view_1305 = torch.ops.aten.reshape.default(mm_186, [1, 1, 248320]);  mm_186 = None
    copy_ = torch.ops.aten.copy_.default(arg9_1, copy_4);  arg9_1 = copy_4 = copy_ = None
    copy__1 = torch.ops.aten.copy_.default(arg13_1, add_12);  arg13_1 = add_12 = copy__1 = None
    copy__2 = torch.ops.aten.copy_.default(arg25_1, copy_8);  arg25_1 = copy_8 = copy__2 = None
    copy__3 = torch.ops.aten.copy_.default(arg29_1, add_32);  arg29_1 = add_32 = copy__3 = None
    copy__4 = torch.ops.aten.copy_.default(arg41_1, copy_12);  arg41_1 = copy_12 = copy__4 = None
    copy__5 = torch.ops.aten.copy_.default(arg45_1, add_52);  arg45_1 = add_52 = copy__5 = None
    copy__6 = torch.ops.aten.copy_.default(arg58_1, add_69);  arg58_1 = add_69 = copy__6 = None
    copy__9 = torch.ops.aten.copy_.default(arg71_1, copy_16);  arg71_1 = copy_16 = copy__9 = None
    copy__10 = torch.ops.aten.copy_.default(arg75_1, add_88);  arg75_1 = add_88 = copy__10 = None
    copy__11 = torch.ops.aten.copy_.default(arg87_1, copy_20);  arg87_1 = copy_20 = copy__11 = None
    copy__12 = torch.ops.aten.copy_.default(arg91_1, add_108);  arg91_1 = add_108 = copy__12 = None
    copy__13 = torch.ops.aten.copy_.default(arg103_1, copy_24);  arg103_1 = copy_24 = copy__13 = None
    copy__14 = torch.ops.aten.copy_.default(arg107_1, add_128);  arg107_1 = add_128 = copy__14 = None
    copy__15 = torch.ops.aten.copy_.default(arg120_1, add_145);  arg120_1 = add_145 = copy__15 = None
    copy__18 = torch.ops.aten.copy_.default(arg133_1, copy_28);  arg133_1 = copy_28 = copy__18 = None
    copy__19 = torch.ops.aten.copy_.default(arg137_1, add_164);  arg137_1 = add_164 = copy__19 = None
    copy__20 = torch.ops.aten.copy_.default(arg149_1, copy_32);  arg149_1 = copy_32 = copy__20 = None
    copy__21 = torch.ops.aten.copy_.default(arg153_1, add_184);  arg153_1 = add_184 = copy__21 = None
    copy__22 = torch.ops.aten.copy_.default(arg165_1, copy_36);  arg165_1 = copy_36 = copy__22 = None
    copy__23 = torch.ops.aten.copy_.default(arg169_1, add_204);  arg169_1 = add_204 = copy__23 = None
    copy__24 = torch.ops.aten.copy_.default(arg182_1, add_221);  arg182_1 = add_221 = copy__24 = None
    copy__27 = torch.ops.aten.copy_.default(arg195_1, copy_40);  arg195_1 = copy_40 = copy__27 = None
    copy__28 = torch.ops.aten.copy_.default(arg199_1, add_240);  arg199_1 = add_240 = copy__28 = None
    copy__29 = torch.ops.aten.copy_.default(arg211_1, copy_44);  arg211_1 = copy_44 = copy__29 = None
    copy__30 = torch.ops.aten.copy_.default(arg215_1, add_260);  arg215_1 = add_260 = copy__30 = None
    copy__31 = torch.ops.aten.copy_.default(arg227_1, copy_48);  arg227_1 = copy_48 = copy__31 = None
    copy__32 = torch.ops.aten.copy_.default(arg231_1, add_280);  arg231_1 = add_280 = copy__32 = None
    copy__33 = torch.ops.aten.copy_.default(arg244_1, add_297);  arg244_1 = add_297 = copy__33 = None
    copy__36 = torch.ops.aten.copy_.default(arg257_1, copy_52);  arg257_1 = copy_52 = copy__36 = None
    copy__37 = torch.ops.aten.copy_.default(arg261_1, add_316);  arg261_1 = add_316 = copy__37 = None
    copy__38 = torch.ops.aten.copy_.default(arg273_1, copy_56);  arg273_1 = copy_56 = copy__38 = None
    copy__39 = torch.ops.aten.copy_.default(arg277_1, add_336);  arg277_1 = add_336 = copy__39 = None
    copy__40 = torch.ops.aten.copy_.default(arg289_1, copy_60);  arg289_1 = copy_60 = copy__40 = None
    copy__41 = torch.ops.aten.copy_.default(arg293_1, add_356);  arg293_1 = add_356 = copy__41 = None
    copy__42 = torch.ops.aten.copy_.default(arg306_1, add_373);  arg306_1 = add_373 = copy__42 = None
    copy__45 = torch.ops.aten.copy_.default(arg319_1, copy_64);  arg319_1 = copy_64 = copy__45 = None
    copy__46 = torch.ops.aten.copy_.default(arg323_1, add_392);  arg323_1 = add_392 = copy__46 = None
    copy__47 = torch.ops.aten.copy_.default(arg335_1, copy_68);  arg335_1 = copy_68 = copy__47 = None
    copy__48 = torch.ops.aten.copy_.default(arg339_1, add_412);  arg339_1 = add_412 = copy__48 = None
    copy__49 = torch.ops.aten.copy_.default(arg351_1, copy_72);  arg351_1 = copy_72 = copy__49 = None
    copy__50 = torch.ops.aten.copy_.default(arg355_1, add_432);  arg355_1 = add_432 = copy__50 = None
    copy__51 = torch.ops.aten.copy_.default(arg368_1, add_449);  arg368_1 = add_449 = copy__51 = None
    return (view_1305,)
    