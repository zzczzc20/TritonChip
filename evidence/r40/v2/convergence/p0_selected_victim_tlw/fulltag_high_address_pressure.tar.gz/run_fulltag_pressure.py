from pathlib import Path
import subprocess,itertools,json
r=Path.cwd();out=r/'fulltag_pressure';records=[]
for epoch,policy,seed in itertools.product([0,5],[46,78],[1,7]):
 name=f'epoch{epoch}_policy{policy}_seed{seed}';binary=str(out/(name+'.vvp'));cmd=['iverilog','-g2012','-I','rtl/common','-s','tb_nuca_slice','-Ptb_nuca_slice.SETS=32','-Ptb_nuca_slice.SET_W=5','-Ptb_nuca_slice.WAYS=8','-Ptb_nuca_slice.WAY_W=3','-Ptb_nuca_slice.REGISTER_VICTIM_OWNER=1','-Ptb_nuca_slice.DCO_REGISTERED_RANGES=1','-Ptb_nuca_slice.AMO_TRAFFIC=1','-Ptb_nuca_slice.DRAM_LAT=400',f'-Ptb_nuca_slice.EPOCH_CHURN={epoch}',f'-Ptb_nuca_slice.POLICY={policy}','-o',binary,'rtl/nuca/tnca_nuca_slice.v','rtl/nuca/tnca_nuca_slice_before.v','tb/common/tnca_dram_model.v','fulltag_pressure/tb_fulltag_pressure.v']
 for phase,args in [('build',cmd),('run',['vvp',binary,'+nreq=12000',f'+seed={seed}','+min_wb=1','+min_block=1'])]:
  p=subprocess.run(args,capture_output=True,text=True,timeout=900);s=p.stdout+p.stderr;(out/(name+'_'+phase+'.log')).write_text(s);assert p.returncode==0,(name,phase,s[-3500:])
 assert 'PASS' in s.splitlines() and 'FAIL' not in s and 'FATAL' not in s,s
 records.append(dict(name=name,status='functional-pass',stdout=s));(out/'report.json').write_text(json.dumps(records,indent=2)+'\n');print(name,'PASS',flush=True)
print('FULLTAG_HIGH_ADDRESS_PRESSURE_DONE',flush=True)
