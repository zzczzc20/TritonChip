    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    .li       s1, #4286578688
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s5, #1024
    s.movz       s6, #16
    v.splat      v2, s4
    v.iota       v2                              // arange(0, VLEN)
    s.addi       s7, s2, #0
    s.ld.d       s2, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.mov        v1, v0
for_1:
    s.cmp.ge     s1, s7, s5
    br.nz        s1, endfor_2
    v.splat      v0, s7
    v.movi       v3, #1024
    s.shli       s1, s7, #1                      // element offset -> bytes (x2)
    v.add        v4, v0, v2
    s.add        s8, s3, s1                      // &in_ptr0[...]
    v.movi       v0, #0
    v.cmp.lt     p1, v4, v3
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v3, [s8, #0]
    s.add        s1, s7, s6
    s.movz       s8, #1
    vf.cvt.bf16.f32 v4, v3
    vf.max.prop  v3, v1, v4
    @p1 v.sel        v4, v3, v1
    v.mov        v0, v4
    v.mov        v1, v0
    s.mov        s7, s1
    br.nz        s8, for_1
endfor_2:
    v.movi       v0, #1
    v.movi       v2, #0
    vf.cmp.uo    p1, v1, v1
    v.movi       v3, #0
    @p1 v.sel        v4, v0, v2
    vf.reduce.max.b v0, v1
    .li       s1, #2143289344
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.reduce.or.b v2, v4
    v.movi       v4, #0
    s.movz       s1, #1
    v.cmp.ne     p1, v2, v3
    @p1 v.sel        v2, v1, v0
    s.shli       s3, s4, #1                      // element offset -> bytes (x2)
    v.iota       v0                              // arange(0, VLEN)
    vf.add       v1, v2, v4
    v.splat      v2, s1
    s.add        s1, s2, s3                      // &out_ptr0[...]
    v.cmp.lt     p1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    @p1 v.st.h       [s1, #0], v0
__rctx_next:
    exit
