    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.add        v3, v1, v0
    v.movi       v0, #6
    v.sub        v1, v2, v3
    v.cmp.lt     p1, v3, v2
    @p1 v.sel        v4, v1, v3
    s.rdspecial  s2, arg_base
    v.lshr       v1, v4, v0
    s.ld.d       s3, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v0, v2, v1
    v.movi       v4, #256
    @p1 v.sel        v5, v0, v1
    v.cmp.lt     p1, v3, v4
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v0, [s3, v5]               // index is in elements (ISA sec 9.1)
    v.movi       v1, #0
    v.movi       v6, #63
    v.sub        v7, v1, v3
    v.cmp.lt     p2, v3, v1
    @p2 v.sel        v8, v7, v3
    v.mul        v3, v5, v4
    v.and        v4, v8, v6
    s.shli       s3, s1, #1                      // element offset -> bytes (x2)
    v.sub        v5, v1, v4
    s.ld.d       s1, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p2 v.sel        v6, v5, v4
    v.movi       v4, #64
    s.ld.d       s4, [s2, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.add        v5, v6, v3
    v.sub        v3, v1, v4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v7, [s1, v5]               // index is in elements (ISA sec 9.1)
    v.sub        v8, v2, v4
    v.cmp.lt     p2, v4, v1
    v.cmp.lt     p3, v4, v2
    @p2 v.sel        v1, v3, v4
    @p3 v.sel        v1, v8, v4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s4, v6]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v7
    s.ld.d       s1, [s2, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    vf.cvt.bf16.f32 v3, v1
    s.ld.d       s4, [s2, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    .li       s5, #1132462080
    v.splat      v1, s5                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.add        s5, s1, s3                      // &in_ptr4[...]
    v.rcp.approx v4, v1                          // ISA 8.8: <= 2**-22 relative
    s.ld.d       s1, [s2, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    .li       s3, #1065353216
    v.splat      v7, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v8, [s4, v6]               // index is in elements (ISA sec 9.1)
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v9, [s5, #0]
    vf.cvt.bf16.f32 v10, v8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v8, [s1, v6]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v6, v9
    vf.cvt.bf16.f32 v9, v8
    s.ld.d       s1, [s2, #48]                   // out_ptr0: device_ptr64 at arg_base+48
    .li       s2, #897988541
    v.splat      v8, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1077936128
    v.splat      v11, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3204448256
    v.splat      v12, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v13, v1, v4, v7
    .li       s2, #1065353216
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v14, v6, v9
    vf.add       v6, v3, v7
    vf.fms       v3, v4, v13, v4
    vf.neg       v7, v3                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v7, v7
    @p2 v.sel        v3, v7, v4
    vf.mul       v4, v0, v3                      // a/y: faithful quotient
    vf.fms       v7, v4, v1, v0
    vf.fms       v0, v7, v3, v4
    vf.neg       v1, v0                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v0, v1, v4
    vf.add       v1, v0, v8
    v.rsqrt.approx v0, v1                        // ISA 8.8: <= 2**-22 relative
    vf.mul       v3, v0, v0
    vf.mul       v4, v0, v12
    vf.fms       v7, v1, v3, v11
    vf.mul       v1, v4, v7                      // Newton step: 0.5*r0*(3 - x*r0^2)
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v3, v1, v0
    vf.mul       v0, v2, v3
    vf.mul       v1, v0, v6
    vf.mul       v0, v1, v10
    vf.add       v1, v0, v14
    vf.cvt.f32.bf16 v0, v1
    @p1 v.st.scatter.h [s1, v5], v0
__rctx_next:
    exit
