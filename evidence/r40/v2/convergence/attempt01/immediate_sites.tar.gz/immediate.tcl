set source [open /home/zzhouch/tnca_build/r40_attempt01_focused_p1/drivers.txt r]
gets $source driver_name
close $source
set driver [get_cells -quiet $driver_name]
set pins [get_pins -quiet -of_objects $driver -filter {DIRECTION == OUT}]
set nets [get_nets -quiet -segments -of_objects $pins]
set leaf_pins [get_pins -leaf -quiet -of_objects $nets]
set associated [get_cells -quiet -of_objects $leaf_pins]
set f [open /home/zzhouch/tnca_build/r40_attempt01_interactive_p1/immediate_sites.tsv {WRONLY CREAT EXCL}]
puts $f "cell\tprimitive\tis_primitive\tloc\tcell_query_slrs\tsite_query_slrs\tsites"
foreach cell $associated {
    set ref [get_property REF_NAME $cell]
    set primitive [get_property IS_PRIMITIVE $cell]
    set loc [get_property LOC $cell]
    set region_objects [get_slrs -quiet -of_objects $cell]
    set cell_regions [list]
    if {[llength $region_objects]} {set cell_regions [get_property NAME $region_objects]}
    set sites [list]
    set site_regions [list]
    set site_names [list]
    if {$primitive && $ref ni {GND VCC}} {
        if {$loc ne ""} {set sites [get_sites -quiet $loc]}
        if {[llength $sites]} {
            set site_names [get_property NAME $sites]
            set region_objects [get_slrs -quiet -of_objects $sites]
            if {[llength $region_objects]} {set site_regions [get_property NAME $region_objects]}
        }
    }
    puts $f [join [list [get_property NAME $cell] $ref $primitive $loc $cell_regions $site_regions $site_names] "\t"]
    flush $f
}
close $f
puts "R40_IMMEDIATE_SITE_QUERY_DONE cells=[llength $associated]"
