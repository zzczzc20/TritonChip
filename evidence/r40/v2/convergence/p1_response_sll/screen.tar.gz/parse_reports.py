#!/usr/bin/env python3
"""Vivado 2023.2 module-screen report parser."""

import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path
import re


def parse_timing_report(path: Path, warnings: list[str]) -> tuple[list[dict], str | None]:
    if not path.is_file():
        warnings.append(f"{path.name}: file absent")
        return [], None

    raw_bytes = path.read_bytes()
    file_hash = hashlib.sha256(raw_bytes).hexdigest()
    text = raw_bytes.decode("utf-8", errors="replace")

    sections = re.split(r"(?m)(?=^Slack(?:\s*\([^)]+\))?\s*:)", text)
    paths: list[dict] = []

    for sec in sections:
        if not re.match(r"^Slack(?:\s*\([^)]+\))?\s*:", sec):
            continue

        p: dict = {}
        m = re.search(r"^Slack(?:\s*\([^)]+\))?\s*:\s*(-?[\d.]+)ns", sec, re.M)
        p["slack_ns"] = float(m.group(1)) if m else None

        m = re.search(r"^\s*Source:\s*(\S+)", sec, re.M)
        p["source"] = m.group(1) if m else None

        m = re.search(r"^\s*Destination:\s*(\S+)", sec, re.M)
        p["destination"] = m.group(1) if m else None

        m = re.search(r"^\s*Path Type:\s*(.+)", sec, re.M)
        p["path_type"] = m.group(1).strip() if m else None

        m = re.search(r"^\s*Requirement:\s*(-?[\d.]+)ns", sec, re.M)
        p["requirement_ns"] = float(m.group(1)) if m else None

        dp_m = re.search(r"^\s*Data Path Delay:\s*([^\n\r]+)", sec, re.M)
        if dp_m:
            line = dp_m.group(1)
            dm = re.search(r"(-?[\d.]+)ns", line)
            p["data_delay_ns"] = float(dm.group(1)) if dm else None
            lm = re.search(r"logic\s+(-?[\d.]+)ns", line)
            p["logic_delay_ns"] = float(lm.group(1)) if lm else None
            rm = re.search(r"route\s+(-?[\d.]+)ns", line)
            p["route_delay_ns"] = float(rm.group(1)) if rm else None
        else:
            p["data_delay_ns"] = None
            p["logic_delay_ns"] = None
            p["route_delay_ns"] = None

        m = re.search(r"^\s*Logic Levels:\s*(\d+)", sec, re.M)
        p["logic_levels"] = int(m.group(1)) if m else None

        m = re.search(r"period=(-?[\d.]+)ns", sec)
        p["clock_period_ns"] = float(m.group(1)) if m else None

        # Verify parsed fields and report unparsable occurrences
        path_idx = len(paths) + 1
        for field in ("source", "destination", "path_type", "slack_ns"):
            if p[field] is None:
                warnings.append(f"{path.name} path {path_idx}: unparsable {field}")
        if dp_m and p["data_delay_ns"] is None:
            warnings.append(f"{path.name} path {path_idx}: unparsable data_delay_ns")
        if re.search(r"^\s*Requirement:", sec, re.M) and p["requirement_ns"] is None:
            warnings.append(f"{path.name} path {path_idx}: unparsable requirement_ns")
        if re.search(r"^\s*Logic Levels:", sec, re.M) and p["logic_levels"] is None:
            warnings.append(f"{path.name} path {path_idx}: unparsable logic_levels")

        paths.append(p)

    return paths, file_hash


def parse_response_pairs(path: Path, warnings: list[str]) -> tuple[dict, str | None]:
    if not path.is_file():
        warnings.append(f"{path.name}: file absent")
        null_res = {
            "row_count": None,
            "slr_pair_histogram": None,
            "source_loc_histogram": None,
            "destination_loc_histogram": None,
            "source_loc_prefix_histogram": None,
            "destination_loc_prefix_histogram": None,
            "both_laguna_count": None,
            "both_laguna_loc_count": None,
            "raw_file_hash": None,
            "raw_sha256": None,
        }
        return null_res, None

    raw_bytes = path.read_bytes()
    file_hash = hashlib.sha256(raw_bytes).hexdigest()
    text = raw_bytes.decode("utf-8", errors="replace")

    reader = csv.DictReader(text.splitlines(), delimiter="\t")
    if not reader.fieldnames:
        warnings.append(f"{path.name}: empty or missing header")

    row_count = 0
    slr_pairs: collections.Counter = collections.Counter()
    src_locs = {"SLICE": 0, "LAGUNA": 0, "other": 0}
    dst_locs = {"SLICE": 0, "LAGUNA": 0, "other": 0}
    both_laguna = 0

    for row in reader:
        row_count += 1
        s_slr = row.get("source_slr") or "UNKNOWN"
        d_slr = row.get("destination_slr") or "UNKNOWN"
        slr_pairs[f"{s_slr}->{d_slr}"] += 1

        s_loc = (row.get("source_loc") or "").strip()
        d_loc = (row.get("destination_loc") or "").strip()

        s_pref = "SLICE" if s_loc.startswith("SLICE") else ("LAGUNA" if s_loc.startswith("LAGUNA") else "other")
        d_pref = "SLICE" if d_loc.startswith("SLICE") else ("LAGUNA" if d_loc.startswith("LAGUNA") else "other")

        src_locs[s_pref] += 1
        dst_locs[d_pref] += 1
        if s_pref == "LAGUNA" and d_pref == "LAGUNA":
            both_laguna += 1

    pairs_data = {
        "row_count": row_count,
        "slr_pair_histogram": dict(slr_pairs),
        "source_loc_histogram": src_locs,
        "destination_loc_histogram": dst_locs,
        "source_loc_prefix_histogram": src_locs,
        "destination_loc_prefix_histogram": dst_locs,
        "both_laguna_count": both_laguna,
        "both_laguna_loc_count": both_laguna,
        "raw_file_hash": file_hash,
        "raw_sha256": file_hash,
    }
    return pairs_data, file_hash


def parse_case(case_dir_str: str) -> dict:
    case_dir = Path(case_dir_str)
    warnings: list[str] = []
    input_sha256: dict[str, str] = {}

    if not case_dir.is_dir():
        warnings.append(f"{case_dir_str}: directory not found")

    timing: dict[str, list[dict]] = {}
    for rpt in ("response_setup.rpt", "response_hold.rpt", "critical_paths.rpt"):
        paths, file_hash = parse_timing_report(case_dir / rpt, warnings)
        timing[rpt] = paths
        if file_hash:
            input_sha256[rpt] = file_hash

    pairs_data, pairs_hash = parse_response_pairs(case_dir / "response_pairs.tsv", warnings)
    if pairs_hash:
        input_sha256["response_pairs.tsv"] = pairs_hash

    return {
        "directory": case_dir_str,
        "input_sha256": input_sha256,
        "timing": timing,
        "response_pairs": pairs_data,
        "response_pairs.tsv": pairs_data,
        "warnings": warnings,
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Parse Vivado 2023.2 module-screen reports into JSON."
    )
    parser.add_argument(
        "directories",
        nargs="+",
        help="One or more directories containing reports to parse",
    )
    args = parser.parse_args()

    cases = [parse_case(d) for d in args.directories]
    result = {
        "schema_version": 1,
        "cases": cases,
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
