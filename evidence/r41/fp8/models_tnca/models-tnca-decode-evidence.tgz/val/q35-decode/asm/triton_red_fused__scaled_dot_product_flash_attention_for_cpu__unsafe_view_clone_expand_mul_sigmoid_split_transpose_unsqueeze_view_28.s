    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    s.rdspecial  s1, role_id
    s.movz       s2, #256
    v.sub        v2, v1, v0
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    v.cmp.lt     p1, v0, v1
    @p1 v.sel        v3, v2, v0
    v.movi       v2, #8
    s.ld.d       s1, [s3, #64]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.lshr       v4, v3, v2
    s.rdspecial  s2, arg_base
    s.movz       s3, #1
    s.add        s6, s1, s5                      // this context's own scratch
    v.sub        v2, v1, v4
    s.ld.d       s1, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.addi       s5, s6, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 2)
    s.movz       s6, #16
    s.ld.d       s7, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.iota       v3                              // arange(0, VLEN)
    s.movz       s8, #32
    s.movz       s9, #128
    s.movz       s10, #4
    .li       s11, #68719476737
    .li       s12, #2207613190144
    @p1 v.sel        v5, v2, v4
    s.ld.d       s13, [s2, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    v.splat      v2, s3
    s.movz       s3, #1
    s.ld.d       s14, [s2, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    v.cmp.lt     p1, v3, v2
    v.movi       v2, #256
    s.ld.d       s15, [s2, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    s.movz       s16, #0
    v.sub        v3, v1, v2
    s.ld.d       s17, [s2, #40]                  // out_ptr1: device_ptr64 at arg_base+40
    v.movi       v4, #0
    v.iota       v6                              // arange(0, VLEN)
    s.st.d       [s5, #0], s7
    v.cmp.lt     p2, v0, v4
    v.splat      v7, s3
    s.st.d       [s5, #8], s6
    v.movi       v8, #0
    v.cmp.lt     p3, v2, v1
    s.st.d       [s5, #16], s8
    v.cmp.lt     p4, v6, v7
    s.movz       s2, #0
    s.st.d       [s5, #48], s9
    v.sub        v1, v4, v0
    v.movi       v6, #255
    s.st.d       [s5, #56], s10
    @p2 v.sel        v7, v1, v0
    v.sub        v0, v4, v2
    s.st.d       [s5, #88], s11
    v.and        v1, v7, v6
    v.movi       v6, #0
    s.st.d       [s5, #104], s12
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.sb v7, [s1, v5]              // index is in elements (ISA sec 9.1)
    v.sub        v9, v4, v1
    v.movi       v10, #0
    v.cmp.lt     p1, v2, v4
    s.movz       s1, #32
    s.movz       s2, #16
    v.iota       v4                              // arange(0, VLEN)
    v.movi       v11, #1
    @p3 v.sel        v11, v3, v2
    v.movi       v3, #1
    v.cmp.ne     p3, v7, v8
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v3, [s13, v5]              // index is in elements (ISA sec 9.1)
    @p1 v.sel        v7, v0, v2
    @p2 v.sel        v0, v9, v1
    s.addi       s3, s16, #0
    v.mov        v10, v6
for_1:
    s.cmp.ge     s5, s3, s1
    br.nz        s5, endfor_2
    s.movz       s5, #0
    s.movz       s6, #0
    s.cmp.lt     s8, s4, s5
    s.movz       s5, #256
    s.sub        s9, s6, s8
    s.movz       s6, #0
    s.movz       s8, #0
    s.cmp.lt     s10, s5, s6
    s.xor        s6, s4, s9
    s.sub        s11, s8, s10
    s.sub        s8, s6, s9
    s.xor        s6, s9, s11
    s.lshri      s9, s8, #8
    v.splat      v1, s3
    s.xor        s10, s9, s6
    v.iota       v7                              // arange(0, VLEN)
    s.sub        s12, s10, s6
    s.movz       s6, #32
    s.muli       s10, s12, #128
    s.movz       s13, #16
    s.muli       s16, s3, #4
    v.add        v8, v1, v7
    v.movi       v1, #0
    v.splat      v7, s6
    v.splat      v9, s12
    v.movi       v11, #0
    v.splat      v12, s13
    v.cmp.ge     p1, v8, v1
    v.cmp.lt     p2, v8, v7
    v.cmp.ge     p4, v9, v11
    v.cmp.lt     p5, v9, v12
    s.add        s6, s7, s10
    p.and        p6, p1, p2
    p.and        p1, p4, p5
    s.add        s10, s6, s16
    p.and        p2, p6, p1
    v.splat      v1, s3
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.w       v7, [s10, #0]
    v.add        v8, v1, v4
    v.movi       v1, #256
    v.extract    s6, v0, #0
    v.mul        v9, v8, v1
    v.splat      v1, s6
    v.movi       v11, #32
    v.add        v12, v1, v9
    v.cmp.lt     p1, v8, v11
    v.movi       v1, #0
    v.movi       v8, #2
    v.sub        v9, v1, v5
    v.cmp.lt     p2, v5, v1
    @p2 v.sel        v11, v9, v5
    s.muli       s6, s9, #256
    v.lshr       v9, v11, v8
    v.movi       v8, #4
    v.sub        v11, v1, v9
    s.xor        s9, s5, s11
    @p2 v.sel        v13, v11, v9
    v.sub        v9, v1, v8
    v.cmp.lt     p2, v8, v1
    s.sub        s5, s9, s11
    v.movi       v1, #8192
    s.sub        s5, s8, s6
    v.extract    s5, v3, #0
    v.splat      v11, s5
    .li       s5, #1065353216
    v.splat      v14, s5                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v15, v11                        // ISA 8.8: <= 2**-22 relative
    v.mul        v16, v13, v1
    v.movi       v1, #1
    v.extract    s5, v16, #0
    v.splat      v13, s5
    v.movi       v16, #0
    v.add        v17, v12, v13
    @p3 v.sel        v12, v1, v16
    v.movi       v1, #0
    v.movi       v13, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v13, [s14, v17]            // index is in elements (ISA sec 9.1)
    v.movi       v16, #1
    v.movi       v17, #0
    v.cmp.eq     p4, v12, v1
    @p4 v.sel        v1, v16, v17
    v.movi       v12, #0
    v.extract    s5, v1, #0
    v.splat      v1, s5
    vf.cvt.bf16.f32 v16, v13
    v.cmp.ne     p4, v1, v12
    v.movi       v1, #1
    v.movi       v1, #0
    s.add        s5, s3, s2
    @p2 v.sel        v12, v9, v8
    s.movz       s6, #1
    s.movz       s8, #8192
    vf.fms       v8, v11, v15, v14
    vf.fms       v9, v15, v8, v15
    vf.neg       v8, v9                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v8, v8
    @p2 v.sel        v9, v8, v15
    vf.mul       v8, v7, v9                      // a/y: faithful quotient
    vf.fms       v12, v8, v11, v7
    vf.fms       v7, v12, v9, v8
    vf.neg       v9, v7                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v9, v9
    @p2 v.sel        v7, v9, v8
    @p4 v.sel        v8, v6, v7
    vf.mul       v7, v8, v16
    vf.add       v8, v10, v7
    @p1 v.sel        v7, v8, v10
    v.mov        v1, v7
    v.mov        v10, v1
    s.mov        s3, s5
    br.nz        s6, for_1
endfor_2:
    v.movi       v1, #512
    s.movz       s1, #1
    v.mul        v3, v5, v1
    v.iota       v1                              // arange(0, VLEN)
    v.add        v4, v3, v2
    v.splat      v2, s1
    v.add        v3, v4, v0
    v.cmp.lt     p1, v1, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v0, [s15, v3]              // index is in elements (ISA sec 9.1)
    .li       s1, #1069066811
    v.splat      v1, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1060205080
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v3, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v4, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.reduce.add.b v5, v10
    vf.cvt.bf16.f32 v6, v0
    v.movi       v0, #0
    s.movz       s1, #1
    vf.add       v7, v5, v0
    vf.neg       v0, v6
    s.shli       s2, s4, #1                      // element offset -> bytes (x2)
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s1
    vf.mul       v8, v0, v1
    s.add        s1, s17, s2                     // &out_ptr1[...]
    v.cmp.lt     p1, v5, v6
    s.movz       s2, #512
    v.exp2.approx v5, v8                         // ISA 8.8: <= 2**-22 relative
    vf.fms       v6, v0, v1, v8                  // the exact rounding error of x*log2(e)
    s.movz       s2, #256
    vf.mul       v0, v6, v2
    vf.fma       v1, v5, v0, v5                  // 2**t * 2**d
    vf.cmp.o     p2, v1, v1
    @p2 v.sel        v0, v1, v5
    vf.add       v1, v0, v3
    v.rcp.approx v0, v1                          // ISA 8.8: <= 2**-22 relative
    vf.fms       v2, v1, v0, v4
    vf.fms       v4, v0, v2, v0
    vf.neg       v2, v4                          // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v4, v2, v0
    vf.mul       v0, v3, v4                      // a/y: faithful quotient
    vf.fms       v2, v0, v1, v3
    vf.fms       v1, v2, v4, v0
    vf.neg       v2, v1                          // a/y: one correction to the IEEE quotient
    vf.cmp.o     p2, v2, v2
    @p2 v.sel        v1, v2, v0
    vf.mul       v0, v7, v1
    vf.cvt.f32.bf16 v1, v0
    @p1 v.st.h       [s1, #0], v1
__rctx_next:
    exit
