    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
__rctx_program:
    s.shli       s1, s2, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #5
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.movi       v6, #0
    @p1 v.sel        v7, v5, v4
    v.sub        v5, v0, v4
    v.cmp.lt     p2, v4, v0
    v.lshr       v8, v7, v3
    v.sub        v3, v1, v4
    @p2 v.sel        v7, v5, v4
    v.sub        v5, v2, v8
    v.movi       v9, #14
    v.cmp.lt     p3, v4, v1
    @p1 v.sel        v10, v5, v8
    @p3 v.sel        v5, v3, v4
    v.movi       v3, #31
    v.sub        v4, v6, v10
    v.cmp.lt     p1, v10, v6
    v.movi       v8, #511
    @p1 v.sel        v11, v4, v10
    v.lshr       v4, v7, v9
    v.and        v7, v5, v3
    v.and        v3, v11, v8
    v.sub        v5, v0, v4
    v.sub        v8, v1, v7
    v.sub        v9, v6, v3
    @p2 v.sel        v11, v5, v4
    v.movi       v4, #64
    @p3 v.sel        v5, v8, v7
    @p1 v.sel        v7, v9, v3
    v.movi       v3, #32
    v.mul        v8, v11, v4
    v.movi       v9, #256
    v.cmp.lt     p1, v3, v1
    v.add        v11, v5, v8
    v.mul        v8, v7, v9
    v.movi       v7, #512
    v.sub        v9, v1, v3
    v.add        v1, v11, v8
    v.movi       v8, #16384
    v.mul        v11, v10, v4
    v.ld.gather.h v4, [s3, v1]                   // index is in elements (ISA sec 9.1)
    v.sub        v1, v2, v3
    v.cmp.lt     p2, v3, v2
    v.sub        v2, v6, v7
    v.cmp.lt     p3, v7, v6
    v.sub        v6, v0, v8
    @p1 v.sel        v10, v9, v3
    v.add        v9, v5, v11
    v.cmp.lt     p1, v8, v0
    @p2 v.sel        v0, v1, v3
    @p3 v.sel        v0, v2, v7
    @p1 v.sel        v0, v6, v8
    v.st.scatter.h [s5, v9], v4
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s6, s1, s4
    s.mov        s2, s1
    br.nz        s6, __rctx_program
    exit
