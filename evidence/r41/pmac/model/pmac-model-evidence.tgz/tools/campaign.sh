#!/bin/bash
# The five what-if configurations after the baseline, one after another.
W=~/r41-pmac-model-work
for cfg in g2g4-pf1 g2g4-pf0 g1-pf1 g2g4-pf1-pipe6 g2g4-pf0-pipe6; do
  $W/tools/run_cfg.sh c-$cfg $cfg 14-19 6 $(cat $W/tools/points.txt)
done
echo CAMPAIGN-DONE > $W/runs/campaign.done
