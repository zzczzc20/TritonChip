    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #5
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.movi       v6, #0
    @p1 v.sel        v7, v5, v4
    v.sub        v5, v0, v4
    v.cmp.lt     p2, v4, v0
    v.lshr       v8, v7, v3
    v.sub        v3, v1, v4
    @p2 v.sel        v7, v5, v4
    v.sub        v5, v2, v8
    v.cmp.lt     p3, v4, v1
    @p3 v.sel        v9, v3, v4
    @p1 v.sel        v3, v5, v8
    v.movi       v4, #31
    v.movi       v5, #511
    v.sub        v8, v6, v3
    v.cmp.lt     p1, v3, v6
    v.and        v10, v9, v4
    @p1 v.sel        v4, v8, v3
    s.rdspecial  s1, arg_base
    v.sub        v8, v1, v10
    v.and        v9, v4, v5
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p3 v.sel        v4, v8, v10
    v.sub        v5, v6, v9
    v.movi       v8, #512
    v.movi       v10, #32
    @p1 v.sel        v11, v5, v9
    v.movi       v5, #16384
    v.sub        v9, v1, v10
    v.cmp.lt     p1, v10, v1
    v.sub        v1, v2, v10
    v.cmp.lt     p3, v10, v2
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v2, #14
    v.mul        v12, v11, v8
    @p1 v.sel        v11, v9, v10
    v.lshr       v9, v7, v2
    v.movi       v2, #64
    v.sub        v7, v6, v8
    v.cmp.lt     p1, v8, v6
    v.sub        v6, v0, v9
    v.mul        v11, v3, v2
    @p3 v.sel        v3, v1, v10
    @p2 v.sel        v1, v6, v9
    v.sub        v3, v0, v5
    v.add        v6, v4, v11
    v.mul        v9, v1, v2
    v.cmp.lt     p2, v5, v0
    @p1 v.sel        v0, v7, v8
    v.add        v0, v4, v9
    @p2 v.sel        v1, v3, v5
    v.add        v1, v0, v12
    v.ld.gather.h v0, [s2, v1]                   // index is in elements (ISA sec 9.1)
    v.st.scatter.h [s3, v6], v0
__rctx_next:
    exit
