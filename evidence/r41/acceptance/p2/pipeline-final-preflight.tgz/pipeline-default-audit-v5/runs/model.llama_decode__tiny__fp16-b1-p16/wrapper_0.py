# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/cr/ccrpxm73ljh3525amjh3j4b7rtp5ft4lz7c22ov2c46eus3fgrld.py
# Topologically Sorted Source Nodes: [x, rms_norm], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   rms_norm => add, convert_element_type, convert_element_type_1, mean, mul, mul_1, pow_1, rsqrt
#   x => embedding
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[256, 64][64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %buf0 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf0]
#   %arg6_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg6_1]
#   %embedding : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [2], True), kwargs = {})
#   %add : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean, 9.999999747378752e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg6_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_1, torch.float16), kwargs = {})
#   return %buf0,%convert_element_type_1
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 384}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    _tmp7 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.device_assert((0 <= tmp1) & (tmp1 < 256), "index out of bounds: 0 <= tmp1 < 256")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 64*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp3.to(tl.float32)
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
    tmp7 = triton_helpers.promote_to_tensor(tl.sum(_tmp7, 0))
    tmp9 = tl.load(in_ptr0 + (0))
    tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp20 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp10) & (tmp10 < 256), "index out of bounds: 0 <= tmp10 < 256")
        tmp12 = tl.load(in_ptr1 + (r0_0 + 64*tmp10), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp13 = tmp12.to(tl.float32)
        tmp14 = tl.full([1], 64.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp16 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = libdevice.rsqrt(tmp17)
        tmp19 = tmp13 * tmp18
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp19 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp23, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/fq/cfq5krsqaiszzvwghzvg6ifldwfau47gduz77zkw7uoms6hk4oor.py
# Topologically Sorted Source Nodes: [x, rms_norm, linear], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear => mm, permute, view
#   rms_norm => add, convert_element_type, convert_element_type_1, mean, mul, mul_1, pow_1, rsqrt
#   x => embedding
# Graph fragment:
#   %convert_element_type_1 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0" = PlaceHolder[target=convert_element_type_1]
#   %arg7_1 : Tensor "f16[64, 64][64, 1]tnca:0" = PlaceHolder[target=arg7_1]
#   %embedding : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [2], True), kwargs = {})
#   %add : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean, 9.999999747378752e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %rsqrt), kwargs = {})
#   %mul_1 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %arg6_1), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_1, torch.float16), kwargs = {})
#   %view : Tensor "f16[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_1, [1, 64]), kwargs = {})
#   %permute : Tensor "f16[64, 64][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg7_1, [1, 0]), kwargs = {})
#   %mm : Tensor "f16[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view, %permute), kwargs = {})
#   return %mm
triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1 = async_compile.triton('triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 64
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 64*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 64*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/md/cmdr3n44rzw5nsuxbtukytqpssexv3r6x3pymgzy23j6rdjeaajx.py
# Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_1 => mm_1, permute_2, view_3
# Graph fragment:
#   %convert_element_type_1 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0" = PlaceHolder[target=convert_element_type_1]
#   %arg8_1 : Tensor "f16[32, 64][64, 1]tnca:0" = PlaceHolder[target=arg8_1]
#   %view_3 : Tensor "f16[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_1, [1, 64]), kwargs = {})
#   %permute_2 : Tensor "f16[64, 32][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg8_1, [1, 0]), kwargs = {})
#   %mm_1 : Tensor "f16[1, 32][32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_3, %permute_2), kwargs = {})
#   return %mm_1
triton_tem_fused_mm_t_view_2 = async_compile.triton('triton_tem_fused_mm_t_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_2', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_2(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 32
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 64
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 32*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 32*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/w2/cw2l7omko5fxf66oz6ket2agszjeyzlmzkvfftzwr5ew6m2hlyja.py
# Topologically Sorted Source Nodes: [linear, view, q, chunk, neg], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
# Source node to ATen node mapping:
#   chunk => split
#   linear => view_1
#   neg => neg
#   q => permute_1
#   view => view_2
# Graph fragment:
#   %mm : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm]
#   %view_1 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 64]), kwargs = {})
#   %view_2 : Tensor "f16[1, 1, 4, 16][64, 64, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 1, 4, 16]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 4, 1, 16][64, 16, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_1, 8, -1), kwargs = {})
#   %neg : Tensor "f16[1, 4, 1, 8][32, 8, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_1,), kwargs = {})
#   return %neg
triton_poi_fused__unsafe_view_neg_split_transpose_view_3 = async_compile.triton('triton_poi_fused__unsafe_view_neg_split_transpose_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_neg_split_transpose_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 192}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_neg_split_transpose_view_3(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 8)
    x1 = xindex // 8
    tmp0 = tl.load(in_ptr0 + (8 + x0 + 16*x1), xmask).to(tl.float32)
    tmp1 = -tmp0
    tl.store(out_ptr0 + (x0 + 16*x1), tmp1, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/of/cofewtaydrp2cpvjrexwn4dzhfftxs223mj35mxanhdcuiru6kfa.py
# Topologically Sorted Source Nodes: [linear, view, q, chunk, neg, cat], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   cat => cat
#   chunk => split
#   linear => view_1
#   neg => neg
#   q => permute_1
#   view => view_2
# Graph fragment:
#   %mm : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm]
#   %view_1 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 64]), kwargs = {})
#   %view_2 : Tensor "f16[1, 1, 4, 16][64, 64, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 1, 4, 16]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 4, 1, 16][64, 16, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_1, 8, -1), kwargs = {})
#   %neg : Tensor "f16[1, 4, 1, 8][32, 8, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_1,), kwargs = {})
#   %cat : Tensor "f16[1, 4, 1, 16][64, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %getitem], -1), kwargs = {})
#   return %buf5
triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4 = async_compile.triton('triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 192}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 8)
    x1 = xindex // 8
    tmp0 = tl.load(in_ptr0 + (x0 + 16*x1), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 16*x1), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/cj/ccjybqzgt6vuda2m2x2mrblbdysbhl5bcc4om7tcqwmzeu6ihydw.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
# Source node to ATen node mapping:
#   chunk_1 => split_1
#   k => permute_3
#   linear_1 => view_4
#   neg_1 => neg_1
#   view_1 => view_5
# Graph fragment:
#   %mm_1 : Tensor "f16[1, 32][32, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %view_4 : Tensor "f16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 32]), kwargs = {})
#   %view_5 : Tensor "f16[1, 1, 2, 16][32, 32, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 1, 2, 16]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 2, 1, 16][32, 16, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %split_1 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_3, 8, -1), kwargs = {})
#   %neg_1 : Tensor "f16[1, 2, 1, 8][16, 8, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_3,), kwargs = {})
#   return %neg_1
triton_poi_fused__unsafe_view_neg_split_transpose_view_5 = async_compile.triton('triton_poi_fused__unsafe_view_neg_split_transpose_view_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_neg_split_transpose_view_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 96}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_neg_split_transpose_view_5(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 16
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 8)
    x1 = xindex // 8
    tmp0 = tl.load(in_ptr0 + (8 + x0 + 16*x1), xmask).to(tl.float32)
    tmp1 = -tmp0
    tl.store(out_ptr0 + (x0 + 16*x1), tmp1, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/fz/cfzwaebt57vxz2i2y2dva4dogz57f5yifduzd25fo6l2gpymg6gr.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1, cat_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
# Source node to ATen node mapping:
#   cat_1 => cat_1
#   chunk_1 => split_1
#   k => permute_3
#   linear_1 => view_4
#   neg_1 => neg_1
#   view_1 => view_5
# Graph fragment:
#   %mm_1 : Tensor "f16[1, 32][32, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %view_4 : Tensor "f16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 32]), kwargs = {})
#   %view_5 : Tensor "f16[1, 1, 2, 16][32, 32, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 1, 2, 16]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 2, 1, 16][32, 16, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %split_1 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%permute_3, 8, -1), kwargs = {})
#   %neg_1 : Tensor "f16[1, 2, 1, 8][16, 8, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%getitem_3,), kwargs = {})
#   %cat_1 : Tensor "f16[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %getitem_2], -1), kwargs = {})
#   return %buf8
triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6 = async_compile.triton('triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 96}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 16
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 8)
    x1 = xindex // 8
    tmp0 = tl.load(in_ptr0 + (x0 + 16*x1), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 16*x1), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/ae/cae3jqhxd2x37g6wqvpk6fupiod5z272h2aylp6dr5pkogi6oxgl.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, getitem, mul_2, mul_3, k_1, k_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem => select
#   k => permute_3
#   k_1 => add_2
#   k_2 => cat_2
#   linear_1 => view_4
#   mul_2 => mul_4
#   mul_3 => mul_5
#   view_1 => view_5
# Graph fragment:
#   %arg4_1 : Tensor "f16[2, 1, 2, 16, 16][512, 512, 256, 16, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_4 : Tensor "f16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 32]), kwargs = {})
#   %view_5 : Tensor "f16[1, 1, 2, 16][32, 32, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 1, 2, 16]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 2, 1, 16][32, 16, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %select : Tensor "f16[1, 2, 16, 16][512, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 0), kwargs = {})
#   %mul_4 : Tensor "f16[1, 2, 1, 16][32, 16, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_3, %arg2_1), kwargs = {})
#   %mul_5 : Tensor "f16[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %arg3_1), kwargs = {})
#   %add_2 : Tensor "f16[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_4, %mul_5), kwargs = {})
#   %cat_2 : Tensor "f16[1, 2, 17, 16][544, 272, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select, %add_2], 2), kwargs = {})
#   return %buf10
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3072}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 256)
    x1 = xindex // 256
    tmp0 = tl.load(in_ptr0 + (x2), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 272*x1), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/ya/cyak2ogm4w2bfj4qyfr2eebf3p3nob66p4ovxjvqytqonkz5ildd.py
# Topologically Sorted Source Nodes: [linear_1, view_1, k, mul_2, mul_3, k_1, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
# Source node to ATen node mapping:
#   k => permute_3
#   k_1 => add_2
#   linear_1 => view_4
#   mul_2 => mul_4
#   mul_3 => mul_5
#   stack => cat_8
#   view_1 => view_5
# Graph fragment:
#   %mm_1 : Tensor "f16[1, 32][32, 1]tnca:0" = PlaceHolder[target=mm_1]
#   %arg2_1 : Tensor "f16[1, 16][16, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %cat_1 : Tensor "f16[1, 2, 1, 16][32, 16, 16, 1]tnca:0" = PlaceHolder[target=cat_1]
#   %arg3_1 : Tensor "f16[1, 16][16, 1]tnca:0" = PlaceHolder[target=arg3_1]
#   %add_2 : Tensor "f16[1, 2, 1, 16][544, 272, 16, 1]tnca:0" = PlaceHolder[target=add_2]
#   %view_4 : Tensor "f16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 32]), kwargs = {})
#   %view_5 : Tensor "f16[1, 1, 2, 16][32, 32, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_4, [1, 1, 2, 16]), kwargs = {})
#   %permute_3 : Tensor "f16[1, 2, 1, 16][32, 16, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_5, [0, 2, 1, 3]), kwargs = {})
#   %mul_4 : Tensor "f16[1, 2, 1, 16][32, 16, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_3, %arg2_1), kwargs = {})
#   %mul_5 : Tensor "f16[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %arg3_1), kwargs = {})
#   %add_2 : Tensor "f16[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_4, %mul_5), kwargs = {})
#   %cat_8 : Tensor "f16[2, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%add_2, %add_9],), kwargs = {})
#   return %add_2,%buf66
triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8 = async_compile.triton('triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr0': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 448}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 16)
    x1 = xindex // 16
    tmp0 = tl.load(in_ptr0 + (x2), xmask).to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (x2), xmask).to(tl.float32)
    tmp4 = tl.load(in_ptr3 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp2 = tmp0 * tmp1
    tmp5 = tmp3 * tmp4
    tmp6 = tmp2 + tmp5
    tl.store(out_ptr0 + (x0 + 272*x1), tmp6, xmask)
    tl.store(out_ptr1 + (x2), tmp6, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/7k/c7kbrp5twp7eochw327pmd5vsobrsv3c72its4qxwgkrufhkukvu.py
# Topologically Sorted Source Nodes: [linear, view, q, mul, mul_1, q_1, o, getitem_6, expand, k_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
# Source node to ATen node mapping:
#   expand => expand
#   getitem_6 => unsqueeze
#   k_3 => clone, view_9
#   linear => view_1
#   mul => mul_2
#   mul_1 => mul_3
#   o => bmm, convert_element_type_8, convert_element_type_9, mul_6, mul_7, permute_6, view_11, view_12
#   q => permute_1
#   q_1 => add_1
#   view => view_2
# Graph fragment:
#   %mm : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm]
#   %arg2_1 : Tensor "f16[1, 16][16, 1]tnca:0" = PlaceHolder[target=arg2_1]
#   %cat : Tensor "f16[1, 4, 1, 16][64, 16, 16, 1]tnca:0" = PlaceHolder[target=cat]
#   %arg3_1 : Tensor "f16[1, 16][16, 1]tnca:0" = PlaceHolder[target=arg3_1]
#   %cat_2 : Tensor "f16[1, 2, 17, 16][544, 272, 16, 1]tnca:0" = PlaceHolder[target=cat_2]
#   %view_1 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 64]), kwargs = {})
#   %view_2 : Tensor "f16[1, 1, 4, 16][64, 64, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_1, [1, 1, 4, 16]), kwargs = {})
#   %permute_1 : Tensor "f16[1, 4, 1, 16][64, 16, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_2, [0, 2, 1, 3]), kwargs = {})
#   %mul_2 : Tensor "f16[1, 4, 1, 16][64, 16, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_1, %arg2_1), kwargs = {})
#   %mul_3 : Tensor "f16[1, 4, 1, 16][64, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %arg3_1), kwargs = {})
#   %add_1 : Tensor "f16[1, 4, 1, 16][64, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_2, %mul_3), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[1, 4, 1, 16][64, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_1, torch.float32), kwargs = {})
#   %mul_6 : Tensor "f32[1, 4, 1, 16][64, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%convert_element_type_8, 0.5), kwargs = {})
#   %view_11 : Tensor "f32[4, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_2, [4, 1, 16]), kwargs = {})
#   %unsqueeze : Tensor "f16[1, 2, 1, 17, 16][544, 272, 272, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%cat_2, 2), kwargs = {})
#   %expand : Tensor "f16[1, 2, 2, 17, 16][544, 272, 0, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze, [1, 2, 2, 17, 16]), kwargs = {})
#   %clone : Tensor "f16[1, 2, 2, 17, 16][1088, 544, 272, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand,), kwargs = {memory_format: torch.contiguous_format})
#   %view_9 : Tensor "f16[1, 4, 17, 16][1088, 272, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 4, 17, 16]), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[1, 4, 17, 16][1088, 272, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_9, torch.float32), kwargs = {})
#   %permute_6 : Tensor "f32[1, 4, 16, 17][1088, 272, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_9, [0, 1, 3, 2]), kwargs = {})
#   %mul_7 : Tensor "f32[1, 4, 16, 17][1088, 272, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Scalar](args = (%permute_6, 0.5), kwargs = {})
#   %view_12 : Tensor "f32[4, 16, 17][272, 1, 16]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_3, [4, 16, 17]), kwargs = {})
#   %bmm : Tensor "f32[4, 1, 17][17, 17, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_11, %view_12), kwargs = {})
#   return %bmm
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 128, 'r0_': 16},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 544, 'r0_': 1408}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 68
    XBLOCK: tl.constexpr = 1
    r0_numel = 16
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 17
    x0 = (xindex % 17)
    _tmp15 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_2 + 16*x1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tl.load(in_ptr1 + (r0_2), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp3 = tl.load(in_ptr2 + (r0_2 + 16*x1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tl.load(in_ptr3 + (r0_2), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tl.load(in_ptr4 + (r0_2 + 16*x0 + 272*(x1 // 2)), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp2 = tmp0 * tmp1
        tmp5 = tmp3 * tmp4
        tmp6 = tmp2 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tl.full([1], 0.5, tl.float32)
        tmp9 = tmp7 * tmp8
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tmp11 * tmp8
        tmp13 = tmp9 * tmp12
        tmp14 = tl.broadcast_to(tmp13, [R0_BLOCK])
        tmp16 = _tmp15 + tmp14
        _tmp15 = tl.where(r0_mask, tmp16, _tmp15)
    tmp15 = triton_helpers.promote_to_tensor(tl.sum(_tmp15, 0))
    tl.store(out_ptr0 + (x3), tmp15, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/gg/cggcuiixjolb5ys3emg22auuhpfw5ztkigu2bu5gv4qb63nifpve.py
# Topologically Sorted Source Nodes: [o], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
# Source node to ATen node mapping:
#   o => amax, any_1, eq, exp, logical_not, sub, sum_1, view_13
# Graph fragment:
#   %bmm : Tensor "f32[4, 1, 17][17, 17, 1]tnca:0" = PlaceHolder[target=bmm]
#   %amax : Tensor "f32[1, 4, 1, 1][4, 1, 4, 4]tnca:0" = PlaceHolder[target=amax]
#   %exp : Tensor "f32[1, 4, 1, 17][68, 17, 68, 1]tnca:0" = PlaceHolder[target=exp]
#   %view_13 : Tensor "f32[1, 4, 1, 17][68, 17, 17, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm, [1, 4, 1, 17]), kwargs = {})
#   %eq : Tensor "b8[1, 4, 1, 17][68, 17, 17, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Scalar](args = (%view_13, -inf), kwargs = {})
#   %logical_not : Tensor "b8[1, 4, 1, 17][68, 17, 17, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%eq,), kwargs = {})
#   %any_1 : Tensor "b8[1, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.any.dim](args = (%logical_not, -1, True), kwargs = {})
#   %amax : Tensor "f32[1, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%view_13, [-1], True), kwargs = {})
#   %sub : Tensor "f32[1, 4, 1, 17][68, 17, 17, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%view_13, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 4, 1, 17][68, 17, 17, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub,), kwargs = {})
#   %sum_1 : Tensor "f32[1, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%exp, [-1], True), kwargs = {})
#   return %any_1,%amax,%exp,%sum_1
triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4, 'r0_': 32},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*i1', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 2, 'num_store': 3, 'num_reduction': 3, 'autotune_hints': set(), 'tiling_scores': {'x': 20, 'r0_': 816}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10(in_ptr0, out_ptr0, out_ptr2, out_ptr3, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 4
    XBLOCK: tl.constexpr = 1
    r0_numel = 17
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([R0_BLOCK], False, tl.int1)
    _tmp11 = tl.full([R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 17*x0), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp1 = tl.full([1], float("-inf"), tl.float32)
        tmp2 = tmp0 == tmp1
        tmp3 = tmp2 == 0
        tmp4 = tmp3.to(tl.int64)
        tmp5 = (tmp4 != 0)
        tmp6 = tl.broadcast_to(tmp5, [R0_BLOCK])
        tmp8 = _tmp7 | tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
        tmp10 = tl.broadcast_to(tmp0, [R0_BLOCK])
        tmp12 = tl.maximum(_tmp11, tmp10, tl.PropagateNan.ALL)
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp9 = _tmp7.to(tl.int8)
    tmp7 = triton_helpers.promote_to_tensor(triton_helpers.any(tmp9, 0))
    tmp11 = triton_helpers.promote_to_tensor(triton_helpers.max2(_tmp11, 0))
    tl.store(out_ptr0 + (x0), tmp7, None)
    _tmp17 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr0 + (r0_1 + 17*x0), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp14 = tmp13 - tmp11
        tmp15 = libdevice.exp(tmp14)
        tmp16 = tl.broadcast_to(tmp15, [R0_BLOCK])
        tmp18 = _tmp17 + tmp16
        _tmp17 = tl.where(r0_mask, tmp18, _tmp17)
        tl.store(out_ptr2 + (r0_1 + 17*x0), tmp15, r0_mask)
    tmp17 = triton_helpers.promote_to_tensor(tl.sum(_tmp17, 0))
    tl.store(out_ptr3 + (x0), tmp17, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/zt/czt4itfljsb7m7esualf4r5yfj7qa23xjitucatzlsm4yzduveec.py
# Topologically Sorted Source Nodes: [getitem_1, linear_2, view_2, v, v_1, linear_9, view_5, v_3, stack_1], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat, aten.stack]
# Source node to ATen node mapping:
#   getitem_1 => select_1
#   linear_2 => view_7
#   linear_9 => view_33
#   stack_1 => cat_9
#   v => permute_5
#   v_1 => cat_3
#   v_3 => permute_19
#   view_2 => view_8
#   view_5 => view_34
# Graph fragment:
#   %mm_2 : Tensor "f16[1, 32][32, 1]tnca:0" = PlaceHolder[target=mm_2]
#   %select_1 : Tensor "f16[1, 2, 16, 16][512, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg5_1, 0, 0), kwargs = {})
#   %view_7 : Tensor "f16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 1, 32]), kwargs = {})
#   %view_8 : Tensor "f16[1, 1, 2, 16][32, 32, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_7, [1, 1, 2, 16]), kwargs = {})
#   %permute_5 : Tensor "f16[1, 2, 1, 16][32, 16, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_8, [0, 2, 1, 3]), kwargs = {})
#   %cat_3 : Tensor "f16[1, 2, 17, 16][544, 272, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_1, %permute_5], 2), kwargs = {})
#   %view_33 : Tensor "f16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_9, [1, 1, 32]), kwargs = {})
#   %view_34 : Tensor "f16[1, 1, 2, 16][32, 32, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_33, [1, 1, 2, 16]), kwargs = {})
#   %permute_19 : Tensor "f16[1, 2, 1, 16][32, 16, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_34, [0, 2, 1, 3]), kwargs = {})
#   %cat_9 : Tensor "f16[2, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%permute_5, %permute_19],), kwargs = {})
#   return %buf20,%buf69
triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_11 = async_compile.triton('triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 320}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_11(in_ptr0, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 16)
    x1 = xindex // 16
    tmp0 = tl.load(in_ptr0 + (x2), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 272*x1), tmp0, xmask)
    tl.store(out_ptr1 + (x2), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/a6/ca6uxsrfkgytp6d2cu33a6qmcg2gvd222rf7ylut4lu7k2ezs6tz.py
# Topologically Sorted Source Nodes: [o, getitem_7, expand_1, v_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
# Source node to ATen node mapping:
#   expand_1 => expand_1
#   getitem_7 => unsqueeze_1
#   o => bmm_1, convert_element_type_10, convert_element_type_11, div, full_default, logical_not_1, view_14, view_15, view_16, where
#   v_2 => clone_1, view_10
# Graph fragment:
#   %any_1 : Tensor "b8[1, 4, 1, 1][4, 1, 4, 4]tnca:0" = PlaceHolder[target=any_1]
#   %exp : Tensor "f32[1, 4, 1, 17][68, 17, 68, 1]tnca:0" = PlaceHolder[target=exp]
#   %sum_1 : Tensor "f32[1, 4, 1, 1][4, 1, 4, 4]tnca:0" = PlaceHolder[target=sum_1]
#   %cat_3 : Tensor "f16[1, 2, 17, 16][544, 272, 16, 1]tnca:0" = PlaceHolder[target=cat_3]
#   %bmm_1 : Tensor "f32[4, 1, 16][16, 16, 1]tnca:0" = PlaceHolder[target=bmm_1]
#   %logical_not_1 : Tensor "b8[1, 4, 1, 1][4, 1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.logical_not.default](args = (%any_1,), kwargs = {})
#   %full_default : Tensor "f32[1, 4, 1, 17][68, 17, 17, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.full.default](args = ([1, 4, 1, 17], 0), kwargs = {dtype: torch.float32, layout: torch.strided, device: tnca:0, pin_memory: False})
#   %div : Tensor "f32[1, 4, 1, 17][68, 17, 17, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp, %sum_1), kwargs = {})
#   %where : Tensor "f32[1, 4, 1, 17][68, 17, 17, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.where.self](args = (%logical_not_1, %full_default, %div), kwargs = {})
#   %view_14 : Tensor "f32[4, 1, 17][17, 17, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_4, [4, 1, 17]), kwargs = {})
#   %unsqueeze_1 : Tensor "f16[1, 2, 1, 17, 16][544, 272, 272, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%cat_3, 2), kwargs = {})
#   %expand_1 : Tensor "f16[1, 2, 2, 17, 16][544, 272, 0, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, 2, 2, 17, 16]), kwargs = {})
#   %clone_1 : Tensor "f16[1, 2, 2, 17, 16][1088, 544, 272, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_1,), kwargs = {memory_format: torch.contiguous_format})
#   %view_10 : Tensor "f16[1, 4, 17, 16][1088, 272, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_1, [1, 4, 17, 16]), kwargs = {})
#   %convert_element_type_10 : Tensor "f32[1, 4, 17, 16][1088, 272, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_10, torch.float32), kwargs = {})
#   %view_15 : Tensor "f32[4, 17, 16][272, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%expand_5, [4, 17, 16]), kwargs = {})
#   %bmm_1 : Tensor "f32[4, 1, 16][16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.bmm.default](args = (%view_14, %view_15), kwargs = {})
#   %view_16 : Tensor "f32[1, 4, 1, 16][64, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%bmm_1, [1, 4, 1, 16]), kwargs = {})
#   %convert_element_type_11 : Tensor "f16[1, 4, 1, 16][64, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_16, torch.float16), kwargs = {})
#   return %bmm_1,%convert_element_type_11
triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12 = async_compile.triton('triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 64, 'r0_': 32},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i1', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'i32', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 1344, 'r0_': 272}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 64
    XBLOCK: tl.constexpr = 1
    r0_numel = 17
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    x1 = xindex // 16
    tmp0 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last').to(tl.int1)
    tmp3 = tl.load(in_ptr2 + (x1), None, eviction_policy='evict_last')
    x0 = (xindex % 16)
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp2 = tl.load(in_ptr1 + (r0_2 + 17*x1), r0_mask, eviction_policy='evict_last', other=0.0)
        tmp7 = tl.load(in_ptr3 + (x0 + 16*r0_2 + 272*(x1 // 2)), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp1 = tmp0 == 0
        tmp4 = (tmp2 / tmp3)
        tmp5 = tl.full([1], 0.0, tl.float32)
        tmp6 = tl.where(tmp1, tmp5, tmp4)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp6 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp13 = tmp11.to(tl.float32)
    tl.store(out_ptr1 + (x3), tmp13, None)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/2r/c2rnm64p4qftr6cvwnaiuwdwpby46j4hbv4lni43unoedw2cz5aj.py
# Topologically Sorted Source Nodes: [x, h, x_1, y], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   x => embedding
#   x_1 => add_3
#   y => add_4, convert_element_type_15, convert_element_type_16, mean_1, mul_8, mul_9, pow_2, rsqrt_1
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[256, 64][64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %buf25 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf25]
#   %arg11_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg11_1]
#   %embedding : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 64]), kwargs = {})
#   %add_3 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %convert_element_type_15 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_3, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_15, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [2], True), kwargs = {})
#   %add_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_1, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4,), kwargs = {})
#   %mul_8 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_15, %rsqrt_1), kwargs = {})
#   %mul_9 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_8, %arg11_1), kwargs = {})
#   %convert_element_type_16 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_9, torch.float16), kwargs = {})
#   return %buf25,%convert_element_type_16
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 512}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[64], strides=[1], block_shape=[R0_BLOCK])
    _tmp9 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 256), "index out of bounds: 0 <= tmp1 < 256")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 64*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask, tmp10, _tmp9)
    tmp9 = triton_helpers.promote_to_tensor(tl.sum(_tmp9, 0))
    tmp11 = tl.load(in_ptr0 + (0))
    tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[64], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp24 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp12) & (tmp12 < 256), "index out of bounds: 0 <= tmp12 < 256")
        tmp14 = tl.load(in_ptr1 + (r0_0 + 64*tmp12), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tmp14 + tmp15
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tl.full([1], 64.0, tl.float32)
        tmp19 = (tmp9 / tmp18)
        tmp20 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = libdevice.rsqrt(tmp21)
        tmp23 = tmp17 * tmp22
        tmp25 = tmp24.to(tl.float32)
        tmp26 = tmp23 * tmp25
        tmp27 = tmp26.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp27, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/jn/cjndgno4o5qiu7ycwnl65eqt5ggksrcjfczgsgahyf43bjxh436y.py
# Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_4 => mm_4, permute_11, view_20
# Graph fragment:
#   %convert_element_type_16 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0" = PlaceHolder[target=convert_element_type_16]
#   %arg12_1 : Tensor "f16[128, 64][64, 1]tnca:0" = PlaceHolder[target=arg12_1]
#   %view_20 : Tensor "f16[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_16, [1, 64]), kwargs = {})
#   %permute_11 : Tensor "f16[64, 128][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg12_1, [1, 0]), kwargs = {})
#   %mm_4 : Tensor "f16[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_20, %permute_11), kwargs = {})
#   return %mm_4
triton_tem_fused_mm_t_view_14 = async_compile.triton('triton_tem_fused_mm_t_view_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_14', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_14(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 128
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 64
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 128*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/3v/c3vbpfe5tewqoitni6z557vbi6el6yd4ojb7w2n2sgmmihu4mb6q.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
# Source node to ATen node mapping:
#   linear_4 => view_21
#   linear_5 => mm_5, permute_12, view_22, view_23
#   mul_4 => mul_10
#   silu => add_5, convert_element_type_19, convert_element_type_20, div_1, exp_1, neg_2
# Graph fragment:
#   %convert_element_type_16 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0" = PlaceHolder[target=convert_element_type_16]
#   %arg13_1 : Tensor "f16[128, 64][64, 1]tnca:0" = PlaceHolder[target=arg13_1]
#   %mm_4 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_4]
#   %mm_5 : Tensor "f16[1, 128][128, 1]tnca:0" = PlaceHolder[target=mm_5]
#   %view_21 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 1, 128]), kwargs = {})
#   %convert_element_type_19 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_21, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_19,), kwargs = {})
#   %exp_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_5 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_1, 1), kwargs = {})
#   %div_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_19, %add_5), kwargs = {})
#   %convert_element_type_20 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_1, torch.float16), kwargs = {})
#   %view_22 : Tensor "f16[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_16, [1, 64]), kwargs = {})
#   %permute_12 : Tensor "f16[64, 128][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg13_1, [1, 0]), kwargs = {})
#   %mm_5 : Tensor "f16[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_22, %permute_12), kwargs = {})
#   %view_23 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 1, 128]), kwargs = {})
#   %mul_10 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %view_23), kwargs = {})
#   return %mm_5,%mul_10
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15(arg_A, arg_B, in_ptr2, out_ptr1):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 128
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 64
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 128*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m
    tmp0 = acc.to(tl.float16)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.load(in_ptr2 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask).to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = -tmp3
    tmp5 = libdevice.exp(tmp4)
    tmp6 = tl.full([1], 1.0, tl.float32)
    tmp7 = tmp5 + tmp6
    tmp8 = (tmp3 / tmp7)
    tmp9 = tmp8.to(tl.float32)
    tmp10 = tmp9 * tmp1
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp10, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/dv/cdvar3ir7lhusqm4kb6zckp36ckuzziacveoyj73rrbcx3vrhsqp.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4, linear_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_4 => view_21
#   linear_5 => view_23
#   linear_6 => mm_6, permute_13, view_24
#   mul_4 => mul_10
#   silu => add_5, convert_element_type_19, convert_element_type_20, div_1, exp_1, neg_2
# Graph fragment:
#   %mul_10 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0" = PlaceHolder[target=mul_10]
#   %arg14_1 : Tensor "f16[64, 128][128, 1]tnca:0" = PlaceHolder[target=arg14_1]
#   %view_21 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 1, 128]), kwargs = {})
#   %convert_element_type_19 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_21, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_19,), kwargs = {})
#   %exp_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_5 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_1, 1), kwargs = {})
#   %div_1 : Tensor "f32[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_19, %add_5), kwargs = {})
#   %convert_element_type_20 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_1, torch.float16), kwargs = {})
#   %view_23 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_5, [1, 1, 128]), kwargs = {})
#   %mul_10 : Tensor "f16[1, 1, 128][128, 128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %view_23), kwargs = {})
#   %view_24 : Tensor "f16[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mul_10, [1, 128]), kwargs = {})
#   %permute_13 : Tensor "f16[128, 64][1, 128]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg14_1, [1, 0]), kwargs = {})
#   %mm_6 : Tensor "f16[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_24, %permute_13), kwargs = {})
#   return %mm_6
triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16 = async_compile.triton('triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 64
    K = 128
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 128

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 128*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 64*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 128*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 64*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/pr/cprjj3rgdfzxrbqdca46ig3n6gg6aejgd7cx4tbjiqn54jjxt5rl.py
# Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, rms_norm_2], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   linear_6 => view_25
#   rms_norm_2 => add_7, convert_element_type_25, convert_element_type_26, mean_2, mul_11, mul_12, pow_3, rsqrt_2
#   x => embedding
#   x_1 => add_3
#   x_2 => add_6
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[256, 64][64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %mm_6 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm_6]
#   %buf31 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf31]
#   %arg15_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg15_1]
#   %embedding : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 64]), kwargs = {})
#   %add_3 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %view_25 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 1, 64]), kwargs = {})
#   %add_6 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_3, %view_25), kwargs = {})
#   %convert_element_type_25 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_6, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_25, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [2], True), kwargs = {})
#   %add_7 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_2, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7,), kwargs = {})
#   %mul_11 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_25, %rsqrt_2), kwargs = {})
#   %mul_12 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_11, %arg15_1), kwargs = {})
#   %convert_element_type_26 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=3] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_12, torch.float16), kwargs = {})
#   return %buf31,%convert_element_type_26
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 640}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_ptr2, shape=[64], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr3, shape=[64], strides=[1], block_shape=[R0_BLOCK])
    _tmp11 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp6 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 256), "index out of bounds: 0 <= tmp1 < 256")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 64*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = triton_helpers.promote_to_tensor(tl.sum(_tmp11, 0))
    tmp13 = tl.load(in_ptr0 + (0))
    tmp14 = tl.broadcast_to(tmp13, [R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr2, shape=[64], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr3, shape=[64], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp17 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp19 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp28 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp14) & (tmp14 < 256), "index out of bounds: 0 <= tmp14 < 256")
        tmp16 = tl.load(in_ptr1 + (r0_0 + 64*tmp14), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp18 = tmp16 + tmp17
        tmp20 = tmp18 + tmp19
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tl.full([1], 64.0, tl.float32)
        tmp23 = (tmp11 / tmp22)
        tmp24 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp25 = tmp23 + tmp24
        tmp26 = libdevice.rsqrt(tmp25)
        tmp27 = tmp21 * tmp26
        tmp29 = tmp28.to(tl.float32)
        tmp30 = tmp27 * tmp29
        tmp31 = tmp30.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp31, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/6k/c6kvrv2udrj4mu4f4vk3amfybqwdmfiigqagy2bdkrbj4jhm5jg4.py
# Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_7 => mm_7, permute_14, view_26
# Graph fragment:
#   %convert_element_type_26 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0" = PlaceHolder[target=convert_element_type_26]
#   %arg16_1 : Tensor "f16[64, 64][64, 1]tnca:0" = PlaceHolder[target=arg16_1]
#   %view_26 : Tensor "f16[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_26, [1, 64]), kwargs = {})
#   %permute_14 : Tensor "f16[64, 64][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg16_1, [1, 0]), kwargs = {})
#   %mm_7 : Tensor "f16[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_26, %permute_14), kwargs = {})
#   return %mm_7
triton_tem_fused_mm_t_view_18 = async_compile.triton('triton_tem_fused_mm_t_view_18', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused_mm_t_view_18', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused_mm_t_view_18(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 64
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 64
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 64*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 64*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/tp/ctp63tzscltojdfl7u4g3potj7bn3zybnece6rvupowa2whvx532.py
# Topologically Sorted Source Nodes: [linear_8, view_4, k_4, getitem_8, mul_7, mul_8, k_5, k_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
# Source node to ATen node mapping:
#   getitem_8 => select_2
#   k_4 => permute_17
#   k_5 => add_9
#   k_6 => cat_6
#   linear_8 => view_30
#   mul_7 => mul_15
#   mul_8 => mul_16
#   view_4 => view_31
# Graph fragment:
#   %arg4_1 : Tensor "f16[2, 1, 2, 16, 16][512, 512, 256, 16, 1]tnca:0" = PlaceHolder[target=arg4_1]
#   %view_30 : Tensor "f16[1, 1, 32][32, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [1, 1, 32]), kwargs = {})
#   %view_31 : Tensor "f16[1, 1, 2, 16][32, 32, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_30, [1, 1, 2, 16]), kwargs = {})
#   %permute_17 : Tensor "f16[1, 2, 1, 16][32, 16, 32, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%view_31, [0, 2, 1, 3]), kwargs = {})
#   %select_2 : Tensor "f16[1, 2, 16, 16][512, 256, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%arg4_1, 0, 1), kwargs = {})
#   %mul_15 : Tensor "f16[1, 2, 1, 16][32, 16, 32, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_17, %arg2_1), kwargs = {})
#   %mul_16 : Tensor "f16[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_5, %arg3_1), kwargs = {})
#   %add_9 : Tensor "f16[1, 2, 1, 16][32, 16, 16, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_15, %mul_16), kwargs = {})
#   %cat_6 : Tensor "f16[1, 2, 17, 16][544, 272, 16, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%select_2, %add_9], 2), kwargs = {})
#   return %buf41
triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19 = async_compile.triton('triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3072}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 256)
    x1 = xindex // 256
    tmp0 = tl.load(in_ptr0 + (512 + x2), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x0 + 272*x1), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/ts/ctsb4etku3g26y2kuacqysdbjumv5ppc5saiykis7ommgknmv24v.py
# Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, h_1, x_3, y_1], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   h => view_19
#   h_1 => view_45
#   linear_6 => view_25
#   x => embedding
#   x_1 => add_3
#   x_2 => add_6
#   x_3 => add_10
#   y_1 => add_11, convert_element_type_40, convert_element_type_41, mean_3, mul_19, mul_20, pow_4, rsqrt_3
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "f16[256, 64][64, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %mm_3 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm_3]
#   %mm_6 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm_6]
#   %mm_10 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm_10]
#   %add_10 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0" = PlaceHolder[target=add_10]
#   %buf57 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf57]
#   %arg20_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg20_1]
#   %embedding : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %view_19 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 64]), kwargs = {})
#   %add_3 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_19), kwargs = {})
#   %view_25 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_6, [1, 1, 64]), kwargs = {})
#   %add_6 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_3, %view_25), kwargs = {})
#   %view_45 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_10, [1, 1, 64]), kwargs = {})
#   %add_10 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_6, %view_45), kwargs = {})
#   %convert_element_type_40 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_10, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_40, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [2], True), kwargs = {})
#   %add_11 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_3, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_11,), kwargs = {})
#   %mul_19 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_40, %rsqrt_3), kwargs = {})
#   %mul_20 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_19, %arg20_1), kwargs = {})
#   %convert_element_type_41 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_20, torch.float16), kwargs = {})
#   return %add_10,%buf57,%convert_element_type_41
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 6, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 1024}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [R0_BLOCK])
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[64], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr2, shape=[64], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor2 = tl.make_tensor_descriptor(in_ptr3, shape=[64], strides=[1], block_shape=[R0_BLOCK])
    _tmp13 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp6 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 256), "index out of bounds: 0 <= tmp1 < 256")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 64*tmp1), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp9 = tmp7 + tmp8
        tmp10 = tmp9.to(tl.float32)
        tmp11 = tmp10 * tmp10
        tmp12 = tl.broadcast_to(tmp11, [R0_BLOCK])
        tmp14 = _tmp13 + tmp12
        _tmp13 = tl.where(r0_mask, tmp14, _tmp13)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp9, r0_mask)
    tmp13 = triton_helpers.promote_to_tensor(tl.sum(_tmp13, 0))
    tma_descriptor3 = tl.make_tensor_descriptor(in_out_ptr0, shape=[64], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.debug_barrier()
        tmp15 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp23 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tl.full([1], 64.0, tl.float32)
        tmp18 = (tmp13 / tmp17)
        tmp19 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = libdevice.rsqrt(tmp20)
        tmp22 = tmp16 * tmp21
        tmp24 = tmp23.to(tl.float32)
        tmp25 = tmp22 * tmp24
        tmp26 = tmp25.to(tl.float32)
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp26, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/r5/cr5cdpucij473puhq65kklbnkv365nkt5sijk5kxof4awfrgcwzg.py
# Topologically Sorted Source Nodes: [y_1, linear_11], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_11 => mm_11, permute_25, view_46
#   y_1 => add_11, convert_element_type_40, convert_element_type_41, mean_3, mul_19, mul_20, pow_4, rsqrt_3
# Graph fragment:
#   %convert_element_type_41 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0" = PlaceHolder[target=convert_element_type_41]
#   %arg21_1 : Tensor "f16[128, 64][64, 1]tnca:0" = PlaceHolder[target=arg21_1]
#   %convert_element_type_40 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_10, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_40, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [2], True), kwargs = {})
#   %add_11 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_3, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_11,), kwargs = {})
#   %mul_19 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_40, %rsqrt_3), kwargs = {})
#   %mul_20 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_19, %arg20_1), kwargs = {})
#   %convert_element_type_41 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_20, torch.float16), kwargs = {})
#   %view_46 : Tensor "f16[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_41, [1, 64]), kwargs = {})
#   %permute_25 : Tensor "f16[64, 128][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg21_1, [1, 0]), kwargs = {})
#   %mm_11 : Tensor "f16[1, 128][128, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_46, %permute_25), kwargs = {})
#   return %mm_11
triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21 = async_compile.triton('triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 128
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 128*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 128*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/uk/cukmubhwkcrwu3clj5rv2yorbhaxgjcycezk32zkuhmwwsa7yq4v.py
# Topologically Sorted Source Nodes: [linear_13, x_4, rms_norm_4], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   linear_13 => view_51
#   rms_norm_4 => add_14, convert_element_type_50, convert_element_type_51, mean_4, mul_22, mul_23, pow_5, rsqrt_4
#   x_4 => add_13
# Graph fragment:
#   %add_10 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0" = PlaceHolder[target=add_10]
#   %mm_13 : Tensor "f16[1, 64][64, 1]tnca:0" = PlaceHolder[target=mm_13]
#   %buf63 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0" = PlaceHolder[target=buf63]
#   %arg24_1 : Tensor "f16[64][1]tnca:0" = PlaceHolder[target=arg24_1]
#   %view_51 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 1, 64]), kwargs = {})
#   %add_13 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %view_51), kwargs = {})
#   %convert_element_type_50 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_13, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_50, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [2], True), kwargs = {})
#   %add_14 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_4, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_14,), kwargs = {})
#   %mul_22 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_50, %rsqrt_4), kwargs = {})
#   %mul_23 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_22, %arg24_1), kwargs = {})
#   %convert_element_type_51 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_23, torch.float16), kwargs = {})
#   return %buf63,%convert_element_type_51
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 64},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': True, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 640}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'R0_BLOCK': 8}, 'uses_tma': True, 'uses_device_tma': True}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, R0_BLOCK : tl.constexpr):
    xnumel = 1
    XBLOCK: tl.constexpr = 1
    r0_numel = 64
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = tl.full([1], xoffset, tl.int32)
    xmask = tl.full([R0_BLOCK], True, tl.int1)
    r0_base = tl.arange(0, R0_BLOCK)[:]
    rbase = r0_base
    tma_descriptor0 = tl.make_tensor_descriptor(in_out_ptr0, shape=[64], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor1 = tl.make_tensor_descriptor(in_ptr0, shape=[64], strides=[1], block_shape=[R0_BLOCK])
    _tmp6 = tl.full([R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor0.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp1 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor1.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = triton_helpers.promote_to_tensor(tl.sum(_tmp6, 0))
    tma_descriptor2 = tl.make_tensor_descriptor(in_out_ptr0, shape=[64], strides=[1], block_shape=[R0_BLOCK])
    tma_descriptor3 = tl.make_tensor_descriptor(in_ptr0, shape=[64], strides=[1], block_shape=[R0_BLOCK])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor2.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp9 = tl.reshape(tl.trans(tl.broadcast_to(tma_descriptor3.load([r0_offset])[:, None], [R0_BLOCK, XBLOCK]), [1, 0]), [R0_BLOCK]).to(tl.float32)
        tmp18 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tmp8 + tmp9
        tmp11 = tmp10.to(tl.float32)
        tmp12 = tl.full([1], 64.0, tl.float32)
        tmp13 = (tmp6 / tmp12)
        tmp14 = tl.full([1], 9.999999747378752e-06, tl.float32)
        tmp15 = tmp13 + tmp14
        tmp16 = libdevice.rsqrt(tmp15)
        tmp17 = tmp11 * tmp16
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp17 * tmp19
        tmp21 = tmp20.to(tl.float32)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [R0_BLOCK])), tmp21, r0_mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.llama_decode__tiny__fp16-b1-p16/inductor_cache/gg/cggp4btjm5l7vlmdrfj54wu52z6mxa53lfa2xochs56wx7kn5fi5.py
# Topologically Sorted Source Nodes: [linear_13, x_4, rms_norm_4, linear_14], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_13 => view_51
#   linear_14 => mm_14, permute_28, view_52
#   rms_norm_4 => add_14, convert_element_type_50, convert_element_type_51, mean_4, mul_22, mul_23, pow_5, rsqrt_4
#   x_4 => add_13
# Graph fragment:
#   %convert_element_type_51 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0" = PlaceHolder[target=convert_element_type_51]
#   %arg25_1 : Tensor "f16[256, 64][64, 1]tnca:0" = PlaceHolder[target=arg25_1]
#   %view_51 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_13, [1, 1, 64]), kwargs = {})
#   %add_13 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %view_51), kwargs = {})
#   %convert_element_type_50 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_13, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_50, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [2], True), kwargs = {})
#   %add_14 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Scalar](args = (%mean_4, 9.999999747378752e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_14,), kwargs = {})
#   %mul_22 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_50, %rsqrt_4), kwargs = {})
#   %mul_23 : Tensor "f32[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_22, %arg24_1), kwargs = {})
#   %convert_element_type_51 : Tensor "f16[1, 1, 64][64, 64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_23, torch.float16), kwargs = {})
#   %view_52 : Tensor "f16[1, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_51, [1, 64]), kwargs = {})
#   %permute_28 : Tensor "f16[64, 256][1, 64]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg25_1, [1, 0]), kwargs = {})
#   %mm_14 : Tensor "f16[1, 256][256, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_52, %permute_28), kwargs = {})
#   return %mm_14
triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_23 = async_compile.triton('triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_23', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp16', 'arg_B': '*fp16', 'out_ptr0': '*fp16'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_23', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16, 'GROUP_M': 1, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_23(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    GROUP_M : tl.constexpr = 1
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 1
    N = 256
    K = 64
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 0
    stride_ak = 1
    stride_bk = 1
    stride_bn = 64

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K).to(INDEX_DTYPE)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 64*idx_m
        a = tl.load(A + ((tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_K])).broadcast_to(xindex.shape)))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 256*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 64*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M).to(INDEX_DTYPE)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N).to(INDEX_DTYPE)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 256*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(idx_n, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1 = args
        args.clear()
        assert_size_stride_grouped((arg1_1, arg0_1, arg6_1), ((1, 1), (256, 64), (64, )), ((1, 1), (64, 1), (1, )), 'input')
        buf1 = empty_strided((1, 1, 64), (64, 64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [x, rms_norm], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0.run(arg1_1, arg0_1, arg6_1, buf1, 1, 64, stream=raw_stream0)
        del arg6_1
        assert_size_stride(arg7_1, (64, 64), (64, 1), 'input')
        buf2 = empty_strided((1, 64), (64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [x, rms_norm, linear], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf1, arg7_1, buf2, 4, 1, 1, stream=raw_stream0)
        del arg7_1
        assert_size_stride(arg8_1, (32, 64), (64, 1), 'input')
        buf3 = empty_strided((1, 32), (32, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf1, arg8_1, buf3, 2, 1, 1, stream=raw_stream0)
        del arg8_1
        buf6 = empty_strided((1, 4, 1, 16), (64, 16, 16, 1), device='tnca', dtype=torch.float16)
        buf4 = reinterpret_tensor(buf6, (1, 4, 1, 8), (64, 16, 16, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear, view, q, chunk, neg], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf2, buf4, 32, stream=raw_stream0)
        buf5 = reinterpret_tensor(buf6, (1, 4, 1, 8), (64, 16, 16, 1), 8)  # alias
        # Topologically Sorted Source Nodes: [linear, view, q, chunk, neg, cat], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf2, buf5, 32, stream=raw_stream0)
        buf9 = empty_strided((1, 2, 1, 16), (32, 16, 16, 1), device='tnca', dtype=torch.float16)
        buf7 = reinterpret_tensor(buf9, (1, 2, 1, 8), (32, 16, 16, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf3, buf7, 16, stream=raw_stream0)
        del buf4
        del buf5
        buf8 = reinterpret_tensor(buf9, (1, 2, 1, 8), (32, 16, 16, 1), 8)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, chunk_1, neg_1, cat_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf3, buf8, 16, stream=raw_stream0)
        assert_size_stride(arg4_1, (2, 1, 2, 16, 16), (512, 512, 256, 16, 1), 'input')
        buf12 = empty_strided((1, 2, 17, 16), (544, 272, 16, 1), device='tnca', dtype=torch.float16)
        buf10 = reinterpret_tensor(buf12, (1, 2, 16, 16), (544, 272, 16, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, getitem, mul_2, mul_3, k_1, k_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7.run(arg4_1, buf10, 512, stream=raw_stream0)
        del buf7
        del buf8
        assert_size_stride_grouped((arg2_1, arg3_1), ((1, 16), (1, 16)), ((16, 1), (16, 1)), 'input')
        buf11 = reinterpret_tensor(buf12, (1, 2, 1, 16), (544, 272, 16, 1), 256)  # alias
        buf68 = empty_strided((2, 2, 1, 16), (32, 16, 16, 1), device='tnca', dtype=torch.float16)
        buf66 = reinterpret_tensor(buf68, (1, 2, 1, 16), (32, 16, 16, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_1, view_1, k, mul_2, mul_3, k_1, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf3, arg2_1, buf9, arg3_1, buf11, buf66, 32, stream=raw_stream0)
        buf13 = empty_strided((4, 1, 17), (17, 17, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear, view, q, mul, mul_1, q_1, o, getitem_6, expand, k_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf2, arg2_1, buf6, arg3_1, buf12, buf13, 68, 16, stream=raw_stream0)
        del buf10
        del buf11
        buf14 = empty_strided((1, 4, 1, 1), (4, 1, 4, 4), device='tnca', dtype=torch.bool)
        buf16 = empty_strided((1, 4, 1, 17), (68, 17, 68, 1), device='tnca', dtype=torch.float32)
        buf17 = empty_strided((1, 4, 1, 1), (4, 1, 4, 4), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [o], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf13, buf14, buf16, buf17, 4, 17, stream=raw_stream0)
        del buf13
        assert_size_stride(arg9_1, (32, 64), (64, 1), 'input')
        buf18 = reinterpret_tensor(buf9, (1, 32), (32, 1), 0); del buf9  # reuse
        # Topologically Sorted Source Nodes: [linear_2], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf1, arg9_1, buf18, 2, 1, 1, stream=raw_stream0)
        del arg9_1
        assert_size_stride(arg5_1, (2, 1, 2, 16, 16), (512, 512, 256, 16, 1), 'input')
        buf21 = buf12; del buf12  # reuse
        buf19 = reinterpret_tensor(buf21, (1, 2, 16, 16), (544, 272, 16, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_1, linear_2, view_2, v, v_1], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_7.run(arg5_1, buf19, 512, stream=raw_stream0)
        buf20 = reinterpret_tensor(buf21, (1, 2, 1, 16), (544, 272, 16, 1), 256)  # alias
        buf71 = reinterpret_tensor(buf1, (2, 2, 1, 16), (32, 16, 16, 1), 0); del buf1  # reuse
        buf69 = reinterpret_tensor(buf71, (1, 2, 1, 16), (32, 16, 16, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_1, linear_2, view_2, v, v_1, linear_9, view_5, v_3, stack_1], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_11.run(buf18, buf20, buf69, 32, stream=raw_stream0)
        buf23 = buf6; del buf6  # reuse
        # Topologically Sorted Source Nodes: [o, getitem_7, expand_1, v_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf14, buf16, buf17, buf21, buf23, 64, 17, stream=raw_stream0)
        del buf14
        del buf16
        del buf17
        del buf19
        del buf20
        assert_size_stride(arg10_1, (64, 64), (64, 1), 'input')
        buf24 = buf2; del buf2  # reuse
        # Topologically Sorted Source Nodes: [o, transpose_3, o_1, h], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf23, arg10_1, buf24, 4, 1, 1, stream=raw_stream0)
        del arg10_1
        assert_size_stride(arg11_1, (64, ), (1, ), 'input')
        buf26 = reinterpret_tensor(buf23, (1, 1, 64), (64, 64, 1), 0); del buf23  # reuse
        # Topologically Sorted Source Nodes: [x, h, x_1, y], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_13.run(arg1_1, arg0_1, buf24, arg11_1, buf26, 1, 64, stream=raw_stream0)
        del arg11_1
        assert_size_stride(arg12_1, (128, 64), (64, 1), 'input')
        buf27 = empty_strided((1, 128), (128, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_14.run(buf26, arg12_1, buf27, 8, 1, 1, stream=raw_stream0)
        del arg12_1
        assert_size_stride(arg13_1, (128, 64), (64, 1), 'input')
        buf29 = empty_strided((1, 1, 128), (128, 128, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf26, arg13_1, buf27, buf29, 8, 1, 1, stream=raw_stream0)
        del arg13_1
        del buf27
        assert_size_stride(arg14_1, (64, 128), (128, 1), 'input')
        buf30 = reinterpret_tensor(buf26, (1, 64), (64, 1), 0); del buf26  # reuse
        # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_4, linear_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf29, arg14_1, buf30, 4, 1, 1, stream=raw_stream0)
        del arg14_1
        del buf29
        assert_size_stride(arg15_1, (64, ), (1, ), 'input')
        buf32 = empty_strided((1, 1, 64), (64, 64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, rms_norm_2], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_17.run(arg1_1, arg0_1, buf24, buf30, arg15_1, buf32, 1, 64, stream=raw_stream0)
        del arg15_1
        assert_size_stride(arg16_1, (64, 64), (64, 1), 'input')
        buf33 = empty_strided((1, 64), (64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_18.run(buf32, arg16_1, buf33, 4, 1, 1, stream=raw_stream0)
        del arg16_1
        assert_size_stride(arg17_1, (32, 64), (64, 1), 'input')
        buf34 = buf18; del buf18  # reuse
        # Topologically Sorted Source Nodes: [linear_8], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf32, arg17_1, buf34, 2, 1, 1, stream=raw_stream0)
        del arg17_1
        buf37 = empty_strided((1, 4, 1, 16), (64, 16, 16, 1), device='tnca', dtype=torch.float16)
        buf35 = reinterpret_tensor(buf37, (1, 4, 1, 8), (64, 16, 16, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, chunk_2, neg_2], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_3.run(buf33, buf35, 32, stream=raw_stream0)
        buf36 = reinterpret_tensor(buf37, (1, 4, 1, 8), (64, 16, 16, 1), 8)  # alias
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, chunk_2, neg_2, cat_4], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_4.run(buf33, buf36, 32, stream=raw_stream0)
        buf40 = reinterpret_tensor(buf3, (1, 2, 1, 16), (32, 16, 16, 1), 0); del buf3  # reuse
        buf38 = reinterpret_tensor(buf40, (1, 2, 1, 8), (32, 16, 16, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_4, chunk_3, neg_3], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_neg_split_transpose_view_5.run(buf34, buf38, 16, stream=raw_stream0)
        del buf35
        del buf36
        buf39 = reinterpret_tensor(buf40, (1, 2, 1, 8), (32, 16, 16, 1), 8)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_4, chunk_3, neg_3, cat_5], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.split, aten.neg, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_neg_split_transpose_view_6.run(buf34, buf39, 16, stream=raw_stream0)
        buf43 = buf21; del buf21  # reuse
        buf41 = reinterpret_tensor(buf43, (1, 2, 16, 16), (544, 272, 16, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_4, getitem_8, mul_7, mul_8, k_5, k_6], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.mul, aten.add, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19.run(arg4_1, buf41, 512, stream=raw_stream0)
        del arg4_1
        del buf38
        del buf39
        buf42 = reinterpret_tensor(buf43, (1, 2, 1, 16), (544, 272, 16, 1), 256)  # alias
        buf67 = reinterpret_tensor(buf68, (1, 2, 1, 16), (32, 16, 16, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_8, view_4, k_4, mul_7, mul_8, k_5, stack], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_mul_stack_transpose_view_8.run(buf34, arg2_1, buf40, arg3_1, buf42, buf67, 32, stream=raw_stream0)
        del buf34
        del buf40
        buf44 = empty_strided((4, 1, 17), (17, 17, 1), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [linear_7, view_3, q_2, mul_5, mul_6, q_3, o_2, getitem_14, expand_2, k_7], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.mul, aten.add, aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_add_clone_expand_mul_transpose_unsqueeze_view_9.run(buf33, arg2_1, buf37, arg3_1, buf43, buf44, 68, 16, stream=raw_stream0)
        del arg2_1
        del arg3_1
        del buf33
        del buf37
        del buf41
        del buf42
        buf45 = empty_strided((1, 4, 1, 1), (4, 1, 4, 4), device='tnca', dtype=torch.bool)
        buf47 = empty_strided((1, 4, 1, 17), (68, 17, 68, 1), device='tnca', dtype=torch.float32)
        buf48 = empty_strided((1, 4, 1, 1), (4, 1, 4, 4), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [o_2], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu_10.run(buf44, buf45, buf47, buf48, 4, 17, stream=raw_stream0)
        del buf44
        assert_size_stride(arg18_1, (32, 64), (64, 1), 'input')
        buf49 = empty_strided((1, 32), (32, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_9], Original ATen: [aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused_mm_t_view_2.run(buf32, arg18_1, buf49, 2, 1, 1, stream=raw_stream0)
        del arg18_1
        del buf32
        buf52 = buf43; del buf43  # reuse
        buf50 = reinterpret_tensor(buf52, (1, 2, 16, 16), (544, 272, 16, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem_9, linear_9, view_5, v_3, v_4], Original ATen: [aten.select, aten._unsafe_view, aten.view, aten.transpose, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_add_cat_mul_select_transpose_view_19.run(arg5_1, buf50, 512, stream=raw_stream0)
        del arg5_1
        buf51 = reinterpret_tensor(buf52, (1, 2, 1, 16), (544, 272, 16, 1), 256)  # alias
        buf70 = reinterpret_tensor(buf71, (1, 2, 1, 16), (32, 16, 16, 1), 32)  # alias
        # Topologically Sorted Source Nodes: [linear_2, view_2, v, getitem_9, linear_9, view_5, v_3, v_4, stack_1], Original ATen: [aten._unsafe_view, aten.view, aten.transpose, aten.select, aten.cat, aten.stack]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_cat_select_stack_transpose_view_11.run(buf49, buf51, buf70, 32, stream=raw_stream0)
        del buf49
        buf54 = empty_strided((1, 4, 1, 16), (64, 16, 16, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [o_2, getitem_15, expand_3, v_5], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.unsqueeze, aten.expand, aten.clone, aten._unsafe_view]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__scaled_dot_product_flash_attention_for_cpu__unsafe_view_clone_expand_unsqueeze_12.run(buf45, buf47, buf48, buf52, buf54, 64, 17, stream=raw_stream0)
        del buf45
        del buf47
        del buf48
        del buf50
        del buf51
        del buf52
        assert_size_stride(arg19_1, (64, 64), (64, 1), 'input')
        buf55 = empty_strided((1, 64), (64, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [o_2, transpose_7, o_3, h_1], Original ATen: [aten._scaled_dot_product_flash_attention_for_cpu, aten.transpose, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_embedding_mean_mm_mul_pow_rsqrt_t_view_1.run(buf54, arg19_1, buf55, 4, 1, 1, stream=raw_stream0)
        del arg19_1
        assert_size_stride(arg20_1, (64, ), (1, ), 'input')
        buf56 = reinterpret_tensor(buf24, (1, 1, 64), (64, 64, 1), 0); del buf24  # reuse
        buf58 = reinterpret_tensor(buf54, (1, 1, 64), (64, 64, 1), 0); del buf54  # reuse
        # Topologically Sorted Source Nodes: [x, h, x_1, linear_6, x_2, h_1, x_3, y_1], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_20.run(buf56, arg1_1, arg0_1, buf30, buf55, arg20_1, buf58, 1, 64, stream=raw_stream0)
        del arg0_1
        del arg1_1
        del arg20_1
        del buf30
        del buf55
        assert_size_stride(arg21_1, (128, 64), (64, 1), 'input')
        buf59 = empty_strided((1, 128), (128, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [y_1, linear_11], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_21.run(buf58, arg21_1, buf59, 8, 1, 1, stream=raw_stream0)
        del arg21_1
        assert_size_stride(arg22_1, (128, 64), (64, 1), 'input')
        buf61 = empty_strided((1, 1, 128), (128, 128, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_9], Original ATen: [aten._unsafe_view, aten.silu, aten.view, aten.t, aten.mm, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_15.run(buf58, arg22_1, buf59, buf61, 8, 1, 1, stream=raw_stream0)
        del arg22_1
        del buf59
        assert_size_stride(arg23_1, (64, 128), (128, 1), 'input')
        buf62 = reinterpret_tensor(buf58, (1, 64), (64, 1), 0); del buf58  # reuse
        # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_9, linear_13], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__unsafe_view_mm_mul_silu_t_view_16.run(buf61, arg23_1, buf62, 4, 1, 1, stream=raw_stream0)
        del arg23_1
        del buf61
        assert_size_stride(arg24_1, (64, ), (1, ), 'input')
        buf64 = buf56; del buf56  # reuse
        # Topologically Sorted Source Nodes: [linear_13, x_4, rms_norm_4], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_22.run(buf64, buf62, arg24_1, 1, 64, stream=raw_stream0)
        del arg24_1
        del buf62
        assert_size_stride(arg25_1, (256, 64), (64, 1), 'input')
        buf65 = empty_strided((1, 256), (256, 1), device='tnca', dtype=torch.float16)
        # Topologically Sorted Source Nodes: [linear_13, x_4, rms_norm_4, linear_14], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__to_copy__unsafe_view_add_mean_mm_mul_pow_rsqrt_t_view_23.run(buf64, arg25_1, buf65, 16, 1, 1, stream=raw_stream0)
        del arg25_1
        del buf64
        return (reinterpret_tensor(buf65, (1, 1, 256), (256, 256, 1), 0), reinterpret_tensor(buf68, (2, 1, 2, 1, 16), (32, 32, 16, 16, 1), 0), reinterpret_tensor(buf71, (2, 1, 2, 1, 16), (32, 32, 16, 16, 1), 0), )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((256, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg1_1 = rand_strided((1, 1), (1, 1), device='tnca:0', dtype=torch.int64)
    arg2_1 = rand_strided((1, 16), (16, 1), device='tnca:0', dtype=torch.float16)
    arg3_1 = rand_strided((1, 16), (16, 1), device='tnca:0', dtype=torch.float16)
    arg4_1 = rand_strided((2, 1, 2, 16, 16), (512, 512, 256, 16, 1), device='tnca:0', dtype=torch.float16)
    arg5_1 = rand_strided((2, 1, 2, 16, 16), (512, 512, 256, 16, 1), device='tnca:0', dtype=torch.float16)
    arg6_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg7_1 = rand_strided((64, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg8_1 = rand_strided((32, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg9_1 = rand_strided((32, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg10_1 = rand_strided((64, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg11_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg12_1 = rand_strided((128, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg13_1 = rand_strided((128, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg14_1 = rand_strided((64, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg15_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg16_1 = rand_strided((64, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg17_1 = rand_strided((32, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg18_1 = rand_strided((32, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg19_1 = rand_strided((64, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg20_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg21_1 = rand_strided((128, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg22_1 = rand_strided((128, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    arg23_1 = rand_strided((64, 128), (128, 1), device='tnca:0', dtype=torch.float16)
    arg24_1 = rand_strided((64, ), (1, ), device='tnca:0', dtype=torch.float16)
    arg25_1 = rand_strided((256, 64), (64, 1), device='tnca:0', dtype=torch.float16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
