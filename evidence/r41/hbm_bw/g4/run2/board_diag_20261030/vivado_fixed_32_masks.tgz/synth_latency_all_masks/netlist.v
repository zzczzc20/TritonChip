// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2023.2 (lin64) Build 4029153 Fri Oct 13 20:13:54 MDT 2023
// Date        : Fri Oct 30 18:15:29 2026
// Host        : acf3019 running 64-bit Ubuntu 22.04.5 LTS
// Command     : write_verilog -force netlist.v
// Design      : latency_probe
// Purpose     : This is a Verilog netlist of the current design or from a specific cell of the design. The output is an
//               IEEE 1364-2001 compliant Verilog HDL file that contains netlist information obtained from the input
//               design files.
// Device      : xcu280-fsvh2892-2L-e
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* STRUCTURAL_NETLIST = "yes" *)
module latency_probe
   (result);
  output [95:0]result;

  wire \<const0> ;
  wire \<const1> ;
  wire [95:0]result;

  GND GND
       (.G(\<const0> ));
  VCC VCC
       (.P(\<const1> ));
  OBUF \result_OBUF[0]_inst 
       (.I(\<const0> ),
        .O(result[0]));
  OBUF \result_OBUF[10]_inst 
       (.I(\<const1> ),
        .O(result[10]));
  OBUF \result_OBUF[11]_inst 
       (.I(\<const0> ),
        .O(result[11]));
  OBUF \result_OBUF[12]_inst 
       (.I(\<const1> ),
        .O(result[12]));
  OBUF \result_OBUF[13]_inst 
       (.I(\<const0> ),
        .O(result[13]));
  OBUF \result_OBUF[14]_inst 
       (.I(\<const0> ),
        .O(result[14]));
  OBUF \result_OBUF[15]_inst 
       (.I(\<const0> ),
        .O(result[15]));
  OBUF \result_OBUF[16]_inst 
       (.I(\<const1> ),
        .O(result[16]));
  OBUF \result_OBUF[17]_inst 
       (.I(\<const0> ),
        .O(result[17]));
  OBUF \result_OBUF[18]_inst 
       (.I(\<const0> ),
        .O(result[18]));
  OBUF \result_OBUF[19]_inst 
       (.I(\<const1> ),
        .O(result[19]));
  OBUF \result_OBUF[1]_inst 
       (.I(\<const0> ),
        .O(result[1]));
  OBUF \result_OBUF[20]_inst 
       (.I(\<const0> ),
        .O(result[20]));
  OBUF \result_OBUF[21]_inst 
       (.I(\<const1> ),
        .O(result[21]));
  OBUF \result_OBUF[22]_inst 
       (.I(\<const1> ),
        .O(result[22]));
  OBUF \result_OBUF[23]_inst 
       (.I(\<const0> ),
        .O(result[23]));
  OBUF \result_OBUF[24]_inst 
       (.I(\<const1> ),
        .O(result[24]));
  OBUF \result_OBUF[25]_inst 
       (.I(\<const0> ),
        .O(result[25]));
  OBUF \result_OBUF[26]_inst 
       (.I(\<const0> ),
        .O(result[26]));
  OBUF \result_OBUF[27]_inst 
       (.I(\<const0> ),
        .O(result[27]));
  OBUF \result_OBUF[28]_inst 
       (.I(\<const1> ),
        .O(result[28]));
  OBUF \result_OBUF[29]_inst 
       (.I(\<const0> ),
        .O(result[29]));
  OBUF \result_OBUF[2]_inst 
       (.I(\<const0> ),
        .O(result[2]));
  OBUF \result_OBUF[30]_inst 
       (.I(\<const0> ),
        .O(result[30]));
  OBUF \result_OBUF[31]_inst 
       (.I(\<const1> ),
        .O(result[31]));
  OBUF \result_OBUF[32]_inst 
       (.I(\<const0> ),
        .O(result[32]));
  OBUF \result_OBUF[33]_inst 
       (.I(\<const1> ),
        .O(result[33]));
  OBUF \result_OBUF[34]_inst 
       (.I(\<const1> ),
        .O(result[34]));
  OBUF \result_OBUF[35]_inst 
       (.I(\<const0> ),
        .O(result[35]));
  OBUF \result_OBUF[36]_inst 
       (.I(\<const0> ),
        .O(result[36]));
  OBUF \result_OBUF[37]_inst 
       (.I(\<const1> ),
        .O(result[37]));
  OBUF \result_OBUF[38]_inst 
       (.I(\<const0> ),
        .O(result[38]));
  OBUF \result_OBUF[39]_inst 
       (.I(\<const1> ),
        .O(result[39]));
  OBUF \result_OBUF[3]_inst 
       (.I(\<const1> ),
        .O(result[3]));
  OBUF \result_OBUF[40]_inst 
       (.I(\<const1> ),
        .O(result[40]));
  OBUF \result_OBUF[41]_inst 
       (.I(\<const0> ),
        .O(result[41]));
  OBUF \result_OBUF[42]_inst 
       (.I(\<const1> ),
        .O(result[42]));
  OBUF \result_OBUF[43]_inst 
       (.I(\<const1> ),
        .O(result[43]));
  OBUF \result_OBUF[44]_inst 
       (.I(\<const0> ),
        .O(result[44]));
  OBUF \result_OBUF[45]_inst 
       (.I(\<const0> ),
        .O(result[45]));
  OBUF \result_OBUF[46]_inst 
       (.I(\<const0> ),
        .O(result[46]));
  OBUF \result_OBUF[47]_inst 
       (.I(\<const1> ),
        .O(result[47]));
  OBUF \result_OBUF[48]_inst 
       (.I(\<const1> ),
        .O(result[48]));
  OBUF \result_OBUF[49]_inst 
       (.I(\<const0> ),
        .O(result[49]));
  OBUF \result_OBUF[4]_inst 
       (.I(\<const0> ),
        .O(result[4]));
  OBUF \result_OBUF[50]_inst 
       (.I(\<const0> ),
        .O(result[50]));
  OBUF \result_OBUF[51]_inst 
       (.I(\<const0> ),
        .O(result[51]));
  OBUF \result_OBUF[52]_inst 
       (.I(\<const1> ),
        .O(result[52]));
  OBUF \result_OBUF[53]_inst 
       (.I(\<const0> ),
        .O(result[53]));
  OBUF \result_OBUF[54]_inst 
       (.I(\<const0> ),
        .O(result[54]));
  OBUF \result_OBUF[55]_inst 
       (.I(\<const1> ),
        .O(result[55]));
  OBUF \result_OBUF[56]_inst 
       (.I(\<const0> ),
        .O(result[56]));
  OBUF \result_OBUF[57]_inst 
       (.I(\<const1> ),
        .O(result[57]));
  OBUF \result_OBUF[58]_inst 
       (.I(\<const1> ),
        .O(result[58]));
  OBUF \result_OBUF[59]_inst 
       (.I(\<const0> ),
        .O(result[59]));
  OBUF \result_OBUF[5]_inst 
       (.I(\<const0> ),
        .O(result[5]));
  OBUF \result_OBUF[60]_inst 
       (.I(\<const0> ),
        .O(result[60]));
  OBUF \result_OBUF[61]_inst 
       (.I(\<const1> ),
        .O(result[61]));
  OBUF \result_OBUF[62]_inst 
       (.I(\<const0> ),
        .O(result[62]));
  OBUF \result_OBUF[63]_inst 
       (.I(\<const1> ),
        .O(result[63]));
  OBUF \result_OBUF[64]_inst 
       (.I(\<const1> ),
        .O(result[64]));
  OBUF \result_OBUF[65]_inst 
       (.I(\<const0> ),
        .O(result[65]));
  OBUF \result_OBUF[66]_inst 
       (.I(\<const1> ),
        .O(result[66]));
  OBUF \result_OBUF[67]_inst 
       (.I(\<const1> ),
        .O(result[67]));
  OBUF \result_OBUF[68]_inst 
       (.I(\<const0> ),
        .O(result[68]));
  OBUF \result_OBUF[69]_inst 
       (.I(\<const0> ),
        .O(result[69]));
  OBUF \result_OBUF[6]_inst 
       (.I(\<const1> ),
        .O(result[6]));
  OBUF \result_OBUF[70]_inst 
       (.I(\<const0> ),
        .O(result[70]));
  OBUF \result_OBUF[71]_inst 
       (.I(\<const1> ),
        .O(result[71]));
  OBUF \result_OBUF[72]_inst 
       (.I(\<const0> ),
        .O(result[72]));
  OBUF \result_OBUF[73]_inst 
       (.I(\<const1> ),
        .O(result[73]));
  OBUF \result_OBUF[74]_inst 
       (.I(\<const0> ),
        .O(result[74]));
  OBUF \result_OBUF[75]_inst 
       (.I(\<const1> ),
        .O(result[75]));
  OBUF \result_OBUF[76]_inst 
       (.I(\<const1> ),
        .O(result[76]));
  OBUF \result_OBUF[77]_inst 
       (.I(\<const0> ),
        .O(result[77]));
  OBUF \result_OBUF[78]_inst 
       (.I(\<const1> ),
        .O(result[78]));
  OBUF \result_OBUF[79]_inst 
       (.I(\<const1> ),
        .O(result[79]));
  OBUF \result_OBUF[7]_inst 
       (.I(\<const0> ),
        .O(result[7]));
  OBUF \result_OBUF[80]_inst 
       (.I(\<const0> ),
        .O(result[80]));
  OBUF \result_OBUF[81]_inst 
       (.I(\<const0> ),
        .O(result[81]));
  OBUF \result_OBUF[82]_inst 
       (.I(\<const0> ),
        .O(result[82]));
  OBUF \result_OBUF[83]_inst 
       (.I(\<const1> ),
        .O(result[83]));
  OBUF \result_OBUF[84]_inst 
       (.I(\<const1> ),
        .O(result[84]));
  OBUF \result_OBUF[85]_inst 
       (.I(\<const1> ),
        .O(result[85]));
  OBUF \result_OBUF[86]_inst 
       (.I(\<const0> ),
        .O(result[86]));
  OBUF \result_OBUF[87]_inst 
       (.I(\<const0> ),
        .O(result[87]));
  OBUF \result_OBUF[88]_inst 
       (.I(\<const0> ),
        .O(result[88]));
  OBUF \result_OBUF[89]_inst 
       (.I(\<const1> ),
        .O(result[89]));
  OBUF \result_OBUF[8]_inst 
       (.I(\<const0> ),
        .O(result[8]));
  OBUF \result_OBUF[90]_inst 
       (.I(\<const0> ),
        .O(result[90]));
  OBUF \result_OBUF[91]_inst 
       (.I(\<const0> ),
        .O(result[91]));
  OBUF \result_OBUF[92]_inst 
       (.I(\<const1> ),
        .O(result[92]));
  OBUF \result_OBUF[93]_inst 
       (.I(\<const1> ),
        .O(result[93]));
  OBUF \result_OBUF[94]_inst 
       (.I(\<const0> ),
        .O(result[94]));
  OBUF \result_OBUF[95]_inst 
       (.I(\<const1> ),
        .O(result[95]));
  OBUF \result_OBUF[9]_inst 
       (.I(\<const0> ),
        .O(result[9]));
endmodule
