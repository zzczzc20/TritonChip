#!/bin/bash
source ~/tc_env/env.sh
cd /tmp/r40_pipeline_control13 || exit 2
export PYTHONPATH="$PWD/python:$PWD/compiler/python:$PWD/tools/asm"
CUDA_VISIBLE_DEVICES='' TNCA_PIPELINE=1 "$HOME/tc_env/torchenv/bin/python" tools/r39/rctx_roles_tests.py --only gemm_one_step gemm_odd_steps gemm_grid_3x2 gemm_carried_pointers --json /tmp/r40_pipeline_control14_native.json > /tmp/r40_pipeline_control14_native.log 2>&1
rc=$?
printf '%s
' "$rc" > /tmp/r40_pipeline_control14_native.exit
exit "$rc"
