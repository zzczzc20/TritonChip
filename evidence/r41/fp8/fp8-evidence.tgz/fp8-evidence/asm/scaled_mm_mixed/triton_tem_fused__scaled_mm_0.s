    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #1
    s.movz       s2, #0
    s.sub        s3, s1, s4
    s.movz       s5, #0
    s.min.s      s6, s3, s1
    s.movz       s3, #0
    s.cmp.lt     s7, s6, s2
    s.movz       s2, #0
    s.cmp.lt     s8, s4, s5
    s.sub        s5, s3, s7
    s.sub        s3, s2, s8
    s.xor        s2, s6, s5
    s.movz       s7, #0
    s.movz       s8, #1
    s.xor        s9, s4, s3
    s.sub        s10, s2, s5
    s.rdspecial  s2, arg_base
    s.movz       s5, #0
    s.sub        s11, s9, s3
    s.addi       s9, s7, #0
    s.cmp.eq     s7, s10, s8
    s.ld.d       s8, [s2, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.addi       s12, s5, #0
    s.ld.d       s5, [s2, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s13, [s2, #16]                  // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s14, [s2, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s15, [s2, #32]                  // out_ptr0: device_ptr64 at arg_base+32
    s.mov        s9, s11
    br.nz        s7, sdiv_done_1
    s.movz       s2, #0
    s.movz       s7, #31
    s.mov        s9, s2
    s.addi       s2, s7, #0
sdiv_2:
    s.lshr       s7, s11, s2
    s.shli       s16, s12, #1
    s.andi       s17, s7, #1
    s.movz       s7, #0
    s.or         s18, s16, s17
    s.movz       s16, #1
    s.cmp.geu    s17, s18, s10
    s.shl        s19, s16, s2
    s.sub        s16, s7, s17
    s.subi       s7, s2, #1
    s.and        s17, s10, s16
    s.and        s20, s19, s16
    s.sub        s16, s18, s17
    s.or         s17, s9, s20
    s.mov        s12, s16
    s.mov        s9, s17
    s.mov        s2, s7
    s.movz       s7, #0
    s.cmp.ge     s16, s2, s7
    br.nz        s16, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.movz       s7, #0
    s.movz       s9, #0
    s.movz       s10, #0
    s.cmp.lt     s11, s6, s2
    s.movz       s2, #0
    s.cmp.lt     s16, s7, s9
    s.sub        s9, s10, s11
    s.sub        s10, s2, s16
    s.xor        s2, s6, s9
    s.xor        s6, s12, s3
    s.xor        s11, s7, s10
    s.sub        s12, s2, s9
    s.movz       s2, #0
    s.movz       s16, #1
    s.sub        s17, s6, s3
    s.sub        s3, s11, s10
    s.movz       s6, #0
    s.addi       s11, s2, #0
    s.cmp.eq     s2, s12, s16
    s.add        s16, s4, s17
    s.addi       s4, s6, #0
    s.mov        s11, s3
    br.nz        s2, sdiv_done_3
    s.movz       s2, #0
    s.movz       s6, #31
    s.mov        s11, s2
    s.addi       s2, s6, #0
sdiv_4:
    s.lshr       s6, s3, s2
    s.shli       s17, s4, #1
    s.andi       s18, s6, #1
    s.movz       s6, #0
    s.or         s19, s17, s18
    s.movz       s17, #1
    s.cmp.geu    s18, s19, s12
    s.shl        s20, s17, s2
    s.sub        s17, s6, s18
    s.subi       s6, s2, #1
    s.and        s18, s12, s17
    s.and        s21, s20, s17
    s.sub        s17, s19, s18
    s.or         s18, s11, s21
    s.mov        s4, s17
    s.mov        s11, s18
    s.mov        s2, s6
    s.movz       s6, #0
    s.cmp.ge     s17, s2, s6
    br.nz        s17, sdiv_4
sdiv_done_3:
    s.xor        s2, s10, s9
    s.movz       s3, #16
    s.xor        s4, s11, s2
    s.mul        s6, s16, s3
    s.sub        s9, s4, s2
    v.splat      v0, s16
    s.mul        s2, s9, s3
    v.splat      v1, s7
    s.andi       s4, s6, #15
    v.splat      v2, s9
    v.splat      v3, s7
    s.andi       s9, s2, #15
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s6
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s2
    v.splat      v1, s4
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s9
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.movz       s10, #2
    s.addi       s11, s7, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s7, s11, s10
    br.nz        s7, endfor_6
    s.mul        s7, s11, s3
    s.add        s12, s8, s7                     // the tile origin
    s.muli       s16, s4, #32                    // a runtime tile origin, x32
    s.add        s17, s12, s16                   // the tile origin
    // a 16x16 f8E4M3FN tile, one row per vector load: f8E4M3FN has no fragment this can unpack
    s.rdspecial  s12, arg_base
    s.ld.d       s16, [s12, #40]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s12, role_id
    s.movz       s18, #3584
    s.mul        s19, s12, s18
    s.add        s12, s16, s19                   // this context's own scratch
    s.addi       s16, s12, #0
    v.ld.b       v0, [s17, #0]
    v.st.w       [s16, #0], v0
    s.addi       s18, s16, #64
    s.addi       s19, s17, #32                   // row 1
    v.ld.b       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s16, #128
    s.addi       s19, s17, #64                   // row 2
    v.ld.b       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s16, #192
    s.addi       s19, s17, #96                   // row 3
    v.ld.b       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s16, #256
    s.addi       s19, s17, #128                  // row 4
    v.ld.b       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s16, #320
    s.addi       s19, s17, #160                  // row 5
    v.ld.b       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s16, #384
    s.addi       s19, s17, #192                  // row 6
    v.ld.b       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s16, #448
    s.addi       s19, s17, #224                  // row 7
    v.ld.b       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s16, #512
    s.addi       s19, s17, #256                  // row 8
    v.ld.b       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s16, #576
    s.addi       s19, s17, #288                  // row 9
    v.ld.b       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s16, #640
    s.addi       s19, s17, #320                  // row 10
    v.ld.b       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s16, #704
    s.addi       s19, s17, #352                  // row 11
    v.ld.b       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s16, #768
    s.addi       s19, s17, #384                  // row 12
    v.ld.b       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s16, #832
    s.addi       s19, s17, #416                  // row 13
    v.ld.b       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s16, #896
    s.addi       s19, s17, #448                  // row 14
    v.ld.b       v0, [s19, #0]
    v.st.w       [s18, #0], v0
    s.addi       s18, s16, #960
    s.addi       s16, s17, #480                  // row 15
    v.ld.b       v0, [s16, #0]
    v.st.w       [s18, #0], v0
    fence.acq_rel.device
    s.addi       s16, s12, #1024
    s.movz       s17, #0
    s.add        s18, s17, s7                    // the tile origin
    s.muli       s7, s9, #32                     // a runtime tile origin, x32
    s.add        s17, s18, s7                    // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    s.movz       s7, #32
    v.splat      v1, s7
    v.mul        v2, v0, v1
    v.splat      v0, s17
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s16, #0], v0
    s.addi       s7, s16, #64
    s.addi       s18, s17, #1
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    s.addi       s7, s16, #128
    s.addi       s18, s17, #2
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    s.addi       s7, s16, #192
    s.addi       s18, s17, #3
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    s.addi       s7, s16, #256
    s.addi       s18, s17, #4
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    s.addi       s7, s16, #320
    s.addi       s18, s17, #5
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    s.addi       s7, s16, #384
    s.addi       s18, s17, #6
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    s.addi       s7, s16, #448
    s.addi       s18, s17, #7
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    s.addi       s7, s16, #512
    s.addi       s18, s17, #8
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    s.addi       s7, s16, #576
    s.addi       s18, s17, #9
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    s.addi       s7, s16, #640
    s.addi       s18, s17, #10
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    s.addi       s7, s16, #704
    s.addi       s18, s17, #11
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    s.addi       s7, s16, #768
    s.addi       s18, s17, #12
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    s.addi       s7, s16, #832
    s.addi       s18, s17, #13
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    s.addi       s7, s16, #896
    s.addi       s18, s17, #14
    v.splat      v0, s18
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    s.addi       s7, s16, #960
    s.addi       s16, s17, #15
    v.splat      v0, s16
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s5, v1]                   // index is in elements (ISA sec 9.1)
    v.st.w       [s7, #0], v0
    fence.acq_rel.device
    // E4M3 x E5M2: both operands as FP16 fragments, exactly (ISA sec 9C.1)
    s.addi       s7, s12, #2048                  // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s16, s12, #0
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 0: f8E4M3FN -> f16
    v.st.h       [s7, #0], v1
    s.addi       s16, s12, #64
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 1: f8E4M3FN -> f16
    s.addi       s16, s7, #32                    // row 1
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #128
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 2: f8E4M3FN -> f16
    s.addi       s16, s7, #64                    // row 2
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #192
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 3: f8E4M3FN -> f16
    s.addi       s16, s7, #96                    // row 3
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #256
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 4: f8E4M3FN -> f16
    s.addi       s16, s7, #128                   // row 4
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #320
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 5: f8E4M3FN -> f16
    s.addi       s16, s7, #160                   // row 5
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #384
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 6: f8E4M3FN -> f16
    s.addi       s16, s7, #192                   // row 6
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #448
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 7: f8E4M3FN -> f16
    s.addi       s16, s7, #224                   // row 7
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #512
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 8: f8E4M3FN -> f16
    s.addi       s16, s7, #256                   // row 8
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #576
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 9: f8E4M3FN -> f16
    s.addi       s16, s7, #288                   // row 9
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #640
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 10: f8E4M3FN -> f16
    s.addi       s16, s7, #320                   // row 10
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #704
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 11: f8E4M3FN -> f16
    s.addi       s16, s7, #352                   // row 11
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #768
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 12: f8E4M3FN -> f16
    s.addi       s16, s7, #384                   // row 12
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #832
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 13: f8E4M3FN -> f16
    s.addi       s16, s7, #416                   // row 13
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #896
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 14: f8E4M3FN -> f16
    s.addi       s16, s7, #448                   // row 14
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #960
    v.ld.w       v0, [s16, #0]
    vf.cvt.e4m3.f16 v1, v0                       // row 15: f8E4M3FN -> f16
    s.addi       s16, s7, #480                   // row 15
    v.st.h       [s16, #0], v1
    s.addi       s16, s12, #2560                 // TensorMap 0: a repacked tile
    s.movz       s17, #0
    s.st.d       [s16, #0], s7
    s.movz       s7, #16
    s.st.d       [s16, #8], s7
    s.movz       s7, #16
    s.st.d       [s16, #16], s7
    s.movz       s7, #32
    s.st.d       [s16, #48], s7
    s.movz       s7, #2
    s.st.d       [s16, #56], s7
    .li       s7, #68719476752
    s.st.d       [s16, #88], s7
    .li       s7, #8589934592
    s.st.d       [s16, #104], s7
    fence.release.device
    td.load      d0, [s16]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s7, #0
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s16, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s17, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s18, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s17, s16
    mb.wait      s16
    s.addi       s7, s12, #2816                  // 512 bytes of repack scratch
    // repack 16x16 f16 through memory: there is no v.pack (ISA sec 8.4)
    s.addi       s17, s12, #1024
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 0: f8E5M2 -> f16
    v.st.h       [s7, #0], v1
    s.addi       s17, s12, #1088
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 1: f8E5M2 -> f16
    s.addi       s17, s7, #32                    // row 1
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #1152
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 2: f8E5M2 -> f16
    s.addi       s17, s7, #64                    // row 2
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #1216
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 3: f8E5M2 -> f16
    s.addi       s17, s7, #96                    // row 3
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #1280
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 4: f8E5M2 -> f16
    s.addi       s17, s7, #128                   // row 4
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #1344
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 5: f8E5M2 -> f16
    s.addi       s17, s7, #160                   // row 5
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #1408
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 6: f8E5M2 -> f16
    s.addi       s17, s7, #192                   // row 6
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #1472
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 7: f8E5M2 -> f16
    s.addi       s17, s7, #224                   // row 7
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #1536
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 8: f8E5M2 -> f16
    s.addi       s17, s7, #256                   // row 8
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #1600
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 9: f8E5M2 -> f16
    s.addi       s17, s7, #288                   // row 9
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #1664
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 10: f8E5M2 -> f16
    s.addi       s17, s7, #320                   // row 10
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #1728
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 11: f8E5M2 -> f16
    s.addi       s17, s7, #352                   // row 11
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #1792
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 12: f8E5M2 -> f16
    s.addi       s17, s7, #384                   // row 12
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #1856
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 13: f8E5M2 -> f16
    s.addi       s17, s7, #416                   // row 13
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #1920
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 14: f8E5M2 -> f16
    s.addi       s17, s7, #448                   // row 14
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #1984
    v.ld.w       v0, [s17, #0]
    vf.cvt.e5m2.f16 v1, v0                       // row 15: f8E5M2 -> f16
    s.addi       s17, s7, #480                   // row 15
    v.st.h       [s17, #0], v1
    s.addi       s17, s12, #3328                 // TensorMap 1: a repacked tile
    s.movz       s12, #0
    s.st.d       [s17, #0], s7
    s.movz       s7, #16
    s.st.d       [s17, #8], s7
    s.movz       s7, #16
    s.st.d       [s17, #16], s7
    s.movz       s7, #32
    s.st.d       [s17, #48], s7
    s.movz       s7, #2
    s.st.d       [s17, #56], s7
    .li       s7, #68719476752
    s.st.d       [s17, #88], s7
    .li       s7, #8589934592
    s.st.d       [s17, #104], s7
    fence.release.device
    td.load      d1, [s17]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s7, #0
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s12, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a repacked tile: one tile into a window (ISA sec 9E)
    s.mov        s17, s7                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s18, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s17, s12
    mb.wait      s12
    mb.arm       s7, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.f16 a0, v56, v48, s7
    mb.wait      s7
    s.add        s17, s11, s1
    s.mov        s11, s17
    s.movz       s17, #1
    br.nz        s17, for_5
endfor_6:
    s.ld.w       s1, [s13, #0]                   // one element, not a vector
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s4, #0
    s.movz       s5, #0
    s.movz       s8, #0
    s.add        s9, s5, s2                      // the tile origin
    s.muli       s5, s2, #2                      // a runtime tile origin, x2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s9
    s.add        s2, s8, s6                      // the tile origin
    s.muli       s8, s6, #32                     // a runtime tile origin, x32
    v.splat      v2, s2
    s.ld.w       s6, [s14, #0]                   // one element, not a vector
    v.splat      v3, s1
    a.vread      v4, a0, s4
    v.splat      v5, s3
    v.add        v6, v0, v1
    v.splat      v0, s3
    s.add        s1, s15, s5                     // the tile origin
    v.cmp.lt     p1, v2, v5
    v.cmp.lt     p2, v6, v0
    s.add        s3, s1, s8                      // the tile origin
    p.and        p3, p1, p2
    v.splat      v0, s6
    s.movz       s1, #1
    s.addi       s4, s2, #1
    vf.mul       v1, v3, v0
    vf.mul       v2, v3, v0
    v.splat      v6, s4
    s.addi       s4, s3, #32                     // row 1
    s.movz       s5, #2
    vf.mul       v7, v4, v1
    v.cmp.lt     p1, v6, v5
    p.and        p4, p1, p2
    vf.mul       v1, v3, v0
    s.addi       s6, s2, #2
    vf.cvt.f32.bf16 v4, v7
    v.splat      v6, s6
    s.addi       s6, s3, #64                     // row 2
    s.movz       s8, #3
    vf.mul       v7, v3, v0
    @p3 v.st.h       [s3, #0], v4
    a.vread      v4, a0, s1
    v.cmp.lt     p1, v6, v5
    p.and        p3, p1, p2
    vf.mul       v6, v4, v2
    s.addi       s1, s2, #3
    s.addi       s9, s3, #96                     // row 3
    v.splat      v2, s1
    s.movz       s1, #4
    vf.cvt.f32.bf16 v4, v6
    vf.mul       v6, v3, v0
    s.addi       s10, s2, #4
    s.addi       s11, s3, #128                   // row 4
    v.splat      v8, s10
    @p4 v.st.h       [s4, #0], v4
    a.vread      v4, a0, s5
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v4, v1
    s.movz       s4, #5
    vf.mul       v1, v3, v0
    s.addi       s5, s2, #5
    s.addi       s10, s3, #160                   // row 5
    vf.cvt.f32.bf16 v4, v2
    v.splat      v2, s5
    s.movz       s5, #6
    vf.mul       v9, v3, v0
    @p3 v.st.h       [s6, #0], v4
    a.vread      v4, a0, s8
    v.cmp.lt     p1, v8, v5
    p.and        p3, p1, p2
    vf.mul       v8, v4, v7
    s.addi       s6, s2, #6
    s.addi       s8, s3, #192                    // row 6
    v.splat      v4, s6
    s.movz       s6, #7
    vf.cvt.f32.bf16 v7, v8
    vf.mul       v8, v3, v0
    @p4 v.st.h       [s9, #0], v7
    a.vread      v7, a0, s1
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v7, v6
    s.addi       s1, s2, #7
    s.addi       s9, s3, #224                    // row 7
    v.splat      v6, s1
    s.movz       s1, #8
    vf.cvt.f32.bf16 v7, v2
    vf.mul       v2, v3, v0
    @p3 v.st.h       [s11, #0], v7
    a.vread      v7, a0, s4
    v.cmp.lt     p1, v4, v5
    p.and        p3, p1, p2
    vf.mul       v4, v7, v1
    s.addi       s4, s2, #8
    s.addi       s11, s3, #256                   // row 8
    v.splat      v1, s4
    s.movz       s4, #9
    vf.cvt.f32.bf16 v7, v4
    vf.mul       v4, v3, v0
    @p4 v.st.h       [s10, #0], v7
    a.vread      v7, a0, s5
    v.cmp.lt     p1, v6, v5
    p.and        p4, p1, p2
    vf.mul       v6, v7, v9
    s.addi       s5, s2, #9
    s.addi       s10, s3, #288                   // row 9
    v.splat      v7, s5
    s.movz       s5, #10
    vf.cvt.f32.bf16 v9, v6
    vf.mul       v6, v3, v0
    @p3 v.st.h       [s8, #0], v9
    a.vread      v9, a0, s6
    v.cmp.lt     p1, v1, v5
    p.and        p3, p1, p2
    vf.mul       v1, v9, v8
    s.addi       s6, s2, #10
    s.addi       s8, s3, #320                    // row 10
    v.splat      v8, s6
    s.movz       s6, #11
    vf.cvt.f32.bf16 v9, v1
    vf.mul       v1, v3, v0
    @p4 v.st.h       [s9, #0], v9
    a.vread      v9, a0, s1
    v.cmp.lt     p1, v7, v5
    p.and        p4, p1, p2
    vf.mul       v7, v9, v2
    s.addi       s1, s2, #11
    s.addi       s9, s3, #352                    // row 11
    v.splat      v2, s1
    s.movz       s1, #12
    vf.cvt.f32.bf16 v9, v7
    vf.mul       v7, v3, v0
    @p3 v.st.h       [s11, #0], v9
    a.vread      v9, a0, s4
    v.cmp.lt     p1, v8, v5
    p.and        p3, p1, p2
    vf.mul       v8, v9, v4
    s.addi       s4, s2, #12
    s.addi       s11, s3, #384                   // row 12
    v.splat      v4, s4
    s.movz       s4, #13
    vf.cvt.f32.bf16 v9, v8
    vf.mul       v8, v3, v0
    @p4 v.st.h       [s10, #0], v9
    a.vread      v9, a0, s5
    v.cmp.lt     p1, v2, v5
    p.and        p4, p1, p2
    vf.mul       v2, v9, v6
    s.addi       s5, s2, #13
    s.addi       s10, s3, #416                   // row 13
    v.splat      v6, s5
    s.movz       s5, #14
    vf.cvt.f32.bf16 v9, v2
    vf.mul       v2, v3, v0
    vf.mul       v10, v3, v0
    @p3 v.st.h       [s8, #0], v9
    a.vread      v0, a0, s6
    v.cmp.lt     p1, v4, v5
    p.and        p3, p1, p2
    vf.mul       v3, v0, v1
    s.addi       s6, s2, #14
    s.addi       s8, s3, #448                    // row 14
    v.splat      v0, s6
    s.movz       s6, #15
    vf.cvt.f32.bf16 v1, v3
    s.addi       s13, s2, #15
    s.addi       s2, s3, #480                    // row 15
    v.splat      v3, s13
    @p4 v.st.h       [s9, #0], v1
    a.vread      v1, a0, s1
    v.cmp.lt     p1, v6, v5
    p.and        p4, p1, p2
    vf.mul       v4, v1, v7
    vf.cvt.f32.bf16 v1, v4
    @p3 v.st.h       [s11, #0], v1
    a.vread      v1, a0, s4
    v.cmp.lt     p1, v0, v5
    p.and        p3, p1, p2
    vf.mul       v0, v1, v8
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s10, #0], v1
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v3, v5
    p.and        p4, p1, p2
    vf.mul       v1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    @p3 v.st.h       [s8, #0], v0
    a.vread      v0, a0, s6
    vf.mul       v1, v0, v10
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s2, #0], v0
__rctx_next:
    exit
