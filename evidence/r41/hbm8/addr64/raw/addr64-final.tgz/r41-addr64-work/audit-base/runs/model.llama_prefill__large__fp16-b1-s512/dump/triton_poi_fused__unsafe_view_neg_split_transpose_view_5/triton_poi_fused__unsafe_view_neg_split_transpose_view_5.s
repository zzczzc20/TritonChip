    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    v.movi       v2, #0
    v.movi       v3, #5
    v.add        v4, v1, v0
    v.movi       v0, #0
    v.movi       v1, #0
    v.sub        v5, v2, v4
    v.cmp.lt     p1, v4, v2
    v.sub        v6, v0, v4
    @p1 v.sel        v7, v5, v4
    v.movi       v5, #0
    v.sub        v8, v1, v4
    v.lshr       v9, v7, v3
    v.cmp.lt     p2, v4, v0
    v.cmp.lt     p3, v4, v1
    v.sub        v3, v2, v9
    @p2 v.sel        v7, v6, v4
    v.movi       v6, #31
    @p1 v.sel        v10, v3, v9
    @p3 v.sel        v3, v8, v4
    v.and        v4, v7, v6
    v.sub        v6, v5, v10
    v.cmp.lt     p1, v10, v5
    v.movi       v7, #511
    @p1 v.sel        v8, v6, v10
    v.sub        v6, v0, v4
    s.rdspecial  s1, arg_base
    v.and        v9, v8, v7
    v.movi       v7, #32
    @p2 v.sel        v8, v6, v4
    v.sub        v4, v5, v9
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v6, #512
    @p1 v.sel        v11, v4, v9
    v.movi       v4, #16384
    v.sub        v9, v0, v7
    v.sub        v12, v2, v7
    v.cmp.lt     p1, v7, v0
    v.sub        v0, v5, v6
    v.cmp.lt     p2, v7, v2
    v.sub        v2, v1, v4
    @p1 v.sel        v13, v9, v7
    s.ld.d       s3, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    v.movi       v9, #14
    v.mul        v13, v11, v6
    v.cmp.lt     p1, v6, v5
    v.lshr       v5, v3, v9
    v.movi       v3, #64
    v.add        v9, v8, v7
    @p2 v.sel        v11, v12, v7
    v.sub        v7, v1, v5
    v.mul        v11, v10, v3
    v.cmp.lt     p2, v4, v1
    @p3 v.sel        v1, v7, v5
    v.add        v5, v8, v11
    @p1 v.sel        v7, v0, v6
    v.mul        v0, v1, v3
    @p2 v.sel        v1, v2, v4
    v.add        v1, v9, v0
    v.add        v0, v1, v13
    v.ld.gather.h v1, [s2, v0]                   // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v0, v1
    vf.neg       v1, v0
    vf.cvt.f32.f16 v0, v1
    v.st.scatter.h [s3, v5], v0
__rctx_next:
    exit
