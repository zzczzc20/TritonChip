    s.rdspecial  s1, arg_base
    s.movz       s2, #0
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s4, #65
    s.movz       s5, #32
    s.movz       s6, #1
    s.rdspecial  s6, role_id
    s.rdspecial  s7, npid.x
    s.ld.d       s8, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s9, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s10, [s1, #24]                  // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s11, [s1, #32]                  // out_ptr0: device_ptr64 at arg_base+32
__rctx_program:
    v.splat      v0, s6
    v.movi       v1, #0
    v.movi       v2, #5
    v.movi       v3, #6
    v.sub        v4, v1, v0
    v.cmp.lt     p1, v0, v1
    v.movi       v5, #1
    @p1 v.sel        v6, v4, v0
    v.movi       v0, #31
    v.movi       v4, #65
    v.lshr       v7, v6, v2
    v.lshr       v2, v6, v3
    v.and        v3, v6, v0
    v.sub        v0, v1, v7
    v.sub        v6, v1, v2
    v.sub        v8, v1, v3
    @p1 v.sel        v9, v0, v7
    @p1 v.sel        v0, v6, v2
    v.movi       v2, #32
    v.sub        v6, v1, v9
    v.cmp.lt     p2, v9, v1
    v.movi       v7, #2
    @p2 v.sel        v10, v6, v9
    v.movi       v6, #64
    @p1 v.sel        v9, v8, v3
    v.and        v3, v10, v5
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v10, #16
    v.sub        v11, v1, v3
    v.sub        v12, v1, v2
    v.sub        v13, v1, v7
    @p2 v.sel        v14, v11, v3
    v.sub        v3, v1, v6
    v.movi       v11, #0
    v.mul        v15, v14, v4
    v.movi       v16, #0
    v.movi       v17, #0
    v.extract    s1, v15, #0
    v.extract    s12, v0, #0
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p2, v7, v1
    v.cmp.lt     p3, v6, v1
    v.add        v15, v8, v10
    v.movi       v10, #129
    v.extract    s13, v9, #0
    @p1 v.sel        v9, v12, v2
    v.sub        v9, v1, v0
    v.cmp.lt     p1, v0, v1
    v.movi       v12, #2080
    @p1 v.sel        v18, v9, v0
    v.movi       v9, #4128
    v.mul        v19, v0, v10
    v.lshr       v0, v18, v5
    v.mul        v18, v14, v12
    v.extract    s14, v19, #0
    v.sub        v12, v1, v0
    v.extract    s15, v18, #0
    @p2 v.sel        v14, v13, v7
    @p1 v.sel        v7, v12, v0
    @p3 v.sel        v0, v3, v6
    s.addi       s16, s2, #0
    v.mul        v0, v7, v9
    v.mov        v16, v11
    v.mov        v17, v11
    v.splat      v3, s1
    v.extract    s1, v0, #0
    v.splat      v0, s12
    v.movi       v6, #0
    v.splat      v7, s14
    .li       s12, #1065353216
    v.splat      v9, s12                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v12, s13
    v.splat      v13, s15
    v.splat      v14, s1
for_1:
    v.splat      v18, s16
    v.splat      v19, s16
    v.add        v20, v18, v8
    v.add        v18, v19, v15
    v.add        v19, v20, v3
    v.add        v21, v18, v3
    v.cmp.lt     p1, v20, v4
    v.cmp.lt     p2, v19, v10
    v.cmp.lt     p3, v18, v4
    v.cmp.lt     p4, v21, v10
    p.and        p5, p1, p2
    p.and        p6, p3, p4
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v22, [s9, v0]              // index is in elements (ISA sec 9.1)
    v.mul        v23, v20, v2
    v.mul        v20, v18, v2
    v.add        v18, v19, v7
    v.add        v19, v21, v7
    v.add        v21, v12, v23
    v.add        v23, v12, v20
    v.add        v20, v21, v13
    v.add        v21, v23, v13
    v.add        v23, v20, v14
    v.add        v20, v21, v14
    v.movi       v21, #0                         // other=, materialised (sec 12)
    @p6 v.ld.gather.w v21, [s9, v0]              // index is in elements (ISA sec 9.1)
    v.rcp.approx v24, v22                        // ISA 8.8: <= 2**-22 relative
    v.rcp.approx v25, v21                        // ISA 8.8: <= 2**-22 relative
    v.movi       v26, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.sb v26, [s3, v0]             // index is in elements (ISA sec 9.1)
    vf.fms       v27, v22, v24, v9
    vf.fms       v22, v24, v27, v24
    v.movi       v27, #0                         // other=, materialised (sec 12)
    @p6 v.ld.gather.sb v27, [s3, v0]             // index is in elements (ISA sec 9.1)
    v.cmp.ne     p7, v26, v6
    vf.neg       v26, v22                        // Newton step: r0*(2 - x*r0)
    @p7 v.sel        v22, v5, v1
    v.cmp.eq     p7, v22, v1
    vf.cmp.o     p8, v26, v26
    @p8 v.sel        v22, v26, v24
    vf.fms       v24, v21, v25, v9
    vf.fms       v21, v25, v24, v25
    v.movi       v24, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.w v24, [s8, v18]             // index is in elements (ISA sec 9.1)
    vf.neg       v18, v21                        // Newton step: r0*(2 - x*r0)
    v.cmp.ne     p8, v27, v6
    @p8 v.sel        v21, v5, v1
    vf.cmp.o     p8, v18, v18
    @p8 v.sel        v26, v18, v25
    v.cmp.eq     p8, v21, v1
    v.movi       v18, #0                         // other=, materialised (sec 12)
    @p6 v.ld.gather.w v18, [s8, v19]             // index is in elements (ISA sec 9.1)
    vf.mul       v19, v24, v22                   // a/y as a refined reciprocal (ISA has no divide)
    @p7 v.sel        v21, v11, v19
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p5 v.ld.gather.h v19, [s10, v23]            // index is in elements (ISA sec 9.1)
    vf.mul       v22, v18, v26                   // a/y as a refined reciprocal (ISA has no divide)
    @p8 v.sel        v18, v11, v22
    v.movi       v22, #0                         // other=, materialised (sec 12)
    @p6 v.ld.gather.h v22, [s10, v20]            // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v20, v19
    vf.mul       v19, v21, v20
    @p2 v.sel        v20, v19, v11
    vf.cvt.f16.f32 v19, v22
    vf.add       v21, v16, v20
    vf.mul       v20, v18, v19
    @p1 v.sel        v16, v21, v16
    @p4 v.sel        v18, v20, v11
    vf.add       v19, v17, v18
    @p3 v.sel        v17, v19, v17
    s.add        s16, s16, s5
    s.cmp.lt     s1, s16, s4
    br.nz        s1, for_1
endfor_2:
    vf.reduce.add.b v0, v16
    vf.reduce.add.b v1, v17
    v.movi       v2, #0
    s.movz       s1, #1
    vf.add       v3, v0, v1
    s.shli       s12, s6, #2                     // element offset -> bytes (x4)
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s11, s12                    // &out_ptr0[...]
    vf.add       v4, v3, v2
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v4
__rctx_next:
    s.addi       s1, s6, #4                      // the next program of this context: + 4
    s.cmp.lt     s12, s1, s7
    s.mov        s6, s1
    br.nz        s12, __rctx_program
    exit
