#!/bin/sh
# launch.sh NAME EXTRA_ARGS...  -- detached compile-estimate run in ~/r41s1-qwen/runs/NAME
name=$1; shift
cd ~/r41s1-qwen || exit 1
log=runs/$name.log
setsid -f sh -c "cd ~/r41s1-qwen; taskset -c 0-5 ~/r41-stage1/envs/transformers-4321355/bin/python -u src/tools/performance_harness/model_compile_estimate.py --config inputs/config.json --inventory inputs/inventory.json --sources inputs/sources.json --torch-extensions-dir ~/r41s1-qwen/torch_ext --out runs/$name $*; echo EXIT=\$? >> $log" > "$log" 2>&1 < /dev/null
echo started $name
