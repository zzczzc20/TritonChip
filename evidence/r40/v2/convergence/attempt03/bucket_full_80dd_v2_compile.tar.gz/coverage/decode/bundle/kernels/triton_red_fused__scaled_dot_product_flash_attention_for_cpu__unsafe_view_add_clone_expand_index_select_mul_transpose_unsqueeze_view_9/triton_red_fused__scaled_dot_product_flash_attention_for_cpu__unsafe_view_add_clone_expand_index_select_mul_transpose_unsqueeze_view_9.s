    s.rdspecial  s1, arg_base
    s.rdspecial  s2, role_id
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.rdspecial  s4, npid.x
    s.ld.d       s5, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s6, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s7, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s8, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s9, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s10, [s1, #48]                  // out_ptr0: device_ptr64 at arg_base+48
__rctx_program:
    v.splat      v0, s2
    v.movi       v1, #576
    v.movi       v2, #0
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v4, #1
    v.sub        v5, v2, v0
    v.sub        v6, v2, v1
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    @p1 v.sel        v7, v5, v0
    @p2 v.sel        v5, v6, v1
    v.movi       v6, #0
    v.movi       v8, #0
    s.movz       s1, #31
idiv_1:
    v.splat      v9, s1
    v.shl        v10, v8, v4
    v.cmp.lt     p3, v8, v2
    v.lshr       v11, v7, v9
    v.shl        v12, v4, v9
    s.subi       s11, s1, #1
    v.and        v9, v11, v4
    s.movz       s12, #0
    v.or         v11, v10, v9
    v.cmp.geu    p4, v11, v5
    p.or         p5, p3, p4
    v.sub        v9, v11, v5
    @p5 v.sel        v10, v12, v2
    @p5 v.sel        v12, v9, v11
    v.or         v9, v6, v10
    v.mov        v8, v12
    v.mov        v6, v9
    s.mov        s1, s11
    s.cmp.ge     s11, s1, s12
    br.nz        s11, idiv_1
    s.ld.d       s1, [s5, #0]                    // one element, not a vector
    v.movi       v4, #0
    v.movi       v5, #0
    v.sub        v7, v2, v6
    p.xor        p3, p1, p2
    @p3 v.sel        v2, v7, v6
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #0
    v.insert     v5, s11, #0
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #1
    v.insert     v5, s11, #1
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #2
    v.insert     v5, s11, #2
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #3
    v.insert     v5, s11, #3
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #4
    v.insert     v5, s11, #4
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #5
    v.insert     v5, s11, #5
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #6
    v.insert     v5, s11, #6
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #7
    v.insert     v5, s11, #7
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #8
    v.insert     v5, s11, #8
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #9
    v.insert     v5, s11, #9
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #10
    v.insert     v5, s11, #10
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #11
    v.insert     v5, s11, #11
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #12
    v.insert     v5, s11, #12
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #13
    v.insert     v5, s11, #13
    v.movi       v6, #0
    s.lshri      s11, s1, #32
    v.insert     v4, s1, #14
    v.insert     v5, s11, #14
    v.sub        v7, v6, v0
    v.sub        v8, v6, v1
    s.lshri      s11, s1, #32
    v.cmp.lt     p1, v0, v6
    v.cmp.lt     p2, v1, v6
    v.insert     v4, s1, #15
    v.insert     v5, s11, #15
    v.movi       v9, #1
    @p1 v.sel        v10, v7, v0
    @p2 v.sel        v0, v8, v1
    v.movi       v1, #0
    v.movi       v7, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v8, s1
    v.shl        v11, v7, v9
    v.cmp.lt     p2, v7, v6
    v.lshr       v12, v10, v8
    v.shl        v13, v9, v8
    s.subi       s11, s1, #1
    v.and        v8, v12, v9
    s.movz       s12, #0
    v.or         v12, v11, v8
    v.cmp.geu    p3, v12, v0
    p.or         p4, p2, p3
    v.sub        v8, v12, v0
    @p4 v.sel        v11, v13, v6
    @p4 v.sel        v13, v8, v12
    v.or         v8, v1, v11
    v.mov        v7, v13
    v.mov        v1, v8
    s.mov        s1, s11
    s.cmp.ge     s11, s1, s12
    br.nz        s11, idiv_2
    v.sub        v0, v6, v7
    v.movi       v1, #0
    v.movi       v6, #0
    s.movz       s1, #0
    @p1 v.sel        v8, v0, v7
    s.movz       s11, #64
    s.movz       s12, #16
    s.addi       s13, s1, #0
    v.mov        v6, v1
for_3:
    s.cmp.ge     s1, s13, s11
    br.nz        s1, endfor_4
    v.movi       v0, #0
    v.movi       v1, #2
    v.movi       v7, #64
    v.sub        v9, v0, v2
    v.cmp.lt     p1, v2, v0
    v.mul        v10, v8, v7
    @p1 v.sel        v11, v9, v2
    s.movz       s1, #36864
    v.splat      v9, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v12, s13
    v.lshr       v13, v11, v1
    v.mul        v1, v2, v7
    v.extract    s1, v10, #0
    v.sub        v7, v0, v13
    v.extract    s14, v5, #0
    v.add        v10, v12, v3
    @p1 v.sel        v11, v7, v13
    v.splat      v7, s1
    v.extract    s1, v1, #0
    v.mul        v1, v11, v9
    v.extract    s15, v4, #0
    s.shli       s16, s14, #32
    v.extract    s14, v1, #0
    v.splat      v1, s1
    v.add        v9, v10, v7
    v.splat      v7, s14
    s.or         s1, s15, s16
    s.movz       s14, #576
    v.extract    s15, v4, #1
    v.movi       v11, #64
    v.extract    s16, v5, #1
    s.add        s17, s1, s14
    v.add        v12, v10, v1
    v.add        v1, v9, v7
    v.movi       v7, #0
    v.movi       v9, #0
    s.lshri      s1, s17, #32
    v.cmp.lt     p1, v10, v11
    s.shli       s14, s16, #32
    s.movz       s16, #576
    s.or         s18, s15, s14
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v11, [s3, v12]             // index is in elements (ISA sec 9.1)
    s.add        s14, s18, s16
    v.movi       v13, #4
    s.lshri      s15, s14, #32
    v.movi       v14, #1
    v.sub        v14, v0, v13
    v.cmp.lt     p2, v13, v0
    s.movz       s16, #36864
    @p2 v.sel        v0, v14, v13
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v0, [s7, v12]              // index is in elements (ISA sec 9.1)
    vf.cvt.f16.f32 v12, v11
    v.extract    s16, v5, #2
    v.extract    s18, v4, #2
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.h v11, [s9, v1]              // index is in elements (ISA sec 9.1)
    v.insert     v7, s17, #0
    v.insert     v9, s1, #0
    vf.cvt.f16.f32 v1, v0
    s.shli       s1, s16, #32
    v.extract    s16, v5, #3
    s.or         s17, s18, s1
    s.movz       s1, #576
    v.extract    s18, v4, #3
    s.shli       s19, s16, #32
    s.add        s16, s17, s1
    v.extract    s1, v5, #4
    v.insert     v7, s14, #1
    v.insert     v9, s15, #1
    s.or         s14, s18, s19
    s.movz       s15, #576
    s.lshri      s17, s16, #32
    v.extract    s18, v4, #4
    s.shli       s19, s1, #32
    s.add        s1, s14, s15
    v.insert     v7, s16, #2
    v.insert     v9, s17, #2
    s.or         s14, s18, s19
    s.movz       s15, #576
    s.lshri      s16, s1, #32
    s.add        s17, s14, s15
    v.insert     v7, s1, #3
    v.insert     v9, s16, #3
    s.lshri      s1, s17, #32
    v.insert     v7, s17, #4
    v.insert     v9, s1, #4
    vf.cvt.f16.f32 v0, v11
    v.extract    s1, v5, #5
    v.extract    s14, v4, #5
    s.shli       s15, s1, #32
    v.extract    s1, v5, #6
    s.or         s16, s14, s15
    s.movz       s14, #576
    v.extract    s15, v4, #6
    s.shli       s17, s1, #32
    s.add        s1, s16, s14
    v.extract    s14, v5, #7
    s.or         s16, s15, s17
    s.movz       s15, #576
    s.lshri      s17, s1, #32
    v.extract    s18, v4, #7
    s.shli       s19, s14, #32
    s.add        s14, s16, s15
    v.extract    s15, v5, #8
    v.insert     v7, s1, #5
    v.insert     v9, s17, #5
    s.or         s1, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s14, #32
    v.extract    s18, v4, #8
    s.shli       s19, s15, #32
    s.add        s15, s1, s16
    v.extract    s1, v5, #9
    v.insert     v7, s14, #6
    v.insert     v9, s17, #6
    s.or         s14, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s15, #32
    v.extract    s18, v4, #9
    s.shli       s19, s1, #32
    s.add        s1, s14, s16
    v.extract    s14, v5, #10
    v.insert     v7, s15, #7
    v.insert     v9, s17, #7
    s.or         s15, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s1, #32
    v.extract    s18, v4, #10
    s.shli       s19, s14, #32
    s.add        s14, s15, s16
    v.extract    s15, v5, #11
    v.insert     v7, s1, #8
    v.insert     v9, s17, #8
    s.or         s1, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s14, #32
    v.extract    s18, v4, #11
    s.shli       s19, s15, #32
    s.add        s15, s1, s16
    v.extract    s1, v5, #12
    v.insert     v7, s14, #9
    v.insert     v9, s17, #9
    s.or         s14, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s15, #32
    v.extract    s18, v4, #12
    s.shli       s19, s1, #32
    s.add        s1, s14, s16
    v.extract    s14, v5, #13
    v.insert     v7, s15, #10
    v.insert     v9, s17, #10
    s.or         s15, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s1, #32
    v.extract    s18, v4, #13
    s.shli       s19, s14, #32
    s.add        s14, s15, s16
    v.extract    s15, v5, #14
    v.insert     v7, s1, #11
    v.insert     v9, s17, #11
    s.or         s1, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s14, #32
    v.extract    s18, v4, #14
    s.shli       s19, s15, #32
    s.add        s15, s1, s16
    v.extract    s1, v5, #15
    v.insert     v7, s14, #12
    v.insert     v9, s17, #12
    s.or         s14, s18, s19
    s.movz       s16, #576
    s.lshri      s17, s15, #32
    v.extract    s18, v4, #15
    s.shli       s19, s1, #32
    v.extract    s1, v5, #0
    s.add        s20, s14, s16
    v.insert     v7, s15, #13
    v.insert     v9, s17, #13
    s.or         s14, s18, s19
    s.movz       s15, #576
    v.extract    s16, v4, #0
    s.shli       s17, s1, #32
    s.lshri      s1, s20, #32
    v.extract    s18, v5, #1
    s.add        s19, s14, s15
    s.or         s14, s16, s17
    s.movz       s15, #0
    v.insert     v7, s20, #14
    v.insert     v9, s1, #14
    v.movi       v11, #0
    v.extract    s1, v4, #1
    s.shli       s16, s18, #32
    s.lshri      s17, s19, #32
    s.cmp.lt     s18, s14, s15
    v.extract    s14, v5, #2
    s.or         s15, s1, s16
    s.movz       s1, #0
    v.insert     v7, s19, #15
    v.insert     v9, s17, #15
    v.insert     v11, s18, #0
    v.extract    s16, v4, #2
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s15, s1
    v.extract    s1, v5, #3
    s.or         s15, s16, s17
    s.movz       s16, #0
    v.insert     v11, s14, #1
    v.extract    s14, v4, #3
    s.shli       s17, s1, #32
    s.cmp.lt     s1, s15, s16
    v.extract    s15, v5, #4
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v11, s1, #2
    v.extract    s1, v4, #4
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s16, s14
    v.extract    s14, v5, #5
    s.or         s16, s1, s17
    s.movz       s1, #0
    v.insert     v11, s15, #3
    v.extract    s15, v4, #5
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s16, s1
    v.extract    s1, v5, #6
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v11, s14, #4
    v.extract    s14, v4, #6
    s.shli       s17, s1, #32
    s.cmp.lt     s1, s16, s15
    v.extract    s15, v5, #7
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v11, s1, #5
    v.extract    s1, v4, #7
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s16, s14
    v.extract    s14, v5, #8
    s.or         s16, s1, s17
    s.movz       s1, #0
    v.insert     v11, s15, #6
    v.extract    s15, v4, #8
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s16, s1
    v.extract    s1, v5, #9
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v11, s14, #7
    v.extract    s14, v4, #9
    s.shli       s17, s1, #32
    s.cmp.lt     s1, s16, s15
    v.extract    s15, v5, #10
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v11, s1, #8
    v.extract    s1, v4, #10
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s16, s14
    v.extract    s14, v5, #11
    s.or         s16, s1, s17
    s.movz       s1, #0
    v.insert     v11, s15, #9
    v.extract    s15, v4, #11
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s16, s1
    v.extract    s1, v5, #12
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v11, s14, #10
    v.extract    s14, v4, #12
    s.shli       s17, s1, #32
    s.cmp.lt     s1, s16, s15
    v.extract    s15, v5, #13
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v11, s1, #11
    v.extract    s1, v4, #13
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s16, s14
    v.extract    s14, v5, #14
    s.or         s16, s1, s17
    s.movz       s1, #0
    v.insert     v11, s15, #12
    v.extract    s15, v4, #14
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s16, s1
    v.extract    s1, v5, #15
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v11, s14, #13
    v.extract    s14, v4, #15
    s.shli       s17, s1, #32
    s.cmp.lt     s1, s16, s15
    s.or         s15, s14, s17
    s.movz       s14, #0
    v.insert     v11, s1, #14
    s.cmp.lt     s1, s15, s14
    v.movi       v13, #0
    v.insert     v11, s1, #15
    v.movi       v14, #1
    v.movi       v15, #0
    v.extract    s1, v9, #0
    v.extract    s14, v5, #0
    v.cmp.ne     p2, v11, v13
    v.extract    s15, v7, #0
    s.shli       s16, s1, #32
    v.extract    s1, v4, #0
    s.shli       s17, s14, #32
    @p2 v.sel        v11, v14, v15
    v.extract    s14, v9, #1
    v.extract    s18, v5, #1
    s.or         s19, s15, s16
    s.or         s15, s1, s17
    v.extract    s1, v7, #1
    s.shli       s16, s14, #32
    v.extract    s14, v4, #1
    s.shli       s17, s18, #32
    v.extract    s18, v11, #0
    s.sub        s20, s19, s15
    v.extract    s19, v9, #2
    s.or         s21, s1, s16
    v.extract    s1, v5, #2
    s.or         s16, s14, s17
    s.mul        s14, s18, s20
    v.extract    s17, v7, #2
    s.shli       s18, s19, #32
    v.extract    s19, v4, #2
    s.shli       s20, s1, #32
    s.sub        s1, s21, s16
    s.or         s21, s17, s18
    v.extract    s17, v11, #1
    s.or         s18, s19, s20
    s.mul        s19, s17, s1
    v.extract    s1, v11, #2
    s.sub        s17, s21, s18
    s.add        s20, s15, s14
    v.movi       v13, #0
    v.extract    s14, v7, #3
    v.movi       v14, #0
    v.extract    s15, v9, #3
    s.mul        s21, s1, s17
    v.extract    s1, v5, #3
    s.shli       s17, s15, #32
    s.shli       s15, s1, #32
    s.or         s1, s14, s17
    v.extract    s14, v4, #3
    s.add        s17, s16, s19
    s.or         s16, s14, s15
    s.lshri      s14, s20, #32
    v.extract    s15, v11, #3
    s.sub        s19, s1, s16
    v.insert     v13, s20, #0
    v.extract    s1, v7, #4
    v.insert     v14, s14, #0
    v.extract    s14, v9, #4
    s.mul        s20, s15, s19
    v.extract    s15, v5, #4
    s.shli       s19, s14, #32
    s.shli       s14, s15, #32
    s.or         s15, s1, s19
    v.extract    s1, v4, #4
    s.add        s19, s18, s21
    s.or         s18, s1, s14
    s.lshri      s1, s17, #32
    v.extract    s14, v11, #4
    s.sub        s21, s15, s18
    v.insert     v13, s17, #1
    v.extract    s15, v7, #5
    v.insert     v14, s1, #1
    v.extract    s1, v9, #5
    s.mul        s17, s14, s21
    v.extract    s14, v5, #5
    s.shli       s21, s1, #32
    s.shli       s1, s14, #32
    s.or         s14, s15, s21
    v.extract    s15, v4, #5
    s.add        s21, s16, s20
    s.or         s16, s15, s1
    s.lshri      s1, s19, #32
    v.extract    s15, v11, #5
    s.sub        s20, s14, s16
    v.insert     v13, s19, #2
    v.extract    s14, v7, #6
    v.insert     v14, s1, #2
    v.extract    s1, v9, #6
    s.mul        s19, s15, s20
    v.extract    s15, v5, #6
    s.shli       s20, s1, #32
    s.shli       s1, s15, #32
    s.or         s15, s14, s20
    v.extract    s14, v4, #6
    s.add        s20, s18, s17
    s.or         s17, s14, s1
    s.lshri      s1, s21, #32
    v.extract    s14, v11, #6
    s.sub        s18, s15, s17
    v.insert     v13, s21, #3
    v.extract    s15, v7, #7
    v.insert     v14, s1, #3
    v.extract    s1, v9, #7
    s.mul        s21, s14, s18
    v.extract    s14, v5, #7
    s.shli       s18, s1, #32
    s.shli       s1, s14, #32
    s.or         s14, s15, s18
    v.extract    s15, v4, #7
    s.add        s18, s16, s19
    s.or         s16, s15, s1
    s.lshri      s1, s20, #32
    v.extract    s15, v11, #7
    s.sub        s19, s14, s16
    v.insert     v13, s20, #4
    v.extract    s14, v7, #8
    v.insert     v14, s1, #4
    v.extract    s1, v9, #8
    s.mul        s20, s15, s19
    v.extract    s15, v5, #8
    s.shli       s19, s1, #32
    s.shli       s1, s15, #32
    s.or         s15, s14, s19
    v.extract    s14, v4, #8
    s.add        s19, s17, s21
    s.or         s17, s14, s1
    s.lshri      s1, s18, #32
    v.extract    s14, v11, #8
    s.sub        s21, s15, s17
    v.insert     v13, s18, #5
    v.extract    s15, v7, #9
    v.insert     v14, s1, #5
    v.extract    s1, v9, #9
    s.mul        s18, s14, s21
    v.extract    s14, v5, #9
    s.shli       s21, s1, #32
    s.shli       s1, s14, #32
    s.or         s14, s15, s21
    v.extract    s15, v4, #9
    s.add        s21, s16, s20
    s.or         s16, s15, s1
    s.lshri      s1, s19, #32
    v.extract    s15, v11, #9
    s.sub        s20, s14, s16
    v.insert     v13, s19, #6
    v.extract    s14, v7, #10
    v.insert     v14, s1, #6
    v.extract    s1, v9, #10
    s.mul        s19, s15, s20
    v.extract    s15, v5, #10
    s.shli       s20, s1, #32
    s.shli       s1, s15, #32
    s.or         s15, s14, s20
    v.extract    s14, v4, #10
    s.add        s20, s17, s18
    s.or         s17, s14, s1
    s.lshri      s1, s21, #32
    v.extract    s14, v11, #10
    s.sub        s18, s15, s17
    v.insert     v13, s21, #7
    v.extract    s15, v7, #11
    v.insert     v14, s1, #7
    v.extract    s1, v9, #11
    s.mul        s21, s14, s18
    v.extract    s14, v5, #11
    s.shli       s18, s1, #32
    s.shli       s1, s14, #32
    s.or         s14, s15, s18
    v.extract    s15, v4, #11
    s.add        s18, s16, s19
    s.or         s16, s15, s1
    s.lshri      s1, s20, #32
    v.extract    s15, v11, #11
    s.sub        s19, s14, s16
    v.insert     v13, s20, #8
    v.extract    s14, v7, #12
    v.insert     v14, s1, #8
    v.extract    s1, v9, #12
    s.mul        s20, s15, s19
    v.extract    s15, v5, #12
    s.shli       s19, s1, #32
    s.shli       s1, s15, #32
    s.or         s15, s14, s19
    v.extract    s14, v4, #12
    s.add        s19, s17, s21
    s.or         s17, s14, s1
    s.lshri      s1, s18, #32
    v.extract    s14, v11, #12
    s.sub        s21, s15, s17
    v.insert     v13, s18, #9
    v.extract    s15, v7, #13
    v.insert     v14, s1, #9
    v.extract    s1, v9, #13
    s.mul        s18, s14, s21
    v.extract    s14, v5, #13
    s.shli       s21, s1, #32
    s.shli       s1, s14, #32
    s.or         s14, s15, s21
    v.extract    s15, v4, #13
    s.add        s21, s16, s20
    s.or         s16, s15, s1
    s.lshri      s1, s19, #32
    v.extract    s15, v11, #13
    s.sub        s20, s14, s16
    v.insert     v13, s19, #10
    v.extract    s14, v7, #14
    v.insert     v14, s1, #10
    v.extract    s1, v9, #14
    s.mul        s19, s15, s20
    v.extract    s15, v5, #14
    s.shli       s20, s1, #32
    s.shli       s1, s15, #32
    s.or         s15, s14, s20
    v.extract    s14, v4, #14
    s.add        s20, s17, s18
    s.or         s17, s14, s1
    s.lshri      s1, s21, #32
    v.extract    s14, v11, #14
    s.sub        s18, s15, s17
    v.insert     v13, s21, #11
    v.extract    s15, v7, #15
    v.insert     v14, s1, #11
    v.extract    s1, v9, #15
    s.mul        s21, s14, s18
    v.extract    s14, v5, #15
    s.shli       s18, s1, #32
    s.shli       s1, s14, #32
    s.or         s14, s15, s18
    v.extract    s15, v4, #15
    s.add        s18, s16, s19
    s.or         s16, s15, s1
    s.lshri      s1, s20, #32
    v.extract    s15, v11, #15
    s.sub        s19, s14, s16
    v.insert     v13, s20, #12
    v.insert     v14, s1, #12
    s.mul        s1, s15, s19
    s.lshri      s14, s18, #32
    s.add        s15, s17, s21
    v.insert     v13, s18, #13
    v.insert     v14, s14, #13
    s.lshri      s14, s15, #32
    s.add        s17, s16, s1
    v.insert     v13, s15, #14
    v.insert     v14, s14, #14
    s.lshri      s1, s17, #32
    v.insert     v13, s17, #15
    v.insert     v14, s1, #15
    s.movz       s1, #0
    v.extract    s14, v13, #0
    v.extract    s15, v14, #0
    v.extract    s16, v14, #1
    s.shli       s17, s15, #32
    v.movi       v7, #0
    s.or         s15, s14, s17
    v.extract    s14, v13, #1
    s.shli       s17, s16, #32
    s.cmp.ge     s16, s15, s1
    v.extract    s1, v14, #2
    s.or         s15, s14, s17
    s.movz       s14, #0
    v.insert     v7, s16, #0
    v.extract    s16, v13, #2
    s.shli       s17, s1, #32
    s.cmp.ge     s1, s15, s14
    v.extract    s14, v14, #3
    s.or         s15, s16, s17
    s.movz       s16, #0
    v.insert     v7, s1, #1
    v.extract    s1, v13, #3
    s.shli       s17, s14, #32
    s.cmp.ge     s14, s15, s16
    v.extract    s15, v14, #4
    s.or         s16, s1, s17
    s.movz       s1, #0
    v.insert     v7, s14, #2
    v.extract    s14, v13, #4
    s.shli       s17, s15, #32
    s.cmp.ge     s15, s16, s1
    v.extract    s1, v14, #5
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v7, s15, #3
    v.extract    s15, v13, #5
    s.shli       s17, s1, #32
    s.cmp.ge     s1, s16, s14
    v.extract    s14, v14, #6
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v7, s1, #4
    v.extract    s1, v13, #6
    s.shli       s17, s14, #32
    s.cmp.ge     s14, s16, s15
    v.extract    s15, v14, #7
    s.or         s16, s1, s17
    s.movz       s1, #0
    v.insert     v7, s14, #5
    v.extract    s14, v13, #7
    s.shli       s17, s15, #32
    s.cmp.ge     s15, s16, s1
    v.extract    s1, v14, #8
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v7, s15, #6
    v.extract    s15, v13, #8
    s.shli       s17, s1, #32
    s.cmp.ge     s1, s16, s14
    v.extract    s14, v14, #9
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v7, s1, #7
    v.extract    s1, v13, #9
    s.shli       s17, s14, #32
    s.cmp.ge     s14, s16, s15
    v.extract    s15, v14, #10
    s.or         s16, s1, s17
    s.movz       s1, #0
    v.insert     v7, s14, #8
    v.extract    s14, v13, #10
    s.shli       s17, s15, #32
    s.cmp.ge     s15, s16, s1
    v.extract    s1, v14, #11
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v7, s15, #9
    v.extract    s15, v13, #11
    s.shli       s17, s1, #32
    s.cmp.ge     s1, s16, s14
    v.extract    s14, v14, #12
    s.or         s16, s15, s17
    s.movz       s15, #0
    v.insert     v7, s1, #10
    v.extract    s1, v13, #12
    s.shli       s17, s14, #32
    s.cmp.ge     s14, s16, s15
    v.extract    s15, v14, #13
    s.or         s16, s1, s17
    s.movz       s1, #0
    v.insert     v7, s14, #11
    v.extract    s14, v13, #13
    s.shli       s17, s15, #32
    s.cmp.ge     s15, s16, s1
    v.extract    s1, v14, #14
    s.or         s16, s14, s17
    s.movz       s14, #0
    v.insert     v7, s15, #12
    v.extract    s15, v13, #14
    s.shli       s17, s1, #32
    s.cmp.ge     s1, s16, s14
    v.extract    s14, v14, #15
    v.extract    s16, v14, #0
    s.or         s18, s15, s17
    s.movz       s15, #0
    v.insert     v7, s1, #13
    v.extract    s1, v13, #15
    s.shli       s17, s14, #32
    v.extract    s14, v13, #0
    s.shli       s19, s16, #32
    s.cmp.ge     s16, s18, s15
    v.extract    s15, v14, #1
    s.or         s18, s1, s17
    s.movz       s1, #0
    s.or         s17, s14, s19
    s.movz       s14, #576
    v.insert     v7, s16, #14
    v.movi       v9, #0
    v.extract    s16, v13, #1
    s.shli       s19, s15, #32
    s.cmp.ge     s15, s18, s1
    s.cmp.lt     s1, s17, s14
    v.extract    s14, v14, #2
    s.or         s17, s16, s19
    s.movz       s16, #576
    v.insert     v7, s15, #15
    v.insert     v9, s1, #0
    v.extract    s1, v13, #2
    s.shli       s15, s14, #32
    s.cmp.lt     s14, s17, s16
    v.extract    s16, v14, #3
    s.or         s17, s1, s15
    s.movz       s1, #576
    v.insert     v9, s14, #1
    v.extract    s14, v13, #3
    s.shli       s15, s16, #32
    s.cmp.lt     s16, s17, s1
    v.extract    s1, v14, #4
    s.or         s17, s14, s15
    s.movz       s14, #576
    v.insert     v9, s16, #2
    v.extract    s15, v13, #4
    s.shli       s16, s1, #32
    s.cmp.lt     s1, s17, s14
    v.extract    s14, v14, #5
    s.or         s17, s15, s16
    s.movz       s15, #576
    v.insert     v9, s1, #3
    v.extract    s1, v13, #5
    s.shli       s16, s14, #32
    s.cmp.lt     s14, s17, s15
    v.extract    s15, v14, #6
    s.or         s17, s1, s16
    s.movz       s1, #576
    v.insert     v9, s14, #4
    v.extract    s14, v13, #6
    s.shli       s16, s15, #32
    s.cmp.lt     s15, s17, s1
    v.movi       v11, #0
    s.or         s1, s14, s16
    v.insert     v9, s15, #5
    v.cmp.ne     p2, v7, v11
    v.extract    s14, v14, #7
    s.movz       s15, #576
    v.extract    s16, v13, #7
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s1, s15
    v.extract    s1, v14, #8
    s.or         s15, s16, s17
    s.movz       s16, #576
    v.insert     v9, s14, #6
    v.extract    s14, v13, #8
    s.shli       s17, s1, #32
    s.cmp.lt     s1, s15, s16
    v.extract    s15, v14, #9
    s.or         s16, s14, s17
    s.movz       s14, #576
    v.insert     v9, s1, #7
    v.extract    s1, v13, #9
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s16, s14
    v.extract    s14, v14, #10
    s.or         s16, s1, s17
    s.movz       s1, #576
    v.insert     v9, s15, #8
    v.extract    s15, v13, #10
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s16, s1
    v.extract    s1, v14, #11
    s.or         s16, s15, s17
    s.movz       s15, #576
    v.insert     v9, s14, #9
    v.extract    s14, v13, #11
    s.shli       s17, s1, #32
    s.cmp.lt     s1, s16, s15
    v.extract    s15, v14, #12
    s.or         s16, s14, s17
    s.movz       s14, #576
    v.insert     v9, s1, #10
    v.extract    s1, v13, #12
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s16, s14
    v.extract    s14, v14, #13
    s.or         s16, s1, s17
    s.movz       s1, #576
    v.insert     v9, s15, #11
    v.extract    s15, v13, #13
    s.shli       s17, s14, #32
    s.cmp.lt     s14, s16, s1
    v.extract    s1, v14, #14
    s.or         s16, s15, s17
    s.movz       s15, #576
    v.insert     v9, s14, #12
    v.extract    s14, v13, #14
    s.shli       s17, s1, #32
    s.cmp.lt     s1, s16, s15
    v.extract    s15, v14, #15
    s.or         s16, s14, s17
    s.movz       s14, #576
    v.insert     v9, s1, #13
    v.extract    s1, v13, #15
    s.shli       s17, s15, #32
    s.cmp.lt     s15, s16, s14
    s.or         s14, s1, s17
    s.movz       s1, #576
    v.insert     v9, s15, #14
    s.cmp.lt     s15, s14, s1
    v.movi       v7, #0
    v.insert     v9, s15, #15
    v.movi       v11, #0
    v.movi       v15, #1
    v.cmp.ne     p3, v9, v7
    p.and        p4, p2, p3
    s.movz       s1, #0
    @p4 v.sel        v7, v11, v15
    v.reduce.or  s14, v7
    s.cmp.eq     s15, s14, s1
    br.nz        s15, assert_ok_5
    trap         #677351
assert_ok_5:
    v.extract    s1, v14, #0
    v.extract    s14, v13, #0
    s.shli       s15, s1, #32
    v.extract    s1, v14, #1
    s.or         s16, s14, s15
    s.movz       s14, #64
    v.extract    s15, v13, #1
    s.shli       s17, s1, #32
    s.mul        s1, s16, s14
    v.extract    s14, v14, #2
    s.or         s16, s15, s17
    s.movz       s15, #64
    v.extract    s17, v13, #2
    s.shli       s18, s14, #32
    s.mul        s14, s16, s15
    v.extract    s15, v14, #3
    v.movi       v7, #0
    v.movi       v9, #0
    s.or         s16, s17, s18
    s.movz       s17, #64
    s.lshri      s18, s1, #32
    v.extract    s19, v13, #3
    s.shli       s20, s15, #32
    s.mul        s15, s16, s17
    v.extract    s16, v14, #4
    v.insert     v7, s1, #0
    v.insert     v9, s18, #0
    s.or         s1, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s14, #32
    v.extract    s19, v13, #4
    s.shli       s20, s16, #32
    s.mul        s16, s1, s17
    v.extract    s1, v14, #5
    v.insert     v7, s14, #1
    v.insert     v9, s18, #1
    s.or         s14, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s15, #32
    v.extract    s19, v13, #5
    s.shli       s20, s1, #32
    s.mul        s1, s14, s17
    v.extract    s14, v14, #6
    v.insert     v7, s15, #2
    v.insert     v9, s18, #2
    s.or         s15, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s16, #32
    v.extract    s19, v13, #6
    s.shli       s20, s14, #32
    s.mul        s14, s15, s17
    v.extract    s15, v14, #7
    v.insert     v7, s16, #3
    v.insert     v9, s18, #3
    s.or         s16, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s1, #32
    v.extract    s19, v13, #7
    s.shli       s20, s15, #32
    s.mul        s15, s16, s17
    v.extract    s16, v14, #8
    v.insert     v7, s1, #4
    v.insert     v9, s18, #4
    s.or         s1, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s14, #32
    v.extract    s19, v13, #8
    s.shli       s20, s16, #32
    s.mul        s16, s1, s17
    v.extract    s1, v14, #9
    v.insert     v7, s14, #5
    v.insert     v9, s18, #5
    s.or         s14, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s15, #32
    v.extract    s19, v13, #9
    s.shli       s20, s1, #32
    s.mul        s1, s14, s17
    v.extract    s14, v14, #10
    v.insert     v7, s15, #6
    v.insert     v9, s18, #6
    s.or         s15, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s16, #32
    v.extract    s19, v13, #10
    s.shli       s20, s14, #32
    s.mul        s14, s15, s17
    v.extract    s15, v14, #11
    v.insert     v7, s16, #7
    v.insert     v9, s18, #7
    s.or         s16, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s1, #32
    v.extract    s19, v13, #11
    s.shli       s20, s15, #32
    s.mul        s15, s16, s17
    v.extract    s16, v14, #12
    v.insert     v7, s1, #8
    v.insert     v9, s18, #8
    s.or         s1, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s14, #32
    v.extract    s19, v13, #12
    s.shli       s20, s16, #32
    s.mul        s16, s1, s17
    v.extract    s1, v14, #13
    v.insert     v7, s14, #9
    v.insert     v9, s18, #9
    s.or         s14, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s15, #32
    v.extract    s19, v13, #13
    s.shli       s20, s1, #32
    s.mul        s1, s14, s17
    v.extract    s14, v14, #14
    v.insert     v7, s15, #10
    v.insert     v9, s18, #10
    s.or         s15, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s16, #32
    v.extract    s19, v13, #14
    s.shli       s20, s14, #32
    s.mul        s14, s15, s17
    v.extract    s15, v14, #15
    v.insert     v7, s16, #11
    v.insert     v9, s18, #11
    s.or         s16, s19, s20
    s.movz       s17, #64
    s.lshri      s18, s1, #32
    v.extract    s19, v13, #15
    s.shli       s20, s15, #32
    s.mul        s15, s16, s17
    v.insert     v7, s1, #12
    v.insert     v9, s18, #12
    s.or         s1, s19, s20
    s.movz       s16, #64
    s.lshri      s17, s14, #32
    v.extract    s18, v10, #0
    s.mul        s19, s1, s16
    v.insert     v7, s14, #13
    v.insert     v9, s17, #13
    s.shli       s1, s18, #32
    s.lshri      s14, s15, #32
    v.extract    s16, v10, #1
    s.ashri      s17, s1, #32
    v.insert     v7, s15, #14
    v.insert     v9, s14, #14
    v.movi       v11, #0
    v.movi       v13, #0
    s.shli       s1, s16, #32
    s.lshri      s14, s19, #32
    s.lshri      s15, s17, #32
    v.extract    s16, v10, #2
    s.ashri      s18, s1, #32
    v.insert     v7, s19, #15
    v.insert     v9, s14, #15
    v.insert     v11, s17, #0
    v.insert     v13, s15, #0
    s.shli       s1, s16, #32
    s.lshri      s14, s18, #32
    v.extract    s15, v10, #3
    s.ashri      s16, s1, #32
    v.insert     v11, s18, #1
    v.insert     v13, s14, #1
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v10, #4
    s.ashri      s17, s1, #32
    v.insert     v11, s16, #2
    v.insert     v13, s14, #2
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v10, #5
    s.ashri      s16, s1, #32
    v.insert     v11, s17, #3
    v.insert     v13, s14, #3
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v10, #6
    s.ashri      s17, s1, #32
    v.insert     v11, s16, #4
    v.insert     v13, s14, #4
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v10, #7
    s.ashri      s16, s1, #32
    v.insert     v11, s17, #5
    v.insert     v13, s14, #5
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v10, #8
    s.ashri      s17, s1, #32
    v.insert     v11, s16, #6
    v.insert     v13, s14, #6
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v10, #9
    s.ashri      s16, s1, #32
    v.insert     v11, s17, #7
    v.insert     v13, s14, #7
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v10, #10
    s.ashri      s17, s1, #32
    v.insert     v11, s16, #8
    v.insert     v13, s14, #8
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v10, #11
    s.ashri      s16, s1, #32
    v.insert     v11, s17, #9
    v.insert     v13, s14, #9
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v10, #12
    s.ashri      s17, s1, #32
    v.insert     v11, s16, #10
    v.insert     v13, s14, #10
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v10, #13
    s.ashri      s16, s1, #32
    v.insert     v11, s17, #11
    v.insert     v13, s14, #11
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    v.extract    s15, v10, #14
    s.ashri      s17, s1, #32
    v.insert     v11, s16, #12
    v.insert     v13, s14, #12
    s.shli       s1, s15, #32
    s.lshri      s14, s17, #32
    v.extract    s15, v10, #15
    s.ashri      s16, s1, #32
    v.insert     v11, s17, #13
    v.insert     v13, s14, #13
    s.shli       s1, s15, #32
    s.lshri      s14, s16, #32
    s.ashri      s15, s1, #32
    v.insert     v11, s16, #14
    v.insert     v13, s14, #14
    s.lshri      s1, s15, #32
    v.insert     v11, s15, #15
    v.insert     v13, s1, #15
    v.extract    s1, v9, #0
    v.extract    s14, v11, #0
    v.extract    s15, v13, #0
    v.extract    s16, v7, #0
    s.shli       s17, s15, #32
    s.shli       s15, s1, #32
    v.extract    s1, v13, #1
    v.extract    s18, v9, #1
    s.or         s19, s14, s17
    s.or         s14, s16, s15
    v.movi       v10, #0
    v.extract    s15, v11, #1
    s.shli       s16, s1, #32
    v.extract    s1, v7, #1
    s.shli       s17, s18, #32
    s.add        s18, s19, s14
    v.extract    s14, v13, #2
    v.extract    s19, v9, #2
    s.or         s20, s15, s16
    s.or         s15, s1, s17
    v.movi       v14, #0
    v.insert     v10, s18, #0
    v.extract    s1, v11, #2
    s.shli       s16, s14, #32
    v.extract    s14, v7, #2
    s.shli       s17, s19, #32
    s.lshri      s19, s18, #32
    s.add        s18, s20, s15
    v.extract    s15, v13, #3
    s.or         s20, s1, s16
    v.extract    s1, v9, #3
    s.or         s16, s14, s17
    v.insert     v14, s19, #0
    v.insert     v10, s18, #1
    v.extract    s14, v11, #3
    s.shli       s17, s15, #32
    v.extract    s15, v7, #3
    s.shli       s19, s1, #32
    s.lshri      s1, s18, #32
    s.add        s18, s20, s16
    v.extract    s16, v13, #4
    s.or         s20, s14, s17
    v.extract    s14, v9, #4
    s.or         s17, s15, s19
    v.insert     v14, s1, #1
    v.insert     v10, s18, #2
    v.extract    s1, v11, #4
    s.shli       s15, s16, #32
    v.extract    s16, v7, #4
    s.shli       s19, s14, #32
    s.lshri      s14, s18, #32
    s.add        s18, s20, s17
    v.extract    s17, v13, #5
    s.or         s20, s1, s15
    v.extract    s1, v9, #5
    s.or         s15, s16, s19
    v.insert     v14, s14, #2
    v.insert     v10, s18, #3
    v.extract    s14, v11, #5
    s.shli       s16, s17, #32
    v.extract    s17, v7, #5
    s.shli       s19, s1, #32
    s.lshri      s1, s18, #32
    s.add        s18, s20, s15
    v.extract    s15, v13, #6
    s.or         s20, s14, s16
    v.extract    s14, v9, #6
    s.or         s16, s17, s19
    v.insert     v14, s1, #3
    v.insert     v10, s18, #4
    v.extract    s1, v11, #6
    s.shli       s17, s15, #32
    v.extract    s15, v7, #6
    s.shli       s19, s14, #32
    s.lshri      s14, s18, #32
    s.add        s18, s20, s16
    v.extract    s16, v13, #7
    s.or         s20, s1, s17
    v.extract    s1, v9, #7
    s.or         s17, s15, s19
    v.insert     v14, s14, #4
    v.insert     v10, s18, #5
    v.extract    s14, v11, #7
    s.shli       s15, s16, #32
    v.extract    s16, v7, #7
    s.shli       s19, s1, #32
    s.lshri      s1, s18, #32
    s.add        s18, s20, s17
    v.extract    s17, v13, #8
    s.or         s20, s14, s15
    v.extract    s14, v9, #8
    s.or         s15, s16, s19
    v.insert     v14, s1, #5
    v.insert     v10, s18, #6
    v.extract    s1, v11, #8
    s.shli       s16, s17, #32
    v.extract    s17, v7, #8
    s.shli       s19, s14, #32
    s.lshri      s14, s18, #32
    s.add        s18, s20, s15
    v.extract    s15, v13, #9
    s.or         s20, s1, s16
    v.extract    s1, v9, #9
    s.or         s16, s17, s19
    v.insert     v14, s14, #6
    v.insert     v10, s18, #7
    v.extract    s14, v11, #9
    s.shli       s17, s15, #32
    v.extract    s15, v7, #9
    s.shli       s19, s1, #32
    s.lshri      s1, s18, #32
    s.add        s18, s20, s16
    v.extract    s16, v13, #10
    s.or         s20, s14, s17
    v.extract    s14, v9, #10
    s.or         s17, s15, s19
    v.insert     v14, s1, #7
    v.insert     v10, s18, #8
    v.extract    s1, v11, #10
    s.shli       s15, s16, #32
    v.extract    s16, v7, #10
    s.shli       s19, s14, #32
    s.lshri      s14, s18, #32
    s.add        s18, s20, s17
    v.extract    s17, v13, #11
    s.or         s20, s1, s15
    v.extract    s1, v9, #11
    s.or         s15, s16, s19
    v.insert     v14, s14, #8
    v.insert     v10, s18, #9
    v.extract    s14, v11, #11
    s.shli       s16, s17, #32
    v.extract    s17, v7, #11
    s.shli       s19, s1, #32
    s.lshri      s1, s18, #32
    s.add        s18, s20, s15
    v.extract    s15, v13, #12
    s.or         s20, s14, s16
    v.extract    s14, v9, #12
    s.or         s16, s17, s19
    v.insert     v14, s1, #9
    v.insert     v10, s18, #10
    v.extract    s1, v11, #12
    s.shli       s17, s15, #32
    v.extract    s15, v7, #12
    s.shli       s19, s14, #32
    s.lshri      s14, s18, #32
    s.add        s18, s20, s16
    v.extract    s16, v13, #13
    s.or         s20, s1, s17
    v.extract    s1, v9, #13
    s.or         s17, s15, s19
    v.insert     v14, s14, #10
    v.insert     v10, s18, #11
    v.extract    s14, v11, #13
    s.shli       s15, s16, #32
    v.extract    s16, v7, #13
    s.shli       s19, s1, #32
    s.lshri      s1, s18, #32
    s.add        s18, s20, s17
    v.extract    s17, v13, #14
    s.or         s20, s14, s15
    v.extract    s14, v9, #14
    s.or         s15, s16, s19
    v.insert     v14, s1, #11
    v.insert     v10, s18, #12
    v.extract    s1, v11, #14
    s.shli       s16, s17, #32
    v.extract    s17, v7, #14
    s.shli       s19, s14, #32
    s.lshri      s14, s18, #32
    s.add        s18, s20, s15
    v.extract    s15, v13, #15
    s.or         s20, s1, s16
    v.extract    s1, v9, #15
    s.or         s16, s17, s19
    v.insert     v14, s14, #12
    v.insert     v10, s18, #13
    v.extract    s14, v11, #15
    s.shli       s17, s15, #32
    v.extract    s15, v7, #15
    s.shli       s19, s1, #32
    s.lshri      s1, s18, #32
    s.add        s18, s20, s16
    s.or         s16, s14, s17
    s.or         s14, s15, s19
    v.insert     v14, s1, #13
    v.insert     v10, s18, #14
    s.lshri      s1, s18, #32
    s.add        s15, s16, s14
    v.insert     v14, s1, #14
    v.insert     v10, s15, #15
    v.movi       v7, #31
    s.lshri      s1, s15, #32
    v.movi       v9, #1
    v.insert     v14, s1, #15
    v.ashr       v11, v10, v7
    v.movi       v7, #0
    s.movz       s1, #0
    v.cmp.ne     p2, v14, v11
    @p2 v.sel        v11, v9, v7
    v.reduce.or  s14, v11
    s.cmp.eq     s15, s14, s1
    br.nz        s15, narrow_ok_6
    trap         #677220
narrow_ok_6:
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v7, [s6, v10]              // index is in elements (ISA sec 9.1)
    v.movi       v9, #31
    v.movi       v11, #1
    v.movi       v13, #0
    v.ashr       v15, v10, v9
    s.movz       s1, #0
    v.cmp.ne     p2, v14, v15
    @p2 v.sel        v9, v11, v13
    v.reduce.or  s14, v9
    s.cmp.eq     s15, s14, s1
    vf.cvt.f16.f32 v9, v7
    vf.mul       v7, v12, v9
    br.nz        s15, narrow_ok_7
    trap         #677220
narrow_ok_7:
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v9, [s8, v10]              // index is in elements (ISA sec 9.1)
    .li       s1, #1052050675
    v.splat      v10, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v11, #0
    s.add        s1, s13, s12
    vf.mul       v12, v0, v10
    s.movz       s14, #1
    vf.cvt.f16.f32 v0, v9
    vf.mul       v9, v1, v0
    vf.add       v0, v7, v9
    vf.mul       v1, v0, v10
    vf.mul       v0, v1, v12
    vf.add       v1, v6, v0
    @p1 v.sel        v0, v1, v6
    v.mov        v11, v0
    v.mov        v6, v11
    s.mov        s13, s1
    br.nz        s14, for_3
endfor_4:
    vf.reduce.add.b v0, v6
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s11, s2, #2                     // element offset -> bytes (x4)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s10, s11                    // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    s.addi       s1, s2, #4                      // the next program of this context: + 4
    s.cmp.lt     s11, s1, s4
    s.mov        s2, s1
    br.nz        s11, __rctx_program
    exit
