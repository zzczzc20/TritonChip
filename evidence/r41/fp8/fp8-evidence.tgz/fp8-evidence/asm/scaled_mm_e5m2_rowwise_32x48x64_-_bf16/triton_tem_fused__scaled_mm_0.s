    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // out_ptr0: device_ptr64 at arg_base+32
    s.rdspecial  s1, arg_base
    s.ld.d       s8, [s1, #40]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s9, #512
    s.mul        s10, s1, s9
    s.add        s1, s8, s10                     // this context's own scratch
    s.addi       s8, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s8, #0], s2
    .li       s1, #2147483647
    s.st.d       [s8, #8], s1
    .li       s1, #2147483647
    s.st.d       [s8, #16], s1
    s.movz       s1, #64
    s.st.d       [s8, #48], s1
    s.movz       s1, #1
    s.st.d       [s8, #56], s1
    .li       s1, #68719476752
    s.st.d       [s8, #88], s1
    .li       s1, #8804682956800
    s.st.d       [s8, #104], s1
    fence.release.device
    td.load      d0, [s8]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #3
    s.movz       s2, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.movz       s10, #0
    s.cmp.lt     s11, s1, s10
    s.sub        s10, s9, s11
    s.xor        s9, s1, s10
    s.sub        s11, s9, s10
    .li       s9, #1431655766
    s.movz       s11, #2
    s.movz       s12, #1
    s.movz       s13, #0
    s.movz       s14, #0
    s.movz       s15, #0
    s.movz       s16, #0
    s.movz       s17, #0
    s.movz       s18, #0
    s.movz       s19, #1
    s.cmp.lt     s20, s4, s8
    s.sub        s8, s2, s20
    s.xor        s2, s4, s8
    s.sub        s20, s2, s8
    s.mul        s2, s20, s9
    s.lshri      s9, s2, #32
    s.sub        s2, s20, s9
    s.lshri      s21, s2, #1
    s.add        s2, s9, s21
    s.lshri      s9, s2, #1
    s.muli       s2, s9, #3
    s.sub        s21, s20, s2
    s.xor        s2, s8, s10
    s.xor        s8, s9, s2
    s.sub        s9, s8, s2
    s.sub        s2, s11, s9
    s.min.s      s8, s2, s12
    s.cmp.lt     s2, s4, s14
    s.sub        s10, s13, s2
    s.cmp.lt     s2, s8, s16
    s.sub        s11, s15, s2
    s.xor        s2, s4, s10
    s.sub        s13, s2, s10
    s.xor        s2, s8, s11
    s.sub        s14, s2, s11
    s.addi       s2, s17, #0
    s.addi       s11, s18, #0
    s.cmp.eq     s15, s14, s19
    s.mov        s2, s13
    br.nz        s15, sdiv_done_1
    s.movz       s15, #0
    s.movz       s16, #31
    s.mov        s2, s15
    s.addi       s15, s16, #0
sdiv_2:
    s.lshr       s16, s13, s15
    s.shli       s17, s11, #1
    s.andi       s18, s16, #1
    s.movz       s16, #0
    s.or         s19, s17, s18
    s.movz       s17, #1
    s.cmp.geu    s18, s19, s14
    s.shl        s20, s17, s15
    s.sub        s17, s16, s18
    s.subi       s16, s15, #1
    s.and        s18, s14, s17
    s.and        s21, s20, s17
    s.sub        s17, s19, s18
    s.or         s18, s2, s21
    s.mov        s11, s17
    s.mov        s2, s18
    s.mov        s15, s16
    s.movz       s16, #0
    s.cmp.ge     s17, s15, s16
    br.nz        s17, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.movz       s13, #0
    s.cmp.lt     s14, s4, s2
    .li       s2, #1431655766
    s.sub        s15, s13, s14
    s.movz       s13, #0
    s.xor        s14, s4, s15
    s.movz       s4, #0
    s.sub        s16, s14, s15
    s.movz       s14, #0
    s.mul        s17, s16, s2
    s.cmp.lt     s2, s8, s13
    s.movz       s13, #0
    s.sub        s18, s14, s2
    s.movz       s2, #0
    s.lshri      s14, s17, #32
    s.cmp.lt     s17, s1, s13
    s.xor        s13, s8, s18
    s.xor        s8, s11, s10
    s.sub        s11, s13, s18
    s.sub        s13, s8, s10
    s.sub        s8, s16, s14
    s.add        s10, s9, s13
    s.lshri      s9, s8, #1
    s.movz       s8, #0
    s.add        s13, s14, s9
    s.sub        s9, s8, s17
    s.lshri      s8, s13, #1
    s.movz       s13, #0
    s.muli       s14, s8, #3
    s.movz       s8, #1
    s.xor        s17, s1, s9
    s.addi       s1, s13, #0
    s.cmp.eq     s13, s11, s8
    s.sub        s8, s16, s14
    s.movz       s14, #0
    s.xor        s16, s8, s15
    s.sub        s8, s17, s9
    s.sub        s8, s16, s15
    s.addi       s9, s14, #0
    s.cmp.lt     s14, s8, s4
    s.sub        s4, s2, s14
    s.xor        s2, s8, s4
    s.sub        s8, s2, s4
    s.mov        s1, s8
    br.nz        s13, sdiv_done_3
    s.movz       s2, #0
    s.movz       s13, #31
    s.mov        s1, s2
    s.addi       s2, s13, #0
sdiv_4:
    s.lshr       s13, s8, s2
    s.shli       s14, s9, #1
    s.andi       s15, s13, #1
    s.movz       s13, #0
    s.or         s16, s14, s15
    s.movz       s14, #1
    s.cmp.geu    s15, s16, s11
    s.shl        s17, s14, s2
    s.sub        s14, s13, s15
    s.subi       s13, s2, #1
    s.and        s15, s11, s14
    s.and        s19, s17, s14
    s.sub        s14, s16, s15
    s.or         s15, s1, s19
    s.mov        s9, s14
    s.mov        s1, s15
    s.mov        s2, s13
    s.movz       s13, #0
    s.cmp.ge     s14, s2, s13
    br.nz        s14, sdiv_4
sdiv_done_3:
    s.xor        s2, s4, s18
    s.movz       s4, #16
    s.xor        s8, s1, s2
    .li       s1, #1431655766
    s.sub        s9, s8, s2
    s.mul        s2, s10, s4
    s.mul        s8, s9, s4
    s.movz       s11, #0
    v.splat      v0, s10
    v.splat      v1, s11
    s.andi       s10, s2, #31
    s.mul        s13, s8, s1
    v.splat      v2, s9
    v.splat      v3, s11
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s2
    s.lshri      s1, s13, #32
    v.cmp.ge     p1, v0, v1
    s.sub        s9, s8, s1
    v.splat      v0, s8
    s.lshri      s13, s9, #1
    v.splat      v1, s10
    s.add        s9, s1, s13
    v.cmp.ge     p1, v2, v3
    s.lshri      s1, s9, #5
    v.iota       v2                              // arange(0, VLEN)
    s.muli       s9, s1, #48
    v.iota       v3                              // arange(0, VLEN)
    v.add        v6, v5, v4
    v.add        v5, v0, v4
    v.add        v0, v1, v2
    s.sub        s1, s8, s9
    s.movz       s9, #4
    v.splat      v0, s1
    s.addi       s13, s11, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    v.add        v1, v0, v3
for_5:
    s.cmp.ge     s11, s13, s9
    br.nz        s11, endfor_6
    s.mul        s11, s13, s4
    s.muli       s14, s1, #64                    // a runtime tile origin, x64
    // repack 16x16 f8E5M2 through memory: there is no v.pack (ISA sec 8.4)
    s.movz       s15, #0
    s.movz       s16, #64
    v.iota       v0                              // arange(0, VLEN)
    s.add        s17, s15, s11                   // the tile origin
    v.splat      v1, s16
    s.add        s15, s17, s14                   // the tile origin
    w.def        w0, #60, #4                     // v60..v63
    mb.arm       s14, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.mul        v2, v0, v1
    v.splat      v0, s15
    s.rdspecial  s16, arg_base
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s17, s10                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s18, s11                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s17, s14
    mb.wait      s14
    s.ld.d       s11, [s16, #40]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.add        v1, v2, v0
    s.rdspecial  s16, role_id
    s.movz       s17, #512
    s.addi       s18, s15, #1
    s.mul        s19, s16, s17
    v.splat      v0, s18
    s.addi       s16, s15, #2
    s.addi       s17, s15, #3
    v.add        v3, v2, v0
    v.splat      v0, s16
    v.ld.gather.b v4, [s3, v1]                   // index is in elements (ISA sec 9.1)
    s.add        s16, s11, s19                   // this context's own scratch
    v.add        v1, v2, v0
    s.addi       s11, s16, #256                  // 256 bytes of repack scratch
    v.splat      v0, s17
    s.addi       s16, s11, #16                   // row 1
    s.addi       s17, s11, #32                   // row 2
    v.add        v5, v2, v0
    s.addi       s18, s15, #4
    s.addi       s19, s11, #48                   // row 3
    v.splat      v0, s18
    s.addi       s18, s15, #5
    v.st.b       [s11, #0], v4
    v.add        v4, v2, v0
    v.splat      v0, s18
    s.addi       s18, s11, #64                   // row 4
    s.addi       s20, s15, #6
    v.add        v6, v2, v0
    s.addi       s21, s11, #80                   // row 5
    s.addi       s22, s15, #7
    v.ld.gather.b v0, [s3, v3]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s16, #0], v0
    v.splat      v0, s20
    s.addi       s16, s11, #96                   // row 6
    s.addi       s20, s15, #8
    v.add        v3, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s17, #0], v0
    v.splat      v0, s22
    s.addi       s17, s11, #112                  // row 7
    s.addi       s22, s15, #9
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v5]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s19, #0], v0
    v.splat      v0, s20
    s.addi       s19, s11, #128                  // row 8
    s.addi       s20, s15, #10
    v.add        v5, v2, v0
    v.ld.gather.b v0, [s3, v4]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s18, #0], v0
    v.splat      v0, s22
    s.addi       s18, s11, #144                  // row 9
    s.addi       s22, s15, #11
    v.add        v4, v2, v0
    v.ld.gather.b v0, [s3, v6]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s21, #0], v0
    v.splat      v0, s20
    s.addi       s20, s11, #160                  // row 10
    s.addi       s21, s15, #12
    v.add        v6, v2, v0
    v.ld.gather.b v0, [s3, v3]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s16, #0], v0
    v.splat      v0, s22
    s.addi       s16, s11, #176                  // row 11
    s.addi       s22, s15, #13
    v.add        v3, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s17, #0], v0
    v.splat      v0, s21
    s.addi       s17, s11, #192                  // row 12
    s.addi       s21, s15, #14
    v.add        v1, v2, v0
    s.addi       s23, s15, #15
    v.ld.gather.b v0, [s3, v5]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s19, #0], v0
    v.splat      v0, s22
    s.addi       s15, s11, #208                  // row 13
    s.addi       s19, s11, #224                  // row 14
    v.add        v5, v2, v0
    v.ld.gather.b v0, [s3, v4]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s18, #0], v0
    v.splat      v0, s21
    s.addi       s18, s11, #240                  // row 15
    s.addi       s21, s11, #64
    v.add        v4, v2, v0
    v.ld.gather.b v0, [s3, v6]                   // index is in elements (ISA sec 9.1)
    s.add        s22, s13, s12
    v.st.b       [s20, #0], v0
    v.splat      v0, s23
    s.addi       s20, s11, #128
    s.addi       s23, s11, #192
    v.add        v6, v2, v0
    v.ld.gather.b v0, [s3, v3]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s16, #0], v0
    s.movz       s16, #1
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s17, #0], v0
    v.ld.gather.b v0, [s3, v5]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s15, #0], v0
    v.ld.gather.b v0, [s3, v4]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s19, #0], v0
    v.ld.gather.b v0, [s3, v6]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s18, #0], v0
    w.def        w1, #56, #4                     // v56..v59
    fence.acq_rel.device
    v.ld.w       v0, [s11, #0]
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s21, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s20, #0]
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s23, #0]
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    mb.arm       s11, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.e5m2 a0, v60, v56, s11
    mb.wait      s11
    s.mov        s13, s22
    br.nz        s16, for_5
endfor_6:
    s.movz       s1, #0
    s.movz       s3, #0
    s.add        s4, s1, s8                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s4
    s.add        s1, s3, s2                      // the tile origin
    s.movz       s3, #32
    s.movz       s4, #48
    s.movz       s9, #0
    v.splat      v2, s1
    v.splat      v3, s3
    v.add        v4, v0, v1
    v.splat      v0, s4
    s.add        s3, s9, s2                      // the tile origin
    v.cmp.lt     p1, v2, v3
    v.splat      v1, s3
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    s.addi       s4, s1, #1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v1]               // index is in elements (ISA sec 9.1)
    v.splat      v1, s4
    s.addi       s4, s3, #1
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s9, #0
    v.splat      v2, s4
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s4, s1, #2
    s.addi       s10, s3, #2
    v.splat      v1, s4
    v.splat      v4, s10
    s.movz       s4, #1
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s10, s1, #3
    s.addi       s12, s3, #3
    v.splat      v1, s10
    v.splat      v5, s12
    a.vwrite     a1, s9, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    s.movz       s9, #2
    p.and        p3, p1, p2
    s.addi       s10, s1, #4
    s.addi       s12, s3, #4
    v.splat      v1, s10
    v.splat      v2, s12
    s.movz       s10, #3
    s.addi       s12, s1, #5
    s.addi       s13, s3, #5
    v.splat      v6, s12
    v.splat      v7, s13
    s.movz       s12, #4
    s.addi       s13, s1, #6
    s.addi       s15, s3, #6
    a.vwrite     a1, s4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v4]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.splat      v1, s13
    v.splat      v4, s15
    s.movz       s4, #5
    s.addi       s13, s1, #7
    s.addi       s15, s3, #7
    a.vwrite     a1, s9, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v6, v3
    p.and        p3, p1, p2
    v.splat      v5, s13
    v.splat      v6, s15
    s.movz       s9, #6
    s.addi       s13, s1, #8
    s.addi       s15, s3, #8
    a.vwrite     a1, s10, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.splat      v1, s13
    v.splat      v2, s15
    s.movz       s10, #7
    s.addi       s13, s1, #9
    s.addi       s15, s3, #9
    a.vwrite     a1, s12, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v7]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.splat      v5, s13
    v.splat      v7, s15
    s.movz       s12, #8
    s.addi       s13, s1, #10
    s.addi       s15, s3, #10
    a.vwrite     a1, s4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v4]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.splat      v1, s13
    v.splat      v4, s15
    s.movz       s4, #9
    s.addi       s13, s1, #11
    s.addi       s15, s3, #11
    a.vwrite     a1, s9, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v6]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.splat      v5, s13
    v.splat      v6, s15
    s.movz       s9, #10
    s.addi       s13, s1, #12
    s.addi       s15, s3, #12
    a.vwrite     a1, s10, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.splat      v1, s13
    v.splat      v2, s15
    s.movz       s10, #11
    s.addi       s13, s1, #13
    s.addi       s15, s3, #13
    a.vwrite     a1, s12, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v7]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.splat      v5, s13
    v.splat      v7, s15
    s.movz       s12, #12
    s.addi       s13, s1, #14
    s.addi       s15, s3, #14
    s.addi       s16, s3, #15
    a.vwrite     a1, s4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v4]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.splat      v1, s13
    v.splat      v4, s15
    s.movz       s3, #13
    s.addi       s4, s1, #15
    s.movz       s13, #14
    a.vwrite     a1, s9, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v6]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.splat      v5, s4
    v.splat      v6, s16
    s.muli       s4, s8, #4                      // a runtime tile origin, x4
    s.movz       s9, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s15, #0
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s16, s8, #2                     // a runtime tile origin, x2
    s.muli       s8, s2, #96                     // a runtime tile origin, x96
    s.add        s2, s6, s4                      // the tile origin
    s.movz       s4, #0
    s.add        s6, s7, s16                     // the tile origin
    s.add        s7, s6, s8                      // the tile origin
    a.vwrite     a1, s10, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v2]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.splat      v1, s1
    v.splat      v2, s1
    a.vwrite     a1, s12, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v7]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    s.addi       s6, s1, #1
    s.movz       s8, #1
    v.splat      v5, s6
    s.movz       s6, #1
    a.vwrite     a1, s3, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v4]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s3, s1, #1
    s.addi       s10, s7, #96                    // row 1
    v.splat      v1, s3
    a.vwrite     a1, s13, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v6]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.addi       s3, s1, #2
    s.movz       s5, #2
    v.splat      v2, s3
    s.movz       s3, #2
    a.vwrite     a1, s9, v0
    a.vread      v0, a0, s15
    a.vread      v4, a1, s4
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v6, [s2, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p4, p1, p2
    s.addi       s4, s1, #2
    s.addi       s9, s1, #3
    v.splat      v5, s4
    s.addi       s4, s7, #192                    // row 2
    s.movz       s12, #3
    s.movz       s13, #3
    vf.mul       v7, v4, v6
    v.splat      v4, s9
    vf.mul       v6, v0, v7
    vf.cvt.f32.bf16 v0, v6
    @p3 v.st.h       [s7, #0], v0
    a.vread      v0, a0, s8
    a.vread      v6, a1, s6
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s6, s1, #3
    s.addi       s8, s7, #288                    // row 3
    v.splat      v1, s6
    s.movz       s6, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s2, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s9, #4
    vf.mul       v2, v6, v7
    vf.mul       v6, v0, v2
    s.addi       s15, s1, #4
    vf.cvt.f32.bf16 v0, v6
    v.splat      v2, s15
    @p3 v.st.h       [s10, #0], v0
    a.vread      v0, a0, s5
    a.vread      v6, a1, s3
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    s.addi       s3, s1, #4
    s.addi       s5, s7, #384                    // row 4
    v.splat      v5, s3
    s.movz       s3, #5
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s2, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.movz       s10, #5
    vf.mul       v4, v6, v7
    vf.mul       v6, v0, v4
    s.addi       s15, s1, #5
    vf.cvt.f32.bf16 v0, v6
    v.splat      v4, s15
    @p3 v.st.h       [s4, #0], v0
    a.vread      v0, a0, s12
    a.vread      v6, a1, s13
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s4, s1, #5
    s.addi       s12, s7, #480                   // row 5
    v.splat      v1, s4
    s.movz       s4, #6
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s2, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s13, #6
    vf.mul       v2, v6, v7
    vf.mul       v6, v0, v2
    s.addi       s15, s1, #6
    vf.cvt.f32.bf16 v0, v6
    v.splat      v2, s15
    @p3 v.st.h       [s8, #0], v0
    a.vread      v0, a0, s6
    a.vread      v6, a1, s9
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    s.addi       s6, s1, #6
    s.addi       s8, s7, #576                    // row 6
    v.splat      v5, s6
    s.movz       s6, #7
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s2, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.movz       s9, #7
    vf.mul       v4, v6, v7
    vf.mul       v6, v0, v4
    s.addi       s15, s1, #7
    vf.cvt.f32.bf16 v0, v6
    v.splat      v4, s15
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s3
    a.vread      v6, a1, s10
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s3, s1, #7
    s.addi       s5, s7, #672                    // row 7
    v.splat      v1, s3
    s.movz       s3, #8
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s2, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s10, #8
    vf.mul       v2, v6, v7
    vf.mul       v6, v0, v2
    s.addi       s15, s1, #8
    vf.cvt.f32.bf16 v0, v6
    v.splat      v2, s15
    @p3 v.st.h       [s12, #0], v0
    a.vread      v0, a0, s4
    a.vread      v6, a1, s13
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    s.addi       s4, s1, #8
    s.addi       s12, s7, #768                   // row 8
    v.splat      v5, s4
    s.movz       s4, #9
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s2, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.movz       s13, #9
    vf.mul       v4, v6, v7
    vf.mul       v6, v0, v4
    s.addi       s15, s1, #9
    vf.cvt.f32.bf16 v0, v6
    v.splat      v4, s15
    @p3 v.st.h       [s8, #0], v0
    a.vread      v0, a0, s6
    a.vread      v6, a1, s9
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s6, s1, #9
    s.addi       s8, s7, #864                    // row 9
    v.splat      v1, s6
    s.movz       s6, #10
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s2, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s9, #10
    vf.mul       v2, v6, v7
    vf.mul       v6, v0, v2
    s.addi       s15, s1, #10
    vf.cvt.f32.bf16 v0, v6
    v.splat      v2, s15
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s3
    a.vread      v6, a1, s10
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    s.addi       s3, s1, #10
    s.addi       s5, s7, #960                    // row 10
    v.splat      v5, s3
    s.movz       s3, #11
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s2, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.movz       s10, #11
    vf.mul       v4, v6, v7
    vf.mul       v6, v0, v4
    s.addi       s15, s1, #11
    vf.cvt.f32.bf16 v0, v6
    v.splat      v4, s15
    @p3 v.st.h       [s12, #0], v0
    a.vread      v0, a0, s4
    a.vread      v6, a1, s13
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s4, s1, #11
    s.addi       s12, s7, #1056                  // row 11
    v.splat      v1, s4
    s.movz       s4, #12
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s2, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s13, #12
    vf.mul       v2, v6, v7
    vf.mul       v6, v0, v2
    s.addi       s15, s1, #12
    vf.cvt.f32.bf16 v0, v6
    v.splat      v2, s15
    @p3 v.st.h       [s8, #0], v0
    a.vread      v0, a0, s6
    a.vread      v6, a1, s9
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    s.addi       s6, s1, #12
    s.addi       s8, s7, #1152                   // row 12
    v.splat      v5, s6
    s.movz       s6, #13
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s2, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.movz       s9, #13
    vf.mul       v4, v6, v7
    vf.mul       v6, v0, v4
    s.addi       s15, s1, #13
    vf.cvt.f32.bf16 v0, v6
    v.splat      v4, s15
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s3
    a.vread      v6, a1, s10
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s3, s1, #13
    s.addi       s5, s7, #1248                   // row 13
    v.splat      v1, s3
    s.movz       s3, #14
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s2, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s10, #14
    vf.mul       v2, v6, v7
    vf.mul       v6, v0, v2
    s.addi       s15, s1, #14
    vf.cvt.f32.bf16 v0, v6
    v.splat      v2, s15
    @p3 v.st.h       [s12, #0], v0
    a.vread      v0, a0, s4
    a.vread      v6, a1, s13
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    s.addi       s4, s1, #14
    s.addi       s12, s7, #1344                  // row 14
    v.splat      v5, s4
    s.movz       s4, #15
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s2, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.movz       s13, #15
    vf.mul       v4, v6, v7
    vf.mul       v6, v0, v4
    s.addi       s15, s1, #15
    vf.cvt.f32.bf16 v0, v6
    v.splat      v4, s15
    @p3 v.st.h       [s8, #0], v0
    a.vread      v0, a0, s6
    a.vread      v6, a1, s9
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.addi       s6, s1, #15
    s.addi       s1, s7, #1440                   // row 15
    v.splat      v1, s6
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v7, [s2, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    vf.mul       v2, v6, v7
    vf.mul       v6, v0, v2
    vf.cvt.f32.bf16 v0, v6
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s3
    a.vread      v2, a1, s10
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v5, [s2, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    vf.mul       v4, v2, v5
    vf.mul       v2, v0, v4
    vf.cvt.f32.bf16 v0, v2
    @p3 v.st.h       [s12, #0], v0
    a.vread      v0, a0, s4
    a.vread      v2, a1, s13
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v1, [s2, #0]
    vf.mul       v3, v2, v1
    vf.mul       v1, v0, v3
    vf.cvt.f32.bf16 v0, v1
    @p3 v.st.h       [s1, #0], v0
__rctx_next:
    exit
