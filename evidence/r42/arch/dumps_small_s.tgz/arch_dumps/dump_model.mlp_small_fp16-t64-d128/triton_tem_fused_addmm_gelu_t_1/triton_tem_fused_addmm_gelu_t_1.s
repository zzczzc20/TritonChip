    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_A: device_ptr64 at arg_base+8
    s.ld.d       s4, [s1, #16]                   // arg_B: device_ptr64 at arg_base+16
    s.ld.d       s5, [s1, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #512
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.st.d       [s6, #0], s3
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    s.st.d       [s6, #16], s1
    s.movz       s3, #1024
    s.st.d       [s6, #48], s3
    s.movz       s7, #2
    s.st.d       [s6, #56], s7
    .li       s8, #68719476752
    s.st.d       [s6, #88], s8
    .li       s9, #8589934592
    s.st.d       [s6, #104], s9
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s6, arg_base
    s.ld.d       s10, [s6, #32]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s6, role_id
    s.movz       s11, #512
    s.mul        s12, s6, s11
    s.add        s6, s10, s12                    // this context's own scratch
    s.addi       s10, s6, #256                   // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.st.d       [s10, #0], s4
    s.st.d       [s10, #8], s1
    s.st.d       [s10, #16], s1
    s.st.d       [s10, #48], s3
    s.st.d       [s10, #56], s7
    s.st.d       [s10, #88], s8
    s.st.d       [s10, #104], s9
    fence.release.device
    td.load      d1, [s10]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #8
    s.movz       s3, #0
    s.cmp.lt     s4, s1, s3
    s.sub        s1, s3, s4
    s.movz       s4, #4
    s.movz       s6, #1
    s.rdspecial  s7, role_id
    s.rdspecial  s8, npid.x
__rctx_program:
    s.cmp.lt     s9, s7, s3
    s.addi       s10, s3, #0
    s.sub        s11, s3, s9
    s.addi       s9, s3, #0
    s.xor        s12, s7, s11
    s.xor        s13, s11, s1
    s.sub        s14, s12, s11
    s.lshri      s15, s14, #3
    s.mov        s10, s14
    s.xor        s16, s15, s13
    s.sub        s15, s16, s13
    s.sub        s13, s4, s15
    s.min.s      s16, s13, s6
    s.cmp.lt     s13, s16, s3
    s.sub        s17, s3, s13
    s.xor        s13, s16, s17
    s.sub        s16, s13, s17
    s.cmp.eq     s13, s16, s6
    br.nz        s13, sdiv_done_1
    s.movz       s18, #0
    s.movz       s19, #31
    s.mov        s10, s18
    s.addi       s20, s19, #0
sdiv_2:
    s.lshr       s19, s14, s20
    s.shli       s21, s9, #1
    s.andi       s22, s19, #1
    s.shl        s19, s6, s20
    s.or         s23, s21, s22
    s.cmp.geu    s21, s23, s16
    s.sub        s22, s18, s21
    s.and        s21, s16, s22
    s.and        s24, s19, s22
    s.sub        s9, s23, s21
    s.or         s10, s10, s24
    s.subi       s20, s20, #1
    s.cmp.ge     s19, s20, s18
    br.nz        s19, sdiv_2
sdiv_done_1:
    s.sub        s10, s12, s11
    s.xor        s12, s9, s11
    s.lshri      s9, s10, #3
    s.sub        s14, s12, s11
    s.muli       s12, s9, #8
    s.addi       s9, s3, #0
    s.add        s18, s15, s14
    s.addi       s14, s3, #0
    s.sub        s15, s10, s12
    s.xor        s10, s15, s11
    s.sub        s12, s10, s11
    s.cmp.lt     s10, s12, s3
    s.sub        s11, s3, s10
    s.xor        s10, s12, s11
    s.sub        s12, s10, s11
    s.mov        s9, s12
    br.nz        s13, sdiv_done_3
    s.movz       s10, #0
    s.movz       s13, #31
    s.mov        s9, s10
    s.addi       s15, s13, #0
    s.movz       s13, #1
sdiv_4:
    s.lshr       s19, s12, s15
    s.shli       s20, s14, #1
    s.andi       s21, s19, #1
    s.shl        s19, s13, s15
    s.or         s22, s20, s21
    s.cmp.geu    s20, s22, s16
    s.sub        s21, s10, s20
    s.and        s20, s16, s21
    s.and        s23, s19, s21
    s.sub        s14, s22, s20
    s.or         s9, s9, s23
    s.subi       s15, s15, #1
    s.cmp.ge     s19, s15, s10
    br.nz        s19, sdiv_4
sdiv_done_3:
    s.xor        s10, s11, s17
    s.movz       s11, #16
    s.xor        s12, s9, s10
    s.mul        s9, s18, s11
    s.sub        s13, s12, s10
    s.movz       s10, #0
    s.mul        s12, s13, s11
    s.movz       s13, #32
    s.andi       s14, s9, #63
    s.addi       s15, s10, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    s.andi       s16, s12, #127
for_5:
    s.cmp.ge     s17, s15, s13
    br.nz        s17, endfor_6
    s.mul        s17, s15, s11
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s18, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s19, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s20, s17                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s19, s18
    w.def        w1, #48, #8                     // v48..v55
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s19, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s20, s17                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s19, s18
    mb.wait      s18
gemm_pipe:
    mb.arm       s17, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s19, #1
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v56, v48, s17
    s.add        s15, s15, s6
    s.cmp.ge     s19, s15, s13
    br.nz        s19, gemm_pipe_drain0
    s.mul        s19, s15, s11
    w.def        w2, #40, #8                     // v40..v47
    mb.arm       s20, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s21, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s21, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s22, s19                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w2, d0, s21, s20
    w.def        w3, #32, #8                     // v32..v39
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s21, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s22, s19                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w3, d1, s21, s20
    mb.wait      s20
    mb.wait      s17
    mb.arm       s19, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.dp.async.k16.f16 a0, v40, v32, s19
    s.add        s15, s15, s6
    s.cmp.ge     s21, s15, s13
    br.nz        s21, gemm_pipe_drain1
    s.mul        s21, s15, s11
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s22, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s23, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s24, s14                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s25, s21                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s24, s22
    w.def        w1, #48, #8                     // v48..v55
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s24, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s25, s21                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s24, s22
    mb.wait      s22
    mb.wait      s19
    br.nz        s23, gemm_pipe
gemm_pipe_drain0:
    s.movz       s11, #1
    mb.wait      s17
    br.nz        s11, endfor_6
gemm_pipe_drain1:
    mb.wait      s19
endfor_6:
    s.add        s11, s10, s12                   // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s11
    s.add        s11, s10, s9                    // the tile origin
    s.movz       s13, #64
    s.movz       s14, #128
    s.muli       s15, s12, #2                    // a runtime tile origin, x2
    v.splat      v2, s11
    v.splat      v3, s13
    v.add        v4, v0, v1
    v.splat      v0, s14
    v.cmp.lt     p1, v2, v3
    s.add        s12, s2, s15                    // the tile origin
    v.cmp.lt     p2, v4, v0
    p.and        p3, p1, p2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    a.vread      v0, a0, s10
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s12, #0]
    s.addi       s10, s11, #1
    s.muli       s13, s9, #256                   // a runtime tile origin, x256
    v.splat      v2, s10
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.add        s9, s5, s15                     // the tile origin
    s.movz       s10, #1
    v.cmp.lt     p1, v2, v3
    s.add        s14, s9, s13                    // the tile origin
    p.and        p4, p1, p2
    s.addi       s9, s11, #2
    s.addi       s13, s14, #256                  // row 1
    v.splat      v2, s9
    s.movz       s9, #2
    s.addi       s15, s11, #3
    vf.cvt.f16.f32 v4, v1
    v.splat      v1, s15
    s.addi       s15, s14, #512                  // row 2
    s.movz       s16, #3
    s.addi       s21, s11, #4
    vf.add       v5, v0, v4
    v.splat      v0, s21
    s.addi       s21, s14, #768                  // row 3
    s.movz       s23, #4
    vf.cvt.f32.f16 v4, v5
    @p3 v.st.h       [s14, #0], v4
    a.vread      v4, a0, s10
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.addi       s10, s11, #5
    v.splat      v2, s10
    s.addi       s10, s14, #1024                 // row 4
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p4 v.st.h       [s13, #0], v4
    a.vread      v4, a0, s9
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s9, #5
    s.addi       s13, s11, #6
    v.splat      v1, s13
    s.addi       s13, s14, #1280                 // row 5
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p3 v.st.h       [s15, #0], v4
    a.vread      v4, a0, s16
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.movz       s15, #6
    s.addi       s16, s11, #7
    v.splat      v0, s16
    s.addi       s16, s14, #1536                 // row 6
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p4 v.st.h       [s21, #0], v4
    a.vread      v4, a0, s23
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s21, #7
    s.addi       s23, s11, #8
    v.splat      v2, s23
    s.addi       s23, s14, #1792                 // row 7
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p3 v.st.h       [s10, #0], v4
    a.vread      v4, a0, s9
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.movz       s9, #8
    s.addi       s10, s11, #9
    v.splat      v1, s10
    s.addi       s10, s14, #2048                 // row 8
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p4 v.st.h       [s13, #0], v4
    a.vread      v4, a0, s15
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    s.movz       s13, #9
    s.addi       s15, s11, #10
    v.splat      v0, s15
    s.addi       s15, s14, #2304                 // row 9
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p3 v.st.h       [s16, #0], v4
    a.vread      v4, a0, s21
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    s.movz       s16, #10
    s.addi       s21, s11, #11
    v.splat      v2, s21
    s.addi       s21, s14, #2560                 // row 10
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p4 v.st.h       [s23, #0], v4
    a.vread      v4, a0, s9
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.movz       s9, #11
    s.addi       s23, s11, #12
    v.splat      v1, s23
    s.addi       s23, s14, #2816                 // row 11
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p3 v.st.h       [s10, #0], v4
    a.vread      v4, a0, s13
    v.cmp.lt     p1, v0, v3
    p.and        p3, p1, p2
    s.movz       s10, #12
    s.addi       s13, s11, #13
    v.splat      v0, s13
    s.addi       s13, s14, #3072                 // row 12
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p4 v.st.h       [s15, #0], v4
    a.vread      v4, a0, s16
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.movz       s15, #13
    s.addi       s16, s11, #14
    v.splat      v2, s16
    s.addi       s16, s14, #3328                 // row 13
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    @p3 v.st.h       [s21, #0], v4
    a.vread      v4, a0, s9
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    s.movz       s9, #14
    s.addi       s21, s11, #15
    s.addi       s11, s14, #3584                 // row 14
    v.splat      v1, s21
    s.movz       s21, #15
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v5, [s12, #0]
    vf.cvt.f16.f32 v6, v5
    vf.add       v5, v4, v6
    vf.cvt.f32.f16 v4, v5
    s.addi       s24, s14, #3840                 // row 15
    @p4 v.st.h       [s23, #0], v4
    a.vread      v4, a0, s10
    v.cmp.lt     p1, v0, v3
    p.and        p4, p1, p2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s12, #0]
    vf.cvt.f16.f32 v5, v0
    vf.add       v0, v4, v5
    vf.cvt.f32.f16 v4, v0
    @p3 v.st.h       [s13, #0], v4
    a.vread      v0, a0, s15
    v.cmp.lt     p1, v2, v3
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v2, [s12, #0]
    vf.cvt.f16.f32 v4, v2
    vf.add       v2, v0, v4
    vf.cvt.f32.f16 v0, v2
    @p4 v.st.h       [s16, #0], v0
    a.vread      v0, a0, s9
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    @p3 v.st.h       [s11, #0], v0
    a.vread      v0, a0, s21
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v1, [s12, #0]
    vf.cvt.f16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.f16 v0, v1
    @p4 v.st.h       [s24, #0], v0
__rctx_next:
    s.addi       s9, s7, #2                      // the next program of this context: + 2
    s.cmp.lt     s10, s9, s8
    s.mov        s7, s9
    br.nz        s10, __rctx_program
    exit
