    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    s.ld.d       s9, [s1, #48]                   // out_ptr0: device_ptr64 at arg_base+48
    s.ld.d       s10, [s1, #56]                  // out_ptr1: device_ptr64 at arg_base+56
    s.rdspecial  s1, pid.y
    s.shli       s11, s1, #4                     // x16 as a shift
    s.shli       s1, s4, #4                      // x16 as a shift
    s.rdspecial  s4, arg_base
    s.ld.d       s12, [s4, #80]                  // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s4, role_id
    s.movz       s13, #15360
    s.mul        s14, s4, s13
    s.add        s4, s12, s14                    // this context's own scratch
    s.addi       s12, s4, #0
    s.movz       s13, #0
    s.add        s14, s13, s11                   // the tile origin
    v.splat      v0, s14
    s.movz       s13, #64
    v.splat      v1, s13
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s12, #0], v2
    s.addi       s13, s12, #64
    s.addi       s15, s14, #1
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #128
    s.addi       s15, s14, #2
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #192
    s.addi       s15, s14, #3
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #256
    s.addi       s15, s14, #4
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #320
    s.addi       s15, s14, #5
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #384
    s.addi       s15, s14, #6
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #448
    s.addi       s15, s14, #7
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #512
    s.addi       s15, s14, #8
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #576
    s.addi       s15, s14, #9
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #640
    s.addi       s15, s14, #10
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #704
    s.addi       s15, s14, #11
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #768
    s.addi       s15, s14, #12
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #832
    s.addi       s15, s14, #13
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #896
    s.addi       s15, s14, #14
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #960
    s.addi       s12, s14, #15
    v.splat      v0, s12
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #63
    v.and        v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    fence.acq_rel.device
    s.addi       s12, s4, #1024
    v.splat      v0, s14
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s12, #0], v2
    s.addi       s13, s12, #64
    s.addi       s15, s14, #1
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #128
    s.addi       s15, s14, #2
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #192
    s.addi       s15, s14, #3
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #256
    s.addi       s15, s14, #4
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #320
    s.addi       s15, s14, #5
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #384
    s.addi       s15, s14, #6
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #448
    s.addi       s15, s14, #7
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #512
    s.addi       s15, s14, #8
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #576
    s.addi       s15, s14, #9
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #640
    s.addi       s15, s14, #10
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #704
    s.addi       s15, s14, #11
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #768
    s.addi       s15, s14, #12
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #832
    s.addi       s15, s14, #13
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #896
    s.addi       s15, s14, #14
    v.splat      v0, s15
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    s.addi       s13, s12, #960
    s.addi       s12, s14, #15
    v.splat      v0, s12
    v.movi       v2, #0
    v.cmp.lt     p1, v0, v2
    v.cmp.lt     p2, v1, v2
    v.sub        v3, v2, v0
    @p1 v.sel        v4, v3, v0
    v.sub        v0, v2, v1
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #6
    v.lshr       v3, v4, v0
    v.sub        v0, v2, v3
    @p1 v.sel        v2, v0, v3
    v.st.w       [s13, #0], v2
    fence.acq_rel.device
    s.addi       s12, s4, #2048
    s.movz       s13, #0
    v.splat      v0, s13
    s.movz       s15, #0
    s.add        s16, s15, s1                    // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s16
    v.add        v4, v2, v3
    s.addi       s15, s4, #1024
    v.ld.w       v2, [s15, #0]
    s.movz       s15, #32
    v.splat      v3, s15
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s15, s4, #0
    v.ld.w       v5, [s15, #0]
    s.movz       s15, #128
    v.splat      v6, s15
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s12, #0], v2
    s.addi       s15, s12, #64
    s.addi       s16, s4, #1088
    v.ld.w       v2, [s16, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s16, s4, #64
    v.ld.w       v5, [s16, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #128
    s.addi       s16, s4, #1152
    v.ld.w       v2, [s16, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s16, s4, #128
    v.ld.w       v5, [s16, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #192
    s.addi       s16, s4, #1216
    v.ld.w       v2, [s16, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s16, s4, #192
    v.ld.w       v5, [s16, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #256
    s.addi       s16, s4, #1280
    v.ld.w       v2, [s16, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s16, s4, #256
    v.ld.w       v5, [s16, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #320
    s.addi       s16, s4, #1344
    v.ld.w       v2, [s16, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s16, s4, #320
    v.ld.w       v5, [s16, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #384
    s.addi       s16, s4, #1408
    v.ld.w       v2, [s16, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s16, s4, #384
    v.ld.w       v5, [s16, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #448
    s.addi       s16, s4, #1472
    v.ld.w       v2, [s16, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s16, s4, #448
    v.ld.w       v5, [s16, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #512
    s.addi       s16, s4, #1536
    v.ld.w       v2, [s16, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s16, s4, #512
    v.ld.w       v5, [s16, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #576
    s.addi       s16, s4, #1600
    v.ld.w       v2, [s16, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s16, s4, #576
    v.ld.w       v5, [s16, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #640
    s.addi       s16, s4, #1664
    v.ld.w       v2, [s16, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s16, s4, #640
    v.ld.w       v5, [s16, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #704
    s.addi       s16, s4, #1728
    v.ld.w       v2, [s16, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s16, s4, #704
    v.ld.w       v5, [s16, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #768
    s.addi       s16, s4, #1792
    v.ld.w       v2, [s16, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s16, s4, #768
    v.ld.w       v5, [s16, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #832
    s.addi       s16, s4, #1856
    v.ld.w       v2, [s16, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s16, s4, #832
    v.ld.w       v5, [s16, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #896
    s.addi       s16, s4, #1920
    v.ld.w       v2, [s16, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s16, s4, #896
    v.ld.w       v5, [s16, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #960
    s.addi       s12, s4, #1984
    v.ld.w       v2, [s12, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s12, s4, #960
    v.ld.w       v5, [s12, #0]
    v.mul        v7, v5, v6
    v.add        v5, v2, v7
    v.add        v2, v0, v5
    v.st.w       [s15, #0], v2
    fence.acq_rel.device
    s.addi       s12, s4, #3072
    s.addi       s15, s4, #2048
    v.ld.w       v0, [s15, #0]
    v.cmpi.lt    p1, v4, #32
    v.splat      v2, s14
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s15, s12, #64
    s.addi       s16, s4, #2112
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #1
    v.splat      v2, s16
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #128
    s.addi       s16, s4, #2176
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #2
    v.splat      v2, s16
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #192
    s.addi       s16, s4, #2240
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #3
    v.splat      v2, s16
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #256
    s.addi       s16, s4, #2304
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #4
    v.splat      v2, s16
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #320
    s.addi       s16, s4, #2368
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #5
    v.splat      v2, s16
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #384
    s.addi       s16, s4, #2432
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #6
    v.splat      v2, s16
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #448
    s.addi       s16, s4, #2496
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #7
    v.splat      v2, s16
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #512
    s.addi       s16, s4, #2560
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #8
    v.splat      v2, s16
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #576
    s.addi       s16, s4, #2624
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #9
    v.splat      v2, s16
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #640
    s.addi       s16, s4, #2688
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #10
    v.splat      v2, s16
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #704
    s.addi       s16, s4, #2752
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #11
    v.splat      v2, s16
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #768
    s.addi       s16, s4, #2816
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #12
    v.splat      v2, s16
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #832
    s.addi       s16, s4, #2880
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #13
    v.splat      v2, s16
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #896
    s.addi       s16, s4, #2944
    v.ld.w       v0, [s16, #0]
    s.addi       s16, s14, #14
    v.splat      v2, s16
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    s.addi       s15, s12, #960
    s.addi       s12, s4, #3008
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #15
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s15, #0], v2
    fence.acq_rel.device
    s.addi       s2, s4, #4096
    s.addi       s12, s4, #0
    v.ld.w       v0, [s12, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s2, #0], v0
    s.addi       s12, s2, #64
    s.addi       s15, s4, #64
    v.ld.w       v0, [s15, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    s.addi       s12, s2, #128
    s.addi       s15, s4, #128
    v.ld.w       v0, [s15, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    s.addi       s12, s2, #192
    s.addi       s15, s4, #192
    v.ld.w       v0, [s15, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    s.addi       s12, s2, #256
    s.addi       s15, s4, #256
    v.ld.w       v0, [s15, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    s.addi       s12, s2, #320
    s.addi       s15, s4, #320
    v.ld.w       v0, [s15, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    s.addi       s12, s2, #384
    s.addi       s15, s4, #384
    v.ld.w       v0, [s15, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    s.addi       s12, s2, #448
    s.addi       s15, s4, #448
    v.ld.w       v0, [s15, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    s.addi       s12, s2, #512
    s.addi       s15, s4, #512
    v.ld.w       v0, [s15, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    s.addi       s12, s2, #576
    s.addi       s15, s4, #576
    v.ld.w       v0, [s15, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    s.addi       s12, s2, #640
    s.addi       s15, s4, #640
    v.ld.w       v0, [s15, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    s.addi       s12, s2, #704
    s.addi       s15, s4, #704
    v.ld.w       v0, [s15, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    s.addi       s12, s2, #768
    s.addi       s15, s4, #768
    v.ld.w       v0, [s15, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    s.addi       s12, s2, #832
    s.addi       s15, s4, #832
    v.ld.w       v0, [s15, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    s.addi       s12, s2, #896
    s.addi       s15, s4, #896
    v.ld.w       v0, [s15, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    s.addi       s12, s2, #960
    s.addi       s2, s4, #960
    v.ld.w       v0, [s2, #0]
    v.mul        v2, v0, v3
    v.add        v0, v4, v2
    v.st.w       [s12, #0], v0
    fence.acq_rel.device
    s.addi       s2, s4, #5120
    v.splat      v0, s13
    s.addi       s12, s4, #4096
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s2, #0], v5
    s.addi       s12, s2, #64
    s.addi       s15, s4, #4160
    v.ld.w       v2, [s15, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #128
    s.addi       s15, s4, #4224
    v.ld.w       v2, [s15, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #192
    s.addi       s15, s4, #4288
    v.ld.w       v2, [s15, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #256
    s.addi       s15, s4, #4352
    v.ld.w       v2, [s15, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #320
    s.addi       s15, s4, #4416
    v.ld.w       v2, [s15, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #384
    s.addi       s15, s4, #4480
    v.ld.w       v2, [s15, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #448
    s.addi       s15, s4, #4544
    v.ld.w       v2, [s15, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #512
    s.addi       s15, s4, #4608
    v.ld.w       v2, [s15, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #576
    s.addi       s15, s4, #4672
    v.ld.w       v2, [s15, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #640
    s.addi       s15, s4, #4736
    v.ld.w       v2, [s15, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #704
    s.addi       s15, s4, #4800
    v.ld.w       v2, [s15, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #768
    s.addi       s15, s4, #4864
    v.ld.w       v2, [s15, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #832
    s.addi       s15, s4, #4928
    v.ld.w       v2, [s15, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #896
    s.addi       s15, s4, #4992
    v.ld.w       v2, [s15, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    s.addi       s12, s2, #960
    s.addi       s2, s4, #5056
    v.ld.w       v2, [s2, #0]
    v.add        v5, v0, v2
    v.st.w       [s12, #0], v5
    fence.acq_rel.device
    s.addi       s2, s4, #6144
    s.addi       s12, s4, #5120
    v.ld.w       v0, [s12, #0]
    v.splat      v2, s14
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s2, #0], v2
    s.addi       s12, s2, #64
    s.addi       s15, s4, #5184
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #1
    v.splat      v2, s15
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s2, #128
    s.addi       s15, s4, #5248
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #2
    v.splat      v2, s15
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s2, #192
    s.addi       s15, s4, #5312
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #3
    v.splat      v2, s15
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s2, #256
    s.addi       s15, s4, #5376
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #4
    v.splat      v2, s15
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s2, #320
    s.addi       s15, s4, #5440
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #5
    v.splat      v2, s15
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s2, #384
    s.addi       s15, s4, #5504
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #6
    v.splat      v2, s15
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s2, #448
    s.addi       s15, s4, #5568
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #7
    v.splat      v2, s15
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s2, #512
    s.addi       s15, s4, #5632
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #8
    v.splat      v2, s15
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s2, #576
    s.addi       s15, s4, #5696
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #9
    v.splat      v2, s15
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s2, #640
    s.addi       s15, s4, #5760
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #10
    v.splat      v2, s15
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s2, #704
    s.addi       s15, s4, #5824
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #11
    v.splat      v2, s15
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s2, #768
    s.addi       s15, s4, #5888
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #12
    v.splat      v2, s15
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s2, #832
    s.addi       s15, s4, #5952
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #13
    v.splat      v2, s15
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s2, #896
    s.addi       s15, s4, #6016
    v.ld.w       v0, [s15, #0]
    s.addi       s15, s14, #14
    v.splat      v2, s15
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    s.addi       s12, s2, #960
    s.addi       s2, s4, #6080
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s14, #15
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s3, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s12, #0], v2
    fence.acq_rel.device
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s2, #0
    s.addi       s3, s4, #6144
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #1
    s.addi       s3, s4, #6208
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #2
    s.addi       s3, s4, #6272
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #3
    s.addi       s3, s4, #6336
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #4
    s.addi       s3, s4, #6400
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #5
    s.addi       s3, s4, #6464
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #6
    s.addi       s3, s4, #6528
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #7
    s.addi       s3, s4, #6592
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #8
    s.addi       s3, s4, #6656
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #9
    s.addi       s3, s4, #6720
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #10
    s.addi       s3, s4, #6784
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #11
    s.addi       s3, s4, #6848
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #12
    s.addi       s3, s4, #6912
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #13
    s.addi       s3, s4, #6976
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #14
    s.addi       s3, s4, #7040
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.movz       s2, #15
    s.addi       s3, s4, #7104
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a0, s2, v2
    s.muli       s2, s1, #2                      // a runtime tile origin, x2
    s.add        s3, s5, s2                      // the tile origin
    s.muli       s2, s11, #64                    // a runtime tile origin, x64
    s.add        s5, s3, s2                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.addi       s2, s4, #7168
    v.splat      v0, s13
    s.addi       s3, s4, #4096
    v.ld.w       v2, [s3, #0]
    v.add        v5, v0, v2
    v.st.w       [s2, #0], v5
    s.addi       s3, s2, #64
    s.addi       s12, s4, #4160
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #128
    s.addi       s12, s4, #4224
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #192
    s.addi       s12, s4, #4288
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #256
    s.addi       s12, s4, #4352
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #320
    s.addi       s12, s4, #4416
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #384
    s.addi       s12, s4, #4480
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #448
    s.addi       s12, s4, #4544
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #512
    s.addi       s12, s4, #4608
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #576
    s.addi       s12, s4, #4672
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #640
    s.addi       s12, s4, #4736
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #704
    s.addi       s12, s4, #4800
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #768
    s.addi       s12, s4, #4864
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #832
    s.addi       s12, s4, #4928
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #896
    s.addi       s12, s4, #4992
    v.ld.w       v2, [s12, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #960
    s.addi       s2, s4, #5056
    v.ld.w       v2, [s2, #0]
    v.add        v5, v0, v2
    v.st.w       [s3, #0], v5
    fence.acq_rel.device
    s.addi       s2, s4, #8192
    s.addi       s3, s4, #7168
    v.ld.w       v0, [s3, #0]
    v.splat      v2, s14
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s2, #0], v2
    s.addi       s3, s2, #64
    s.addi       s12, s4, #7232
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #1
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #128
    s.addi       s12, s4, #7296
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #2
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #192
    s.addi       s12, s4, #7360
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #3
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #256
    s.addi       s12, s4, #7424
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #4
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #320
    s.addi       s12, s4, #7488
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #5
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #384
    s.addi       s12, s4, #7552
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #6
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #448
    s.addi       s12, s4, #7616
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #7
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #512
    s.addi       s12, s4, #7680
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #8
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #576
    s.addi       s12, s4, #7744
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #9
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #640
    s.addi       s12, s4, #7808
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #10
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #704
    s.addi       s12, s4, #7872
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #11
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #768
    s.addi       s12, s4, #7936
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #12
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #832
    s.addi       s12, s4, #8000
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #13
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #896
    s.addi       s12, s4, #8064
    v.ld.w       v0, [s12, #0]
    s.addi       s12, s14, #14
    v.splat      v2, s12
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #960
    s.addi       s2, s4, #8128
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s14, #15
    v.splat      v2, s2
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v2, [s6, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v2
    fence.acq_rel.device
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s2, #0
    s.addi       s3, s4, #8192
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #1
    s.addi       s3, s4, #8256
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #2
    s.addi       s3, s4, #8320
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #3
    s.addi       s3, s4, #8384
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #4
    s.addi       s3, s4, #8448
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #5
    s.addi       s3, s4, #8512
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #6
    s.addi       s3, s4, #8576
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #7
    s.addi       s3, s4, #8640
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #8
    s.addi       s3, s4, #8704
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #9
    s.addi       s3, s4, #8768
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #10
    s.addi       s3, s4, #8832
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #11
    s.addi       s3, s4, #8896
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #12
    s.addi       s3, s4, #8960
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #13
    s.addi       s3, s4, #9024
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #14
    s.addi       s3, s4, #9088
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.movz       s2, #15
    s.addi       s3, s4, #9152
    v.ld.w       v0, [s3, #0]
    vf.cvt.f16.f32 v2, v0
    a.vwrite     a1, s2, v2
    s.addi       s2, s4, #9216
    s.addi       s3, s4, #1024
    v.ld.w       v0, [s3, #0]
    s.movz       s3, #2
    v.splat      v2, s3
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s2, #0], v5
    s.addi       s3, s2, #64
    s.addi       s6, s4, #1088
    v.ld.w       v0, [s6, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #128
    s.addi       s6, s4, #1152
    v.ld.w       v0, [s6, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #192
    s.addi       s6, s4, #1216
    v.ld.w       v0, [s6, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #256
    s.addi       s6, s4, #1280
    v.ld.w       v0, [s6, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #320
    s.addi       s6, s4, #1344
    v.ld.w       v0, [s6, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #384
    s.addi       s6, s4, #1408
    v.ld.w       v0, [s6, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #448
    s.addi       s6, s4, #1472
    v.ld.w       v0, [s6, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #512
    s.addi       s6, s4, #1536
    v.ld.w       v0, [s6, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #576
    s.addi       s6, s4, #1600
    v.ld.w       v0, [s6, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #640
    s.addi       s6, s4, #1664
    v.ld.w       v0, [s6, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #704
    s.addi       s6, s4, #1728
    v.ld.w       v0, [s6, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #768
    s.addi       s6, s4, #1792
    v.ld.w       v0, [s6, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #832
    s.addi       s6, s4, #1856
    v.ld.w       v0, [s6, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #896
    s.addi       s6, s4, #1920
    v.ld.w       v0, [s6, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v6, v7, v0
    v.sub        v0, v5, v6
    @p2 v.sel        v5, v0, v6
    v.st.w       [s3, #0], v5
    s.addi       s3, s2, #960
    s.addi       s2, s4, #1984
    v.ld.w       v0, [s2, #0]
    v.movi       v5, #0
    v.cmp.lt     p2, v0, v5
    v.cmp.lt     p3, v2, v5
    v.sub        v6, v5, v0
    @p2 v.sel        v7, v6, v0
    v.sub        v0, v5, v2
    @p3 v.sel        v6, v0, v2
    v.movi       v0, #1
    v.lshr       v2, v7, v0
    v.sub        v0, v5, v2
    @p2 v.sel        v5, v0, v2
    v.st.w       [s3, #0], v5
    fence.acq_rel.device
    s.addi       s2, s4, #10240
    v.splat      v0, s13
    s.addi       s3, s4, #9216
    v.ld.w       v2, [s3, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s3, s4, #0
    v.ld.w       v5, [s3, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s2, #0], v2
    s.addi       s3, s2, #64
    s.addi       s6, s4, #9280
    v.ld.w       v2, [s6, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s6, s4, #64
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #128
    s.addi       s6, s4, #9344
    v.ld.w       v2, [s6, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s6, s4, #128
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #192
    s.addi       s6, s4, #9408
    v.ld.w       v2, [s6, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s6, s4, #192
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #256
    s.addi       s6, s4, #9472
    v.ld.w       v2, [s6, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s6, s4, #256
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #320
    s.addi       s6, s4, #9536
    v.ld.w       v2, [s6, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s6, s4, #320
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #384
    s.addi       s6, s4, #9600
    v.ld.w       v2, [s6, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s6, s4, #384
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #448
    s.addi       s6, s4, #9664
    v.ld.w       v2, [s6, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s6, s4, #448
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #512
    s.addi       s6, s4, #9728
    v.ld.w       v2, [s6, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s6, s4, #512
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #576
    s.addi       s6, s4, #9792
    v.ld.w       v2, [s6, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s6, s4, #576
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #640
    s.addi       s6, s4, #9856
    v.ld.w       v2, [s6, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s6, s4, #640
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #704
    s.addi       s6, s4, #9920
    v.ld.w       v2, [s6, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s6, s4, #704
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #768
    s.addi       s6, s4, #9984
    v.ld.w       v2, [s6, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s6, s4, #768
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #832
    s.addi       s6, s4, #10048
    v.ld.w       v2, [s6, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s6, s4, #832
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #896
    s.addi       s6, s4, #10112
    v.ld.w       v2, [s6, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s6, s4, #896
    v.ld.w       v5, [s6, #0]
    v.mul        v6, v5, v1
    v.add        v5, v2, v6
    v.add        v2, v0, v5
    v.st.w       [s3, #0], v2
    s.addi       s3, s2, #960
    s.addi       s2, s4, #10176
    v.ld.w       v2, [s2, #0]
    v.mul        v5, v2, v3
    v.add        v2, v4, v5
    s.addi       s2, s4, #960
    v.ld.w       v3, [s2, #0]
    v.mul        v4, v3, v1
    v.add        v1, v2, v4
    v.add        v2, v0, v1
    v.st.w       [s3, #0], v2
    fence.acq_rel.device
    s.addi       s2, s4, #11264
    s.addi       s3, s4, #10240
    v.ld.w       v0, [s3, #0]
    v.splat      v1, s14
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s2, #0], v1
    s.addi       s3, s2, #64
    s.addi       s6, s4, #10304
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #1
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #128
    s.addi       s6, s4, #10368
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #2
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #192
    s.addi       s6, s4, #10432
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #3
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #256
    s.addi       s6, s4, #10496
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #4
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #320
    s.addi       s6, s4, #10560
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #5
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #384
    s.addi       s6, s4, #10624
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #6
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #448
    s.addi       s6, s4, #10688
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #7
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #512
    s.addi       s6, s4, #10752
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #8
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #576
    s.addi       s6, s4, #10816
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #9
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #640
    s.addi       s6, s4, #10880
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #10
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #704
    s.addi       s6, s4, #10944
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #11
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #768
    s.addi       s6, s4, #11008
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #12
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #832
    s.addi       s6, s4, #11072
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #13
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #896
    s.addi       s6, s4, #11136
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #14
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #960
    s.addi       s2, s4, #11200
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s14, #15
    v.splat      v1, s2
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    fence.acq_rel.device
    s.addi       s2, s4, #12288
    v.splat      v0, s13
    s.addi       s3, s4, #4096
    v.ld.w       v1, [s3, #0]
    s.addi       s3, s4, #9216
    v.ld.w       v2, [s3, #0]
    s.movz       s3, #2048
    v.splat      v3, s3
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s2, #0], v1
    s.addi       s3, s2, #64
    s.addi       s6, s4, #4160
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #9280
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #128
    s.addi       s6, s4, #4224
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #9344
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #192
    s.addi       s6, s4, #4288
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #9408
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #256
    s.addi       s6, s4, #4352
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #9472
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #320
    s.addi       s6, s4, #4416
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #9536
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #384
    s.addi       s6, s4, #4480
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #9600
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #448
    s.addi       s6, s4, #4544
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #9664
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #512
    s.addi       s6, s4, #4608
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #9728
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #576
    s.addi       s6, s4, #4672
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #9792
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #640
    s.addi       s6, s4, #4736
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #9856
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #704
    s.addi       s6, s4, #4800
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #9920
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #768
    s.addi       s6, s4, #4864
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #9984
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #832
    s.addi       s6, s4, #4928
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #10048
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #896
    s.addi       s6, s4, #4992
    v.ld.w       v1, [s6, #0]
    s.addi       s6, s4, #10112
    v.ld.w       v2, [s6, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #960
    s.addi       s2, s4, #5056
    v.ld.w       v1, [s2, #0]
    s.addi       s2, s4, #10176
    v.ld.w       v2, [s2, #0]
    v.mul        v4, v2, v3
    v.add        v2, v1, v4
    v.add        v1, v0, v2
    v.st.w       [s3, #0], v1
    fence.acq_rel.device
    s.addi       s2, s4, #13312
    s.addi       s3, s4, #12288
    v.ld.w       v0, [s3, #0]
    v.splat      v1, s14
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s2, #0], v1
    s.addi       s3, s2, #64
    s.addi       s6, s4, #12352
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #1
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #128
    s.addi       s6, s4, #12416
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #2
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #192
    s.addi       s6, s4, #12480
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #3
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #256
    s.addi       s6, s4, #12544
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #4
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #320
    s.addi       s6, s4, #12608
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #5
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #384
    s.addi       s6, s4, #12672
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #6
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #448
    s.addi       s6, s4, #12736
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #7
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #512
    s.addi       s6, s4, #12800
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #8
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #576
    s.addi       s6, s4, #12864
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #9
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #640
    s.addi       s6, s4, #12928
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #10
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #704
    s.addi       s6, s4, #12992
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #11
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #768
    s.addi       s6, s4, #13056
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #12
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #832
    s.addi       s6, s4, #13120
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #13
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #896
    s.addi       s6, s4, #13184
    v.ld.w       v0, [s6, #0]
    s.addi       s6, s14, #14
    v.splat      v1, s6
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    s.addi       s3, s2, #960
    s.addi       s2, s4, #13248
    v.ld.w       v0, [s2, #0]
    s.addi       s2, s14, #15
    v.splat      v1, s2
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.h v1, [s8, v0]               // index is in elements (ISA sec 9.1)
    v.st.w       [s3, #0], v1
    fence.acq_rel.device
    .li       s2, #1054295293
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1054295293
    v.splat      v1, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s2, #0
    s.addi       s3, s4, #11264
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #0
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #13312
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #0
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #1
    s.addi       s3, s4, #11328
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #1
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #13376
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #1
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #2
    s.addi       s3, s4, #11392
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #2
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #13440
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #2
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #3
    s.addi       s3, s4, #11456
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #3
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #13504
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #3
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #4
    s.addi       s3, s4, #11520
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #4
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #13568
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #4
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #5
    s.addi       s3, s4, #11584
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #5
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #13632
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #5
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #6
    s.addi       s3, s4, #11648
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #6
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #13696
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #6
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #7
    s.addi       s3, s4, #11712
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #7
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #13760
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #7
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #8
    s.addi       s3, s4, #11776
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #8
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #13824
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #8
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #9
    s.addi       s3, s4, #11840
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #9
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #13888
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #9
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #10
    s.addi       s3, s4, #11904
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #10
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #13952
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #10
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #11
    s.addi       s3, s4, #11968
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #11
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #14016
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #11
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #12
    s.addi       s3, s4, #12032
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #12
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #14080
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #12
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #13
    s.addi       s3, s4, #12096
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #13
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #14144
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #13
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #14
    s.addi       s3, s4, #12160
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #14
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #14208
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #14
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.movz       s2, #15
    s.addi       s3, s4, #12224
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #15
    a.vread      v2, a0, s3
    vf.mul       v5, v4, v2
    s.addi       s3, s4, #14272
    v.ld.w       v2, [s3, #0]
    vf.cvt.f16.f32 v4, v2
    s.movz       s3, #15
    a.vread      v2, a1, s3
    vf.mul       v6, v4, v2
    vf.add       v2, v5, v6
    vf.mul       v4, v2, v1
    a.vwrite     a2, s2, v4
    s.muli       s2, s1, #4                      // a runtime tile origin, x4
    s.add        s3, s9, s2                      // the tile origin
    s.muli       s2, s11, #128                   // a runtime tile origin, x128
    s.add        s6, s3, s2                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.addi       s2, s4, #3072
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #0
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    v.splat      v1, s14
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s5, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #0
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    v.splat      v1, s14
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s6, #0], v2
    s.addi       s2, s4, #3136
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #1
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #64                     // row 1
    s.addi       s3, s14, #1
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #1
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #128                    // row 1
    s.addi       s3, s14, #1
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #3200
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #2
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #128                    // row 2
    s.addi       s3, s14, #2
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #2
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #256                    // row 2
    s.addi       s3, s14, #2
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #3264
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #3
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #192                    // row 3
    s.addi       s3, s14, #3
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #3
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #384                    // row 3
    s.addi       s3, s14, #3
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #3328
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #4
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #256                    // row 4
    s.addi       s3, s14, #4
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #4
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #512                    // row 4
    s.addi       s3, s14, #4
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #3392
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #5
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #320                    // row 5
    s.addi       s3, s14, #5
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #5
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #640                    // row 5
    s.addi       s3, s14, #5
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #3456
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #6
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #384                    // row 6
    s.addi       s3, s14, #6
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #6
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #768                    // row 6
    s.addi       s3, s14, #6
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #3520
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #7
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #448                    // row 7
    s.addi       s3, s14, #7
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #7
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #896                    // row 7
    s.addi       s3, s14, #7
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #3584
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #8
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #512                    // row 8
    s.addi       s3, s14, #8
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #8
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #1024                   // row 8
    s.addi       s3, s14, #8
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #3648
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #9
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #576                    // row 9
    s.addi       s3, s14, #9
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #9
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #1152                   // row 9
    s.addi       s3, s14, #9
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #3712
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #10
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #640                    // row 10
    s.addi       s3, s14, #10
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #10
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #1280                   // row 10
    s.addi       s3, s14, #10
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #3776
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #11
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #704                    // row 11
    s.addi       s3, s14, #11
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #11
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #1408                   // row 11
    s.addi       s3, s14, #11
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #3840
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #12
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #768                    // row 12
    s.addi       s3, s14, #12
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #12
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #1536                   // row 12
    s.addi       s3, s14, #12
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #3904
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #13
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #832                    // row 13
    s.addi       s3, s14, #13
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #13
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #1664                   // row 13
    s.addi       s3, s14, #13
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #3968
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #14
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #896                    // row 14
    s.addi       s3, s14, #14
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #14
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #1792                   // row 14
    s.addi       s3, s14, #14
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #4032
    v.ld.w       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #15
    a.vread      v1, a0, s2
    vf.mul       v4, v2, v1
    s.addi       s2, s5, #960                    // row 15
    s.addi       s3, s14, #15
    v.splat      v1, s3
    v.cmpi.lt    p2, v1, #256
    p.and        p3, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s2, #0]
    vf.cvt.f16.f32 v2, v1
    s.movz       s2, #15
    a.vread      v1, a1, s2
    vf.mul       v5, v2, v1
    vf.add       v1, v4, v5
    vf.mul       v2, v1, v0
    s.addi       s2, s6, #1920                   // row 15
    s.addi       s3, s14, #15
    v.splat      v0, s3
    v.cmpi.lt    p2, v0, #256
    p.and        p3, p1, p2
    @p3 v.st.w       [s2, #0], v2
    s.addi       s2, s4, #14336
    v.splat      v0, s13
    s.addi       s3, s4, #0
    v.ld.w       v1, [s3, #0]
    s.movz       s3, #0
    s.muli       s5, s1, #64                     // a runtime tile origin, x64
    s.add        s1, s3, s5                      // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s3, #64
    v.splat      v4, s3
    v.mul        v5, v2, v4
    v.splat      v2, s1
    v.add        v4, v5, v2
    v.add        v2, v1, v4
    s.addi       s1, s4, #1024
    v.ld.w       v1, [s1, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s2, #0], v2
    s.addi       s1, s2, #64
    s.addi       s3, s4, #64
    v.ld.w       v1, [s3, #0]
    v.add        v2, v1, v4
    s.addi       s3, s4, #1088
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s1, s2, #128
    s.addi       s3, s4, #128
    v.ld.w       v1, [s3, #0]
    v.add        v2, v1, v4
    s.addi       s3, s4, #1152
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s1, s2, #192
    s.addi       s3, s4, #192
    v.ld.w       v1, [s3, #0]
    v.add        v2, v1, v4
    s.addi       s3, s4, #1216
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s1, s2, #256
    s.addi       s3, s4, #256
    v.ld.w       v1, [s3, #0]
    v.add        v2, v1, v4
    s.addi       s3, s4, #1280
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s1, s2, #320
    s.addi       s3, s4, #320
    v.ld.w       v1, [s3, #0]
    v.add        v2, v1, v4
    s.addi       s3, s4, #1344
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s1, s2, #384
    s.addi       s3, s4, #384
    v.ld.w       v1, [s3, #0]
    v.add        v2, v1, v4
    s.addi       s3, s4, #1408
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s1, s2, #448
    s.addi       s3, s4, #448
    v.ld.w       v1, [s3, #0]
    v.add        v2, v1, v4
    s.addi       s3, s4, #1472
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s1, s2, #512
    s.addi       s3, s4, #512
    v.ld.w       v1, [s3, #0]
    v.add        v2, v1, v4
    s.addi       s3, s4, #1536
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s1, s2, #576
    s.addi       s3, s4, #576
    v.ld.w       v1, [s3, #0]
    v.add        v2, v1, v4
    s.addi       s3, s4, #1600
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s1, s2, #640
    s.addi       s3, s4, #640
    v.ld.w       v1, [s3, #0]
    v.add        v2, v1, v4
    s.addi       s3, s4, #1664
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s1, s2, #704
    s.addi       s3, s4, #704
    v.ld.w       v1, [s3, #0]
    v.add        v2, v1, v4
    s.addi       s3, s4, #1728
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s1, s2, #768
    s.addi       s3, s4, #768
    v.ld.w       v1, [s3, #0]
    v.add        v2, v1, v4
    s.addi       s3, s4, #1792
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s1, s2, #832
    s.addi       s3, s4, #832
    v.ld.w       v1, [s3, #0]
    v.add        v2, v1, v4
    s.addi       s3, s4, #1856
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s1, s2, #896
    s.addi       s3, s4, #896
    v.ld.w       v1, [s3, #0]
    v.add        v2, v1, v4
    s.addi       s3, s4, #1920
    v.ld.w       v1, [s3, #0]
    v.mul        v5, v1, v3
    v.add        v1, v2, v5
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    s.addi       s1, s2, #960
    s.addi       s2, s4, #960
    v.ld.w       v1, [s2, #0]
    v.add        v2, v1, v4
    s.addi       s2, s4, #1984
    v.ld.w       v1, [s2, #0]
    v.mul        v4, v1, v3
    v.add        v1, v2, v4
    v.add        v2, v0, v1
    v.st.w       [s1, #0], v2
    fence.acq_rel.device
    s.movz       s1, #0
    a.vread      v0, a2, s1
    s.addi       s1, s4, #14336
    v.ld.w       v1, [s1, #0]
    v.splat      v2, s14
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #1
    a.vread      v0, a2, s1
    s.addi       s1, s4, #14400
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #1
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #2
    a.vread      v0, a2, s1
    s.addi       s1, s4, #14464
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #2
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #3
    a.vread      v0, a2, s1
    s.addi       s1, s4, #14528
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #3
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #4
    a.vread      v0, a2, s1
    s.addi       s1, s4, #14592
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #4
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #5
    a.vread      v0, a2, s1
    s.addi       s1, s4, #14656
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #5
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #6
    a.vread      v0, a2, s1
    s.addi       s1, s4, #14720
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #6
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #7
    a.vread      v0, a2, s1
    s.addi       s1, s4, #14784
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #7
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #8
    a.vread      v0, a2, s1
    s.addi       s1, s4, #14848
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #8
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #9
    a.vread      v0, a2, s1
    s.addi       s1, s4, #14912
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #9
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #10
    a.vread      v0, a2, s1
    s.addi       s1, s4, #14976
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #10
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #11
    a.vread      v0, a2, s1
    s.addi       s1, s4, #15040
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #11
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #12
    a.vread      v0, a2, s1
    s.addi       s1, s4, #15104
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #12
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #13
    a.vread      v0, a2, s1
    s.addi       s1, s4, #15168
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #13
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #14
    a.vread      v0, a2, s1
    s.addi       s1, s4, #15232
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #14
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
    s.movz       s1, #15
    a.vread      v0, a2, s1
    s.addi       s1, s4, #15296
    v.ld.w       v1, [s1, #0]
    s.addi       s1, s14, #15
    v.splat      v2, s1
    v.cmpi.lt    p2, v2, #256
    p.and        p3, p1, p2
    @p3 v.st.scatter.w [s10, v1], v0
__rctx_next:
    exit
