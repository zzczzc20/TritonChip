    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    .li       s1, #1149239296
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s1, s4, #4                      // x16 as a shift
    v.iota       v1                              // arange(0, VLEN)
    v.rcp.approx v2, v0                          // ISA 8.8: <= 2**-22 relative
    v.splat      v3, s1
    v.movi       v4, #0
    s.rdspecial  s2, arg_base
    v.add        v5, v3, v1
    v.movi       v1, #10
    s.ld.d       s3, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v3, v4, v5
    v.cmp.lt     p1, v5, v4
    .li       s4, #1065353216
    v.splat      v6, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    @p1 v.sel        v7, v3, v5
    .li       s4, #925353388
    v.splat      v3, s4                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v8, #0
    v.lshr       v9, v7, v1
    v.movi       v1, #1023
    v.sub        v7, v8, v5
    v.cmp.lt     p2, v5, v8
    s.ld.d       s4, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    @p2 v.sel        v10, v7, v5
    v.and        v7, v10, v1
    v.sub        v1, v4, v9
    @p1 v.sel        v10, v1, v9
    v.movi       v1, #2
    vf.fms       v9, v0, v2, v6
    v.ld.gather.w v0, [s3, v10]                  // index is in elements (ISA sec 9.1)
    v.mul        v6, v5, v1
    v.sub        v1, v8, v7
    .li       s3, #1077936128
    v.splat      v5, s3                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v10, v2, v9, v2
    @p2 v.sel        v9, v1, v7
    v.movi       v1, #1024
    vf.neg       v7, v10                         // Newton step: r0*(2 - x*r0)
    v.cmp.lt     p1, v1, v4
    v.sub        v10, v4, v1
    v.cmp.lt     p2, v1, v8
    v.sub        v4, v8, v1
    vf.cmp.o     p3, v7, v7
    @p3 v.sel        v8, v7, v2
    @p1 v.sel        v2, v10, v1
    @p2 v.sel        v2, v4, v1
    vf.mul       v1, v0, v8                      // a/y as a refined reciprocal (ISA has no divide)
    s.ld.d       s3, [s2, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    vf.add       v0, v1, v3
    v.rsqrt.approx v1, v0                        // ISA 8.8: <= 2**-22 relative
    v.ld.gather.w v2, [s4, v6]                   // index is in elements (ISA sec 9.1)
    v.ld.gather.w v3, [s3, v9]                   // index is in elements (ISA sec 9.1)
    vf.mul       v4, v1, v1
    vf.fms       v6, v0, v4, v5
    s.ld.d       s3, [s2, #24]                   // out_ptr0: device_ptr64 at arg_base+24
    .li       s2, #3204448256
    v.splat      v0, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.shli       s2, s1, #2                      // element offset -> bytes (x4)
    vf.mul       v4, v1, v0
    vf.mul       v0, v4, v6                      // Newton step: 0.5*r0*(3 - x*r0^2)
    s.add        s1, s3, s2                      // &out_ptr0[...]
    vf.cmp.o     p1, v0, v0
    @p1 v.sel        v4, v0, v1
    vf.mul       v0, v2, v4
    vf.mul       v1, v0, v3
    v.st.w       [s1, #0], v1
__rctx_next:
    exit
