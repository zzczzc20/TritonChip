    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    s.rdspecial  s2, arg_base
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v2, #5
    v.add        v3, v1, v0
    v.movi       v0, #4
    v.movi       v1, #1
    v.mul        v4, v3, v2
    v.mul        v2, v3, v0
    v.movi       v5, #2
    v.movi       v6, #6144
    v.add        v7, v4, v1
    v.add        v8, v4, v5
    s.ld.d       s4, [s2, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.add        v9, v2, v1
    v.cmp.lt     p1, v3, v6
    v.movi       v1, #3
    v.add        v3, v2, v5
    v.add        v5, v4, v0
    v.add        v0, v4, v1
    v.add        v4, v2, v1
    s.shli       s5, s1, #2                      // element offset -> bytes (x4)
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s3, v7]               // index is in elements (ISA sec 9.1)
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v6, [s4, v2]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s3, v8]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v7, v6
    vf.mul       v6, v2, v7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s4, v9]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v7, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s3, v0]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v0, v2
    vf.mul       v2, v7, v0
    vf.add       v0, v6, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v2, [s4, v3]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v3, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v1, [s3, v5]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v5, v2
    vf.mul       v2, v3, v5
    vf.add       v3, v0, v2
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v0, [s4, v4]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v2, v1
    vf.cvt.bf16.f32 v1, v0
    s.ld.d       s1, [s2, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    vf.mul       v0, v2, v1
    vf.add       v1, v3, v0
    s.add        s2, s1, s5                      // &out_ptr0[...]
    @p1 v.st.w       [s2, #0], v1
__rctx_next:
    exit
