# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.resnet_block__tiny__fp32-n1-c8-hw8/inductor_cache/h7/ch7byiawbjpv4giw3cjvblhv2pqriczawvwfjebackeyrgfqi6fs.py
# Topologically Sorted Source Nodes: [conv2d], Original ATen: [aten.convolution]
# Source node to ATen node mapping:
#   conv2d => convolution
# Graph fragment:
#   %arg1_1 : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %convolution : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.convolution.default](args = (%arg1_1, %arg0_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1), kwargs = {})
#   return %buf0
triton_poi_fused_convolution_0 = async_compile.triton('triton_poi_fused_convolution_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'y': 8, 'x': 64}, tile_hint=TileHint.SQUARE,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_poi_fused_convolution_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'y': 4096, 'x': 2048}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'tma_min_block_sizes': {'YBLOCK': 4}, 'uses_tma': True, 'uses_device_tma': True},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_convolution_0(in_ptr0, out_ptr0, ynumel, xnumel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 8
    xnumel = 64
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :]
    xmask = xindex < xnumel
    x1 = xindex
    y0 = yindex
    tmp0 = tl.load(in_ptr0 + (x1 + 64*y0), xmask & ymask)
    tl.make_tensor_descriptor(out_ptr0, shape=[64, 8], strides=[8, 1], block_shape=[XBLOCK, YBLOCK]).store([xoffset, yoffset], tl.trans(tl.broadcast_to(tmp0, [YBLOCK, XBLOCK]), [1, 0]).to(tl.float32))
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.resnet_block__tiny__fp32-n1-c8-hw8/inductor_cache/lf/clfae6y6ovbxybqb2mkip24pqsybbrrecpk4fu4v5vobhqgdr6hl.py
# Topologically Sorted Source Nodes: [conv2d], Original ATen: [aten.convolution]
# Source node to ATen node mapping:
#   conv2d => convolution
# Graph fragment:
#   %arg0_1 : Tensor "f32[8, 8, 3, 3][72, 9, 3, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %convolution : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.convolution.default](args = (%arg1_1, %arg0_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1), kwargs = {})
#   return %buf1
triton_poi_fused_convolution_1 = async_compile.triton('triton_poi_fused_convolution_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'y': 64, 'x': 16}, tile_hint=TileHint.SQUARE,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'ynumel': 'i32', 'xnumel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'kernel_name': 'triton_poi_fused_convolution_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'y': 4608, 'x': 2304}, 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_convolution_1(in_ptr0, out_ptr0, ynumel, xnumel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 64
    xnumel = 9
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :]
    xmask = xindex < xnumel
    x2 = xindex
    y3 = yindex
    y0 = (yindex % 8)
    y1 = yindex // 8
    tmp0 = tl.load(in_ptr0 + (x2 + 9*y3), xmask & ymask)
    tl.store(out_ptr0 + (y0 + 8*x2 + 72*y1), tmp0, xmask & ymask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.resnet_block__tiny__fp32-n1-c8-hw8/inductor_cache/lh/clhzydboihdfejbtgsjq7sbf6hssr6soaxpzxt4ebd7nzk2kkbhp.py
# Topologically Sorted Source Nodes: [conv2d, batch_norm, y], Original ATen: [aten.convolution, aten._native_batch_norm_legit_no_training, aten.relu]
# Source node to ATen node mapping:
#   batch_norm => add, add_1, mul, mul_1, rsqrt, sub, unsqueeze, unsqueeze_1, unsqueeze_2, unsqueeze_3, unsqueeze_4, unsqueeze_5, unsqueeze_6, unsqueeze_7
#   conv2d => convolution
#   y => relu
# Graph fragment:
#   %buf0 : Tensor "f32[1, 8, 8, 8][512, 1, 64, 8]tnca:0" = PlaceHolder[target=buf0]
#   %buf1 : Tensor "f32[8, 8, 3, 3][72, 1, 24, 8]tnca:0" = PlaceHolder[target=buf1]
#   %convolution : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0" = PlaceHolder[target=convolution]
#   %arg2_1 : Tensor "f32[8][1]tnca:0" = PlaceHolder[target=arg2_1]
#   %arg3_1 : Tensor "f32[8][1]tnca:0" = PlaceHolder[target=arg3_1]
#   %arg4_1 : Tensor "f32[8][1]tnca:0" = PlaceHolder[target=arg4_1]
#   %arg5_1 : Tensor "f32[8][1]tnca:0" = PlaceHolder[target=arg5_1]
#   %convolution : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.convolution.default](args = (%arg1_1, %arg0_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1), kwargs = {})
#   %unsqueeze : Tensor "f32[8, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg2_1, -1), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[8, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, -1), kwargs = {})
#   %sub : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%convolution, %unsqueeze_1), kwargs = {})
#   %add : Tensor "f32[8][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg3_1, 1e-05), kwargs = {})
#   %rsqrt : Tensor "f32[8][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %unsqueeze_2 : Tensor "f32[8, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%rsqrt, -1), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[8, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_2, -1), kwargs = {})
#   %mul : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub, %unsqueeze_3), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[8, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, -1), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[8, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_4, -1), kwargs = {})
#   %mul_1 : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %unsqueeze_5), kwargs = {})
#   %unsqueeze_6 : Tensor "f32[8, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg5_1, -1), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[8, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_6, -1), kwargs = {})
#   %add_1 : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_1, %unsqueeze_7), kwargs = {})
#   %relu : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.relu.default](args = (%add_1,), kwargs = {})
#   return %convolution,%relu
triton_tem_fused__native_batch_norm_legit_no_training_convolution_relu_2 = async_compile.triton('triton_tem_fused__native_batch_norm_legit_no_training_convolution_relu_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_X': '*fp32', 'arg_W': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': '*fp32', 'out_ptr1': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__native_batch_norm_legit_no_training_convolution_relu_2', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'KERNEL_H': 3, 'KERNEL_W': 3, 'STRIDE_H': 1, 'STRIDE_W': 1, 'PADDING_H': 1, 'PADDING_W': 1, 'GROUPS': 1, 'UNROLL': False, 'ALLOW_TF32': False, 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16}},

)
@triton.jit
def triton_tem_fused__native_batch_norm_legit_no_training_convolution_relu_2(arg_X, arg_W, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr1):
    KERNEL_H : tl.constexpr = 3
    KERNEL_W : tl.constexpr = 3
    STRIDE_H : tl.constexpr = 1
    STRIDE_W : tl.constexpr = 1
    PADDING_H : tl.constexpr = 1
    PADDING_W : tl.constexpr = 1
    GROUPS : tl.constexpr = 1
    UNROLL : tl.constexpr = False
    ALLOW_TF32 : tl.constexpr = False
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    INDEX_DTYPE : tl.constexpr = tl.int32
    X = arg_X
    W = arg_W

    # Tensor dimensions
    BATCH = 1
    IN_C = 8
    IN_H = 8
    IN_W = 8
    OUT_C = 8
    OUT_H = 8
    OUT_W = 8

    # Strides:
    stride_xn = 512
    stride_xc = 1
    stride_xh = 64
    stride_xw = 8
    stride_wc_out = 72
    stride_wc_in = 1
    stride_wh = 24
    stride_ww = 8

    nhw = tl.program_id(0).to(INDEX_DTYPE) * BLOCK_M + tl.arange(0, BLOCK_M)
    idx_y_w = nhw % OUT_W
    nh = nhw // OUT_W
    idx_y_h = nh % OUT_H
    idx_n = nh // OUT_H
    idx_y_c = tl.program_id(1).to(INDEX_DTYPE) * BLOCK_N + tl.arange(0, BLOCK_N)


    group = 0
    GROUP_IN_C = IN_C
    GROUP_OUT_C = OUT_C


    x_base = X + (group * stride_xc * GROUP_IN_C + idx_n * stride_xn)[:, None]
    w_base = (
        W + (group * stride_wc_out * GROUP_OUT_C + idx_y_c * stride_wc_out)[None, :]
    )

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)


    # Could be simplified, but slightly slower:
    # for i in range(KERNEL_H):
    #     for j in range(KERNEL_W):
    #         for k in range(0, GROUP_IN_C, BLOCK_K):
    BLOCK_K_COUNT = (GROUP_IN_C + BLOCK_K - 1) // BLOCK_K
    for ijk in range(KERNEL_H * KERNEL_W * BLOCK_K_COUNT):
        k = (ijk % BLOCK_K_COUNT) * BLOCK_K
        ij = ijk // BLOCK_K_COUNT
        i = ij // KERNEL_W
        j = ij % KERNEL_W

        idx_x_h = i - PADDING_H + idx_y_h * STRIDE_H
        idx_x_w = j - PADDING_W + idx_y_w * STRIDE_W
        idx_x_c = tl.arange(0, BLOCK_K) + k

        x_ptrs = x_base + (
            (idx_x_h * stride_xh)[:, None]
            + (idx_x_w * stride_xw)[:, None]
            + (idx_x_c * stride_xc)[None, :]
        )
        mask_x = (
            (idx_n < BATCH)[:, None]
            & (idx_x_h >= 0)[:, None]
            & (idx_x_h < IN_H)[:, None]
            & (idx_x_w >= 0)[:, None]
            & (idx_x_w < IN_W)[:, None]
            & (idx_x_c < GROUP_IN_C)[None, :]
        )
        matrix_x = tl.load(x_ptrs, mask=mask_x, other=0.0)

        w_ptrs = w_base + (
            (idx_x_c * stride_wc_in)[:, None] + (i * stride_wh) + (j * stride_ww)
        )
        mask_w = (idx_x_c[:, None] < GROUP_IN_C) & (idx_y_c[None, :] < GROUP_OUT_C)
        matrix_w = tl.load(w_ptrs, mask=mask_w, other=0.0)
        acc += tl.dot(matrix_x, matrix_w, allow_tf32=ALLOW_TF32)



    mask = (
        (idx_n < BATCH)[:, None]
        & (idx_y_h < OUT_H)[:, None]
        & (idx_y_w < OUT_W)[:, None]
        & (idx_y_c < GROUP_OUT_C)[None, :]
    )
    idx_n = idx_n[:, None]
    idx_c = idx_y_c[None, :] + group * GROUP_OUT_C
    idx_h = idx_y_h[:, None]
    idx_w = idx_y_w[:, None]

    # inductor generates a suffix
    xindex = idx_w + 8*idx_h + 64*idx_c + 512*idx_n
    x5 = (xindex % 64)
    tmp0 = tl.load(in_ptr2 + (tl.broadcast_to(idx_c, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr3 + (tl.broadcast_to(idx_c, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last')
    tmp7 = tl.load(in_ptr4 + (tl.broadcast_to(idx_c, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr5 + (tl.broadcast_to(idx_c, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last')
    tmp1 = acc - tmp0
    tmp3 = tl.full([1], 1e-05, tl.float32)
    tmp4 = tmp2 + tmp3
    tmp5 = libdevice.rsqrt(tmp4)
    tmp6 = tmp1 * tmp5
    tmp8 = tmp6 * tmp7
    tmp10 = tmp8 + tmp9
    tmp11 = tl.full([1], 0, tl.int32)
    tmp12 = tl.maximum(tmp11, tmp10, tl.PropagateNan.ALL)
    tl.store(out_ptr1 + (idx_c + 8*x5), tmp12, mask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-accept-p2/pipeline-default-audit-v5/runs/model.resnet_block__tiny__fp32-n1-c8-hw8/inductor_cache/2n/c2nt7fgzfx7wyxdbm4tgyddqjfuptdhgblmuls5au6pne5wspacg.py
# Topologically Sorted Source Nodes: [batch_norm, y, conv2d_1, batch_norm_1, add, relu_1], Original ATen: [aten._native_batch_norm_legit_no_training, aten.relu, aten.convolution, aten.add]
# Source node to ATen node mapping:
#   add => add_4
#   batch_norm => add, add_1, mul, mul_1, rsqrt, sub, unsqueeze, unsqueeze_1, unsqueeze_2, unsqueeze_3, unsqueeze_4, unsqueeze_5, unsqueeze_6, unsqueeze_7
#   batch_norm_1 => add_2, add_3, mul_2, mul_3, rsqrt_1, sub_1, unsqueeze_10, unsqueeze_11, unsqueeze_12, unsqueeze_13, unsqueeze_14, unsqueeze_15, unsqueeze_8, unsqueeze_9
#   conv2d_1 => convolution_1
#   relu_1 => relu_1
#   y => relu
# Graph fragment:
#   %relu : Tensor "f32[1, 8, 8, 8][512, 1, 64, 8]tnca:0" = PlaceHolder[target=relu]
#   %buf4 : Tensor "f32[8, 8, 3, 3][72, 1, 24, 8]tnca:0" = PlaceHolder[target=buf4]
#   %convolution_1 : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0" = PlaceHolder[target=convolution_1]
#   %arg7_1 : Tensor "f32[8][1]tnca:0" = PlaceHolder[target=arg7_1]
#   %arg8_1 : Tensor "f32[8][1]tnca:0" = PlaceHolder[target=arg8_1]
#   %arg9_1 : Tensor "f32[8][1]tnca:0" = PlaceHolder[target=arg9_1]
#   %arg10_1 : Tensor "f32[8][1]tnca:0" = PlaceHolder[target=arg10_1]
#   %arg1_1 : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0" = PlaceHolder[target=arg1_1]
#   %unsqueeze : Tensor "f32[8, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg2_1, -1), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[8, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, -1), kwargs = {})
#   %sub : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%convolution, %unsqueeze_1), kwargs = {})
#   %add : Tensor "f32[8][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg3_1, 1e-05), kwargs = {})
#   %rsqrt : Tensor "f32[8][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %unsqueeze_2 : Tensor "f32[8, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%rsqrt, -1), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[8, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_2, -1), kwargs = {})
#   %mul : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub, %unsqueeze_3), kwargs = {})
#   %unsqueeze_4 : Tensor "f32[8, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, -1), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[8, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_4, -1), kwargs = {})
#   %mul_1 : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul, %unsqueeze_5), kwargs = {})
#   %unsqueeze_6 : Tensor "f32[8, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg5_1, -1), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[8, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_6, -1), kwargs = {})
#   %add_1 : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_1, %unsqueeze_7), kwargs = {})
#   %relu : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.relu.default](args = (%add_1,), kwargs = {})
#   %convolution_1 : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.convolution.default](args = (%relu, %arg6_1, None, [1, 1], [1, 1], [1, 1], False, [0, 0], 1), kwargs = {})
#   %unsqueeze_8 : Tensor "f32[8, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg7_1, -1), kwargs = {})
#   %unsqueeze_9 : Tensor "f32[8, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_8, -1), kwargs = {})
#   %sub_1 : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%convolution_1, %unsqueeze_9), kwargs = {})
#   %add_2 : Tensor "f32[8][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg8_1, 1e-05), kwargs = {})
#   %rsqrt_1 : Tensor "f32[8][1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_2,), kwargs = {})
#   %unsqueeze_10 : Tensor "f32[8, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%rsqrt_1, -1), kwargs = {})
#   %unsqueeze_11 : Tensor "f32[8, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_10, -1), kwargs = {})
#   %mul_2 : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub_1, %unsqueeze_11), kwargs = {})
#   %unsqueeze_12 : Tensor "f32[8, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg9_1, -1), kwargs = {})
#   %unsqueeze_13 : Tensor "f32[8, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_12, -1), kwargs = {})
#   %mul_3 : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_2, %unsqueeze_13), kwargs = {})
#   %unsqueeze_14 : Tensor "f32[8, 1][1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg10_1, -1), kwargs = {})
#   %unsqueeze_15 : Tensor "f32[8, 1, 1][1, 1, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze_14, -1), kwargs = {})
#   %add_3 : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_3, %unsqueeze_15), kwargs = {})
#   %add_4 : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_3, %arg1_1), kwargs = {})
#   %relu_1 : Tensor "f32[1, 8, 8, 8][512, 64, 8, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.relu.default](args = (%add_4,), kwargs = {})
#   return %convolution_1,%relu_1
triton_tem_fused__native_batch_norm_legit_no_training_add_convolution_relu_3 = async_compile.triton('triton_tem_fused__native_batch_norm_legit_no_training_add_convolution_relu_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_X': '*fp32', 'arg_W': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': '*fp32', 'in_ptr6': '*fp32', 'out_ptr1': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__native_batch_norm_legit_no_training_add_convolution_relu_3', 'backend_hash': 'D518B551BD02DDEF573559C02F4B2A7475004DB433A022C06323631FA0653C47', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'KERNEL_H': 3, 'KERNEL_W': 3, 'STRIDE_H': 1, 'STRIDE_W': 1, 'PADDING_H': 1, 'PADDING_W': 1, 'GROUPS': 1, 'UNROLL': False, 'ALLOW_TF32': False, 'BLOCK_M': 16, 'BLOCK_N': 16, 'BLOCK_K': 16}},

)
@triton.jit
def triton_tem_fused__native_batch_norm_legit_no_training_add_convolution_relu_3(arg_X, arg_W, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr1):
    KERNEL_H : tl.constexpr = 3
    KERNEL_W : tl.constexpr = 3
    STRIDE_H : tl.constexpr = 1
    STRIDE_W : tl.constexpr = 1
    PADDING_H : tl.constexpr = 1
    PADDING_W : tl.constexpr = 1
    GROUPS : tl.constexpr = 1
    UNROLL : tl.constexpr = False
    ALLOW_TF32 : tl.constexpr = False
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 16
    BLOCK_K : tl.constexpr = 16
    INDEX_DTYPE : tl.constexpr = tl.int32
    X = arg_X
    W = arg_W

    # Tensor dimensions
    BATCH = 1
    IN_C = 8
    IN_H = 8
    IN_W = 8
    OUT_C = 8
    OUT_H = 8
    OUT_W = 8

    # Strides:
    stride_xn = 512
    stride_xc = 1
    stride_xh = 64
    stride_xw = 8
    stride_wc_out = 72
    stride_wc_in = 1
    stride_wh = 24
    stride_ww = 8

    nhw = tl.program_id(0).to(INDEX_DTYPE) * BLOCK_M + tl.arange(0, BLOCK_M)
    idx_y_w = nhw % OUT_W
    nh = nhw // OUT_W
    idx_y_h = nh % OUT_H
    idx_n = nh // OUT_H
    idx_y_c = tl.program_id(1).to(INDEX_DTYPE) * BLOCK_N + tl.arange(0, BLOCK_N)


    group = 0
    GROUP_IN_C = IN_C
    GROUP_OUT_C = OUT_C


    x_base = X + (group * stride_xc * GROUP_IN_C + idx_n * stride_xn)[:, None]
    w_base = (
        W + (group * stride_wc_out * GROUP_OUT_C + idx_y_c * stride_wc_out)[None, :]
    )

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)


    # Could be simplified, but slightly slower:
    # for i in range(KERNEL_H):
    #     for j in range(KERNEL_W):
    #         for k in range(0, GROUP_IN_C, BLOCK_K):
    BLOCK_K_COUNT = (GROUP_IN_C + BLOCK_K - 1) // BLOCK_K
    for ijk in range(KERNEL_H * KERNEL_W * BLOCK_K_COUNT):
        k = (ijk % BLOCK_K_COUNT) * BLOCK_K
        ij = ijk // BLOCK_K_COUNT
        i = ij // KERNEL_W
        j = ij % KERNEL_W

        idx_x_h = i - PADDING_H + idx_y_h * STRIDE_H
        idx_x_w = j - PADDING_W + idx_y_w * STRIDE_W
        idx_x_c = tl.arange(0, BLOCK_K) + k

        x_ptrs = x_base + (
            (idx_x_h * stride_xh)[:, None]
            + (idx_x_w * stride_xw)[:, None]
            + (idx_x_c * stride_xc)[None, :]
        )
        mask_x = (
            (idx_n < BATCH)[:, None]
            & (idx_x_h >= 0)[:, None]
            & (idx_x_h < IN_H)[:, None]
            & (idx_x_w >= 0)[:, None]
            & (idx_x_w < IN_W)[:, None]
            & (idx_x_c < GROUP_IN_C)[None, :]
        )
        matrix_x = tl.load(x_ptrs, mask=mask_x, other=0.0)

        w_ptrs = w_base + (
            (idx_x_c * stride_wc_in)[:, None] + (i * stride_wh) + (j * stride_ww)
        )
        mask_w = (idx_x_c[:, None] < GROUP_IN_C) & (idx_y_c[None, :] < GROUP_OUT_C)
        matrix_w = tl.load(w_ptrs, mask=mask_w, other=0.0)
        acc += tl.dot(matrix_x, matrix_w, allow_tf32=ALLOW_TF32)



    mask = (
        (idx_n < BATCH)[:, None]
        & (idx_y_h < OUT_H)[:, None]
        & (idx_y_w < OUT_W)[:, None]
        & (idx_y_c < GROUP_OUT_C)[None, :]
    )
    idx_n = idx_n[:, None]
    idx_c = idx_y_c[None, :] + group * GROUP_OUT_C
    idx_h = idx_y_h[:, None]
    idx_w = idx_y_w[:, None]

    # inductor generates a suffix
    xindex = idx_w + 8*idx_h + 64*idx_c + 512*idx_n
    tmp0 = tl.load(in_ptr2 + (tl.broadcast_to(idx_c, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr3 + (tl.broadcast_to(idx_c, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last')
    tmp7 = tl.load(in_ptr4 + (tl.broadcast_to(idx_c, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr5 + (tl.broadcast_to(idx_c, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last')
    tmp11 = tl.load(in_ptr6 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), mask, eviction_policy='evict_last')
    tmp1 = acc - tmp0
    tmp3 = tl.full([1], 1e-05, tl.float32)
    tmp4 = tmp2 + tmp3
    tmp5 = libdevice.rsqrt(tmp4)
    tmp6 = tmp1 * tmp5
    tmp8 = tmp6 * tmp7
    tmp10 = tmp8 + tmp9
    tmp12 = tmp10 + tmp11
    tmp13 = tl.full([1], 0, tl.int32)
    tmp14 = tl.maximum(tmp13, tmp12, tl.PropagateNan.ALL)
    tl.store(out_ptr1 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), tmp14, mask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1 = args
        args.clear()
        assert_size_stride(arg1_1, (1, 8, 8, 8), (512, 64, 8, 1), 'input')
        buf0 = empty_strided((1, 8, 8, 8), (512, 1, 64, 8), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [conv2d], Original ATen: [aten.convolution]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_0.run(arg1_1, buf0, 8, 64, stream=raw_stream0)
        assert_size_stride(arg0_1, (8, 8, 3, 3), (72, 9, 3, 1), 'input')
        buf1 = empty_strided((8, 8, 3, 3), (72, 1, 24, 8), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [conv2d], Original ATen: [aten.convolution]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_1.run(arg0_1, buf1, 64, 9, stream=raw_stream0)
        del arg0_1
        assert_size_stride_grouped((arg2_1, arg3_1, arg4_1, arg5_1), ((8, ), (8, ), (8, ), (8, )), ((1, ), (1, ), (1, ), (1, )), 'input')
        buf3 = empty_strided((1, 8, 8, 8), (512, 1, 64, 8), device='tnca', dtype=torch.float32)
        # Topologically Sorted Source Nodes: [conv2d, batch_norm, y], Original ATen: [aten.convolution, aten._native_batch_norm_legit_no_training, aten.relu]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__native_batch_norm_legit_no_training_convolution_relu_2.run(buf0, buf1, arg2_1, arg3_1, arg4_1, arg5_1, buf3, 4, 1, 1, stream=raw_stream0)
        del arg2_1
        del arg3_1
        del arg4_1
        del arg5_1
        assert_size_stride(arg6_1, (8, 8, 3, 3), (72, 9, 3, 1), 'input')
        buf4 = buf1; del buf1  # reuse
        # Topologically Sorted Source Nodes: [batch_norm, y, conv2d_1], Original ATen: [aten._native_batch_norm_legit_no_training, aten.relu, aten.convolution]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_convolution_1.run(arg6_1, buf4, 64, 9, stream=raw_stream0)
        del arg6_1
        assert_size_stride_grouped((arg7_1, arg8_1, arg9_1, arg10_1), ((8, ), (8, ), (8, ), (8, )), ((1, ), (1, ), (1, ), (1, )), 'input')
        buf6 = reinterpret_tensor(buf0, (1, 8, 8, 8), (512, 64, 8, 1), 0); del buf0  # reuse
        # Topologically Sorted Source Nodes: [batch_norm, y, conv2d_1, batch_norm_1, add, relu_1], Original ATen: [aten._native_batch_norm_legit_no_training, aten.relu, aten.convolution, aten.add]
        raw_stream0 = get_raw_stream(0)
        triton_tem_fused__native_batch_norm_legit_no_training_add_convolution_relu_3.run(buf3, buf4, arg7_1, arg8_1, arg9_1, arg10_1, arg1_1, buf6, 4, 1, 1, stream=raw_stream0)
        del arg10_1
        del arg1_1
        del arg7_1
        del arg8_1
        del arg9_1
        return (buf6, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((8, 8, 3, 3), (72, 9, 3, 1), device='tnca:0', dtype=torch.float32)
    arg1_1 = rand_strided((1, 8, 8, 8), (512, 64, 8, 1), device='tnca:0', dtype=torch.float32)
    arg2_1 = rand_strided((8, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg3_1 = rand_strided((8, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg4_1 = rand_strided((8, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg5_1 = rand_strided((8, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg6_1 = rand_strided((8, 8, 3, 3), (72, 9, 3, 1), device='tnca:0', dtype=torch.float32)
    arg7_1 = rand_strided((8, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg8_1 = rand_strided((8, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg9_1 = rand_strided((8, ), (1, ), device='tnca:0', dtype=torch.float32)
    arg10_1 = rand_strided((8, ), (1, ), device='tnca:0', dtype=torch.float32)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
