

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=1,
num_warps=1,
triton_meta={'signature': {'arg_A': '*fp8e4nv', 'arg_B': '*fp8e4nv', 'arg_SA': '*fp32', 'arg_SB': '*fp32', 'out_ptr0': '*fp32'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'configs': [{(4,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'Placeholder.DESCRIPTIVE_NAME', 'backend_hash': 'CA5032EC726CA6E61C0217C0A8AA4F8F7BE235BC0C62059C21A6728B52CF91B7', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'BLOCK_M': 64, 'BLOCK_N': 64, 'BLOCK_K': 128, 'TILE_A': 1, 'TILE_B': 128, 'KSUB': 128, 'SA_KB_FIRST': False, 'SB_KB_FIRST': True}},

)
@triton.jit
def triton_tnca_scaled_mm_blockwise(arg_A, arg_B, arg_SA, arg_SB, out_ptr0):
    BLOCK_M : tl.constexpr = 64
    BLOCK_N : tl.constexpr = 64
    BLOCK_K : tl.constexpr = 128
    TILE_A : tl.constexpr = 1
    TILE_B : tl.constexpr = 128
    KSUB : tl.constexpr = 128
    SA_KB_FIRST : tl.constexpr = False
    SB_KB_FIRST : tl.constexpr = True
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B
    SA = arg_SA
    SB = arg_SB

    M = 64
    N = 256
    K = 256
    if M * N == 0:
        return
    stride_am = 256
    stride_ak = 1
    stride_bk = 1
    stride_bn = 256
    sa_r = 1
    sa_k = 64
    sb_k = 1
    sb_c = 4

    pid = tl.program_id(0)
    grid_n = (N + BLOCK_N - 1) // BLOCK_N
    pid_m = pid // grid_n
    pid_n = pid % grid_n
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_m = rm % M
    offs_n = rn % N
    offs_k = tl.arange(0, KSUB)
    a_ptrs = A + (offs_m[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_n[None, :] * stride_bn)
    sa_ptrs = SA + (offs_m // TILE_A) * sa_r
    sb_ptrs = SB + (offs_n // TILE_B) * sb_c

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for kb in range(0, tl.cdiv(K, BLOCK_K)):
        k_remaining = K - kb * BLOCK_K
        a_s = tl.load(sa_ptrs + kb * sa_k)
        b_s = tl.load(sb_ptrs + kb * sb_k)
        a = tl.load(a_ptrs, mask=offs_k[None, :] < k_remaining, other=0.0)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_remaining, other=0.0)
        acc += tl.dot(a, b) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_K * stride_ak
        b_ptrs += BLOCK_K * stride_bk

    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 256*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)