# AOT ID: ['2_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import tnca.torch_device
tnca.torch_device.register()
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from tnca.torch_device.inductor_device import get_raw_stream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /home/zhongchun/r41-addr64-work/h1/cache/inductor/ck/ccklfmunlloxabht7chkqerxhz5vzmi6t56bz47nwwwf2gmkxqev.py
# Topologically Sorted Source Nodes: [getitem, getitem_1, getitem_2, cat], Original ATen: [aten.slice, aten.cat]
# Source node to ATen node mapping:
#   cat => cat
#   getitem => slice_1, slice_2
#   getitem_1 => slice_3, slice_4
#   getitem_2 => slice_5, slice_6
# Graph fragment:
#   %arg0_1 : Tensor "bf16[589824, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %slice_1 : Tensor "bf16[8, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg0_1, 0, 0, 8), kwargs = {})
#   %slice_2 : Tensor "bf16[8, 64][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_1, 1, 0, 64), kwargs = {})
#   %slice_3 : Tensor "bf16[8, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg0_1, 0, -8, 9223372036854775807), kwargs = {})
#   %slice_4 : Tensor "bf16[8, 64][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_3, 1, 0, 64), kwargs = {})
#   %slice_5 : Tensor "bf16[8, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg0_1, 0, 294912, 294920), kwargs = {})
#   %slice_6 : Tensor "bf16[8, 64][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_5, 1, 0, 64), kwargs = {})
#   %cat : Tensor "bf16[24, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%slice_2, %slice_4, %slice_6],), kwargs = {})
#   return %buf0
triton_poi_fused_cat_slice_0 = async_compile.triton('triton_poi_fused_cat_slice_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_cat_slice_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3072}, 'backend_hash': 'F7A510A5B4757A8AFA4C5CB01E3AA47E837DCA4F150A7B3D4FC4F62F051AD5E4', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_slice_0(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 2048*x1), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x2), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-addr64-work/h1/cache/inductor/ho/chov7fvlu7wdphw4q62woraol54y5ziuzgxtmlq6jibtc5uwgjpd.py
# Topologically Sorted Source Nodes: [getitem, getitem_1, getitem_2, cat], Original ATen: [aten.slice, aten.cat]
# Source node to ATen node mapping:
#   cat => cat
#   getitem => slice_1, slice_2
#   getitem_1 => slice_3, slice_4
#   getitem_2 => slice_5, slice_6
# Graph fragment:
#   %arg0_1 : Tensor "bf16[589824, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %slice_1 : Tensor "bf16[8, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg0_1, 0, 0, 8), kwargs = {})
#   %slice_2 : Tensor "bf16[8, 64][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_1, 1, 0, 64), kwargs = {})
#   %slice_3 : Tensor "bf16[8, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg0_1, 0, -8, 9223372036854775807), kwargs = {})
#   %slice_4 : Tensor "bf16[8, 64][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_3, 1, 0, 64), kwargs = {})
#   %slice_5 : Tensor "bf16[8, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg0_1, 0, 294912, 294920), kwargs = {})
#   %slice_6 : Tensor "bf16[8, 64][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_5, 1, 0, 64), kwargs = {})
#   %cat : Tensor "bf16[24, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%slice_2, %slice_4, %slice_6],), kwargs = {})
#   return %buf1
triton_poi_fused_cat_slice_1 = async_compile.triton('triton_poi_fused_cat_slice_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_cat_slice_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3072}, 'backend_hash': 'F7A510A5B4757A8AFA4C5CB01E3AA47E837DCA4F150A7B3D4FC4F62F051AD5E4', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_slice_1(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (1207943168 + x0 + 2048*x1), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x2), tmp0, xmask)
''', device_str='tnca')


# kernel path: /home/zhongchun/r41-addr64-work/h1/cache/inductor/jq/cjq37felam2wjxjub47kmr5mtqhprpo7ite2ajnshyhekupdsyv4.py
# Topologically Sorted Source Nodes: [getitem, getitem_1, getitem_2, cat], Original ATen: [aten.slice, aten.cat]
# Source node to ATen node mapping:
#   cat => cat
#   getitem => slice_1, slice_2
#   getitem_1 => slice_3, slice_4
#   getitem_2 => slice_5, slice_6
# Graph fragment:
#   %arg0_1 : Tensor "bf16[589824, 2048][2048, 1]tnca:0" = PlaceHolder[target=arg0_1]
#   %slice_1 : Tensor "bf16[8, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg0_1, 0, 0, 8), kwargs = {})
#   %slice_2 : Tensor "bf16[8, 64][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_1, 1, 0, 64), kwargs = {})
#   %slice_3 : Tensor "bf16[8, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg0_1, 0, -8, 9223372036854775807), kwargs = {})
#   %slice_4 : Tensor "bf16[8, 64][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_3, 1, 0, 64), kwargs = {})
#   %slice_5 : Tensor "bf16[8, 2048][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg0_1, 0, 294912, 294920), kwargs = {})
#   %slice_6 : Tensor "bf16[8, 64][2048, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_5, 1, 0, 64), kwargs = {})
#   %cat : Tensor "bf16[24, 64][64, 1]tnca:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%slice_2, %slice_4, %slice_6],), kwargs = {})
#   return %buf2
triton_poi_fused_cat_slice_2 = async_compile.triton('triton_poi_fused_cat_slice_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='tnca', index=0, multi_processor_count=1, cc=0, major=0, regs_per_multiprocessor=256, max_threads_per_multi_processor=64, max_threads_per_block=16, warp_size=1), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_cat_slice_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 3072}, 'backend_hash': 'F7A510A5B4757A8AFA4C5CB01E3AA47E837DCA4F150A7B3D4FC4F62F051AD5E4', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_slice_2(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (603979776 + x0 + 2048*x1), xmask).to(tl.float32)
    tl.store(out_ptr0 + (x2), tmp0, xmask)
''', device_str='tnca')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, = args
        args.clear()
        assert_size_stride(arg0_1, (589824, 2048), (2048, 1), 'input')
        buf3 = empty_strided((24, 64), (64, 1), device='tnca', dtype=torch.bfloat16)
        buf0 = reinterpret_tensor(buf3, (8, 64), (64, 1), 0)  # alias
        # Topologically Sorted Source Nodes: [getitem, getitem_1, getitem_2, cat], Original ATen: [aten.slice, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_slice_0.run(arg0_1, buf0, 512, stream=raw_stream0)
        buf1 = reinterpret_tensor(buf3, (8, 64), (64, 1), 512)  # alias
        # Topologically Sorted Source Nodes: [getitem, getitem_1, getitem_2, cat], Original ATen: [aten.slice, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_slice_1.run(arg0_1, buf1, 512, stream=raw_stream0)
        buf2 = reinterpret_tensor(buf3, (8, 64), (64, 1), 1024)  # alias
        # Topologically Sorted Source Nodes: [getitem, getitem_1, getitem_2, cat], Original ATen: [aten.slice, aten.cat]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_cat_slice_2.run(arg0_1, buf2, 512, stream=raw_stream0)
        del arg0_1
        return (buf3, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((589824, 2048), (2048, 1), device='tnca:0', dtype=torch.bfloat16)
    return [arg0_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='tnca')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
