    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.shli       s1, s4, #4                      // x16 as a shift
    s.rdspecial  s2, pid.y
    s.rdspecial  s3, arg_base
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s4, #0
    s.muli       s5, s1, #32                     // a runtime tile origin, x32
    s.shli       s6, s2, #4                      // x16 as a shift
    s.ld.d       s2, [s3, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s7, #32
    s.add        s8, s4, s1                      // the tile origin
    s.add        s9, s4, s6                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s7
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s8
    s.add        s7, s9, s5                      // the tile origin
    s.add        s5, s4, s6                      // the tile origin
    v.mul        v4, v0, v1
    v.splat      v0, s7
    v.add        v1, v2, v3
    v.splat      v2, s5
    v.add        v3, v4, v0
    v.cmpi.lt    p1, v1, #32
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    s.addi       s8, s7, #1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s2, v3]               // index is in elements (ISA sec 9.1)
    s.addi       s9, s5, #1
    v.splat      v1, s8
    v.splat      v2, s9
    s.addi       s8, s7, #2
    v.add        v3, v4, v1
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    s.addi       s9, s5, #2
    v.splat      v1, s8
    v.splat      v2, s9
    s.movz       s8, #1
    v.add        v5, v4, v1
    v.cmpi.lt    p2, v2, #32
    p.and        p4, p1, p2
    s.addi       s9, s7, #3
    s.movz       s10, #2
    v.splat      v1, s9
    s.ld.d       s9, [s3, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    a.vwrite     a0, s4, v0
    s.addi       s3, s5, #3
    v.add        v0, v4, v1
    v.splat      v1, s3
    s.addi       s3, s7, #4
    s.addi       s4, s5, #4
    v.splat      v2, s3
    v.splat      v6, s4
    s.movz       s3, #3
    v.add        v7, v4, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v2, [s2, v3]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    s.addi       s4, s7, #5
    s.addi       s11, s5, #5
    v.splat      v1, s4
    v.splat      v3, s11
    s.movz       s4, #4
    v.add        v8, v4, v1
    s.addi       s11, s7, #6
    s.addi       s12, s5, #6
    a.vwrite     a0, s8, v2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v1, [s2, v5]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v6, #32
    p.and        p4, p1, p2
    v.splat      v2, s11
    v.splat      v5, s12
    s.movz       s8, #5
    v.add        v6, v4, v2
    s.addi       s11, s7, #7
    s.addi       s12, s5, #7
    a.vwrite     a0, s10, v1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v1, [s2, v0]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v3, #32
    p.and        p3, p1, p2
    v.splat      v0, s11
    v.splat      v2, s12
    s.movz       s10, #6
    v.add        v3, v4, v0
    s.addi       s11, s7, #8
    s.addi       s12, s5, #8
    a.vwrite     a0, s3, v1
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s2, v7]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v5, #32
    p.and        p4, p1, p2
    v.splat      v1, s11
    v.splat      v5, s12
    s.movz       s3, #7
    v.add        v7, v4, v1
    s.addi       s11, s7, #9
    s.addi       s12, s5, #9
    a.vwrite     a0, s4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s2, v8]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    v.splat      v1, s11
    v.splat      v2, s12
    s.movz       s4, #8
    v.add        v8, v4, v1
    s.addi       s11, s7, #10
    s.addi       s12, s5, #10
    a.vwrite     a0, s8, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s2, v6]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v5, #32
    p.and        p4, p1, p2
    v.splat      v1, s11
    v.splat      v5, s12
    s.movz       s8, #9
    v.add        v6, v4, v1
    s.addi       s11, s7, #11
    s.addi       s12, s5, #11
    a.vwrite     a0, s10, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s2, v3]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    v.splat      v1, s11
    v.splat      v2, s12
    s.movz       s10, #10
    v.add        v3, v4, v1
    s.addi       s11, s7, #12
    s.addi       s12, s5, #12
    a.vwrite     a0, s3, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s2, v7]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v5, #32
    p.and        p4, p1, p2
    v.splat      v1, s11
    v.splat      v5, s12
    s.movz       s3, #11
    v.add        v7, v4, v1
    s.addi       s11, s7, #13
    s.addi       s12, s5, #13
    a.vwrite     a0, s4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s2, v8]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    v.splat      v1, s11
    v.splat      v2, s12
    s.movz       s4, #12
    v.add        v8, v4, v1
    s.addi       s11, s7, #14
    s.addi       s12, s5, #14
    a.vwrite     a0, s8, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s2, v6]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v5, #32
    p.and        p4, p1, p2
    v.splat      v1, s11
    v.splat      v5, s12
    s.movz       s8, #13
    v.add        v6, v4, v1
    s.addi       s11, s7, #15
    s.addi       s7, s5, #15
    s.movz       s12, #14
    a.vwrite     a0, s10, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s2, v3]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    v.splat      v1, s11
    v.splat      v2, s7
    s.muli       s7, s1, #4                      // a runtime tile origin, x4
    v.add        v3, v4, v1
    s.muli       s1, s6, #128                    // a runtime tile origin, x128
    v.splat      v1, s5
    s.movz       s6, #15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s10, #0
    s.add        s11, s9, s7                     // the tile origin
    s.add        s7, s11, s1                     // the tile origin
    a.vwrite     a0, s3, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s2, v7]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v5, #32
    p.and        p4, p1, p2
    s.addi       s1, s5, #1
    s.movz       s3, #1
    v.splat      v4, s1
    s.addi       s1, s7, #128                    // row 1
    a.vwrite     a0, s4, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s2, v8]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v2, #32
    p.and        p3, p1, p2
    s.addi       s4, s5, #2
    s.movz       s9, #2
    v.splat      v2, s4
    s.addi       s4, s7, #256                    // row 2
    s.movz       s11, #3
    a.vwrite     a0, s8, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s2, v6]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v1, #32
    p.and        p4, p1, p2
    s.addi       s8, s5, #3
    v.splat      v1, s8
    s.addi       s8, s7, #384                    // row 3
    a.vwrite     a0, s12, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s2, v3]               // index is in elements (ISA sec 9.1)
    v.cmpi.lt    p2, v4, #32
    p.and        p3, p1, p2
    s.addi       s2, s5, #4
    s.movz       s12, #4
    v.splat      v3, s2
    s.addi       s2, s5, #5
    v.splat      v4, s2
    s.addi       s2, s7, #512                    // row 4
    a.vwrite     a0, s6, v0
    a.vread      v0, a0, s10
    s.movz       s6, #5
    s.addi       s10, s5, #6
    @p4 v.st.w       [s7, #0], v0
    a.vread      v0, a0, s3
    v.cmpi.lt    p2, v2, #32
    p.and        p4, p1, p2
    v.splat      v2, s10
    s.addi       s3, s7, #640                    // row 5
    s.movz       s10, #6
    @p3 v.st.w       [s1, #0], v0
    a.vread      v0, a0, s9
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    s.addi       s1, s5, #7
    s.addi       s9, s7, #768                    // row 6
    v.splat      v1, s1
    s.movz       s1, #7
    @p4 v.st.w       [s4, #0], v0
    a.vread      v0, a0, s11
    v.cmpi.lt    p2, v3, #32
    p.and        p4, p1, p2
    s.addi       s4, s5, #8
    s.addi       s11, s7, #896                   // row 7
    v.splat      v3, s4
    s.movz       s4, #8
    @p3 v.st.w       [s8, #0], v0
    a.vread      v0, a0, s12
    v.cmpi.lt    p2, v4, #32
    p.and        p3, p1, p2
    s.addi       s8, s5, #9
    s.addi       s12, s7, #1024                  // row 8
    v.splat      v4, s8
    s.movz       s8, #9
    @p4 v.st.w       [s2, #0], v0
    a.vread      v0, a0, s6
    v.cmpi.lt    p2, v2, #32
    p.and        p4, p1, p2
    s.addi       s2, s5, #10
    s.addi       s6, s7, #1152                   // row 9
    v.splat      v2, s2
    s.movz       s2, #10
    @p3 v.st.w       [s3, #0], v0
    a.vread      v0, a0, s10
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    s.addi       s3, s5, #11
    s.addi       s10, s7, #1280                  // row 10
    v.splat      v1, s3
    s.movz       s3, #11
    @p4 v.st.w       [s9, #0], v0
    a.vread      v0, a0, s1
    v.cmpi.lt    p2, v3, #32
    p.and        p4, p1, p2
    s.addi       s1, s5, #12
    s.addi       s9, s7, #1408                   // row 11
    v.splat      v3, s1
    s.movz       s1, #12
    @p3 v.st.w       [s11, #0], v0
    a.vread      v0, a0, s4
    v.cmpi.lt    p2, v4, #32
    p.and        p3, p1, p2
    s.addi       s4, s5, #13
    s.addi       s11, s7, #1536                  // row 12
    v.splat      v4, s4
    s.movz       s4, #13
    @p4 v.st.w       [s12, #0], v0
    a.vread      v0, a0, s8
    v.cmpi.lt    p2, v2, #32
    p.and        p4, p1, p2
    s.addi       s8, s5, #14
    s.addi       s12, s7, #1664                  // row 13
    v.splat      v2, s8
    s.movz       s8, #14
    s.addi       s13, s5, #15
    v.splat      v5, s13
    s.addi       s5, s7, #1792                   // row 14
    s.addi       s13, s7, #1920                  // row 15
    @p3 v.st.w       [s6, #0], v0
    a.vread      v0, a0, s2
    v.cmpi.lt    p2, v1, #32
    p.and        p3, p1, p2
    s.movz       s2, #15
    @p4 v.st.w       [s10, #0], v0
    a.vread      v0, a0, s3
    v.cmpi.lt    p2, v3, #32
    p.and        p4, p1, p2
    @p3 v.st.w       [s9, #0], v0
    a.vread      v0, a0, s1
    v.cmpi.lt    p2, v4, #32
    p.and        p3, p1, p2
    @p4 v.st.w       [s11, #0], v0
    a.vread      v0, a0, s4
    v.cmpi.lt    p2, v2, #32
    p.and        p4, p1, p2
    @p3 v.st.w       [s12, #0], v0
    a.vread      v0, a0, s8
    v.cmpi.lt    p2, v5, #32
    p.and        p3, p1, p2
    @p4 v.st.w       [s5, #0], v0
    a.vread      v0, a0, s2
    @p3 v.st.w       [s13, #0], v0
__rctx_next:
    exit
