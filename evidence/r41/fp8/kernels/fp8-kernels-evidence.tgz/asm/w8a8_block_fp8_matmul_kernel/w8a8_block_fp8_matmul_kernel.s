    s.rdspecial  s1, arg_base
    s.movz       s2, #127
    s.ld.sw      s3, [s1, #48]                   // N: i32 at arg_base+48
    s.movz       s4, #0
    s.movz       s5, #0
    s.movz       s6, #128
    s.movz       s7, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s6, s7
    s.movz       s7, #15
    s.sub        s10, s8, s9
    s.rdspecial  s8, pid.x
    s.movz       s9, #0
    s.add        s11, s3, s2
    s.ld.sw      s12, [s1, #40]                  // M: i32 at arg_base+40
    s.cmp.lt     s13, s11, s4
    s.movz       s4, #0
    s.sub        s14, s5, s13
    s.rdspecial  s5, pid.y
    s.xor        s13, s11, s14
    s.movz       s11, #16
    s.movz       s15, #0
    s.movz       s16, #0
    s.cmp.lt     s17, s11, s15
    s.add        s15, s12, s7
    s.sub        s7, s16, s17
    s.cmp.lt     s16, s15, s9
    s.xor        s9, s11, s7
    s.sub        s17, s4, s16
    s.ld.d       s4, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.sub        s16, s13, s14
    s.xor        s13, s15, s17
    s.xor        s15, s17, s7
    s.sub        s18, s13, s17
    s.sub        s13, s9, s7
    s.lshri      s7, s18, #4
    s.muli       s9, s7, #16
    s.xor        s13, s7, s15
    s.ld.d       s7, [s1, #8]                    // B: device_ptr64 at arg_base+8
    s.xor        s17, s6, s10
    s.sub        s19, s18, s9
    s.sub        s9, s13, s15
    s.ld.d       s13, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.sub        s15, s17, s10
    s.ld.d       s15, [s1, #24]                  // As: device_ptr64 at arg_base+24
    s.lshri      s17, s16, #7
    s.ld.d       s18, [s1, #32]                  // Bs: device_ptr64 at arg_base+32
    s.xor        s19, s14, s10
    s.muli       s10, s17, #128
    s.sub        s14, s16, s10
    s.ld.sw      s10, [s1, #56]                  // K: i32 at arg_base+56
    s.xor        s14, s17, s19
    s.ld.sw      s16, [s1, #64]                  // stride_am: i32 at arg_base+64
    s.sub        s17, s14, s19
    s.ld.sw      s14, [s1, #72]                  // stride_bn: i32 at arg_base+72
    s.mul        s19, s8, s17
    s.ld.sw      s8, [s1, #80]                   // stride_cm: i32 at arg_base+80
    s.add        s20, s19, s5
    s.ld.sw      s5, [s1, #88]                   // stride_as_m: i32 at arg_base+88
    s.movz       s19, #8
    s.ld.sw      s21, [s1, #96]                  // stride_bs_n: i32 at arg_base+96
    s.mul        s1, s17, s19
    s.movz       s17, #0
    s.movz       s22, #0
    s.movz       s23, #0
    s.movz       s24, #0
    s.cmp.lt     s25, s1, s17
    s.cmp.lt     s17, s20, s22
    s.sub        s22, s23, s25
    s.sub        s23, s24, s17
    s.xor        s17, s1, s22
    s.xor        s24, s20, s23
    s.sub        s25, s17, s22
    s.movz       s17, #0
    s.movz       s26, #1
    s.sub        s27, s24, s23
    s.movz       s24, #0
    s.addi       s28, s17, #0
    s.cmp.eq     s17, s25, s26
    s.addi       s26, s24, #0
    s.mov        s28, s27
    br.nz        s17, sdiv_done_1
    s.movz       s17, #0
    s.movz       s24, #31
    s.mov        s28, s17
    s.addi       s17, s24, #0
sdiv_2:
    s.lshr       s24, s27, s17
    s.shli       s29, s26, #1
    s.andi       s30, s24, #1
    s.movz       s24, #0
    s.or         s31, s29, s30
    s.movz       s29, #1
    s.cmp.geu    s30, s31, s25
    s.shl        s32, s29, s17
    s.sub        s29, s24, s30
    s.subi       s24, s17, #1
    s.and        s30, s25, s29
    s.and        s33, s32, s29
    s.sub        s29, s31, s30
    s.or         s30, s28, s33
    s.mov        s26, s29
    s.mov        s28, s30
    s.mov        s17, s24
    s.movz       s24, #0
    s.cmp.ge     s29, s17, s24
    br.nz        s29, sdiv_2
sdiv_done_1:
    s.xor        s17, s23, s22
    s.movz       s22, #0
    s.xor        s23, s28, s17
    s.movz       s24, #0
    s.movz       s25, #0
    s.cmp.lt     s26, s1, s22
    s.sub        s22, s23, s17
    s.movz       s17, #0
    s.cmp.lt     s23, s20, s24
    s.sub        s24, s25, s26
    s.mul        s25, s22, s19
    s.sub        s22, s17, s23
    s.xor        s17, s1, s24
    s.xor        s1, s20, s22
    s.sub        s20, s17, s24
    s.movz       s17, #0
    s.movz       s23, #1
    s.sub        s24, s9, s25
    s.sub        s9, s1, s22
    s.movz       s1, #0
    s.addi       s26, s17, #0
    s.cmp.eq     s17, s20, s23
    s.min.s      s23, s24, s19
    s.addi       s19, s1, #0
    s.mov        s26, s9
    br.nz        s17, sdiv_done_3
    s.movz       s1, #0
    s.movz       s17, #31
    s.mov        s26, s1
    s.addi       s1, s17, #0
sdiv_4:
    s.lshr       s17, s9, s1
    s.shli       s24, s19, #1
    s.andi       s27, s17, #1
    s.movz       s17, #0
    s.or         s28, s24, s27
    s.movz       s24, #1
    s.cmp.geu    s27, s28, s20
    s.shl        s29, s24, s1
    s.sub        s24, s17, s27
    s.subi       s17, s1, #1
    s.and        s27, s20, s24
    s.and        s30, s29, s24
    s.sub        s24, s28, s27
    s.or         s27, s26, s30
    s.mov        s19, s24
    s.mov        s26, s27
    s.mov        s1, s17
    s.movz       s17, #0
    s.cmp.ge     s24, s1, s17
    br.nz        s24, sdiv_4
sdiv_done_3:
    s.xor        s1, s19, s22
    s.movz       s9, #0
    s.sub        s17, s1, s22
    s.movz       s1, #0
    s.movz       s19, #0
    s.cmp.lt     s20, s23, s9
    s.movz       s9, #0
    s.cmp.lt     s22, s17, s1
    s.sub        s1, s19, s20
    s.sub        s19, s9, s22
    s.xor        s9, s23, s1
    s.xor        s20, s17, s19
    s.sub        s22, s9, s1
    s.movz       s1, #0
    s.movz       s9, #1
    s.sub        s24, s20, s19
    s.movz       s20, #0
    s.addi       s26, s1, #0
    s.cmp.eq     s1, s22, s9
    s.addi       s9, s20, #0
    s.mov        s26, s24
    br.nz        s1, sdiv_done_5
    s.movz       s1, #0
    s.movz       s20, #31
    s.mov        s26, s1
    s.addi       s1, s20, #0
sdiv_6:
    s.lshr       s20, s24, s1
    s.shli       s27, s9, #1
    s.andi       s28, s20, #1
    s.movz       s20, #0
    s.or         s29, s27, s28
    s.movz       s27, #1
    s.cmp.geu    s28, s29, s22
    s.shl        s30, s27, s1
    s.sub        s27, s20, s28
    s.subi       s20, s1, #1
    s.and        s28, s22, s27
    s.and        s31, s30, s27
    s.sub        s27, s29, s28
    s.or         s28, s26, s31
    s.mov        s9, s27
    s.mov        s26, s28
    s.mov        s1, s20
    s.movz       s20, #0
    s.cmp.ge     s27, s1, s20
    br.nz        s27, sdiv_6
sdiv_done_5:
    s.movz       s1, #0
    s.movz       s20, #0
    s.movz       s22, #0
    s.cmp.lt     s24, s23, s1
    s.movz       s1, #0
    s.cmp.lt     s26, s17, s20
    s.sub        s20, s22, s24
    s.sub        s22, s1, s26
    s.xor        s1, s23, s20
    s.xor        s23, s9, s19
    s.xor        s9, s17, s22
    s.sub        s17, s1, s20
    s.movz       s1, #0
    s.movz       s24, #1
    s.sub        s26, s23, s19
    s.sub        s19, s9, s22
    s.movz       s9, #0
    s.addi       s23, s1, #0
    s.cmp.eq     s1, s17, s24
    s.add        s24, s25, s26
    s.addi       s25, s9, #0
    s.mov        s23, s19
    br.nz        s1, sdiv_done_7
    s.movz       s1, #0
    s.movz       s9, #31
    s.mov        s23, s1
    s.addi       s1, s9, #0
sdiv_8:
    s.lshr       s9, s19, s1
    s.shli       s26, s25, #1
    s.andi       s27, s9, #1
    s.movz       s9, #0
    s.or         s28, s26, s27
    s.movz       s26, #1
    s.cmp.geu    s27, s28, s17
    s.shl        s29, s26, s1
    s.sub        s26, s9, s27
    s.subi       s9, s1, #1
    s.and        s27, s17, s26
    s.and        s30, s29, s26
    s.sub        s26, s28, s27
    s.or         s27, s23, s30
    s.mov        s25, s26
    s.mov        s23, s27
    s.mov        s1, s9
    s.movz       s9, #0
    s.cmp.ge     s26, s1, s9
    br.nz        s26, sdiv_8
sdiv_done_7:
    s.mul        s1, s24, s11
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s12
    v.movi       v2, #0
    s.xor        s9, s22, s20
    v.splat      v3, s1
    v.sub        v4, v2, v1
    s.xor        s17, s23, s9
    v.add        v5, v3, v0
    v.cmp.lt     p1, v1, v2
    s.sub        s19, s17, s9
    v.sub        v0, v2, v5
    v.cmp.lt     p2, v5, v2
    v.movi       v3, #1
    @p2 v.sel        v6, v0, v5
    @p1 v.sel        v0, v4, v1
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s9, #31
idiv_9:
    v.splat      v5, s9
    v.shl        v7, v4, v3
    v.cmp.lt     p1, v4, v2
    v.lshr       v8, v6, v5
    v.shl        v9, v3, v5
    s.subi       s17, s9, #1
    v.and        v5, v8, v3
    s.movz       s20, #0
    v.or         v8, v7, v5
    v.cmp.geu    p3, v8, v0
    p.or         p4, p1, p3
    v.sub        v5, v8, v0
    @p4 v.sel        v7, v9, v2
    @p4 v.sel        v9, v5, v8
    v.or         v5, v1, v7
    v.mov        v4, v9
    v.mov        v1, v5
    s.mov        s9, s17
    s.cmp.ge     s17, s9, s20
    br.nz        s17, idiv_9
    s.mul        s9, s19, s6
    v.iota       v0                              // arange(0, VLEN)
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v3, #16
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s9
    v.movi       v7, #32
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #48
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #64
    v.iota       v12                             // arange(0, VLEN)
    v.movi       v13, #80
    v.iota       v14                             // arange(0, VLEN)
    v.movi       v15, #96
    v.iota       v16                             // arange(0, VLEN)
    v.movi       v17, #112
    v.add        v18, v6, v0
    v.splat      v0, s3
    v.sub        v6, v2, v4
    v.add        v2, v1, v3
    v.add        v1, v5, v7
    v.add        v3, v8, v9
    v.add        v5, v10, v11
    v.add        v7, v12, v13
    v.add        v8, v14, v15
    v.add        v9, v16, v17
    v.splat      v10, s9
    v.splat      v11, s9
    v.splat      v12, s9
    v.splat      v13, s9
    v.splat      v14, s9
    v.splat      v15, s9
    v.splat      v16, s9
    @p2 v.sel        v17, v6, v4
    v.movi       v4, #0
    v.add        v6, v10, v2
    v.add        v2, v11, v1
    v.sub        v1, v4, v18
    v.sub        v10, v4, v0
    v.cmp.lt     p1, v18, v4
    v.cmp.lt     p2, v0, v4
    v.add        v11, v12, v3
    v.add        v3, v13, v5
    v.add        v5, v14, v7
    v.add        v7, v15, v8
    v.add        v8, v16, v9
    v.splat      v9, s3
    v.splat      v12, s3
    v.splat      v13, s3
    v.splat      v14, s3
    v.splat      v15, s3
    v.splat      v16, s3
    v.splat      v19, s3
    v.movi       v20, #1
    @p1 v.sel        v21, v1, v18
    @p2 v.sel        v1, v10, v0
    v.movi       v0, #0
    v.movi       v10, #0
    s.movz       s17, #31
idiv_10:
    v.splat      v18, s17
    v.shl        v22, v10, v20
    v.cmp.lt     p2, v10, v4
    v.lshr       v23, v21, v18
    v.shl        v24, v20, v18
    s.subi       s19, s17, #1
    v.and        v18, v23, v20
    s.movz       s20, #0
    v.or         v23, v22, v18
    v.cmp.geu    p3, v23, v1
    p.or         p4, p2, p3
    v.sub        v18, v23, v1
    @p4 v.sel        v22, v24, v4
    @p4 v.sel        v24, v18, v23
    v.or         v18, v0, v22
    v.mov        v10, v24
    v.mov        v0, v18
    s.mov        s17, s19
    s.cmp.ge     s19, s17, s20
    br.nz        s19, idiv_10
    v.movi       v0, #0
    v.sub        v1, v4, v10
    v.movi       v4, #1
    v.sub        v18, v0, v6
    v.sub        v20, v0, v9
    v.cmp.lt     p2, v6, v0
    v.cmp.lt     p3, v9, v0
    @p1 v.sel        v21, v1, v10
    @p2 v.sel        v1, v18, v6
    @p3 v.sel        v6, v20, v9
    v.movi       v9, #0
    v.movi       v10, #0
    s.movz       s17, #31
idiv_11:
    v.splat      v18, s17
    v.shl        v20, v10, v4
    v.cmp.lt     p1, v10, v0
    v.lshr       v22, v1, v18
    v.shl        v23, v4, v18
    s.subi       s19, s17, #1
    v.and        v18, v22, v4
    s.movz       s20, #0
    v.or         v22, v20, v18
    v.cmp.geu    p3, v22, v6
    p.or         p4, p1, p3
    v.sub        v18, v22, v6
    @p4 v.sel        v20, v23, v0
    @p4 v.sel        v23, v18, v22
    v.or         v18, v9, v20
    v.mov        v10, v23
    v.mov        v9, v18
    s.mov        s17, s19
    s.cmp.ge     s19, s17, s20
    br.nz        s19, idiv_11
    v.movi       v1, #0
    v.sub        v4, v0, v10
    v.movi       v0, #1
    v.sub        v6, v1, v2
    v.sub        v9, v1, v12
    v.cmp.lt     p1, v2, v1
    v.cmp.lt     p3, v12, v1
    @p2 v.sel        v18, v4, v10
    @p1 v.sel        v4, v6, v2
    @p3 v.sel        v2, v9, v12
    v.movi       v6, #0
    v.movi       v9, #0
    s.movz       s17, #31
idiv_12:
    v.splat      v10, s17
    v.shl        v12, v9, v0
    v.cmp.lt     p2, v9, v1
    v.lshr       v20, v4, v10
    v.shl        v22, v0, v10
    s.subi       s19, s17, #1
    v.and        v10, v20, v0
    s.movz       s20, #0
    v.or         v20, v12, v10
    v.cmp.geu    p3, v20, v2
    p.or         p4, p2, p3
    v.sub        v10, v20, v2
    @p4 v.sel        v12, v22, v1
    @p4 v.sel        v22, v10, v20
    v.or         v10, v6, v12
    v.mov        v9, v22
    v.mov        v6, v10
    s.mov        s17, s19
    s.cmp.ge     s19, s17, s20
    br.nz        s19, idiv_12
    v.movi       v0, #0
    v.sub        v2, v1, v9
    v.movi       v1, #1
    v.sub        v4, v0, v11
    v.sub        v6, v0, v13
    v.cmp.lt     p2, v11, v0
    v.cmp.lt     p3, v13, v0
    @p1 v.sel        v10, v2, v9
    @p2 v.sel        v2, v4, v11
    @p3 v.sel        v4, v6, v13
    v.movi       v6, #0
    v.movi       v9, #0
    s.movz       s17, #31
idiv_13:
    v.splat      v11, s17
    v.shl        v12, v9, v1
    v.cmp.lt     p1, v9, v0
    v.lshr       v13, v2, v11
    v.shl        v20, v1, v11
    s.subi       s19, s17, #1
    v.and        v11, v13, v1
    s.movz       s20, #0
    v.or         v13, v12, v11
    v.cmp.geu    p3, v13, v4
    p.or         p4, p1, p3
    v.sub        v11, v13, v4
    @p4 v.sel        v12, v20, v0
    @p4 v.sel        v20, v11, v13
    v.or         v11, v6, v12
    v.mov        v9, v20
    v.mov        v6, v11
    s.mov        s17, s19
    s.cmp.ge     s19, s17, s20
    br.nz        s19, idiv_13
    v.movi       v1, #0
    v.sub        v2, v0, v9
    v.movi       v0, #1
    v.sub        v4, v1, v3
    v.sub        v6, v1, v14
    v.cmp.lt     p1, v3, v1
    v.cmp.lt     p3, v14, v1
    @p2 v.sel        v11, v2, v9
    @p1 v.sel        v2, v4, v3
    @p3 v.sel        v3, v6, v14
    v.movi       v4, #0
    v.movi       v6, #0
    s.movz       s17, #31
idiv_14:
    v.splat      v9, s17
    v.shl        v12, v6, v0
    v.cmp.lt     p2, v6, v1
    v.lshr       v13, v2, v9
    v.shl        v14, v0, v9
    s.subi       s19, s17, #1
    v.and        v9, v13, v0
    s.movz       s20, #0
    v.or         v13, v12, v9
    v.cmp.geu    p3, v13, v3
    p.or         p4, p2, p3
    v.sub        v9, v13, v3
    @p4 v.sel        v12, v14, v1
    @p4 v.sel        v14, v9, v13
    v.or         v9, v4, v12
    v.mov        v6, v14
    v.mov        v4, v9
    s.mov        s17, s19
    s.cmp.ge     s19, s17, s20
    br.nz        s19, idiv_14
    v.movi       v0, #0
    v.sub        v2, v1, v6
    v.movi       v1, #1
    v.sub        v3, v0, v5
    v.sub        v4, v0, v15
    v.cmp.lt     p2, v5, v0
    v.cmp.lt     p3, v15, v0
    @p1 v.sel        v9, v2, v6
    @p2 v.sel        v2, v3, v5
    @p3 v.sel        v3, v4, v15
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s17, #31
idiv_15:
    v.splat      v6, s17
    v.shl        v12, v5, v1
    v.cmp.lt     p1, v5, v0
    v.lshr       v13, v2, v6
    v.shl        v14, v1, v6
    s.subi       s19, s17, #1
    v.and        v6, v13, v1
    s.movz       s20, #0
    v.or         v13, v12, v6
    v.cmp.geu    p3, v13, v3
    p.or         p4, p1, p3
    v.sub        v6, v13, v3
    @p4 v.sel        v12, v14, v0
    @p4 v.sel        v14, v6, v13
    v.or         v6, v4, v12
    v.mov        v5, v14
    v.mov        v4, v6
    s.mov        s17, s19
    s.cmp.ge     s19, s17, s20
    br.nz        s19, idiv_15
    v.movi       v1, #0
    v.sub        v2, v0, v5
    v.movi       v0, #1
    v.sub        v3, v1, v7
    v.sub        v4, v1, v16
    v.cmp.lt     p1, v7, v1
    v.cmp.lt     p3, v16, v1
    @p2 v.sel        v6, v2, v5
    @p1 v.sel        v2, v3, v7
    @p3 v.sel        v3, v4, v16
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s17, #31
idiv_16:
    v.splat      v7, s17
    v.shl        v12, v5, v0
    v.cmp.lt     p2, v5, v1
    v.lshr       v13, v2, v7
    v.shl        v14, v0, v7
    s.subi       s19, s17, #1
    v.and        v7, v13, v0
    s.movz       s20, #0
    v.or         v13, v12, v7
    v.cmp.geu    p3, v13, v3
    p.or         p4, p2, p3
    v.sub        v7, v13, v3
    @p4 v.sel        v12, v14, v1
    @p4 v.sel        v14, v7, v13
    v.or         v7, v4, v12
    v.mov        v5, v14
    v.mov        v4, v7
    s.mov        s17, s19
    s.cmp.ge     s19, s17, s20
    br.nz        s19, idiv_16
    v.movi       v0, #0
    v.sub        v2, v1, v5
    v.movi       v1, #1
    v.sub        v3, v0, v8
    v.sub        v4, v0, v19
    v.cmp.lt     p2, v8, v0
    v.cmp.lt     p3, v19, v0
    @p1 v.sel        v7, v2, v5
    @p2 v.sel        v2, v3, v8
    @p3 v.sel        v3, v4, v19
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s17, #31
idiv_17:
    v.splat      v8, s17
    v.shl        v12, v5, v1
    v.cmp.lt     p1, v5, v0
    v.lshr       v13, v2, v8
    v.shl        v14, v1, v8
    s.subi       s19, s17, #1
    v.and        v8, v13, v1
    s.movz       s20, #0
    v.or         v13, v12, v8
    v.cmp.geu    p3, v13, v3
    p.or         p4, p1, p3
    v.sub        v8, v13, v3
    @p4 v.sel        v12, v14, v0
    @p4 v.sel        v14, v8, v13
    v.or         v8, v4, v12
    v.mov        v5, v14
    v.mov        v4, v8
    s.mov        s17, s19
    s.cmp.ge     s19, s17, s20
    br.nz        s19, idiv_17
    v.sub        v1, v0, v5
    v.movi       v0, #0
    v.movi       v2, #0
    @p2 v.sel        v3, v1, v5
    v.movi       v1, #0
    v.sub        v4, v0, v21
    v.sub        v5, v2, v18
    v.sub        v8, v1, v10
    v.cmp.lt     p1, v21, v0
    v.cmp.lt     p2, v18, v2
    v.cmp.lt     p3, v10, v1
    @p1 v.sel        v12, v4, v21
    v.movi       v4, #7
    @p2 v.sel        v13, v5, v18
    v.movi       v5, #7
    @p3 v.sel        v14, v8, v10
    v.movi       v8, #7
    v.lshr       v15, v12, v4
    v.lshr       v4, v13, v5
    v.lshr       v5, v14, v8
    v.movi       v8, #128
    v.sub        v12, v0, v15
    v.movi       v13, #128
    v.sub        v14, v2, v4
    v.movi       v16, #128
    v.sub        v19, v1, v5
    v.movi       v20, #128
    v.splat      v22, s5
    v.sub        v23, v0, v8
    @p1 v.sel        v24, v12, v15
    v.sub        v12, v2, v13
    @p2 v.sel        v15, v14, v4
    v.sub        v4, v1, v16
    @p3 v.sel        v14, v19, v5
    v.cmp.lt     p1, v8, v0
    v.cmp.lt     p2, v13, v2
    v.cmp.lt     p3, v16, v1
    s.movz       s5, #32
    v.movi       v0, #0
    s.movz       s17, #48
    s.movz       s19, #64
    s.movz       s20, #80
    s.movz       s22, #96
    v.sub        v1, v0, v11
    s.movz       s23, #112
    v.sub        v2, v0, v20
    v.mul        v5, v17, v22
    v.movi       v19, #7
    v.movi       v22, #1
    v.movi       v22, #0
    v.movi       v25, #128
    @p1 v.sel        v26, v23, v8
    v.sub        v8, v22, v9
    v.cmp.lt     p1, v11, v0
    @p1 v.sel        v23, v1, v11
    v.movi       v1, #7
    v.sub        v26, v22, v25
    v.lshr       v27, v23, v19
    v.movi       v19, #1
    v.movi       v19, #0
    v.sub        v23, v0, v27
    v.movi       v28, #128
    @p2 v.sel        v29, v12, v13
    v.sub        v12, v19, v6
    v.cmp.lt     p2, v9, v22
    @p2 v.sel        v13, v8, v9
    v.movi       v8, #7
    @p1 v.sel        v29, v23, v27
    v.cmp.lt     p1, v6, v19
    @p1 v.sel        v23, v12, v6
    v.lshr       v12, v13, v1
    v.sub        v1, v19, v28
    v.lshr       v13, v23, v8
    v.sub        v8, v22, v12
    v.movi       v23, #1
    v.movi       v23, #0
    v.sub        v27, v19, v13
    @p2 v.sel        v30, v8, v12
    v.cmp.lt     p2, v7, v23
    v.movi       v8, #128
    @p1 v.sel        v12, v27, v13
    v.cmp.lt     p1, v20, v0
    @p3 v.sel        v0, v4, v16
    v.sub        v0, v23, v7
    v.movi       v4, #7
    v.sub        v13, v23, v8
    @p2 v.sel        v16, v0, v7
    v.cmp.lt     p3, v25, v22
    v.movi       v0, #1
    v.movi       v0, #0
    v.lshr       v22, v16, v4
    v.movi       v4, #128
    @p1 v.sel        v16, v2, v20
    v.sub        v2, v0, v3
    v.cmp.lt     p1, v3, v0
    v.movi       v16, #7
    @p1 v.sel        v20, v2, v3
    v.sub        v2, v23, v22
    v.movi       v27, #1
    v.lshr       v27, v20, v16
    @p2 v.sel        v16, v2, v22
    v.sub        v2, v0, v4
    v.sub        v20, v0, v27
    v.cmp.lt     p2, v28, v19
    v.splat      v19, s21
    @p1 v.sel        v22, v20, v27
    v.splat      v20, s21
    v.cmp.lt     p1, v8, v23
    v.splat      v23, s21
    @p3 v.sel        v27, v26, v25
    v.splat      v25, s21
    v.splat      v26, s21
    v.cmp.lt     p3, v4, v0
    v.splat      v0, s21
    v.movi       v27, #1
    s.add        s24, s10, s2
    @p2 v.sel        v27, v1, v28
    s.movz       s2, #0
    s.movz       s25, #0
    s.cmp.lt     s26, s24, s2
    s.movz       s2, #0
    s.sub        s27, s25, s26
    s.movz       s25, #0
    s.cmp.lt     s26, s6, s2
    v.splat      v1, s21
    v.splat      v27, s21
    v.movi       v28, #1
    s.xor        s2, s24, s27
    s.sub        s21, s25, s26
    s.sub        s24, s2, s27
    s.xor        s2, s6, s21
    s.lshri      s25, s24, #7
    @p1 v.sel        v28, v13, v8
    s.muli       s26, s25, #128
    s.xor        s28, s27, s21
    s.movz       s27, #0
    s.xor        s29, s25, s28
    v.movi       v8, #1
    s.movz       s25, #0
    s.movz       s30, #0
    @p3 v.sel        v8, v2, v4
    v.mul        v2, v24, v19
    v.mul        v4, v15, v20
    v.mul        v8, v14, v23
    v.mul        v13, v29, v25
    v.mul        v14, v30, v26
    v.mul        v15, v12, v0
    v.mul        v0, v16, v1
    v.mul        v1, v22, v27
    s.sub        s31, s2, s21
    s.sub        s2, s24, s26
    s.sub        s2, s29, s28
    s.movz       s21, #1
    s.addi       s24, s27, #0
    s.addi       s26, s25, #0
    s.addi       s25, s30, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_18:
    s.cmp.ge     s28, s24, s2
    br.nz        s28, endfor_19
    s.mul        s28, s24, s6
    s.sub        s29, s10, s28
    v.splat      v12, s14
    v.mul        v16, v21, v12
    v.splat      v12, s14
    v.mul        v19, v18, v12
    v.splat      v12, s14
    v.mul        v20, v10, v12
    v.splat      v12, s14
    v.mul        v22, v11, v12
    v.splat      v12, s14
    v.mul        v23, v9, v12
    v.splat      v12, s14
    v.mul        v24, v6, v12
    v.splat      v12, s14
    v.mul        v25, v7, v12
    v.splat      v12, s14
    v.mul        v26, v3, v12
    v.splat      v12, s24
    s.shli       s28, s24, #2                    // element offset -> bytes (x4)
    s.add        s30, s15, s28                   // &As[...]
    v.ld.gather.w v12, [s30, v5]                 // index is in elements (ISA sec 9.1)
    v.splat      v27, s24
    v.splat      v27, s24
    v.splat      v27, s24
    v.splat      v27, s24
    v.splat      v27, s24
    v.splat      v27, s24
    v.splat      v27, s24
    v.splat      v27, s24
    s.add        s30, s18, s28                   // &Bs[...]
    v.ld.gather.w v27, [s30, v2]                 // index is in elements (ISA sec 9.1)
    s.add        s30, s18, s28                   // &Bs[...]
    v.ld.gather.w v28, [s30, v4]                 // index is in elements (ISA sec 9.1)
    s.add        s30, s18, s28                   // &Bs[...]
    v.ld.gather.w v29, [s30, v8]                 // index is in elements (ISA sec 9.1)
    s.add        s30, s18, s28                   // &Bs[...]
    v.ld.gather.w v30, [s30, v13]                // index is in elements (ISA sec 9.1)
    s.add        s30, s18, s28                   // &Bs[...]
    v.ld.gather.w v31, [s30, v14]                // index is in elements (ISA sec 9.1)
    s.add        s30, s18, s28                   // &Bs[...]
    v.ld.gather.w v32, [s30, v15]                // index is in elements (ISA sec 9.1)
    s.add        s30, s18, s28                   // &Bs[...]
    v.ld.gather.w v33, [s30, v0]                 // index is in elements (ISA sec 9.1)
    s.add        s30, s18, s28                   // &Bs[...]
    v.ld.gather.w v34, [s30, v1]                 // index is in elements (ISA sec 9.1)
    s.add        s28, s27, s29
    // tl.dot 16x128 by 128x128 FP8 as (B^T A^T)^T: B^T rows are contiguous loads, A is scattered into the MMA B operand
    v.iota       v35                             // arange(0, VLEN)
    s.movz       s30, #16
    v.splat      v36, s30
    v.mul        v37, v35, v36
    v.iota       v35                             // arange(0, VLEN)
    v.movi       v36, #7
    v.and        v38, v35, v36
    v.movi       v35, #2
    v.shl        v36, v38, v35
    v.iota       v35                             // arange(0, VLEN)
    v.movi       v38, #3
    v.lshr       v39, v35, v38
    v.movi       v35, #0
    v.cmp.eq     p1, v39, v35
    v.iota       v35                             // arange(0, VLEN)
    v.movi       v38, #3
    v.lshr       v39, v35, v38
    v.movi       v35, #1
    v.cmp.eq     p2, v39, v35
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    s.rdspecial  s30, arg_base
    s.ld.d       s31, [s30, #104]                // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s30, s31, #0                    // 512 bytes of repack scratch
    v.splat      v35, s16
    v.mul        v38, v17, v35
    v.extract    s32, v38, #0
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.iota       v35                             // arange(0, VLEN)
    s.movz       s33, #0
    s.add        s34, s33, s29                   // the tile origin
    v.splat      v39, s34
    v.cmp.lt     p3, v35, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #0
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #1
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #1
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #2
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #2
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #3
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #3
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #4
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #4
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #5
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #5
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #6
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #6
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #7
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #7
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #8
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #8
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #9
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #9
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #10
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #10
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #11
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #11
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #12
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #12
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #13
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #13
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #14
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #14
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #15
    s.add        s33, s32, s26
    s.add        s32, s4, s33
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s32, #0]
    s.addi       s32, s30, #15
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #0
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    s.movz       s32, #0
    s.add        s34, s32, s11                   // the tile origin
    v.splat      v39, s34
    v.add        v40, v35, v39
    s.movz       s32, #0
    s.add        s34, s32, s29                   // the tile origin
    v.splat      v39, s34
    v.cmp.lt     p3, v40, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #256
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #1
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #257
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #2
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #258
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #3
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #259
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #4
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #260
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #5
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #261
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #6
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #262
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #7
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #263
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #8
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #264
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #9
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #265
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #10
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #266
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #11
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #267
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #12
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #268
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #13
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #269
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #14
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #270
    v.st.scatter.b [s32, v37], v39
    v.extract    s32, v38, #15
    s.add        s33, s32, s26
    s.addi       s32, s33, #16
    s.add        s33, s4, s32
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s33, #0]
    s.addi       s32, s30, #271
    v.st.scatter.b [s32, v37], v39
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v39, [s30, #0]
    v.mov        v48, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s30, #64
    v.ld.w       v39, [s32, #0]
    v.mov        v49, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s30, #128
    v.ld.w       v39, [s32, #0]
    v.mov        v50, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s30, #192
    v.ld.w       v39, [s32, #0]
    v.mov        v51, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s30, #256
    v.ld.w       v39, [s32, #0]
    v.mov        v52, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s30, #320
    v.ld.w       v39, [s32, #0]
    v.mov        v53, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s30, #384
    v.ld.w       v39, [s32, #0]
    v.mov        v54, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s32, s30, #448
    v.ld.w       v39, [s32, #0]
    v.mov        v55, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s30, s28, #0
    v.splat      v39, s30
    v.sub        v40, v39, v36
    v.movi       v39, #0
    v.cmp.gt     p3, v40, v39
    v.movi       v39, #0
    v.max.s      v41, v40, v39
    v.movi       v39, #4
    v.min.s      v40, v41, v39
    v.movi       v39, #1
    v.movi       v41, #3
    v.shl        v42, v40, v41
    v.shl        v41, v39, v42
    v.movi       v39, #1
    v.sub        v42, v41, v39
    v.movi       v39, #4
    v.cmp.ge     p4, v40, v39
    v.movi       v39, #-1
    @p4 v.sel        v40, v39, v42
    s.add        s30, s7, s25
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s32, v16, #0
    s.add        s33, s30, s32
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s33, #0]
    v.extract    s32, v16, #1
    s.add        s33, s30, s32
    s.addi       s32, s33, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s32, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v16, #2
    s.add        s33, s30, s32
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s33, #0]
    v.extract    s32, v16, #3
    s.add        s33, s30, s32
    s.addi       s32, s33, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s32, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v16, #4
    s.add        s33, s30, s32
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s33, #0]
    v.extract    s32, v16, #5
    s.add        s33, s30, s32
    s.addi       s32, s33, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s32, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v16, #6
    s.add        s33, s30, s32
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s33, #0]
    v.extract    s32, v16, #7
    s.add        s33, s30, s32
    s.addi       s32, s33, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s32, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v16, #8
    s.add        s33, s30, s32
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s33, #0]
    v.extract    s32, v16, #9
    s.add        s33, s30, s32
    s.addi       s32, s33, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s32, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v16, #10
    s.add        s33, s30, s32
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s33, #0]
    v.extract    s32, v16, #11
    s.add        s33, s30, s32
    s.addi       s32, s33, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s32, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v16, #12
    s.add        s33, s30, s32
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s33, #0]
    v.extract    s32, v16, #13
    s.add        s33, s30, s32
    s.addi       s32, s33, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s32, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s32, v16, #14
    s.add        s33, s30, s32
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s33, #0]
    v.extract    s32, v16, #15
    s.add        s33, s30, s32
    s.addi       s30, s33, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s30, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s30
    mb.wait      s30
    s.add        s32, s7, s25
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s33, v19, #0
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s34, #0]
    v.extract    s33, v19, #1
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s33, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v19, #2
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s34, #0]
    v.extract    s33, v19, #3
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s33, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v19, #4
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s34, #0]
    v.extract    s33, v19, #5
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s33, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v19, #6
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s34, #0]
    v.extract    s33, v19, #7
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s33, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v19, #8
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s34, #0]
    v.extract    s33, v19, #9
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s33, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v19, #10
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s34, #0]
    v.extract    s33, v19, #11
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s33, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v19, #12
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s34, #0]
    v.extract    s33, v19, #13
    s.add        s34, s32, s33
    s.addi       s33, s34, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s33, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s33, v19, #14
    s.add        s34, s32, s33
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s34, #0]
    v.extract    s33, v19, #15
    s.add        s34, s32, s33
    s.addi       s32, s34, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s32, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s32, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s32
    mb.wait      s32
    s.add        s33, s7, s25
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s34, v20, #0
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s35, #0]
    v.extract    s34, v20, #1
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s34, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v20, #2
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s35, #0]
    v.extract    s34, v20, #3
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s34, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v20, #4
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s35, #0]
    v.extract    s34, v20, #5
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s34, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v20, #6
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s35, #0]
    v.extract    s34, v20, #7
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s34, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v20, #8
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s35, #0]
    v.extract    s34, v20, #9
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s34, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v20, #10
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s35, #0]
    v.extract    s34, v20, #11
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s34, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v20, #12
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s35, #0]
    v.extract    s34, v20, #13
    s.add        s35, s33, s34
    s.addi       s34, s35, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s34, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s34, v20, #14
    s.add        s35, s33, s34
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s35, #0]
    v.extract    s34, v20, #15
    s.add        s35, s33, s34
    s.addi       s33, s35, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s33, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s33, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s33
    mb.wait      s33
    s.add        s34, s7, s25
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s35, v22, #0
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s36, #0]
    v.extract    s35, v22, #1
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s35, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v22, #2
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s36, #0]
    v.extract    s35, v22, #3
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s35, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v22, #4
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s36, #0]
    v.extract    s35, v22, #5
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s35, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v22, #6
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s36, #0]
    v.extract    s35, v22, #7
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s35, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v22, #8
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s36, #0]
    v.extract    s35, v22, #9
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s35, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v22, #10
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s36, #0]
    v.extract    s35, v22, #11
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s35, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v22, #12
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s36, #0]
    v.extract    s35, v22, #13
    s.add        s36, s34, s35
    s.addi       s35, s36, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s35, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s35, v22, #14
    s.add        s36, s34, s35
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s36, #0]
    v.extract    s35, v22, #15
    s.add        s36, s34, s35
    s.addi       s34, s36, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s34, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s34, b3, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s34
    mb.wait      s34
    s.add        s35, s7, s25
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s36, v23, #0
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s37, #0]
    v.extract    s36, v23, #1
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s36, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v23, #2
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s37, #0]
    v.extract    s36, v23, #3
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s36, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v23, #4
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s37, #0]
    v.extract    s36, v23, #5
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s36, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v23, #6
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s37, #0]
    v.extract    s36, v23, #7
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s36, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v23, #8
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s37, #0]
    v.extract    s36, v23, #9
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s36, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v23, #10
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s37, #0]
    v.extract    s36, v23, #11
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s36, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v23, #12
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s37, #0]
    v.extract    s36, v23, #13
    s.add        s37, s35, s36
    s.addi       s36, s37, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s36, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s36, v23, #14
    s.add        s37, s35, s36
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s37, #0]
    v.extract    s36, v23, #15
    s.add        s37, s35, s36
    s.addi       s35, s37, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s35, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s35, b4, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s35
    mb.wait      s35
    s.add        s36, s7, s25
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s37, v24, #0
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s38, #0]
    v.extract    s37, v24, #1
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s37, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v24, #2
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s38, #0]
    v.extract    s37, v24, #3
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s37, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v24, #4
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s38, #0]
    v.extract    s37, v24, #5
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s37, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v24, #6
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s38, #0]
    v.extract    s37, v24, #7
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s37, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v24, #8
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s38, #0]
    v.extract    s37, v24, #9
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s37, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v24, #10
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s38, #0]
    v.extract    s37, v24, #11
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s37, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v24, #12
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s38, #0]
    v.extract    s37, v24, #13
    s.add        s38, s36, s37
    s.addi       s37, s38, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s37, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s37, v24, #14
    s.add        s38, s36, s37
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s38, #0]
    v.extract    s37, v24, #15
    s.add        s38, s36, s37
    s.addi       s36, s38, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s36, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s36, b5, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s36
    mb.wait      s36
    s.add        s37, s7, s25
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s38, v25, #0
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s39, #0]
    v.extract    s38, v25, #1
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s38, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v25, #2
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s39, #0]
    v.extract    s38, v25, #3
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s38, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v25, #4
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s39, #0]
    v.extract    s38, v25, #5
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s38, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v25, #6
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s39, #0]
    v.extract    s38, v25, #7
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s38, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v25, #8
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s39, #0]
    v.extract    s38, v25, #9
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s38, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v25, #10
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s39, #0]
    v.extract    s38, v25, #11
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s38, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v25, #12
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s39, #0]
    v.extract    s38, v25, #13
    s.add        s39, s37, s38
    s.addi       s38, s39, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s38, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s38, v25, #14
    s.add        s39, s37, s38
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s39, #0]
    v.extract    s38, v25, #15
    s.add        s39, s37, s38
    s.addi       s37, s39, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s37, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s37, b6, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s37
    mb.wait      s37
    s.add        s38, s7, s25
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s39, v26, #0
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s40, #0]
    v.extract    s39, v26, #1
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v26, #2
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s40, #0]
    v.extract    s39, v26, #3
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v26, #4
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s40, #0]
    v.extract    s39, v26, #5
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v26, #6
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s40, #0]
    v.extract    s39, v26, #7
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v26, #8
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s40, #0]
    v.extract    s39, v26, #9
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v26, #10
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s40, #0]
    v.extract    s39, v26, #11
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v26, #12
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s40, #0]
    v.extract    s39, v26, #13
    s.add        s40, s38, s39
    s.addi       s39, s40, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v26, #14
    s.add        s40, s38, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s40, #0]
    v.extract    s39, v26, #15
    s.add        s40, s38, s39
    s.addi       s38, s40, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s38, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s38, b7, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s38
    mb.wait      s38
    s.addi       s39, s31, #512                  // 512 bytes of repack scratch
    v.extract    s40, v38, #0
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    s.movz       s40, #0
    s.add        s42, s40, s5                    // the tile origin
    v.splat      v39, s42
    v.add        v40, v35, v39
    s.movz       s40, #0
    s.add        s42, s40, s29                   // the tile origin
    v.splat      v39, s42
    v.cmp.lt     p3, v40, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #0
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #1
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #1
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #2
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #2
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #3
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #3
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #4
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #4
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #5
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #5
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #6
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #6
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #7
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #7
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #8
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #8
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #9
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #9
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #10
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #10
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #11
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #11
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #12
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #12
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #13
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #13
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #14
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #14
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #15
    s.add        s41, s40, s26
    s.addi       s40, s41, #32
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #15
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #0
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    s.movz       s40, #0
    s.add        s42, s40, s17                   // the tile origin
    v.splat      v39, s42
    v.add        v40, v35, v39
    s.movz       s40, #0
    s.add        s42, s40, s29                   // the tile origin
    v.splat      v39, s42
    v.cmp.lt     p3, v40, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #256
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #1
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #257
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #2
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #258
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #3
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #259
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #4
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #260
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #5
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #261
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #6
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #262
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #7
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #263
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #8
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #264
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #9
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #265
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #10
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #266
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #11
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #267
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #12
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #268
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #13
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #269
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #14
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #270
    v.st.scatter.b [s40, v37], v39
    v.extract    s40, v38, #15
    s.add        s41, s40, s26
    s.addi       s40, s41, #48
    s.add        s41, s4, s40
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s41, #0]
    s.addi       s40, s39, #271
    v.st.scatter.b [s40, v37], v39
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v39, [s39, #0]
    v.mov        v48, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s39, #64
    v.ld.w       v39, [s40, #0]
    v.mov        v49, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s39, #128
    v.ld.w       v39, [s40, #0]
    v.mov        v50, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s39, #192
    v.ld.w       v39, [s40, #0]
    v.mov        v51, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s39, #256
    v.ld.w       v39, [s40, #0]
    v.mov        v52, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s39, #320
    v.ld.w       v39, [s40, #0]
    v.mov        v53, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s39, #384
    v.ld.w       v39, [s40, #0]
    v.mov        v54, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s40, s39, #448
    v.ld.w       v39, [s40, #0]
    v.mov        v55, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s39, s28, #-32
    v.splat      v39, s39
    v.sub        v40, v39, v36
    v.movi       v39, #0
    v.cmp.gt     p3, v40, v39
    v.movi       v39, #0
    v.max.s      v41, v40, v39
    v.movi       v39, #4
    v.min.s      v40, v41, v39
    v.movi       v39, #1
    v.movi       v41, #3
    v.shl        v42, v40, v41
    v.shl        v41, v39, v42
    v.movi       v39, #1
    v.sub        v42, v41, v39
    v.movi       v39, #4
    v.cmp.ge     p4, v40, v39
    v.movi       v39, #-1
    @p4 v.sel        v40, v39, v42
    s.addi       s39, s25, #32
    s.add        s40, s7, s39
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s39, v16, #0
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s41, #0]
    v.extract    s39, v16, #1
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v16, #2
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s41, #0]
    v.extract    s39, v16, #3
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v16, #4
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s41, #0]
    v.extract    s39, v16, #5
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v16, #6
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s41, #0]
    v.extract    s39, v16, #7
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v16, #8
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s41, #0]
    v.extract    s39, v16, #9
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v16, #10
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s41, #0]
    v.extract    s39, v16, #11
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v16, #12
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s41, #0]
    v.extract    s39, v16, #13
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s39, v16, #14
    s.add        s41, s40, s39
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s41, #0]
    v.extract    s39, v16, #15
    s.add        s41, s40, s39
    s.addi       s39, s41, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s39, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s39, b8, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s39
    mb.wait      s39
    s.addi       s40, s25, #32
    s.add        s41, s7, s40
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s40, v19, #0
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s42, #0]
    v.extract    s40, v19, #1
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s40, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v19, #2
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s42, #0]
    v.extract    s40, v19, #3
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s40, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v19, #4
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s42, #0]
    v.extract    s40, v19, #5
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s40, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v19, #6
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s42, #0]
    v.extract    s40, v19, #7
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s40, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v19, #8
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s42, #0]
    v.extract    s40, v19, #9
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s40, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v19, #10
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s42, #0]
    v.extract    s40, v19, #11
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s40, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v19, #12
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s42, #0]
    v.extract    s40, v19, #13
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s40, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s40, v19, #14
    s.add        s42, s41, s40
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s42, #0]
    v.extract    s40, v19, #15
    s.add        s42, s41, s40
    s.addi       s40, s42, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s40, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s40, b9, #0, #1                 // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s40
    mb.wait      s40
    s.addi       s41, s25, #32
    s.add        s42, s7, s41
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s41, v20, #0
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s43, #0]
    v.extract    s41, v20, #1
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s41, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v20, #2
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s43, #0]
    v.extract    s41, v20, #3
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s41, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v20, #4
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s43, #0]
    v.extract    s41, v20, #5
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s41, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v20, #6
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s43, #0]
    v.extract    s41, v20, #7
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s41, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v20, #8
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s43, #0]
    v.extract    s41, v20, #9
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s41, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v20, #10
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s43, #0]
    v.extract    s41, v20, #11
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s41, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v20, #12
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s43, #0]
    v.extract    s41, v20, #13
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s41, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s41, v20, #14
    s.add        s43, s42, s41
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s43, #0]
    v.extract    s41, v20, #15
    s.add        s43, s42, s41
    s.addi       s41, s43, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s41, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s41, b10, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s41
    mb.wait      s41
    s.addi       s42, s25, #32
    s.add        s43, s7, s42
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s42, v22, #0
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s44, #0]
    v.extract    s42, v22, #1
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s42, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v22, #2
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s44, #0]
    v.extract    s42, v22, #3
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s42, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v22, #4
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s44, #0]
    v.extract    s42, v22, #5
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s42, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v22, #6
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s44, #0]
    v.extract    s42, v22, #7
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s42, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v22, #8
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s44, #0]
    v.extract    s42, v22, #9
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s42, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v22, #10
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s44, #0]
    v.extract    s42, v22, #11
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s42, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v22, #12
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s44, #0]
    v.extract    s42, v22, #13
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s42, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s42, v22, #14
    s.add        s44, s43, s42
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s44, #0]
    v.extract    s42, v22, #15
    s.add        s44, s43, s42
    s.addi       s42, s44, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s42, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s42, b11, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s42
    mb.wait      s42
    s.addi       s43, s25, #32
    s.add        s44, s7, s43
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s43, v23, #0
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s45, #0]
    v.extract    s43, v23, #1
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s43, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v23, #2
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s45, #0]
    v.extract    s43, v23, #3
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s43, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v23, #4
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s45, #0]
    v.extract    s43, v23, #5
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s43, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v23, #6
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s45, #0]
    v.extract    s43, v23, #7
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s43, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v23, #8
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s45, #0]
    v.extract    s43, v23, #9
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s43, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v23, #10
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s45, #0]
    v.extract    s43, v23, #11
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s43, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v23, #12
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s45, #0]
    v.extract    s43, v23, #13
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s43, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s43, v23, #14
    s.add        s45, s44, s43
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s45, #0]
    v.extract    s43, v23, #15
    s.add        s45, s44, s43
    s.addi       s43, s45, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s43, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s43, b12, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s43
    mb.wait      s43
    s.addi       s44, s25, #32
    s.add        s45, s7, s44
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s44, v24, #0
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s46, #0]
    v.extract    s44, v24, #1
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s44, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v24, #2
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s46, #0]
    v.extract    s44, v24, #3
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s44, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v24, #4
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s46, #0]
    v.extract    s44, v24, #5
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s44, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v24, #6
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s46, #0]
    v.extract    s44, v24, #7
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s44, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v24, #8
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s46, #0]
    v.extract    s44, v24, #9
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s44, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v24, #10
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s46, #0]
    v.extract    s44, v24, #11
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s44, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v24, #12
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s46, #0]
    v.extract    s44, v24, #13
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s44, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s44, v24, #14
    s.add        s46, s45, s44
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s46, #0]
    v.extract    s44, v24, #15
    s.add        s46, s45, s44
    s.addi       s44, s46, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s44, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s44, b13, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s44
    mb.wait      s44
    s.addi       s45, s25, #32
    s.add        s46, s7, s45
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s45, v25, #0
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s47, #0]
    v.extract    s45, v25, #1
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s45, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v25, #2
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s47, #0]
    v.extract    s45, v25, #3
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s45, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v25, #4
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s47, #0]
    v.extract    s45, v25, #5
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s45, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v25, #6
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s47, #0]
    v.extract    s45, v25, #7
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s45, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v25, #8
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s47, #0]
    v.extract    s45, v25, #9
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s45, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v25, #10
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s47, #0]
    v.extract    s45, v25, #11
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s45, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v25, #12
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s47, #0]
    v.extract    s45, v25, #13
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s45, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s45, v25, #14
    s.add        s47, s46, s45
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s47, #0]
    v.extract    s45, v25, #15
    s.add        s47, s46, s45
    s.addi       s45, s47, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s45, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s45, b14, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s45
    mb.wait      s45
    s.addi       s46, s25, #32
    s.add        s47, s7, s46
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s46, v26, #0
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s48, #0]
    v.extract    s46, v26, #1
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s46, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v26, #2
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s48, #0]
    v.extract    s46, v26, #3
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s46, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v26, #4
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s48, #0]
    v.extract    s46, v26, #5
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s46, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v26, #6
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s48, #0]
    v.extract    s46, v26, #7
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s46, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v26, #8
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s48, #0]
    v.extract    s46, v26, #9
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s46, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v26, #10
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s48, #0]
    v.extract    s46, v26, #11
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s46, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v26, #12
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s48, #0]
    v.extract    s46, v26, #13
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s46, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s46, v26, #14
    s.add        s48, s47, s46
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s48, #0]
    v.extract    s46, v26, #15
    s.add        s48, s47, s46
    s.addi       s46, s48, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s46, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s46, b15, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s46
    mb.wait      s46
    s.addi       s47, s31, #1024                 // 512 bytes of repack scratch
    v.extract    s48, v38, #0
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    s.movz       s48, #0
    s.add        s50, s48, s19                   // the tile origin
    v.splat      v39, s50
    v.add        v40, v35, v39
    s.movz       s48, #0
    s.add        s50, s48, s29                   // the tile origin
    v.splat      v39, s50
    v.cmp.lt     p3, v40, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #0
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #1
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #1
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #2
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #2
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #3
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #3
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #4
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #4
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #5
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #5
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #6
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #6
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #7
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #7
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #8
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #8
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #9
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #9
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #10
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #10
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #11
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #11
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #12
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #12
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #13
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #13
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #14
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #14
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #15
    s.add        s49, s48, s26
    s.addi       s48, s49, #64
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #15
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #0
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    s.movz       s48, #0
    s.add        s50, s48, s20                   // the tile origin
    v.splat      v39, s50
    v.add        v40, v35, v39
    s.movz       s48, #0
    s.add        s50, s48, s29                   // the tile origin
    v.splat      v39, s50
    v.cmp.lt     p3, v40, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #256
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #1
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #257
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #2
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #258
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #3
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #259
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #4
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #260
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #5
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #261
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #6
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #262
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #7
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #263
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #8
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #264
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #9
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #265
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #10
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #266
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #11
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #267
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #12
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #268
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #13
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #269
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #14
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #270
    v.st.scatter.b [s48, v37], v39
    v.extract    s48, v38, #15
    s.add        s49, s48, s26
    s.addi       s48, s49, #80
    s.add        s49, s4, s48
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s49, #0]
    s.addi       s48, s47, #271
    v.st.scatter.b [s48, v37], v39
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v39, [s47, #0]
    v.mov        v48, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s48, s47, #64
    v.ld.w       v39, [s48, #0]
    v.mov        v49, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s48, s47, #128
    v.ld.w       v39, [s48, #0]
    v.mov        v50, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s48, s47, #192
    v.ld.w       v39, [s48, #0]
    v.mov        v51, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s48, s47, #256
    v.ld.w       v39, [s48, #0]
    v.mov        v52, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s48, s47, #320
    v.ld.w       v39, [s48, #0]
    v.mov        v53, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s48, s47, #384
    v.ld.w       v39, [s48, #0]
    v.mov        v54, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s48, s47, #448
    v.ld.w       v39, [s48, #0]
    v.mov        v55, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s47, s28, #-64
    v.splat      v39, s47
    v.sub        v40, v39, v36
    v.movi       v39, #0
    v.cmp.gt     p3, v40, v39
    v.movi       v39, #0
    v.max.s      v41, v40, v39
    v.movi       v39, #4
    v.min.s      v40, v41, v39
    v.movi       v39, #1
    v.movi       v41, #3
    v.shl        v42, v40, v41
    v.shl        v41, v39, v42
    v.movi       v39, #1
    v.sub        v42, v41, v39
    v.movi       v39, #4
    v.cmp.ge     p4, v40, v39
    v.movi       v39, #-1
    @p4 v.sel        v40, v39, v42
    s.addi       s47, s25, #64
    s.add        s48, s7, s47
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s47, v16, #0
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s49, #0]
    v.extract    s47, v16, #1
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s47, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v16, #2
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s49, #0]
    v.extract    s47, v16, #3
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s47, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v16, #4
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s49, #0]
    v.extract    s47, v16, #5
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s47, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v16, #6
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s49, #0]
    v.extract    s47, v16, #7
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s47, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v16, #8
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s49, #0]
    v.extract    s47, v16, #9
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s47, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v16, #10
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s49, #0]
    v.extract    s47, v16, #11
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s47, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v16, #12
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s49, #0]
    v.extract    s47, v16, #13
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s47, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s47, v16, #14
    s.add        s49, s48, s47
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s49, #0]
    v.extract    s47, v16, #15
    s.add        s49, s48, s47
    s.addi       s47, s49, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s47, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s47, b16, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s47
    mb.wait      s47
    s.addi       s48, s25, #64
    s.add        s49, s7, s48
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s48, v19, #0
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s50, #0]
    v.extract    s48, v19, #1
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s48, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v19, #2
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s50, #0]
    v.extract    s48, v19, #3
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s48, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v19, #4
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s50, #0]
    v.extract    s48, v19, #5
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s48, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v19, #6
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s50, #0]
    v.extract    s48, v19, #7
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s48, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v19, #8
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s50, #0]
    v.extract    s48, v19, #9
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s48, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v19, #10
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s50, #0]
    v.extract    s48, v19, #11
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s48, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v19, #12
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s50, #0]
    v.extract    s48, v19, #13
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s48, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s48, v19, #14
    s.add        s50, s49, s48
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s50, #0]
    v.extract    s48, v19, #15
    s.add        s50, s49, s48
    s.addi       s48, s50, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s48, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s48, b17, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s48
    mb.wait      s48
    s.addi       s49, s25, #64
    s.add        s50, s7, s49
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s49, v20, #0
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s51, #0]
    v.extract    s49, v20, #1
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s49, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v20, #2
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s51, #0]
    v.extract    s49, v20, #3
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s49, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v20, #4
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s51, #0]
    v.extract    s49, v20, #5
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s49, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v20, #6
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s51, #0]
    v.extract    s49, v20, #7
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s49, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v20, #8
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s51, #0]
    v.extract    s49, v20, #9
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s49, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v20, #10
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s51, #0]
    v.extract    s49, v20, #11
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s49, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v20, #12
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s51, #0]
    v.extract    s49, v20, #13
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s49, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s49, v20, #14
    s.add        s51, s50, s49
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s51, #0]
    v.extract    s49, v20, #15
    s.add        s51, s50, s49
    s.addi       s49, s51, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s49, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s49, b18, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s49
    mb.wait      s49
    s.addi       s50, s25, #64
    s.add        s51, s7, s50
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s50, v22, #0
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s52, #0]
    v.extract    s50, v22, #1
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s50, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v22, #2
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s52, #0]
    v.extract    s50, v22, #3
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s50, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v22, #4
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s52, #0]
    v.extract    s50, v22, #5
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s50, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v22, #6
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s52, #0]
    v.extract    s50, v22, #7
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s50, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v22, #8
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s52, #0]
    v.extract    s50, v22, #9
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s50, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v22, #10
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s52, #0]
    v.extract    s50, v22, #11
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s50, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v22, #12
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s52, #0]
    v.extract    s50, v22, #13
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s50, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s50, v22, #14
    s.add        s52, s51, s50
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s52, #0]
    v.extract    s50, v22, #15
    s.add        s52, s51, s50
    s.addi       s50, s52, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s50, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s50, b19, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s50
    mb.wait      s50
    s.addi       s51, s25, #64
    s.add        s52, s7, s51
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s51, v23, #0
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s53, #0]
    v.extract    s51, v23, #1
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s51, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v23, #2
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s53, #0]
    v.extract    s51, v23, #3
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s51, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v23, #4
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s53, #0]
    v.extract    s51, v23, #5
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s51, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v23, #6
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s53, #0]
    v.extract    s51, v23, #7
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s51, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v23, #8
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s53, #0]
    v.extract    s51, v23, #9
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s51, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v23, #10
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s53, #0]
    v.extract    s51, v23, #11
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s51, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v23, #12
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s53, #0]
    v.extract    s51, v23, #13
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s51, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s51, v23, #14
    s.add        s53, s52, s51
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s53, #0]
    v.extract    s51, v23, #15
    s.add        s53, s52, s51
    s.addi       s51, s53, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s51, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s51, b20, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s51
    mb.wait      s51
    s.addi       s52, s25, #64
    s.add        s53, s7, s52
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s52, v24, #0
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s54, #0]
    v.extract    s52, v24, #1
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s52, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v24, #2
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s54, #0]
    v.extract    s52, v24, #3
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s52, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v24, #4
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s54, #0]
    v.extract    s52, v24, #5
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s52, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v24, #6
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s54, #0]
    v.extract    s52, v24, #7
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s52, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v24, #8
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s54, #0]
    v.extract    s52, v24, #9
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s52, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v24, #10
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s54, #0]
    v.extract    s52, v24, #11
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s52, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v24, #12
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s54, #0]
    v.extract    s52, v24, #13
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s52, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s52, v24, #14
    s.add        s54, s53, s52
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s54, #0]
    v.extract    s52, v24, #15
    s.add        s54, s53, s52
    s.addi       s52, s54, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s52, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s52, b21, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s52
    mb.wait      s52
    s.addi       s53, s25, #64
    s.add        s54, s7, s53
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s53, v25, #0
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s55, #0]
    v.extract    s53, v25, #1
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s53, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v25, #2
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s55, #0]
    v.extract    s53, v25, #3
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s53, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v25, #4
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s55, #0]
    v.extract    s53, v25, #5
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s53, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v25, #6
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s55, #0]
    v.extract    s53, v25, #7
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s53, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v25, #8
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s55, #0]
    v.extract    s53, v25, #9
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s53, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v25, #10
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s55, #0]
    v.extract    s53, v25, #11
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s53, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v25, #12
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s55, #0]
    v.extract    s53, v25, #13
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s53, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s53, v25, #14
    s.add        s55, s54, s53
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s55, #0]
    v.extract    s53, v25, #15
    s.add        s55, s54, s53
    s.addi       s53, s55, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s53, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s53, b22, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s53
    mb.wait      s53
    s.addi       s54, s25, #64
    s.add        s55, s7, s54
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s54, v26, #0
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s56, #0]
    v.extract    s54, v26, #1
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s54, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v56, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v26, #2
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s56, #0]
    v.extract    s54, v26, #3
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s54, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v57, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v26, #4
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s56, #0]
    v.extract    s54, v26, #5
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s54, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v58, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v26, #6
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s56, #0]
    v.extract    s54, v26, #7
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s54, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v59, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v26, #8
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s56, #0]
    v.extract    s54, v26, #9
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s54, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v60, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v26, #10
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s56, #0]
    v.extract    s54, v26, #11
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s54, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v61, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v26, #12
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s56, #0]
    v.extract    s54, v26, #13
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s54, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v62, v39                        // hand off through the shared window (sec 7.3)
    v.extract    s54, v26, #14
    s.add        s56, s55, s54
    p.and        p4, p1, p3
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v39, [s56, #0]
    v.extract    s54, v26, #15
    s.add        s56, s55, s54
    s.addi       s54, s56, #-32
    p.and        p4, p2, p3
    v.movi       v41, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v41, [s54, #0]
    v.or         v42, v39, v41
    v.and        v39, v42, v40
    v.mov        v63, v39                        // hand off through the shared window (sec 7.3)
    mb.arm       s54, b23, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s54
    mb.wait      s54
    s.addi       s55, s31, #1536                 // 512 bytes of repack scratch
    v.extract    s56, v38, #0
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    s.movz       s56, #0
    s.add        s58, s56, s22                   // the tile origin
    v.splat      v39, s58
    v.add        v40, v35, v39
    s.movz       s56, #0
    s.add        s58, s56, s29                   // the tile origin
    v.splat      v39, s58
    v.cmp.lt     p3, v40, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #0
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #1
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #1
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #2
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #2
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #3
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #3
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #4
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #4
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #5
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #5
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #6
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #6
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #7
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #7
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #8
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #8
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #9
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #9
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #10
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #10
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #11
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #11
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #12
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #12
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #13
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #13
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #14
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #14
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #15
    s.add        s57, s56, s26
    s.addi       s56, s57, #96
    s.add        s57, s4, s56
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v39, [s57, #0]
    s.addi       s56, s55, #15
    v.st.scatter.b [s56, v37], v39
    v.extract    s56, v38, #0
    s.add        s57, s56, s26
    s.addi       s56, s57, #112
    s.add        s57, s4, s56
    s.movz       s56, #0
    s.add        s58, s56, s23                   // the tile origin
    v.splat      v39, s58
    v.add        v40, v35, v39
    s.movz       s56, #0
    s.add        s58, s56, s29                   // the tile origin
    v.splat      v35, s58
    v.cmp.lt     p3, v40, v35
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s57, #0]
    s.addi       s29, s55, #256
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #1
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #257
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #2
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #258
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #3
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #259
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #4
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #260
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #5
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #261
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #6
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #262
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #7
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #263
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #8
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #264
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #9
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #265
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #10
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #266
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #11
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #267
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #12
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #268
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #13
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #269
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #14
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #270
    v.st.scatter.b [s29, v37], v35
    v.extract    s29, v38, #15
    s.add        s56, s29, s26
    s.addi       s29, s56, #112
    s.add        s56, s4, s29
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p3 v.ld.b       v35, [s56, #0]
    s.addi       s29, s55, #271
    v.st.scatter.b [s29, v37], v35
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v35, [s55, #0]
    v.mov        v48, v35                        // hand off through the shared window (sec 7.3)
    s.addi       s29, s55, #64
    v.ld.w       v35, [s29, #0]
    v.mov        v49, v35                        // hand off through the shared window (sec 7.3)
    s.addi       s29, s55, #128
    v.ld.w       v35, [s29, #0]
    v.mov        v50, v35                        // hand off through the shared window (sec 7.3)
    s.addi       s29, s55, #192
    v.ld.w       v35, [s29, #0]
    v.mov        v51, v35                        // hand off through the shared window (sec 7.3)
    s.addi       s29, s55, #256
    v.ld.w       v35, [s29, #0]
    v.mov        v52, v35                        // hand off through the shared window (sec 7.3)
    s.addi       s29, s55, #320
    v.ld.w       v35, [s29, #0]
    v.mov        v53, v35                        // hand off through the shared window (sec 7.3)
    s.addi       s29, s55, #384
    v.ld.w       v35, [s29, #0]
    v.mov        v54, v35                        // hand off through the shared window (sec 7.3)
    s.addi       s29, s55, #448
    v.ld.w       v35, [s29, #0]
    v.mov        v55, v35                        // hand off through the shared window (sec 7.3)
    s.addi       s29, s28, #-96
    v.splat      v35, s29
    v.sub        v38, v35, v36
    v.movi       v35, #0
    v.cmp.gt     p3, v38, v35
    v.movi       v35, #0
    v.max.s      v36, v38, v35
    v.movi       v35, #4
    v.min.s      v38, v36, v35
    v.movi       v35, #1
    v.movi       v36, #3
    v.shl        v39, v38, v36
    v.shl        v36, v35, v39
    v.movi       v35, #1
    v.sub        v39, v36, v35
    v.movi       v35, #4
    v.cmp.ge     p4, v38, v35
    v.movi       v35, #-1
    @p4 v.sel        v36, v35, v39
    s.addi       s28, s25, #96
    s.add        s29, s7, s28
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s28, v16, #0
    s.add        s55, s29, s28
    p.and        p4, p1, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s55, #0]
    v.extract    s28, v16, #1
    s.add        s55, s29, s28
    s.addi       s28, s55, #-32
    p.and        p4, p2, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s28, #0]
    v.or         v39, v35, v38
    v.and        v35, v39, v36
    v.mov        v56, v35                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v16, #2
    s.add        s55, s29, s28
    p.and        p4, p1, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s55, #0]
    v.extract    s28, v16, #3
    s.add        s55, s29, s28
    s.addi       s28, s55, #-32
    p.and        p4, p2, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s28, #0]
    v.or         v39, v35, v38
    v.and        v35, v39, v36
    v.mov        v57, v35                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v16, #4
    s.add        s55, s29, s28
    p.and        p4, p1, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s55, #0]
    v.extract    s28, v16, #5
    s.add        s55, s29, s28
    s.addi       s28, s55, #-32
    p.and        p4, p2, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s28, #0]
    v.or         v39, v35, v38
    v.and        v35, v39, v36
    v.mov        v58, v35                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v16, #6
    s.add        s55, s29, s28
    p.and        p4, p1, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s55, #0]
    v.extract    s28, v16, #7
    s.add        s55, s29, s28
    s.addi       s28, s55, #-32
    p.and        p4, p2, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s28, #0]
    v.or         v39, v35, v38
    v.and        v35, v39, v36
    v.mov        v59, v35                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v16, #8
    s.add        s55, s29, s28
    p.and        p4, p1, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s55, #0]
    v.extract    s28, v16, #9
    s.add        s55, s29, s28
    s.addi       s28, s55, #-32
    p.and        p4, p2, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s28, #0]
    v.or         v39, v35, v38
    v.and        v35, v39, v36
    v.mov        v60, v35                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v16, #10
    s.add        s55, s29, s28
    p.and        p4, p1, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s55, #0]
    v.extract    s28, v16, #11
    s.add        s55, s29, s28
    s.addi       s28, s55, #-32
    p.and        p4, p2, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s28, #0]
    v.or         v39, v35, v38
    v.and        v35, v39, v36
    v.mov        v61, v35                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v16, #12
    s.add        s55, s29, s28
    p.and        p4, p1, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s55, #0]
    v.extract    s28, v16, #13
    s.add        s55, s29, s28
    s.addi       s28, s55, #-32
    p.and        p4, p2, p3
    v.movi       v38, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v38, [s28, #0]
    v.or         v39, v35, v38
    v.and        v35, v39, v36
    v.mov        v62, v35                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v16, #14
    s.add        s55, s29, s28
    p.and        p4, p1, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s55, #0]
    v.extract    s28, v16, #15
    s.add        s55, s29, s28
    s.addi       s28, s55, #-32
    p.and        p4, p2, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.or         v38, v35, v16
    v.and        v16, v38, v36
    v.mov        v63, v16                        // hand off through the shared window (sec 7.3)
    mb.arm       s28, b24, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a8, v56, v48, s28
    mb.wait      s28
    s.addi       s29, s25, #96
    s.add        s55, s7, s29
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s29, v19, #0
    s.add        s56, s55, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.extract    s29, v19, #1
    s.add        s56, s55, s29
    s.addi       s29, s56, #-32
    p.and        p4, p2, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s29, #0]
    v.or         v38, v16, v35
    v.and        v16, v38, v36
    v.mov        v56, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s29, v19, #2
    s.add        s56, s55, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.extract    s29, v19, #3
    s.add        s56, s55, s29
    s.addi       s29, s56, #-32
    p.and        p4, p2, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s29, #0]
    v.or         v38, v16, v35
    v.and        v16, v38, v36
    v.mov        v57, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s29, v19, #4
    s.add        s56, s55, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.extract    s29, v19, #5
    s.add        s56, s55, s29
    s.addi       s29, s56, #-32
    p.and        p4, p2, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s29, #0]
    v.or         v38, v16, v35
    v.and        v16, v38, v36
    v.mov        v58, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s29, v19, #6
    s.add        s56, s55, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.extract    s29, v19, #7
    s.add        s56, s55, s29
    s.addi       s29, s56, #-32
    p.and        p4, p2, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s29, #0]
    v.or         v38, v16, v35
    v.and        v16, v38, v36
    v.mov        v59, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s29, v19, #8
    s.add        s56, s55, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.extract    s29, v19, #9
    s.add        s56, s55, s29
    s.addi       s29, s56, #-32
    p.and        p4, p2, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s29, #0]
    v.or         v38, v16, v35
    v.and        v16, v38, v36
    v.mov        v60, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s29, v19, #10
    s.add        s56, s55, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.extract    s29, v19, #11
    s.add        s56, s55, s29
    s.addi       s29, s56, #-32
    p.and        p4, p2, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s29, #0]
    v.or         v38, v16, v35
    v.and        v16, v38, v36
    v.mov        v61, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s29, v19, #12
    s.add        s56, s55, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.extract    s29, v19, #13
    s.add        s56, s55, s29
    s.addi       s29, s56, #-32
    p.and        p4, p2, p3
    v.movi       v35, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v35, [s29, #0]
    v.or         v38, v16, v35
    v.and        v16, v38, v36
    v.mov        v62, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s29, v19, #14
    s.add        s56, s55, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s56, #0]
    v.extract    s29, v19, #15
    s.add        s56, s55, s29
    s.addi       s29, s56, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s29, #0]
    v.or         v35, v16, v19
    v.and        v16, v35, v36
    v.mov        v63, v16                        // hand off through the shared window (sec 7.3)
    mb.arm       s29, b25, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a9, v56, v48, s29
    mb.wait      s29
    s.addi       s55, s25, #96
    s.add        s56, s7, s55
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s55, v20, #0
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.extract    s55, v20, #1
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s55, #0]
    v.or         v35, v16, v19
    v.and        v16, v35, v36
    v.mov        v56, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v20, #2
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.extract    s55, v20, #3
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s55, #0]
    v.or         v35, v16, v19
    v.and        v16, v35, v36
    v.mov        v57, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v20, #4
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.extract    s55, v20, #5
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s55, #0]
    v.or         v35, v16, v19
    v.and        v16, v35, v36
    v.mov        v58, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v20, #6
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.extract    s55, v20, #7
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s55, #0]
    v.or         v35, v16, v19
    v.and        v16, v35, v36
    v.mov        v59, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v20, #8
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.extract    s55, v20, #9
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s55, #0]
    v.or         v35, v16, v19
    v.and        v16, v35, v36
    v.mov        v60, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v20, #10
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.extract    s55, v20, #11
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s55, #0]
    v.or         v35, v16, v19
    v.and        v16, v35, v36
    v.mov        v61, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v20, #12
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.extract    s55, v20, #13
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s55, #0]
    v.or         v35, v16, v19
    v.and        v16, v35, v36
    v.mov        v62, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s55, v20, #14
    s.add        s57, s56, s55
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s57, #0]
    v.extract    s55, v20, #15
    s.add        s57, s56, s55
    s.addi       s55, s57, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s55, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v63, v16                        // hand off through the shared window (sec 7.3)
    mb.arm       s55, b26, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a10, v56, v48, s55
    mb.wait      s55
    s.addi       s56, s25, #96
    s.add        s57, s7, s56
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s56, v22, #0
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.extract    s56, v22, #1
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s56, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v56, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v22, #2
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.extract    s56, v22, #3
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s56, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v57, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v22, #4
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.extract    s56, v22, #5
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s56, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v58, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v22, #6
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.extract    s56, v22, #7
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s56, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v59, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v22, #8
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.extract    s56, v22, #9
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s56, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v60, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v22, #10
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.extract    s56, v22, #11
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s56, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v61, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v22, #12
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.extract    s56, v22, #13
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s56, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v62, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s56, v22, #14
    s.add        s58, s57, s56
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s58, #0]
    v.extract    s56, v22, #15
    s.add        s58, s57, s56
    s.addi       s56, s58, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s56, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v63, v16                        // hand off through the shared window (sec 7.3)
    mb.arm       s56, b27, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a11, v56, v48, s56
    mb.wait      s56
    s.addi       s57, s25, #96
    s.add        s58, s7, s57
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s57, v23, #0
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s59, #0]
    v.extract    s57, v23, #1
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s57, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v56, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s57, v23, #2
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s59, #0]
    v.extract    s57, v23, #3
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s57, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v57, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s57, v23, #4
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s59, #0]
    v.extract    s57, v23, #5
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s57, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v58, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s57, v23, #6
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s59, #0]
    v.extract    s57, v23, #7
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s57, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v59, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s57, v23, #8
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s59, #0]
    v.extract    s57, v23, #9
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s57, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v60, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s57, v23, #10
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s59, #0]
    v.extract    s57, v23, #11
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s57, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v61, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s57, v23, #12
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s59, #0]
    v.extract    s57, v23, #13
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s57, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v62, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s57, v23, #14
    s.add        s59, s58, s57
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s59, #0]
    v.extract    s57, v23, #15
    s.add        s59, s58, s57
    s.addi       s57, s59, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s57, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v63, v16                        // hand off through the shared window (sec 7.3)
    mb.arm       s57, b28, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a12, v56, v48, s57
    mb.wait      s57
    s.addi       s58, s25, #96
    s.add        s59, s7, s58
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s58, v24, #0
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s60, #0]
    v.extract    s58, v24, #1
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s58, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v56, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s58, v24, #2
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s60, #0]
    v.extract    s58, v24, #3
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s58, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v57, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s58, v24, #4
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s60, #0]
    v.extract    s58, v24, #5
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s58, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v58, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s58, v24, #6
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s60, #0]
    v.extract    s58, v24, #7
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s58, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v59, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s58, v24, #8
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s60, #0]
    v.extract    s58, v24, #9
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s58, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v60, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s58, v24, #10
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s60, #0]
    v.extract    s58, v24, #11
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s58, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v61, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s58, v24, #12
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s60, #0]
    v.extract    s58, v24, #13
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s58, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v62, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s58, v24, #14
    s.add        s60, s59, s58
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s60, #0]
    v.extract    s58, v24, #15
    s.add        s60, s59, s58
    s.addi       s58, s60, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s58, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v63, v16                        // hand off through the shared window (sec 7.3)
    mb.arm       s58, b29, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a13, v56, v48, s58
    mb.wait      s58
    s.addi       s59, s25, #96
    s.add        s60, s7, s59
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s59, v25, #0
    s.add        s28, s60, s59
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s28, #0]
    v.extract    s28, v25, #1
    s.add        s29, s60, s28
    s.addi       s28, s29, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v56, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v25, #2
    s.add        s29, s60, s28
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s29, #0]
    v.extract    s28, v25, #3
    s.add        s29, s60, s28
    s.addi       s28, s29, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v57, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v25, #4
    s.add        s29, s60, s28
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s29, #0]
    v.extract    s28, v25, #5
    s.add        s29, s60, s28
    s.addi       s28, s29, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v58, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v25, #6
    s.add        s29, s60, s28
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s29, #0]
    v.extract    s28, v25, #7
    s.add        s29, s60, s28
    s.addi       s28, s29, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v59, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v25, #8
    s.add        s29, s60, s28
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s29, #0]
    v.extract    s28, v25, #9
    s.add        s29, s60, s28
    s.addi       s28, s29, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v60, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v25, #10
    s.add        s29, s60, s28
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s29, #0]
    v.extract    s28, v25, #11
    s.add        s29, s60, s28
    s.addi       s28, s29, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v61, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v25, #12
    s.add        s29, s60, s28
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s29, #0]
    v.extract    s28, v25, #13
    s.add        s29, s60, s28
    s.addi       s28, s29, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v62, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s28, v25, #14
    s.add        s29, s60, s28
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s29, #0]
    v.extract    s28, v25, #15
    s.add        s29, s60, s28
    s.addi       s28, s29, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s28, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v63, v16                        // hand off through the shared window (sec 7.3)
    mb.arm       s28, b30, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a14, v56, v48, s28
    mb.wait      s28
    s.addi       s29, s25, #96
    s.add        s30, s7, s29
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s29, v26, #0
    s.add        s32, s30, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s32, #0]
    v.extract    s29, v26, #1
    s.add        s32, s30, s29
    s.addi       s29, s32, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s29, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v56, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s29, v26, #2
    s.add        s32, s30, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s32, #0]
    v.extract    s29, v26, #3
    s.add        s32, s30, s29
    s.addi       s29, s32, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s29, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v57, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s29, v26, #4
    s.add        s32, s30, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s32, #0]
    v.extract    s29, v26, #5
    s.add        s32, s30, s29
    s.addi       s29, s32, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s29, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v58, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s29, v26, #6
    s.add        s32, s30, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s32, #0]
    v.extract    s29, v26, #7
    s.add        s32, s30, s29
    s.addi       s29, s32, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s29, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v59, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s29, v26, #8
    s.add        s32, s30, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s32, #0]
    v.extract    s29, v26, #9
    s.add        s32, s30, s29
    s.addi       s29, s32, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s29, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v60, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s29, v26, #10
    s.add        s32, s30, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s32, #0]
    v.extract    s29, v26, #11
    s.add        s32, s30, s29
    s.addi       s29, s32, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s29, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v61, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s29, v26, #12
    s.add        s32, s30, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s32, #0]
    v.extract    s29, v26, #13
    s.add        s32, s30, s29
    s.addi       s29, s32, #-32
    p.and        p4, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v19, [s29, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v62, v16                        // hand off through the shared window (sec 7.3)
    v.extract    s29, v26, #14
    s.add        s32, s30, s29
    p.and        p4, p1, p3
    v.movi       v16, #0                         // other=, materialised (sec 12)
    @p4 v.ld.w       v16, [s32, #0]
    v.extract    s29, v26, #15
    s.add        s32, s30, s29
    s.addi       s29, s32, #-32
    p.and        p1, p2, p3
    v.movi       v19, #0                         // other=, materialised (sec 12)
    @p1 v.ld.w       v19, [s29, #0]
    v.or         v20, v16, v19
    v.and        v16, v20, v36
    v.mov        v63, v16                        // hand off through the shared window (sec 7.3)
    mb.arm       s29, b31, #0, #1                // 0 arrival(s), 1 operation(s)
    m.mma.async.k32.e4m3 a15, v56, v48, s29
    mb.wait      s29
    s.addi       s30, s31, #2048
    s.movz       s32, #0
    a.vread      v16, a8, s32
    v.st.scatter.w [s30, v37], v16
    s.addi       s32, s30, #4
    s.movz       s33, #1
    a.vread      v16, a8, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #8
    s.movz       s33, #2
    a.vread      v16, a8, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #12
    s.movz       s33, #3
    a.vread      v16, a8, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #16
    s.movz       s33, #4
    a.vread      v16, a8, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #20
    s.movz       s33, #5
    a.vread      v16, a8, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #24
    s.movz       s33, #6
    a.vread      v16, a8, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #28
    s.movz       s33, #7
    a.vread      v16, a8, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #32
    s.movz       s33, #8
    a.vread      v16, a8, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #36
    s.movz       s33, #9
    a.vread      v16, a8, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #40
    s.movz       s33, #10
    a.vread      v16, a8, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #44
    s.movz       s33, #11
    a.vread      v16, a8, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #48
    s.movz       s33, #12
    a.vread      v16, a8, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #52
    s.movz       s33, #13
    a.vread      v16, a8, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #56
    s.movz       s33, #14
    a.vread      v16, a8, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #60
    s.movz       s30, #15
    a.vread      v16, a8, s30
    v.st.scatter.w [s32, v37], v16
    fence.acq_rel.device
    s.addi       s30, s31, #3072
    s.movz       s32, #0
    a.vread      v16, a9, s32
    v.st.scatter.w [s30, v37], v16
    s.addi       s32, s30, #4
    s.movz       s33, #1
    a.vread      v16, a9, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #8
    s.movz       s33, #2
    a.vread      v16, a9, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #12
    s.movz       s33, #3
    a.vread      v16, a9, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #16
    s.movz       s33, #4
    a.vread      v16, a9, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #20
    s.movz       s33, #5
    a.vread      v16, a9, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #24
    s.movz       s33, #6
    a.vread      v16, a9, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #28
    s.movz       s33, #7
    a.vread      v16, a9, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #32
    s.movz       s33, #8
    a.vread      v16, a9, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #36
    s.movz       s33, #9
    a.vread      v16, a9, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #40
    s.movz       s33, #10
    a.vread      v16, a9, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #44
    s.movz       s33, #11
    a.vread      v16, a9, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #48
    s.movz       s33, #12
    a.vread      v16, a9, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #52
    s.movz       s33, #13
    a.vread      v16, a9, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #56
    s.movz       s33, #14
    a.vread      v16, a9, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #60
    s.movz       s30, #15
    a.vread      v16, a9, s30
    v.st.scatter.w [s32, v37], v16
    fence.acq_rel.device
    s.addi       s30, s31, #4096
    s.movz       s32, #0
    a.vread      v16, a10, s32
    v.st.scatter.w [s30, v37], v16
    s.addi       s32, s30, #4
    s.movz       s33, #1
    a.vread      v16, a10, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #8
    s.movz       s33, #2
    a.vread      v16, a10, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #12
    s.movz       s33, #3
    a.vread      v16, a10, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #16
    s.movz       s33, #4
    a.vread      v16, a10, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #20
    s.movz       s33, #5
    a.vread      v16, a10, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #24
    s.movz       s33, #6
    a.vread      v16, a10, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #28
    s.movz       s33, #7
    a.vread      v16, a10, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #32
    s.movz       s33, #8
    a.vread      v16, a10, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #36
    s.movz       s33, #9
    a.vread      v16, a10, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #40
    s.movz       s33, #10
    a.vread      v16, a10, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #44
    s.movz       s33, #11
    a.vread      v16, a10, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #48
    s.movz       s33, #12
    a.vread      v16, a10, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #52
    s.movz       s33, #13
    a.vread      v16, a10, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #56
    s.movz       s33, #14
    a.vread      v16, a10, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #60
    s.movz       s30, #15
    a.vread      v16, a10, s30
    v.st.scatter.w [s32, v37], v16
    fence.acq_rel.device
    s.addi       s30, s31, #5120
    s.movz       s32, #0
    a.vread      v16, a11, s32
    v.st.scatter.w [s30, v37], v16
    s.addi       s32, s30, #4
    s.movz       s33, #1
    a.vread      v16, a11, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #8
    s.movz       s33, #2
    a.vread      v16, a11, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #12
    s.movz       s33, #3
    a.vread      v16, a11, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #16
    s.movz       s33, #4
    a.vread      v16, a11, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #20
    s.movz       s33, #5
    a.vread      v16, a11, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #24
    s.movz       s33, #6
    a.vread      v16, a11, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #28
    s.movz       s33, #7
    a.vread      v16, a11, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #32
    s.movz       s33, #8
    a.vread      v16, a11, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #36
    s.movz       s33, #9
    a.vread      v16, a11, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #40
    s.movz       s33, #10
    a.vread      v16, a11, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #44
    s.movz       s33, #11
    a.vread      v16, a11, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #48
    s.movz       s33, #12
    a.vread      v16, a11, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #52
    s.movz       s33, #13
    a.vread      v16, a11, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #56
    s.movz       s33, #14
    a.vread      v16, a11, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #60
    s.movz       s30, #15
    a.vread      v16, a11, s30
    v.st.scatter.w [s32, v37], v16
    fence.acq_rel.device
    s.addi       s30, s31, #6144
    s.movz       s32, #0
    a.vread      v16, a12, s32
    v.st.scatter.w [s30, v37], v16
    s.addi       s32, s30, #4
    s.movz       s33, #1
    a.vread      v16, a12, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #8
    s.movz       s33, #2
    a.vread      v16, a12, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #12
    s.movz       s33, #3
    a.vread      v16, a12, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #16
    s.movz       s33, #4
    a.vread      v16, a12, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #20
    s.movz       s33, #5
    a.vread      v16, a12, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #24
    s.movz       s33, #6
    a.vread      v16, a12, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #28
    s.movz       s33, #7
    a.vread      v16, a12, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #32
    s.movz       s33, #8
    a.vread      v16, a12, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #36
    s.movz       s33, #9
    a.vread      v16, a12, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #40
    s.movz       s33, #10
    a.vread      v16, a12, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #44
    s.movz       s33, #11
    a.vread      v16, a12, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #48
    s.movz       s33, #12
    a.vread      v16, a12, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #52
    s.movz       s33, #13
    a.vread      v16, a12, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #56
    s.movz       s33, #14
    a.vread      v16, a12, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #60
    s.movz       s30, #15
    a.vread      v16, a12, s30
    v.st.scatter.w [s32, v37], v16
    fence.acq_rel.device
    s.addi       s30, s31, #7168
    s.movz       s32, #0
    a.vread      v16, a13, s32
    v.st.scatter.w [s30, v37], v16
    s.addi       s32, s30, #4
    s.movz       s33, #1
    a.vread      v16, a13, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #8
    s.movz       s33, #2
    a.vread      v16, a13, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #12
    s.movz       s33, #3
    a.vread      v16, a13, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #16
    s.movz       s33, #4
    a.vread      v16, a13, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #20
    s.movz       s33, #5
    a.vread      v16, a13, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #24
    s.movz       s33, #6
    a.vread      v16, a13, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #28
    s.movz       s33, #7
    a.vread      v16, a13, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #32
    s.movz       s33, #8
    a.vread      v16, a13, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #36
    s.movz       s33, #9
    a.vread      v16, a13, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #40
    s.movz       s33, #10
    a.vread      v16, a13, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #44
    s.movz       s33, #11
    a.vread      v16, a13, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #48
    s.movz       s33, #12
    a.vread      v16, a13, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #52
    s.movz       s33, #13
    a.vread      v16, a13, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #56
    s.movz       s33, #14
    a.vread      v16, a13, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #60
    s.movz       s30, #15
    a.vread      v16, a13, s30
    v.st.scatter.w [s32, v37], v16
    fence.acq_rel.device
    s.addi       s30, s31, #8192
    s.movz       s32, #0
    a.vread      v16, a14, s32
    v.st.scatter.w [s30, v37], v16
    s.addi       s32, s30, #4
    s.movz       s33, #1
    a.vread      v16, a14, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #8
    s.movz       s33, #2
    a.vread      v16, a14, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #12
    s.movz       s33, #3
    a.vread      v16, a14, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #16
    s.movz       s33, #4
    a.vread      v16, a14, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #20
    s.movz       s33, #5
    a.vread      v16, a14, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #24
    s.movz       s33, #6
    a.vread      v16, a14, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #28
    s.movz       s33, #7
    a.vread      v16, a14, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #32
    s.movz       s33, #8
    a.vread      v16, a14, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #36
    s.movz       s33, #9
    a.vread      v16, a14, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #40
    s.movz       s33, #10
    a.vread      v16, a14, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #44
    s.movz       s33, #11
    a.vread      v16, a14, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #48
    s.movz       s33, #12
    a.vread      v16, a14, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #52
    s.movz       s33, #13
    a.vread      v16, a14, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #56
    s.movz       s33, #14
    a.vread      v16, a14, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #60
    s.movz       s30, #15
    a.vread      v16, a14, s30
    v.st.scatter.w [s32, v37], v16
    fence.acq_rel.device
    s.addi       s30, s31, #9216
    s.movz       s32, #0
    a.vread      v16, a15, s32
    v.st.scatter.w [s30, v37], v16
    s.addi       s32, s30, #4
    s.movz       s33, #1
    a.vread      v16, a15, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #8
    s.movz       s33, #2
    a.vread      v16, a15, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #12
    s.movz       s33, #3
    a.vread      v16, a15, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #16
    s.movz       s33, #4
    a.vread      v16, a15, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #20
    s.movz       s33, #5
    a.vread      v16, a15, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #24
    s.movz       s33, #6
    a.vread      v16, a15, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #28
    s.movz       s33, #7
    a.vread      v16, a15, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #32
    s.movz       s33, #8
    a.vread      v16, a15, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #36
    s.movz       s33, #9
    a.vread      v16, a15, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #40
    s.movz       s33, #10
    a.vread      v16, a15, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #44
    s.movz       s33, #11
    a.vread      v16, a15, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #48
    s.movz       s33, #12
    a.vread      v16, a15, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #52
    s.movz       s33, #13
    a.vread      v16, a15, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #56
    s.movz       s33, #14
    a.vread      v16, a15, s33
    v.st.scatter.w [s32, v37], v16
    s.addi       s32, s30, #60
    s.movz       s30, #15
    a.vread      v16, a15, s30
    v.st.scatter.w [s32, v37], v16
    fence.acq_rel.device
    s.addi       s30, s31, #10240
    s.movz       s32, #0
    a.vread      v16, a0, s32
    s.addi       s32, s31, #2048
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v12, #0
    v.splat      v20, s32
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s30, #0], v20
    s.addi       s32, s30, #64
    s.movz       s33, #1
    a.vread      v16, a0, s33
    s.addi       s33, s31, #2112
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #1
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #128
    s.movz       s33, #2
    a.vread      v16, a0, s33
    s.addi       s33, s31, #2176
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #2
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #192
    s.movz       s33, #3
    a.vread      v16, a0, s33
    s.addi       s33, s31, #2240
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #3
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #256
    s.movz       s33, #4
    a.vread      v16, a0, s33
    s.addi       s33, s31, #2304
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #4
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #320
    s.movz       s33, #5
    a.vread      v16, a0, s33
    s.addi       s33, s31, #2368
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #5
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #384
    s.movz       s33, #6
    a.vread      v16, a0, s33
    s.addi       s33, s31, #2432
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #6
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #448
    s.movz       s33, #7
    a.vread      v16, a0, s33
    s.addi       s33, s31, #2496
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #7
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #512
    s.movz       s33, #8
    a.vread      v16, a0, s33
    s.addi       s33, s31, #2560
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #8
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #576
    s.movz       s33, #9
    a.vread      v16, a0, s33
    s.addi       s33, s31, #2624
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #9
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #640
    s.movz       s33, #10
    a.vread      v16, a0, s33
    s.addi       s33, s31, #2688
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #10
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #704
    s.movz       s33, #11
    a.vread      v16, a0, s33
    s.addi       s33, s31, #2752
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #11
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #768
    s.movz       s33, #12
    a.vread      v16, a0, s33
    s.addi       s33, s31, #2816
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #12
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #832
    s.movz       s33, #13
    a.vread      v16, a0, s33
    s.addi       s33, s31, #2880
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #13
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #896
    s.movz       s33, #14
    a.vread      v16, a0, s33
    s.addi       s33, s31, #2944
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #14
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #960
    s.movz       s30, #15
    a.vread      v16, a0, s30
    s.addi       s30, s31, #3008
    v.ld.w       v19, [s30, #0]
    v.extract    s30, v12, #15
    v.splat      v20, s30
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v27
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    fence.acq_rel.device
    s.addi       s30, s31, #11264
    s.movz       s32, #0
    a.vread      v16, a1, s32
    s.addi       s32, s31, #3072
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v12, #0
    v.splat      v20, s32
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s30, #0], v20
    s.addi       s32, s30, #64
    s.movz       s33, #1
    a.vread      v16, a1, s33
    s.addi       s33, s31, #3136
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #1
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #128
    s.movz       s33, #2
    a.vread      v16, a1, s33
    s.addi       s33, s31, #3200
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #2
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #192
    s.movz       s33, #3
    a.vread      v16, a1, s33
    s.addi       s33, s31, #3264
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #3
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #256
    s.movz       s33, #4
    a.vread      v16, a1, s33
    s.addi       s33, s31, #3328
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #4
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #320
    s.movz       s33, #5
    a.vread      v16, a1, s33
    s.addi       s33, s31, #3392
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #5
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #384
    s.movz       s33, #6
    a.vread      v16, a1, s33
    s.addi       s33, s31, #3456
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #6
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #448
    s.movz       s33, #7
    a.vread      v16, a1, s33
    s.addi       s33, s31, #3520
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #7
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #512
    s.movz       s33, #8
    a.vread      v16, a1, s33
    s.addi       s33, s31, #3584
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #8
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #576
    s.movz       s33, #9
    a.vread      v16, a1, s33
    s.addi       s33, s31, #3648
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #9
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #640
    s.movz       s33, #10
    a.vread      v16, a1, s33
    s.addi       s33, s31, #3712
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #10
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #704
    s.movz       s33, #11
    a.vread      v16, a1, s33
    s.addi       s33, s31, #3776
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #11
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #768
    s.movz       s33, #12
    a.vread      v16, a1, s33
    s.addi       s33, s31, #3840
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #12
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #832
    s.movz       s33, #13
    a.vread      v16, a1, s33
    s.addi       s33, s31, #3904
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #13
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #896
    s.movz       s33, #14
    a.vread      v16, a1, s33
    s.addi       s33, s31, #3968
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #14
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #960
    s.movz       s30, #15
    a.vread      v16, a1, s30
    s.addi       s30, s31, #4032
    v.ld.w       v19, [s30, #0]
    v.extract    s30, v12, #15
    v.splat      v20, s30
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v28
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    fence.acq_rel.device
    s.addi       s30, s31, #12288
    s.movz       s32, #0
    a.vread      v16, a2, s32
    s.addi       s32, s31, #4096
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v12, #0
    v.splat      v20, s32
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s30, #0], v20
    s.addi       s32, s30, #64
    s.movz       s33, #1
    a.vread      v16, a2, s33
    s.addi       s33, s31, #4160
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #1
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #128
    s.movz       s33, #2
    a.vread      v16, a2, s33
    s.addi       s33, s31, #4224
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #2
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #192
    s.movz       s33, #3
    a.vread      v16, a2, s33
    s.addi       s33, s31, #4288
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #3
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #256
    s.movz       s33, #4
    a.vread      v16, a2, s33
    s.addi       s33, s31, #4352
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #4
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #320
    s.movz       s33, #5
    a.vread      v16, a2, s33
    s.addi       s33, s31, #4416
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #5
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #384
    s.movz       s33, #6
    a.vread      v16, a2, s33
    s.addi       s33, s31, #4480
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #6
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #448
    s.movz       s33, #7
    a.vread      v16, a2, s33
    s.addi       s33, s31, #4544
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #7
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #512
    s.movz       s33, #8
    a.vread      v16, a2, s33
    s.addi       s33, s31, #4608
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #8
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #576
    s.movz       s33, #9
    a.vread      v16, a2, s33
    s.addi       s33, s31, #4672
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #9
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #640
    s.movz       s33, #10
    a.vread      v16, a2, s33
    s.addi       s33, s31, #4736
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #10
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #704
    s.movz       s33, #11
    a.vread      v16, a2, s33
    s.addi       s33, s31, #4800
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #11
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #768
    s.movz       s33, #12
    a.vread      v16, a2, s33
    s.addi       s33, s31, #4864
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #12
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #832
    s.movz       s33, #13
    a.vread      v16, a2, s33
    s.addi       s33, s31, #4928
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #13
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #896
    s.movz       s33, #14
    a.vread      v16, a2, s33
    s.addi       s33, s31, #4992
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #14
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #960
    s.movz       s30, #15
    a.vread      v16, a2, s30
    s.addi       s30, s31, #5056
    v.ld.w       v19, [s30, #0]
    v.extract    s30, v12, #15
    v.splat      v20, s30
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v29
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    fence.acq_rel.device
    s.addi       s30, s31, #13312
    s.movz       s32, #0
    a.vread      v16, a3, s32
    s.addi       s32, s31, #5120
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v12, #0
    v.splat      v20, s32
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s30, #0], v20
    s.addi       s32, s30, #64
    s.movz       s33, #1
    a.vread      v16, a3, s33
    s.addi       s33, s31, #5184
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #1
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #128
    s.movz       s33, #2
    a.vread      v16, a3, s33
    s.addi       s33, s31, #5248
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #2
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #192
    s.movz       s33, #3
    a.vread      v16, a3, s33
    s.addi       s33, s31, #5312
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #3
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #256
    s.movz       s33, #4
    a.vread      v16, a3, s33
    s.addi       s33, s31, #5376
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #4
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #320
    s.movz       s33, #5
    a.vread      v16, a3, s33
    s.addi       s33, s31, #5440
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #5
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #384
    s.movz       s33, #6
    a.vread      v16, a3, s33
    s.addi       s33, s31, #5504
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #6
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #448
    s.movz       s33, #7
    a.vread      v16, a3, s33
    s.addi       s33, s31, #5568
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #7
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #512
    s.movz       s33, #8
    a.vread      v16, a3, s33
    s.addi       s33, s31, #5632
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #8
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #576
    s.movz       s33, #9
    a.vread      v16, a3, s33
    s.addi       s33, s31, #5696
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #9
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #640
    s.movz       s33, #10
    a.vread      v16, a3, s33
    s.addi       s33, s31, #5760
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #10
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #704
    s.movz       s33, #11
    a.vread      v16, a3, s33
    s.addi       s33, s31, #5824
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #11
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #768
    s.movz       s33, #12
    a.vread      v16, a3, s33
    s.addi       s33, s31, #5888
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #12
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #832
    s.movz       s33, #13
    a.vread      v16, a3, s33
    s.addi       s33, s31, #5952
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #13
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #896
    s.movz       s33, #14
    a.vread      v16, a3, s33
    s.addi       s33, s31, #6016
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #14
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #960
    s.movz       s30, #15
    a.vread      v16, a3, s30
    s.addi       s30, s31, #6080
    v.ld.w       v19, [s30, #0]
    v.extract    s30, v12, #15
    v.splat      v20, s30
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v30
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    fence.acq_rel.device
    s.addi       s30, s31, #14336
    s.movz       s32, #0
    a.vread      v16, a4, s32
    s.addi       s32, s31, #6144
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v12, #0
    v.splat      v20, s32
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s30, #0], v20
    s.addi       s32, s30, #64
    s.movz       s33, #1
    a.vread      v16, a4, s33
    s.addi       s33, s31, #6208
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #1
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #128
    s.movz       s33, #2
    a.vread      v16, a4, s33
    s.addi       s33, s31, #6272
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #2
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #192
    s.movz       s33, #3
    a.vread      v16, a4, s33
    s.addi       s33, s31, #6336
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #3
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #256
    s.movz       s33, #4
    a.vread      v16, a4, s33
    s.addi       s33, s31, #6400
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #4
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #320
    s.movz       s33, #5
    a.vread      v16, a4, s33
    s.addi       s33, s31, #6464
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #5
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #384
    s.movz       s33, #6
    a.vread      v16, a4, s33
    s.addi       s33, s31, #6528
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #6
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #448
    s.movz       s33, #7
    a.vread      v16, a4, s33
    s.addi       s33, s31, #6592
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #7
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #512
    s.movz       s33, #8
    a.vread      v16, a4, s33
    s.addi       s33, s31, #6656
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #8
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #576
    s.movz       s33, #9
    a.vread      v16, a4, s33
    s.addi       s33, s31, #6720
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #9
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #640
    s.movz       s33, #10
    a.vread      v16, a4, s33
    s.addi       s33, s31, #6784
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #10
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #704
    s.movz       s33, #11
    a.vread      v16, a4, s33
    s.addi       s33, s31, #6848
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #11
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #768
    s.movz       s33, #12
    a.vread      v16, a4, s33
    s.addi       s33, s31, #6912
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #12
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #832
    s.movz       s33, #13
    a.vread      v16, a4, s33
    s.addi       s33, s31, #6976
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #13
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #896
    s.movz       s33, #14
    a.vread      v16, a4, s33
    s.addi       s33, s31, #7040
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #14
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #960
    s.movz       s30, #15
    a.vread      v16, a4, s30
    s.addi       s30, s31, #7104
    v.ld.w       v19, [s30, #0]
    v.extract    s30, v12, #15
    v.splat      v20, s30
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v31
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    fence.acq_rel.device
    s.addi       s30, s31, #15360
    s.movz       s32, #0
    a.vread      v16, a5, s32
    s.addi       s32, s31, #7168
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v12, #0
    v.splat      v20, s32
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s30, #0], v20
    s.addi       s32, s30, #64
    s.movz       s33, #1
    a.vread      v16, a5, s33
    s.addi       s33, s31, #7232
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #1
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #128
    s.movz       s33, #2
    a.vread      v16, a5, s33
    s.addi       s33, s31, #7296
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #2
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #192
    s.movz       s33, #3
    a.vread      v16, a5, s33
    s.addi       s33, s31, #7360
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #3
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #256
    s.movz       s33, #4
    a.vread      v16, a5, s33
    s.addi       s33, s31, #7424
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #4
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #320
    s.movz       s33, #5
    a.vread      v16, a5, s33
    s.addi       s33, s31, #7488
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #5
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #384
    s.movz       s33, #6
    a.vread      v16, a5, s33
    s.addi       s33, s31, #7552
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #6
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #448
    s.movz       s33, #7
    a.vread      v16, a5, s33
    s.addi       s33, s31, #7616
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #7
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #512
    s.movz       s33, #8
    a.vread      v16, a5, s33
    s.addi       s33, s31, #7680
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #8
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #576
    s.movz       s33, #9
    a.vread      v16, a5, s33
    s.addi       s33, s31, #7744
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #9
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #640
    s.movz       s33, #10
    a.vread      v16, a5, s33
    s.addi       s33, s31, #7808
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #10
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #704
    s.movz       s33, #11
    a.vread      v16, a5, s33
    s.addi       s33, s31, #7872
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #11
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #768
    s.movz       s33, #12
    a.vread      v16, a5, s33
    s.addi       s33, s31, #7936
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #12
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #832
    s.movz       s33, #13
    a.vread      v16, a5, s33
    s.addi       s33, s31, #8000
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #13
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #896
    s.movz       s33, #14
    a.vread      v16, a5, s33
    s.addi       s33, s31, #8064
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #14
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #960
    s.movz       s30, #15
    a.vread      v16, a5, s30
    s.addi       s30, s31, #8128
    v.ld.w       v19, [s30, #0]
    v.extract    s30, v12, #15
    v.splat      v20, s30
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v32
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    fence.acq_rel.device
    s.addi       s30, s31, #16384
    s.movz       s32, #0
    a.vread      v16, a6, s32
    s.addi       s32, s31, #8192
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v12, #0
    v.splat      v20, s32
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s30, #0], v20
    s.addi       s32, s30, #64
    s.movz       s33, #1
    a.vread      v16, a6, s33
    s.addi       s33, s31, #8256
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #1
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #128
    s.movz       s33, #2
    a.vread      v16, a6, s33
    s.addi       s33, s31, #8320
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #2
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #192
    s.movz       s33, #3
    a.vread      v16, a6, s33
    s.addi       s33, s31, #8384
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #3
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #256
    s.movz       s33, #4
    a.vread      v16, a6, s33
    s.addi       s33, s31, #8448
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #4
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #320
    s.movz       s33, #5
    a.vread      v16, a6, s33
    s.addi       s33, s31, #8512
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #5
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #384
    s.movz       s33, #6
    a.vread      v16, a6, s33
    s.addi       s33, s31, #8576
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #6
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #448
    s.movz       s33, #7
    a.vread      v16, a6, s33
    s.addi       s33, s31, #8640
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #7
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #512
    s.movz       s33, #8
    a.vread      v16, a6, s33
    s.addi       s33, s31, #8704
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #8
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #576
    s.movz       s33, #9
    a.vread      v16, a6, s33
    s.addi       s33, s31, #8768
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #9
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #640
    s.movz       s33, #10
    a.vread      v16, a6, s33
    s.addi       s33, s31, #8832
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #10
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #704
    s.movz       s33, #11
    a.vread      v16, a6, s33
    s.addi       s33, s31, #8896
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #11
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #768
    s.movz       s33, #12
    a.vread      v16, a6, s33
    s.addi       s33, s31, #8960
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #12
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #832
    s.movz       s33, #13
    a.vread      v16, a6, s33
    s.addi       s33, s31, #9024
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #13
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #896
    s.movz       s33, #14
    a.vread      v16, a6, s33
    s.addi       s33, s31, #9088
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #14
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #960
    s.movz       s30, #15
    a.vread      v16, a6, s30
    s.addi       s30, s31, #9152
    v.ld.w       v19, [s30, #0]
    v.extract    s30, v12, #15
    v.splat      v20, s30
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v33
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    fence.acq_rel.device
    s.addi       s30, s31, #17408
    s.movz       s32, #0
    a.vread      v16, a7, s32
    s.addi       s32, s31, #9216
    v.ld.w       v19, [s32, #0]
    v.extract    s32, v12, #0
    v.splat      v20, s32
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s30, #0], v20
    s.addi       s32, s30, #64
    s.movz       s33, #1
    a.vread      v16, a7, s33
    s.addi       s33, s31, #9280
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #1
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #128
    s.movz       s33, #2
    a.vread      v16, a7, s33
    s.addi       s33, s31, #9344
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #2
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #192
    s.movz       s33, #3
    a.vread      v16, a7, s33
    s.addi       s33, s31, #9408
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #3
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #256
    s.movz       s33, #4
    a.vread      v16, a7, s33
    s.addi       s33, s31, #9472
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #4
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #320
    s.movz       s33, #5
    a.vread      v16, a7, s33
    s.addi       s33, s31, #9536
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #5
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #384
    s.movz       s33, #6
    a.vread      v16, a7, s33
    s.addi       s33, s31, #9600
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #6
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #448
    s.movz       s33, #7
    a.vread      v16, a7, s33
    s.addi       s33, s31, #9664
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #7
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #512
    s.movz       s33, #8
    a.vread      v16, a7, s33
    s.addi       s33, s31, #9728
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #8
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #576
    s.movz       s33, #9
    a.vread      v16, a7, s33
    s.addi       s33, s31, #9792
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #9
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #640
    s.movz       s33, #10
    a.vread      v16, a7, s33
    s.addi       s33, s31, #9856
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #10
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #704
    s.movz       s33, #11
    a.vread      v16, a7, s33
    s.addi       s33, s31, #9920
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #11
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #768
    s.movz       s33, #12
    a.vread      v16, a7, s33
    s.addi       s33, s31, #9984
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #12
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #832
    s.movz       s33, #13
    a.vread      v16, a7, s33
    s.addi       s33, s31, #10048
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #13
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #896
    s.movz       s33, #14
    a.vread      v16, a7, s33
    s.addi       s33, s31, #10112
    v.ld.w       v19, [s33, #0]
    v.extract    s33, v12, #14
    v.splat      v20, s33
    vf.mul       v22, v19, v20
    vf.mul       v19, v22, v34
    vf.add       v20, v16, v19
    v.st.w       [s32, #0], v20
    s.addi       s32, s30, #960
    s.movz       s30, #15
    a.vread      v16, a7, s30
    s.addi       s30, s31, #10176
    v.ld.w       v19, [s30, #0]
    v.extract    s30, v12, #15
    v.splat      v12, s30
    vf.mul       v20, v19, v12
    vf.mul       v12, v20, v34
    vf.add       v19, v16, v12
    v.st.w       [s32, #0], v19
    fence.acq_rel.device
    s.addi       s30, s26, #128
    s.addi       s32, s30, #0
    s.addi       s30, s25, #128
    s.addi       s33, s30, #0
    s.mov        s26, s32
    s.mov        s25, s33
    s.movz       s30, #0
    s.addi       s32, s31, #10240
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #1
    s.addi       s32, s31, #10304
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #2
    s.addi       s32, s31, #10368
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #3
    s.addi       s32, s31, #10432
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #4
    s.addi       s32, s31, #10496
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #5
    s.addi       s32, s31, #10560
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #6
    s.addi       s32, s31, #10624
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #7
    s.addi       s32, s31, #10688
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #8
    s.addi       s32, s31, #10752
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #9
    s.addi       s32, s31, #10816
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #10
    s.addi       s32, s31, #10880
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #11
    s.addi       s32, s31, #10944
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #12
    s.addi       s32, s31, #11008
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #13
    s.addi       s32, s31, #11072
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #14
    s.addi       s32, s31, #11136
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #15
    s.addi       s32, s31, #11200
    v.ld.w       v12, [s32, #0]
    a.vwrite     a0, s30, v12
    s.movz       s30, #0
    s.addi       s32, s31, #11264
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #1
    s.addi       s32, s31, #11328
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #2
    s.addi       s32, s31, #11392
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #3
    s.addi       s32, s31, #11456
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #4
    s.addi       s32, s31, #11520
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #5
    s.addi       s32, s31, #11584
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #6
    s.addi       s32, s31, #11648
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #7
    s.addi       s32, s31, #11712
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #8
    s.addi       s32, s31, #11776
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #9
    s.addi       s32, s31, #11840
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #10
    s.addi       s32, s31, #11904
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #11
    s.addi       s32, s31, #11968
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #12
    s.addi       s32, s31, #12032
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #13
    s.addi       s32, s31, #12096
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #14
    s.addi       s32, s31, #12160
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #15
    s.addi       s32, s31, #12224
    v.ld.w       v12, [s32, #0]
    a.vwrite     a1, s30, v12
    s.movz       s30, #0
    s.addi       s32, s31, #12288
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #1
    s.addi       s32, s31, #12352
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #2
    s.addi       s32, s31, #12416
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #3
    s.addi       s32, s31, #12480
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #4
    s.addi       s32, s31, #12544
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #5
    s.addi       s32, s31, #12608
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #6
    s.addi       s32, s31, #12672
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #7
    s.addi       s32, s31, #12736
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #8
    s.addi       s32, s31, #12800
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #9
    s.addi       s32, s31, #12864
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #10
    s.addi       s32, s31, #12928
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #11
    s.addi       s32, s31, #12992
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #12
    s.addi       s32, s31, #13056
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #13
    s.addi       s32, s31, #13120
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #14
    s.addi       s32, s31, #13184
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #15
    s.addi       s32, s31, #13248
    v.ld.w       v12, [s32, #0]
    a.vwrite     a2, s30, v12
    s.movz       s30, #0
    s.addi       s32, s31, #13312
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #1
    s.addi       s32, s31, #13376
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #2
    s.addi       s32, s31, #13440
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #3
    s.addi       s32, s31, #13504
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #4
    s.addi       s32, s31, #13568
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #5
    s.addi       s32, s31, #13632
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #6
    s.addi       s32, s31, #13696
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #7
    s.addi       s32, s31, #13760
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #8
    s.addi       s32, s31, #13824
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #9
    s.addi       s32, s31, #13888
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #10
    s.addi       s32, s31, #13952
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #11
    s.addi       s32, s31, #14016
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #12
    s.addi       s32, s31, #14080
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #13
    s.addi       s32, s31, #14144
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #14
    s.addi       s32, s31, #14208
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #15
    s.addi       s32, s31, #14272
    v.ld.w       v12, [s32, #0]
    a.vwrite     a3, s30, v12
    s.movz       s30, #0
    s.addi       s32, s31, #14336
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #1
    s.addi       s32, s31, #14400
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #2
    s.addi       s32, s31, #14464
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #3
    s.addi       s32, s31, #14528
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #4
    s.addi       s32, s31, #14592
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #5
    s.addi       s32, s31, #14656
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #6
    s.addi       s32, s31, #14720
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #7
    s.addi       s32, s31, #14784
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #8
    s.addi       s32, s31, #14848
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #9
    s.addi       s32, s31, #14912
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #10
    s.addi       s32, s31, #14976
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #11
    s.addi       s32, s31, #15040
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #12
    s.addi       s32, s31, #15104
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #13
    s.addi       s32, s31, #15168
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #14
    s.addi       s32, s31, #15232
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #15
    s.addi       s32, s31, #15296
    v.ld.w       v12, [s32, #0]
    a.vwrite     a4, s30, v12
    s.movz       s30, #0
    s.addi       s32, s31, #15360
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #1
    s.addi       s32, s31, #15424
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #2
    s.addi       s32, s31, #15488
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #3
    s.addi       s32, s31, #15552
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #4
    s.addi       s32, s31, #15616
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #5
    s.addi       s32, s31, #15680
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #6
    s.addi       s32, s31, #15744
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #7
    s.addi       s32, s31, #15808
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #8
    s.addi       s32, s31, #15872
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #9
    s.addi       s32, s31, #15936
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #10
    s.addi       s32, s31, #16000
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #11
    s.addi       s32, s31, #16064
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #12
    s.addi       s32, s31, #16128
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #13
    s.addi       s32, s31, #16192
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #14
    s.addi       s32, s31, #16256
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #15
    s.addi       s32, s31, #16320
    v.ld.w       v12, [s32, #0]
    a.vwrite     a5, s30, v12
    s.movz       s30, #0
    s.addi       s32, s31, #16384
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #1
    s.addi       s32, s31, #16448
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #2
    s.addi       s32, s31, #16512
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #3
    s.addi       s32, s31, #16576
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #4
    s.addi       s32, s31, #16640
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #5
    s.addi       s32, s31, #16704
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #6
    s.addi       s32, s31, #16768
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #7
    s.addi       s32, s31, #16832
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #8
    s.addi       s32, s31, #16896
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #9
    s.addi       s32, s31, #16960
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #10
    s.addi       s32, s31, #17024
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #11
    s.addi       s32, s31, #17088
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #12
    s.addi       s32, s31, #17152
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #13
    s.addi       s32, s31, #17216
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #14
    s.addi       s32, s31, #17280
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #15
    s.addi       s32, s31, #17344
    v.ld.w       v12, [s32, #0]
    a.vwrite     a6, s30, v12
    s.movz       s30, #0
    s.addi       s32, s31, #17408
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #1
    s.addi       s32, s31, #17472
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #2
    s.addi       s32, s31, #17536
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #3
    s.addi       s32, s31, #17600
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #4
    s.addi       s32, s31, #17664
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #5
    s.addi       s32, s31, #17728
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #6
    s.addi       s32, s31, #17792
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #7
    s.addi       s32, s31, #17856
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #8
    s.addi       s32, s31, #17920
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #9
    s.addi       s32, s31, #17984
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #10
    s.addi       s32, s31, #18048
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #11
    s.addi       s32, s31, #18112
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #12
    s.addi       s32, s31, #18176
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #13
    s.addi       s32, s31, #18240
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #14
    s.addi       s32, s31, #18304
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.movz       s30, #15
    s.addi       s32, s31, #18368
    v.ld.w       v12, [s32, #0]
    a.vwrite     a7, s30, v12
    s.add        s30, s24, s21
    s.mov        s24, s30
    s.movz       s30, #1
    br.nz        s30, for_18
endfor_19:
    s.mul        s2, s1, s8
    s.movz       s4, #0
    s.movz       s5, #0
    s.add        s6, s4, s9                      // the tile origin
    s.movz       s4, #0
    s.movz       s7, #0
    s.movz       s10, #0
    s.muli       s11, s2, #2
    s.muli       s2, s9, #2
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s6
    a.vread      v2, a0, s5
    s.muli       s5, s8, #2
    s.add        s6, s4, s1                      // the tile origin
    s.add        s1, s7, s12                     // the tile origin
    s.add        s4, s10, s3                     // the tile origin
    v.splat      v3, s6
    v.splat      v4, s1
    v.add        v5, v0, v1
    v.splat      v1, s4
    vf.cvt.f32.bf16 v6, v2
    s.add        s1, s11, s2
    v.cmp.lt     p1, v3, v4
    v.cmp.lt     p2, v5, v1
    s.muli       s4, s5, #1
    s.add        s7, s13, s1
    p.and        p3, p1, p2
    s.movz       s1, #1
    @p3 v.st.h       [s7, #0], v6
    a.vread      v1, a0, s1
    s.addi       s1, s6, #1
    s.add        s7, s4, s11
    v.splat      v2, s1
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s7, s2
    v.cmp.lt     p1, v2, v4
    s.add        s4, s13, s1
    p.and        p3, p1, p2
    s.movz       s1, #2
    s.addi       s7, s9, #16
    s.addi       s8, s9, #32
    s.muli       s10, s5, #2
    @p3 v.st.h       [s4, #0], v3
    a.vread      v1, a0, s1
    s.addi       s1, s9, #48
    s.addi       s4, s9, #64
    s.add        s12, s10, s11
    vf.cvt.f32.bf16 v2, v1
    s.add        s10, s12, s2
    s.addi       s12, s9, #80
    s.add        s14, s13, s10
    s.addi       s10, s9, #96
    s.addi       s15, s6, #2
    s.addi       s16, s9, #112
    v.splat      v1, s15
    s.muli       s9, s5, #3
    s.movz       s15, #3
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    s.addi       s17, s6, #3
    @p3 v.st.h       [s14, #0], v2
    a.vread      v1, a0, s15
    s.add        s14, s9, s11
    v.splat      v2, s17
    vf.cvt.f32.bf16 v3, v1
    s.add        s9, s14, s2
    v.cmp.lt     p1, v2, v4
    s.muli       s14, s5, #4
    s.add        s15, s13, s9
    p.and        p3, p1, p2
    s.movz       s9, #4
    s.addi       s17, s6, #4
    s.add        s18, s14, s11
    v.splat      v1, s17
    @p3 v.st.h       [s15, #0], v3
    a.vread      v2, a0, s9
    s.add        s9, s18, s2
    v.cmp.lt     p1, v1, v4
    vf.cvt.f32.bf16 v1, v2
    s.muli       s14, s5, #5
    s.add        s15, s13, s9
    p.and        p3, p1, p2
    s.movz       s9, #5
    s.addi       s17, s6, #5
    s.add        s18, s14, s11
    v.splat      v2, s17
    s.add        s14, s18, s2
    s.muli       s17, s5, #6
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p1, v2, v4
    s.add        s9, s13, s14
    vf.cvt.f32.bf16 v2, v1
    p.and        p3, p1, p2
    s.movz       s14, #6
    s.addi       s15, s6, #6
    s.add        s18, s17, s11
    v.splat      v1, s15
    s.add        s15, s18, s2
    s.muli       s17, s5, #7
    v.cmp.lt     p1, v1, v4
    s.add        s18, s13, s15
    @p3 v.st.h       [s9, #0], v2
    a.vread      v1, a0, s14
    p.and        p3, p1, p2
    s.movz       s9, #7
    vf.cvt.f32.bf16 v2, v1
    s.addi       s14, s6, #7
    s.add        s15, s17, s11
    v.splat      v1, s14
    s.add        s14, s15, s2
    s.muli       s15, s5, #8
    v.cmp.lt     p1, v1, v4
    s.add        s17, s13, s14
    p.and        p4, p1, p2
    s.movz       s14, #8
    @p3 v.st.h       [s18, #0], v2
    a.vread      v1, a0, s9
    s.addi       s9, s6, #8
    s.add        s18, s15, s11
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s9
    s.add        s9, s18, s2
    s.muli       s15, s5, #9
    v.cmp.lt     p1, v1, v4
    s.add        s18, s13, s9
    p.and        p3, p1, p2
    s.movz       s9, #9
    s.addi       s19, s6, #9
    s.add        s20, s15, s11
    @p4 v.st.h       [s17, #0], v2
    a.vread      v1, a0, s14
    v.splat      v2, s19
    s.add        s14, s20, s2
    vf.cvt.f32.bf16 v3, v1
    v.cmp.lt     p1, v2, v4
    s.muli       s15, s5, #10
    s.add        s17, s13, s14
    p.and        p4, p1, p2
    s.movz       s14, #10
    s.addi       s19, s6, #10
    s.add        s20, s15, s11
    v.splat      v1, s19
    s.add        s15, s20, s2
    @p3 v.st.h       [s18, #0], v3
    a.vread      v2, a0, s9
    v.cmp.lt     p1, v1, v4
    s.muli       s9, s5, #11
    vf.cvt.f32.bf16 v1, v2
    s.add        s18, s13, s15
    p.and        p3, p1, p2
    s.movz       s15, #11
    s.addi       s19, s6, #11
    s.add        s20, s9, s11
    v.splat      v2, s19
    s.add        s9, s20, s2
    s.muli       s19, s5, #12
    s.add        s20, s13, s9
    @p4 v.st.h       [s17, #0], v1
    a.vread      v1, a0, s14
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.movz       s9, #12
    s.addi       s14, s6, #12
    s.add        s17, s19, s11
    v.splat      v1, s14
    s.add        s14, s17, s2
    s.muli       s17, s5, #13
    s.add        s19, s13, s14
    s.movz       s14, #13
    s.addi       s21, s6, #13
    @p3 v.st.h       [s18, #0], v2
    a.vread      v2, a0, s15
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s15, s17, s11
    v.splat      v2, s21
    s.add        s17, s15, s2
    s.muli       s15, s5, #14
    s.add        s18, s13, s17
    s.movz       s17, #14
    s.addi       s21, s6, #14
    s.add        s22, s15, s11
    @p4 v.st.h       [s20, #0], v1
    a.vread      v1, a0, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s21
    s.add        s9, s22, s2
    s.muli       s15, s5, #15
    s.add        s20, s13, s9
    s.movz       s9, #15
    s.addi       s21, s6, #15
    v.splat      v3, s6
    s.add        s22, s15, s11
    v.splat      v5, s21
    @p3 v.st.h       [s19, #0], v2
    a.vread      v2, a0, s14
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.movz       s14, #0
    s.add        s15, s22, s2
    s.add        s2, s14, s7                     // the tile origin
    s.add        s14, s13, s15
    s.movz       s15, #0
    s.movz       s19, #0
    s.muli       s21, s7, #2
    v.splat      v2, s2
    s.add        s2, s19, s3                     // the tile origin
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a0, s17
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v5, v1
    v.add        v1, v0, v2
    v.splat      v2, s2
    s.add        s2, s11, s21
    v.cmp.lt     p1, v3, v4
    s.muli       s7, s5, #1
    s.add        s17, s13, s2
    s.movz       s2, #1
    s.addi       s18, s6, #1
    s.muli       s19, s5, #2
    @p3 v.st.h       [s20, #0], v5
    a.vread      v3, a0, s9
    v.cmp.lt     p2, v1, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s9, s7, s11
    v.splat      v2, s18
    s.add        s7, s9, s21
    s.movz       s9, #2
    s.add        s18, s13, s7
    s.addi       s7, s6, #2
    s.add        s20, s19, s11
    v.splat      v3, s7
    s.add        s7, s20, s21
    @p4 v.st.h       [s14, #0], v1
    a.vread      v1, a1, s15
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.muli       s14, s5, #3
    s.add        s15, s13, s7
    s.movz       s7, #3
    s.addi       s19, s6, #3
    s.muli       s20, s5, #4
    s.add        s22, s14, s11
    v.splat      v1, s19
    s.add        s14, s22, s21
    s.movz       s19, #4
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a1, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s2, s13, s14
    s.addi       s14, s6, #4
    s.add        s17, s20, s11
    v.splat      v2, s14
    s.add        s14, s17, s21
    s.muli       s17, s5, #5
    s.add        s20, s13, s14
    s.movz       s14, #5
    @p4 v.st.h       [s18, #0], v3
    a.vread      v3, a1, s9
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s9, s6, #5
    s.add        s18, s17, s11
    v.splat      v3, s9
    s.add        s9, s18, s21
    s.muli       s17, s5, #6
    s.add        s18, s13, s9
    s.movz       s9, #6
    @p3 v.st.h       [s15, #0], v1
    a.vread      v1, a1, s7
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s7, s6, #6
    s.add        s15, s17, s11
    v.splat      v1, s7
    s.add        s7, s15, s21
    s.muli       s15, s5, #7
    s.add        s17, s13, s7
    s.movz       s7, #7
    @p4 v.st.h       [s2, #0], v2
    a.vread      v2, a1, s19
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s2, s6, #7
    s.add        s19, s15, s11
    v.splat      v2, s2
    s.add        s2, s19, s21
    s.muli       s15, s5, #8
    s.add        s19, s13, s2
    s.movz       s2, #8
    @p3 v.st.h       [s20, #0], v3
    a.vread      v3, a1, s14
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s14, s6, #8
    s.add        s20, s15, s11
    v.splat      v3, s14
    s.add        s14, s20, s21
    s.muli       s15, s5, #9
    s.add        s20, s13, s14
    s.movz       s14, #9
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a1, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s9, s6, #9
    s.add        s18, s15, s11
    v.splat      v1, s9
    s.add        s9, s18, s21
    s.muli       s15, s5, #10
    s.add        s18, s13, s9
    s.movz       s9, #10
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a1, s7
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s7, s6, #10
    s.add        s17, s15, s11
    v.splat      v2, s7
    s.add        s7, s17, s21
    s.muli       s15, s5, #11
    s.add        s17, s13, s7
    s.movz       s7, #11
    @p4 v.st.h       [s19, #0], v3
    a.vread      v3, a1, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s2, s6, #11
    s.add        s19, s15, s11
    v.splat      v3, s2
    s.add        s2, s19, s21
    s.muli       s15, s5, #12
    s.add        s19, s13, s2
    s.movz       s2, #12
    @p3 v.st.h       [s20, #0], v1
    a.vread      v1, a1, s14
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s14, s6, #12
    s.add        s20, s15, s11
    v.splat      v1, s14
    s.add        s14, s20, s21
    s.muli       s15, s5, #13
    s.add        s20, s13, s14
    s.movz       s14, #13
    @p4 v.st.h       [s18, #0], v2
    a.vread      v2, a1, s9
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s9, s6, #13
    s.add        s18, s15, s11
    v.splat      v2, s9
    s.add        s9, s18, s21
    s.muli       s15, s5, #14
    s.add        s18, s13, s9
    s.movz       s9, #14
    @p3 v.st.h       [s17, #0], v3
    a.vread      v3, a1, s7
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.addi       s7, s6, #14
    s.add        s17, s15, s11
    v.splat      v3, s7
    s.add        s7, s17, s21
    s.muli       s15, s5, #15
    s.add        s17, s13, s7
    s.movz       s7, #15
    @p4 v.st.h       [s19, #0], v1
    a.vread      v1, a1, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s2, s6, #15
    s.add        s19, s15, s11
    v.splat      v1, s2
    s.movz       s2, #0
    s.add        s15, s19, s21
    s.add        s19, s2, s8                     // the tile origin
    s.add        s2, s13, s15
    s.movz       s15, #0
    s.muli       s21, s8, #2
    @p3 v.st.h       [s20, #0], v2
    a.vread      v2, a1, s14
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.movz       s8, #0
    v.splat      v2, s19
    s.add        s14, s8, s3                     // the tile origin
    v.splat      v5, s6
    v.add        v6, v0, v2
    v.splat      v2, s14
    s.add        s8, s11, s21
    s.muli       s14, s5, #1
    s.add        s19, s13, s8
    @p4 v.st.h       [s18, #0], v3
    a.vread      v3, a1, s9
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    v.cmp.lt     p1, v5, v4
    s.movz       s8, #1
    s.addi       s9, s6, #1
    s.add        s18, s14, s11
    v.splat      v3, s9
    s.add        s9, s18, s21
    s.muli       s14, s5, #2
    s.add        s18, s13, s9
    s.movz       s9, #2
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a1, s7
    v.cmp.lt     p2, v6, v2
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s7, s6, #2
    s.add        s17, s14, s11
    v.splat      v1, s7
    s.add        s7, s17, s21
    s.muli       s14, s5, #3
    s.add        s17, s13, s7
    s.movz       s7, #3
    @p4 v.st.h       [s2, #0], v2
    a.vread      v2, a2, s15
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s2, s6, #3
    s.add        s15, s14, s11
    v.splat      v2, s2
    s.add        s2, s15, s21
    s.muli       s14, s5, #4
    s.add        s15, s13, s2
    s.movz       s2, #4
    s.addi       s20, s6, #4
    @p3 v.st.h       [s19, #0], v3
    a.vread      v3, a2, s8
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s8, s14, s11
    v.splat      v3, s20
    s.add        s14, s8, s21
    s.muli       s8, s5, #5
    s.add        s19, s13, s14
    s.movz       s14, #5
    s.addi       s20, s6, #5
    s.add        s22, s8, s11
    @p4 v.st.h       [s18, #0], v1
    a.vread      v1, a2, s9
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s20
    s.add        s8, s22, s21
    s.muli       s9, s5, #6
    s.add        s18, s13, s8
    s.movz       s8, #6
    s.addi       s20, s6, #6
    s.add        s22, s9, s11
    v.splat      v5, s20
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s7
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s7, s22, s21
    s.muli       s9, s5, #7
    s.add        s17, s13, s7
    s.movz       s7, #7
    s.addi       s20, s6, #7
    s.add        s22, s9, s11
    v.splat      v2, s20
    s.add        s9, s22, s21
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a2, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s5, #8
    s.add        s15, s13, s9
    s.movz       s9, #8
    s.addi       s20, s6, #8
    s.add        s22, s2, s11
    v.splat      v3, s20
    s.add        s2, s22, s21
    @p3 v.st.h       [s19, #0], v1
    a.vread      v1, a2, s14
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s14, s5, #9
    s.add        s19, s13, s2
    s.movz       s2, #9
    s.addi       s20, s6, #9
    s.add        s22, s14, s11
    v.splat      v1, s20
    s.add        s14, s22, s21
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a2, s8
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s8, s5, #10
    s.add        s18, s13, s14
    s.movz       s14, #10
    s.addi       s20, s6, #10
    s.add        s22, s8, s11
    v.splat      v5, s20
    s.add        s8, s22, s21
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s7
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s7, s5, #11
    s.add        s17, s13, s8
    s.movz       s8, #11
    s.addi       s20, s6, #11
    s.add        s22, s7, s11
    v.splat      v2, s20
    s.add        s7, s22, s21
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a2, s9
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s9, s5, #12
    s.add        s15, s13, s7
    s.movz       s7, #12
    s.addi       s20, s6, #12
    s.add        s22, s9, s11
    v.splat      v3, s20
    s.add        s9, s22, s21
    @p3 v.st.h       [s19, #0], v1
    a.vread      v1, a2, s2
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s2, s5, #13
    s.add        s19, s13, s9
    s.movz       s9, #13
    s.addi       s20, s6, #13
    s.add        s22, s2, s11
    v.splat      v1, s20
    s.add        s2, s22, s21
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a2, s14
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s14, s5, #14
    s.add        s18, s13, s2
    s.movz       s2, #14
    s.addi       s20, s6, #14
    s.add        s22, s14, s11
    v.splat      v5, s20
    s.add        s14, s22, s21
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s8
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s8, s5, #15
    s.add        s17, s13, s14
    s.movz       s14, #15
    s.addi       s20, s6, #15
    s.add        s22, s8, s11
    v.splat      v2, s20
    s.add        s8, s22, s21
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a2, s7
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.movz       s7, #0
    s.add        s15, s13, s8
    s.add        s8, s7, s1                      // the tile origin
    s.movz       s7, #0
    s.muli       s20, s1, #2
    v.splat      v3, s8
    v.splat      v6, s6
    @p3 v.st.h       [s19, #0], v1
    a.vread      v1, a2, s9
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.movz       s1, #0
    v.add        v1, v0, v3
    s.add        s8, s1, s3                      // the tile origin
    s.add        s1, s11, s20
    v.splat      v3, s8
    s.muli       s8, s5, #1
    s.add        s9, s13, s1
    s.movz       s1, #1
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a2, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    v.cmp.lt     p1, v6, v4
    s.addi       s2, s6, #1
    s.add        s18, s8, s11
    v.splat      v5, s2
    s.add        s2, s18, s20
    s.muli       s8, s5, #2
    s.add        s18, s13, s2
    s.movz       s2, #2
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a2, s14
    v.cmp.lt     p2, v1, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s14, s6, #2
    s.add        s17, s8, s11
    v.splat      v2, s14
    s.add        s8, s17, s20
    s.muli       s14, s5, #3
    s.add        s17, s13, s8
    s.movz       s8, #3
    @p4 v.st.h       [s15, #0], v1
    a.vread      v1, a3, s7
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s7, s6, #3
    s.add        s15, s14, s11
    v.splat      v1, s7
    s.add        s7, s15, s20
    s.muli       s14, s5, #4
    s.add        s15, s13, s7
    s.movz       s7, #4
    s.addi       s19, s6, #4
    @p3 v.st.h       [s9, #0], v3
    a.vread      v3, a3, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.add        s1, s14, s11
    v.splat      v3, s19
    s.add        s9, s1, s20
    s.muli       s1, s5, #5
    s.add        s14, s13, s9
    s.movz       s9, #5
    s.addi       s19, s6, #5
    s.add        s21, s1, s11
    @p4 v.st.h       [s18, #0], v2
    a.vread      v2, a3, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.splat      v2, s19
    s.add        s1, s21, s20
    s.muli       s2, s5, #6
    s.add        s18, s13, s1
    s.movz       s1, #6
    s.addi       s19, s6, #6
    s.add        s21, s2, s11
    v.splat      v5, s19
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s8
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s2, s21, s20
    s.muli       s8, s5, #7
    s.add        s17, s13, s2
    s.movz       s2, #7
    s.addi       s19, s6, #7
    s.add        s21, s8, s11
    v.splat      v1, s19
    s.add        s8, s21, s20
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a3, s7
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s7, s5, #8
    s.add        s15, s13, s8
    s.movz       s8, #8
    s.addi       s19, s6, #8
    s.add        s21, s7, s11
    v.splat      v3, s19
    s.add        s7, s21, s20
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a3, s9
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s9, s5, #9
    s.add        s14, s13, s7
    s.movz       s7, #9
    s.addi       s19, s6, #9
    s.add        s21, s9, s11
    v.splat      v2, s19
    s.add        s9, s21, s20
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a3, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s1, s5, #10
    s.add        s18, s13, s9
    s.movz       s9, #10
    s.addi       s19, s6, #10
    s.add        s21, s1, s11
    v.splat      v5, s19
    s.add        s1, s21, s20
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s2, s5, #11
    s.add        s17, s13, s1
    s.movz       s1, #11
    s.addi       s19, s6, #11
    s.add        s21, s2, s11
    v.splat      v1, s19
    s.add        s2, s21, s20
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a3, s8
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s8, s5, #12
    s.add        s15, s13, s2
    s.movz       s2, #12
    s.addi       s19, s6, #12
    s.add        s21, s8, s11
    v.splat      v3, s19
    s.add        s8, s21, s20
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a3, s7
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s7, s5, #13
    s.add        s14, s13, s8
    s.movz       s8, #13
    s.addi       s19, s6, #13
    s.add        s21, s7, s11
    v.splat      v2, s19
    s.add        s7, s21, s20
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a3, s9
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s9, s5, #14
    s.add        s18, s13, s7
    s.movz       s7, #14
    s.addi       s19, s6, #14
    s.add        s21, s9, s11
    v.splat      v5, s19
    s.add        s9, s21, s20
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s1, s5, #15
    s.add        s17, s13, s9
    s.movz       s9, #15
    s.addi       s19, s6, #15
    s.add        s21, s1, s11
    v.splat      v1, s19
    s.add        s1, s21, s20
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a3, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.movz       s2, #0
    s.add        s15, s13, s1
    s.add        s1, s2, s4                      // the tile origin
    s.movz       s2, #0
    s.muli       s19, s4, #2
    v.splat      v3, s1
    v.splat      v6, s6
    @p3 v.st.h       [s14, #0], v2
    a.vread      v2, a3, s8
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.movz       s1, #0
    v.add        v2, v0, v3
    s.add        s4, s1, s3                      // the tile origin
    s.add        s1, s11, s19
    v.splat      v3, s4
    s.muli       s4, s5, #1
    s.add        s8, s13, s1
    s.movz       s1, #1
    @p4 v.st.h       [s18, #0], v5
    a.vread      v5, a3, s7
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    v.cmp.lt     p1, v6, v4
    s.addi       s7, s6, #1
    s.add        s14, s4, s11
    v.splat      v5, s7
    s.add        s4, s14, s19
    s.muli       s7, s5, #2
    s.add        s14, s13, s4
    s.movz       s4, #2
    @p3 v.st.h       [s17, #0], v1
    a.vread      v1, a3, s9
    v.cmp.lt     p2, v2, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s9, s6, #2
    s.add        s17, s7, s11
    v.splat      v1, s9
    s.add        s7, s17, s19
    s.muli       s9, s5, #3
    s.add        s17, s13, s7
    s.movz       s7, #3
    @p4 v.st.h       [s15, #0], v2
    a.vread      v2, a4, s2
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s2, s6, #3
    s.add        s15, s9, s11
    v.splat      v2, s2
    s.add        s2, s15, s19
    s.muli       s9, s5, #4
    s.add        s15, s13, s2
    s.movz       s2, #4
    s.addi       s18, s6, #4
    @p3 v.st.h       [s8, #0], v3
    a.vread      v3, a4, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s1, s9, s11
    v.splat      v3, s18
    s.add        s8, s1, s19
    s.muli       s1, s5, #5
    s.add        s9, s13, s8
    s.movz       s8, #5
    s.addi       s18, s6, #5
    s.add        s20, s1, s11
    @p4 v.st.h       [s14, #0], v1
    a.vread      v1, a4, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s18
    s.add        s1, s20, s19
    s.muli       s4, s5, #6
    s.add        s14, s13, s1
    s.movz       s1, #6
    s.addi       s18, s6, #6
    s.add        s20, s4, s11
    v.splat      v5, s18
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s7
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s4, s20, s19
    s.muli       s7, s5, #7
    s.add        s17, s13, s4
    s.movz       s4, #7
    s.addi       s18, s6, #7
    s.add        s20, s7, s11
    v.splat      v2, s18
    s.add        s7, s20, s19
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a4, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s5, #8
    s.add        s15, s13, s7
    s.movz       s7, #8
    s.addi       s18, s6, #8
    s.add        s20, s2, s11
    v.splat      v3, s18
    s.add        s2, s20, s19
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a4, s8
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s8, s5, #9
    s.add        s9, s13, s2
    s.movz       s2, #9
    s.addi       s18, s6, #9
    s.add        s20, s8, s11
    v.splat      v1, s18
    s.add        s8, s20, s19
    @p4 v.st.h       [s14, #0], v5
    a.vread      v5, a4, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s1, s5, #10
    s.add        s14, s13, s8
    s.movz       s8, #10
    s.addi       s18, s6, #10
    s.add        s20, s1, s11
    v.splat      v5, s18
    s.add        s1, s20, s19
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s4, s5, #11
    s.add        s17, s13, s1
    s.movz       s1, #11
    s.addi       s18, s6, #11
    s.add        s20, s4, s11
    v.splat      v2, s18
    s.add        s4, s20, s19
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a4, s7
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s7, s5, #12
    s.add        s15, s13, s4
    s.movz       s4, #12
    s.addi       s18, s6, #12
    s.add        s20, s7, s11
    v.splat      v3, s18
    s.add        s7, s20, s19
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a4, s2
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s2, s5, #13
    s.add        s9, s13, s7
    s.movz       s7, #13
    s.addi       s18, s6, #13
    s.add        s20, s2, s11
    v.splat      v1, s18
    s.add        s2, s20, s19
    @p4 v.st.h       [s14, #0], v5
    a.vread      v5, a4, s8
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s8, s5, #14
    s.add        s14, s13, s2
    s.movz       s2, #14
    s.addi       s18, s6, #14
    s.add        s20, s8, s11
    v.splat      v5, s18
    s.add        s8, s20, s19
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s1, s5, #15
    s.add        s17, s13, s8
    s.movz       s8, #15
    s.addi       s18, s6, #15
    s.add        s20, s1, s11
    v.splat      v2, s18
    s.add        s1, s20, s19
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a4, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.movz       s4, #0
    s.add        s15, s13, s1
    s.add        s1, s4, s12                     // the tile origin
    s.movz       s4, #0
    s.muli       s18, s12, #2
    v.splat      v3, s1
    v.splat      v6, s6
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a4, s7
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.movz       s1, #0
    v.add        v1, v0, v3
    s.add        s7, s1, s3                      // the tile origin
    s.add        s1, s11, s18
    v.splat      v3, s7
    s.muli       s7, s5, #1
    s.add        s9, s13, s1
    s.movz       s1, #1
    @p4 v.st.h       [s14, #0], v5
    a.vread      v5, a4, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    v.cmp.lt     p1, v6, v4
    s.addi       s2, s6, #1
    s.add        s12, s7, s11
    v.splat      v5, s2
    s.add        s2, s12, s18
    s.muli       s7, s5, #2
    s.add        s12, s13, s2
    s.movz       s2, #2
    @p3 v.st.h       [s17, #0], v2
    a.vread      v2, a4, s8
    v.cmp.lt     p2, v1, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.addi       s8, s6, #2
    s.add        s14, s7, s11
    v.splat      v2, s8
    s.add        s7, s14, s18
    s.muli       s8, s5, #3
    s.add        s14, s13, s7
    s.movz       s7, #3
    @p4 v.st.h       [s15, #0], v1
    a.vread      v1, a5, s4
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.addi       s4, s6, #3
    s.add        s15, s8, s11
    v.splat      v1, s4
    s.add        s4, s15, s18
    s.muli       s8, s5, #4
    s.add        s15, s13, s4
    s.movz       s4, #4
    s.addi       s17, s6, #4
    @p3 v.st.h       [s9, #0], v3
    a.vread      v3, a5, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.add        s1, s8, s11
    v.splat      v3, s17
    s.add        s8, s1, s18
    s.muli       s1, s5, #5
    s.add        s9, s13, s8
    s.movz       s8, #5
    s.addi       s17, s6, #5
    s.add        s19, s1, s11
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a5, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    v.splat      v2, s17
    s.add        s1, s19, s18
    s.muli       s2, s5, #6
    s.add        s12, s13, s1
    s.movz       s1, #6
    s.addi       s17, s6, #6
    s.add        s19, s2, s11
    v.splat      v5, s17
    @p3 v.st.h       [s14, #0], v1
    a.vread      v1, a5, s7
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.add        s2, s19, s18
    s.muli       s7, s5, #7
    s.add        s14, s13, s2
    s.movz       s2, #7
    s.addi       s17, s6, #7
    s.add        s19, s7, s11
    v.splat      v1, s17
    s.add        s7, s19, s18
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a5, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s4, s5, #8
    s.add        s15, s13, s7
    s.movz       s7, #8
    s.addi       s17, s6, #8
    s.add        s19, s4, s11
    v.splat      v3, s17
    s.add        s4, s19, s18
    @p3 v.st.h       [s9, #0], v2
    a.vread      v2, a5, s8
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s8, s5, #9
    s.add        s9, s13, s4
    s.movz       s4, #9
    s.addi       s17, s6, #9
    s.add        s19, s8, s11
    v.splat      v2, s17
    s.add        s8, s19, s18
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a5, s1
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s1, s5, #10
    s.add        s12, s13, s8
    s.movz       s8, #10
    s.addi       s17, s6, #10
    s.add        s19, s1, s11
    v.splat      v5, s17
    s.add        s1, s19, s18
    @p3 v.st.h       [s14, #0], v1
    a.vread      v1, a5, s2
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s2, s5, #11
    s.add        s14, s13, s1
    s.movz       s1, #11
    s.addi       s17, s6, #11
    s.add        s19, s2, s11
    v.splat      v1, s17
    s.add        s2, s19, s18
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a5, s7
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.muli       s7, s5, #12
    s.add        s15, s13, s2
    s.movz       s2, #12
    s.addi       s17, s6, #12
    s.add        s19, s7, s11
    v.splat      v3, s17
    s.add        s7, s19, s18
    @p3 v.st.h       [s9, #0], v2
    a.vread      v2, a5, s4
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.muli       s4, s5, #13
    s.add        s9, s13, s7
    s.movz       s7, #13
    s.addi       s17, s6, #13
    s.add        s19, s4, s11
    v.splat      v2, s17
    s.add        s4, s19, s18
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a5, s8
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    s.muli       s8, s5, #14
    s.add        s12, s13, s4
    s.movz       s4, #14
    s.addi       s17, s6, #14
    s.add        s19, s8, s11
    v.splat      v5, s17
    s.add        s8, s19, s18
    @p3 v.st.h       [s14, #0], v1
    a.vread      v1, a5, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s1, s5, #15
    s.add        s14, s13, s8
    s.movz       s8, #15
    s.addi       s17, s6, #15
    s.add        s19, s1, s11
    v.splat      v1, s17
    s.add        s1, s19, s18
    @p4 v.st.h       [s15, #0], v3
    a.vread      v3, a5, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    s.movz       s2, #0
    s.add        s15, s13, s1
    s.add        s1, s2, s10                     // the tile origin
    s.movz       s2, #0
    s.muli       s17, s10, #2
    v.splat      v3, s1
    v.splat      v6, s6
    @p3 v.st.h       [s9, #0], v2
    a.vread      v2, a5, s7
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v2
    s.movz       s1, #0
    v.add        v2, v0, v3
    s.add        s7, s1, s3                      // the tile origin
    s.add        s1, s11, s17
    v.splat      v3, s7
    s.muli       s7, s5, #1
    s.add        s9, s13, s1
    s.movz       s1, #1
    @p4 v.st.h       [s12, #0], v5
    a.vread      v5, a5, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v5
    v.cmp.lt     p1, v6, v4
    s.addi       s4, s6, #1
    s.add        s10, s7, s11
    v.splat      v5, s4
    s.add        s4, s10, s17
    s.muli       s7, s5, #2
    s.add        s10, s13, s4
    s.movz       s4, #2
    @p3 v.st.h       [s14, #0], v1
    a.vread      v1, a5, s8
    v.cmp.lt     p2, v2, v3
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    s.addi       s8, s6, #2
    s.add        s12, s7, s11
    v.splat      v1, s8
    s.add        s7, s12, s17
    s.muli       s8, s5, #3
    s.add        s12, s13, s7
    s.movz       s7, #3
    @p4 v.st.h       [s15, #0], v2
    a.vread      v2, a6, s2
    v.cmp.lt     p1, v5, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.addi       s2, s6, #3
    s.add        s14, s8, s11
    v.splat      v2, s2
    s.add        s2, s14, s17
    s.muli       s8, s5, #4
    s.add        s14, s13, s2
    s.movz       s2, #4
    s.addi       s15, s6, #4
    @p3 v.st.h       [s9, #0], v3
    a.vread      v3, a6, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.add        s1, s8, s11
    v.splat      v3, s15
    s.add        s8, s1, s17
    s.muli       s1, s5, #5
    s.add        s9, s13, s8
    s.movz       s8, #5
    s.addi       s15, s6, #5
    s.add        s18, s1, s11
    @p4 v.st.h       [s10, #0], v1
    a.vread      v1, a6, s4
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v1
    v.splat      v1, s15
    s.add        s1, s18, s17
    s.muli       s4, s5, #6
    s.add        s10, s13, s1
    s.movz       s1, #6
    s.addi       s15, s6, #6
    s.add        s18, s4, s11
    v.splat      v5, s15
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a6, s7
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.add        s4, s18, s17
    s.muli       s7, s5, #7
    s.add        s12, s13, s4
    s.movz       s4, #7
    s.addi       s15, s6, #7
    s.add        s18, s7, s11
    v.splat      v2, s15
    s.add        s7, s18, s17
    @p4 v.st.h       [s14, #0], v3
    a.vread      v3, a6, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s2, s5, #8
    s.add        s14, s13, s7
    s.movz       s7, #8
    s.addi       s15, s6, #8
    s.add        s18, s2, s11
    v.splat      v3, s15
    s.add        s2, s18, s17
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a6, s8
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s8, s5, #9
    s.add        s9, s13, s2
    s.movz       s2, #9
    s.addi       s15, s6, #9
    s.add        s18, s8, s11
    v.splat      v1, s15
    s.add        s8, s18, s17
    @p4 v.st.h       [s10, #0], v5
    a.vread      v5, a6, s1
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s1, s5, #10
    s.add        s10, s13, s8
    s.movz       s8, #10
    s.addi       s15, s6, #10
    s.add        s18, s1, s11
    v.splat      v5, s15
    s.add        s1, s18, s17
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a6, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s4, s5, #11
    s.add        s12, s13, s1
    s.movz       s1, #11
    s.addi       s15, s6, #11
    s.add        s18, s4, s11
    v.splat      v2, s15
    s.add        s4, s18, s17
    @p4 v.st.h       [s14, #0], v3
    a.vread      v3, a6, s7
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.muli       s7, s5, #12
    s.add        s14, s13, s4
    s.movz       s4, #12
    s.addi       s15, s6, #12
    s.add        s18, s7, s11
    v.splat      v3, s15
    s.add        s7, s18, s17
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a6, s2
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.muli       s2, s5, #13
    s.add        s9, s13, s7
    s.movz       s7, #13
    s.addi       s15, s6, #13
    s.add        s18, s2, s11
    v.splat      v1, s15
    s.add        s2, s18, s17
    @p4 v.st.h       [s10, #0], v5
    a.vread      v5, a6, s8
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v5
    s.muli       s8, s5, #14
    s.add        s10, s13, s2
    s.movz       s2, #14
    s.addi       s15, s6, #14
    s.add        s18, s8, s11
    v.splat      v5, s15
    s.add        s8, s18, s17
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a6, s1
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v2
    s.muli       s1, s5, #15
    s.add        s12, s13, s8
    s.movz       s8, #15
    s.addi       s15, s6, #15
    s.add        s18, s1, s11
    v.splat      v2, s15
    s.add        s1, s18, s17
    @p4 v.st.h       [s14, #0], v3
    a.vread      v3, a6, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v3
    s.movz       s4, #0
    s.add        s14, s13, s1
    s.add        s1, s4, s16                     // the tile origin
    s.movz       s4, #0
    s.muli       s15, s16, #2
    v.splat      v3, s1
    v.splat      v6, s6
    @p3 v.st.h       [s9, #0], v1
    a.vread      v1, a6, s7
    v.cmp.lt     p1, v5, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v5, v1
    s.movz       s1, #0
    v.add        v1, v0, v3
    s.add        s7, s1, s3                      // the tile origin
    s.add        s1, s11, s15
    v.splat      v0, s7
    s.muli       s3, s5, #1
    s.add        s7, s13, s1
    s.movz       s1, #1
    @p4 v.st.h       [s10, #0], v5
    a.vread      v3, a6, s2
    v.cmp.lt     p1, v2, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v3
    v.cmp.lt     p1, v6, v4
    s.addi       s2, s6, #1
    s.add        s9, s3, s11
    v.splat      v3, s2
    s.add        s2, s9, s15
    s.muli       s3, s5, #2
    s.add        s9, s13, s2
    s.movz       s2, #2
    @p3 v.st.h       [s12, #0], v2
    a.vread      v2, a6, s8
    v.cmp.lt     p2, v1, v0
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v0, v2
    s.addi       s8, s6, #2
    s.add        s10, s3, s11
    v.splat      v1, s8
    s.add        s3, s10, s15
    s.muli       s8, s5, #3
    s.add        s10, s13, s3
    s.movz       s3, #3
    @p4 v.st.h       [s14, #0], v0
    a.vread      v0, a7, s4
    v.cmp.lt     p1, v3, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.addi       s4, s6, #3
    s.add        s12, s8, s11
    v.splat      v0, s4
    s.add        s4, s12, s15
    s.muli       s8, s5, #4
    s.add        s12, s13, s4
    s.movz       s4, #4
    s.addi       s14, s6, #4
    @p3 v.st.h       [s7, #0], v2
    a.vread      v2, a7, s1
    v.cmp.lt     p1, v1, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s1, s8, s11
    v.splat      v2, s14
    s.add        s7, s1, s15
    s.muli       s1, s5, #5
    s.add        s8, s13, s7
    s.movz       s7, #5
    s.addi       s14, s6, #5
    s.add        s16, s1, s11
    @p4 v.st.h       [s9, #0], v1
    a.vread      v1, a7, s2
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    v.splat      v1, s14
    s.add        s1, s16, s15
    s.muli       s2, s5, #6
    s.add        s9, s13, s1
    s.movz       s1, #6
    s.addi       s14, s6, #6
    s.add        s16, s2, s11
    v.splat      v3, s14
    @p3 v.st.h       [s10, #0], v0
    a.vread      v0, a7, s3
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.add        s2, s16, s15
    s.muli       s3, s5, #7
    s.add        s10, s13, s2
    s.movz       s2, #7
    s.addi       s14, s6, #7
    s.add        s16, s3, s11
    v.splat      v0, s14
    s.add        s3, s16, s15
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a7, s4
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s4, s5, #8
    s.add        s12, s13, s3
    s.movz       s3, #8
    s.addi       s14, s6, #8
    s.add        s16, s4, s11
    v.splat      v2, s14
    s.add        s4, s16, s15
    @p3 v.st.h       [s8, #0], v1
    a.vread      v1, a7, s7
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s7, s5, #9
    s.add        s8, s13, s4
    s.movz       s4, #9
    s.addi       s14, s6, #9
    s.add        s16, s7, s11
    v.splat      v1, s14
    s.add        s7, s16, s15
    @p4 v.st.h       [s9, #0], v3
    a.vread      v3, a7, s1
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v3
    s.muli       s1, s5, #10
    s.add        s9, s13, s7
    s.movz       s7, #10
    s.addi       s14, s6, #10
    s.add        s16, s1, s11
    v.splat      v3, s14
    s.add        s1, s16, s15
    @p3 v.st.h       [s10, #0], v0
    a.vread      v0, a7, s2
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s2, s5, #11
    s.add        s10, s13, s1
    s.movz       s1, #11
    s.addi       s14, s6, #11
    s.add        s16, s2, s11
    v.splat      v0, s14
    s.add        s2, s16, s15
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a7, s3
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.muli       s3, s5, #12
    s.add        s12, s13, s2
    s.movz       s2, #12
    s.addi       s14, s6, #12
    s.add        s16, s3, s11
    v.splat      v2, s14
    s.add        s3, s16, s15
    @p3 v.st.h       [s8, #0], v1
    a.vread      v1, a7, s4
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v3, v1
    s.muli       s4, s5, #13
    s.add        s8, s13, s3
    s.movz       s3, #13
    s.addi       s14, s6, #13
    s.add        s16, s4, s11
    v.splat      v1, s14
    s.add        s4, s16, s15
    @p4 v.st.h       [s9, #0], v3
    a.vread      v3, a7, s7
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v3
    s.muli       s7, s5, #14
    s.add        s9, s13, s4
    s.movz       s4, #14
    s.addi       s14, s6, #14
    s.add        s16, s7, s11
    v.splat      v3, s14
    s.add        s7, s16, s15
    @p3 v.st.h       [s10, #0], v0
    a.vread      v0, a7, s1
    v.cmp.lt     p1, v2, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v0
    s.muli       s1, s5, #15
    s.add        s5, s13, s7
    s.movz       s7, #15
    s.addi       s10, s6, #15
    s.add        s6, s1, s11
    v.splat      v0, s10
    s.add        s1, s6, s15
    @p4 v.st.h       [s12, #0], v2
    a.vread      v2, a7, s2
    v.cmp.lt     p1, v1, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v1, v2
    s.add        s2, s13, s1
    @p3 v.st.h       [s8, #0], v1
    a.vread      v1, a7, s3
    v.cmp.lt     p1, v3, v4
    p.and        p3, p1, p2
    vf.cvt.f32.bf16 v2, v1
    @p4 v.st.h       [s9, #0], v2
    a.vread      v1, a7, s4
    v.cmp.lt     p1, v0, v4
    p.and        p4, p1, p2
    vf.cvt.f32.bf16 v0, v1
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a7, s7
    vf.cvt.f32.bf16 v1, v0
    @p4 v.st.h       [s2, #0], v1
    exit
    exit
