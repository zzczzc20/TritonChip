.li s5, #0x10020
mb.wait s5
exit
