    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    v.movi       v0, #0
    s.ld.d       s2, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.movi       v1, #0
    s.movz       s3, #16
    s.ld.d       s5, [s2, #0]                    // one element, not a vector
    s.mul        s2, s4, s3
    v.iota       v2                              // arange(0, VLEN)
    s.lshri      s3, s5, #32
    s.ld.d       s4, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    s.lshri      s6, s5, #32
    v.splat      v3, s2
    s.ld.d       s7, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.lshri      s8, s5, #32
    v.add        v4, v3, v2
    s.ld.d       s9, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    v.movi       v2, #0
    v.movi       v3, #0
    s.ld.d       s10, [s1, #32]                  // in_ptr4: device_ptr64 at arg_base+32
    v.sub        v5, v2, v4
    v.sub        v6, v3, v4
    s.ld.d       s11, [s1, #40]                  // in_ptr5: device_ptr64 at arg_base+40
    s.lshri      s12, s5, #32
    v.cmp.lt     p1, v4, v2
    s.ld.d       s13, [s1, #48]                  // in_ptr6: device_ptr64 at arg_base+48
    v.cmp.lt     p2, v4, v3
    @p1 v.sel        v7, v5, v4
    s.ld.d       s14, [s1, #56]                  // out_ptr0: device_ptr64 at arg_base+56
    v.insert     v0, s5, #0
    v.insert     v1, s3, #0
    v.insert     v0, s5, #1
    v.insert     v1, s6, #1
    v.insert     v0, s5, #2
    v.insert     v1, s8, #2
    v.insert     v0, s5, #3
    v.insert     v1, s12, #3
    s.lshri      s1, s5, #32
    v.insert     v0, s5, #4
    v.insert     v1, s1, #4
    s.lshri      s1, s5, #32
    v.insert     v0, s5, #5
    v.insert     v1, s1, #5
    v.movi       v5, #127
    @p2 v.sel        v8, v6, v4
    v.movi       v6, #7
    v.and        v9, v7, v5
    v.lshr       v5, v8, v6
    v.sub        v6, v2, v9
    v.sub        v7, v3, v5
    v.movi       v8, #1024
    v.insert     v0, s5, #6
    @p1 v.sel        v10, v6, v9
    @p2 v.sel        v6, v7, v5
    v.cmp.lt     p1, v4, v8
    s.lshri      s1, s5, #32
    v.movi       v4, #128
    v.insert     v1, s1, #6
    v.insert     v0, s5, #7
    v.sub        v5, v2, v4
    v.sub        v7, v3, v4
    v.cmp.lt     p2, v4, v2
    v.cmp.lt     p3, v4, v3
    v.movi       v2, #1
    s.lshri      s1, s5, #32
    s.lshri      s3, s5, #32
    v.insert     v1, s1, #7
    v.insert     v0, s5, #8
    v.insert     v1, s3, #8
    v.insert     v0, s5, #9
    @p2 v.sel        v2, v5, v4
    s.lshri      s1, s5, #32
    s.lshri      s3, s5, #32
    v.insert     v1, s1, #9
    v.insert     v0, s5, #10
    v.insert     v1, s3, #10
    v.insert     v0, s5, #11
    v.movi       v2, #1
    s.lshri      s1, s5, #32
    s.lshri      s3, s5, #32
    v.insert     v1, s1, #11
    v.insert     v0, s5, #12
    v.insert     v1, s3, #12
    v.insert     v0, s5, #13
    @p3 v.sel        v2, v7, v4
    s.lshri      s1, s5, #32
    s.lshri      s3, s5, #32
    v.insert     v1, s1, #13
    v.insert     v0, s5, #14
    v.insert     v1, s3, #14
    s.lshri      s1, s5, #32
    v.insert     v0, s5, #15
    v.insert     v1, s1, #15
    v.extract    s1, v0, #0
    v.extract    s3, v1, #0
    s.shli       s5, s3, #32
    v.extract    s3, v1, #1
    s.or         s6, s1, s5
    s.movz       s1, #32
    s.shli       s5, s3, #32
    v.extract    s3, v0, #1
    v.extract    s8, v1, #2
    s.shli       s12, s2, #1                     // element offset -> bytes (x2)
    s.add        s2, s6, s1
    s.or         s1, s3, s5
    s.movz       s3, #32
    s.shli       s5, s8, #32
    v.extract    s6, v0, #2
    v.extract    s8, v1, #3
    s.add        s15, s7, s12                    // &in_ptr2[...]
    s.add        s7, s11, s12                    // &in_ptr5[...]
    v.movi       v2, #0
    v.movi       v3, #0
    s.lshri      s11, s2, #32
    s.add        s12, s1, s3
    s.or         s1, s6, s5
    s.movz       s3, #32
    s.shli       s5, s8, #32
    v.extract    s6, v0, #3
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v4, [s4, v10]              // index is in elements (ISA sec 9.1)
    s.lshri      s4, s12, #32
    s.add        s8, s1, s3
    s.or         s1, s6, s5
    s.movz       s3, #32
    s.lshri      s5, s8, #32
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v5, [s15, #0]
    s.add        s6, s1, s3
    vf.cvt.bf16.f32 v7, v4
    v.extract    s1, v0, #4
    s.lshri      s3, s6, #32
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v4, [s9, v6]               // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v8, v5
    v.extract    s9, v1, #4
    s.shli       s15, s9, #32
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v5, [s10, v10]             // index is in elements (ISA sec 9.1)
    s.or         s9, s1, s15
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v9, [s7, #0]
    vf.cvt.bf16.f32 v11, v5
    s.movz       s1, #32
    s.add        s7, s9, s1
    v.movi       v5, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.h v5, [s13, v10]             // index is in elements (ISA sec 9.1)
    v.insert     v2, s2, #0
    v.insert     v3, s11, #0
    v.insert     v2, s12, #1
    v.insert     v3, s4, #1
    v.insert     v2, s8, #2
    v.insert     v3, s5, #2
    v.insert     v2, s6, #3
    v.insert     v3, s3, #3
    v.insert     v2, s7, #4
    vf.cvt.bf16.f32 v12, v9
    s.lshri      s1, s7, #32
    vf.cvt.bf16.f32 v9, v5
    v.extract    s2, v1, #5
    s.shli       s3, s2, #32
    v.extract    s2, v0, #5
    v.extract    s4, v1, #6
    s.or         s5, s2, s3
    s.movz       s2, #32
    s.shli       s3, s4, #32
    v.extract    s4, v0, #6
    v.extract    s6, v1, #7
    s.add        s7, s5, s2
    s.or         s2, s4, s3
    s.movz       s3, #32
    s.shli       s4, s6, #32
    v.extract    s5, v0, #7
    v.extract    s6, v1, #8
    v.insert     v3, s1, #4
    s.lshri      s1, s7, #32
    s.add        s8, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #32
    s.shli       s4, s6, #32
    v.extract    s5, v0, #8
    v.extract    s6, v1, #9
    v.insert     v2, s7, #5
    v.insert     v3, s1, #5
    s.lshri      s1, s8, #32
    s.add        s7, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #32
    s.shli       s4, s6, #32
    v.extract    s5, v0, #9
    v.extract    s6, v1, #10
    v.insert     v2, s8, #6
    v.insert     v3, s1, #6
    s.lshri      s1, s7, #32
    s.add        s8, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #32
    s.shli       s4, s6, #32
    v.extract    s5, v0, #10
    v.extract    s6, v1, #11
    v.insert     v2, s7, #7
    v.insert     v3, s1, #7
    s.lshri      s1, s8, #32
    s.add        s7, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #32
    s.shli       s4, s6, #32
    v.extract    s5, v0, #11
    v.extract    s6, v1, #12
    v.insert     v2, s8, #8
    v.insert     v3, s1, #8
    s.lshri      s1, s7, #32
    s.add        s8, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #32
    s.shli       s4, s6, #32
    v.extract    s5, v0, #12
    v.extract    s6, v1, #13
    v.insert     v2, s7, #9
    v.insert     v3, s1, #9
    s.lshri      s1, s8, #32
    s.add        s7, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #32
    s.shli       s4, s6, #32
    v.extract    s5, v0, #13
    v.extract    s6, v1, #14
    v.insert     v2, s8, #10
    v.insert     v3, s1, #10
    s.lshri      s1, s7, #32
    s.add        s8, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #32
    s.shli       s4, s6, #32
    v.extract    s5, v0, #14
    v.extract    s6, v1, #15
    v.insert     v2, s7, #11
    v.insert     v3, s1, #11
    s.lshri      s1, s8, #32
    s.add        s7, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #32
    s.shli       s4, s6, #32
    v.extract    s5, v0, #15
    v.extract    s6, v1, #0
    v.insert     v2, s8, #12
    v.insert     v3, s1, #12
    s.lshri      s1, s7, #32
    s.add        s8, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #32
    s.shli       s4, s6, #32
    v.extract    s5, v0, #0
    v.extract    s6, v1, #1
    v.insert     v2, s7, #13
    v.insert     v3, s1, #13
    s.lshri      s1, s8, #32
    s.add        s7, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #1
    v.extract    s6, v1, #2
    v.insert     v2, s8, #14
    v.insert     v3, s1, #14
    s.lshri      s1, s7, #32
    v.movi       v5, #0
    s.cmp.lt     s8, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #2
    v.extract    s6, v1, #3
    v.insert     v2, s7, #15
    v.insert     v3, s1, #15
    v.insert     v5, s8, #0
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #3
    v.extract    s6, v1, #4
    v.insert     v5, s1, #1
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #4
    v.extract    s6, v1, #5
    v.insert     v5, s1, #2
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #5
    v.extract    s6, v1, #6
    v.insert     v5, s1, #3
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #6
    v.extract    s6, v1, #7
    v.insert     v5, s1, #4
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #7
    v.extract    s6, v1, #8
    v.insert     v5, s1, #5
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #8
    v.extract    s6, v1, #9
    v.insert     v5, s1, #6
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #9
    v.extract    s6, v1, #10
    v.insert     v5, s1, #7
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #10
    v.extract    s6, v1, #11
    v.insert     v5, s1, #8
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #11
    v.extract    s6, v1, #12
    v.insert     v5, s1, #9
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #12
    v.extract    s6, v1, #13
    v.insert     v5, s1, #10
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #13
    v.extract    s6, v1, #14
    v.insert     v5, s1, #11
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #14
    v.extract    s6, v1, #15
    v.insert     v5, s1, #12
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    s.shli       s4, s6, #32
    v.extract    s5, v0, #15
    v.insert     v5, s1, #13
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #0
    v.insert     v5, s1, #14
    s.cmp.lt     s1, s2, s3
    v.extract    s2, v3, #0
    v.extract    s3, v1, #0
    v.insert     v5, s1, #15
    v.movi       v13, #0
    s.shli       s1, s2, #32
    s.shli       s2, s3, #32
    v.movi       v14, #1
    v.movi       v15, #0
    v.extract    s3, v2, #0
    v.extract    s4, v0, #0
    v.extract    s5, v3, #1
    v.extract    s6, v1, #1
    v.cmp.ne     p2, v5, v13
    s.or         s7, s3, s1
    s.or         s1, s4, s2
    s.shli       s2, s5, #32
    s.shli       s3, s6, #32
    @p2 v.sel        v5, v14, v15
    v.extract    s4, v2, #1
    v.extract    s5, v0, #1
    v.extract    s6, v3, #2
    v.extract    s8, v1, #2
    s.sub        s9, s7, s1
    s.or         s7, s4, s2
    s.or         s2, s5, s3
    s.shli       s3, s6, #32
    s.shli       s4, s8, #32
    v.extract    s5, v5, #0
    v.extract    s6, v2, #2
    v.extract    s8, v0, #2
    s.mul        s10, s5, s9
    s.sub        s5, s7, s2
    s.or         s7, s6, s3
    s.or         s3, s8, s4
    v.extract    s4, v5, #1
    s.mul        s6, s4, s5
    s.sub        s4, s7, s3
    v.extract    s5, v5, #2
    s.mul        s7, s5, s4
    s.add        s4, s1, s10
    v.extract    s1, v5, #3
    v.movi       v13, #0
    v.extract    s5, v2, #3
    v.movi       v14, #0
    v.extract    s8, v3, #3
    v.extract    s9, v1, #3
    s.shli       s10, s8, #32
    s.shli       s8, s9, #32
    v.extract    s9, v0, #3
    s.or         s11, s5, s10
    s.or         s5, s9, s8
    s.lshri      s8, s4, #32
    s.sub        s9, s11, s5
    s.add        s10, s2, s6
    s.mul        s2, s1, s9
    v.insert     v13, s4, #0
    v.extract    s1, v2, #4
    v.extract    s4, v5, #4
    v.insert     v14, s8, #0
    v.extract    s6, v3, #4
    v.extract    s8, v1, #4
    s.shli       s9, s6, #32
    s.shli       s6, s8, #32
    v.extract    s8, v0, #4
    s.or         s11, s1, s9
    s.or         s1, s8, s6
    s.lshri      s6, s10, #32
    s.sub        s8, s11, s1
    s.add        s9, s3, s7
    s.mul        s3, s4, s8
    v.insert     v13, s10, #1
    v.extract    s4, v2, #5
    v.extract    s7, v5, #5
    v.insert     v14, s6, #1
    v.extract    s6, v3, #5
    v.extract    s8, v1, #5
    s.shli       s10, s6, #32
    s.shli       s6, s8, #32
    v.extract    s8, v0, #5
    s.or         s11, s4, s10
    s.or         s4, s8, s6
    s.lshri      s6, s9, #32
    s.sub        s8, s11, s4
    s.add        s10, s5, s2
    s.mul        s2, s7, s8
    v.insert     v13, s9, #2
    v.extract    s5, v2, #6
    v.extract    s7, v5, #6
    v.insert     v14, s6, #2
    v.extract    s6, v3, #6
    v.extract    s8, v1, #6
    s.shli       s9, s6, #32
    s.shli       s6, s8, #32
    v.extract    s8, v0, #6
    s.or         s11, s5, s9
    s.or         s5, s8, s6
    s.lshri      s6, s10, #32
    s.sub        s8, s11, s5
    s.add        s9, s1, s3
    s.mul        s1, s7, s8
    v.insert     v13, s10, #3
    v.extract    s3, v2, #7
    v.extract    s7, v5, #7
    v.insert     v14, s6, #3
    v.extract    s6, v3, #7
    v.extract    s8, v1, #7
    s.shli       s10, s6, #32
    s.shli       s6, s8, #32
    v.extract    s8, v0, #7
    s.or         s11, s3, s10
    s.or         s3, s8, s6
    s.lshri      s6, s9, #32
    s.sub        s8, s11, s3
    s.add        s10, s4, s2
    s.mul        s2, s7, s8
    v.insert     v13, s9, #4
    v.extract    s4, v2, #8
    v.extract    s7, v5, #8
    v.insert     v14, s6, #4
    v.extract    s6, v3, #8
    v.extract    s8, v1, #8
    s.shli       s9, s6, #32
    s.shli       s6, s8, #32
    v.extract    s8, v0, #8
    s.or         s11, s4, s9
    s.or         s4, s8, s6
    s.lshri      s6, s10, #32
    s.sub        s8, s11, s4
    s.add        s9, s5, s1
    s.mul        s1, s7, s8
    v.insert     v13, s10, #5
    v.extract    s5, v2, #9
    v.extract    s7, v5, #9
    v.insert     v14, s6, #5
    v.extract    s6, v3, #9
    v.extract    s8, v1, #9
    s.shli       s10, s6, #32
    s.shli       s6, s8, #32
    v.extract    s8, v0, #9
    s.or         s11, s5, s10
    s.or         s5, s8, s6
    s.lshri      s6, s9, #32
    s.sub        s8, s11, s5
    s.add        s10, s3, s2
    s.mul        s2, s7, s8
    v.insert     v13, s9, #6
    v.extract    s3, v2, #10
    v.extract    s7, v5, #10
    v.insert     v14, s6, #6
    v.extract    s6, v3, #10
    v.extract    s8, v1, #10
    s.shli       s9, s6, #32
    s.shli       s6, s8, #32
    v.extract    s8, v0, #10
    s.or         s11, s3, s9
    s.or         s3, s8, s6
    s.lshri      s6, s10, #32
    s.sub        s8, s11, s3
    s.add        s9, s4, s1
    s.mul        s1, s7, s8
    v.insert     v13, s10, #7
    v.extract    s4, v2, #11
    v.extract    s7, v5, #11
    v.insert     v14, s6, #7
    v.extract    s6, v3, #11
    v.extract    s8, v1, #11
    s.shli       s10, s6, #32
    s.shli       s6, s8, #32
    v.extract    s8, v0, #11
    s.or         s11, s4, s10
    s.or         s4, s8, s6
    s.lshri      s6, s9, #32
    s.sub        s8, s11, s4
    s.add        s10, s5, s2
    s.mul        s2, s7, s8
    v.insert     v13, s9, #8
    v.extract    s5, v2, #12
    v.extract    s7, v5, #12
    v.insert     v14, s6, #8
    v.extract    s6, v3, #12
    v.extract    s8, v1, #12
    s.shli       s9, s6, #32
    s.shli       s6, s8, #32
    v.extract    s8, v0, #12
    s.or         s11, s5, s9
    s.or         s5, s8, s6
    s.lshri      s6, s10, #32
    s.sub        s8, s11, s5
    s.add        s9, s3, s1
    s.mul        s1, s7, s8
    v.insert     v13, s10, #9
    v.extract    s3, v2, #13
    v.extract    s7, v5, #13
    v.insert     v14, s6, #9
    v.extract    s6, v3, #13
    v.extract    s8, v1, #13
    s.shli       s10, s6, #32
    s.shli       s6, s8, #32
    v.extract    s8, v0, #13
    s.or         s11, s3, s10
    s.or         s3, s8, s6
    s.lshri      s6, s9, #32
    s.sub        s8, s11, s3
    s.add        s10, s4, s2
    s.mul        s2, s7, s8
    v.insert     v13, s9, #10
    v.extract    s4, v2, #14
    v.extract    s7, v5, #14
    v.insert     v14, s6, #10
    v.extract    s6, v3, #14
    v.extract    s8, v1, #14
    s.shli       s9, s6, #32
    s.shli       s6, s8, #32
    v.extract    s8, v0, #14
    s.or         s11, s4, s9
    s.or         s4, s8, s6
    s.lshri      s6, s10, #32
    s.sub        s8, s11, s4
    s.add        s9, s5, s1
    s.mul        s1, s7, s8
    v.insert     v13, s10, #11
    v.extract    s5, v2, #15
    v.extract    s7, v5, #15
    v.insert     v14, s6, #11
    v.extract    s6, v3, #15
    v.extract    s8, v1, #15
    s.shli       s10, s6, #32
    s.shli       s6, s8, #32
    v.extract    s8, v0, #15
    s.or         s11, s5, s10
    s.or         s5, s8, s6
    s.lshri      s6, s9, #32
    s.sub        s8, s11, s5
    s.add        s10, s3, s2
    s.mul        s2, s7, s8
    v.insert     v13, s9, #12
    v.insert     v14, s6, #12
    s.lshri      s3, s10, #32
    s.add        s6, s4, s1
    v.insert     v13, s10, #13
    v.insert     v14, s3, #13
    s.lshri      s1, s6, #32
    s.add        s3, s5, s2
    v.insert     v13, s6, #14
    v.insert     v14, s1, #14
    s.lshri      s1, s3, #32
    v.insert     v13, s3, #15
    v.insert     v14, s1, #15
    v.extract    s1, v13, #0
    v.extract    s2, v14, #0
    s.shli       s3, s2, #32
    v.extract    s2, v14, #1
    s.or         s4, s1, s3
    s.movz       s1, #0
    s.shli       s3, s2, #32
    v.extract    s2, v13, #1
    v.extract    s5, v14, #2
    v.movi       v0, #0
    s.cmp.ge     s6, s4, s1
    s.or         s1, s2, s3
    s.movz       s2, #0
    s.shli       s3, s5, #32
    v.extract    s4, v13, #2
    v.extract    s5, v14, #3
    v.insert     v0, s6, #0
    s.cmp.ge     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #0
    s.shli       s3, s5, #32
    v.extract    s4, v13, #3
    v.extract    s5, v14, #4
    v.insert     v0, s6, #1
    s.cmp.ge     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #0
    s.shli       s3, s5, #32
    v.extract    s4, v13, #4
    v.extract    s5, v14, #5
    v.insert     v0, s6, #2
    s.cmp.ge     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #0
    s.shli       s3, s5, #32
    v.extract    s4, v13, #5
    v.extract    s5, v14, #6
    v.insert     v0, s6, #3
    s.cmp.ge     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #0
    s.shli       s3, s5, #32
    v.extract    s4, v13, #6
    v.extract    s5, v14, #7
    v.insert     v0, s6, #4
    s.cmp.ge     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #0
    s.shli       s3, s5, #32
    v.extract    s4, v13, #7
    v.extract    s5, v14, #8
    v.insert     v0, s6, #5
    s.cmp.ge     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #0
    s.shli       s3, s5, #32
    v.extract    s4, v13, #8
    v.extract    s5, v14, #9
    v.insert     v0, s6, #6
    s.cmp.ge     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #0
    s.shli       s3, s5, #32
    v.extract    s4, v13, #9
    v.extract    s5, v14, #10
    v.insert     v0, s6, #7
    s.cmp.ge     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #0
    s.shli       s3, s5, #32
    v.extract    s4, v13, #10
    v.extract    s5, v14, #11
    v.insert     v0, s6, #8
    s.cmp.ge     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #0
    s.shli       s3, s5, #32
    v.extract    s4, v13, #11
    v.extract    s5, v14, #12
    v.insert     v0, s6, #9
    s.cmp.ge     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #0
    s.shli       s3, s5, #32
    v.extract    s4, v13, #12
    v.extract    s5, v14, #13
    v.insert     v0, s6, #10
    s.cmp.ge     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #0
    s.shli       s3, s5, #32
    v.extract    s4, v13, #13
    v.extract    s5, v14, #14
    v.insert     v0, s6, #11
    s.cmp.ge     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #0
    s.shli       s3, s5, #32
    v.extract    s4, v13, #14
    v.extract    s5, v14, #15
    v.extract    s7, v14, #0
    v.insert     v0, s6, #12
    s.cmp.ge     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #0
    s.shli       s3, s5, #32
    s.shli       s4, s7, #32
    v.extract    s5, v13, #15
    v.extract    s7, v13, #0
    v.extract    s8, v14, #1
    v.insert     v0, s6, #13
    s.cmp.ge     s6, s1, s2
    s.or         s1, s5, s3
    s.movz       s2, #0
    s.or         s3, s7, s4
    s.movz       s4, #32
    s.shli       s5, s8, #32
    v.extract    s7, v13, #1
    v.extract    s8, v14, #2
    v.insert     v0, s6, #14
    s.cmp.ge     s6, s1, s2
    v.movi       v1, #0
    s.cmp.lt     s1, s3, s4
    s.or         s2, s7, s5
    s.movz       s3, #32
    s.shli       s4, s8, #32
    v.extract    s5, v13, #2
    v.extract    s7, v14, #3
    v.insert     v0, s6, #15
    v.insert     v1, s1, #0
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #32
    s.shli       s4, s7, #32
    v.extract    s5, v13, #3
    v.extract    s6, v14, #4
    v.insert     v1, s1, #1
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #32
    s.shli       s4, s6, #32
    v.extract    s5, v13, #4
    v.extract    s6, v14, #5
    v.insert     v1, s1, #2
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #32
    s.shli       s4, s6, #32
    v.extract    s5, v13, #5
    v.extract    s6, v14, #6
    v.insert     v1, s1, #3
    s.cmp.lt     s1, s2, s3
    s.or         s2, s5, s4
    s.movz       s3, #32
    s.shli       s4, s6, #32
    v.extract    s5, v13, #6
    v.insert     v1, s1, #4
    s.cmp.lt     s1, s2, s3
    v.movi       v2, #0
    s.or         s2, s5, s4
    v.insert     v1, s1, #5
    v.cmp.ne     p2, v0, v2
    v.extract    s1, v14, #7
    s.movz       s3, #32
    s.shli       s4, s1, #32
    v.extract    s1, v13, #7
    v.extract    s5, v14, #8
    s.cmp.lt     s6, s2, s3
    s.or         s2, s1, s4
    s.movz       s1, #32
    s.shli       s3, s5, #32
    v.extract    s4, v13, #8
    v.extract    s5, v14, #9
    v.insert     v1, s6, #6
    s.cmp.lt     s6, s2, s1
    s.or         s1, s4, s3
    s.movz       s2, #32
    s.shli       s3, s5, #32
    v.extract    s4, v13, #9
    v.extract    s5, v14, #10
    v.insert     v1, s6, #7
    s.cmp.lt     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #32
    s.shli       s3, s5, #32
    v.extract    s4, v13, #10
    v.extract    s5, v14, #11
    v.insert     v1, s6, #8
    s.cmp.lt     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #32
    s.shli       s3, s5, #32
    v.extract    s4, v13, #11
    v.extract    s5, v14, #12
    v.insert     v1, s6, #9
    s.cmp.lt     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #32
    s.shli       s3, s5, #32
    v.extract    s4, v13, #12
    v.extract    s5, v14, #13
    v.insert     v1, s6, #10
    s.cmp.lt     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #32
    s.shli       s3, s5, #32
    v.extract    s4, v13, #13
    v.extract    s5, v14, #14
    v.insert     v1, s6, #11
    s.cmp.lt     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #32
    s.shli       s3, s5, #32
    v.extract    s4, v13, #14
    v.extract    s5, v14, #15
    v.insert     v1, s6, #12
    s.cmp.lt     s6, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #32
    s.shli       s3, s5, #32
    v.extract    s4, v13, #15
    v.insert     v1, s6, #13
    s.cmp.lt     s5, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #32
    v.insert     v1, s5, #14
    s.cmp.lt     s3, s1, s2
    v.movi       v0, #0
    v.insert     v1, s3, #15
    v.movi       v2, #0
    v.cmp.ne     p3, v1, v0
    p.and        p4, p2, p3
    v.movi       v0, #1
    s.movz       s1, #0
    @p4 v.sel        v1, v2, v0
    v.reduce.or  s2, v1
    s.cmp.eq     s3, s2, s1
    br.nz        s3, assert_ok_1
    trap         #677351
assert_ok_1:
    v.extract    s1, v14, #0
    s.shli       s2, s1, #32
    v.extract    s1, v13, #0
    v.extract    s3, v14, #1
    s.or         s4, s1, s2
    s.movz       s1, #128
    s.shli       s2, s3, #32
    v.extract    s3, v13, #1
    s.mul        s5, s4, s1
    s.or         s1, s3, s2
    s.movz       s2, #128
    v.movi       v0, #0
    s.mul        s3, s1, s2
    v.movi       v1, #0
    s.lshri      s1, s5, #32
    v.insert     v0, s5, #0
    v.insert     v1, s1, #0
    v.insert     v0, s3, #1
    .li       s1, #1124073472
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    s.lshri      s1, s3, #32
    v.rcp.approx v3, v2                          // ISA 8.8: <= 2**-22 relative
    v.insert     v1, s1, #1
    .li       s1, #1065353216
    v.splat      v5, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.extract    s1, v13, #2
    .li       s2, #897988541
    v.splat      v15, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #1077936128
    v.splat      v16, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.mul       v17, v12, v9
    .li       s2, #3204448256
    v.splat      v9, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v12, v2, v3, v5
    v.extract    s2, v14, #2
    vf.fms       v5, v3, v12, v3
    s.shli       s3, s2, #32
    vf.neg       v12, v5                         // Newton step: r0*(2 - x*r0)
    s.or         s2, s1, s3
    vf.cmp.o     p2, v12, v12
    s.movz       s1, #128
    @p2 v.sel        v5, v12, v3
    s.mul        s3, s2, s1
    vf.mul       v3, v4, v5                      // a/y: faithful quotient
    v.insert     v0, s3, #2
    vf.fms       v12, v3, v2, v4
    s.lshri      s1, s3, #32
    vf.fms       v2, v12, v5, v3
    v.insert     v1, s1, #2
    vf.neg       v4, v2                          // a/y: one correction to the IEEE quotient
    v.extract    s1, v13, #3
    vf.cmp.o     p2, v4, v4
    v.extract    s2, v14, #3
    @p2 v.sel        v2, v4, v3
    s.shli       s3, s2, #32
    vf.add       v3, v2, v15
    s.or         s2, s1, s3
    s.movz       s1, #128
    v.rsqrt.approx v2, v3                        // ISA 8.8: <= 2**-22 relative
    s.mul        s3, s2, s1
    vf.mul       v4, v2, v2
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #3
    vf.mul       v5, v2, v9
    vf.fms       v9, v3, v4, v16
    v.extract    s2, v14, #4
    v.extract    s3, v13, #4
    v.insert     v1, s1, #3
    vf.mul       v3, v5, v9                      // Newton step: 0.5*r0*(3 - x*r0^2)
    s.shli       s1, s2, #32
    vf.cmp.o     p2, v3, v3
    s.or         s2, s3, s1
    @p2 v.sel        v4, v3, v2
    s.movz       s1, #128
    vf.mul       v2, v8, v4
    s.mul        s3, s2, s1
    vf.mul       v3, v7, v2
    v.insert     v0, s3, #4
    vf.mul       v2, v3, v11
    s.lshri      s1, s3, #32
    v.insert     v1, s1, #4
    vf.add       v3, v2, v17
    v.extract    s1, v14, #5
    s.shli       s2, s1, #32
    v.extract    s1, v13, #5
    v.extract    s3, v14, #6
    s.or         s4, s1, s2
    s.movz       s1, #128
    s.shli       s2, s3, #32
    v.extract    s3, v13, #6
    v.extract    s5, v14, #7
    s.mul        s6, s4, s1
    s.or         s1, s3, s2
    s.movz       s2, #128
    s.shli       s3, s5, #32
    v.extract    s4, v13, #7
    v.extract    s5, v14, #8
    s.mul        s7, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #128
    s.shli       s3, s5, #32
    v.extract    s4, v13, #8
    v.extract    s5, v14, #9
    s.mul        s8, s1, s2
    s.or         s1, s4, s3
    s.movz       s2, #128
    s.shli       s3, s5, #32
    s.lshri      s4, s6, #32
    s.mul        s5, s1, s2
    v.extract    s1, v13, #9
    s.or         s2, s1, s3
    v.extract    s1, v14, #10
    s.shli       s3, s1, #32
    v.insert     v0, s6, #5
    s.movz       s1, #128
    v.insert     v1, s4, #5
    s.lshri      s4, s7, #32
    s.mul        s6, s2, s1
    v.extract    s1, v13, #10
    s.or         s2, s1, s3
    v.extract    s1, v14, #11
    s.shli       s3, s1, #32
    v.insert     v0, s7, #6
    s.movz       s1, #128
    v.insert     v1, s4, #6
    s.lshri      s4, s8, #32
    s.mul        s7, s2, s1
    v.extract    s1, v13, #11
    s.or         s2, s1, s3
    v.extract    s1, v14, #12
    s.shli       s3, s1, #32
    v.insert     v0, s8, #7
    s.movz       s1, #128
    v.insert     v1, s4, #7
    s.lshri      s4, s5, #32
    s.mul        s8, s2, s1
    v.extract    s1, v13, #12
    s.or         s2, s1, s3
    v.extract    s1, v14, #13
    s.shli       s3, s1, #32
    v.insert     v0, s5, #8
    s.movz       s1, #128
    v.insert     v1, s4, #8
    s.lshri      s4, s6, #32
    s.mul        s5, s2, s1
    v.extract    s1, v13, #13
    s.or         s2, s1, s3
    v.extract    s1, v14, #14
    s.shli       s3, s1, #32
    v.insert     v0, s6, #9
    s.movz       s1, #128
    v.insert     v1, s4, #9
    s.lshri      s4, s7, #32
    s.mul        s6, s2, s1
    v.extract    s1, v13, #14
    s.or         s2, s1, s3
    v.extract    s1, v14, #15
    s.shli       s3, s1, #32
    v.insert     v0, s7, #10
    s.movz       s1, #128
    v.insert     v1, s4, #10
    s.lshri      s4, s8, #32
    s.mul        s7, s2, s1
    v.extract    s1, v13, #15
    s.or         s2, s1, s3
    s.movz       s1, #128
    v.insert     v0, s8, #11
    v.insert     v1, s4, #11
    s.lshri      s3, s5, #32
    s.mul        s4, s2, s1
    v.extract    s1, v10, #0
    v.insert     v0, s5, #12
    v.insert     v1, s3, #12
    s.lshri      s2, s6, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #1
    v.insert     v0, s6, #13
    v.insert     v1, s2, #13
    s.lshri      s2, s7, #32
    s.ashri      s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #2
    v.insert     v0, s7, #14
    v.insert     v1, s2, #14
    s.lshri      s2, s4, #32
    v.movi       v2, #0
    v.movi       v4, #0
    s.lshri      s6, s5, #32
    s.ashri      s7, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #3
    v.insert     v0, s4, #15
    v.insert     v1, s2, #15
    v.insert     v2, s5, #0
    v.insert     v4, s6, #0
    s.lshri      s2, s7, #32
    s.ashri      s4, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #4
    v.insert     v2, s7, #1
    v.insert     v4, s2, #1
    s.lshri      s2, s4, #32
    s.ashri      s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #5
    v.insert     v2, s4, #2
    v.insert     v4, s2, #2
    s.lshri      s2, s5, #32
    s.ashri      s4, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #6
    v.insert     v2, s5, #3
    v.insert     v4, s2, #3
    s.lshri      s2, s4, #32
    s.ashri      s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #7
    v.insert     v2, s4, #4
    v.insert     v4, s2, #4
    s.lshri      s2, s5, #32
    s.ashri      s4, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #8
    v.insert     v2, s5, #5
    v.insert     v4, s2, #5
    s.lshri      s2, s4, #32
    s.ashri      s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #9
    v.insert     v2, s4, #6
    v.insert     v4, s2, #6
    s.lshri      s2, s5, #32
    s.ashri      s4, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #10
    v.insert     v2, s5, #7
    v.insert     v4, s2, #7
    s.lshri      s2, s4, #32
    s.ashri      s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #11
    v.insert     v2, s4, #8
    v.insert     v4, s2, #8
    s.lshri      s2, s5, #32
    s.ashri      s4, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #12
    v.insert     v2, s5, #9
    v.insert     v4, s2, #9
    s.lshri      s2, s4, #32
    s.ashri      s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #13
    v.insert     v2, s4, #10
    v.insert     v4, s2, #10
    s.lshri      s2, s5, #32
    s.ashri      s4, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #14
    v.insert     v2, s5, #11
    v.insert     v4, s2, #11
    s.lshri      s2, s4, #32
    s.ashri      s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v10, #15
    v.insert     v2, s4, #12
    v.insert     v4, s2, #12
    s.lshri      s2, s5, #32
    s.ashri      s4, s3, #32
    s.shli       s3, s1, #32
    v.insert     v2, s5, #13
    v.insert     v4, s2, #13
    s.lshri      s1, s4, #32
    s.ashri      s2, s3, #32
    v.insert     v2, s4, #14
    v.insert     v4, s1, #14
    s.lshri      s1, s2, #32
    v.insert     v2, s2, #15
    v.insert     v4, s1, #15
    v.extract    s1, v1, #0
    v.extract    s2, v4, #0
    s.shli       s3, s2, #32
    s.shli       s2, s1, #32
    v.extract    s1, v2, #0
    v.extract    s4, v0, #0
    v.extract    s5, v4, #1
    v.extract    s6, v1, #1
    s.or         s7, s1, s3
    s.or         s1, s4, s2
    s.shli       s2, s5, #32
    s.shli       s3, s6, #32
    v.extract    s4, v2, #1
    v.extract    s5, v0, #1
    v.extract    s6, v4, #2
    s.add        s8, s7, s1
    v.extract    s1, v1, #2
    s.or         s7, s4, s2
    s.or         s2, s5, s3
    s.shli       s3, s6, #32
    s.shli       s4, s1, #32
    v.extract    s1, v2, #2
    v.extract    s5, v0, #2
    v.movi       v5, #0
    v.movi       v7, #0
    s.add        s6, s7, s2
    v.extract    s2, v4, #3
    s.or         s7, s1, s3
    v.extract    s1, v1, #3
    s.or         s3, s5, s4
    s.lshri      s4, s8, #32
    s.shli       s5, s2, #32
    s.shli       s2, s1, #32
    v.insert     v5, s8, #0
    v.extract    s1, v2, #3
    v.insert     v7, s4, #0
    v.extract    s4, v0, #3
    s.add        s8, s7, s3
    v.extract    s3, v4, #4
    s.or         s7, s1, s5
    v.extract    s1, v1, #4
    s.or         s5, s4, s2
    s.lshri      s2, s6, #32
    s.shli       s4, s3, #32
    s.shli       s3, s1, #32
    v.insert     v5, s6, #1
    v.extract    s1, v2, #4
    v.insert     v7, s2, #1
    v.extract    s2, v0, #4
    s.add        s6, s7, s5
    v.extract    s5, v4, #5
    s.or         s7, s1, s4
    v.extract    s1, v1, #5
    s.or         s4, s2, s3
    s.lshri      s2, s8, #32
    s.shli       s3, s5, #32
    s.shli       s5, s1, #32
    v.insert     v5, s8, #2
    v.extract    s1, v2, #5
    v.insert     v7, s2, #2
    v.extract    s2, v0, #5
    s.add        s8, s7, s4
    v.extract    s4, v4, #6
    s.or         s7, s1, s3
    v.extract    s1, v1, #6
    s.or         s3, s2, s5
    s.lshri      s2, s6, #32
    s.shli       s5, s4, #32
    s.shli       s4, s1, #32
    v.insert     v5, s6, #3
    v.extract    s1, v2, #6
    v.insert     v7, s2, #3
    v.extract    s2, v0, #6
    s.add        s6, s7, s3
    v.extract    s3, v4, #7
    s.or         s7, s1, s5
    v.extract    s1, v1, #7
    s.or         s5, s2, s4
    s.lshri      s2, s8, #32
    s.shli       s4, s3, #32
    s.shli       s3, s1, #32
    v.insert     v5, s8, #4
    v.extract    s1, v2, #7
    v.insert     v7, s2, #4
    v.extract    s2, v0, #7
    s.add        s8, s7, s5
    v.extract    s5, v4, #8
    s.or         s7, s1, s4
    v.extract    s1, v1, #8
    s.or         s4, s2, s3
    s.lshri      s2, s6, #32
    s.shli       s3, s5, #32
    s.shli       s5, s1, #32
    v.insert     v5, s6, #5
    v.extract    s1, v2, #8
    v.insert     v7, s2, #5
    v.extract    s2, v0, #8
    s.add        s6, s7, s4
    v.extract    s4, v4, #9
    s.or         s7, s1, s3
    v.extract    s1, v1, #9
    s.or         s3, s2, s5
    s.lshri      s2, s8, #32
    s.shli       s5, s4, #32
    s.shli       s4, s1, #32
    v.insert     v5, s8, #6
    v.extract    s1, v2, #9
    v.insert     v7, s2, #6
    v.extract    s2, v0, #9
    s.add        s8, s7, s3
    v.extract    s3, v4, #10
    s.or         s7, s1, s5
    v.extract    s1, v1, #10
    s.or         s5, s2, s4
    s.lshri      s2, s6, #32
    s.shli       s4, s3, #32
    s.shli       s3, s1, #32
    v.insert     v5, s6, #7
    v.extract    s1, v2, #10
    v.insert     v7, s2, #7
    v.extract    s2, v0, #10
    s.add        s6, s7, s5
    v.extract    s5, v4, #11
    s.or         s7, s1, s4
    v.extract    s1, v1, #11
    s.or         s4, s2, s3
    s.lshri      s2, s8, #32
    s.shli       s3, s5, #32
    s.shli       s5, s1, #32
    v.insert     v5, s8, #8
    v.extract    s1, v2, #11
    v.insert     v7, s2, #8
    v.extract    s2, v0, #11
    s.add        s8, s7, s4
    v.extract    s4, v4, #12
    s.or         s7, s1, s3
    v.extract    s1, v1, #12
    s.or         s3, s2, s5
    s.lshri      s2, s6, #32
    s.shli       s5, s4, #32
    s.shli       s4, s1, #32
    v.insert     v5, s6, #9
    v.extract    s1, v2, #12
    v.insert     v7, s2, #9
    v.extract    s2, v0, #12
    s.add        s6, s7, s3
    v.extract    s3, v4, #13
    s.or         s7, s1, s5
    v.extract    s1, v1, #13
    s.or         s5, s2, s4
    s.lshri      s2, s8, #32
    s.shli       s4, s3, #32
    s.shli       s3, s1, #32
    v.insert     v5, s8, #10
    v.extract    s1, v2, #13
    v.insert     v7, s2, #10
    v.extract    s2, v0, #13
    s.add        s8, s7, s5
    v.extract    s5, v4, #14
    s.or         s7, s1, s4
    v.extract    s1, v1, #14
    s.or         s4, s2, s3
    s.lshri      s2, s6, #32
    s.shli       s3, s5, #32
    s.shli       s5, s1, #32
    v.insert     v5, s6, #11
    v.extract    s1, v2, #14
    v.insert     v7, s2, #11
    v.movi       v8, #4096
    v.extract    s2, v0, #14
    v.mul        v9, v6, v8
    s.add        s6, s7, s4
    v.extract    s4, v4, #15
    s.or         s7, s1, s3
    v.extract    s1, v1, #15
    s.or         s3, s2, s5
    s.lshri      s2, s8, #32
    s.shli       s5, s4, #32
    s.shli       s4, s1, #32
    v.insert     v5, s8, #12
    v.extract    s1, v2, #15
    v.insert     v7, s2, #12
    v.extract    s2, v0, #15
    s.add        s8, s7, s3
    v.extract    s3, v9, #0
    s.or         s7, s1, s5
    s.lshri      s1, s6, #32
    s.or         s5, s2, s4
    s.shli       s2, s3, #32
    v.extract    s3, v9, #1
    v.insert     v5, s6, #13
    v.insert     v7, s1, #13
    s.lshri      s1, s8, #32
    s.add        s4, s7, s5
    s.ashri      s5, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v9, #2
    v.insert     v5, s8, #14
    v.insert     v7, s1, #14
    s.lshri      s1, s4, #32
    v.movi       v0, #0
    v.movi       v1, #0
    s.lshri      s6, s5, #32
    s.ashri      s7, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v9, #3
    v.insert     v5, s4, #15
    v.insert     v7, s1, #15
    v.insert     v0, s5, #0
    v.insert     v1, s6, #0
    s.lshri      s1, s7, #32
    s.ashri      s4, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v9, #4
    v.insert     v0, s7, #1
    v.insert     v1, s1, #1
    s.lshri      s1, s4, #32
    s.ashri      s5, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v9, #5
    v.insert     v0, s4, #2
    v.insert     v1, s1, #2
    s.lshri      s1, s5, #32
    s.ashri      s4, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v9, #6
    v.insert     v0, s5, #3
    v.insert     v1, s1, #3
    s.lshri      s1, s4, #32
    s.ashri      s5, s2, #32
    s.shli       s2, s3, #32
    v.extract    s3, v9, #7
    v.insert     v0, s4, #4
    v.insert     v1, s1, #4
    s.lshri      s1, s5, #32
    s.ashri      s4, s2, #32
    v.insert     v0, s5, #5
    v.insert     v1, s1, #5
    s.lshri      s1, s4, #32
    v.insert     v0, s4, #6
    v.insert     v1, s1, #6
    s.movz       s1, #4096
    s.shli       s1, s3, #32
    v.extract    s2, v9, #8
    s.ashri      s3, s1, #32
    s.shli       s1, s2, #32
    v.extract    s2, v9, #9
    s.lshri      s4, s3, #32
    s.ashri      s5, s1, #32
    s.shli       s1, s2, #32
    v.extract    s2, v9, #10
    v.insert     v0, s3, #7
    v.insert     v1, s4, #7
    s.lshri      s3, s5, #32
    s.ashri      s4, s1, #32
    s.shli       s1, s2, #32
    v.extract    s2, v9, #11
    v.insert     v0, s5, #8
    v.insert     v1, s3, #8
    s.lshri      s3, s4, #32
    s.ashri      s5, s1, #32
    s.shli       s1, s2, #32
    v.extract    s2, v9, #12
    v.insert     v0, s4, #9
    v.insert     v1, s3, #9
    s.lshri      s3, s5, #32
    s.ashri      s4, s1, #32
    s.shli       s1, s2, #32
    v.extract    s2, v9, #13
    v.insert     v0, s5, #10
    v.insert     v1, s3, #10
    s.lshri      s3, s4, #32
    s.ashri      s5, s1, #32
    s.shli       s1, s2, #32
    v.extract    s2, v9, #14
    v.insert     v0, s4, #11
    v.insert     v1, s3, #11
    s.lshri      s3, s5, #32
    s.ashri      s4, s1, #32
    s.shli       s1, s2, #32
    v.extract    s2, v9, #15
    v.insert     v0, s5, #12
    v.insert     v1, s3, #12
    s.lshri      s3, s4, #32
    s.ashri      s5, s1, #32
    s.shli       s1, s2, #32
    v.insert     v0, s4, #13
    v.insert     v1, s3, #13
    s.lshri      s2, s5, #32
    s.ashri      s3, s1, #32
    v.insert     v0, s5, #14
    v.insert     v1, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v0, s3, #15
    v.insert     v1, s1, #15
    v.extract    s1, v7, #0
    v.extract    s2, v1, #0
    s.shli       s3, s1, #32
    s.shli       s1, s2, #32
    v.extract    s2, v5, #0
    v.extract    s4, v0, #0
    v.extract    s5, v7, #1
    v.extract    s6, v1, #1
    s.or         s7, s2, s3
    s.or         s2, s4, s1
    s.shli       s1, s5, #32
    s.shli       s3, s6, #32
    v.extract    s4, v5, #1
    v.extract    s5, v0, #1
    v.extract    s6, v7, #2
    v.movi       v2, #0
    s.add        s8, s7, s2
    v.extract    s2, v1, #2
    s.or         s7, s4, s1
    s.or         s1, s5, s3
    s.shli       s3, s6, #32
    s.shli       s4, s2, #32
    v.extract    s2, v5, #2
    v.extract    s5, v0, #2
    v.movi       v4, #0
    v.insert     v2, s8, #0
    s.lshri      s6, s8, #32
    s.add        s8, s7, s1
    v.extract    s1, v7, #3
    s.or         s7, s2, s3
    v.extract    s2, v1, #3
    s.or         s3, s5, s4
    s.shli       s4, s1, #32
    s.shli       s1, s2, #32
    v.extract    s2, v5, #3
    v.insert     v4, s6, #0
    v.extract    s5, v0, #3
    v.insert     v2, s8, #1
    s.lshri      s6, s8, #32
    s.add        s8, s7, s3
    v.extract    s3, v7, #4
    s.or         s7, s2, s4
    v.extract    s2, v1, #4
    s.or         s4, s5, s1
    s.shli       s1, s3, #32
    s.shli       s3, s2, #32
    v.extract    s2, v5, #4
    v.insert     v4, s6, #1
    v.extract    s5, v0, #4
    v.insert     v2, s8, #2
    s.lshri      s6, s8, #32
    s.add        s8, s7, s4
    v.extract    s4, v7, #5
    s.or         s7, s2, s1
    v.extract    s1, v1, #5
    s.or         s2, s5, s3
    s.shli       s3, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v5, #5
    v.insert     v4, s6, #2
    v.extract    s5, v0, #5
    v.insert     v2, s8, #3
    s.lshri      s6, s8, #32
    s.add        s8, s7, s2
    v.extract    s2, v7, #6
    s.or         s7, s1, s3
    v.extract    s1, v1, #6
    s.or         s3, s5, s4
    s.shli       s4, s2, #32
    s.shli       s2, s1, #32
    v.extract    s1, v5, #6
    v.insert     v4, s6, #3
    v.extract    s5, v0, #6
    v.insert     v2, s8, #4
    s.lshri      s6, s8, #32
    s.add        s8, s7, s3
    v.extract    s3, v7, #7
    s.or         s7, s1, s4
    v.extract    s1, v1, #7
    s.or         s4, s5, s2
    s.shli       s2, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v5, #7
    v.insert     v4, s6, #4
    v.extract    s5, v0, #7
    v.insert     v2, s8, #5
    s.lshri      s6, s8, #32
    s.add        s8, s7, s4
    v.extract    s4, v7, #8
    s.or         s7, s1, s2
    v.extract    s1, v1, #8
    s.or         s2, s5, s3
    s.shli       s3, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v5, #8
    v.insert     v4, s6, #5
    v.extract    s5, v0, #8
    v.insert     v2, s8, #6
    s.lshri      s6, s8, #32
    s.add        s8, s7, s2
    v.extract    s2, v7, #9
    s.or         s7, s1, s3
    v.extract    s1, v1, #9
    s.or         s3, s5, s4
    s.shli       s4, s2, #32
    s.shli       s2, s1, #32
    v.extract    s1, v5, #9
    v.insert     v4, s6, #6
    v.extract    s5, v0, #9
    v.insert     v2, s8, #7
    s.lshri      s6, s8, #32
    s.add        s8, s7, s3
    v.extract    s3, v7, #10
    s.or         s7, s1, s4
    v.extract    s1, v1, #10
    s.or         s4, s5, s2
    s.shli       s2, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v5, #10
    v.insert     v4, s6, #7
    v.extract    s5, v0, #10
    v.insert     v2, s8, #8
    s.lshri      s6, s8, #32
    s.add        s8, s7, s4
    v.extract    s4, v7, #11
    s.or         s7, s1, s2
    v.extract    s1, v1, #11
    s.or         s2, s5, s3
    s.shli       s3, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v5, #11
    v.insert     v4, s6, #8
    v.extract    s5, v0, #11
    v.insert     v2, s8, #9
    s.lshri      s6, s8, #32
    s.add        s8, s7, s2
    v.extract    s2, v7, #12
    s.or         s7, s1, s3
    v.extract    s1, v1, #12
    s.or         s3, s5, s4
    s.shli       s4, s2, #32
    s.shli       s2, s1, #32
    v.extract    s1, v5, #12
    v.insert     v4, s6, #9
    v.extract    s5, v0, #12
    v.insert     v2, s8, #10
    s.lshri      s6, s8, #32
    s.add        s8, s7, s3
    v.extract    s3, v7, #13
    s.or         s7, s1, s4
    v.extract    s1, v1, #13
    s.or         s4, s5, s2
    s.shli       s2, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v5, #13
    v.insert     v4, s6, #10
    v.extract    s5, v0, #13
    v.insert     v2, s8, #11
    s.lshri      s6, s8, #32
    s.add        s8, s7, s4
    v.extract    s4, v7, #14
    s.or         s7, s1, s2
    v.extract    s1, v1, #14
    s.or         s2, s5, s3
    s.shli       s3, s4, #32
    s.shli       s4, s1, #32
    v.extract    s1, v5, #14
    v.insert     v4, s6, #11
    v.extract    s5, v0, #14
    v.insert     v2, s8, #12
    s.lshri      s6, s8, #32
    s.add        s8, s7, s2
    v.extract    s2, v7, #15
    s.or         s7, s1, s3
    v.extract    s1, v1, #15
    s.or         s3, s5, s4
    s.shli       s4, s2, #32
    s.shli       s2, s1, #32
    v.extract    s1, v5, #15
    v.insert     v4, s6, #12
    v.extract    s5, v0, #15
    v.insert     v2, s8, #13
    s.lshri      s6, s8, #32
    s.add        s8, s7, s3
    s.or         s3, s1, s4
    s.or         s1, s5, s2
    v.insert     v4, s6, #13
    v.insert     v2, s8, #14
    s.lshri      s2, s8, #32
    s.add        s4, s3, s1
    v.insert     v4, s2, #14
    v.insert     v2, s4, #15
    s.lshri      s1, s4, #32
    v.movi       v0, #31
    v.insert     v4, s1, #15
    v.ashr       v1, v2, v0
    v.movi       v0, #1
    v.movi       v5, #0
    v.cmp.ne     p2, v4, v1
    @p2 v.sel        v1, v0, v5
    s.movz       s1, #0
    v.reduce.or  s2, v1
    s.cmp.eq     s3, s2, s1
    br.nz        s3, narrow_ok_2
    trap         #677220
narrow_ok_2:
    vf.cvt.f32.bf16 v0, v3
    @p1 v.st.scatter.h [s14, v2], v0
__rctx_next:
    exit
