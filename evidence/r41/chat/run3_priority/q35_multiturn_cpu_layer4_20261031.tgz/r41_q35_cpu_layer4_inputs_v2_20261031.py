#!/usr/bin/env python3
"""Locate layer-4 CPU whole-vs-grouped segmentation differences."""
import json,sys,time
from pathlib import Path
import torch
home=Path.home();tree=home/'r41_q35_multiturn_diag_20261031'
sys.path[:0]=[str(tree/'tools/models'),str(tree),str(tree/'python'),str(tree/'compiler/python'),str(tree/'tools/asm')]
import chat
prompt='My name is Alice. Please remember it and reply with one short sentence.'
args=chat.parser().parse_args(['--model','q35','--device','cpu','--threads','4','--bucket','256','--new-tokens','1'])
app=chat.ChatApplication(args);chat.L.install_fp8_route('reference',dot='exact',scale_div='ieee')
inputs,text=chat.make_inputs(app.spec,app.processor,[chat.user_message(prompt)])
layer=app.model.model.language_model.layers[4]
if layer.block_type!='linear_attention':raise ValueError('unexpected layer 4 type: '+layer.block_type)
names=('input_layernorm','linear_attn.in_proj_qkv','linear_attn.in_proj_z','linear_attn.in_proj_b','linear_attn.in_proj_a','linear_attn.norm','linear_attn.out_proj','linear_attn','post_attention_layernorm','mlp.gate_proj','mlp.up_proj','mlp.down_proj','mlp')
modules=dict(layer.named_modules());captures={};handles=[]
for name in names:
 if name not in modules:raise ValueError('module missing: '+name)
 def hook(module,args,out,n=name):
  x=out[0] if isinstance(out,(tuple,list)) else out
  if not isinstance(x,torch.Tensor) or x.ndim not in (2,3):raise TypeError(f'{n}: unexpected {type(out)} shape={getattr(x,"shape",None)}')
  captures.setdefault(n,[]).append(x.detach().cpu().contiguous().clone())
 handles.append(modules[name].register_forward_hook(hook))
def norm_inputs(module,args):
 if len(args) != 2: raise ValueError('unexpected gated norm arguments')
 for name,x in zip(('linear_attn.norm_input_core','linear_attn.norm_input_z'),args):
  captures.setdefault(name,[]).append(x.detach().cpu().contiguous().clone())
handles.append(modules['linear_attn.norm'].register_forward_pre_hook(norm_inputs))
probes=names+('linear_attn.norm_input_core','linear_attn.norm_input_z')
values={}
try:
 for name,chunk in [('whole',0),('grouped_chunk8',8)]:
  captures.clear();session=chat.Session(app.model,app.spec,'cpu',256,chunk)
  with torch.no_grad():logits,parts,reused=session.prefill_prompt(inputs,None)
  values[name]={n:torch.cat(captures[n],dim=1 if captures[n][0].ndim==3 else 0) for n in probes}
  del session
finally:
 for h in handles:h.remove()
rows=[]
for n in probes:
 a,b=values['whole'][n],values['grouped_chunk8'][n]
 if a.shape!=b.shape or a.dtype!=b.dtype:raise ValueError(f'{n}: shape/dtype differ {a.shape} {b.shape}')
 dtype={2:torch.int16,4:torch.int32}.get(a.element_size())
 if dtype is None:raise TypeError(f'{n}: dtype {a.dtype}')
 diff=a.view(dtype)!=b.view(dtype);af=a.float();bf=b.float()
 pos=diff.any(dim=-1).reshape(-1);p=torch.nonzero(pos).flatten()
 rows.append(dict(module=n,shape=list(a.shape),first_differing_vector=int(p[0]) if len(p) else None,differing_vectors=int(pos.sum()),elements=a.numel(),bit_mismatches=int(diff.sum()),rel_l2=float((af-bf).norm()/af.norm().clamp_min(1e-30)),max_abs=float((af-bf).abs().max())))
out={'schema':'r41-q35-cpu-layer4-inputs/1','scope':'full-checkpoint CPU, exact FP8 route; whole vs grouped; not board or TLM','layer':4,'block_type':layer.block_type,'input_ids':inputs['input_ids'].tolist(),'modules':rows}
p=home/'r41_q35_cpu_layer4_inputs_v2_20261031.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
