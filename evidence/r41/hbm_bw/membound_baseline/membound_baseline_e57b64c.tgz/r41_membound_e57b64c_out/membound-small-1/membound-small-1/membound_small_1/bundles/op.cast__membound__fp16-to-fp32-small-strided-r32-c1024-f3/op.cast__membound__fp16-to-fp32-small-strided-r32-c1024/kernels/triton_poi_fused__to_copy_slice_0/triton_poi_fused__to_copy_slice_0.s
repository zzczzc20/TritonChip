    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.shli       s2, s4, #4                      // x16 as a shift
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s2
    v.movi       v2, #2
    s.shli       s4, s2, #2                      // element offset -> bytes (x4)
    v.add        v3, v1, v0
    v.mul        v0, v3, v2
    v.ld.gather.h v1, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.ld.d       s2, [s1, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    vf.cvt.f16.f32 v0, v1
    s.add        s1, s2, s4                      // &out_ptr0[...]
    v.st.w       [s1, #0], v0
__rctx_next:
    exit
