    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, role_id
    s.movz       s2, #512
    s.rdspecial  s3, arg_base
    s.mul        s5, s1, s2
    s.ld.d       s1, [s3, #32]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s2, arg_base
    s.rdspecial  s3, role_id
    s.movz       s6, #512
    s.add        s7, s1, s5                      // this context's own scratch
    s.ld.d       s1, [s2, #8]                    // arg_A: device_ptr64 at arg_base+8
    s.addi       s5, s7, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    .li       s7, #2147483647
    .li       s8, #2147483647
    s.movz       s9, #8192
    s.movz       s10, #2
    .li       s11, #68719476752
    .li       s12, #1108101562368
    s.rdspecial  s13, arg_base
    s.mul        s14, s3, s6
    s.ld.d       s3, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    .li       s6, #2147483647
    .li       s15, #2147483647
    s.ld.d       s16, [s2, #16]                  // arg_B: device_ptr64 at arg_base+16
    s.movz       s17, #64
    s.movz       s18, #8192
    s.ld.d       s19, [s2, #24]                  // out_ptr0: device_ptr64 at arg_base+24
    s.movz       s2, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.movz       s22, #0
    s.cmp.lt     s23, s17, s21
    s.st.d       [s5, #0], s1
    s.sub        s1, s22, s23
    s.movz       s21, #2
    s.st.d       [s5, #8], s7
    .li       s7, #68719476752
    .li       s22, #1108101562368
    s.st.d       [s5, #16], s8
    s.xor        s8, s17, s1
    s.movz       s23, #0
    s.st.d       [s5, #48], s9
    s.movz       s9, #16
    s.movz       s23, #0
    s.st.d       [s5, #56], s10
    s.cmp.lt     s10, s4, s2
    s.movz       s2, #1
    s.sub        s23, s20, s10
    s.movz       s10, #0
    s.st.d       [s5, #88], s11
    s.xor        s11, s4, s23
    s.sub        s20, s8, s1
    s.sub        s8, s11, s23
    s.movz       s11, #0
    s.st.d       [s5, #104], s12
    s.lshri      s12, s8, #6
    fence.release.device
    td.load      d0, [s5]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.xor        s5, s23, s1
    s.movz       s1, #0
    s.movz       s20, #0
    s.ld.d       s23, [s13, #32]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.add        s13, s23, s14                   // this context's own scratch
    s.xor        s14, s12, s5
    s.cmp.lt     s23, s4, s11
    s.sub        s11, s14, s5
    s.muli       s5, s12, #64
    s.sub        s12, s9, s11
    s.addi       s14, s13, #256                  // TensorMap 1: a tile contiguous down its columns (built once, at entry)
    s.min.s      s13, s12, s2
    s.sub        s12, s20, s23
    s.cmp.lt     s20, s13, s10
    s.movz       s10, #0
    s.st.d       [s14, #0], s16
    s.sub        s16, s1, s20
    s.movz       s1, #1
    s.xor        s20, s4, s12
    s.st.d       [s14, #8], s6
    s.xor        s6, s13, s16
    s.sub        s23, s20, s12
    s.st.d       [s14, #16], s15
    s.sub        s15, s6, s16
    s.movz       s6, #0
    s.addi       s16, s10, #0
    s.st.d       [s14, #48], s18
    s.cmp.eq     s10, s15, s1
    s.sub        s1, s8, s5
    s.st.d       [s14, #56], s21
    s.addi       s1, s6, #0
    s.st.d       [s14, #88], s7
    s.st.d       [s14, #104], s22
    fence.release.device
    td.load      d1, [s14]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.mov        s16, s23
    br.nz        s10, sdiv_done_1
    s.movz       s5, #0
    s.movz       s6, #31
    s.mov        s16, s5
    s.addi       s5, s6, #0
sdiv_2:
    s.lshr       s6, s23, s5
    s.shli       s7, s1, #1
    s.andi       s8, s6, #1
    s.movz       s6, #0
    s.or         s10, s7, s8
    s.movz       s7, #1
    s.cmp.geu    s8, s10, s15
    s.shl        s14, s7, s5
    s.sub        s7, s6, s8
    s.subi       s6, s5, #1
    s.and        s8, s15, s7
    s.and        s18, s14, s7
    s.sub        s7, s10, s8
    s.or         s8, s16, s18
    s.mov        s1, s7
    s.mov        s16, s8
    s.mov        s5, s6
    s.movz       s6, #0
    s.cmp.ge     s7, s5, s6
    br.nz        s7, sdiv_2
sdiv_done_1:
    s.movz       s5, #0
    s.movz       s6, #0
    s.cmp.lt     s7, s4, s5
    s.movz       s5, #0
    s.sub        s8, s6, s7
    s.movz       s6, #0
    s.xor        s7, s4, s8
    s.movz       s4, #0
    s.sub        s10, s7, s8
    s.cmp.lt     s7, s13, s5
    s.lshri      s5, s10, #6
    s.movz       s14, #0
    s.muli       s15, s5, #64
    s.sub        s5, s4, s7
    s.movz       s4, #0
    s.cmp.lt     s7, s17, s14
    s.xor        s14, s13, s5
    s.sub        s13, s10, s15
    s.movz       s10, #0
    s.xor        s15, s13, s8
    s.xor        s13, s1, s12
    s.sub        s1, s15, s8
    s.sub        s8, s10, s7
    s.cmp.lt     s7, s1, s6
    s.sub        s6, s14, s5
    s.sub        s10, s4, s7
    s.movz       s4, #0
    s.xor        s7, s1, s10
    s.movz       s1, #1
    s.sub        s14, s13, s12
    s.xor        s12, s17, s8
    s.sub        s13, s7, s10
    s.movz       s7, #0
    s.addi       s15, s4, #0
    s.cmp.eq     s4, s6, s1
    s.add        s1, s11, s14
    s.sub        s11, s12, s8
    s.addi       s8, s7, #0
    s.mov        s15, s13
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.movz       s7, #31
    s.mov        s15, s4
    s.addi       s4, s7, #0
sdiv_4:
    s.lshr       s7, s13, s4
    s.shli       s11, s8, #1
    s.andi       s12, s7, #1
    s.movz       s7, #0
    s.or         s14, s11, s12
    s.movz       s11, #1
    s.cmp.geu    s12, s14, s6
    s.shl        s16, s11, s4
    s.sub        s11, s7, s12
    s.subi       s7, s4, #1
    s.and        s12, s6, s11
    s.and        s17, s16, s11
    s.sub        s11, s14, s12
    s.or         s12, s15, s17
    s.mov        s8, s11
    s.mov        s15, s12
    s.mov        s4, s7
    s.movz       s7, #0
    s.cmp.ge     s11, s4, s7
    br.nz        s11, sdiv_4
sdiv_done_3:
    s.xor        s4, s10, s5
    s.mul        s5, s1, s9
    s.xor        s6, s15, s4
    s.movz       s7, #0
    s.sub        s8, s6, s4
    v.splat      v0, s1
    s.mul        s1, s8, s9
    s.andi       s4, s5, #255
    v.splat      v1, s7
    v.splat      v2, s8
    v.splat      v3, s7
    s.andi       s6, s1, #1023
    v.iota       v4                              // arange(0, VLEN)
    v.splat      v5, s5
    v.cmp.ge     p1, v0, v1
    v.splat      v0, s1
    v.splat      v1, s4
    v.cmp.ge     p1, v2, v3
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v3, s6
    v.add        v6, v5, v4
    v.iota       v5                              // arange(0, VLEN)
    v.add        v6, v0, v4
    v.add        v0, v1, v2
    v.add        v0, v3, v5
    s.movz       s8, #256
    s.addi       s10, s7, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_5:
    s.cmp.ge     s7, s10, s8
    br.nz        s7, endfor_6
    s.mul        s7, s10, s9
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s11, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.add        s12, s10, s2
    s.movz       s13, #1
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s14, s4                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s14, s11
    mb.wait      s11
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s14, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    // a tile contiguous down its columns: its transpose is a plain tile, written transposed by the engine (ISA sec 9E mod[5])
    s.mov        s15, s6                         // coordinates must be consecutive (ISA sec 9E)
    s.mov        s16, s7                         // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h.t w1, d1, s15, s14
    mb.wait      s14
    mb.arm       s7, b2, #0, #1                  // 0 arrival(s), 1 operation(s)
    // acc + tl.dot(a, b): accumulated in place (ISA sec 9C)
    m.mma.async.k16.bf16 a0, v56, v48, s7
    mb.wait      s7
    s.mov        s10, s12
    br.nz        s13, for_5
endfor_6:
    s.movz       s2, #0
    s.movz       s4, #0
    s.add        s6, s2, s1                      // the tile origin
    s.muli       s2, s1, #2                      // a runtime tile origin, x2
    s.add        s9, s4, s5                      // the tile origin
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s6
    s.movz       s4, #1024
    v.splat      v2, s9
    v.splat      v3, s8
    v.add        v4, v0, v1
    v.splat      v0, s4
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p2, v4, v0
    s.add        s4, s3, s2                      // the tile origin
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    p.and        p3, p1, p2
    a.vread      v0, a0, s2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s2, s1, #2                      // a runtime tile origin, x2
    s.muli       s1, s5, #2048                   // a runtime tile origin, x2048
    s.addi       s3, s9, #1
    v.splat      v2, s9
    v.splat      v4, s3
    vf.cvt.bf16.f32 v5, v1
    s.add        s3, s19, s2                     // the tile origin
    v.cmp.lt     p1, v2, v3
    v.cmp.lt     p3, v4, v3
    vf.add       v1, v0, v5
    s.add        s2, s3, s1                      // the tile origin
    p.and        p4, p1, p2
    s.movz       s1, #1
    vf.cvt.f32.bf16 v0, v1
    p.and        p1, p3, p2
    s.addi       s3, s9, #1
    s.addi       s5, s9, #2
    @p4 v.st.h       [s2, #0], v0
    a.vread      v0, a0, s1
    v.splat      v1, s3
    v.splat      v2, s5
    v.cmp.lt     p3, v1, v3
    s.addi       s1, s2, #2048                   // row 1
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p1 v.ld.h       v1, [s4, #0]
    v.cmp.lt     p1, v2, v3
    p.and        p4, p3, p2
    s.movz       s3, #2
    p.and        p3, p1, p2
    s.addi       s5, s9, #2
    vf.cvt.bf16.f32 v2, v1
    s.addi       s6, s9, #3
    v.splat      v1, s5
    v.splat      v4, s6
    vf.add       v5, v0, v2
    s.addi       s5, s2, #4096                   // row 2
    s.movz       s6, #3
    s.addi       s8, s9, #3
    vf.cvt.f32.bf16 v0, v5
    s.addi       s10, s9, #4
    v.splat      v2, s8
    v.splat      v5, s10
    @p4 v.st.h       [s1, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p1, v1, v3
    p.and        p4, p1, p2
    s.addi       s1, s2, #6144                   // row 3
    s.movz       s3, #4
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    v.cmp.lt     p1, v4, v3
    p.and        p3, p1, p2
    s.addi       s8, s9, #4
    s.addi       s10, s9, #5
    v.splat      v4, s8
    vf.cvt.bf16.f32 v6, v1
    v.splat      v1, s10
    s.addi       s8, s2, #8192                   // row 4
    s.movz       s10, #5
    vf.add       v7, v0, v6
    vf.cvt.f32.bf16 v0, v7
    s.addi       s12, s9, #5
    v.splat      v6, s12
    @p4 v.st.h       [s5, #0], v0
    a.vread      v0, a0, s6
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s5, s9, #6
    s.addi       s6, s2, #10240                  // row 5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.splat      v5, s5
    s.movz       s5, #6
    vf.cvt.bf16.f32 v7, v2
    vf.add       v2, v0, v7
    vf.cvt.f32.bf16 v0, v2
    s.addi       s12, s9, #6
    v.splat      v2, s12
    @p4 v.st.h       [s1, #0], v0
    a.vread      v0, a0, s3
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.addi       s1, s9, #7
    s.addi       s3, s2, #12288                  // row 6
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s4, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.splat      v1, s1
    s.movz       s1, #7
    vf.cvt.bf16.f32 v7, v4
    vf.add       v4, v0, v7
    vf.cvt.f32.bf16 v0, v4
    s.addi       s12, s9, #7
    v.splat      v4, s12
    @p4 v.st.h       [s8, #0], v0
    a.vread      v0, a0, s10
    v.cmp.lt     p1, v6, v3
    p.and        p4, p1, p2
    s.addi       s8, s9, #8
    s.addi       s10, s2, #14336                 // row 7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s4, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.splat      v5, s8
    s.movz       s8, #8
    vf.cvt.bf16.f32 v7, v6
    vf.add       v6, v0, v7
    vf.cvt.f32.bf16 v0, v6
    s.addi       s12, s9, #8
    v.splat      v6, s12
    @p4 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s5, s9, #9
    s.addi       s6, s2, #16384                  // row 8
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.splat      v1, s5
    s.movz       s5, #9
    vf.cvt.bf16.f32 v7, v2
    vf.add       v2, v0, v7
    vf.cvt.f32.bf16 v0, v2
    s.addi       s12, s9, #9
    v.splat      v2, s12
    @p4 v.st.h       [s3, #0], v0
    a.vread      v0, a0, s1
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.addi       s1, s9, #10
    s.addi       s3, s2, #18432                  // row 9
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s4, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.splat      v5, s1
    s.movz       s1, #10
    vf.cvt.bf16.f32 v7, v4
    vf.add       v4, v0, v7
    vf.cvt.f32.bf16 v0, v4
    s.addi       s12, s9, #10
    v.splat      v4, s12
    @p4 v.st.h       [s10, #0], v0
    a.vread      v0, a0, s8
    v.cmp.lt     p1, v6, v3
    p.and        p4, p1, p2
    s.addi       s8, s9, #11
    s.addi       s10, s2, #20480                 // row 10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s4, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.splat      v1, s8
    s.movz       s8, #11
    vf.cvt.bf16.f32 v7, v6
    vf.add       v6, v0, v7
    vf.cvt.f32.bf16 v0, v6
    s.addi       s12, s9, #11
    v.splat      v6, s12
    @p4 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s5, s9, #12
    s.addi       s6, s2, #22528                  // row 11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.splat      v5, s5
    s.movz       s5, #12
    vf.cvt.bf16.f32 v7, v2
    vf.add       v2, v0, v7
    vf.cvt.f32.bf16 v0, v2
    s.addi       s12, s9, #12
    v.splat      v2, s12
    @p4 v.st.h       [s3, #0], v0
    a.vread      v0, a0, s1
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    s.addi       s1, s9, #13
    s.addi       s3, s2, #24576                  // row 12
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s4, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.splat      v1, s1
    s.movz       s1, #13
    vf.cvt.bf16.f32 v7, v4
    vf.add       v4, v0, v7
    vf.cvt.f32.bf16 v0, v4
    s.addi       s12, s9, #13
    v.splat      v4, s12
    @p4 v.st.h       [s10, #0], v0
    a.vread      v0, a0, s8
    v.cmp.lt     p1, v6, v3
    p.and        p4, p1, p2
    s.addi       s8, s9, #14
    s.addi       s10, s2, #26624                 // row 13
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v6, [s4, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    v.splat      v5, s8
    s.movz       s8, #14
    vf.cvt.bf16.f32 v7, v6
    vf.add       v6, v0, v7
    vf.cvt.f32.bf16 v0, v6
    s.addi       s12, s9, #14
    v.splat      v6, s12
    @p4 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    s.addi       s5, s9, #15
    s.addi       s6, s2, #28672                  // row 14
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s4, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    v.splat      v1, s5
    s.movz       s5, #15
    vf.cvt.bf16.f32 v7, v2
    vf.add       v2, v0, v7
    vf.cvt.f32.bf16 v0, v2
    s.addi       s12, s9, #15
    s.addi       s9, s2, #30720                  // row 15
    v.splat      v2, s12
    @p4 v.st.h       [s3, #0], v0
    a.vread      v0, a0, s1
    v.cmp.lt     p1, v4, v3
    p.and        p4, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s4, #0]
    v.cmp.lt     p1, v5, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v5, v4
    vf.add       v4, v0, v5
    vf.cvt.f32.bf16 v0, v4
    @p4 v.st.h       [s10, #0], v0
    a.vread      v0, a0, s8
    v.cmp.lt     p1, v6, v3
    p.and        p4, p1, p2
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s4, #0]
    v.cmp.lt     p1, v1, v3
    p.and        p3, p1, p2
    vf.cvt.bf16.f32 v1, v4
    vf.add       v4, v0, v1
    vf.cvt.f32.bf16 v0, v4
    @p4 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s5
    v.cmp.lt     p1, v2, v3
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s4, #0]
    vf.cvt.bf16.f32 v2, v1
    vf.add       v1, v0, v2
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s9, #0], v0
__rctx_next:
    exit
