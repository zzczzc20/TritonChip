#!/bin/bash
set -u
source ~/tc_env/env.sh
cd ~/tritonchip-r40-native-model-ref || exit 2
export PYTHONPATH=python:compiler/python:tools/asm CUDA_VISIBLE_DEVICES= OMP_NUM_THREADS=12 MKL_NUM_THREADS=12
~/tc_env/torchenv/bin/python -u tools/r40/native_model.py --reference-only \
  --software-tree-sha256 files:bd04f1ecc57ad18bc2813c1743b28df07d616f946502d35d2978ea133c0f383e \
  --out /tmp/r40_full_native_model_reference
r40_reference_rc=$?
printf '%s\n' "$r40_reference_rc" > /tmp/r40_full_native_model_reference.exit
exit "$r40_reference_rc"
