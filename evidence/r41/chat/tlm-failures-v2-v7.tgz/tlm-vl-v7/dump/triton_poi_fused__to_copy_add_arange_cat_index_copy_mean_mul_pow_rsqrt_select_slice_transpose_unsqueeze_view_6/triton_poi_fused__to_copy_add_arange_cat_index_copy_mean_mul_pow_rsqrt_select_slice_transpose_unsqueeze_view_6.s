    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.movz       s2, #16
    s.ld.d       s3, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.mul        s5, s4, s2
    v.iota       v0                              // arange(0, VLEN)
    v.movi       v1, #0
    v.movi       v2, #0
    v.movi       v3, #127
    v.splat      v4, s5
    v.movi       v5, #0
    v.movi       v6, #10
    v.add        v7, v4, v0
    v.movi       v0, #128
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    v.sub        v4, v1, v7
    v.cmp.lt     p1, v7, v1
    v.sub        v8, v2, v7
    @p1 v.sel        v9, v4, v7
    v.movi       v4, #7
    v.cmp.lt     p2, v7, v2
    @p2 v.sel        v10, v8, v7
    v.sub        v8, v5, v7
    v.cmp.lt     p3, v7, v5
    v.and        v11, v10, v3
    s.ld.d       s4, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    v.lshr       v3, v9, v4
    v.sub        v4, v2, v11
    @p3 v.sel        v9, v8, v7
    v.movi       v8, #18432
    @p2 v.sel        v10, v4, v11
    v.lshr       v4, v9, v6
    v.cmp.lt     p2, v7, v8
    v.movi       v6, #1024
    v.sub        v8, v5, v4
    v.sub        v9, v2, v0
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    v.sub        v11, v1, v3
    @p3 v.sel        v12, v8, v4
    v.sub        v4, v5, v6
    v.sub        v8, v1, v0
    v.cmp.lt     p3, v6, v5
    v.cmp.lt     p4, v0, v2
    v.movi       v2, #1
    @p3 v.sel        v2, v4, v6
    v.cmp.lt     p3, v0, v1
    v.movi       v1, #1
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    @p1 v.sel        v1, v11, v3
    @p4 v.sel        v2, v9, v0
    v.movi       v2, #1
    @p3 v.sel        v2, v8, v0
    s.ld.d       s8, [s1, #40]                   // in_ptr5: device_ptr64 at arg_base+40
    v.movi       v2, #8
    s.ld.d       s9, [s1, #48]                   // in_ptr6: device_ptr64 at arg_base+48
    v.movi       v3, #0
    s.ld.d       s10, [s1, #56]                  // out_ptr0: device_ptr64 at arg_base+56
    v.movi       v4, #0
    v.movi       v5, #0
    v.sub        v6, v3, v1
    v.cmp.lt     p1, v1, v3
    v.movi       v8, #7
    @p1 v.sel        v9, v6, v1
    v.sub        v6, v3, v2
    v.cmp.lt     p3, v2, v3
    v.and        v11, v9, v8
    v.movi       v8, #1
    s.ld.d       s1, [s3, #0]                    // one element, not a vector
    v.sub        v8, v3, v11
    @p3 v.sel        v3, v6, v2
    @p1 v.sel        v2, v8, v11
    s.lshri      s3, s1, #32
    v.insert     v4, s1, #0
    v.insert     v5, s3, #0
    s.lshri      s3, s1, #32
    v.insert     v4, s1, #1
    v.insert     v5, s3, #1
    s.lshri      s3, s1, #32
    v.insert     v4, s1, #2
    v.insert     v5, s3, #2
    s.lshri      s3, s1, #32
    v.insert     v4, s1, #3
    v.insert     v5, s3, #3
    s.lshri      s3, s1, #32
    v.insert     v4, s1, #4
    v.insert     v5, s3, #4
    s.lshri      s3, s1, #32
    v.insert     v4, s1, #5
    v.insert     v5, s3, #5
    s.lshri      s3, s1, #32
    v.insert     v4, s1, #6
    v.insert     v5, s3, #6
    s.lshri      s3, s1, #32
    v.insert     v4, s1, #7
    v.insert     v5, s3, #7
    s.lshri      s3, s1, #32
    v.insert     v4, s1, #8
    v.insert     v5, s3, #8
    v.movi       v3, #0
    s.lshri      s3, s1, #32
    v.insert     v4, s1, #9
    v.insert     v5, s3, #9
    v.sub        v6, v3, v10
    s.lshri      s3, s1, #32
    v.cmp.lt     p1, v10, v3
    v.insert     v4, s1, #10
    v.insert     v5, s3, #10
    @p1 v.sel        v8, v6, v10
    v.movi       v6, #63
    s.lshri      s3, s1, #32
    v.insert     v4, s1, #11
    v.insert     v5, s3, #11
    v.and        v9, v8, v6
    s.lshri      s3, s1, #32
    v.insert     v4, s1, #12
    v.insert     v5, s3, #12
    v.movi       v6, #64
    v.sub        v8, v3, v9
    v.mul        v11, v12, v0
    v.movi       v0, #2304
    s.lshri      s3, s1, #32
    v.extract    s11, v12, #0
    v.insert     v4, s1, #13
    v.insert     v5, s3, #13
    v.mul        v13, v12, v6
    @p1 v.sel        v14, v8, v9
    v.add        v8, v10, v11
    v.mul        v9, v2, v0
    s.shli       s3, s11, #32
    s.lshri      s11, s1, #32
    s.shli       s12, s5, #1                     // element offset -> bytes (x2)
    s.ashri      s5, s3, #32
    v.insert     v4, s1, #14
    v.extract    s3, v12, #1
    v.insert     v5, s11, #14
    v.add        v0, v13, v14
    v.add        v11, v8, v9
    v.movi       v8, #0
    v.movi       v9, #0
    s.shli       s11, s3, #32
    s.lshri      s3, s1, #32
    s.add        s13, s4, s12                    // &in_ptr2[...]
    s.lshri      s4, s5, #32
    s.ashri      s12, s11, #32
    v.insert     v4, s1, #15
    v.insert     v5, s3, #15
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.h v15, [s2, v10]             // index is in elements (ISA sec 9.1)
    v.extract    s1, v12, #2
    s.lshri      s2, s12, #32
    v.sub        v16, v3, v6
    v.cmp.lt     p1, v6, v3
    s.movz       s3, #64
    v.movi       v3, #1
    @p1 v.sel        v3, v16, v6
    s.movz       s3, #128
    s.movz       s3, #2304
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.h       v3, [s13, #0]
    vf.cvt.bf16.f32 v16, v15
    s.shli       s3, s1, #32
    s.ashri      s1, s3, #32
    s.lshri      s3, s1, #32
    v.movi       v15, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v15, [s6, v1]              // index is in elements (ISA sec 9.1)
    vf.cvt.bf16.f32 v1, v3
    v.extract    s6, v12, #3
    v.extract    s11, v12, #4
    s.shli       s13, s6, #32
    s.shli       s6, s11, #32
    s.ashri      s11, s13, #32
    v.extract    s13, v12, #5
    s.lshri      s14, s11, #32
    s.ashri      s15, s6, #32
    s.shli       s6, s13, #32
    s.ashri      s13, s6, #32
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v3, [s7, v0]               // index is in elements (ISA sec 9.1)
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.h v17, [s8, v11]             // index is in elements (ISA sec 9.1)
    s.lshri      s6, s15, #32
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s9, v0]              // index is in elements (ISA sec 9.1)
    v.insert     v8, s5, #0
    v.insert     v9, s4, #0
    v.extract    s4, v12, #6
    v.insert     v8, s12, #1
    v.insert     v9, s2, #1
    s.shli       s2, s4, #32
    v.insert     v8, s1, #2
    v.insert     v9, s3, #2
    s.lshri      s1, s13, #32
    v.insert     v8, s11, #3
    v.insert     v9, s14, #3
    v.extract    s3, v12, #7
    v.insert     v8, s15, #4
    v.insert     v9, s6, #4
    s.ashri      s4, s2, #32
    v.insert     v8, s13, #5
    v.insert     v9, s1, #5
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.insert     v8, s4, #6
    v.insert     v9, s2, #6
    vf.cvt.bf16.f32 v0, v17
    v.extract    s2, v12, #8
    s.ashri      s3, s1, #32
    s.shli       s1, s2, #32
    s.lshri      s2, s3, #32
    v.extract    s4, v12, #9
    s.ashri      s5, s1, #32
    v.insert     v8, s3, #7
    v.insert     v9, s2, #7
    s.shli       s1, s4, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #10
    s.ashri      s4, s1, #32
    v.insert     v8, s5, #8
    v.insert     v9, s2, #8
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #11
    s.ashri      s5, s1, #32
    v.insert     v8, s4, #9
    v.insert     v9, s2, #9
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #12
    s.ashri      s4, s1, #32
    v.insert     v8, s5, #10
    v.insert     v9, s2, #10
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #13
    s.ashri      s5, s1, #32
    v.insert     v8, s4, #11
    v.insert     v9, s2, #11
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #14
    s.ashri      s4, s1, #32
    v.insert     v8, s5, #12
    v.insert     v9, s2, #12
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #15
    s.ashri      s5, s1, #32
    v.insert     v8, s4, #13
    v.insert     v9, s2, #13
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    s.ashri      s3, s1, #32
    v.insert     v8, s5, #14
    v.insert     v9, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v8, s3, #15
    v.insert     v9, s1, #15
    v.extract    s1, v5, #0
    v.extract    s2, v8, #0
    v.extract    s3, v9, #0
    v.extract    s4, v4, #0
    s.shli       s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v9, #1
    v.extract    s6, v5, #1
    s.or         s8, s2, s5
    s.or         s2, s4, s3
    v.extract    s3, v8, #1
    s.shli       s4, s1, #32
    v.extract    s1, v4, #1
    s.shli       s5, s6, #32
    s.add        s6, s8, s2
    v.extract    s2, v9, #2
    v.extract    s8, v5, #2
    v.movi       v12, #0
    v.movi       v17, #0
    s.or         s11, s3, s4
    s.or         s3, s1, s5
    s.lshri      s1, s6, #32
    v.extract    s4, v8, #2
    s.shli       s5, s2, #32
    v.extract    s2, v4, #2
    s.shli       s12, s8, #32
    s.add        s8, s11, s3
    v.extract    s3, v9, #3
    v.extract    s11, v5, #3
    v.insert     v12, s6, #0
    v.insert     v17, s1, #0
    s.or         s1, s4, s5
    s.or         s4, s2, s12
    s.lshri      s2, s8, #32
    v.extract    s5, v8, #3
    s.shli       s6, s3, #32
    v.extract    s3, v4, #3
    s.shli       s12, s11, #32
    s.add        s11, s1, s4
    v.extract    s1, v9, #4
    v.extract    s4, v5, #4
    v.insert     v12, s8, #1
    v.insert     v17, s2, #1
    s.or         s2, s5, s6
    s.or         s5, s3, s12
    s.lshri      s3, s11, #32
    v.extract    s6, v8, #4
    s.shli       s8, s1, #32
    v.extract    s1, v4, #4
    s.shli       s12, s4, #32
    s.add        s4, s2, s5
    v.extract    s2, v9, #5
    v.extract    s5, v5, #5
    v.insert     v12, s11, #2
    v.insert     v17, s3, #2
    s.or         s3, s6, s8
    s.or         s6, s1, s12
    s.lshri      s1, s4, #32
    v.extract    s8, v8, #5
    s.shli       s11, s2, #32
    v.extract    s2, v4, #5
    s.shli       s12, s5, #32
    s.add        s5, s3, s6
    v.extract    s3, v9, #6
    v.extract    s6, v5, #6
    v.insert     v12, s4, #3
    v.insert     v17, s1, #3
    s.or         s1, s8, s11
    s.or         s4, s2, s12
    s.lshri      s2, s5, #32
    v.extract    s8, v8, #6
    s.shli       s11, s3, #32
    v.extract    s3, v4, #6
    s.shli       s12, s6, #32
    s.add        s6, s1, s4
    v.extract    s1, v9, #7
    v.extract    s4, v5, #7
    v.insert     v12, s5, #4
    v.insert     v17, s2, #4
    s.or         s2, s8, s11
    s.or         s5, s3, s12
    s.lshri      s3, s6, #32
    v.extract    s8, v8, #7
    s.shli       s11, s1, #32
    v.extract    s1, v4, #7
    s.shli       s12, s4, #32
    s.add        s4, s2, s5
    v.extract    s2, v9, #8
    v.extract    s5, v5, #8
    v.insert     v12, s6, #5
    v.insert     v17, s3, #5
    s.or         s3, s8, s11
    s.or         s6, s1, s12
    s.lshri      s1, s4, #32
    v.extract    s8, v8, #8
    s.shli       s11, s2, #32
    v.extract    s2, v4, #8
    s.shli       s12, s5, #32
    s.add        s5, s3, s6
    v.extract    s3, v9, #9
    v.extract    s6, v5, #9
    v.insert     v12, s4, #6
    v.insert     v17, s1, #6
    s.or         s1, s8, s11
    s.or         s4, s2, s12
    s.lshri      s2, s5, #32
    v.extract    s8, v8, #9
    s.shli       s11, s3, #32
    v.extract    s3, v4, #9
    s.shli       s12, s6, #32
    s.add        s6, s1, s4
    v.extract    s1, v9, #10
    v.extract    s4, v5, #10
    v.insert     v12, s5, #7
    v.insert     v17, s2, #7
    s.or         s2, s8, s11
    s.or         s5, s3, s12
    s.lshri      s3, s6, #32
    v.extract    s8, v8, #10
    s.shli       s11, s1, #32
    v.extract    s1, v4, #10
    s.shli       s12, s4, #32
    s.add        s4, s2, s5
    v.extract    s2, v9, #11
    v.extract    s5, v5, #11
    v.insert     v12, s6, #8
    v.insert     v17, s3, #8
    s.or         s3, s8, s11
    s.or         s6, s1, s12
    s.lshri      s1, s4, #32
    v.extract    s8, v8, #11
    s.shli       s11, s2, #32
    v.extract    s2, v4, #11
    s.shli       s12, s5, #32
    s.add        s5, s3, s6
    v.extract    s3, v9, #12
    v.extract    s6, v5, #12
    v.insert     v12, s4, #9
    v.insert     v17, s1, #9
    s.or         s1, s8, s11
    s.or         s4, s2, s12
    s.lshri      s2, s5, #32
    v.extract    s8, v8, #12
    s.shli       s11, s3, #32
    v.extract    s3, v4, #12
    s.shli       s12, s6, #32
    s.add        s6, s1, s4
    v.extract    s1, v9, #13
    v.extract    s4, v5, #13
    v.insert     v12, s5, #10
    v.insert     v17, s2, #10
    s.or         s2, s8, s11
    s.or         s5, s3, s12
    s.lshri      s3, s6, #32
    v.extract    s8, v8, #13
    s.shli       s11, s1, #32
    v.extract    s1, v4, #13
    s.shli       s12, s4, #32
    s.add        s4, s2, s5
    v.extract    s2, v9, #14
    v.extract    s5, v5, #14
    v.insert     v12, s6, #11
    v.insert     v17, s3, #11
    s.or         s3, s8, s11
    s.or         s6, s1, s12
    s.lshri      s1, s4, #32
    v.extract    s8, v8, #14
    s.shli       s11, s2, #32
    v.extract    s2, v4, #14
    s.shli       s12, s5, #32
    s.add        s5, s3, s6
    v.extract    s3, v9, #15
    v.extract    s6, v5, #15
    v.insert     v12, s4, #12
    v.insert     v17, s1, #12
    s.or         s1, s8, s11
    s.or         s4, s2, s12
    s.lshri      s2, s5, #32
    v.extract    s8, v8, #15
    s.shli       s11, s3, #32
    v.extract    s3, v4, #15
    s.shli       s12, s6, #32
    s.add        s6, s1, s4
    v.insert     v12, s5, #13
    v.insert     v17, s2, #13
    s.or         s1, s8, s11
    s.or         s2, s3, s12
    s.lshri      s3, s6, #32
    s.add        s4, s1, s2
    v.insert     v12, s6, #14
    v.insert     v17, s3, #14
    s.lshri      s1, s4, #32
    v.insert     v12, s4, #15
    v.insert     v17, s1, #15
    s.movz       s1, #64
    v.extract    s2, v12, #0
    v.extract    s3, v17, #0
    v.extract    s4, v17, #1
    s.shli       s5, s3, #32
    v.extract    s3, v12, #1
    s.or         s6, s2, s5
    s.shli       s2, s4, #32
    s.add        s4, s6, s1
    v.extract    s1, v17, #2
    v.movi       v4, #0
    v.movi       v5, #0
    s.or         s5, s3, s2
    s.movz       s2, #64
    s.lshri      s3, s4, #32
    v.extract    s6, v12, #2
    s.shli       s8, s1, #32
    s.add        s1, s5, s2
    v.extract    s2, v17, #3
    v.insert     v4, s4, #0
    v.insert     v5, s3, #0
    s.or         s3, s6, s8
    s.movz       s4, #64
    s.lshri      s5, s1, #32
    v.extract    s6, v12, #3
    s.shli       s8, s2, #32
    s.add        s2, s3, s4
    v.extract    s3, v17, #4
    v.insert     v4, s1, #1
    v.insert     v5, s5, #1
    s.or         s1, s6, s8
    s.movz       s4, #64
    s.lshri      s5, s2, #32
    v.extract    s6, v12, #4
    s.shli       s8, s3, #32
    s.add        s3, s1, s4
    v.extract    s1, v17, #5
    v.insert     v4, s2, #2
    v.insert     v5, s5, #2
    s.or         s2, s6, s8
    s.movz       s4, #64
    s.lshri      s5, s3, #32
    v.extract    s6, v12, #5
    s.shli       s8, s1, #32
    s.add        s1, s2, s4
    v.extract    s2, v17, #6
    v.insert     v4, s3, #3
    v.insert     v5, s5, #3
    s.or         s3, s6, s8
    s.movz       s4, #64
    s.lshri      s5, s1, #32
    v.extract    s6, v12, #6
    s.shli       s8, s2, #32
    s.add        s2, s3, s4
    v.extract    s3, v17, #7
    v.insert     v4, s1, #4
    v.insert     v5, s5, #4
    s.or         s1, s6, s8
    s.movz       s4, #64
    s.lshri      s5, s2, #32
    v.extract    s6, v12, #7
    s.shli       s8, s3, #32
    s.add        s3, s1, s4
    v.extract    s1, v17, #8
    v.insert     v4, s2, #5
    v.insert     v5, s5, #5
    s.or         s2, s6, s8
    s.movz       s4, #64
    s.lshri      s5, s3, #32
    v.extract    s6, v12, #8
    s.shli       s8, s1, #32
    s.add        s1, s2, s4
    v.extract    s2, v17, #9
    v.insert     v4, s3, #6
    v.insert     v5, s5, #6
    s.or         s3, s6, s8
    s.movz       s4, #64
    s.lshri      s5, s1, #32
    v.extract    s6, v12, #9
    s.shli       s8, s2, #32
    s.add        s2, s3, s4
    v.extract    s3, v17, #10
    v.insert     v4, s1, #7
    v.insert     v5, s5, #7
    s.or         s1, s6, s8
    s.movz       s4, #64
    s.lshri      s5, s2, #32
    v.extract    s6, v12, #10
    s.shli       s8, s3, #32
    s.add        s3, s1, s4
    v.extract    s1, v17, #11
    v.insert     v4, s2, #8
    v.insert     v5, s5, #8
    s.or         s2, s6, s8
    s.movz       s4, #64
    s.lshri      s5, s3, #32
    v.extract    s6, v12, #11
    s.shli       s8, s1, #32
    s.add        s1, s2, s4
    v.extract    s2, v17, #12
    v.insert     v4, s3, #9
    v.insert     v5, s5, #9
    s.or         s3, s6, s8
    s.movz       s4, #64
    s.lshri      s5, s1, #32
    v.extract    s6, v12, #12
    s.shli       s8, s2, #32
    s.add        s2, s3, s4
    v.extract    s3, v17, #13
    v.insert     v4, s1, #10
    v.insert     v5, s5, #10
    s.or         s1, s6, s8
    s.movz       s4, #64
    s.lshri      s5, s2, #32
    v.extract    s6, v12, #13
    s.shli       s8, s3, #32
    s.add        s3, s1, s4
    v.extract    s1, v17, #14
    v.insert     v4, s2, #11
    v.insert     v5, s5, #11
    s.or         s2, s6, s8
    s.movz       s4, #64
    s.lshri      s5, s3, #32
    v.extract    s6, v12, #14
    s.shli       s8, s1, #32
    s.add        s1, s2, s4
    v.extract    s2, v17, #15
    v.insert     v4, s3, #12
    v.insert     v5, s5, #12
    s.or         s3, s6, s8
    s.movz       s4, #64
    s.lshri      s5, s1, #32
    v.extract    s6, v12, #15
    s.shli       s8, s2, #32
    v.extract    s2, v17, #0
    s.add        s11, s3, s4
    v.insert     v4, s1, #13
    v.insert     v5, s5, #13
    s.or         s1, s6, s8
    s.movz       s3, #64
    v.extract    s4, v12, #0
    s.shli       s5, s2, #32
    s.lshri      s2, s11, #32
    v.extract    s6, v17, #1
    s.add        s8, s1, s3
    s.or         s1, s4, s5
    s.movz       s3, #0
    v.insert     v4, s11, #14
    v.insert     v5, s2, #14
    v.movi       v8, #0
    v.extract    s2, v12, #1
    s.shli       s4, s6, #32
    s.lshri      s5, s8, #32
    s.cmp.lt     s6, s1, s3
    v.extract    s1, v17, #2
    s.or         s3, s2, s4
    s.movz       s2, #0
    v.insert     v4, s8, #15
    v.insert     v5, s5, #15
    v.insert     v8, s6, #0
    v.extract    s4, v12, #2
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s3, s2
    v.extract    s2, v17, #3
    s.or         s3, s4, s5
    s.movz       s4, #0
    v.insert     v8, s1, #1
    v.extract    s1, v12, #3
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s3, s4
    v.extract    s3, v17, #4
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v8, s2, #2
    v.extract    s2, v12, #4
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s1
    v.extract    s1, v17, #5
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v8, s3, #3
    v.extract    s3, v12, #5
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s2
    v.extract    s2, v17, #6
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v8, s1, #4
    v.extract    s1, v12, #6
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s3
    v.extract    s3, v17, #7
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v8, s2, #5
    v.extract    s2, v12, #7
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s1
    v.extract    s1, v17, #8
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v8, s3, #6
    v.extract    s3, v12, #8
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s2
    v.extract    s2, v17, #9
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v8, s1, #7
    v.extract    s1, v12, #9
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s3
    v.extract    s3, v17, #10
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v8, s2, #8
    v.extract    s2, v12, #10
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s1
    v.extract    s1, v17, #11
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v8, s3, #9
    v.extract    s3, v12, #11
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s2
    v.extract    s2, v17, #12
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v8, s1, #10
    v.extract    s1, v12, #12
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s3
    v.extract    s3, v17, #13
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v8, s2, #11
    v.extract    s2, v12, #13
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s1
    v.extract    s1, v17, #14
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v8, s3, #12
    v.extract    s3, v12, #14
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s2
    v.extract    s2, v17, #15
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v8, s1, #13
    v.extract    s1, v12, #15
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s3
    s.or         s3, s1, s5
    s.movz       s1, #0
    v.insert     v8, s2, #14
    s.cmp.lt     s2, s3, s1
    v.movi       v9, #0
    v.insert     v8, s2, #15
    v.movi       v18, #1
    v.movi       v19, #0
    v.extract    s1, v5, #0
    v.extract    s2, v17, #0
    v.cmp.ne     p1, v8, v9
    v.extract    s3, v4, #0
    s.shli       s4, s1, #32
    v.extract    s1, v12, #0
    s.shli       s5, s2, #32
    @p1 v.sel        v8, v18, v19
    v.extract    s2, v5, #1
    v.extract    s6, v17, #1
    s.or         s8, s3, s4
    s.or         s3, s1, s5
    v.extract    s1, v4, #1
    s.shli       s4, s2, #32
    v.extract    s2, v12, #1
    s.shli       s5, s6, #32
    v.extract    s6, v8, #0
    s.sub        s11, s8, s3
    v.extract    s8, v5, #2
    v.extract    s12, v17, #2
    s.or         s13, s1, s4
    s.or         s1, s2, s5
    s.mul        s2, s6, s11
    v.extract    s4, v4, #2
    s.shli       s5, s8, #32
    v.extract    s6, v12, #2
    s.shli       s8, s12, #32
    v.extract    s11, v8, #1
    s.sub        s12, s13, s1
    s.or         s13, s4, s5
    s.or         s4, s6, s8
    s.mul        s5, s11, s12
    v.extract    s6, v8, #2
    s.sub        s8, s13, s4
    s.add        s11, s3, s2
    v.movi       v9, #0
    v.extract    s2, v4, #3
    v.movi       v18, #0
    v.extract    s3, v5, #3
    v.extract    s12, v17, #3
    s.shli       s13, s3, #32
    v.extract    s3, v12, #3
    s.shli       s14, s12, #32
    s.or         s12, s2, s13
    s.or         s2, s3, s14
    s.mul        s3, s6, s8
    s.lshri      s6, s11, #32
    v.extract    s8, v8, #3
    s.sub        s13, s12, s2
    s.add        s12, s1, s5
    v.insert     v9, s11, #0
    v.extract    s1, v4, #4
    v.insert     v18, s6, #0
    v.extract    s5, v5, #4
    v.extract    s6, v17, #4
    s.shli       s11, s5, #32
    v.extract    s5, v12, #4
    s.shli       s14, s6, #32
    s.or         s6, s1, s11
    s.or         s1, s5, s14
    s.mul        s5, s8, s13
    s.lshri      s8, s12, #32
    v.extract    s11, v8, #4
    s.sub        s13, s6, s1
    s.add        s6, s4, s3
    v.insert     v9, s12, #1
    v.extract    s3, v4, #5
    v.insert     v18, s8, #1
    v.extract    s4, v5, #5
    v.extract    s8, v17, #5
    s.shli       s12, s4, #32
    v.extract    s4, v12, #5
    s.shli       s14, s8, #32
    s.or         s8, s3, s12
    s.or         s3, s4, s14
    s.mul        s4, s11, s13
    s.lshri      s11, s6, #32
    v.extract    s12, v8, #5
    s.sub        s13, s8, s3
    s.add        s8, s2, s5
    v.insert     v9, s6, #2
    v.extract    s2, v4, #6
    v.insert     v18, s11, #2
    v.extract    s5, v5, #6
    v.extract    s6, v17, #6
    s.shli       s11, s5, #32
    v.extract    s5, v12, #6
    s.shli       s14, s6, #32
    s.or         s6, s2, s11
    s.or         s2, s5, s14
    s.mul        s5, s12, s13
    s.lshri      s11, s8, #32
    v.extract    s12, v8, #6
    s.sub        s13, s6, s2
    s.add        s6, s1, s4
    v.insert     v9, s8, #3
    v.extract    s1, v4, #7
    v.insert     v18, s11, #3
    v.extract    s4, v5, #7
    v.extract    s8, v17, #7
    s.shli       s11, s4, #32
    v.extract    s4, v12, #7
    s.shli       s14, s8, #32
    s.or         s8, s1, s11
    s.or         s1, s4, s14
    s.mul        s4, s12, s13
    s.lshri      s11, s6, #32
    v.extract    s12, v8, #7
    s.sub        s13, s8, s1
    s.add        s8, s3, s5
    v.insert     v9, s6, #4
    v.extract    s3, v4, #8
    v.insert     v18, s11, #4
    v.extract    s5, v5, #8
    v.extract    s6, v17, #8
    s.shli       s11, s5, #32
    v.extract    s5, v12, #8
    s.shli       s14, s6, #32
    s.or         s6, s3, s11
    s.or         s3, s5, s14
    s.mul        s5, s12, s13
    s.lshri      s11, s8, #32
    v.extract    s12, v8, #8
    s.sub        s13, s6, s3
    s.add        s6, s2, s4
    v.insert     v9, s8, #5
    v.extract    s2, v4, #9
    v.insert     v18, s11, #5
    v.extract    s4, v5, #9
    v.extract    s8, v17, #9
    s.shli       s11, s4, #32
    v.extract    s4, v12, #9
    s.shli       s14, s8, #32
    s.or         s8, s2, s11
    s.or         s2, s4, s14
    s.mul        s4, s12, s13
    s.lshri      s11, s6, #32
    v.extract    s12, v8, #9
    s.sub        s13, s8, s2
    s.add        s8, s1, s5
    v.insert     v9, s6, #6
    v.extract    s1, v4, #10
    v.insert     v18, s11, #6
    v.extract    s5, v5, #10
    v.extract    s6, v17, #10
    s.shli       s11, s5, #32
    v.extract    s5, v12, #10
    s.shli       s14, s6, #32
    s.or         s6, s1, s11
    s.or         s1, s5, s14
    s.mul        s5, s12, s13
    s.lshri      s11, s8, #32
    v.extract    s12, v8, #10
    s.sub        s13, s6, s1
    s.add        s6, s3, s4
    v.insert     v9, s8, #7
    v.extract    s3, v4, #11
    v.insert     v18, s11, #7
    v.extract    s4, v5, #11
    v.extract    s8, v17, #11
    s.shli       s11, s4, #32
    v.extract    s4, v12, #11
    s.shli       s14, s8, #32
    s.or         s8, s3, s11
    s.or         s3, s4, s14
    s.mul        s4, s12, s13
    s.lshri      s11, s6, #32
    v.extract    s12, v8, #11
    s.sub        s13, s8, s3
    s.add        s8, s2, s5
    v.insert     v9, s6, #8
    v.extract    s2, v4, #12
    v.insert     v18, s11, #8
    v.extract    s5, v5, #12
    v.extract    s6, v17, #12
    s.shli       s11, s5, #32
    v.extract    s5, v12, #12
    s.shli       s14, s6, #32
    s.or         s6, s2, s11
    s.or         s2, s5, s14
    s.mul        s5, s12, s13
    s.lshri      s11, s8, #32
    v.extract    s12, v8, #12
    s.sub        s13, s6, s2
    s.add        s6, s1, s4
    v.insert     v9, s8, #9
    v.extract    s1, v4, #13
    v.insert     v18, s11, #9
    v.extract    s4, v5, #13
    v.extract    s8, v17, #13
    s.shli       s11, s4, #32
    v.extract    s4, v12, #13
    s.shli       s14, s8, #32
    s.or         s8, s1, s11
    s.or         s1, s4, s14
    s.mul        s4, s12, s13
    s.lshri      s11, s6, #32
    v.extract    s12, v8, #13
    s.sub        s13, s8, s1
    s.add        s8, s3, s5
    v.insert     v9, s6, #10
    v.extract    s3, v4, #14
    v.insert     v18, s11, #10
    v.extract    s5, v5, #14
    v.extract    s6, v17, #14
    s.shli       s11, s5, #32
    v.extract    s5, v12, #14
    s.shli       s14, s6, #32
    s.or         s6, s3, s11
    s.or         s3, s5, s14
    s.mul        s5, s12, s13
    s.lshri      s11, s8, #32
    v.extract    s12, v8, #14
    s.sub        s13, s6, s3
    s.add        s6, s2, s4
    v.insert     v9, s8, #11
    v.extract    s2, v4, #15
    v.insert     v18, s11, #11
    v.extract    s4, v5, #15
    v.extract    s8, v17, #15
    s.shli       s11, s4, #32
    v.extract    s4, v12, #15
    s.shli       s14, s8, #32
    s.or         s8, s2, s11
    s.or         s2, s4, s14
    s.mul        s4, s12, s13
    s.lshri      s11, s6, #32
    v.extract    s12, v8, #15
    s.sub        s13, s8, s2
    s.add        s8, s1, s5
    v.insert     v9, s6, #12
    v.insert     v18, s11, #12
    s.mul        s1, s12, s13
    s.lshri      s5, s8, #32
    s.add        s6, s3, s4
    v.insert     v9, s8, #13
    v.insert     v18, s5, #13
    s.lshri      s3, s6, #32
    s.add        s4, s2, s1
    v.insert     v9, s6, #14
    v.insert     v18, s3, #14
    s.lshri      s1, s4, #32
    v.insert     v9, s4, #15
    v.insert     v18, s1, #15
    s.movz       s1, #0
    v.extract    s2, v9, #0
    v.extract    s3, v18, #0
    v.extract    s4, v18, #1
    s.shli       s5, s3, #32
    v.movi       v4, #0
    s.or         s3, s2, s5
    v.extract    s2, v9, #1
    s.shli       s5, s4, #32
    s.cmp.ge     s4, s3, s1
    v.extract    s1, v18, #2
    s.or         s3, s2, s5
    s.movz       s2, #0
    v.insert     v4, s4, #0
    v.extract    s4, v9, #2
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s3, s2
    v.extract    s2, v18, #3
    s.or         s3, s4, s5
    s.movz       s4, #0
    v.insert     v4, s1, #1
    v.extract    s1, v9, #3
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s3, s4
    v.extract    s3, v18, #4
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v4, s2, #2
    v.extract    s2, v9, #4
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v18, #5
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v4, s3, #3
    v.extract    s3, v9, #5
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v18, #6
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v4, s1, #4
    v.extract    s1, v9, #6
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v18, #7
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v4, s2, #5
    v.extract    s2, v9, #7
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v18, #8
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v4, s3, #6
    v.extract    s3, v9, #8
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v18, #9
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v4, s1, #7
    v.extract    s1, v9, #9
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v18, #10
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v4, s2, #8
    v.extract    s2, v9, #10
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v18, #11
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v4, s3, #9
    v.extract    s3, v9, #11
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v18, #12
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v4, s1, #10
    v.extract    s1, v9, #12
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v18, #13
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v4, s2, #11
    v.extract    s2, v9, #13
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v18, #14
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v4, s3, #12
    v.extract    s3, v9, #14
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v18, #15
    v.extract    s4, v18, #0
    s.or         s6, s3, s5
    s.movz       s3, #0
    v.insert     v4, s1, #13
    v.extract    s1, v9, #15
    s.shli       s5, s2, #32
    v.extract    s2, v9, #0
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s6, s3
    v.extract    s3, v18, #1
    s.or         s6, s1, s5
    s.movz       s1, #0
    s.or         s5, s2, s8
    s.movz       s2, #64
    v.insert     v4, s4, #14
    v.movi       v5, #0
    v.extract    s4, v9, #1
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s6, s1
    s.cmp.lt     s1, s5, s2
    v.extract    s2, v18, #2
    s.or         s5, s4, s8
    s.movz       s4, #64
    v.insert     v4, s3, #15
    v.insert     v5, s1, #0
    v.extract    s1, v9, #2
    s.shli       s3, s2, #32
    s.cmp.lt     s2, s5, s4
    v.extract    s4, v18, #3
    s.or         s5, s1, s3
    s.movz       s1, #64
    v.insert     v5, s2, #1
    v.extract    s2, v9, #3
    s.shli       s3, s4, #32
    s.cmp.lt     s4, s5, s1
    v.extract    s1, v18, #4
    s.or         s5, s2, s3
    s.movz       s2, #64
    v.insert     v5, s4, #2
    v.extract    s3, v9, #4
    s.shli       s4, s1, #32
    s.cmp.lt     s1, s5, s2
    v.extract    s2, v18, #5
    s.or         s5, s3, s4
    s.movz       s3, #64
    v.insert     v5, s1, #3
    v.extract    s1, v9, #5
    s.shli       s4, s2, #32
    s.cmp.lt     s2, s5, s3
    v.extract    s3, v18, #6
    s.or         s5, s1, s4
    s.movz       s1, #64
    v.insert     v5, s2, #4
    v.extract    s2, v9, #6
    s.shli       s4, s3, #32
    s.cmp.lt     s3, s5, s1
    v.movi       v8, #0
    s.or         s1, s2, s4
    v.insert     v5, s3, #5
    v.cmp.ne     p1, v4, v8
    v.extract    s2, v18, #7
    s.movz       s3, #64
    v.extract    s4, v9, #7
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s1, s3
    v.extract    s1, v18, #8
    s.or         s3, s4, s5
    s.movz       s4, #64
    v.insert     v5, s2, #6
    v.extract    s2, v9, #8
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s3, s4
    v.extract    s3, v18, #9
    s.or         s4, s2, s5
    s.movz       s2, #64
    v.insert     v5, s1, #7
    v.extract    s1, v9, #9
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    v.extract    s2, v18, #10
    s.or         s4, s1, s5
    s.movz       s1, #64
    v.insert     v5, s3, #8
    v.extract    s3, v9, #10
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s1
    v.extract    s1, v18, #11
    s.or         s4, s3, s5
    s.movz       s3, #64
    v.insert     v5, s2, #9
    v.extract    s2, v9, #11
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s3
    v.extract    s3, v18, #12
    s.or         s4, s2, s5
    s.movz       s2, #64
    v.insert     v5, s1, #10
    v.extract    s1, v9, #12
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    v.extract    s2, v18, #13
    s.or         s4, s1, s5
    s.movz       s1, #64
    v.insert     v5, s3, #11
    v.extract    s3, v9, #13
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s1
    v.extract    s1, v18, #14
    s.or         s4, s3, s5
    s.movz       s3, #64
    v.insert     v5, s2, #12
    v.extract    s2, v9, #14
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s3
    v.extract    s3, v18, #15
    s.or         s4, s2, s5
    s.movz       s2, #64
    v.insert     v5, s1, #13
    v.extract    s1, v9, #15
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    s.or         s2, s1, s5
    s.movz       s1, #64
    v.insert     v5, s3, #14
    s.cmp.lt     s3, s2, s1
    v.movi       v4, #0
    v.insert     v5, s3, #15
    v.movi       v8, #-1
    v.movi       v12, #0
    v.cmp.ne     p3, v5, v4
    p.and        p4, p1, p3
    v.cmp.ne     p1, v8, v12
    p.xor        p3, p2, p1
    v.movi       v4, #0
    v.movi       v5, #1
    p.or         p1, p4, p3
    s.movz       s1, #0
    @p1 v.sel        v8, v4, v5
    v.reduce.or  s2, v8
    s.cmp.eq     s3, s2, s1
    br.nz        s3, assert_ok_1
    trap         #677351
assert_ok_1:
    v.movi       v4, #0
    v.movi       v5, #63
    v.movi       v8, #0
    v.sub        v12, v4, v7
    v.cmp.lt     p1, v7, v4
    v.movi       v17, #0
    @p1 v.sel        v19, v12, v7
    .li       s1, #1124073472
    v.splat      v7, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s1, #1065353216
    v.splat      v12, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.and        v20, v19, v5
    v.rcp.approx v5, v7                          // ISA 8.8: <= 2**-22 relative
    .li       s1, #897988541
    v.splat      v19, s1                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.cmp.lt     p3, v6, v4
    v.movi       v21, #1
    vf.fms       v21, v7, v5, v12
    vf.fms       v12, v5, v21, v5
    vf.neg       v21, v12                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p4, v21, v21
    @p4 v.sel        v12, v21, v5
    v.sub        v5, v4, v20
    v.sub        v21, v4, v6
    @p1 v.sel        v4, v5, v20
    vf.mul       v5, v15, v12                    // a/y: faithful quotient
    @p3 v.sel        v20, v21, v6
    v.extract    s1, v4, #0
    v.extract    s2, v4, #1
    s.shli       s3, s1, #32
    s.shli       s1, s2, #32
    s.ashri      s2, s3, #32
    v.extract    s3, v4, #2
    s.lshri      s4, s2, #32
    s.ashri      s5, s1, #32
    v.insert     v8, s2, #0
    v.insert     v17, s4, #0
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    s.ashri      s3, s1, #32
    v.insert     v8, s5, #1
    v.insert     v17, s2, #1
    vf.fms       v6, v5, v7, v15
    s.lshri      s1, s3, #32
    v.insert     v8, s3, #2
    .li       s2, #1077936128
    v.splat      v7, s2                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    .li       s2, #3204448256
    v.splat      v15, s2                         // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v20, v6, v12, v5
    v.insert     v17, s1, #2
    vf.neg       v6, v20                         // a/y: one correction to the IEEE quotient
    v.extract    s1, v4, #3
    vf.cmp.o     p1, v6, v6
    s.shli       s2, s1, #32
    @p1 v.sel        v12, v6, v5
    s.ashri      s1, s2, #32
    v.insert     v8, s1, #3
    vf.add       v5, v12, v19
    s.lshri      s2, s1, #32
    v.rsqrt.approx v6, v5                        // ISA 8.8: <= 2**-22 relative
    v.insert     v17, s2, #3
    vf.mul       v12, v6, v6
    v.extract    s1, v4, #4
    vf.mul       v19, v6, v15
    s.shli       s2, s1, #32
    vf.fms       v15, v5, v12, v7
    s.ashri      s1, s2, #32
    s.lshri      s2, s1, #32
    v.insert     v8, s1, #4
    vf.mul       v5, v19, v15                    // Newton step: 0.5*r0*(3 - x*r0^2)
    v.insert     v17, s2, #4
    vf.cmp.o     p1, v5, v5
    v.extract    s1, v4, #5
    @p1 v.sel        v7, v5, v6
    s.shli       s2, s1, #32
    vf.mul       v5, v1, v7
    s.ashri      s1, s2, #32
    vf.mul       v1, v16, v5
    v.extract    s2, v4, #6
    s.lshri      s3, s1, #32
    s.shli       s4, s2, #32
    v.extract    s2, v4, #7
    s.ashri      s5, s4, #32
    v.insert     v8, s1, #5
    v.insert     v17, s3, #5
    s.shli       s1, s2, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v4, #8
    s.ashri      s4, s1, #32
    v.insert     v8, s5, #6
    v.insert     v17, s2, #6
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v4, #9
    s.ashri      s5, s1, #32
    v.insert     v8, s4, #7
    v.insert     v17, s2, #7
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v4, #10
    s.ashri      s4, s1, #32
    v.insert     v8, s5, #8
    v.insert     v17, s2, #8
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v4, #11
    s.ashri      s5, s1, #32
    v.insert     v8, s4, #9
    v.insert     v17, s2, #9
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v4, #12
    s.ashri      s4, s1, #32
    v.insert     v8, s5, #10
    v.insert     v17, s2, #10
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v4, #13
    s.ashri      s5, s1, #32
    v.insert     v8, s4, #11
    v.insert     v17, s2, #11
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v4, #14
    s.ashri      s4, s1, #32
    v.insert     v8, s5, #12
    v.insert     v17, s2, #12
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v4, #15
    s.ashri      s5, s1, #32
    v.insert     v8, s4, #13
    v.insert     v17, s2, #13
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    s.ashri      s3, s1, #32
    v.insert     v8, s5, #14
    v.insert     v17, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v8, s3, #15
    v.insert     v17, s1, #15
    s.movz       s1, #2
    v.extract    s2, v8, #0
    v.extract    s3, v17, #0
    v.extract    s4, v17, #1
    s.shli       s5, s3, #32
    v.movi       v4, #0
    s.or         s3, s2, s5
    v.extract    s2, v8, #1
    s.shli       s5, s4, #32
    s.cmp.ge     s4, s3, s1
    v.extract    s1, v17, #2
    s.or         s3, s2, s5
    s.movz       s2, #2
    v.insert     v4, s4, #0
    v.extract    s4, v8, #2
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s3, s2
    v.extract    s2, v17, #3
    s.or         s3, s4, s5
    s.movz       s4, #2
    v.insert     v4, s1, #1
    v.extract    s1, v8, #3
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s3, s4
    v.extract    s3, v17, #4
    s.or         s4, s1, s5
    s.movz       s1, #2
    v.insert     v4, s2, #2
    v.extract    s2, v8, #4
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v17, #5
    s.or         s4, s2, s5
    s.movz       s2, #2
    v.insert     v4, s3, #3
    v.extract    s3, v8, #5
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v17, #6
    s.or         s4, s3, s5
    s.movz       s3, #2
    v.insert     v4, s1, #4
    v.extract    s1, v8, #6
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v17, #7
    s.or         s4, s1, s5
    s.movz       s1, #2
    v.insert     v4, s2, #5
    v.extract    s2, v8, #7
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v17, #8
    s.or         s4, s2, s5
    s.movz       s2, #2
    v.insert     v4, s3, #6
    v.extract    s3, v8, #8
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v17, #9
    s.or         s4, s3, s5
    s.movz       s3, #2
    v.insert     v4, s1, #7
    v.extract    s1, v8, #9
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v17, #10
    s.or         s4, s1, s5
    s.movz       s1, #2
    v.insert     v4, s2, #8
    v.extract    s2, v8, #10
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v17, #11
    s.or         s4, s2, s5
    s.movz       s2, #2
    v.insert     v4, s3, #9
    v.extract    s3, v8, #11
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v17, #12
    s.or         s4, s3, s5
    s.movz       s3, #2
    v.insert     v4, s1, #10
    v.extract    s1, v8, #12
    s.shli       s5, s2, #32
    s.cmp.ge     s2, s4, s3
    v.extract    s3, v17, #13
    s.or         s4, s1, s5
    s.movz       s1, #2
    v.insert     v4, s2, #11
    v.extract    s2, v8, #13
    s.shli       s5, s3, #32
    s.cmp.ge     s3, s4, s1
    v.extract    s1, v17, #14
    s.or         s4, s2, s5
    s.movz       s2, #2
    v.insert     v4, s3, #12
    v.extract    s3, v8, #14
    s.shli       s5, s1, #32
    s.cmp.ge     s1, s4, s2
    v.extract    s2, v17, #15
    v.extract    s4, v17, #0
    s.or         s6, s3, s5
    s.movz       s3, #2
    v.insert     v4, s1, #13
    v.extract    s1, v8, #15
    s.shli       s5, s2, #32
    v.extract    s2, v8, #0
    s.shli       s8, s4, #32
    s.cmp.ge     s4, s6, s3
    v.extract    s3, v17, #1
    s.or         s6, s1, s5
    s.movz       s1, #2
    s.or         s5, s2, s8
    s.movz       s2, #60
    v.insert     v4, s4, #14
    v.movi       v5, #0
    v.extract    s4, v8, #1
    s.shli       s8, s3, #32
    s.cmp.ge     s3, s6, s1
    s.cmp.lt     s1, s5, s2
    v.extract    s2, v17, #2
    s.or         s5, s4, s8
    s.movz       s4, #60
    v.insert     v4, s3, #15
    v.insert     v5, s1, #0
    v.extract    s1, v8, #2
    s.shli       s3, s2, #32
    s.cmp.lt     s2, s5, s4
    v.extract    s4, v17, #3
    s.or         s5, s1, s3
    s.movz       s1, #60
    v.insert     v5, s2, #1
    v.extract    s2, v8, #3
    s.shli       s3, s4, #32
    s.cmp.lt     s4, s5, s1
    v.extract    s1, v17, #4
    s.or         s5, s2, s3
    s.movz       s2, #60
    v.insert     v5, s4, #2
    v.extract    s3, v8, #4
    s.shli       s4, s1, #32
    s.cmp.lt     s1, s5, s2
    v.extract    s2, v17, #5
    s.or         s5, s3, s4
    s.movz       s3, #60
    v.insert     v5, s1, #3
    v.extract    s1, v8, #5
    s.shli       s4, s2, #32
    s.cmp.lt     s2, s5, s3
    v.extract    s3, v17, #6
    s.or         s5, s1, s4
    s.movz       s1, #60
    v.insert     v5, s2, #4
    v.extract    s2, v8, #6
    s.shli       s4, s3, #32
    s.cmp.lt     s3, s5, s1
    v.movi       v6, #0
    s.or         s1, s2, s4
    v.insert     v5, s3, #5
    v.cmp.ne     p1, v4, v6
    v.extract    s2, v17, #7
    s.movz       s3, #60
    v.extract    s4, v8, #7
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s1, s3
    v.extract    s1, v17, #8
    s.or         s3, s4, s5
    s.movz       s4, #60
    v.insert     v5, s2, #6
    v.extract    s2, v8, #8
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s3, s4
    v.extract    s3, v17, #9
    s.or         s4, s2, s5
    s.movz       s2, #60
    v.insert     v5, s1, #7
    v.extract    s1, v8, #9
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    v.extract    s2, v17, #10
    s.or         s4, s1, s5
    s.movz       s1, #60
    v.insert     v5, s3, #8
    v.extract    s3, v8, #10
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s1
    v.extract    s1, v17, #11
    s.or         s4, s3, s5
    s.movz       s3, #60
    v.insert     v5, s2, #9
    v.extract    s2, v8, #11
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s3
    v.extract    s3, v17, #12
    s.or         s4, s2, s5
    s.movz       s2, #60
    v.insert     v5, s1, #10
    v.extract    s1, v8, #12
    s.shli       s5, s3, #32
    s.cmp.lt     s3, s4, s2
    v.extract    s2, v17, #13
    s.or         s4, s1, s5
    s.movz       s1, #60
    v.insert     v5, s3, #11
    v.extract    s3, v8, #13
    s.shli       s5, s2, #32
    s.cmp.lt     s2, s4, s1
    v.extract    s1, v17, #14
    s.or         s4, s3, s5
    s.movz       s3, #60
    v.insert     v5, s2, #12
    v.extract    s2, v8, #14
    s.shli       s5, s1, #32
    s.cmp.lt     s1, s4, s3
    v.extract    s3, v17, #15
    s.or         s4, s2, s5
    s.movz       s2, #60
    v.insert     v5, s1, #13
    v.extract    s1, v8, #15
    s.shli       s5, s3, #32
    v.movi       v4, #-2
    s.cmp.lt     s3, s4, s2
    s.or         s2, s1, s5
    s.movz       s1, #60
    v.insert     v5, s3, #14
    v.add        v6, v14, v4
    v.movi       v4, #3
    v.movi       v7, #0
    s.cmp.lt     s3, s2, s1
    v.movi       v8, #0
    v.insert     v5, s3, #15
    v.sub        v12, v7, v6
    v.sub        v14, v7, v4
    v.cmp.lt     p3, v6, v7
    v.cmp.lt     p4, v4, v7
    v.cmp.ne     p5, v5, v8
    .li       s1, #-2
    v.movi       v5, #1
    @p3 v.sel        v8, v12, v6
    @p4 v.sel        v12, v14, v4
    v.movi       v14, #0
    v.movi       v15, #0
    s.movz       s1, #31
idiv_2:
    v.splat      v16, s1
    v.shl        v17, v15, v5
    v.cmp.lt     p4, v15, v7
    v.lshr       v19, v8, v16
    v.shl        v20, v5, v16
    s.subi       s2, s1, #1
    v.and        v16, v19, v5
    s.movz       s3, #0
    v.or         v19, v17, v16
    v.cmp.geu    p6, v19, v12
    p.or         p7, p4, p6
    v.sub        v16, v19, v12
    @p7 v.sel        v17, v20, v7
    @p7 v.sel        v20, v16, v19
    v.or         v16, v14, v17
    v.mov        v15, v20
    v.mov        v14, v16
    s.mov        s1, s2
    s.cmp.ge     s2, s1, s3
    br.nz        s2, idiv_2
    v.sub        v5, v7, v15
    v.movi       v7, #0
    v.movi       v8, #0
    @p3 v.sel        v12, v5, v15
    v.extract    s1, v12, #0
    v.extract    s2, v12, #1
    s.shli       s3, s1, #32
    s.shli       s1, s2, #32
    s.ashri      s2, s3, #32
    v.extract    s3, v12, #2
    s.lshri      s4, s2, #32
    s.ashri      s5, s1, #32
    v.insert     v7, s2, #0
    v.insert     v8, s4, #0
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #3
    s.ashri      s4, s1, #32
    v.insert     v7, s5, #1
    v.insert     v8, s2, #1
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #4
    s.ashri      s5, s1, #32
    v.insert     v7, s4, #2
    v.insert     v8, s2, #2
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #5
    s.ashri      s4, s1, #32
    v.insert     v7, s5, #3
    v.insert     v8, s2, #3
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #6
    s.ashri      s5, s1, #32
    v.insert     v7, s4, #4
    v.insert     v8, s2, #4
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #7
    s.ashri      s4, s1, #32
    v.insert     v7, s5, #5
    v.insert     v8, s2, #5
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #8
    s.ashri      s5, s1, #32
    v.insert     v7, s4, #6
    v.insert     v8, s2, #6
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #9
    s.ashri      s4, s1, #32
    v.insert     v7, s5, #7
    v.insert     v8, s2, #7
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #10
    s.ashri      s5, s1, #32
    v.insert     v7, s4, #8
    v.insert     v8, s2, #8
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #11
    s.ashri      s4, s1, #32
    v.insert     v7, s5, #9
    v.insert     v8, s2, #9
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #12
    s.ashri      s5, s1, #32
    v.insert     v7, s4, #10
    v.insert     v8, s2, #10
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #13
    s.ashri      s4, s1, #32
    v.insert     v7, s5, #11
    v.insert     v8, s2, #11
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v12, #14
    s.ashri      s5, s1, #32
    v.insert     v7, s4, #12
    v.insert     v8, s2, #12
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v12, #15
    s.ashri      s4, s1, #32
    v.insert     v7, s5, #13
    v.insert     v8, s2, #13
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    s.ashri      s3, s1, #32
    v.insert     v7, s4, #14
    v.insert     v8, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v7, s3, #15
    v.insert     v8, s1, #15
    s.movz       s1, #0
    v.extract    s2, v7, #0
    v.extract    s3, v8, #0
    v.extract    s4, v8, #1
    s.shli       s5, s3, #32
    v.movi       v5, #0
    s.or         s3, s2, s5
    v.extract    s2, v7, #1
    s.shli       s5, s4, #32
    s.cmp.eq     s4, s3, s1
    v.extract    s1, v8, #2
    s.or         s3, s2, s5
    s.movz       s2, #0
    v.insert     v5, s4, #0
    v.extract    s4, v7, #2
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s3, s2
    v.extract    s2, v8, #3
    s.or         s3, s4, s5
    s.movz       s4, #0
    v.insert     v5, s1, #1
    v.extract    s1, v7, #3
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s3, s4
    v.extract    s3, v8, #4
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v5, s2, #2
    v.extract    s2, v7, #4
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v8, #5
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v5, s3, #3
    v.extract    s3, v7, #5
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v8, #6
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v5, s1, #4
    v.extract    s1, v7, #6
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    v.extract    s3, v8, #7
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v5, s2, #5
    v.extract    s2, v7, #7
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v8, #8
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v5, s3, #6
    v.extract    s3, v7, #8
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v8, #9
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v5, s1, #7
    v.extract    s1, v7, #9
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    v.extract    s3, v8, #10
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v5, s2, #8
    v.extract    s2, v7, #10
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v8, #11
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v5, s3, #9
    v.extract    s3, v7, #11
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v8, #12
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v5, s1, #10
    v.extract    s1, v7, #12
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    v.extract    s3, v8, #13
    s.or         s4, s1, s5
    s.movz       s1, #0
    v.insert     v5, s2, #11
    v.extract    s2, v7, #13
    s.shli       s5, s3, #32
    s.cmp.eq     s3, s4, s1
    v.extract    s1, v8, #14
    s.or         s4, s2, s5
    s.movz       s2, #0
    v.insert     v5, s3, #12
    v.extract    s3, v7, #14
    s.shli       s5, s1, #32
    s.cmp.eq     s1, s4, s2
    v.extract    s2, v8, #15
    s.or         s4, s3, s5
    s.movz       s3, #0
    v.insert     v5, s1, #13
    v.extract    s1, v7, #15
    s.shli       s5, s2, #32
    s.cmp.eq     s2, s4, s3
    s.or         s3, s1, s5
    s.movz       s1, #0
    v.insert     v5, s2, #14
    s.cmp.eq     s2, s3, s1
    v.movi       v7, #0
    v.insert     v5, s2, #15
    v.movi       v8, #0
    v.sub        v14, v7, v6
    v.sub        v15, v7, v4
    p.and        p3, p1, p5
    v.cmp.ne     p1, v5, v8
    v.cmp.lt     p4, v6, v7
    v.cmp.lt     p5, v4, v7
    p.and        p6, p3, p1
    v.movi       v5, #1
    @p4 v.sel        v8, v14, v6
    @p5 v.sel        v14, v15, v4
    v.movi       v15, #0
    v.movi       v16, #0
    s.movz       s1, #31
idiv_3:
    v.splat      v17, s1
    v.shl        v19, v16, v5
    v.cmp.lt     p1, v16, v7
    v.lshr       v20, v8, v17
    v.shl        v21, v5, v17
    s.subi       s2, s1, #1
    v.and        v17, v20, v5
    s.movz       s3, #0
    v.or         v20, v19, v17
    v.cmp.geu    p3, v20, v14
    p.or         p7, p1, p3
    v.sub        v17, v20, v14
    @p7 v.sel        v19, v21, v7
    @p7 v.sel        v21, v17, v20
    v.or         v17, v15, v19
    v.mov        v16, v21
    v.mov        v15, v17
    s.mov        s1, s2
    s.cmp.ge     s2, s1, s3
    br.nz        s2, idiv_3
    v.sub        v5, v7, v15
    p.xor        p1, p4, p5
    v.movi       v7, #1
    @p1 v.sel        v8, v5, v15
    v.movi       v5, #0
    v.extract    s1, v18, #0
    v.sub        v14, v8, v7
    v.cmp.ne     p1, v12, v5
    v.cmp.lt     p3, v6, v5
    @p1 v.sel        v5, v14, v8
    v.extract    s2, v9, #0
    s.shli       s3, s1, #32
    @p3 v.sel        v6, v5, v8
    v.extract    s1, v18, #1
    v.movi       v5, #2306
    v.mul        v7, v6, v4
    s.or         s4, s2, s3
    s.movz       s2, #128
    v.extract    s3, v9, #1
    s.shli       s5, s1, #32
    s.mul        s1, s4, s2
    v.extract    s2, v18, #2
    v.add        v4, v7, v5
    s.or         s4, s3, s5
    s.movz       s3, #128
    v.extract    s5, v9, #2
    s.shli       s6, s2, #32
    s.mul        s2, s4, s3
    v.add        v5, v4, v13
    v.movi       v4, #0
    v.movi       v6, #0
    s.or         s3, s5, s6
    s.movz       s4, #128
    p.and        p1, p6, p2
    s.lshri      s5, s1, #32
    s.mul        s6, s3, s4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v7, [s7, v5]               // index is in elements (ISA sec 9.1)
    s.lshri      s3, s2, #32
    s.movz       s4, #1
    v.extract    s4, v18, #3
    s.movz       s7, #3
    s.shli       s7, s4, #32
    s.movz       s4, #2306
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v8, [s9, v5]               // index is in elements (ISA sec 9.1)
    v.extract    s4, v9, #3
    v.insert     v4, s1, #0
    v.extract    s1, v18, #4
    v.insert     v6, s5, #0
    s.or         s5, s4, s7
    s.movz       s4, #128
    v.extract    s7, v9, #4
    s.shli       s8, s1, #32
    s.mul        s1, s5, s4
    v.insert     v4, s2, #1
    v.insert     v6, s3, #1
    s.or         s2, s7, s8
    s.lshri      s3, s6, #32
    v.insert     v4, s6, #2
    v.insert     v6, s3, #2
    s.lshri      s3, s1, #32
    v.insert     v4, s1, #3
    v.insert     v6, s3, #3
    @p6 v.sel        v5, v7, v3
    s.movz       s1, #128
    @p6 v.sel        v3, v8, v11
    vf.mul       v7, v1, v5
    s.mul        s3, s2, s1
    vf.mul       v1, v0, v3
    s.lshri      s1, s3, #32
    v.insert     v4, s3, #4
    v.insert     v6, s1, #4
    vf.add       v0, v7, v1
    v.extract    s1, v18, #5
    v.extract    s2, v9, #5
    s.shli       s3, s1, #32
    v.extract    s1, v18, #6
    s.or         s4, s2, s3
    s.movz       s2, #128
    v.extract    s3, v9, #6
    s.shli       s5, s1, #32
    s.mul        s1, s4, s2
    v.extract    s2, v18, #7
    s.or         s4, s3, s5
    s.movz       s3, #128
    v.extract    s5, v9, #7
    s.shli       s6, s2, #32
    s.mul        s2, s4, s3
    v.extract    s3, v18, #8
    s.or         s4, s5, s6
    s.movz       s5, #128
    s.lshri      s6, s1, #32
    v.extract    s7, v9, #8
    s.shli       s8, s3, #32
    s.mul        s3, s4, s5
    v.extract    s4, v18, #9
    v.insert     v4, s1, #5
    v.insert     v6, s6, #5
    s.or         s1, s7, s8
    s.movz       s5, #128
    s.lshri      s6, s2, #32
    v.extract    s7, v9, #9
    s.shli       s8, s4, #32
    s.mul        s4, s1, s5
    v.extract    s1, v18, #10
    v.insert     v4, s2, #6
    v.insert     v6, s6, #6
    s.or         s2, s7, s8
    s.movz       s5, #128
    s.lshri      s6, s3, #32
    v.extract    s7, v9, #10
    s.shli       s8, s1, #32
    s.mul        s1, s2, s5
    v.extract    s2, v18, #11
    v.insert     v4, s3, #7
    v.insert     v6, s6, #7
    s.or         s3, s7, s8
    s.movz       s5, #128
    s.lshri      s6, s4, #32
    v.extract    s7, v9, #11
    s.shli       s8, s2, #32
    s.mul        s2, s3, s5
    v.extract    s3, v18, #12
    v.insert     v4, s4, #8
    v.insert     v6, s6, #8
    s.or         s4, s7, s8
    s.movz       s5, #128
    s.lshri      s6, s1, #32
    v.extract    s7, v9, #12
    s.shli       s8, s3, #32
    s.mul        s3, s4, s5
    v.extract    s4, v18, #13
    v.insert     v4, s1, #9
    v.insert     v6, s6, #9
    s.or         s1, s7, s8
    s.movz       s5, #128
    s.lshri      s6, s2, #32
    v.extract    s7, v9, #13
    s.shli       s8, s4, #32
    s.mul        s4, s1, s5
    v.extract    s1, v18, #14
    v.insert     v4, s2, #10
    v.insert     v6, s6, #10
    s.or         s2, s7, s8
    s.movz       s5, #128
    s.lshri      s6, s3, #32
    v.extract    s7, v9, #14
    s.shli       s8, s1, #32
    s.mul        s1, s2, s5
    v.extract    s2, v18, #15
    v.insert     v4, s3, #11
    v.insert     v6, s6, #11
    s.or         s3, s7, s8
    s.movz       s5, #128
    s.lshri      s6, s4, #32
    v.extract    s7, v9, #15
    s.shli       s8, s2, #32
    s.mul        s2, s3, s5
    v.insert     v4, s4, #12
    v.insert     v6, s6, #12
    s.or         s3, s7, s8
    s.movz       s4, #128
    s.lshri      s5, s1, #32
    v.extract    s6, v10, #0
    s.mul        s7, s3, s4
    v.insert     v4, s1, #13
    v.insert     v6, s5, #13
    s.shli       s1, s6, #32
    s.lshri      s3, s2, #32
    v.extract    s4, v10, #1
    s.ashri      s5, s1, #32
    v.insert     v4, s2, #14
    v.insert     v6, s3, #14
    v.movi       v1, #0
    v.movi       v3, #0
    s.shli       s1, s4, #32
    s.lshri      s2, s7, #32
    s.lshri      s3, s5, #32
    v.extract    s4, v10, #2
    s.ashri      s6, s1, #32
    v.insert     v4, s7, #15
    v.insert     v6, s2, #15
    v.insert     v1, s5, #0
    v.insert     v3, s3, #0
    s.shli       s1, s4, #32
    s.lshri      s2, s6, #32
    v.extract    s3, v10, #3
    s.ashri      s4, s1, #32
    v.insert     v1, s6, #1
    v.insert     v3, s2, #1
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v10, #4
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #2
    v.insert     v3, s2, #2
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v10, #5
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #3
    v.insert     v3, s2, #3
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v10, #6
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #4
    v.insert     v3, s2, #4
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v10, #7
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #5
    v.insert     v3, s2, #5
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v10, #8
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #6
    v.insert     v3, s2, #6
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v10, #9
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #7
    v.insert     v3, s2, #7
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v10, #10
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #8
    v.insert     v3, s2, #8
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v10, #11
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #9
    v.insert     v3, s2, #9
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v10, #12
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #10
    v.insert     v3, s2, #10
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v10, #13
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #11
    v.insert     v3, s2, #11
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v10, #14
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #12
    v.insert     v3, s2, #12
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v10, #15
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #13
    v.insert     v3, s2, #13
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    s.ashri      s3, s1, #32
    v.insert     v1, s4, #14
    v.insert     v3, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v1, s3, #15
    v.insert     v3, s1, #15
    v.extract    s1, v6, #0
    v.extract    s2, v1, #0
    v.extract    s3, v3, #0
    v.extract    s4, v4, #0
    s.shli       s5, s3, #32
    s.shli       s3, s1, #32
    v.extract    s1, v3, #1
    v.extract    s6, v6, #1
    s.or         s7, s2, s5
    s.or         s2, s4, s3
    v.extract    s3, v1, #1
    s.shli       s4, s1, #32
    v.extract    s1, v4, #1
    s.shli       s5, s6, #32
    s.add        s6, s7, s2
    v.extract    s2, v3, #2
    v.extract    s7, v6, #2
    v.movi       v5, #0
    v.movi       v7, #0
    s.or         s8, s3, s4
    s.or         s3, s1, s5
    s.lshri      s1, s6, #32
    v.extract    s4, v1, #2
    s.shli       s5, s2, #32
    s.shli       s2, s7, #32
    s.add        s7, s8, s3
    v.extract    s3, v4, #2
    v.insert     v5, s6, #0
    v.extract    s6, v3, #3
    v.insert     v7, s1, #0
    v.extract    s1, v6, #3
    s.or         s8, s4, s5
    s.or         s4, s3, s2
    s.lshri      s2, s7, #32
    v.extract    s3, v1, #3
    s.shli       s5, s6, #32
    s.shli       s6, s1, #32
    s.add        s1, s8, s4
    v.extract    s4, v4, #3
    v.insert     v5, s7, #1
    v.extract    s7, v3, #4
    v.insert     v7, s2, #1
    v.extract    s2, v6, #4
    s.or         s8, s3, s5
    s.or         s3, s4, s6
    s.lshri      s4, s1, #32
    v.extract    s5, v1, #4
    s.shli       s6, s7, #32
    s.shli       s7, s2, #32
    s.add        s2, s8, s3
    v.extract    s3, v4, #4
    v.insert     v5, s1, #2
    v.extract    s1, v3, #5
    v.insert     v7, s4, #2
    v.extract    s4, v6, #5
    s.or         s8, s5, s6
    s.or         s5, s3, s7
    s.lshri      s3, s2, #32
    v.extract    s6, v1, #5
    s.shli       s7, s1, #32
    s.shli       s1, s4, #32
    s.add        s4, s8, s5
    v.extract    s5, v4, #5
    v.insert     v5, s2, #3
    v.extract    s2, v3, #6
    v.insert     v7, s3, #3
    v.extract    s3, v6, #6
    s.or         s8, s6, s7
    s.or         s6, s5, s1
    s.lshri      s1, s4, #32
    v.extract    s5, v1, #6
    s.shli       s7, s2, #32
    s.shli       s2, s3, #32
    s.add        s3, s8, s6
    v.extract    s6, v4, #6
    v.insert     v5, s4, #4
    v.extract    s4, v3, #7
    v.insert     v7, s1, #4
    v.extract    s1, v6, #7
    s.or         s8, s5, s7
    s.or         s5, s6, s2
    s.lshri      s2, s3, #32
    v.extract    s6, v1, #7
    s.shli       s7, s4, #32
    s.shli       s4, s1, #32
    s.add        s1, s8, s5
    v.extract    s5, v4, #7
    v.insert     v5, s3, #5
    v.extract    s3, v3, #8
    v.insert     v7, s2, #5
    v.extract    s2, v6, #8
    s.or         s8, s6, s7
    s.or         s6, s5, s4
    s.lshri      s4, s1, #32
    v.extract    s5, v1, #8
    s.shli       s7, s3, #32
    s.shli       s3, s2, #32
    s.add        s2, s8, s6
    v.extract    s6, v4, #8
    v.insert     v5, s1, #6
    v.extract    s1, v3, #9
    v.insert     v7, s4, #6
    v.extract    s4, v6, #9
    s.or         s8, s5, s7
    s.or         s5, s6, s3
    s.lshri      s3, s2, #32
    v.extract    s6, v1, #9
    s.shli       s7, s1, #32
    s.shli       s1, s4, #32
    s.add        s4, s8, s5
    v.extract    s5, v4, #9
    v.insert     v5, s2, #7
    v.extract    s2, v3, #10
    v.insert     v7, s3, #7
    v.extract    s3, v6, #10
    s.or         s8, s6, s7
    s.or         s6, s5, s1
    s.lshri      s1, s4, #32
    v.extract    s5, v1, #10
    s.shli       s7, s2, #32
    s.shli       s2, s3, #32
    s.add        s3, s8, s6
    v.extract    s6, v4, #10
    v.insert     v5, s4, #8
    v.extract    s4, v3, #11
    v.insert     v7, s1, #8
    v.extract    s1, v6, #11
    s.or         s8, s5, s7
    s.or         s5, s6, s2
    s.lshri      s2, s3, #32
    v.extract    s6, v1, #11
    s.shli       s7, s4, #32
    s.shli       s4, s1, #32
    s.add        s1, s8, s5
    v.extract    s5, v4, #11
    v.insert     v5, s3, #9
    v.extract    s3, v3, #12
    v.insert     v7, s2, #9
    v.extract    s2, v6, #12
    s.or         s8, s6, s7
    s.or         s6, s5, s4
    s.lshri      s4, s1, #32
    v.extract    s5, v1, #12
    s.shli       s7, s3, #32
    s.shli       s3, s2, #32
    s.add        s2, s8, s6
    v.extract    s6, v4, #12
    v.insert     v5, s1, #10
    v.extract    s1, v3, #13
    v.insert     v7, s4, #10
    v.extract    s4, v6, #13
    s.or         s8, s5, s7
    s.or         s5, s6, s3
    s.lshri      s3, s2, #32
    v.extract    s6, v1, #13
    s.shli       s7, s1, #32
    s.shli       s1, s4, #32
    s.add        s4, s8, s5
    v.extract    s5, v4, #13
    v.insert     v5, s2, #11
    v.extract    s2, v3, #14
    v.insert     v7, s3, #11
    v.movi       v8, #8192
    v.extract    s3, v6, #14
    s.or         s8, s6, s7
    s.or         s6, s5, s1
    s.lshri      s1, s4, #32
    v.extract    s5, v1, #14
    s.shli       s7, s2, #32
    s.shli       s2, s3, #32
    v.mul        v9, v2, v8
    s.add        s3, s8, s6
    v.extract    s6, v4, #14
    v.insert     v5, s4, #12
    v.extract    s4, v3, #15
    v.insert     v7, s1, #12
    v.extract    s1, v6, #15
    s.or         s8, s5, s7
    s.or         s5, s6, s2
    s.lshri      s2, s3, #32
    v.extract    s6, v1, #15
    s.shli       s7, s4, #32
    s.shli       s4, s1, #32
    s.add        s1, s8, s5
    v.extract    s5, v4, #15
    v.insert     v5, s3, #13
    v.extract    s3, v9, #0
    v.insert     v7, s2, #13
    s.or         s2, s6, s7
    s.or         s6, s5, s4
    s.shli       s4, s3, #32
    s.lshri      s3, s1, #32
    v.extract    s5, v9, #1
    s.add        s7, s2, s6
    s.ashri      s2, s4, #32
    v.insert     v5, s1, #14
    v.insert     v7, s3, #14
    v.movi       v1, #0
    v.movi       v2, #0
    s.shli       s1, s5, #32
    s.lshri      s3, s7, #32
    s.lshri      s4, s2, #32
    v.extract    s5, v9, #2
    s.ashri      s6, s1, #32
    v.insert     v5, s7, #15
    v.insert     v7, s3, #15
    v.insert     v1, s2, #0
    v.insert     v2, s4, #0
    s.shli       s1, s5, #32
    s.lshri      s2, s6, #32
    v.extract    s3, v9, #3
    s.ashri      s4, s1, #32
    v.insert     v1, s6, #1
    v.insert     v2, s2, #1
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #4
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #2
    v.insert     v2, s2, #2
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #5
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #3
    v.insert     v2, s2, #3
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #6
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #4
    v.insert     v2, s2, #4
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #7
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #5
    v.insert     v2, s2, #5
    s.lshri      s1, s4, #32
    v.insert     v1, s4, #6
    v.insert     v2, s1, #6
    s.movz       s1, #8192
    s.shli       s1, s3, #32
    v.extract    s2, v9, #8
    s.ashri      s3, s1, #32
    s.shli       s1, s2, #32
    s.lshri      s2, s3, #32
    v.extract    s4, v9, #9
    s.ashri      s5, s1, #32
    v.insert     v1, s3, #7
    v.insert     v2, s2, #7
    s.shli       s1, s4, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #10
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #8
    v.insert     v2, s2, #8
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #11
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #9
    v.insert     v2, s2, #9
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #12
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #10
    v.insert     v2, s2, #10
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #13
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #11
    v.insert     v2, s2, #11
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    v.extract    s3, v9, #14
    s.ashri      s4, s1, #32
    v.insert     v1, s5, #12
    v.insert     v2, s2, #12
    s.shli       s1, s3, #32
    s.lshri      s2, s4, #32
    v.extract    s3, v9, #15
    s.ashri      s5, s1, #32
    v.insert     v1, s4, #13
    v.insert     v2, s2, #13
    s.shli       s1, s3, #32
    s.lshri      s2, s5, #32
    s.ashri      s3, s1, #32
    v.insert     v1, s5, #14
    v.insert     v2, s2, #14
    s.lshri      s1, s3, #32
    v.insert     v1, s3, #15
    v.insert     v2, s1, #15
    v.extract    s1, v7, #0
    v.extract    s2, v5, #0
    v.extract    s3, v2, #0
    s.shli       s4, s1, #32
    v.extract    s1, v1, #0
    s.shli       s5, s3, #32
    v.extract    s3, v7, #1
    v.extract    s6, v2, #1
    s.or         s7, s2, s4
    s.or         s2, s1, s5
    v.movi       v3, #0
    v.extract    s1, v5, #1
    s.shli       s4, s3, #32
    v.extract    s3, v1, #1
    s.shli       s5, s6, #32
    s.add        s6, s7, s2
    v.extract    s2, v7, #2
    v.extract    s7, v2, #2
    s.or         s8, s1, s4
    s.or         s1, s3, s5
    v.movi       v4, #0
    v.insert     v3, s6, #0
    v.extract    s3, v5, #2
    s.shli       s4, s2, #32
    v.extract    s2, v1, #2
    s.shli       s5, s7, #32
    s.lshri      s7, s6, #32
    s.add        s6, s8, s1
    v.extract    s1, v7, #3
    s.or         s8, s3, s4
    v.extract    s3, v2, #3
    s.or         s4, s2, s5
    v.insert     v4, s7, #0
    v.insert     v3, s6, #1
    v.extract    s2, v5, #3
    s.shli       s5, s1, #32
    v.extract    s1, v1, #3
    s.shli       s7, s3, #32
    s.lshri      s3, s6, #32
    s.add        s6, s8, s4
    v.extract    s4, v7, #4
    s.or         s8, s2, s5
    v.extract    s2, v2, #4
    s.or         s5, s1, s7
    v.insert     v4, s3, #1
    v.insert     v3, s6, #2
    v.extract    s1, v5, #4
    s.shli       s3, s4, #32
    v.extract    s4, v1, #4
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s5
    v.extract    s5, v7, #5
    s.or         s8, s1, s3
    v.extract    s1, v2, #5
    s.or         s3, s4, s7
    v.insert     v4, s2, #2
    v.insert     v3, s6, #3
    v.extract    s2, v5, #5
    s.shli       s4, s5, #32
    v.extract    s5, v1, #5
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s3
    v.extract    s3, v7, #6
    s.or         s8, s2, s4
    v.extract    s2, v2, #6
    s.or         s4, s5, s7
    v.insert     v4, s1, #3
    v.insert     v3, s6, #4
    v.extract    s1, v5, #6
    s.shli       s5, s3, #32
    v.extract    s3, v1, #6
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s4
    v.extract    s4, v7, #7
    s.or         s8, s1, s5
    v.extract    s1, v2, #7
    s.or         s5, s3, s7
    v.insert     v4, s2, #4
    v.insert     v3, s6, #5
    v.extract    s2, v5, #7
    s.shli       s3, s4, #32
    v.extract    s4, v1, #7
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s5
    v.extract    s5, v7, #8
    s.or         s8, s2, s3
    v.extract    s2, v2, #8
    s.or         s3, s4, s7
    v.insert     v4, s1, #5
    v.insert     v3, s6, #6
    v.extract    s1, v5, #8
    s.shli       s4, s5, #32
    v.extract    s5, v1, #8
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s3
    v.extract    s3, v7, #9
    s.or         s8, s1, s4
    v.extract    s1, v2, #9
    s.or         s4, s5, s7
    v.insert     v4, s2, #6
    v.insert     v3, s6, #7
    v.extract    s2, v5, #9
    s.shli       s5, s3, #32
    v.extract    s3, v1, #9
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s4
    v.extract    s4, v7, #10
    s.or         s8, s2, s5
    v.extract    s2, v2, #10
    s.or         s5, s3, s7
    v.insert     v4, s1, #7
    v.insert     v3, s6, #8
    v.extract    s1, v5, #10
    s.shli       s3, s4, #32
    v.extract    s4, v1, #10
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s5
    v.extract    s5, v7, #11
    s.or         s8, s1, s3
    v.extract    s1, v2, #11
    s.or         s3, s4, s7
    v.insert     v4, s2, #8
    v.insert     v3, s6, #9
    v.extract    s2, v5, #11
    s.shli       s4, s5, #32
    v.extract    s5, v1, #11
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s3
    v.extract    s3, v7, #12
    s.or         s8, s2, s4
    v.extract    s2, v2, #12
    s.or         s4, s5, s7
    v.insert     v4, s1, #9
    v.insert     v3, s6, #10
    v.extract    s1, v5, #12
    s.shli       s5, s3, #32
    v.extract    s3, v1, #12
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s4
    v.extract    s4, v7, #13
    s.or         s8, s1, s5
    v.extract    s1, v2, #13
    s.or         s5, s3, s7
    v.insert     v4, s2, #10
    v.insert     v3, s6, #11
    v.extract    s2, v5, #13
    s.shli       s3, s4, #32
    v.extract    s4, v1, #13
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s5
    v.extract    s5, v7, #14
    s.or         s8, s2, s3
    v.extract    s2, v2, #14
    s.or         s3, s4, s7
    v.insert     v4, s1, #11
    v.insert     v3, s6, #12
    v.extract    s1, v5, #14
    s.shli       s4, s5, #32
    v.extract    s5, v1, #14
    s.shli       s7, s2, #32
    s.lshri      s2, s6, #32
    s.add        s6, s8, s3
    v.extract    s3, v7, #15
    s.or         s8, s1, s4
    v.extract    s1, v2, #15
    s.or         s4, s5, s7
    v.insert     v4, s2, #12
    v.insert     v3, s6, #13
    v.extract    s2, v5, #15
    s.shli       s5, s3, #32
    v.extract    s3, v1, #15
    s.shli       s7, s1, #32
    s.lshri      s1, s6, #32
    s.add        s6, s8, s4
    s.or         s4, s2, s5
    s.or         s2, s3, s7
    v.insert     v4, s1, #13
    v.insert     v3, s6, #14
    s.lshri      s1, s6, #32
    s.add        s3, s4, s2
    v.insert     v4, s1, #14
    v.insert     v3, s3, #15
    v.movi       v1, #31
    s.lshri      s1, s3, #32
    v.movi       v2, #1
    v.insert     v4, s1, #15
    v.ashr       v5, v3, v1
    v.movi       v1, #0
    s.movz       s1, #0
    v.cmp.ne     p1, v4, v5
    @p1 v.sel        v4, v2, v1
    v.reduce.or  s2, v4
    s.cmp.eq     s3, s2, s1
    br.nz        s3, narrow_ok_4
    trap         #677220
narrow_ok_4:
    vf.cvt.f32.bf16 v1, v0
    @p2 v.st.scatter.h [s10, v3], v1
__rctx_next:
    exit
