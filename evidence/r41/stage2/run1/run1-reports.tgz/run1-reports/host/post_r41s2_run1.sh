#!/bin/bash
# Waits for full run 1 to end, then runs the read-only post-route analysis (2 threads) through
# the Stage 2 vivado slot (>= 20 GB available). Never touches the card.
B=$HOME/tnca_build/r41s2_run1_c9f25787494a
SRC=$HOME/tnca_src_r41s2_run1_c9f25787494a
A=$B/analysis
while [ ! -f $B/build/attempt.exit ]; do sleep 120; done
mkdir -p $A.d
log=$A.d/post.log
echo "$(date -u +%FT%TZ) attempt exit $(cat $B/build/attempt.exit)" >> $log
I=$B/xo/tmp/link/vivado/vpl/prj/prj.runs/impl_1
DCP=$(ls $I/level0_wrapper_postroute_physopt.dcp 2>/dev/null || ls $I/level0_wrapper_routed.dcp 2>/dev/null)
[ -n "$DCP" ] || { echo "no routed dcp" >> $log; ls $I >> $log 2>&1; echo FAIL > $A.d/post.exit; exit 1; }
echo "dcp $DCP $(sha256sum $DCP | cut -c1-64)" >> $log
bash $SRC/evidence/r41/stage2/launches/vivado_slot.sh --min-gb 20 $log -- \
  vivado -mode batch -nojournal -log $A.d/vivado.log -source $HOME/tnca_build/analyze_run1.tcl -tclargs $DCP $A
echo $? > $A.d/post.exit
