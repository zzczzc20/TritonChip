    s.rdspecial  s1, arg_base
    s.rdspecial  s2, arg_base
    s.ld.d       s3, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    .li       s1, #4286578688
    v.splat      v0, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v1, #0
    .li       s1, #2147483647
    v.splat      v2, s1                          // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.movi       v3, #0
    s.movz       s1, #32000
    s.movz       s4, #2
    s.movz       s5, #16
    .li       s6, #4294967296
    s.movz       s7, #0
    v.iota       v4                              // arange(0, VLEN)
    s.ld.d       s8, [s2, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.addi       s9, s3, #0                      // TensorMap 0: tl.make_tensor_descriptor (rank 1)
    s.movz       s3, #0
    s.movz       s3, #32000
    s.addi       s10, s7, #0
    s.ld.d       s7, [s2, #8]                    // out_ptr0: device_ptr64 at arg_base+8
    s.st.d       [s9, #0], s8
    s.st.d       [s9, #8], s1
    s.movz       s1, #16
    s.st.d       [s9, #48], s4
    s.st.d       [s9, #88], s5
    s.st.d       [s9, #104], s6
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    v.mov        v1, v0
    v.mov        v3, v2
for_1:
    s.cmp.ge     s2, s10, s3
    br.nz        s2, endfor_2
    v.splat      v0, s10
    v.iota       v2                              // arange(0, VLEN)
    s.movz       s2, #32000
    s.muli       s4, s10, #2
    v.add        v5, v0, v2
    v.movi       v0, #0
    v.splat      v2, s2
    v.movi       v6, #-1
    v.cmp.ge     p1, v5, v0
    v.cmp.lt     p2, v5, v2
    s.add        s2, s8, s4
    p.and        p3, p1, p2
    v.movi       v0, #0
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v2, [s2, #0]
    v.splat      v5, s10
    vf.cmp.ne    p1, v1, v1
    v.cmp.ne     p2, v6, v0
    v.add        v0, v5, v4
    v.movi       v5, #32000
    v.movi       v6, #0
    v.cmp.lt     p3, v3, v0
    v.cmp.lt     p4, v0, v5
    v.movi       v5, #0
    s.add        s2, s10, s1
    s.movz       s4, #1
    vf.cvt.f16.f32 v7, v2
    vf.cmp.ne    p5, v7, v7
    p.xor        p6, p5, p2
    p.and        p2, p1, p5
    vf.cmp.eq    p5, v1, v7
    p.and        p7, p1, p6
    p.or         p1, p5, p2
    vf.cmp.gt    p2, v1, v7
    p.or         p5, p2, p7
    p.and        p2, p1, p3
    p.or         p1, p5, p2
    @p1 v.sel        v2, v1, v7
    @p1 v.sel        v7, v3, v0
    @p4 v.sel        v0, v2, v1
    @p4 v.sel        v2, v7, v3
    v.mov        v6, v0
    v.mov        v5, v2
    v.mov        v1, v6
    v.mov        v3, v5
    s.mov        s10, s2
    br.nz        s4, for_1
endfor_2:
    v.extract    s1, v1, #0
    v.extract    s2, v1, #1
    v.splat      v0, s1
    v.splat      v2, s2
    v.extract    s1, v3, #0
    v.extract    s2, v3, #1
    v.splat      v4, s1
    v.splat      v5, s2
    v.extract    s1, v1, #2
    v.extract    s2, v3, #2
    v.splat      v6, s1
    v.splat      v7, s2
    v.extract    s1, v1, #3
    v.extract    s2, v3, #3
    v.splat      v8, s1
    v.splat      v9, s2
    v.extract    s1, v1, #4
    v.extract    s2, v3, #4
    v.splat      v10, s1
    v.splat      v11, s2
    v.extract    s1, v1, #5
    v.extract    s2, v3, #5
    v.splat      v12, s1
    v.splat      v13, s2
    v.extract    s1, v1, #6
    v.extract    s2, v3, #6
    v.splat      v14, s1
    v.splat      v15, s2
    v.extract    s1, v1, #7
    v.extract    s2, v3, #7
    v.splat      v16, s1
    v.splat      v17, s2
    v.extract    s1, v1, #8
    vf.cmp.gt    p1, v0, v2
    v.splat      v18, s1
    vf.cmp.eq    p2, v0, v2
    v.extract    s1, v3, #8
    v.extract    s2, v1, #9
    vf.cmp.ne    p3, v0, v0
    v.splat      v19, s1
    v.splat      v20, s2
    vf.cmp.ne    p4, v2, v2
    v.extract    s1, v3, #9
    v.extract    s2, v1, #10
    .li       s3, #-1
    v.splat      v21, s1
    v.splat      v22, s2
    v.splat      v23, s3
    v.extract    s1, v3, #10
    v.extract    s2, v1, #11
    v.movi       v24, #0
    v.splat      v25, s1
    v.splat      v26, s2
    v.cmp.ne     p5, v23, v24
    v.extract    s1, v3, #11
    v.extract    s2, v1, #12
    p.xor        p6, p4, p5
    v.splat      v23, s1
    v.splat      v24, s2
    p.and        p5, p3, p6
    v.extract    s1, v3, #12
    v.extract    s2, v1, #13
    p.or         p6, p1, p5
    v.splat      v27, s1
    v.splat      v28, s2
    p.and        p1, p3, p4
    v.extract    s1, v3, #13
    v.extract    s2, v1, #14
    p.or         p3, p2, p1
    v.splat      v29, s1
    v.splat      v30, s2
    v.cmp.lt     p1, v4, v5
    v.extract    s1, v3, #14
    v.extract    s2, v1, #15
    p.and        p2, p3, p1
    v.splat      v1, s1
    v.splat      v31, s2
    p.or         p1, p6, p2
    v.splat      v32, s3
    @p1 v.sel        v33, v0, v2
    v.movi       v0, #0
    vf.cmp.ne    p2, v6, v6
    vf.cmp.ne    p3, v33, v33
    v.cmp.ne     p4, v32, v0
    @p1 v.sel        v0, v4, v5
    p.xor        p1, p2, p4
    p.and        p4, p3, p2
    vf.cmp.eq    p2, v33, v6
    p.and        p5, p3, p1
    p.or         p1, p2, p4
    vf.cmp.gt    p2, v33, v6
    v.cmp.lt     p3, v0, v7
    p.or         p4, p2, p5
    p.and        p2, p1, p3
    v.splat      v2, s3
    p.or         p1, p4, p2
    v.movi       v4, #0
    @p1 v.sel        v5, v33, v6
    vf.cmp.ne    p2, v8, v8
    v.cmp.ne     p3, v2, v4
    vf.cmp.ne    p4, v5, v5
    @p1 v.sel        v2, v0, v7
    p.xor        p1, p2, p3
    p.and        p3, p4, p2
    vf.cmp.eq    p2, v5, v8
    p.and        p5, p4, p1
    vf.cmp.gt    p1, v5, v8
    p.or         p4, p1, p5
    v.extract    s1, v3, #15
    p.or         p1, p2, p3
    v.splat      v0, s1
    v.cmp.lt     p2, v2, v9
    p.and        p3, p1, p2
    v.splat      v3, s3
    p.or         p1, p4, p3
    v.movi       v4, #0
    @p1 v.sel        v6, v5, v8
    vf.cmp.ne    p2, v10, v10
    v.cmp.ne     p3, v3, v4
    vf.cmp.ne    p4, v6, v6
    @p1 v.sel        v3, v2, v9
    p.xor        p1, p2, p3
    p.and        p3, p4, p2
    vf.cmp.eq    p2, v6, v10
    p.and        p5, p4, p1
    p.or         p1, p2, p3
    vf.cmp.gt    p2, v6, v10
    v.cmp.lt     p3, v3, v11
    p.or         p4, p2, p5
    p.and        p2, p1, p3
    v.splat      v2, s3
    p.or         p1, p4, p2
    v.movi       v4, #0
    @p1 v.sel        v5, v6, v10
    vf.cmp.ne    p2, v12, v12
    v.cmp.ne     p3, v2, v4
    vf.cmp.ne    p4, v5, v5
    @p1 v.sel        v2, v3, v11
    p.xor        p1, p2, p3
    p.and        p3, p4, p2
    vf.cmp.eq    p2, v5, v12
    p.and        p5, p4, p1
    p.or         p1, p2, p3
    vf.cmp.gt    p2, v5, v12
    v.cmp.lt     p3, v2, v13
    p.or         p4, p2, p5
    p.and        p2, p1, p3
    v.splat      v3, s3
    p.or         p1, p4, p2
    v.movi       v4, #0
    @p1 v.sel        v6, v5, v12
    vf.cmp.ne    p2, v14, v14
    v.cmp.ne     p3, v3, v4
    vf.cmp.ne    p4, v6, v6
    @p1 v.sel        v3, v2, v13
    p.xor        p1, p2, p3
    p.and        p3, p4, p2
    vf.cmp.eq    p2, v6, v14
    p.and        p5, p4, p1
    p.or         p1, p2, p3
    vf.cmp.gt    p2, v6, v14
    v.cmp.lt     p3, v3, v15
    p.or         p4, p2, p5
    p.and        p2, p1, p3
    v.splat      v2, s3
    p.or         p1, p4, p2
    v.movi       v4, #0
    @p1 v.sel        v5, v6, v14
    vf.cmp.ne    p2, v16, v16
    v.cmp.ne     p3, v2, v4
    vf.cmp.ne    p4, v5, v5
    @p1 v.sel        v2, v3, v15
    p.xor        p1, p2, p3
    p.and        p3, p4, p2
    vf.cmp.eq    p2, v5, v16
    p.and        p5, p4, p1
    p.or         p1, p2, p3
    vf.cmp.gt    p2, v5, v16
    v.cmp.lt     p3, v2, v17
    p.or         p4, p2, p5
    p.and        p2, p1, p3
    v.splat      v3, s3
    p.or         p1, p4, p2
    v.movi       v4, #0
    @p1 v.sel        v6, v5, v16
    vf.cmp.ne    p2, v18, v18
    v.cmp.ne     p3, v3, v4
    vf.cmp.ne    p4, v6, v6
    @p1 v.sel        v3, v2, v17
    p.xor        p1, p2, p3
    p.and        p3, p4, p2
    vf.cmp.eq    p2, v6, v18
    p.and        p5, p4, p1
    p.or         p1, p2, p3
    vf.cmp.gt    p2, v6, v18
    v.cmp.lt     p3, v3, v19
    p.or         p4, p2, p5
    p.and        p2, p1, p3
    v.splat      v2, s3
    p.or         p1, p4, p2
    v.movi       v4, #0
    @p1 v.sel        v5, v6, v18
    vf.cmp.ne    p2, v20, v20
    v.cmp.ne     p3, v2, v4
    vf.cmp.ne    p4, v5, v5
    @p1 v.sel        v2, v3, v19
    p.xor        p1, p2, p3
    p.and        p3, p4, p2
    vf.cmp.eq    p2, v5, v20
    p.and        p5, p4, p1
    p.or         p1, p2, p3
    vf.cmp.gt    p2, v5, v20
    v.cmp.lt     p3, v2, v21
    p.or         p4, p2, p5
    p.and        p2, p1, p3
    v.splat      v3, s3
    p.or         p1, p4, p2
    v.movi       v4, #0
    @p1 v.sel        v6, v5, v20
    vf.cmp.ne    p2, v22, v22
    v.cmp.ne     p3, v3, v4
    vf.cmp.ne    p4, v6, v6
    @p1 v.sel        v3, v2, v21
    p.xor        p1, p2, p3
    p.and        p3, p4, p2
    vf.cmp.eq    p2, v6, v22
    p.and        p5, p4, p1
    p.or         p1, p2, p3
    vf.cmp.gt    p2, v6, v22
    v.cmp.lt     p3, v3, v25
    p.or         p4, p2, p5
    p.and        p2, p1, p3
    v.splat      v2, s3
    p.or         p1, p4, p2
    v.movi       v4, #0
    @p1 v.sel        v5, v6, v22
    vf.cmp.ne    p2, v26, v26
    v.cmp.ne     p3, v2, v4
    vf.cmp.ne    p4, v5, v5
    @p1 v.sel        v2, v3, v25
    p.xor        p1, p2, p3
    p.and        p3, p4, p2
    vf.cmp.eq    p2, v5, v26
    p.and        p5, p4, p1
    p.or         p1, p2, p3
    vf.cmp.gt    p2, v5, v26
    v.cmp.lt     p3, v2, v23
    p.or         p4, p2, p5
    p.and        p2, p1, p3
    v.splat      v3, s3
    p.or         p1, p4, p2
    v.movi       v4, #0
    @p1 v.sel        v6, v5, v26
    vf.cmp.ne    p2, v24, v24
    v.cmp.ne     p3, v3, v4
    vf.cmp.ne    p4, v6, v6
    @p1 v.sel        v3, v2, v23
    p.xor        p1, p2, p3
    p.and        p3, p4, p2
    vf.cmp.eq    p2, v6, v24
    p.and        p5, p4, p1
    p.or         p1, p2, p3
    vf.cmp.gt    p2, v6, v24
    v.cmp.lt     p3, v3, v27
    p.or         p4, p2, p5
    p.and        p2, p1, p3
    v.splat      v2, s3
    p.or         p1, p4, p2
    v.movi       v4, #0
    @p1 v.sel        v5, v6, v24
    vf.cmp.ne    p2, v28, v28
    v.cmp.ne     p3, v2, v4
    vf.cmp.ne    p4, v5, v5
    @p1 v.sel        v2, v3, v27
    p.xor        p1, p2, p3
    p.and        p3, p4, p2
    vf.cmp.eq    p2, v5, v28
    p.and        p5, p4, p1
    p.or         p1, p2, p3
    vf.cmp.gt    p2, v5, v28
    v.cmp.lt     p3, v2, v29
    p.or         p4, p2, p5
    p.and        p2, p1, p3
    v.splat      v3, s3
    p.or         p1, p4, p2
    v.movi       v4, #0
    @p1 v.sel        v6, v5, v28
    vf.cmp.ne    p2, v30, v30
    v.cmp.ne     p3, v3, v4
    vf.cmp.ne    p4, v6, v6
    @p1 v.sel        v3, v2, v29
    p.xor        p1, p2, p3
    p.and        p3, p4, p2
    vf.cmp.eq    p2, v6, v30
    p.and        p5, p4, p1
    p.or         p1, p2, p3
    vf.cmp.gt    p2, v6, v30
    v.cmp.lt     p3, v3, v1
    p.or         p4, p2, p5
    p.and        p2, p1, p3
    v.splat      v2, s3
    p.or         p1, p4, p2
    v.movi       v4, #0
    @p1 v.sel        v5, v6, v30
    vf.cmp.ne    p2, v31, v31
    v.cmp.ne     p3, v2, v4
    vf.cmp.ne    p4, v5, v5
    @p1 v.sel        v2, v3, v1
    p.xor        p1, p2, p3
    p.and        p3, p4, p2
    vf.cmp.eq    p2, v5, v31
    p.and        p5, p4, p1
    p.or         p1, p2, p3
    vf.cmp.gt    p2, v5, v31
    v.cmp.lt     p3, v2, v0
    p.or         p4, p2, p5
    p.and        p2, p1, p3
    v.movi       v1, #0
    p.or         p1, p4, p2
    v.movi       v3, #0
    @p1 v.sel        v4, v2, v0
    v.movi       v0, #0
    s.movz       s1, #1
    v.extract    s2, v4, #0
    v.movi       v2, #1
    s.shli       s3, s2, #32
    v.iota       v4                              // arange(0, VLEN)
    s.ashri      s2, s3, #32
    v.splat      v6, s1
    s.lshri      s1, s2, #32
    v.insert     v1, s2, #0
    v.insert     v3, s1, #0
    v.shl        v7, v0, v2
    s.addi       s1, s7, #4
    v.cmp.lt     p2, v4, v6
    @p1 v.sel        v0, v5, v31
    @p2 v.st.scatter.w [s7, v7], v1
    @p2 v.st.scatter.w [s1, v7], v3
    exit
    exit
