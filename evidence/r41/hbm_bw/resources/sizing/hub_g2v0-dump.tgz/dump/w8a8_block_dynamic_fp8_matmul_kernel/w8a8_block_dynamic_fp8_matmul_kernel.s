    s.rdspecial  s1, arg_base
    s.movz       s2, #15
    s.ld.sw      s3, [s1, #40]                   // N: i32 at arg_base+40
    s.rdspecial  s4, pid.x
    s.rdspecial  s5, pid.y
    s.ld.sw      s6, [s1, #32]                   // M: i32 at arg_base+32
    s.movz       s7, #16
    s.add        s8, s6, s2
    s.ld.d       s2, [s1, #0]                    // A: device_ptr64 at arg_base+0
    s.movz       s9, #0
    s.ld.d       s10, [s1, #8]                   // B: device_ptr64 at arg_base+8
    s.movz       s11, #0
    s.ld.d       s12, [s1, #16]                  // C: device_ptr64 at arg_base+16
    s.cmp.lt     s13, s8, s11
    s.ld.d       s11, [s1, #24]                  // Bs: device_ptr64 at arg_base+24
    s.sub        s14, s9, s13
    s.movz       s9, #0
    s.movz       s13, #0
    s.ld.sw      s15, [s1, #48]                  // K: i32 at arg_base+48
    s.cmp.lt     s16, s7, s9
    s.ld.sw      s9, [s1, #56]                   // stride_am: i32 at arg_base+56
    s.sub        s17, s13, s16
    s.ld.sw      s13, [s1, #64]                  // stride_bn: i32 at arg_base+64
    s.xor        s16, s8, s14
    s.ld.sw      s8, [s1, #72]                   // stride_cm: i32 at arg_base+72
    s.sub        s18, s16, s14
    s.ld.sw      s16, [s1, #80]                  // stride_bs_n: i32 at arg_base+80
    s.movz       s1, #127
    s.movz       s19, #0
    s.add        s20, s3, s1
    s.movz       s21, #0
    s.cmp.lt     s22, s20, s19
    s.movz       s19, #128
    s.sub        s23, s21, s22
    s.movz       s21, #0
    s.lshri      s22, s18, #4
    s.xor        s24, s14, s17
    s.muli       s14, s22, #16
    s.xor        s25, s7, s17
    s.xor        s26, s22, s24
    s.sub        s22, s25, s17
    s.movz       s17, #0
    s.xor        s22, s20, s23
    s.cmp.lt     s20, s19, s17
    s.sub        s17, s18, s14
    s.sub        s14, s21, s20
    s.sub        s17, s22, s23
    s.xor        s18, s19, s14
    s.sub        s20, s26, s24
    s.lshri      s21, s17, #7
    s.xor        s22, s23, s14
    s.movz       s23, #8
    s.xor        s24, s21, s22
    s.movz       s25, #0
    s.sub        s26, s24, s22
    s.movz       s22, #0
    s.mul        s24, s4, s26
    s.mul        s4, s26, s23
    s.muli       s26, s21, #128
    s.sub        s21, s18, s14
    s.movz       s14, #0
    s.add        s18, s24, s5
    s.cmp.lt     s5, s4, s14
    s.movz       s14, #0
    s.cmp.lt     s21, s18, s25
    s.sub        s24, s22, s5
    s.sub        s5, s14, s21
    s.sub        s14, s17, s26
    s.xor        s14, s4, s24
    s.xor        s17, s18, s5
    s.sub        s21, s14, s24
    s.movz       s14, #0
    s.movz       s22, #1
    s.sub        s25, s17, s5
    s.movz       s17, #0
    s.addi       s26, s14, #0
    s.cmp.eq     s14, s21, s22
    s.addi       s22, s17, #0
    s.mov        s26, s25
    br.nz        s14, sdiv_done_1
    s.movz       s14, #0
    s.mov        s26, s14
    s.movz       s14, #31
    s.addi       s17, s14, #0
sdiv_2:
    s.lshr       s14, s25, s17
    s.andi       s27, s14, #1
    s.shli       s14, s22, #1
    s.or         s28, s14, s27
    s.movz       s14, #0
    s.cmp.geu    s27, s28, s21
    s.sub        s29, s14, s27
    s.and        s14, s21, s29
    s.sub        s27, s28, s14
    s.mov        s22, s27
    s.movz       s14, #1
    s.shl        s27, s14, s17
    s.and        s14, s27, s29
    s.or         s27, s26, s14
    s.mov        s26, s27
    s.subi       s14, s17, #1
    s.mov        s17, s14
    s.movz       s14, #0
    s.cmp.ge     s27, s17, s14
    br.nz        s27, sdiv_2
sdiv_done_1:
    s.xor        s14, s5, s24
    s.movz       s5, #0
    s.xor        s17, s26, s14
    s.movz       s21, #0
    s.cmp.lt     s22, s4, s5
    s.sub        s5, s17, s14
    s.movz       s14, #0
    s.cmp.lt     s17, s18, s21
    s.sub        s21, s14, s22
    s.movz       s14, #0
    s.mul        s22, s5, s23
    s.sub        s5, s14, s17
    s.xor        s14, s4, s21
    s.xor        s4, s18, s5
    s.sub        s17, s14, s21
    s.movz       s14, #0
    s.sub        s18, s20, s22
    s.sub        s20, s4, s5
    s.movz       s4, #0
    s.addi       s21, s14, #0
    s.min.s      s14, s18, s23
    s.movz       s18, #1
    s.addi       s23, s4, #0
    s.cmp.eq     s4, s17, s18
    s.mov        s21, s20
    br.nz        s4, sdiv_done_3
    s.movz       s4, #0
    s.mov        s21, s4
    s.movz       s4, #31
    s.addi       s18, s4, #0
sdiv_4:
    s.lshr       s4, s20, s18
    s.andi       s24, s4, #1
    s.shli       s4, s23, #1
    s.or         s25, s4, s24
    s.movz       s4, #0
    s.cmp.geu    s24, s25, s17
    s.sub        s26, s4, s24
    s.and        s4, s17, s26
    s.sub        s24, s25, s4
    s.mov        s23, s24
    s.movz       s4, #1
    s.shl        s24, s4, s18
    s.and        s4, s24, s26
    s.or         s24, s21, s4
    s.mov        s21, s24
    s.subi       s4, s18, #1
    s.mov        s18, s4
    s.movz       s4, #0
    s.cmp.ge     s24, s18, s4
    br.nz        s24, sdiv_4
sdiv_done_3:
    s.xor        s4, s23, s5
    s.movz       s17, #0
    s.sub        s18, s4, s5
    s.movz       s4, #0
    s.movz       s5, #0
    s.cmp.lt     s20, s14, s17
    s.movz       s17, #0
    s.cmp.lt     s21, s18, s4
    s.sub        s4, s5, s20
    s.sub        s5, s17, s21
    s.xor        s17, s14, s4
    s.xor        s20, s18, s5
    s.sub        s21, s17, s4
    s.movz       s4, #0
    s.movz       s17, #1
    s.sub        s23, s20, s5
    s.movz       s20, #0
    s.addi       s24, s4, #0
    s.cmp.eq     s4, s21, s17
    s.addi       s17, s20, #0
    s.mov        s24, s23
    br.nz        s4, sdiv_done_5
    s.movz       s4, #0
    s.mov        s24, s4
    s.movz       s4, #31
    s.addi       s20, s4, #0
sdiv_6:
    s.lshr       s4, s23, s20
    s.andi       s25, s4, #1
    s.shli       s4, s17, #1
    s.or         s26, s4, s25
    s.movz       s4, #0
    s.cmp.geu    s25, s26, s21
    s.sub        s27, s4, s25
    s.and        s4, s21, s27
    s.sub        s25, s26, s4
    s.mov        s17, s25
    s.movz       s4, #1
    s.shl        s25, s4, s20
    s.and        s4, s25, s27
    s.or         s25, s24, s4
    s.mov        s24, s25
    s.subi       s4, s20, #1
    s.mov        s20, s4
    s.movz       s4, #0
    s.cmp.ge     s25, s20, s4
    br.nz        s25, sdiv_6
sdiv_done_5:
    s.movz       s4, #0
    s.movz       s20, #0
    s.movz       s21, #0
    s.cmp.lt     s23, s14, s4
    s.cmp.lt     s4, s18, s20
    s.sub        s20, s21, s23
    s.movz       s21, #0
    s.xor        s23, s14, s20
    s.sub        s14, s21, s4
    s.xor        s4, s17, s5
    s.xor        s17, s18, s14
    s.sub        s18, s23, s20
    s.movz       s21, #0
    s.sub        s23, s4, s5
    s.sub        s4, s17, s14
    s.movz       s5, #0
    s.addi       s17, s21, #0
    s.add        s21, s22, s23
    s.movz       s22, #1
    s.addi       s23, s5, #0
    s.cmp.eq     s5, s18, s22
    s.mov        s17, s4
    br.nz        s5, sdiv_done_7
    s.movz       s5, #0
    s.mov        s17, s5
    s.movz       s5, #31
    s.addi       s22, s5, #0
sdiv_8:
    s.lshr       s5, s4, s22
    s.andi       s24, s5, #1
    s.shli       s5, s23, #1
    s.or         s25, s5, s24
    s.movz       s5, #0
    s.cmp.geu    s24, s25, s18
    s.sub        s26, s5, s24
    s.and        s5, s18, s26
    s.sub        s24, s25, s5
    s.mov        s23, s24
    s.movz       s5, #1
    s.shl        s24, s5, s22
    s.and        s5, s24, s26
    s.or         s24, s17, s5
    s.mov        s17, s24
    s.subi       s5, s22, #1
    s.mov        s22, s5
    s.movz       s5, #0
    s.cmp.ge     s24, s22, s5
    br.nz        s24, sdiv_8
sdiv_done_7:
    s.mul        s4, s21, s7
    v.iota       v0                              // arange(0, VLEN)
    s.xor        s5, s14, s20
    v.splat      v1, s6
    v.movi       v2, #0
    v.splat      v3, s4
    s.xor        s14, s17, s5
    v.add        v4, v3, v0
    v.sub        v0, v2, v1
    v.sub        v3, v2, v4
    v.cmp.lt     p1, v4, v2
    v.cmp.lt     p2, v1, v2
    s.sub        s17, s14, s5
    v.movi       v5, #1
    @p1 v.sel        v6, v3, v4
    @p2 v.sel        v3, v0, v1
    v.movi       v0, #0
    v.movi       v1, #0
    s.movz       s5, #31
idiv_9:
    v.splat      v4, s5
    v.shl        v7, v1, v5
    v.lshr       v8, v6, v4
    v.cmp.lt     p2, v1, v2
    v.and        v9, v8, v5
    v.shl        v8, v5, v4
    v.or         v4, v7, v9
    s.subi       s14, s5, #1
    v.cmp.geu    p3, v4, v3
    p.or         p4, p2, p3
    v.sub        v7, v4, v3
    @p4 v.sel        v9, v8, v2
    @p4 v.sel        v8, v7, v4
    v.or         v4, v0, v9
    v.mov        v1, v8
    v.mov        v0, v4
    s.mov        s5, s14
    s.movz       s14, #0
    s.cmp.ge     s18, s5, s14
    br.nz        s18, idiv_9
    s.mul        s5, s17, s19
    v.iota       v0                              // arange(0, VLEN)
    v.iota       v3                              // arange(0, VLEN)
    v.movi       v4, #16
    v.iota       v5                              // arange(0, VLEN)
    v.movi       v6, #32
    v.iota       v7                              // arange(0, VLEN)
    v.movi       v8, #48
    v.iota       v9                              // arange(0, VLEN)
    v.movi       v10, #64
    v.sub        v11, v2, v1
    v.iota       v2                              // arange(0, VLEN)
    v.add        v12, v3, v4
    v.add        v3, v5, v6
    v.add        v4, v7, v8
    v.add        v5, v9, v10
    @p1 v.sel        v6, v11, v1
    v.splat      v1, s5
    v.movi       v7, #80
    v.iota       v8                              // arange(0, VLEN)
    v.movi       v9, #96
    v.iota       v10                             // arange(0, VLEN)
    v.movi       v11, #112
    v.add        v13, v1, v0
    v.add        v0, v2, v7
    v.add        v1, v8, v9
    v.add        v2, v10, v11
    v.splat      v7, s3
    v.splat      v8, s5
    v.splat      v9, s5
    v.splat      v10, s5
    v.splat      v11, s5
    v.splat      v14, s5
    v.splat      v15, s5
    v.splat      v16, s5
    v.movi       v17, #0
    v.add        v18, v8, v12
    v.add        v8, v9, v3
    v.cmp.lt     p1, v13, v17
    v.add        v3, v10, v4
    v.cmp.lt     p2, v7, v17
    v.add        v4, v11, v5
    v.sub        v5, v17, v13
    v.add        v9, v14, v0
    v.add        v0, v15, v1
    v.sub        v1, v17, v7
    v.add        v10, v16, v2
    v.splat      v2, s3
    v.splat      v11, s3
    v.splat      v12, s3
    v.splat      v14, s3
    v.splat      v15, s3
    v.splat      v16, s3
    v.splat      v19, s3
    v.movi       v20, #1
    @p1 v.sel        v21, v5, v13
    @p2 v.sel        v5, v1, v7
    v.movi       v1, #0
    v.movi       v7, #0
    s.movz       s14, #31
idiv_10:
    v.splat      v13, s14
    v.shl        v22, v7, v20
    v.lshr       v23, v21, v13
    v.cmp.lt     p2, v7, v17
    v.and        v24, v23, v20
    v.shl        v23, v20, v13
    v.or         v13, v22, v24
    s.subi       s17, s14, #1
    v.cmp.geu    p3, v13, v5
    p.or         p4, p2, p3
    v.sub        v22, v13, v5
    @p4 v.sel        v24, v23, v17
    @p4 v.sel        v23, v22, v13
    v.or         v13, v1, v24
    v.mov        v7, v23
    v.mov        v1, v13
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_10
    v.movi       v1, #0
    v.sub        v5, v17, v7
    v.sub        v13, v1, v18
    v.sub        v17, v1, v2
    v.cmp.lt     p2, v18, v1
    @p1 v.sel        v20, v5, v7
    v.cmp.lt     p1, v2, v1
    v.movi       v5, #1
    @p2 v.sel        v7, v13, v18
    @p1 v.sel        v13, v17, v2
    v.movi       v2, #0
    v.movi       v17, #0
    s.movz       s14, #31
idiv_11:
    v.splat      v18, s14
    v.shl        v21, v17, v5
    v.lshr       v22, v7, v18
    v.cmp.lt     p1, v17, v1
    v.and        v23, v22, v5
    v.shl        v22, v5, v18
    v.or         v18, v21, v23
    s.subi       s17, s14, #1
    v.cmp.geu    p3, v18, v13
    p.or         p4, p1, p3
    v.sub        v21, v18, v13
    @p4 v.sel        v23, v22, v1
    @p4 v.sel        v22, v21, v18
    v.or         v18, v2, v23
    v.mov        v17, v22
    v.mov        v2, v18
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_11
    v.movi       v2, #0
    v.sub        v5, v1, v17
    v.sub        v1, v2, v8
    v.sub        v7, v2, v11
    v.cmp.lt     p1, v8, v2
    @p2 v.sel        v13, v5, v17
    v.cmp.lt     p2, v11, v2
    v.movi       v5, #1
    @p1 v.sel        v17, v1, v8
    @p2 v.sel        v1, v7, v11
    v.movi       v7, #0
    v.movi       v8, #0
    s.movz       s14, #31
idiv_12:
    v.splat      v11, s14
    v.shl        v18, v8, v5
    v.lshr       v21, v17, v11
    v.cmp.lt     p2, v8, v2
    v.and        v22, v21, v5
    v.shl        v21, v5, v11
    v.or         v11, v18, v22
    s.subi       s17, s14, #1
    v.cmp.geu    p3, v11, v1
    p.or         p4, p2, p3
    v.sub        v18, v11, v1
    @p4 v.sel        v22, v21, v2
    @p4 v.sel        v21, v18, v11
    v.or         v11, v7, v22
    v.mov        v8, v21
    v.mov        v7, v11
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_12
    v.movi       v1, #0
    v.sub        v5, v2, v8
    v.sub        v2, v1, v3
    v.sub        v7, v1, v12
    v.cmp.lt     p2, v3, v1
    @p1 v.sel        v11, v5, v8
    v.cmp.lt     p1, v12, v1
    v.movi       v5, #1
    @p2 v.sel        v8, v2, v3
    @p1 v.sel        v2, v7, v12
    v.movi       v3, #0
    v.movi       v7, #0
    s.movz       s14, #31
idiv_13:
    v.splat      v12, s14
    v.shl        v17, v7, v5
    v.lshr       v18, v8, v12
    v.cmp.lt     p1, v7, v1
    v.and        v21, v18, v5
    v.shl        v18, v5, v12
    v.or         v12, v17, v21
    s.subi       s17, s14, #1
    v.cmp.geu    p3, v12, v2
    p.or         p4, p1, p3
    v.sub        v17, v12, v2
    @p4 v.sel        v21, v18, v1
    @p4 v.sel        v18, v17, v12
    v.or         v12, v3, v21
    v.mov        v7, v18
    v.mov        v3, v12
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_13
    v.movi       v2, #0
    v.sub        v3, v1, v7
    v.sub        v1, v2, v4
    v.sub        v5, v2, v14
    v.cmp.lt     p1, v4, v2
    @p2 v.sel        v8, v3, v7
    v.cmp.lt     p2, v14, v2
    v.movi       v3, #1
    @p1 v.sel        v7, v1, v4
    @p2 v.sel        v1, v5, v14
    v.movi       v4, #0
    v.movi       v5, #0
    s.movz       s14, #31
idiv_14:
    v.splat      v12, s14
    v.shl        v14, v5, v3
    v.lshr       v17, v7, v12
    v.cmp.lt     p2, v5, v2
    v.and        v18, v17, v3
    v.shl        v17, v3, v12
    v.or         v12, v14, v18
    s.subi       s17, s14, #1
    v.cmp.geu    p3, v12, v1
    p.or         p4, p2, p3
    v.sub        v14, v12, v1
    @p4 v.sel        v18, v17, v2
    @p4 v.sel        v17, v14, v12
    v.or         v12, v4, v18
    v.mov        v5, v17
    v.mov        v4, v12
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_14
    v.movi       v1, #0
    v.sub        v3, v2, v5
    v.sub        v2, v1, v9
    v.sub        v4, v1, v15
    v.cmp.lt     p2, v9, v1
    @p1 v.sel        v7, v3, v5
    v.cmp.lt     p1, v15, v1
    v.movi       v3, #1
    @p2 v.sel        v5, v2, v9
    @p1 v.sel        v2, v4, v15
    v.movi       v4, #0
    v.movi       v9, #0
    s.movz       s14, #31
idiv_15:
    v.splat      v12, s14
    v.shl        v14, v9, v3
    v.lshr       v15, v5, v12
    v.cmp.lt     p1, v9, v1
    v.and        v17, v15, v3
    v.shl        v15, v3, v12
    v.or         v12, v14, v17
    s.subi       s17, s14, #1
    v.cmp.geu    p3, v12, v2
    p.or         p4, p1, p3
    v.sub        v14, v12, v2
    @p4 v.sel        v17, v15, v1
    @p4 v.sel        v15, v14, v12
    v.or         v12, v4, v17
    v.mov        v9, v15
    v.mov        v4, v12
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_15
    v.movi       v2, #0
    v.sub        v3, v1, v9
    v.sub        v1, v2, v0
    v.sub        v4, v2, v16
    v.cmp.lt     p1, v0, v2
    @p2 v.sel        v5, v3, v9
    v.cmp.lt     p2, v16, v2
    v.movi       v3, #1
    @p1 v.sel        v9, v1, v0
    @p2 v.sel        v0, v4, v16
    v.movi       v1, #0
    v.movi       v4, #0
    s.movz       s14, #31
idiv_16:
    v.splat      v12, s14
    v.shl        v14, v4, v3
    v.lshr       v15, v9, v12
    v.cmp.lt     p2, v4, v2
    v.and        v16, v15, v3
    v.shl        v15, v3, v12
    v.or         v12, v14, v16
    s.subi       s17, s14, #1
    v.cmp.geu    p3, v12, v0
    p.or         p4, p2, p3
    v.sub        v14, v12, v0
    @p4 v.sel        v16, v15, v2
    @p4 v.sel        v15, v14, v12
    v.or         v12, v1, v16
    v.mov        v4, v15
    v.mov        v1, v12
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_16
    v.movi       v0, #0
    v.sub        v1, v2, v4
    v.sub        v2, v0, v10
    v.sub        v3, v0, v19
    v.cmp.lt     p2, v10, v0
    @p1 v.sel        v9, v1, v4
    v.cmp.lt     p1, v19, v0
    v.movi       v1, #1
    @p2 v.sel        v4, v2, v10
    @p1 v.sel        v2, v3, v19
    v.movi       v3, #0
    v.movi       v10, #0
    s.movz       s14, #31
idiv_17:
    v.splat      v12, s14
    v.shl        v14, v10, v1
    v.lshr       v15, v4, v12
    v.cmp.lt     p1, v10, v0
    v.and        v16, v15, v1
    v.shl        v15, v1, v12
    v.or         v12, v14, v16
    s.subi       s17, s14, #1
    v.cmp.geu    p3, v12, v2
    p.or         p4, p1, p3
    v.sub        v14, v12, v2
    @p4 v.sel        v16, v15, v0
    @p4 v.sel        v15, v14, v12
    v.or         v12, v3, v16
    v.mov        v10, v15
    v.mov        v3, v12
    s.mov        s14, s17
    s.movz       s17, #0
    s.cmp.ge     s18, s14, s17
    br.nz        s18, idiv_17
    v.sub        v1, v0, v10
    v.movi       v0, #0
    @p2 v.sel        v2, v1, v10
    v.sub        v1, v0, v20
    v.cmp.lt     p1, v20, v0
    @p1 v.sel        v3, v1, v20
    v.movi       v1, #7
    v.movi       v4, #128
    s.movz       s14, #32
    v.lshr       v10, v3, v1
    v.sub        v1, v0, v4
    v.cmp.lt     p2, v4, v0
    s.movz       s17, #48
    v.sub        v3, v0, v10
    s.movz       s18, #64
    @p1 v.sel        v0, v3, v10
    s.movz       s20, #80
    v.movi       v3, #128
    s.movz       s21, #96
    v.movi       v10, #0
    s.movz       s22, #112
    v.cmp.lt     p1, v13, v10
    v.movi       v12, #1
    v.sub        v12, v10, v13
    v.movi       v14, #7
    @p1 v.sel        v15, v12, v13
    v.sub        v12, v10, v3
    v.lshr       v16, v15, v14
    @p2 v.sel        v14, v1, v4
    v.movi       v1, #0
    v.sub        v4, v10, v16
    v.cmp.lt     p2, v11, v1
    v.movi       v14, #128
    @p1 v.sel        v15, v4, v16
    v.cmp.lt     p1, v3, v10
    v.movi       v4, #1
    v.sub        v4, v1, v11
    v.movi       v10, #7
    @p2 v.sel        v16, v4, v11
    v.sub        v4, v1, v14
    v.lshr       v17, v16, v10
    @p1 v.sel        v10, v12, v3
    v.movi       v3, #0
    v.sub        v10, v1, v17
    v.cmp.lt     p1, v8, v3
    v.movi       v12, #128
    @p2 v.sel        v16, v10, v17
    v.cmp.lt     p2, v14, v1
    v.movi       v1, #1
    v.sub        v1, v3, v8
    v.movi       v10, #7
    @p1 v.sel        v17, v1, v8
    v.sub        v1, v3, v12
    v.lshr       v18, v17, v10
    @p2 v.sel        v10, v4, v14
    v.movi       v4, #0
    v.sub        v10, v3, v18
    v.cmp.lt     p2, v7, v4
    v.movi       v14, #128
    @p1 v.sel        v17, v10, v18
    v.cmp.lt     p1, v12, v3
    v.movi       v3, #1
    v.sub        v3, v4, v7
    v.movi       v10, #7
    @p2 v.sel        v18, v3, v7
    v.sub        v3, v4, v14
    v.lshr       v19, v18, v10
    @p1 v.sel        v10, v1, v12
    v.movi       v1, #0
    v.sub        v10, v4, v19
    v.cmp.lt     p1, v5, v1
    v.movi       v12, #128
    @p2 v.sel        v18, v10, v19
    v.cmp.lt     p2, v14, v4
    v.movi       v4, #1
    v.sub        v4, v1, v5
    v.movi       v10, #7
    @p1 v.sel        v19, v4, v5
    v.sub        v4, v1, v12
    v.lshr       v21, v19, v10
    @p2 v.sel        v10, v3, v14
    v.movi       v3, #0
    v.sub        v10, v1, v21
    v.cmp.lt     p2, v9, v3
    v.movi       v14, #128
    @p1 v.sel        v19, v10, v21
    v.cmp.lt     p1, v12, v1
    v.movi       v1, #1
    v.sub        v1, v3, v9
    v.movi       v10, #7
    @p2 v.sel        v21, v1, v9
    v.sub        v1, v3, v14
    v.lshr       v22, v21, v10
    @p1 v.sel        v10, v4, v12
    v.movi       v4, #0
    v.sub        v10, v3, v22
    v.cmp.lt     p1, v2, v4
    v.movi       v12, #128
    @p2 v.sel        v21, v10, v22
    v.cmp.lt     p2, v14, v3
    v.movi       v3, #1
    v.sub        v3, v4, v2
    v.movi       v10, #7
    @p1 v.sel        v22, v3, v2
    v.sub        v3, v4, v12
    v.lshr       v23, v22, v10
    @p2 v.sel        v10, v1, v14
    v.sub        v1, v4, v23
    v.splat      v10, s16
    @p1 v.sel        v14, v1, v23
    v.splat      v1, s16
    v.splat      v22, s16
    v.splat      v23, s16
    v.splat      v24, s16
    v.cmp.lt     p1, v12, v4
    v.movi       v4, #1
    v.splat      v4, s16
    @p1 v.sel        v25, v3, v12
    s.add        s23, s15, s1
    s.movz       s1, #0
    s.movz       s24, #0
    s.cmp.lt     s25, s23, s1
    s.movz       s1, #0
    s.sub        s26, s24, s25
    v.splat      v3, s16
    s.movz       s24, #0
    v.splat      v12, s16
    s.cmp.lt     s16, s19, s24
    v.mul        v25, v0, v10
    s.sub        s24, s1, s16
    v.mul        v0, v15, v1
    s.xor        s1, s23, s26
    v.mul        v1, v16, v22
    s.sub        s16, s1, s26
    v.mul        v10, v17, v23
    s.xor        s1, s19, s24
    v.mul        v15, v18, v24
    v.mul        v16, v19, v4
    s.lshri      s23, s16, #7
    v.mul        v4, v21, v3
    s.muli       s25, s23, #128
    v.mul        v3, v14, v12
    s.xor        s27, s26, s24
    s.sub        s26, s1, s24
    s.xor        s1, s23, s27
    s.movz       s23, #0
    s.movz       s24, #0
    s.sub        s26, s16, s25
    s.movz       s16, #0
    s.sub        s25, s1, s27
    s.movz       s1, #1
    s.addi       s26, s23, #0
    s.addi       s27, s24, #0
    s.addi       s24, s16, #0
    s.addi       s16, s11, #0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a1
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a2
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a3
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a4
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a5
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a6
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a7
for_26:
    s.cmp.ge     s11, s26, s25
    br.nz        s11, endfor_27
    s.mul        s11, s26, s19
    s.sub        s28, s15, s11
    s.rdspecial  s11, arg_base
    s.ld.d       s29, [s11, #88]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.addi       s11, s29, #0
    s.muli       s30, s9, #2
    s.muli       s31, s27, #2
    v.splat      v12, s30
    v.mul        v14, v6, v12
    v.extract    s30, v14, #0
    s.add        s32, s30, s31
    s.add        s30, s2, s32
    v.iota       v12                             // arange(0, VLEN)
    s.movz       s32, #0
    s.add        s33, s32, s28                   // the tile origin
    v.splat      v17, s33
    v.cmp.lt     p1, v12, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s30, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s11, #0], v18
    s.addi       s30, s11, #64
    v.extract    s32, v14, #1
    s.add        s33, s32, s31
    s.add        s32, s2, s33
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #128
    v.extract    s32, v14, #2
    s.add        s33, s32, s31
    s.add        s32, s2, s33
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #192
    v.extract    s32, v14, #3
    s.add        s33, s32, s31
    s.add        s32, s2, s33
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #256
    v.extract    s32, v14, #4
    s.add        s33, s32, s31
    s.add        s32, s2, s33
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #320
    v.extract    s32, v14, #5
    s.add        s33, s32, s31
    s.add        s32, s2, s33
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #384
    v.extract    s32, v14, #6
    s.add        s33, s32, s31
    s.add        s32, s2, s33
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #448
    v.extract    s32, v14, #7
    s.add        s33, s32, s31
    s.add        s32, s2, s33
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #512
    v.extract    s32, v14, #8
    s.add        s33, s32, s31
    s.add        s32, s2, s33
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #576
    v.extract    s32, v14, #9
    s.add        s33, s32, s31
    s.add        s32, s2, s33
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #640
    v.extract    s32, v14, #10
    s.add        s33, s32, s31
    s.add        s32, s2, s33
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #704
    v.extract    s32, v14, #11
    s.add        s33, s32, s31
    s.add        s32, s2, s33
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #768
    v.extract    s32, v14, #12
    s.add        s33, s32, s31
    s.add        s32, s2, s33
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #832
    v.extract    s32, v14, #13
    s.add        s33, s32, s31
    s.add        s32, s2, s33
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #896
    v.extract    s32, v14, #14
    s.add        s33, s32, s31
    s.add        s32, s2, s33
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #960
    v.extract    s11, v14, #15
    s.add        s32, s11, s31
    s.add        s11, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s11, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    fence.acq_rel.device
    s.addi       s11, s29, #1024
    v.extract    s30, v14, #0
    s.add        s32, s30, s31
    s.addi       s30, s32, #32
    s.add        s32, s2, s30
    s.movz       s30, #0
    s.add        s33, s30, s7                    // the tile origin
    v.splat      v17, s33
    v.add        v18, v12, v17
    s.movz       s30, #0
    s.add        s33, s30, s28                   // the tile origin
    v.splat      v17, s33
    v.cmp.lt     p1, v18, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s11, #0], v18
    s.addi       s30, s11, #64
    v.extract    s32, v14, #1
    s.add        s33, s32, s31
    s.addi       s32, s33, #32
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #128
    v.extract    s32, v14, #2
    s.add        s33, s32, s31
    s.addi       s32, s33, #32
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #192
    v.extract    s32, v14, #3
    s.add        s33, s32, s31
    s.addi       s32, s33, #32
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #256
    v.extract    s32, v14, #4
    s.add        s33, s32, s31
    s.addi       s32, s33, #32
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #320
    v.extract    s32, v14, #5
    s.add        s33, s32, s31
    s.addi       s32, s33, #32
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #384
    v.extract    s32, v14, #6
    s.add        s33, s32, s31
    s.addi       s32, s33, #32
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #448
    v.extract    s32, v14, #7
    s.add        s33, s32, s31
    s.addi       s32, s33, #32
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #512
    v.extract    s32, v14, #8
    s.add        s33, s32, s31
    s.addi       s32, s33, #32
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #576
    v.extract    s32, v14, #9
    s.add        s33, s32, s31
    s.addi       s32, s33, #32
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #640
    v.extract    s32, v14, #10
    s.add        s33, s32, s31
    s.addi       s32, s33, #32
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #704
    v.extract    s32, v14, #11
    s.add        s33, s32, s31
    s.addi       s32, s33, #32
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #768
    v.extract    s32, v14, #12
    s.add        s33, s32, s31
    s.addi       s32, s33, #32
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #832
    v.extract    s32, v14, #13
    s.add        s33, s32, s31
    s.addi       s32, s33, #32
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #896
    v.extract    s32, v14, #14
    s.add        s33, s32, s31
    s.addi       s32, s33, #32
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #960
    v.extract    s11, v14, #15
    s.add        s32, s11, s31
    s.addi       s11, s32, #32
    s.add        s32, s2, s11
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    fence.acq_rel.device
    s.addi       s11, s29, #2048
    v.extract    s30, v14, #0
    s.add        s32, s30, s31
    s.addi       s30, s32, #64
    s.add        s32, s2, s30
    s.movz       s30, #0
    s.add        s33, s30, s14                   // the tile origin
    v.splat      v17, s33
    v.add        v18, v12, v17
    s.movz       s30, #0
    s.add        s33, s30, s28                   // the tile origin
    v.splat      v17, s33
    v.cmp.lt     p1, v18, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s11, #0], v18
    s.addi       s30, s11, #64
    v.extract    s32, v14, #1
    s.add        s33, s32, s31
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #128
    v.extract    s32, v14, #2
    s.add        s33, s32, s31
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #192
    v.extract    s32, v14, #3
    s.add        s33, s32, s31
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #256
    v.extract    s32, v14, #4
    s.add        s33, s32, s31
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #320
    v.extract    s32, v14, #5
    s.add        s33, s32, s31
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #384
    v.extract    s32, v14, #6
    s.add        s33, s32, s31
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #448
    v.extract    s32, v14, #7
    s.add        s33, s32, s31
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #512
    v.extract    s32, v14, #8
    s.add        s33, s32, s31
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #576
    v.extract    s32, v14, #9
    s.add        s33, s32, s31
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #640
    v.extract    s32, v14, #10
    s.add        s33, s32, s31
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #704
    v.extract    s32, v14, #11
    s.add        s33, s32, s31
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #768
    v.extract    s32, v14, #12
    s.add        s33, s32, s31
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #832
    v.extract    s32, v14, #13
    s.add        s33, s32, s31
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #896
    v.extract    s32, v14, #14
    s.add        s33, s32, s31
    s.addi       s32, s33, #64
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #960
    v.extract    s11, v14, #15
    s.add        s32, s11, s31
    s.addi       s11, s32, #64
    s.add        s32, s2, s11
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    fence.acq_rel.device
    s.addi       s11, s29, #3072
    v.extract    s30, v14, #0
    s.add        s32, s30, s31
    s.addi       s30, s32, #96
    s.add        s32, s2, s30
    s.movz       s30, #0
    s.add        s33, s30, s17                   // the tile origin
    v.splat      v17, s33
    v.add        v18, v12, v17
    s.movz       s30, #0
    s.add        s33, s30, s28                   // the tile origin
    v.splat      v17, s33
    v.cmp.lt     p1, v18, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s11, #0], v18
    s.addi       s30, s11, #64
    v.extract    s32, v14, #1
    s.add        s33, s32, s31
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #128
    v.extract    s32, v14, #2
    s.add        s33, s32, s31
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #192
    v.extract    s32, v14, #3
    s.add        s33, s32, s31
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #256
    v.extract    s32, v14, #4
    s.add        s33, s32, s31
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #320
    v.extract    s32, v14, #5
    s.add        s33, s32, s31
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #384
    v.extract    s32, v14, #6
    s.add        s33, s32, s31
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #448
    v.extract    s32, v14, #7
    s.add        s33, s32, s31
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #512
    v.extract    s32, v14, #8
    s.add        s33, s32, s31
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #576
    v.extract    s32, v14, #9
    s.add        s33, s32, s31
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #640
    v.extract    s32, v14, #10
    s.add        s33, s32, s31
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #704
    v.extract    s32, v14, #11
    s.add        s33, s32, s31
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #768
    v.extract    s32, v14, #12
    s.add        s33, s32, s31
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #832
    v.extract    s32, v14, #13
    s.add        s33, s32, s31
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #896
    v.extract    s32, v14, #14
    s.add        s33, s32, s31
    s.addi       s32, s33, #96
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #960
    v.extract    s11, v14, #15
    s.add        s32, s11, s31
    s.addi       s11, s32, #96
    s.add        s32, s2, s11
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    fence.acq_rel.device
    s.addi       s11, s29, #4096
    v.extract    s30, v14, #0
    s.add        s32, s30, s31
    s.addi       s30, s32, #128
    s.add        s32, s2, s30
    s.movz       s30, #0
    s.add        s33, s30, s18                   // the tile origin
    v.splat      v17, s33
    v.add        v18, v12, v17
    s.movz       s30, #0
    s.add        s33, s30, s28                   // the tile origin
    v.splat      v17, s33
    v.cmp.lt     p1, v18, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s11, #0], v18
    s.addi       s30, s11, #64
    v.extract    s32, v14, #1
    s.add        s33, s32, s31
    s.addi       s32, s33, #128
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #128
    v.extract    s32, v14, #2
    s.add        s33, s32, s31
    s.addi       s32, s33, #128
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #192
    v.extract    s32, v14, #3
    s.add        s33, s32, s31
    s.addi       s32, s33, #128
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #256
    v.extract    s32, v14, #4
    s.add        s33, s32, s31
    s.addi       s32, s33, #128
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #320
    v.extract    s32, v14, #5
    s.add        s33, s32, s31
    s.addi       s32, s33, #128
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #384
    v.extract    s32, v14, #6
    s.add        s33, s32, s31
    s.addi       s32, s33, #128
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #448
    v.extract    s32, v14, #7
    s.add        s33, s32, s31
    s.addi       s32, s33, #128
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #512
    v.extract    s32, v14, #8
    s.add        s33, s32, s31
    s.addi       s32, s33, #128
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #576
    v.extract    s32, v14, #9
    s.add        s33, s32, s31
    s.addi       s32, s33, #128
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #640
    v.extract    s32, v14, #10
    s.add        s33, s32, s31
    s.addi       s32, s33, #128
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #704
    v.extract    s32, v14, #11
    s.add        s33, s32, s31
    s.addi       s32, s33, #128
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #768
    v.extract    s32, v14, #12
    s.add        s33, s32, s31
    s.addi       s32, s33, #128
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #832
    v.extract    s32, v14, #13
    s.add        s33, s32, s31
    s.addi       s32, s33, #128
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #896
    v.extract    s32, v14, #14
    s.add        s33, s32, s31
    s.addi       s32, s33, #128
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #960
    v.extract    s11, v14, #15
    s.add        s32, s11, s31
    s.addi       s11, s32, #128
    s.add        s32, s2, s11
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    fence.acq_rel.device
    s.addi       s11, s29, #5120
    v.extract    s30, v14, #0
    s.add        s32, s30, s31
    s.addi       s30, s32, #160
    s.add        s32, s2, s30
    s.movz       s30, #0
    s.add        s33, s30, s20                   // the tile origin
    v.splat      v17, s33
    v.add        v18, v12, v17
    s.movz       s30, #0
    s.add        s33, s30, s28                   // the tile origin
    v.splat      v17, s33
    v.cmp.lt     p1, v18, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s11, #0], v18
    s.addi       s30, s11, #64
    v.extract    s32, v14, #1
    s.add        s33, s32, s31
    s.addi       s32, s33, #160
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #128
    v.extract    s32, v14, #2
    s.add        s33, s32, s31
    s.addi       s32, s33, #160
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #192
    v.extract    s32, v14, #3
    s.add        s33, s32, s31
    s.addi       s32, s33, #160
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #256
    v.extract    s32, v14, #4
    s.add        s33, s32, s31
    s.addi       s32, s33, #160
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #320
    v.extract    s32, v14, #5
    s.add        s33, s32, s31
    s.addi       s32, s33, #160
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #384
    v.extract    s32, v14, #6
    s.add        s33, s32, s31
    s.addi       s32, s33, #160
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #448
    v.extract    s32, v14, #7
    s.add        s33, s32, s31
    s.addi       s32, s33, #160
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #512
    v.extract    s32, v14, #8
    s.add        s33, s32, s31
    s.addi       s32, s33, #160
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #576
    v.extract    s32, v14, #9
    s.add        s33, s32, s31
    s.addi       s32, s33, #160
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #640
    v.extract    s32, v14, #10
    s.add        s33, s32, s31
    s.addi       s32, s33, #160
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #704
    v.extract    s32, v14, #11
    s.add        s33, s32, s31
    s.addi       s32, s33, #160
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #768
    v.extract    s32, v14, #12
    s.add        s33, s32, s31
    s.addi       s32, s33, #160
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #832
    v.extract    s32, v14, #13
    s.add        s33, s32, s31
    s.addi       s32, s33, #160
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #896
    v.extract    s32, v14, #14
    s.add        s33, s32, s31
    s.addi       s32, s33, #160
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #960
    v.extract    s11, v14, #15
    s.add        s32, s11, s31
    s.addi       s11, s32, #160
    s.add        s32, s2, s11
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    fence.acq_rel.device
    s.addi       s11, s29, #6144
    v.extract    s30, v14, #0
    s.add        s32, s30, s31
    s.addi       s30, s32, #192
    s.add        s32, s2, s30
    s.movz       s30, #0
    s.add        s33, s30, s21                   // the tile origin
    v.splat      v17, s33
    v.add        v18, v12, v17
    s.movz       s30, #0
    s.add        s33, s30, s28                   // the tile origin
    v.splat      v17, s33
    v.cmp.lt     p1, v18, v17
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s11, #0], v18
    s.addi       s30, s11, #64
    v.extract    s32, v14, #1
    s.add        s33, s32, s31
    s.addi       s32, s33, #192
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #128
    v.extract    s32, v14, #2
    s.add        s33, s32, s31
    s.addi       s32, s33, #192
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #192
    v.extract    s32, v14, #3
    s.add        s33, s32, s31
    s.addi       s32, s33, #192
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #256
    v.extract    s32, v14, #4
    s.add        s33, s32, s31
    s.addi       s32, s33, #192
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #320
    v.extract    s32, v14, #5
    s.add        s33, s32, s31
    s.addi       s32, s33, #192
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #384
    v.extract    s32, v14, #6
    s.add        s33, s32, s31
    s.addi       s32, s33, #192
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #448
    v.extract    s32, v14, #7
    s.add        s33, s32, s31
    s.addi       s32, s33, #192
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #512
    v.extract    s32, v14, #8
    s.add        s33, s32, s31
    s.addi       s32, s33, #192
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #576
    v.extract    s32, v14, #9
    s.add        s33, s32, s31
    s.addi       s32, s33, #192
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #640
    v.extract    s32, v14, #10
    s.add        s33, s32, s31
    s.addi       s32, s33, #192
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #704
    v.extract    s32, v14, #11
    s.add        s33, s32, s31
    s.addi       s32, s33, #192
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #768
    v.extract    s32, v14, #12
    s.add        s33, s32, s31
    s.addi       s32, s33, #192
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #832
    v.extract    s32, v14, #13
    s.add        s33, s32, s31
    s.addi       s32, s33, #192
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #896
    v.extract    s32, v14, #14
    s.add        s33, s32, s31
    s.addi       s32, s33, #192
    s.add        s33, s2, s32
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s33, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    s.addi       s30, s11, #960
    v.extract    s11, v14, #15
    s.add        s32, s11, s31
    s.addi       s11, s32, #192
    s.add        s32, s2, s11
    v.movi       v17, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v17, [s32, #0]
    vf.cvt.bf16.f32 v18, v17
    v.st.w       [s30, #0], v18
    fence.acq_rel.device
    s.addi       s11, s29, #7168
    v.extract    s30, v14, #0
    s.add        s32, s30, s31
    s.addi       s30, s32, #224
    s.add        s32, s2, s30
    s.movz       s30, #0
    s.add        s33, s30, s22                   // the tile origin
    v.splat      v17, s33
    v.add        v18, v12, v17
    s.movz       s30, #0
    s.add        s33, s30, s28                   // the tile origin
    v.splat      v12, s33
    v.cmp.lt     p1, v18, v12
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s32, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s11, #0], v17
    s.addi       s30, s11, #64
    v.extract    s32, v14, #1
    s.add        s33, s32, s31
    s.addi       s32, s33, #224
    s.add        s33, s2, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s30, #0], v17
    s.addi       s30, s11, #128
    v.extract    s32, v14, #2
    s.add        s33, s32, s31
    s.addi       s32, s33, #224
    s.add        s33, s2, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s30, #0], v17
    s.addi       s30, s11, #192
    v.extract    s32, v14, #3
    s.add        s33, s32, s31
    s.addi       s32, s33, #224
    s.add        s33, s2, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s30, #0], v17
    s.addi       s30, s11, #256
    v.extract    s32, v14, #4
    s.add        s33, s32, s31
    s.addi       s32, s33, #224
    s.add        s33, s2, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s30, #0], v17
    s.addi       s30, s11, #320
    v.extract    s32, v14, #5
    s.add        s33, s32, s31
    s.addi       s32, s33, #224
    s.add        s33, s2, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s30, #0], v17
    s.addi       s30, s11, #384
    v.extract    s32, v14, #6
    s.add        s33, s32, s31
    s.addi       s32, s33, #224
    s.add        s33, s2, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s30, #0], v17
    s.addi       s30, s11, #448
    v.extract    s32, v14, #7
    s.add        s33, s32, s31
    s.addi       s32, s33, #224
    s.add        s33, s2, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s30, #0], v17
    s.addi       s30, s11, #512
    v.extract    s32, v14, #8
    s.add        s33, s32, s31
    s.addi       s32, s33, #224
    s.add        s33, s2, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s30, #0], v17
    s.addi       s30, s11, #576
    v.extract    s32, v14, #9
    s.add        s33, s32, s31
    s.addi       s32, s33, #224
    s.add        s33, s2, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s30, #0], v17
    s.addi       s30, s11, #640
    v.extract    s32, v14, #10
    s.add        s33, s32, s31
    s.addi       s32, s33, #224
    s.add        s33, s2, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s30, #0], v17
    s.addi       s30, s11, #704
    v.extract    s32, v14, #11
    s.add        s33, s32, s31
    s.addi       s32, s33, #224
    s.add        s33, s2, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s30, #0], v17
    s.addi       s30, s11, #768
    v.extract    s32, v14, #12
    s.add        s33, s32, s31
    s.addi       s32, s33, #224
    s.add        s33, s2, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s30, #0], v17
    s.addi       s30, s11, #832
    v.extract    s32, v14, #13
    s.add        s33, s32, s31
    s.addi       s32, s33, #224
    s.add        s33, s2, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s30, #0], v17
    s.addi       s30, s11, #896
    v.extract    s32, v14, #14
    s.add        s33, s32, s31
    s.addi       s32, s33, #224
    s.add        s33, s2, s32
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s33, #0]
    vf.cvt.bf16.f32 v17, v12
    v.st.w       [s30, #0], v17
    s.addi       s30, s11, #960
    v.extract    s11, v14, #15
    s.add        s32, s11, s31
    s.addi       s11, s32, #224
    s.add        s31, s2, s11
    v.movi       v12, #0                         // other=, materialised (sec 12)
    @p1 v.ld.h       v12, [s31, #0]
    vf.cvt.bf16.f32 v14, v12
    v.st.w       [s30, #0], v14
    fence.acq_rel.device
    s.addi       s11, s29, #0
    v.ld.w       v12, [s11, #0]
    vf.abs       v14, v12
    s.addi       s11, s29, #1024
    v.ld.w       v12, [s11, #0]
    vf.abs       v17, v12
    vf.max.ieee  v12, v14, v17
    s.addi       s11, s29, #2048
    v.ld.w       v14, [s11, #0]
    vf.abs       v17, v14
    vf.max.ieee  v14, v12, v17
    s.addi       s11, s29, #3072
    v.ld.w       v12, [s11, #0]
    vf.abs       v17, v12
    vf.max.ieee  v12, v14, v17
    s.addi       s11, s29, #4096
    v.ld.w       v14, [s11, #0]
    vf.abs       v17, v14
    vf.max.ieee  v14, v12, v17
    s.addi       s11, s29, #5120
    v.ld.w       v12, [s11, #0]
    vf.abs       v17, v12
    vf.max.ieee  v12, v14, v17
    s.addi       s11, s29, #6144
    v.ld.w       v14, [s11, #0]
    vf.abs       v17, v14
    vf.max.ieee  v14, v12, v17
    s.addi       s11, s29, #7168
    v.ld.w       v12, [s11, #0]
    vf.abs       v17, v12
    vf.max.ieee  v12, v14, v17
    vf.reduce.max.b v14, v12
    s.addi       s11, s29, #64
    v.ld.w       v12, [s11, #0]
    vf.abs       v17, v12
    s.addi       s11, s29, #1088
    v.ld.w       v12, [s11, #0]
    vf.abs       v18, v12
    vf.max.ieee  v12, v17, v18
    s.addi       s11, s29, #2112
    v.ld.w       v17, [s11, #0]
    vf.abs       v18, v17
    vf.max.ieee  v17, v12, v18
    s.addi       s11, s29, #3136
    v.ld.w       v12, [s11, #0]
    vf.abs       v18, v12
    vf.max.ieee  v12, v17, v18
    s.addi       s11, s29, #4160
    v.ld.w       v17, [s11, #0]
    vf.abs       v18, v17
    vf.max.ieee  v17, v12, v18
    s.addi       s11, s29, #5184
    v.ld.w       v12, [s11, #0]
    vf.abs       v18, v12
    vf.max.ieee  v12, v17, v18
    s.addi       s11, s29, #6208
    v.ld.w       v17, [s11, #0]
    vf.abs       v18, v17
    vf.max.ieee  v17, v12, v18
    s.addi       s11, s29, #7232
    v.ld.w       v12, [s11, #0]
    vf.abs       v18, v12
    vf.max.ieee  v12, v17, v18
    vf.reduce.max.b v17, v12
    s.addi       s11, s29, #128
    v.ld.w       v12, [s11, #0]
    vf.abs       v18, v12
    s.addi       s11, s29, #1152
    v.ld.w       v12, [s11, #0]
    vf.abs       v19, v12
    vf.max.ieee  v12, v18, v19
    s.addi       s11, s29, #2176
    v.ld.w       v18, [s11, #0]
    vf.abs       v19, v18
    vf.max.ieee  v18, v12, v19
    s.addi       s11, s29, #3200
    v.ld.w       v12, [s11, #0]
    vf.abs       v19, v12
    vf.max.ieee  v12, v18, v19
    s.addi       s11, s29, #4224
    v.ld.w       v18, [s11, #0]
    vf.abs       v19, v18
    vf.max.ieee  v18, v12, v19
    s.addi       s11, s29, #5248
    v.ld.w       v12, [s11, #0]
    vf.abs       v19, v12
    vf.max.ieee  v12, v18, v19
    s.addi       s11, s29, #6272
    v.ld.w       v18, [s11, #0]
    vf.abs       v19, v18
    vf.max.ieee  v18, v12, v19
    s.addi       s11, s29, #7296
    v.ld.w       v12, [s11, #0]
    vf.abs       v19, v12
    vf.max.ieee  v12, v18, v19
    vf.reduce.max.b v18, v12
    s.addi       s11, s29, #192
    v.ld.w       v12, [s11, #0]
    vf.abs       v19, v12
    s.addi       s11, s29, #1216
    v.ld.w       v12, [s11, #0]
    vf.abs       v21, v12
    vf.max.ieee  v12, v19, v21
    s.addi       s11, s29, #2240
    v.ld.w       v19, [s11, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v12, v21
    s.addi       s11, s29, #3264
    v.ld.w       v12, [s11, #0]
    vf.abs       v21, v12
    vf.max.ieee  v12, v19, v21
    s.addi       s11, s29, #4288
    v.ld.w       v19, [s11, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v12, v21
    s.addi       s11, s29, #5312
    v.ld.w       v12, [s11, #0]
    vf.abs       v21, v12
    vf.max.ieee  v12, v19, v21
    s.addi       s11, s29, #6336
    v.ld.w       v19, [s11, #0]
    vf.abs       v21, v19
    vf.max.ieee  v19, v12, v21
    s.addi       s11, s29, #7360
    v.ld.w       v12, [s11, #0]
    vf.abs       v21, v12
    vf.max.ieee  v12, v19, v21
    vf.reduce.max.b v19, v12
    s.addi       s11, s29, #256
    v.ld.w       v12, [s11, #0]
    vf.abs       v21, v12
    s.addi       s11, s29, #1280
    v.ld.w       v12, [s11, #0]
    vf.abs       v22, v12
    vf.max.ieee  v12, v21, v22
    s.addi       s11, s29, #2304
    v.ld.w       v21, [s11, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v12, v22
    s.addi       s11, s29, #3328
    v.ld.w       v12, [s11, #0]
    vf.abs       v22, v12
    vf.max.ieee  v12, v21, v22
    s.addi       s11, s29, #4352
    v.ld.w       v21, [s11, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v12, v22
    s.addi       s11, s29, #5376
    v.ld.w       v12, [s11, #0]
    vf.abs       v22, v12
    vf.max.ieee  v12, v21, v22
    s.addi       s11, s29, #6400
    v.ld.w       v21, [s11, #0]
    vf.abs       v22, v21
    vf.max.ieee  v21, v12, v22
    s.addi       s11, s29, #7424
    v.ld.w       v12, [s11, #0]
    vf.abs       v22, v12
    vf.max.ieee  v12, v21, v22
    vf.reduce.max.b v21, v12
    s.addi       s11, s29, #320
    v.ld.w       v12, [s11, #0]
    vf.abs       v22, v12
    s.addi       s11, s29, #1344
    v.ld.w       v12, [s11, #0]
    vf.abs       v23, v12
    vf.max.ieee  v12, v22, v23
    s.addi       s11, s29, #2368
    v.ld.w       v22, [s11, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v12, v23
    s.addi       s11, s29, #3392
    v.ld.w       v12, [s11, #0]
    vf.abs       v23, v12
    vf.max.ieee  v12, v22, v23
    s.addi       s11, s29, #4416
    v.ld.w       v22, [s11, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v12, v23
    s.addi       s11, s29, #5440
    v.ld.w       v12, [s11, #0]
    vf.abs       v23, v12
    vf.max.ieee  v12, v22, v23
    s.addi       s11, s29, #6464
    v.ld.w       v22, [s11, #0]
    vf.abs       v23, v22
    vf.max.ieee  v22, v12, v23
    s.addi       s11, s29, #7488
    v.ld.w       v12, [s11, #0]
    vf.abs       v23, v12
    vf.max.ieee  v12, v22, v23
    vf.reduce.max.b v22, v12
    s.addi       s11, s29, #384
    v.ld.w       v12, [s11, #0]
    vf.abs       v23, v12
    s.addi       s11, s29, #1408
    v.ld.w       v12, [s11, #0]
    vf.abs       v24, v12
    vf.max.ieee  v12, v23, v24
    s.addi       s11, s29, #2432
    v.ld.w       v23, [s11, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v12, v24
    s.addi       s11, s29, #3456
    v.ld.w       v12, [s11, #0]
    vf.abs       v24, v12
    vf.max.ieee  v12, v23, v24
    s.addi       s11, s29, #4480
    v.ld.w       v23, [s11, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v12, v24
    s.addi       s11, s29, #5504
    v.ld.w       v12, [s11, #0]
    vf.abs       v24, v12
    vf.max.ieee  v12, v23, v24
    s.addi       s11, s29, #6528
    v.ld.w       v23, [s11, #0]
    vf.abs       v24, v23
    vf.max.ieee  v23, v12, v24
    s.addi       s11, s29, #7552
    v.ld.w       v12, [s11, #0]
    vf.abs       v24, v12
    vf.max.ieee  v12, v23, v24
    vf.reduce.max.b v23, v12
    s.addi       s11, s29, #448
    v.ld.w       v12, [s11, #0]
    vf.abs       v24, v12
    s.addi       s11, s29, #1472
    v.ld.w       v12, [s11, #0]
    vf.abs       v26, v12
    vf.max.ieee  v12, v24, v26
    s.addi       s11, s29, #2496
    v.ld.w       v24, [s11, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v12, v26
    s.addi       s11, s29, #3520
    v.ld.w       v12, [s11, #0]
    vf.abs       v26, v12
    vf.max.ieee  v12, v24, v26
    s.addi       s11, s29, #4544
    v.ld.w       v24, [s11, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v12, v26
    s.addi       s11, s29, #5568
    v.ld.w       v12, [s11, #0]
    vf.abs       v26, v12
    vf.max.ieee  v12, v24, v26
    s.addi       s11, s29, #6592
    v.ld.w       v24, [s11, #0]
    vf.abs       v26, v24
    vf.max.ieee  v24, v12, v26
    s.addi       s11, s29, #7616
    v.ld.w       v12, [s11, #0]
    vf.abs       v26, v12
    vf.max.ieee  v12, v24, v26
    vf.reduce.max.b v24, v12
    s.addi       s11, s29, #512
    v.ld.w       v12, [s11, #0]
    vf.abs       v26, v12
    s.addi       s11, s29, #1536
    v.ld.w       v12, [s11, #0]
    vf.abs       v27, v12
    vf.max.ieee  v12, v26, v27
    s.addi       s11, s29, #2560
    v.ld.w       v26, [s11, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v12, v27
    s.addi       s11, s29, #3584
    v.ld.w       v12, [s11, #0]
    vf.abs       v27, v12
    vf.max.ieee  v12, v26, v27
    s.addi       s11, s29, #4608
    v.ld.w       v26, [s11, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v12, v27
    s.addi       s11, s29, #5632
    v.ld.w       v12, [s11, #0]
    vf.abs       v27, v12
    vf.max.ieee  v12, v26, v27
    s.addi       s11, s29, #6656
    v.ld.w       v26, [s11, #0]
    vf.abs       v27, v26
    vf.max.ieee  v26, v12, v27
    s.addi       s11, s29, #7680
    v.ld.w       v12, [s11, #0]
    vf.abs       v27, v12
    vf.max.ieee  v12, v26, v27
    vf.reduce.max.b v26, v12
    s.addi       s11, s29, #576
    v.ld.w       v12, [s11, #0]
    vf.abs       v27, v12
    s.addi       s11, s29, #1600
    v.ld.w       v12, [s11, #0]
    vf.abs       v28, v12
    vf.max.ieee  v12, v27, v28
    s.addi       s11, s29, #2624
    v.ld.w       v27, [s11, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v12, v28
    s.addi       s11, s29, #3648
    v.ld.w       v12, [s11, #0]
    vf.abs       v28, v12
    vf.max.ieee  v12, v27, v28
    s.addi       s11, s29, #4672
    v.ld.w       v27, [s11, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v12, v28
    s.addi       s11, s29, #5696
    v.ld.w       v12, [s11, #0]
    vf.abs       v28, v12
    vf.max.ieee  v12, v27, v28
    s.addi       s11, s29, #6720
    v.ld.w       v27, [s11, #0]
    vf.abs       v28, v27
    vf.max.ieee  v27, v12, v28
    s.addi       s11, s29, #7744
    v.ld.w       v12, [s11, #0]
    vf.abs       v28, v12
    vf.max.ieee  v12, v27, v28
    vf.reduce.max.b v27, v12
    s.addi       s11, s29, #640
    v.ld.w       v12, [s11, #0]
    vf.abs       v28, v12
    s.addi       s11, s29, #1664
    v.ld.w       v12, [s11, #0]
    vf.abs       v29, v12
    vf.max.ieee  v12, v28, v29
    s.addi       s11, s29, #2688
    v.ld.w       v28, [s11, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v12, v29
    s.addi       s11, s29, #3712
    v.ld.w       v12, [s11, #0]
    vf.abs       v29, v12
    vf.max.ieee  v12, v28, v29
    s.addi       s11, s29, #4736
    v.ld.w       v28, [s11, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v12, v29
    s.addi       s11, s29, #5760
    v.ld.w       v12, [s11, #0]
    vf.abs       v29, v12
    vf.max.ieee  v12, v28, v29
    s.addi       s11, s29, #6784
    v.ld.w       v28, [s11, #0]
    vf.abs       v29, v28
    vf.max.ieee  v28, v12, v29
    s.addi       s11, s29, #7808
    v.ld.w       v12, [s11, #0]
    vf.abs       v29, v12
    vf.max.ieee  v12, v28, v29
    vf.reduce.max.b v28, v12
    s.addi       s11, s29, #704
    v.ld.w       v12, [s11, #0]
    vf.abs       v29, v12
    s.addi       s11, s29, #1728
    v.ld.w       v12, [s11, #0]
    vf.abs       v30, v12
    vf.max.ieee  v12, v29, v30
    s.addi       s11, s29, #2752
    v.ld.w       v29, [s11, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v12, v30
    s.addi       s11, s29, #3776
    v.ld.w       v12, [s11, #0]
    vf.abs       v30, v12
    vf.max.ieee  v12, v29, v30
    s.addi       s11, s29, #4800
    v.ld.w       v29, [s11, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v12, v30
    s.addi       s11, s29, #5824
    v.ld.w       v12, [s11, #0]
    vf.abs       v30, v12
    vf.max.ieee  v12, v29, v30
    s.addi       s11, s29, #6848
    v.ld.w       v29, [s11, #0]
    vf.abs       v30, v29
    vf.max.ieee  v29, v12, v30
    s.addi       s11, s29, #7872
    v.ld.w       v12, [s11, #0]
    vf.abs       v30, v12
    vf.max.ieee  v12, v29, v30
    vf.reduce.max.b v29, v12
    s.addi       s11, s29, #768
    v.ld.w       v12, [s11, #0]
    vf.abs       v30, v12
    s.addi       s11, s29, #1792
    v.ld.w       v12, [s11, #0]
    vf.abs       v31, v12
    vf.max.ieee  v12, v30, v31
    s.addi       s11, s29, #2816
    v.ld.w       v30, [s11, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v12, v31
    s.addi       s11, s29, #3840
    v.ld.w       v12, [s11, #0]
    vf.abs       v31, v12
    vf.max.ieee  v12, v30, v31
    s.addi       s11, s29, #4864
    v.ld.w       v30, [s11, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v12, v31
    s.addi       s11, s29, #5888
    v.ld.w       v12, [s11, #0]
    vf.abs       v31, v12
    vf.max.ieee  v12, v30, v31
    s.addi       s11, s29, #6912
    v.ld.w       v30, [s11, #0]
    vf.abs       v31, v30
    vf.max.ieee  v30, v12, v31
    s.addi       s11, s29, #7936
    v.ld.w       v12, [s11, #0]
    vf.abs       v31, v12
    vf.max.ieee  v12, v30, v31
    vf.reduce.max.b v30, v12
    s.addi       s11, s29, #832
    v.ld.w       v12, [s11, #0]
    vf.abs       v31, v12
    s.addi       s11, s29, #1856
    v.ld.w       v12, [s11, #0]
    vf.abs       v32, v12
    vf.max.ieee  v12, v31, v32
    s.addi       s11, s29, #2880
    v.ld.w       v31, [s11, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v12, v32
    s.addi       s11, s29, #3904
    v.ld.w       v12, [s11, #0]
    vf.abs       v32, v12
    vf.max.ieee  v12, v31, v32
    s.addi       s11, s29, #4928
    v.ld.w       v31, [s11, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v12, v32
    s.addi       s11, s29, #5952
    v.ld.w       v12, [s11, #0]
    vf.abs       v32, v12
    vf.max.ieee  v12, v31, v32
    s.addi       s11, s29, #6976
    v.ld.w       v31, [s11, #0]
    vf.abs       v32, v31
    vf.max.ieee  v31, v12, v32
    s.addi       s11, s29, #8000
    v.ld.w       v12, [s11, #0]
    vf.abs       v32, v12
    vf.max.ieee  v12, v31, v32
    vf.reduce.max.b v31, v12
    s.addi       s11, s29, #896
    v.ld.w       v12, [s11, #0]
    vf.abs       v32, v12
    s.addi       s11, s29, #1920
    v.ld.w       v12, [s11, #0]
    vf.abs       v33, v12
    vf.max.ieee  v12, v32, v33
    s.addi       s11, s29, #2944
    v.ld.w       v32, [s11, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v12, v33
    s.addi       s11, s29, #3968
    v.ld.w       v12, [s11, #0]
    vf.abs       v33, v12
    vf.max.ieee  v12, v32, v33
    s.addi       s11, s29, #4992
    v.ld.w       v32, [s11, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v12, v33
    s.addi       s11, s29, #6016
    v.ld.w       v12, [s11, #0]
    vf.abs       v33, v12
    vf.max.ieee  v12, v32, v33
    s.addi       s11, s29, #7040
    v.ld.w       v32, [s11, #0]
    vf.abs       v33, v32
    vf.max.ieee  v32, v12, v33
    s.addi       s11, s29, #8064
    v.ld.w       v12, [s11, #0]
    vf.abs       v33, v12
    vf.max.ieee  v12, v32, v33
    vf.reduce.max.b v32, v12
    s.addi       s11, s29, #960
    v.ld.w       v12, [s11, #0]
    vf.abs       v33, v12
    s.addi       s11, s29, #1984
    v.ld.w       v12, [s11, #0]
    vf.abs       v34, v12
    vf.max.ieee  v12, v33, v34
    s.addi       s11, s29, #3008
    v.ld.w       v33, [s11, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v12, v34
    s.addi       s11, s29, #4032
    v.ld.w       v12, [s11, #0]
    vf.abs       v34, v12
    vf.max.ieee  v12, v33, v34
    s.addi       s11, s29, #5056
    v.ld.w       v33, [s11, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v12, v34
    s.addi       s11, s29, #6080
    v.ld.w       v12, [s11, #0]
    vf.abs       v34, v12
    vf.max.ieee  v12, v33, v34
    s.addi       s11, s29, #7104
    v.ld.w       v33, [s11, #0]
    vf.abs       v34, v33
    vf.max.ieee  v33, v12, v34
    s.addi       s11, s29, #8128
    v.ld.w       v12, [s11, #0]
    vf.abs       v34, v12
    vf.max.ieee  v12, v33, v34
    vf.reduce.max.b v33, v12
    v.movi       v12, #0
    // one value per row into one vector (ISA 0x09)
    v.extract    s11, v14, #0
    v.insert     v12, s11, #0
    v.extract    s11, v17, #0
    v.insert     v12, s11, #1
    v.extract    s11, v18, #0
    v.insert     v12, s11, #2
    v.extract    s11, v19, #0
    v.insert     v12, s11, #3
    v.extract    s11, v21, #0
    v.insert     v12, s11, #4
    v.extract    s11, v22, #0
    v.insert     v12, s11, #5
    v.extract    s11, v23, #0
    v.insert     v12, s11, #6
    v.extract    s11, v24, #0
    v.insert     v12, s11, #7
    v.extract    s11, v26, #0
    v.insert     v12, s11, #8
    v.extract    s11, v27, #0
    v.insert     v12, s11, #9
    v.extract    s11, v28, #0
    v.insert     v12, s11, #10
    v.extract    s11, v29, #0
    v.insert     v12, s11, #11
    v.extract    s11, v30, #0
    v.insert     v12, s11, #12
    v.extract    s11, v31, #0
    v.insert     v12, s11, #13
    v.extract    s11, v32, #0
    v.insert     v12, s11, #14
    v.extract    s11, v33, #0
    v.insert     v12, s11, #15
    .li       s11, #1138753536
    v.splat      v14, s11                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.rcp.approx v17, v14                        // ISA 8.8: <= 2**-22 relative
    .li       s11, #1065353216
    v.splat      v18, s11                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    vf.fms       v19, v14, v17, v18
    vf.fms       v21, v17, v19, v17
    vf.neg       v19, v21                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v19, v19
    @p1 v.sel        v21, v19, v17
    vf.mul       v17, v12, v21                   // a/y: faithful quotient
    vf.fms       v19, v17, v14, v12
    vf.fms       v12, v19, v21, v17
    vf.neg       v14, v12                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v14, v14
    @p1 v.sel        v12, v14, v17
    .li       s11, #730643660
    v.splat      v14, s11                        // a 32-bit constant does not fit v.movi (ISA 0x40)
    v.splat      v17, s13
    v.mul        v19, v20, v17
    v.splat      v17, s13
    v.mul        v21, v13, v17
    v.splat      v17, s13
    v.mul        v22, v11, v17
    v.splat      v17, s13
    v.mul        v23, v8, v17
    v.splat      v17, s13
    v.mul        v24, v7, v17
    v.splat      v17, s13
    v.mul        v26, v5, v17
    v.splat      v17, s13
    v.mul        v27, v9, v17
    v.splat      v17, s13
    v.mul        v28, v2, v17
    v.ld.gather.w v17, [s16, v25]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v29, [s16, v0]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v30, [s16, v1]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v31, [s16, v10]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v32, [s16, v15]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v33, [s16, v16]                // index is in elements (ISA sec 9.1)
    v.ld.gather.w v34, [s16, v4]                 // index is in elements (ISA sec 9.1)
    v.ld.gather.w v35, [s16, v3]                 // index is in elements (ISA sec 9.1)
    s.add        s11, s23, s28
    // tl.dot 16x128 by 128x128 FP8, B as W's rows written transposed by the engine (ISA sec 9E, tensor_transpose_8bit)
    v.movi       v36, #0
    v.movi       v37, #0
    v.iota       v38                             // arange(0, VLEN)
    s.movz       s28, #0
    s.cmp.ge     s30, s11, s28
    v.extract    s28, v20, #0
    v.splat      v39, s28
    v.add        v40, v39, v38
    v.sub        v39, v20, v40
    v.reduce.or  s31, v39
    s.movz       s32, #0
    s.cmp.eq     s33, s31, s32
    s.movz       s31, #0
    s.cmp.ge     s32, s28, s31
    s.and        s31, s33, s32
    s.and        s32, s31, s30
    v.insert     v36, s32, #0
    v.insert     v37, s28, #0
    v.extract    s28, v13, #0
    v.splat      v39, s28
    v.add        v40, v39, v38
    v.sub        v39, v13, v40
    v.reduce.or  s31, v39
    s.movz       s32, #0
    s.cmp.eq     s33, s31, s32
    s.movz       s31, #0
    s.cmp.ge     s32, s28, s31
    s.and        s31, s33, s32
    s.and        s32, s31, s30
    v.insert     v36, s32, #1
    v.insert     v37, s28, #1
    v.extract    s28, v11, #0
    v.splat      v39, s28
    v.add        v40, v39, v38
    v.sub        v39, v11, v40
    v.reduce.or  s31, v39
    s.movz       s32, #0
    s.cmp.eq     s33, s31, s32
    s.movz       s31, #0
    s.cmp.ge     s32, s28, s31
    s.and        s31, s33, s32
    s.and        s32, s31, s30
    v.insert     v36, s32, #2
    v.insert     v37, s28, #2
    v.extract    s28, v8, #0
    v.splat      v39, s28
    v.add        v40, v39, v38
    v.sub        v39, v8, v40
    v.reduce.or  s31, v39
    s.movz       s32, #0
    s.cmp.eq     s33, s31, s32
    s.movz       s31, #0
    s.cmp.ge     s32, s28, s31
    s.and        s31, s33, s32
    s.and        s32, s31, s30
    v.insert     v36, s32, #3
    v.insert     v37, s28, #3
    v.extract    s28, v7, #0
    v.splat      v39, s28
    v.add        v40, v39, v38
    v.sub        v39, v7, v40
    v.reduce.or  s31, v39
    s.movz       s32, #0
    s.cmp.eq     s33, s31, s32
    s.movz       s31, #0
    s.cmp.ge     s32, s28, s31
    s.and        s31, s33, s32
    s.and        s32, s31, s30
    v.insert     v36, s32, #4
    v.insert     v37, s28, #4
    v.extract    s28, v5, #0
    v.splat      v39, s28
    v.add        v40, v39, v38
    v.sub        v39, v5, v40
    v.reduce.or  s31, v39
    s.movz       s32, #0
    s.cmp.eq     s33, s31, s32
    s.movz       s31, #0
    s.cmp.ge     s32, s28, s31
    s.and        s31, s33, s32
    s.and        s32, s31, s30
    v.insert     v36, s32, #5
    v.insert     v37, s28, #5
    v.extract    s28, v9, #0
    v.splat      v39, s28
    v.add        v40, v39, v38
    v.sub        v39, v9, v40
    v.reduce.or  s31, v39
    s.movz       s32, #0
    s.cmp.eq     s33, s31, s32
    s.movz       s31, #0
    s.cmp.ge     s32, s28, s31
    s.and        s31, s33, s32
    s.and        s32, s31, s30
    v.insert     v36, s32, #6
    v.insert     v37, s28, #6
    v.extract    s28, v2, #0
    v.splat      v39, s28
    v.add        v40, v39, v38
    v.sub        v38, v2, v40
    v.reduce.or  s31, v38
    s.movz       s32, #0
    s.cmp.eq     s33, s31, s32
    s.movz       s31, #0
    s.cmp.ge     s32, s28, s31
    s.and        s31, s33, s32
    s.and        s32, s31, s30
    v.insert     v36, s32, #7
    v.insert     v37, s28, #7
    s.add        s28, s10, s24
    s.addi       s30, s29, #8192                 // TensorMap 0: W's rows for a transposed FP8 B
    s.movz       s31, #0
    s.st.d       [s30, #0], s28
    .li       s28, #2147483647
    s.st.d       [s30, #8], s28
    s.st.d       [s30, #16], s11
    s.st.d       [s30, #48], s13
    s.movz       s28, #1
    s.st.d       [s30, #56], s28
    .li       s28, #137438953488
    s.st.d       [s30, #88], s28
    .li       s28, #7705171329024
    s.st.d       [s30, #104], s28
    td.load      d0, [s30]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.addi       s28, s29, #8448
    s.addi       s30, s29, #8960                 // TensorMap 1: the gathered fallback B tile
    s.movz       s31, #0
    s.st.d       [s30, #0], s28
    s.movz       s28, #32
    s.st.d       [s30, #8], s28
    s.movz       s28, #16
    s.st.d       [s30, #16], s28
    s.movz       s28, #16
    s.st.d       [s30, #48], s28
    s.movz       s28, #1
    s.st.d       [s30, #56], s28
    .li       s28, #68719476768
    s.st.d       [s30, #88], s28
    .li       s28, #7705171329024
    s.st.d       [s30, #104], s28
    td.load      d1, [s30]                       // a versioned snapshot, not a pointer (ISA sec 9D.1)
    m.zero       a8
    m.zero       a9
    m.zero       a10
    m.zero       a11
    m.zero       a12
    m.zero       a13
    m.zero       a14
    m.zero       a15
    s.addi       s28, s29, #9216                 // 512 bytes of repack scratch
    s.addi       s30, s29, #0
    v.ld.w       v38, [s30, #0]
    v.extract    s30, v12, #0
    v.splat      v39, s30
    vf.max.ieee  v40, v39, v14
    v.rcp.approx v39, v40                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v41, v40, v39, v18
    vf.fms       v42, v39, v41, v39
    vf.neg       v41, v42                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v42, v41, v39
    vf.mul       v39, v38, v42                   // a/y: faithful quotient
    vf.fms       v41, v39, v40, v38
    vf.fms       v38, v41, v42, v39
    vf.neg       v40, v38                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v40, v40
    @p1 v.sel        v38, v40, v39
    vf.cvt.f32.e4m3 v39, v38
    v.movi       v40, #24
    v.lshr       v41, v38, v40
    v.movi       v38, #128
    v.and        v42, v41, v38
    v.or         v41, v39, v42                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #0
    v.st.b       [s30, #0], v41
    s.addi       s30, s29, #64
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #1
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #32
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #128
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #2
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #64
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #192
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #3
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #96
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #256
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #4
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #128
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #320
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #5
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #160
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #384
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #6
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #192
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #448
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #7
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #224
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #512
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #8
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #256
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #576
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #9
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #288
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #640
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #10
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #320
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #704
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #11
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #352
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #768
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #12
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #384
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #832
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #13
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #416
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #896
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #14
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #448
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #960
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #15
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #480
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1024
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #0
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #16
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1088
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #1
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #48
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1152
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #2
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #80
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1216
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #3
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #112
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1280
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #4
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #144
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1344
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #5
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #176
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1408
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #6
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #208
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1472
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #7
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #240
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1536
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #8
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #272
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1600
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #9
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #304
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1664
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #10
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #336
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1728
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #11
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #368
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1792
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #12
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #400
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1856
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #13
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #432
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1920
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #14
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #464
    v.st.b       [s30, #0], v42
    s.addi       s30, s29, #1984
    v.ld.w       v39, [s30, #0]
    v.extract    s30, v12, #15
    v.splat      v41, s30
    vf.max.ieee  v42, v41, v14
    v.rcp.approx v41, v42                        // ISA 8.8: <= 2**-22 relative
    vf.fms       v43, v42, v41, v18
    vf.fms       v44, v41, v43, v41
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v41
    vf.mul       v41, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v41, v42, v39
    vf.fms       v39, v43, v44, v41
    vf.neg       v42, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v39, v42, v41
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    s.addi       s30, s28, #496
    v.st.b       [s30, #0], v42
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    v.ld.w       v39, [s28, #0]
    v.mov        v48, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s30, s28, #64
    v.ld.w       v39, [s30, #0]
    v.mov        v49, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s30, s28, #128
    v.ld.w       v39, [s30, #0]
    v.mov        v50, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s30, s28, #192
    v.ld.w       v39, [s30, #0]
    v.mov        v51, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s30, s28, #256
    v.ld.w       v39, [s30, #0]
    v.mov        v52, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s30, s28, #320
    v.ld.w       v39, [s30, #0]
    v.mov        v53, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s30, s28, #384
    v.ld.w       v39, [s30, #0]
    v.mov        v54, v39                        // hand off through the shared window (sec 7.3)
    s.addi       s30, s28, #448
    v.ld.w       v39, [s30, #0]
    v.mov        v55, v39                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    v.extract    s28, v36, #0
    br.nz        s28, x8dot_done_28
    s.movz       s30, #0
    s.add        s31, s10, s24
    s.addi       s32, s30, #0
    s.addi       s30, s29, #8448
x8dot_row_29:
    s.addi       s33, s11, #0
    v.movi       v39, #0
    s.sub        s34, s33, s32
    s.add        s33, s31, s32
    v.splat      v41, s34
    s.shli       s34, s32, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s33, v19]            // index is in elements (ISA sec 9.1)
    s.add        s33, s30, s34
    s.addi       s34, s32, #1
    s.movz       s35, #32
    v.st.b       [s33, #0], v39
    fence.acq_rel.device
    s.mov        s32, s34
    s.cmp.lt     s33, s32, s35
    br.nz        s33, x8dot_row_29
x8dot_done_28:
    v.splat      v39, s28
    v.movi       v41, #0
    mb.arm       s30, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s31, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s28
    v.movi       v41, #0
    s.movz       s28, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s32, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s32, s30            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s28, #0
    v.extract    s31, v37, #0
    s.mov        s32, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s28                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s30          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s30
    mb.arm       s28, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s31, v36, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s28
    mb.wait      s28
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s31, x8dot_done_30
    s.movz       s32, #0
    s.add        s33, s10, s24
    s.addi       s34, s32, #0
    s.addi       s32, s29, #8448
x8dot_row_31:
    s.addi       s35, s11, #0
    v.movi       v39, #0
    s.sub        s36, s35, s34
    s.add        s35, s33, s34
    v.splat      v41, s36
    s.shli       s36, s34, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s35, v21]            // index is in elements (ISA sec 9.1)
    s.add        s35, s32, s36
    s.addi       s36, s34, #1
    s.movz       s37, #32
    v.st.b       [s35, #0], v39
    fence.acq_rel.device
    s.mov        s34, s36
    s.cmp.lt     s35, s34, s37
    br.nz        s35, x8dot_row_31
x8dot_done_30:
    v.splat      v39, s31
    v.movi       v41, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s31
    v.movi       v41, #0
    s.movz       s31, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s32            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s31, #0
    v.extract    s33, v37, #1
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v36, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_32
    s.movz       s34, #0
    s.add        s35, s10, s24
    s.addi       s36, s34, #0
    s.addi       s34, s29, #8448
x8dot_row_33:
    s.addi       s37, s11, #0
    v.movi       v39, #0
    s.sub        s38, s37, s36
    s.add        s37, s35, s36
    v.splat      v41, s38
    s.shli       s38, s36, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s37, v22]            // index is in elements (ISA sec 9.1)
    s.add        s37, s34, s38
    s.addi       s38, s36, #1
    s.movz       s39, #32
    v.st.b       [s37, #0], v39
    fence.acq_rel.device
    s.mov        s36, s38
    s.cmp.lt     s37, s36, s39
    br.nz        s37, x8dot_row_33
x8dot_done_32:
    v.splat      v39, s33
    v.movi       v41, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s35, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s33
    v.movi       v41, #0
    s.movz       s33, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s34            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s33, #0
    v.extract    s35, v37, #2
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v36, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s33
    mb.wait      s33
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_34
    s.movz       s36, #0
    s.add        s37, s10, s24
    s.addi       s38, s36, #0
    s.addi       s36, s29, #8448
x8dot_row_35:
    s.addi       s39, s11, #0
    v.movi       v39, #0
    s.sub        s40, s39, s38
    s.add        s39, s37, s38
    v.splat      v41, s40
    s.shli       s40, s38, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s39, v23]            // index is in elements (ISA sec 9.1)
    s.add        s39, s36, s40
    s.addi       s40, s38, #1
    s.movz       s41, #32
    v.st.b       [s39, #0], v39
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s39, s38, s41
    br.nz        s39, x8dot_row_35
x8dot_done_34:
    v.splat      v39, s35
    v.movi       v41, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s35
    v.movi       v41, #0
    s.movz       s35, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s36            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s35, #0
    v.extract    s37, v37, #3
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v36, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_36
    s.movz       s38, #0
    s.add        s39, s10, s24
    s.addi       s40, s38, #0
    s.addi       s38, s29, #8448
x8dot_row_37:
    s.addi       s41, s11, #0
    v.movi       v39, #0
    s.sub        s42, s41, s40
    s.add        s41, s39, s40
    v.splat      v41, s42
    s.shli       s42, s40, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s41, v24]            // index is in elements (ISA sec 9.1)
    s.add        s41, s38, s42
    s.addi       s42, s40, #1
    s.movz       s43, #32
    v.st.b       [s41, #0], v39
    fence.acq_rel.device
    s.mov        s40, s42
    s.cmp.lt     s41, s40, s43
    br.nz        s41, x8dot_row_37
x8dot_done_36:
    v.splat      v39, s37
    v.movi       v41, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s37
    v.movi       v41, #0
    s.movz       s37, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s40, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s38            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s37, #0
    v.extract    s39, v37, #4
    s.mov        s40, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s40, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v36, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s39, x8dot_done_38
    s.movz       s40, #0
    s.add        s41, s10, s24
    s.addi       s42, s40, #0
    s.addi       s40, s29, #8448
x8dot_row_39:
    s.addi       s43, s11, #0
    v.movi       v39, #0
    s.sub        s44, s43, s42
    s.add        s43, s41, s42
    v.splat      v41, s44
    s.shli       s44, s42, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s43, v26]            // index is in elements (ISA sec 9.1)
    s.add        s43, s40, s44
    s.addi       s44, s42, #1
    s.movz       s45, #32
    v.st.b       [s43, #0], v39
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s43, s42, s45
    br.nz        s43, x8dot_row_39
x8dot_done_38:
    v.splat      v39, s39
    v.movi       v41, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s39
    v.movi       v41, #0
    s.movz       s39, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s40            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s39, #0
    v.extract    s41, v37, #5
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v36, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s41, x8dot_done_40
    s.movz       s42, #0
    s.add        s43, s10, s24
    s.addi       s44, s42, #0
    s.addi       s42, s29, #8448
x8dot_row_41:
    s.addi       s45, s11, #0
    v.movi       v39, #0
    s.sub        s46, s45, s44
    s.add        s45, s43, s44
    v.splat      v41, s46
    s.shli       s46, s44, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s45, v27]            // index is in elements (ISA sec 9.1)
    s.add        s45, s42, s46
    s.addi       s46, s44, #1
    s.movz       s47, #32
    v.st.b       [s45, #0], v39
    fence.acq_rel.device
    s.mov        s44, s46
    s.cmp.lt     s45, s44, s47
    br.nz        s45, x8dot_row_41
x8dot_done_40:
    v.splat      v39, s41
    v.movi       v41, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s41
    v.movi       v41, #0
    s.movz       s41, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s44, s42            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s41, #0
    v.extract    s43, v37, #6
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v36, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s43, x8dot_done_42
    s.movz       s44, #0
    s.add        s45, s10, s24
    s.addi       s46, s44, #0
    s.addi       s44, s29, #8448
x8dot_row_43:
    s.addi       s47, s11, #0
    v.movi       v39, #0
    s.sub        s48, s47, s46
    s.add        s47, s45, s46
    v.splat      v41, s48
    s.shli       s48, s46, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s47, v28]            // index is in elements (ISA sec 9.1)
    s.add        s47, s44, s48
    s.addi       s48, s46, #1
    s.movz       s49, #32
    v.st.b       [s47, #0], v39
    fence.acq_rel.device
    s.mov        s46, s48
    s.cmp.lt     s47, s46, s49
    br.nz        s47, x8dot_row_43
x8dot_done_42:
    v.splat      v39, s43
    v.movi       v41, #0
    v.splat      v42, s43
    v.movi       v43, #0
    mb.arm       s43, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s44, #0
    s.movz       s45, #0
    v.cmp.ne     p1, v39, v41
    v.cmp.eq     p2, v42, v43
    s.mov        s46, s44                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s46, s43            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s44, v12, #0
    v.splat      v39, s44
    s.movz       s44, #0
    vf.max.ieee  v41, v39, v14
    v.extract    s45, v37, #7
    s.mov        s46, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s44                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s43          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s43
    v.rcp.approx v39, v41                        // ISA 8.8: <= 2**-22 relative
    mb.arm       s44, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s45, s29, #2048
    m.mma.async.k32.e4m3 a15, v48, v56, s44
    mb.wait      s44
    v.ld.w       v42, [s45, #0]
    s.addi       s45, s29, #9728                 // 512 bytes of repack scratch
    s.addi       s46, s45, #0
    vf.fms       v43, v41, v39, v18
    vf.fms       v44, v39, v43, v39
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v39
    vf.mul       v39, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v39, v41, v42
    vf.fms       v41, v43, v44, v39
    vf.neg       v42, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v41, v42, v39
    vf.cvt.f32.e4m3 v39, v41
    v.lshr       v42, v41, v40
    v.and        v41, v42, v38
    v.or         v42, v39, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #1
    v.splat      v39, s46
    s.addi       s46, s29, #2112
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #32
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #2
    v.splat      v39, s46
    s.addi       s46, s29, #2176
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #64
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #3
    v.splat      v39, s46
    s.addi       s46, s29, #2240
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #96
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #4
    v.splat      v39, s46
    s.addi       s46, s29, #2304
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #128
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #5
    v.splat      v39, s46
    s.addi       s46, s29, #2368
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #160
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #6
    v.splat      v39, s46
    s.addi       s46, s29, #2432
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #192
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #7
    v.splat      v39, s46
    s.addi       s46, s29, #2496
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #224
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #8
    v.splat      v39, s46
    s.addi       s46, s29, #2560
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #256
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #9
    v.splat      v39, s46
    s.addi       s46, s29, #2624
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #288
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #10
    v.splat      v39, s46
    s.addi       s46, s29, #2688
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #320
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #11
    v.splat      v39, s46
    s.addi       s46, s29, #2752
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #352
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #12
    v.splat      v39, s46
    s.addi       s46, s29, #2816
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #384
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #13
    v.splat      v39, s46
    s.addi       s46, s29, #2880
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #416
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #14
    v.splat      v39, s46
    s.addi       s46, s29, #2944
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #448
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #15
    v.splat      v39, s46
    s.addi       s46, s29, #3008
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #480
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #0
    v.splat      v39, s46
    s.addi       s46, s29, #3072
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #16
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #1
    v.splat      v39, s46
    s.addi       s46, s29, #3136
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #48
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #2
    v.splat      v39, s46
    s.addi       s46, s29, #3200
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #80
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #3
    v.splat      v39, s46
    s.addi       s46, s29, #3264
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #112
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #4
    v.splat      v39, s46
    s.addi       s46, s29, #3328
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #144
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #5
    v.splat      v39, s46
    s.addi       s46, s29, #3392
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #176
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #6
    v.splat      v39, s46
    s.addi       s46, s29, #3456
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #208
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #7
    v.splat      v39, s46
    s.addi       s46, s29, #3520
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #240
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #8
    v.splat      v39, s46
    s.addi       s46, s29, #3584
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #272
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #9
    v.splat      v39, s46
    s.addi       s46, s29, #3648
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #304
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #10
    v.splat      v39, s46
    s.addi       s46, s29, #3712
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #336
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #11
    v.splat      v39, s46
    s.addi       s46, s29, #3776
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #368
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #12
    v.splat      v39, s46
    s.addi       s46, s29, #3840
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #400
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #13
    v.splat      v39, s46
    s.addi       s46, s29, #3904
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #432
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #14
    v.splat      v39, s46
    s.addi       s46, s29, #3968
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #464
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    v.extract    s46, v12, #15
    v.splat      v39, s46
    s.addi       s46, s29, #4032
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s46, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s46, s45, #496
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s46, #0], v42
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s46, s45, #64
    v.ld.w       v39, [s45, #0]
    v.mov        v48, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s46, #0]
    s.addi       s46, s45, #128
    v.mov        v49, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s46, #0]
    s.addi       s46, s45, #192
    v.mov        v50, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s46, #0]
    s.addi       s46, s45, #256
    v.mov        v51, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s46, #0]
    s.addi       s46, s45, #320
    v.mov        v52, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s46, #0]
    s.addi       s46, s45, #384
    s.addi       s47, s45, #448
    v.mov        v53, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s46, #0]
    v.extract    s45, v36, #0
    v.mov        v54, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s47, #0]
    v.mov        v55, v39                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s45, x8dot_done_44
    s.movz       s46, #0
    s.add        s47, s10, s24
    s.addi       s48, s46, #0
    s.addi       s46, s47, #32
    s.addi       s47, s29, #8448
x8dot_row_45:
    s.addi       s49, s11, #-32
    v.movi       v39, #0
    s.sub        s50, s49, s48
    s.add        s49, s46, s48
    v.splat      v41, s50
    s.shli       s50, s48, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s49, v19]            // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.addi       s50, s48, #1
    s.movz       s51, #32
    v.st.b       [s49, #0], v39
    fence.acq_rel.device
    s.mov        s48, s50
    s.cmp.lt     s49, s48, s51
    br.nz        s49, x8dot_row_45
x8dot_done_44:
    v.splat      v39, s45
    v.movi       v41, #0
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s45
    v.movi       v41, #0
    s.movz       s45, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s48, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s48, s46            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s45, #32
    v.extract    s47, v37, #0
    s.mov        s48, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s48, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v36, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s45
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s47, x8dot_done_46
    s.movz       s48, #0
    s.add        s49, s10, s24
    s.addi       s50, s48, #0
    s.addi       s48, s49, #32
    s.addi       s49, s29, #8448
x8dot_row_47:
    s.addi       s51, s11, #-32
    v.movi       v39, #0
    s.sub        s52, s51, s50
    s.add        s51, s48, s50
    v.splat      v41, s52
    s.shli       s52, s50, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s51, v21]            // index is in elements (ISA sec 9.1)
    s.add        s51, s49, s52
    s.addi       s52, s50, #1
    s.movz       s53, #32
    v.st.b       [s51, #0], v39
    fence.acq_rel.device
    s.mov        s50, s52
    s.cmp.lt     s51, s50, s53
    br.nz        s51, x8dot_row_47
x8dot_done_46:
    v.splat      v39, s47
    v.movi       v41, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s47
    v.movi       v41, #0
    s.movz       s47, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s50, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s50, s48            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s47, #32
    v.extract    s49, v37, #1
    s.mov        s50, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v36, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s49, x8dot_done_48
    s.movz       s50, #0
    s.add        s51, s10, s24
    s.addi       s52, s50, #0
    s.addi       s50, s51, #32
    s.addi       s51, s29, #8448
x8dot_row_49:
    s.addi       s53, s11, #-32
    v.movi       v39, #0
    s.sub        s54, s53, s52
    s.add        s53, s50, s52
    v.splat      v41, s54
    s.shli       s54, s52, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s53, v22]            // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.addi       s54, s52, #1
    s.movz       s55, #32
    v.st.b       [s53, #0], v39
    fence.acq_rel.device
    s.mov        s52, s54
    s.cmp.lt     s53, s52, s55
    br.nz        s53, x8dot_row_49
x8dot_done_48:
    v.splat      v39, s49
    v.movi       v41, #0
    mb.arm       s50, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s51, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s49
    v.movi       v41, #0
    s.movz       s49, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s52, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s52, s50            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s49, #32
    v.extract    s51, v37, #2
    s.mov        s52, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s49                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s52, s50          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s50
    mb.arm       s49, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s51, v36, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s49
    mb.wait      s49
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s51, x8dot_done_50
    s.movz       s52, #0
    s.add        s53, s10, s24
    s.addi       s54, s52, #0
    s.addi       s52, s53, #32
    s.addi       s53, s29, #8448
x8dot_row_51:
    s.addi       s55, s11, #-32
    v.movi       v39, #0
    s.sub        s56, s55, s54
    s.add        s55, s52, s54
    v.splat      v41, s56
    s.shli       s56, s54, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s55, v23]            // index is in elements (ISA sec 9.1)
    s.add        s55, s53, s56
    s.addi       s56, s54, #1
    s.movz       s57, #32
    v.st.b       [s55, #0], v39
    fence.acq_rel.device
    s.mov        s54, s56
    s.cmp.lt     s55, s54, s57
    br.nz        s55, x8dot_row_51
x8dot_done_50:
    v.splat      v39, s51
    v.movi       v41, #0
    mb.arm       s52, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s51
    v.movi       v41, #0
    s.movz       s51, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s54, s52            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s51, #32
    v.extract    s53, v37, #3
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v36, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s53, x8dot_done_52
    s.movz       s54, #0
    s.add        s55, s10, s24
    s.addi       s56, s54, #0
    s.addi       s54, s55, #32
    s.addi       s55, s29, #8448
x8dot_row_53:
    s.addi       s57, s11, #-32
    v.movi       v39, #0
    s.sub        s58, s57, s56
    s.add        s57, s54, s56
    v.splat      v41, s58
    s.shli       s58, s56, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s57, v24]            // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.addi       s58, s56, #1
    s.movz       s59, #32
    v.st.b       [s57, #0], v39
    fence.acq_rel.device
    s.mov        s56, s58
    s.cmp.lt     s57, s56, s59
    br.nz        s57, x8dot_row_53
x8dot_done_52:
    v.splat      v39, s53
    v.movi       v41, #0
    mb.arm       s54, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s55, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s53
    v.movi       v41, #0
    s.movz       s53, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s56, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s56, s54            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s53, #32
    v.extract    s55, v37, #4
    s.mov        s56, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s56, s54          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v36, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s53
    mb.wait      s53
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s55, x8dot_done_54
    s.movz       s56, #0
    s.add        s57, s10, s24
    s.addi       s58, s56, #0
    s.addi       s56, s57, #32
    s.addi       s57, s29, #8448
x8dot_row_55:
    s.addi       s59, s11, #-32
    v.movi       v39, #0
    s.sub        s60, s59, s58
    s.add        s59, s56, s58
    v.splat      v41, s60
    s.shli       s60, s58, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s59, v26]            // index is in elements (ISA sec 9.1)
    s.add        s59, s57, s60
    s.addi       s60, s58, #1
    s.movz       s28, #32
    v.st.b       [s59, #0], v39
    fence.acq_rel.device
    s.mov        s58, s60
    s.cmp.lt     s30, s58, s28
    br.nz        s30, x8dot_row_55
x8dot_done_54:
    v.splat      v39, s55
    v.movi       v41, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s30, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s55
    v.movi       v41, #0
    s.movz       s31, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s32, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s32, s28            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s30, #32
    v.extract    s31, v37, #5
    s.mov        s32, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s31, v36, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s30
    mb.wait      s30
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s31, x8dot_done_56
    s.movz       s32, #0
    s.add        s33, s10, s24
    s.addi       s34, s32, #0
    s.addi       s32, s33, #32
    s.addi       s33, s29, #8448
x8dot_row_57:
    s.addi       s35, s11, #-32
    v.movi       v39, #0
    s.sub        s36, s35, s34
    s.add        s35, s32, s34
    v.splat      v41, s36
    s.shli       s36, s34, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s35, v27]            // index is in elements (ISA sec 9.1)
    s.add        s35, s33, s36
    s.addi       s36, s34, #1
    s.movz       s37, #32
    v.st.b       [s35, #0], v39
    fence.acq_rel.device
    s.mov        s34, s36
    s.cmp.lt     s35, s34, s37
    br.nz        s35, x8dot_row_57
x8dot_done_56:
    v.splat      v39, s31
    v.movi       v41, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s31
    v.movi       v41, #0
    s.movz       s31, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s32            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s31, #32
    v.extract    s33, v37, #6
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v36, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_58
    s.movz       s34, #0
    s.add        s35, s10, s24
    s.addi       s36, s34, #0
    s.addi       s34, s35, #32
    s.addi       s35, s29, #8448
x8dot_row_59:
    s.addi       s37, s11, #-32
    v.movi       v39, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v41, s38
    s.shli       s38, s36, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s37, v28]            // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.addi       s38, s36, #1
    s.movz       s39, #32
    v.st.b       [s37, #0], v39
    fence.acq_rel.device
    s.mov        s36, s38
    s.cmp.lt     s37, s36, s39
    br.nz        s37, x8dot_row_59
x8dot_done_58:
    v.splat      v39, s33
    v.movi       v41, #0
    v.splat      v42, s33
    v.movi       v43, #0
    mb.arm       s33, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s34, #0
    s.movz       s35, #0
    v.cmp.ne     p1, v39, v41
    v.cmp.eq     p2, v42, v43
    s.mov        s36, s34                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s33            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s34, v12, #0
    v.splat      v39, s34
    s.movz       s34, #32
    vf.max.ieee  v41, v39, v14
    v.extract    s35, v37, #7
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s34                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s33          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s33
    v.rcp.approx v39, v41                        // ISA 8.8: <= 2**-22 relative
    mb.arm       s34, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s35, s29, #4096
    m.mma.async.k32.e4m3 a15, v48, v56, s34
    mb.wait      s34
    v.ld.w       v42, [s35, #0]
    s.addi       s35, s29, #10240                // 512 bytes of repack scratch
    s.addi       s36, s35, #0
    vf.fms       v43, v41, v39, v18
    vf.fms       v44, v39, v43, v39
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v39
    vf.mul       v39, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v39, v41, v42
    vf.fms       v41, v43, v44, v39
    vf.neg       v42, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v41, v42, v39
    vf.cvt.f32.e4m3 v39, v41
    v.lshr       v42, v41, v40
    v.and        v41, v42, v38
    v.or         v42, v39, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #1
    v.splat      v39, s36
    s.addi       s36, s29, #4160
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #32
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #2
    v.splat      v39, s36
    s.addi       s36, s29, #4224
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #64
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #3
    v.splat      v39, s36
    s.addi       s36, s29, #4288
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #96
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #4
    v.splat      v39, s36
    s.addi       s36, s29, #4352
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #128
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #5
    v.splat      v39, s36
    s.addi       s36, s29, #4416
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #160
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #6
    v.splat      v39, s36
    s.addi       s36, s29, #4480
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #192
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #7
    v.splat      v39, s36
    s.addi       s36, s29, #4544
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #224
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #8
    v.splat      v39, s36
    s.addi       s36, s29, #4608
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #256
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #9
    v.splat      v39, s36
    s.addi       s36, s29, #4672
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #288
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #10
    v.splat      v39, s36
    s.addi       s36, s29, #4736
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #320
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #11
    v.splat      v39, s36
    s.addi       s36, s29, #4800
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #352
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #12
    v.splat      v39, s36
    s.addi       s36, s29, #4864
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #384
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #13
    v.splat      v39, s36
    s.addi       s36, s29, #4928
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #416
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #14
    v.splat      v39, s36
    s.addi       s36, s29, #4992
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #448
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #15
    v.splat      v39, s36
    s.addi       s36, s29, #5056
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #480
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #0
    v.splat      v39, s36
    s.addi       s36, s29, #5120
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #16
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #1
    v.splat      v39, s36
    s.addi       s36, s29, #5184
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #48
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #2
    v.splat      v39, s36
    s.addi       s36, s29, #5248
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #80
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #3
    v.splat      v39, s36
    s.addi       s36, s29, #5312
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #112
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #4
    v.splat      v39, s36
    s.addi       s36, s29, #5376
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #144
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #5
    v.splat      v39, s36
    s.addi       s36, s29, #5440
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #176
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #6
    v.splat      v39, s36
    s.addi       s36, s29, #5504
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #208
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #7
    v.splat      v39, s36
    s.addi       s36, s29, #5568
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #240
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #8
    v.splat      v39, s36
    s.addi       s36, s29, #5632
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #272
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #9
    v.splat      v39, s36
    s.addi       s36, s29, #5696
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #304
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #10
    v.splat      v39, s36
    s.addi       s36, s29, #5760
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #336
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #11
    v.splat      v39, s36
    s.addi       s36, s29, #5824
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #368
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #12
    v.splat      v39, s36
    s.addi       s36, s29, #5888
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #400
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #13
    v.splat      v39, s36
    s.addi       s36, s29, #5952
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #432
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #14
    v.splat      v39, s36
    s.addi       s36, s29, #6016
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #464
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    v.extract    s36, v12, #15
    v.splat      v39, s36
    s.addi       s36, s29, #6080
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s36, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s36, s35, #496
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s36, #0], v42
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s36, s35, #64
    v.ld.w       v39, [s35, #0]
    v.mov        v48, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s36, #0]
    s.addi       s36, s35, #128
    v.mov        v49, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s36, #0]
    s.addi       s36, s35, #192
    v.mov        v50, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s36, #0]
    s.addi       s36, s35, #256
    v.mov        v51, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s36, #0]
    s.addi       s36, s35, #320
    v.mov        v52, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s36, #0]
    s.addi       s36, s35, #384
    s.addi       s37, s35, #448
    v.mov        v53, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s36, #0]
    v.extract    s35, v36, #0
    v.mov        v54, v39                        // hand off through the shared window (sec 7.3)
    v.ld.w       v39, [s37, #0]
    v.mov        v55, v39                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_60
    s.movz       s36, #0
    s.add        s37, s10, s24
    s.addi       s38, s36, #0
    s.addi       s36, s37, #64
    s.addi       s37, s29, #8448
x8dot_row_61:
    s.addi       s39, s11, #-64
    v.movi       v39, #0
    s.sub        s40, s39, s38
    s.add        s39, s36, s38
    v.splat      v41, s40
    s.shli       s40, s38, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s39, v19]            // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.addi       s40, s38, #1
    s.movz       s41, #32
    v.st.b       [s39, #0], v39
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s39, s38, s41
    br.nz        s39, x8dot_row_61
x8dot_done_60:
    v.splat      v39, s35
    v.movi       v41, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s35
    v.movi       v41, #0
    s.movz       s35, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s36            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s35, #64
    v.extract    s37, v37, #0
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v36, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_62
    s.movz       s38, #0
    s.add        s39, s10, s24
    s.addi       s40, s38, #0
    s.addi       s38, s39, #64
    s.addi       s39, s29, #8448
x8dot_row_63:
    s.addi       s41, s11, #-64
    v.movi       v39, #0
    s.sub        s42, s41, s40
    s.add        s41, s38, s40
    v.splat      v41, s42
    s.shli       s42, s40, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s41, v21]            // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.addi       s42, s40, #1
    s.movz       s43, #32
    v.st.b       [s41, #0], v39
    fence.acq_rel.device
    s.mov        s40, s42
    s.cmp.lt     s41, s40, s43
    br.nz        s41, x8dot_row_63
x8dot_done_62:
    v.splat      v39, s37
    v.movi       v41, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s37
    v.movi       v41, #0
    s.movz       s37, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s40, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s38            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s37, #64
    v.extract    s39, v37, #1
    s.mov        s40, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s40, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v36, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s39, x8dot_done_64
    s.movz       s40, #0
    s.add        s41, s10, s24
    s.addi       s42, s40, #0
    s.addi       s40, s41, #64
    s.addi       s41, s29, #8448
x8dot_row_65:
    s.addi       s43, s11, #-64
    v.movi       v39, #0
    s.sub        s44, s43, s42
    s.add        s43, s40, s42
    v.splat      v41, s44
    s.shli       s44, s42, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s43, v22]            // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.addi       s44, s42, #1
    s.movz       s45, #32
    v.st.b       [s43, #0], v39
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s43, s42, s45
    br.nz        s43, x8dot_row_65
x8dot_done_64:
    v.splat      v39, s39
    v.movi       v41, #0
    mb.arm       s40, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s41, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s39
    v.movi       v41, #0
    s.movz       s39, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s40            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s39, #64
    v.extract    s41, v37, #2
    s.mov        s42, s41                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s42, s40          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s40
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s41, v36, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s39
    mb.wait      s39
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s41, x8dot_done_66
    s.movz       s42, #0
    s.add        s43, s10, s24
    s.addi       s44, s42, #0
    s.addi       s42, s43, #64
    s.addi       s43, s29, #8448
x8dot_row_67:
    s.addi       s45, s11, #-64
    v.movi       v39, #0
    s.sub        s46, s45, s44
    s.add        s45, s42, s44
    v.splat      v41, s46
    s.shli       s46, s44, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s45, v23]            // index is in elements (ISA sec 9.1)
    s.add        s45, s43, s46
    s.addi       s46, s44, #1
    s.movz       s47, #32
    v.st.b       [s45, #0], v39
    fence.acq_rel.device
    s.mov        s44, s46
    s.cmp.lt     s45, s44, s47
    br.nz        s45, x8dot_row_67
x8dot_done_66:
    v.splat      v39, s41
    v.movi       v41, #0
    mb.arm       s42, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s43, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s41
    v.movi       v41, #0
    s.movz       s41, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s44, s42            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s41, #64
    v.extract    s43, v37, #3
    s.mov        s44, s43                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s45, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s44, s42          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s42
    mb.arm       s41, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s43, v36, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s41
    mb.wait      s41
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s43, x8dot_done_68
    s.movz       s44, #0
    s.add        s45, s10, s24
    s.addi       s46, s44, #0
    s.addi       s44, s45, #64
    s.addi       s45, s29, #8448
x8dot_row_69:
    s.addi       s47, s11, #-64
    v.movi       v39, #0
    s.sub        s48, s47, s46
    s.add        s47, s44, s46
    v.splat      v41, s48
    s.shli       s48, s46, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s47, v24]            // index is in elements (ISA sec 9.1)
    s.add        s47, s45, s48
    s.addi       s48, s46, #1
    s.movz       s49, #32
    v.st.b       [s47, #0], v39
    fence.acq_rel.device
    s.mov        s46, s48
    s.cmp.lt     s47, s46, s49
    br.nz        s47, x8dot_row_69
x8dot_done_68:
    v.splat      v39, s43
    v.movi       v41, #0
    mb.arm       s44, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s45, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s43
    v.movi       v41, #0
    s.movz       s43, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s46, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s46, s44            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s43, #64
    v.extract    s45, v37, #4
    s.mov        s46, s45                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s47, s43                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s46, s44          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s44
    mb.arm       s43, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s45, v36, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s43
    mb.wait      s43
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s45, x8dot_done_70
    s.movz       s46, #0
    s.add        s47, s10, s24
    s.addi       s48, s46, #0
    s.addi       s46, s47, #64
    s.addi       s47, s29, #8448
x8dot_row_71:
    s.addi       s49, s11, #-64
    v.movi       v39, #0
    s.sub        s50, s49, s48
    s.add        s49, s46, s48
    v.splat      v41, s50
    s.shli       s50, s48, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s49, v26]            // index is in elements (ISA sec 9.1)
    s.add        s49, s47, s50
    s.addi       s50, s48, #1
    s.movz       s51, #32
    v.st.b       [s49, #0], v39
    fence.acq_rel.device
    s.mov        s48, s50
    s.cmp.lt     s49, s48, s51
    br.nz        s49, x8dot_row_71
x8dot_done_70:
    v.splat      v39, s45
    v.movi       v41, #0
    mb.arm       s46, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s47, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s45
    v.movi       v41, #0
    s.movz       s45, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s48, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s48, s46            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s45, #64
    v.extract    s47, v37, #5
    s.mov        s48, s47                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s49, s45                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s48, s46          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s46
    mb.arm       s45, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s47, v36, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s45
    mb.wait      s45
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s47, x8dot_done_72
    s.movz       s48, #0
    s.add        s49, s10, s24
    s.addi       s50, s48, #0
    s.addi       s48, s49, #64
    s.addi       s49, s29, #8448
x8dot_row_73:
    s.addi       s51, s11, #-64
    v.movi       v39, #0
    s.sub        s52, s51, s50
    s.add        s51, s48, s50
    v.splat      v41, s52
    s.shli       s52, s50, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s51, v27]            // index is in elements (ISA sec 9.1)
    s.add        s51, s49, s52
    s.addi       s52, s50, #1
    s.movz       s53, #32
    v.st.b       [s51, #0], v39
    fence.acq_rel.device
    s.mov        s50, s52
    s.cmp.lt     s51, s50, s53
    br.nz        s51, x8dot_row_73
x8dot_done_72:
    v.splat      v39, s47
    v.movi       v41, #0
    mb.arm       s48, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s49, #0
    v.cmp.ne     p1, v39, v41
    v.splat      v39, s47
    v.movi       v41, #0
    s.movz       s47, #0
    v.cmp.eq     p2, v39, v41
    s.mov        s50, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s50, s48            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s47, #64
    v.extract    s49, v37, #6
    s.mov        s50, s49                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s51, s47                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s50, s48          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s48
    mb.arm       s47, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s49, v36, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s47
    mb.wait      s47
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s49, x8dot_done_74
    s.movz       s50, #0
    s.add        s51, s10, s24
    s.addi       s52, s50, #0
    s.addi       s50, s51, #64
    s.addi       s51, s29, #8448
x8dot_row_75:
    s.addi       s53, s11, #-64
    v.movi       v39, #0
    s.sub        s54, s53, s52
    s.add        s53, s50, s52
    v.splat      v41, s54
    s.shli       s54, s52, #4
    v.cmp.gt     p1, v41, v39
    v.movi       v39, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v39, [s53, v28]            // index is in elements (ISA sec 9.1)
    s.add        s53, s51, s54
    s.addi       s54, s52, #1
    s.movz       s55, #32
    v.st.b       [s53, #0], v39
    fence.acq_rel.device
    s.mov        s52, s54
    s.cmp.lt     s53, s52, s55
    br.nz        s53, x8dot_row_75
x8dot_done_74:
    v.splat      v39, s49
    v.movi       v41, #0
    v.splat      v42, s49
    v.movi       v43, #0
    mb.arm       s49, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s50, #0
    s.movz       s51, #0
    v.cmp.ne     p1, v39, v41
    v.cmp.eq     p2, v42, v43
    s.mov        s52, s50                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s52, s49            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s50, v12, #0
    v.splat      v39, s50
    s.movz       s50, #64
    vf.max.ieee  v41, v39, v14
    v.extract    s51, v37, #7
    s.mov        s52, s51                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s53, s50                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s52, s49          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s49
    v.rcp.approx v39, v41                        // ISA 8.8: <= 2**-22 relative
    mb.arm       s50, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.addi       s51, s29, #6144
    m.mma.async.k32.e4m3 a15, v48, v56, s50
    mb.wait      s50
    v.ld.w       v42, [s51, #0]
    s.addi       s51, s29, #10752                // 512 bytes of repack scratch
    s.addi       s52, s51, #0
    vf.fms       v43, v41, v39, v18
    vf.fms       v44, v39, v43, v39
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v39
    vf.mul       v39, v42, v44                   // a/y: faithful quotient
    vf.fms       v43, v39, v41, v42
    vf.fms       v41, v43, v44, v39
    vf.neg       v42, v41                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v41, v42, v39
    vf.cvt.f32.e4m3 v39, v41
    v.lshr       v42, v41, v40
    v.and        v41, v42, v38
    v.or         v42, v39, v41                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #1
    v.splat      v39, s52
    s.addi       s52, s29, #6208
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #32
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #2
    v.splat      v39, s52
    s.addi       s52, s29, #6272
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #64
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #3
    v.splat      v39, s52
    s.addi       s52, s29, #6336
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #96
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #4
    v.splat      v39, s52
    s.addi       s52, s29, #6400
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #128
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #5
    v.splat      v39, s52
    s.addi       s52, s29, #6464
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #160
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #6
    v.splat      v39, s52
    s.addi       s52, s29, #6528
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #192
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #7
    v.splat      v39, s52
    s.addi       s52, s29, #6592
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #224
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #8
    v.splat      v39, s52
    s.addi       s52, s29, #6656
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #256
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #9
    v.splat      v39, s52
    s.addi       s52, s29, #6720
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #288
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #10
    v.splat      v39, s52
    s.addi       s52, s29, #6784
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #320
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #11
    v.splat      v39, s52
    s.addi       s52, s29, #6848
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #352
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #12
    v.splat      v39, s52
    s.addi       s52, s29, #6912
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #384
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #13
    v.splat      v39, s52
    s.addi       s52, s29, #6976
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #416
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #14
    v.splat      v39, s52
    s.addi       s52, s29, #7040
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #448
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #15
    v.splat      v39, s52
    s.addi       s52, s29, #7104
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #480
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #0
    v.splat      v39, s52
    s.addi       s52, s29, #7168
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #16
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #1
    v.splat      v39, s52
    s.addi       s52, s29, #7232
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #48
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #2
    v.splat      v39, s52
    s.addi       s52, s29, #7296
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #80
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #3
    v.splat      v39, s52
    s.addi       s52, s29, #7360
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #112
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #4
    v.splat      v39, s52
    s.addi       s52, s29, #7424
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #144
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #5
    v.splat      v39, s52
    s.addi       s52, s29, #7488
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #176
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #6
    v.splat      v39, s52
    s.addi       s52, s29, #7552
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #208
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #7
    v.splat      v39, s52
    s.addi       s52, s29, #7616
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #240
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #8
    v.splat      v39, s52
    s.addi       s52, s29, #7680
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #272
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #9
    v.splat      v39, s52
    s.addi       s52, s29, #7744
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #304
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #10
    v.splat      v39, s52
    s.addi       s52, s29, #7808
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #336
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #11
    v.splat      v39, s52
    s.addi       s52, s29, #7872
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #368
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #12
    v.splat      v39, s52
    s.addi       s52, s29, #7936
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #400
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #13
    v.splat      v39, s52
    s.addi       s52, s29, #8000
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #432
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #14
    v.splat      v39, s52
    s.addi       s52, s29, #8064
    vf.max.ieee  v41, v39, v14
    v.ld.w       v39, [s52, #0]
    v.rcp.approx v42, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #464
    vf.fms       v43, v41, v42, v18
    vf.fms       v44, v42, v43, v42
    vf.neg       v43, v44                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v43, v43
    @p1 v.sel        v44, v43, v42
    vf.mul       v42, v39, v44                   // a/y: faithful quotient
    vf.fms       v43, v42, v41, v39
    vf.fms       v39, v43, v44, v42
    vf.neg       v41, v39                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v41, v41
    @p1 v.sel        v39, v41, v42
    vf.cvt.f32.e4m3 v41, v39
    v.lshr       v42, v39, v40
    v.and        v39, v42, v38
    v.or         v42, v41, v39                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v42
    v.extract    s52, v12, #15
    v.splat      v39, s52
    s.addi       s52, s29, #8128
    vf.max.ieee  v41, v39, v14
    v.ld.w       v14, [s52, #0]
    v.rcp.approx v39, v41                        // ISA 8.8: <= 2**-22 relative
    s.addi       s52, s51, #496
    vf.fms       v42, v41, v39, v18
    vf.fms       v18, v39, v42, v39
    vf.neg       v42, v18                        // Newton step: r0*(2 - x*r0)
    vf.cmp.o     p1, v42, v42
    @p1 v.sel        v18, v42, v39
    vf.mul       v39, v14, v18                   // a/y: faithful quotient
    vf.fms       v42, v39, v41, v14
    vf.fms       v14, v42, v18, v39
    vf.neg       v18, v14                        // a/y: one correction to the IEEE quotient
    vf.cmp.o     p1, v18, v18
    @p1 v.sel        v14, v18, v39
    vf.cvt.f32.e4m3 v18, v14
    v.lshr       v39, v14, v40
    v.and        v14, v39, v38
    v.or         v38, v18, v14                   // f32 -> f8E4M3FN: a NaN keeps its sign
    v.st.b       [s52, #0], v38
    fence.acq_rel.device
    w.def        w0, #48, #8                     // v48..v55
    s.addi       s52, s51, #64
    v.ld.w       v14, [s51, #0]
    v.mov        v48, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s52, #0]
    s.addi       s52, s51, #128
    v.mov        v49, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s52, #0]
    s.addi       s52, s51, #192
    v.mov        v50, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s52, #0]
    s.addi       s52, s51, #256
    v.mov        v51, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s52, #0]
    s.addi       s52, s51, #320
    v.mov        v52, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s52, #0]
    s.addi       s52, s51, #384
    s.addi       s53, s51, #448
    v.mov        v53, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s52, #0]
    v.extract    s51, v36, #0
    v.mov        v54, v14                        // hand off through the shared window (sec 7.3)
    v.ld.w       v14, [s53, #0]
    v.mov        v55, v14                        // hand off through the shared window (sec 7.3)
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s51, x8dot_done_76
    s.movz       s52, #0
    s.add        s53, s10, s24
    s.addi       s54, s52, #0
    s.addi       s52, s53, #96
    s.addi       s53, s29, #8448
x8dot_row_77:
    s.addi       s55, s11, #-96
    v.movi       v14, #0
    s.sub        s56, s55, s54
    s.add        s55, s52, s54
    v.splat      v18, s56
    s.shli       s56, s54, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s55, v19]            // index is in elements (ISA sec 9.1)
    s.add        s55, s53, s56
    s.addi       s56, s54, #1
    s.movz       s57, #32
    v.st.b       [s55, #0], v14
    fence.acq_rel.device
    s.mov        s54, s56
    s.cmp.lt     s55, s54, s57
    br.nz        s55, x8dot_row_77
x8dot_done_76:
    v.splat      v14, s51
    v.movi       v18, #0
    mb.arm       s52, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s53, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s51
    v.movi       v18, #0
    s.movz       s51, #0
    v.cmp.eq     p2, v14, v18
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s54, s52            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s51, #96
    v.extract    s53, v37, #0
    s.mov        s54, s53                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s55, s51                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s54, s52          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s52
    mb.arm       s51, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s53, v36, #1
    m.mma.async.k32.e4m3 a8, v48, v56, s51
    mb.wait      s51
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s53, x8dot_done_78
    s.movz       s54, #0
    s.add        s55, s10, s24
    s.addi       s56, s54, #0
    s.addi       s54, s55, #96
    s.addi       s55, s29, #8448
x8dot_row_79:
    s.addi       s57, s11, #-96
    v.movi       v14, #0
    s.sub        s58, s57, s56
    s.add        s57, s54, s56
    v.splat      v18, s58
    s.shli       s58, s56, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s57, v21]            // index is in elements (ISA sec 9.1)
    s.add        s57, s55, s58
    s.addi       s58, s56, #1
    s.movz       s59, #32
    v.st.b       [s57, #0], v14
    fence.acq_rel.device
    s.mov        s56, s58
    s.cmp.lt     s57, s56, s59
    br.nz        s57, x8dot_row_79
x8dot_done_78:
    v.splat      v14, s53
    v.movi       v18, #0
    mb.arm       s54, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s55, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s53
    v.movi       v18, #0
    s.movz       s53, #0
    v.cmp.eq     p2, v14, v18
    s.mov        s56, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s56, s54            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s53, #96
    v.extract    s55, v37, #1
    s.mov        s56, s55                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s57, s53                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s56, s54          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s54
    mb.arm       s53, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s55, v36, #2
    m.mma.async.k32.e4m3 a9, v48, v56, s53
    mb.wait      s53
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s55, x8dot_done_80
    s.movz       s56, #0
    s.add        s57, s10, s24
    s.addi       s58, s56, #0
    s.addi       s56, s57, #96
    s.addi       s57, s29, #8448
x8dot_row_81:
    s.addi       s59, s11, #-96
    v.movi       v14, #0
    s.sub        s60, s59, s58
    s.add        s59, s56, s58
    v.splat      v18, s60
    s.shli       s60, s58, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s59, v22]            // index is in elements (ISA sec 9.1)
    s.add        s59, s57, s60
    s.addi       s60, s58, #1
    s.movz       s28, #32
    v.st.b       [s59, #0], v14
    fence.acq_rel.device
    s.mov        s58, s60
    s.cmp.lt     s30, s58, s28
    br.nz        s30, x8dot_row_81
x8dot_done_80:
    v.splat      v14, s55
    v.movi       v18, #0
    mb.arm       s28, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s30, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s55
    v.movi       v18, #0
    s.movz       s31, #0
    v.cmp.eq     p2, v14, v18
    s.mov        s32, s30                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s32, s28            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s30, #96
    v.extract    s31, v37, #2
    s.mov        s32, s31                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s33, s30                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s32, s28          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s28
    mb.arm       s30, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s31, v36, #3
    m.mma.async.k32.e4m3 a10, v48, v56, s30
    mb.wait      s30
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s31, x8dot_done_82
    s.movz       s32, #0
    s.add        s33, s10, s24
    s.addi       s34, s32, #0
    s.addi       s32, s33, #96
    s.addi       s33, s29, #8448
x8dot_row_83:
    s.addi       s35, s11, #-96
    v.movi       v14, #0
    s.sub        s36, s35, s34
    s.add        s35, s32, s34
    v.splat      v18, s36
    s.shli       s36, s34, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s35, v23]            // index is in elements (ISA sec 9.1)
    s.add        s35, s33, s36
    s.addi       s36, s34, #1
    s.movz       s37, #32
    v.st.b       [s35, #0], v14
    fence.acq_rel.device
    s.mov        s34, s36
    s.cmp.lt     s35, s34, s37
    br.nz        s35, x8dot_row_83
x8dot_done_82:
    v.splat      v14, s31
    v.movi       v18, #0
    mb.arm       s32, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s33, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s31
    v.movi       v18, #0
    s.movz       s31, #0
    v.cmp.eq     p2, v14, v18
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s34, s32            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s31, #96
    v.extract    s33, v37, #3
    s.mov        s34, s33                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s35, s31                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s34, s32          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s32
    mb.arm       s31, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s33, v36, #4
    m.mma.async.k32.e4m3 a11, v48, v56, s31
    mb.wait      s31
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s33, x8dot_done_84
    s.movz       s34, #0
    s.add        s35, s10, s24
    s.addi       s36, s34, #0
    s.addi       s34, s35, #96
    s.addi       s35, s29, #8448
x8dot_row_85:
    s.addi       s37, s11, #-96
    v.movi       v14, #0
    s.sub        s38, s37, s36
    s.add        s37, s34, s36
    v.splat      v18, s38
    s.shli       s38, s36, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s37, v24]            // index is in elements (ISA sec 9.1)
    s.add        s37, s35, s38
    s.addi       s38, s36, #1
    s.movz       s39, #32
    v.st.b       [s37, #0], v14
    fence.acq_rel.device
    s.mov        s36, s38
    s.cmp.lt     s37, s36, s39
    br.nz        s37, x8dot_row_85
x8dot_done_84:
    v.splat      v14, s33
    v.movi       v18, #0
    mb.arm       s34, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s35, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s33
    v.movi       v18, #0
    s.movz       s33, #0
    v.cmp.eq     p2, v14, v18
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s36, s34            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s33, #96
    v.extract    s35, v37, #4
    s.mov        s36, s35                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s37, s33                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s36, s34          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s34
    mb.arm       s33, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s35, v36, #5
    m.mma.async.k32.e4m3 a12, v48, v56, s33
    mb.wait      s33
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s35, x8dot_done_86
    s.movz       s36, #0
    s.add        s37, s10, s24
    s.addi       s38, s36, #0
    s.addi       s36, s37, #96
    s.addi       s37, s29, #8448
x8dot_row_87:
    s.addi       s39, s11, #-96
    v.movi       v14, #0
    s.sub        s40, s39, s38
    s.add        s39, s36, s38
    v.splat      v18, s40
    s.shli       s40, s38, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s39, v26]            // index is in elements (ISA sec 9.1)
    s.add        s39, s37, s40
    s.addi       s40, s38, #1
    s.movz       s41, #32
    v.st.b       [s39, #0], v14
    fence.acq_rel.device
    s.mov        s38, s40
    s.cmp.lt     s39, s38, s41
    br.nz        s39, x8dot_row_87
x8dot_done_86:
    v.splat      v14, s35
    v.movi       v18, #0
    mb.arm       s36, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s37, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s35
    v.movi       v18, #0
    s.movz       s35, #0
    v.cmp.eq     p2, v14, v18
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s38, s36            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s35, #96
    v.extract    s37, v37, #5
    s.mov        s38, s37                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s39, s35                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s38, s36          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s36
    mb.arm       s35, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s37, v36, #6
    m.mma.async.k32.e4m3 a13, v48, v56, s35
    mb.wait      s35
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s37, x8dot_done_88
    s.movz       s38, #0
    s.add        s39, s10, s24
    s.addi       s40, s38, #0
    s.addi       s38, s39, #96
    s.addi       s39, s29, #8448
x8dot_row_89:
    s.addi       s41, s11, #-96
    v.movi       v14, #0
    s.sub        s42, s41, s40
    s.add        s41, s38, s40
    v.splat      v18, s42
    s.shli       s42, s40, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s41, v27]            // index is in elements (ISA sec 9.1)
    s.add        s41, s39, s42
    s.addi       s42, s40, #1
    s.movz       s43, #32
    v.st.b       [s41, #0], v14
    fence.acq_rel.device
    s.mov        s40, s42
    s.cmp.lt     s41, s40, s43
    br.nz        s41, x8dot_row_89
x8dot_done_88:
    v.splat      v14, s37
    v.movi       v18, #0
    mb.arm       s38, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s39, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s37
    v.movi       v18, #0
    s.movz       s37, #0
    v.cmp.eq     p2, v14, v18
    s.mov        s40, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s40, s38            // predicated off still completes once (ISA sec 9A.3)
    s.movz       s37, #96
    v.extract    s39, v37, #6
    s.mov        s40, s39                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s41, s37                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s40, s38          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s38
    mb.arm       s37, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    v.extract    s39, v36, #7
    m.mma.async.k32.e4m3 a14, v48, v56, s37
    mb.wait      s37
    w.def        w1, #56, #8                     // v56..v63
    br.nz        s39, x8dot_done_90
    s.movz       s40, #0
    s.add        s41, s10, s24
    s.addi       s42, s40, #0
    s.addi       s40, s41, #96
    s.addi       s41, s29, #8448
x8dot_row_91:
    s.addi       s43, s11, #-96
    v.movi       v14, #0
    s.sub        s44, s43, s42
    s.add        s43, s40, s42
    v.splat      v18, s44
    s.shli       s44, s42, #4
    v.cmp.gt     p1, v18, v14
    v.movi       v14, #0                         // other=, materialised (sec 12)
    @p1 v.ld.gather.b v14, [s43, v28]            // index is in elements (ISA sec 9.1)
    s.add        s43, s41, s44
    s.addi       s44, s42, #1
    s.movz       s45, #32
    v.st.b       [s43, #0], v14
    fence.acq_rel.device
    s.mov        s42, s44
    s.cmp.lt     s43, s42, s45
    br.nz        s43, x8dot_row_91
x8dot_done_90:
    v.splat      v14, s39
    v.movi       v18, #0
    mb.arm       s11, b0, #0, #2                 // 0 arrival(s), 2 operation(s)
    s.movz       s40, #0
    s.movz       s41, #0
    v.cmp.ne     p1, v14, v18
    v.splat      v14, s39
    v.movi       v18, #0
    s.movz       s39, #96
    v.cmp.eq     p2, v14, v18
    s.mov        s42, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s43, s41                        // coordinates must be consecutive (ISA sec 9E)
    @p2 t.ld.async.b w1, d1, s42, s11            // predicated off still completes once (ISA sec 9A.3)
    v.extract    s40, v37, #7
    s.mov        s41, s40                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s42, s39                        // coordinates must be consecutive (ISA sec 9E)
    @p1 t.ld.async.b.t w1, d0, s41, s11          // predicated off still completes once (ISA sec 9A.3)
    mb.wait      s11
    mb.arm       s39, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s40, #0
    m.mma.async.k32.e4m3 a15, v48, v56, s39
    mb.wait      s39
    s.addi       s41, s29, #11264
    a.vread      v14, a8, s40
    s.movz       s40, #1
    v.st.w       [s41, #0], v14
    s.addi       s42, s41, #64
    a.vread      v14, a8, s40
    s.movz       s40, #2
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #128
    a.vread      v14, a8, s40
    s.movz       s40, #3
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #192
    a.vread      v14, a8, s40
    s.movz       s40, #4
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #256
    a.vread      v14, a8, s40
    s.movz       s40, #5
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #320
    a.vread      v14, a8, s40
    s.movz       s40, #6
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #384
    a.vread      v14, a8, s40
    s.movz       s40, #7
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #448
    a.vread      v14, a8, s40
    s.movz       s40, #8
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #512
    a.vread      v14, a8, s40
    s.movz       s40, #9
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #576
    a.vread      v14, a8, s40
    s.movz       s40, #10
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #640
    a.vread      v14, a8, s40
    s.movz       s40, #11
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #704
    a.vread      v14, a8, s40
    s.movz       s40, #12
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #768
    a.vread      v14, a8, s40
    s.movz       s40, #13
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #832
    a.vread      v14, a8, s40
    s.movz       s40, #14
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #896
    a.vread      v14, a8, s40
    s.movz       s40, #15
    s.addi       s43, s41, #960
    v.st.w       [s42, #0], v14
    a.vread      v14, a8, s40
    s.movz       s40, #0
    s.addi       s41, s29, #12288
    v.st.w       [s43, #0], v14
    fence.acq_rel.device
    a.vread      v14, a9, s40
    s.movz       s40, #1
    s.addi       s42, s41, #64
    v.st.w       [s41, #0], v14
    a.vread      v14, a9, s40
    s.movz       s40, #2
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #128
    a.vread      v14, a9, s40
    s.movz       s40, #3
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #192
    a.vread      v14, a9, s40
    s.movz       s40, #4
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #256
    a.vread      v14, a9, s40
    s.movz       s40, #5
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #320
    a.vread      v14, a9, s40
    s.movz       s40, #6
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #384
    a.vread      v14, a9, s40
    s.movz       s40, #7
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #448
    a.vread      v14, a9, s40
    s.movz       s40, #8
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #512
    a.vread      v14, a9, s40
    s.movz       s40, #9
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #576
    a.vread      v14, a9, s40
    s.movz       s40, #10
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #640
    a.vread      v14, a9, s40
    s.movz       s40, #11
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #704
    a.vread      v14, a9, s40
    s.movz       s40, #12
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #768
    a.vread      v14, a9, s40
    s.movz       s40, #13
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #832
    a.vread      v14, a9, s40
    s.movz       s40, #14
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #896
    a.vread      v14, a9, s40
    s.movz       s40, #15
    s.addi       s43, s41, #960
    v.st.w       [s42, #0], v14
    a.vread      v14, a9, s40
    s.movz       s40, #0
    s.addi       s41, s29, #13312
    v.st.w       [s43, #0], v14
    fence.acq_rel.device
    a.vread      v14, a10, s40
    s.movz       s40, #1
    s.addi       s42, s41, #64
    v.st.w       [s41, #0], v14
    a.vread      v14, a10, s40
    s.movz       s40, #2
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #128
    a.vread      v14, a10, s40
    s.movz       s40, #3
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #192
    a.vread      v14, a10, s40
    s.movz       s40, #4
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #256
    a.vread      v14, a10, s40
    s.movz       s40, #5
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #320
    a.vread      v14, a10, s40
    s.movz       s40, #6
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #384
    a.vread      v14, a10, s40
    s.movz       s40, #7
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #448
    a.vread      v14, a10, s40
    s.movz       s40, #8
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #512
    a.vread      v14, a10, s40
    s.movz       s40, #9
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #576
    a.vread      v14, a10, s40
    s.movz       s40, #10
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #640
    a.vread      v14, a10, s40
    s.movz       s40, #11
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #704
    a.vread      v14, a10, s40
    s.movz       s40, #12
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #768
    a.vread      v14, a10, s40
    s.movz       s40, #13
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #832
    a.vread      v14, a10, s40
    s.movz       s40, #14
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #896
    a.vread      v14, a10, s40
    s.movz       s40, #15
    s.addi       s43, s41, #960
    v.st.w       [s42, #0], v14
    a.vread      v14, a10, s40
    s.movz       s40, #0
    s.addi       s41, s29, #14336
    v.st.w       [s43, #0], v14
    fence.acq_rel.device
    a.vread      v14, a11, s40
    s.movz       s40, #1
    s.addi       s42, s41, #64
    v.st.w       [s41, #0], v14
    a.vread      v14, a11, s40
    s.movz       s40, #2
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #128
    a.vread      v14, a11, s40
    s.movz       s40, #3
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #192
    a.vread      v14, a11, s40
    s.movz       s40, #4
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #256
    a.vread      v14, a11, s40
    s.movz       s40, #5
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #320
    a.vread      v14, a11, s40
    s.movz       s40, #6
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #384
    a.vread      v14, a11, s40
    s.movz       s40, #7
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #448
    a.vread      v14, a11, s40
    s.movz       s40, #8
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #512
    a.vread      v14, a11, s40
    s.movz       s40, #9
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #576
    a.vread      v14, a11, s40
    s.movz       s40, #10
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #640
    a.vread      v14, a11, s40
    s.movz       s40, #11
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #704
    a.vread      v14, a11, s40
    s.movz       s40, #12
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #768
    a.vread      v14, a11, s40
    s.movz       s40, #13
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #832
    a.vread      v14, a11, s40
    s.movz       s40, #14
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #896
    a.vread      v14, a11, s40
    s.movz       s40, #15
    s.addi       s43, s41, #960
    v.st.w       [s42, #0], v14
    a.vread      v14, a11, s40
    s.movz       s40, #0
    s.addi       s41, s29, #15360
    v.st.w       [s43, #0], v14
    fence.acq_rel.device
    a.vread      v14, a12, s40
    s.movz       s40, #1
    s.addi       s42, s41, #64
    v.st.w       [s41, #0], v14
    a.vread      v14, a12, s40
    s.movz       s40, #2
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #128
    a.vread      v14, a12, s40
    s.movz       s40, #3
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #192
    a.vread      v14, a12, s40
    s.movz       s40, #4
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #256
    a.vread      v14, a12, s40
    s.movz       s40, #5
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #320
    a.vread      v14, a12, s40
    s.movz       s40, #6
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #384
    a.vread      v14, a12, s40
    s.movz       s40, #7
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #448
    a.vread      v14, a12, s40
    s.movz       s40, #8
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #512
    a.vread      v14, a12, s40
    s.movz       s40, #9
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #576
    a.vread      v14, a12, s40
    s.movz       s40, #10
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #640
    a.vread      v14, a12, s40
    s.movz       s40, #11
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #704
    a.vread      v14, a12, s40
    s.movz       s40, #12
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #768
    a.vread      v14, a12, s40
    s.movz       s40, #13
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #832
    a.vread      v14, a12, s40
    s.movz       s40, #14
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #896
    a.vread      v14, a12, s40
    s.movz       s40, #15
    s.addi       s43, s41, #960
    v.st.w       [s42, #0], v14
    a.vread      v14, a12, s40
    s.movz       s40, #0
    s.addi       s41, s29, #16384
    v.st.w       [s43, #0], v14
    fence.acq_rel.device
    a.vread      v14, a13, s40
    s.movz       s40, #1
    s.addi       s42, s41, #64
    v.st.w       [s41, #0], v14
    a.vread      v14, a13, s40
    s.movz       s40, #2
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #128
    a.vread      v14, a13, s40
    s.movz       s40, #3
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #192
    a.vread      v14, a13, s40
    s.movz       s40, #4
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #256
    a.vread      v14, a13, s40
    s.movz       s40, #5
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #320
    a.vread      v14, a13, s40
    s.movz       s40, #6
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #384
    a.vread      v14, a13, s40
    s.movz       s40, #7
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #448
    a.vread      v14, a13, s40
    s.movz       s40, #8
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #512
    a.vread      v14, a13, s40
    s.movz       s40, #9
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #576
    a.vread      v14, a13, s40
    s.movz       s40, #10
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #640
    a.vread      v14, a13, s40
    s.movz       s40, #11
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #704
    a.vread      v14, a13, s40
    s.movz       s40, #12
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #768
    a.vread      v14, a13, s40
    s.movz       s40, #13
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #832
    a.vread      v14, a13, s40
    s.movz       s40, #14
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #896
    a.vread      v14, a13, s40
    s.movz       s40, #15
    s.addi       s43, s41, #960
    v.st.w       [s42, #0], v14
    a.vread      v14, a13, s40
    s.movz       s40, #0
    s.addi       s41, s29, #17408
    v.st.w       [s43, #0], v14
    fence.acq_rel.device
    a.vread      v14, a14, s40
    s.movz       s40, #1
    s.addi       s42, s41, #64
    v.st.w       [s41, #0], v14
    a.vread      v14, a14, s40
    s.movz       s40, #2
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #128
    a.vread      v14, a14, s40
    s.movz       s40, #3
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #192
    a.vread      v14, a14, s40
    s.movz       s40, #4
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #256
    a.vread      v14, a14, s40
    s.movz       s40, #5
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #320
    a.vread      v14, a14, s40
    s.movz       s40, #6
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #384
    a.vread      v14, a14, s40
    s.movz       s40, #7
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #448
    a.vread      v14, a14, s40
    s.movz       s40, #8
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #512
    a.vread      v14, a14, s40
    s.movz       s40, #9
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #576
    a.vread      v14, a14, s40
    s.movz       s40, #10
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #640
    a.vread      v14, a14, s40
    s.movz       s40, #11
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #704
    a.vread      v14, a14, s40
    s.movz       s40, #12
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #768
    a.vread      v14, a14, s40
    s.movz       s40, #13
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #832
    a.vread      v14, a14, s40
    s.movz       s40, #14
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #896
    a.vread      v14, a14, s40
    s.movz       s40, #15
    s.addi       s43, s41, #960
    v.st.w       [s42, #0], v14
    a.vread      v14, a14, s40
    s.movz       s40, #0
    s.addi       s41, s29, #18432
    v.st.w       [s43, #0], v14
    fence.acq_rel.device
    a.vread      v14, a15, s40
    s.movz       s40, #1
    s.addi       s42, s41, #64
    v.st.w       [s41, #0], v14
    a.vread      v14, a15, s40
    s.movz       s40, #2
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #128
    a.vread      v14, a15, s40
    s.movz       s40, #3
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #192
    a.vread      v14, a15, s40
    s.movz       s40, #4
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #256
    a.vread      v14, a15, s40
    s.movz       s40, #5
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #320
    a.vread      v14, a15, s40
    s.movz       s40, #6
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #384
    a.vread      v14, a15, s40
    s.movz       s40, #7
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #448
    a.vread      v14, a15, s40
    s.movz       s40, #8
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #512
    a.vread      v14, a15, s40
    s.movz       s40, #9
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #576
    a.vread      v14, a15, s40
    s.movz       s40, #10
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #640
    a.vread      v14, a15, s40
    s.movz       s40, #11
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #704
    a.vread      v14, a15, s40
    s.movz       s40, #12
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #768
    a.vread      v14, a15, s40
    s.movz       s40, #13
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #832
    a.vread      v14, a15, s40
    s.movz       s40, #14
    v.st.w       [s42, #0], v14
    s.addi       s42, s41, #896
    a.vread      v14, a15, s40
    s.movz       s40, #15
    s.addi       s43, s41, #960
    v.st.w       [s42, #0], v14
    a.vread      v14, a15, s40
    s.movz       s40, #0
    s.addi       s41, s29, #11264
    v.st.w       [s43, #0], v14
    fence.acq_rel.device
    a.vread      v14, a0, s40
    v.extract    s40, v12, #0
    v.splat      v18, s40
    s.addi       s40, s29, #19456
    s.movz       s42, #1
    v.ld.w       v19, [s41, #0]
    s.addi       s41, s29, #11328
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s40, #0], v19
    a.vread      v14, a0, s42
    v.extract    s42, v12, #1
    v.splat      v18, s42
    s.addi       s42, s40, #64
    v.ld.w       v19, [s41, #0]
    s.movz       s41, #2
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s42, #0], v19
    s.addi       s42, s29, #11392
    a.vread      v14, a0, s41
    v.extract    s41, v12, #2
    v.splat      v18, s41
    s.addi       s41, s40, #128
    v.ld.w       v19, [s42, #0]
    s.movz       s42, #3
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s41, #0], v19
    s.addi       s41, s29, #11456
    a.vread      v14, a0, s42
    v.extract    s42, v12, #3
    v.splat      v18, s42
    s.addi       s42, s40, #192
    v.ld.w       v19, [s41, #0]
    s.movz       s41, #4
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s42, #0], v19
    s.addi       s42, s29, #11520
    a.vread      v14, a0, s41
    v.extract    s41, v12, #4
    v.splat      v18, s41
    s.addi       s41, s40, #256
    v.ld.w       v19, [s42, #0]
    s.movz       s42, #5
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s41, #0], v19
    s.addi       s41, s29, #11584
    a.vread      v14, a0, s42
    v.extract    s42, v12, #5
    v.splat      v18, s42
    s.addi       s42, s40, #320
    v.ld.w       v19, [s41, #0]
    s.movz       s41, #6
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s42, #0], v19
    s.addi       s42, s29, #11648
    a.vread      v14, a0, s41
    v.extract    s41, v12, #6
    v.splat      v18, s41
    s.addi       s41, s40, #384
    v.ld.w       v19, [s42, #0]
    s.movz       s42, #7
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s41, #0], v19
    s.addi       s41, s29, #11712
    a.vread      v14, a0, s42
    v.extract    s42, v12, #7
    v.splat      v18, s42
    s.addi       s42, s40, #448
    v.ld.w       v19, [s41, #0]
    s.movz       s41, #8
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s42, #0], v19
    s.addi       s42, s29, #11776
    a.vread      v14, a0, s41
    v.extract    s41, v12, #8
    v.splat      v18, s41
    s.addi       s41, s40, #512
    v.ld.w       v19, [s42, #0]
    s.movz       s42, #9
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s41, #0], v19
    s.addi       s41, s29, #11840
    a.vread      v14, a0, s42
    v.extract    s42, v12, #9
    v.splat      v18, s42
    s.addi       s42, s40, #576
    v.ld.w       v19, [s41, #0]
    s.movz       s41, #10
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s42, #0], v19
    s.addi       s42, s29, #11904
    a.vread      v14, a0, s41
    v.extract    s41, v12, #10
    v.splat      v18, s41
    s.addi       s41, s40, #640
    v.ld.w       v19, [s42, #0]
    s.movz       s42, #11
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s41, #0], v19
    s.addi       s41, s29, #11968
    a.vread      v14, a0, s42
    v.extract    s42, v12, #11
    v.splat      v18, s42
    s.addi       s42, s40, #704
    v.ld.w       v19, [s41, #0]
    s.movz       s41, #12
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s42, #0], v19
    s.addi       s42, s29, #12032
    a.vread      v14, a0, s41
    v.extract    s41, v12, #12
    v.splat      v18, s41
    s.addi       s41, s40, #768
    v.ld.w       v19, [s42, #0]
    s.movz       s42, #13
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s41, #0], v19
    s.addi       s41, s29, #12096
    a.vread      v14, a0, s42
    v.extract    s42, v12, #13
    v.splat      v18, s42
    s.addi       s42, s40, #832
    v.ld.w       v19, [s41, #0]
    s.movz       s41, #14
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s42, #0], v19
    s.addi       s42, s29, #12160
    a.vread      v14, a0, s41
    v.extract    s41, v12, #14
    v.splat      v18, s41
    s.addi       s41, s40, #896
    s.addi       s43, s40, #960
    v.ld.w       v19, [s42, #0]
    s.movz       s40, #15
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v19, v14, v18
    v.st.w       [s41, #0], v19
    s.addi       s41, s29, #12224
    a.vread      v14, a0, s40
    v.extract    s40, v12, #15
    v.splat      v18, s40
    s.movz       s40, #0
    v.ld.w       v19, [s41, #0]
    s.addi       s41, s29, #12288
    vf.mul       v21, v19, v18
    vf.mul       v18, v21, v17
    vf.add       v17, v14, v18
    v.st.w       [s43, #0], v17
    fence.acq_rel.device
    a.vread      v14, a1, s40
    v.extract    s40, v12, #0
    v.splat      v17, s40
    s.addi       s40, s29, #20480
    s.movz       s42, #1
    v.ld.w       v18, [s41, #0]
    s.addi       s41, s29, #12352
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s40, #0], v18
    a.vread      v14, a1, s42
    v.extract    s42, v12, #1
    v.splat      v17, s42
    s.addi       s42, s40, #64
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #2
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #12416
    a.vread      v14, a1, s41
    v.extract    s41, v12, #2
    v.splat      v17, s41
    s.addi       s41, s40, #128
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #3
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #12480
    a.vread      v14, a1, s42
    v.extract    s42, v12, #3
    v.splat      v17, s42
    s.addi       s42, s40, #192
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #4
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #12544
    a.vread      v14, a1, s41
    v.extract    s41, v12, #4
    v.splat      v17, s41
    s.addi       s41, s40, #256
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #5
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #12608
    a.vread      v14, a1, s42
    v.extract    s42, v12, #5
    v.splat      v17, s42
    s.addi       s42, s40, #320
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #6
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #12672
    a.vread      v14, a1, s41
    v.extract    s41, v12, #6
    v.splat      v17, s41
    s.addi       s41, s40, #384
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #7
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #12736
    a.vread      v14, a1, s42
    v.extract    s42, v12, #7
    v.splat      v17, s42
    s.addi       s42, s40, #448
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #8
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #12800
    a.vread      v14, a1, s41
    v.extract    s41, v12, #8
    v.splat      v17, s41
    s.addi       s41, s40, #512
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #9
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #12864
    a.vread      v14, a1, s42
    v.extract    s42, v12, #9
    v.splat      v17, s42
    s.addi       s42, s40, #576
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #10
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #12928
    a.vread      v14, a1, s41
    v.extract    s41, v12, #10
    v.splat      v17, s41
    s.addi       s41, s40, #640
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #11
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #12992
    a.vread      v14, a1, s42
    v.extract    s42, v12, #11
    v.splat      v17, s42
    s.addi       s42, s40, #704
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #12
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #13056
    a.vread      v14, a1, s41
    v.extract    s41, v12, #12
    v.splat      v17, s41
    s.addi       s41, s40, #768
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #13
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #13120
    a.vread      v14, a1, s42
    v.extract    s42, v12, #13
    v.splat      v17, s42
    s.addi       s42, s40, #832
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #14
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #13184
    a.vread      v14, a1, s41
    v.extract    s41, v12, #14
    v.splat      v17, s41
    s.addi       s41, s40, #896
    s.addi       s43, s40, #960
    v.ld.w       v18, [s42, #0]
    s.movz       s40, #15
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #13248
    a.vread      v14, a1, s40
    v.extract    s40, v12, #15
    v.splat      v17, s40
    s.movz       s40, #0
    v.ld.w       v18, [s41, #0]
    s.addi       s41, s29, #13312
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v29
    vf.add       v18, v14, v17
    v.st.w       [s43, #0], v18
    fence.acq_rel.device
    a.vread      v14, a2, s40
    v.extract    s40, v12, #0
    v.splat      v17, s40
    s.addi       s40, s29, #21504
    s.movz       s42, #1
    v.ld.w       v18, [s41, #0]
    s.addi       s41, s29, #13376
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s40, #0], v18
    a.vread      v14, a2, s42
    v.extract    s42, v12, #1
    v.splat      v17, s42
    s.addi       s42, s40, #64
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #2
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #13440
    a.vread      v14, a2, s41
    v.extract    s41, v12, #2
    v.splat      v17, s41
    s.addi       s41, s40, #128
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #3
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #13504
    a.vread      v14, a2, s42
    v.extract    s42, v12, #3
    v.splat      v17, s42
    s.addi       s42, s40, #192
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #4
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #13568
    a.vread      v14, a2, s41
    v.extract    s41, v12, #4
    v.splat      v17, s41
    s.addi       s41, s40, #256
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #5
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #13632
    a.vread      v14, a2, s42
    v.extract    s42, v12, #5
    v.splat      v17, s42
    s.addi       s42, s40, #320
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #6
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #13696
    a.vread      v14, a2, s41
    v.extract    s41, v12, #6
    v.splat      v17, s41
    s.addi       s41, s40, #384
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #7
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #13760
    a.vread      v14, a2, s42
    v.extract    s42, v12, #7
    v.splat      v17, s42
    s.addi       s42, s40, #448
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #8
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #13824
    a.vread      v14, a2, s41
    v.extract    s41, v12, #8
    v.splat      v17, s41
    s.addi       s41, s40, #512
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #9
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #13888
    a.vread      v14, a2, s42
    v.extract    s42, v12, #9
    v.splat      v17, s42
    s.addi       s42, s40, #576
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #10
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #13952
    a.vread      v14, a2, s41
    v.extract    s41, v12, #10
    v.splat      v17, s41
    s.addi       s41, s40, #640
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #11
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #14016
    a.vread      v14, a2, s42
    v.extract    s42, v12, #11
    v.splat      v17, s42
    s.addi       s42, s40, #704
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #12
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #14080
    a.vread      v14, a2, s41
    v.extract    s41, v12, #12
    v.splat      v17, s41
    s.addi       s41, s40, #768
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #13
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #14144
    a.vread      v14, a2, s42
    v.extract    s42, v12, #13
    v.splat      v17, s42
    s.addi       s42, s40, #832
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #14
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #14208
    a.vread      v14, a2, s41
    v.extract    s41, v12, #14
    v.splat      v17, s41
    s.addi       s41, s40, #896
    s.addi       s43, s40, #960
    v.ld.w       v18, [s42, #0]
    s.movz       s40, #15
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #14272
    a.vread      v14, a2, s40
    v.extract    s40, v12, #15
    v.splat      v17, s40
    s.movz       s40, #0
    v.ld.w       v18, [s41, #0]
    s.addi       s41, s29, #14336
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v30
    vf.add       v18, v14, v17
    v.st.w       [s43, #0], v18
    fence.acq_rel.device
    a.vread      v14, a3, s40
    v.extract    s40, v12, #0
    v.splat      v17, s40
    s.addi       s40, s29, #22528
    s.movz       s42, #1
    v.ld.w       v18, [s41, #0]
    s.addi       s41, s29, #14400
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s40, #0], v18
    a.vread      v14, a3, s42
    v.extract    s42, v12, #1
    v.splat      v17, s42
    s.addi       s42, s40, #64
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #2
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #14464
    a.vread      v14, a3, s41
    v.extract    s41, v12, #2
    v.splat      v17, s41
    s.addi       s41, s40, #128
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #3
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #14528
    a.vread      v14, a3, s42
    v.extract    s42, v12, #3
    v.splat      v17, s42
    s.addi       s42, s40, #192
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #4
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #14592
    a.vread      v14, a3, s41
    v.extract    s41, v12, #4
    v.splat      v17, s41
    s.addi       s41, s40, #256
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #5
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #14656
    a.vread      v14, a3, s42
    v.extract    s42, v12, #5
    v.splat      v17, s42
    s.addi       s42, s40, #320
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #6
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #14720
    a.vread      v14, a3, s41
    v.extract    s41, v12, #6
    v.splat      v17, s41
    s.addi       s41, s40, #384
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #7
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #14784
    a.vread      v14, a3, s42
    v.extract    s42, v12, #7
    v.splat      v17, s42
    s.addi       s42, s40, #448
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #8
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #14848
    a.vread      v14, a3, s41
    v.extract    s41, v12, #8
    v.splat      v17, s41
    s.addi       s41, s40, #512
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #9
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #14912
    a.vread      v14, a3, s42
    v.extract    s42, v12, #9
    v.splat      v17, s42
    s.addi       s42, s40, #576
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #10
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #14976
    a.vread      v14, a3, s41
    v.extract    s41, v12, #10
    v.splat      v17, s41
    s.addi       s41, s40, #640
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #11
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #15040
    a.vread      v14, a3, s42
    v.extract    s42, v12, #11
    v.splat      v17, s42
    s.addi       s42, s40, #704
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #12
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #15104
    a.vread      v14, a3, s41
    v.extract    s41, v12, #12
    v.splat      v17, s41
    s.addi       s41, s40, #768
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #13
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #15168
    a.vread      v14, a3, s42
    v.extract    s42, v12, #13
    v.splat      v17, s42
    s.addi       s42, s40, #832
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #14
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #15232
    a.vread      v14, a3, s41
    v.extract    s41, v12, #14
    v.splat      v17, s41
    s.addi       s41, s40, #896
    s.addi       s43, s40, #960
    v.ld.w       v18, [s42, #0]
    s.movz       s40, #15
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #15296
    a.vread      v14, a3, s40
    v.extract    s40, v12, #15
    v.splat      v17, s40
    s.movz       s40, #0
    v.ld.w       v18, [s41, #0]
    s.addi       s41, s29, #15360
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v31
    vf.add       v18, v14, v17
    v.st.w       [s43, #0], v18
    fence.acq_rel.device
    a.vread      v14, a4, s40
    v.extract    s40, v12, #0
    v.splat      v17, s40
    s.addi       s40, s29, #23552
    s.movz       s42, #1
    v.ld.w       v18, [s41, #0]
    s.addi       s41, s29, #15424
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s40, #0], v18
    a.vread      v14, a4, s42
    v.extract    s42, v12, #1
    v.splat      v17, s42
    s.addi       s42, s40, #64
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #2
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #15488
    a.vread      v14, a4, s41
    v.extract    s41, v12, #2
    v.splat      v17, s41
    s.addi       s41, s40, #128
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #3
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #15552
    a.vread      v14, a4, s42
    v.extract    s42, v12, #3
    v.splat      v17, s42
    s.addi       s42, s40, #192
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #4
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #15616
    a.vread      v14, a4, s41
    v.extract    s41, v12, #4
    v.splat      v17, s41
    s.addi       s41, s40, #256
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #5
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #15680
    a.vread      v14, a4, s42
    v.extract    s42, v12, #5
    v.splat      v17, s42
    s.addi       s42, s40, #320
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #6
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #15744
    a.vread      v14, a4, s41
    v.extract    s41, v12, #6
    v.splat      v17, s41
    s.addi       s41, s40, #384
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #7
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #15808
    a.vread      v14, a4, s42
    v.extract    s42, v12, #7
    v.splat      v17, s42
    s.addi       s42, s40, #448
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #8
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #15872
    a.vread      v14, a4, s41
    v.extract    s41, v12, #8
    v.splat      v17, s41
    s.addi       s41, s40, #512
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #9
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #15936
    a.vread      v14, a4, s42
    v.extract    s42, v12, #9
    v.splat      v17, s42
    s.addi       s42, s40, #576
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #10
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #16000
    a.vread      v14, a4, s41
    v.extract    s41, v12, #10
    v.splat      v17, s41
    s.addi       s41, s40, #640
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #11
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #16064
    a.vread      v14, a4, s42
    v.extract    s42, v12, #11
    v.splat      v17, s42
    s.addi       s42, s40, #704
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #12
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #16128
    a.vread      v14, a4, s41
    v.extract    s41, v12, #12
    v.splat      v17, s41
    s.addi       s41, s40, #768
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #13
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #16192
    a.vread      v14, a4, s42
    v.extract    s42, v12, #13
    v.splat      v17, s42
    s.addi       s42, s40, #832
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #14
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #16256
    a.vread      v14, a4, s41
    v.extract    s41, v12, #14
    v.splat      v17, s41
    s.addi       s41, s40, #896
    s.addi       s43, s40, #960
    v.ld.w       v18, [s42, #0]
    s.movz       s40, #15
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #16320
    a.vread      v14, a4, s40
    v.extract    s40, v12, #15
    v.splat      v17, s40
    s.movz       s40, #0
    v.ld.w       v18, [s41, #0]
    s.addi       s41, s29, #16384
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v32
    vf.add       v18, v14, v17
    v.st.w       [s43, #0], v18
    fence.acq_rel.device
    a.vread      v14, a5, s40
    v.extract    s40, v12, #0
    v.splat      v17, s40
    s.addi       s40, s29, #24576
    s.movz       s42, #1
    v.ld.w       v18, [s41, #0]
    s.addi       s41, s29, #16448
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s40, #0], v18
    a.vread      v14, a5, s42
    v.extract    s42, v12, #1
    v.splat      v17, s42
    s.addi       s42, s40, #64
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #2
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #16512
    a.vread      v14, a5, s41
    v.extract    s41, v12, #2
    v.splat      v17, s41
    s.addi       s41, s40, #128
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #3
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #16576
    a.vread      v14, a5, s42
    v.extract    s42, v12, #3
    v.splat      v17, s42
    s.addi       s42, s40, #192
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #4
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #16640
    a.vread      v14, a5, s41
    v.extract    s41, v12, #4
    v.splat      v17, s41
    s.addi       s41, s40, #256
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #5
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #16704
    a.vread      v14, a5, s42
    v.extract    s42, v12, #5
    v.splat      v17, s42
    s.addi       s42, s40, #320
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #6
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #16768
    a.vread      v14, a5, s41
    v.extract    s41, v12, #6
    v.splat      v17, s41
    s.addi       s41, s40, #384
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #7
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #16832
    a.vread      v14, a5, s42
    v.extract    s42, v12, #7
    v.splat      v17, s42
    s.addi       s42, s40, #448
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #8
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #16896
    a.vread      v14, a5, s41
    v.extract    s41, v12, #8
    v.splat      v17, s41
    s.addi       s41, s40, #512
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #9
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #16960
    a.vread      v14, a5, s42
    v.extract    s42, v12, #9
    v.splat      v17, s42
    s.addi       s42, s40, #576
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #10
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #17024
    a.vread      v14, a5, s41
    v.extract    s41, v12, #10
    v.splat      v17, s41
    s.addi       s41, s40, #640
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #11
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #17088
    a.vread      v14, a5, s42
    v.extract    s42, v12, #11
    v.splat      v17, s42
    s.addi       s42, s40, #704
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #12
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #17152
    a.vread      v14, a5, s41
    v.extract    s41, v12, #12
    v.splat      v17, s41
    s.addi       s41, s40, #768
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #13
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #17216
    a.vread      v14, a5, s42
    v.extract    s42, v12, #13
    v.splat      v17, s42
    s.addi       s42, s40, #832
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #14
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #17280
    a.vread      v14, a5, s41
    v.extract    s41, v12, #14
    v.splat      v17, s41
    s.addi       s41, s40, #896
    s.addi       s43, s40, #960
    v.ld.w       v18, [s42, #0]
    s.movz       s40, #15
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #17344
    a.vread      v14, a5, s40
    v.extract    s40, v12, #15
    v.splat      v17, s40
    s.movz       s40, #0
    v.ld.w       v18, [s41, #0]
    s.addi       s41, s29, #17408
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v33
    vf.add       v18, v14, v17
    v.st.w       [s43, #0], v18
    fence.acq_rel.device
    a.vread      v14, a6, s40
    v.extract    s40, v12, #0
    v.splat      v17, s40
    s.addi       s40, s29, #25600
    s.movz       s42, #1
    v.ld.w       v18, [s41, #0]
    s.addi       s41, s29, #17472
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s40, #0], v18
    a.vread      v14, a6, s42
    v.extract    s42, v12, #1
    v.splat      v17, s42
    s.addi       s42, s40, #64
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #2
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #17536
    a.vread      v14, a6, s41
    v.extract    s41, v12, #2
    v.splat      v17, s41
    s.addi       s41, s40, #128
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #3
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #17600
    a.vread      v14, a6, s42
    v.extract    s42, v12, #3
    v.splat      v17, s42
    s.addi       s42, s40, #192
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #4
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #17664
    a.vread      v14, a6, s41
    v.extract    s41, v12, #4
    v.splat      v17, s41
    s.addi       s41, s40, #256
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #5
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #17728
    a.vread      v14, a6, s42
    v.extract    s42, v12, #5
    v.splat      v17, s42
    s.addi       s42, s40, #320
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #6
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #17792
    a.vread      v14, a6, s41
    v.extract    s41, v12, #6
    v.splat      v17, s41
    s.addi       s41, s40, #384
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #7
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #17856
    a.vread      v14, a6, s42
    v.extract    s42, v12, #7
    v.splat      v17, s42
    s.addi       s42, s40, #448
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #8
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #17920
    a.vread      v14, a6, s41
    v.extract    s41, v12, #8
    v.splat      v17, s41
    s.addi       s41, s40, #512
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #9
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #17984
    a.vread      v14, a6, s42
    v.extract    s42, v12, #9
    v.splat      v17, s42
    s.addi       s42, s40, #576
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #10
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #18048
    a.vread      v14, a6, s41
    v.extract    s41, v12, #10
    v.splat      v17, s41
    s.addi       s41, s40, #640
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #11
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #18112
    a.vread      v14, a6, s42
    v.extract    s42, v12, #11
    v.splat      v17, s42
    s.addi       s42, s40, #704
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #12
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #18176
    a.vread      v14, a6, s41
    v.extract    s41, v12, #12
    v.splat      v17, s41
    s.addi       s41, s40, #768
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #13
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #18240
    a.vread      v14, a6, s42
    v.extract    s42, v12, #13
    v.splat      v17, s42
    s.addi       s42, s40, #832
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #14
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #18304
    a.vread      v14, a6, s41
    v.extract    s41, v12, #14
    v.splat      v17, s41
    s.addi       s41, s40, #896
    s.addi       s43, s40, #960
    v.ld.w       v18, [s42, #0]
    s.movz       s40, #15
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #18368
    a.vread      v14, a6, s40
    v.extract    s40, v12, #15
    v.splat      v17, s40
    s.movz       s40, #0
    v.ld.w       v18, [s41, #0]
    s.addi       s41, s29, #18432
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v34
    vf.add       v18, v14, v17
    v.st.w       [s43, #0], v18
    fence.acq_rel.device
    a.vread      v14, a7, s40
    v.extract    s40, v12, #0
    v.splat      v17, s40
    s.addi       s40, s29, #26624
    s.movz       s42, #1
    v.ld.w       v18, [s41, #0]
    s.addi       s41, s29, #18496
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s40, #0], v18
    a.vread      v14, a7, s42
    v.extract    s42, v12, #1
    v.splat      v17, s42
    s.addi       s42, s40, #64
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #2
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #18560
    a.vread      v14, a7, s41
    v.extract    s41, v12, #2
    v.splat      v17, s41
    s.addi       s41, s40, #128
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #3
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #18624
    a.vread      v14, a7, s42
    v.extract    s42, v12, #3
    v.splat      v17, s42
    s.addi       s42, s40, #192
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #4
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #18688
    a.vread      v14, a7, s41
    v.extract    s41, v12, #4
    v.splat      v17, s41
    s.addi       s41, s40, #256
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #5
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #18752
    a.vread      v14, a7, s42
    v.extract    s42, v12, #5
    v.splat      v17, s42
    s.addi       s42, s40, #320
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #6
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #18816
    a.vread      v14, a7, s41
    v.extract    s41, v12, #6
    v.splat      v17, s41
    s.addi       s41, s40, #384
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #7
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #18880
    a.vread      v14, a7, s42
    v.extract    s42, v12, #7
    v.splat      v17, s42
    s.addi       s42, s40, #448
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #8
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #18944
    a.vread      v14, a7, s41
    v.extract    s41, v12, #8
    v.splat      v17, s41
    s.addi       s41, s40, #512
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #9
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #19008
    a.vread      v14, a7, s42
    v.extract    s42, v12, #9
    v.splat      v17, s42
    s.addi       s42, s40, #576
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #10
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #19072
    a.vread      v14, a7, s41
    v.extract    s41, v12, #10
    v.splat      v17, s41
    s.addi       s41, s40, #640
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #11
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #19136
    a.vread      v14, a7, s42
    v.extract    s42, v12, #11
    v.splat      v17, s42
    s.addi       s42, s40, #704
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #12
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #19200
    a.vread      v14, a7, s41
    v.extract    s41, v12, #12
    v.splat      v17, s41
    s.addi       s41, s40, #768
    v.ld.w       v18, [s42, #0]
    s.movz       s42, #13
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #19264
    a.vread      v14, a7, s42
    v.extract    s42, v12, #13
    v.splat      v17, s42
    s.addi       s42, s40, #832
    v.ld.w       v18, [s41, #0]
    s.movz       s41, #14
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s42, #0], v18
    s.addi       s42, s29, #19328
    a.vread      v14, a7, s41
    v.extract    s41, v12, #14
    v.splat      v17, s41
    s.addi       s41, s40, #896
    s.addi       s43, s40, #960
    v.ld.w       v18, [s42, #0]
    s.movz       s40, #15
    vf.mul       v19, v18, v17
    vf.mul       v17, v19, v35
    vf.add       v18, v14, v17
    v.st.w       [s41, #0], v18
    s.addi       s41, s29, #19392
    a.vread      v14, a7, s40
    v.extract    s40, v12, #15
    v.splat      v12, s40
    s.addi       s40, s27, #128
    s.addi       s42, s16, #4                    // &ptr_carry_19[1] (a constant offset, x4)
    s.addi       s42, s40, #0
    s.addi       s40, s16, #4                    // &ptr_carry_20[1] (a constant offset, x4)
    v.ld.w       v17, [s41, #0]
    s.addi       s40, s24, #128
    s.addi       s41, s16, #4                    // &ptr_carry_21[1] (a constant offset, x4)
    s.addi       s41, s40, #0
    s.addi       s40, s16, #4                    // &ptr_carry_22[1] (a constant offset, x4)
    s.addi       s40, s16, #4                    // &ptr_carry_23[1] (a constant offset, x4)
    vf.mul       v18, v17, v12
    s.addi       s40, s16, #4                    // &ptr_carry_24[1] (a constant offset, x4)
    vf.mul       v12, v18, v35
    s.addi       s40, s16, #4                    // &ptr_carry_25[1] (a constant offset, x4)
    vf.add       v17, v14, v12
    v.st.w       [s43, #0], v17
    s.addi       s40, s16, #4                    // &ptr_carry_18[1] (a constant offset, x4)
    fence.acq_rel.device
    s.addi       s43, s40, #0
    s.mov        s27, s42
    s.addi       s40, s29, #19456
    s.mov        s24, s41
    s.mov        s16, s43
    s.movz       s41, #0
    s.addi       s42, s29, #19520
    v.ld.w       v12, [s40, #0]
    s.movz       s40, #1
    s.addi       s43, s29, #19584
    s.movz       s44, #2
    s.addi       s45, s29, #19648
    a.vwrite     a0, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #3
    s.addi       s42, s29, #19712
    a.vwrite     a0, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #4
    s.addi       s43, s29, #19776
    a.vwrite     a0, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #5
    s.addi       s45, s29, #19840
    a.vwrite     a0, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #6
    s.addi       s42, s29, #19904
    a.vwrite     a0, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #7
    s.addi       s43, s29, #19968
    a.vwrite     a0, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #8
    s.addi       s45, s29, #20032
    a.vwrite     a0, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #9
    s.addi       s42, s29, #20096
    a.vwrite     a0, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #10
    s.addi       s43, s29, #20160
    a.vwrite     a0, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #11
    s.addi       s45, s29, #20224
    a.vwrite     a0, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #12
    s.addi       s42, s29, #20288
    a.vwrite     a0, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #13
    s.addi       s43, s29, #20352
    a.vwrite     a0, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #14
    s.addi       s45, s29, #20416
    a.vwrite     a0, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #15
    s.addi       s42, s29, #20480
    a.vwrite     a0, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #0
    s.addi       s43, s29, #20544
    a.vwrite     a0, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #1
    s.addi       s45, s29, #20608
    a.vwrite     a0, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #2
    s.addi       s42, s29, #20672
    a.vwrite     a1, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #3
    s.addi       s43, s29, #20736
    a.vwrite     a1, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #4
    s.addi       s45, s29, #20800
    a.vwrite     a1, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #5
    s.addi       s42, s29, #20864
    a.vwrite     a1, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #6
    s.addi       s43, s29, #20928
    a.vwrite     a1, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #7
    s.addi       s45, s29, #20992
    a.vwrite     a1, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #8
    s.addi       s42, s29, #21056
    a.vwrite     a1, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #9
    s.addi       s43, s29, #21120
    a.vwrite     a1, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #10
    s.addi       s45, s29, #21184
    a.vwrite     a1, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #11
    s.addi       s42, s29, #21248
    a.vwrite     a1, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #12
    s.addi       s43, s29, #21312
    a.vwrite     a1, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #13
    s.addi       s45, s29, #21376
    a.vwrite     a1, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #14
    s.addi       s42, s29, #21440
    a.vwrite     a1, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #15
    s.addi       s43, s29, #21504
    a.vwrite     a1, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #0
    s.addi       s45, s29, #21568
    a.vwrite     a1, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #1
    s.addi       s42, s29, #21632
    a.vwrite     a1, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #2
    s.addi       s43, s29, #21696
    a.vwrite     a2, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #3
    s.addi       s45, s29, #21760
    a.vwrite     a2, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #4
    s.addi       s42, s29, #21824
    a.vwrite     a2, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #5
    s.addi       s43, s29, #21888
    a.vwrite     a2, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #6
    s.addi       s45, s29, #21952
    a.vwrite     a2, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #7
    s.addi       s42, s29, #22016
    a.vwrite     a2, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #8
    s.addi       s43, s29, #22080
    a.vwrite     a2, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #9
    s.addi       s45, s29, #22144
    a.vwrite     a2, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #10
    s.addi       s42, s29, #22208
    a.vwrite     a2, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #11
    s.addi       s43, s29, #22272
    a.vwrite     a2, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #12
    s.addi       s45, s29, #22336
    a.vwrite     a2, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #13
    s.addi       s42, s29, #22400
    a.vwrite     a2, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #14
    s.addi       s43, s29, #22464
    a.vwrite     a2, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #15
    s.addi       s45, s29, #22528
    a.vwrite     a2, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #0
    s.addi       s42, s29, #22592
    a.vwrite     a2, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #1
    s.addi       s43, s29, #22656
    a.vwrite     a2, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #2
    s.addi       s45, s29, #22720
    a.vwrite     a3, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #3
    s.addi       s42, s29, #22784
    a.vwrite     a3, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #4
    s.addi       s43, s29, #22848
    a.vwrite     a3, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #5
    s.addi       s45, s29, #22912
    a.vwrite     a3, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #6
    s.addi       s42, s29, #22976
    a.vwrite     a3, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #7
    s.addi       s43, s29, #23040
    a.vwrite     a3, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #8
    s.addi       s45, s29, #23104
    a.vwrite     a3, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #9
    s.addi       s42, s29, #23168
    a.vwrite     a3, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #10
    s.addi       s43, s29, #23232
    a.vwrite     a3, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #11
    s.addi       s45, s29, #23296
    a.vwrite     a3, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #12
    s.addi       s42, s29, #23360
    a.vwrite     a3, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #13
    s.addi       s43, s29, #23424
    a.vwrite     a3, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #14
    s.addi       s45, s29, #23488
    a.vwrite     a3, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #15
    s.addi       s42, s29, #23552
    a.vwrite     a3, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #0
    s.addi       s43, s29, #23616
    a.vwrite     a3, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #1
    s.addi       s45, s29, #23680
    a.vwrite     a3, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #2
    s.addi       s42, s29, #23744
    a.vwrite     a4, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #3
    s.addi       s43, s29, #23808
    a.vwrite     a4, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #4
    s.addi       s45, s29, #23872
    a.vwrite     a4, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #5
    s.addi       s42, s29, #23936
    a.vwrite     a4, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #6
    s.addi       s43, s29, #24000
    a.vwrite     a4, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #7
    s.addi       s45, s29, #24064
    a.vwrite     a4, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #8
    s.addi       s42, s29, #24128
    a.vwrite     a4, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #9
    s.addi       s43, s29, #24192
    a.vwrite     a4, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #10
    s.addi       s45, s29, #24256
    a.vwrite     a4, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #11
    s.addi       s42, s29, #24320
    a.vwrite     a4, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #12
    s.addi       s43, s29, #24384
    a.vwrite     a4, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #13
    s.addi       s45, s29, #24448
    a.vwrite     a4, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #14
    s.addi       s42, s29, #24512
    a.vwrite     a4, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #15
    s.addi       s43, s29, #24576
    a.vwrite     a4, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #0
    s.addi       s45, s29, #24640
    a.vwrite     a4, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #1
    s.addi       s42, s29, #24704
    a.vwrite     a4, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #2
    s.addi       s43, s29, #24768
    a.vwrite     a5, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #3
    s.addi       s45, s29, #24832
    a.vwrite     a5, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #4
    s.addi       s42, s29, #24896
    a.vwrite     a5, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #5
    s.addi       s43, s29, #24960
    a.vwrite     a5, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #6
    s.addi       s45, s29, #25024
    a.vwrite     a5, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #7
    s.addi       s42, s29, #25088
    a.vwrite     a5, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #8
    s.addi       s43, s29, #25152
    a.vwrite     a5, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #9
    s.addi       s45, s29, #25216
    a.vwrite     a5, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #10
    s.addi       s42, s29, #25280
    a.vwrite     a5, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #11
    s.addi       s43, s29, #25344
    a.vwrite     a5, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #12
    s.addi       s45, s29, #25408
    a.vwrite     a5, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #13
    s.addi       s42, s29, #25472
    a.vwrite     a5, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #14
    s.addi       s43, s29, #25536
    a.vwrite     a5, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #15
    s.addi       s45, s29, #25600
    a.vwrite     a5, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #0
    s.addi       s42, s29, #25664
    a.vwrite     a5, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #1
    s.addi       s43, s29, #25728
    a.vwrite     a5, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #2
    s.addi       s45, s29, #25792
    a.vwrite     a6, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #3
    s.addi       s42, s29, #25856
    a.vwrite     a6, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #4
    s.addi       s43, s29, #25920
    a.vwrite     a6, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #5
    s.addi       s45, s29, #25984
    a.vwrite     a6, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #6
    s.addi       s42, s29, #26048
    a.vwrite     a6, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #7
    s.addi       s43, s29, #26112
    a.vwrite     a6, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #8
    s.addi       s45, s29, #26176
    a.vwrite     a6, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #9
    s.addi       s42, s29, #26240
    a.vwrite     a6, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #10
    s.addi       s43, s29, #26304
    a.vwrite     a6, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #11
    s.addi       s45, s29, #26368
    a.vwrite     a6, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #12
    s.addi       s42, s29, #26432
    a.vwrite     a6, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #13
    s.addi       s43, s29, #26496
    a.vwrite     a6, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #14
    s.addi       s45, s29, #26560
    a.vwrite     a6, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #15
    s.addi       s42, s29, #26624
    a.vwrite     a6, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #0
    s.addi       s43, s29, #26688
    a.vwrite     a6, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #1
    s.addi       s45, s29, #26752
    a.vwrite     a6, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #2
    s.addi       s42, s29, #26816
    a.vwrite     a7, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #3
    s.addi       s43, s29, #26880
    a.vwrite     a7, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #4
    s.addi       s45, s29, #26944
    a.vwrite     a7, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #5
    s.addi       s42, s29, #27008
    a.vwrite     a7, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #6
    s.addi       s43, s29, #27072
    a.vwrite     a7, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #7
    s.addi       s45, s29, #27136
    a.vwrite     a7, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #8
    s.addi       s42, s29, #27200
    a.vwrite     a7, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #9
    s.addi       s43, s29, #27264
    a.vwrite     a7, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #10
    s.addi       s45, s29, #27328
    a.vwrite     a7, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s41, #11
    s.addi       s42, s29, #27392
    a.vwrite     a7, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #12
    s.addi       s43, s29, #27456
    a.vwrite     a7, s44, v12
    v.ld.w       v12, [s45, #0]
    s.movz       s44, #13
    s.addi       s45, s29, #27520
    s.addi       s46, s29, #27584
    a.vwrite     a7, s41, v12
    v.ld.w       v12, [s42, #0]
    s.movz       s29, #14
    s.movz       s41, #15
    s.add        s42, s26, s1
    a.vwrite     a7, s40, v12
    v.ld.w       v12, [s43, #0]
    s.movz       s40, #1
    a.vwrite     a7, s44, v12
    v.ld.w       v12, [s45, #0]
    a.vwrite     a7, s29, v12
    v.ld.w       v12, [s46, #0]
    a.vwrite     a7, s41, v12
    s.mov        s26, s42
    br.nz        s40, for_26
endfor_27:
    s.mul        s1, s4, s8
    s.muli       s2, s8, #2
    s.muli       s7, s5, #2
    s.movz       s8, #0
    s.addi       s9, s5, #16
    s.muli       s10, s1, #2
    s.movz       s1, #0
    a.vread      v0, a0, s8
    s.addi       s8, s5, #32
    s.add        s13, s1, s4                     // the tile origin
    vf.cvt.f32.bf16 v1, v0
    s.add        s1, s10, s7
    s.addi       s4, s5, #48
    v.splat      v0, s13
    s.add        s14, s12, s1
    s.addi       s1, s5, #64
    s.movz       s15, #0
    s.addi       s16, s5, #80
    s.add        s17, s15, s6                    // the tile origin
    s.addi       s6, s5, #96
    v.splat      v2, s17
    s.addi       s15, s5, #112
    s.movz       s17, #0
    s.movz       s18, #0
    s.add        s19, s17, s5                    // the tile origin
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s19
    s.add        s5, s18, s3                     // the tile origin
    v.add        v5, v3, v4
    s.muli       s17, s2, #1
    v.cmp.lt     p1, v0, v2
    v.splat      v0, s5
    s.movz       s5, #1
    v.cmp.lt     p2, v5, v0
    p.and        p3, p1, p2
    s.addi       s18, s13, #1
    @p3 v.st.h       [s14, #0], v1
    a.vread      v0, a0, s5
    s.add        s5, s17, s10
    v.splat      v1, s18
    s.muli       s14, s2, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s17
    p.and        p3, p1, p2
    s.movz       s17, #2
    s.addi       s18, s13, #2
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a0, s17
    s.add        s5, s14, s10
    v.splat      v1, s18
    s.muli       s14, s2, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s17
    p.and        p3, p1, p2
    s.movz       s17, #3
    s.addi       s18, s13, #3
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a0, s17
    s.add        s5, s14, s10
    v.splat      v1, s18
    s.muli       s14, s2, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s17
    p.and        p3, p1, p2
    s.movz       s17, #4
    s.addi       s18, s13, #4
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a0, s17
    s.add        s5, s14, s10
    v.splat      v1, s18
    s.muli       s14, s2, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s17
    p.and        p3, p1, p2
    s.movz       s17, #5
    s.addi       s18, s13, #5
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a0, s17
    s.add        s5, s14, s10
    v.splat      v1, s18
    s.muli       s14, s2, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s17
    p.and        p3, p1, p2
    s.movz       s17, #6
    s.addi       s18, s13, #6
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a0, s17
    s.add        s5, s14, s10
    v.splat      v1, s18
    s.muli       s14, s2, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s17
    p.and        p3, p1, p2
    s.movz       s17, #7
    s.addi       s18, s13, #7
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a0, s17
    s.add        s5, s14, s10
    v.splat      v1, s18
    s.muli       s14, s2, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s17
    p.and        p3, p1, p2
    s.movz       s17, #8
    s.addi       s18, s13, #8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a0, s17
    s.add        s5, s14, s10
    v.splat      v1, s18
    s.muli       s14, s2, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s17
    p.and        p3, p1, p2
    s.movz       s17, #9
    s.addi       s18, s13, #9
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a0, s17
    s.add        s5, s14, s10
    v.splat      v1, s18
    s.muli       s14, s2, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s17
    p.and        p3, p1, p2
    s.movz       s17, #10
    s.addi       s18, s13, #10
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a0, s17
    s.add        s5, s14, s10
    v.splat      v1, s18
    s.muli       s14, s2, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s17
    p.and        p3, p1, p2
    s.movz       s17, #11
    s.addi       s18, s13, #11
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a0, s17
    s.add        s5, s14, s10
    v.splat      v1, s18
    s.muli       s14, s2, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s17
    p.and        p3, p1, p2
    s.movz       s17, #12
    s.addi       s18, s13, #12
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a0, s17
    s.add        s5, s14, s10
    v.splat      v1, s18
    s.muli       s14, s2, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s17
    p.and        p3, p1, p2
    s.movz       s17, #13
    s.addi       s18, s13, #13
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a0, s17
    s.add        s5, s14, s10
    v.splat      v1, s18
    s.muli       s14, s2, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s17
    p.and        p3, p1, p2
    s.movz       s17, #14
    s.addi       s18, s13, #14
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a0, s17
    s.add        s5, s14, s10
    v.splat      v1, s18
    s.muli       s14, s2, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s17
    p.and        p3, p1, p2
    s.movz       s17, #15
    s.addi       s18, s13, #15
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a0, s17
    s.add        s5, s14, s10
    v.splat      v1, s18
    vf.cvt.f32.bf16 v4, v0
    s.movz       s14, #0
    s.add        s17, s5, s7
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s9, #2
    s.add        s7, s14, s9                     // the tile origin
    s.add        s9, s12, s17
    s.movz       s14, #0
    p.and        p3, p1, p2
    s.movz       s17, #0
    v.splat      v0, s7
    s.add        s7, s14, s3                     // the tile origin
    @p3 v.st.h       [s9, #0], v4
    a.vread      v1, a1, s17
    v.splat      v4, s13
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s9, s10, s5
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s7
    s.add        s7, s12, s9
    s.muli       s9, s2, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s14, #1
    s.addi       s17, s13, #1
    @p3 v.st.h       [s7, #0], v0
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    s.muli       s9, s2, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s14
    p.and        p3, p1, p2
    s.movz       s14, #2
    s.addi       s17, s13, #2
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    s.muli       s9, s2, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s14
    p.and        p3, p1, p2
    s.movz       s14, #3
    s.addi       s17, s13, #3
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    s.muli       s9, s2, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s14
    p.and        p3, p1, p2
    s.movz       s14, #4
    s.addi       s17, s13, #4
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    s.muli       s9, s2, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s14
    p.and        p3, p1, p2
    s.movz       s14, #5
    s.addi       s17, s13, #5
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    s.muli       s9, s2, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s14
    p.and        p3, p1, p2
    s.movz       s14, #6
    s.addi       s17, s13, #6
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    s.muli       s9, s2, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s14
    p.and        p3, p1, p2
    s.movz       s14, #7
    s.addi       s17, s13, #7
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    s.muli       s9, s2, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s14
    p.and        p3, p1, p2
    s.movz       s14, #8
    s.addi       s17, s13, #8
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    s.muli       s9, s2, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s14
    p.and        p3, p1, p2
    s.movz       s14, #9
    s.addi       s17, s13, #9
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    s.muli       s9, s2, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s14
    p.and        p3, p1, p2
    s.movz       s14, #10
    s.addi       s17, s13, #10
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    s.muli       s9, s2, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s14
    p.and        p3, p1, p2
    s.movz       s14, #11
    s.addi       s17, s13, #11
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    s.muli       s9, s2, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s14
    p.and        p3, p1, p2
    s.movz       s14, #12
    s.addi       s17, s13, #12
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    s.muli       s9, s2, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s14
    p.and        p3, p1, p2
    s.movz       s14, #13
    s.addi       s17, s13, #13
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    s.muli       s9, s2, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s14
    p.and        p3, p1, p2
    s.movz       s14, #14
    s.addi       s17, s13, #14
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    s.muli       s9, s2, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s14
    p.and        p3, p1, p2
    s.movz       s14, #15
    s.addi       s17, s13, #15
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a1, s14
    s.add        s7, s9, s10
    v.splat      v1, s17
    vf.cvt.f32.bf16 v4, v0
    s.movz       s9, #0
    s.add        s14, s7, s5
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s8, #2
    s.add        s7, s9, s8                      // the tile origin
    s.add        s8, s12, s14
    s.movz       s9, #0
    p.and        p3, p1, p2
    s.movz       s14, #0
    v.splat      v0, s7
    s.add        s7, s9, s3                      // the tile origin
    @p3 v.st.h       [s8, #0], v4
    a.vread      v1, a2, s14
    v.splat      v4, s13
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s8, s10, s5
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s7
    s.add        s7, s12, s8
    s.muli       s8, s2, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s9, #1
    s.addi       s14, s13, #1
    @p3 v.st.h       [s7, #0], v0
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    s.muli       s8, s2, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s9
    p.and        p3, p1, p2
    s.movz       s9, #2
    s.addi       s14, s13, #2
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    s.muli       s8, s2, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s9
    p.and        p3, p1, p2
    s.movz       s9, #3
    s.addi       s14, s13, #3
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    s.muli       s8, s2, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s9
    p.and        p3, p1, p2
    s.movz       s9, #4
    s.addi       s14, s13, #4
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    s.muli       s8, s2, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s9
    p.and        p3, p1, p2
    s.movz       s9, #5
    s.addi       s14, s13, #5
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    s.muli       s8, s2, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s9
    p.and        p3, p1, p2
    s.movz       s9, #6
    s.addi       s14, s13, #6
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    s.muli       s8, s2, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s9
    p.and        p3, p1, p2
    s.movz       s9, #7
    s.addi       s14, s13, #7
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    s.muli       s8, s2, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s9
    p.and        p3, p1, p2
    s.movz       s9, #8
    s.addi       s14, s13, #8
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    s.muli       s8, s2, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s9
    p.and        p3, p1, p2
    s.movz       s9, #9
    s.addi       s14, s13, #9
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    s.muli       s8, s2, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s9
    p.and        p3, p1, p2
    s.movz       s9, #10
    s.addi       s14, s13, #10
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    s.muli       s8, s2, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s9
    p.and        p3, p1, p2
    s.movz       s9, #11
    s.addi       s14, s13, #11
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    s.muli       s8, s2, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s9
    p.and        p3, p1, p2
    s.movz       s9, #12
    s.addi       s14, s13, #12
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    s.muli       s8, s2, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s9
    p.and        p3, p1, p2
    s.movz       s9, #13
    s.addi       s14, s13, #13
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    s.muli       s8, s2, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s9
    p.and        p3, p1, p2
    s.movz       s9, #14
    s.addi       s14, s13, #14
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    s.muli       s8, s2, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s9
    p.and        p3, p1, p2
    s.movz       s9, #15
    s.addi       s14, s13, #15
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a2, s9
    s.add        s7, s8, s10
    v.splat      v1, s14
    vf.cvt.f32.bf16 v4, v0
    s.movz       s8, #0
    s.add        s9, s7, s5
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s4, #2
    s.add        s7, s8, s4                      // the tile origin
    s.add        s4, s12, s9
    s.movz       s8, #0
    p.and        p3, p1, p2
    s.movz       s9, #0
    v.splat      v0, s7
    s.add        s7, s8, s3                      // the tile origin
    @p3 v.st.h       [s4, #0], v4
    a.vread      v1, a3, s9
    v.splat      v4, s13
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s4, s10, s5
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s7
    s.add        s7, s12, s4
    s.muli       s4, s2, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s8, #1
    s.addi       s9, s13, #1
    @p3 v.st.h       [s7, #0], v0
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    s.muli       s4, s2, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s8
    p.and        p3, p1, p2
    s.movz       s8, #2
    s.addi       s9, s13, #2
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    s.muli       s4, s2, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s8
    p.and        p3, p1, p2
    s.movz       s8, #3
    s.addi       s9, s13, #3
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    s.muli       s4, s2, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s8
    p.and        p3, p1, p2
    s.movz       s8, #4
    s.addi       s9, s13, #4
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    s.muli       s4, s2, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s8
    p.and        p3, p1, p2
    s.movz       s8, #5
    s.addi       s9, s13, #5
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    s.muli       s4, s2, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s8
    p.and        p3, p1, p2
    s.movz       s8, #6
    s.addi       s9, s13, #6
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    s.muli       s4, s2, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s8
    p.and        p3, p1, p2
    s.movz       s8, #7
    s.addi       s9, s13, #7
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    s.muli       s4, s2, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s8
    p.and        p3, p1, p2
    s.movz       s8, #8
    s.addi       s9, s13, #8
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    s.muli       s4, s2, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s8
    p.and        p3, p1, p2
    s.movz       s8, #9
    s.addi       s9, s13, #9
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    s.muli       s4, s2, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s8
    p.and        p3, p1, p2
    s.movz       s8, #10
    s.addi       s9, s13, #10
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    s.muli       s4, s2, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s8
    p.and        p3, p1, p2
    s.movz       s8, #11
    s.addi       s9, s13, #11
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    s.muli       s4, s2, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s8
    p.and        p3, p1, p2
    s.movz       s8, #12
    s.addi       s9, s13, #12
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    s.muli       s4, s2, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s8
    p.and        p3, p1, p2
    s.movz       s8, #13
    s.addi       s9, s13, #13
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    s.muli       s4, s2, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s8
    p.and        p3, p1, p2
    s.movz       s8, #14
    s.addi       s9, s13, #14
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    s.muli       s4, s2, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.add        s7, s12, s8
    p.and        p3, p1, p2
    s.movz       s8, #15
    s.addi       s9, s13, #15
    @p3 v.st.h       [s7, #0], v4
    a.vread      v0, a3, s8
    s.add        s7, s4, s10
    v.splat      v1, s9
    vf.cvt.f32.bf16 v4, v0
    s.movz       s4, #0
    s.add        s8, s7, s5
    v.cmp.lt     p1, v1, v2
    s.muli       s5, s1, #2
    s.add        s7, s4, s1                      // the tile origin
    s.add        s1, s12, s8
    s.movz       s4, #0
    p.and        p3, p1, p2
    s.movz       s8, #0
    v.splat      v0, s7
    s.add        s7, s4, s3                      // the tile origin
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a4, s8
    v.splat      v4, s13
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s1, s10, s5
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s7
    s.add        s4, s12, s1
    s.muli       s1, s2, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s7, #1
    s.addi       s8, s13, #1
    @p3 v.st.h       [s4, #0], v0
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.add        s4, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #2
    s.addi       s8, s13, #2
    @p3 v.st.h       [s4, #0], v4
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.add        s4, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #3
    s.addi       s8, s13, #3
    @p3 v.st.h       [s4, #0], v4
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.add        s4, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #4
    s.addi       s8, s13, #4
    @p3 v.st.h       [s4, #0], v4
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.add        s4, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #5
    s.addi       s8, s13, #5
    @p3 v.st.h       [s4, #0], v4
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.add        s4, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #6
    s.addi       s8, s13, #6
    @p3 v.st.h       [s4, #0], v4
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.add        s4, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #7
    s.addi       s8, s13, #7
    @p3 v.st.h       [s4, #0], v4
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.add        s4, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #8
    s.addi       s8, s13, #8
    @p3 v.st.h       [s4, #0], v4
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.add        s4, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #9
    s.addi       s8, s13, #9
    @p3 v.st.h       [s4, #0], v4
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.add        s4, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #10
    s.addi       s8, s13, #10
    @p3 v.st.h       [s4, #0], v4
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.add        s4, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #11
    s.addi       s8, s13, #11
    @p3 v.st.h       [s4, #0], v4
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.add        s4, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #12
    s.addi       s8, s13, #12
    @p3 v.st.h       [s4, #0], v4
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.add        s4, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #13
    s.addi       s8, s13, #13
    @p3 v.st.h       [s4, #0], v4
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.add        s4, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #14
    s.addi       s8, s13, #14
    @p3 v.st.h       [s4, #0], v4
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.add        s4, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #15
    s.addi       s8, s13, #15
    @p3 v.st.h       [s4, #0], v4
    a.vread      v0, a4, s7
    s.add        s4, s1, s10
    v.splat      v1, s8
    vf.cvt.f32.bf16 v4, v0
    s.movz       s1, #0
    s.add        s7, s4, s5
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s16, #2
    s.add        s5, s1, s16                     // the tile origin
    s.add        s1, s12, s7
    s.movz       s7, #0
    p.and        p3, p1, p2
    s.movz       s8, #0
    v.splat      v0, s5
    s.add        s5, s7, s3                      // the tile origin
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a5, s8
    v.splat      v4, s13
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s1, s10, s4
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s5
    s.add        s5, s12, s1
    s.muli       s1, s2, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s7, #1
    s.addi       s8, s13, #1
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #2
    s.addi       s8, s13, #2
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #3
    s.addi       s8, s13, #3
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #4
    s.addi       s8, s13, #4
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #5
    s.addi       s8, s13, #5
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #6
    s.addi       s8, s13, #6
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #7
    s.addi       s8, s13, #7
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #8
    s.addi       s8, s13, #8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #9
    s.addi       s8, s13, #9
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #10
    s.addi       s8, s13, #10
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #11
    s.addi       s8, s13, #11
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #12
    s.addi       s8, s13, #12
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #13
    s.addi       s8, s13, #13
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #14
    s.addi       s8, s13, #14
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    s.muli       s1, s2, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s7
    p.and        p3, p1, p2
    s.movz       s7, #15
    s.addi       s8, s13, #15
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a5, s7
    s.add        s5, s1, s10
    v.splat      v1, s8
    vf.cvt.f32.bf16 v4, v0
    s.movz       s1, #0
    s.add        s7, s5, s4
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s6, #2
    s.add        s5, s1, s6                      // the tile origin
    s.add        s1, s12, s7
    s.movz       s6, #0
    p.and        p3, p1, p2
    s.movz       s7, #0
    v.splat      v0, s5
    s.add        s5, s6, s3                      // the tile origin
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a6, s7
    v.splat      v4, s13
    v.add        v5, v3, v0
    vf.cvt.f32.bf16 v0, v1
    s.add        s1, s10, s4
    v.cmp.lt     p1, v4, v2
    v.splat      v1, s5
    s.add        s5, s12, s1
    s.muli       s1, s2, #1
    v.cmp.lt     p2, v5, v1
    p.and        p3, p1, p2
    s.movz       s6, #1
    s.addi       s7, s13, #1
    @p3 v.st.h       [s5, #0], v0
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    s.muli       s1, s2, #2
    vf.cvt.f32.bf16 v4, v0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s6
    p.and        p3, p1, p2
    s.movz       s6, #2
    s.addi       s7, s13, #2
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    s.muli       s1, s2, #3
    vf.cvt.f32.bf16 v4, v0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s6
    p.and        p3, p1, p2
    s.movz       s6, #3
    s.addi       s7, s13, #3
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    s.muli       s1, s2, #4
    vf.cvt.f32.bf16 v4, v0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s6
    p.and        p3, p1, p2
    s.movz       s6, #4
    s.addi       s7, s13, #4
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    s.muli       s1, s2, #5
    vf.cvt.f32.bf16 v4, v0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s6
    p.and        p3, p1, p2
    s.movz       s6, #5
    s.addi       s7, s13, #5
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    s.muli       s1, s2, #6
    vf.cvt.f32.bf16 v4, v0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s6
    p.and        p3, p1, p2
    s.movz       s6, #6
    s.addi       s7, s13, #6
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    s.muli       s1, s2, #7
    vf.cvt.f32.bf16 v4, v0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s6
    p.and        p3, p1, p2
    s.movz       s6, #7
    s.addi       s7, s13, #7
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    s.muli       s1, s2, #8
    vf.cvt.f32.bf16 v4, v0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s6
    p.and        p3, p1, p2
    s.movz       s6, #8
    s.addi       s7, s13, #8
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    s.muli       s1, s2, #9
    vf.cvt.f32.bf16 v4, v0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s6
    p.and        p3, p1, p2
    s.movz       s6, #9
    s.addi       s7, s13, #9
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    s.muli       s1, s2, #10
    vf.cvt.f32.bf16 v4, v0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s6
    p.and        p3, p1, p2
    s.movz       s6, #10
    s.addi       s7, s13, #10
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    s.muli       s1, s2, #11
    vf.cvt.f32.bf16 v4, v0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s6
    p.and        p3, p1, p2
    s.movz       s6, #11
    s.addi       s7, s13, #11
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    s.muli       s1, s2, #12
    vf.cvt.f32.bf16 v4, v0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s6
    p.and        p3, p1, p2
    s.movz       s6, #12
    s.addi       s7, s13, #12
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    s.muli       s1, s2, #13
    vf.cvt.f32.bf16 v4, v0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s6
    p.and        p3, p1, p2
    s.movz       s6, #13
    s.addi       s7, s13, #13
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    s.muli       s1, s2, #14
    vf.cvt.f32.bf16 v4, v0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s6
    p.and        p3, p1, p2
    s.movz       s6, #14
    s.addi       s7, s13, #14
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    s.muli       s1, s2, #15
    vf.cvt.f32.bf16 v4, v0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.add        s5, s12, s6
    p.and        p3, p1, p2
    s.movz       s6, #15
    s.addi       s7, s13, #15
    @p3 v.st.h       [s5, #0], v4
    a.vread      v0, a6, s6
    s.add        s5, s1, s10
    v.splat      v1, s7
    vf.cvt.f32.bf16 v4, v0
    s.movz       s1, #0
    s.add        s6, s5, s4
    v.cmp.lt     p1, v1, v2
    s.muli       s4, s15, #2
    s.add        s5, s1, s15                     // the tile origin
    s.add        s1, s12, s6
    s.movz       s6, #0
    p.and        p3, p1, p2
    s.movz       s7, #0
    v.splat      v0, s5
    s.add        s5, s6, s3                      // the tile origin
    @p3 v.st.h       [s1, #0], v4
    a.vread      v1, a7, s7
    v.splat      v4, s13
    v.add        v5, v3, v0
    v.splat      v0, s5
    vf.cvt.f32.bf16 v3, v1
    s.add        s1, s10, s4
    v.cmp.lt     p1, v4, v2
    v.cmp.lt     p2, v5, v0
    s.add        s3, s12, s1
    s.muli       s1, s2, #1
    p.and        p3, p1, p2
    s.movz       s5, #1
    s.addi       s6, s13, #1
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s5
    s.add        s3, s1, s10
    v.splat      v1, s6
    s.muli       s1, s2, #2
    vf.cvt.f32.bf16 v3, v0
    s.add        s5, s3, s4
    v.cmp.lt     p1, v1, v2
    s.add        s3, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #2
    s.addi       s6, s13, #2
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s5
    s.add        s3, s1, s10
    v.splat      v1, s6
    s.muli       s1, s2, #3
    vf.cvt.f32.bf16 v3, v0
    s.add        s5, s3, s4
    v.cmp.lt     p1, v1, v2
    s.add        s3, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #3
    s.addi       s6, s13, #3
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s5
    s.add        s3, s1, s10
    v.splat      v1, s6
    s.muli       s1, s2, #4
    vf.cvt.f32.bf16 v3, v0
    s.add        s5, s3, s4
    v.cmp.lt     p1, v1, v2
    s.add        s3, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #4
    s.addi       s6, s13, #4
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s5
    s.add        s3, s1, s10
    v.splat      v1, s6
    s.muli       s1, s2, #5
    vf.cvt.f32.bf16 v3, v0
    s.add        s5, s3, s4
    v.cmp.lt     p1, v1, v2
    s.add        s3, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #5
    s.addi       s6, s13, #5
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s5
    s.add        s3, s1, s10
    v.splat      v1, s6
    s.muli       s1, s2, #6
    vf.cvt.f32.bf16 v3, v0
    s.add        s5, s3, s4
    v.cmp.lt     p1, v1, v2
    s.add        s3, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #6
    s.addi       s6, s13, #6
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s5
    s.add        s3, s1, s10
    v.splat      v1, s6
    s.muli       s1, s2, #7
    vf.cvt.f32.bf16 v3, v0
    s.add        s5, s3, s4
    v.cmp.lt     p1, v1, v2
    s.add        s3, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #7
    s.addi       s6, s13, #7
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s5
    s.add        s3, s1, s10
    v.splat      v1, s6
    s.muli       s1, s2, #8
    vf.cvt.f32.bf16 v3, v0
    s.add        s5, s3, s4
    v.cmp.lt     p1, v1, v2
    s.add        s3, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #8
    s.addi       s6, s13, #8
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s5
    s.add        s3, s1, s10
    v.splat      v1, s6
    s.muli       s1, s2, #9
    vf.cvt.f32.bf16 v3, v0
    s.add        s5, s3, s4
    v.cmp.lt     p1, v1, v2
    s.add        s3, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #9
    s.addi       s6, s13, #9
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s5
    s.add        s3, s1, s10
    v.splat      v1, s6
    s.muli       s1, s2, #10
    vf.cvt.f32.bf16 v3, v0
    s.add        s5, s3, s4
    v.cmp.lt     p1, v1, v2
    s.add        s3, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #10
    s.addi       s6, s13, #10
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s5
    s.add        s3, s1, s10
    v.splat      v1, s6
    s.muli       s1, s2, #11
    vf.cvt.f32.bf16 v3, v0
    s.add        s5, s3, s4
    v.cmp.lt     p1, v1, v2
    s.add        s3, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #11
    s.addi       s6, s13, #11
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s5
    s.add        s3, s1, s10
    v.splat      v1, s6
    s.muli       s1, s2, #12
    vf.cvt.f32.bf16 v3, v0
    s.add        s5, s3, s4
    v.cmp.lt     p1, v1, v2
    s.add        s3, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #12
    s.addi       s6, s13, #12
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s5
    s.add        s3, s1, s10
    v.splat      v1, s6
    s.muli       s1, s2, #13
    vf.cvt.f32.bf16 v3, v0
    s.add        s5, s3, s4
    v.cmp.lt     p1, v1, v2
    s.add        s3, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #13
    s.addi       s6, s13, #13
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s5
    s.add        s3, s1, s10
    v.splat      v1, s6
    s.muli       s1, s2, #14
    vf.cvt.f32.bf16 v3, v0
    s.add        s5, s3, s4
    v.cmp.lt     p1, v1, v2
    s.add        s3, s12, s5
    p.and        p3, p1, p2
    s.movz       s5, #14
    s.addi       s6, s13, #14
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s5
    s.add        s3, s1, s10
    v.splat      v1, s6
    s.muli       s1, s2, #15
    vf.cvt.f32.bf16 v3, v0
    s.add        s2, s3, s4
    v.cmp.lt     p1, v1, v2
    s.add        s3, s12, s2
    p.and        p3, p1, p2
    s.movz       s2, #15
    s.addi       s5, s13, #15
    @p3 v.st.h       [s3, #0], v3
    a.vread      v0, a7, s2
    s.add        s2, s1, s10
    v.splat      v1, s5
    vf.cvt.f32.bf16 v3, v0
    s.add        s1, s2, s4
    v.cmp.lt     p1, v1, v2
    s.add        s2, s12, s1
    p.and        p3, p1, p2
    @p3 v.st.h       [s2, #0], v3
    exit
    exit
