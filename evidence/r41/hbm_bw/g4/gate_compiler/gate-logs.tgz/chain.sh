#!/bin/bash
bash ~/r41g4_gate/gate_g4.sh base > ~/r41g4_gate/gate-base.out 2>&1
bash ~/r41g4_gate/gate_g4.sh head > ~/r41g4_gate/gate-head.out 2>&1
echo done > ~/r41g4_gate/CHAIN_DONE
