    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // in_ptr2: device_ptr64 at arg_base+16
    s.ld.d       s6, [s1, #24]                   // in_ptr3: device_ptr64 at arg_base+24
    s.ld.d       s7, [s1, #32]                   // in_ptr4: device_ptr64 at arg_base+32
    s.ld.d       s8, [s1, #40]                   // out_ptr0: device_ptr64 at arg_base+40
    s.rdspecial  s1, arg_base
    s.ld.d       s9, [s1, #48]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s10, #512
    s.mul        s11, s1, s10
    s.add        s1, s9, s11                     // this context's own scratch
    s.addi       s9, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s9, #0], s2
    .li       s1, #2147483647
    s.st.d       [s9, #8], s1
    .li       s1, #2147483647
    s.st.d       [s9, #16], s1
    s.movz       s1, #16
    s.st.d       [s9, #48], s1
    s.movz       s1, #1
    s.st.d       [s9, #56], s1
    .li       s1, #68719476752
    s.st.d       [s9, #88], s1
    .li       s1, #7705171329024
    s.st.d       [s9, #104], s1
    fence.release.device
    td.load      d0, [s9]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #1
    s.movz       s2, #0
    s.movz       s9, #0
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.movz       s13, #0
    s.movz       s14, #1
    s.sub        s15, s1, s4
    s.min.s      s16, s15, s1
    s.cmp.lt     s1, s4, s9
    s.sub        s9, s2, s1
    s.cmp.lt     s1, s16, s11
    s.sub        s2, s10, s1
    s.xor        s1, s4, s9
    s.sub        s10, s1, s9
    s.xor        s1, s16, s2
    s.sub        s11, s1, s2
    s.addi       s1, s12, #0
    s.addi       s2, s13, #0
    s.cmp.eq     s12, s11, s14
    s.mov        s1, s10
    br.nz        s12, sdiv_done_1
    s.movz       s12, #0
    s.movz       s13, #31
    s.mov        s1, s12
    s.addi       s12, s13, #0
sdiv_2:
    s.lshr       s13, s10, s12
    s.shli       s14, s2, #1
    s.andi       s15, s13, #1
    s.movz       s13, #0
    s.or         s17, s14, s15
    s.movz       s14, #1
    s.cmp.geu    s15, s17, s11
    s.shl        s18, s14, s12
    s.sub        s14, s13, s15
    s.subi       s13, s12, #1
    s.and        s15, s11, s14
    s.and        s19, s18, s14
    s.sub        s14, s17, s15
    s.or         s15, s1, s19
    s.mov        s2, s14
    s.mov        s1, s15
    s.mov        s12, s13
    s.movz       s13, #0
    s.cmp.ge     s14, s12, s13
    br.nz        s14, sdiv_2
sdiv_done_1:
    s.movz       s1, #0
    s.movz       s10, #0
    s.movz       s11, #0
    s.movz       s12, #0
    s.cmp.lt     s13, s16, s1
    s.movz       s1, #0
    s.cmp.lt     s14, s10, s11
    s.sub        s11, s12, s13
    s.sub        s12, s1, s14
    s.xor        s1, s16, s11
    s.xor        s13, s2, s9
    s.xor        s2, s10, s12
    s.sub        s14, s1, s11
    s.movz       s1, #0
    s.movz       s15, #1
    s.sub        s16, s13, s9
    s.sub        s9, s2, s12
    s.movz       s2, #0
    s.addi       s13, s1, #0
    s.cmp.eq     s1, s14, s15
    s.add        s15, s4, s16
    s.addi       s4, s2, #0
    s.mov        s13, s9
    br.nz        s1, sdiv_done_3
    s.movz       s1, #0
    s.movz       s2, #31
    s.mov        s13, s1
    s.addi       s1, s2, #0
sdiv_4:
    s.lshr       s2, s9, s1
    s.shli       s16, s4, #1
    s.andi       s17, s2, #1
    s.movz       s2, #0
    s.or         s18, s16, s17
    s.movz       s16, #1
    s.cmp.geu    s17, s18, s14
    s.shl        s19, s16, s1
    s.sub        s16, s2, s17
    s.subi       s2, s1, #1
    s.and        s17, s14, s16
    s.and        s20, s19, s16
    s.sub        s16, s18, s17
    s.or         s17, s13, s20
    s.mov        s4, s16
    s.mov        s13, s17
    s.mov        s1, s2
    s.movz       s2, #0
    s.cmp.ge     s16, s1, s2
    br.nz        s16, sdiv_4
sdiv_done_3:
    s.xor        s1, s12, s11
    s.movz       s2, #16
    s.xor        s4, s13, s1
    s.movz       s9, #16
    s.sub        s11, s4, s1
    s.mul        s1, s15, s2
    s.mul        s4, s11, s2
    // repack 16x16 f8E4M3FN through memory: there is no v.pack (ISA sec 8.4)
    s.movz       s12, #0
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s9
    w.def        w0, #60, #4                     // v60..v63
    s.andi       s9, s4, #15
    mb.arm       s13, b0, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.muli       s14, s9, #16                    // a runtime tile origin, x16
    v.mul        v2, v0, v1
    s.andi       s16, s1, #15
    s.movz       s17, #0
    v.splat      v0, s15
    s.add        s15, s12, s14                   // the tile origin
    s.rdspecial  s12, arg_base
    v.splat      v1, s15
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s18, s16                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s19, s17                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.b w0, d0, s18, s13
    mb.wait      s13
    s.ld.d       s14, [s12, #48]                 // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.add        v3, v2, v1
    s.rdspecial  s12, role_id
    s.movz       s17, #512
    v.splat      v1, s10
    s.mul        s18, s12, s17
    s.addi       s12, s15, #1
    v.splat      v4, s11
    v.splat      v5, s12
    v.splat      v6, s10
    v.iota       v7                              // arange(0, VLEN)
    v.ld.gather.b v8, [s3, v3]                   // index is in elements (ISA sec 9.1)
    s.add        s10, s14, s18                   // this context's own scratch
    v.add        v3, v2, v5
    s.addi       s11, s10, #256                  // 256 bytes of repack scratch
    v.splat      v5, s1
    s.addi       s10, s11, #16                   // row 1
    v.cmp.ge     p1, v0, v1
    s.addi       s12, s15, #2
    v.splat      v0, s4
    v.splat      v1, s12
    v.cmp.ge     p1, v4, v6
    s.addi       s12, s15, #3
    v.st.b       [s11, #0], v8
    v.add        v4, v2, v1
    s.addi       s14, s11, #32                   // row 2
    v.splat      v1, s16
    v.iota       v6                              // arange(0, VLEN)
    v.splat      v8, s9
    v.add        v9, v5, v7
    v.splat      v5, s12
    v.add        v9, v0, v7
    s.addi       s9, s15, #4
    v.add        v0, v2, v5
    v.splat      v5, s9
    v.ld.gather.b v7, [s3, v3]                   // index is in elements (ISA sec 9.1)
    s.addi       s9, s11, #48                    // row 3
    v.iota       v3                              // arange(0, VLEN)
    v.add        v9, v1, v6
    v.add        v1, v2, v5
    s.addi       s12, s11, #64                   // row 4
    v.add        v5, v8, v3
    s.addi       s16, s15, #5
    s.addi       s17, s15, #6
    v.splat      v3, s16
    v.splat      v5, s17
    s.addi       s16, s11, #80                   // row 5
    v.st.b       [s10, #0], v7
    v.add        v6, v2, v3
    v.add        v3, v2, v5
    s.addi       s10, s15, #7
    s.addi       s17, s11, #96                   // row 6
    v.splat      v5, s10
    s.addi       s10, s15, #8
    v.add        v7, v2, v5
    v.splat      v5, s10
    s.addi       s10, s11, #112                  // row 7
    v.ld.gather.b v8, [s3, v4]                   // index is in elements (ISA sec 9.1)
    v.add        v4, v2, v5
    v.st.b       [s14, #0], v8
    s.addi       s14, s15, #9
    v.splat      v5, s14
    s.addi       s14, s11, #128                  // row 8
    v.add        v8, v2, v5
    v.ld.gather.b v5, [s3, v0]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s9, #0], v5
    s.addi       s9, s15, #10
    v.splat      v0, s9
    s.addi       s9, s11, #144                   // row 9
    v.add        v5, v2, v0
    v.ld.gather.b v0, [s3, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s12, #0], v0
    s.addi       s12, s15, #11
    v.splat      v0, s12
    s.addi       s12, s11, #160                  // row 10
    v.add        v1, v2, v0
    v.ld.gather.b v0, [s3, v6]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s16, #0], v0
    s.addi       s16, s15, #12
    v.splat      v0, s16
    s.addi       s16, s11, #176                  // row 11
    v.add        v6, v2, v0
    v.ld.gather.b v0, [s3, v3]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s17, #0], v0
    s.addi       s17, s15, #13
    v.splat      v0, s17
    s.addi       s17, s11, #192                  // row 12
    v.add        v3, v2, v0
    v.ld.gather.b v0, [s3, v7]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s10, #0], v0
    s.addi       s10, s15, #14
    s.addi       s18, s15, #15
    v.splat      v0, s10
    s.addi       s10, s11, #208                  // row 13
    v.splat      v7, s18
    v.add        v9, v2, v0
    s.addi       s15, s11, #224                  // row 14
    v.add        v0, v2, v7
    v.ld.gather.b v2, [s3, v4]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s14, #0], v2
    s.addi       s14, s11, #240                  // row 15
    v.ld.gather.b v2, [s3, v8]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s9, #0], v2
    s.addi       s9, s11, #64
    v.ld.gather.b v2, [s3, v5]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s12, #0], v2
    s.addi       s12, s11, #128
    v.movi       v2, #0
    v.ld.gather.b v4, [s3, v1]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s16, #0], v4
    s.addi       s16, s11, #192
    v.splat      v1, s2
    v.ld.gather.b v4, [s3, v6]                   // index is in elements (ISA sec 9.1)
    v.st.b       [s17, #0], v4
    s.movz       s17, #0
    v.iota       v4                              // arange(0, VLEN)
    s.add        s18, s17, s4                    // the tile origin
    v.splat      v5, s2
    s.movz       s2, #0
    v.splat      v6, s18
    s.add        s17, s2, s1                     // the tile origin
    s.movz       s2, #0
    v.splat      v7, s17
    v.add        v8, v4, v6
    s.add        s18, s2, s1                     // the tile origin
    v.ld.gather.b v4, [s3, v3]                   // index is in elements (ISA sec 9.1)
    v.splat      v3, s18
    v.cmp.lt     p1, v7, v1
    v.cmp.lt     p2, v8, v5
    p.and        p3, p1, p2
    v.st.b       [s10, #0], v4
    s.addi       s2, s18, #1
    v.ld.gather.b v4, [s3, v9]                   // index is in elements (ISA sec 9.1)
    v.splat      v5, s2
    s.addi       s2, s17, #1
    v.st.b       [s15, #0], v4
    v.splat      v4, s2
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s2, #0
    s.movz       s10, #1
    v.cmp.lt     p1, v4, v1
    p.and        p4, p1, p2
    v.ld.gather.b v4, [s3, v0]                   // index is in elements (ISA sec 9.1)
    s.movz       s3, #2
    v.st.b       [s14, #0], v4
    w.def        w1, #56, #4                     // v56..v59
    fence.acq_rel.device
    s.addi       s14, s17, #2
    v.ld.w       v0, [s11, #0]
    v.splat      v4, s14
    s.addi       s11, s18, #2
    v.splat      v6, s11
    v.mov        v56, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s9, #0]
    v.mov        v57, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s12, #0]
    s.addi       s9, s18, #3
    s.movz       s11, #3
    v.mov        v58, v0                         // hand off through the shared window (sec 7.3)
    v.ld.w       v0, [s16, #0]
    s.addi       s12, s17, #3
    v.splat      v7, s9
    v.splat      v8, s12
    v.mov        v59, v0                         // hand off through the shared window (sec 7.3)
    m.zero       a0
    mb.arm       s9, b1, #0, #1                  // 0 arrival(s), 1 operation(s)
    m.mma.async.k16.e4m3 a0, v60, v56, s9
    mb.wait      s9
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v3]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    s.addi       s12, s17, #4
    s.addi       s14, s18, #4
    v.splat      v3, s12
    v.splat      v4, s14
    s.addi       s12, s17, #5
    s.addi       s14, s18, #5
    s.movz       s15, #4
    s.addi       s16, s18, #6
    a.vwrite     a1, s2, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v5]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v8, v1
    p.and        p4, p1, p2
    v.splat      v5, s12
    v.splat      v8, s14
    s.addi       s2, s17, #6
    s.movz       s12, #5
    s.addi       s14, s18, #7
    a.vwrite     a1, s10, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v6]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v1
    p.and        p3, p1, p2
    v.splat      v3, s2
    v.splat      v6, s16
    s.addi       s2, s17, #7
    s.movz       s10, #6
    s.addi       s16, s18, #8
    a.vwrite     a1, s3, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v7]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v1
    p.and        p4, p1, p2
    v.splat      v5, s2
    v.splat      v7, s14
    s.addi       s2, s17, #8
    s.movz       s3, #7
    s.addi       s14, s18, #9
    a.vwrite     a1, s11, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v4]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v1
    p.and        p3, p1, p2
    v.splat      v3, s2
    v.splat      v4, s16
    s.addi       s2, s17, #9
    s.movz       s11, #8
    s.addi       s16, s18, #10
    a.vwrite     a1, s15, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v8]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v1
    p.and        p4, p1, p2
    v.splat      v5, s2
    v.splat      v8, s14
    s.addi       s2, s17, #10
    s.movz       s14, #9
    s.addi       s15, s18, #11
    a.vwrite     a1, s12, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v6]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v1
    p.and        p3, p1, p2
    v.splat      v3, s2
    v.splat      v6, s16
    s.addi       s2, s17, #11
    s.movz       s12, #10
    s.addi       s16, s18, #12
    a.vwrite     a1, s10, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v7]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v1
    p.and        p4, p1, p2
    v.splat      v5, s2
    v.splat      v7, s15
    s.addi       s2, s17, #12
    s.movz       s10, #11
    s.addi       s15, s18, #13
    a.vwrite     a1, s3, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v4]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v1
    p.and        p3, p1, p2
    v.splat      v3, s2
    v.splat      v4, s16
    s.addi       s2, s17, #13
    s.movz       s3, #12
    s.addi       s16, s18, #14
    a.vwrite     a1, s11, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v8]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v1
    p.and        p4, p1, p2
    v.splat      v5, s2
    v.splat      v8, s15
    s.addi       s2, s17, #14
    s.movz       s11, #13
    s.addi       s15, s18, #15
    s.movz       s18, #14
    a.vwrite     a1, s14, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v6]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v1
    p.and        p3, p1, p2
    v.splat      v3, s2
    v.splat      v6, s16
    s.addi       s2, s17, #15
    s.muli       s14, s4, #4                     // a runtime tile origin, x4
    s.movz       s16, #15
    s.add        s19, s6, s14                    // the tile origin
    a.vwrite     a1, s12, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v7]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v1
    p.and        p4, p1, p2
    v.splat      v5, s2
    v.splat      v7, s15
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s2, #0
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s6, s4, #2                      // a runtime tile origin, x2
    // a masked 16x16 tile with contiguous rows: one predicated load a row
    s.muli       s12, s4, #2                     // a runtime tile origin, x2
    s.muli       s4, s1, #32                     // a runtime tile origin, x32
    s.add        s1, s7, s6                      // the tile origin
    s.add        s6, s8, s12                     // the tile origin
    s.add        s7, s6, s4                      // the tile origin
    a.vwrite     a1, s10, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v4]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v1
    p.and        p3, p1, p2
    v.splat      v3, s17
    s.movz       s4, #0
    v.splat      v4, s17
    a.vwrite     a1, s3, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v8]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v5, v1
    p.and        p4, p1, p2
    v.splat      v5, s17
    a.vwrite     a1, s11, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.gather.w v0, [s5, v6]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v3, v1
    p.and        p3, p1, p2
    s.addi       s3, s17, #1
    s.movz       s6, #1
    v.splat      v3, s3
    s.movz       s3, #1
    a.vwrite     a1, s18, v0
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v0, [s5, v7]               // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v1
    p.and        p4, p1, p2
    s.addi       s5, s17, #1
    v.splat      v4, s5
    a.vwrite     a1, s16, v0
    a.vread      v0, a0, s2
    a.vread      v6, a1, s4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v7, [s19, #0]
    vf.add       v8, v0, v2
    v.cmp.lt     p1, v5, v1
    p.and        p3, p1, p2
    s.addi       s2, s17, #1
    s.addi       s4, s17, #2
    v.splat      v0, s2
    v.splat      v5, s4
    s.addi       s2, s7, #32                     // row 1
    s.movz       s4, #2
    s.movz       s5, #2
    vf.mul       v9, v6, v7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s1, #0]
    v.cmp.lt     p1, v3, v1
    p.and        p4, p1, p2
    vf.mul       v3, v8, v9
    s.addi       s8, s17, #2
    v.splat      v7, s8
    vf.cvt.bf16.f32 v8, v6
    vf.add       v6, v3, v8
    vf.cvt.f32.bf16 v3, v6
    s.addi       s8, s7, #64                     // row 2
    @p3 v.st.h       [s7, #0], v3
    a.vread      v3, a0, s6
    a.vread      v6, a1, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    vf.add       v4, v3, v2
    s.addi       s3, s17, #2
    s.movz       s6, #3
    v.splat      v3, s3
    s.movz       s3, #3
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.cmp.lt     p1, v0, v1
    p.and        p4, p1, p2
    s.addi       s10, s17, #3
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s1, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p1, v5, v1
    p.and        p3, p1, p2
    v.splat      v5, s10
    vf.mul       v6, v4, v9
    s.addi       s10, s17, #3
    vf.cvt.bf16.f32 v4, v0
    v.splat      v0, s10
    vf.add       v8, v6, v4
    vf.cvt.f32.bf16 v4, v8
    s.addi       s10, s7, #96                    // row 3
    @p4 v.st.h       [s2, #0], v4
    a.vread      v4, a0, s4
    a.vread      v6, a1, s5
    v.cmp.lt     p1, v7, v1
    p.and        p4, p1, p2
    vf.add       v7, v4, v2
    s.addi       s2, s17, #3
    s.movz       s4, #4
    v.splat      v4, s2
    s.movz       s2, #4
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s19, #0]
    v.cmp.lt     p1, v3, v1
    p.and        p3, p1, p2
    s.addi       s5, s17, #4
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v3, [s1, #0]
    vf.mul       v9, v6, v8
    v.cmp.lt     p1, v5, v1
    p.and        p4, p1, p2
    v.splat      v5, s5
    vf.mul       v6, v7, v9
    s.addi       s5, s17, #4
    vf.cvt.bf16.f32 v7, v3
    v.splat      v3, s5
    vf.add       v8, v6, v7
    vf.cvt.f32.bf16 v6, v8
    s.addi       s5, s7, #128                    // row 4
    @p3 v.st.h       [s8, #0], v6
    a.vread      v6, a0, s6
    a.vread      v7, a1, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    vf.add       v0, v6, v2
    s.addi       s3, s17, #4
    s.movz       s6, #5
    v.splat      v6, s3
    s.movz       s3, #5
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.cmp.lt     p1, v4, v1
    p.and        p4, p1, p2
    s.addi       s8, s17, #5
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s1, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p1, v5, v1
    p.and        p3, p1, p2
    v.splat      v5, s8
    vf.mul       v7, v0, v9
    s.addi       s8, s17, #5
    vf.cvt.bf16.f32 v0, v4
    v.splat      v4, s8
    vf.add       v8, v7, v0
    vf.cvt.f32.bf16 v0, v8
    s.addi       s8, s7, #160                    // row 5
    @p4 v.st.h       [s10, #0], v0
    a.vread      v0, a0, s4
    a.vread      v7, a1, s2
    v.cmp.lt     p1, v3, v1
    p.and        p4, p1, p2
    vf.add       v3, v0, v2
    s.addi       s2, s17, #5
    s.movz       s4, #6
    v.splat      v0, s2
    s.movz       s2, #6
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s19, #0]
    v.cmp.lt     p1, v6, v1
    p.and        p3, p1, p2
    s.addi       s10, s17, #6
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s1, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p1, v5, v1
    p.and        p4, p1, p2
    v.splat      v5, s10
    vf.mul       v7, v3, v9
    s.addi       s10, s17, #6
    vf.cvt.bf16.f32 v3, v6
    v.splat      v6, s10
    vf.add       v8, v7, v3
    vf.cvt.f32.bf16 v3, v8
    s.addi       s10, s7, #192                   // row 6
    @p3 v.st.h       [s5, #0], v3
    a.vread      v3, a0, s6
    a.vread      v7, a1, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    vf.add       v4, v3, v2
    s.addi       s3, s17, #6
    s.movz       s5, #7
    v.splat      v3, s3
    s.movz       s3, #7
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.cmp.lt     p1, v0, v1
    p.and        p4, p1, p2
    s.addi       s6, s17, #7
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s1, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p1, v5, v1
    p.and        p3, p1, p2
    v.splat      v5, s6
    vf.mul       v7, v4, v9
    s.addi       s6, s17, #7
    vf.cvt.bf16.f32 v4, v0
    v.splat      v0, s6
    vf.add       v8, v7, v4
    vf.cvt.f32.bf16 v4, v8
    s.addi       s6, s7, #224                    // row 7
    @p4 v.st.h       [s8, #0], v4
    a.vread      v4, a0, s4
    a.vread      v7, a1, s2
    v.cmp.lt     p1, v6, v1
    p.and        p4, p1, p2
    vf.add       v6, v4, v2
    s.addi       s2, s17, #7
    s.movz       s4, #8
    v.splat      v4, s2
    s.movz       s2, #8
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s19, #0]
    v.cmp.lt     p1, v3, v1
    p.and        p3, p1, p2
    s.addi       s8, s17, #8
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v3, [s1, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p1, v5, v1
    p.and        p4, p1, p2
    v.splat      v5, s8
    vf.mul       v7, v6, v9
    s.addi       s8, s17, #8
    vf.cvt.bf16.f32 v6, v3
    v.splat      v3, s8
    vf.add       v8, v7, v6
    vf.cvt.f32.bf16 v6, v8
    s.addi       s8, s7, #256                    // row 8
    @p3 v.st.h       [s10, #0], v6
    a.vread      v6, a0, s5
    a.vread      v7, a1, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    vf.add       v0, v6, v2
    s.addi       s3, s17, #8
    s.movz       s5, #9
    v.splat      v6, s3
    s.movz       s3, #9
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.cmp.lt     p1, v4, v1
    p.and        p4, p1, p2
    s.addi       s10, s17, #9
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s1, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p1, v5, v1
    p.and        p3, p1, p2
    v.splat      v5, s10
    vf.mul       v7, v0, v9
    s.addi       s10, s17, #9
    vf.cvt.bf16.f32 v0, v4
    v.splat      v4, s10
    vf.add       v8, v7, v0
    vf.cvt.f32.bf16 v0, v8
    s.addi       s10, s7, #288                   // row 9
    @p4 v.st.h       [s6, #0], v0
    a.vread      v0, a0, s4
    a.vread      v7, a1, s2
    v.cmp.lt     p1, v3, v1
    p.and        p4, p1, p2
    vf.add       v3, v0, v2
    s.addi       s2, s17, #9
    s.movz       s4, #10
    v.splat      v0, s2
    s.movz       s2, #10
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s19, #0]
    v.cmp.lt     p1, v6, v1
    p.and        p3, p1, p2
    s.addi       s6, s17, #10
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s1, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p1, v5, v1
    p.and        p4, p1, p2
    v.splat      v5, s6
    vf.mul       v7, v3, v9
    s.addi       s6, s17, #10
    vf.cvt.bf16.f32 v3, v6
    v.splat      v6, s6
    vf.add       v8, v7, v3
    vf.cvt.f32.bf16 v3, v8
    s.addi       s6, s7, #320                    // row 10
    @p3 v.st.h       [s8, #0], v3
    a.vread      v3, a0, s5
    a.vread      v7, a1, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    vf.add       v4, v3, v2
    s.addi       s3, s17, #10
    s.movz       s5, #11
    v.splat      v3, s3
    s.movz       s3, #11
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.cmp.lt     p1, v0, v1
    p.and        p4, p1, p2
    s.addi       s8, s17, #11
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s1, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p1, v5, v1
    p.and        p3, p1, p2
    v.splat      v5, s8
    vf.mul       v7, v4, v9
    s.addi       s8, s17, #11
    vf.cvt.bf16.f32 v4, v0
    v.splat      v0, s8
    vf.add       v8, v7, v4
    vf.cvt.f32.bf16 v4, v8
    s.addi       s8, s7, #352                    // row 11
    @p4 v.st.h       [s10, #0], v4
    a.vread      v4, a0, s4
    a.vread      v7, a1, s2
    v.cmp.lt     p1, v6, v1
    p.and        p4, p1, p2
    vf.add       v6, v4, v2
    s.addi       s2, s17, #11
    s.movz       s4, #12
    v.splat      v4, s2
    s.movz       s2, #12
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s19, #0]
    v.cmp.lt     p1, v3, v1
    p.and        p3, p1, p2
    s.addi       s10, s17, #12
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v3, [s1, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p1, v5, v1
    p.and        p4, p1, p2
    v.splat      v5, s10
    vf.mul       v7, v6, v9
    s.addi       s10, s17, #12
    vf.cvt.bf16.f32 v6, v3
    v.splat      v3, s10
    vf.add       v8, v7, v6
    vf.cvt.f32.bf16 v6, v8
    s.addi       s10, s7, #384                   // row 12
    @p3 v.st.h       [s6, #0], v6
    a.vread      v6, a0, s5
    a.vread      v7, a1, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    vf.add       v0, v6, v2
    s.addi       s3, s17, #12
    s.movz       s5, #13
    v.splat      v6, s3
    s.movz       s3, #13
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.cmp.lt     p1, v4, v1
    p.and        p4, p1, p2
    s.addi       s6, s17, #13
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v4, [s1, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p1, v5, v1
    p.and        p3, p1, p2
    v.splat      v5, s6
    vf.mul       v7, v0, v9
    s.addi       s6, s17, #13
    vf.cvt.bf16.f32 v0, v4
    v.splat      v4, s6
    vf.add       v8, v7, v0
    vf.cvt.f32.bf16 v0, v8
    s.addi       s6, s7, #416                    // row 13
    @p4 v.st.h       [s8, #0], v0
    a.vread      v0, a0, s4
    a.vread      v7, a1, s2
    v.cmp.lt     p1, v3, v1
    p.and        p4, p1, p2
    vf.add       v3, v0, v2
    s.addi       s2, s17, #13
    s.movz       s4, #14
    v.splat      v0, s2
    s.movz       s2, #14
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s19, #0]
    v.cmp.lt     p1, v6, v1
    p.and        p3, p1, p2
    s.addi       s8, s17, #14
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v6, [s1, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p1, v5, v1
    p.and        p4, p1, p2
    v.splat      v5, s8
    vf.mul       v7, v3, v9
    s.addi       s8, s17, #14
    vf.cvt.bf16.f32 v3, v6
    v.splat      v6, s8
    vf.add       v8, v7, v3
    vf.cvt.f32.bf16 v3, v8
    s.addi       s8, s7, #448                    // row 14
    @p3 v.st.h       [s10, #0], v3
    a.vread      v3, a0, s5
    a.vread      v7, a1, s3
    v.cmp.lt     p1, v4, v1
    p.and        p3, p1, p2
    vf.add       v4, v3, v2
    s.addi       s3, s17, #14
    s.movz       s5, #15
    v.splat      v3, s3
    s.movz       s3, #15
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v8, [s19, #0]
    v.cmp.lt     p1, v0, v1
    p.and        p4, p1, p2
    s.addi       s10, s17, #15
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v0, [s1, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p1, v5, v1
    p.and        p3, p1, p2
    v.splat      v5, s10
    vf.mul       v7, v4, v9
    s.addi       s10, s17, #15
    vf.cvt.bf16.f32 v4, v0
    v.splat      v0, s10
    vf.add       v8, v7, v4
    vf.cvt.f32.bf16 v4, v8
    s.addi       s10, s7, #480                   // row 15
    @p4 v.st.h       [s6, #0], v4
    a.vread      v4, a0, s4
    a.vread      v7, a1, s2
    v.cmp.lt     p1, v6, v1
    p.and        p4, p1, p2
    vf.add       v6, v4, v2
    s.addi       s2, s17, #15
    v.splat      v4, s2
    v.movi       v8, #0                          // other=, materialised (sec 12)
    @p3 v.ld.w       v8, [s19, #0]
    v.cmp.lt     p1, v3, v1
    p.and        p3, p1, p2
    v.movi       v3, #0                          // other=, materialised (sec 12)
    @p4 v.ld.h       v3, [s1, #0]
    vf.mul       v9, v7, v8
    v.cmp.lt     p1, v5, v1
    p.and        p4, p1, p2
    vf.mul       v5, v6, v9
    vf.cvt.bf16.f32 v6, v3
    vf.add       v3, v5, v6
    vf.cvt.f32.bf16 v5, v3
    @p3 v.st.h       [s8, #0], v5
    a.vread      v3, a0, s5
    a.vread      v5, a1, s3
    v.cmp.lt     p1, v0, v1
    p.and        p3, p1, p2
    vf.add       v0, v3, v2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.w       v2, [s19, #0]
    v.cmp.lt     p1, v4, v1
    p.and        p4, p1, p2
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p3 v.ld.h       v1, [s1, #0]
    vf.mul       v3, v5, v2
    vf.mul       v2, v0, v3
    vf.cvt.bf16.f32 v0, v1
    vf.add       v1, v2, v0
    vf.cvt.f32.bf16 v0, v1
    @p4 v.st.h       [s10, #0], v0
__rctx_next:
    exit
