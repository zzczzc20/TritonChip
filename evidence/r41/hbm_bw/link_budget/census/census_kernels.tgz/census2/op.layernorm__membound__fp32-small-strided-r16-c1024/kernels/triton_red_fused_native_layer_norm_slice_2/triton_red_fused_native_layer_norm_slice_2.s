    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    v.splat      v0, s4
    v.movi       v1, #0
    s.rdspecial  s1, arg_base
    v.movi       v2, #3
    v.sub        v3, v1, v0
    v.cmp.lt     p1, v0, v1
    s.ld.d       s2, [s1, #8]                    // in_ptr1: device_ptr64 at arg_base+8
    @p1 v.sel        v4, v3, v0
    s.movz       s3, #1
    v.movi       v0, #8
    v.lshr       v3, v4, v2
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s3
    v.sub        v5, v1, v3
    v.sub        v6, v1, v0
    v.movi       v7, #0
    @p1 v.sel        v8, v5, v3
    v.movi       v3, #0
    s.movz       s3, #0
    v.cmp.lt     p1, v0, v1
    v.cmp.lt     p2, v2, v4
    s.ld.d       s5, [s1, #0]                    // in_ptr0: device_ptr64 at arg_base+0
    s.movz       s6, #128
    s.movz       s7, #16
    v.iota       v1                              // arange(0, VLEN)
    v.movi       v2, #1
    @p1 v.sel        v2, v6, v0
    s.addi       s8, s3, #0
    s.ld.d       s3, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    v.movi       v0, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v0, [s2, v8]               // index is in elements (ISA sec 9.1)
    v.mov        v3, v7
for_1:
    s.cmp.ge     s1, s8, s6
    br.nz        s1, endfor_2
    s.movz       s1, #256
    v.splat      v2, s8
    s.mul        s2, s4, s1
    v.movi       v4, #2
    v.add        v5, v2, v1
    v.movi       v2, #128
    v.extract    s1, v0, #0
    v.mul        v6, v5, v4
    v.splat      v4, s2
    v.cmp.lt     p1, v5, v2
    v.splat      v2, s1
    v.add        v5, v6, v4
    v.movi       v4, #0
    s.add        s1, s8, s7
    v.movi       v6, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v6, [s5, v5]               // index is in elements (ISA sec 9.1)
    s.movz       s2, #1
    s.movz       s9, #2
    vf.sub       v5, v6, v2
    vf.mul       v2, v5, v5
    vf.add       v5, v3, v2
    @p1 v.sel        v2, v5, v3
    v.mov        v4, v2
    v.mov        v3, v4
    s.mov        s8, s1
    br.nz        s2, for_1
endfor_2:
    vf.reduce.add.b v0, v3
    v.movi       v1, #0
    s.movz       s1, #1
    s.shli       s2, s4, #2                      // element offset -> bytes (x4)
    vf.add       v2, v0, v1
    v.iota       v0                              // arange(0, VLEN)
    v.splat      v1, s1
    s.add        s1, s3, s2                      // &out_ptr0[...]
    v.cmp.lt     p1, v0, v1
    @p1 v.st.w       [s1, #0], v2
__rctx_next:
    exit
