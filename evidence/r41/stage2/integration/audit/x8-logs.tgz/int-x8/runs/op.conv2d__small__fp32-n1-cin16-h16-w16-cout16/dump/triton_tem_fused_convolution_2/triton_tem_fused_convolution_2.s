    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.movz       s1, #16
    v.iota       v0                              // arange(0, VLEN)
    s.mul        s2, s4, s1
    s.rdspecial  s3, pid.y
    s.rdspecial  s4, role_id
    s.mul        s5, s3, s1
    s.movz       s3, #4160
    v.splat      v1, s2
    s.rdspecial  s2, arg_base
    v.add        v2, v1, v0
    s.mul        s6, s4, s3
    v.movi       v1, #0
    s.ld.d       s3, [s2, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    v.sub        v3, v1, v2
    v.cmp.lt     p1, v2, v1
    s.add        s2, s3, s6                      // this context's own scratch
    s.movz       s3, #0
    @p1 v.sel        v4, v3, v2
    s.addi       s4, s2, #0
    v.movi       v3, #16
    s.rdspecial  s6, arg_base
    v.movi       v5, #15
    s.addi       s7, s4, #64
    s.addi       s8, s4, #128
    s.addi       s9, s4, #192
    s.addi       s10, s4, #256
    s.addi       s11, s4, #320
    s.addi       s12, s4, #384
    s.addi       s13, s4, #448
    s.addi       s14, s4, #512
    s.addi       s15, s4, #576
    s.addi       s16, s4, #640
    s.addi       s17, s4, #704
    s.addi       s18, s4, #768
    s.addi       s19, s4, #832
    s.addi       s20, s4, #896
    s.addi       s21, s4, #960
    s.addi       s22, s2, #1024
    v.sub        v6, v1, v3
    v.cmp.lt     p2, v3, v1
    s.ld.d       s23, [s6, #0]                   // arg_X: device_ptr64 at arg_base+0
    v.and        v7, v4, v5
    s.movz       s24, #4096
    s.ld.d       s24, [s6, #8]                   // arg_W: device_ptr64 at arg_base+8
    v.sub        v4, v1, v7
    s.movz       s25, #144
    s.ld.d       s25, [s6, #16]                  // out_ptr0: device_ptr64 at arg_base+16
    v.movi       v1, #0
    v.movi       v5, #4
    v.sub        v8, v1, v2
    v.cmp.lt     p3, v2, v1
    @p3 v.sel        v9, v8, v2
    v.movi       v2, #0
    v.lshr       v8, v9, v5
    v.movi       v5, #0
    v.sub        v9, v1, v8
    v.movi       v10, #15
    @p3 v.sel        v11, v9, v8
    v.sub        v8, v1, v3
    v.sub        v9, v2, v11
    v.cmp.lt     p3, v11, v2
    v.sub        v12, v5, v11
    s.movz       s6, #9
    @p3 v.sel        v13, v9, v11
    s.movz       s26, #1
    v.movi       v9, #1
    @p2 v.sel        v9, v6, v3
    v.movi       v6, #4
    v.cmp.lt     p2, v11, v5
    v.lshr       v9, v13, v6
    v.movi       v6, #4096
    @p2 v.sel        v13, v12, v11
    v.sub        v11, v2, v9
    v.and        v12, v13, v10
    @p3 v.sel        v10, v11, v9
    v.splat      v9, s5
    v.mul        v11, v10, v6
    v.add        v6, v9, v0
    v.extract    s27, v11, #0
    v.extract    s28, v11, #1
    v.splat      v9, s3
    v.cmp.lt     p3, v3, v1
    v.splat      v1, s27
    @p1 v.sel        v13, v4, v7
    v.splat      v4, s28
    v.add        v7, v9, v1
    v.add        v1, v9, v4
    v.cmp.lt     p1, v3, v5
    v.movi       v4, #1
    v.extract    s27, v11, #2
    v.extract    s28, v11, #3
    @p3 v.sel        v4, v8, v3
    v.extract    s29, v11, #4
    v.splat      v4, s27
    v.cmp.lt     p3, v3, v2
    v.sub        v8, v2, v3
    v.add        v2, v9, v4
    v.movi       v4, #1
    v.extract    s27, v11, #5
    v.extract    s30, v11, #6
    v.movi       v4, #1
    @p3 v.sel        v4, v8, v3
    v.splat      v4, s28
    v.st.w       [s4, #0], v7
    v.splat      v7, s29
    v.add        v8, v9, v4
    v.add        v4, v9, v7
    v.st.w       [s7, #0], v1
    v.splat      v1, s27
    v.add        v7, v9, v1
    v.st.w       [s8, #0], v2
    v.sub        v1, v5, v3
    v.sub        v2, v5, v12
    @p1 v.sel        v5, v1, v3
    v.extract    s4, v11, #7
    v.splat      v1, s30
    @p2 v.sel        v5, v2, v12
    v.extract    s7, v11, #8
    v.extract    s8, v11, #9
    v.extract    s27, v11, #10
    v.extract    s28, v11, #11
    v.extract    s29, v11, #12
    v.extract    s30, v11, #13
    v.extract    s31, v11, #14
    v.splat      v2, s4
    v.extract    s4, v11, #15
    v.splat      v11, s7
    v.add        v12, v9, v1
    v.add        v1, v9, v2
    v.add        v2, v9, v11
    v.st.w       [s9, #0], v8
    v.movi       v8, #144
    v.mul        v11, v6, v8
    v.st.w       [s10, #0], v4
    v.splat      v4, s8
    v.add        v8, v9, v4
    v.st.w       [s11, #0], v7
    v.splat      v4, s27
    s.addi       s7, s3, #0
    v.add        v7, v9, v4
    v.st.w       [s12, #0], v12
    v.splat      v4, s28
    v.add        v12, v9, v4
    v.st.w       [s13, #0], v1
    v.splat      v1, s29
    v.add        v4, v9, v1
    v.st.w       [s14, #0], v2
    v.splat      v1, s30
    v.add        v2, v9, v1
    v.st.w       [s15, #0], v8
    v.splat      v1, s31
    v.add        v8, v9, v1
    v.st.w       [s16, #0], v7
    v.splat      v1, s4
    v.add        v7, v9, v1
    v.splat      v1, s3
    v.add        v9, v1, v11
    v.st.w       [s17, #0], v12
    v.st.w       [s18, #0], v4
    v.st.w       [s19, #0], v2
    v.st.w       [s20, #0], v8
    v.st.w       [s21, #0], v7
    fence.acq_rel.device
    v.st.w       [s22, #0], v9
    fence.acq_rel.device
    // a zero tile carried round the loop: one m.zero (ISA sec 9C)
    m.zero       a0
for_1:
    s.cmp.ge     s4, s7, s6
    br.nz        s4, endfor_2
    s.movz       s4, #0
    s.movz       s8, #0
    s.cmp.lt     s9, s7, s4
    s.movz       s4, #0
    s.sub        s10, s8, s9
    .li       s8, #1431655766
    s.xor        s9, s7, s10
    s.movz       s11, #0
    s.sub        s12, s9, s10
    s.cmp.lt     s9, s7, s4
    s.mul        s4, s12, s8
    s.sub        s8, s11, s9
    .li       s9, #1431655766
    s.xor        s11, s7, s8
    s.movz       s13, #3
    s.sub        s14, s11, s8
    s.lshri      s11, s4, #32
    s.mul        s4, s14, s9
    s.sub        s9, s12, s11
    s.movz       s15, #0
    s.lshri      s16, s9, #1
    s.movz       s9, #0
    s.add        s17, s11, s16
    s.lshri      s11, s4, #32
    s.lshri      s4, s17, #1
    s.sub        s16, s14, s11
    s.muli       s17, s4, #3
    s.cmp.lt     s4, s13, s15
    s.lshri      s15, s16, #1
    s.sub        s16, s9, s4
    s.add        s4, s11, s15
    s.xor        s9, s8, s16
    s.lshri      s8, s4, #1
    s.sub        s4, s12, s17
    s.xor        s11, s8, s9
    s.xor        s12, s4, s10
    s.sub        s4, s11, s9
    s.sub        s9, s12, s10
    s.sub        s10, s4, s26
    s.sub        s11, s9, s26
    v.splat      v1, s10
    v.splat      v2, s11
    v.add        v4, v1, v5
    v.add        v1, v2, v13
    v.movi       v2, #256
    v.mul        v7, v1, v3
    v.mul        v8, v4, v2
    s.addi       s10, s2, #1088
    s.movz       s11, #0
    s.movz       s12, #0
    s.cmp.lt     s15, s13, s11
    s.muli       s11, s8, #3
    s.sub        s8, s12, s15
    s.xor        s12, s13, s16
    s.addi       s15, s2, #0
    s.sub        s17, s12, s16
    v.ld.w       v2, [s15, #0]
    v.extract    s12, v8, #0
    v.extract    s15, v7, #0
    v.splat      v9, s12
    v.splat      v11, s15
    v.iota       v12                             // arange(0, VLEN)
    v.add        v14, v9, v11
    s.xor        s12, s13, s8
    v.add        v9, v14, v12
    s.sub        s15, s14, s11
    v.add        v11, v2, v9
    s.addi       s11, s2, #64
    v.st.w       [s10, #0], v11
    v.extract    s14, v8, #1
    v.extract    s15, v7, #1
    v.splat      v2, s14
    v.splat      v9, s15
    s.addi       s14, s10, #64
    v.add        v11, v2, v9
    s.addi       s15, s2, #128
    v.add        v2, v11, v12
    s.addi       s16, s10, #128
    v.ld.w       v9, [s11, #0]
    s.sub        s11, s12, s8
    v.extract    s8, v8, #2
    v.extract    s11, v7, #2
    v.splat      v11, s8
    v.splat      v14, s11
    s.addi       s8, s2, #192
    v.add        v15, v11, v14
    v.extract    s11, v8, #3
    v.add        v11, v15, v12
    v.add        v14, v9, v2
    v.extract    s12, v7, #3
    v.st.w       [s14, #0], v14
    v.splat      v2, s11
    v.splat      v9, s12
    s.addi       s11, s10, #192
    v.add        v14, v2, v9
    s.movz       s12, #256
    v.add        v2, v14, v12
    s.addi       s12, s2, #256
    v.extract    s14, v8, #4
    v.splat      v9, s14
    v.ld.w       v14, [s15, #0]
    v.extract    s14, v7, #4
    v.splat      v15, s14
    s.addi       s14, s10, #256
    v.add        v16, v9, v15
    s.addi       s15, s2, #320
    v.add        v9, v16, v12
    v.add        v15, v14, v11
    v.st.w       [s16, #0], v15
    v.extract    s16, v8, #5
    v.splat      v11, s16
    v.extract    s16, v7, #5
    v.splat      v14, s16
    s.addi       s16, s10, #320
    v.add        v15, v11, v14
    v.add        v11, v15, v12
    v.ld.w       v14, [s8, #0]
    s.addi       s8, s2, #384
    v.add        v15, v14, v2
    v.st.w       [s11, #0], v15
    v.extract    s11, v8, #6
    v.splat      v2, s11
    v.extract    s11, v7, #6
    v.splat      v14, s11
    s.addi       s11, s10, #384
    v.add        v15, v2, v14
    v.add        v2, v15, v12
    v.ld.w       v14, [s12, #0]
    s.addi       s12, s2, #448
    v.add        v15, v14, v9
    v.st.w       [s14, #0], v15
    v.extract    s14, v8, #7
    v.splat      v9, s14
    v.extract    s14, v7, #7
    v.splat      v14, s14
    s.addi       s14, s10, #448
    v.add        v15, v9, v14
    v.add        v9, v15, v12
    v.ld.w       v14, [s15, #0]
    s.addi       s15, s2, #512
    v.add        v15, v14, v11
    v.st.w       [s16, #0], v15
    v.extract    s16, v8, #8
    v.splat      v11, s16
    v.extract    s16, v7, #8
    v.splat      v14, s16
    s.addi       s16, s10, #512
    v.add        v15, v11, v14
    v.add        v11, v15, v12
    v.ld.w       v14, [s8, #0]
    s.addi       s8, s2, #576
    v.add        v15, v14, v2
    v.st.w       [s11, #0], v15
    v.extract    s11, v8, #9
    v.splat      v2, s11
    v.extract    s11, v7, #9
    v.splat      v14, s11
    s.addi       s11, s10, #576
    v.add        v15, v2, v14
    v.add        v2, v15, v12
    v.ld.w       v14, [s12, #0]
    s.addi       s12, s2, #640
    v.add        v15, v14, v9
    v.st.w       [s14, #0], v15
    v.extract    s14, v8, #10
    v.splat      v9, s14
    v.extract    s14, v7, #10
    v.splat      v14, s14
    s.addi       s14, s10, #640
    v.add        v15, v9, v14
    v.add        v9, v15, v12
    v.ld.w       v14, [s15, #0]
    s.addi       s15, s2, #704
    v.add        v15, v14, v11
    v.st.w       [s16, #0], v15
    v.extract    s16, v8, #11
    v.splat      v11, s16
    v.extract    s16, v7, #11
    v.splat      v14, s16
    s.addi       s16, s10, #704
    v.add        v15, v11, v14
    v.add        v11, v15, v12
    v.ld.w       v14, [s8, #0]
    s.addi       s8, s2, #768
    v.add        v15, v14, v2
    v.st.w       [s11, #0], v15
    v.extract    s11, v8, #12
    v.splat      v2, s11
    v.extract    s11, v7, #12
    v.splat      v14, s11
    s.addi       s11, s10, #768
    v.add        v15, v2, v14
    v.add        v2, v15, v12
    v.ld.w       v14, [s12, #0]
    s.addi       s12, s2, #832
    v.add        v15, v14, v9
    v.st.w       [s14, #0], v15
    v.extract    s14, v8, #13
    v.splat      v9, s14
    v.extract    s14, v7, #13
    v.splat      v14, s14
    s.addi       s14, s10, #832
    v.add        v15, v9, v14
    v.add        v9, v15, v12
    v.ld.w       v14, [s15, #0]
    s.addi       s15, s2, #896
    v.movi       v15, #1
    v.add        v16, v14, v11
    v.cmp.lt     p1, v10, v15
    v.st.w       [s16, #0], v16
    v.extract    s16, v8, #14
    v.splat      v11, s16
    v.extract    s16, v7, #14
    v.splat      v14, s16
    s.addi       s16, s10, #896
    v.add        v15, v11, v14
    v.movi       v11, #1
    v.add        v14, v15, v12
    v.movi       v15, #0
    v.ld.w       v16, [s8, #0]
    s.addi       s8, s2, #960
    v.movi       v17, #0
    @p1 v.sel        v18, v11, v15
    v.movi       v11, #1
    v.cmp.ge     p1, v4, v17
    v.cmp.lt     p2, v4, v3
    v.movi       v4, #0
    s.addi       s17, s10, #960
    @p1 v.sel        v15, v11, v4
    v.add        v4, v16, v2
    v.movi       v2, #1
    v.st.w       [s11, #0], v4
    v.extract    s10, v8, #15
    v.splat      v4, s10
    v.extract    s10, v7, #15
    v.splat      v7, s10
    v.movi       v8, #0
    v.add        v11, v4, v7
    @p2 v.sel        v4, v2, v8
    v.add        v2, v11, v12
    v.movi       v7, #1
    v.ld.w       v8, [s12, #0]
    v.movi       v11, #0
    v.cmp.ge     p1, v1, v17
    @p1 v.sel        v16, v7, v11
    v.movi       v7, #1
    v.movi       v11, #0
    v.cmp.lt     p1, v1, v3
    @p1 v.sel        v1, v7, v11
    v.cmp.lt     p1, v0, v3
    v.add        v7, v8, v9
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s10, #0
    v.st.w       [s14, #0], v7
    v.extract    s11, v18, #0
    s.addi       s12, s2, #1088
    v.ld.w       v7, [s15, #0]
    v.extract    s14, v15, #0
    v.splat      v8, s11
    v.movi       v9, #0
    v.splat      v11, s14
    v.movi       v17, #0
    v.cmp.ne     p2, v8, v9
    v.cmp.ne     p3, v11, v17
    v.add        v8, v7, v14
    p.and        p4, p2, p3
    v.st.w       [s16, #0], v8
    v.extract    s11, v4, #0
    v.splat      v7, s11
    v.movi       v8, #0
    v.ld.w       v9, [s8, #0]
    v.extract    s8, v16, #0
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s8
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v7, v8
    p.and        p4, p3, p2
    v.add        v7, v9, v2
    v.extract    s8, v1, #0
    v.st.w       [s17, #0], v7
    fence.acq_rel.device
    v.splat      v2, s8
    v.movi       v7, #0
    v.extract    s8, v18, #1
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    v.extract    s11, v15, #1
    p.and        p2, p3, p1
    v.splat      v2, s8
    v.ld.w       v7, [s12, #0]
    v.movi       v8, #0
    v.splat      v9, s11
    v.movi       v11, #0
    s.addi       s8, s2, #1152
    v.extract    s11, v4, #1
    v.cmp.ne     p3, v2, v8
    v.cmp.ne     p4, v9, v11
    v.splat      v2, s11
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s23, v7]              // index is in elements (ISA sec 9.1)
    p.and        p2, p3, p4
    v.extract    s11, v16, #1
    v.cmp.ne     p3, v2, v8
    v.splat      v2, s11
    v.movi       v7, #0
    p.and        p4, p2, p3
    v.extract    s11, v1, #1
    v.cmp.ne     p2, v2, v7
    v.splat      v2, s11
    a.vwrite     a1, s10, v9
    v.ld.w       v7, [s8, #0]
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.cmp.ne     p2, v2, v8
    p.and        p4, p3, p2
    v.extract    s8, v18, #2
    p.and        p2, p4, p1
    v.extract    s10, v15, #2
    v.splat      v2, s8
    v.movi       v8, #0
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s23, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s10
    v.movi       v11, #0
    s.movz       s8, #1
    s.addi       s10, s2, #1216
    v.extract    s11, v4, #2
    v.cmp.ne     p2, v2, v8
    v.cmp.ne     p3, v7, v11
    v.splat      v2, s11
    v.movi       v7, #0
    a.vwrite     a1, s8, v9
    v.ld.w       v8, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s8, v16, #2
    v.cmp.ne     p2, v2, v7
    v.splat      v2, s8
    v.movi       v7, #0
    p.and        p3, p4, p2
    v.extract    s8, v1, #2
    v.cmp.ne     p2, v2, v7
    v.splat      v2, s8
    v.movi       v7, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v7
    p.and        p3, p4, p2
    v.extract    s8, v18, #3
    p.and        p2, p3, p1
    v.extract    s10, v15, #3
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s23, v8]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s8
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s8, #2
    s.addi       s10, s2, #1280
    v.extract    s11, v4, #3
    v.cmp.ne     p2, v7, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v7, s11
    v.movi       v8, #0
    a.vwrite     a1, s8, v2
    v.ld.w       v2, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s8, v16, #3
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s8
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s8, v1, #3
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s8
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    v.extract    s8, v18, #4
    p.and        p2, p3, p1
    v.extract    s10, v15, #4
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s8
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s8, #3
    s.addi       s10, s2, #1344
    v.extract    s11, v4, #4
    v.cmp.ne     p2, v2, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v2, s11
    v.movi       v8, #0
    a.vwrite     a1, s8, v7
    v.ld.w       v7, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s8, v16, #4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s8
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s8, v1, #4
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s8
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v8
    p.and        p3, p4, p2
    v.extract    s8, v18, #5
    p.and        p2, p3, p1
    v.extract    s10, v15, #5
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s23, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s8
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s8, #4
    s.addi       s10, s2, #1408
    v.extract    s11, v4, #5
    v.cmp.ne     p2, v7, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v7, s11
    v.movi       v8, #0
    a.vwrite     a1, s8, v2
    v.ld.w       v2, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s8, v16, #5
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s8
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s8, v1, #5
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s8
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    v.extract    s8, v18, #6
    p.and        p2, p3, p1
    v.extract    s10, v15, #6
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s8
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s8, #5
    s.addi       s10, s2, #1472
    v.extract    s11, v4, #6
    v.cmp.ne     p2, v2, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v2, s11
    v.movi       v8, #0
    a.vwrite     a1, s8, v7
    v.ld.w       v7, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s8, v16, #6
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s8
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s8, v1, #6
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s8
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v8
    p.and        p3, p4, p2
    v.extract    s8, v18, #7
    p.and        p2, p3, p1
    v.extract    s10, v15, #7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s23, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s8
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s8, #6
    s.addi       s10, s2, #1536
    v.extract    s11, v4, #7
    v.cmp.ne     p2, v7, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v7, s11
    v.movi       v8, #0
    a.vwrite     a1, s8, v2
    v.ld.w       v2, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s8, v16, #7
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s8
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s8, v1, #7
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s8
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    v.extract    s8, v18, #8
    p.and        p2, p3, p1
    v.extract    s10, v15, #8
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s8
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s8, #7
    s.addi       s10, s2, #1600
    v.extract    s11, v4, #8
    v.cmp.ne     p2, v2, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v2, s11
    v.movi       v8, #0
    a.vwrite     a1, s8, v7
    v.ld.w       v7, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s8, v16, #8
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s8
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s8, v1, #8
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s8
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v8
    p.and        p3, p4, p2
    v.extract    s8, v18, #9
    p.and        p2, p3, p1
    v.extract    s10, v15, #9
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s23, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s8
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s8, #8
    s.addi       s10, s2, #1664
    v.extract    s11, v4, #9
    v.cmp.ne     p2, v7, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v7, s11
    v.movi       v8, #0
    a.vwrite     a1, s8, v2
    v.ld.w       v2, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s8, v16, #9
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s8
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s8, v1, #9
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s8
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    v.extract    s8, v18, #10
    p.and        p2, p3, p1
    v.extract    s10, v15, #10
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s8
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s8, #9
    s.addi       s10, s2, #1728
    v.extract    s11, v4, #10
    v.cmp.ne     p2, v2, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v2, s11
    v.movi       v8, #0
    a.vwrite     a1, s8, v7
    v.ld.w       v7, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s8, v16, #10
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s8
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s8, v1, #10
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s8
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v8
    p.and        p3, p4, p2
    v.extract    s8, v18, #11
    p.and        p2, p3, p1
    v.extract    s10, v15, #11
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s23, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s8
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s8, #10
    s.addi       s10, s2, #1792
    v.extract    s11, v4, #11
    v.cmp.ne     p2, v7, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v7, s11
    v.movi       v8, #0
    a.vwrite     a1, s8, v2
    v.ld.w       v2, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s8, v16, #11
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s8
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s8, v1, #11
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s8
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    v.extract    s8, v18, #12
    p.and        p2, p3, p1
    v.extract    s10, v15, #12
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s8
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s8, #11
    s.addi       s10, s2, #1856
    v.extract    s11, v4, #12
    v.cmp.ne     p2, v2, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v2, s11
    v.movi       v8, #0
    a.vwrite     a1, s8, v7
    v.ld.w       v7, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s8, v16, #12
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s8
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s8, v1, #12
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s8
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v8
    p.and        p3, p4, p2
    v.extract    s8, v18, #13
    p.and        p2, p3, p1
    v.extract    s10, v15, #13
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s23, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s8
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s8, #12
    s.addi       s10, s2, #1920
    v.extract    s11, v4, #13
    v.cmp.ne     p2, v7, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v7, s11
    v.movi       v8, #0
    a.vwrite     a1, s8, v2
    v.ld.w       v2, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s8, v16, #13
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s8
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s8, v1, #13
    v.cmp.ne     p2, v7, v8
    v.splat      v7, s8
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v7, v8
    p.and        p3, p4, p2
    v.extract    s8, v18, #14
    p.and        p2, p3, p1
    v.extract    s10, v15, #14
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v7, [s23, v2]              // index is in elements (ISA sec 9.1)
    v.splat      v2, s8
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s8, #13
    s.addi       s10, s2, #1984
    v.extract    s11, v4, #14
    v.cmp.ne     p2, v2, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v2, s11
    v.movi       v8, #0
    a.vwrite     a1, s8, v7
    v.ld.w       v7, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s8, v16, #14
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s8
    v.movi       v8, #0
    p.and        p3, p4, p2
    v.extract    s8, v1, #14
    v.cmp.ne     p2, v2, v8
    v.splat      v2, s8
    v.movi       v8, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v2, v8
    p.and        p3, p4, p2
    v.extract    s8, v18, #15
    p.and        p2, p3, p1
    v.extract    s10, v15, #15
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s23, v7]              // index is in elements (ISA sec 9.1)
    v.splat      v7, s8
    v.movi       v8, #0
    v.splat      v9, s10
    v.movi       v11, #0
    s.movz       s8, #14
    s.addi       s10, s2, #2048
    v.extract    s11, v4, #15
    v.cmp.ne     p2, v7, v8
    v.cmp.ne     p3, v9, v11
    v.splat      v4, s11
    v.movi       v7, #0
    a.vwrite     a1, s8, v2
    v.ld.w       v2, [s10, #0]
    p.and        p4, p2, p3
    v.extract    s8, v16, #15
    v.cmp.ne     p2, v4, v7
    v.splat      v4, s8
    v.movi       v7, #0
    p.and        p3, p4, p2
    v.extract    s8, v1, #15
    v.cmp.ne     p2, v4, v7
    v.splat      v1, s8
    v.movi       v4, #0
    p.and        p4, p3, p2
    v.cmp.ne     p2, v1, v4
    p.and        p3, p4, p2
    s.movz       s8, #48
    p.and        p2, p3, p1
    s.movz       s10, #15
    v.movi       v1, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v1, [s23, v2]              // index is in elements (ISA sec 9.1)
    s.addi       s11, s2, #1024
    s.mul        s12, s4, s8
    s.mul        s4, s9, s1
    s.movz       s8, #0
    s.addi       s9, s2, #2112
    s.addi       s14, s2, #1024
    s.add        s15, s8, s12                    // the tile origin
    s.addi       s8, s9, #64
    s.add        s12, s15, s4                    // the tile origin
    a.vwrite     a1, s10, v1
    v.ld.w       v1, [s11, #0]
    v.splat      v2, s12
    s.addi       s4, s12, #1
    s.addi       s10, s2, #1024
    v.splat      v4, s4
    s.addi       s4, s12, #2
    s.addi       s11, s9, #128
    v.splat      v7, s4
    s.addi       s4, s2, #1024
    s.addi       s15, s12, #3
    v.add        v8, v1, v2
    v.splat      v1, s15
    v.st.w       [s9, #0], v8
    s.addi       s15, s9, #192
    s.addi       s16, s2, #1024
    s.addi       s17, s12, #4
    v.splat      v2, s17
    s.addi       s17, s9, #256
    v.ld.w       v8, [s14, #0]
    s.addi       s14, s2, #1024
    v.add        v9, v8, v4
    v.st.w       [s8, #0], v9
    s.addi       s8, s12, #5
    v.splat      v4, s8
    s.addi       s8, s9, #320
    v.ld.w       v8, [s10, #0]
    s.addi       s10, s2, #1024
    v.add        v9, v8, v7
    v.st.w       [s11, #0], v9
    s.addi       s11, s12, #6
    v.splat      v7, s11
    s.addi       s11, s9, #384
    v.ld.w       v8, [s4, #0]
    s.addi       s4, s2, #1024
    v.add        v9, v8, v1
    v.st.w       [s15, #0], v9
    s.addi       s15, s12, #7
    v.splat      v1, s15
    s.addi       s15, s9, #448
    v.ld.w       v8, [s16, #0]
    s.addi       s16, s2, #1024
    v.add        v9, v8, v2
    v.st.w       [s17, #0], v9
    s.addi       s17, s12, #8
    v.splat      v2, s17
    s.addi       s17, s9, #512
    v.ld.w       v8, [s14, #0]
    s.addi       s14, s2, #1024
    v.add        v9, v8, v4
    v.st.w       [s8, #0], v9
    s.addi       s8, s12, #9
    v.splat      v4, s8
    s.addi       s8, s9, #576
    v.ld.w       v8, [s10, #0]
    s.addi       s10, s2, #1024
    v.add        v9, v8, v7
    v.st.w       [s11, #0], v9
    s.addi       s11, s12, #10
    v.splat      v7, s11
    s.addi       s11, s9, #640
    v.ld.w       v8, [s4, #0]
    s.addi       s4, s2, #1024
    v.add        v9, v8, v1
    v.st.w       [s15, #0], v9
    s.addi       s15, s12, #11
    v.splat      v1, s15
    s.addi       s15, s9, #704
    v.ld.w       v8, [s16, #0]
    s.addi       s16, s2, #1024
    v.add        v9, v8, v2
    v.st.w       [s17, #0], v9
    s.addi       s17, s12, #12
    v.splat      v2, s17
    s.addi       s17, s9, #768
    v.ld.w       v8, [s14, #0]
    s.addi       s14, s2, #1024
    v.add        v9, v8, v4
    v.splat      v4, s3
    v.st.w       [s8, #0], v9
    s.addi       s8, s12, #13
    v.splat      v8, s1
    v.splat      v9, s8
    s.addi       s8, s9, #832
    v.cmp.lt     p1, v4, v8
    v.ld.w       v4, [s10, #0]
    s.addi       s10, s2, #1024
    v.add        v11, v4, v7
    v.splat      v4, s1
    v.st.w       [s11, #0], v11
    s.addi       s11, s12, #14
    s.addi       s18, s12, #15
    v.splat      v7, s11
    s.addi       s11, s9, #896
    v.splat      v11, s18
    s.addi       s12, s2, #1024
    s.addi       s18, s9, #960
    v.ld.w       v14, [s4, #0]
    s.addi       s4, s2, #2112
    v.add        v15, v14, v1
    v.st.w       [s15, #0], v15
    s.movz       s9, #0
    v.splat      v1, s26
    s.add        s15, s9, s5                     // the tile origin
    v.cmp.lt     p2, v1, v8
    v.splat      v1, s15
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s9, #0
    v.add        v14, v12, v1
    v.cmp.lt     p3, v14, v4
    v.ld.w       v1, [s16, #0]
    p.and        p4, p1, p3
    s.addi       s15, s2, #2176
    p.and        p1, p2, p3
    v.add        v4, v1, v2
    v.st.w       [s17, #0], v4
    s.movz       s16, #1
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s2, #2240
    v.add        v2, v1, v9
    v.st.w       [s8, #0], v2
    s.movz       s8, #2
    v.splat      v1, s8
    s.movz       s8, #2
    v.cmp.lt     p2, v1, v8
    p.and        p5, p2, p3
    v.ld.w       v1, [s10, #0]
    s.addi       s10, s2, #2304
    v.splat      v2, s13
    s.movz       s13, #3
    v.add        v4, v1, v7
    v.st.w       [s11, #0], v4
    s.addi       s11, s2, #2368
    v.ld.w       v1, [s12, #0]
    s.movz       s12, #4
    v.splat      v4, s12
    s.movz       s12, #4
    v.add        v7, v1, v11
    v.st.w       [s18, #0], v7
    fence.acq_rel.device
    s.movz       s17, #5
    v.ld.w       v1, [s4, #0]
    s.addi       s4, s2, #2432
    v.movi       v7, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v7, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p2, v2, v8
    p.and        p4, p2, p3
    a.vwrite     a2, s9, v7
    v.ld.w       v1, [s15, #0]
    s.movz       s9, #5
    s.addi       s15, s2, #2496
    v.splat      v2, s9
    s.movz       s9, #6
    v.splat      v7, s9
    s.movz       s9, #6
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p1 v.ld.gather.w v9, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v8
    p.and        p2, p1, p3
    a.vwrite     a2, s16, v9
    v.ld.w       v1, [s14, #0]
    s.addi       s14, s2, #2560
    s.movz       s16, #7
    v.splat      v4, s16
    s.movz       s16, #7
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v9, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v8
    p.and        p5, p1, p3
    a.vwrite     a2, s8, v9
    v.ld.w       v1, [s10, #0]
    s.addi       s8, s2, #2624
    s.movz       s10, #8
    v.splat      v2, s10
    s.movz       s10, #8
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v9, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v8
    p.and        p4, p1, p3
    a.vwrite     a2, s13, v9
    v.ld.w       v1, [s11, #0]
    s.addi       s11, s2, #2688
    v.splat      v7, s6
    s.movz       s13, #9
    s.addi       s18, s2, #2752
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v8
    p.and        p2, p1, p3
    a.vwrite     a2, s12, v9
    v.ld.w       v1, [s4, #0]
    s.movz       s4, #10
    s.movz       s12, #10
    v.splat      v4, s4
    s.addi       s4, s2, #2816
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v9, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v8
    p.and        p5, p1, p3
    a.vwrite     a2, s17, v9
    v.ld.w       v1, [s15, #0]
    s.movz       s15, #11
    s.movz       s17, #11
    v.splat      v2, s15
    s.addi       s15, s2, #2880
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v9, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v8
    p.and        p4, p1, p3
    a.vwrite     a2, s9, v9
    v.ld.w       v1, [s14, #0]
    s.movz       s9, #12
    s.movz       s14, #12
    v.splat      v7, s9
    s.addi       s9, s2, #2944
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v9, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v8
    p.and        p2, p1, p3
    a.vwrite     a2, s16, v9
    v.ld.w       v1, [s8, #0]
    s.movz       s8, #13
    s.movz       s16, #13
    v.splat      v4, s8
    s.addi       s8, s2, #3008
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v9, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v8
    p.and        p5, p1, p3
    a.vwrite     a2, s10, v9
    v.ld.w       v1, [s11, #0]
    s.movz       s10, #14
    s.movz       s11, #14
    v.splat      v2, s10
    s.movz       s10, #15
    v.movi       v9, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v9, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v7, v8
    p.and        p4, p1, p3
    a.vwrite     a2, s13, v9
    v.ld.w       v1, [s18, #0]
    s.addi       s13, s2, #3072
    s.movz       s18, #15
    v.movi       v7, #0
    v.splat      v9, s18
    v.movi       v11, #0                         // other=, materialised (sec 12)
    @p2 v.ld.gather.w v11, [s24, v1]             // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v4, v8
    p.and        p2, p1, p3
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s18, #0
    a.vwrite     a2, s12, v11
    v.ld.w       v1, [s4, #0]
    s.movz       s4, #0
    s.movz       s12, #0
    v.movi       v4, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v4, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v2, v8
    p.and        p5, p1, p3
    a.vwrite     a2, s17, v4
    v.ld.w       v1, [s15, #0]
    s.movz       s15, #1
    s.movz       s17, #2
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s24, v1]              // index is in elements (ISA sec 9.1)
    v.cmp.lt     p1, v9, v8
    p.and        p4, p1, p3
    a.vwrite     a2, s14, v2
    v.ld.w       v1, [s9, #0]
    s.movz       s9, #3
    s.movz       s14, #4
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p2 v.ld.gather.w v2, [s24, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s16, v2
    v.ld.w       v1, [s8, #0]
    s.movz       s8, #5
    s.movz       s16, #6
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p5 v.ld.gather.w v2, [s24, v1]              // index is in elements (ISA sec 9.1)
    a.vwrite     a2, s11, v2
    v.ld.w       v1, [s13, #0]
    s.movz       s11, #7
    v.movi       v2, #0                          // other=, materialised (sec 12)
    @p4 v.ld.gather.w v2, [s24, v1]              // index is in elements (ISA sec 9.1)
    s.movz       s13, #8
    a.vwrite     a2, s10, v2
    a.vread      v1, a1, s4
    a.vread      v2, a2, s12
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s15
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s17
    v.extract    s4, v1, #3
    vf.fma       v8, v2, v4, v9
    v.splat      v2, s4
    a.vread      v4, a2, s9
    v.extract    s4, v1, #4
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s14
    v.extract    s4, v1, #5
    vf.fma       v8, v2, v4, v9
    v.splat      v2, s4
    a.vread      v4, a2, s8
    v.extract    s4, v1, #6
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s16
    v.extract    s4, v1, #7
    vf.fma       v8, v2, v4, v9
    v.splat      v2, s4
    a.vread      v4, a2, s11
    v.extract    s4, v1, #8
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s13
    s.movz       s4, #9
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #9
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #10
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #11
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #12
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #13
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #14
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #15
    v.splat      v1, s8
    a.vread      v2, a2, s4
    s.movz       s4, #1
    vf.fma       v4, v1, v2, v8
    s.movz       s8, #0
    s.movz       s9, #1
    s.movz       s10, #2
    a.vwrite     a3, s18, v4
    a.vread      v1, a1, s4
    a.vread      v2, a2, s8
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s9
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s10
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #1
    vf.fma       v8, v2, v4, v9
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #2
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s8
    a.vread      v2, a2, s9
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s11
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #2
    vf.fma       v8, v2, v4, v9
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #3
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s8
    a.vread      v2, a2, s9
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s11
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #4
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s8
    a.vread      v2, a2, s9
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s11
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v8, v2, v4, v9
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #5
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s8
    a.vread      v2, a2, s9
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s11
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #6
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s8
    a.vread      v2, a2, s9
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s11
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v8, v2, v4, v9
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #7
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s8
    a.vread      v2, a2, s9
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s11
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #8
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s8
    a.vread      v2, a2, s9
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s11
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v8, v2, v4, v9
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #9
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s8
    a.vread      v2, a2, s9
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s11
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #9
    vf.fma       v8, v2, v4, v9
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #10
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s8
    a.vread      v2, a2, s9
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s11
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #10
    vf.fma       v8, v2, v4, v9
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #11
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s8
    a.vread      v2, a2, s9
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s11
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #11
    vf.fma       v8, v2, v4, v9
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #12
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s8
    a.vread      v2, a2, s9
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s11
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #12
    vf.fma       v8, v2, v4, v9
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #13
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s8
    a.vread      v2, a2, s9
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s11
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #13
    vf.fma       v8, v2, v4, v9
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #14
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s8
    a.vread      v2, a2, s9
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v9, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s11
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v9
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v9, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #14
    vf.fma       v8, v2, v4, v9
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v9, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v9
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #15
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    s.movz       s10, #1
    s.movz       s11, #2
    a.vwrite     a3, s4, v4
    a.vread      v1, a1, s8
    a.vread      v2, a2, s9
    v.extract    s4, v1, #0
    v.splat      v4, s4
    v.extract    s4, v1, #1
    vf.fma       v8, v4, v2, v7
    v.splat      v2, s4
    a.vread      v4, a2, s10
    v.extract    s4, v1, #2
    vf.fma       v7, v2, v4, v8
    v.splat      v2, s4
    a.vread      v4, a2, s11
    s.movz       s4, #3
    vf.fma       v8, v2, v4, v7
    v.extract    s8, v1, #3
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #4
    vf.fma       v7, v2, v4, v8
    v.extract    s8, v1, #4
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #5
    vf.fma       v8, v2, v4, v7
    v.extract    s8, v1, #5
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #6
    vf.fma       v7, v2, v4, v8
    v.extract    s8, v1, #6
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #7
    vf.fma       v8, v2, v4, v7
    v.extract    s8, v1, #7
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #8
    vf.fma       v7, v2, v4, v8
    v.extract    s8, v1, #8
    v.splat      v2, s8
    a.vread      v4, a2, s4
    s.movz       s4, #15
    vf.fma       v8, v2, v4, v7
    s.movz       s8, #9
    v.extract    s9, v1, #9
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #10
    vf.fma       v7, v2, v4, v8
    v.extract    s9, v1, #10
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #11
    vf.fma       v8, v2, v4, v7
    v.extract    s9, v1, #11
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #12
    vf.fma       v7, v2, v4, v8
    v.extract    s9, v1, #12
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #13
    vf.fma       v8, v2, v4, v7
    v.extract    s9, v1, #13
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #14
    vf.fma       v7, v2, v4, v8
    v.extract    s9, v1, #14
    v.splat      v2, s9
    a.vread      v4, a2, s8
    s.movz       s8, #15
    vf.fma       v8, v2, v4, v7
    v.extract    s9, v1, #15
    v.splat      v1, s9
    a.vread      v2, a2, s8
    s.movz       s8, #0
    vf.fma       v4, v1, v2, v8
    s.movz       s9, #0
    // a computed 16x16 tile, into an accumulator (ISA sec 9B)
    s.movz       s10, #0
    s.movz       s11, #1
    a.vwrite     a3, s4, v4
    a.vread      v1, a0, s8
    a.vread      v2, a3, s9
    s.movz       s4, #1
    vf.add       v4, v1, v2
    s.movz       s8, #1
    s.movz       s9, #2
    s.movz       s12, #2
    a.vwrite     a4, s10, v4
    a.vread      v1, a0, s11
    a.vread      v2, a3, s4
    s.movz       s4, #2
    vf.add       v4, v1, v2
    s.movz       s10, #3
    s.movz       s11, #3
    s.movz       s13, #3
    a.vwrite     a4, s8, v4
    a.vread      v1, a0, s9
    a.vread      v2, a3, s12
    s.movz       s8, #4
    vf.add       v4, v1, v2
    s.movz       s9, #4
    s.movz       s12, #4
    s.movz       s14, #5
    a.vwrite     a4, s4, v4
    a.vread      v1, a0, s10
    a.vread      v2, a3, s11
    s.movz       s4, #5
    vf.add       v4, v1, v2
    s.movz       s10, #5
    s.movz       s11, #6
    s.movz       s15, #6
    a.vwrite     a4, s13, v4
    a.vread      v1, a0, s8
    a.vread      v2, a3, s9
    s.movz       s8, #6
    vf.add       v4, v1, v2
    s.movz       s9, #7
    s.movz       s13, #7
    s.movz       s16, #7
    a.vwrite     a4, s12, v4
    a.vread      v1, a0, s14
    a.vread      v2, a3, s4
    s.movz       s4, #8
    vf.add       v4, v1, v2
    s.movz       s12, #8
    s.movz       s14, #8
    s.movz       s17, #9
    a.vwrite     a4, s10, v4
    a.vread      v1, a0, s11
    a.vread      v2, a3, s15
    s.movz       s10, #9
    vf.add       v4, v1, v2
    s.movz       s11, #9
    s.movz       s15, #10
    s.movz       s18, #10
    a.vwrite     a4, s8, v4
    a.vread      v1, a0, s9
    a.vread      v2, a3, s13
    s.movz       s8, #10
    vf.add       v4, v1, v2
    s.movz       s9, #11
    s.movz       s13, #11
    s.movz       s19, #11
    a.vwrite     a4, s16, v4
    a.vread      v1, a0, s4
    a.vread      v2, a3, s12
    s.movz       s4, #12
    vf.add       v4, v1, v2
    s.movz       s12, #12
    s.movz       s16, #12
    a.vwrite     a4, s14, v4
    a.vread      v1, a0, s17
    a.vread      v2, a3, s10
    s.movz       s10, #13
    vf.add       v4, v1, v2
    s.movz       s14, #13
    s.movz       s17, #13
    a.vwrite     a4, s11, v4
    a.vread      v1, a0, s15
    a.vread      v2, a3, s18
    s.movz       s11, #14
    vf.add       v4, v1, v2
    s.movz       s15, #14
    s.movz       s18, #14
    a.vwrite     a4, s8, v4
    a.vread      v1, a0, s9
    a.vread      v2, a3, s13
    s.movz       s8, #15
    vf.add       v4, v1, v2
    s.movz       s9, #15
    s.movz       s13, #15
    a.vwrite     a4, s19, v4
    a.vread      v1, a0, s4
    a.vread      v2, a3, s12
    s.movz       s4, #0
    vf.add       v4, v1, v2
    s.movz       s12, #0
    s.movz       s19, #1
    a.vwrite     a4, s16, v4
    a.vread      v1, a0, s10
    a.vread      v2, a3, s14
    s.movz       s10, #1
    vf.add       v4, v1, v2
    s.movz       s14, #2
    s.movz       s16, #2
    a.vwrite     a4, s17, v4
    a.vread      v1, a0, s11
    a.vread      v2, a3, s15
    s.movz       s11, #3
    vf.add       v4, v1, v2
    s.movz       s15, #3
    s.movz       s17, #4
    a.vwrite     a4, s18, v4
    a.vread      v1, a0, s8
    a.vread      v2, a3, s9
    s.movz       s8, #4
    vf.add       v4, v1, v2
    s.movz       s9, #5
    s.movz       s18, #5
    a.vwrite     a4, s13, v4
    a.vread      v1, a4, s4
    s.movz       s4, #6
    a.vwrite     a0, s12, v1
    a.vread      v1, a4, s19
    s.movz       s12, #6
    a.vwrite     a0, s10, v1
    a.vread      v1, a4, s14
    s.movz       s10, #7
    a.vwrite     a0, s16, v1
    a.vread      v1, a4, s11
    s.movz       s11, #7
    a.vwrite     a0, s15, v1
    a.vread      v1, a4, s17
    s.movz       s13, #8
    a.vwrite     a0, s8, v1
    a.vread      v1, a4, s9
    s.movz       s8, #8
    a.vwrite     a0, s18, v1
    a.vread      v1, a4, s4
    s.movz       s4, #9
    a.vwrite     a0, s12, v1
    a.vread      v1, a4, s10
    s.movz       s9, #9
    a.vwrite     a0, s11, v1
    a.vread      v1, a4, s13
    s.movz       s10, #10
    a.vwrite     a0, s8, v1
    a.vread      v1, a4, s4
    s.movz       s4, #10
    a.vwrite     a0, s9, v1
    a.vread      v1, a4, s10
    s.movz       s8, #11
    a.vwrite     a0, s4, v1
    s.movz       s4, #11
    a.vread      v1, a4, s8
    s.movz       s8, #12
    a.vwrite     a0, s4, v1
    s.movz       s4, #12
    a.vread      v1, a4, s8
    s.movz       s8, #13
    a.vwrite     a0, s4, v1
    s.movz       s4, #13
    a.vread      v1, a4, s8
    s.movz       s8, #14
    a.vwrite     a0, s4, v1
    s.movz       s4, #14
    a.vread      v1, a4, s8
    s.movz       s8, #15
    a.vwrite     a0, s4, v1
    s.movz       s4, #15
    a.vread      v1, a4, s8
    s.add        s8, s7, s26
    s.movz       s9, #1
    a.vwrite     a0, s4, v1
    s.mov        s7, s8
    br.nz        s9, for_1
endfor_2:
    s.muli       s4, s5, #256                    // a runtime tile origin, x256
    s.movz       s5, #0
    s.movz       s6, #256
    v.extract    s7, v5, #0
    v.extract    s8, v5, #1
    v.splat      v0, s7
    v.splat      v1, s1
    s.add        s1, s5, s4                      // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    v.splat      v4, s6
    v.splat      v7, s8
    v.extract    s4, v13, #0
    v.extract    s5, v13, #1
    v.extract    s6, v13, #2
    v.splat      v8, s4
    v.mul        v9, v0, v1
    v.mul        v0, v2, v4
    v.splat      v2, s1
    v.splat      v4, s5
    v.mul        v11, v7, v1
    v.splat      v7, s6
    v.add        v12, v8, v9
    v.add        v8, v0, v2
    v.add        v0, v4, v11
    v.movi       v2, #1
    v.extract    s1, v5, #2
    v.movi       v4, #1
    v.movi       v9, #0
    v.movi       v11, #1
    s.addi       s4, s2, #3136
    v.add        v14, v12, v8
    v.add        v12, v0, v8
    v.cmp.lt     p1, v10, v2
    v.splat      v0, s1
    v.movi       v2, #0
    v.mul        v10, v0, v1
    v.cmp.lt     p2, v5, v3
    v.add        v0, v7, v10
    v.splat      v7, s3
    @p1 v.sel        v10, v4, v9
    v.add        v4, v0, v8
    @p2 v.sel        v0, v11, v2
    v.extract    s1, v13, #3
    v.movi       v2, #1
    v.movi       v9, #0
    v.add        v11, v7, v14
    s.addi       s3, s4, #64
    v.add        v14, v7, v12
    s.addi       s5, s4, #128
    v.add        v12, v7, v4
    s.addi       s6, s4, #192
    v.cmp.lt     p1, v13, v3
    v.extract    s7, v5, #3
    @p1 v.sel        v4, v2, v9
    v.splat      v2, s7
    v.st.w       [s4, #0], v11
    v.splat      v9, s1
    v.mul        v11, v2, v1
    v.cmp.lt     p1, v6, v3
    v.extract    s1, v5, #4
    v.extract    s7, v5, #5
    v.extract    s8, v5, #6
    v.splat      v2, s1
    v.splat      v3, s7
    v.extract    s1, v13, #4
    v.extract    s7, v13, #5
    v.extract    s9, v13, #6
    v.mul        v6, v2, v1
    v.mul        v2, v3, v1
    v.add        v3, v9, v11
    v.splat      v9, s8
    v.add        v11, v3, v8
    v.mul        v3, v9, v1
    v.add        v9, v7, v11
    s.addi       s8, s4, #256
    v.st.w       [s3, #0], v14
    v.extract    s3, v5, #7
    v.splat      v11, s3
    v.extract    s3, v13, #7
    v.mul        v14, v11, v1
    v.st.w       [s5, #0], v12
    v.extract    s5, v5, #8
    v.splat      v11, s5
    v.extract    s5, v13, #8
    v.mul        v12, v11, v1
    v.st.w       [s6, #0], v9
    v.splat      v9, s1
    v.extract    s1, v5, #9
    v.extract    s6, v13, #9
    v.add        v11, v9, v6
    v.splat      v6, s1
    v.add        v9, v11, v8
    v.mul        v11, v6, v1
    v.add        v6, v7, v9
    s.addi       s1, s4, #320
    v.st.w       [s8, #0], v6
    v.splat      v6, s7
    v.extract    s7, v5, #10
    v.extract    s8, v13, #10
    v.add        v9, v6, v2
    v.splat      v2, s7
    v.add        v6, v9, v8
    v.mul        v9, v2, v1
    v.add        v2, v7, v6
    s.addi       s7, s4, #384
    v.st.w       [s1, #0], v2
    v.splat      v2, s9
    v.extract    s1, v5, #11
    v.extract    s9, v13, #11
    v.add        v6, v2, v3
    v.splat      v2, s1
    v.add        v3, v6, v8
    v.mul        v6, v2, v1
    v.add        v2, v7, v3
    s.addi       s1, s4, #448
    v.st.w       [s7, #0], v2
    v.splat      v2, s3
    v.extract    s3, v5, #12
    v.extract    s7, v13, #12
    v.add        v3, v2, v14
    v.splat      v2, s3
    v.add        v14, v3, v8
    v.mul        v3, v2, v1
    v.add        v2, v7, v14
    s.addi       s3, s4, #512
    v.st.w       [s1, #0], v2
    v.splat      v2, s5
    v.extract    s1, v5, #13
    v.extract    s5, v13, #13
    v.add        v14, v2, v12
    v.splat      v2, s1
    v.add        v12, v14, v8
    v.mul        v14, v2, v1
    v.add        v2, v7, v12
    s.addi       s1, s4, #576
    v.st.w       [s3, #0], v2
    v.splat      v2, s6
    v.extract    s3, v5, #14
    v.extract    s6, v13, #14
    v.add        v12, v2, v11
    v.splat      v2, s3
    v.add        v11, v12, v8
    v.mul        v12, v2, v1
    v.add        v2, v7, v11
    s.addi       s3, s4, #640
    v.st.w       [s1, #0], v2
    v.splat      v2, s8
    v.extract    s1, v5, #15
    v.extract    s8, v13, #15
    v.splat      v5, s9
    v.splat      v11, s7
    v.add        v13, v2, v9
    v.splat      v2, s1
    v.add        v9, v5, v6
    v.splat      v5, s5
    v.add        v6, v11, v3
    v.splat      v3, s6
    v.add        v11, v5, v14
    v.splat      v5, s8
    v.add        v14, v3, v12
    v.add        v3, v13, v8
    v.mul        v12, v2, v1
    v.add        v1, v9, v8
    v.add        v2, v6, v8
    v.add        v6, v11, v8
    v.add        v9, v14, v8
    v.add        v11, v7, v3
    v.add        v3, v5, v12
    s.addi       s1, s4, #704
    v.add        v5, v7, v1
    s.addi       s5, s4, #768
    v.add        v1, v7, v2
    s.addi       s6, s4, #832
    v.add        v2, v7, v6
    s.addi       s7, s4, #896
    v.add        v6, v7, v9
    s.addi       s8, s4, #960
    v.st.w       [s3, #0], v11
    v.add        v9, v3, v8
    s.movz       s3, #0
    v.add        v3, v7, v9
    s.addi       s4, s2, #3136
    v.extract    s9, v10, #0
    v.splat      v7, s9
    v.st.w       [s1, #0], v5
    v.extract    s1, v0, #0
    v.movi       v5, #0
    v.splat      v8, s1
    v.movi       v9, #0
    v.extract    s1, v4, #0
    v.cmp.ne     p2, v7, v5
    v.cmp.ne     p3, v8, v9
    v.splat      v5, s1
    v.movi       v7, #0
    v.st.w       [s5, #0], v1
    p.and        p4, p2, p3
    v.cmp.ne     p2, v5, v7
    p.and        p3, p4, p2
    s.movz       s1, #1
    p.and        p2, p3, p1
    s.addi       s5, s2, #3200
    v.extract    s9, v10, #1
    v.splat      v1, s9
    v.st.w       [s6, #0], v2
    v.extract    s6, v0, #1
    v.movi       v2, #0
    v.splat      v5, s6
    v.movi       v7, #0
    v.extract    s6, v4, #1
    v.cmp.ne     p3, v1, v2
    v.cmp.ne     p4, v5, v7
    v.splat      v1, s6
    v.movi       v2, #0
    v.st.w       [s7, #0], v6
    p.and        p5, p3, p4
    v.cmp.ne     p3, v1, v2
    p.and        p4, p5, p3
    s.movz       s6, #2
    p.and        p3, p4, p1
    s.addi       s7, s2, #3264
    v.extract    s9, v10, #2
    v.splat      v1, s9
    v.st.w       [s8, #0], v3
    fence.acq_rel.device
    a.vread      v2, a0, s3
    v.extract    s3, v0, #2
    v.movi       v3, #0
    v.splat      v5, s3
    v.movi       v6, #0
    v.cmp.ne     p4, v1, v3
    v.ld.w       v1, [s4, #0]
    v.extract    s3, v4, #2
    v.splat      v3, s3
    v.movi       v7, #0
    s.movz       s3, #3
    s.addi       s4, s2, #3328
    v.extract    s8, v10, #3
    v.splat      v8, s8
    v.movi       v9, #0
    @p2 v.st.scatter.w [s25, v1], v2
    a.vread      v1, a0, s1
    v.cmp.ne     p2, v5, v6
    p.and        p5, p4, p2
    v.cmp.ne     p2, v3, v7
    p.and        p4, p5, p2
    v.extract    s1, v0, #3
    p.and        p2, p4, p1
    v.splat      v2, s1
    v.movi       v3, #0
    v.ld.w       v5, [s5, #0]
    v.extract    s1, v4, #3
    v.cmp.ne     p4, v8, v9
    v.splat      v6, s1
    v.movi       v7, #0
    s.movz       s1, #4
    s.addi       s5, s2, #3392
    v.extract    s8, v10, #4
    v.splat      v8, s8
    v.movi       v9, #0
    @p3 v.st.scatter.w [s25, v5], v1
    a.vread      v1, a0, s6
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v6, v7
    p.and        p4, p5, p3
    v.extract    s6, v0, #4
    p.and        p3, p4, p1
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v5, [s7, #0]
    v.extract    s6, v4, #4
    v.cmp.ne     p4, v8, v9
    v.splat      v6, s6
    v.movi       v7, #0
    s.movz       s6, #5
    s.addi       s7, s2, #3456
    v.extract    s8, v10, #5
    v.splat      v8, s8
    v.movi       v9, #0
    @p2 v.st.scatter.w [s25, v5], v1
    a.vread      v1, a0, s3
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v6, v7
    p.and        p4, p5, p2
    v.extract    s3, v0, #5
    p.and        p2, p4, p1
    v.splat      v2, s3
    v.movi       v3, #0
    v.ld.w       v5, [s4, #0]
    v.extract    s3, v4, #5
    v.cmp.ne     p4, v8, v9
    v.splat      v6, s3
    v.movi       v7, #0
    s.movz       s3, #6
    s.addi       s4, s2, #3520
    v.extract    s8, v10, #6
    v.splat      v8, s8
    v.movi       v9, #0
    @p3 v.st.scatter.w [s25, v5], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v6, v7
    p.and        p4, p5, p3
    v.extract    s1, v0, #6
    p.and        p3, p4, p1
    v.splat      v2, s1
    v.movi       v3, #0
    v.ld.w       v5, [s5, #0]
    v.extract    s1, v4, #6
    v.cmp.ne     p4, v8, v9
    v.splat      v6, s1
    v.movi       v7, #0
    s.movz       s1, #7
    s.addi       s5, s2, #3584
    v.extract    s8, v10, #7
    v.splat      v8, s8
    v.movi       v9, #0
    @p2 v.st.scatter.w [s25, v5], v1
    a.vread      v1, a0, s6
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v6, v7
    p.and        p4, p5, p2
    v.extract    s6, v0, #7
    p.and        p2, p4, p1
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v5, [s7, #0]
    v.extract    s6, v4, #7
    v.cmp.ne     p4, v8, v9
    v.splat      v6, s6
    v.movi       v7, #0
    s.movz       s6, #8
    s.addi       s7, s2, #3648
    v.extract    s8, v10, #8
    v.splat      v8, s8
    v.movi       v9, #0
    @p3 v.st.scatter.w [s25, v5], v1
    a.vread      v1, a0, s3
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v6, v7
    p.and        p4, p5, p3
    v.extract    s3, v0, #8
    p.and        p3, p4, p1
    v.splat      v2, s3
    v.movi       v3, #0
    v.ld.w       v5, [s4, #0]
    v.extract    s3, v4, #8
    v.cmp.ne     p4, v8, v9
    v.splat      v6, s3
    v.movi       v7, #0
    s.movz       s3, #9
    s.addi       s4, s2, #3712
    v.extract    s8, v10, #9
    v.splat      v8, s8
    v.movi       v9, #0
    @p2 v.st.scatter.w [s25, v5], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v6, v7
    p.and        p4, p5, p2
    v.extract    s1, v0, #9
    p.and        p2, p4, p1
    v.splat      v2, s1
    v.movi       v3, #0
    v.ld.w       v5, [s5, #0]
    v.extract    s1, v4, #9
    v.cmp.ne     p4, v8, v9
    v.splat      v6, s1
    v.movi       v7, #0
    s.movz       s1, #10
    s.addi       s5, s2, #3776
    v.extract    s8, v10, #10
    v.splat      v8, s8
    v.movi       v9, #0
    @p3 v.st.scatter.w [s25, v5], v1
    a.vread      v1, a0, s6
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v6, v7
    p.and        p4, p5, p3
    v.extract    s6, v0, #10
    p.and        p3, p4, p1
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v5, [s7, #0]
    v.extract    s6, v4, #10
    v.cmp.ne     p4, v8, v9
    v.splat      v6, s6
    v.movi       v7, #0
    s.movz       s6, #11
    s.addi       s7, s2, #3840
    v.extract    s8, v10, #11
    v.splat      v8, s8
    v.movi       v9, #0
    @p2 v.st.scatter.w [s25, v5], v1
    a.vread      v1, a0, s3
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v6, v7
    p.and        p4, p5, p2
    v.extract    s3, v0, #11
    p.and        p2, p4, p1
    v.splat      v2, s3
    v.movi       v3, #0
    v.ld.w       v5, [s4, #0]
    v.extract    s3, v4, #11
    v.cmp.ne     p4, v8, v9
    v.splat      v6, s3
    v.movi       v7, #0
    s.movz       s3, #12
    s.addi       s4, s2, #3904
    v.extract    s8, v10, #12
    v.splat      v8, s8
    v.movi       v9, #0
    @p3 v.st.scatter.w [s25, v5], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v6, v7
    p.and        p4, p5, p3
    v.extract    s1, v0, #12
    p.and        p3, p4, p1
    v.splat      v2, s1
    v.movi       v3, #0
    v.ld.w       v5, [s5, #0]
    v.extract    s1, v4, #12
    v.cmp.ne     p4, v8, v9
    v.splat      v6, s1
    v.movi       v7, #0
    s.movz       s1, #13
    s.addi       s5, s2, #3968
    v.extract    s8, v10, #13
    v.splat      v8, s8
    v.movi       v9, #0
    @p2 v.st.scatter.w [s25, v5], v1
    a.vread      v1, a0, s6
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v6, v7
    p.and        p4, p5, p2
    v.extract    s6, v0, #13
    p.and        p2, p4, p1
    v.splat      v2, s6
    v.movi       v3, #0
    v.ld.w       v5, [s7, #0]
    v.extract    s6, v4, #13
    v.cmp.ne     p4, v8, v9
    v.splat      v6, s6
    v.movi       v7, #0
    s.movz       s6, #14
    s.addi       s7, s2, #4032
    v.extract    s8, v10, #14
    v.splat      v8, s8
    v.movi       v9, #0
    @p3 v.st.scatter.w [s25, v5], v1
    a.vread      v1, a0, s3
    v.cmp.ne     p3, v2, v3
    p.and        p5, p4, p3
    v.cmp.ne     p3, v6, v7
    p.and        p4, p5, p3
    v.extract    s3, v0, #14
    p.and        p3, p4, p1
    v.splat      v2, s3
    v.movi       v3, #0
    v.ld.w       v5, [s4, #0]
    v.extract    s3, v4, #14
    v.cmp.ne     p4, v8, v9
    v.splat      v6, s3
    v.movi       v7, #0
    s.movz       s3, #15
    s.addi       s4, s2, #4096
    v.extract    s2, v10, #15
    v.splat      v8, s2
    v.movi       v9, #0
    @p2 v.st.scatter.w [s25, v5], v1
    a.vread      v1, a0, s1
    v.cmp.ne     p2, v2, v3
    p.and        p5, p4, p2
    v.cmp.ne     p2, v6, v7
    p.and        p4, p5, p2
    v.extract    s1, v0, #15
    p.and        p2, p4, p1
    v.splat      v0, s1
    v.movi       v2, #0
    v.ld.w       v3, [s5, #0]
    v.extract    s1, v4, #15
    v.cmp.ne     p4, v8, v9
    v.splat      v4, s1
    v.movi       v5, #0
    @p3 v.st.scatter.w [s25, v3], v1
    a.vread      v1, a0, s6
    v.cmp.ne     p3, v0, v2
    p.and        p5, p4, p3
    v.cmp.ne     p3, v4, v5
    p.and        p4, p5, p3
    p.and        p3, p4, p1
    v.ld.w       v0, [s7, #0]
    @p2 v.st.scatter.w [s25, v0], v1
    a.vread      v0, a0, s3
    v.ld.w       v1, [s4, #0]
    @p3 v.st.scatter.w [s25, v1], v0
__rctx_next:
    exit
