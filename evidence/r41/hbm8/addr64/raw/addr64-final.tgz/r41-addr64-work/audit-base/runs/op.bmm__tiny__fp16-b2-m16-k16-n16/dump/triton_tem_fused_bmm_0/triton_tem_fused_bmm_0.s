    s.rdspecial  s1, role_id
    s.rdspecial  s2, pid.x
    s.rdspecial  s3, npid.x
    s.add        s4, s2, s1
    s.cmp.ge     s1, s4, s3
    br.nz        s1, __rctx_next
__rctx_program:
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #0]                    // arg_A: device_ptr64 at arg_base+0
    s.ld.d       s3, [s1, #8]                    // arg_B: device_ptr64 at arg_base+8
    s.ld.d       s5, [s1, #16]                   // out_ptr0: device_ptr64 at arg_base+16
    s.rdspecial  s1, arg_base
    s.ld.d       s6, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s7, #512
    s.mul        s8, s1, s7
    s.add        s1, s6, s8                      // this context's own scratch
    s.addi       s6, s1, #0                      // TensorMap 0: a 2-D tt.load (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s6, #0], s2
    .li       s1, #2147483647
    s.st.d       [s6, #8], s1
    .li       s1, #2147483647
    s.st.d       [s6, #16], s1
    s.movz       s1, #32
    s.st.d       [s6, #48], s1
    s.movz       s1, #2
    s.st.d       [s6, #56], s1
    .li       s1, #68719476752
    s.st.d       [s6, #88], s1
    .li       s1, #8589934592
    s.st.d       [s6, #104], s1
    fence.release.device
    td.load      d0, [s6]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.rdspecial  s1, arg_base
    s.ld.d       s2, [s1, #24]                   // descriptor scratch: one slot past the declared arguments (ABI v1 offsets are unchanged)
    s.rdspecial  s1, role_id
    s.movz       s6, #512
    s.mul        s7, s1, s6
    s.add        s1, s2, s7                      // this context's own scratch
    s.addi       s2, s1, #256                    // TensorMap 1: a 2-D tt.load (built once, at entry)
    s.movz       s1, #0
    s.st.d       [s2, #0], s3
    .li       s1, #2147483647
    s.st.d       [s2, #8], s1
    .li       s1, #2147483647
    s.st.d       [s2, #16], s1
    s.movz       s1, #32
    s.st.d       [s2, #48], s1
    s.movz       s1, #2
    s.st.d       [s2, #56], s1
    .li       s1, #68719476752
    s.st.d       [s2, #88], s1
    .li       s1, #8589934592
    s.st.d       [s2, #104], s1
    fence.release.device
    td.load      d1, [s2]                        // a versioned snapshot, not a pointer (ISA sec 9D.1)
    s.movz       s1, #1
    s.movz       s2, #0
    s.movz       s3, #0
    s.movz       s6, #0
    s.movz       s7, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.movz       s10, #1
    s.sub        s11, s1, s4
    s.min.s      s12, s11, s1
    s.cmp.lt     s11, s4, s3
    s.sub        s3, s2, s11
    s.cmp.lt     s2, s12, s7
    s.sub        s7, s6, s2
    s.xor        s2, s4, s3
    s.sub        s6, s2, s3
    s.xor        s2, s12, s7
    s.sub        s11, s2, s7
    s.addi       s2, s8, #0
    s.addi       s7, s9, #0
    s.cmp.eq     s8, s11, s10
    s.mov        s2, s6
    br.nz        s8, sdiv_done_1
    s.movz       s8, #0
    s.movz       s9, #31
    s.mov        s2, s8
    s.addi       s8, s9, #0
sdiv_2:
    s.lshr       s9, s6, s8
    s.shli       s10, s7, #1
    s.andi       s13, s9, #1
    s.movz       s9, #0
    s.or         s14, s10, s13
    s.movz       s10, #1
    s.cmp.geu    s13, s14, s11
    s.shl        s15, s10, s8
    s.sub        s10, s9, s13
    s.subi       s9, s8, #1
    s.and        s13, s11, s10
    s.and        s16, s15, s10
    s.sub        s10, s14, s13
    s.or         s13, s2, s16
    s.mov        s7, s10
    s.mov        s2, s13
    s.mov        s8, s9
    s.movz       s9, #0
    s.cmp.ge     s10, s8, s9
    br.nz        s10, sdiv_2
sdiv_done_1:
    s.movz       s2, #0
    s.movz       s6, #0
    s.movz       s8, #0
    s.movz       s9, #0
    s.cmp.lt     s10, s12, s2
    s.movz       s2, #0
    s.cmp.lt     s11, s6, s8
    s.sub        s8, s9, s10
    s.sub        s9, s2, s11
    s.xor        s2, s12, s8
    s.xor        s10, s7, s3
    s.xor        s7, s6, s9
    s.sub        s11, s2, s8
    s.movz       s2, #0
    s.movz       s12, #1
    s.sub        s13, s10, s3
    s.sub        s3, s7, s9
    s.movz       s7, #0
    s.addi       s10, s2, #0
    s.cmp.eq     s2, s11, s12
    s.add        s12, s4, s13
    s.addi       s4, s7, #0
    s.mov        s10, s3
    br.nz        s2, sdiv_done_3
    s.movz       s2, #0
    s.movz       s7, #31
    s.mov        s10, s2
    s.addi       s2, s7, #0
sdiv_4:
    s.lshr       s7, s3, s2
    s.shli       s13, s4, #1
    s.andi       s14, s7, #1
    s.movz       s7, #0
    s.or         s15, s13, s14
    s.movz       s13, #1
    s.cmp.geu    s14, s15, s11
    s.shl        s16, s13, s2
    s.sub        s13, s7, s14
    s.subi       s7, s2, #1
    s.and        s14, s11, s13
    s.and        s17, s16, s13
    s.sub        s13, s15, s14
    s.or         s14, s10, s17
    s.mov        s4, s13
    s.mov        s10, s14
    s.mov        s2, s7
    s.movz       s7, #0
    s.cmp.ge     s13, s2, s7
    br.nz        s13, sdiv_4
sdiv_done_3:
    s.rdspecial  s2, pid.z
    s.rdspecial  s3, npid.y
    s.xor        s4, s9, s8
    s.mul        s7, s2, s3
    s.rdspecial  s2, pid.y
    s.xor        s3, s10, s4
    s.movz       s8, #16
    s.sub        s9, s3, s4
    s.add        s3, s2, s7
    s.mul        s2, s12, s8
    s.min.s      s4, s3, s1
    s.movz       s1, #256
    s.mul        s7, s9, s8
    s.mul        s10, s4, s1
    w.def        w0, #56, #8                     // v56..v63
    mb.arm       s4, b0, #0, #1                  // 0 arrival(s), 1 operation(s)
    s.andi       s11, s2, #15
    s.andi       s13, s7, #15
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s14, s11                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s15, s10                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w0, d0, s14, s4
    mb.wait      s4
    w.def        w1, #48, #8                     // v48..v55
    mb.arm       s14, b1, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s15, #0
    s.add        s16, s13, s10
    v.movi       v0, #0
    // a 2-D tt.load: one tile into a window (ISA sec 9E)
    s.mov        s17, s15                        // coordinates must be consecutive (ISA sec 9E)
    s.mov        s18, s16                        // coordinates must be consecutive (ISA sec 9E)
    t.ld.async.h w1, d1, s17, s14
    mb.wait      s14
    m.zero       a0
    mb.arm       s10, b2, #0, #1                 // 0 arrival(s), 1 operation(s)
    s.movz       s15, #2
    v.splat      v1, s3
    m.mma.async.k16.f16 a0, v56, v48, s10
    mb.wait      s10
    v.splat      v2, s15
    v.splat      v3, s12
    v.splat      v4, s6
    s.mul        s12, s3, s1
    v.cmp.lt     p1, v1, v2
    v.splat      v1, s9
    v.splat      v2, s6
    v.iota       v5                              // arange(0, VLEN)
    v.splat      v6, s2
    v.splat      v7, s7
    v.splat      v8, s11
    v.cmp.ge     p2, v3, v4
    s.muli       s1, s7, #2                      // a runtime tile origin, x2
    s.muli       s3, s2, #32                     // a runtime tile origin, x32
    v.iota       v3                              // arange(0, VLEN)
    v.splat      v4, s13
    v.cmp.ge     p2, v1, v2
    // a masked 16x16 tile with contiguous rows: one predicated store a row
    s.movz       s6, #0
    s.muli       s9, s12, #2                     // a runtime tile origin, x2
    a.vread      v1, a0, s6
    s.add        s6, s5, s1                      // the tile origin
    v.iota       v2                              // arange(0, VLEN)
    s.add        s1, s6, s3                      // the tile origin
    v.add        v9, v6, v5
    s.movz       s3, #0
    vf.add       v6, v1, v0
    s.add        s5, s1, s9                      // the tile origin
    v.add        v1, v7, v5
    s.add        s1, s3, s2                      // the tile origin
    v.splat      v1, s8
    v.splat      v5, s1
    vf.cvt.f32.f16 v7, v6
    v.add        v6, v8, v3
    s.movz       s2, #0
    v.iota       v3                              // arange(0, VLEN)
    s.add        s3, s2, s7                      // the tile origin
    v.cmp.lt     p2, v5, v1
    v.splat      v5, s3
    v.add        v6, v4, v2
    v.splat      v2, s8
    v.add        v4, v3, v5
    s.movz       s2, #1
    s.addi       s3, s1, #1
    v.cmp.lt     p3, v4, v2
    p.and        p4, p2, p3
    v.splat      v2, s3
    p.and        p2, p4, p1
    s.addi       s3, s5, #32                     // row 1
    @p2 v.st.h       [s5, #0], v7
    a.vread      v3, a0, s2
    v.cmp.lt     p2, v2, v1
    p.and        p4, p2, p3
    vf.add       v2, v3, v0
    p.and        p2, p4, p1
    s.movz       s2, #2
    s.addi       s6, s1, #2
    s.addi       s7, s5, #64                     // row 2
    vf.cvt.f32.f16 v3, v2
    v.splat      v2, s6
    s.movz       s6, #3
    s.addi       s8, s1, #3
    v.cmp.lt     p4, v2, v1
    @p2 v.st.h       [s3, #0], v3
    a.vread      v2, a0, s2
    p.and        p2, p4, p3
    v.splat      v3, s8
    vf.add       v4, v2, v0
    p.and        p4, p2, p1
    v.cmp.lt     p2, v3, v1
    p.and        p5, p2, p3
    s.addi       s2, s5, #96                     // row 3
    vf.cvt.f32.f16 v2, v4
    p.and        p2, p5, p1
    s.movz       s3, #4
    s.addi       s8, s1, #4
    s.addi       s9, s5, #128                    // row 4
    @p4 v.st.h       [s7, #0], v2
    a.vread      v2, a0, s6
    v.splat      v3, s8
    s.movz       s6, #5
    vf.add       v4, v2, v0
    v.cmp.lt     p4, v3, v1
    p.and        p5, p4, p3
    s.addi       s7, s1, #5
    p.and        p4, p5, p1
    vf.cvt.f32.f16 v2, v4
    v.splat      v3, s7
    s.addi       s7, s5, #160                    // row 5
    s.movz       s8, #6
    s.addi       s11, s1, #6
    @p2 v.st.h       [s2, #0], v2
    a.vread      v2, a0, s3
    v.cmp.lt     p2, v3, v1
    p.and        p5, p2, p3
    vf.add       v3, v2, v0
    p.and        p2, p5, p1
    v.splat      v2, s11
    s.addi       s2, s5, #192                    // row 6
    s.movz       s3, #7
    vf.cvt.f32.f16 v4, v3
    s.addi       s11, s1, #7
    s.addi       s12, s5, #224                   // row 7
    v.splat      v3, s11
    s.movz       s11, #8
    @p4 v.st.h       [s9, #0], v4
    a.vread      v4, a0, s6
    v.cmp.lt     p4, v2, v1
    p.and        p5, p4, p3
    vf.add       v2, v4, v0
    p.and        p4, p5, p1
    s.addi       s6, s1, #8
    s.addi       s9, s5, #256                    // row 8
    v.splat      v4, s6
    vf.cvt.f32.f16 v5, v2
    s.movz       s6, #9
    s.addi       s13, s1, #9
    s.addi       s15, s5, #288                   // row 9
    v.splat      v2, s13
    @p2 v.st.h       [s7, #0], v5
    a.vread      v5, a0, s8
    v.cmp.lt     p2, v3, v1
    p.and        p5, p2, p3
    vf.add       v3, v5, v0
    p.and        p2, p5, p1
    s.movz       s7, #10
    s.addi       s8, s1, #10
    s.addi       s13, s5, #320                   // row 10
    vf.cvt.f32.f16 v5, v3
    v.splat      v3, s8
    s.movz       s8, #11
    @p4 v.st.h       [s2, #0], v5
    a.vread      v5, a0, s3
    v.cmp.lt     p4, v4, v1
    p.and        p5, p4, p3
    vf.add       v4, v5, v0
    p.and        p4, p5, p1
    s.addi       s2, s1, #11
    s.addi       s3, s5, #352                    // row 11
    v.splat      v5, s2
    vf.cvt.f32.f16 v6, v4
    s.movz       s2, #12
    @p2 v.st.h       [s12, #0], v6
    a.vread      v4, a0, s11
    v.cmp.lt     p2, v2, v1
    p.and        p5, p2, p3
    vf.add       v2, v4, v0
    p.and        p2, p5, p1
    s.addi       s11, s1, #12
    s.addi       s12, s5, #384                   // row 12
    v.splat      v4, s11
    vf.cvt.f32.f16 v6, v2
    s.movz       s11, #13
    @p4 v.st.h       [s9, #0], v6
    a.vread      v2, a0, s6
    v.cmp.lt     p4, v3, v1
    p.and        p5, p4, p3
    vf.add       v3, v2, v0
    p.and        p4, p5, p1
    s.addi       s6, s1, #13
    s.addi       s9, s5, #416                    // row 13
    v.splat      v2, s6
    vf.cvt.f32.f16 v6, v3
    s.movz       s6, #14
    @p2 v.st.h       [s15, #0], v6
    a.vread      v3, a0, s7
    v.cmp.lt     p2, v5, v1
    p.and        p5, p2, p3
    vf.add       v5, v3, v0
    p.and        p2, p5, p1
    s.addi       s7, s1, #14
    s.addi       s15, s5, #448                   // row 14
    v.splat      v3, s7
    vf.cvt.f32.f16 v6, v5
    s.movz       s7, #15
    @p4 v.st.h       [s13, #0], v6
    a.vread      v5, a0, s8
    v.cmp.lt     p4, v4, v1
    p.and        p5, p4, p3
    vf.add       v4, v5, v0
    p.and        p4, p5, p1
    s.addi       s8, s1, #15
    s.addi       s1, s5, #480                    // row 15
    v.splat      v5, s8
    vf.cvt.f32.f16 v6, v4
    @p2 v.st.h       [s3, #0], v6
    a.vread      v4, a0, s2
    v.cmp.lt     p2, v2, v1
    p.and        p5, p2, p3
    vf.add       v2, v4, v0
    p.and        p2, p5, p1
    vf.cvt.f32.f16 v4, v2
    @p4 v.st.h       [s12, #0], v4
    a.vread      v2, a0, s11
    v.cmp.lt     p4, v3, v1
    p.and        p5, p4, p3
    vf.add       v3, v2, v0
    p.and        p4, p5, p1
    vf.cvt.f32.f16 v2, v3
    @p2 v.st.h       [s9, #0], v2
    a.vread      v2, a0, s6
    v.cmp.lt     p2, v5, v1
    p.and        p5, p2, p3
    vf.add       v1, v2, v0
    p.and        p2, p5, p1
    vf.cvt.f32.f16 v2, v1
    @p4 v.st.h       [s15, #0], v2
    a.vread      v1, a0, s7
    vf.add       v2, v1, v0
    vf.cvt.f32.f16 v0, v2
    @p2 v.st.h       [s1, #0], v0
__rctx_next:
    exit
